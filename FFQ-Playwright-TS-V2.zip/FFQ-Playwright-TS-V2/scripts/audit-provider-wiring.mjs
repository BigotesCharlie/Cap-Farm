import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';

const expected = {
  'AceHomeDataProviders.class': 'aceHomeData',
  'AutoDataProviders.class': 'autoData',
  'AceBundleDataProviders.class': 'bundleData',
  'SqlDataProviders.class': 'sqlAutoData',
  'DataProviders.class': 'classicData',
  '': 'inlineData',
};
async function specs(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const nested = await Promise.all(entries.map((entry) =>
    entry.isDirectory() ? specs(join(directory, entry.name)) : [join(directory, entry.name)]));
  return nested.flat().filter((file) => file.endsWith('.spec.ts'));
}
const failures = [];
let checked = 0;
for (const file of await specs('tests/legacy')) {
  const text = await readFile(file, 'utf8');
  const declarations = [...text.matchAll(/test(?:\.skip)?\([^\n]+async \(\{ page, (\w+) \}/g)].map((m) => m[1]);
  const calls = [...text.matchAll(/executeMigratedScenario\(page, testInfo, (\w+), (\{[^\n]+\})\);/g)];
  if (declarations.length !== calls.length) failures.push(`${file}: declarations=${declarations.length}, calls=${calls.length}`);
  for (const [index, call] of calls.entries()) {
    let metadata;
    try { metadata = JSON.parse(call[2]); }
    catch { failures.push(`${file}: invalid metadata at ${index}`); continue; }
    const fixture = expected[metadata.dataProviderClass];
    if (!fixture || call[1] !== fixture || declarations[index] !== fixture) {
      failures.push(`${metadata.legacyId}: expected ${fixture ?? 'unmapped'}, got ${declarations[index]} / ${call[1]}`);
    }
    checked++;
  }
}
console.log(JSON.stringify({ checked, failures }, null, 2));
if (failures.length || checked !== 2941) process.exitCode = 1;
