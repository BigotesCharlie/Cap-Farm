# Configuración local del maestro

Esta copia de entrega incluye `.env` con los valores que se pudieron mapear directamente desde el maestro y los cuatro archivos de configuración originales y los archivos Java/XML que contienen referencias o valores de autenticación, sin modificar, en `config/legacy-master/`. La `.env` está ignorada por Git. No agregues estos archivos originales a un repositorio ni a un PR.

El runtime TS lee `.env`; conserva el resto del maestro para consulta durante la migración. Los campos `POSTGRES_*` siguen vacíos porque no se identificaron credenciales equivalentes en los archivos de configuración originales. Los valores del maestro no hacen que los flujos UI pendientes funcionen por sí solos.

La copia es para uso local y no se ha publicado como una nueva versión persistente.
