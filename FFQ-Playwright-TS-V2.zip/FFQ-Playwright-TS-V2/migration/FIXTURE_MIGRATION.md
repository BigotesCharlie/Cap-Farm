# Fixture migration status

Source: `ffq-test-master (1) 2(2).zip`, the Selenium/Java master supplied for this migration. Its eleven workbooks were byte-identical to the eleven formerly present in `data/legacy` of the TypeScript project. The source's five provider classes declare 40 providers; 36 distinct provider references occur in the 2,941 Playwright declarations.

## Converted sources

| Java source | Fixture catalog | Runtime selection |
| --- | --- | --- |
| `AceHomeDataProviders` | `AceHomeTestData` | Applicant category, state constraints, random row, one per state, discount children |
| `AutoDataProviders` | `OneUIAutoTestData`, `AutoDefaultCoveragesData` | Applicant/ADPF selections, household data, linked vehicles/drivers/incidents/discounts, coverages |
| `SqlDataProviders` | `AutoTestData` | Applicant sheets, joined vehicles/drivers/incidents/discounts/payments/representatives |
| `DataProviders` | `HomeTestData`, `HQMTestData`, `HQMApexTestData`, `LifeTestData`, `BusinessTestData`, `AceHomeTestData` | Product and provider-specific applicant source |
| `AceBundleDataProviders` | `OneUIAutoTestData` plus `AceHomeTestData` | Auto and Home selected from the same state |
| Direct Java test usage | `Nearmap+Roof+Age+Prefill+Test+Addresses` | State and evidence-specific address |
| Unreferenced source workbook | `auto_home_condo_renter_fees` | Preserved as catalog; no direct source-code filename reference found |

The catalog has 122 sheets, 26,869 populated rows, and 9,520 formula cells. 9,519 `TODAY()` date formulas resolve on the FFQ test date, defaulting to `America/Los_Angeles`. The one source array formula at `AutoDefaultCoveragesData/PA/P122` has a cached `#NAME?`; selection fails closed there. ZIP codes are stored as text. Original workbooks and the runtime Excel adapter were removed after conversion.

## Functional limit

The generated specs still call `executeMigratedScenario`; no UI handler is certified. Data selection and structural validation work, but no end-to-end test reaches a business decision or an application break yet. The recovery guard can observe a real test once its UI steps exist. It does not manufacture a PASS for a breakpoint or for a missing handler.

The selector covers the 36 provider references and the core Java filters. Provider-specific branches, data edits, environment behavior, and every UI assertion need case-level parity review against Java before certification. For example, source Java contains special behavior for ADPF, high-value Auto states, bind applicant mutation, HQM monetization, and legacy Home state support. An empty selection raises `FixtureSelectionError`; it is never a skip or PASS.

## Local verification performed

- ID parity: 2,941 unique declarations, no missing or duplicate legacy IDs.
- Catalog counts: eleven books, 122 sheets, 26,869 rows, 9,520 formulas.
- Formula evaluation: 9,519 source date formulas resolved; one pre-existing source error is explicit.
- Playwright discovery: 2,941 tests in 218 files.
- TypeScript strict compile: passed.
- HOME E2E sample data: three methods selected 1, 1, and 2 candidates in MA11 with the audit seed.
- Recovery guard: expected KnockOut stayed terminal, unexpected KnockOut without a verified action failed in an isolated mock.
- Browser E2E against FFQ: not run; no authenticated MA11/RA11 connection was available to this workspace.
