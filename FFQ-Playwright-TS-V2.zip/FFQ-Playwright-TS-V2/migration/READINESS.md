# Estado de migración y entrega

## Resultado medido

| Área | Estado | Evidencia / límite |
| --- | --- | --- |
| Inventario Java → TS | 2,941 identificadores de método en 218 archivos de spec | `npm run audit:parity`; la paridad de nombres no acredita comportamiento. |
| Fixtures Excel → JSON | 11 libros, 122 hojas, 26,869 filas | `npm run verify:data`; ningún test lee XLSX durante la ejecución. |
| Fixtures Playwright por proveedor | 2,941 declaraciones conectadas con su fixture de familia | `npm run audit:provider-wiring`; cada proveedor está en su propio módulo y `mergeTests` los compone. Las filas múltiples todavía no generan casos individuales. |
| Selección de DataProviders | 526/535 combinaciones representativas seleccionan filas en MA11 | `npm run audit:selection`; nueve combinaciones fallan y requieren resolver reglas o datos fuente. |
| Casos funcionales Playwright | **0/2,941** | El ejecutor selecciona fixture y falla antes de navegar porque no hay handler de UI; 2,691 tienen gate, 250 estaban deshabilitados en Java. |
| Locators | 142 IDs con dos puntos corregidos | Los Page Objects generados conservan XPath y locators provisionales `data-legacy-field`; no están comprobados contra DOM. |
| HealthCheck | Presente, automático en todos los specs | RecoveryGuard captura Inconvenience, KnockOut, TryAgain; Sentinel observa errores, permite `step`, CopyDOM y validación final. Los flujos existentes todavía no invocan `step` ni aserciones finales. |
| Ejecución FFQ | Pendiente | No se dispone en esta entrega de una sesión FFQ ni de Chromium instalado para validar UI. |

## Selecciones que no tienen fila en MA11

Estas condiciones producen error explícito, sin sustituir datos de otra prueba:

| Caso representativo | Proveedor y condición |
| --- | --- |
| `AceCondoAddressPageValidationTest#testFGIANotOfferingValidationCondoLob` | AceHome ApplicantHome, `INCLUDED_STATES={MA,NC}` |
| `AceCondoAddressPageValidationTest#testFGIALandingPageValidationCondoLob` | AceHome ApplicantHome, filtro de estado del método |
| `AutoSaveAndRetrieveQuoteTests#validateAgeOfPNIisNotMissingWithRetrievalQuote` | OneUI auto, `applicantId=1`, NJ |
| `KnockoutTests#validateNY_Commuter_KO_For_NJ_User` | OneUI auto, `applicantId=1`, NJ |
| `VehiclesReviewTest#validateOnlyVehicleSelectedOnHeresIsWhatWeHaveFoundIsDisplayed` | ADPF vehículos y conductores, doce incompletos y exclusiones de estado |
| `CSStoFFQCrossSellScenarios#testCrossSellFromCSStoAutoAce` | HQM ApplicantHome, restricciones de estado |
| `CrossSellScenarios#testCrossSellHQMToAutoAce` | HQM ApplicantHome, `EXCLUDED_STATES={CA,MT,NV}` |
| `PageValidationScenarios#testHQMMonetizationScenarios` | HQM ApplicantHome, restricciones de estado |
| `QuoteRetrievalScenarios#testProdRetrieveOnQuotePageHQM` | HQM ApplicantHome, restricciones de estado |

`npm run audit:selection` imprime los identificadores completos y el error exacto. El resultado depende de `TEST_ENV` y `FFQ_DATA_STATES`; esta auditoría usa MA11 por defecto.

## Para convertir un caso en funcional

1. Leer método Java, helper de navegación, Page Objects y condiciones del DataProvider; mantener la misma rama y aserciones.
2. Implementar un handler Playwright que abra FFQ y ejecute pasos con `healthCheck.step`, con locators `getByRole`, `getByLabel` o `getByTestId` contrastados con el DOM real.
3. Validar la pantalla final con `healthCheck.verifyOutcome`; para un terminal esperado usar `verifyTerminal` y comprobar su contenido. Adjuntar CopyDOM en cada paso y revisar la recuperación.
4. Ejecutar en el entorno objetivo, revisar trazas y fallos, certificar sólo ese identificador tras comprobar el resultado. Repetir para los casos y combinaciones de datos del método.

Hasta entonces `npm test` falla con un mensaje claro y `EXECUTE_MIGRATED_TESTS=true npm run test:diagnostic -- --grep '<método>'` también debe fallar antes del flujo. No interpretar `npm run verify` como pruebas funcionales aprobadas.
