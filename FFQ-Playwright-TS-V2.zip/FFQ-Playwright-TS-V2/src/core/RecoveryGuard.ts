import { promises as fs } from 'node:fs';
import type { Locator, Page, TestInfo } from '@playwright/test';
import { env } from '../config/env.js';

export type RecoveryKind = 'knockout' | 'inconvenience' | 'try-again';
interface RecoveryTarget { readonly kind: RecoveryKind; readonly marker: Locator; readonly action: Locator }

/** Watches each test from fixture setup until teardown. A detected break can never produce PASS by itself. */
export class RecoveryGuard {
  private stopped = false;
  private attempts = 0;
  private failure: Error | undefined;
  private loop: Promise<void> | undefined;
  private expected: RecoveryKind | undefined;
  private observed: RecoveryKind | undefined;
  private lastCheckpoint = 'test setup';
  private pending: Promise<void> | undefined;

  public constructor(private readonly page: Page, private readonly testInfo: TestInfo) {}
  public start(): void { this.loop = this.monitor(); }
  /** The scenario must still assert the expected page contents before it can pass. */
  public expectTerminal(kind: RecoveryKind): void { this.expected = kind; }
  public async checkpoint(label: string): Promise<void> {
    this.lastCheckpoint = label;
    if (this.failure) throw this.failure;
    if (!this.page.isClosed()) await this.recoverIfPresent();
    if (this.failure) throw this.failure;
  }
  public assertExpectedTerminal(kind: RecoveryKind): void {
    if (this.observed !== kind) throw new Error(`Expected ${kind} at ${this.lastCheckpoint}, observed ${this.observed ?? 'none'}`);
  }
  public async stop(): Promise<void> {
    this.stopped = true;
    await this.loop;
    if (this.failure) throw this.failure;
  }

  private targets(): readonly RecoveryTarget[] {
    return [
      {
        kind: 'inconvenience',
        marker: this.page.locator('#inconvenience_header-title, #FFQAuto_Commonpage_inconvHeader, h1.inconvenience__title').first(),
        action: this.page.getByRole('button', { name: /try again|continue|restart/i }).first(),
      },
      {
        kind: 'knockout',
        marker: this.page.locator('#knockout_title, #knock-out_header-title, .knock-out_header-title, app-knockout-lead-form, .mobilehome-knockout__title').first(),
        action: this.page.getByRole('button', { name: /try again|start over/i }).first(),
      },
      {
        kind: 'try-again',
        marker: this.page.getByRole('heading', { name: /^try again$/i }).first(),
        action: this.page.getByRole('button', { name: /^try again$/i }).first(),
      },
    ];
  }

  private async monitor(): Promise<void> {
    while (!this.stopped) {
      try {
        if (!this.page.isClosed()) await this.recoverIfPresent();
      } catch (error) {
        this.failure = error instanceof Error ? error : new Error(String(error));
        this.stopped = true;
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, env.RECOVERY_POLL_INTERVAL_MS));
    }
  }

  private async recoverIfPresent(): Promise<void> {
    if (this.pending) return this.pending;
    const work = this.inspectPage();
    this.pending = work;
    try { await work; } finally { if (this.pending === work) this.pending = undefined; }
  }

  private async inspectPage(): Promise<void> {
    for (const target of this.targets()) {
      if (!(await target.marker.isVisible().catch(() => false))) continue;
      if (this.observed === target.kind && this.expected === target.kind) return;
      this.observed = target.kind;
      await this.capture(target.kind);
      if (target.kind === this.expected) return;
      if (this.attempts >= env.RECOVERY_MAX_ATTEMPTS) {
        throw new Error(`${target.kind} at ${this.lastCheckpoint}: recovery limit ${env.RECOVERY_MAX_ATTEMPTS} exhausted`);
      }
      if (!(await target.action.isVisible().catch(() => false))) {
        throw new Error(`${target.kind} at ${this.lastCheckpoint}: no verified recovery action; URL=${this.page.url()}`);
      }
      this.attempts += 1;
      await target.action.click();
      await target.marker.waitFor({ state: 'hidden', timeout: env.ACTION_TIMEOUT_MS }).catch(() => {
        throw new Error(`${target.kind} remains visible after recovery attempt ${this.attempts} at ${this.lastCheckpoint}`);
      });
      return;
    }
  }

  private async capture(kind: RecoveryKind): Promise<void> {
    const prefix = `break-${this.attempts + 1}-${kind}`;
    const screenshot = this.testInfo.outputPath(`${prefix}.png`);
    const html = this.testInfo.outputPath(`${prefix}.html`);
    const context = this.testInfo.outputPath(`${prefix}.json`);
    await this.page.screenshot({ path: screenshot, fullPage: true });
    await fs.writeFile(html, await this.page.content(), 'utf8');
    await fs.writeFile(context, JSON.stringify({
      kind, attempt: this.attempts + 1, expected: this.expected === kind,
      checkpoint: this.lastCheckpoint, url: this.page.url(),
      title: await this.page.title().catch(() => ''), timestamp: new Date().toISOString(),
    }, null, 2), 'utf8');
    await this.testInfo.attach(`${prefix}-screenshot`, { path: screenshot, contentType: 'image/png' });
    await this.testInfo.attach(`${prefix}-CopyDOM`, { path: html, contentType: 'text/html' });
    await this.testInfo.attach(`${prefix}-context`, { path: context, contentType: 'application/json' });
  }
}
