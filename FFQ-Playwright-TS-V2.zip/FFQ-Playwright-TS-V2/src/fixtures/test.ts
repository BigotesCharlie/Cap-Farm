import { promises as fs } from 'node:fs';
import { mergeTests, expect } from '@playwright/test';
import { test as aceHome } from './data/ace-home.fixture.js';
import { test as auto } from './data/auto.fixture.js';
import { test as bundle } from './data/bundle.fixture.js';
import { test as sqlAuto } from './data/sql-auto.fixture.js';
import { test as classic } from './data/classic.fixture.js';
import { test as inline } from './data/inline.fixture.js';
import { test as reference } from './data/reference.fixture.js';
import { test as recovery } from './health/recovery.fixture.js';
import { test as health } from './health/health-check.fixture.js';

/** One import for specs; each DataProvider is independently defined and lazy. */
export const test = mergeTests(aceHome, auto, bundle, sqlAuto, classic, inline, reference, recovery, health);

test.afterEach(async ({ page }, testInfo) => {
  if (page.isClosed()) return;
  const dom = await page.content().catch(() => '');
  if (dom) {
    const path = testInfo.outputPath('final-dom.html');
    await fs.writeFile(path, dom, 'utf8');
    await testInfo.attach('final-dom', { path, contentType: 'text/html' });
  }
});

export { expect };
