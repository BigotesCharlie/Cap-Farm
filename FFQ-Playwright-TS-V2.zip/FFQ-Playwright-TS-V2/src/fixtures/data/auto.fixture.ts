import { test as base } from '@playwright/test';
import { providerFor, type Provider } from './provider.js';

/** Java AutoDataProviders: OneUI auto and ADPF applicants. */
export const test = base.extend<{ autoData: Provider }>({
  autoData: async ({}, use, testInfo) => {
    await use(providerFor('AutoDataProviders', testInfo));
  },
});
