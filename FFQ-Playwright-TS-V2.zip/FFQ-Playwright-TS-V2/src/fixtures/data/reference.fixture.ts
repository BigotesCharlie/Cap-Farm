import { test as base } from '@playwright/test';
import { ReferenceFixtures } from '../../data/ReferenceFixtures.js';

export const test = base.extend<{ referenceData: ReferenceFixtures }>({
  referenceData: async ({}, use, testInfo) => {
    await use(new ReferenceFixtures(process.env.FFQ_DATA_SEED || testInfo.testId));
  },
});
