import { test as base } from '@playwright/test';
import { selectLegacyCases, type SelectedCase } from '../../data/LegacyProviderSelector.js';
import type { LegacyTestMetadata } from '../../migration/LegacyTestMetadata.js';

/** Tests that have no Java DataProvider still receive an isolated case. */
export const test = base.extend<{ inlineData: (metadata: LegacyTestMetadata) => Promise<SelectedCase[]> }>({
  inlineData: async ({}, use, testInfo) => {
    await use((metadata) => {
      if (metadata.dataProvider) throw new Error(`Expected inline data: ${metadata.legacyId}`);
      return selectLegacyCases(metadata, { seed: testInfo.testId, environment: process.env.TEST_ENV || 'MA11' });
    });
  },
});
