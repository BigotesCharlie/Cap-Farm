import { test as base } from '@playwright/test';
import { providerFor, type Provider } from './provider.js';

/** Java AceBundleDataProviders: correlated auto and home applicants. */
export const test = base.extend<{ bundleData: Provider }>({
  bundleData: async ({}, use, testInfo) => {
    await use(providerFor('AceBundleDataProviders', testInfo));
  },
});
