import { test as base } from '@playwright/test';
import { providerFor, type Provider } from './provider.js';

/** Java DataProviders: legacy Home, HQM, Life, Business, MobileHome. */
export const test = base.extend<{ classicData: Provider }>({
  classicData: async ({}, use, testInfo) => {
    await use(providerFor('DataProviders', testInfo));
  },
});
