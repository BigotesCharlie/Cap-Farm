import { test as base } from '@playwright/test';
import { providerFor, type Provider } from './provider.js';

/** Java SqlDataProviders mapped to versioned fixture catalogs. */
export const test = base.extend<{ sqlAutoData: Provider }>({
  sqlAutoData: async ({}, use, testInfo) => {
    await use(providerFor('SqlDataProviders', testInfo));
  },
});
