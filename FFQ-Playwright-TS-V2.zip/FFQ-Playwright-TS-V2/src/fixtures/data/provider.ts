import type { TestInfo } from '@playwright/test';
import { selectLegacyCases, type SelectedCase } from '../../data/LegacyProviderSelector.js';
import type { LegacyTestMetadata } from '../../migration/LegacyTestMetadata.js';

export type Provider = (metadata: LegacyTestMetadata) => Promise<SelectedCase[]>;

/** A separate cache and deterministic data seed for each Playwright test. */
export function providerFor(owner: string, testInfo: TestInfo): Provider {
  const cache = new Map<string, Promise<SelectedCase[]>>();
  return (metadata) => {
    const actual = metadata.dataProviderClass.replace(/\.class$/, '');
    if (actual !== owner) {
      throw new Error(`Wrong fixture for ${metadata.legacyId}: expected ${owner}, got ${actual || 'none'}`);
    }
    let selected = cache.get(metadata.legacyId);
    if (!selected) {
      selected = selectLegacyCases(metadata, {
        seed: process.env.FFQ_DATA_SEED || testInfo.testId,
        environment: process.env.TEST_ENV || 'MA11',
        ...(process.env.FFQ_DATA_STATES ? { states: process.env.FFQ_DATA_STATES } : {}),
      });
      cache.set(metadata.legacyId, selected);
    }
    return selected;
  };
}
