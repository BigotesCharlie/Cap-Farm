import { test as base } from '@playwright/test';
import { providerFor, type Provider } from './provider.js';

/** Java AceHomeDataProviders: ApplicantHome, page validation, stability. */
export const test = base.extend<{ aceHomeData: Provider }>({
  aceHomeData: async ({}, use, testInfo) => {
    await use(providerFor('AceHomeDataProviders', testInfo));
  },
});
