# FFQ Playwright fixtures

`test.ts` composes the independent fixtures with `mergeTests` and exports the only `test` that specs import. The source catalogs are JSON in `src/data/catalog`; Playwright fixtures are TypeScript definitions under this directory.

| Java source | Fixture in spec | Definition | Catalog family |
| --- | --- | --- | --- |
| `AceHomeDataProviders` | `aceHomeData` | `data/ace-home.fixture.ts` | AceHomeTestData |
| `AutoDataProviders` | `autoData` | `data/auto.fixture.ts` | OneUIAutoTestData |
| `AceBundleDataProviders` | `bundleData` | `data/bundle.fixture.ts` | OneUIAutoTestData + AceHomeTestData |
| `SqlDataProviders` | `sqlAutoData` | `data/sql-auto.fixture.ts` | AutoTestData |
| `DataProviders` | `classicData` | `data/classic.fixture.ts` | Home, HQM, Life, Business, MobileHome |
| No provider | `inlineData` | `data/inline.fixture.ts` | No external row |

`data/reference.fixture.ts` exposes `referenceData` for Nearmap, coverages, and umbrella data. `health/recovery.fixture.ts` and `health/health-check.fixture.ts` are automatic fixtures active for all imported specs.

Example from `tests/legacy/acehome/AceHomeEndToEndTest.spec.ts`:

```ts
test('testReviewQuotePagePresentmentCardHome', async ({ page, aceHomeData }, testInfo) => {
  // The Java metadata is passed to the selected provider fixture.
  await executeMigratedScenario(page, testInfo, aceHomeData, metadata);
});
```

`aceHomeData(metadata)` validates the owner, selects rows using the Java attributes, seed, and environment, resolves formulas, and returns `SelectedCase[]`. It is cached only within the Playwright test. Incorrect provider wiring fails explicitly; `npm run audit:provider-wiring` checks all 2,941 declarations.

**Current limitation:** `executeMigratedScenario` does not navigate FFQ or perform UI assertions, and a multirow provider returns an array within one declared test. True TestNG-style per-row Playwright parameterization remains pending. These fixtures prepare data, not behavior certification.
