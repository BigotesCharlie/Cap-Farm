import { test as base } from '@playwright/test';
import { RecoveryGuard } from '../../core/RecoveryGuard.js';

export const test = base.extend<{ recoveryGuard: RecoveryGuard }>({
  recoveryGuard: [async ({ page }, use, testInfo) => {
    const guard = new RecoveryGuard(page, testInfo);
    guard.start();
    await use(guard);
    await guard.stop();
  }, { auto: true }],
});
