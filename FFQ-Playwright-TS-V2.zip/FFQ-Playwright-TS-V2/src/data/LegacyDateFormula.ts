/** The source workbooks contain date formulas whose saved values expire each day. */
export type LegacyFormula = Readonly<{
  __excelFormula: string;
  cached: unknown;
  cell: string;
}>;

export function isLegacyFormula(value: unknown): value is LegacyFormula {
  return typeof value === 'object' && value !== null && '__excelFormula' in value;
}

const DAY_MS = 86_400_000;

type Value = number | string | boolean;

function tokens(source: string): string[] {
  const pattern = /\s*("(?:[^"]|"")*"|(?:[A-Za-z_][A-Za-z_0-9]*!)?\$?[A-Za-z]+\$?\d+|[A-Za-z_][A-Za-z_0-9]*|\d+(?:\.\d+)?|[()+\-,=])\s*/gy;
  const result: string[] = [];
  let position = 0;
  while (position < source.length) {
    pattern.lastIndex = position;
    const match = pattern.exec(source);
    if (!match) throw new Error(`Unsupported Excel formula token near ${source.slice(position, position + 24)}`);
    result.push(match[1]!);
    position = pattern.lastIndex;
  }
  return result;
}

function datePart(serial: number): Date {
  return new Date(serial * DAY_MS);
}

function excelText(value: Value, format: string): string {
  if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error('Expected date number in TEXT formula');
  const date = datePart(value);
  const mm = String(date.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(date.getUTCDate()).padStart(2, '0');
  const yyyy = String(date.getUTCFullYear());
  switch (format.toLowerCase()) {
    case 'mmddyyyy': return `${mm}${dd}${yyyy}`;
    case 'mmyyyy': return `${mm}${yyyy}`;
    case 'mm/yy': return `${mm}/${yyyy.slice(-2)}`;
    default: throw new Error(`Unsupported Excel date format: ${format}`);
  }
}

export function evaluateLegacyDateFormula(
  formula: string,
  today: Date,
  lookup: (reference: string) => Value,
): Value {
  const parts = tokens(formula.replace(/^=/, ''));
  let cursor = 0;
  const peek = () => parts[cursor];
  const consume = (expected?: string): string => {
    const current = parts[cursor++];
    if (!current || (expected && current !== expected)) {
      throw new Error(`Expected ${expected ?? 'formula token'} in ${formula}`);
    }
    return current;
  };
  const numeric = (value: Value): number => {
    const number = Number(value);
    if (!Number.isFinite(number)) throw new Error(`Non-numeric formula operand in ${formula}`);
    return number;
  };
  const atom = (): Value => {
    const item = consume();
    if (item === '(') {
      const value = equality();
      consume(')');
      return value;
    }
    if (item === '-') return -numeric(atom());
    if (/^\d/.test(item)) return Number(item);
    if (item.startsWith('"')) return item.slice(1, -1).replace(/""/g, '"');
    if (peek() !== '(') return lookup(item);
    consume('(');
    const args: Value[] = [];
    if (peek() !== ')') {
      args.push(equality());
      while (peek() === ',') { consume(','); args.push(equality()); }
    }
    consume(')');
    switch (item.toUpperCase()) {
      case 'TODAY':
        if (args.length) throw new Error('TODAY takes no arguments');
        return Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()) / DAY_MS;
      case 'YEAR': return datePart(numeric(args[0]!)).getUTCFullYear();
      case 'MONTH': return datePart(numeric(args[0]!)).getUTCMonth() + 1;
      case 'DAY': return datePart(numeric(args[0]!)).getUTCDate();
      case 'DATE': return Date.UTC(numeric(args[0]!), numeric(args[1]!) - 1, numeric(args[2]!)) / DAY_MS;
      case 'TEXT': return excelText(args[0]!, String(args[1]));
      default: throw new Error(`Unsupported Excel function ${item}`);
    }
  };
  const arithmetic = (): Value => {
    let value = atom();
    while (peek() === '+' || peek() === '-') {
      const operator = consume();
      value = numeric(value) + (operator === '+' ? 1 : -1) * numeric(atom());
    }
    return value;
  };
  const equality = (): Value => {
    const left = arithmetic();
    return peek() === '=' ? (consume('='), left === arithmetic()) : left;
  };
  const value = equality();
  if (cursor !== parts.length) throw new Error(`Unsupported Excel expression: ${formula}`);
  return value;
}
