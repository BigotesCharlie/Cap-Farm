import { readFile } from 'node:fs/promises';
import type { Page, TestInfo } from '@playwright/test';
import type { SelectedCase } from '../data/LegacyProviderSelector.js';
import type { LegacyMethodContract, LegacyTestMetadata } from './LegacyTestMetadata.js';

let contracts: Promise<Record<string, LegacyMethodContract>> | undefined;

async function loadContracts(): Promise<Record<string, LegacyMethodContract>> {
  contracts ??= readFile('migration/audit/legacy-method-contracts.json', 'utf8').then(
    (source) => JSON.parse(source) as Record<string, LegacyMethodContract>,
  );
  return contracts;
}

/**
 * Auditable execution boundary for generated tests.
 *
 * A behavioral handler must be registered for a test before the safety gate is
 * enabled. This deliberately fails closed: an unmigrated scenario can never be
 * reported as a false PASS merely because the FFQ landing page loaded.
 */
export async function executeMigratedScenario(
  page: Page,
  testInfo: TestInfo,
  legacyData: (metadata: LegacyTestMetadata) => Promise<SelectedCase[]>,
  metadata: LegacyTestMetadata,
): Promise<void> {
  const contract = (await loadContracts())[metadata.legacyId];
  if (!contract) throw new Error(`Missing immutable migration contract: ${metadata.legacyId}`);

  testInfo.annotations.push(
    { type: 'legacy-id', description: metadata.legacyId },
    { type: 'legacy-source', description: `${metadata.sourceFile}:${metadata.sourceLine}` },
    { type: 'data-provider', description: metadata.dataProvider || 'none' },
  );
  await testInfo.attach('legacy-contract.json', {
    body: Buffer.from(JSON.stringify(contract, null, 2)),
    contentType: 'application/json',
  });

  const selected = await legacyData(metadata);
  await testInfo.attach('selected-fixture-rows.json', {
    body: Buffer.from(JSON.stringify(selected.map(({ source, sheet, sourceId, state }) => ({
      source, sheet, sourceId, state,
    })), null, 2)),
    contentType: 'application/json',
  });

  void page;
  throw new Error(
    `Behavioral handler not certified for ${metadata.legacyId}; selected ${selected.length} fixture row(s). ` +
      'Data selection is executable, but UI behavior and assertions still require migration. No PASS is allowed.',
  );
}
