import { defineConfig, devices } from '@playwright/test';
import { env } from './src/config/env.js';

const debugVisual = env.FFQ_DEBUG_VISUAL;

const chromiumProject = {
  name: 'chromium',
  use: {
    viewport: null,
    launchOptions: {
      args: env.SAUCE_USERNAME || env.SAUCE_ACCESS_KEY ? [] : ['--start-maximized'],
    },
  },
};

const otherProjects = [
  { name: 'firefox', testIgnore: 'Auto/**/*.spec.ts', use: { ...devices['Desktop Firefox'] } },
  { name: 'webkit', testIgnore: 'Auto/**/*.spec.ts', use: { ...devices['Desktop Safari'] } },
  { name: 'edge', testIgnore: 'Auto/**/*.spec.ts', use: { ...devices['Desktop Edge'], channel: 'msedge' } },
  { name: 'mobile-chrome', testIgnore: 'Auto/**/*.spec.ts', use: { ...devices['Pixel 7'] } },
  { name: 'mobile-safari', testIgnore: 'Auto/**/*.spec.ts', use: { ...devices['iPhone 15'] } },
];

export default defineConfig({
  testDir: './tests',
  testMatch: '**/*.spec.ts',
  outputDir: 'test-results/artifacts',
  fullyParallel: true,
  forbidOnly: Boolean(process.env.CI),
  retries: debugVisual ? 0 : process.env.CI ? Math.max(env.RETRIES, 2) : env.RETRIES,
  workers: debugVisual ? 1 : process.env.CI ? Math.min(env.WORKERS, 4) : env.WORKERS,
  repeatEach: 1,
  timeout: env.TEST_TIMEOUT_MS,
  expect: { timeout: env.EXPECT_TIMEOUT_MS },
  reporter: process.env.CI
    ? [
        ['line'],
        ['./reports/custom-report/PlaywrightEnvironmentExecutionReporter.ts'],
        ['html', { open: 'never' }],
        ['junit', { outputFile: 'test-results/junit.xml' }],
      ]
    : [['list'], ['./reports/custom-report/PlaywrightEnvironmentExecutionReporter.ts'], ['html', { open: 'never' }]],
  use: {
    baseURL: env.FFQ_BASE_URL,
    headless: false,
    actionTimeout: env.ACTION_TIMEOUT_MS,
    navigationTimeout: env.NAVIGATION_TIMEOUT_MS,
    screenshot: 'only-on-failure',
    trace: 'on',
    video: 'retain-on-failure',
    testIdAttribute: 'data-testid',
    locale: 'en-US',
    timezoneId: 'America/Los_Angeles',
  },
  projects: debugVisual ? [chromiumProject] : [chromiumProject, ...otherProjects],
});
