import { expect, type Locator, type Page } from '@playwright/test';
import type { ApplicantAceHome } from '../../models/acehome/ApplicantAceHome.js';
import {
  AceHomeAboutYouPage,
  AceHomeAdditionalCoveragesPage,
  AceHomeAdditionalInfoPage,
  AceHomeContactInfoPage,
  AceHomeDwellingCoveragePage,
  AceHomeJustAFewMoreThingsPage,
  AceHomePageClassifier,
  AceHomePaymentPage,
  AceHomePaymentSelectionPage,
  AceHomePropertyInfoPage,
  AceHomeQualityGradePage,
  AceHomeReviewQuotePage,
} from '../../pages/acehome/AceHomePages.js';
import type { RecoveryGuard } from '../../core/RecoveryGuard.js';
import { safeScrollAndClick } from '../../core/BrowserUi.js';
import { logger } from '../../../utils/logger.js';

export interface FlowHooks {
  checkpoint(name: string): Promise<void>;
  annotate(type: string, description: string): void;
}

export class AceHomeNavigationFlow {
  private classifier: AceHomePageClassifier;

  public constructor(
    private readonly page: Page,
    private readonly hooks: FlowHooks,
    private readonly recoveryGuard?: RecoveryGuard,
  ) {
    this.classifier = new AceHomePageClassifier(page);
  }

  public async navigateToReviewQuotePage(applicant: ApplicantAceHome): Promise<AceHomeReviewQuotePage> {
    await this.page.goto('/', { waitUntil: 'domcontentloaded' });
    await this.capture('01-home-start');

    await this.dismissCookieBannerIfPresent();
    await this.capture('01a-after-cookie');
    await this.selectHomeProductAndStart(applicant);
    await this.failClosedIfKnockoutEncountered(applicant);

    await this.ensurePropertyInfoWithFallbackFill(applicant);
    await this.capture('04-property-information');

    await this.clickPrimaryContinue('property-info-continue');
    await this.ensureQualityGradeOrPropertyDetails();

    const qualityPage = new AceHomeQualityGradePage(this.page);
    if (await qualityPage.isQualityGradePageAlone()) {
      await this.capture('05-quality-grade');
      await qualityPage.clickContinueIfVisible();
    }

    await this.ensurePropertyDetailsPage();
    await this.capture('06-property-details');
    await this.clickPrimaryContinue('property-details-continue');

    await this.ensureAdditionalInfoPage();
    await this.capture('07-additional-information');
    await this.clickPrimaryContinue('additional-information-continue');

    const additionalInfo = new AceHomeAdditionalInfoPage(this.page);
    if (!(await additionalInfo.isNewFlowEnabledState(applicant.stateCode))) {
      const aboutYou = new AceHomeAboutYouPage(this.page);
      await aboutYou.assertOnPage();
      await this.capture('08-about-you');
      await aboutYou.clickContinue();
    }

    const contact = new AceHomeContactInfoPage(this.page);
    await contact.assertOnPage();
    await this.capture('09-contact-information');
    await this.fillContactInfo(applicant);
    await this.captureFormSubmitBoundary('09a-contact-info-submit-boundary');
    await contact.clickAgreeAndSubmit();
    await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);

    const dwelling = new AceHomeDwellingCoveragePage(this.page);
    await dwelling.assertOnPage();
    await this.capture('10-dwelling-coverage');

    // Wait for dwelling coverage page content to fully load before capturing button state
    const dwellingHeading = this.page.getByRole('heading', { name: /Review your dwelling coverage/i }).first();
    await dwellingHeading.waitFor({ state: 'visible', timeout: 5000 }).catch(() => undefined);

    await this.captureFormSubmitBoundary('10a-dwelling-coverage-buttons');
    await this.capture('10a-dwelling-coverage-before-click');
    const dwellingButton = dwelling.continueButton();
    const buttonEvidence = await dwellingButton.evaluate((element) => {
      const htmlElement = element as HTMLElement;
      const style = window.getComputedStyle(htmlElement);
      const parent = htmlElement.parentElement;
      return {
        locator: '#continueButton',
        attached: Boolean(htmlElement.isConnected),
        visible:
          style.visibility !== 'hidden' &&
          style.display !== 'none' &&
          htmlElement.getBoundingClientRect().width > 0 &&
          htmlElement.getBoundingClientRect().height > 0,
        enabled: !(htmlElement instanceof HTMLButtonElement) ? true : !htmlElement.disabled,
        bbox: htmlElement.getBoundingClientRect().toJSON(),
        computed: {
          display: style.display,
          visibility: style.visibility,
          pointerEvents: style.pointerEvents,
        },
        ariaDisabled: htmlElement.getAttribute('aria-disabled') ?? '',
        disabled:
          htmlElement instanceof HTMLButtonElement
            ? htmlElement.disabled
            : htmlElement.getAttribute('disabled') !== null,
        outerHTML: htmlElement.outerHTML,
        parentHTML: parent?.outerHTML ?? '',
      };
    });
    logger.info('DWELLING CONTINUE READY TO CLICK');
    logger.info(`DWELLING CONTINUE BUTTON COORDINATES: ${JSON.stringify(buttonEvidence.bbox)}`);
    logger.info(`DWELLING CONTINUE BUTTON LOCATOR: ${buttonEvidence.locator}`);
    logger.info(
      `DWELLING CONTINUE BUTTON ATTACHED=${buttonEvidence.attached} VISIBLE=${buttonEvidence.visible} ENABLED=${buttonEvidence.enabled}`,
    );
    await safeScrollAndClick(dwellingButton, 'DWELLING', { page: this.page });
    await this.capture('10b-dwelling-coverage-after-click');

    // CRITICAL: Wait for review quote with RECOVERY PROTECTION
    // This is a critical async transition boundary where INCONVENIENCE can appear
    if (this.recoveryGuard) {
      const finalState = await this.recoveryGuard.waitForStateWithRecovery(this.classifier, {
        expectedStates: ['REVIEW_QUOTE'],
        intermediateStates: ['REVIEW_QUOTE_LOADING'],
        recoveryStates: ['INCONVENIENCE', 'KNOCKOUT', 'TRY_AGAIN'],
        maxRecoveryAttempts: 2,
        pollIntervalMs: 350,
        timeoutMs: 30000,
      });
      logger.info('✅ Reached expected state:', { state: finalState.type });
    } else {
      // Fallback if recovery guard not available (shouldn't happen in test context)
      await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);
      await this.page
        .waitForFunction(
          () => {
            const headings = Array.from(document.querySelectorAll('h1,h2,h3,[role="heading"]')).map((el) =>
              (el.textContent ?? '').toLowerCase(),
            );
            const text = headings.join(' | ');
            return text.includes('review quote') || text.includes('coverage details');
          },
          undefined,
          { timeout: 10000 },
        )
        .catch(() => undefined);

      // Wait for presentment card to load (may take several seconds for async content)
      await this.page
        .locator('tui-quote-presentment, .quote-presentment, app-home-quote-review')
        .first()
        .waitFor({ state: 'visible', timeout: 15000 })
        .catch(() => {
          logger.warn('⚠️  Presentment card did not appear after 15s, continuing anyway');
        });

      await this.page.waitForTimeout(1500);
    }

    const review = new AceHomeReviewQuotePage(this.page);
    await review.assertOnPage();
    await this.capture('11-review-quote');
    return review;
  }

  public async navigateToAdditionalCoveragesPage(applicant: ApplicantAceHome): Promise<AceHomeAdditionalCoveragesPage> {
    const review = await this.navigateToReviewQuotePage(applicant);
    await review.clickContinue();
    const additional = new AceHomeAdditionalCoveragesPage(this.page);
    await additional.assertOnPage();
    await this.capture('12-additional-coverages');
    return additional;
  }

  public async navigateToAdditionalInfoPage(applicant: ApplicantAceHome): Promise<AceHomeAdditionalInfoPage> {
    await this.page.goto('/', { waitUntil: 'domcontentloaded' });
    await this.capture('01-home-start');

    await this.dismissCookieBannerIfPresent();
    await this.capture('01a-after-cookie');
    await this.selectHomeProductAndStart(applicant);
    await this.failClosedIfKnockoutEncountered(applicant);

    await this.ensurePropertyInfoWithFallbackFill(applicant);
    await this.capture('04-property-information');

    await this.clickPrimaryContinue('property-info-continue');
    await this.ensureQualityGradeOrPropertyDetails();

    const qualityPage = new AceHomeQualityGradePage(this.page);
    if (await qualityPage.isQualityGradePageAlone()) {
      await this.capture('05-quality-grade');
      await qualityPage.clickContinueIfVisible();
    }

    await this.ensurePropertyDetailsPage();
    await this.capture('06-property-details');
    await this.clickPrimaryContinue('property-details-continue');

    await this.ensureAdditionalInfoPage();
    const additionalInfo = new AceHomeAdditionalInfoPage(this.page);
    await additionalInfo.assertOnPage();
    await this.capture('07-additional-information');
    return additionalInfo;
  }

  public async navigateToDwellingCoveragePage(applicant: ApplicantAceHome): Promise<AceHomeDwellingCoveragePage> {
    await this.page.goto('/', { waitUntil: 'domcontentloaded' });
    await this.capture('01-home-start');

    await this.dismissCookieBannerIfPresent();
    await this.capture('01a-after-cookie');
    await this.selectHomeProductAndStart(applicant);
    await this.failClosedIfKnockoutEncountered(applicant);

    await this.ensurePropertyInfoWithFallbackFill(applicant);
    await this.capture('04-property-information');
    await this.clickPrimaryContinue('property-info-continue');
    await this.advancePastHomeDetailsIfPresent();

    const qualityPage = new AceHomeQualityGradePage(this.page);
    if (await qualityPage.isQualityGradePageAlone()) {
      await this.capture('05-quality-grade');
      await qualityPage.clickContinueIfVisible();
    }

    await this.ensurePropertyDetailsPage();
    await this.capture('06-property-details');
    await this.clickPrimaryContinue('property-details-continue');

    await this.ensureAdditionalInfoPage();
    await this.capture('07-additional-information');
    await this.clickPrimaryContinue('additional-information-continue');

    const additionalInfo = new AceHomeAdditionalInfoPage(this.page);
    if (!(await additionalInfo.isNewFlowEnabledState(applicant.stateCode))) {
      const aboutYou = new AceHomeAboutYouPage(this.page);
      await aboutYou.assertOnPage();
      await this.capture('08-about-you');
      await aboutYou.clickContinue();
    }

    const contact = new AceHomeContactInfoPage(this.page);
    await contact.assertOnPage();
    await this.capture('09-contact-information');
    await this.fillContactInfo(applicant);
    await contact.clickAgreeAndSubmit();

    const dwelling = new AceHomeDwellingCoveragePage(this.page);
    await dwelling.assertOnPage();
    await this.capture('10-dwelling-coverage');
    return dwelling;
  }

  public async continueFromReviewToPayment(applicant: ApplicantAceHome): Promise<void> {
    const review = new AceHomeReviewQuotePage(this.page);
    await review.assertOnPage();
    await review.clickContinue();

    const additional = new AceHomeAdditionalCoveragesPage(this.page);
    await additional.assertOnPage();
    await this.capture('12-additional-coverages');
    await additional.clickContinue();

    const jfmt = new AceHomeJustAFewMoreThingsPage(this.page);
    await jfmt.assertOnPage();
    await this.capture('13-just-a-few-more-things');
    await jfmt.fillOut(applicant);
    await jfmt.clickContinue();

    const paymentSelection = new AceHomePaymentSelectionPage(this.page);
    await paymentSelection.assertOnPage();
    await this.capture('14-payment-selection');
    await paymentSelection.selectPayInFullCard();

    const paymentPage = new AceHomePaymentPage(this.page);
    await paymentPage.assertOnPage();
    await this.capture('15-payment');
  }

  private async ensurePropertyInfoWithFallbackFill(applicant: ApplicantAceHome): Promise<void> {
    await this.failClosedIfKnockoutEncountered(applicant);
    await this.waitForPrePropertyEntryState();
    await this.completeLetsBeginIfPresent(applicant);
    await this.completeHomePersonalInfoIfPresent(applicant);
    await this.completeGuidewireYourInfoIfPresent(applicant);
    await this.failClosedIfKnockoutEncountered(applicant);

    // Property Info page contract recognition - may come via multiple URLs/headings
    const propertyInfoHeading = this.page.getByRole('heading', { name: /tell us more about your home/i }).first();
    const propertyHeading = this.page.getByRole('heading', { name: /property information|property info/i }).first();
    const propertyTypeHeading = this.page.getByRole('heading', { name: /what type of property is it\??/i }).first();
    const letBegin = this.page.getByRole('heading', { name: /let'?s begin/i }).first();

    const onPropertyInfo =
      (await propertyInfoHeading.isVisible({ timeout: 1500 }).catch(() => false)) ||
      (await propertyHeading.isVisible({ timeout: 1500 }).catch(() => false));
    const onPropertyTypeHeading = await propertyTypeHeading.isVisible({ timeout: 1000 }).catch(() => false);
    const onPropertyTypeUrl = /\/quote\/home\/property-type/i.test(this.page.url());
    const onPropertyType = onPropertyTypeUrl || onPropertyTypeHeading;
    const onLetBegin = await letBegin.isVisible({ timeout: 1000 }).catch(() => false);

    if (!onPropertyInfo && !onPropertyType && !onLetBegin) {
      const addressIntro = this.page
        .getByRole('heading', { name: /let'?s start with your address|let.?s begin/i })
        .first();
      const onAddressIntro = await addressIntro.isVisible({ timeout: 500 }).catch(() => false);
      if (onAddressIntro) {
        throw new Error(
          `BLOCKED: Applicant ${applicant.id} (${applicant.stateCode}) landed on Home address/personal-info entry flow ` +
            'instead of Property Information. Legacy scenario path requires downstream page contracts that are not available for this branch.',
        );
      }
      throw new Error(
        `BLOCKED: Property Information page not reached. Current URL=${this.page.url()} title=${await this.page
          .title()
          .catch(() => '')}`,
      );
    }

    if (onPropertyType) {
      this.hooks.annotate('scenario-step', 'property-type-screen-detected');
      const homeType = this.page.getByRole('radio', { name: /^home\b/i }).first();
      if (await homeType.isVisible({ timeout: 1200 }).catch(() => false)) {
        const checked = await homeType.isChecked().catch(() => false);
        if (!checked) {
          this.hooks.annotate('attempted-action', 'select-property-type-home');
          this.hooks.annotate('attempted-locator', 'role=radio[name=/^home\\b/i]');
          await homeType.click();
        }
      }

      const primaryYes = this.page.getByRole('radio', { name: /^yes$/i }).first();
      if (await primaryYes.isVisible({ timeout: 1000 }).catch(() => false)) {
        const yesChecked = await primaryYes.isChecked().catch(() => false);
        if (!yesChecked) {
          this.hooks.annotate('attempted-action', 'select-primary-residence-yes');
          this.hooks.annotate('attempted-locator', 'role=radio[name=/^yes$/i]');
          await primaryYes.click();
        }
      }

      const selectionAlert = this.page.getByText(/please select an option/i).first();
      if (await selectionAlert.isVisible({ timeout: 500 }).catch(() => false)) {
        await selectionAlert.waitFor({ state: 'hidden', timeout: 2500 }).catch(() => undefined);
      }
      return;
    }

    // Handle "Let's begin" flow as alternative to property-info
    if (onLetBegin) {
      this.hooks.annotate('scenario-step', 'lets-begin-personal-info-flow');
      // "Let's begin" is a personal information entry form
      // Skip it here as it's already handled by completeLetsBeginIfPresent
      // Continue to next page
      return;
    }

    const property = new AceHomePropertyInfoPage(this.page);
    await property.assertOnPage();

    await this.fillVisibleInput(/year built/i, applicant.yearBuilt);
    await this.fillVisibleInput(/square feet|square footage/i, applicant.squareFeet);
    await this.fillVisibleInput(/zip/i, applicant.zipCode);
    await this.fillVisibleInput(/city/i, applicant.city);

    await this.selectVisibleOption(/stories/i, applicant.numberOfStories);
    await this.selectVisibleOption(/bathroom/i, applicant.bathrooms);
    await this.selectVisibleOption(/foundation/i, applicant.foundationType);
    await this.selectVisibleOption(/roof/i, applicant.roofCover);
    await this.selectVisibleOption(/heating/i, applicant.heatingSystem);

    await this.toggleIfVisible(/pool/i, applicant.swimmingPool);
    await this.toggleIfVisible(/trampoline/i, applicant.trampoline);
    await this.toggleIfVisible(/solar/i, applicant.solarPanels);
    await this.toggleIfVisible(/smoke alarm/i, applicant.smokeAlarm);
    await this.toggleIfVisible(/water leak/i, applicant.waterLeakProtection);
  }

  private async completeHomePersonalInfoIfPresent(applicant: ApplicantAceHome): Promise<void> {
    const addressHeading = this.page
      .getByRole('heading', { name: /please enter your .* address|let'?s start with your address/i })
      .first();
    const contactHeading = this.page.getByRole('heading', { name: /contact information/i }).first();
    const phoneField = this.page.locator('input[type="tel"]:visible').first();
    const agree = this.page.getByRole('button', { name: /agree and submit/i }).first();
    const onHomePersonalInfoUrl = /\/quote\/home\/personal-info/i.test(this.page.url());
    const onHomePersonalInfoHeading = await addressHeading.isVisible({ timeout: 800 }).catch(() => false);
    const onContactSection = await contactHeading.isVisible({ timeout: 800 }).catch(() => false);
    const hasPhoneField = await phoneField.isVisible({ timeout: 800 }).catch(() => false);
    const canSubmit = await agree.isVisible({ timeout: 800 }).catch(() => false);
    if (
      (!onHomePersonalInfoUrl && !onHomePersonalInfoHeading && !canSubmit) ||
      (!canSubmit && !onContactSection && !hasPhoneField)
    )
      return;

    await this.capture('03-lets-begin');
    this.hooks.annotate('scenario-step', 'home-personal-info');

    const address = this.page.getByRole('combobox', { name: /home address/i }).first();
    if (await address.isVisible({ timeout: 1200 }).catch(() => false)) {
      const current = (await address.inputValue().catch(() => '')).trim();
      if (!current) {
        this.hooks.annotate('attempted-action', 'fill-home-address');
        this.hooks.annotate('attempted-locator', 'role=combobox[name=/home address/i]');
        await address.fill(applicant.address);
        await address.press('ArrowDown').catch(() => undefined);
        const suggestion = this.page.getByRole('option').first();
        if (await suggestion.isVisible({ timeout: 1000 }).catch(() => false)) {
          await suggestion.click();
        } else {
          await address.press('Enter').catch(() => undefined);
        }
      }
    }

    await this.fillVisibleInput(/city/i, applicant.city);
    const zipField = this.page.locator('input[name="zipCode"]:visible, input[aria-label*="zip" i]:visible').first();
    if (await zipField.isVisible().catch(() => false)) {
      const zip = applicant.zipCode.replace(/\D/g, '').slice(0, 5);
      await zipField.fill(zip);
    }
    await this.fillContactInfo(applicant);

    this.hooks.annotate('attempted-action', 'click-personal-info-agree-submit');
    this.hooks.annotate('attempted-locator', 'role=button[name=/agree and submit/i]');
    const phone = this.page.locator('input[type="tel"]:visible').first();
    const submitOnce = async (): Promise<boolean> => {
      const visible = await agree.isVisible({ timeout: 1200 }).catch(() => false);
      if (!visible) {
        return !/\/home\/personal-info/i.test(this.page.url());
      }
      await this.waitForBlockingSpinnerToClear();
      try {
        await this.clickWithInterceptionRecovery(agree);
      } catch {
        if (!/\/home\/personal-info/i.test(this.page.url())) {
          return true;
        }
        throw new Error('Failed to click Agree and submit while still on personal-info page.');
      }
      this.hooks.annotate('logical-checkpoint', 'home-personal-info-agree-submit');
      await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);
      const moved = await this.page
        .waitForFunction(() => !window.location.pathname.toLowerCase().includes('/home/personal-info'), undefined, {
          timeout: 4000,
        })
        .then(() => true)
        .catch(() => false);
      return moved;
    };

    if (await phone.isVisible().catch(() => false)) {
      for (const candidate of this.phoneCandidates(applicant)) {
        await phone.fill(candidate);
        await phone.press('Tab').catch(() => undefined);
        if (await submitOnce()) {
          await this.capture('03b-after-lets-begin');
          return;
        }

        const invalidPhone = this.page.getByText(/is not a valid entry|invalid phone|invalid entry/i).first();
        if (await invalidPhone.isVisible({ timeout: 600 }).catch(() => false)) {
          continue;
        }
      }

      throw new Error(
        `BLOCKED: Personal-info submit did not transition after phone retries for applicant ${applicant.id} (${applicant.stateCode}).`,
      );
    }

    await submitOnce();
    await this.capture('03b-after-lets-begin');
  }

  private async completeGuidewireYourInfoIfPresent(applicant: ApplicantAceHome): Promise<void> {
    const onGuidewireYourInfo = /quote-and-buy\/quote-ho\/your-info/i.test(this.page.url());
    const yourInfoHeading = this.page.getByRole('heading', { name: /tell us about yourself/i }).first();
    const headingVisible = await yourInfoHeading.isVisible({ timeout: 1200 }).catch(() => false);
    if (!onGuidewireYourInfo && !headingVisible) return;

    this.hooks.annotate('scenario-step', 'guidewire-your-info');
    await this.capture('03-guidewire-your-info');

    const email = this.page.getByRole('textbox', { name: /email address/i }).first();
    if (await email.isVisible({ timeout: 1200 }).catch(() => false)) {
      const current = (await email.inputValue().catch(() => '')).trim();
      if (!current) await email.fill(applicant.emailAddress);
    }

    const phone = this.page.getByRole('textbox', { name: /phone number/i }).first();
    if (await phone.isVisible({ timeout: 1200 }).catch(() => false)) {
      const candidates = this.phoneCandidates(applicant)
        .map((value) => value.replace(/\D/g, '').slice(0, 10))
        .filter((digits) => digits.length === 10)
        .map((digits) => `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`);
      const first = candidates[0] ?? '(515) 234-6370';
      const current = (await phone.inputValue().catch(() => '')).trim();
      if (!current) await phone.fill(first);
    }

    const street = this.page.getByRole('textbox', { name: /street address/i }).first();
    if (await street.isVisible({ timeout: 1200 }).catch(() => false)) {
      const current = (await street.inputValue().catch(() => '')).trim();
      if (!current) await street.fill(applicant.address);
    }

    const agree = this.page.getByRole('button', { name: /agree and submit/i }).first();
    if (await agree.isVisible({ timeout: 1200 }).catch(() => false)) {
      await this.waitForBlockingSpinnerToClear();
      await this.clickWithInterceptionRecovery(agree);
      await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);
      await this.page
        .waitForFunction(() => !window.location.pathname.toLowerCase().includes('/quote-ho/your-info'), undefined, {
          timeout: 15000,
        })
        .catch(() => undefined);
      await this.capture('03b-after-guidewire-your-info');
    }
  }

  private async ensureQualityGradeOrPropertyDetails(): Promise<void> {
    const quality = this.page.getByRole('heading', { name: /quality grade/i }).first();
    const propertyDetails = this.page
      .getByRole('heading', { name: /here's what we have so far|property details/i })
      .first();
    const additionalInfo = this.page.getByRole('heading', { name: /additional information/i }).first();

    for (let attempt = 0; attempt < 5; attempt += 1) {
      // Check if we reached Quality Grade, Property Details, or even Additional Information
      if (
        await quality
          .or(propertyDetails)
          .or(additionalInfo)
          .isVisible({ timeout: 800 })
          .catch(() => false)
      )
        return;

      const advanced = await this.advancePastHomeDetailsIfPresent();
      if (!advanced) {
        // Try clicking primary continue if no home-details step
        const cont = this.page.getByRole('button', { name: /continue|next/i }).first();
        if (await cont.isVisible({ timeout: 500 }).catch(() => false)) {
          await cont.click().catch(() => undefined);
        }
        await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);
      }
    }

    // Fallback: if still not found, check if we're on a different page we can proceed from
    const isQuality = await quality.isVisible({ timeout: 500 }).catch(() => false);
    const isPropertyDetails = await propertyDetails.isVisible({ timeout: 500 }).catch(() => false);
    const isAdditional = await additionalInfo.isVisible({ timeout: 500 }).catch(() => false);

    if (!isQuality && !isPropertyDetails && !isAdditional) {
      // Log but don't fail - allow next step to handle or fail appropriately
      this.hooks.annotate('scenario-step', 'quality-grade-not-found-proceeding-anyway');
    }
  }

  private async advancePastHomeDetailsIfPresent(): Promise<boolean> {
    const homeDetailsHeading = this.page.getByRole('heading', { name: /tell us more about your home/i }).first();
    const homeKindGroup = this.page.getByRole('radiogroup', { name: /what kind of home is it\??/i }).first();
    const isHomeDetailsStep =
      (await homeDetailsHeading.isVisible({ timeout: 1200 }).catch(() => false)) ||
      (await homeKindGroup.isVisible({ timeout: 1200 }).catch(() => false));
    if (!isHomeDetailsStep) return false;

    this.hooks.annotate('scenario-step', 'home-details-intermediate-step');
    const homeSingleFamily = this.page.getByRole('radio', { name: /single-family home/i }).first();
    if (await homeSingleFamily.isVisible({ timeout: 800 }).catch(() => false)) {
      const checked = await homeSingleFamily.isChecked().catch(() => false);
      if (!checked) await homeSingleFamily.click();
    }

    const ownedOneYear = this.page.getByRole('radio', { name: /a year or more/i }).first();
    if (await ownedOneYear.isVisible({ timeout: 800 }).catch(() => false)) {
      const checked = await ownedOneYear.isChecked().catch(() => false);
      if (!checked) await ownedOneYear.click();
    }

    const claimsNone = this.page.getByRole('radio', { name: /^none$/i }).first();
    if (await claimsNone.isVisible({ timeout: 800 }).catch(() => false)) {
      const checked = await claimsNone.isChecked().catch(() => false);
      if (!checked) await claimsNone.click();
    }

    await this.clickPrimaryContinue('home-details-continue');
    await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);

    const stillHomeDetails =
      (await homeDetailsHeading.isVisible({ timeout: 1200 }).catch(() => false)) ||
      (await homeKindGroup.isVisible({ timeout: 1200 }).catch(() => false));
    if (stillHomeDetails) {
      const continueBtn = this.page.getByRole('button', { name: /continue/i }).first();
      if (await continueBtn.isVisible({ timeout: 1200 }).catch(() => false)) {
        await continueBtn.click({ force: true }).catch(() => undefined);
        await continueBtn.press('Enter').catch(() => undefined);
        await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);
      }
    }

    return true;
  }

  private async ensurePropertyDetailsPage(): Promise<void> {
    const propDetails = this.page
      .getByRole('heading', { name: /here's what we have so far|property details/i })
      .first();
    const additionalInfo = this.page.getByRole('heading', { name: /additional information/i }).first();

    // Try to wait for Property Details or Additional Information
    for (let attempt = 0; attempt < 3; attempt += 1) {
      if (
        await propDetails
          .or(additionalInfo)
          .isVisible({ timeout: 1000 })
          .catch(() => false)
      )
        return;
      const cont = this.page.getByRole('button', { name: /continue|next/i }).first();
      if (await cont.isVisible({ timeout: 500 }).catch(() => false)) {
        await cont.click().catch(() => undefined);
      }
      await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);
    }

    // If still not found, continue anyway (may be already advanced)
    this.hooks.annotate('scenario-step', 'property-details-not-found-continuing');
  }

  private async ensureAdditionalInfoPage(): Promise<void> {
    const additionalHeading = this.page.getByRole('heading', { name: /additional information/i }).first();
    const reviewHeading = this.page.getByRole('heading', { name: /review quote/i }).first();

    // May already be on review page, that's OK
    const onAdditional = await additionalHeading.isVisible({ timeout: 1000 }).catch(() => false);
    const onReview = await reviewHeading.isVisible({ timeout: 500 }).catch(() => false);

    if (!onAdditional && !onReview) {
      this.hooks.annotate('scenario-step', 'additional-info-not-found-continuing');
    }
  }

  private async fillContactInfo(applicant: ApplicantAceHome): Promise<void> {
    // Fill Policy start date if present
    const policyStartDate = this.page
      .locator('input[aria-label*="Policy start" i], input[name*="policyStart" i]')
      .first();
    if (await policyStartDate.isVisible({ timeout: 500 }).catch(() => false)) {
      const current = await policyStartDate.inputValue().catch(() => '');
      if (!current) {
        const today = new Date();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        const yyyy = String(today.getFullYear());
        await policyStartDate.fill(`${mm}/${dd}/${yyyy}`);
      }
    }

    // Fill Gender if present and required (has alert)
    const genderRadioGroup = this.page.locator('mat-radio-group').first();
    if (await genderRadioGroup.isVisible({ timeout: 500 }).catch(() => false)) {
      const hasValidationError = await this.page
        .getByText(/this is required/i, { exact: false })
        .isVisible({ timeout: 100 })
        .catch(() => false);

      if (hasValidationError) {
        const maleRadio = this.page.getByRole('radio', { name: /^Male$/i }).first();
        const isSelected = await maleRadio.isChecked().catch(() => false);

        if (!isSelected && (await maleRadio.isVisible({ timeout: 200 }).catch(() => false))) {
          await maleRadio.click();
          // Wait for selection to register
          await this.page.waitForTimeout(300);
        }
      }
    }

    // Fill email
    const email = this.page.locator('input[type="email"]:visible').first();
    if (await email.isVisible({ timeout: 500 }).catch(() => false)) {
      const current = await email.inputValue();
      if (!current) await email.fill(applicant.emailAddress);
    }

    // Fill phone
    const phone = this.page.locator('input[type="tel"]:visible').first();
    if (await phone.isVisible({ timeout: 500 }).catch(() => false)) {
      const current = (await phone.inputValue().catch(() => '')).trim();
      if (!current) {
        const candidate = this.phoneCandidates(applicant)[0] ?? this.normalizedPhone(applicant.phoneNumber);
        await phone.fill(candidate);
        await phone.press('Tab').catch(() => undefined);
      }
    }

    // Auto-select first bundle option if not already selected (Auto)
    const autoCheckbox = this.page
      .locator('[type="checkbox"][aria-label*="Auto"], input[type="checkbox"] ~ label:has-text("Auto")')
      .first();
    const isAutoChecked = await autoCheckbox.isChecked({ timeout: 100 }).catch(() => false);
    if (!isAutoChecked) {
      await autoCheckbox.click().catch(() => undefined);
    }
  }

  private normalizedPhone(raw: string): string {
    const digits = raw.replace(/\D/g, '').slice(0, 10);
    if (digits.length !== 10) return raw;
    return `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
  }

  private phoneCandidates(applicant: ApplicantAceHome): string[] {
    const baseDigits = applicant.phoneNumber.replace(/\D/g, '').slice(0, 10);
    const candidates = new Set<string>();

    if (baseDigits.length === 10) {
      candidates.add(`${baseDigits.slice(0, 3)}-${baseDigits.slice(3, 6)}-${baseDigits.slice(6)}`);
      candidates.add(`(${baseDigits.slice(0, 3)}) ${baseDigits.slice(3, 6)}-${baseDigits.slice(6)}`);
      candidates.add(baseDigits);
    }

    const stateDefaults: Record<string, string[]> = {
      IA: ['5152346370', '5632346370', '6412346370', '7122346370'],
    };
    for (const raw of stateDefaults[applicant.stateCode] ?? []) {
      const digits = raw.replace(/\D/g, '').slice(0, 10);
      if (digits.length === 10) candidates.add(`${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`);
    }

    candidates.add('9492346370');
    candidates.add('7142346370');

    return Array.from(candidates);
  }

  private async completeLetsBeginIfPresent(applicant: ApplicantAceHome): Promise<void> {
    await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);
    const letsBegin = this.page.getByRole('heading', { name: /let'?s begin/i }).first();
    const firstName = this.page.getByLabel(/first name/i).first();
    const maybeLetsBegin =
      (await letsBegin.isVisible({ timeout: 1000 }).catch(() => false)) ||
      (await firstName.isVisible({ timeout: 1000 }).catch(() => false));
    if (!maybeLetsBegin) return;

    await this.capture('03-lets-begin');
    await this.fillVisibleInput(/first name/i, applicant.firstName);
    await this.fillVisibleInput(/last name/i, applicant.lastName);
    await this.fillVisibleInput(/date of birth|mmddyyyy|mm\/dd\/yyyy/i, applicant.dateOfBirth);

    const agree = this.page.getByRole('button', { name: /^agree$/i }).first();
    if (await agree.isVisible().catch(() => false)) {
      this.hooks.annotate('attempted-action', 'click-lets-begin-agree');
      this.hooks.annotate('attempted-locator', 'role=button[name=/^agree$/i]');
      await agree.click();
      this.hooks.annotate('logical-checkpoint', 'lets-begin-agree');
      await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);
      await this.capture('03b-after-lets-begin');
      await this.page
        .waitForFunction(
          () => {
            const text = Array.from(document.querySelectorAll('h1,h2,h3,[role="heading"]'))
              .map((el) => (el.textContent ?? '').toLowerCase())
              .join(' | ');
            return (
              !text.includes("let's begin") ||
              text.includes('property information') ||
              text.includes('contact information')
            );
          },
          undefined,
          { timeout: 12000 },
        )
        .catch(() => undefined);
    }
  }

  private async waitForPrePropertyEntryState(): Promise<void> {
    await this.page
      .waitForFunction(
        () => {
          const text = Array.from(document.querySelectorAll('h1,h2,h3,[role="heading"]'))
            .map((el) => (el.textContent ?? '').toLowerCase())
            .join(' | ');
          if (text.includes('property information') || text.includes('property info')) return true;
          if (text.includes("let's begin")) return true;
          if (text.includes('please enter your') && text.includes('address')) return true;
          if (text.includes('tell us about yourself')) return true;
          if (text.includes("it's not you. it's us") || text.includes("we just can't offer")) return true;
          const path = window.location.pathname.toLowerCase();
          return path.includes('/quote/home/personal-info');
        },
        undefined,
        { timeout: 15000 },
      )
      .catch(() => undefined);
  }

  private async selectHomeProductAndStart(applicant: ApplicantAceHome): Promise<void> {
    this.hooks.annotate('scenario-step', 'start-home-product-selection');
    const homeOption = this.page.getByRole('option', { name: /home icon/i }).first();
    await expect(homeOption).toBeVisible();

    const selectedBefore = (await homeOption.getAttribute('aria-selected')) === 'true';
    if (!selectedBefore) {
      this.hooks.annotate('attempted-action', 'select-home-product');
      this.hooks.annotate('attempted-locator', 'role=option[name=/home icon/i]');
      await homeOption.click();
    }
    const selectedAfter = (await homeOption.getAttribute('aria-selected')) === 'true';
    if (!selectedAfter) {
      throw new Error('Start step failed: Home product option is not selected.');
    }
    await this.capture('02-after-home-product-selection');

    const zip = this.page.getByRole('textbox', { name: /zip code/i }).first();
    await expect(zip).toBeVisible();
    const zip5 = applicant.zipCode.replace(/\D/g, '').slice(0, 5);
    if (!zip5 || zip5.length < 5) {
      throw new Error(`Start step failed: Applicant zip code is not a valid 5-digit value (${applicant.zipCode}).`);
    }
    this.hooks.annotate('attempted-action', 'fill-zip-code');
    this.hooks.annotate('attempted-locator', 'role=textbox[name=/zip code/i]');
    await zip.fill(zip5);
    await zip.press('Tab');

    const currentZip = (await zip.inputValue().catch(() => '')).replace(/\D/g, '').slice(0, 5);
    if (currentZip !== zip5) {
      throw new Error(`Start step failed: ZIP input value mismatch. expected=${zip5} actual=${currentZip || 'empty'}`);
    }

    const startButton = this.page
      .getByRole('button', { name: /start\s*my\s*quote|start\s*quote|get\s*my\s*quote/i })
      .first();
    await expect(startButton).toBeVisible();
    this.hooks.annotate('attempted-action', 'click-start-quote');
    this.hooks.annotate(
      'attempted-locator',
      'role=button[name=/start\\s*my\\s*quote|start\\s*quote|get\\s*my\\s*quote/i]',
    );
    await startButton.click();
    this.hooks.annotate('logical-checkpoint', 'start-quote-submit');
    await this.capture('02b-after-start-click');
    await this.waitForPostStartTransition();
  }

  private async waitForPostStartTransition(): Promise<void> {
    await this.page
      .waitForFunction(
        () => {
          const href = window.location.href;
          const normalized = href.toLowerCase();
          if (!/\/fastquote\/?$/.test(normalized)) return true;

          const headingText = Array.from(document.querySelectorAll('h1,h2,h3,[role="heading"]'))
            .map((el) => (el.textContent ?? '').trim().toLowerCase())
            .join(' | ');
          return (
            headingText.includes("let's begin") ||
            headingText.includes("let's start with your address") ||
            headingText.includes('property information') ||
            headingText.includes('property info') ||
            headingText.includes('continue your quote request')
          );
        },
        undefined,
        { timeout: 10000 },
      )
      .catch(() => undefined);

    const currentUrl = this.page.url();
    const atStart = /\/fastquote\/?$/i.test(currentUrl);
    if (!atStart) return;

    const headingSamples = await this.page
      .locator('h1:visible, h2:visible, h3:visible, [role="heading"]:visible')
      .allInnerTexts()
      .catch(() => []);
    const buttonSamples = await this.page
      .locator('button:visible, [role="button"]:visible')
      .allInnerTexts()
      .catch(() => []);
    throw new Error(
      `BLOCKED: Start CTA did not transition from FastQuote landing. url=${currentUrl} ` +
        `headings=${headingSamples.slice(0, 6).join(' | ') || 'none'} ` +
        `buttons=${buttonSamples.slice(0, 8).join(' | ') || 'none'}`,
    );
  }

  private async fillVisibleInput(label: RegExp, value: string): Promise<void> {
    if (!value) return;
    const input = this.page.getByLabel(label).first();
    if (await input.isVisible().catch(() => false)) {
      await input.fill(value);
    }
  }

  private async selectVisibleOption(label: RegExp, value: string): Promise<void> {
    if (!value) return;
    const combo = this.page.getByRole('combobox', { name: label }).first();
    if (await combo.isVisible().catch(() => false)) {
      await combo.selectOption({ label: value }).catch(async () => {
        await combo.selectOption({ value });
      });
    }
  }

  private async toggleIfVisible(question: RegExp, enabled: boolean): Promise<void> {
    const yesNo = this.page
      .getByRole('button', { name: new RegExp(`${enabled ? 'yes' : 'no'}.*${question.source}`, 'i') })
      .first();
    if (await yesNo.isVisible().catch(() => false)) {
      await yesNo.click();
      return;
    }

    const field = this.page.getByLabel(question).first();
    if (await field.isVisible().catch(() => false)) {
      await field.check({ force: false }).catch(() => undefined);
    }
  }

  private async clickPrimaryContinue(checkpoint: string): Promise<void> {
    const button = this.page
      .getByRole('button', { name: /continue|next|get my quote|agree and submit|^agree$/i })
      .first();
    await expect(button).toBeVisible();
    await this.waitForBlockingSpinnerToClear();
    await this.clickWithInterceptionRecovery(button);
    this.hooks.annotate('logical-checkpoint', checkpoint);
  }

  private async clickByRoleName(name: RegExp, checkpoint: string): Promise<void> {
    const button = this.page.getByRole('button', { name }).first();
    await expect(button).toBeVisible();
    await this.waitForBlockingSpinnerToClear();
    await this.clickWithInterceptionRecovery(button);
    this.hooks.annotate('logical-checkpoint', checkpoint);
  }

  private async waitForBlockingSpinnerToClear(timeoutMs = 6000): Promise<void> {
    const spinner = this.page.locator('.tui-spinner-app-background:visible, .spinner-section:visible').first();
    if (await spinner.isVisible({ timeout: 250 }).catch(() => false)) {
      await spinner.waitFor({ state: 'hidden', timeout: timeoutMs }).catch(() => undefined);
    }
  }

  private async clickWithInterceptionRecovery(target: Locator): Promise<void> {
    let lastError: unknown;
    for (let attempt = 0; attempt < 5; attempt += 1) {
      try {
        await target.click({ timeout: 7000 });
        return;
      } catch (error) {
        lastError = error;
        await this.waitForBlockingSpinnerToClear(3000);
        await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);
      }
    }
    throw lastError;
  }

  private async dismissCookieBannerIfPresent(): Promise<void> {
    const reject = this.page.getByRole('button', { name: /^reject$/i }).first();
    if (await reject.isVisible().catch(() => false)) {
      await reject.click();
      return;
    }
    const close = this.page.getByRole('button', { name: /^close$/i }).first();
    if (await close.isVisible().catch(() => false)) {
      await close.click();
    }
  }

  private async capture(name: string): Promise<void> {
    this.hooks.annotate('logical-checkpoint', name);
    await this.hooks.checkpoint(name);
  }

  private async failClosedIfKnockoutEncountered(applicant: ApplicantAceHome): Promise<void> {
    await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);
    const knockoutDialog = this.page
      .getByRole('heading', {
        name: /continue your quote request|unable to offer|unable to continue|not eligible|it's not you\.? it's us\.?|you'?re still on your way to new coverage|we just can'?t offer you a farmers/i,
      })
      .first();
    const knockoutBody = this.page
      .getByText(
        /unable to offer you an online quote|other companies|cannot continue|we can'?t offer you a farmers|still help you find coverage/i,
      )
      .first();
    const onInterstitial = /\/fastquote\/interstitial/i.test(this.page.url());

    const hasDialog = await knockoutDialog.isVisible({ timeout: 500 }).catch(() => false);
    const hasBody = await knockoutBody.isVisible({ timeout: 500 }).catch(() => false);
    if (!onInterstitial && !hasDialog && !hasBody) return;

    this.hooks.annotate('expected-knockout', 'true');
    this.hooks.annotate('knockout-url', this.page.url());
    await this.capture('03-knockout-detected');
    throw new Error(
      `BLOCKED: ${applicant.stateCode} applicant routed to FGIA/knockout after start submission. ` +
        'Legacy scenario expects quote flow pages (Property Information onward), but the environment/data branch prevents execution. ' +
        'Use a valid candidate for this environment or update source test data contracts.',
    );
  }

  private async captureFormSubmitBoundary(checkpoint: string): Promise<void> {
    // Capture comprehensive form DOM analysis
    this.hooks.annotate('logical-checkpoint', checkpoint);

    // Extract all button candidates and their properties
    const formAnalysis = await this.page.evaluate(() => {
      const allButtons: Array<{
        text: string;
        type: string;
        id: string;
        name: string;
        testid: string;
        ariaLabel: string;
        disabled: boolean;
        ariaDisabled: string;
        visible: boolean;
        role: string;
        form: string;
        inside: string;
        bounding: { top: number; left: number; width: number; height: number };
        classes: string;
      }> = [];

      // Find all candidate buttons
      const candidates = [
        ...document.querySelectorAll('button'),
        ...document.querySelectorAll('button[type="submit"]'),
        ...document.querySelectorAll('input[type="submit"]'),
        ...document.querySelectorAll('[role="button"]'),
      ];

      const seen = new Set<Element>();
      for (const btn of candidates) {
        if (seen.has(btn)) continue;
        seen.add(btn);

        const rect = btn.getBoundingClientRect();
        const computedStyle = window.getComputedStyle(btn);
        const isVisible =
          rect.width > 0 &&
          rect.height > 0 &&
          computedStyle.visibility !== 'hidden' &&
          computedStyle.display !== 'none';

        let container = 'root';
        let parent = btn.parentElement;
        while (parent && container === 'root') {
          if (parent.tagName.toLowerCase() === 'form') {
            const formId = parent.id || (parent as HTMLFormElement).name || 'unnamed';
            container = `form(${formId})`;
          } else if (parent.id) container = `#${parent.id}`;
          parent = parent.parentElement;
        }

        allButtons.push({
          text: (btn as HTMLElement).textContent?.trim() || '',
          type: (btn as HTMLButtonElement).type || 'button',
          id: btn.id || '',
          name: (btn as HTMLButtonElement).name || '',
          testid: btn.getAttribute('data-testid') || '',
          ariaLabel: btn.getAttribute('aria-label') || '',
          disabled: (btn as HTMLButtonElement).disabled || false,
          ariaDisabled: btn.getAttribute('aria-disabled') || '',
          visible: isVisible,
          role: btn.getAttribute('role') || 'button',
          form: (btn as HTMLButtonElement).form?.id || '',
          inside: container,
          bounding: { top: rect.top, left: rect.left, width: rect.width, height: rect.height },
          classes: btn.className,
        });
      }

      // Check form validity
      const forms = document.querySelectorAll('form');
      const formStates = Array.from(forms).map((f) => ({
        id: f.id || f.name || 'unnamed',
        valid: f.checkValidity(),
        invalidFields: Array.from(f.querySelectorAll(':invalid')).map((el) => ({
          name: (el as HTMLInputElement).name,
          id: el.id,
          type: el.tagName,
          message: (el as HTMLInputElement).validationMessage,
        })),
      }));

      return { allButtons, formStates };
    });

    // Save analysis as JSON
    await this.hooks.checkpoint(checkpoint);

    // Log summary
    logger.info(`\n=== Form Submit Boundary Analysis (${checkpoint}) ===`);
    logger.info(`Total button candidates: ${formAnalysis.allButtons.length}`);
    logger.info(`Forms found: ${formAnalysis.formStates.length}`);
    formAnalysis.allButtons.forEach((btn, idx) => {
      logger.info(
        `  [${idx}] "${btn.text}" | type=${btn.type} | id=${btn.id} | ` +
          `visible=${btn.visible} | disabled=${btn.disabled} | aria-disabled=${btn.ariaDisabled} | inside=${btn.inside}`,
      );
    });
    formAnalysis.formStates.forEach((form) => {
      logger.info(`  Form "${form.id}": valid=${form.valid}, invalid-fields=${form.invalidFields.length}`);
      form.invalidFields.forEach((field) => {
        logger.info(`    - ${field.name || field.id}: ${field.message}`);
      });
    });
  }
}
