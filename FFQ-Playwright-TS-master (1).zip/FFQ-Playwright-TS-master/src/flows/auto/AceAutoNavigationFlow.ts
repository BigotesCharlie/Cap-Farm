import { type Page, type TestInfo } from '@playwright/test';
import { captureDomCheckpoint } from '../../core/DomCheckpoint.js';
import { OneMomentPage } from '../../pages/auto/OneMomentPage.js';
import { StartQuotePage } from '../../pages/auto/StartQuotePage.js';
import { LetsBeginPage } from '../../pages/auto/LetsBeginPage.js';
import { AddressPage } from '../../pages/auto/AddressPage.js';
import { HeresWhatWeFoundPage as ModernHeresWhatWeFoundPage } from '../../pages/auto/HeresWhatWeFoundPage.js';
import { QuoteSummaryPage } from '../../pages/auto/QuoteSummaryPage.js';
import { AdditionalInfoPage } from '../../pages/auto/AdditionalInfoPage.js';
import { PaymentSelectionPage } from '../../pages/auto/PaymentSelectionPage.js';
import { WhoShouldWeInsurePage } from '../../pages/legacy/auto/pages/WhoShouldWeInsurePage.js';
import { HeresWhatWeFoundPage } from '../../pages/legacy/auto/pages/HeresWhatWeFoundPage.js';
import { VehicleReviewPage } from '../../pages/legacy/auto/pages/VehicleReviewPage.js';
import { DriverReviewPage } from '../../pages/legacy/auto/pages/DriverReviewPage.js';
import type { AutoApplicant } from '../../models/auto/AutoApplicant.js';
import type { AutoPageDataService } from '../../data/auto/AutoPageDataService.js';
import { GetRewardedForDrivingSafelyPage } from '../../pages/auto/GetRewardedForDrivingSafelypage.js';
import { ContactInfoPage } from '../../pages/auto/ContactInfoPage.js';
import { BundlePage } from '../../pages/auto/BundlePage.js';
import { BundleOfferingPage } from '../../pages/auto/BundleOfferingPage.js';
import { HeresYourQuotePage } from '../../pages/auto/HeresYourQuote.js';
import { ThankYouPage } from '../../pages/auto/ThankYouPage.js';
import { AnnualMileagePage } from '../../pages/auto/AnnualMileagePage.js';

export interface PaymentSelectionResult {
  readonly quoteNumber: string;
}

export class AceAutoNavigationFlow {
  public constructor(
    private readonly page: Page,
    private readonly testInfo: TestInfo,
  ) {}

  public updateApplicantDataToAvoidPossibleBw(applicant: AutoApplicant): AutoApplicant {
    const updatedDrivers = applicant.additionalDrivers.map((driver) => ({
      ...driver,
      financialFiling: 'No',
      anyIncident: false,
      licenseToDriveInUSA: 'Yes',
    }));

    const updatedVehicles = applicant.vehicles.map((vehicle) => ({
      ...vehicle,
      vehicleUsage: 'Personal',
      parkInresidentAddress: true,
    }));

    return {
      ...applicant,
      incidents: [],
      haveAccidentOrViolations: false,
      financialFiling: 'No',
      additionalDrivers: updatedDrivers,
      vehicles: updatedVehicles,
    };
  }

  public async validateAndBindAutoQuote(autoData: AutoPageDataService): Promise<void> {
    const startQuoteData = await autoData.getStartQuotePageData();
    const startQuotePage = new StartQuotePage(this.page);
    await startQuotePage.goto();
    await startQuotePage.startQuote(startQuoteData.zipCode);

    const bundlePage = new BundlePage(this.page);
    await bundlePage.enterBundlePage();

    const letsBeginPage = new LetsBeginPage(this.page);
    const letsBeginData = await autoData.getLetsBeginPageData();
    await letsBeginPage.enterLetsBeginPage(letsBeginData);
    await captureDomCheckpoint(this.page, this.testInfo, 'modern-01-lets-begin');

    const addressPage = new AddressPage(this.page);
    if (await addressPage.isPresent()) {
      await addressPage.enterAddressPage(await autoData.getAddressPageData());
      await captureDomCheckpoint(this.page, this.testInfo, 'modern-02-address');
    }
    const oneMomentPage = new OneMomentPage(this.page);
    await oneMomentPage.waitForOneMomentPageToBeHidden();

    const heresWhatWeFoundPage = new ModernHeresWhatWeFoundPage(this.page);
    await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);

    await heresWhatWeFoundPage.enterHeresWhatWeFoundPage(await autoData.getHeresWhatWeFoundPageData());
    await captureDomCheckpoint(this.page, this.testInfo, 'modern-03-heres-what-we-found');

    const getRewardedForDrivingSafelyPage = new GetRewardedForDrivingSafelyPage(this.page);
    await getRewardedForDrivingSafelyPage.clickNotNowThankyou();

    const contactInfoPage = new ContactInfoPage(this.page);
    await contactInfoPage.enterContactInfoPage(await autoData.getContactInfoPageData());
    await captureDomCheckpoint(this.page, this.testInfo, 'modern-04-contact-info');

    await oneMomentPage.waitForOneMomentPageToBeHidden();
    await captureDomCheckpoint(this.page, this.testInfo, 'modern-04-5-one-moment');

    const bundleOfferingPage = new BundleOfferingPage(this.page);
    await bundleOfferingPage.enterBundleOfferingPage();

    const heresYourQuotePage = new HeresYourQuotePage(this.page);
    await heresYourQuotePage.enterHeresYourQuotePage(await autoData.getHeresYourQuotePageData());
    await captureDomCheckpoint(this.page, this.testInfo, 'modern-05-heres-your-quote');

    const additionalInfoPage = new AdditionalInfoPage(this.page);
    await additionalInfoPage.enterAdditionalInfo(await autoData.getAdditionalInfoPageData());
    await captureDomCheckpoint(this.page, this.testInfo, 'modern-06-additional-information');

    await oneMomentPage.waitForFinishingYourQuotePageToBeHidden();

    const annualMileagePage = new AnnualMileagePage(this.page);
    await annualMileagePage.enterAnnualMileage(await autoData.getAnnualMileagePageData());
    await captureDomCheckpoint(this.page, this.testInfo, 'modern-06-5-annual-mileage');

    const paymentSelectionPage = new PaymentSelectionPage(this.page);
    await paymentSelectionPage.enterPaymentSelectionPage(
      await autoData.getPaymentSelectionPageData(),
      await autoData.getLetsBeginPageData(),
    );
    await captureDomCheckpoint(this.page, this.testInfo, 'modern-07-payment-selection');

    const thankYouPage = new ThankYouPage(this.page);
    await thankYouPage.enterThankYouPage();
    await captureDomCheckpoint(this.page, this.testInfo, 'modern-08-thank-you');
  }
  //Navigate to Payment Selection Page - using legacy methods which are not recommended for new implementations
  public async navigateToPaymentSelectionPage(applicant: AutoApplicant): Promise<PaymentSelectionResult> {
    const startQuotePage = new StartQuotePage(this.page);
    await startQuotePage.goto();
    await captureDomCheckpoint(this.page, this.testInfo, '01-start-quote');
    await startQuotePage.startQuote(applicant.zipCode);
    await this.page.waitForLoadState('domcontentloaded');

    const letsBeginPage = new LetsBeginPage(this.page);
    await letsBeginPage.enterLetsBeginPage(applicant);
    await captureDomCheckpoint(this.page, this.testInfo, '02-lets-begin');

    await this.handleWhoShouldWeInsureIfPresent();
    await this.tryDismissInterstitialBundle();
    await captureDomCheckpoint(this.page, this.testInfo, '04-vehicle-information');
    await this.progressVehicleAndDriverStages();
    await captureDomCheckpoint(this.page, this.testInfo, '05-driver-information');

    await this.progressToQuoteSummary();
    const quoteSummaryPage = new QuoteSummaryPage(this.page);
    await quoteSummaryPage.assertOnPage();
    await captureDomCheckpoint(this.page, this.testInfo, '07-quote-summary');
    await quoteSummaryPage.startCheckoutFlow();

    await this.handleDriverMismatchIfPresent();
    await this.handleBristolWestContinueIfPresent();
    await this.handleDriverMismatchIfPresent();

    await captureDomCheckpoint(this.page, this.testInfo, '08-payment-selection');

    const quoteNumber = await this.extractQuoteNumber();
    return { quoteNumber };
  }

  private async progressVehicleAndDriverStages(): Promise<void> {
    for (let i = 0; i < 8; i += 1) {
      if (await this.advanceKnownVehicleDriverStage()) {
        continue;
      }

      const continueSelectors = [
        this.page.getByRole('button', { name: /continue with auto|continue my quote/i }).first(),
        this.page.getByRole('button', { name: /^continue$/i }).first(),
        this.page.getByRole('button', { name: /done adding drivers|done adding vehicles/i }).first(),
        this.page.getByRole('button', { name: /save/i }).first(),
      ];

      let moved = false;
      for (const locator of continueSelectors) {
        if (await locator.isVisible({ timeout: 1_500 }).catch(() => false)) {
          await locator.click();
          await this.page.waitForLoadState('domcontentloaded');
          moved = true;
          break;
        }
      }
      if (!moved) break;
    }
  }

  private async progressToQuoteSummary(): Promise<void> {
    const quoteSummaryPage = new QuoteSummaryPage(this.page);
    for (let i = 0; i < 12; i += 1) {
      if (await quoteSummaryPage.isOnPage()) return;

      if (await this.advanceKnownVehicleDriverStage()) {
        continue;
      }

      const continueButton = this.page
        .getByRole('button', {
          name: /agree and submit|submit|continue|save|done adding drivers|done adding vehicles/i,
        })
        .first();
      if (!(await continueButton.isVisible({ timeout: 500 }).catch(() => false))) {
        break;
      }
      await continueButton.click();
      await this.page.waitForLoadState('domcontentloaded');
    }
  }

  private async advanceKnownVehicleDriverStage(): Promise<boolean> {
    const whoShouldWeInsurePage = new WhoShouldWeInsurePage(this.page);
    if (await whoShouldWeInsurePage.whoShouldWeInsureTitle.isVisible({ timeout: 1_000 }).catch(() => false)) {
      const progressbar = this.page.getByRole('progressbar').first();
      await progressbar.waitFor({ state: 'hidden', timeout: 15_000 }).catch(() => undefined);

      const addVehiclesAndDrivers = whoShouldWeInsurePage.addVehicleAndDriversButton
        .or(this.page.getByRole('button', { name: /add vehicles and drivers/i }))
        .first();
      await addVehiclesAndDrivers.scrollIntoViewIfNeeded().catch(() => undefined);
      await addVehiclesAndDrivers.click().catch(async () => {
        await addVehiclesAndDrivers.click({ force: true });
      });

      await Promise.race([
        whoShouldWeInsurePage.whoShouldWeInsureTitle.waitFor({ state: 'hidden', timeout: 20_000 }),
        this.page
          .getByText(/we'?re looking up your current drivers, vehicles and coverage/i)
          .first()
          .waitFor({ state: 'visible', timeout: 20_000 }),
      ]).catch(() => undefined);
      return true;
    }

    const heresWhatWeFoundPage = new HeresWhatWeFoundPage(this.page);
    if (await heresWhatWeFoundPage.heresWhatWeFoundPageHeader.isVisible({ timeout: 1_000 }).catch(() => false)) {
      await heresWhatWeFoundPage.continueToDriversButton.click();
      await this.page.waitForLoadState('domcontentloaded');
      return true;
    }

    const vehicleReviewPage = new VehicleReviewPage(this.page);
    if (await vehicleReviewPage.vehicleReviewPageTitle.isVisible({ timeout: 1_000 }).catch(() => false)) {
      await vehicleReviewPage.continueToDriversButton.click();
      await this.page.waitForLoadState('domcontentloaded');
      return true;
    }

    const driverReviewPage = new DriverReviewPage(this.page);
    if (await driverReviewPage.driverReviewPageHeader.isVisible({ timeout: 1_000 }).catch(() => false)) {
      await driverReviewPage.continueButton.click();
      await this.page.waitForLoadState('domcontentloaded');
      return true;
    }

    return false;
  }

  private async handleWhoShouldWeInsureIfPresent(): Promise<boolean> {
    const heading = this.page.getByRole('heading', { name: /who should we insure/i }).first();
    if (!(await heading.isVisible({ timeout: 2_000 }).catch(() => false))) return false;

    const progressbar = this.page.getByRole('progressbar').first();
    await progressbar.waitFor({ state: 'hidden', timeout: 15_000 }).catch(() => undefined);

    const addVehiclesAndDrivers = this.page.getByRole('button', { name: /add vehicles and drivers/i }).first();
    if (!(await addVehiclesAndDrivers.isVisible({ timeout: 5_000 }).catch(() => false))) return false;

    await addVehiclesAndDrivers.scrollIntoViewIfNeeded().catch(() => undefined);
    await addVehiclesAndDrivers.click().catch(async () => {
      await addVehiclesAndDrivers.click({ force: true });
    });
    await this.page.waitForLoadState('domcontentloaded');
    const advanced = !(await heading.isVisible({ timeout: 3_000 }).catch(() => false));
    return advanced;
  }

  private async handleDriverMismatchIfPresent(): Promise<void> {
    const driverMismatchTitle = this.page.getByRole('heading', { name: /driver mismatch|drivers.*match/i }).first();
    if (!(await driverMismatchTitle.isVisible({ timeout: 1_000 }).catch(() => false))) return;

    const reasonRadio = this.page.getByRole('radio').first();
    if (await reasonRadio.isVisible({ timeout: 500 }).catch(() => false)) {
      await reasonRadio.check();
    }
    const continueButton = this.page.getByRole('button', { name: /^continue$/i }).first();
    if (await continueButton.isVisible({ timeout: 500 }).catch(() => false)) {
      await continueButton.click();
      await this.page.waitForLoadState('domcontentloaded');
    }
  }

  private async handleBristolWestContinueIfPresent(): Promise<void> {
    const bwContext = this.page.getByText(/bristol west|bw discount|continue with bristol west/i).first();
    if (!(await bwContext.isVisible({ timeout: 1_000 }).catch(() => false))) return;

    const spinnerOverlay = this.page.locator('.tui-spinner-app-background, .spinner-section').first();
    await spinnerOverlay.waitFor({ state: 'hidden', timeout: 10_000 }).catch(() => undefined);

    const bwContinue = this.page
      .getByRole('button', { name: /continue with bristol west|continue with bw|continue/i })
      .first();
    if (!(await bwContinue.isVisible({ timeout: 1_000 }).catch(() => false))) return;

    await bwContinue.click({ force: true });
    await this.page.waitForLoadState('domcontentloaded');

    const bwDiscountContinue = this.page.getByRole('button', { name: /^continue$/i }).first();
    if (await bwDiscountContinue.isVisible({ timeout: 500 }).catch(() => false)) {
      await spinnerOverlay.waitFor({ state: 'hidden', timeout: 10_000 }).catch(() => undefined);
      await bwDiscountContinue.click();
      await this.page.waitForLoadState('domcontentloaded');
    }
  }

  private async tryDismissInterstitialBundle(): Promise<void> {
    const continueWithAuto = this.page.getByRole('button', { name: /continue with auto|continue/i }).first();
    if (await continueWithAuto.isVisible({ timeout: 1_000 }).catch(() => false)) {
      await continueWithAuto.click();
      await this.page.waitForLoadState('domcontentloaded');
    }
  }

  private async extractQuoteNumber(): Promise<string> {
    const quotePattern = /\b\d{8,12}\b/;
    const bodyText = await this.page
      .locator('body')
      .innerText()
      .catch(() => '');
    const match = bodyText.match(quotePattern);
    return match?.[0] ?? 'unknown';
  }
}
