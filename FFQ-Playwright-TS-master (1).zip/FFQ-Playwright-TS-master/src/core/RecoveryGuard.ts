import { promises as fs } from 'node:fs';
import type { Locator, Page, TestInfo } from '@playwright/test';
import { env } from '../config/env.js';
import { EnvironmentBaselineBlockedError } from './EnvironmentBaselineBlockedError.js';
import { clickAfterReadiness, collectPageSummary } from './BrowserUi.js';
import { captureDomCheckpoint } from './DomCheckpoint.js';
import { logger } from '../../utils/logger.js';

type RecoveryKind = 'knockout' | 'inconvenience' | 'try-again';

function rootCauseFor(kind: RecoveryKind): 'KNOCKOUT' | 'INCONVENIENCE' | 'TRY_AGAIN' {
  if (kind === 'knockout') return 'KNOCKOUT';
  if (kind === 'inconvenience') return 'INCONVENIENCE';
  return 'TRY_AGAIN';
}

interface RecoveryTarget {
  readonly kind: RecoveryKind;
  readonly marker: Locator;
  readonly action: Locator;
}

export interface StateWaitConfig {
  expectedStates: string[];
  intermediateStates?: string[];
  recoveryStates?: string[];
  maxRecoveryAttempts?: number;
  pollIntervalMs?: number;
  timeoutMs?: number;
}

/**
 * SAFE SERIALIZED Recovery Guard.
 * No background polling. All recovery operations are synchronized through explicit safe-points.
 * Recovery can only execute when the test calls executeWithRecovery() or inspectRecovery().
 * This prevents concurrent Playwright Page manipulation.
 */
export class RecoveryGuard {
  private attempts = 0;
  private detections = 0;
  private expectedKnockoutCaptured = false;
  private failure: Error | undefined;
  private reviewQuoteLoadingCaptured = false;

  public constructor(
    private readonly page: Page,
    private readonly testInfo: TestInfo,
  ) {}

  public start(): void {
    // No-op. Recovery is now synchronized through executeWithRecovery() and inspectRecovery().
  }

  public async stop(): Promise<void> {
    if (this.failure) throw this.failure;
  }

  /**
   * Wait for an expected state while periodically checking for and handling recovery states.
   * This is the GLOBAL SENTINEL for async transitions and loading boundaries.
   * Serialized, with controlled polling intervals to detect recovery states.
   */
  public async waitForStateWithRecovery(
    pageClassifier: { detect(): Promise<{ type: string }> },
    config: StateWaitConfig,
  ): Promise<{ type: string }> {
    const {
      expectedStates,
      intermediateStates = [],
      recoveryStates = ['KNOCKOUT', 'INCONVENIENCE', 'TRY_AGAIN'],
      maxRecoveryAttempts = env.RECOVERY_MAX_ATTEMPTS,
      pollIntervalMs = env.RECOVERY_POLL_INTERVAL_MS,
      timeoutMs = 30000,
    } = config;

    const startTime = Date.now();

    while (Date.now() - startTime < timeoutMs) {
      if (this.page.isClosed()) {
        throw new Error('Page closed during waitForStateWithRecovery');
      }

      const pendingRecovery = await this.detectRecoveryState(recoveryStates);
      if (pendingRecovery) {
        this.detections += 1;
        logger.info(
          `[SENTINEL] detected=${pendingRecovery.type} detections=${this.detections} actions=${this.attempts}`,
        );
        if (this.attempts >= maxRecoveryAttempts) {
          this.failure = new Error(
            `Recovery exhausted (${maxRecoveryAttempts} attempts) while waiting for ${expectedStates.join(' or ')}. ` +
              `Current state: ${pendingRecovery.type}`,
          );
          throw this.failure;
        }

        const nextAttempt = this.attempts + 1;
        const recoveryKind = pendingRecovery.type.toLowerCase().replace(/_/g, '-') as RecoveryKind;
        await captureDomCheckpoint(this.page, this.testInfo, `recovery-${nextAttempt}-${recoveryKind}-detected`);
        await this.captureRecoveryEvent(
          recoveryKind,
          'wait-for-state',
          'recovery-detected',
          pendingRecovery,
          nextAttempt,
        );

        if (env.FFQ_ENVIRONMENT_BASELINE || env.FFQ_ENVIRONMENT_BASELINE_MODE) {
          throw new EnvironmentBaselineBlockedError(
            rootCauseFor(recoveryKind),
            `Environment baseline blocked by ${rootCauseFor(recoveryKind)} while waiting for ${expectedStates.join(' or ')}.`,
          );
        }

        logger.info(`[RECOVERY] executing attempt ${nextAttempt}/${maxRecoveryAttempts}`);
        const recovered = await this.inspectRecovery('waitForStateWithRecovery', 'recovery-action');
        if (recovered) {
          const stateAfterRecovery = await pageClassifier.detect();
          await captureDomCheckpoint(this.page, this.testInfo, `recovery-after-attempt-${nextAttempt}`);
          logger.info(`[RECOVERY] State after recovery=${stateAfterRecovery.type}`);
          if (expectedStates.includes(stateAfterRecovery.type)) {
            logger.info('[RECOVERY] RECOVERED');
            return stateAfterRecovery;
          }
          continue;
        } else {
          throw new Error(`Recovery action failed for ${pendingRecovery.type} during waitForStateWithRecovery`);
        }
      }

      const state = await pageClassifier.detect();
      logger.info(`[TRANSITION] Current URL=${this.page.url()}`);
      logger.info(`[TRANSITION] Current state=${state.type}`);

      if (expectedStates.includes(state.type)) {
        await captureDomCheckpoint(this.page, this.testInfo, '11-review-quote');
        return state;
      }

      if (intermediateStates.includes(state.type)) {
        if (state.type === 'REVIEW_QUOTE_LOADING' && !this.reviewQuoteLoadingCaptured) {
          this.reviewQuoteLoadingCaptured = true;
          await captureDomCheckpoint(this.page, this.testInfo, '10e-review-quote-loading');
        }
        await this.page.waitForTimeout(pollIntervalMs);
        continue;
      }

      await this.page.waitForTimeout(pollIntervalMs);
    }

    const finalState = await pageClassifier.detect();
    throw new Error(
      `Timeout waiting for ${expectedStates.join(' or ')} (${timeoutMs}ms). ` +
        `Final state: ${finalState.type}. ` +
        `Recovery attempts: ${this.attempts}/${maxRecoveryAttempts}`,
    );
  }

  private async captureRecoveryEvent(
    kind: RecoveryKind,
    context: string,
    phase: string,
    state: { type: string },
    attemptNumber: number,
  ): Promise<void> {
    const prefix = `recovery-${attemptNumber}-${kind}-${context}-${phase}`;
    const pageSummary = await collectPageSummary(this.page);
    await this.page.screenshot({
      path: this.testInfo.outputPath(`${prefix}.png`),
      fullPage: true,
    });
    await fs.writeFile(this.testInfo.outputPath(`${prefix}.html`), await this.page.content(), 'utf8');
    await fs.writeFile(
      this.testInfo.outputPath(`${prefix}.json`),
      JSON.stringify(
        {
          kind,
          context,
          phase,
          detectedState: state.type,
          attempt: attemptNumber,
          detections: this.detections,
          recoveryActionsExecuted: this.attempts,
          testId: this.testInfo.testId,
          testName: this.testInfo.title,
          legacyId: this.legacyId(),
          logicalCheckpoint: this.logicalCheckpoint(),
          applicantCorrelationId: this.applicantCorrelationId(),
          url: this.page.url(),
          title: await this.page.title().catch(() => ''),
          pageClassification: pageSummary.pageClassification,
          heading: pageSummary.heading,
          visibleButtons: pageSummary.visibleButtons,
          selectedValues: pageSummary.selectedValues,
          validationMessages: pageSummary.validationMessages,
          overlayVisible: pageSummary.overlayVisible,
          overlayText: pageSummary.overlayText,
          zoom: pageSummary.zoom,
          timestamp: new Date().toISOString(),
          note: 'SERIALIZED RECOVERY: Detected during state wait, recovery action triggered',
        },
        null,
        2,
      ),
      'utf8',
    );
  }

  /**
   * Execute an action with recovery safety checks before and after.
   * Pattern: check recovery → execute action → check recovery → recover if needed
   * Fully serialized; no concurrent page operations.
   */
  public async executeWithRecovery<T>(actionName: string, action: () => Promise<T>): Promise<T> {
    // Check before
    await this.inspectRecovery(actionName, 'before');

    // Execute
    let result: T;
    try {
      result = await action();
    } catch (error) {
      // Check on error
      await this.inspectRecovery(actionName, 'on-error');
      throw error;
    }

    // Check after
    await this.inspectRecovery(actionName, 'after');

    return result;
  }

  /**
   * Inspect current page state and recover if a recovery marker is detected.
   * Called at safe-points (before/after/on-error).
   * Returns boolean indicating whether recovery was performed.
   */
  public async inspectRecovery(actionName: string, phase: string): Promise<boolean> {
    if (this.page.isClosed()) return false;

    for (const target of this.targets()) {
      const isVisible = await target.marker.isVisible({ timeout: 100 }).catch(() => false);
      if (!isVisible) continue;

      // Expected knockout - log but don't recover
      if (target.kind === 'knockout' && this.expectedKnockout()) {
        if (!this.expectedKnockoutCaptured) {
          await this.capture(target.kind, actionName, phase);
          this.expectedKnockoutCaptured = true;
        }
        if (env.FFQ_ENVIRONMENT_BASELINE || env.FFQ_ENVIRONMENT_BASELINE_MODE) {
          throw new EnvironmentBaselineBlockedError(
            rootCauseFor(target.kind),
            `Environment baseline blocked by ${rootCauseFor(target.kind)} during ${actionName}:${phase}.`,
          );
        }
        return false;
      }

      if (env.FFQ_ENVIRONMENT_BASELINE || env.FFQ_ENVIRONMENT_BASELINE_MODE) {
        const attemptNumber = this.attempts + 1;
        await captureDomCheckpoint(
          this.page,
          this.testInfo,
          `recovery-${attemptNumber}-${target.kind}-baseline-blocked`,
        );
        await this.capture(target.kind, actionName, phase);
        throw new EnvironmentBaselineBlockedError(
          rootCauseFor(target.kind),
          `Environment baseline blocked by ${rootCauseFor(target.kind)} during ${actionName}:${phase}.`,
        );
      }

      // Recovery marker detected - attempt recovery
      if (this.attempts >= env.RECOVERY_MAX_ATTEMPTS) {
        this.failure = new Error(
          `Recovery limit (${env.RECOVERY_MAX_ATTEMPTS}) exceeded after detecting ${target.kind} during ${actionName}:${phase}.`,
        );
        throw this.failure;
      }

      const attemptNumber = this.attempts + 1;
      await captureDomCheckpoint(this.page, this.testInfo, `recovery-${attemptNumber}-${target.kind}-action`);
      this.attempts = attemptNumber;
      await this.capture(target.kind, actionName, phase);
      logger.info('[RECOVERY] Action executed');

      if (await target.action.isVisible({ timeout: 500 }).catch(() => false)) {
        await clickAfterReadiness(target.action, this.page, `${target.kind}-recovery-action`);
        await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);
      } else {
        await this.page.reload({ waitUntil: 'domcontentloaded' });
      }

      logger.info(`[RECOVERY] complete actions=${this.attempts}`);

      return true;
    }

    return false;
  }

  private async detectRecoveryState(recoveryStates: readonly string[]): Promise<{ type: string } | null> {
    for (const target of this.targets()) {
      const stateType = target.kind.toUpperCase().replace(/-/g, '_');
      if (!recoveryStates.includes(stateType)) continue;

      const isVisible = await target.marker.isVisible({ timeout: 100 }).catch(() => false);
      if (isVisible) {
        return { type: stateType };
      }
    }

    return null;
  }

  private targets(): readonly RecoveryTarget[] {
    return [
      {
        kind: 'try-again',
        marker: this.page.getByText(/try again/i).first(),
        action: this.page.getByRole('button', { name: /try again/i }).first(),
      },
      {
        kind: 'inconvenience',
        marker: this.page.getByText(/sorry for the inconvenience|inconvenience/i).first(),
        action: this.page.getByRole('button', { name: /try again|continue|restart/i }).first(),
      },
      {
        kind: 'knockout',
        marker: this.page
          .getByText(
            /unable to continue|cannot continue|unable to offer|not eligible|it's not you\.? it's us\.?|we just can'?t offer you a farmers|still on your way to new coverage/i,
          )
          .first(),
        action: this.page.getByRole('button', { name: /try again|start over|continue/i }).first(),
      },
    ];
  }

  private expectedKnockout(): boolean {
    const marker = this.testInfo.annotations
      .filter((annotation) => annotation.type === 'expected-knockout')
      .at(-1)?.description;
    return marker === 'true';
  }

  private applicantCorrelationId(): string {
    return (
      this.testInfo.annotations.filter((annotation) => annotation.type === 'applicant-correlation-id').at(-1)
        ?.description ?? 'unknown'
    );
  }

  private logicalCheckpoint(): string {
    return (
      this.testInfo.annotations.filter((annotation) => annotation.type === 'logical-checkpoint').at(-1)?.description ??
      'unknown'
    );
  }

  private legacyId(): string {
    return (
      this.testInfo.annotations.filter((annotation) => annotation.type === 'legacy-id').at(-1)?.description ?? 'unknown'
    );
  }

  private async capture(kind: RecoveryKind, actionName: string, phase: string): Promise<void> {
    this.testInfo.annotations.push({
      type: 'recovery-kind',
      description: rootCauseFor(kind),
    });
    const prefix = `recovery-${this.attempts}-${kind}-${actionName}-${phase}`;
    await this.page.screenshot({
      path: this.testInfo.outputPath(`${prefix}.png`),
      fullPage: true,
    });
    await fs.writeFile(this.testInfo.outputPath(`${prefix}.html`), await this.page.content(), 'utf8');
    await fs.writeFile(
      this.testInfo.outputPath(`${prefix}.json`),
      JSON.stringify(
        {
          kind,
          actionName,
          phase,
          attempt: this.attempts,
          detections: this.detections,
          recoveryActionsExecuted: this.attempts,
          testId: this.testInfo.testId,
          testName: this.testInfo.title,
          legacyId: this.legacyId(),
          logicalCheckpoint: this.logicalCheckpoint(),
          applicantCorrelationId: this.applicantCorrelationId(),
          url: this.page.url(),
          title: await this.page.title().catch(() => ''),
          timestamp: new Date().toISOString(),
          note: 'SAFE SERIALIZED: Recovery happens within explicit safe-points, no concurrent background polling',
        },
        null,
        2,
      ),
      'utf8',
    );
  }
}
