import { expect, type Locator, type Page } from '@playwright/test';
import { logger } from '../../utils/logger.js';

export abstract class BasePage {
  protected constructor(protected readonly page: Page) {}

  protected async open(path = ''): Promise<void> {
    await this.page.goto(path, { waitUntil: 'domcontentloaded' });
  }

  /**
   * Utility: wait for AJAX track ID response (stub for demonstration)
   */
  protected async waitForAJAXTrackIDResponse() {
    await this.page.waitForTimeout(1000); // Placeholder
  }
  /**
   * This is to enter data into text box fields:
   *
   * @param locator pass the locator details
   * @param data pass the data to operate on the locator
   * @param customTimeout optional timeout for waiting operations
   */
  /**
   * Fills an input, logs the action, and handles errors with screenshot.
   */
  async fill(locator: Locator, value: string) {
    const fieldName = this.getFieldName(locator);
    if (!this.isFalsy(value)) {
      try {
        const field = locator.first();
        await field.waitFor({ state: 'visible', timeout: 10000 });
        await field.fill(value);
        logger.info(`Entered ${fieldName}: ${value}`);
      } catch (error) {
        logger.error(`Error entering ${fieldName} with value '${value}': ${error}`);
        throw error;
      }
    } else {
      logger.info(`Skipped entering ${fieldName} because value is falsy: '${value}'`);
    }
  }

  async pressSequentially(locator: Locator, value: string) {
    const fieldName = this.getFieldName(locator);
    if (this.isFalsy(value)) {
      logger.info(`Skipped sequential entry for ${fieldName} because value is falsy: '${value}'`);
      return;
    }

    try {
      const field = locator.first();
      await field.waitFor({ state: 'visible', timeout: 10000 });
      await field.pressSequentially(value);
      logger.info(`Entered ${fieldName} sequentially: ${value}`);
    } catch (error) {
      logger.error(`Error entering ${fieldName} sequentially with value '${value}': ${error}`);
      throw error;
    }
  }

  static isFalsy(value: unknown): boolean {
    if (
      value === false ||
      Number.isNaN(value) ||
      value === 0 ||
      value === '' ||
      value === undefined ||
      value === null ||
      value === 'NA' ||
      value === 'na'
    ) {
      return true;
    }
    return false;
  }
  /**
   * Utility: check if value is falsy (reuse from GenericUtil)
   */
  protected isFalsy(value: unknown): boolean {
    // Import GenericUtil at the top if not already
    // import { GenericUtil } from '../utils/genericUtil';
    return BasePage.isFalsy(value);
  }

  private getFieldName(locator: Locator): string {
    const locatorDescription = locator.toString();
    const accessibleName =
      locatorDescription.match(/name:\s*(['"])(.*?)\1/)?.[2] ??
      locatorDescription
        .match(/name:\s*\/((?:\\.|[^/])+)\/[a-z]*/i)?.[1]
        ?.split('|')[0]
        ?.trim() ??
      locatorDescription.match(/getByLabel\((['"])(.*?)\1/)?.[2] ??
      locatorDescription.match(/aria-label\*?=['"]([^'"]+)['"]/i)?.[1] ??
      locatorDescription.match(/formcontrolname=['"]([^'"]+)['"]/i)?.[1]?.replace(/([a-z])([A-Z])/g, '$1 $2');
    if (!accessibleName) return locatorDescription;

    const name = accessibleName.trim();
    const normalizedName = name.match(/\b(first name|last name|date of birth)\s*$/i)?.[1] ?? name;
    return normalizedName.toLowerCase();
  }
  /**
   * Utility: wait for loader icon to disappear and all AJAX/network activity to finish
   */
  public async waitForLoaderIconToDisappear() {
    await this.page.waitForLoadState('domcontentloaded');
    await this.page
      .waitForSelector('div[class="mdc-circular-progress__spinner-layer"]', { state: 'detached', timeout: 60000 })
      .catch(() => {});
    await this.page
      .waitForFunction(
        () => {
          const win = window as Window & {
            __pendingXHRCount?: number;
            __pendingFetchCount?: number;
          };
          // Playwright auto-waits for networkidle, but for extra robustness, check for active XHR/fetch
          const hasPendingXHR = (win.__pendingXHRCount ?? 0) > 0;
          const hasPendingFetch = (win.__pendingFetchCount ?? 0) > 0;
          return !hasPendingXHR && !hasPendingFetch;
        },
        undefined,
        { timeout: 15000 },
      )
      .catch(() => {});
  }

  /**
   * Clicks an element, logs the action, and handles errors with screenshot.
   */
  async click(locator: Locator, description?: string) {
    const target = description ?? this.getClickTarget(locator);
    try {
      await locator.click();
      await this.waitForLoaderIconToDisappear();
      logger.info(`Clicked: ${target}`);
    } catch (error) {
      logger.error(`Error clicking ${target}: ${error}`);
      await this.page.screenshot({ path: `error_click_${target.replace(/[^a-z0-9-_]/gi, '_')}.png` });
      throw error;
    }
  }

  private getClickTarget(locator: Locator): string {
    const locatorDescription = locator.toString();
    const roleMatch = locatorDescription.match(
      /getByRole\('([^']+)',\s*\{\s*name:\s*(?:'([^']+)'|"([^"]+)"|\/((?:\\.|[^/])+)\/[a-z]*)/,
    );
    if (roleMatch) {
      const role = roleMatch[1] ?? 'element';
      const name = (roleMatch[2] ?? roleMatch[3] ?? roleMatch[4] ?? role).replace(/\\\//g, '/').replace(/\|/g, ' or ');
      const elementType = role === 'radio' || role === 'button' ? 'button' : role;
      return `${name.trim()} ${elementType}`;
    }

    const xpathTextMatch = locatorDescription.match(/(?:text\(\)|normalize-space\(\))\s*=\s*\\?(['"])(.*?)\\?\1/);
    if (xpathTextMatch?.[2]) return xpathTextMatch[2].replace(/\\(['"])/g, '$1').trim();

    const textMatch = locatorDescription.match(/getByText\('([^']+)'/);
    if (textMatch?.[1]) return textMatch[1].trim();

    return locatorDescription;
  }

  /**
   * This is to enter data into text box fields:
   *
   * @param locator pass the locator details
   * @param data pass the data to operate on the locator
   */
  async specialFill(locator: Locator, data: string | undefined) {
    const fieldName = this.getFieldName(locator);
    if (data === undefined) {
      logger.info(`Skipped entering ${fieldName} because value is undefined`);
      return;
    }
    const customTimeout = 2000;
    const p = this.page;
    if (!this.isFalsy(data)) {
      const field = locator;
      const maxAttempts = 3; // Maximum number of attempts
      const retryDelay = 2000; // Delay between retries in milliseconds

      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
          // Ensure the field is attached and visible
          await field.waitFor({ state: 'attached', timeout: customTimeout });
          await field.waitFor({ state: 'visible', timeout: customTimeout });
          await field.scrollIntoViewIfNeeded();
          await field.hover();

          await field.click({ force: true });

          // Attempt to fill the field
          await field.fill(data, { force: true });

          // Validate using Playwright's expect API to check if the field has some data
          await expect(field).not.toHaveValue('', { timeout: customTimeout });

          // Trigger blur to ensure validation is triggered
          await field.press('Tab', { delay: 0 });
          await this.waitForLoaderIconToDisappear();

          const hasDataChangeAttribute = (await field.getAttribute('data-change')) !== null;
          if (hasDataChangeAttribute) {
            await this.waitForAJAXTrackIDResponse();
          } else {
            logger.info(`Skipping AJAX wait for ${fieldName}: data-change attribute is not present`);
          }

          // Validate using aria-invalid
          const isInvalid = await field.getAttribute('aria-invalid');
          if (isInvalid === 'true') {
            logger.info(`${fieldName} is marked invalid; retrying`);
            await p.waitForTimeout(retryDelay);
            continue;
          }

          // Validate that the value has been entered correctly
          const enteredValue = await field.inputValue();
          if (!this.isFalsy(enteredValue.trim())) {
            logger.info(`Entered ${fieldName}: ${enteredValue}`);
            return; // Exit the method if successful
          } else {
            logger.info(`Value mismatch for ${fieldName}; retrying`);
            await p.waitForTimeout(retryDelay);
          }
        } catch (error) {
          logger.error(
            `Attempt ${attempt} to enter ${fieldName} failed: ${error instanceof Error ? error.message : String(error)}`,
          );
          if (attempt === maxAttempts) {
            logger.error(`Failed to enter ${fieldName} after ${maxAttempts} attempts`);
            await this.page.screenshot({ path: `error_${locator}.png` });
            throw error;
          }
        }
      }
      throw new Error(`Failed to enter ${fieldName} after ${maxAttempts} attempts`);
    } else {
      logger.info(`Skipped entering ${fieldName} because value is falsy: '${data}'`);
    }
  }
  protected async selectByText(locator: Locator, value: string): Promise<void> {
    await expect(locator).toBeVisible();
    await locator.selectOption({ label: value });
  }
}
