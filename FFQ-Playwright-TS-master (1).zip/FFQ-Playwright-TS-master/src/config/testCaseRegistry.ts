import { readFileSync } from 'node:fs';
import { resolve, relative, sep } from 'node:path';
import { z } from 'zod';

const testCaseId = z
  .string()
  .trim()
  .min(1)
  .max(100)
  .regex(/^[A-Za-z0-9][A-Za-z0-9._-]*$/);
const workbookPath = z.string().trim().min(1).max(260);
const testCaseTag = z
  .string()
  .trim()
  .regex(/^@[A-Za-z0-9][A-Za-z0-9_-]*$/);
const stateCode = z
  .string()
  .trim()
  .regex(/^[A-Za-z]{2}$/)
  .transform((state) => state.toUpperCase());
const stateSelection = z.union([z.literal('all'), z.array(stateCode).min(1)]).default('all');

const testCaseSchema = z
  .object({
    testCaseId,
    LOB: z.literal('auto'),
    scenario: z.string().trim().min(1).max(200),
    enabled: z.boolean(),
    tags: z.array(testCaseTag),
    workbook: workbookPath,
    state: stateSelection,
  })
  .strict();

const registrySchema = z.object({
  testCases: z.array(testCaseSchema),
});

export type AutoTestCase = Readonly<z.infer<typeof testCaseSchema>>;

const repositoryRoot = resolve('.');
const dataRoot = resolve(repositoryRoot, 'data');
const registryPath = resolve(repositoryRoot, 'config', 'test-cases', 'auto.test-cases.json');

function validateWorkbookPath(workbook: string): string {
  const resolvedPath = resolve(dataRoot, workbook);
  const pathFromDataRoot = relative(dataRoot, resolvedPath);
  if (pathFromDataRoot === '' || pathFromDataRoot === '..' || pathFromDataRoot.startsWith(`..${sep}`)) {
    throw new Error(`Workbook path must remain under the data directory: ${workbook}`);
  }
  return workbook;
}

export class AutoTestCaseRegistry {
  private readonly byId: ReadonlyMap<string, AutoTestCase>;

  private constructor(testCases: readonly AutoTestCase[]) {
    const entries = new Map<string, AutoTestCase>();
    for (const testCase of testCases) {
      if (entries.has(testCase.testCaseId)) {
        throw new Error(`Duplicate Auto test-case ID: ${testCase.testCaseId}`);
      }
      entries.set(
        testCase.testCaseId,
        Object.freeze({ ...testCase, workbook: validateWorkbookPath(testCase.workbook) }),
      );
    }
    this.byId = entries;
  }

  public static load(filePath = registryPath): AutoTestCaseRegistry {
    let content: string;
    try {
      content = readFileSync(filePath, 'utf8');
    } catch (error) {
      throw new Error(`Unable to read Auto test-case registry at ${filePath}: ${String(error)}`);
    }

    let parsedJson: unknown;
    try {
      parsedJson = JSON.parse(content);
    } catch (error) {
      throw new Error(`Invalid JSON in Auto test-case registry at ${filePath}: ${String(error)}`);
    }

    const parsed = registrySchema.safeParse(parsedJson);
    if (!parsed.success) {
      const issues = parsed.error.issues.map((issue) => `${issue.path.join('.')}: ${issue.message}`).join('\n');
      throw new Error(`Invalid Auto test-case registry:\n${issues}`);
    }
    return new AutoTestCaseRegistry(parsed.data.testCases);
  }

  public getEnabled(testCaseId: string): AutoTestCase {
    const testCase = this.byId.get(testCaseId);
    if (!testCase) {
      throw new Error(`Unknown Auto test-case ID: ${testCaseId}`);
    }
    if (!testCase.enabled) {
      throw new Error(`Auto test-case ID is disabled: ${testCaseId}`);
    }
    return testCase;
  }

  public getEnabledCases(testCaseId?: string): readonly AutoTestCase[] {
    if (testCaseId) {
      return Object.freeze([this.getEnabled(testCaseId)]);
    }
    return Object.freeze([...this.byId.values()].filter((testCase) => testCase.enabled));
  }
}
