import type { AutoTestCase } from '../../config/testCaseRegistry.js';
import { ExcelDataSource, ExcelRowNotFoundError, type ExcelRecord } from '../ExcelDataSource.js';

export class MissingPageDataRecordError extends Error {
  public constructor(
    public readonly pageKey: string,
    public readonly testCaseId: string,
    public readonly referenceHeader: string,
    public readonly referenceValue: string,
  ) {
    super(
      `Test case ${testCaseId} references ${referenceHeader}=${referenceValue}, but no row was found in ${pageKey}.`,
    );
  }
}

interface PageSheetSource {
  readonly worksheet: string;
  readonly testCaseHeader: string;
  readonly lookupHeader: string;
}

const pageSheetSources: Readonly<Record<string, PageSheetSource>> = Object.freeze({
  LetsBeginPage: { worksheet: 'PersonalInfo', testCaseHeader: 'PersonalInfoID', lookupHeader: 'ApplicantID' },
  AddressPage: { worksheet: 'AddressInfo', testCaseHeader: 'AddressInfoID', lookupHeader: 'AddressID' },
  HeresWhatWeFoundPage: {
    worksheet: 'HeresWhatWeFound',
    testCaseHeader: 'HeresWhatWeFoundID',
    lookupHeader: 'HereISWhatWeFoundID',
  },
  ContactInfoPage: { worksheet: 'ContactInfo', testCaseHeader: 'ContactInfoID', lookupHeader: 'ContactInfoID' },
  HeresYourQuotePage: {
    worksheet: 'HeresYourQuote',
    testCaseHeader: 'HeresYourQuoteID',
    lookupHeader: 'HereYourQuoteID',
  },
  AdditionalInfoPage: { worksheet: 'AdditionalInfo', testCaseHeader: 'AdditionalInfoID', lookupHeader: 'AdditionalInfoID' },
  PaymentSelectionPage: {
    worksheet: 'PaymentSelection',
    testCaseHeader: 'PaymentSelectionID',
    lookupHeader: 'PaymentSelectionID',
  },
  AnnualMileagePage: { worksheet: 'AnnualMileage', testCaseHeader: 'AnnualMileageID', lookupHeader: 'AnnualMileageID' },
});

// StartQuotePage data
export interface StartQuotePageData {
  readonly zipCode: string;
}

// LetsBeginPage data
export interface LetsBeginPageData {
  readonly firstName: string;
  readonly lastName: string;
  readonly dateOfBirth: string;
}

const letsBeginPageHeaders = ['FirstName', 'LastName', 'DOB'] as const;

// AddressPage data
export interface AddressPageData {
  readonly residentAddress1: string;
  readonly city: string;
  readonly zipCode: string;
  readonly email: string | undefined;
  readonly phoneNumber: string | undefined;
}

const addressPageHeaders = ['Address', 'City', 'Zipcode', 'Email', 'MobilePhone'] as const;

export interface AnnualMileagePageData {
  readonly annualMileage: string | undefined;
}

const annualMileagePageHeaders = ['AnnualMileage'] as const;

// HeresWhatWeFoundPage data
export type VehicleChangeAction = 'Add' | 'Edit';
export type DriverChangeAction = VehicleChangeAction;

export interface HeresWhatWeFoundVehicleData {
  readonly position: number;
  readonly action: VehicleChangeAction;
  readonly vin: string | undefined;
  readonly usedFor: string | undefined;
  readonly rideOrShare: string | undefined;
  readonly ownership: string | undefined;
  readonly acquiredDate: string | undefined;
  readonly parkedAtCurrentAddress: boolean | undefined;
  readonly garageAddress: string | undefined;
  readonly city: string | undefined;
  readonly zipCode: string | undefined;
}

export interface HeresWhatWeFoundDriverData {
  readonly position: number;
  readonly action: DriverChangeAction;
  readonly firstName: string | undefined;
  readonly lastName: string | undefined;
  readonly dateOfBirth: string | undefined;
  readonly gender: string | undefined;
  readonly currentlyInsured: string | undefined;
  readonly insuranceCompany: string | undefined;
  readonly injuryLimits: string | undefined;
  readonly policyExpirationDate: string | undefined;
  readonly howLongInsured: string | undefined;
  readonly licenseIssuedByUs: boolean | undefined;
}

export interface HeresWhatWeFoundPageData {
  readonly vehicles: readonly HeresWhatWeFoundVehicleData[];
  readonly drivers: readonly HeresWhatWeFoundDriverData[];
}

const detailPositions = [1, 2, 3, 4, 5] as const;

interface VehicleHeaders {
  readonly action: string;
  readonly vin: string;
  readonly usedFor: string;
  readonly rideOrShare: string;
  readonly ownership: string;
  readonly acquiredDate: string;
  readonly parkedAtCurrentAddress: string;
  readonly garageAddress: string;
  readonly city: string;
  readonly zipCode: string;
}

function vehicleHeaders(position: number): VehicleHeaders {
  return Object.freeze({
    action: `EditOrAddVehicle${position}`,
    vin: `Vehicle${position}Vin`,
    usedFor: `Vehicle${position}UsedFor`,
    rideOrShare: `Vehicle${position}RideOrShare`,
    ownership: `Vehicle${position}Ownership`,
    acquiredDate: `Vehicle${position}AccquiredDate`,
    parkedAtCurrentAddress: `isVehicle${position}ParkedAddressSameAsCurrentAddress`,
    garageAddress: `Vehicle${position}GarageAddress`,
    city: `Vehicle${position}City`,
    zipCode: `Vehicle${position}Zipcode`,
  });
}

export interface ContactInfoPageData {
  readonly eligibleFarmersProducts: string | undefined;
}

export interface AdditionalInfoPageData {
  readonly policyStartDate: string | undefined;
  readonly licenseNumber: string;
  readonly vehicleLeasingCompany: string | undefined;
}

const additionalInfoPageHeaders = [
  'PolicyStartDate',
  'VehicleLeasingCompany',
] as const;

export interface HeresYourQuotePageData {
  readonly selectedLiabilityCoverages: string | undefined;
  readonly bodilyInjuryCoverage: string | undefined;
  readonly propertyDamageLiabilityCoverage: string | undefined;
  readonly umUimBodilyInjuryCoverage: string | undefined;
  readonly umUimPropertyDamageCoverage: string | undefined;
  readonly medicalCoverage: string | undefined;
  readonly accidentalDeathOrDisablingInjuryCoverage: string | undefined;
  readonly personalInjuryProtectionCoverage: string | undefined;
}

const heresYourQuotePageHeaders = [
  'SelectLiablityCoverages',
  'BodilyInjuryCoverage',
  'PropertyDamageLiabilityCoverage',
  'UM/UIMBodilyInjuryCoverage',
  'UM/UIMPropertyDamageCoverage',
  'MedicalCoverage',
  'AccidentalDeathorDisablingInjuryCoverage',
  'PersonalInjuryProtectionCoverage',
] as const;

export interface PaymentSelectionPageData {
  readonly paymentMode: string | undefined;
  readonly preferredPaymentMethod: string | undefined;
  readonly routingNumber: string | undefined;
  readonly accountNumber: string | undefined;
  readonly confirmAccountNumber: string | undefined;
  readonly cardNumber: string | undefined;
  readonly expirationDate: string | undefined;
  readonly cvv: string | undefined;
  readonly billingZipcode: string | undefined;
}

const paymentSelectionPageHeaders = [
  'PaymentMode',
  'PrefferedPaymentMethod',
  'RoutingNumber',
  'AccountNumber',
  'ConfirmAccountNumber',
  'CardNumber',
  'CardExpirationDate',
  'CVV',
  'BillingZipCode',
] as const;
export class AutoPageDataService {
  private readonly pageDataCache = new Map<string, Promise<ExcelRecord>>();
  private testCaseRow: Promise<ExcelRecord> | undefined;

  public constructor(
    private readonly testCase: AutoTestCase,
    private readonly dataSource = new ExcelDataSource(),
    private readonly selectedState?: string,
  ) { }

  // StartQuotePage data
  public async getStartQuotePageData(): Promise<StartQuotePageData> {
    const row = await this.getAddressPageRow();
    return Object.freeze({ zipCode: requiredString(row, 'Zipcode') });
  }

  // LetsBeginPage data
  public async getLetsBeginPageData(): Promise<LetsBeginPageData> {
    const row = await this.getPageData('LetsBeginPage', letsBeginPageHeaders);
    return Object.freeze({
      firstName: requiredString(row, 'FirstName'),
      lastName: requiredString(row, 'LastName'),
      dateOfBirth: requiredDate(row, 'DOB'),
    });
  }

  // AddressPage data
  public async getAddressPageData(): Promise<AddressPageData> {
    const row = await this.getAddressPageRow();
    return Object.freeze({
      residentAddress1: requiredString(row, 'Address'),
      city: requiredString(row, 'City'),
      zipCode: requiredString(row, 'Zipcode'),
      email: optionalString(row, 'Email'),
      phoneNumber: optionalString(row, 'MobilePhone'),
    });
  }

  public async getAddressStates(): Promise<readonly string[]> {
    const testCaseRow = await this.getTestCaseRow('AddressInfoID');
    const addressIds = requiredString(testCaseRow, 'AddressInfoID')
      .split(',')
      .map((addressId) => addressId.trim())
      .filter(Boolean);
    const addressRows = await this.dataSource.rows(this.testCase.workbook, 'AddressInfo');
    return Object.freeze(addressIds.map((addressId) => {
      const row = addressRows.find((candidate) => optionalString(candidate, 'AddressID') === addressId);
      if (!row) throw new MissingPageDataRecordError('AddressPage', this.testCase.testCaseId, 'AddressID', addressId);
      return requiredString(row, 'State');
    }));
  }

  // HeresWhatWeFoundPage data
  public async getHeresWhatWeFoundPageData(): Promise<HeresWhatWeFoundPageData> {
    const vehicleDetails = detailPositions.map((position) => ({ position, headers: vehicleHeaders(position) }));
    const row = await this.getPageData('HeresWhatWeFoundPage', []);
    const vehicles = vehicleDetails.flatMap(({ position, headers }) => {
      const action = detailAction(row, headers.action, this.testCase.testCaseId);
      if (!action) return [];

      return [
        Object.freeze({
          position,
          action,
          vin: optionalDetailValue(row, headers.vin),
          usedFor: optionalDetailValue(row, headers.usedFor),
          rideOrShare: optionalDetailValue(row, headers.rideOrShare),
          ownership: optionalDetailValue(row, headers.ownership),
          acquiredDate: optionalDetailValue(row, headers.acquiredDate),
          parkedAtCurrentAddress: optionalDetailBoolean(row, headers.parkedAtCurrentAddress),
          garageAddress: optionalDetailValue(row, headers.garageAddress),
          city: optionalDetailValue(row, headers.city),
          zipCode: optionalDetailValue(row, headers.zipCode),
        }),
      ];
    });
    const drivers = detailPositions.flatMap((position) => {
      const action = detailAction(row, `EditOrAddDriver${position}`, this.testCase.testCaseId);
      if (!action) return [];

      return [
        Object.freeze({
          position,
          action,
          firstName: optionalDetailValue(row, `Driver${position}FirstName`),
          lastName: optionalDetailValue(row, `Driver${position}LastName`),
          dateOfBirth: optionalDetailValue(row, `Driver${position}DOB`),
          gender: optionalDetailValue(row, `Driver${position}Gender`),
          currentlyInsured: optionalDetailValue(row, `Driver${position}AreYouCurrentlyInsured`),
          insuranceCompany: optionalDetailValue(row, `Driver${position}CurrentInsuranceCompany`),
          injuryLimits: optionalDetailValue(row, `Driver${position}InjuryLimits`),
          policyExpirationDate: optionalDetailValue(row, `Driver${position}ExipirationDate`),
          howLongInsured: optionalDetailValue(row, `Driver${position}LengthOfinsurance`),
          licenseIssuedByUs: optionalDetailBoolean(row, `Driver${position}isDrivingLicenseIssueByUS`),
        }),
      ];
    });
    return Object.freeze({ vehicles: Object.freeze(vehicles), drivers: Object.freeze(drivers) });
  }
  public async getContactInfoPageData(): Promise<ContactInfoPageData> {
    const row = await this.getPageData('ContactInfoPage', ['EligibleFarmersProducts']);
    return Object.freeze({ eligibleFarmersProducts: optionalString(row, 'EligibleFarmersProducts') });
  }

  public async getAdditionalInfoPageData(): Promise<AdditionalInfoPageData> {
    const row = await this.getPageData('AdditionalInfoPage', additionalInfoPageHeaders);
    const addressRow = await this.getAddressPageRow();
    return Object.freeze({
      policyStartDate: optionalDate(row, 'PolicyStartDate'),
      licenseNumber: requiredString(addressRow, 'LicenseNumber'),
      vehicleLeasingCompany: optionalDetailValue(row, 'VehicleLeasingCompany'),
    });
  }

  public async getHeresYourQuotePageData(): Promise<HeresYourQuotePageData> {
    const row = await this.getPageData('HeresYourQuotePage', heresYourQuotePageHeaders);
    return Object.freeze({
      selectedLiabilityCoverages: optionalString(row, 'SelectLiablityCoverages'),
      bodilyInjuryCoverage: optionalString(row, 'BodilyInjuryCoverage'),
      propertyDamageLiabilityCoverage: optionalString(row, 'PropertyDamageLiabilityCoverage'),
      umUimBodilyInjuryCoverage: optionalString(row, 'UM/UIMBodilyInjuryCoverage'),
      umUimPropertyDamageCoverage: optionalString(row, 'UM/UIMPropertyDamageCoverage'),
      medicalCoverage: optionalString(row, 'MedicalCoverage'),
      accidentalDeathOrDisablingInjuryCoverage: optionalString(row, 'AccidentalDeathorDisablingInjuryCoverage'),
      personalInjuryProtectionCoverage: optionalString(row, 'PersonalInjuryProtectionCoverage'),
    });
  }
  //Annual Mileage Page Data
  public async getAnnualMileagePageData(): Promise<AnnualMileagePageData> {
    const row = await this.getPageData('AnnualMileagePage', annualMileagePageHeaders);
    return Object.freeze({
      annualMileage: optionalDetailValue(row, 'AnnualMileage'),
    });
  }
  public async getPaymentSelectionPageData(): Promise<PaymentSelectionPageData> {
    const row = await this.getPageData('PaymentSelectionPage', paymentSelectionPageHeaders);
    return Object.freeze({
      paymentMode: optionalDetailValue(row, 'PaymentMode'),
      preferredPaymentMethod: optionalDetailValue(row, 'PrefferedPaymentMethod'),
      routingNumber: optionalDetailValue(row, 'RoutingNumber'),
      accountNumber: optionalDetailValue(row, 'AccountNumber'),
      confirmAccountNumber: optionalDetailValue(row, 'ConfirmAccountNumber'),
      cardNumber: optionalDetailValue(row, 'CardNumber'),
      expirationDate: optionalDetailValue(row, 'CardExpirationDate'),
      cvv: optionalDetailValue(row, 'CVV'),
      billingZipcode: optionalDetailValue(row, 'BillingZipCode'),
    });
  }

  // Shared Excel access helpers
  private async getPageData<T extends ExcelRecord = ExcelRecord>(
    pageKey: string,
    requiredHeaders: readonly string[],
  ): Promise<T> {
    const source = pageSheetSources[pageKey];
    if (!source) throw new Error(`No worksheet reference mapping exists for ${pageKey}.`);
    const testCaseRow = await this.getTestCaseRow(source.testCaseHeader);
    const referenceValue = requiredString(testCaseRow, source.testCaseHeader);
    if (referenceValue.toUpperCase() === 'NA') return Object.freeze({}) as T;
    const cacheKey = `${source.worksheet}:${source.lookupHeader}:${referenceValue}:${requiredHeaders.join('|')}`;
    const existing = this.pageDataCache.get(cacheKey);
    if (existing) return (await existing) as T;

    const pending = this.dataSource.rowByHeader(
      this.testCase.workbook,
      source.worksheet,
      source.lookupHeader,
      referenceValue,
      requiredHeaders,
    );
    this.pageDataCache.set(cacheKey, pending);
    try {
      return (await pending) as T;
    } catch (error) {
      this.pageDataCache.delete(cacheKey);
      if (error instanceof ExcelRowNotFoundError) {
        throw new MissingPageDataRecordError(
          pageKey,
          this.testCase.testCaseId,
          source.lookupHeader,
          referenceValue,
        );
      }
      throw error;
    }
  }

  private async getAddressPageRow(): Promise<ExcelRecord> {
    const testCaseRow = await this.getTestCaseRow('AddressInfoID');
    const addressIds = requiredString(testCaseRow, 'AddressInfoID')
      .split(',')
      .map((addressId) => addressId.trim())
      .filter(Boolean);
    const addressRows = await this.dataSource.rows(this.testCase.workbook, 'AddressInfo');
    const matches = addressRows.filter((row) => addressIds.includes(optionalString(row, 'AddressID') ?? ''));
    const selectedState = this.selectedState;
    const row = selectedState
      ? matches.find((candidate) => optionalString(candidate, 'State')?.toUpperCase() === selectedState.toUpperCase())
      : matches.length === 1 ? matches[0] : undefined;
    if (!row) {
      const selection = selectedState ? ` for state ${selectedState}` : '';
      throw new MissingPageDataRecordError('AddressPage', this.testCase.testCaseId, 'AddressInfoID', `${addressIds.join(',')}${selection}`);
    }
    for (const header of addressPageHeaders) {
      if (!(header in row)) throw new Error(`Worksheet AddressInfo in ${this.testCase.workbook} is missing required header: ${header}.`);
    }
    return row;
  }

  private async getTestCaseRow(requiredReferenceHeader: string): Promise<ExcelRecord> {
    if (!this.testCaseRow) {
      this.testCaseRow = this.dataSource.rowByHeader(
        this.testCase.workbook,
        'TestCase',
        'TestcaseID',
        this.testCase.testCaseId,
        [requiredReferenceHeader],
        2,
      );
    }
    try {
      return await this.testCaseRow;
    } catch (error) {
      this.testCaseRow = undefined;
      if (error instanceof ExcelRowNotFoundError) {
        throw new Error(
          `Test case ${this.testCase.testCaseId} has no matching workbook TestcaseID.`,
        );
      }
      throw error;
    }
  }
}

function requiredString(row: ExcelRecord, header: string): string {
  const value = stringifyCellValue(row[header]).trim();
  if (!value) {
    throw new Error(`Workbook record ${String(row.TestcaseID ?? row.ApplicantID ?? '')} has no value for required header ${header}.`);
  }
  return value;
}

function optionalString(row: ExcelRecord, header: string): string | undefined {
  const value = stringifyCellValue(row[header]).trim();
  return value || undefined;
}

function optionalDate(row: ExcelRecord, header: string): string | undefined {
  const value = row[header];
  if (value instanceof Date) {
    const month = String(value.getUTCMonth() + 1).padStart(2, '0');
    const day = String(value.getUTCDate()).padStart(2, '0');
    return `${month}/${day}/${value.getUTCFullYear()}`;
  }
  const date = stringifyCellValue(value).trim();
  return date && date.toUpperCase() !== 'NA' ? date : undefined;
}

function detailAction(row: ExcelRecord, header: string, testCaseId: string): VehicleChangeAction | undefined {
  const action = optionalDetailValue(row, header);
  if (!action) return undefined;
  if (action.toLowerCase() === 'add') return 'Add';
  if (action.toLowerCase() === 'edit') return 'Edit';
  throw new Error(`Test case ${testCaseId} has unsupported ${header} value: ${action}.`);
}

function optionalDetailValue(row: ExcelRecord, header: string): string | undefined {
  const value = stringifyCellValue(row[header]).trim();
  return value && value.toUpperCase() !== 'NA' ? value : undefined;
}

function optionalDetailBoolean(row: ExcelRecord, header: string): boolean | undefined {
  const value = optionalDetailValue(row, header);
  if (!value) return undefined;
  if (/^(yes|true)$/i.test(value)) return true;
  if (/^(no|false)$/i.test(value)) return false;
  throw new Error(`Expected ${header} to be Yes, No, true, or false, received: ${value}.`);
}

function requiredDate(row: ExcelRecord, header: string): string {
  const value = row[header];
  if (value instanceof Date) {
    const month = String(value.getUTCMonth() + 1).padStart(2, '0');
    const day = String(value.getUTCDate()).padStart(2, '0');
    return `${month}/${day}/${value.getUTCFullYear()}`;
  }
  return requiredString(row, header);
}

function stringifyCellValue(value: unknown): string {
  if (value === null || value === undefined) return '';
  if (typeof value !== 'object') return String(value);

  if ('text' in value && typeof value.text === 'string') {
    return value.text;
  }
  if ('result' in value && value.result !== undefined && value.result !== null) {
    return stringifyCellValue(value.result);
  }
  if ('richText' in value && Array.isArray(value.richText)) {
    return value.richText
      .map((part) => ('text' in part && typeof part.text === 'string' ? part.text : ''))
      .join('');
  }
  return String(value);
}
