import { resolve } from 'node:path';
import ExcelJS from 'exceljs';

export type ExcelRecord = Readonly<Record<string, unknown>>;

export class ExcelRowNotFoundError extends Error {}

interface WorksheetData {
  readonly headers: readonly string[];
  readonly rows: readonly ExcelRecord[];
}

export class ExcelDataSource {
  private static readonly workbookCache = new Map<string, Promise<ExcelJS.Workbook>>();
  private static readonly worksheetCache = new Map<string, Promise<WorksheetData>>();

  public constructor(private readonly dataRoot = resolve('data')) {}

  public async rows(fileName: string, worksheetName: string, headerRow = 1): Promise<ExcelRecord[]> {
    const worksheet = await this.readWorksheet(fileName, worksheetName, headerRow);
    return [...worksheet.rows];
  }

  public async rowByHeader(
    fileName: string,
    worksheetName: string,
    lookupHeader: string,
    lookupValue: string,
    requiredHeaders: readonly string[] = [],
    headerRow = 1,
  ): Promise<ExcelRecord> {
    const worksheet = await this.readWorksheet(fileName, worksheetName, headerRow);
    const missingHeaders = [lookupHeader, ...requiredHeaders].filter(
      (header) => !worksheet.headers.includes(header),
    );
    if (missingHeaders.length > 0) {
      throw new Error(
        `Worksheet ${worksheetName} in ${fileName} is missing required headers: ${missingHeaders.join(', ')}.`,
      );
    }

    const matches = worksheet.rows.filter(
      (row) => String(row[lookupHeader] ?? '').trim() === lookupValue.trim(),
    );
    if (matches.length === 0) {
      throw new ExcelRowNotFoundError(
        `No row in worksheet ${worksheetName} in ${fileName} has ${lookupHeader}=${lookupValue}.`,
      );
    }
    if (matches.length > 1) {
      throw new Error(
        `Multiple rows in worksheet ${worksheetName} in ${fileName} have ${lookupHeader}=${lookupValue}.`,
      );
    }
    return matches[0]!;
  }

  private async readWorksheet(fileName: string, worksheetName: string, headerRow: number): Promise<WorksheetData> {
    const filePath = resolve(this.dataRoot, fileName);
    const cacheKey = `${filePath}::${worksheetName}::${headerRow}`;
    const existing = ExcelDataSource.worksheetCache.get(cacheKey);
    if (existing) return existing;

    const pending = this.loadWorksheet(filePath, fileName, worksheetName, headerRow);
    ExcelDataSource.worksheetCache.set(cacheKey, pending);
    try {
      return await pending;
    } catch (error) {
      ExcelDataSource.worksheetCache.delete(cacheKey);
      throw error;
    }
  }

  private async loadWorksheet(
    filePath: string,
    fileName: string,
    worksheetName: string,
    headerRow: number,
  ): Promise<WorksheetData> {
    const workbook = await this.readWorkbook(filePath);
    const worksheet = workbook.getWorksheet(worksheetName);
    if (!worksheet) {
      throw new Error(`Worksheet ${worksheetName} was not found in ${fileName}.`);
    }
    const headerValues = worksheet.getRow(headerRow).values;
    const headers: string[] = (Array.isArray(headerValues) ? headerValues : [])
      .slice(1)
      .map((value) => String(value ?? '').trim());
    const duplicateHeaders = headers.filter((header, index) => header !== '' && headers.indexOf(header) !== index);
    if (duplicateHeaders.length > 0) {
      throw new Error(`Worksheet ${worksheetName} in ${fileName} contains duplicate headers: ${duplicateHeaders.join(', ')}.`);
    }
    const records: ExcelRecord[] = [];
    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber <= headerRow) return;
      const record: Record<string, unknown> = {};
      let hasValue = false;
      headers.forEach((header: string, index: number) => {
        if (!header) return;
        const value = row.getCell(index + 1).value;
        if (value !== null && value !== undefined && value !== '') hasValue = true;
        record[header] = value;
      });
      if (hasValue) records.push(Object.freeze(record));
    });
    return Object.freeze({ headers: Object.freeze(headers), rows: Object.freeze(records) });
  }

  private async readWorkbook(filePath: string): Promise<ExcelJS.Workbook> {
    const existing = ExcelDataSource.workbookCache.get(filePath);
    if (existing) return existing;

    const pending = (async () => {
      const workbook = new ExcelJS.Workbook();
      await workbook.xlsx.readFile(filePath);
      return workbook;
    })();
    ExcelDataSource.workbookCache.set(filePath, pending);
    try {
      return await pending;
    } catch (error) {
      ExcelDataSource.workbookCache.delete(filePath);
      throw error;
    }
  }

  public filter(rows: readonly ExcelRecord[], expression: string): ExcelRecord[] {
    if (!expression.trim()) return [...rows];
    const clauses = expression.split(',').map((clause) => clause.trim());
    return rows.filter((row) =>
      clauses.every((clause) => {
        const [key, ...valueParts] = clause.split('=');
        if (!key || valueParts.length === 0) throw new Error(`Invalid filter: ${clause}`);
        return String(row[key] ?? '').trim() === valueParts.join('=').trim();
      }),
    );
  }
}
