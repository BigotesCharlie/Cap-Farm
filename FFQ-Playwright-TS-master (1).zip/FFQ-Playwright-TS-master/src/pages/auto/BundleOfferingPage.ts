import { type Page, type Locator } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import { expect } from '@playwright/test';
import { isOnpage } from '../../../utils/CommonUtils.js';

export class BundleOfferingPage extends BasePage {
  private readonly bundleOfferingPageHeader: Locator;
  private readonly continueWithAutoOnlyButton: Locator;
  private readonly continueWithoutDiscountlink: Locator;
  public constructor(page: Page) {
    super(page);

    this.bundleOfferingPageHeader = this.page.getByRole('heading', { name: 'Want a renters discount?' });
    this.continueWithAutoOnlyButton = this.page.getByRole('button', { name: ' Continue with auto ' });
    this.continueWithoutDiscountlink = this.page.getByText('Continue without discount', { exact: true });
  }

  public async enterBundleOfferingPage(): Promise<void> {
    const isBundleOfferingPageDisplayed = await isOnpage(this.bundleOfferingPageHeader);
    if (isBundleOfferingPageDisplayed) {
      await this.page.waitForURL('**/auto-renters-bundle-offering');
      await expect(this.bundleOfferingPageHeader).toBeVisible();
      await this.click(this.continueWithAutoOnlyButton);
      await this.click(this.continueWithoutDiscountlink);
    }
  }
}
