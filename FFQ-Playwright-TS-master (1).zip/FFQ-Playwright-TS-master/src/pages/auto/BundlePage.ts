import { type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import { isOnpage } from '../../../utils/CommonUtils.js';

export class BundlePage extends BasePage {
  private readonly header: Locator;
  private readonly continueWithAutoOnlyButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.header = page.getByText(' Bundle and save ');
    this.continueWithAutoOnlyButton = this.page.getByText('Continue with auto only');
  }

  public async enterBundlePage(): Promise<void> {
    const isBundlePageDisplayed = await isOnpage(this.header);
    if (isBundlePageDisplayed) {
      await this.click(this.continueWithAutoOnlyButton);
    }
  }
}
