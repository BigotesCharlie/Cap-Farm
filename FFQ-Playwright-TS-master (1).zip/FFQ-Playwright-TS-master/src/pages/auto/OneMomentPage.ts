import { expect, type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import { logger } from '../../../utils/logger.js';

export class OneMomentPage extends BasePage {
  private readonly oneMomentPageHeader: Locator;
  private readonly finishingUpPageHeader: Locator;

  public constructor(page: Page) {
    super(page);
    this.oneMomentPageHeader = page.getByRole('heading', { name: 'One moment, please' });
    this.finishingUpPageHeader = page.getByRole('heading', { name: 'Finalizing your quote' });
  }

  public async waitForOneMomentPageToBeHidden(): Promise<void> {
    logger.info('Waiting for One Moment page to be hidden');
    await expect(this.oneMomentPageHeader).toBeHidden({ timeout: 120_000 });
  }

  public async waitForFinishingYourQuotePageToBeHidden(): Promise<void> {
    logger.info('Waiting for Finishing Your Quote page to be hidden');
    await expect(this.finishingUpPageHeader).toBeHidden({ timeout: 120_000 });
  }
}
