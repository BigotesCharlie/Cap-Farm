import { expect, type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';

export class QuoteSummaryPage extends BasePage {
  private readonly quoteSummaryHeading: Locator;
  private readonly startCheckout: Locator;

  public constructor(page: Page) {
    super(page);
    this.quoteSummaryHeading = page.getByRole('heading', { name: /review quote|quote summary/i }).first();
    this.startCheckout = page
      .getByRole('button', { name: /start checkout|continue with this quote|continue/i })
      .first();
  }

  public async isOnPage(): Promise<boolean> {
    const headingVisible = await this.quoteSummaryHeading.isVisible({ timeout: 2_500 }).catch(() => false);
    if (headingVisible) return true;
    return this.startCheckout.isVisible({ timeout: 2_500 }).catch(() => false);
  }

  public async assertOnPage(): Promise<void> {
    if (await this.startCheckout.isVisible({ timeout: 2_000 }).catch(() => false)) {
      return;
    }
    await expect(this.quoteSummaryHeading).toBeVisible();
  }

  public async startCheckoutFlow(): Promise<void> {
    await this.startCheckout.click();
    await this.page.waitForLoadState('domcontentloaded');
  }
}
