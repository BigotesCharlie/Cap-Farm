import { type Locator, type Page, expect } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';

export class ThankYouPage extends BasePage {
  private readonly header: Locator;

  public constructor(page: Page) {
    super(page);
    this.header = page.getByRole('heading', { name: 'Thank you for joining us as a policyholder!' });
  }

  public async enterThankYouPage(): Promise<void> {
    //await this.page.waitForURL('**/esignature/*/pending-ecn');
    await expect(this.header).toBeVisible({ timeout: 60000 });
  }
}
