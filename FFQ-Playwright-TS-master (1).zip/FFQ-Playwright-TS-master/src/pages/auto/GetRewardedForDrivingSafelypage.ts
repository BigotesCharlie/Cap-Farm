import { type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import { isOnpage } from '../../../utils/CommonUtils.js';

export class GetRewardedForDrivingSafelyPage extends BasePage {
  private readonly notNowThankyoubutton: Locator;

  constructor(page: Page) {
    super(page);
    this.notNowThankyoubutton = page.getByText('Not now, thank you');
  }

  public async clickNotNowThankyou(): Promise<void> {
    const isSignalPageDisplayed = await isOnpage(this.notNowThankyoubutton);
    if (isSignalPageDisplayed) {
      await this.page.waitForURL(/signal/);
      await this.click(this.notNowThankyoubutton);
    }
  }
}
