import { type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import { normalizeDate } from '../../../utils/CommonUtils.js';

export class RetrieveSavedQuotePage extends BasePage {
  private readonly quoteIdInput: Locator;
  private readonly retrieveButton: Locator;
  private readonly lastName: Locator;
  private readonly DOB: Locator;
  private readonly zipcode: Locator;
  private readonly retrivetab: Locator;
  public constructor(page: Page) {
    super(page);
    this.quoteIdInput = page.getByRole('textbox', { name: /Quote Number Or Email/i }).first();
    this.retrieveButton = page.getByRole('button', { name: /Retrieve your quote/i }).first();
    this.lastName = page.getByRole('textbox', { name: /last Name/i }).first();
    this.DOB = page.getByLabel('Date of Birth in form MM/DD/YYYY').first();
    this.zipcode = page.getByLabel('ZIP Code').first();
    this.retrivetab = page.getByText('Retrieve a Saved Quote').last();
  }

  public async enterRetrieveSavedQuotePage(
    quoteId: string,
    lastName: string,
    DOB: string,
    zipcode: string,
  ): Promise<void> {
    await this.retrivetab.click();
    await this.fill(this.quoteIdInput, quoteId);
    await this.fill(this.lastName, lastName);
    await this.fill(this.DOB, normalizeDate(DOB));
    await this.fill(this.zipcode, zipcode);
    await this.retrieveButton.click();
  }
}
