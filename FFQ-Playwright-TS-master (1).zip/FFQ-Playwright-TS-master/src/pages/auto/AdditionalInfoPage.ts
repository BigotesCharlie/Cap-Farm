import { type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import { expect } from '@playwright/test';
import { normalizeDate, clickWithIntervals } from '../../../utils/CommonUtils.js';
import type { AdditionalInfoPageData } from '../../data/auto/AutoPageDataService.js';

export class AdditionalInfoPage extends BasePage {
  private readonly LicenseNumber: Locator;
  private readonly policyStartDate: Locator;
  private readonly continueButton: Locator;
  private readonly header: Locator;
  private readonly vehicleLeasingCompany: Locator;
  private readonly signalEnrollment: Locator;
  public constructor(page: Page) {
    super(page);
    this.LicenseNumber = page.getByRole('textbox', { name: 'License' });
    this.policyStartDate = page.getByLabel('Select policy start date in the format of mmddyyyy,');
    this.continueButton = page.getByRole('button', { name: /continue/i });
    this.header = page.getByText(' Review and complete auto ');
    this.vehicleLeasingCompany = page.getByLabel(' Enter leasing company ');
    this.signalEnrollment = page.getByLabel('By clicking Continue below, I confirm that I:');
  }

  public async enterAdditionalInfo(additionalInfoData: AdditionalInfoPageData): Promise<void> {
    await this.page.waitForURL(/additional-info/);
    await expect(this.header).toBeVisible();
    if (await this.LicenseNumber.isVisible()) {
      await this.specialFill(this.LicenseNumber, additionalInfoData.licenseNumber);
    }
    const policyStartDate = additionalInfoData.policyStartDate?.trim();
    if (policyStartDate && policyStartDate.toUpperCase() !== 'NA') {
      await this.specialFill(this.policyStartDate, normalizeDate(policyStartDate));
    }
    await this.vehicleInfo(additionalInfoData);
    await this.waitForLoaderIconToDisappear();
    await clickWithIntervals(this.continueButton);
  }

  public async vehicleInfo(additionalInfoData: AdditionalInfoPageData): Promise<void> {
    const vehicleLeasingCompany = additionalInfoData.vehicleLeasingCompany?.trim();
    if (vehicleLeasingCompany && vehicleLeasingCompany.toUpperCase() !== 'NA') {
      await this.vehicleLeasingCompany.pressSequentially(vehicleLeasingCompany);
      await this.page.keyboard.press('Tab');
    }

    if (await this.signalEnrollment.isVisible()) {
      await this.signalEnrollment.check();
    }
  }
}
