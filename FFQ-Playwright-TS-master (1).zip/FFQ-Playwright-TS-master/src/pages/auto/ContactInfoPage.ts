import { type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import { expect } from '@playwright/test';
import { proceedToNextPage, splitAndTrim } from '../../../utils/CommonUtils.js';
import type { ContactInfoPageData } from '../../data/auto/AutoPageDataService.js';

export class ContactInfoPage extends BasePage {
  private contactInfoPageHeader: Locator;
  private readonly continueButton: Locator;
  private readonly toggleSwitch: Locator;
  constructor(page: Page) {
    super(page);
    this.contactInfoPageHeader = page.getByRole('heading', { name: 'Last step before your quote' });
    this.continueButton = page.getByRole('button', { name: /agree and submit|continue/i }).first();
    this.toggleSwitch = page.locator("span[class='mdc-elevation-overlay']");
  }

  public async enterContactInfoPage(contactInfoPageData: ContactInfoPageData): Promise<void> {
    await expect(this.contactInfoPageHeader).toBeVisible();
    for (const product of splitAndTrim(contactInfoPageData.eligibleFarmersProducts ?? '')) {
      await this.click(this.page.locator(`//span[text()='${product}']`));
    }
    await proceedToNextPage(this.continueButton, this.page);
  }
}
