import { type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import { normalizeDate, proceedToNextPage } from '../../../utils/CommonUtils.js';
import type {
  HeresWhatWeFoundDriverData,
  HeresWhatWeFoundPageData,
  HeresWhatWeFoundVehicleData,
} from '../../data/auto/AutoPageDataService.js';

export class HeresWhatWeFoundPage extends BasePage {
  private readonly pageHeading: Locator;
  private readonly continueButton: Locator;
  private readonly vin: Locator;
  private readonly usedForPersonal: Locator;
  private readonly usedForBusiness: Locator;
  private readonly rideshareorfoodDeliveryService: Locator;
  private readonly ownershipasOwned: Locator;
  private readonly ownershipasLeased: Locator;
  private readonly ownershipasFinanced: Locator;
  private readonly dateofPurchase: Locator;
  private readonly otherLocationAddress: Locator;
  private readonly garageAddress: Locator;
  private readonly city: Locator;
  private readonly state: Locator;
  private readonly zipCode: Locator;
  private readonly savechangesButton: Locator;
  private readonly addAnotherVehicleButton: Locator;
  private readonly addAnotherDriverButton: Locator;
  private readonly firstName: Locator;
  private readonly lastName: Locator;
  private readonly dateOfBirth: Locator;
  private readonly addVehicleButton: Locator;
  private readonly addVehiclesAndDriversButton: Locator;
  private readonly currentlyInsuredYes: Locator;
  private readonly currentlyInsuredNo: Locator;
  private readonly currentInsuranceCompany: Locator;
  private readonly currentInjuryLimits: Locator;
  private readonly policyExpirationDate: Locator;
  private readonly howLongInsured: Locator;
  private readonly injuryLimitsDropdown: Locator;
  private readonly howLongInsuredDropdown: Locator;
  private readonly whoShouldWeInsureHeader: Locator;
  private readonly doYouHaveMoreVehicles: Locator;
  private readonly cancelButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageHeading = page.getByRole('heading', { name: /what we found/i }).first();
    this.continueButton = page.getByRole('button', { name: /agree and submit|continue/i }).first();
    this.vin = page.getByLabel('VIN (Optional)');
    this.usedForPersonal = page.getByRole('radio', { name: 'Personal' });
    this.usedForBusiness = page.getByRole('radio', { name: 'Business' });
    this.rideshareorfoodDeliveryService = page.getByRole('checkbox', {
      name: /this vehicle is used for rideshare and\/or food delivery services/i,
    });
    this.ownershipasOwned = page.getByRole('radio', { name: 'Owned' });
    this.ownershipasLeased = page.getByRole('radio', { name: 'Leased' });
    this.ownershipasFinanced = page.getByRole('radio', { name: 'Financed' });
    this.dateofPurchase = page.getByText('Date of purchase');
    this.otherLocationAddress = page.getByLabel('Other location');
    this.garageAddress = page.getByLabel('Garaging address').last();
    this.city = page.getByLabel('City');
    this.state = page.getByLabel('State');
    this.zipCode = page.getByLabel('Zip Code');
    this.savechangesButton = page.getByRole('button', { name: /save changes/i });
    this.addAnotherVehicleButton = page.getByRole('button', { name: /add another vehicle/i });
    this.addAnotherDriverButton = page.getByRole('button', { name: /add another driver/i });
    this.firstName = page.getByLabel('First Name');
    this.lastName = page.getByLabel('Last Name');
    this.dateOfBirth = page.getByLabel('Date of Birth');
    this.addVehicleButton = page.getByRole('button', { name: /Add Vehicle/i });
    this.addVehiclesAndDriversButton = page.getByText(' Add vehicles and drivers ');
    this.currentlyInsuredYes = page.locator(
      "//label[text()=' Are you currently insured? ']/following::span[text()='Yes'] ",
    );
    this.currentlyInsuredNo = page.locator(
      "//label[text()=' Are you currently insured? ']/following::span[text()='No'] ",
    );
    this.currentInsuranceCompany = page.getByLabel('Current Insurance Company');
    this.currentInjuryLimits = page.locator('#mat-select-0');
    this.policyExpirationDate = page.getByLabel('Policy Expiration Date');
    this.howLongInsured = page.getByLabel('How Long Insured');
    this.currentlyInsuredYes = page.locator(
      "//label[text()=' Are you currently insured? ']/following::span[text()='Yes'] ",
    );
    this.currentlyInsuredNo = page.locator(
      "//label[text()=' Are you currently insured? ']/following::span[text()='No'] ",
    );
    this.currentInsuranceCompany = page.getByLabel('Current insurance company');
    this.currentInjuryLimits = page.locator('[id=mat-select-value-4]');
    this.policyExpirationDate = page.locator('[class*="mat-datepicker-input"]').last();
    this.howLongInsured = page.locator('[id=mat-select-value-5]');
    this.injuryLimitsDropdown = page.locator(" [class='mat-mdc-select-arrow']").first();
    this.howLongInsuredDropdown = page.locator(" [class='mat-mdc-select-arrow']").last();
    this.whoShouldWeInsureHeader = page.getByText(' Who should we insure? ');
    this.doYouHaveMoreVehicles = page.getByText('Do you have more vehicles?');
    this.cancelButton = page.getByText('Cancel').last();
  }

  public async isPresent(): Promise<boolean> {
    try {
      await this.pageHeading.waitFor({ state: 'visible', timeout: 15_000 });
      return true;
    } catch {
      return false;
    }
  }

  public async enterHeresWhatWeFoundPage(data: HeresWhatWeFoundPageData): Promise<void> {
    //await this.page.waitForURL(/vehicles-drivers-info/);
    const shouldAddVehiclesAndDrivers = await this.whoShouldWeInsureHeader
      .waitFor({ state: 'visible', timeout: 50_000 })
      .then(() => true)
      .catch(() => false);
    if (shouldAddVehiclesAndDrivers) {
      await this.click(this.addVehiclesAndDriversButton);
    }

    await this.vehicleDetails(data.vehicles);
    await this.page.waitForTimeout(1000);
    if (await this.doYouHaveMoreVehicles.isVisible()) {
      await this.click(this.cancelButton);
    }
    await this.driverDetails(data.drivers);
    await proceedToNextPage(this.continueButton, this.page);
  }

  private async vehicleDetails(vehicles: readonly HeresWhatWeFoundVehicleData[]): Promise<void> {
    for (const vehicle of vehicles) {
      if (vehicle.action === 'Edit') {
        await this.click(this.editVehicleLink(vehicle.position - 1));
      } else if (vehicle.action === 'Add' && (await this.addAnotherVehicleButton.isVisible())) {
        await this.click(this.addAnotherVehicleButton);
      }
      await this.fillIfDefined(this.vin, vehicle.vin);
      await this.selectVehicleUsage(vehicle.usedFor);
      await this.setRideshare(vehicle.rideOrShare);
      await this.selectVehicleOwnership(vehicle.ownership);
      await this.setParkingLocation(vehicle.parkedAtCurrentAddress);
      await this.fillIfDefined(this.garageAddress, vehicle.garageAddress);
      await this.fillIfDefined(this.city, vehicle.city);
      await this.fillIfDefined(this.zipCode, vehicle.zipCode);

      if (vehicle.action === 'Edit') {
        await this.saveDetail();
      } else {
        await this.click(this.addVehicleButton);
      }
    }
  }

  private async driverDetails(drivers: readonly HeresWhatWeFoundDriverData[]): Promise<void> {
    for (const driver of drivers) {
      if (driver.action === 'Edit') {
        await this.page.locator(`[class*='driver-checkbox mat-accent']`).click();
        await this.selectDriverCheckbox(driver.position - 1);
        await this.click(this.editDriverLink(driver.position - 1));
      } else {
        await this.click(this.addAnotherDriverButton);
      }

      await this.fillIfDefined(this.firstName, driver.firstName);
      await this.fillIfDefined(this.lastName, driver.lastName);
      await this.fillIfDefined(this.dateOfBirth, driver.dateOfBirth);
      await this.selectDriverGender(driver.gender);
      await this.setDriverLicenseIssuedByUs(driver.licenseIssuedByUs);
      await this.areYouCurrentlyInsured(driver);
      await this.setDriverLicenseIssuedByUs(driver.licenseIssuedByUs);
      await this.saveDetail();
    }
  }
  public async areYouCurrentlyInsured(driver: HeresWhatWeFoundDriverData): Promise<void> {
    if (!driver.currentlyInsured) return;
    if (/^(yes|true)$/i.test(driver.currentlyInsured)) {
      await this.click(this.currentlyInsuredYes);
      if (await this.whoShouldWeInsureHeader.isVisible()) {
        await this.fillIfDefined(this.currentInsuranceCompany, driver.insuranceCompany);
        await this.page.getByText(driver.insuranceCompany ?? '', { exact: true }).click();
        await this.page.keyboard.press('Tab');
        await this.injuryLimitsDropdown.click();
        await this.page.getByRole('option', { name: driver.injuryLimits ?? '', exact: true }).click();
        await this.page.keyboard.press('Tab');
        const policyExpirationDate = driver.policyExpirationDate
          ? normalizeDate(driver.policyExpirationDate)
          : undefined;
        await this.policyExpirationDate.pressSequentially(policyExpirationDate ?? '');
        await this.howLongInsuredDropdown.click();
        await this.page.getByRole('option', { name: driver.howLongInsured ?? '', exact: true }).click();
      }

      return;
    }

    if (/^(no|false)$/i.test(driver.currentlyInsured)) {
      await this.click(this.currentlyInsuredNo);
      return;
    }

    throw new Error(`Invalid Currently Insured value: "${driver.currentlyInsured}"`);
  }

  private editVehicleLink(index: number): Locator {
    return this.page.getByText(' Edit vehicle ').nth(index);
  }

  public selectvehicleCheckbox(index: number): Locator {
    return this.page.locator(`//*[contains(@aria-label, "Select vehicle ${index}:")]`);
  }
  private editDriverLink(index: number): Locator {
    return this.page.getByText(' Edit driver  ').nth(index);
  }

  private async fillIfDefined(locator: Locator, value: string | undefined): Promise<void> {
    if (value !== undefined) await this.fill(locator, value);
  }

  private async selectVehicleUsage(value: string | undefined): Promise<void> {
    if (!value) return;
    if (/^personal$/i.test(value)) return this.click(this.usedForPersonal);
    if (/^business$/i.test(value)) return this.click(this.usedForBusiness);
    throw new Error(`Unsupported vehicle usage: ${value}.`);
  }

  private async setRideshare(value: string | undefined): Promise<void> {
    if (!value) return;
    if (/^(yes|true)$/i.test(value)) return this.rideshareorfoodDeliveryService.check();
    if (/^(no|false)$/i.test(value)) return this.rideshareorfoodDeliveryService.uncheck();
    throw new Error(`Unsupported rideshare value: ${value}.`);
  }

  private async selectVehicleOwnership(value: string | undefined): Promise<void> {
    if (!value) return;
    if (/^owned$/i.test(value)) return this.click(this.ownershipasOwned);
    if (/^leased$/i.test(value)) return this.click(this.ownershipasLeased);
    if (/^financed$/i.test(value)) return this.click(this.ownershipasFinanced);
    throw new Error(`Unsupported vehicle ownership: ${value}.`);
  }

  private async setParkingLocation(value: boolean | undefined): Promise<void> {
    if (value === undefined) return;
    const name = value ? /current address|primary address/i : /other location/i;
    await this.click(this.page.getByRole('radio', { name }).first());
  }

  private async selectDriverGender(value: string | undefined): Promise<void> {
    if (!value) return;
    await this.page.getByText(value, { exact: true }).click();
  }
  private async selectDriverCheckbox(index: number): Promise<void> {
    this.page.getByText('Select driver ').nth(index);
  }
  private async setDriverLicenseIssuedByUs(value: boolean | undefined): Promise<void> {
    if (value === undefined) return;
    const name = value ? /^yes$/i : /^no$/i;
    const licenseissuedByUS = await this.page.getByLabel(
      'Is this driver’s license issued by a U.S. state, U.S. territory, or Canadian province?',
    );
    await licenseissuedByUS.getByRole('radio', { name }).click();
    //await this.click(this.page.getByRole('radio', { name }).last());
  }

  private async saveDetail(): Promise<void> {
    await this.click(this.savechangesButton);
    await this.savechangesButton.waitFor({ state: 'hidden', timeout: 10_000 }).catch(() => undefined);
  }
}
