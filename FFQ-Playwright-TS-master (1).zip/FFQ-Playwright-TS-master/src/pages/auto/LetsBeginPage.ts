import { expect, type Locator, type Page } from '@playwright/test';
import { normalizeDate, proceedToNextPage } from '../../../utils/CommonUtils.js';
import { BasePage } from '../../core/BasePage.js';
import type { LetsBeginPageData } from '../../data/auto/AutoPageDataService.js';

export class LetsBeginPage extends BasePage {
  private readonly firstName: Locator;
  private readonly lastName: Locator;
  private readonly dateOfBirth: Locator;
  private readonly pageHeading: Locator;
  private readonly continueButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.firstName = page.getByRole('textbox', {
      name: 'Farmers Fast Quote - Auto Insurance - Personal Info First name',
    });
    this.lastName = page.getByRole('textbox', { name: 'Last name' });
    this.dateOfBirth = page.getByRole('textbox', { name: 'Date of birth' });
    this.pageHeading = page.getByRole('heading', { name: /let'?s begin/i });
    this.continueButton = page
      .locator('[data-tui-tracking-id="personal-info__continue-button-cta"]')
      .or(page.getByRole('button', { name: /agree and submit|agree|continue/i }))
      .first();
  }

  public async enterLetsBeginPage(letsBeginData: LetsBeginPageData): Promise<void> {
    await expect(this.pageHeading).toBeVisible();
    await this.fill(this.firstName, letsBeginData.firstName);
    await this.fill(this.lastName, letsBeginData.lastName);
    await this.fill(this.dateOfBirth, normalizeDate(letsBeginData.dateOfBirth));
    await proceedToNextPage(this.continueButton, this.page);
  }
}
