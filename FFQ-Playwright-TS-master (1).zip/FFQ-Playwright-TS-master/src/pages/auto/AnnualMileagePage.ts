import { type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import { isOnpage } from '../../../utils/CommonUtils.js';
import { AnnualMileagePageData } from '../../data/auto/AutoPageDataService.js';

export class AnnualMileagePage extends BasePage {
  private readonly annualMileage: Locator;
  private readonly continueButton: Locator;
  private readonly header: Locator;

  public constructor(page: Page) {
    super(page);
    this.annualMileage = page.locator('[formcontrolname="annualMileage"]');
    this.continueButton = page.getByText('Continue');
    this.header = page.getByRole('heading', { name: 'Annual mileage' });
  }

  public async enterAnnualMileage(annualMileageData: AnnualMileagePageData): Promise<void> {
    const isAnnualMileagePageDisplayed = await isOnpage(this.header);
    if (isAnnualMileagePageDisplayed) {
      await this.specialFill(this.annualMileage, annualMileageData.annualMileage);
      await this.continueButton.click();
    }
  }
}
