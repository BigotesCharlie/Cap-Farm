import { type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import { isVisible, clickWithIntervals } from '../../../utils/CommonUtils.js';
import type { AddressPageData } from '../../data/auto/AutoPageDataService.js';

export class AddressPage extends BasePage {
  private readonly address: Locator;
  private readonly city: Locator;
  private readonly zipCode: Locator;
  private readonly email: Locator;
  private readonly mobilePhone: Locator;
  private readonly pageHeading: Locator;
  private readonly agreeAndSubmitButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.address = page
      .getByRole('combobox', { name: /home address|address/i })
      .or(page.getByRole('textbox', { name: /home address|address/i }))
      .first();
    this.city = page.getByRole('textbox', { name: /city/i }).first();
    this.zipCode = page.getByRole('textbox', { name: /zipCode|zip|postal/i }).first();
    this.email = page
      .locator(
        'input[type="email"]:visible, input[formcontrolname="email"]:visible, input[aria-label*="Email"]:visible',
      )
      .first();
    this.mobilePhone = page
      .locator(
        'input[type="tel"]:visible, input[formcontrolname="phoneNumber"]:visible, input[aria-label*="phone"]:visible',
      )
      .first();
    this.pageHeading = page.getByRole('heading', { name: /^hi,/i }).first();
    this.agreeAndSubmitButton = this.page.getByRole('button', { name: 'Agree and submit' });
  }

  public async isPresent(): Promise<boolean> {
    return isVisible(this.pageHeading);
  }

  public async enterAddressPage(addressData: AddressPageData): Promise<void> {
    await this.fill(this.address, addressData.residentAddress1);
    await this.fill(this.city, addressData.city);
    await this.fill(this.zipCode, addressData.zipCode);
    await this.specialFill(this.email, addressData.email);
    if (addressData.phoneNumber) {
      const normalizedPhone = addressData.phoneNumber.replace(/\D/g, '').slice(0, 10);
      await this.mobilePhone.clear();
      await this.pressSequentially(this.mobilePhone, normalizedPhone);
    }
    await clickWithIntervals(this.agreeAndSubmitButton, 3, 2000);
  }
}
