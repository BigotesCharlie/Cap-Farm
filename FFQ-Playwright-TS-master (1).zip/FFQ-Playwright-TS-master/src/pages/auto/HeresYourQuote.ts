import { type Locator, type Page, expect } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import { splitAndTrim } from '../../../utils/CommonUtils.js';
import type { HeresYourQuotePageData } from '../../data/auto/AutoPageDataService.js';

export class HeresYourQuotePage extends BasePage {
  private readonly editLiablityCoverage: Locator;
  private readonly toggleSwitch: Locator;
  private readonly recalculateButton: Locator;
  private readonly continueButton: Locator;
  private readonly continueWithSignalDiscountButton: Locator;
  private readonly acceptSignalDiscount: Locator;

  constructor(page: Page) {
    super(page);
    this.editLiablityCoverage = page.getByLabel('Edit liability coverage').last();
    this.toggleSwitch = page.locator("[class*='mat-mdc-dialog-component-host']").getByRole('switch');
    this.recalculateButton = page.getByRole('button', { name: 'Recalculate' });
    this.continueButton = page.getByRole('button', { name: 'Continue' });
    this.continueWithSignalDiscountButton = page.getByRole('heading', { name: 'Continue with Signal discount?' });
    this.acceptSignalDiscount = page.getByRole('button', { name: ' Yes, continue ' });
  }
  public async enterHeresYourQuotePage(reviewQuote: HeresYourQuotePageData): Promise<void> {
    await this.editLiablityCoverage.click({ timeout: 60000 });

    await this.uncheckCoverage();
    await this.selectCoverages(reviewQuote);
    await this.continueButton.scrollIntoViewIfNeeded();
    await this.page.locator('.tui-spinner-app-background').waitFor({ state: 'hidden', timeout: 60000 });
    await this.continueButton.click();
    if (await this.continueWithSignalDiscountButton.isVisible()) {
      await this.acceptSignalDiscount.click();
    }
  }

  public async uncheckCoverage(): Promise<void> {
    await expect(this.toggleSwitch.first()).toBeVisible({ timeout: 60000 });
    const switchCount = await this.toggleSwitch.count();

    for (let index = switchCount - 1; index >= 0; index--) {
      const toggle = this.toggleSwitch.nth(index);
      if ((await toggle.getAttribute('aria-checked')) === 'true') {
        await toggle.click();
        await expect(toggle).toHaveAttribute('aria-checked', 'false');
      }
    }
  }

  public async selectCoverages(reviewQuote: HeresYourQuotePageData): Promise<void> {
    for (const coverage of splitAndTrim(reviewQuote.selectedLiabilityCoverages)) {
      if (coverage !== 'NA') {
        await this.page.locator(`//h3[normalize-space()='${coverage}']`).click();
      }
    }

    const coverageFields = [
      { label: 'select Bodily Injury (required)', value: reviewQuote.bodilyInjuryCoverage },
      { label: 'select Property Damage Liability (required)', value: reviewQuote.propertyDamageLiabilityCoverage },
      { label: 'select UM/UIM Bodily Injury', value: reviewQuote.umUimBodilyInjuryCoverage },
      { label: 'select UM/UIM Property Damage', value: reviewQuote.umUimPropertyDamageCoverage },
      { label: 'select Medical', value: reviewQuote.medicalCoverage },
      {
        label: 'select Accidental Death or Disabling Injury',
        value: reviewQuote.accidentalDeathOrDisablingInjuryCoverage,
      },
      { label: 'select Personal Injury Protection', value: reviewQuote.personalInjuryProtectionCoverage },
    ];

    for (const { label, value } of coverageFields) {
      const coverageValue = value?.trim();

      if (!coverageValue || coverageValue.toUpperCase() === 'NA') {
        continue;
      }

      const formattedCoverageValue = coverageValue
        ?.split('/')
        .map((v) => {
          const cleaned = v.replace(/\$|,/g, '').trim();
          return /^\d+$/.test(cleaned) ? `$${Number(cleaned).toLocaleString()}` : v.trim();
        })
        .join('/');

      console.log(`Selecting coverage for label: ${label} with value: ${coverageValue}`);
      await this.page
        .getByRole('radiogroup', { name: label })
        .getByRole('radio', { name: formattedCoverageValue })
        .check();
    }
    await this.recalculateButton.click();
  }
}
