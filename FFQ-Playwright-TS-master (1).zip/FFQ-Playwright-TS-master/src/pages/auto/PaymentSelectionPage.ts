import { FrameLocator, type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import type { PaymentSelectionPageData } from '../../data/auto/AutoPageDataService.js';
import type { LetsBeginPageData } from '../../data/auto/AutoPageDataService.js';
import { expect } from '@playwright/test';

type PaymentSelectionPageInput = PaymentSelectionPageData & {
  readonly updatePaymentMethod?: string;
};

export class PaymentSelectionPage extends BasePage {
  private readonly header: Locator;
  private readonly routingNumber: Locator;
  private readonly accountNumber: Locator;
  private readonly confirmAccountNumber: Locator;
  private readonly cardNumber: Locator;
  private readonly expirationDate: Locator;
  private readonly cvv: Locator;
  private readonly billingZipcode: Locator;
  private readonly addButton: Locator;
  private readonly accountHolderName: Locator;
  private readonly changePaymentMethodLink: Locator;
  private readonly paymentusManageSidebar!: FrameLocator;
  private readonly completePurchaseButton: Locator;
  private readonly termPrice: Locator;
  private readonly validateThankYouPageHeader: Locator;
  private readonly spinnerIcon: Locator;

  public constructor(page: Page) {
    super(page);
    this.header = page.getByRole('heading', { name: /payment/i }).first();
    this.paymentusManageSidebar = page.frameLocator('iframe[title="Paymentus Manage Payments"]');
    this.routingNumber = this.paymentusManageSidebar.getByLabel('Bank Routing Number (9 digits)');
    this.accountNumber = this.paymentusManageSidebar.getByLabel('Account Number', { exact: true });
    this.confirmAccountNumber = this.paymentusManageSidebar.getByLabel('Confirm Account Number', { exact: true });
    this.cardNumber = this.paymentusManageSidebar.getByLabel('Card Number');
    this.expirationDate = this.paymentusManageSidebar.getByLabel('Expiration Date');
    this.cvv = this.paymentusManageSidebar.getByLabel('Card Security Code (CVV)');
    this.billingZipcode = this.paymentusManageSidebar.getByLabel('Billing ZIP Code');
    this.addButton = this.paymentusManageSidebar.locator('button[name="submitBtn"]');
    this.accountHolderName = this.paymentusManageSidebar.locator("//label/following::input[@id='accountHolderField']");
    this.changePaymentMethodLink = this.page.locator("xpath=//a[contains(.,'Change')]").first();

    this.completePurchaseButton = page.locator("[class*='-autopay-purchase-btn']");
    this.termPrice = page.locator("//span[@class='tui-h4']").last();
    this.validateThankYouPageHeader = page.getByRole('heading', {
      name: 'Thank you for joining us as a policyholder!',
    });
    this.spinnerIcon = page.locator("div[class='mdc-circular-progress__spinner-layer']");
  }
  public async enterPaymentSelectionPage(
    paymentsData: PaymentSelectionPageInput,
    letsBeginData: LetsBeginPageData,
  ): Promise<void> {
    await this.selectPaymentMode(paymentsData, letsBeginData);
    await this.addPaymentMethod();
    await this.changePaymentMethod(paymentsData, letsBeginData);
    await this.completePurchase();
  }

  public async selectBankPayment(
    paymentsData: PaymentSelectionPageData,
    letsBeginData: LetsBeginPageData,
  ): Promise<void> {
    await this.accountHolderName.waitFor({ state: 'visible', timeout: 60000 });
    const accountHolderName = await this.accountHolderName.inputValue();
    await expect(accountHolderName).toContain(`${letsBeginData.firstName} ${letsBeginData.lastName}`);
    await this.page.keyboard.press('Tab');
    await this.routingNumber.fill(paymentsData.routingNumber ?? '');
    await this.accountNumber.fill(paymentsData.accountNumber ?? '');
    await this.confirmAccountNumber.fill(paymentsData.confirmAccountNumber ?? '');
    await this.page.keyboard.press('Tab');
  }

  public async selectCardPayment(
    paymentsData: PaymentSelectionPageData,
    letsBeginData: LetsBeginPageData,
  ): Promise<void> {
    await this.page.keyboard.press('Tab');
    await this.cardNumber.fill(paymentsData.cardNumber ?? '');
    console.log(`filling expiration date: + ${paymentsData.expirationDate}`);
    await this.expirationDate.fill(paymentsData.expirationDate ?? '');
    await this.cvv.fill(paymentsData.cvv ?? '');
    await this.billingZipcode.fill(paymentsData.billingZipcode ?? '');
  }

  public async validateAddingBankAccountResponse(): Promise<void> {
    await this.addPaymentMethod();
    await this.completePurchase();
  }

  private async addPaymentMethod(): Promise<void> {
    await this.addButton.waitFor({ state: 'visible', timeout: 60000 });
    await this.addButton.evaluate((btn: HTMLButtonElement) => btn.click());
    await this.termPrice.waitFor({ state: 'visible', timeout: 60000 });
    await this.spinnerIcon.waitFor({ state: 'hidden', timeout: 300000 });
  }

  private async completePurchase(): Promise<void> {
    await this.completePurchaseButton.click({ trial: true });
    await this.completePurchaseButton.click();
    await this.spinnerIcon.waitFor({ state: 'hidden', timeout: 300000 });
    await expect(this.validateThankYouPageHeader).toBeVisible({ timeout: 300000 });
  }

  public async validateApplicantName(letsBeginData: LetsBeginPageData): Promise<void> {
    await this.accountHolderName.waitFor({ state: 'visible', timeout: 60000 });
    const accountHolderName = await this.accountHolderName.inputValue();
    await expect(accountHolderName).toContain(`${letsBeginData.firstName} ${letsBeginData.lastName}`);
    await this.page.keyboard.press('Tab');
  }

  public async selectPaymentMode(
    paymentsData: PaymentSelectionPageInput,
    letsBeginData: LetsBeginPageData,
    paymentMode: string | undefined = paymentsData.paymentMode,
  ): Promise<void> {
    if (!paymentMode) throw new Error('PaymentMode is required to select a payment mode.');
    await this.page.getByRole('radio', { name: paymentMode }).click();
    await this.page.getByLabel(paymentsData.preferredPaymentMethod ?? '').click();
    switch (paymentsData.preferredPaymentMethod) {
      case 'Bank payment':
        await this.selectBankPayment(paymentsData, letsBeginData);
        break;
      case 'Card':
        await this.selectCardPayment(paymentsData, letsBeginData);
        break;
      default:
        throw new Error(`Unsupported payment method: ${paymentsData.preferredPaymentMethod ?? '(missing)'}.`);
    }
  }

  public async changePaymentMethod(
    paymentsData: PaymentSelectionPageInput,
    letsBeginData: LetsBeginPageData,
  ): Promise<void> {
    const updatePaymentMethod = paymentsData.updatePaymentMethod?.trim();
    if (!updatePaymentMethod || updatePaymentMethod === paymentsData.paymentMode?.trim()) return;

    await this.changePaymentMethodLink.waitFor({ state: 'visible', timeout: 60000 });
    await this.changePaymentMethodLink.click();
    await this.selectPaymentMode(paymentsData, letsBeginData, updatePaymentMethod);
    await this.addPaymentMethod();
  }
}
