import { promises as fs } from 'node:fs';
import { test as base, expect } from '@playwright/test';
import { env } from '../config/env.js';
import { applyGlobalBrowserZoom, captureAutoDebuggingEvidence, collectPageSummary } from '../core/BrowserUi.js';
import { RecoveryGuard } from '../core/RecoveryGuard.js';
import { logger } from '../../utils/logger.js';
import { writeRuntimeEvidence } from '../../reports/custom-report/EnvironmentExecutionReport.js';

type AutoFixtures = {
  recoveryGuard: RecoveryGuard;
};

export const test = base.extend<AutoFixtures>({
  recoveryGuard: [
    async ({ page }, use, testInfo) => {
      const guard = new RecoveryGuard(page, testInfo);
      guard.start();
      await use(guard);
      await guard.stop();
    },
    { auto: true },
  ],
  page: async ({ page }, use) => {
    await applyGlobalBrowserZoom(page, 0.75);
    await use(page);
  },
});

test.afterEach(async ({ page }, testInfo) => {
  const annotations = testInfo.annotations.map((annotation) => ({
    type: annotation.type,
    description: annotation.description ?? '',
  }));
  const pageClosed = page.isClosed();
  const pageSummary = pageClosed
    ? undefined
    : await collectPageSummary(page).then((summary) => ({
        url: summary.url,
        title: summary.title,
        heading: summary.heading,
        pageClassification: summary.pageClassification,
        validationMessages: summary.validationMessages,
      }));

  await writeRuntimeEvidence({
    testId: testInfo.testId,
    retry: testInfo.retry,
    title: testInfo.title,
    status: testInfo.status ?? 'unknown',
    expectedStatus: testInfo.expectedStatus,
    pageClosed,
    annotations,
    capturedAt: new Date().toISOString(),
    ...(pageSummary ? { pageSummary } : {}),
  });

  if (!pageClosed) {
    await fs.writeFile(testInfo.outputPath('final-dom.html'), await page.content(), 'utf8');
    await captureAutoDebuggingEvidence(page, testInfo, 'after-each');
  }

  if (env.FFQ_KEEP_BROWSER_OPEN && testInfo.status !== testInfo.expectedStatus) {
    logger.info('DEBUG HOLD: Browser is intentionally paused at failure state.');
    await page.pause();
  }
});

export { expect };
