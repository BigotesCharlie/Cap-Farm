import type { Page, TestInfo } from '@playwright/test';
import { AutoTestCaseRegistry, type AutoTestCase } from '../config/testCaseRegistry.js';
import { env } from '../config/env.js';
import { AutoPageDataService } from '../data/auto/AutoPageDataService.js';
import { test as baseTest, expect } from './test.js';

export interface AutoLobFixtures {
  readonly testCase: AutoTestCase;
  readonly autoData: AutoPageDataService;
}

type AutoTestBody = (
  fixtures: { readonly page: Page; readonly autoData: AutoPageDataService; readonly testCase: AutoTestCase },
  testInfo: TestInfo,
) => Promise<void>;

const testCaseIdPattern = /^[A-Za-z0-9][A-Za-z0-9._-]*$/;

export function autoTestCase(testCaseId: string, tags: string | readonly string[]) {
  if (!testCaseIdPattern.test(testCaseId)) {
    throw new Error(`Invalid Auto testCaseId: ${testCaseId}`);
  }
  return {
    tag: typeof tags === 'string' ? tags : [...tags],
    annotation: {
      type: 'testCaseId',
      description: testCaseId,
    },
  };
}

interface AutoTestRegistration {
  readonly testCase: AutoTestCase;
  readonly state?: string;
}

const registrations: readonly AutoTestRegistration[] = await Promise.all(
  AutoTestCaseRegistry.load()
    .getEnabledCases(env.TEST_CASE_ID)
    .filter((testCase) => !env.TEST_TAG || testCase.tags.includes(env.TEST_TAG))
    .map(async (testCase) => {
      const availableStates = await new AutoPageDataService(testCase).getAddressStates();
      const selectedStates = env.TEST_STATE
        ? [env.TEST_STATE]
        : testCase.state === 'all'
          ? [availableStates[Math.floor(Math.random() * availableStates.length)]!]
          : testCase.state;
      const unavailableStates = selectedStates.filter(
        (state) => !availableStates.some((availableState) => availableState.toUpperCase() === state.toUpperCase()),
      );
      if (unavailableStates.length > 0) {
        throw new Error(
          `Auto test case ${testCase.testCaseId} requests state(s) ${unavailableStates.join(', ')} not defined by its AddressInfoID in Excel.`,
        );
      }
      if (selectedStates.length === 0) {
        throw new Error(`Auto test case ${testCase.testCaseId} has no states defined by its AddressInfoID in Excel.`);
      }
      if (testCase.state === 'all' && !env.TEST_STATE) {
        return [{ testCase }];
      }
      return selectedStates.map((state) => ({ testCase, state: state.toUpperCase() }));
    }),
).then((cases) => cases.flat());

function declaredTestCaseId(testInfo: TestInfo): string {
  const values = testInfo.annotations
    .filter((annotation) => annotation.type === 'testCaseId')
    .map((annotation) => annotation.description?.trim() ?? '')
    .filter(Boolean);
  if (values.length !== 1) {
    throw new Error(`Modern Auto test "${testInfo.title}" must declare exactly one testCaseId annotation.`);
  }
  return values[0]!;
}

function declaredTestState(testInfo: TestInfo): string | undefined {
  const values = testInfo.annotations
    .filter((annotation) => annotation.type === 'testCaseState')
    .map((annotation) => annotation.description?.trim() ?? '')
    .filter(Boolean);
  if (values.length > 1) {
    throw new Error(`Modern Auto test "${testInfo.title}" must not declare multiple testCaseState annotations.`);
  }
  return values[0];
}

const autoTest = baseTest.extend<AutoLobFixtures>({
  testCase: async ({}, use, testInfo) => {
    const testCaseId = declaredTestCaseId(testInfo);
    if (env.TEST_CASE_ID && env.TEST_CASE_ID !== testCaseId) {
      throw new Error(`Selected TEST_CASE_ID ${env.TEST_CASE_ID} does not match declared testCaseId ${testCaseId}.`);
    }
    await use(AutoTestCaseRegistry.load().getEnabled(testCaseId));
  },
  autoData: async ({ testCase }, use, testInfo) => {
    const data = new AutoPageDataService(testCase);
    const declaredState = declaredTestState(testInfo);
    const availableStates = declaredState ? [] : await data.getAddressStates();
    const selectedState = declaredState ?? availableStates[Math.floor(Math.random() * availableStates.length)];
    if (!selectedState) {
      throw new Error(`Auto test case ${testCase.testCaseId} has no state available for execution.`);
    }
    testInfo.annotations.push({ type: 'testCaseState', description: selectedState });
    await use(new AutoPageDataService(testCase, undefined, selectedState));
  },
});

export function test(title: string, body: AutoTestBody): void {
  for (const { testCase, state } of registrations) {
    const stateLabel = state ? `[state:${state}]` : '[state:random]';
    autoTest(
      `[case:${testCase.testCaseId}]${stateLabel} ${title} - ${testCase.scenario}`,
      {
        tag: testCase.tags,
        annotation: state
          ? [
              { type: 'testCaseId', description: testCase.testCaseId },
              { type: 'testCaseState', description: state },
            ]
          : [{ type: 'testCaseId', description: testCase.testCaseId }],
      },
      body,
    );
  }
}

export { expect };
