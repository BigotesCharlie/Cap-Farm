# FFQ Playwright TypeScript

Playwright and TypeScript automation for Farmers Fast Quote (FFQ). This branch contains the maintained TypeScript framework, its modern Auto test path, and migration infrastructure that executes legacy scenarios through explicit behavioral handlers.

A migrated scenario is not complete merely because it compiles or opens FFQ. It must execute its intended business flow and pass its functional assertions with runtime evidence.

## Quick Start

### Prerequisites

- Node.js 22.x. `.nvmrc` is the repository source of truth.
- npm, included with Node.js.
- Access to a valid FFQ environment.
- Playwright browsers installed locally.

```powershell
# Optional when nvm is available
nvm use

# Install exact versions from package-lock.json and set up Husky hooks.
npm ci

# Install the default browser used by the Chromium project.
npx playwright install chromium

# Create local configuration. Never commit this file.
Copy-Item .env.example .env

# Run the deterministic local/CI quality gate.
npm run verify
```

`npm run verify` checks formatting, linting, TypeScript, generated output, and Playwright test discovery. It does **not** execute browser scenarios; run a focused Playwright command when behavior changes.

## Configuration and Safety Gates

[src/config/env.ts](src/config/env.ts) validates configuration at startup with Zod. Start from [.env.example](.env.example); secrets belong in local environment configuration or CI secrets, never in Git.

| Variable                                                    | Purpose                                                                                 |
| ----------------------------------------------------------- | --------------------------------------------------------------------------------------- |
| `TEST_ENV`                                                  | Logical environment label. Defaults to `RA11`; supports `MA11` and `RA11`.              |
| `MA11_BASE_URL`, `RA11_BASE_URL`                            | Fast Quote URLs for each environment. The selected URL is shared by all tests.          |
| `HEADLESS`                                                  | Runs the browser without a visible window when `true`.                                  |
| `WORKERS`, `RETRIES`                                        | Test parallelism and retry limits.                                                      |
| `*_TIMEOUT_MS`                                              | Test, assertion, action, and navigation timeouts.                                       |
| `FFQ_DEBUG_VISUAL`                                          | Uses visual-debug settings: headed browser, one worker, and no retries.                 |
| `FFQ_KEEP_BROWSER_OPEN`                                     | Pauses on an unexpected failure for local investigation.                                |
| `AUTO_PROVIDER_SEED`, `ACE_HOME_PROVIDER_SEED`              | Makes data-provider selection reproducible.                                             |
| `FFQ_ENVIRONMENT_BASELINE`, `FFQ_ENVIRONMENT_BASELINE_MODE` | Classifies recovery states as environment blockers rather than attempting recovery.     |
| `EXECUTE_MIGRATED_TESTS`                                    | First authorization gate for migrated-scenario execution.                               |
| `MIGRATION_ALLOW_UNCERTIFIED_CERTIFICATION_RUN`             | Permits controlled execution of an implemented but uncertified scenario.                |
| `MIGRATION_CERTIFICATION_ALLOWLIST`                         | Comma-separated exact legacy IDs, or `*`, permitted for a controlled certification run. |

Migrated scenarios fail closed: they require an immutable contract, a registered behavioral handler, `EXECUTE_MIGRATED_TESTS=true`, and, when not runtime-certified, certification authorization and allowlisting. This prevents a partial flow from reporting a false pass.

Configure both URLs in local `.env` from [.env.example](.env.example). Jenkins should provide the selected environment's URL and `TEST_ENV`. In GitHub Actions, configure `RA11_BASE_URL` and `MA11_BASE_URL` secrets; manually dispatched runs let you choose the environment, while push and pull-request runs default to RA11. The existing `FFQ_BASE_URL` secret remains a fallback for `RA11_BASE_URL`.

## Framework Architecture

```text
Modern Auto test                     Migrated legacy test
---------------                      --------------------
tests/Auto                           tests/legacy
  -> custom fixture                    -> executeMigratedScenario
  -> product flow                      -> immutable contract + handler registry
  -> page objects                      -> product handler and flow
  -> BrowserUi/BasePage                -> page objects
             \                          /
              -> Playwright page <-
                       |
              RecoveryGuard safe points
                       |
         checkpoints, evidence, custom reporter
```

### Test and Data Flow

```text
Excel workbook -> ExcelDataSource -> product provider -> typed applicant/model
     -> fixture or handler -> flow -> page object -> Playwright locator/action
```

- **Fixtures** in `src/fixtures/` extend Playwright with an automatic `RecoveryGuard`, global browser zoom, final-DOM capture, runtime evidence, and failure diagnostics.
- **Flows** in `src/flows/` orchestrate multi-page business journeys. They coordinate transitions and page contracts; they do not own low-level selectors.
- **Page objects** in `src/pages/` own locators, UI interaction, and page-specific assertions.
- **Data providers** in `src/data/` read Excel workbooks from `data/legacy/`, filter/select test data, and build typed models from `src/models/`.
- **Migration** components in `src/migration/` map immutable legacy metadata to registered handlers and attach registry/certification metadata to tests.
- **Reporting** in `src/reporting/` writes runtime evidence and produces execution records with a classified result and root cause.

### Recovery, Diagnostics, and Reporting

`RecoveryGuard` is serialized. It does not poll in the background or manipulate a Playwright page concurrently. A test or flow calls `executeWithRecovery`, `inspectRecovery`, or `waitForStateWithRecovery` at a safe point.

The guard recognizes `KNOCKOUT`, `INCONVENIENCE`, and `TRY_AGAIN`. At detection it captures a DOM checkpoint and recovery evidence. It either performs the bounded recovery action or raises `EnvironmentBaselineBlockedError` when baseline mode is enabled. `RECOVERY_MAX_ATTEMPTS` limits recovery.

The custom reporter combines Playwright results, runtime evidence, annotations, and migration inventory into an execution record. Typical classifications include `PASS`, `BLOCKED`, `MISSING_HANDLER`, `MISSING_FIXTURE`, `CONFIGURATION_ERROR`, `TIMEOUT`, `NETWORK_ERROR`, `VALIDATION_ERROR`, and `TEST_AUTOMATION_ERROR`.

## Repository Structure

```text
config/                  Test-case configuration
data/legacy/             Excel workbooks used by product data providers
migration/               Migration audits, contracts, reports, and utility scripts
scripts/                 Repository automation and validation scripts
src/
  commonUtils/           Shared product-support utilities
  config/                Validated environment and test-case registry
  core/                  Browser utilities, BasePage, checkpoints, recovery, soft assertions
  data/                  Excel source and product data providers
  fixtures/              Custom Playwright fixtures and lifecycle hooks
  flows/                 Auto and AceHome business-flow orchestration
  migration/             Executor, contracts, handler registry, and behavioral handlers
  models/                Typed product test-data models
  pages/                 Auto, AceHome, and legacy page objects
  reporting/             Runtime evidence and custom Playwright reporter
tests/
  Auto/                  Modern Auto tests, executed by the common Chromium project
  config/                Configuration tests
  data/                  Data tests
  legacy/                Migrated legacy scenario specifications
```

Use the owning layer when adding code:

- Add UI locators and single-page behavior to `src/pages/<product>/`.
- Add multi-page navigation or business sequencing to `src/flows/<product>/`.
- Add workbook parsing and data selection to `src/data/` or its providers.
- Add test-data types to `src/models/`.
- Add modern tests to the appropriate `tests/` product folder.
- Treat `tests/legacy/` and migration inventories as migration-owned; change them only through the relevant migration process.

Update this map whenever a top-level directory, product area, or cross-cutting framework component is introduced.

## Test Projects and Commands

The Playwright configuration defines:

| Project                          | Purpose                                        |
| -------------------------------- | ---------------------------------------------- |
| `chromium`                       | Desktop Chromium for all specs under `tests/`. |
| `firefox`, `webkit`, `edge`      | Desktop cross-browser coverage.                |
| `mobile-chrome`, `mobile-safari` | Pixel 7 and iPhone 15 device coverage.         |

### Quality and Maintenance

| Command                      | Description                                                                                  |
| ---------------------------- | -------------------------------------------------------------------------------------------- |
| `npm run verify`             | Format check, lint, typecheck, generated-JS guard, then Chromium test discovery.             |
| `npm run format`             | Format repository files with Prettier.                                                       |
| `npm run format:check`       | Verify formatting without editing files.                                                     |
| `npm run lint`               | Run ESLint.                                                                                  |
| `npm run lint:fix`           | Apply ESLint fixes where available.                                                          |
| `npm run typecheck`          | Run `tsc --noEmit`.                                                                          |
| `npm run check:generated-js` | Fail when generated JavaScript, declarations, or maps appear beside TypeScript source/tests. |
| `npm run clean`              | Remove local `test-results/` and `playwright-report/` output.                                |

### Playwright Execution

| Command               | Description                                                           |
| --------------------- | --------------------------------------------------------------------- |
| `npm test`            | Run every discovered test in Chromium, including Auto.                |
| `npm run test:all`    | Run the configured browser/device matrix; Auto runs in Chromium only. |
| `npm run test:headed` | Run Chromium with a visible browser.                                  |
| `npm run test:debug`  | Run Chromium using Playwright debug mode.                             |
| `npm run test:ui`     | Open Playwright UI mode.                                              |
| `npm run test:list`   | Discover Chromium tests without executing them.                       |
| `npm run report`      | Open the latest Playwright HTML report.                               |

Run a specific test directly:

```powershell
npx playwright test tests/Auto/AutoEndToEndTest.spec.ts --project=chromium
npx playwright test tests/Auto/AutoEndToEndTest.spec.ts --project=chromium --grep "case:AUTO-001"
```

`test:run` is the focused Auto runner. It requires an environment and exactly one selector; it uses the same `.env` values as ordinary Playwright runs:

```powershell
npm run test:run -- --env=RA11 --testCaseId=AUTO-001
npm run test:run -- --env=RA11 --tag=@smoke
npm run test:run -- --env=RA11 --testCaseId=TC01 --state=AZ
```

Auto cases use `"state": "all"` to randomly select one state referenced by that case's `AddressInfoID` in the workbook for each run. Use a list such as `"state": ["TX", "AZ"]` to run once for each listed workbook state. `--state=<code>` overrides the JSON selection for that run and must exist for each selected case.

### Migration Audits

| Command                                       | Description                              |
| --------------------------------------------- | ---------------------------------------- |
| `npm run audit:parity`                        | Check migration parity data.             |
| `npm run audit:skip-policy`                   | Audit migration skip-policy conformance. |
| `npm run migration:remove-runtime-skip-gates` | Maintain migration runtime skip gates.   |

## Libraries

| Library                                                   | Purpose                                                               |
| --------------------------------------------------------- | --------------------------------------------------------------------- |
| `@playwright/test`                                        | Browser automation, test runner, fixtures, assertions, and reporters. |
| `typescript`                                              | Strictly typed implementation with non-emitting type checks.          |
| `exceljs`                                                 | Excel test-data workbook access.                                      |
| `zod`                                                     | Runtime environment configuration validation.                         |
| `dotenv`                                                  | Local environment-file loading.                                       |
| `eslint`, `typescript-eslint`, `eslint-plugin-playwright` | TypeScript and Playwright static analysis.                            |
| `prettier`                                                | Repository formatting.                                                |
| `husky`, `lint-staged`                                    | Staged-file validation through Git hooks.                             |
| `@commitlint/*`                                           | Conventional Commit validation.                                       |

See [package.json](package.json) for exact pinned versions.

## Quality Tooling

- [tsconfig.json](tsconfig.json) uses strict TypeScript with NodeNext resolution and `noEmit`. Use `npm run typecheck`; do not generate JavaScript beside source.
- [eslint.config.mjs](eslint.config.mjs) applies TypeScript recommendations, Node globals, and Playwright rules to `tests/`. Skipped Playwright tests are errors. Legacy/generated migration and report surfaces are intentionally excluded from maintained-code linting.
- [.editorconfig](.editorconfig) standardizes UTF-8, LF, two-space indentation, and trailing-newline behavior. Prettier is the formatter used by `format` and `format:check`.
- `.gitignore` excludes Playwright output, coverage, traces, screenshots, recovery evidence, DOM checkpoints, temporary files, and generated TypeScript output.
- `check:generated-js` protects the TypeScript-only policy even when ignored output would otherwise stay unnoticed.

Husky is installed by `npm ci`/`npm install` through the `prepare` script:

- `.husky/pre-commit` invokes `lint-staged` against staged files.
- `.husky/commit-msg` invokes Commitlint.
- Both hooks use the local Node runtime, including a Windows Node fallback for Git GUI clients.

## Commit Convention

Commitlint uses `@commitlint/config-conventional`. Use:

```text
type(scope): concise imperative summary
```

Examples:

```text
feat(auto): add address page guard
fix(recovery): capture blocked baseline state
test(acehome): add review quote assertion
docs(readme): document migration gates
chore(tooling): enforce generated output check
ci(workflow): upload test artifacts
```

Common types: `feat`, `fix`, `docs`, `style`, `refactor`, `perf`, `test`, `build`, `ci`, and `chore`. Keep the title focused; use a blank line and a body for meaningful implementation detail.

## CI and Artifacts

[.github/workflows/playwright.yml](.github/workflows/playwright.yml) runs on pull requests, pushes to `main`, and manual dispatch. It uses the `.nvmrc` Node version, runs `npm ci`, installs Chromium, executes `npm run verify`, and uploads `playwright-report/` and `test-results/` for 14 days.

Browser artifacts include screenshots, traces, videos, final DOM capture, recovery evidence, runtime evidence, JUnit XML, and HTML reports. They are diagnostic output, not source. Keep them ignored locally and retrieve them from CI when investigating a failed build.

## Maintenance Rules

1. Keep selectors and single-page interactions in page objects; keep cross-page sequencing in flows.
2. Reuse `BasePage`, `BrowserUi`, fixtures, `RecoveryGuard`, data providers, and reporting helpers before adding parallel abstractions.
3. Validate configuration and business data at boundaries. Do not silently replace invalid test data.
4. Preserve migrated test intent and runtime gates. A scenario without a handler or certification must fail clearly rather than pass on a landing page.
5. Do not commit credentials, API keys, personal data, generated JavaScript, or Playwright artifacts.
6. Run `npm run verify` before a pull request and add focused browser-test evidence for changes that affect runtime behavior.
7. Update this README whenever setup, scripts, quality gates, project structure, CI behavior, or framework contracts change.

## Troubleshooting

| Symptom                       | Action                                                                                                     |
| ----------------------------- | ---------------------------------------------------------------------------------------------------------- |
| `Configure <env>_BASE_URL`    | Set `MA11_BASE_URL` or `RA11_BASE_URL` for the selected `TEST_ENV` in `.env` or CI.                        |
| Browser executable is missing | Run `npx playwright install chromium`.                                                                     |
| A migrated test is blocked    | Verify handler registration, `EXECUTE_MIGRATED_TESTS`, certification permission, and allowlist membership. |
| Commitlint rejects a commit   | Use `type(scope): summary`, such as `fix(auto): correct date input`.                                       |
| Pre-commit hook fails         | Run `npm run lint` and `npm run format:check`, then stage the fixes.                                       |
| Generated-JS check fails      | Remove generated output and use `npm run typecheck` rather than an emitting TypeScript command.            |
