import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { expect, test } from '@playwright/test';
import { AutoTestCaseRegistry } from '../../src/config/testCaseRegistry.js';

async function withRegistry(content: unknown, assertion: (filePath: string) => void): Promise<void> {
  const directory = await mkdtemp(join(tmpdir(), 'ffq-auto-registry-'));
  const filePath = join(directory, 'auto.test-cases.json');
  try {
    await writeFile(filePath, JSON.stringify(content), 'utf8');
    assertion(filePath);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
}

test.describe('Scenario validator', () => {
  test('resolves an enabled Auto test case', async () => {
    await withRegistry(
      {
        testCases: [
          {
            testCaseId: 'AUTO-100',
            LOB: 'auto',
            scenario: 'Reference quote',
            enabled: true,
            tags: ['@auto'],
            workbook: 'legacy/AutoTestData.xlsx',
          },
        ],
      },
      (filePath) => {
        const testCase = AutoTestCaseRegistry.load(filePath).getEnabled('AUTO-100');
        expect(testCase.testCaseId).toBe('AUTO-100');
        expect(testCase.LOB).toBe('auto');
        expect(testCase.state).toBe('all');
      },
    );
  });

  test('rejects duplicate IDs and paths outside the data directory', async () => {
    await withRegistry(
      {
        testCases: [
          {
            testCaseId: 'AUTO-100',
            LOB: 'auto',
            scenario: 'One',
            enabled: true,
            tags: ['@auto'],
            workbook: 'legacy/AutoTestData.xlsx',
          },
          {
            testCaseId: 'AUTO-100',
            LOB: 'auto',
            scenario: 'Two',
            enabled: true,
            tags: ['@auto'],
            workbook: '../outside.xlsx',
          },
        ],
      },
      (filePath) => {
        expect(() => AutoTestCaseRegistry.load(filePath)).toThrow('Duplicate Auto test-case ID');
      },
    );

    await withRegistry(
      {
        testCases: [
          {
            testCaseId: 'AUTO-101',
            LOB: 'auto',
            scenario: 'Outside root',
            enabled: true,
            tags: ['@auto'],
            workbook: '../outside.xlsx',
          },
        ],
      },
      (filePath) => {
        expect(() => AutoTestCaseRegistry.load(filePath)).toThrow('Workbook path must remain under the data directory');
      },
    );
  });

  test('rejects disabled test cases', async () => {
    await withRegistry(
      {
        testCases: [
          {
            testCaseId: 'AUTO-102',
            LOB: 'auto',
            scenario: 'Disabled',
            enabled: false,
            tags: ['@auto'],
            workbook: 'legacy/AutoTestData.xlsx',
          },
        ],
      },
      (filePath) => {
        expect(() => AutoTestCaseRegistry.load(filePath).getEnabled('AUTO-102')).toThrow('is disabled');
      },
    );
  });
});
