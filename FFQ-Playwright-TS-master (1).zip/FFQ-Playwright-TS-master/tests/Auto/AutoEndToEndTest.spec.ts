import { AceAutoNavigationFlow } from '../../src/flows/auto/AceAutoNavigationFlow.js';
import { test } from '../../src/fixtures/AutoTestFixture.js';

test('validate and bind auto quote', async ({ autoData, page }, testInfo) => {
  const flow = new AceAutoNavigationFlow(page, testInfo);
  await flow.validateAndBindAutoQuote(autoData);
});
