import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

const environmentPattern = /^[A-Za-z][A-Za-z0-9_-]{0,31}$/;
const testCaseIdPattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/;
const tagPattern = /^@[A-Za-z0-9][A-Za-z0-9_-]{0,98}$/;
const supportedFlags = new Set(['env', 'tag', 'testCaseId', 'state']);
const supportedEnvironments = new Set(['MA11', 'RA11']);

function parseArguments(argv) {
  const values = new Map();
  for (const argument of argv) {
    const match = /^--([A-Za-z][A-Za-z0-9]*)=(.+)$/.exec(argument);
    if (!match || !supportedFlags.has(match[1])) {
      throw new Error(`Unsupported argument: ${argument}`);
    }
    const [, name, value] = match;
    if (values.has(name)) {
      throw new Error(`Repeated argument: --${name}`);
    }
    values.set(name, value);
  }

  const environment = values.get('env')?.toUpperCase();
  const tag = values.get('tag');
  const testCaseId = values.get('testCaseId');
  const state = values.get('state')?.toUpperCase();
  if (!environment || !environmentPattern.test(environment)) {
    throw new Error('A valid --env=<name> argument is required.');
  }
  if (!supportedEnvironments.has(environment)) {
    throw new Error(`Unsupported environment: ${environment}. Use MA11 or RA11.`);
  }
  if (Boolean(tag) === Boolean(testCaseId)) {
    throw new Error('Provide exactly one selector: --tag=<tag> or --testCaseId=<id>.');
  }
  if (tag && !tagPattern.test(tag)) {
    throw new Error(`Invalid tag selector: ${tag}`);
  }
  if (testCaseId && !testCaseIdPattern.test(testCaseId)) {
    throw new Error(`Invalid test-case selector: ${testCaseId}`);
  }
  if (state && !/^[A-Z]{2}$/.test(state)) {
    throw new Error(`Invalid state selector: ${state}`);
  }
  return { environment, tag, testCaseId, state };
}

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function main() {
  const { environment, tag, testCaseId, state } = parseArguments(process.argv.slice(2));
  const grep = tag ? `(?<!\\S)${escapeRegex(tag)}(?!\\S)` : `\\[case:${escapeRegex(testCaseId)}\\]`;
  const playwrightCli = resolve('node_modules', '@playwright', 'test', 'cli.js');
  const environmentVariables = {
    ...process.env,
    TEST_ENV: environment,
    TEST_STATE: state ?? '',
    ...(tag ? { TEST_TAG: tag, TEST_CASE_ID: '' } : { TEST_CASE_ID: testCaseId, TEST_TAG: '' }),
  };
  const result = spawnSync(process.execPath, [playwrightCli, 'test', '--project=chromium', `--grep=${grep}`], {
    stdio: 'inherit',
    env: environmentVariables,
  });
  if (result.error) throw result.error;
  process.exitCode = result.status ?? 1;
}

try {
  main();
} catch (error) {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
}
