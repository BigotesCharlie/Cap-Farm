import { expect, type Locator, type Page } from '@playwright/test';

export async function isVisible(locator: Locator, timeout = 1_000): Promise<boolean> {
  try {
    await locator.waitFor({ state: 'visible', timeout });
    return true;
  } catch (error) {
    if (error instanceof Error && error.name === 'TimeoutError') return false;
    throw error;
  }
}

export async function proceedToNextPage(locator: Locator, page: Page): Promise<void> {
  await expect(locator).toBeEnabled();
  await locator.click();
  await page.waitForLoadState();
}

export async function fillOrUsePrefilledValue(
  locator: Locator,
  excelValue: string | undefined,
  fieldName: string,
): Promise<void> {
  const value = excelValue?.trim() ?? '';
  if (value) {
    await locator.fill(value);
    return;
  }

  if ((await locator.inputValue().catch(() => '')).trim() === '') {
    throw new Error(`Expected ${fieldName} field to contain a prefilled value because its Excel value is blank.`);
  }
}

export function normalizeDate(rawDate: string): string {
  const value = rawDate.trim();
  if (/^\d{2}\/\d{2}\/\d{4}$/.test(value)) return value;

  const digits = value.replace(/\D/g, '');
  if (digits.length === 8) {
    const maybeYear = Number(digits.slice(0, 4));
    if (maybeYear >= 1900 && maybeYear <= 2099) {
      const mm = digits.slice(4, 6);
      const dd = digits.slice(6, 8);
      return `${mm}/${dd}/${digits.slice(0, 4)}`;
    }
    const mm = digits.slice(0, 2);
    const dd = digits.slice(2, 4);
    const yyyy = digits.slice(4, 8);
    return `${mm}/${dd}/${yyyy}`;
  }

  const parsedDate = new Date(value);
  if (Number.isNaN(parsedDate.getTime())) return value;

  return (
    `${String(parsedDate.getUTCMonth() + 1).padStart(2, '0')}/` +
    `${String(parsedDate.getUTCDate()).padStart(2, '0')}/` +
    `${parsedDate.getUTCFullYear()}`
  );
}

export async function waitForSpinnerToDisappear(page: Page, timeout = 10_000): Promise<void> {
  await page.locator("[class*='spinner']").waitFor({ state: 'hidden', timeout });
}

export function splitAndTrim(value: string | undefined, delimiter = ',') {
  return (
    value
      ?.split(delimiter)
      .map((item) => item.trim())
      .filter(Boolean) ?? []
  );
}

export async function clickWithIntervals(locator: Locator, maxAttempts = 3, intervalMs = 2000): Promise<void> {
  let attempts = 0;

  while (attempts < maxAttempts) {
    await locator.click();
    console.log(`Click attempt ${attempts + 1}`);

    attempts++;
    if (attempts >= maxAttempts) return;

    await locator.page().waitForTimeout(intervalMs);

    const stillVisible = await locator.isVisible().catch(() => false);

    if (!stillVisible) {
      return;
    }
  }
}

export async function isOnpage(locator: Locator, timeout: number = 30000): Promise<boolean> {
  try {
    await locator.waitFor({ state: 'visible', timeout });
    return true;
  } catch {
    return false;
  }
}
