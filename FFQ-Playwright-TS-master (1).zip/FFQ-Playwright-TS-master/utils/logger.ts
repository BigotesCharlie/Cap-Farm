import { inspect } from 'node:util';
import { createLogger, format, transports } from 'winston';

const { combine, errors, timestamp, printf, colorize } = format;

const consoleFormat = printf(({ level, message, timestamp: logTimestamp, ...metadata }) => {
  const details = Object.keys(metadata).length > 0 ? ` ${inspect(metadata, { colors: true, depth: 5 })}` : '';
  return `${logTimestamp} [${level}]: ${message}${details}`;
});

export const logger = createLogger({
  level: process.env.LOG_LEVEL ?? 'info',
  format: combine(errors({ stack: true }), timestamp(), colorize(), consoleFormat),
  transports: [new transports.Console()],
});
