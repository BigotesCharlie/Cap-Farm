# Arbol transitivo de dependencias

Todas las rutas son internas al paquete. Includes imports de tipos y dinamicos. Las referencias ya listadas no se repiten.

```text
tests/legacy/acehome/AceHomeGoToPaymentSectionTest.spec.ts
  src/fixtures/test.ts
    src/config/env.ts
    src/core/BrowserUi.ts
      src/core/EvidenceSanitizer.ts
    src/reporting/EnvironmentExecutionReport.ts
    src/core/DomCheckpoint.ts
      src/core/BrowserUi.ts [referencia ya listada]
      src/core/EvidenceSanitizer.ts [referencia ya listada]
    src/core/EvidenceSanitizer.ts [referencia ya listada]
    src/fixtures/data/ace-home.fixture.ts
      src/fixtures/data/domain-provider.ts
        src/data/FixtureCatalog.ts
          src/data/LegacyDateFormula.ts
        src/data/LegacyProviderSelector.ts
          src/migration/LegacyTestMetadata.ts
          src/data/FixtureCatalog.ts [referencia ya listada]
          src/data/LegacyApplicantTransforms.ts
            src/data/FixtureCatalog.ts [referencia ya listada]
        src/migration/LegacyTestMetadata.ts [referencia ya listada]
        src/fixtures/data/provider.ts
          src/data/LegacyProviderSelector.ts [referencia ya listada]
          src/migration/LegacyTestMetadata.ts [referencia ya listada]
          src/data/providers/acehome/AceHomeQaBindData.ts
            src/config/env.ts [referencia ya listada]
            src/data/LegacyProviderSelector.ts [referencia ya listada]
            src/migration/LegacyTestMetadata.ts [referencia ya listada]
    src/fixtures/data/auto.fixture.ts
      src/fixtures/data/domain-provider.ts [referencia ya listada]
    src/fixtures/data/bundle.fixture.ts
      src/fixtures/data/provider.ts [referencia ya listada]
    src/fixtures/data/sql-auto.fixture.ts
      src/fixtures/data/domain-provider.ts [referencia ya listada]
    src/fixtures/data/classic.fixture.ts
      src/fixtures/data/provider.ts [referencia ya listada]
    src/fixtures/data/legacy-home.fixture.ts
      src/fixtures/data/domain-provider.ts [referencia ya listada]
    src/fixtures/data/inline.fixture.ts
      src/data/LegacyProviderSelector.ts [referencia ya listada]
      src/migration/LegacyTestMetadata.ts [referencia ya listada]
    src/fixtures/data/reference.fixture.ts
      src/data/ReferenceFixtures.ts
        src/data/FixtureCatalog.ts [referencia ya listada]
        src/data/LegacyProviderSelector.ts [referencia ya listada]
    src/fixtures/health/recovery.fixture.ts
      src/core/RecoveryGuard.ts
        src/config/env.ts [referencia ya listada]
        src/core/DomCheckpoint.ts [referencia ya listada]
        src/core/EvidenceSanitizer.ts [referencia ya listada]
    src/fixtures/health/health-check.fixture.ts
      src/core/HealthCheck.ts
        src/core/RecoveryGuard.ts [referencia ya listada]
        src/core/DomCheckpoint.ts [referencia ya listada]
        src/core/EvidenceSanitizer.ts [referencia ya listada]
        src/migration/contracts/ExecutionTracker.ts
          src/migration/contracts/ScenarioContract.ts
      src/core/RecoveryGuard.ts [referencia ya listada]
  src/migration/ScenarioExecutor.ts
    src/data/LegacyProviderSelector.ts [referencia ya listada]
    src/migration/LegacyTestMetadata.ts [referencia ya listada]
    src/migration/registry/HandlerCatalog.ts
      src/migration/handlers/auto/AceAutoEndToEndOneRandomApplicantHandler.ts
        src/data/providers/AutoApplicantProvider.ts
          src/migration/LegacyTestMetadata.ts [referencia ya listada]
          src/data/LegacyProviderSelector.ts [referencia ya listada]
          src/data/FixtureCatalog.ts [referencia ya listada]
          src/models/auto/AutoApplicant.ts
        src/flows/auto/AceAutoNavigationFlow.ts
          src/core/DomCheckpoint.ts [referencia ya listada]
          src/pages/auto/StartQuotePage.ts
            src/core/BasePage.ts
              src/core/BrowserUi.ts [referencia ya listada]
          src/pages/auto/NameDobPage.ts
            src/core/BasePage.ts [referencia ya listada]
            src/models/auto/AutoApplicant.ts [referencia ya listada]
          src/pages/auto/AddressPage.ts
            src/core/BasePage.ts [referencia ya listada]
            src/models/auto/AutoApplicant.ts [referencia ya listada]
          src/pages/auto/QuoteSummaryPage.ts
            src/core/BasePage.ts [referencia ya listada]
          src/pages/auto/AdditionalInfoPage.ts
            src/core/BasePage.ts [referencia ya listada]
          src/pages/auto/PaymentSelectionPage.ts
            src/core/BasePage.ts [referencia ya listada]
          src/pages/legacy/auto/pages/WhoShouldWeInsurePage.ts
            src/core/BasePage.ts [referencia ya listada]
          src/pages/legacy/auto/pages/HeresWhatWeFoundPage.ts
            src/core/BasePage.ts [referencia ya listada]
          src/pages/legacy/auto/pages/VehicleReviewPage.ts
            src/core/BasePage.ts [referencia ya listada]
          src/pages/legacy/auto/pages/DriverReviewPage.ts
            src/core/BasePage.ts [referencia ya listada]
          src/models/auto/AutoApplicant.ts [referencia ya listada]
        src/migration/handlers/ScenarioTypes.ts
          src/data/LegacyProviderSelector.ts [referencia ya listada]
          src/core/RecoveryGuard.ts [referencia ya listada]
          src/migration/contracts/ExecutionTracker.ts [referencia ya listada]
          src/migration/LegacyTestMetadata.ts [referencia ya listada]
      src/migration/handlers/acehome/AceHomeAdditionalInfoHandler.ts
        src/core/SoftAssertCollector.ts
          src/core/DomCheckpoint.ts [referencia ya listada]
          src/core/EvidenceSanitizer.ts [referencia ya listada]
        src/data/providers/acehome/AceHomeApplicantProvider.ts
          src/migration/LegacyTestMetadata.ts [referencia ya listada]
          src/data/LegacyProviderSelector.ts [referencia ya listada]
          src/data/FixtureCatalog.ts [referencia ya listada]
          src/models/acehome/ApplicantAceHome.ts
        src/flows/acehome/AceHomeNavigationFlow.ts
          src/models/acehome/ApplicantAceHome.ts [referencia ya listada]
          src/pages/acehome/AceHomePages.ts
            src/core/DomCheckpoint.ts [referencia ya listada]
            src/models/acehome/ApplicantAceHome.ts [referencia ya listada]
            src/core/SoftAssertCollector.ts [referencia ya listada]
            src/core/BrowserUi.ts [referencia ya listada]
            src/pages/acehome/AceHomePageClassifier.ts
            src/config/env.ts [referencia ya listada]
            src/data/providers/acehome/AceHomeQaBindData.ts [referencia ya listada]
          src/core/RecoveryGuard.ts [referencia ya listada]
          src/core/BrowserUi.ts [referencia ya listada]
          src/core/EvidenceSanitizer.ts [referencia ya listada]
        src/models/acehome/ApplicantAceHome.ts [referencia ya listada]
        src/pages/acehome/AceHomePages.ts [referencia ya listada]
        src/migration/handlers/ScenarioTypes.ts [referencia ya listada]
      src/migration/handlers/acehome/AceHomeProdRetrieveRatedQuoteHandler.ts
        src/config/env.ts [referencia ya listada]
        src/core/AceHomePrivateRunCapture.ts
          src/models/acehome/ApplicantAceHome.ts [referencia ya listada]
          src/data/LegacyProviderSelector.ts [referencia ya listada]
        src/core/SoftAssertCollector.ts [referencia ya listada]
        src/data/providers/acehome/AceHomeApplicantProvider.ts [referencia ya listada]
        src/flows/acehome/AceHomeBindFlow.ts
          src/models/acehome/ApplicantAceHome.ts [referencia ya listada]
          src/flows/acehome/AceHomeNavigationFlow.ts [referencia ya listada]
        src/flows/acehome/AceHomeNavigationFlow.ts [referencia ya listada]
        src/flows/acehome/AceHomeRetrieveQuoteFlow.ts
          src/pages/acehome/AceHomePages.ts [referencia ya listada]
          src/models/acehome/ApplicantAceHome.ts [referencia ya listada]
          src/flows/acehome/AceHomeNavigationFlow.ts [referencia ya listada]
        src/models/acehome/HomeQuoteState.ts
        src/pages/acehome/AceHomePages.ts [referencia ya listada]
        src/migration/handlers/ScenarioTypes.ts [referencia ya listada]
      src/migration/handlers/acehome/AceHomeQuoteAndBindHandler.ts
        src/data/providers/acehome/AceHomeApplicantProvider.ts [referencia ya listada]
        src/data/providers/acehome/AceHomeQaBindData.ts [referencia ya listada]
        src/flows/acehome/AceHomeNavigationFlow.ts [referencia ya listada]
        src/pages/acehome/AceHomePages.ts [referencia ya listada]
        src/core/SoftAssertCollector.ts [referencia ya listada]
        src/core/AceHomePrivateRunCapture.ts [referencia ya listada]
        src/migration/handlers/ScenarioTypes.ts [referencia ya listada]
      src/migration/handlers/acehome/AceHomeReviewQuotePresentmentHandler.ts
        src/config/env.ts [referencia ya listada]
        src/core/SoftAssertCollector.ts [referencia ya listada]
        src/data/providers/acehome/AceHomeApplicantProvider.ts [referencia ya listada]
        src/flows/acehome/AceHomeNavigationFlow.ts [referencia ya listada]
        src/pages/acehome/AceHomePages.ts [referencia ya listada]
        src/models/acehome/ApplicantAceHome.ts [referencia ya listada]
        src/migration/handlers/ScenarioTypes.ts [referencia ya listada]
      src/migration/handlers/acehome/AceHomeSmokePresentmentHandler.ts
        src/core/SoftAssertCollector.ts [referencia ya listada]
        src/data/providers/acehome/AceHomeApplicantProvider.ts [referencia ya listada]
        src/flows/acehome/AceHomeNavigationFlow.ts [referencia ya listada]
        src/migration/handlers/ScenarioTypes.ts [referencia ya listada]
      src/migration/registry/ScenarioHandlerRegistry.ts
        src/migration/handlers/ScenarioTypes.ts [referencia ya listada]
    src/fixtures/health/recovery.fixture.ts [referencia ya listada]
    src/fixtures/health/health-check.fixture.ts [referencia ya listada]
    src/migration/contracts/ExecutionTracker.ts [referencia ya listada]
    src/migration/handlers/ScenarioTypes.ts [referencia ya listada]
    src/data/providers/acehome/AceHomeQaBindData.ts [referencia ya listada]
    src/core/DomCheckpoint.ts [referencia ya listada]
playwright.config.ts
  src/config/env.ts [referencia ya listada]
src/reporting/PlaywrightEnvironmentExecutionReporter.ts
  src/reporting/EnvironmentExecutionReport.ts [referencia ya listada]
```

## Archivos leidos en runtime

- config/legacy-master/properties.json: endpoints MA11, sin secretos.
- src/data/catalog/AceHomeTestData.json: solicitante TX/116 y descuento.
- src/data/catalog/AutoTestData.json: nueve registros bancarios QA autorizados.
- src/data/catalog/columns.json y source-rows.json: columnas y trazabilidad de filas.
- src/data/catalog/provider-constants.json y state-support.json: provider/categoria/estados.
- migration/audit/legacy-method-contracts.json: contrato exacto del escenario.
- migration/audit/full-test-execution-inventory.json: entrada del reporter.

Dotenv no requiere un .env existente. Los otros catalogos de fixtures lazy no se leen para este ID.
No se encontraron assets locales adicionales: la UI y PaymentUS sirven sus propios recursos remotos.
