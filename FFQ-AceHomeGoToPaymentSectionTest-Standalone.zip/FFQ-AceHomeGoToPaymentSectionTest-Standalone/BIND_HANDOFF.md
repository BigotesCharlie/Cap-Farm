# Isolated Bind Handoff

## Owner Authorization

On 2026-10-22 the user explicitly requested: "In the ISOLATED Bind workspace only, amend the local repository instruction to state explicitly that testQuoteAndBindHomeLob may be implemented and run there, with its own integrity and execution evidence, independently of the original demo seal."

The user also required the original demo workspace, instructions, launcher, manifest, expected hashes and Review/Smoke historical evidence to remain untouched. This records authorization; it does not establish that the current session's governing instructions have changed.

## Policy Change

Before: this isolated workspace had no .github/copilot-instructions.md.

After: a local instruction file limits implementation and execution to Bind and preserves the original demo freeze. The exact addition is recorded in the sibling isolated policy diff evidence. The original instruction file was not edited.

## Validated Inputs

- Provider: AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER.
- Source: AceHomeTestData / PageValidationApplicantAceHome / 116 / TX.
- Category: Bind validation; TX takes the monthly automatic bank-payment branch.
- Existing MA11 QA fixture: AutoTestData/payments, shared nine-row instrument; local provenance validation passed. Banking values are deliberately omitted.
- Current selector/fixture source copies match preserved-current bytes. Their original-demo mismatches are comment-only.
- Dependencies, catalog and configuration are junctions to shared original locations. Treat every shared target as read-only; do not install, regenerate, format or write through those junctions.
- No browser session, quote number or prior-run appStore state was copied.

## Existing Java-Equivalent Methods

- Navigation: AceHomeNavigationFlow.navigateToDwellingCoveragePage, waitForReviewQuoteAfterDwellingContinue and continueFromReviewToPaymentSelection.
- Payment: AceHomePaymentPage.assertOnPage, openBankSetup and addQaBankAccount.
- Assertions: validateAddedBank, validateBankServiceCharge, validateMonthlyAgreement and completeQaPurchase, followed by the original final fsa.assertAll().
- Existing handler: src/migration/handlers/acehome/AceHomeQuoteAndBindHandler.ts.

Before execution, address the existing handler's preventAutomaticRecovery call and the shared flow's forced-click fallback only in physical isolated source copies, preserving assertions. Required per-wait diagnostics have not yet been implemented.

## Execution Status

NOT RUN. No new Playwright result, execution run ID, exit code, application response, screenshot or trace exists. The preparation-directory ID is not a test execution ID.

The current session retains the original workspace's governing freeze instruction. Creating this local file does not supersede that already-loaded instruction. Open the isolated directory as its own VS Code workspace in a new session, review the applicable policy, implement the required diagnostics, then execute only the specified Bind test.

## Original Demo Status

Last verified FAILED, with comment-only mismatches in src/data/LegacyProviderSelector.ts and src/fixtures/data/ace-home.fixture.ts. Exact frozen reference copies exist; neither original file was restored. No original manifest, hash, instruction or historical PASS evidence was changed. No independent demo verifier was copied into this isolated workspace, and this policy addition is not a new demo seal.