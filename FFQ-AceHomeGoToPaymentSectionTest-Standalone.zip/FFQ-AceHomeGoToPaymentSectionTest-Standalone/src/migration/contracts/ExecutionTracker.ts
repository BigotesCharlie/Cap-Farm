/**
 * ExecutionTracker: Records what actually happened during scenario execution.
 *
 * Used by ScenarioExecutor to validate that all required steps, checkpoints,
 * and assertions were executed before allowing a PASS result.
 */

import type { ScenarioCheckpoint, ScenarioStepType } from './ScenarioContract.js';

export interface ExecutionEvent {
  type: 'step' | 'checkpoint' | 'assertion' | 'recovery' | 'error' | 'warning';
  timestamp: number;
  id: string;
  description: string;
  success: boolean;
  metadata?: Record<string, unknown> | undefined;
}

export class ExecutionTracker {
  private events: ExecutionEvent[] = [];
  private stepsExecuted: Set<ScenarioStepType> = new Set();
  private checkpointsReached: Set<string> = new Set();
  private assertionsExecuted: Set<string> = new Set();
  private recoveryAttempts: number = 0;
  private currentPageState: string | undefined;
  private startTime: number = 0;
  private lastCheckpointTime: number = 0;

  constructor() {
    this.startTime = Date.now();
  }

  /**
   * Record execution of a step.
   */
  recordStep(step: ScenarioStepType, description: string, success: boolean, metadata?: Record<string, unknown>): void {
    this.stepsExecuted.add(step);
    this.events.push({
      type: 'step',
      timestamp: Date.now(),
      id: step,
      description,
      success,
      metadata,
    });
  }

  /**
   * Record reaching a checkpoint.
   */
  recordCheckpoint(
    checkpoint: ScenarioCheckpoint | string,
    success: boolean,
    metadata?: Record<string, unknown>,
  ): void {
    const name = typeof checkpoint === 'string' ? checkpoint : checkpoint.name;
    this.checkpointsReached.add(name);
    this.lastCheckpointTime = Date.now();
    this.events.push({
      type: 'checkpoint',
      timestamp: this.lastCheckpointTime,
      id: name,
      description: `Checkpoint: ${name}`,
      success,
      metadata,
    });
  }

  /**
   * Record execution of an assertion.
   */
  recordAssertion(
    assertionId: string,
    description: string,
    success: boolean,
    metadata?: Record<string, unknown>,
  ): void {
    this.assertionsExecuted.add(assertionId);
    this.events.push({
      type: 'assertion',
      timestamp: Date.now(),
      id: assertionId,
      description,
      success,
      metadata,
    });
  }

  /**
   * Record a recovery attempt.
   */
  recordRecoveryAttempt(state: string, success: boolean, metadata?: Record<string, unknown>): void {
    this.recoveryAttempts++;
    this.events.push({
      type: 'recovery',
      timestamp: Date.now(),
      id: `recovery-${this.recoveryAttempts}`,
      description: `Recovery attempt ${this.recoveryAttempts} for state: ${state}`,
      success,
      metadata,
    });
  }

  /**
   * Record an error.
   */
  recordError(id: string, message: string, metadata?: Record<string, unknown>): void {
    this.events.push({
      type: 'error',
      timestamp: Date.now(),
      id,
      description: message,
      success: false,
      metadata,
    });
  }

  /**
   * Record a warning.
   */
  recordWarning(id: string, message: string, metadata?: Record<string, unknown>): void {
    this.events.push({
      type: 'warning',
      timestamp: Date.now(),
      id,
      description: message,
      success: false,
      metadata,
    });
  }

  /**
   * Update current page state.
   */
  updatePageState(state: string): void {
    this.currentPageState = state;
  }

  /**
   * Get current page state.
   */
  getPageState(): string | undefined {
    return this.currentPageState;
  }

  /**
   * Check if a step was executed.
   */
  hasExecutedStep(step: ScenarioStepType): boolean {
    return this.stepsExecuted.has(step);
  }

  /**
   * Check if a checkpoint was reached.
   */
  hasReachedCheckpoint(checkpoint: string): boolean {
    return this.checkpointsReached.has(checkpoint);
  }

  /**
   * Check if an assertion was executed.
   */
  hasExecutedAssertion(assertionId: string): boolean {
    return this.assertionsExecuted.has(assertionId);
  }

  /**
   * Get all executed steps.
   */
  getExecutedSteps(): ScenarioStepType[] {
    return Array.from(this.stepsExecuted);
  }

  /**
   * Get all reached checkpoints.
   */
  getReachedCheckpoints(): string[] {
    return Array.from(this.checkpointsReached);
  }

  /**
   * Get all executed assertions.
   */
  getExecutedAssertions(): string[] {
    return Array.from(this.assertionsExecuted);
  }

  /**
   * Get number of recovery attempts.
   */
  getRecoveryAttempts(): number {
    return this.recoveryAttempts;
  }

  /**
   * Get total execution time in milliseconds.
   */
  getExecutionTimeMs(): number {
    return Date.now() - this.startTime;
  }

  /**
   * Get all events in order.
   */
  getEvents(): ExecutionEvent[] {
    return [...this.events];
  }

  /**
   * Get execution summary.
   */
  getSummary(): {
    stepsCount: number;
    checkpointsCount: number;
    assertionsCount: number;
    recoveryAttempts: number;
    executionTimeMs: number;
    lastCheckpointTime: number;
  } {
    return {
      stepsCount: this.stepsExecuted.size,
      checkpointsCount: this.checkpointsReached.size,
      assertionsCount: this.assertionsExecuted.size,
      recoveryAttempts: this.recoveryAttempts,
      executionTimeMs: this.getExecutionTimeMs(),
      lastCheckpointTime: this.lastCheckpointTime,
    };
  }

  /**
   * Get formatted execution log.
   */
  getFormattedLog(): string[] {
    const lines: string[] = [];
    for (const event of this.events) {
      const status = event.success ? '✓' : '✗';
      const timestamp = new Date(event.timestamp).toISOString();
      lines.push(`[${timestamp}] ${status} [${event.type.toUpperCase()}] ${event.id}: ${event.description}`);
    }
    return lines;
  }
}
