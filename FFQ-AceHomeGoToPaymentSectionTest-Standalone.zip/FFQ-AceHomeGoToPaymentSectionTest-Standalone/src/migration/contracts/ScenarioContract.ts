/**
 * ScenarioContract: Immutable specification of expected E2E behavior for a migrated test.
 *
 * This contract defines what is required for a test to be considered a legitimate E2E pass.
 * No handler can return PASS unless:
 * 1. All required steps have executed
 * 2. All mandatory checkpoints have been reached
 * 3. All required assertions have passed
 * 4. The expected final state has been reached
 * 5. The handler is runtime-certified
 * 6. No required exception was swallowed
 * 7. No early-return or placeholder path was used
 */

export type ScenarioStepType =
  | 'LOAD_APPLICATION'
  | 'SELECT_PRODUCT'
  | 'FILL_PROPERTY_INFO'
  | 'FILL_QUALITY_GRADE'
  | 'FILL_PROPERTY_DETAILS'
  | 'FILL_ADDITIONAL_INFO'
  | 'FILL_ABOUT_YOU'
  | 'FILL_CONTACT_INFO'
  | 'FILL_DWELLING_COVERAGE'
  | 'REACH_REVIEW_QUOTE'
  | 'NAVIGATE_TO_PAYMENT_SELECTION'
  | 'SELECT_PAYMENT_METHOD'
  | 'SETUP_PAYMENT'
  | 'ENTER_PAYMENT_DETAILS'
  | 'VALIDATE_PAYMENT_PAGE'
  | 'COMPLETE_PAYMENT'
  | 'REACH_CONFIRMATION'
  | 'REACH_E_CHECKOUT'
  | 'CHANGE_PAYMENT_METHOD'
  | 'VALIDATE_PAYMENT_CHANGE'
  | 'FILL_RENEWAL_INFO'
  | 'SETUP_BUNDLE'
  | 'SELECT_BUNDLE_DISCOUNT'
  | 'VALIDATE_BUNDLE_DISCOUNT'
  | 'BIND_TRANSACTION'
  | 'VALIDATE_POLICY_BOUND';

export type PageState =
  | 'HOME'
  | 'PRODUCT_SELECTION'
  | 'PROPERTY_INFORMATION'
  | 'QUALITY_GRADE'
  | 'PROPERTY_DETAILS'
  | 'ADDITIONAL_INFORMATION'
  | 'ABOUT_YOU'
  | 'CONTACT_INFORMATION'
  | 'DWELLING_COVERAGE'
  | 'REVIEW_QUOTE'
  | 'PAYMENT_SELECTION'
  | 'PAYMENT'
  | 'PAY_IN_FULL'
  | 'CONFIRMATION'
  | 'E_CHECKOUT'
  | 'BUNDLE_DISCOUNT'
  | 'BUNDLE_PAYMENT'
  | 'BOUND_CONFIRMATION';

export interface ScenarioStep {
  step: ScenarioStepType;
  description: string;
  mandatory: boolean;
  checkpoint?: string;
  expectedResult?: string;
}

export interface ScenarioCheckpoint {
  name: string;
  expectedAfterStep: ScenarioStepType;
  description: string;
  mandatory: boolean;
  expectedElements?: string[];
}

export interface ScenarioAssertion {
  id: string;
  description: string;
  relatedStep: ScenarioStepType;
  mandatory: boolean;
  type: 'page-presence' | 'element-content' | 'element-state' | 'value-validation' | 'payment-state' | 'business-logic';
}

export interface ScenarioContract {
  readonly legacyId: string;
  readonly testName: string;
  readonly domain:
    | 'auto'
    | 'acehome'
    | 'acebundle'
    | 'acelife'
    | 'acemobilehome'
    | 'acerenters'
    | 'acecondo'
    | 'acebusiness';
  readonly suite: string;
  readonly workflowFamily: string; // e.g., 'payment-acehome', 'bind-auto', 'renewal', 'bundle-selection'

  /**
   * Expected behavior based on legacy Java implementation.
   * This is derived from the javaSource in LegacyMethodContract.
   */
  readonly expectedBehavior: string;

  /**
   * The handler that must be used to execute this scenario.
   * If handler is missing or not runtime-certified, test must FAIL.
   */
  readonly requiredHandler: string;

  /**
   * Must be true for test to PASS. If false, test must FAIL or BLOCK.
   */
  readonly runtimeCertificationRequired: boolean;

  /**
   * Whether this scenario supports recovery mechanisms.
   */
  readonly supportsRecovery: boolean;

  /**
   * The initial page state when scenario starts.
   */
  readonly startState: PageState;

  /**
   * The final page state after scenario completes.
   * Test must NOT PASS if actual final state != expected final state.
   */
  readonly expectedFinalState: PageState;

  /**
   * All steps that must execute for E2E pass.
   * Handler must invoke all mandatory steps.
   */
  readonly requiredSteps: ScenarioStep[];

  /**
   * All checkpoints that must be reached.
   * Checkpoint counts only if real UI action was observed.
   */
  readonly requiredCheckpoints: ScenarioCheckpoint[];

  /**
   * All assertions that must pass.
   * Mandatory assertions must all execute before test ends.
   * Soft assertions must be collected and verified via assertAll().
   */
  readonly requiredAssertions: ScenarioAssertion[];

  /**
   * Recovery states this scenario may encounter and how to handle them.
   */
  readonly recoveryBehavior?: {
    readonly states: Array<'INCONVENIENCE' | 'KNOCKOUT' | 'TRY_AGAIN'>;
    readonly maxAttempts: number;
    readonly timeoutMs: number;
  };

  /**
   * If true, no early returns or placeholder paths are allowed.
   * Handler must execute full flow or fail.
   */
  readonly mustExecuteFullFlow: boolean;

  /**
   * Version of contract. Increment when expected behavior changes.
   */
  readonly contractVersion: number;

  /**
   * Last updated timestamp (ISO 8601).
   */
  readonly lastUpdated: string;

  /**
   * Human-readable notes explaining the contract.
   */
  readonly notes: string;
}

/**
 * Result of validating a scenario execution against its contract.
 */
export interface ScenarioContractValidation {
  isValid: boolean;
  status: 'E2E_CERTIFIED' | 'FAILED' | 'BLOCKED' | 'INCOMPLETE';
  stepsExpected: ScenarioStepType[];
  stepsExecuted: ScenarioStepType[];
  checkpointsExpected: string[];
  checkpointsExecuted: string[];
  assertionsExpected: string[];
  assertionsExecuted: string[];
  expectedFinalState: PageState;
  actualFinalState: PageState | undefined;
  recoveryAttempts: number;
  handlerStatus: 'not-found' | 'not-certified' | 'certified' | 'compatible-error';
  errors: string[];
  warnings: string[];
  executionTimeMs: number;
}
