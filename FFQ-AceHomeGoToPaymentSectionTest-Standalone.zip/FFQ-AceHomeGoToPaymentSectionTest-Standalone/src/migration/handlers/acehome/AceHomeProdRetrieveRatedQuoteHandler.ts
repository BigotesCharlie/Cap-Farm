import { env, requireSecret } from '../../../config/env.js';
import { AceHomePrivateRunCapture } from '../../../core/AceHomePrivateRunCapture.js';
import { SoftAssertCollector } from '../../../core/SoftAssertCollector.js';
import { AceHomeApplicantProvider } from '../../../data/providers/acehome/AceHomeApplicantProvider.js';
import { AceHomeBindFlow } from '../../../flows/acehome/AceHomeBindFlow.js';
import { AceHomeNavigationFlow } from '../../../flows/acehome/AceHomeNavigationFlow.js';
import { AceHomeRetrieveQuoteFlow } from '../../../flows/acehome/AceHomeRetrieveQuoteFlow.js';
import type { HomeQuoteState } from '../../../models/acehome/HomeQuoteState.js';
import {
  AceHomeAppStoreReader,
  AceHomeAboutYouPage,
  AceHomeAdditionalInfoPage,
  AceHomeContactInfoPage,
  AceHomeDwellingCoveragePage,
  AceHomePropertyDetailsPage,
  AceHomePropertyInfoPage,
  AceHomeQualityGradePage,
} from '../../../pages/acehome/AceHomePages.js';
import type { ScenarioExecutionContext, ScenarioHandler } from '../ScenarioTypes.js';

export const ACE_HOME_PROD_RETRIEVE_RATED_QUOTE_LEGACY_ID =
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testProdRetrieveRatedQuoteAceHome';

function isProductionEnvironment(): boolean {
  const name = env.TEST_ENV.toUpperCase();
  return name === 'PROD' || name === 'PRODUCTION';
}

function updateApplicantForProdValidation(applicant: Awaited<ReturnType<AceHomeApplicantProvider['fromFixture']>>['applicant']) {
  if (!isProductionEnvironment()) return applicant;
  return {
    ...applicant,
    firstName: requireSecret('FFQ_PRODUCTION_APPLICANT_FIRST_NAME'),
    lastName: requireSecret('FFQ_PRODUCTION_APPLICANT_LAST_NAME'),
    emailAddress: requireSecret('FFQ_PRODUCTION_APPLICANT_EMAIL'),
  };
}

export class AceHomeProdRetrieveRatedQuoteHandler implements ScenarioHandler {
  public readonly legacyId = ACE_HOME_PROD_RETRIEVE_RATED_QUOTE_LEGACY_ID;
  public readonly domain = 'acehome';
  public readonly status = 'implemented' as const;

  private readonly provider = new AceHomeApplicantProvider();

  public async execute(context: ScenarioExecutionContext): Promise<void> {
    if (isProductionEnvironment() && !env.FFQ_ALLOW_PRODUCTION_EXECUTION) {
      throw new Error(
        'Production execution is blocked. Set FFQ_ALLOW_PRODUCTION_EXECUTION=true only when explicitly authorized.',
      );
    }

    await this.executeWhenDependencyResolved(context);
  }

  public async executeWhenDependencyResolved(context: ScenarioExecutionContext): Promise<void> {
    if (context.selectedCases.length !== 1) {
      throw new Error(
        `Expected one AceHome production applicant per execution; received ${context.selectedCases.length}`,
      );
    }
    const selected = await this.provider.fromFixture(context.metadata, context.selectedCases[0]);
    const applicant = updateApplicantForProdValidation(selected.applicant);
    const seed = process.env.FFQ_DATA_SEED || context.testInfo.testId;
    const privateCapture = new AceHomePrivateRunCapture(
      context.page,
      context.testInfo,
      context.selectedCases[0]!,
      applicant,
      seed,
    );
    await privateCapture.start();
    await privateCapture.checkpoint('test-start-resolved-inputs');
    context.annotate('applicant-correlation-id', selected.correlationId);
    context.annotate('provider-workbook', `${selected.workbook}:${selected.worksheet}`);
    context.annotate('provider-source-id', context.selectedCases[0]?.sourceId ?? 'unknown');
    context.annotate('provider-seed', seed);
    const fsa = new SoftAssertCollector(context.page, context.testInfo, context.metadata.legacyId);
    const flow = new AceHomeNavigationFlow(
      context.page,
      {
        checkpoint: async (name) => {
          await context.checkpoint(name);
          await privateCapture.checkpoint(name);
        },
        annotate: context.annotate,
      },
      context.recoveryGuard,
    );

    const state: HomeQuoteState = {
      quoteNumber: '',
      dwellingCoverageAmount: '',
      dwellingCoverageQualityGrade: '',
      quotePriceBeforeRetrieve: '',
      discountsBeforeRetrieve: [],
    };

    const dwellingPage = await flow.navigateToDwellingCoveragePage(applicant);
    state.dwellingCoverageAmount = await dwellingPage.dwellingCoverageAmount();
    state.dwellingCoverageQualityGrade = await dwellingPage.dwellingCoverageQualityGrade();
    await dwellingPage.clickContinue();

    let reviewPage = await flow.waitForReviewQuoteAfterDwellingContinue();
    await privateCapture.checkpoint('initial-review-quote');
    state.discountsBeforeRetrieve = (await reviewPage.discounts()).sort();

    await reviewPage.validatePageLinksText(fsa);
    await reviewPage.validatePageLinksNavigationTitles(fsa);

    await reviewPage.clickChangeCoverage();
    await dwellingPage.assertOnPage();
    await dwellingPage.changeDwellingCoverage();
    await dwellingPage.clickContinue();
    reviewPage = await flow.waitForReviewQuoteAfterDwellingContinue();
    state.quotePriceBeforeRetrieve = await reviewPage.quotePriceOnCard();
    await privateCapture.checkpoint('rerated-review-quote');

    const retrieveFlow = new AceHomeRetrieveQuoteFlow(context.page, {
      checkpoint: context.checkpoint,
      annotate: context.annotate,
    });
    state.quoteNumber = await new AceHomeAppStoreReader(context.page).quoteNumber();
    if (!state.quoteNumber) throw new Error('QUOTE_RETRIEVAL_BLOCKED: app-store quote number is empty.');
    await retrieveFlow.retrieveByQuoteNumber(state.quoteNumber, applicant);
    await privateCapture.checkpoint('quote-retrieved');

    await fsa.check(
      await reviewPage.isWelcomeBackMessageDisplayed(applicant.firstName),
      'Welcome back snackbar not displayed after quote retrieval.',
      'retrieve-welcome-back',
    );

    await fsa.equal(
      await reviewPage.quotePriceOnCard(),
      state.quotePriceBeforeRetrieve,
      'Quote price mismatch after retrieval.',
      'retrieve-price-compare',
    );

    await reviewPage.verifyQuotePresentmentCard(applicant.stateCode, fsa);
    await reviewPage.validateQuoteSavedText(state.quoteNumber, fsa);
    await fsa.equal(
      (await reviewPage.discounts()).sort().join('|'),
      state.discountsBeforeRetrieve.join('|'),
      'Discounts mismatch after retrieval on Review Quote page.',
      'retrieve-discounts-compare',
    );

    await reviewPage.selectEnterInfoStepper();
    await privateCapture.checkpoint('return-to-enter-info');
    const propertyInfo = new AceHomePropertyInfoPage(context.page);
    await propertyInfo.assertOnPage();
    await propertyInfo.clickContinue();

    const quality = new AceHomeQualityGradePage(context.page);
    await quality.waitForQualityGradeOrPropertyDetails();
    if (await quality.isQualityGradePageAlone()) {
      await quality.assertStandalone(fsa);
      await quality.validateAddressAndFeatures(fsa);
      await quality.clickContinueIfVisible();
    } else {
      await quality.assertCombined(fsa);
      await quality.validateAddressAndFeatures(fsa);
    }

    const propertyDetails = new AceHomePropertyDetailsPage(context.page);
    await propertyDetails.assertOnPage();
    await fsa.equal(
      await propertyDetails.pageTitle(),
      "Here's what we have so far",
      'Property Details title mismatch.',
      'property-details-title',
    );
    await propertyDetails.validateSavedQuote(state.quoteNumber, fsa);
    await propertyDetails.validateDiscounts(state.discountsBeforeRetrieve, fsa);
    await propertyDetails.clickContinue();

    const additionalInfo = new AceHomeAdditionalInfoPage(context.page);
    await additionalInfo.assertOnPage();
    await additionalInfo.validateSelections(fsa);
    await additionalInfo.clickContinue();

    if (!(await additionalInfo.isNewFlowEnabledState(applicant.stateCode))) {
      const aboutYou = new AceHomeAboutYouPage(context.page);
      await aboutYou.assertOnPage();
      await aboutYou.validateSelections(fsa);
      await aboutYou.clickContinue();
    }

    const contactInfo = new AceHomeContactInfoPage(context.page);
    await contactInfo.assertOnPage();
    await contactInfo.validateSelections(applicant, fsa);
    await contactInfo.clickAgreeAndSubmit();

    const dwellingAfterRetrieve = new AceHomeDwellingCoveragePage(context.page);
    await dwellingAfterRetrieve.assertOnPage();
    await fsa.equal(
      await dwellingAfterRetrieve.dwellingCoverageAmount(),
      state.dwellingCoverageAmount,
      'Dwelling coverage amount mismatch after retrieval.',
      'dwelling-after-retrieve-amount',
    );
    await fsa.equal(
      await dwellingAfterRetrieve.dwellingCoverageQualityGrade(),
      state.dwellingCoverageQualityGrade,
      'Dwelling quality grade mismatch after retrieval.',
      'dwelling-after-retrieve-quality-grade',
    );
    await fsa.equal(
      (await dwellingAfterRetrieve.discounts()).join('|'),
      state.discountsBeforeRetrieve.join('|'),
      'Dwelling discounts mismatch after retrieval.',
      'dwelling-after-retrieve-discounts',
    );
    await fsa.equal(
      await dwellingAfterRetrieve.displayedQuoteNumber(),
      state.quoteNumber,
      'Dwelling quote number mismatch after retrieval.',
      'dwelling-after-retrieve-quote-number',
    );
    await dwellingAfterRetrieve.clickContinue();

    await reviewPage.assertOnPage();
    await reviewPage.verifyQuotePresentmentCard(applicant.stateCode, fsa);
    await reviewPage.validateQuoteSavedText(state.quoteNumber, fsa);
    await fsa.equal(
      (await reviewPage.discounts()).sort().join('|'),
      state.discountsBeforeRetrieve.join('|'),
      'Review Quote discounts changed after returning from Enter Info.',
      'return-review-discounts',
    );

    const bindFlow = new AceHomeBindFlow(context.page, {
      checkpoint: async (name) => {
        await context.checkpoint(name);
        await privateCapture.checkpoint(name);
      },
      annotate: context.annotate,
    });
    await bindFlow.continueFromReviewQuote(applicant);
    const privateInputPath = await privateCapture.saveAtPayment();
    context.annotate('private-resolved-inputs', privateInputPath);

    await fsa.assertAll('Ace Home - Prod Retrieve rated quote.');
    context.annotate('assertAll-completed', context.metadata.legacyId);
  }
}
