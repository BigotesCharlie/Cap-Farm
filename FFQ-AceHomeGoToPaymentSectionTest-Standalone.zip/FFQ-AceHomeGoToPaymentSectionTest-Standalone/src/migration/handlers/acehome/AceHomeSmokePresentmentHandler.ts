import { SoftAssertCollector } from '../../../core/SoftAssertCollector.js';
import { AceHomeApplicantProvider } from '../../../data/providers/acehome/AceHomeApplicantProvider.js';
import { AceHomeNavigationFlow } from '../../../flows/acehome/AceHomeNavigationFlow.js';
import type { ScenarioExecutionContext, ScenarioHandler } from '../ScenarioTypes.js';

export const ACE_HOME_SMOKE_PRESENTMENT_LEGACY_ID =
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testSmokeReviewQuotePagePresentmentCardHome';

export class AceHomeSmokePresentmentHandler implements ScenarioHandler {
  public readonly legacyId = ACE_HOME_SMOKE_PRESENTMENT_LEGACY_ID;
  public readonly domain = 'acehome';
  public readonly status = 'implemented' as const;

  private readonly provider = new AceHomeApplicantProvider();

  public async execute(context: ScenarioExecutionContext): Promise<void> {
    const selected = await this.provider.fromFixture(context.metadata, context.selectedCases[0]);
    const applicant = selected.applicant;

    context.annotate('applicant-correlation-id', selected.correlationId);
    context.annotate('provider-workbook', `${selected.workbook}:${selected.worksheet}`);
    context.annotate('provider-source-id', context.selectedCases[0]?.sourceId ?? 'unknown');
    context.annotate('provider-seed', process.env.FFQ_DATA_SEED || context.testInfo.testId);
    context.annotate('legacy-groups', 'ACE_HOME_SMOKE,ACE_HOME_ADA_SUITE,ADA_SUITE');
    context.annotate('expected-knockout', 'true');

    const fsa = new SoftAssertCollector(context.page, context.testInfo, context.metadata.legacyId);
    const flow = new AceHomeNavigationFlow(
      context.page,
      {
        checkpoint: context.checkpoint,
        annotate: context.annotate,
      },
      context.recoveryGuard,
    );
    const additionalCoverages = await flow.navigateToAdditionalCoveragesPage(applicant);

    await additionalCoverages.validatePageTitleSubtitle(fsa);
    await additionalCoverages.verifyQuotePresentmentCard(fsa);
    await additionalCoverages.validateEmailThisQuoteLink(applicant, fsa);
    await additionalCoverages.validateDiscounts(fsa);

    await fsa.assertAll('Smoke test - Validate Ace Home Additional coverages page - Quote Presentment Card.');
    context.annotate('assertAll-completed', context.metadata.legacyId);
  }
}
