import type { Response } from '@playwright/test';
import { AceHomeApplicantProvider } from '../../../data/providers/acehome/AceHomeApplicantProvider.js';
import {
  ACE_HOME_QUOTE_BIND_LEGACY_ID,
  assertQaBindConfiguration,
  loadQaBankFixture,
  getAceHomeBindEnvironment,
  getBindBankFixtureStatus,
  type QaBankFixture,
} from '../../../data/providers/acehome/AceHomeQaBindData.js';
import { AceHomeNavigationFlow } from '../../../flows/acehome/AceHomeNavigationFlow.js';
import { AceHomePaymentPage, AceHomePageClassifier } from '../../../pages/acehome/AceHomePages.js';
import { SoftAssertCollector } from '../../../core/SoftAssertCollector.js';
import { AceHomePrivateRunCapture } from '../../../core/AceHomePrivateRunCapture.js';
import type { ScenarioExecutionContext, ScenarioHandler } from '../ScenarioTypes.js';

interface BindStep {
  readonly step: string;
  readonly action: string;
  readonly assertion: string;
  readonly result: 'PASS' | 'FAIL';
  readonly evidence: string;
}

export class AceHomeQuoteAndBindHandler implements ScenarioHandler {
  public readonly legacyId = ACE_HOME_QUOTE_BIND_LEGACY_ID;
  public readonly domain = 'acehome';
  public readonly status = 'implemented' as const;

  public async execute(context: ScenarioExecutionContext): Promise<void> {
    assertQaBindConfiguration();
    const environment = getAceHomeBindEnvironment();
    const bankStatus = getBindBankFixtureStatus();
    const row = context.selectedCases[0];
    if (!row || context.selectedCases.length !== 1) throw new Error('BLOCKED: bind requires exactly one provider row.');
    const selected = new AceHomeApplicantProvider().fromFixture(context.metadata, row);
    const applicant = selected.applicant;
    let bank: QaBankFixture | undefined;
    const mode = row.state === 'UT' ? 'PIF' : 'MONTHLY_BANK';
    context.annotate('provider-source-id', row.sourceId);
    context.annotate('payment-branch', mode);
    context.annotate('bank-fixture-source', bankStatus.source);
    context.annotate('bind-environment', `${environment.name}/${environment.tier}`);
    context.recoveryGuard?.preventAutomaticRecovery();
    const capture = new AceHomePrivateRunCapture(
      context.page,
      context.testInfo,
      row,
      applicant,
      process.env.FFQ_DATA_SEED ?? context.testInfo.testId,
    );
    await capture.start();
    const steps: BindStep[] = [];
    const checkpoints: Array<{
      checkpoint: string;
      screen: string;
      url: string;
      action: string;
      assertion: string;
      result: string;
    }> = [];
    const locationResponses: Array<{ at: string; method: string; host: string; path: string; status: number }> = [];
    const observedOrigins = new Set<string>();
    let activeAction = 'Navigate selected applicant/property';
    let environmentMismatch = false;
    let firstFailedResponse: Response | undefined;
    let rejectService: (error: Error) => void = () => undefined;
    const serviceFailure = new Promise<never>((_resolve, reject) => {
      rejectService = reject;
    });
    void serviceFailure.catch(() => undefined);
    const failureMessage = (): string => {
      if (!firstFailedResponse) return 'Application failure';
      if (environmentMismatch)
        return `BLOCKED: observed API host does not match ${environment.name}/${environment.tier}; no retry.`;
      return `BLOCKED: ${firstFailedResponse.request().method()} ${new URL(firstFailedResponse.url()).pathname} HTTP ${firstFailedResponse.status()}; first service failure, no retry.`;
    };
    const onResponse = (response: Response): void => {
      const url = new URL(response.url());
      if (url.pathname === '/home-api/rate/getLocation') {
        locationResponses.push({
          at: new Date().toISOString(),
          method: response.request().method(),
          host: url.hostname,
          path: url.pathname,
          status: response.status(),
        });
      }
      const isApplicationApi = /^\/(?:home-api|auto-api)\//.test(url.pathname);
      const wrongOrigin =
        isApplicationApi &&
        (![new URL(environment.uiUrl).origin, environment.apiOrigin].includes(url.origin) ||
          (url.pathname.startsWith('/home-api/') && url.origin !== environment.apiOrigin));
      if (!firstFailedResponse && isApplicationApi && (response.status() >= 400 || wrongOrigin)) {
        environmentMismatch = wrongOrigin;
        firstFailedResponse = response;
        rejectService(new Error(failureMessage()));
      }
    };
    context.page.on('response', onResponse);
    const checkpoint = async (name: string): Promise<void> => {
      if (firstFailedResponse) throw new Error(failureMessage());
      assertQaBindConfiguration(context.page.url());
      const url = new URL(context.page.url());
      observedOrigins.add(url.origin);
      await context.checkpoint(name);
      await capture.checkpoint(name);
      const component = await context.page.evaluate(
        () =>
          Array.from(
            document.querySelectorAll(
              'app-property-type,app-property-info,app-quality-grade,app-property-details,app-contact-info,app-dwelling-coverages,app-home-quote-review,app-home-payment,app-add-payment',
            ),
          )
            .find((element) => element.getClientRects().length > 0)
            ?.tagName.toLowerCase() ?? 'See checkpoint DOM',
      );
      checkpoints.push({
        checkpoint: name,
        screen: component,
        url: url.origin + url.pathname,
        action: activeAction,
        assertion:
          'Environment origin verified; CopyDOM/screenshot captured; contract assertions recorded separately by step',
        result: 'PASS',
      });
    };
    const flow = new AceHomeNavigationFlow(
      context.page,
      { checkpoint, annotate: context.annotate },
      context.recoveryGuard,
    );
    const fsa = new SoftAssertCollector(context.page, context.testInfo, this.legacyId);
    const step = async (name: string, action: string, assertion: string, work: () => Promise<void>): Promise<void> => {
      context.annotate('bind-action', `${name}: ${action}`);
      activeAction = action;
      try {
        await Promise.race([work(), serviceFailure]);
        await checkpoint(name);
        steps.push({ step: name, action, assertion, result: 'PASS', evidence: `${name}.html / ${name}.png` });
      } catch (error) {
        steps.push({
          step: name,
          action,
          assertion,
          result: 'FAIL',
          evidence: 'bind-first-failure.html / bind-first-failure.png / trace.zip',
        });
        throw error;
      }
    };
    try {
      await step(
        'bind-01-dwelling',
        'Navigate with selected applicant and property',
        'Dwelling Coverage screen reached',
        async () => {
          await flow.navigateToDwellingCoveragePage(applicant);
        },
      );
      await step('bind-02-review', 'Continue from Dwelling', 'Review Quote screen reached', async () => {
        const { AceHomeDwellingCoveragePage } = await import('../../../pages/acehome/AceHomePages.js');
        await new AceHomeDwellingCoveragePage(context.page).clickContinue();
        await flow.waitForReviewQuoteAfterDwellingContinue();
      });
      let paymentSelection:
        | Awaited<ReturnType<AceHomeNavigationFlow['continueFromReviewToPaymentSelection']>>
        | undefined;
      await step(
        'bind-03-selection',
        'Continue Additional Coverages and Just A Few More Things',
        'Payment Selection screen reached',
        async () => {
          paymentSelection = await flow.continueFromReviewToPaymentSelection(applicant);
        },
      );
      const payment = new AceHomePaymentPage(context.page);
      await step('bind-04-payment', `Select ${mode}`, 'Payment screen matches selected state branch', async () => {
        assertQaBindConfiguration(context.page.url());
        if (!paymentSelection) throw new Error('Payment Selection was not reached.');
        if (mode === 'PIF') await paymentSelection.selectPayInFullCard();
        else await paymentSelection.selectMonthlyAutoPayBank();
        await payment.assertOnPage(mode);
      });
      await step(
        'bind-05-setup',
        'Verify environment bank authorization, then open Set Up Payment',
        'Authorized bank fixture before setup; dialog and iframe present',
        async () => {
          bank = await loadQaBankFixture();
          await payment.openBankSetup();
        },
      );
      await step(
        'bind-06-add-bank',
        'Enter verified QA instrument and Add',
        'Sandbox verified and bank dialog closes',
        async () => {
          if (!bank) throw new Error('BLOCKED: environment-authorized bank fixture is missing.');
          await payment.addQaBankAccount(bank);
        },
      );
      await step(
        'bind-07-bank-details',
        'Validate added bank details',
        'Added message, icon and masked account match',
        async () => {
          if (!bank) throw new Error('BLOCKED: environment-authorized bank fixture is missing.');
          await payment.validateAddedBank(bank, fsa);
          await fsa.assertAll('Added bank validation');
        },
      );
      await step(
        'bind-08-service-charge',
        'Validate service charge',
        'Original state-specific bank service charge text',
        async () => {
          await payment.validateBankServiceCharge(row.state, fsa);
          await fsa.assertAll('Bank service charge validation');
        },
      );
      await step(
        'bind-09-footer',
        'Validate payment agreement texts',
        'Original monthly footer assertions',
        async () => {
          await payment.validateMonthlyAgreement(fsa);
          await fsa.assertAll('Pre-purchase agreement validation');
        },
      );
      let endpoint: 'CHECKOUT' | 'FINISH_DOCUMENTS' | undefined;
      await step(
        'bind-10-endpoint',
        'Complete Purchase or validate Finish Documents',
        'Original final checkout/document branch verified',
        async () => {
          endpoint = await payment.completeQaPurchase(fsa);
          await fsa.assertAll('Final checkout validation');
        },
      );
      await fsa.assertAll('Ace Home - Validate quote and bind, end-to-end.');
      if (!endpoint) throw new Error('Bind endpoint has not been verified.');
      context.annotate('bind-endpoint-verified', endpoint);
      context.annotate('assertAll-completed', this.legacyId);
    } catch (error) {
      await context.page.route('**/*', (route) => route.abort()).catch(() => undefined);
      if (firstFailedResponse) {
        const responseBody = (await firstFailedResponse.json().catch(() => ({}))) as {
          message?: string;
          errorInfo?: { exceptionName?: string; errorCode?: string };
        };
        await context.testInfo.attach('first-failed-http.json', {
          body: Buffer.from(
            JSON.stringify(
              {
                method: firstFailedResponse.request().method(),
                path: new URL(firstFailedResponse.url()).pathname,
                status: firstFailedResponse.status(),
                capturedAt: new Date().toISOString(),
                message:
                  responseBody.message === 'An error occurred while data conversion'
                    ? responseBody.message
                    : 'See restricted trace response',
                errorCode: /^ERROR\d+$/.test(responseBody.errorInfo?.errorCode ?? '')
                  ? responseBody.errorInfo?.errorCode
                  : undefined,
                exceptionName: /^[A-Za-z]+Exception$/.test(responseBody.errorInfo?.exceptionName ?? '')
                  ? responseBody.errorInfo?.exceptionName
                  : undefined,
              },
              null,
              2,
            ),
          ),
          contentType: 'application/json',
        });
      }
      await context.checkpoint('bind-first-failure').catch(() => undefined);
      const screen = await new AceHomePageClassifier(context.page).detect().catch(() => undefined);
      const lastUrl = new URL(context.page.url());
      checkpoints.push({
        checkpoint: 'bind-first-failure',
        screen: screen?.type ?? 'UNKNOWN',
        url: lastUrl.origin + lastUrl.pathname,
        action: activeAction,
        assertion: 'First failure retained; no automatic retry',
        result: 'FAIL',
      });
      context.annotate('bind-last-screen', screen?.type ?? 'UNKNOWN');
      context.annotate(
        'bind-result',
        firstFailedResponse ? (environmentMismatch ? 'BLOCKED_ENVIRONMENT' : 'BLOCKED_SERVICE') : 'FAIL',
      );
      let message = firstFailedResponse ? failureMessage() : error instanceof Error ? error.message : 'Bind failed';
      for (const value of [
        bank?.routingNumber ?? '',
        bank?.accountNumber ?? '',
        applicant.firstName,
        applicant.lastName,
        applicant.address,
        applicant.phoneNumber,
        applicant.emailAddress,
        applicant.dateOfBirth,
      ]) {
        if (value.length >= 3) message = message.split(value).join('[REDACTED]');
      }
      await context.page.close().catch(() => undefined);
      throw new Error(message);
    } finally {
      context.page.off('response', onResponse);
      await context.testInfo.attach('bind-environment.json', {
        body: Buffer.from(
          JSON.stringify(
            {
              environment: environment.name,
              tier: environment.tier,
              uiHost: new URL(environment.uiUrl).hostname,
              apiHost: new URL(environment.apiOrigin).hostname,
              observedBrowserOrigins: [...observedOrigins],
              project: context.testInfo.project.name,
              headed: context.testInfo.project.use.headless === false,
              bankFixtureVerifiedForEnvironment: bankStatus.available,
              environmentMismatch,
              getLocationResponses: locationResponses,
            },
            null,
            2,
          ),
        ),
        contentType: 'application/json',
      });
      await context.testInfo.attach('quote-bind-checkpoints.json', {
        body: Buffer.from(JSON.stringify(checkpoints, null, 2)),
        contentType: 'application/json',
      });
      await context.testInfo.attach('quote-bind-steps.json', {
        body: Buffer.from(
          JSON.stringify(
            {
              legacyId: this.legacyId,
              sourceId: row.sourceId,
              sheet: row.sheet,
              state: row.state,
              category: row.data.testCategory,
              mode,
              steps,
            },
            null,
            2,
          ),
        ),
        contentType: 'application/json',
      });
    }
  }
}
