import { readFile } from 'node:fs/promises';
import type { Page, TestInfo } from '@playwright/test';
import type { SelectedCase } from '../data/LegacyProviderSelector.js';
import type { LegacyMethodContract, LegacyTestMetadata } from './LegacyTestMetadata.js';
import { getHandlerRegistry } from './registry/HandlerCatalog.js';
import { getRecoveryGuard } from '../fixtures/health/recovery.fixture.js';
import { getHealthCheck, isHealthCheckExcludedForLegacyId } from '../fixtures/health/health-check.fixture.js';
import { ExecutionTracker } from './contracts/ExecutionTracker.js';
import type { ScenarioExecutionContext } from './handlers/ScenarioTypes.js';
import { ACE_HOME_QUOTE_BIND_LEGACY_ID } from '../data/providers/acehome/AceHomeQaBindData.js';

const aceHomeEndToEndAssertAllLegacyIds = new Set([
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testReviewQuotePagePresentmentCardHome',
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testSmokeReviewQuotePagePresentmentCardHome',
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testProdRetrieveRatedQuoteAceHome',
]);

const aceHomeReviewHealthLegacyIds = new Set([
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testReviewQuotePagePresentmentCardHome',
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testSmokeReviewQuotePagePresentmentCardHome',
]);

let contracts: Promise<Record<string, LegacyMethodContract>> | undefined;

async function loadContracts(): Promise<Record<string, LegacyMethodContract>> {
  contracts ??= readFile('migration/audit/legacy-method-contracts.json', 'utf8').then(
    (source) => JSON.parse(source) as Record<string, LegacyMethodContract>,
  );
  return contracts;
}

/**
 * Auditable execution boundary for generated tests.
 *
 * A behavioral handler must be registered for a test before the safety gate is
 * enabled. This deliberately fails closed: an unmigrated scenario can never be
 * reported as a false PASS merely because the FFQ landing page loaded.
 */
export async function executeMigratedScenario(
  page: Page,
  testInfo: TestInfo,
  legacyData: (metadata: LegacyTestMetadata) => Promise<SelectedCase[]>,
  metadata: LegacyTestMetadata,
): Promise<void> {
  if (metadata.legacyId === 'com.farmers.ffq.acehome.AceHomeEndToEndTest#testProdRetrieveRatedQuoteAceHome') {
    testInfo.skip(
      true,
      'BLOCKED: TX 116 getLocation HTTP 500, ERROR11 / DataConversionException; pendiente de investigaci\u00f3n del servicio',
    );
  }
  const contract = (await loadContracts())[metadata.legacyId];
  if (!contract) throw new Error(`Missing immutable migration contract: ${metadata.legacyId}`);

  testInfo.annotations.push(
    { type: 'legacy-id', description: metadata.legacyId },
    { type: 'legacy-source', description: `${metadata.sourceFile}:${metadata.sourceLine}` },
    { type: 'data-provider', description: metadata.dataProvider || 'none' },
  );
  await testInfo.attach('legacy-contract.json', {
    body: Buffer.from(JSON.stringify(contract, null, 2)),
    contentType: 'application/json',
  });

  const selected = await legacyData(metadata);
  await testInfo.attach('selected-fixture-rows.json', {
    body: Buffer.from(
      JSON.stringify(
        selected.map(({ source, sheet, sourceId, state }) => ({
          source,
          sheet,
          sourceId,
          state,
        })),
        null,
        2,
      ),
    ),
    contentType: 'application/json',
  });

  const handler = getHandlerRegistry().resolve(metadata.legacyId);
  if (!handler) {
    throw new Error(
      `Behavioral handler not implemented for ${metadata.legacyId}; selected ${selected.length} fixture row(s). ` +
        'No generic navigation is allowed to produce PASS.',
    );
  }
  testInfo.annotations.push({ type: 'handler-status', description: 'implemented; not runtime certified' });
  const tracker = new ExecutionTracker();
  const healthRequired = aceHomeReviewHealthLegacyIds.has(metadata.legacyId) && !isHealthCheckExcludedForLegacyId(metadata.legacyId);
  const health = healthRequired ? getHealthCheck(page) : undefined;
  if (healthRequired && !health) {
    throw new Error('Missing per-test HealthCheck fixture for AceHome Review scenario.');
  }
  const publishExecutionEvent = (): void => {
    const event = tracker.getEvents().at(-1);
    if (event) health?.observeExecutionEvent(event);
  };
  const context: ScenarioExecutionContext = {
    page,
    testInfo,
    metadata,
    contract,
    selectedCases: selected,
    tracker,
    recoveryGuard: getRecoveryGuard(page),
    checkpoint: async (name) => {
      testInfo.annotations.push({ type: 'logical-checkpoint', description: name });
      const { captureDomCheckpoint } = await import('../core/DomCheckpoint.js');
      await captureDomCheckpoint(page, testInfo, name);
      tracker.recordCheckpoint(name, true);
      publishExecutionEvent();
    },
    annotate: (type, description) => {
      testInfo.annotations.push({ type, description });
      if (health && type === 'assertAll-completed' && description === metadata.legacyId) {
        tracker.recordAssertion(metadata.legacyId, 'Original handler final assertAll completed', true, { finalOutcome: true });
        publishExecutionEvent();
      }
    },
  };
  try {
    await handler.execute(context);
  } catch (error) {
    tracker.recordError(metadata.legacyId, error instanceof Error ? error.name : 'UnknownError');
    publishExecutionEvent();
    await testInfo.attach('execution-tracker.json', {
      body: Buffer.from(
        JSON.stringify(
          { summary: tracker.getSummary(), eventTypes: tracker.getEvents().map(({ type }) => type) },
          null,
          2,
        ),
      ),
      contentType: 'application/json',
    });
    throw error;
  }
  await testInfo.attach('execution-tracker.json', {
    body: Buffer.from(
      JSON.stringify(
        { summary: tracker.getSummary(), eventTypes: tracker.getEvents().map(({ type }) => type) },
        null,
        2,
      ),
    ),
    contentType: 'application/json',
  });
  const assertAllCompleted = testInfo.annotations.some(
    (annotation) => annotation.type === 'assertAll-completed' && annotation.description === metadata.legacyId,
  );
  if (aceHomeEndToEndAssertAllLegacyIds.has(metadata.legacyId) && assertAllCompleted) return;
  if (metadata.legacyId === ACE_HOME_QUOTE_BIND_LEGACY_ID && assertAllCompleted &&
      testInfo.annotations.some((annotation) => annotation.type === 'bind-endpoint-verified' &&
        ['CHECKOUT', 'FINISH_DOCUMENTS'].includes(annotation.description ?? ''))) return;

  throw new Error(
    `Behavioral handler for ${metadata.legacyId} reached its current end without a verified assertAll completion. ` +
      'No generic handler return can produce PASS.',
  );
}
