import { mkdir, readdir, readFile, rm, writeFile } from 'node:fs/promises';
import { basename, join, relative, resolve } from 'node:path';
import ExcelJS from 'exceljs';

export const EXECUTION_STATUSES = ['PASS', 'FAILED', 'BLOCKED'] as const;
export type ExecutionStatus = (typeof EXECUTION_STATUSES)[number];

export const ROOT_CAUSES = [
  'INCONVENIENCE',
  'KNOCKOUT',
  'TRY_AGAIN',
  'TIMEOUT',
  'APPLICATION_ERROR',
  'VALIDATION_ERROR',
  'NAVIGATION_ERROR',
  'NETWORK_ERROR',
  'HTTP_ERROR',
  'BROWSER_ERROR',
  'TEST_AUTOMATION_ERROR',
  'MISSING_HANDLER',
  'MISSING_FIXTURE',
  'CONFIGURATION_ERROR',
  'UNKNOWN',
] as const;
export type RootCause = (typeof ROOT_CAUSES)[number];

export interface InventoryRow {
  readonly sequentialId: number;
  readonly specFile: string;
  readonly testClass: string;
  readonly testName: string;
  readonly legacyId: string;
  readonly productFolder: string;
  readonly sourcePath: string;
  readonly handlerName: string;
  readonly handlerRegistered: boolean;
  readonly structurallyExecutable: boolean;
  readonly structuralBlocker: string;
  readonly enabled: boolean;
  readonly skipDetected: boolean;
  readonly todoDetected: boolean;
}

export interface InventoryDocument {
  readonly summary: Readonly<Record<string, unknown>>;
  readonly tests: readonly InventoryRow[];
}

export interface RuntimeAnnotation {
  readonly type: string;
  readonly description: string;
}

export interface RuntimeEvidenceSummary {
  readonly url: string;
  readonly title: string;
  readonly heading: string;
  readonly pageClassification: string;
  readonly validationMessages: readonly string[];
}

export interface RuntimeEvidence {
  readonly testId: string;
  readonly retry: number;
  readonly title: string;
  readonly status: string;
  readonly expectedStatus: string;
  readonly pageClosed: boolean;
  readonly annotations: readonly RuntimeAnnotation[];
  readonly capturedAt: string;
  readonly pageSummary?: RuntimeEvidenceSummary;
}

export interface RuntimeResultRecord {
  readonly recordKey: string;
  readonly executionId: string;
  readonly specFile: string;
  readonly testClass: string;
  readonly testName: string;
  readonly legacyId: string;
  readonly productSuite: string;
  readonly day: string;
  readonly time: string;
  readonly error: string;
  readonly rootCause: RootCause | '';
  readonly status: ExecutionStatus;
  readonly mappedToInventory: boolean;
}

const ROOT_DIR = resolve('.');
const REPORTS_DIR = resolve(process.env.FFQ_REPORTS_DIR || resolve(ROOT_DIR, 'reports'));
const RUNTIME_RESULTS_DIR = resolve(REPORTS_DIR, 'runtime-results');
const RUNTIME_EVIDENCE_DIR = resolve(REPORTS_DIR, 'runtime-evidence');
const WORKBOOK_PATH = resolve(REPORTS_DIR, 'FFQ_Playwright_Environment_Execution_Report.xlsx');
const INVENTORY_PATH = resolve(ROOT_DIR, 'migration', 'audit', 'full-test-execution-inventory.json');
const RUN_METADATA_PATH = resolve(RUNTIME_RESULTS_DIR, 'run-metadata.json');

const HEADER_FILL = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } } as const;
const HEADER_FONT = { color: { argb: 'FFFFFFFF' }, bold: true } as const;
const STATUS_FILLS: Record<ExecutionStatus, { type: 'pattern'; pattern: 'solid'; fgColor: { argb: string } }> = {
  PASS: { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFC6EFCE' } },
  FAILED: { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFC7CE' } },
  BLOCKED: { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFE699' } },
};

function pad(value: number): string {
  return value.toString().padStart(2, '0');
}

function sanitizeSegment(value: string): string {
  return (
    value
      .replace(/[^a-zA-Z0-9._-]+/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '') || 'record'
  );
}

function executionKey(specFile: string, testName: string): string {
  return `${specFile}::${testName}`.toLowerCase();
}

function headerStyle(row: ExcelJS.Row): void {
  row.eachCell((cell) => {
    cell.fill = HEADER_FILL;
    cell.font = HEADER_FONT;
    cell.alignment = { vertical: 'middle', horizontal: 'center' };
  });
}

function autoSizeColumns(worksheet: ExcelJS.Worksheet): void {
  worksheet.columns.forEach((column) => {
    if (!column?.eachCell) return;
    let width = 12;
    column.eachCell({ includeEmpty: true }, (cell) => {
      const value = cell.value;
      const text =
        typeof value === 'object' && value && 'richText' in value ? JSON.stringify(value) : String(value ?? '');
      width = Math.max(width, Math.min(text.length + 2, 60));
    });
    column.width = width;
  });
}

function ensureStatusCellFormatting(worksheet: ExcelJS.Worksheet): void {
  for (let rowIndex = 2; rowIndex <= worksheet.rowCount; rowIndex += 1) {
    const rootCauseCell = worksheet.getCell(`I${rowIndex}`);
    const statusCell = worksheet.getCell(`J${rowIndex}`);
    statusCell.dataValidation = {
      type: 'list',
      allowBlank: false,
      formulae: ["'Lists'!$A$2:$A$4"],
    };
    rootCauseCell.dataValidation = {
      type: 'list',
      allowBlank: true,
      formulae: [`'Lists'!$B$2:$B$${ROOT_CAUSES.length + 1}`],
    };
    const status = statusCell.value as ExecutionStatus | null;
    if (status && status in STATUS_FILLS) {
      statusCell.fill = STATUS_FILLS[status];
    }
  }
}

function formatDay(date: Date): string {
  return `${pad(date.getMonth() + 1)}/${pad(date.getDate())}/${date.getFullYear()}`;
}

function formatTime(date: Date): string {
  const hours = date.getHours();
  const normalized = hours % 12 || 12;
  const suffix = hours >= 12 ? 'PM' : 'AM';
  return `${pad(normalized)}:${pad(date.getMinutes())}:${pad(date.getSeconds())} ${suffix}`;
}

export function generateExecutionId(now = new Date()): string {
  return `FFQ-${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
}

export function inventoryLookupKey(specFile: string, testName: string): string {
  return executionKey(specFile.replace(/\\/g, '/'), testName.trim());
}

export function specFileFromTestLocation(testFile: string): string {
  return relative(ROOT_DIR, resolve(testFile)).replace(/\\/g, '/');
}

export function runtimeEvidencePath(testId: string, retry: number): string {
  return join(RUNTIME_EVIDENCE_DIR, `${sanitizeSegment(testId)}-r${retry}.json`);
}

export async function writeRuntimeEvidence(evidence: RuntimeEvidence): Promise<void> {
  await mkdir(RUNTIME_EVIDENCE_DIR, { recursive: true });
  await writeFile(
    runtimeEvidencePath(evidence.testId, evidence.retry),
    JSON.stringify(evidence, null, 2) + '\n',
    'utf8',
  );
}

export async function readRuntimeEvidence(testId: string, retry: number): Promise<RuntimeEvidence | undefined> {
  try {
    const source = await readFile(runtimeEvidencePath(testId, retry), 'utf8');
    return JSON.parse(source) as RuntimeEvidence;
  } catch {
    return undefined;
  }
}

export async function prepareReportRun(executionId: string): Promise<void> {
  await mkdir(REPORTS_DIR, { recursive: true });
  await rm(RUNTIME_RESULTS_DIR, { recursive: true, force: true });
  await rm(RUNTIME_EVIDENCE_DIR, { recursive: true, force: true });
  await mkdir(RUNTIME_RESULTS_DIR, { recursive: true });
  await mkdir(RUNTIME_EVIDENCE_DIR, { recursive: true });
  await writeFile(
    RUN_METADATA_PATH,
    JSON.stringify({ executionId, startedAt: new Date().toISOString() }, null, 2) + '\n',
    'utf8',
  );
}

export async function loadInventory(): Promise<InventoryDocument> {
  const source = await readFile(INVENTORY_PATH, 'utf8');
  return JSON.parse(source) as InventoryDocument;
}

export async function writeRuntimeResultRecord(recordKey: string, record: RuntimeResultRecord): Promise<void> {
  await mkdir(RUNTIME_RESULTS_DIR, { recursive: true });
  await writeFile(
    join(RUNTIME_RESULTS_DIR, `${sanitizeSegment(recordKey)}.json`),
    JSON.stringify(record, null, 2) + '\n',
    'utf8',
  );
}

export async function readRuntimeResultRecords(): Promise<RuntimeResultRecord[]> {
  const entries = await readdir(RUNTIME_RESULTS_DIR, { withFileTypes: true }).catch(() => []);
  const rows: RuntimeResultRecord[] = [];
  for (const entry of entries) {
    if (!entry.isFile() || !entry.name.endsWith('.json') || entry.name === basename(RUN_METADATA_PATH)) continue;
    const source = await readFile(join(RUNTIME_RESULTS_DIR, entry.name), 'utf8');
    rows.push(JSON.parse(source) as RuntimeResultRecord);
  }
  return rows.sort(
    (left, right) => left.testClass.localeCompare(right.testClass) || left.testName.localeCompare(right.testName),
  );
}

export async function readRunExecutionId(): Promise<string | undefined> {
  try {
    const source = await readFile(RUN_METADATA_PATH, 'utf8');
    const metadata = JSON.parse(source) as { executionId?: string };
    return metadata.executionId;
  } catch {
    return undefined;
  }
}

function tableColumns(headers: readonly string[]): { name: string; filterButton: boolean }[] {
  return headers.map((name) => ({ name, filterButton: true }));
}

function addExecutionResultsSheet(workbook: ExcelJS.Workbook, rows: readonly RuntimeResultRecord[]): void {
  const worksheet = workbook.addWorksheet('Execution Results', {
    views: [{ state: 'frozen', ySplit: 1 }],
  });
  const headers = [
    'Execution ID',
    'Test Class',
    'Test Name',
    'Legacy ID',
    'Product / Suite',
    'Day',
    'Time',
    'Error',
    'Root Cause',
    'Status',
  ] as const;
  const tableRows = rows.map((row) => [
    row.executionId,
    row.testClass,
    row.testName,
    row.legacyId,
    row.productSuite,
    row.day,
    row.time,
    row.error,
    row.rootCause,
    row.status,
  ]);

  worksheet.addTable({
    name: 'ExecutionResultsTable',
    ref: 'A1',
    headerRow: true,
    style: {
      theme: 'TableStyleMedium2',
      showRowStripes: true,
    },
    columns: tableColumns(headers),
    rows: tableRows,
  });

  headerStyle(worksheet.getRow(1));
  worksheet.getColumn('H').alignment = { wrapText: true, vertical: 'top' };
  worksheet.getColumn('A').width = 22;
  worksheet.getColumn('B').width = 34;
  worksheet.getColumn('C').width = 42;
  worksheet.getColumn('D').width = 68;
  worksheet.getColumn('E').width = 20;
  worksheet.getColumn('F').width = 14;
  worksheet.getColumn('G').width = 14;
  worksheet.getColumn('H').width = 64;
  worksheet.getColumn('I').width = 24;
  worksheet.getColumn('J').width = 14;
  ensureStatusCellFormatting(worksheet);
  autoSizeColumns(worksheet);
}

function addSummarySheet(
  workbook: ExcelJS.Workbook,
  inventory: readonly InventoryRow[],
  rows: readonly RuntimeResultRecord[],
  executionId: string,
): void {
  const worksheet = workbook.addWorksheet('Summary');
  worksheet.views = [{ state: 'frozen', ySplit: 2 }];
  worksheet.addRow(['Execution ID', executionId]);
  worksheet.addRow(['Metric', 'Count', 'Percent']);
  headerStyle(worksheet.getRow(2));

  const total = inventory.length;
  const executed = rows.length;
  const pass = rows.filter((row) => row.status === 'PASS').length;
  const failed = rows.filter((row) => row.status === 'FAILED').length;
  const blocked = rows.filter((row) => row.status === 'BLOCKED').length;
  const executedInventoryKeys = new Set(
    rows.filter((row) => row.mappedToInventory).map((row) => inventoryLookupKey(row.specFile, row.testName)),
  );
  const notExecuted = Math.max(total - executedInventoryKeys.size, 0);

  const summaryRows = [
    ['Total', total, '100.00%'],
    ['Executed', executed, total === 0 ? '0.00%' : `${((executed / total) * 100).toFixed(2)}%`],
    ['Pass', pass, executed === 0 ? '0.00%' : `${((pass / executed) * 100).toFixed(2)}%`],
    ['Failed', failed, executed === 0 ? '0.00%' : `${((failed / executed) * 100).toFixed(2)}%`],
    ['Blocked', blocked, executed === 0 ? '0.00%' : `${((blocked / executed) * 100).toFixed(2)}%`],
    ['Not Executed', notExecuted, total === 0 ? '0.00%' : `${((notExecuted / total) * 100).toFixed(2)}%`],
  ];

  for (const row of summaryRows) worksheet.addRow(row);
  worksheet.addRow([]);
  worksheet.addRow(['Root Cause', 'Count']);
  headerStyle(worksheet.getRow(10));

  for (const rootCause of ROOT_CAUSES) {
    const count = rows.filter((row) => row.rootCause === rootCause).length;
    worksheet.addRow([rootCause, count]);
  }

  autoSizeColumns(worksheet);
}

function addInventorySheet(workbook: ExcelJS.Workbook, inventory: readonly InventoryRow[]): void {
  const worksheet = workbook.addWorksheet('Test Inventory', {
    views: [{ state: 'frozen', ySplit: 1 }],
  });
  const firstRow = inventory[0];
  const headers = firstRow ? Object.keys(firstRow) : [];
  worksheet.addRow(headers);
  headerStyle(worksheet.getRow(1));
  for (const row of inventory) {
    worksheet.addRow(headers.map((header) => String(row[header as keyof InventoryRow] ?? '')));
  }
  if (headers.length > 0) {
    worksheet.addTable({
      name: 'InventoryTable',
      ref: 'A1',
      headerRow: true,
      style: { theme: 'TableStyleMedium4', showRowStripes: true },
      columns: tableColumns(headers),
      rows: inventory.map((row) => headers.map((header) => String(row[header as keyof InventoryRow] ?? ''))),
    });
  }
  autoSizeColumns(worksheet);
}

function addListsSheet(workbook: ExcelJS.Workbook): void {
  const worksheet = workbook.addWorksheet('Lists');
  worksheet.addRow(['Status Values', 'Root Cause Values']);
  headerStyle(worksheet.getRow(1));
  const maxRows = Math.max(EXECUTION_STATUSES.length, ROOT_CAUSES.length);
  for (let index = 0; index < maxRows; index += 1) {
    worksheet.addRow([EXECUTION_STATUSES[index] ?? '', ROOT_CAUSES[index] ?? '']);
  }
  autoSizeColumns(worksheet);
}

export async function rebuildEnvironmentExecutionWorkbook(executionId?: string, outputPath?: string): Promise<string> {
  const inventory = await loadInventory();
  const runtimeResults = await readRuntimeResultRecords();
  const resolvedExecutionId = executionId ?? (await readRunExecutionId()) ?? generateExecutionId();

  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'GitHub Copilot';
  workbook.created = new Date();
  workbook.modified = new Date();

  addExecutionResultsSheet(workbook, runtimeResults);
  addSummarySheet(workbook, inventory.tests, runtimeResults, resolvedExecutionId);
  addInventorySheet(workbook, inventory.tests);
  addListsSheet(workbook);

  const finalPath = outputPath ?? WORKBOOK_PATH;
  await mkdir(resolve(finalPath, '..'), { recursive: true });
  await workbook.xlsx.writeFile(finalPath);
  return finalPath;
}

export function buildRuntimeRecord(params: {
  recordKey: string;
  executionId: string;
  specFile: string;
  testClass: string;
  testName: string;
  legacyId: string;
  productSuite: string;
  timestamp?: Date;
  error: string;
  rootCause: RootCause | '';
  status: ExecutionStatus;
  mappedToInventory: boolean;
}): RuntimeResultRecord {
  const timestamp = params.timestamp ?? new Date();
  return {
    recordKey: params.recordKey,
    executionId: params.executionId,
    specFile: params.specFile,
    testClass: params.testClass,
    testName: params.testName,
    legacyId: params.legacyId,
    productSuite: params.productSuite,
    day: formatDay(timestamp),
    time: formatTime(timestamp),
    error: params.error,
    rootCause: params.rootCause,
    status: params.status,
    mappedToInventory: params.mappedToInventory,
  };
}
