import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import type { TestInfo } from '@playwright/test';
import { selectLegacyCases, type SelectedCase } from '../../data/LegacyProviderSelector.js';
import type { LegacyTestMetadata } from '../../migration/LegacyTestMetadata.js';
import { ACE_HOME_QUOTE_BIND_LEGACY_ID, selectAceHomeQuoteBindCase } from '../../data/providers/acehome/AceHomeQaBindData.js';

export type Provider = (metadata: LegacyTestMetadata) => Promise<SelectedCase[]>;

const aceHomeEndToEndTxRows: Record<string, {
  provider: string;
  sheet: string;
  sourceId: string;
  category?: string;
}> = {
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testReviewQuotePagePresentmentCardHome': {
    provider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
    sheet: 'ApplicantHome',
    sourceId: '217',
  },
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testSmokeReviewQuotePagePresentmentCardHome': {
    provider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
    sheet: 'ApplicantHome',
    sourceId: '217',
  },
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testProdRetrieveRatedQuoteAceHome': {
    provider: 'AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER',
    sheet: 'PageValidationApplicantAceHome',
    sourceId: '116',
    category: 'Bind validation',
  },
};

export async function selectAceHomeEndToEndTxCase(metadata: LegacyTestMetadata, seed: string): Promise<SelectedCase[]> {
  const expected = aceHomeEndToEndTxRows[metadata.legacyId];
  if (!expected) throw new Error(`TX_DIAGNOSTIC_SELECTION_UNSUPPORTED: ${metadata.legacyId}`);
  if (metadata.dataProvider !== expected.provider || metadata.dataProviderClass !== 'AceHomeDataProviders.class') {
    throw new Error(`TX_DIAGNOSTIC_PROVIDER_MISMATCH: ${metadata.legacyId}`);
  }
  if (expected.category && !metadata.annotation.includes('suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION')) {
    throw new Error(`TX_DIAGNOSTIC_CATEGORY_CONTRACT_MISMATCH: ${metadata.legacyId}`);
  }
  if (metadata.legacyId.endsWith('#testSmokeReviewQuotePagePresentmentCardHome') &&
      !metadata.annotation.includes('EXCLUDED_STATES, values = {CA,LA,MA,MS,NC}')) {
    throw new Error(`TX_DIAGNOSTIC_STATE_FILTER_CONTRACT_MISMATCH: ${metadata.legacyId}`);
  }

  const selected = await selectLegacyCases(
    { ...metadata, testName: `row=${expected.sourceId}` },
    { seed, environment: process.env.TEST_ENV || 'MA11', states: 'TX' },
  );
  if (selected.length !== 1) throw new Error(`TX_DIAGNOSTIC_CARDINALITY_MISMATCH: ${metadata.legacyId}`);
  const [row] = selected;
  if (
    row?.source !== 'AceHomeTestData' || row.sheet !== expected.sheet || row.sourceId !== expected.sourceId ||
    row.state !== 'TX' || String(row.data.id) !== expected.sourceId || row.data.stateCode !== 'TX' ||
    (expected.category && row.data.testCategory !== expected.category)
  ) {
    throw new Error(`TX_DIAGNOSTIC_ROW_CONTRACT_MISMATCH: ${metadata.legacyId}`);
  }
  const phone = String(row.data.phoneNumber ?? '').replace(/\D/g, '');
  if (
    !String(row.data.address ?? '').trim() || !String(row.data.city ?? '').trim() ||
    !/^7[5-9]\d{3}$/.test(String(row.data.zipCode ?? '')) ||
    !String(row.data.yearBuilt ?? '').trim() || !String(row.data.squareFeet ?? '').trim() ||
    !/^[2-9]\d{2}[2-9]\d{6}$/.test(phone)
  ) {
    throw new Error(`TX_DIAGNOSTIC_INCOMPLETE_ROW: ${metadata.legacyId}`);
  }
  if (expected.category && !['true', 'yes', 'y', '1'].includes(String(row.data.homeVisible ?? '').trim().toLowerCase())) {
    throw new Error(`TX_DIAGNOSTIC_HOME_VISIBILITY_MISSING: ${metadata.legacyId}`);
  }
  const hydrant = String(row.data.fireHydrant ?? '').trim().toLowerCase();
  const hydrantIsNo = ['', 'false', 'no', 'n', '0'].includes(hydrant);
  const homeIsVisible = ['true', 'yes', 'y', '1'].includes(String(row.data.homeVisible ?? '').trim().toLowerCase());
  const columns = JSON.parse(await readFile(resolve('src/data/catalog/columns.json'), 'utf8')) as {
    AceHomeTestData?: Record<string, readonly string[]>;
  };
  const hasSecondaryHeatingColumn = columns.AceHomeTestData?.[expected.sheet]?.includes('secondaryHeatingSource') ?? false;
  if (
    expected.category && hydrantIsNo && homeIsVisible &&
    !hasSecondaryHeatingColumn
  ) {
    throw new Error(`TX_DIAGNOSTIC_SECONDARY_HEATING_COLUMN_MISSING: ${metadata.legacyId}`);
  }
  return selected;
}

/** A separate cache and deterministic data seed for each Playwright test. */
export function providerFor(owner: string, testInfo: TestInfo): Provider {
  const cache = new Map<string, Promise<SelectedCase[]>>();
  return (metadata) => {
    const actual = metadata.dataProviderClass.replace(/\.class$/, '');
    if (actual !== owner) {
      throw new Error(`Wrong fixture for ${metadata.legacyId}: expected ${owner}, got ${actual || 'none'}`);
    }
    let selected = cache.get(metadata.legacyId);
    if (!selected) {
      const seed = process.env.FFQ_DATA_SEED || testInfo.testId;
      const expected = aceHomeEndToEndTxRows[metadata.legacyId];
      selected = metadata.legacyId === ACE_HOME_QUOTE_BIND_LEGACY_ID
        ? selectAceHomeQuoteBindCase(metadata, seed)
        : process.env.ACEHOME_ENDTOEND_TX_ROW_OVERRIDE === '1' && expected
        ? selectAceHomeEndToEndTxCase(metadata, seed)
        : selectLegacyCases(metadata, {
            seed,
            environment: process.env.TEST_ENV || 'MA11',
            ...(process.env.FFQ_DATA_STATES ? { states: process.env.FFQ_DATA_STATES } : {}),
            ...(process.env.FFQ_DATA_SCENARIOS ? { scenarios: process.env.FFQ_DATA_SCENARIOS } : {}),
          });
      cache.set(metadata.legacyId, selected);
    }
    return selected;
  };
}
