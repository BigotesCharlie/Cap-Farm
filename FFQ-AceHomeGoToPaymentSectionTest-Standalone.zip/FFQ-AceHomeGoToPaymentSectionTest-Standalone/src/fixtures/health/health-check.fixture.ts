import { test as base, type Page } from '@playwright/test';
import { HealthCheck } from '../../core/HealthCheck.js';
import { RecoveryGuard } from '../../core/RecoveryGuard.js';

const activeHealthChecks = new WeakMap<Page, HealthCheck>();
const healthCheckExcludedLegacyIds = new Set([
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testReviewQuotePagePresentmentCardHome',
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testSmokeReviewQuotePagePresentmentCardHome',
]);

export function isHealthCheckExcludedForLegacyId(legacyId: string): boolean {
  return healthCheckExcludedLegacyIds.has(legacyId);
}

export function getHealthCheck(page: Page): HealthCheck | undefined {
  return activeHealthChecks.get(page);
}

export const test = base.extend<{ healthCheck: HealthCheck; recoveryGuard: RecoveryGuard }>({
  healthCheck: [
    async ({ page, recoveryGuard }, use, testInfo) => {
      const health = new HealthCheck(page, testInfo, recoveryGuard);
      const owner = 'com.farmers.ffq.acehome.AceHomeEndToEndTest';
      const legacyId = `${owner}#${testInfo.title}`;
      if (testInfo.titlePath.includes(owner) && isHealthCheckExcludedForLegacyId(legacyId)) {
        testInfo.annotations.push({ type: 'healthcheck-policy', description: 'temporary exact-ID exclusion; Recovery remains active' });
        await testInfo.attach('healthcheck-policy.json', {
          body: Buffer.from(JSON.stringify({ legacyId, listenersInstalled: false, closingChecksEnabled: false,
            recoveryFixtureIndependent: true }, null, 2)), contentType: 'application/json',
        });
        await use(health);
        return;
      }
      activeHealthChecks.set(page, health);
      health.start();
      try {
        await use(health);
      } finally {
        try {
          await health.stop();
        } finally {
          activeHealthChecks.delete(page);
        }
      }
    },
    { auto: true },
  ],
});
