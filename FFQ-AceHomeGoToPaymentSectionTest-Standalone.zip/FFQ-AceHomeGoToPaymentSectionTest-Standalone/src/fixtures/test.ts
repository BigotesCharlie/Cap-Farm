import { promises as fs } from 'node:fs';
import { mergeTests, expect } from '@playwright/test';
import { env } from '../config/env.js';
import { applyGlobalBrowserZoom, captureAutoDebuggingEvidence, collectPageSummary } from '../core/BrowserUi.js';
import { writeRuntimeEvidence } from '../reporting/EnvironmentExecutionReport.js';
import { safePageContent } from '../core/DomCheckpoint.js';
import { sanitizeTextEvidence } from '../core/EvidenceSanitizer.js';
import { test as aceHome } from './data/ace-home.fixture.js';
import { test as auto } from './data/auto.fixture.js';
import { test as bundle } from './data/bundle.fixture.js';
import { test as sqlAuto } from './data/sql-auto.fixture.js';
import { test as classic } from './data/classic.fixture.js';
import { test as legacyHome } from './data/legacy-home.fixture.js';
import { test as inline } from './data/inline.fixture.js';
import { test as reference } from './data/reference.fixture.js';
import { test as recovery } from './health/recovery.fixture.js';
import { test as health } from './health/health-check.fixture.js';

/** One import for specs; each DataProvider is independently defined and lazy. */
export const test = mergeTests(
  aceHome,
  auto,
  bundle,
  sqlAuto,
  classic,
  legacyHome,
  inline,
  reference,
  recovery,
  health,
);

test.beforeEach(async ({ page }) => {
  await applyGlobalBrowserZoom(page, 0.75);
});

test.afterEach(async ({ page }, testInfo) => {
  const pageClosed = page.isClosed();
  const pageSummary = pageClosed ? undefined : await collectPageSummary(page).catch(() => undefined);
  await writeRuntimeEvidence(
    sanitizeTextEvidence({
      testId: testInfo.testId,
      retry: testInfo.retry,
      title: testInfo.title,
      status: testInfo.status ?? 'unknown',
      expectedStatus: testInfo.expectedStatus,
      pageClosed,
      annotations: testInfo.annotations.map(({ type, description }) => ({ type, description: description ?? '' })),
      capturedAt: new Date().toISOString(),
      ...(pageSummary ? { pageSummary } : {}),
    }) as Parameters<typeof writeRuntimeEvidence>[0],
  );
  if (pageClosed) return;
  const dom = await safePageContent(page).catch(() => '');
  if (dom) {
    const path = testInfo.outputPath('final-dom.html');
    await fs.writeFile(path, dom, 'utf8');
    await testInfo.attach('final-dom', { path, contentType: 'text/html' });
  }
  if (testInfo.status !== testInfo.expectedStatus) {
    await captureAutoDebuggingEvidence(page, testInfo, 'after-each');
    if (env.FFQ_KEEP_BROWSER_OPEN) await page.pause();
  }
});

export { expect };
