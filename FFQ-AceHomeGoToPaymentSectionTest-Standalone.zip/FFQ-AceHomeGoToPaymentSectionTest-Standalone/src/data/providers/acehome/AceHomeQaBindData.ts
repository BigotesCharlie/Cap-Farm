import { readFile } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import { env } from '../../../config/env.js';
import { selectLegacyCases, type SelectedCase } from '../../LegacyProviderSelector.js';
import type { LegacyTestMetadata } from '../../../migration/LegacyTestMetadata.js';

export const ACE_HOME_QUOTE_BIND_LEGACY_ID =
  'com.farmers.ffq.acehome.AceHomeGoToPaymentSectionTest#testQuoteAndBindHomeLob';

export interface QaBankFixture {
  readonly routingNumber: string;
  readonly accountNumber: string;
  readonly source: string;
}

export function getAceHomeBindEnvironment(): {
  name: 'MA11' | 'RA11';
  tier: 'QA' | 'UAT';
  uiUrl: string;
  apiOrigin: string;
} {
  const name = env.TEST_ENV.toUpperCase();
  if (!['MA11', 'RA11'].includes(name) || env.FFQ_ALLOW_PRODUCTION_EXECUTION) {
    throw new Error('BLOCKED: bind requires MA11/QA or RA11/UAT with production execution disabled.');
  }
  const config = JSON.parse(readFileSync('config/legacy-master/properties.json', 'utf8')) as {
    environment: Record<string, { uri?: string; uri_hqm?: string }>;
  };
  const entry = config.environment[name];
  if (!entry?.uri || !entry.uri_hqm) {
    throw new Error(`BLOCKED: properties.environment.${name}.uri and uri_hqm are required.`);
  }
  if (new URL(env.FFQ_BASE_URL).origin !== new URL(entry.uri).origin) {
    throw new Error(`BLOCKED: FFQ_BASE_URL must match properties.environment.${name}.uri.`);
  }
  return {
    name: name as 'MA11' | 'RA11',
    tier: name === 'RA11' ? 'UAT' : 'QA',
    uiUrl: entry.uri,
    apiOrigin: new URL(entry.uri_hqm).origin,
  };
}

export function assertQaBindConfiguration(url = env.FFQ_BASE_URL): void {
  const expected = getAceHomeBindEnvironment();
  const parsed = new URL(url);
  if (parsed.protocol !== 'https:' || ![new URL(expected.uiUrl).origin, expected.apiOrigin].includes(parsed.origin)) {
    throw new Error(`BLOCKED: browser/API host does not match ${expected.name}/${expected.tier} configuration.`);
  }
}

export function getBindBankFixtureStatus(): { available: boolean; source: string; reason?: string } {
  const environment = getAceHomeBindEnvironment();
  if (environment.name === 'RA11') {
    return {
      available: false,
      source: 'No RA11-authorized bank fixture reference in repository configuration',
      reason:
        'BLOCKED: RA11 bank test instrument is not verified; stop before Set Up Payment. MA11 instrument is not authorized for UAT.',
    };
  }
  return { available: true, source: 'AutoTestData/payments: shared nine-row QA instrument' };
}

export async function loadQaBankFixture(): Promise<QaBankFixture> {
  assertQaBindConfiguration();
  const status = getBindBankFixtureStatus();
  if (!status.available) throw new Error(status.reason);
  const catalog = JSON.parse(await readFile('src/data/catalog/AutoTestData.json', 'utf8')) as {
    payments: Array<{ paymentMethod?: string; routingNumber?: string; bankAccountNumber?: string }>;
  };
  const bankRows = catalog.payments.filter(
    (row) => row.paymentMethod === 'Bank Account' && row.routingNumber && row.bankAccountNumber,
  );
  const pairs = new Set(bankRows.map((row) => `${row.routingNumber}:${row.bankAccountNumber}`));
  if (bankRows.length !== 9 || pairs.size !== 1) {
    throw new Error('BLOCKED: shared repository QA bank fixture provenance changed; review required.');
  }
  const routingNumber = String(bankRows[0]!.routingNumber);
  const accountNumber = String(bankRows[0]!.bankAccountNumber);
  if (!/^\d{9}$/.test(routingNumber) || !/^\d{10}$/.test(accountNumber)) {
    throw new Error('BLOCKED: repository bank fixture has an invalid shape.');
  }
  return Object.freeze({
    routingNumber,
    accountNumber,
    source: 'AutoTestData/payments: shared nine-row QA instrument',
  });
}

export async function selectAceHomeQuoteBindCase(metadata: LegacyTestMetadata, seed: string): Promise<SelectedCase[]> {
  assertQaBindConfiguration();
  const sourceId = process.env.ACEHOME_QUOTE_BIND_SOURCE_ID;
  const state = process.env.FFQ_DATA_STATES;
  if (
    metadata.legacyId !== ACE_HOME_QUOTE_BIND_LEGACY_ID ||
    metadata.dataProvider !== 'AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER' ||
    metadata.dataProviderClass !== 'AceHomeDataProviders.class' ||
    !metadata.annotation.includes('CATEGORY_BIND_VALIDATION') ||
    !metadata.annotation.includes('values = {CA,LA,MA,MS,NC}') ||
    !sourceId ||
    !/^\d+$/.test(sourceId) ||
    !state ||
    !/^[A-Z]{2}$/.test(state)
  ) {
    throw new Error('BLOCKED: quote/bind requires exact provider metadata, source ID and one explicit state.');
  }
  const rows = await selectLegacyCases(
    { ...metadata, testName: `row=${sourceId}` },
    {
      seed,
      environment: env.TEST_ENV,
      states: state,
    },
  );
  const row = rows[0];
  if (
    rows.length !== 1 ||
    row?.source !== 'AceHomeTestData' ||
    row.sheet !== 'PageValidationApplicantAceHome' ||
    row.sourceId !== sourceId ||
    row.state !== state ||
    String(row.data.id) !== sourceId ||
    row.data.testCategory !== 'Bind validation' ||
    row.data.stateCode !== state ||
    !['address', 'city', 'zipCode', 'yearBuilt', 'squareFeet', 'phoneNumber', 'dateOfBirth', 'gender'].every((key) =>
      String(row.data[key] ?? '').trim(),
    )
  ) {
    throw new Error('BLOCKED: quote/bind must select exactly one complete, eligible applicant/property row.');
  }
  return rows;
}
