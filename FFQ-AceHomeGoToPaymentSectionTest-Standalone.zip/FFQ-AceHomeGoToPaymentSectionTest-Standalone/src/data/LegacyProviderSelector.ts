import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import type { LegacyTestMetadata } from '../migration/LegacyTestMetadata.js';
import { materializeRow, rawRows, type DataRecord } from './FixtureCatalog.js';
import { prepareJavaApplicant } from './LegacyApplicantTransforms.js';

export type SelectedCase<T extends DataRecord = DataRecord> = Readonly<{
  source: string;
  sheet: string;
  sourceId: string;
  state: string;
  data: T;
}>;

export class FixtureSelectionError extends Error {
  public override readonly name = 'FixtureSelectionError';
}

type CatalogRef = Readonly<{ book: string; sheet: string; mode?: 'one' | 'perState' | 'all' }>;
export type SelectionOptions = Readonly<{ seed: string; environment: string; states?: string; scenarios?: string }>;

let constantsCache: Promise<Record<string, Record<string, string>>> | undefined;
let statesCache: Promise<Record<string, string[]>> | undefined;
async function jsonFile<T>(name: string): Promise<T> {
  return JSON.parse(await readFile(resolve('src/data/catalog', name), 'utf8')) as T;
}
async function constants(): Promise<Record<string, Record<string, string>>> {
  constantsCache ??= jsonFile('provider-constants.json');
  return constantsCache;
}
async function stateLists(): Promise<Record<string, string[]>> {
  statesCache ??= jsonFile('state-support.json');
  return statesCache;
}

function random(seed: string): () => number {
  let value = 2166136261;
  for (const char of seed) value = Math.imul(value ^ char.charCodeAt(0), 16777619);
  return () => {
    value += 0x6d2b79f5;
    let next = value;
    next = Math.imul(next ^ (next >>> 15), next | 1);
    next ^= next + Math.imul(next ^ (next >>> 7), next | 61);
    return ((next ^ (next >>> 14)) >>> 0) / 4294967296;
  };
}

function pick<T>(values: readonly T[], rng: () => number, context: string): T {
  if (!values.length) throw new FixtureSelectionError(`No eligible fixture rows: ${context}`);
  return values[Math.floor(rng() * values.length)]!;
}

function shuffled<T>(values: readonly T[], rng: () => number): T[] {
  const result = [...values];
  for (let index = result.length - 1; index > 0; index--) {
    const other = Math.floor(rng() * (index + 1));
    [result[index], result[other]] = [result[other]!, result[index]!];
  }
  return result;
}

function stateOf(row: DataRecord): string {
  return String(row.stateCode ?? row.state ?? row.stateAbb ?? '')
    .trim()
    .toUpperCase();
}

function sourceId(row: DataRecord): string {
  return String(row.applicantId ?? row.id ?? row.householdNumber ?? row.stateCode ?? 'unidentified');
}

async function attributes(annotation: string): Promise<Map<string, string[]>> {
  const result = new Map<string, string[]>();
  for (const match of annotation.matchAll(
    /@CustomAttribute\(name\s*=\s*("[^"]*"|[\w.]+)(?:,\s*values\s*=\s*(\{[^}]*\}|"[^"]*"|[\w.]+))?\s*\)/g,
  )) {
    const name = await resolveConstant(match[1]!);
    const expressions = (match[2] ?? '').replace(/^\{|\}$/g, '').match(/"[^"]*"|[\w.]+/g) ?? [];
    result.set(name, await Promise.all(expressions.map(resolveConstant)));
  }
  return result;
}

async function resolveConstant(expression: string): Promise<string> {
  if (expression.startsWith('"') && expression.endsWith('"')) return JSON.parse(expression) as string;
  const match = /^(\w+)\.(\w+)$/.exec(expression);
  if (!match) {
    if (expression === 'ONE_APPLICANT_PER_STATE') return 'OneApplicantPerState';
    return expression;
  }
  return (await constants())[match[1]!]?.[match[2]!] ?? match[2]!;
}

function sourceFor(metadata: LegacyTestMetadata): CatalogRef {
  const provider = metadata.dataProvider.split('.').pop() ?? '';
  const owner = metadata.dataProviderClass.replace(/\.class$/, '');
  if (!provider) throw new FixtureSelectionError(`No DataProvider for ${metadata.legacyId}`);
  if (owner === 'AceHomeDataProviders') {
    return {
      book: 'AceHomeTestData',
      sheet: provider === 'APPLICANT_ACE_HOME_DATA_PROVIDER' ? 'ApplicantHome' : 'PageValidationApplicantAceHome',
      mode:
        provider === 'APPLICANT_ACE_HOME_DATA_PROVIDER'
          ? 'all'
          : provider === 'ENVIRONMENT_STABILITY_DATA_PROVIDER'
            ? 'perState'
            : 'one',
    };
  }
  if (owner === 'AceBundleDataProviders') return { book: 'OneUIAutoTestData', sheet: 'applicant', mode: 'all' };
  if (owner === 'AutoDataProviders') {
    if (provider === 'AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER')
      return { book: 'OneUIAutoTestData', sheet: 'pageValidationApplicant', mode: 'all' };
    if (provider === 'RANDOM_ADPF_APPLICANT_DATA_PROVIDER')
      return { book: 'OneUIAutoTestData', sheet: 'ADPFApplicant', mode: 'one' };
    if (provider === 'BIND_ADPF_APPLICANT_DATA_PROVIDER')
      return { book: 'OneUIAutoTestData', sheet: 'bindOneUIApplicant' };
    if (provider === 'ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER')
      return { book: 'OneUIAutoTestData', sheet: 'ADPFApplicantVehicleDriverNum', mode: 'one' };
    if (provider === 'AUTO_APPLICANT_DATA_PROVIDER') return { book: 'OneUIAutoTestData', sheet: 'applicant' };
  }
  if (owner === 'SqlDataProviders') {
    const sheets: Record<string, string> = {
      STATES_DATA_PROVIDER_NAME: 'stateValidation',
      AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER: 'pageValidationApplicant',
      AUTO_APPLICANT_DATA_PROVIDER: 'applicant',
      AUTO_APPLICANT_SAVE_AND_RETRIEVE_DATA_PROVIDER: 'retrieveQuoteApplicant',
      AUTO_APPLICANT_COMMON_DATA_PROVIDER: 'applicantTest',
      TEST_AUTO_APPLICANT_DATA_PROVIDER: 'testApplicant',
      ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER: 'applicantBVT',
      BVT_AUTO_APPLICANT_DATA_PROVIDER: 'applicantBVT',
      BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER: 'applicantBW',
      JENKINS_AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER: 'pageValidationApplicant',
      JENKINS_AUTO_APPLICANT_SMOKE_TEST_DATA_PROVIDER: 'applicantBVT',
      JENKINS_AUTO_APPLICANT_QUOTE_SCENARIOS_DATA_PROVIDER: 'applicant',
      HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER: 'applicant',
    };
    if (sheets[provider]) return { book: 'AutoTestData', sheet: sheets[provider]! };
  }
  if (owner === 'DataProviders') {
    if (
      /^APPLICANT_HOME_|^GET_RETRIEVE_QUOTE_APPLICANT_HOME$|^MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER$/.test(provider)
    ) {
      return {
        book: 'HomeTestData',
        sheet: provider === 'GET_RETRIEVE_QUOTE_APPLICANT_HOME' ? 'GetRetrieveQuoteHome' : 'ApplicantHome',
      };
    }
    if (provider === 'APEX_HQM_DATA_PROVIDER') return { book: 'HQMApexTestData', sheet: 'ApexHQM' };
    if (provider.includes('HQM')) return { book: 'HQMTestData', sheet: 'ApplicantHome' };
    if (provider.includes('LIFE')) return { book: 'LifeTestData', sheet: 'ApplicantLife' };
    if (provider.includes('BUSINESS')) return { book: 'BusinessTestData', sheet: 'businessApplicant' };
    if (provider === 'ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER')
      return { book: 'AceHomeTestData', sheet: 'ApplicantHome' };
  }
  throw new FixtureSelectionError(`Unmapped Java DataProvider ${owner}.${provider} (${metadata.legacyId})`);
}

async function allowedStates(
  owner: string,
  environment: string,
  variant: string,
  domain: string,
): Promise<Set<string> | undefined> {
  if (
    owner === 'AutoDataProviders' &&
    ['RANDOM_ADPF_APPLICANT_DATA_PROVIDER', 'ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER'].includes(variant)
  )
    return undefined;
  if (owner === 'DataProviders' && domain === 'home') {
    if (variant === 'APPLICANT_HOME_ERROR_DATA_PROVIDER') return undefined;
    if (variant === 'MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER') {
      return new Set(['MA11', 'RA11', 'RA61'].includes(environment.toUpperCase()) ? ['NJ', 'NY'] : []);
    }
    // DataProviders.getListOfLegacyHomeStates returns an empty list in the master.
    return new Set();
  }
  if (owner === 'SqlDataProviders') {
    if (variant === 'STATES_DATA_PROVIDER_NAME') return undefined;
    const aceStates = await allowedStates('AutoDataProviders', environment, 'AUTO_APPLICANT_DATA_PROVIDER', 'auto');
    return new Set(
      'AL AR AZ CA CO CT FL GA IA ID IN IL KS KY LA MA MD MI MN MO MS MT NC ND NE NJ NM NV NY OH OK OR PA SD TN TX UT VA WA WI WY'
        .split(' ')
        .filter((state) => !aceStates?.has(state)),
    );
  }
  const family = owner === 'AutoDataProviders' ? 'AceAuto' : owner === 'AceHomeDataProviders' ? 'AceHCR' : '';
  if (!family) return undefined;
  const key = `listOf${family}States_${environment.toUpperCase()}`;
  const list = (await stateLists())[key];
  if (!list) throw new FixtureSelectionError(`Missing Java state support list ${key}`);
  return new Set(list);
}

async function joinChildren(book: string, row: DataRecord): Promise<DataRecord> {
  if (book !== 'AutoTestData' && book !== 'OneUIAutoTestData' && book !== 'AceHomeTestData') return row;
  const id = sourceId(row);
  const sheets =
    book === 'AceHomeTestData'
      ? ['discounts']
      : book === 'AutoTestData'
        ? ['vehicles', 'additionalDriver', 'incidents', 'discounts', 'payments', 'representative']
        : ['vehicles', 'additionalDriver', 'incidents', 'discounts'];
  const result: Record<string, unknown> = { ...row };
  for (const sheet of sheets) {
    const all = await rawRows(book, sheet);
    const linked =
      sheet === 'representative'
        ? all.filter((child) => String(child.representativeId) === String(row.sameStateZip))
        : all.filter((child) => String(child.applicantId) === id);
    let children = await Promise.all(linked.map((child) => materializeRow(book, sheet, child)));
    if (sheet === 'vehicles' && book === 'AutoTestData') {
      children = children.map((child) =>
        Object.freeze({
          ...child,
          garagingAddress: row.garagingAddress,
          garagingCity: row.city,
          garagingZip: row.zipCode,
          ...(stateOf(row) === 'NC' && String(row.knockoutExpected).toLowerCase() !== 'true'
            ? { rideSharing: false }
            : {}),
        }),
      );
    }
    if (sheet === 'vehicles' && book === 'OneUIAutoTestData' && stateOf(row) === 'MA') {
      children = children.map((child) => Object.freeze({ ...child, parkInResidentAddress: true }));
    }
    if (book === 'AutoTestData' && ['discounts', 'payments', 'representative'].includes(sheet)) {
      const field = sheet === 'payments' ? 'payment' : sheet;
      result[field] = sheet === 'payments' ? (children.at(-1) ?? null) : (children[0] ?? null);
    } else {
      result[sheet === 'additionalDriver' ? 'additionalDrivers' : sheet] = Object.freeze(children);
    }
  }
  return Object.freeze(result);
}

export async function selectLegacyCases(
  metadata: LegacyTestMetadata,
  options: SelectionOptions,
): Promise<SelectedCase[]> {
  if (!metadata.dataProvider) {
    return [
      Object.freeze({
        source: 'inline',
        sheet: 'none',
        sourceId: metadata.legacyId,
        state: '',
        data: Object.freeze({}),
      }),
    ];
  }
  const provider = sourceFor(metadata);
  const owner = metadata.dataProviderClass.replace(/\.class$/, '');
  const variant = metadata.dataProvider.split('.').pop() ?? '';
  const rng = random(`${options.seed}:${metadata.legacyId}`);
  const testName = await resolveConstant(metadata.testName);
  const explicitMainConfig =
    owner === 'AutoDataProviders' &&
    provider.sheet === 'applicant' &&
    ((!!options.states?.trim() && options.states.trim().toLowerCase() !== 'all') ||
      !!options.scenarios?.split(',').some((item) => item.trim() && item.trim() !== 'Assault'));
  const suiteExpression = /suiteName\s*=\s*("[^"]*"|[\w.]+)/.exec(metadata.annotation)?.[1] ?? '';
  const category = await resolveConstant(suiteExpression);
  const parsedAttrs = await attributes(metadata.annotation);
  const attrs =
    owner === 'AutoDataProviders' &&
    ['RANDOM_ADPF_APPLICANT_DATA_PROVIDER', 'BIND_ADPF_APPLICANT_DATA_PROVIDER'].includes(variant)
      ? new Map([...parsedAttrs].slice(0, 1).filter(([key]) => key === 'HOUSEHOLD_NUMBER'))
      : owner === 'AutoDataProviders' && variant === 'ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER'
        ? new Map([...parsedAttrs].slice(0, 1))
        : (owner === 'DataProviders' && variant === 'APPLICANT_HOME_ERROR_DATA_PROVIDER') ||
            (owner === 'AutoDataProviders' && variant === 'AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER')
          ? new Map<string, string[]>()
          : parsedAttrs;
  let rows = [...(await rawRows(provider.book, provider.sheet))];
  if (
    category &&
    ((owner === 'AceHomeDataProviders' && provider.sheet === 'PageValidationApplicantAceHome') ||
      (owner === 'AutoDataProviders' && provider.sheet === 'pageValidationApplicant'))
  ) {
    rows = rows.filter((row) => String(row.testCategory ?? '') === category);
  }
  const support = await allowedStates(owner, options.environment, variant, metadata.domain);
  const configured =
    options.states?.trim().toLowerCase() === 'all'
      ? undefined
      : options.states
          ?.split(',')
          .map((state) => state.trim().toUpperCase())
          .filter(Boolean);
  const usesStateProperty =
    !(
      owner === 'AutoDataProviders' &&
      ['RANDOM_ADPF_APPLICANT_DATA_PROVIDER', 'ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER'].includes(
        variant,
      )
    ) && variant !== 'APPLICANT_HOME_ERROR_DATA_PROVIDER';
  if (configured?.length && usesStateProperty && !attrs.has('DISABLED_STATES'))
    rows = rows.filter((row) => configured.includes(stateOf(row)));
  if (support && !attrs.has('DISABLED_STATES')) rows = rows.filter((row) => support.has(stateOf(row)));
  if (attrs.has('INCLUDED_STATES')) rows = rows.filter((row) => attrs.get('INCLUDED_STATES')!.includes(stateOf(row)));
  if (attrs.has('EXCLUDED_STATES')) rows = rows.filter((row) => !attrs.get('EXCLUDED_STATES')!.includes(stateOf(row)));
  if (attrs.has('DISABLED_STATES')) rows = rows.filter((row) => attrs.get('DISABLED_STATES')!.includes(stateOf(row)));
  if (owner === 'SqlDataProviders' && attrs.has('MONETIZED_STATES')) rows = [];
  if (attrs.has('HOUSEHOLD_NUMBER'))
    rows = rows.filter((row) => attrs.get('HOUSEHOLD_NUMBER')!.includes(String(row.householdNumber ?? '')));
  const stateAttributes = [...attrs.keys()].filter((name) => /^[A-Z]{2}$/.test(name));
  if (stateAttributes.length) rows = rows.filter((row) => stateAttributes.includes(stateOf(row)));
  if (attrs.has('RANDOM_STATE'))
    rows = [pick([...new Set(rows.map(stateOf))], rng, `${metadata.legacyId}/random-state`)].flatMap((state) =>
      rows.filter((row) => stateOf(row) === state),
    );
  const filter = attrs.get('FILTER')?.[0];
  if (filter) {
    const [field, value] = filter.split('=');
    if (!field || value === undefined)
      throw new FixtureSelectionError(`Invalid FILTER in ${metadata.legacyId}: ${filter}`);
    rows = rows.filter((row) => String(row[field] ?? '').trim() === value.trim());
  }
  if (testName.startsWith('row=')) {
    const ids = new Set(
      testName
        .slice(4)
        .split(',')
        .map((id) => id.trim()),
    );
    rows = rows.filter((row) => ids.has(sourceId(row)));
  }
  if (!explicitMainConfig && testName === 'RandomAutoApplicantWithOneVehicle') {
    const vehicles = await rawRows(provider.book, 'vehicles');
    rows = rows.filter(
      (row) =>
        String(row.singleVehicle).toLowerCase() !== 'no' &&
        vehicles.filter((vehicle) => String(vehicle.applicantId) === sourceId(row)).length === 1,
    );
  }
  if (!explicitMainConfig && owner === 'AutoDataProviders' && provider.sheet === 'applicant') {
    if (testName === 'financialResponsibility') {
      rows = rows.filter((row) => /^SR.?22/i.test(String(row.financialFiling ?? '')));
    }
    if (testName === 'ServiceVirtualizationApplicants') {
      rows = rows.filter((row) => ['1', '2', '6'].includes(sourceId(row)));
    }
  }
  if (owner === 'AutoDataProviders' && provider.sheet === 'ADPFApplicantVehicleDriverNum') {
    rows = rows.filter((row) => stateOf(row) !== 'CA');
    const rule = [...attrs.keys()].find((name) =>
      /^(?:drivers|vehicles|incomplete|noIncomplete|oneToFive|twelve)/i.test(name),
    );
    if (rule && rule !== 'driversGT5') rows = rows.filter((row) => !['AZ', 'IL'].includes(stateOf(row)));
    const number = (row: DataRecord, key: string) => Number(row[key] ?? 0);
    const tests: Record<string, (row: DataRecord) => boolean> = {
      twelveDriversTwelveVehicles: (r) =>
        number(r, 'numberOfIncompleteVehicles') === 12 && number(r, 'numberOfIncompleteDrivers') === 12,
      driversGT0: (r) => number(r, 'numberOfDrivers') > 0,
      driversGT5: (r) => number(r, 'numberOfDrivers') > 5,
      driversAndVehicles: (r) => number(r, 'numberOfDrivers') > 0 && number(r, 'numberOfVehicles') > 0,
      driversAndNoVehicles: (r) => number(r, 'numberOfDrivers') > 0 && number(r, 'numberOfVehicles') === 0,
      vehiclesAndDriversAndIncompleteDrivers: (r) =>
        number(r, 'numberOfVehicles') > 0 &&
        number(r, 'numberOfDrivers') > 1 &&
        number(r, 'numberOfIncompleteDrivers') > 0,
      vehiclesGT1: (r) => number(r, 'numberOfVehicles') > 1,
      oneToFiveVehicles: (r) => number(r, 'numberOfVehicles') >= 1 && number(r, 'numberOfVehicles') <= 5,
      incompleteDrivers: (r) => number(r, 'numberOfIncompleteDrivers') > 0,
      noIncompleteDriversVehicles: (r) =>
        number(r, 'numberOfIncompleteDrivers') === 0 && number(r, 'numberOfIncompleteVehicles') === 0,
      incompleteDriversVehicles: (r) =>
        number(r, 'numberOfIncompleteDrivers') > 0 && number(r, 'numberOfIncompleteVehicles') > 0,
      incompleteDriversAndNoDrivers: (r) =>
        number(r, 'numberOfIncompleteDrivers') > 0 && number(r, 'numberOfDrivers') === 0,
      oneIncompleteVehicle: (r) => number(r, 'numberOfIncompleteVehicles') === 1,
      noIncompleteVehiclesAndVehiclesLTFive: (r) =>
        number(r, 'numberOfVehicles') > 0 &&
        number(r, 'numberOfVehicles') <= 5 &&
        number(r, 'numberOfIncompleteVehicles') === 0,
    };
    if (rule && tests[rule]) rows = rows.filter(tests[rule]);
  }
  if (owner === 'AceBundleDataProviders' && /WithIncidents|With3Vehicles/.test(testName)) {
    const sheet = testName.includes('Incidents') ? 'incidents' : 'vehicles';
    const linked = await rawRows(provider.book, sheet);
    rows = rows.filter((row) => {
      const count = linked.filter((child) => String(child.applicantId) === sourceId(row)).length;
      return testName.includes('Incidents') ? count > 0 && sourceId(row) !== '35' : count > 2;
    });
  }
  if (owner === 'DataProviders' && metadata.domain === 'home') {
    if (metadata.dataProvider.endsWith('.APPLICANT_HOME_ERROR_DATA_PROVIDER')) {
      rows = rows.filter((row) => String(row.errorScenario) === 'DISABLED');
    }
    if (metadata.dataProvider.endsWith('.MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER')) {
      rows = rows.filter((row) => ['NJ', 'NY'].includes(stateOf(row)));
    }
    if (metadata.dataProvider.endsWith('.APPLICANT_HOME_SMOKE_DATA_PROVIDER')) {
      rows = rows.filter((row) => String(row.lastName) === 'Barnert');
      const state = pick([...new Set(rows.map(stateOf))], rng, `${metadata.legacyId}/smoke-state`);
      rows = rows.filter((row) => stateOf(row) === state);
    }
    if (metadata.dataProvider.endsWith('.GET_RETRIEVE_QUOTE_APPLICANT_HOME')) {
      const states = shuffled([...new Set(rows.map(stateOf))], rng).slice(0, 5);
      rows = rows.filter((row) => states.includes(stateOf(row)));
    }
  }
  if (owner === 'SqlDataProviders') {
    const name = metadata.dataProvider.split('.').pop();
    const bvtStates = new Set(
      'AL AR CA CO CT GA IA ID IN KS KY LA MA MD MI MN MS MT ND NE NJ NM NV OK OR SD TN VA WI WY'.split(' '),
    );
    if (
      (name === 'BVT_AUTO_APPLICANT_DATA_PROVIDER' && !attrs.has('INCLUDED_STATES')) ||
      name?.startsWith('JENKINS_') ||
      (name === 'BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER' && attrs.size > 0)
    ) {
      rows = rows.filter((row) => bvtStates.has(stateOf(row)));
    }
    if (name === 'BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER' && !(configured?.length && attrs.size > 0)) {
      const states = shuffled([...new Set(rows.map(stateOf))], rng).slice(0, 5);
      rows = rows.filter((row) => states.includes(stateOf(row)));
    }
    if (name === 'JENKINS_AUTO_APPLICANT_QUOTE_SCENARIOS_DATA_PROVIDER') {
      const excluded = new Set('IN KY MA MS ND OK PA SD TX TN'.split(' '));
      rows = rows.filter(
        (row) =>
          !excluded.has(stateOf(row)) &&
          ['1', '5', '8'].includes(sourceId(row)) &&
          !(sourceId(row) === '8' && ['CO', 'ID'].includes(stateOf(row))),
      );
    }
    if (name === 'HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER') {
      const groups = [
        'KY LA MA MS NC',
        'AL AR ID MI NE NM OK OR PA TN WI WY',
        'CT GA MT ND SD VA',
        'CO FL IA IN KS MD MN MO NV OH UT WA',
      ];
      const selectedStates = groups.flatMap((group) => {
        const eligible = group.split(' ').filter((state) => support?.has(state));
        return eligible.length ? [pick(eligible, rng, `${metadata.legacyId}/high-value`)] : [];
      });
      rows = rows.filter((row) => selectedStates.includes(stateOf(row)));
    }
  }
  const scenarios =
    options.scenarios
      ?.split(',')
      .map((item) => item.trim())
      .filter(Boolean) ?? [];
  const scenarioOverride =
    owner === 'AutoDataProviders' && provider.sheet === 'applicant' && scenarios.some((item) => item !== 'Assault');
  if (scenarioOverride)
    rows = rows.filter((row) =>
      scenarios.filter((item) => item !== 'Assault').includes(String(row.testScenario ?? '')),
    );
  if (
    metadata.legacyId === 'com.farmers.ffq.auto.e2e.QuoteE2ETests#aceAutoEndToEndOneRandomApplicant' &&
    testName === 'RandomAutoApplicant'
  ) {
    const nonKnockout = rows.filter((row) => String(row.knockoutExpected).toLowerCase() !== 'true');
    if (nonKnockout.length) rows = nonKnockout;
  }
  if (
    owner === 'AutoDataProviders' &&
    provider.sheet === 'pageValidationApplicant' &&
    category !== 'existing customer knockout'
  ) {
    if (!scenarios.length)
      throw new FixtureSelectionError(
        `${metadata.legacyId}: Java category provider requires testScenario; set FFQ_DATA_SCENARIOS`,
      );
    if (scenarios[0]!.includes('Assault')) rows = [pick(rows, rng, `${metadata.legacyId}/assault`)];
    else {
      if (!configured?.length)
        throw new FixtureSelectionError(
          `${metadata.legacyId}: Java multiple-state bind requires explicit stateList; set FFQ_DATA_STATES`,
        );
      rows = (await rawRows(provider.book, provider.sheet)).filter(
        (row) =>
          configured.includes(stateOf(row)) &&
          support?.has(stateOf(row)) &&
          scenarios.includes(String(row.testScenario ?? '').trim()),
      );
    }
  }
  if (!rows.length)
    throw new FixtureSelectionError(
      `No data for ${metadata.legacyId}; ${provider.book}/${provider.sheet}; states=${options.states ?? 'environment default'}; category=${category}`,
    );
  const skipPostSelection =
    owner === 'AutoDataProviders' &&
    (provider.sheet === 'pageValidationApplicant' ||
      (provider.sheet === 'applicant' && (scenarioOverride || !!configured?.length)));
  if (skipPostSelection) {
    // returns immediately for configured scenarios/states before testName processing.
  } else if (owner === 'AutoDataProviders' && testName === 'AutoApplicantsFromAFewStates') {
    const states = shuffled([...new Set(rows.map(stateOf))], rng).slice(0, 4);
    rows = states.map((state) =>
      pick(
        rows.filter((row) => stateOf(row) === state),
        rng,
        `${metadata.legacyId}/${state}`,
      ),
    );
  } else if (owner === 'SqlDataProviders' && metadata.dataProvider.endsWith('.BVT_AUTO_APPLICANT_DATA_PROVIDER')) {
    const state = pick([...new Set(rows.map(stateOf))], rng, `${metadata.legacyId}/bvt-state`);
    rows = rows.filter((row) => stateOf(row) === state);
  } else if (
    provider.mode === 'perState' ||
    /OneApplicantPerState|OneBundleApplicantPerState|RandomAutoApplicantFromEachState/.test(testName)
  ) {
    rows = [...new Set(rows.map(stateOf))].map((state) => {
      const available = rows.filter((row) => stateOf(row) === state);
      const preferred =
        owner === 'AutoDataProviders' && testName === 'RandomAutoApplicantFromEachState'
          ? available.filter((row) => sourceId(row) === '1')
          : [];
      return pick(preferred.length ? preferred : available, rng, `${metadata.legacyId}/${state}`);
    });
  } else if (
    provider.mode === 'one' ||
    /RANDOM_ROW|RandomAutoApplicant|RandomBundleApplicant|ONE_ACE_LIFE|ONE_BUSINESS/.test(
      testName + ' ' + metadata.dataProvider,
    ) ||
    (owner === 'AutoDataProviders' && ['financialResponsibility', 'ServiceVirtualizationApplicants'].includes(testName))
  ) {
    rows = [pick(rows, rng, metadata.legacyId)];
  }
  const selected: SelectedCase[] = [];
  for (const raw of rows) {
    let data = await materializeRow(provider.book, provider.sheet, raw);
    if (
      !(
        owner === 'AutoDataProviders' &&
        provider.sheet !== 'applicant' &&
        provider.sheet !== 'pageValidationApplicant'
      ) &&
      variant !== 'STATES_DATA_PROVIDER_NAME'
    )
      data = await joinChildren(provider.book, data);
    if (owner === 'AutoDataProviders' && provider.sheet === 'ADPFApplicant') {
      const household = String(raw.householdNumber ?? '');
      const members = (await rawRows('OneUIAutoTestData', 'ADPFApplicant')).filter(
        (member) => String(member.householdNumber) === household && member.firstName !== raw.firstName,
      );
      const vehicles = (await rawRows('OneUIAutoTestData', 'ADPFVehicles')).filter(
        (vehicle) => String(vehicle.applicantId) === household,
      );
      data = Object.freeze({
        ...data,
        listOfAdditionalApplicants: Object.freeze(
          await Promise.all(members.map((member) => materializeRow('OneUIAutoTestData', 'ADPFApplicant', member))),
        ),
        listOfApplicantVehicles: Object.freeze(
          await Promise.all(vehicles.map((vehicle) => materializeRow('OneUIAutoTestData', 'ADPFVehicles', vehicle))),
        ),
      });
    }
    if (owner === 'AceBundleDataProviders') {
      const homes = (await rawRows('AceHomeTestData', 'ApplicantHome')).filter(
        (home) => stateOf(home) === stateOf(data),
      );
      const home = await materializeRow(
        'AceHomeTestData',
        'ApplicantHome',
        pick(homes, rng, `${metadata.legacyId}/home`),
      );
      data = Object.freeze({ autoApplicant: data, hrcApplicant: await joinChildren('AceHomeTestData', home) });
    }
    let bindAddress: DataRecord | undefined;
    if (
      owner === 'AutoDataProviders' &&
      provider.sheet === 'applicant' &&
      !skipPostSelection &&
      ['financialResponsibility', 'ServiceVirtualizationApplicants', 'AllApplicants'].includes(testName)
    ) {
      const addresses = (await rawRows(provider.book, 'applicant')).filter((row) => stateOf(row) === stateOf(raw));
      bindAddress = await materializeRow(
        provider.book,
        'applicant',
        pick(addresses, rng, `${metadata.legacyId}/bind-address`),
      );
    }
    data = prepareJavaApplicant(data, owner, variant, testName, rng, bindAddress);
    selected.push(
      Object.freeze({
        source: provider.book,
        sheet: provider.sheet,
        sourceId: sourceId(raw),
        state: stateOf(raw),
        data,
      }),
    );
  }
  return selected;
}
