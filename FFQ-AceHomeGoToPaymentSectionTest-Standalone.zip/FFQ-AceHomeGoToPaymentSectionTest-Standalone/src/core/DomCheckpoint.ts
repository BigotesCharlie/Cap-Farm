import { promises as fs } from 'node:fs';
import type { Page, TestInfo } from '@playwright/test';
import { collectPageSummary } from './BrowserUi.js';
import { sanitizeHtmlEvidence, sanitizeTextEvidence } from './EvidenceSanitizer.js';

function sanitizeCheckpointName(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

export async function safePageContent(page: Page): Promise<string> {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      return sanitizeHtmlEvidence(await page.content());
    } catch {
      await page.waitForLoadState('domcontentloaded', { timeout: 1500 }).catch(() => undefined);
    }
  }
  return '<!-- content-unavailable: navigation-in-progress -->';
}

export async function captureDomCheckpoint(page: Page, testInfo: TestInfo, name: string): Promise<void> {
  const safeName = sanitizeCheckpointName(name);
  const htmlPath = testInfo.outputPath(`${safeName}.html`);
  const pngPath = testInfo.outputPath(`${safeName}.png`);
  const jsonPath = testInfo.outputPath(`${safeName}.json`);
  const legacyId =
    testInfo.annotations.filter((annotation) => annotation.type === 'legacy-id').at(-1)?.description ?? 'unknown';
  const applicantCorrelationId =
    testInfo.annotations.filter((annotation) => annotation.type === 'applicant-correlation-id').at(-1)?.description ??
    'unknown';
  const pageSummary = await collectPageSummary(page);
  const contract = await page
    .evaluate(() => {
      const isVisible = (element: Element): boolean => {
        const html = element as HTMLElement;
        const style = window.getComputedStyle(html);
        if (style.visibility === 'hidden' || style.display === 'none') return false;
        const rect = html.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0;
      };

      const textOf = (element: Element): string => (element.textContent ?? '').replace(/\s+/g, ' ').trim();

      const unique = (values: string[], limit: number): string[] => {
        const deduped = Array.from(new Set(values.filter(Boolean)));
        return deduped.slice(0, limit);
      };

      const headings = unique(
        Array.from(document.querySelectorAll('h1, h2, h3, [role="heading"]')).filter(isVisible).map(textOf),
        20,
      );

      const buttons = unique(
        Array.from(document.querySelectorAll('button, [role="button"]'))
          .filter(isVisible)
          .map((node) => textOf(node) || (node as HTMLElement).getAttribute('aria-label') || ''),
        30,
      );

      const links = unique(
        Array.from(document.querySelectorAll('a, [role="link"]'))
          .filter(isVisible)
          .map((node) => textOf(node) || (node as HTMLElement).getAttribute('aria-label') || ''),
        30,
      );

      const inputs = Array.from(
        document.querySelectorAll('input, textarea, select, [role="textbox"], [role="combobox"]'),
      )
        .filter(isVisible)
        .slice(0, 40)
        .map((node) => {
          const html = node as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement | HTMLElement;
          const role = html.getAttribute('role') ?? html.tagName.toLowerCase();
          const type = html instanceof HTMLInputElement ? html.type : html.tagName.toLowerCase();
          const id = html.id || undefined;
          const name = html.getAttribute('name') || undefined;
          const label = html.getAttribute('aria-label') || undefined;
          const testId = html.getAttribute('data-testid') || html.getAttribute('data-test-id') || undefined;
          const value =
            html instanceof HTMLInputElement || html instanceof HTMLTextAreaElement || html instanceof HTMLSelectElement
              ? html.value
              : undefined;
          return { role, type, id, name, label, testId, value };
        });

      const selectedOptions = unique(
        Array.from(document.querySelectorAll('[role="option"][aria-selected="true"], option:checked'))
          .filter(isVisible)
          .map(textOf),
        20,
      );

      const visibleRoles = unique(
        Array.from(document.querySelectorAll('[role]'))
          .filter(isVisible)
          .map((node) => node.getAttribute('role') ?? ''),
        40,
      );

      const testIds = unique(
        Array.from(document.querySelectorAll('[data-testid], [data-test-id]'))
          .filter(isVisible)
          .map((node) => node.getAttribute('data-testid') || node.getAttribute('data-test-id') || ''),
        40,
      );

      return {
        headings,
        buttons,
        links,
        inputs,
        selectedOptions,
        visibleRoles,
        testIds,
      };
    })
    .catch(() => ({
      headings: [] as string[],
      buttons: [] as string[],
      links: [] as string[],
      inputs: [] as Array<Record<string, unknown>>,
      selectedOptions: [] as string[],
      visibleRoles: [] as string[],
      testIds: [] as string[],
    }));

  let screenshotStatus: 'captured' | 'failed' = 'captured';
  try {
    await page.screenshot({ path: pngPath, timeout: 8000 });
  } catch (error) {
    screenshotStatus = 'failed';
    const failurePath = testInfo.outputPath(`${safeName}-screenshot-failure.json`);
    await fs.writeFile(failurePath, JSON.stringify({
      checkpoint: safeName,
      capturedAt: new Date().toISOString(),
      failure: error instanceof Error && /Protocol error|Unable to capture screenshot/i.test(error.message)
        ? 'Screenshot protocol capture failed; see restricted trace' : 'Screenshot unavailable; see restricted trace',
    }, null, 2), 'utf8');
    testInfo.annotations.push({ type: 'evidence-capture-warning', description: `${safeName}: screenshot failed; DOM capture retained` });
    await testInfo.attach(`${safeName}-screenshot-failure`, { path: failurePath, contentType: 'application/json' });
  }
  await fs.writeFile(htmlPath, await safePageContent(page), 'utf8');
  await fs.writeFile(
    jsonPath,
    JSON.stringify(
      sanitizeTextEvidence({
        logicalScreenName: name,
        checkpointFilePrefix: safeName,
        screenshotStatus,
        testName: testInfo.title,
        legacyId,
        applicantCorrelationId,
        url: page.url(),
        title: await page.title().catch(() => ''),
        pageClassification: pageSummary.pageClassification,
        heading: pageSummary.heading,
        visibleButtons: pageSummary.visibleButtons,
        selectedValues: pageSummary.selectedValues,
        validationMessages: pageSummary.validationMessages,
        overlayVisible: pageSummary.overlayVisible,
        overlayText: pageSummary.overlayText,
        zoom: pageSummary.zoom,
        contract,
        timestamp: new Date().toISOString(),
      }),
      null,
      2,
    ),
    'utf8',
  );
}
