import { execFileSync } from 'node:child_process';
import { promises as fs } from 'node:fs';
import { join } from 'node:path';
import type { Page, Request, Response, TestInfo } from '@playwright/test';
import type { ApplicantAceHome } from '../models/acehome/ApplicantAceHome.js';
import type { SelectedCase } from '../data/LegacyProviderSelector.js';

function redactSecrets(value: unknown, key = ''): unknown {
  if (/password|secret|token|authorization|cookie|cvv|cvc|routing|bank.?account|card.?number|credit.?card/i.test(key))
    return '[REDACTED]';
  if (Array.isArray(value)) return value.map((item) => redactSecrets(item));
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([childKey, child]) => [childKey, redactSecrets(child, childKey)]));
  }
  return value;
}

export class AceHomePrivateRunCapture {
  private readonly directory: string;
  private readonly events: unknown[] = [];
  private readonly checkpoints: unknown[] = [];
  private readonly responses: unknown[] = [];
  private readonly recordBinding = (_source: unknown, event: unknown): void => {
    this.events.push({ at: new Date().toISOString(), ...((event as object) ?? {}) });
  };
  private readonly requestListener = (request: Request): void => {
    const url = new URL(request.url());
    if (/\/(?:home|auto)-api\//.test(url.pathname))
      this.responses.push({ kind: 'request', method: request.method(), path: url.pathname });
  };
  private readonly responseListener = (response: Response): void => {
    const url = new URL(response.url());
    if (/\/(?:home|auto)-api\//.test(url.pathname))
      this.responses.push({ kind: 'response', method: response.request().method(), path: url.pathname, status: response.status() });
  };

  public constructor(
    private readonly page: Page,
    private readonly testInfo: TestInfo,
    private readonly selected: SelectedCase,
    private readonly applicant: ApplicantAceHome,
    private readonly seed: string,
  ) {
    this.directory = testInfo.outputPath('private-inputs');
  }

  public async start(): Promise<void> {
    await fs.mkdir(this.directory, { recursive: true, mode: 0o700 });
    if (process.platform === 'win32') {
      const identity = process.env.USERDOMAIN ? `${process.env.USERDOMAIN}\\${process.env.USERNAME}` : process.env.USERNAME;
      if (!identity) throw new Error('PRIVATE_INPUT_CAPTURE_BLOCKED: Windows user identity unavailable.');
      execFileSync('icacls.exe', [this.directory, '/inheritance:r', '/grant:r', `${identity}:(OI)(CI)F`], { stdio: 'pipe' });
    }
    await this.page.exposeBinding('__aceHomeRecordInput', this.recordBinding);
    await this.page.addInitScript(() => {
      const send = (event: Event): void => {
        const target = event.target;
        if (!(target instanceof HTMLElement)) return;
        const element = target.closest('input,select,textarea,button,[role="radio"],[role="checkbox"]');
        if (!(element instanceof HTMLElement)) return;
        const identity = `${element.id} ${element.getAttribute('name') ?? ''} ${element.getAttribute('aria-label') ?? ''}`;
        if (/password|secret|token|card|credit|debit|account|routing|cvv|cvc/i.test(identity)) return;
        const input = element as HTMLInputElement;
        const binding = (window as unknown as { __aceHomeRecordInput: (data: unknown) => void }).__aceHomeRecordInput;
        binding({ type: event.type, route: location.pathname, id: element.id, name: element.getAttribute('name'),
          label: element.getAttribute('aria-label'), text: element.textContent?.trim(),
          value: 'value' in element ? input.value : undefined, checked: 'checked' in element ? input.checked : undefined });
      };
      for (const event of ['input', 'change', 'click']) document.addEventListener(event, send, true);
    });
    this.page.on('request', this.requestListener);
    this.page.on('response', this.responseListener);
    await this.persist('IN_PROGRESS');
  }

  public async checkpoint(name: string): Promise<void> {
    const pageState = await this.page.evaluate(() => {
      const storeKey = Object.keys(sessionStorage).find((key) => /appstore|app-store|state-store/i.test(key));
      let store: Record<string, unknown> = {};
      try { store = storeKey ? JSON.parse(sessionStorage.getItem(storeKey) ?? '{}') as Record<string, unknown> : {}; } catch { /* state not available */ }
      return {
        url: location.href,
        headings: Array.from(document.querySelectorAll('h1,h2,h3')).filter((node) => node.getClientRects().length > 0)
          .map((node) => node.textContent?.trim()),
        controls: Array.from(document.querySelectorAll('input:not([type="hidden"]),select,textarea'))
          .filter((node) => (node as HTMLElement).getClientRects().length > 0 &&
            !/password|secret|token|card|credit|debit|account|routing|cvv|cvc/i.test(
              `${node.id} ${node.getAttribute('name') ?? ''} ${node.getAttribute('aria-label') ?? ''}`,
            ))
          .map((node) => {
            const input = node as HTMLInputElement;
            return {
              id: input.id,
              name: input.name,
              label: input.getAttribute('aria-label'),
              value: input.value,
              checked: input.checked,
            };
          }),
        appStore: store,
      };
    }).catch(() => ({ unavailable: true }));
    this.checkpoints.push({ name, at: new Date().toISOString(), state: pageState });
    await this.persist('IN_PROGRESS');
  }

  public async saveAtPayment(): Promise<string> {
    this.page.off('request', this.requestListener);
    this.page.off('response', this.responseListener);
    await this.checkpoint('payment-pif-verified');
    await this.persist('PAYMENT_VERIFIED');
    const file = join(this.directory, 'resolved-inputs.json');
    this.testInfo.annotations.push({ type: 'private-resolved-inputs', description: file });
    return file;
  }

  private async persist(status: 'IN_PROGRESS' | 'PAYMENT_VERIFIED'): Promise<void> {
    const file = join(this.directory, 'resolved-inputs.json');
    const pending = join(this.directory, 'resolved-inputs.next.json');
    await fs.writeFile(pending, JSON.stringify(redactSecrets({
      legacyId: this.testInfo.annotations.find((annotation) => annotation.type === 'legacy-id')?.description,
      provider: `${this.selected.source}/${this.selected.sheet}`,
      sourceId: this.selected.sourceId,
      state: this.selected.state,
      seed: this.seed,
      status,
      sourceRow: this.selected.data,
      resolvedApplicant: this.applicant,
      uiEvents: this.events,
      checkpoints: this.checkpoints,
      network: this.responses,
    }), null, 2), { mode: 0o600 });
    await fs.rename(pending, file);
  }
}