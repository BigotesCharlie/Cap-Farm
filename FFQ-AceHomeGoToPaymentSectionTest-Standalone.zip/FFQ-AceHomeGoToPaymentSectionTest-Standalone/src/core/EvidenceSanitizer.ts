import { defaultTreeAdapter, parse, serialize, type DefaultTreeAdapterTypes } from 'parse5';

const LOCATOR_ATTRIBUTES = new Set(['id', 'name', 'class', 'type', 'role', 'data-testid', 'data-test-id']);
const SAFE_IDENTIFIER = /^[a-zA-Z][a-zA-Z0-9_:\s.-]{0,79}$/;

export function sanitizeHtmlEvidence(html: string): string {
  const document = parse(html);

  function scrub(node: DefaultTreeAdapterTypes.Node): void {
    if (defaultTreeAdapter.isTextNode(node)) {
      if (node.value.trim()) node.value = '[REDACTED]';
      return;
    }
    if (defaultTreeAdapter.isCommentNode(node)) {
      node.data = '';
      return;
    }
    if ('tagName' in node) {
      node.attrs = node.attrs.filter(({ name, value }) => LOCATOR_ATTRIBUTES.has(name) && SAFE_IDENTIFIER.test(value));
      if (node.tagName === 'script' || node.tagName === 'style') {
        node.childNodes = [];
        return;
      }
      if ('content' in node) scrub(node.content);
    }
    if ('childNodes' in node) for (const child of node.childNodes) scrub(child);
  }

  scrub(document);
  return serialize(document);
}

export function sanitizeTextEvidence(value: unknown): unknown {
  if (typeof value === 'string') return value ? '[REDACTED]' : '';
  if (Array.isArray(value)) return value.map(sanitizeTextEvidence);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, sanitizeTextEvidence(entry)]));
  }
  return value;
}
