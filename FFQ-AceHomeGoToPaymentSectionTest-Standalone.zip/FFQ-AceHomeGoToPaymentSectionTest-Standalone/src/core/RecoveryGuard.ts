import { promises as fs } from 'node:fs';
import type { Locator, Page, Response, TestInfo } from '@playwright/test';
import { env } from '../config/env.js';
import { safePageContent } from './DomCheckpoint.js';
import { sanitizeTextEvidence } from './EvidenceSanitizer.js';

export type RecoveryKind = 'knockout' | 'inconvenience' | 'try-again';
export interface StateWaitConfig {
  readonly expectedStates: readonly string[];
  readonly intermediateStates?: readonly string[];
  readonly recoveryStates?: readonly string[];
  readonly maxRecoveryAttempts?: number;
  readonly failOnRecoveryState?: boolean;
  readonly pollIntervalMs?: number;
  readonly timeoutMs?: number;
}
interface RecoveryTarget {
  readonly kind: RecoveryKind;
  readonly marker: Locator;
  readonly action: Locator;
}

/** Watches each test from fixture setup until teardown. A detected break can never produce PASS by itself. */
export class RecoveryGuard {
  private stopped = false;
  private attempts = 0;
  private failure: Error | undefined;
  private loop: Promise<void> | undefined;
  private expected: RecoveryKind | undefined;
  private observed: RecoveryKind | undefined;
  private lastCheckpoint = 'test setup';
  private pending: Promise<void> | undefined;
  private recoveryEvidenceSuffix: string | undefined;
  private failOnRecoveryState = false;
  private lastGetLocationFailureStatus: number | undefined;
  private readonly responseListener = (response: Response): void => {
    try {
      if (new URL(response.url()).pathname === '/home-api/rate/getLocation' && response.status() >= 500) {
        this.lastGetLocationFailureStatus = response.status();
      }
    } catch {
      // Ignore malformed response URLs.
    }
  };

  public constructor(
    private readonly page: Page,
    private readonly testInfo: TestInfo,
  ) {}
  public start(): void {
    this.page.on('response', this.responseListener);
    this.loop = this.monitor();
  }
  /** The scenario must still assert the expected page contents before it can pass. */
  public expectTerminal(kind: RecoveryKind): void {
    this.expected = kind;
  }
  public preventAutomaticRecovery(): void {
    this.failOnRecoveryState = true;
  }
  public async checkpoint(label: string): Promise<void> {
    this.lastCheckpoint = label;
    if (this.failure) throw this.failure;
    if (!this.page.isClosed()) await this.recoverIfPresent();
    if (this.failure) throw this.failure;
  }
  public async inspectRecovery(stepId: string, source: string): Promise<boolean> {
    if (this.page.isClosed()) return false;
    const safeSegment = (value: string): string => value.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 80) || 'unknown';
    const previousCheckpoint = this.lastCheckpoint;
    const previousEvidenceSuffix = this.recoveryEvidenceSuffix;
    const previousAttempts = this.attempts;
    const step = safeSegment(stepId);
    const origin = safeSegment(source);
    this.lastCheckpoint = `${step}-${origin}`;
    this.recoveryEvidenceSuffix = `${step}-${origin}`;
    try {
      await this.recoverIfPresent();
      return this.attempts > previousAttempts;
    } finally {
      this.lastCheckpoint = previousCheckpoint;
      this.recoveryEvidenceSuffix = previousEvidenceSuffix;
    }
  }
  /** Synchronized checkpoint around long transitions while the automatic guard remains active. */
  public async waitForStateWithRecovery<T extends { type: string }>(
    classifier: { detect(): Promise<T> },
    config: StateWaitConfig,
  ): Promise<T> {
    const previousFailurePolicy = this.failOnRecoveryState;
    this.failOnRecoveryState = config.failOnRecoveryState ?? previousFailurePolicy;
    try {
      const deadline = Date.now() + (config.timeoutMs ?? 30_000);
      while (Date.now() < deadline) {
        await this.checkpoint(`wait for ${config.expectedStates.join(' or ')}`);
        const state = await classifier.detect();
        if (config.expectedStates.includes(state.type)) return state;
        if (config.recoveryStates?.includes(state.type)) {
          await this.checkpoint(`recovery state ${state.type}`);
          if (this.failOnRecoveryState) {
            throw this.unexpectedRecoveryError(this.recoveryKind(state.type));
          }
          if (this.attempts > (config.maxRecoveryAttempts ?? env.RECOVERY_MAX_ATTEMPTS)) {
            throw new Error(`Recovery limit exceeded at ${state.type}`);
          }
        }
        await new Promise((resolve) => setTimeout(resolve, config.pollIntervalMs ?? env.RECOVERY_POLL_INTERVAL_MS));
      }
      throw new Error(`Timed out waiting for ${config.expectedStates.join(' or ')}; URL=${this.page.url()}`);
    } finally {
      this.failOnRecoveryState = previousFailurePolicy;
    }
  }
  public assertExpectedTerminal(kind: RecoveryKind): void {
    if (this.observed !== kind)
      throw new Error(`Expected ${kind} at ${this.lastCheckpoint}, observed ${this.observed ?? 'none'}`);
  }
  public async stop(): Promise<void> {
    this.stopped = true;
    this.page.off('response', this.responseListener);
    await this.loop;
    if (this.failure) throw this.failure;
  }

  private targets(): readonly RecoveryTarget[] {
    return [
      {
        kind: 'inconvenience',
        marker: this.page
          .locator('#inconvenience_header-title, #FFQAuto_Commonpage_inconvHeader, h1.inconvenience__title')
          .first(),
        action: this.page.getByRole('button', { name: /try again|continue|restart/i }).first(),
      },
      {
        kind: 'knockout',
        marker: this.page
          .locator(
            '#knockout_title, #knock-out_header-title, .knock-out_header-title, app-knockout-lead-form, .mobilehome-knockout__title',
          )
          .first(),
        action: this.page.getByRole('button', { name: /try again|start over/i }).first(),
      },
      {
        kind: 'try-again',
        marker: this.page.getByRole('heading', { name: /^try again$/i }).first(),
        action: this.page.getByRole('button', { name: /^try again$/i }).first(),
      },
    ];
  }

  private async monitor(): Promise<void> {
    while (!this.stopped) {
      try {
        if (!this.page.isClosed()) await this.recoverIfPresent();
      } catch (error) {
        this.failure = error instanceof Error ? error : new Error(String(error));
        this.stopped = true;
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, env.RECOVERY_POLL_INTERVAL_MS));
    }
  }

  private async recoverIfPresent(): Promise<void> {
    if (this.pending) return this.pending;
    const work = this.inspectPage();
    this.pending = work;
    try {
      await work;
    } finally {
      if (this.pending === work) this.pending = undefined;
    }
  }

  private async inspectPage(): Promise<void> {
    for (const target of this.targets()) {
      if (!(await target.marker.isVisible().catch(() => false))) continue;
      if (this.observed === target.kind && this.expected === target.kind) return;
      this.observed = target.kind;
      await this.capture(target.kind);
      if (target.kind === this.expected) return;
      if (this.failOnRecoveryState) throw this.unexpectedRecoveryError(target.kind);
      if (this.attempts >= env.RECOVERY_MAX_ATTEMPTS) {
        throw new Error(
          `${target.kind} at ${this.lastCheckpoint}: recovery limit ${env.RECOVERY_MAX_ATTEMPTS} exhausted`,
        );
      }
      if (!(await target.action.isVisible().catch(() => false))) {
        throw new Error(
          `${target.kind} at ${this.lastCheckpoint}: no verified recovery action; URL=${this.page.url()}`,
        );
      }
      this.attempts += 1;
      await target.action.click();
      await target.marker.waitFor({ state: 'hidden', timeout: env.ACTION_TIMEOUT_MS }).catch(() => {
        throw new Error(
          `${target.kind} remains visible after recovery attempt ${this.attempts} at ${this.lastCheckpoint}`,
        );
      });
      return;
    }
  }

  private recoveryKind(state: string): RecoveryKind {
    if (state === 'KNOCKOUT') return 'knockout';
    if (state === 'TRY_AGAIN') return 'try-again';
    return 'inconvenience';
  }

  private unexpectedRecoveryError(kind: RecoveryKind): Error {
    const apiFailure = this.lastGetLocationFailureStatus
      ? `; POST /home-api/rate/getLocation returned HTTP ${this.lastGetLocationFailureStatus}`
      : '';
    return new Error(
      `Unexpected ${kind} at ${this.lastCheckpoint}; automatic recovery skipped${apiFailure}; URL=${this.page.url()}`,
    );
  }

  private async capture(kind: RecoveryKind): Promise<void> {
    const prefix = this.recoveryEvidenceSuffix
      ? `recovery-${this.attempts + 1}-${kind}-${this.recoveryEvidenceSuffix}`
      : `break-${this.attempts + 1}-${kind}`;
    const screenshot = this.testInfo.outputPath(`${prefix}.png`);
    const html = this.testInfo.outputPath(`${prefix}.html`);
    const context = this.testInfo.outputPath(`${prefix}.json`);
    await this.page.screenshot({ path: screenshot, fullPage: true });
    await fs.writeFile(html, await safePageContent(this.page), 'utf8');
    await fs.writeFile(
      context,
      JSON.stringify(
        sanitizeTextEvidence({
          kind,
          attempt: this.attempts + 1,
          expected: this.expected === kind,
          checkpoint: this.lastCheckpoint,
          url: this.page.url(),
          title: await this.page.title().catch(() => ''),
          timestamp: new Date().toISOString(),
        }),
        null,
        2,
      ),
      'utf8',
    );
    await this.testInfo.attach(`${prefix}-screenshot`, { path: screenshot, contentType: 'image/png' });
    await this.testInfo.attach(`${prefix}-CopyDOM`, { path: html, contentType: 'text/html' });
    await this.testInfo.attach(`${prefix}-context`, { path: context, contentType: 'application/json' });
  }
}
