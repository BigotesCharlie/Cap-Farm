import { promises as fs } from 'node:fs';
import { test, type ConsoleMessage, type Page, type Request, type TestInfo } from '@playwright/test';
import { RecoveryGuard, type RecoveryKind } from './RecoveryGuard.js';
import { safePageContent } from './DomCheckpoint.js';
import { sanitizeTextEvidence } from './EvidenceSanitizer.js';
import type { ExecutionEvent } from '../migration/contracts/ExecutionTracker.js';

type Event = Readonly<{ at: string; kind: string; detail: string; checkpoint: string }>;

/** Per-test Sentinel. A scenario needs observable steps and a verified outcome to PASS. */
export class HealthCheck {
  private readonly events: Event[] = [];
  private stepCount = 0;
  private outcomeVerified = false;
  private checkpoint = 'setup';
  private readonly scenarioCheckpoints = new Set<string>();
  private scenarioIntegrationActive = false;
  private scenarioFailed = false;

  public constructor(
    private readonly page: Page,
    private readonly testInfo: TestInfo,
    private readonly recovery: RecoveryGuard,
  ) {}

  private readonly onPageError = (error: Error): void => this.record('pageerror', error.message);
  private readonly onRequestFailed = (request: Request): void =>
    this.record('requestfailed', `${request.method()} ${request.url()}: ${request.failure()?.errorText ?? 'unknown'}`);
  private readonly onConsole = (message: ConsoleMessage): void => {
    if (message.type() === 'error') this.record('console-error', message.text());
  };

  public start(): void {
    this.page.on('pageerror', this.onPageError);
    this.page.on('requestfailed', this.onRequestFailed);
    this.page.on('console', this.onConsole);
  }

  public observeExecutionEvent(event: ExecutionEvent): void {
    this.scenarioIntegrationActive = true;
    if (!event.success || event.type === 'error') {
      this.scenarioFailed = true;
      this.outcomeVerified = false;
      this.record('scenario-failure', event.type);
      return;
    }
    if (event.type === 'checkpoint' && !this.scenarioCheckpoints.has(event.id)) {
      this.scenarioCheckpoints.add(event.id);
      this.checkpoint = event.id;
      this.stepCount += 1;
    }
    const legacyId = this.testInfo.annotations.find((annotation) => annotation.type === 'legacy-id')?.description;
    if (event.type === 'assertion' && event.metadata?.finalOutcome === true && event.id === legacyId &&
        this.stepCount > 0 && !this.scenarioFailed) {
      this.outcomeVerified = true;
      this.record('scenario-final-assertions-passed', event.id);
    }
  }

  /** One observable screen transition. Capture the DOM after each step and on failure. */
  public async step<T>(label: string, action: () => Promise<T>, verify?: () => Promise<void>): Promise<T> {
    return test.step(label, async () => {
      this.checkpoint = label;
      await this.recovery.checkpoint(`before ${label}`);
      try {
        const result = await action();
        await this.recovery.checkpoint(`after ${label}`);
        if (verify) await verify();
        this.stepCount += 1;
        await this.capture(`step-${this.stepCount}`);
        return result;
      } catch (error) {
        this.record('step-failure', error instanceof Error ? error.message : String(error));
        await this.capture(`failure-${this.stepCount + 1}`).catch(() => undefined);
        throw error;
      }
    });
  }

  /** Call only after the scenario's own final UI assertions pass. */
  public async verifyOutcome(label: string, assertion: () => Promise<void>): Promise<void> {
    await this.step(label, async () => {
      await assertion();
    });
    this.outcomeVerified = true;
  }

  /** Expected KnockOut/Inconvenience/TryAgain still requires an explicit assertion. */
  public async verifyTerminal(kind: RecoveryKind, assertion: () => Promise<void>): Promise<void> {
    this.recovery.expectTerminal(kind);
    await this.step(`expected-${kind}`, async () => {
      await this.recovery.checkpoint(`expected ${kind}`);
      this.recovery.assertExpectedTerminal(kind);
      await assertion();
    });
    this.outcomeVerified = true;
  }

  public async stop(): Promise<void> {
    this.page.off('pageerror', this.onPageError);
    this.page.off('requestfailed', this.onRequestFailed);
    this.page.off('console', this.onConsole);
    if (this.scenarioIntegrationActive) {
      await this.testInfo.attach('health-execution-summary.json', {
        body: Buffer.from(JSON.stringify({
          observedCompletedCheckpoints: [...this.scenarioCheckpoints],
          stepCount: this.stepCount,
          outcomeVerified: this.outcomeVerified,
          scenarioFailed: this.scenarioFailed,
          statusBeforeHealthStop: this.testInfo.status,
          eventKinds: this.events.map((event) => event.kind),
        }, null, 2)), contentType: 'application/json',
      });
    }
    await this.testInfo.attach('sentinel-events.json', {
      body: Buffer.from(JSON.stringify(sanitizeTextEvidence(this.events), null, 2)),
      contentType: 'application/json',
    });
    if (process.env.ACEHOME_INSPECT_TARGET === 'smoke' &&
        this.testInfo.title === 'testSmokeReviewQuotePagePresentmentCardHome' && !this.page.isClosed()) {
      const url = new URL(this.page.url());
      const diagnostic = {
        url: url.origin + url.pathname,
        stepCount: this.stepCount,
        outcomeVerified: this.outcomeVerified,
        sentinelCheckpoint: this.checkpoint,
        playwrightStatusBeforeSentinel: this.testInfo.status,
        expectedStatus: this.testInfo.expectedStatus,
        annotations: this.testInfo.annotations.filter((annotation) =>
          ['assertAll-completed', 'logical-checkpoint', 'handler-status', 'provider-source-id'].includes(annotation.type)),
        eventKinds: this.events.map((event) => event.kind),
        requiredFinalAssertion: 'Smoke handler: validatePageTitleSubtitle, verifyQuotePresentmentCard, validateEmailThisQuoteLink, validateDiscounts, then fsa.assertAll',
      };
      const jsonPath = this.testInfo.outputPath('inspector-smoke-live.json');
      await fs.writeFile(jsonPath, JSON.stringify(diagnostic, null, 2), 'utf8');
      await fs.writeFile(this.testInfo.outputPath('inspector-smoke-live-dom.html'), await safePageContent(this.page), 'utf8');
      await this.page.screenshot({ path: this.testInfo.outputPath('inspector-smoke-live.png'), timeout: 8000 }).catch(() => undefined);
      console.log(`INSPECTOR_SMOKE_PAUSED_BEFORE_SENTINEL: ${jsonPath}`);
      await this.page.pause();
    }
    if (this.testInfo.status === 'passed' && (!this.stepCount || !this.outcomeVerified)) {
      throw new Error(`Sentinel: scenario has ${this.stepCount} observed steps and no verified final outcome`);
    }
    if (this.testInfo.status === 'passed' && this.events.some((event) => event.kind === 'pageerror')) {
      throw new Error('Sentinel: uncaught browser error; see sentinel-events.json');
    }
  }

  private record(kind: string, detail: string): void {
    this.events.push({ at: new Date().toISOString(), kind, detail, checkpoint: this.checkpoint });
  }

  private async capture(label: string): Promise<void> {
    if (this.page.isClosed()) return;
    const prefix = label.replace(/[^a-z0-9-]/gi, '-').toLowerCase();
    const html = this.testInfo.outputPath(`${prefix}-CopyDOM.html`);
    const image = this.testInfo.outputPath(`${prefix}.png`);
    await fs.writeFile(html, await safePageContent(this.page), 'utf8');
    await this.page.screenshot({ path: image, fullPage: true });
    await this.testInfo.attach(`${prefix}-CopyDOM`, { path: html, contentType: 'text/html' });
    await this.testInfo.attach(`${prefix}-screenshot`, { path: image, contentType: 'image/png' });
  }
}
