import type { Page } from '@playwright/test';
import { AceHomeQuoteRetrievalPage, AceHomeReviewQuotePage } from '../../pages/acehome/AceHomePages.js';
import type { ApplicantAceHome } from '../../models/acehome/ApplicantAceHome.js';
import type { FlowHooks } from './AceHomeNavigationFlow.js';

export class AceHomeRetrieveQuoteFlow {
  public constructor(
    private readonly page: Page,
    private readonly hooks: FlowHooks,
  ) {}

  public async retrieveByQuoteNumber(quoteNumber: string, applicant: ApplicantAceHome): Promise<AceHomeReviewQuotePage> {
    await this.page.goto('/', { waitUntil: 'domcontentloaded' });
    await this.hooks.checkpoint('quote-retrieval-landing');
    const retrieval = new AceHomeQuoteRetrievalPage(this.page);
    await retrieval.openSavedQuoteTab();
    await this.hooks.checkpoint('quote-retrieval-form');
    await retrieval.retrieveByQuoteNumber(quoteNumber, applicant);
    this.hooks.annotate('logical-checkpoint', 'quote-retrieval-submit');

    const review = new AceHomeReviewQuotePage(this.page);
    await review.assertOnPage();
    await this.hooks.checkpoint('11-review-quote-retrieved');
    return review;
  }
}
