# FFQ AceHome Bind Standalone

## Escenario y procedencia

Escenario: `com.farmers.ffq.acehome.AceHomeGoToPaymentSectionTest#testQuoteAndBindHomeLob`.

Spec unico: [tests/legacy/acehome/AceHomeGoToPaymentSectionTest.spec.ts](tests/legacy/acehome/AceHomeGoToPaymentSectionTest.spec.ts).

El codigo fuente se copio del repositorio original FFQ-Playwright-TS-V1, no de la copia aislada dentro de artifacts. Los modulos fuente y el spec conservan sus bytes originales. [PROVENANCE.json](PROVENANCE.json) distingue ambas raices y registra hashes. La copia aislada tiene modificaciones de handler, executor y flow que NO se transfirieron al codigo de este paquete.

**Ultimo resultado historico observado: BLOCKED en validacion del iframe PaymentUS; NO PASS E2E.** Ese resultado fue observado en el workspace aislado, ejecucion FFQ-20261102-124400. No constituye una ejecucion ni certificacion de este paquete original.

El host historico `frms-sit5-sit-945.paymentus.io` no cumple la comprobacion actual de sandbox del Page Object. No se modifico esa comprobacion. Requiere confirmacion/autorizacion del responsable de QA; no ingresar el instrumento en otro destino ni relajar el guard solo para conseguir PASS.

## Clasificacion de datos

**PAQUETE RESTRINGIDO:** contiene la fila de prueba QA TX/116, su descuento y los nueve registros del instrumento bancario QA existente. El propietario autorizo expresamente distribuir esta fixture para esta exportacion. No son credenciales ni datos bancarios inventados; no se publican sus valores en este README o manifiestos. No distribuir el ZIP como material publico.

No contiene .env, .npmrc, passwords de configuracion, tokens, node_modules, .git, otros specs, Excel del nuevo Home Bind, screenshots, videos, traces, test-results ni reportes generales.

## Dependencias

```text
tests/legacy/acehome/AceHomeGoToPaymentSectionTest.spec.ts
  src/fixtures/test.ts
    data/*.fixture.ts -> domain-provider.ts -> provider.ts
      LegacyProviderSelector -> FixtureCatalog -> LegacyDateFormula
      AceHomeQaBindData -> catalogo QA y configuracion MA11
    health/recovery.fixture.ts -> RecoveryGuard
    health/health-check.fixture.ts -> HealthCheck
    BrowserUi + DomCheckpoint + EvidenceSanitizer
  src/migration/ScenarioExecutor.ts
    migration/audit/legacy-method-contracts.json (un contrato)
    registry/HandlerCatalog.ts -> ScenarioHandlerRegistry
      AceHomeQuoteAndBindHandler
        AceHomeApplicantProvider -> ApplicantAceHome
        AceHomeNavigationFlow -> AceHomePages + AceHomePageClassifier
        SoftAssertCollector + AceHomePrivateRunCapture
      otros handlers importados por el registry (sin sus tests/datos)
    ExecutionTracker + ScenarioTypes + metadata
playwright.config.ts
  src/config/env.ts
  src/reporting/PlaywrightEnvironmentExecutionReporter.ts
    EnvironmentExecutionReport -> ExcelJS
    migration/audit/full-test-execution-inventory.json (una entrada)
```

[DEPENDENCIES.json](DEPENDENCIES.json) enumera recursivamente los 66 modulos y 173 enlaces de importacion, incluidos imports de tipos, imports dinamicos y reexports. [DEPENDENCY_TREE.md](DEPENDENCY_TREE.md) presenta el arbol completo sin repetir ciclos.

Se incluyen otros handlers AceHome y Auto, sus flows/pages/modelos y las fixtures fusionadas porque los modulos originales los importan al cargarse. No se ejecutan por importar el registry y no se incluyen otros tests. Eliminar esos modulos exigiria cambiar el registry o las fixtures compartidas; este paquete conserva el codigo original.

Las fixtures de datos no solicitadas son lazy. Sus otros catalogos no se necesitan al seleccionar este unico ID. Los assets de la aplicacion y PaymentUS son remotos; no se encontro un asset local adicional leido por esta ruta.

## Catalogo migrado

- AceHomeTestData: una fila PageValidationApplicantAceHome con sourceId 116/TX y su descuento enlazado. Se mantienen los valores y la transformacion legacy original de nombres.
- columns.json: definiciones completas de columnas de esas hojas.
- source-rows.json: numeros fisicos originales alineados con las filas recortadas; sourceId 116 no se presenta como numero fisico de fila Excel.
- provider-constants.json: constantes AceHomeDataProviders necesarias.
- state-support.json: lista MA11 AceHCR completa; el selector original sigue aplicando estado explicito TX y exclusiones Java.
- AutoTestData: las nueve filas Bank Account con los tres campos exigidos por loadQaBankFixture. El loader original verifica nueve filas y un unico instrumento; una sola fila no seria equivalente.
- Contrato: una entrada, sin modificar su contenido Java/metadata. Inventario del reporter: una entrada del test, no un reporte general.
- properties.json: solo environment.MA11.uri y uri_hqm; se quitaron todos los campos de credenciales y configuracion no usada.

No se encontraron formulas de referencia en la fila/discount seleccionados. El audit registra esa comprobacion; no fue necesario copiar otros solicitantes por referencias. No se sustituye este catalogo legacy por un Excel de otro flujo.

## Variables de entorno

Nombres necesarios para seleccionar la fila/estado y ambiente autorizado:

```text
TEST_ENV
FFQ_BASE_URL
ACEHOME_QUOTE_BIND_SOURCE_ID
FFQ_DATA_STATES
```

La seleccion soportada por este paquete es QA/MA11, TX, sourceId 116. El baseURL debe coincidir con la URI MA11 del archivo incluido. El loader exige sourceId y estado explicitos; no intenta escoger una fila alternativa.

Nombres opcionales de configuracion reproducible:

```text
HEADLESS
WORKERS
RETRIES
FFQ_DATA_SEED
FFQ_DATA_TIMEZONE
FFQ_ALLOW_PRODUCTION_EXECUTION
FFQ_KEEP_BROWSER_OPEN
TEST_TIMEOUT_MS
EXPECT_TIMEOUT_MS
ACTION_TIMEOUT_MS
NAVIGATION_TIMEOUT_MS
RECOVERY_MAX_ATTEMPTS
RECOVERY_POLL_INTERVAL_MS
PW_TEST_OUTPUT_DIR
FFQ_REPORTS_DIR
PLAYWRIGHT_HTML_OUTPUT_DIR
PLAYWRIGHT_HTML_OPEN
```

No se proporciona un .env ni valores secretos. Configurar las variables por el mecanismo autorizado de la organizacion. La ejecucion debe mantener produccion deshabilitada, no activar Inspector/PWDEBUG ni reutilizar sessionStorage, storageState o quote previos. HEADLESS=false significa navegador visible; los comandos tambien incluyen --headed.

## Instalacion limpia

Prerequisitos: Node.js conforme al engine de package.json (22 o posterior), npm, acceso a registry.npmjs.org y al CDN autorizado de Playwright. Descomprimir y abrir terminal en la raiz que contiene package.json; todas las lecturas runtime son relativas a esa raiz.

```powershell
npm ci
npx playwright install chromium
```

En Linux pueden requerirse librerias de sistema para Chromium y una sesion grafica/Xvfb para ejecucion visible. Gestionar esos requisitos con el administrador; no se incluye un navegador binario en el ZIP.

El lockfile y las versiones de dependencias son los originales. Los scripts del package.json se acotaron a este spec, discovery y typecheck; no se incluyen prepare/Husky, clean, hooks Git ni launchers de otras suites. No se requiere una carpeta .git ni archivos del repositorio original.

## Typecheck y discovery

```powershell
npm run typecheck
npx playwright test tests/legacy/acehome/AceHomeGoToPaymentSectionTest.spec.ts --project=chromium --grep testQuoteAndBindHomeLob --workers=1 --retries=0 --list --reporter=list
```

Resultado esperado de discovery: exactamente `1 test in 1 file`, proyecto chromium, metodo testQuoteAndBindHomeLob. Discovery no ejecuta el test, no navega a MA11 y no demuestra un PASS.

## Ejecucion autorizada del unico escenario

Solo ejecutar despues de configurar las variables y confirmar autorizacion/acceso QA y del destino PaymentUS. **La tarea de empaquetado no ejecuta E2E.**

```powershell
npx playwright test tests/legacy/acehome/AceHomeGoToPaymentSectionTest.spec.ts --project=chromium --grep testQuoteAndBindHomeLob --headed --workers=1 --retries=0
```

`npm test` contiene el mismo spec/metodo, Chromium visible, un worker y cero retries. No es el launcher del demo original ni acredita certificacion runtime.

## Requisitos y limites de ejecucion

El paquete es independiente del filesystem original, pero no es independiente de los servicios QA: requiere red corporativa/VPN, acceso a los hosts MA11, disponibilidad de UI/APIs, navegador descargado y autorizacion del instrumento bancario/destino externo. En Windows, AceHomePrivateRunCapture usa icacls y la identidad local para ACL de datos privados.

El codigo original difiere del historico aislado: mantiene preventAutomaticRecovery en Bind y la integracion original de HealthCheck. El executor original no conecta Bind a los eventos finales de HealthCheck; su cierre puede fallar aunque se alcance el endpoint. El flow original tambien conserva fallbacks genericos. No se repararon estos comportamientos al exportar, no se autoriza usar clicks forzados y no se afirma que este original vaya a alcanzar PASS al resolver PaymentUS.

Preservar RecoveryGuard, las aserciones originales y el assertAll final; no usar mocks, skips, banca inventada ni bypass del sandbox para obtener PASS. Las capturas generadas durante futuras ejecuciones pueden contener PII/tokens y deben permanecer restringidas.

## Referencias historicas

[ACEHOME_BIND_TECHNICAL_REPORT.md](ACEHOME_BIND_TECHNICAL_REPORT.md) y [BIND_HANDOFF.md](BIND_HANDOFF.md) se copian como referencias historicas de la preparacion/ejecucion aislada. No describen necesariamente los bytes originales exportados. Sus rutas a test-results o artifacts historicos pueden no existir aqui: esos recursos sensibles se excluyeron deliberadamente.

El sello del demo original estaba BROKEN; se registra en PROVENANCE sin modificarlo. Este ZIP no lo repara, no lo reemplaza y no copia ni utiliza su launcher/manifiesto para una nueva certificacion.

## Validaciones de exportacion

[VALIDATION.json](VALIDATION.json) registra instalacion limpia, typecheck, discovery y preflight de datos, sin E2E. [PACKAGE_CONTENTS.txt](PACKAGE_CONTENTS.txt) enumera el contenido del paquete. [PACKAGE_SHA256.json](PACKAGE_SHA256.json) permite verificar archivos despues de descomprimir. No se empaqueta node_modules instalado para validar.