# AceHome Bind: informe tecnico y ejecucion

## 1. Resultado verificable

**NO SE OBTUVO PASS.** La verificacion termino en `bind-06-add-bank`, antes de ingresar datos bancarios, porque el iframe PaymentUS no cumple la comprobacion actual de sandbox. No se modifico esa proteccion ni se intento comprar.

| Dato | Evidencia |
| --- | --- |
| Escenario | `com.farmers.ffq.acehome.AceHomeGoToPaymentSectionTest#testQuoteAndBindHomeLob` |
| Spec | [tests/legacy/acehome/AceHomeGoToPaymentSectionTest.spec.ts](tests/legacy/acehome/AceHomeGoToPaymentSectionTest.spec.ts) |
| Ejecucion del reporter | `FFQ-20261102-124400` |
| Carpeta de verificacion | `acehome-bind-audit-verify-20261102-124338` |
| Inicio del resultado de test | `2026-11-02T18:44:04.253Z` |
| Duracion del test | `357626 ms`, aproximadamente 5 min 58 s |
| Resultado Playwright | `failed`; un test, `retry=0`, cero skipped, cero flaky |
| Resultado funcional | Bloqueado por verificacion del destino de pago; no bind completado |
| Ambiente observado | QA/MA11; UI `ffqautouiqa.farmers.com`, Home API `ffqhomeuiqa.farmers.com` |
| Navegador | Chromium headed, un worker, contexto nuevo |
| Datos | `AceHomeTestData / PageValidationApplicantAceHome / sourceId=116 / TX` |
| Provider | `AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER` |
| Rama | `MONTHLY_BANK` |
| Etapas | 01-05 PASS local; 06 FAIL; 07-10 no alcanzadas |
| Final `fsa.assertAll()` | No alcanzado |
| Instrumento bancario | Procedencia QA comprobada; cero llamadas fill a los tres campos bancarios |
| Compra | Cero clicks `Complete purchase` observados |
| Integridad Bind | Los 20 hashes de preflight coinciden despues de la ejecucion |

El servidor HTML que Playwright abrio al terminar fue cerrado. No queda un test necesario para este trabajo ejecutandose.

## 2. Evidencia y alcance

El resultado nativo es [results.json](test-results/acehome-bind-audit-verify-20261102-124338/results.json). El [reporte HTML](test-results/acehome-bind-audit-verify-20261102-124338/html-report/index.html) permite consultar las etapas y adjuntos. Ambos pueden contener informacion sensible en sus recursos asociados; tratarlos como evidencia restringida.

| Archivo | Contenido |
| --- | --- |
| [execution-summary.json](test-results/acehome-bind-audit-verify-20261102-124338/execution-summary.json) | Estado, tiempos, conteos de acciones, ausencia de ingreso bancario/compra y artefactos |
| [source-method-inventory.json](test-results/acehome-bind-audit-verify-20261102-124338/source-method-inventory.json) | AST de 34 modulos: imports, clases, funciones, callbacks, interfaces, parametros, llamadas sintacticas y lineas |
| [runtime-api-actions.json](test-results/acehome-bind-audit-verify-20261102-124338/runtime-api-actions.json) | 6355 inicios de llamadas Playwright/expect y sus eventos de finalizacion/log; stacks y referencias de fuente de la traza |
| [network-summary.json](test-results/acehome-bind-audit-verify-20261102-124338/network-summary.json) | Las 36 solicitudes de aplicacion, metodo, host, path, status, tiempos; host PaymentUS sin query ni tokens |
| [quote-bind-steps.json](test-results/acehome-bind-audit-verify-20261102-124338/quote-bind-steps.json) | Accion, asercion, resultado y evidencia por etapa efectivamente iniciada |
| [quote-bind-checkpoints.json](test-results/acehome-bind-audit-verify-20261102-124338/quote-bind-checkpoints.json) | Orden de checkpoints, URL sin query, componente observado y accion activa |
| [bind-environment.json](test-results/acehome-bind-audit-verify-20261102-124338/bind-environment.json) | Ambiente, hosts, headed, fixture bancaria y getLocation HTTP 200 |
| [selected-fixture-rows.json](test-results/acehome-bind-audit-verify-20261102-124338/selected-fixture-rows.json) | Procedencia de la fila sin valores personales |
| [execution-tracker.json](test-results/acehome-bind-audit-verify-20261102-124338/execution-tracker.json) | Resumen/eventos del tracker |
| [health-execution-summary.json](test-results/acehome-bind-audit-verify-20261102-124338/health-execution-summary.json) | 24 checkpoints unicos, `outcomeVerified=false`, `scenarioFailed=true` |
| [isolated-bind-baseline.json](test-results/acehome-bind-audit-verify-20261102-124338/isolated-bind-baseline.json) | SHA-256 antes de la verificacion; NO es un sello del demo |
| [isolated-bind-integrity-verification.json](test-results/acehome-bind-audit-verify-20261102-124338/isolated-bind-integrity-verification.json) | Comparacion posterior de los 20 archivos |
| [extract-evidence.mts](test-results/acehome-bind-audit-verify-20261102-124338/extract-evidence.mts) | Extractor reproducible que analiza evidencia existente, sin lanzar navegador |

El inventario AST es estatico: incluye metodos no utilizados definidos en modulos compartidos. El inventario runtime registra operaciones instrumentadas por Playwright, no todas las invocaciones JavaScript puras. No se debe interpretar ninguno como un profiler completo ni como prueba de cobertura total.

Las entradas `before/after` de la traza se correlacionan por `callId`; las referencias compactas de fuente se resuelven con `stacks`. Los parametros de acciones se omiten de la extraccion para evitar exponer PII o banca. Los mensajes de log de la traza tambien se omiten; sus eventos se conservan. Los cuerpos HTTP, headers, queries y tokens no se exportan al resumen de red.

## 3. Cadena de ejecucion

```mermaid
flowchart TD
  Config[Configuracion Playwright + env] --> Fixtures[mergeTests: datos + RecoveryGuard + HealthCheck]
  Fixtures --> Spec[testQuoteAndBindHomeLob]
  Spec --> Executor[executeMigratedScenario]
  Executor --> Contract[Contrato inmutable de migracion]
  Executor --> Selection[aceHomeData: fila 116 / TX]
  Selection --> Catalog[Seleccion + formulas + descuentos + normalizacion]
  Executor --> Registry[ScenarioHandlerRegistry.resolve]
  Registry --> Handler[AceHomeQuoteAndBindHandler.execute]
  Handler --> Flow[AceHomeNavigationFlow]
  Flow --> Pages[Pages + locators + expect]
  Pages --> Setup[Payment Setup]
  Setup --> Sandbox[assertSandboxPaymentFrame]
  Sandbox --> Blocked[Host no verificado: detener antes de banca]
  Handler --> Evidence[Checkpoints / diagnosticos / trace / video]
  Evidence --> Reporter[JSON + HTML + reporter de ambiente]
```

### Spec y metadata

El spec es generado y no se edito. Importa `test` de la fixture fusionada y `executeMigratedScenario`. Solicita `{ page, aceHomeData }` y recibe `testInfo`.

La llamada al executor entrega `legacyId`, dominio `acehome`, fuente Java, `sourceLine=17`, clase, metodo, parametro Java `ApplicantAceHome applicant`, provider, providerClass, grupos y la anotacion Java completa. Esta declara `CATEGORY_BIND_VALIDATION` y excluye `CA, LA, MA, MS, NC`. Los grupos son metadata de migracion, no una implementacion independiente de pasos.

La fuente Java es una referencia del contrato; esta sesion no ejecuto Java ni probo paridad mediante un segundo runner Java.

### Executor y registry

En [src/migration/ScenarioExecutor.ts](src/migration/ScenarioExecutor.ts):

1. `loadContracts()` carga y cachea [legacy-method-contracts.json](migration/audit/legacy-method-contracts.json). Falta de contrato produce error, no PASS generico.
2. Se anotan ID, fuente Java y provider; se adjunta `legacy-contract.json`.
3. `legacyData(metadata)` obtiene las filas; se adjunta su procedencia sin valores personales.
4. `getHandlerRegistry().resolve(legacyId)` obtiene el handler; si falta, falla.
5. Se crea `ExecutionTracker` y el contexto con `page`, `testInfo`, metadata, contrato, filas, tracker, RecoveryGuard, `checkpoint` y `annotate`.
6. El checkpoint anota, captura DOM/screenshot, registra un evento y lo publica a HealthCheck.
7. El handler ejecuta la logica; un error se registra y vuelve a lanzarse.
8. Solo se acepta el retorno de Bind si existen `assertAll-completed` del ID correcto y `bind-endpoint-verified` con `CHECKOUT` o `FINISH_DOCUMENTS`.

[src/migration/registry/HandlerCatalog.ts](src/migration/registry/HandlerCatalog.ts) registra `new AceHomeQuoteAndBindHandler()`. [src/migration/registry/ScenarioHandlerRegistry.ts](src/migration/registry/ScenarioHandlerRegistry.ts) mantiene un `Map`, rechaza duplicados con `register()` y resuelve con `resolve()`. Que importe/registre otros handlers no significa que se ejecuten otros tests.

## 4. Fixtures y ciclo de vida

[src/fixtures/test.ts](src/fixtures/test.ts) fusiona las fixtures de datos AceHome, Auto, Bundle, SQL Auto, Classic, LegacyHome, Inline y Reference, ademas de recovery y health. Los providers de datos son lazy: este test solicita `aceHomeData`; fusionar los otros no implica usarlos.

| Fixture/objeto | Funcion y ciclo |
| --- | --- |
| `browser`, `context`, `page` | Fixtures nativas Playwright. Cada test recibe contexto/pagina nuevos; no se suministro storageState ni quote previo |
| `aceHomeData` | Fixture de test que entrega una funcion `DomainProvider<AceHomeApplicant>`, no una fila ya seleccionada |
| `createDomainProvider()` | Valida variante, hoja, estado y reglas de cardinalidad despues de seleccionar |
| `providerFor()` | Cache `Map<legacyId, Promise<SelectedCase[]>>` por test; verifica owner del provider y enruta Bind al selector especifico |
| `recoveryGuard` | Fixture `{ auto: true }`; crea guard, registra `WeakMap<Page,...>`, `start()`, `use()`, `stop()` y elimina la entrada |
| `healthCheck` | Fixture `{ auto: true }`; depende de `page` y `recoveryGuard`, instala listeners y valida cierre |
| `beforeEach` | `applyGlobalBrowserZoom(page, 0.75)` |
| `afterEach` | Escribe evidencia runtime sanitizada; si la pagina sigue abierta conserva DOM final y diagnostico de fallo |

Fuentes: [ace-home.fixture.ts](src/fixtures/data/ace-home.fixture.ts), [domain-provider.ts](src/fixtures/data/domain-provider.ts), [provider.ts](src/fixtures/data/provider.ts), [recovery.fixture.ts](src/fixtures/health/recovery.fixture.ts), [health-check.fixture.ts](src/fixtures/health/health-check.fixture.ts).

Reglas AceHome declaradas: `APPLICANT_ACE_HOME_DATA_PROVIDER` usa ApplicantHome; las variantes de categoria y nombre sin modificar usan PageValidationApplicantAceHome y `exactlyOne`; `ENVIRONMENT_STABILITY_DATA_PROVIDER` usa esta ultima hoja y `onePerState`. Para Bind, el selector especializado exige ademas exactamente una fila.

HealthCheck observa `pageerror`, `requestfailed` y errores de consola. En esta ejecucion recibio 24 checkpoints unicos y el evento de fallo del escenario. Su registro contiene un `pageerror`; resolver el destino de pago no demostraria por si solo que ese riesgo ha desaparecido.

## 5. Datos, seleccion y modelos

### Seleccion exacta

[src/data/providers/acehome/AceHomeQaBindData.ts](src/data/providers/acehome/AceHomeQaBindData.ts) contiene `ACE_HOME_QUOTE_BIND_LEGACY_ID`, `selectAceHomeQuoteBindCase()`, `getAceHomeBindEnvironment()`, `assertQaBindConfiguration()`, `getBindBankFixtureStatus()` y `loadQaBankFixture()`.

`selectAceHomeQuoteBindCase()` valida ID, provider y clase exactos, categoria/exclusiones en metadata, un sourceId numerico explicito y un estado explicito. Invoca `selectLegacyCases({...metadata, testName: 'row=116'}, {seed, environment, states:'TX'})` y exige source, hoja, ID, categoria, estado y campos obligatorios coherentes.

`sourceId=116` identifica el registro del catalogo. No se debe afirmar que es la fila fisica 116 de Excel: `SelectedAceHomeApplicant.rowNumber` se inicializa a 0 y no contiene esa trazabilidad fisica.

En [src/data/LegacyProviderSelector.ts](src/data/LegacyProviderSelector.ts), la ruta aplicable:

1. `sourceFor()` resuelve AceHomeTestData / PageValidationApplicantAceHome / modo perState.
2. `constants()`, `resolveConstant()` y `attributes()` interpretan constantes, categoria y atributos Java.
3. `rawRows()` lee el catalogo. Se filtra por categoria Bind validation, TX configurado, estados soportados de MA11 y exclusiones Java.
4. `testName=row=116` filtra el ID. `random()` y `pick()` mantienen seleccion determinista por seed; queda un candidato del estado.
5. `materializeRow()` evalua formulas de fechas de la fila seleccionada.
6. `joinChildren()` enlaza descuentos por `applicantId` y materializa sus formulas.
7. `prepareJavaApplicant()` aplica las mutaciones equivalentes a Faker existentes: en este provider AceHome, nombres con sufijo determinista. No altera el catalogo fuente.
8. Devuelve objetos `SelectedCase` congelados: `source`, `sheet`, `sourceId`, `state`, `data`.

[src/data/FixtureCatalog.ts](src/data/FixtureCatalog.ts) cachea workbooks/columnas/source-rows JSON. `materializeRow()` resuelve referencias de formulas por columnas y filas fuente, detecta ciclos y falla ante referencias no soportadas. `fixtureDate()` usa `FFQ_DATA_TIMEZONE` o America/Los_Angeles. [src/data/LegacyDateFormula.ts](src/data/LegacyDateFormula.ts) implementa la evaluacion de formulas; sus funciones estan enumeradas en el inventario AST.

No se ejecuta ExcelDataSource para esta ruta: se consume el catalogo JSON migrado. No se modifica la hoja ni se regenera el catalogo compartido.

### Conversion al modelo

[src/data/providers/acehome/AceHomeApplicantProvider.ts](src/data/providers/acehome/AceHomeApplicantProvider.ts):

- `fromFixture()` verifica source, ID y consistencia del estado; mapea descuentos y solicitante.
- `normalizeText()` resuelve Date, texto enriquecido, objetos con result y strings.
- `normalizeBoolean()` acepta true/yes/y/1; `normalizeNumber()` retorna numero finito o 0.
- `mapDiscount()` y `mapApplicant()` construyen el modelo tipado, sin leer otra fila alternativa.
- El resultado incluye workbook, worksheet, `rowNumber=0`, `seed=0`, correlationId y applicant. Esos ceros no son la seed real ni una fila Excel; la seed real de ejecucion se pasa separadamente al selector/captura.
- `fromBundleFixture()` existe en el modulo pero no es la ruta de este escenario.

Los campos completos y sus tipos estan en [src/models/acehome/ApplicantAceHome.ts](src/models/acehome/ApplicantAceHome.ts) y en el inventario AST. Se conservan sin publicar valores:

| Grupo | Campos |
| --- | --- |
| Identificacion/categoria | id, testCategory |
| Solicitante | firstName, lastName, dateOfBirth, gender, maritalStatus |
| Conyuge | spouseFirstName, spouseLastName, spouseDateOfBirth, spouseGender |
| Domicilio | address, unit, city, county, stateCode, state, zipCode |
| Domicilio anterior/actual | priorOrCurrentAddress, priorOrCurrentUnit, priorOrCurrentCity, priorOrCurrentCounty, priorOrCurrentStateCode, priorOrCurrentState, priorOrCurrentZipCode |
| Construccion | yearBuilt, squareFeet, numberOfStories, bathrooms, foundationType, exteriorWallFinish, roofCover, floorCoverings, heatingSystem, fireplace, garageCarport, garageStyle |
| Contacto | mailingAddressDifferent, emailAddress, phoneNumber, occupation |
| Proteccion | centralBurglarAlarm, centralFireAlarm, localBurglarAlarm, localFireAlarm, burglarAlarm, fireAlarm, alarmSystem, sprinklerSystem, smokeAlarm, waterLeakProtection, fortifiedHome |
| Riesgos/caracteristicas | nonSmoker, temporaryRentals, swimmingPool, solarPanels, trampoline, ulRoof, roofReplaced, mineSubsidence, newlyOwned, inEscrow, fireHydrant, homeVisible, secondaryHeatingSource, wroughtIronBars, previousInsurance, wildFireRisk, stormShutters |
| Actualizaciones | electricalUpdated, plumbingUpdated, hvacUpdated, earlyShoppingFactor |
| Agente/financiacion | agentId, lenderBank, lenderBankName, lenderIncompleteSelection, impoundAccountSelection |
| Preguntas adicionales | plumbingOtherThanCopperPexPVC, primaryHeatingSource, updatedPrimaryHeatingSource, unrepairedStructures, businessOperatedOnPremises, dogsOnPremises, updatedDogsOnPremises, petWithBiteHistory |
| Hijos | discounts |

`HomeDiscount` contiene discountId, applicantId, paymentMethod, startDateOfNewPolicy, autoInsurance, umbrellaInsurance, lifeInsurance, homeInsurance, rentersInsurance, condoInsurance, valueTermLifeInsurance, recreationalBoatWatercraftInsurance, motorcycleInsurance, businessInsurance, ownOrRentHome, paymentMethodForDiscount, mediaAlphaTimeAtResidence, mediaAlphaHasGarage, signalSignup y multiPolicyCEA.

### Fixture bancaria

Solo se permite el instrumento existente `AutoTestData/payments`: nueve filas Bank Account con una unica combinacion routing/account. El loader exige routing de 9 digitos y cuenta de 10, verifica ambiente y retorna `Object.freeze({routingNumber, accountNumber, source})`.

En MA11 su procedencia esta autorizada por el repositorio. La disponibilidad de esa fixture NO autoriza cualquier iframe externo. RA11 devuelve fixture no disponible y debe detenerse antes de Set Up Payment. Esta sesion no uso RA11 ni publico los numeros bancarios.

## 6. Handler: objetos y diez etapas

[src/migration/handlers/acehome/AceHomeQuoteAndBindHandler.ts](src/migration/handlers/acehome/AceHomeQuoteAndBindHandler.ts) es el controlador de negocio.

Objetos: contexto de ejecucion; `SelectedCase`; `SelectedAceHomeApplicant`; `ApplicantAceHome`; `QaBankFixture` opcional hasta etapa 05; `AceHomePrivateRunCapture`; `AceHomeNavigationFlow`; `AceHomePageClassifier`; `SoftAssertCollector`; paginas Dwelling/PaymentSelection/Payment; `Response` del primer fallo; arrays de etapas/checkpoints/red; conjunto de origenes; promesa `serviceFailure`.

El handler valida configuracion y una sola fila, calcula modo (`UT -> PIF`, otros estados -> MONTHLY_BANK), anota procedencia/ambiente y exige RecoveryGuard. La rama ejecutada fue TX/MONTHLY_BANK; la ruta UT no esta validada por este informe.

`step(name, action, assertion, work)` anota accion, escribe diagnostico begin, ejecuta `test.step()` con `Promise.race([work(), serviceFailure])`, registra completed/checkpoint y PASS local. Ante error escribe failed, agrega FAIL y relanza. Un PASS de etapa no es PASS del test.

| Etapa | Metodos principales | Contrato | Runtime |
| --- | --- | --- | --- |
| bind-01-dwelling | `flow.navigateToDwellingCoveragePage(applicant)` | Llegar a Dwelling Coverage | PASS; 160870 ms dentro de test.step |
| bind-02-review | `AceHomeDwellingCoveragePage.clickContinue()`; `flow.waitForReviewQuoteAfterDwellingContinue()` | Llegar a Review Quote con RecoveryGuard | PASS; 62651 ms |
| bind-03-selection | `flow.continueFromReviewToPaymentSelection(applicant)` | Additional Coverages, JFMT, Payment Selection | PASS; 64538 ms |
| bind-04-payment | `selectMonthlyAutoPayBank()`; `payment.assertOnPage(mode)` | Encabezado y modo de pago correctos | PASS; 15227 ms |
| bind-05-setup | `loadQaBankFixture()`; `payment.openBankSetup()` | Fixture autorizada, dialogo y un iframe | PASS; 453 ms |
| bind-06-add-bank | `payment.addQaBankAccount()` -> `assertSandboxPaymentFrame()` | Verificar sandbox antes de fill | FAIL; 61 ms; cero fill bancarios |
| bind-07-bank-details | `validateAddedBank(bank,fsa)`; `fsa.assertAll('Added bank validation')` | Mensaje, icono, cuenta enmascarada y ultimos cuatro | No alcanzada |
| bind-08-service-charge | `validateBankServiceCharge(state,fsa)`; assertAll | TX: texto exacto sin cargos por transferencia | No alcanzada |
| bind-09-footer | `validateMonthlyAgreement(fsa)`; assertAll | Textos originales de acuerdos mensuales | No alcanzada |
| bind-10-endpoint | `completeQaPurchase(fsa)`; assertAll | Checkout o confirmacion Finish Documents | No alcanzada |

Despues debe ejecutarse `fsa.assertAll('Ace Home - Validate quote and bind, end-to-end.')`, comprobar endpoint y emitir `bind-endpoint-verified` y `assertAll-completed`. Nada de esto se alcanzo en la verificacion.

Las duraciones de `test.step` excluyen parte del trabajo de checkpoints del wrapper; no deben sumarse como si fueran la duracion completa del test.

## 7. Navegacion detallada

[src/flows/acehome/AceHomeNavigationFlow.ts](src/flows/acehome/AceHomeNavigationFlow.ts) recibe page, hooks y RecoveryGuard; crea un classifier y mantiene `tx116PhoneDigitGestureApplied` por instancia.

### Hasta Dwelling Coverage

1. `page.goto('/', {waitUntil:'domcontentloaded'})`, relativo al baseURL; `capture('01-home-start')`.
2. `dismissCookieBannerIfPresent()`: Reject o Close visibles; checkpoint posterior.
3. `selectHomeProductAndStart()`: Home por role option, comprobar aria-selected, llenar ZIP de la misma fila, Tab y verificar persistencia; click Start Quote, capturar y `waitForPostStartTransition()`.
4. `failClosedIfKnockoutEncountered()`: detecta interstitial/textos terminales y falla, no los transforma en exito.
5. `ensurePropertyInfoWithFallbackFill()`: reconocimiento de entrada; `waitForPrePropertyEntryState()`, `completeLetsBeginIfPresent()`, `completeHomePersonalInfoIfPresent()`, `completeGuidewireYourInfoIfPresent()` y nueva comprobacion knockout.
6. Rama Property Type: Home y residencia principal Yes si estan visibles, sin forzar; alternativamente Property Info llena campos visibles por label y selecciones con datos de applicant.
7. Checkpoint Property Information; `clickPrimaryContinue()`, `advancePastHomeDetailsIfPresent()` y Quality Grade si aparece.
8. `ensurePropertyDetailsPage()`, checkpoint y Continue.
9. `ensureAdditionalInfoPage()`, checkpoint y Continue. Este metodo de reconocimiento solo anota si no identifica el estado: no equivale por si solo a una asercion de negocio.
10. `isNewFlowEnabledState()` retorna true para AZ/TX/CA. TX no entra a About You independiente; esto es una rama del flujo, no un test skipped.
11. `AceHomeContactInfoPage.assertOnPage()`, `fillContactInfo()` y `clickAgreeAndSubmit()`.
12. `AceHomeDwellingCoveragePage.assertOnPage()` y checkpoint; retorna el objeto pagina.

La ruta Bind usa `navigateToDwellingCoveragePage()`, no `navigateToReviewQuotePage()`. Son metodos distintos del mismo modulo; no se deben atribuir a Bind todos los auxiliares exclusivos de la segunda ruta.

### Personal Info y telefono

`completeLetsBeginIfPresent()` llena nombre/apellido/DOB y usa Agree si corresponde. `completeHomePersonalInfoIfPresent()` reconoce la ruta personal-info, completa direccion si falta, ciudad/ZIP y contacto, y espera respuesta POST submitYourInfo despues de un submit accionable.

Para TX/116, `usesPinnedPersonalInfoPhone()` activa la proteccion de telefono fuente. `phoneCandidates()` devuelve solo formatos de los mismos digitos, sin agregar los telefonos alternativos genericos que existen fuera de Bind.

`reenterLastPersonalInfoPhoneDigit()` comprueba diez digitos, focaliza, End, ajusta posicion si hay caracteres finales, Backspace, reingresa el mismo ultimo digito y Tab. Valida igualdad antes/despues, ausencia de aria-invalid y errores de telefono; emite checkpoint. Se aplica una sola vez. No cambia el numero fuente.

`assertPersonalInfoPhoneValid()` usa expect.poll, igualdad de digitos y validacion UI. La rama fijada no prueba numeros inventados hasta que el formulario acepte uno.

`fillContactInfo()` completa fecha de inicio solo si falta, preguntas requeridas, email si falta, telefono y opcion Auto visible. `AceHomeContactInfoPage.fillRequiredSelections()` traduce hydrant/homeVisible/secondaryHeatingSource a radios y llena genero si esta presente. Las respuestas salen del modelo.

### Review y Payment Selection

`waitForReviewQuoteAfterDwellingContinue()` exige RecoveryGuard y espera REVIEW_QUOTE, permitiendo estado intermedio REVIEW_QUOTE_LOADING y detectando INCONVENIENCE/KNOCKOUT/TRY_AGAIN. Configura 90 s, polling 350 ms y `failOnRecoveryState=true` en esta frontera; luego exige el contrato Review y captura.

`continueFromReviewToPaymentSelection()` valida Review, click Continue, valida Additional Coverages, click Continue, valida JFMT, `fillOut(applicant)`, captura, `clickContinue()`, valida Payment Selection y retorna el objeto.

JFMT usa `#lenderToggleNo`, comprueba la clase seleccionada, fecha solo si falta y cero mat-error. Antes de continuar instala dos waitForResponse POST: saveHomeAdditionalInfo y performVerifyRate; exige respuestas observadas con status menor de 400, respuesta terminada y loader oculto.

### Auxiliares de accion y captura

`fillVisibleInput()`, `selectVisibleOption()`, `toggleIfVisible()`, `normalizedPhone()`, `clickPrimaryContinue()`, `clickByRoleName()`, `waitForBlockingSpinnerToClear()`, `clickWithInterceptionRecovery()` y `capture()` estan en el inventario. No todos deben ejecutarse en cada variante de UI.

`clickWithInterceptionRecovery()` intenta clicks normales con espera del spinner; no es un retry del test. El fallback forzado de Home Details queda bloqueado cuando existe `ACEHOME_QUOTE_BIND_SOURCE_ID`. La alternativa generica para otros escenarios no fue ejecutada ni modificada funcionalmente.

## 8. Pages, locators y aserciones

Las pages estan agrupadas en [src/pages/acehome/AceHomePages.ts](src/pages/acehome/AceHomePages.ts); el reconocimiento esta en [src/pages/acehome/AceHomePageClassifier.ts](src/pages/acehome/AceHomePageClassifier.ts).

| Page/objeto | Metodos relevantes de Bind | Locators/condiciones |
| --- | --- | --- |
| PropertyInfo | `assertOnPage()` en ruta tradicional | Heading de propiedad, radiogroup de tipo de casa, Continue enabled |
| QualityGrade | `isQualityGradePageAlone()`, `clickContinueIfVisible()` | Heading quality grade, Continue visible; despues heading Property Details |
| PropertyDetails | Contrato soportado por auxiliares del flow | Heading Property Details; el classifier tambien acepta Additional Info en assertOnPage |
| AdditionalInfo | `isNewFlowEnabledState()` | AZ/TX/CA; sus validadores roof/pool/persistencia existen pero no son todos llamados por Bind |
| AboutYou | `assertOnPage()`, `clickContinue()` en estados aplicables | Rama independiente no tomada por TX |
| ContactInfo | `assertOnPage()`, `fillRequiredSelections()`, `clickAgreeAndSubmit()` | Hydrant, visibilidad, calefaccion secundaria, genero, Continue visible/unico/enabled |
| DwellingCoverage | `assertOnPage()`, `continueButton()`, `clickContinue()` | Classifier DWELLING_COVERAGE; `#continueButton` o Continue accesible |
| ReviewQuote | `assertOnPage()`, `clickContinue()` | Classifier REVIEW_QUOTE; boton Continue/Review optional coverages/Next |
| AdditionalCoverages | `assertOnPage()`, `clickContinue()` | Heading additional/optional coverages; Continue |
| JustAFewMoreThings | `assertOnPage()`, `fillOut()`, `clickContinue()` | lender No, fecha, cero errores, dos respuestas POST y loader hidden |
| PaymentSelection | `assertOnPage()`, `selectMonthlyAutoPayBank()` | Heading exacto How would you like to pay?; boton exacto Monthly autopay bank, Select and setup payment |
| Payment | `assertOnPage('MONTHLY_BANK')`, `openBankSetup()`, `addQaBankAccount()` | Home policy payment, Monthly autopay - bank, setup enabled, dialogo y un iframe PaymentUS |
| AppStoreReader | `read()`, `selectedPaymentMode()` en rama PIF | Lee sessionStorage actual; no restaura estado previo. No es requisito de selectedPaymentMode para TX mensual |
| PageClassifier | `detect()`, `describeCurrentPage()` y predicados privados | Prioriza estados recovery, luego contratos por headings/controles/URL; UNKNOWN si no identifica |

`safeScrollAndClick()` y `clickAfterReadiness()` en [src/core/BrowserUi.ts](src/core/BrowserUi.ts) esperan attached/visible/enabled, scroll, layout estable y trial click. Solo despues hacen click real. Los logs del recorrido muestran actionability PASS para Dwelling, Review, Additional Coverages y Monthly Bank.

El classifier no es una asercion exhaustiva de contenido: por ejemplo REVIEW_QUOTE puede reconocerse por URL, y hay catches/fallbacks en auxiliares compartidos. Este informe no certifica por esas heuristicas la paridad completa de todos los contratos Java.

### Validaciones de pago posteriores no alcanzadas

`addQaBankAccount()` primero ejecuta `assertSandboxPaymentFrame()`. Solo despues deberia usar frameLocator, esperar `#routingNumberField`, llenar routing, Tab, verificar nombre del banco, llenar `#bankAccountField` y `#confirmBankAccountField`, revalidar sandbox, click submitBtn y esperar dialogo hidden.

`validateAddedBank()` exige el mensaje exacto Bank payment account added., icono de banco y cuenta enmascarada coincidente. `validateBankServiceCharge()` exige para TX No service charges when using bank transfer.; AL tiene contrato diferente.

`validateMonthlyAgreement()` conserva tres textos originales: encabezado By clicking Complete purchase, aceptacion Paperless Terms of Use y autorizaciones de almacenamiento/pagos. El metodo retorna si Complete purchase no esta visible; el contrato alternativo lo decide el paso final.

`completeQaPurchase()` espera Complete purchase o Finish documents. En la segunda rama valida exactamente la confirmacion de datos de pago y retorna FINISH_DOCUMENTS, sin afirmar firma terminada. En checkout hace click Complete purchase y espera Sign electronically, pago exitoso o Choose a password; si ve firma, click Start signing y retorna CHECKOUT.

## 9. Bloqueo PaymentUS

Mensaje de error: `BLOCKED: payment instrument entry requires a verified non-production PaymentUS iframe.`

Metodo que decide: `AceHomePaymentPage.assertSandboxPaymentFrame()`. Fuente: [src/pages/acehome/AceHomePages.ts](src/pages/acehome/AceHomePages.ts). Se requiere HTTPS, hostname terminado en `.paymentus.com` y regex `qa|uat|sandbox|test|stg|stage|nonprod` en el hostname.

La traza registra `frms-sit5-sit-945.paymentus.io` por HTTPS. El dominio `.paymentus.io` no cumple el sufijo permitido y `sit5` tampoco cumple la regex actual. No se copian path/query del iframe porque pueden incluir tokens.

El endpoint `/auto-api/auto/bind/paymentUSiFrameSUTUrls` respondio 200. Eso no es evidencia suficiente para autorizar el destino externo. La presencia de `sit` en un nombre sugiere un entorno de pruebas, pero no prueba por si sola la autorizacion del instrumento QA ni permite relajar el guard.

Para una continuacion futura hace falta confirmar con el responsable del ambiente la procedencia y autorizacion exacta de ese host para MA11, documentar una allowlist respaldada por configuracion/evidencia y obtener autorizacion de una nueva ejecucion. Esta sesion ya uso su correccion y verificacion; no modifica el guard ni ejecuta mas intentos.

## 10. Red y cronologia observada

Las 36 entradas de aplicacion capturadas fueron HTTP 200. Hay dos startQuote y multiples performVerifyRate/getDropDownList observados; son solicitudes de la aplicacion, no evidencia de reintentos del runner. No se oculta su duplicidad.

Recorrido por servicios: startQuote, fetchDropDownList, projectCodeStatus, V2StaticContent, saveQuoteSubInfo, getDropDownList, validateEmail, submitYourInfo, getPrefillData, assignAgent, invokeQuoteConsented, savePropertyType, getPropertyPrefill, getLocation, editPropertyPrefill, fetchBundleQuestion, saveDiscounts, saveContactInfo, callIOR, saveCustomCoverage, getPerilReport, getCoverageValues, performHomeRate, saveHomeAdditionalInfo, performVerifyRate y paymentUSiFrameSUTUrls. Sus paths completos, repeticiones, timestamps y duraciones estan en network-summary.

La ejecucion historica `FFQ-20261027-123535` habia fallado por V2StaticContent HTTP 500. No se reutilizo su quote/session ni se presento su resultado como actual. En esta verificacion ese endpoint y getLocation respondieron 200.

Checkpoints ordenados del recorrido: 01-home-start; 01a-after-cookie; 02-after-home-product-selection; 02b-after-start-click; 03-lets-begin; 03b-after-lets-begin; personal-info-phone-digit-reentry; 04-property-information; 06-property-details; 07-additional-information; 09-contact-information; 10-dwelling-coverage; bind-01-dwelling; 11-review-quote; bind-02-review; 12-additional-coverages; 13-just-a-few-more-things; 13a-jfmt-ready; 13b-after-jfmt-continue; 14-payment-selection; bind-03-selection; bind-04-payment; bind-05-setup; bind-first-failure. Algunos nombres 03 se emitieron mas de una vez; el JSON conserva las entradas, pero los archivos con el mismo prefijo pueden sobrescribirse.

## 11. Guardas, errores y evidencia

`RecoveryGuard.start()` mantiene monitor independiente y listener de getLocation. `checkpoint()` revisa fallos/estados, `inspectRecovery()` sincroniza inspecciones y `waitForStateWithRecovery()` espera estados con limite/politica. Captura screenshots, DOM y contexto ante recovery. `stop()` retira listener y propaga fallos pendientes. Se mantuvo activo.

`SoftAssertCollector.check()` acumula fallos y captura evidencia; `equal()` compara con igualdad estricta; `assertAll()` lanza error si hay fallos acumulados. Los assertAll intermedios de pago y el final se preservaron. No se agregaron mocks, skips ni aserciones falsas.

El listener de respuesta de Bind observa `/home-api/` y `/auto-api/`, verifica origenes y rechaza el primer HTTP >=400 o mismatch. `Promise.race()` corta la etapa. El catch bloquea nuevas solicitudes, captura primer HTTP si existe, toma checkpoint de fallo, anota estado, sanitiza el mensaje y cierra page. No se clasifico el bloqueo PaymentUS como un HTTP 500.

El finally adjunta diagnosticos, ambiente, checkpoints y etapas. `ExecutionTracker` registra el error. HealthCheck retira listeners y adjunta resumen; RecoveryGuard se detiene. El reporter escribe resultado JSON de ambiente y workbook en la carpeta aislada de esta ejecucion.

`bind-wait-diagnostics.jsonl` registra timestamp, fase begin/completed/failed/checkpoint, presencia de headings, componentes/locators con count/attached/visible/enabled, ultimas respuestas y callsite. Es diagnostico por etapa/checkpoint, no un hook de cada wait primitivo. Las esperas primitivas, accionabilidad y stacks se conservan en trace.zip y su extraccion runtime.

La sanitizacion existente de `safePageContent()` usa parse5, conserva estructura/atributos de locator permitidos y elimina textos/valores/scripts. `sanitizeTextEvidence()` sustituye todos los strings no vacios, incluso timestamps y mensajes tecnicos; por ello los resumenes extraidos de metadata no dependen de recuperar valores de esos JSON sanitizados.

`AceHomePrivateRunCapture.start()` crea private-inputs con permisos restrictivos y ACL Windows; registra eventos input/change/click y snapshots de filas/modelos/appStore. Filtra secretos/banca, pero conserva PII del solicitante en esa carpeta privada. No se copian esos valores a este informe. `saveAtPayment()` existe pero este handler Bind no lo llama: el status privado IN_PROGRESS no debe usarse como prueba de PASS.

El estado privado se persiste en checkpoints; un fallo posterior puede dejar eventos de red mas recientes solo en la traza. La captura privada no reemplaza al resultado Playwright.

### Artefactos de fallo

Directorio: [artifacts del test](test-results/acehome-bind-audit-verify-20261102-124338/artifacts/legacy-acehome-AceHomeGoTo-ea52e-est-testQuoteAndBindHomeLob-chromium).

- [Screenshot final](test-results/acehome-bind-audit-verify-20261102-124338/artifacts/legacy-acehome-AceHomeGoTo-ea52e-est-testQuoteAndBindHomeLob-chromium/bind-first-failure.png).
- [DOM final sanitizado](test-results/acehome-bind-audit-verify-20261102-124338/artifacts/legacy-acehome-AceHomeGoTo-ea52e-est-testQuoteAndBindHomeLob-chromium/bind-first-failure.html).
- [Trace ZIP restringido](test-results/acehome-bind-audit-verify-20261102-124338/artifacts/legacy-acehome-AceHomeGoTo-ea52e-est-testQuoteAndBindHomeLob-chromium/trace.zip).
- [Video restringido](test-results/acehome-bind-audit-verify-20261102-124338/artifacts/legacy-acehome-AceHomeGoTo-ea52e-est-testQuoteAndBindHomeLob-chromium/video.webm).
- [Diagnosticos JSONL](test-results/acehome-bind-audit-verify-20261102-124338/artifacts/legacy-acehome-AceHomeGoTo-ea52e-est-testQuoteAndBindHomeLob-chromium/bind-wait-diagnostics.jsonl).

Hubo un fallo de screenshot en 02b-after-start-click; su advertencia y DOM se conservaron. No se afirma que todas las capturas intermedias PNG existan. Screenshots, video, trace y error-context pueden incluir PII o tokens; no distribuirlos como evidencia publica sanitizada.

## 12. Preparacion, correccion y verificacion

Cambios solo en copias fisicas del workspace aislado:

1. Handler: diagnosticos Bind, `test.step` por etapa, exigir RecoveryGuard activo y quitar la llamada que prohibia recuperacion automatica globalmente.
2. Flow: fallar cerrado antes del fallback de click forzado de Home Details cuando se ejecuta Bind.
3. Executor: conectar el ID exacto Bind a HealthCheck para que este observe checkpoints/fallo/assertAll, sin cambiar las reglas de exito de Sentinel.
4. Tras evidencia del primer intento, una correccion del diagnostico: reemplazar classifier sobre about:blank por snapshot DOM sin esperas, y adjuntar el JSONL al finalizar en lugar de copiarlo vacio al inicio.

El primer intento [acehome-bind-audit-20261102-123526](test-results/acehome-bind-audit-20261102-123526) fue interrumpido aproximadamente a los siete minutos por el bloqueo introducido en el diagnostico inicial: el classifier esperaba headings repetidamente sobre about:blank antes del primer goto. Fue un defecto de la instrumentacion agregada en esta sesion, no un fallo probado del servicio. Se conservan resultado/traza y baseline de ese intento; no se reescribieron para ocultarlo.

Hubo discovery inicial con cero tests por un filtro de titulo demasiado anclado, corregido antes de abrir navegador. Un comando de preparacion devolvio outcome desconocido; se comprobaron procesos y carpetas antes de continuar para no duplicar ejecuciones. No hubo una tercera ejecucion del test.

Verificaciones realizadas: TypeScript `tsc --noEmit --pretty false --incremental false` sin errores tras los cambios; discovery del archivo/metodo con un unico test; ejecucion del extractor sobre la traza; chequeos de editor sin errores; hashes posteriores coincidentes. No se ejecuto suite global ni otros escenarios. No se certifica paridad Java completa ni un checkout que no se alcanzo.

## 13. Configuracion y reproduccion documental

[playwright.config.ts](playwright.config.ts) usa baseURL de env, timeout de test por defecto 600000 ms, expect 15000 ms, action 30000 ms y navigation 60000 ms. Conserva screenshot/trace/video al fallar, locale en-US, timezone America/Los_Angeles. El CLI selecciono solo chromium y sobreescribio worker/retries/headed.

Variables aplicadas: TEST_ENV=MA11, HEADLESS=false, WORKERS=1, RETRIES=0, FFQ_ALLOW_PRODUCTION_EXECUTION=false, FFQ_KEEP_BROWSER_OPEN=false, ACEHOME_QUOTE_BIND_SOURCE_ID=116, FFQ_DATA_STATES=TX. La seed fue el nombre unico de la carpeta de cada intento. Se retiraron PWDEBUG, ACEHOME_INSPECT_TARGET, ACEHOME_ENDTOEND_TX_ROW_OVERRIDE y FFQ_DATA_SCENARIOS de la terminal de ejecucion.

FFQ_BASE_URL se leyo de properties.environment.MA11.uri, sin hardcode en el spec. PW_TEST_OUTPUT_DIR, PLAYWRIGHT_HTML_OUTPUT_DIR, PLAYWRIGHT_JSON_OUTPUT_NAME y FFQ_REPORTS_DIR se dirigieron a la nueva carpeta fisica de cada intento. No se uso npm clean ni scripts que regeneren catalogos.

Comando del test ya ejecutado, consignado solo como evidencia, no como autorizacion para repetirlo:

```powershell
node ./node_modules/@playwright/test/cli.js test tests/legacy/acehome/AceHomeGoToPaymentSectionTest.spec.ts --project=chromium --grep testQuoteAndBindHomeLob --headed --workers=1 --retries=0 --reporter=list,json,html,./src/reporting/PlaywrightEnvironmentExecutionReporter.ts
```

Analisis reproducible de evidencia existente, sin nuevas solicitudes a la aplicacion:

```powershell
node --experimental-strip-types test-results/acehome-bind-audit-verify-20261102-124338/extract-evidence.mts
```

## 14. Separacion del demo original

El workspace activo es la copia aislada autorizada por [.github/copilot-instructions.md](.github/copilot-instructions.md). Config, data, migration, node_modules y src/data/catalog son junctions compartidos y se trataron como solo lectura. Los cambios de codigo se hicieron en archivos fisicos locales.

Esta baseline acredita coincidencia de 20 archivos de Bind desde su preflight hasta la verificacion. No es DEMO_FROZEN, no restaura hashes del demo, no repara su sello ni certifica que el demo original pueda abrir Chromium. El handoff historico conserva su estado anterior; no se alteraron manifiesto, instrucciones, launcher ni evidencia del demo original.

No se ejecutaron Review/Smoke como tests, TC3, Codegen, Inspector ni run-demo. Pasar por la pantalla Review Quote es parte de Bind y no equivale a ejecutar esos otros escenarios. No se hizo commit, push ni PR.

**Cierre:** se documento el recorrido real hasta el bloqueo. No es tecnicamente correcto ni autorizado declarar PASS, ingresar banca en un destino no verificado o inventar el resultado de las etapas restantes.