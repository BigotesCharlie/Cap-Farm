// iGero: pure, side-effect-free Playwright test discovery helpers.
// Java method identifiers are not necessarily Playwright test titles.
const COMMON = new Set(['ace','home','test','tests','page','lob','content','validation','validate','validations','and','the','of','on','to','for','in','spec','ts','java','method','acehome','data','with','when','from','section']);
export function tokens(value) {
  return [...new Set(String(value).replace(/([a-z\d])([A-Z])/g, '$1 $2').replace(/([A-Z])([A-Z][a-z])/g, '$1 $2').split(/[^a-z\d]+/i).map(x=>x.toLowerCase()).filter(x=>x.length>=2 && !COMMON.has(x)))];
}
export function parsePlaywrightList(output) {
  const found=[];
  for(const raw of String(output||'').split(/\r?\n/)) {
    // Actual Playwright list reporter: [project] › file.spec.ts:line:column › full test title
    const line=raw.replace(/\x1b\[[\d;]*m/g,'');
    const m=line.match(/^\s*\[([^\]]+)\]\s*›\s*(.+?\.(?:spec|test)\.[cm]?[jt]sx?):(\d+):(\d+)\s*›\s*(.*?)\s*$/);
    if(!m)continue;
    found.push({project:m[1],listingFile:m[2].replace(/\\/g,'/'),line:Number(m[3]),column:Number(m[4]),title:m[5]});
  }
  return found;
}
export function methodRelevance(sel, relativePath, title, sourceMentionsMethod=false) {
  const wanted=tokens(sel.name);
  const found=tokens(relativePath+' '+title);
  const overlap=wanted.filter(x=>found.includes(x));
  const titleWords=tokens(title);
  const titleOverlap=wanted.filter(x=>titleWords.includes(x));
  return {
    // Strong evidence: a descriptive title and a matching filename (not merely a source comment).
    score:titleOverlap.length*4+overlap.length*2+(sourceMentionsMethod?2:0)+(String(title).includes(sel.name)?20:0),
    evidence:overlap,sourceMentionsMethod,
    eligible:Boolean(title.includes(sel.name) || (overlap.length>=2 && (titleOverlap.length>=1 || sourceMentionsMethod)))
  };
}
export function chooseFocusedTest(entries, methodId, previousManifest=null, explicit=null) {
  const valid=entries.filter(x=>x.runnable && x.eligible);
  if(explicit) {
    const chosen=valid.find(x=>x.relativePath===explicit.relativePath && x.title===explicit.title && x.line===Number(explicit.line) && x.project===explicit.project);
    if(!chosen)throw new Error('Selected test is not registered for the selected Java method. Run Discover runnable tests and select a current entry.');
    return chosen;
  }
  if(previousManifest?.methodId===methodId){
    const chosen=valid.find(x=>x.specPath===previousManifest.specPath && x.title===previousManifest.testTitle && x.project===previousManifest.project);
    if(chosen)return chosen;
  }
  // Project variants representing the same test are deduplicated only if one is an
  // obvious Chrome target; never guess a browser project when several qualify.
  const chrome=valid.filter(x=>/chrome|chromium/i.test(x.project));
  const pool=chrome.length===1 && valid.every(x=>x.relativePath===chrome[0].relativePath && x.line===chrome[0].line && x.title===chrome[0].title)
    ? chrome:valid;
  if(pool.length===1)return pool[0];
  if(pool.length===0)throw new Error('NO_MAPPED_EXECUTABLE_TEST: Playwright registered no confidently mapped test for the Java method. Select a discovered registered test or implement a dedicated test; no browser was launched.');
  throw new Error(`AMBIGUOUS_TEST_MAPPING (${pool.length}): select the exact Playwright-registered title in the dashboard; no browser was launched.`);
}
