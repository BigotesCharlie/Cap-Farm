import test from 'node:test';
import assert from 'node:assert/strict';
import {parsePlaywrightList,methodRelevance,chooseFocusedTest,tokens} from '../focused-test-resolver.mjs';
const method={id:'AceHomeNameAndDobPageTest#testContentValidationNameAndDobPageHomeLob',name:'testContentValidationNameAndDobPageHomeLob'};
function item({title='HOME Name and DOB content validation',path='tests/acehome/HomeNameAndDobContentValidation.spec.ts',line=17,project='chromium',source=true}={}) {
  const relevance=methodRelevance(method,path,title,source);
  return {specPath:`/repo/${path}`,relativePath:path,line,project,title,runnable:true,eligible:relevance.eligible};
}
test('regression: parses registered descriptive title without Java method name',()=>{
  const output='Listing tests:\n  [chromium] › tests/acehome/HomeNameAndDobContentValidation.spec.ts:17:5 › HOME Name and DOB content validation\nTotal: 1 test in 1 file';
  const matches=parsePlaywrightList(output);
  assert.equal(matches.length,1);
  assert.equal(matches[0].title,'HOME Name and DOB content validation');
  assert.equal(matches[0].line,17);
  assert.ok(!matches[0].title.includes(method.name));
  assert.ok(methodRelevance(method,'tests/acehome/HomeNameAndDobContentValidation.spec.ts',matches[0].title,true).eligible);
});
test('regression: single runnable alias is selected even when Java-name grep would return zero',()=>{
  const x=item();
  assert.equal(chooseFocusedTest([x],method.id),x);
});
test('regression: source comments alone do not certify an unrelated runnable test',()=>{
  const x=item({title:'Payment screen navigation',path:'tests/acehome/OtherHelpers.spec.ts'});
  assert.equal(methodRelevance(method,x.relativePath,x.title,true).eligible,false);
  assert.throws(()=>chooseFocusedTest([x],method.id),/NO_MAPPED_EXECUTABLE_TEST/);
});
test('regression: missing registered test is not a functional pass',()=>{
  assert.equal(parsePlaywrightList('Error: No tests found.').length,0);
  assert.throws(()=>chooseFocusedTest([],method.id),/NO_MAPPED_EXECUTABLE_TEST/);
});
test('regression: multiple source-mapped real tests demand a human title selection',()=>{
  const a=item({title:'HOME Name and DOB content validation',line:17});
  const b=item({title:'Name and DOB page content checks',path:'tests/acehome/AceHomeNameAndDobPageTest.spec.ts',line:26});
  assert.throws(()=>chooseFocusedTest([a,b],method.id),/AMBIGUOUS_TEST_MAPPING/);
  assert.equal(chooseFocusedTest([a,b],method.id,null,{relativePath:b.relativePath,line:b.line,project:b.project,title:b.title}),b);
});
test('regression: stale manually selected line cannot trigger an unintended test',()=>{
  assert.throws(()=>chooseFocusedTest([item()],method.id,null,{relativePath:'tests/acehome/HomeNameAndDobContentValidation.spec.ts',line:9,project:'chromium',title:'HOME Name and DOB content validation'}),/not registered/);
});
test('regression: duplicate browser projects prefer only a single Chrome target for the same test',()=>{
  const chrome=item({project:'chromium'}),firefox=item({project:'firefox'});
  assert.equal(chooseFocusedTest([chrome,firefox],method.id),chrome);
});
test('regression: preserving matching manifest after code line changes',()=>{
  const cur=item({line:28});
  const manifest={methodId:method.id,specPath:cur.specPath,testTitle:cur.title,project:cur.project,line:17};
  assert.equal(chooseFocusedTest([cur],method.id,manifest),cur);
});
test('regression: no incorrect mapping for unrelated HOME test',()=>{
  const rel=methodRelevance(method,'tests/acehome/AceHomeAddressValidation.spec.ts','Address page duplex content validation',false);
  assert.equal(rel.eligible,false);
});
