import os, tempfile, subprocess, pathlib, json, time, urllib.request, urllib.error, shutil, urllib.parse
root=pathlib.Path(tempfile.mkdtemp(prefix='igero_reg_'))
java=root/'java'; ts=root/'pw'; bin=root/'bin'
(java/'src/test/java/com/farmers/ffq/acehome').mkdir(parents=True)
(ts/'tests/acehome').mkdir(parents=True)
(ts/'node_modules/@playwright/test').mkdir(parents=True)
(ts/'node_modules/.bin').mkdir(parents=True)
(ts/'node_modules/.bin/playwright').touch()
(ts/'node_modules/@playwright/test/package.json').write_text('{"version":"1.64.0"}')
(bin).mkdir(parents=True)
(java/'src/test/java/com/farmers/ffq/acehome/AceHomeNameAndDobPageTest.java').write_text('''public class AceHomeNameAndDobPageTest {\n @Test(dataProvider="fake")\n public void testContentValidationNameAndDobPageHomeLob() { assert 1 == 1; }\n}''')
(ts/'tests/acehome/HomeNameAndDobContentValidation.spec.ts').write_text('''import { test, expect } from '@playwright/test';\nconst legacyId='AceHomeNameAndDobPageTest#testContentValidationNameAndDobPageHomeLob';\n// Aligned with the prior functional spec, with a descriptive title.\ntest('HOME Name and DOB content validation', async ({ page }) => {expect(true).toBeTruthy();});''')
a=ts/'migration/pervez-json/AceHomeNameAndDobPageTest__testContentValidationNameAndDobPageHomeLob'
a.mkdir(parents=True)
(a/'contract.json').write_text(json.dumps({'className':'AceHomeNameAndDobPageTest','methodName':'testContentValidationNameAndDobPageHomeLob','steps':[],'assertions':[{'name':'source-check'}],'unresolved':[]}))
(a/'prompt.md').write_text('Implement HOME Name and DOB content test, using original Java source and Excel data.')
# Mock executor replicates Playwright CLI listing and reporting, no real browser or network.
(bin/'npx').write_text('''#!/usr/bin/env python3
import os,sys,json
args=sys.argv[1:]
if 'playwright' not in args: sys.exit(1)
if os.environ.get('IGERO_MOCK_BLOCK_FILE') and os.path.isfile(os.environ['IGERO_MOCK_BLOCK_FILE']):
 print('Error: No tests found.')
 sys.exit(1)
if '--list' in args:
 print('Listing tests:')
 print('  [chromium] › tests/acehome/HomeNameAndDobContentValidation.spec.ts:4:1 › HOME Name and DOB content validation')
 print('Total: 1 test in 1 file')
 sys.exit(0)
if '--reporter=json' in args:
 report={'suites':[{'title':'','specs':[{'title':'HOME Name and DOB content validation','tests':[{'projectName':'chromium','expectedStatus':'passed','status':'expected','results':[{'status':'passed','duration':24,'steps':[{'title':'expect.toBeTruthy','duration':2}]}]}]}]}]}
 open(os.environ['PLAYWRIGHT_JSON_OUTPUT_NAME'],'w').write(json.dumps(report))
 print('MOCK report stored; no actual browser launched')
 sys.exit(0)
sys.exit(1)
''')
(bin/'npm').write_text('#!/bin/sh\necho "MOCK: TypeScript check pass"\nexit 0\n')
for f in (bin/'npm',bin/'npx'): f.chmod(0o755)
env=os.environ.copy(); env['IGERO_PANEL_PORT']='18866';env['PATH']=str(bin)+os.pathsep+env['PATH'];env['IGERO_MOCK_BLOCK_FILE']=str(root/'force_no_tests')
source_launcher=pathlib.Path(__file__).resolve().parents[1]
launcher=root/'launcher'
launcher.mkdir()
for filename in ('server.mjs','focused-test-resolver.mjs','index.html','app.js'):
 shutil.copy2(source_launcher/filename,launcher/filename)
proc=subprocess.Popen(['node','server.mjs'],cwd=launcher,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT, text=True)
def api(endpoint,data=None):
 request=urllib.request.Request('http://127.0.0.1:18866'+endpoint, data=json.dumps(data).encode() if data is not None else None, headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(request,timeout=10) as r:return json.load(r)
try:
 for _ in range(35):
  try:print('server',api('/api/job')); break
  except Exception:time.sleep(.1)
 cfg=api('/api/config',{'javaRoot':str(java),'playwrightRoot':str(ts),'testEnv':'MA11','autoTypecheck':True,'autoFunctionalCheck':True})
 print('configReady',cfg['ready'])
 methods=api('/api/methods?q=AceHomeNameAndDob')
 print('methods',methods)
 assert len(methods['methods'])==1
 method='AceHomeNameAndDobPageTest#testContentValidationNameAndDobPageHomeLob'
 discovery=api('/api/spec-candidates?id='+urllib.parse.quote(method))
 print('discovery',discovery)
 assert discovery['registered']==1
 first=discovery['entries'][0]
 assert first['title']=='HOME Name and DOB content validation' and first['eligible']
 start=api('/api/start',{'methodId':method,'mode':'functional'})
 print('start',start)
 state={}
 for _ in range(150):
  state=api('/api/job')
  if state['status']!='running':break
  time.sleep(.1)
 print('final',state['status'], state['functional'])
 assert state['status']=='completed'
 assert state['functional']['verdict']=='FUNCTIONAL_PASS'
 assert state['functional']['counts']['passed']==1
 summary=json.loads((a/'functional-summary.json').read_text())
 assert summary['projectName']=='chromium'
 print('PASS: backend discovery -> specific line -> JSON report -> Live functional status [MOCK ONLY]')
 (root/'force_no_tests').touch()
 retry=api('/api/start',{'methodId':method,'mode':'functional'})
 for _ in range(120):
  state=api('/api/job')
  if state['status']!='running':break
  time.sleep(.1)
 assert state['status']=='blocked'
 print('negative',state['status'],state['functional'])
 assert state['functional']['verdict'] in ('BLOCKED','NOT_EXECUTED')
 assert state['functional']['counts']['total']==0
 print('PASS: when discovery fails, previous green result is archived and UI shows BLOCKED [MOCK ONLY]')
finally:
 proc.terminate()
 try:proc.wait(timeout=2)
 except:proc.kill()
 shutil.rmtree(root,ignore_errors=True)
