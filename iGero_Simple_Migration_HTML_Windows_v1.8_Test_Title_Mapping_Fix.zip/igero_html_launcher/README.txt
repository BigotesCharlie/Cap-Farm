iGERO SIMPLE MIGRATION — v1.8 · REGISTERED TEST MAPPING + MA11 QA FUNCTIONAL EXECUTION
=================================================================

This local Windows dashboard automates the two-step Pervez migration method:
Java Selenium/TestNG -> contract.json + prompt.md -> Playwright TypeScript.
It now includes a final real Playwright Functional TC Check and displays
individual test/step results in English.

WHAT IS NEW IN V1.6
-------------------
* Section 0: System Readiness checks Node.js, Copilot CLI --version, Java source,
  target Playwright folder and project-local Playwright installation.
* Copilot login is deliberately marked NOT VERIFIED until a genuine Copilot
  request. Version checks do not consume AI credits and never read credentials.
* Running migrations is blocked early when required tools are missing.
* Java source method safety classification no longer scans unrelated Excel
  DataProvider values or generic contract metadata. Explicit sensitive actions
  still require separate QA/business execution approval.
* Playwright JSON reporting uses PLAYWRIGHT_JSON_OUTPUT_NAME as documented.
* A missing RA11_BASE_URL or similar Playwright config error is separate from
  Node or Copilot readiness and must be fixed in the project's environment.

INSTALL / UPDATE
----------------
1. Stop the old local iGero server (close its command prompt window).
2. Unzip this package into a folder of your choice.
3. If updating an older version, replace the old application files but
   KEEP your config.local.json (if it exists).
4. Launch the dashboard and click Check system in Section 0 (no manual CLI check required).
5. Double-click Start-iGero-HTML.cmd.
6. Open http://127.0.0.1:8766/ if the browser does not open automatically.
7. Verify the System Readiness cards, then select the exact Java @Test method and choose
   Run full migration.

DEFAULT PROJECT PATHS
---------------------
Java source (read-only):
D:\Users\CARLOS.GARCIA19\Master\ffq-test-master

Playwright TypeScript target:
D:\Users\CARLOS.GARCIA19\PW-TS-MM\FFQ-Playwright-TS-master

NEW: AUTOMATIC FUNCTIONAL TC CHECK
----------------------------------
* After generating the .spec.ts and passing TypeScript typecheck, the dashboard
  attempts a focused Playwright run against the real test application.
* It runs only the selected source method's test title, isolated from unrelated
  cases using --grep with the exact Java method name. Generated spec titles
  are instructed to include that method name.
* Uses --headed --workers=1 --retries=0, and the Playwright project chosen
  from the test discovery output. The actual browser channel depends on your
  Playwright project configuration. The dashboard does not rewrite that config.
* Saves an official Playwright JSON report and a sanitized summary in:

  migration/pervez-json/<Class>__<Method>/functional-report.json
  migration/pervez-json/<Class>__<Method>/functional-summary.json
  migration/pervez-json/<Class>__<Method>/spec-manifest.json

* Section 7 displays test counts, results, durations, errors and recorded
  Playwright steps. The individual test result is a real Playwright result,
  never inferred from typecheck. Java runtime parity remains NOT_VERIFIED.
* 'Run Functional TC Check' can run the already migrated method without
  calling Copilot or regenerating the artifacts. It validates TypeScript first.
* Uncheck 'Run Functional TC Check automatically' to skip browser execution
  after migration. Manual execution remains possible for safe scenarios.

SENSITIVE SCENARIO SAFETY
-------------------------
Bind, payment, bank, purchase, policy binding and email tests are not
executed automatically or from the manual functional button in this pilot.
They require a separate, explicitly authorized QA/business execution process.
They are marked SKIPPED_SAFETY, not PASS.

STATUS RULES
------------
FUNCTIONAL_PASS: at least one matching Playwright test executed and all
  tests were expected passes, without skipped, failed or interrupted tests.
FUNCTIONAL_FAILED: actual Playwright execution failed or included skips.
BLOCKED: no single matching spec/test could safely be isolated, typecheck
  failed, or test discovery failed.
SKIPPED_SAFETY: no browser was started for a sensitive business scenario.
NOT_EXECUTED: functional check was explicitly disabled.

AI CREDITS
----------
AI-credit selection remains AUTOMATIC. The launcher does not specify
--max-ai-credits. Your Copilot account and corporate policies still apply.
Autopilot continuations are bounded. No claim of unlimited usage is made.

REQUIRED TOOLS / SECURITY
-------------------------
Node.js, GitHub Copilot CLI, the existing project's Playwright dependencies
and a permitted QA test environment. Do not run this local service on a
public network. It listens only on 127.0.0.1. Do not share raw runtime reports
if they contain personal/customer data.

Java and source Excel are instructed to remain read-only, and the dashboard
checks for accidental file changes. That check is not an OS permission boundary.
Back up or Git-commit your target workspace before allowing Copilot writes.

Local static/server tests were performed without running your corporate
QA application. The actual GitHub Copilot CLI and real Playwright runtime
remain to be verified on your Windows workstation.


V1.6 FIXES (Nov 23 2026)
--------------------------
* If Copilot reports a source-matching existing .spec.ts and leaves it unchanged,
  this no longer fails just because the file mtime did not change.
* The launcher verifies a unique source-method-bearing spec, reuses it, and
  proceeds to TypeScript validation and focused Playwright discovery/execution.
  REUSED_EXISTING is implementation reuse, never automatic Java or runtime parity.
* A new run archives the previous functional summary. The LIVE panel never shows
  an earlier SKIPPED_SAFETY as though it belongs to the current run.
* When migration ends early, Functional TC Check explicitly reports NOT_EXECUTED.
* Functional runs and TypeScript validation now set TEST_ENV=MA11 by default.
  To use RA11, select it deliberately and provide valid RA11 settings in the
  Playwright project. The launcher does not invent RA11_BASE_URL.
* Same security policy: no automatic execution of sensitive business actions.

CURRENT KNOWN LIMITATION
------------------------
Static detection of a source-referenced spec and passing typecheck cannot prove
source assertion parity. Playwright discovery and execution are required before
any FUNCTIONAL_PASS. Actual QA browser validation must be performed on Windows.

VERSION 1.7 — MULTIPLE SPECS RESOLUTION
A .spec.ts containing the Java method name in a comment or metadata is NOT enough.
iGero uses Playwright --list --grep for each candidate spec (without launching a browser),
and automatically selects the one spec registering the selected Java TestNG method.
If two or more specs genuinely register it, use Discover runnable specs and select the
correct .spec.ts from the dropdown. The selection is validated, then persisted in
spec-manifest.json for subsequent runs. No arbitrary file paths or false PASS are allowed.
Existing Name/DOB spec files are never overwritten just because discovery is ambiguous.


VERSION 1.8 — TEST TITLE ALIAS & LINE-BASED FOCUS REGRESSION FIX
----------------------------------------------------------------
* Removes the Java-method-name --grep from Playwright discovery and execution.
  Existing Playwright tests may use descriptive names that differ from Java.
* File-only --list determines the real registered title, location and project.
* A source-aware token match correlates the Java method with the Playwright
  filename/title. If candidates remain ambiguous, select an individual test
  including project, filename and line; no arbitrary test is executed.
* Runs only the selected file:line + project after verifying that the selection
  registers exactly one test. Preserves --headed --workers=1 --retries=0.
* Explicitly differentiates NOT_DISCOVERED from FAILED. A TypeScript build or
  stale history never counts as a Functional PASS.
* The offline regression tests in regression/focused-test-resolver.test.mjs
  validate title mismatch, no-test, duplicate, project and mapping outcomes.
  Run with: node --test regression/focused-test-resolver.test.mjs
* Does NOT claim live Farmers Chrome execution; that requires authorized QA
  runtime on your Windows workstation.
