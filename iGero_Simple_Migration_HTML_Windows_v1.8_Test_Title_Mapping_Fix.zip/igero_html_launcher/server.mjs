import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { parsePlaywrightList, methodRelevance, chooseFocusedTest } from './focused-test-resolver.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const HOST = '127.0.0.1';
const PORT = Number(process.env.IGERO_PANEL_PORT || 8766);
const CONFIG_FILE = path.join(HERE, 'config.local.json');
const DEFAULT = {
  javaRoot: 'D:\\Users\\CARLOS.GARCIA19\\Master\\ffq-test-master',
  playwrightRoot: 'D:\\Users\\CARLOS.GARCIA19\\PW-TS-MM\\FFQ-Playwright-TS-master',
  autoTypecheck: true,
  autoFunctionalCheck: true,
  testEnv: 'MA11', // Select only the configured QA lane; never invent RA11 URLs.
};
// In automatic mode no artificial --max-ai-credits flag is supplied.
// Existing config.local.json files may still contain maxAiCredits from v1.2.
// Ignore that legacy value, but preserve their source/destination paths.
let config = fs.existsSync(CONFIG_FILE) ? { ...DEFAULT, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) } : { ...DEFAULT };
delete config.maxAiCredits;
let currentJob = null;
let runningProcess = null;
let activeCopilotStage = null;
let copilotStopReason = null;
const CREDIT_LIMIT_RE = /\b(?:session limit reached|ai credit(?:s)? (?:session )?limit reached|credit limit reached|future model calls (?:will )?stop|maximum ai credits reached|credit budget exceeded)\b/i;
const CONTINUE_LIMIT_RE = /\b(?:autopilot (?:continuation|continue) limit reached|max(?:imum)? autopilot continues reached)\b/i;
let dispatchPending = false;
let methodCache = [];
let lastMethodScan = 0;
const clients = new Set();
const MAX_LOGS = 1500;
const STATUSES = ['pending','running','pass','blocked','skipped'];
const STEP_NAMES = ['Locate Java method', 'Copilot: generate JSON + prompt.md', 'Validate generated contract', 'Copilot: implement complete spec.ts', 'Validate TypeScript', 'Functional TC Check — Playwright', 'Save results'];
function sendEvent(event, data) {
  for (const res of clients) { try { res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); } catch { clients.delete(res); } }
}
function jobPublic() {
  if (!currentJob) return null;
  const {id, methodId, status, startedAt, endedAt, steps, logs, artifacts, error, aiCreditsObserved, functional} = currentJob;
  return {id, methodId, status, startedAt, endedAt, steps, logs: logs.slice(-200), artifacts, error, aiCreditMode:'automatic', aiCreditsObserved, functional};
}
function log(message, kind='log') {
  if (!currentJob) return;
  // CLI usage information is informational, not an authoritative billing total.
  // It may be absent depending on CLI version and log format.
  if (activeCopilotStage && currentJob) {
    const raw = String(message);
    const usage = raw.match(/\bAI Credits?\s+([0-9]+(?:\.[0-9]+)?)(?=\s|$|\()/i)
      || raw.match(/\b([0-9]+(?:\.[0-9]+)?)\s*\/\s*[0-9]+(?:\.[0-9]+)?\s+AI Credits? used\b/i);
    if (usage) {
      const number = Number(usage[1]);
      if (Number.isFinite(number) && number >= 0)
        currentJob.aiCreditsObserved[activeCopilotStage] = Math.max(currentJob.aiCreditsObserved[activeCopilotStage] || 0, number);
    }
    if (CREDIT_LIMIT_RE.test(raw)) copilotStopReason = 'Copilot reached a CLI or organization AI-credit limit';
    if (CONTINUE_LIMIT_RE.test(raw)) copilotStopReason = 'Copilot reached the automatic-continuation limit';
  }
  const line = { t: new Date().toLocaleTimeString(), text: String(message).slice(0, 1200), kind };
  currentJob.logs.push(line);
  if (currentJob.logs.length > MAX_LOGS) currentJob.logs.shift();
  sendEvent('log', line);
}
function step(index, status, note='') {
  if (!currentJob) return;
  currentJob.steps[index] = {name: STEP_NAMES[index], status, note};
  sendEvent('status', jobPublic());
}
function json(res, status, value) {
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.end(JSON.stringify(value));
}
function safeText(s){ return String(s||'').replace(/\x1b\[[0-9;]*m/g,'').replace(/\r/g,''); }
function validRoot(p) {try { return fs.statSync(p).isDirectory(); } catch { return false; }}
function rootChecks() {
  const j=validRoot(config.javaRoot), p=validRoot(config.playwrightRoot);
  return { javaExists:j, targetExists:p, javaRoot:config.javaRoot, playwrightRoot:config.playwrightRoot, ready:j&&p};
}
// Non-invasive readiness checks: no login, no AI request and no browser is launched.
async function probeCommand(command, args=[], cwd=HERE, timeoutMs=6000) {
  return await new Promise(resolve=>{
    let output='';let done=false;let child;
    const finish=(ok, note='')=>{if(done)return;done=true;clearTimeout(timer);resolve({ok,detail:safeText(output).trim().slice(0,240)||note});};
    const timer=setTimeout(()=>{try{child?.kill()}catch{}finish(false,'Version check timed out')},timeoutMs);
    try {
      child=spawn(command,args,{cwd,windowsHide:true,env:{...process.env,NO_COLOR:'1'}});
      const add=b=>{output+=b.toString();if(output.length>2000)output=output.slice(-2000)};
      child.stdout.on('data',add);child.stderr.on('data',add);
      child.once('error',e=>finish(false,e.code==='ENOENT'?'Command not found':e.message));
      child.once('close',code=>finish(code===0,code===0?'Version available':`Exit code ${code}`));
    } catch(e){finish(false,e.message)}
  });
}
async function systemReadiness() {
  const roots=rootChecks();
  const major=Number((process.version.match(/^v(\d+)/)||[])[1]||0);
  const node={status:major>=22?'PASS':'FAIL',value:process.version,
    detail:major>=22?'Node.js is running this local dashboard.':'Node.js 22 or newer is required by this launcher.'};
  const copilotProbe=process.platform==='win32'
    ? await probeCommand('powershell.exe',['-NoProfile','-NonInteractive','-Command','& copilot --version'],HERE)
    : await probeCommand('copilot',['--version'],HERE);
  const copilot={status:copilotProbe.ok?'PASS':'FAIL',value:copilotProbe.ok?copilotProbe.detail:'Unavailable',
    detail:copilotProbe.ok?'Copilot CLI is callable from the same server environment. Authentication is verified only when a real prompt runs.':
      'Copilot CLI was not found or cannot start. Run copilot --version and, if necessary, copilot login in PowerShell.'};
  const java={status:roots.javaExists?'PASS':'FAIL',value:roots.javaRoot,detail:roots.javaExists?'Source folder accessible (read-only policy).':'Java source folder unavailable.'};
  const target={status:roots.targetExists?'PASS':'FAIL',value:roots.playwrightRoot,detail:roots.targetExists?'Playwright target folder accessible.':'Playwright target folder unavailable.'};
  let packageFound=false;let executableFound=false;
  if(roots.targetExists){
    const nm=path.join(roots.playwrightRoot,'node_modules');
    packageFound=fs.existsSync(path.join(nm,'@playwright','test','package.json'));
    executableFound=fs.existsSync(path.join(nm,'.bin',process.platform==='win32'?'playwright.cmd':'playwright'));
  }
  const playwright={status:packageFound&&executableFound?'PASS':'FAIL',value:packageFound?'@playwright/test detected':'Not installed',
    detail:packageFound&&executableFound?'Project-local Playwright CLI and test package are present. Actual browser and config are checked during Functional TC Check.':
      'Missing project-local @playwright/test or Playwright binary. Check npm install in the target project.'};
  const authentication={status:'INFO',value:'NOT VERIFIED',detail:'A CLI version check cannot verify GitHub login or corporate entitlement. If Copilot prompts fail, use copilot login or verify organization access.'};
  const checks={node,copilot,java,target,playwright,authentication};
  return {checkedAt:new Date().toISOString(),checks,
    migrationReady:[node,copilot,java,target,playwright].every(v=>v.status==='PASS'),
    functionalReady:[node,java,target,playwright].every(v=>v.status==='PASS'),
    note:'Non-invasive preflight: no AI credits consumed, no browser launched, no authentication token exposed.'};
}
async function walk(root, limit=4000) {
  const result=[]; const stack=[root];
  while(stack.length && result.length < limit){
    const dir=stack.pop();
    let entries=[]; try{entries=await fsp.readdir(dir,{withFileTypes:true});}catch{continue;}
    for(const e of entries){
      if(e.name.startsWith('.') || ['build','target','node_modules','out','gradle'].includes(e.name))continue;
      const file=path.join(dir,e.name);
      if(e.isDirectory())stack.push(file);else if(e.isFile() && e.name.endsWith('.java'))result.push(file);
    }
  }
  return result;
}
async function collectMethods(){
  const javaDir = path.join(config.javaRoot, 'src','test','java');
  if(!validRoot(javaDir))return [];
  const files=await walk(javaDir);
  const found=[];
  for(const file of files){
    let txt;try{txt=await fsp.readFile(file,'utf8')}catch{continue;}
    if(!(/acehome|home/i.test(file)))continue;
    const className = (txt.match(/\bclass\s+(\w+)/)||[])[1] || path.basename(file,'.java');
    // Associate each @Test annotation with the next method declaration, not every helper.
    const re=/@Test\b/g; let match;
    while((match=re.exec(txt))!==null){
      const before=txt.slice(Math.max(0, match.index-25),match.index);
      if(/\/\/[^\n]*$/.test(before))continue;
      const rest=txt.slice(match.index,match.index+1300);
      const method=rest.match(/(?:public|protected)\s+(?:(?:static|final|synchronized)\s+)*[\w<>\[\], ?]+?\s+(\w+)\s*\([^)]*\)\s*(?:throws\s+[\w, ]+)?\s*\{/);
      if(!method)continue;
      const name=method[1]; if(['if','for','while'].includes(name))continue;
      const id=`${className}#${name}`;
      if(found.some(x=>x.id===id))continue;
      found.push({ id, className, name, relativePath:path.relative(config.javaRoot,file).replace(/\\/g,'/'), file });
    }
  }
  return found.sort((a,b)=>a.id.localeCompare(b.id));
}
async function findMethod(id) {
  if(!/^[A-Za-z_$][\w$]*#[A-Za-z_$][\w$]*$/.test(id))throw new Error('Use JavaClass#methodName');
  if(Date.now()-lastMethodScan>120000 || !methodCache.length){ methodCache=await collectMethods();lastMethodScan=Date.now(); }
  let selected=methodCache.find(x=>x.id===id);
  if(!selected){methodCache=await collectMethods();lastMethodScan=Date.now();selected=methodCache.find(x=>x.id===id);}
  if(!selected)throw new Error(`Java @Test method ${id} was not found in the selected source project.`);
  return selected;
}
function artifactPaths(selected){
  const dir=path.join(config.playwrightRoot,'migration','pervez-json',`${selected.className}__${selected.name}`);
  return {dir,json:path.join(dir,'contract.json'),prompt:path.join(dir,'prompt.md'),runLog:path.join(dir,'copilot-run.log'),specManifest:path.join(dir,'spec-manifest.json'),functionalReport:path.join(dir,'functional-report.json'),functionalSummary:path.join(dir,'functional-summary.json')};
}
function promptForExtraction(sel,a){
return `TASK: Export the COMPLETE REAL Java Selenium/TestNG test source contract into exactly TWO files.\nJava repository (READ-ONLY): ${config.javaRoot}\nJava class: ${sel.className}\nExact @Test method: ${sel.name}\nJava source file: ${sel.file}\nOutput JSON: ${a.json}\nOutput method prompt: ${a.prompt}\n\nRead the actual Java test and follow the required helper, inherited method, Page Object, DataProvider and assertion call graphs. Preserve conditional branches, input provenance, class/method names, navigation and functional acceptance boundaries. Record unresolved dependencies explicitly instead of guessing. The JSON MUST be valid JSON and have top-level keys className, methodName, sourcePath, dataProvider, steps, assertions, unresolved; the arrays steps, assertions and unresolved must be arrays. For each reference record actual Java source location. The prompt.md should be short and instruct the subsequent agent to mirror the whole Java behavior using this contract and the original source.\nDO NOT modify ANY file under ${config.javaRoot}; do not modify original Excel. Do NOT create TypeScript during this step. Do not execute Java, Playwright, QA websites, email, bank, payment, or binding actions. Write only into ${a.dir} for this operation, with two named deliverables. End by listing those two paths, true source coverage and unresolved items. Do not claim functional PASS.\n`;
}
function promptForMigration(sel,a){
return `TASK: Implement ONE COMPLETE Selenium Java TestNG method in the EXISTING Playwright TypeScript project.\nJava source (READ-ONLY): ${config.javaRoot}\nSource method: ${sel.className}#${sel.name}\nSource file: ${sel.file}\nSource-derived JSON: ${a.json}\nSource-derived prompt: ${a.prompt}\nTarget project root: ${config.playwrightRoot}\n\nRead BOTH generated files completely, inspect original Java source when necessary. Use the method-specific prompt and JSON to faithfully mirror the complete Selenium behavior: fixture, DataProvider, source-eligible state, source Excel workbook/worksheet and filters, conditional branches, Page Objects, helpers, all required assertions, and final acceptance boundary. Use existing HOME structure under tests/acehome and reuse existing working Playwright fixtures, providers and pages. Original Java and Excel MUST remain read-only. No Faker or hardcoded applicant identities. Do not force TX; TX fallback is only allowed when source permits it. Do not change global configuration, J03, or iGero infrastructure unless a confirmed defect prevents this test.\nCreate or complete the actual dedicated .spec.ts (not just helpers). Carry out source-contract comparison and scoped offline validation. Do not execute external QA Chrome test, email, purchase, payment, banking or policy binding in this step. Do not modify unrelated suites, commit, push, or start the queue. Include the exact original Java method name in the Playwright test title so the runner can select only this Test Case. Keep user-facing test titles and diagnostics in English. Report the final spec path, source assertion mapping, real implementation status and unresolved issues. Never claim FUNCTIONAL_PASS without real runtime execution.\n`;
}
async function writePromptFile(a, name, prompt) {
  await fsp.mkdir(a.dir,{recursive:true}); const p=path.join(a.dir,name);await fsp.writeFile(p,prompt,'utf8');return p;
}
function spawnAndLog(command,args,opts, capture=null) {
  return new Promise((resolve,reject)=>{
    const child=spawn(command,args,{...opts, windowsHide:true,env:{...process.env,...(opts.env||{}),NO_COLOR:'1'}});
    runningProcess=child;
    let buffer='';
    const collect=(data)=>{buffer+=safeText(data.toString()); let lines=buffer.split('\n');buffer=lines.pop();for(const line of lines){if(line.trim()){if(capture)capture.push(line);log(line);}}};
    child.stdout?.on('data',collect);child.stderr?.on('data',collect);
    child.once('error',e=>{runningProcess=null;reject(e)});
    child.once('close',code=>{if(buffer.trim()){if(capture)capture.push(buffer);log(buffer);}runningProcess=null;resolve(code);});
  });
}
async function invokeCopilot(promptFile, stage){
  // The selected roots are passed to the wrapper; no manual credit cap is supplied.
  const script=path.join(HERE,'invoke-copilot.ps1');
  const args=['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',script,'-PromptFile',promptFile,'-TargetRoot',config.playwrightRoot,'-SourceRoot',config.javaRoot];
  const cmd=process.platform==='win32'?'powershell.exe':'pwsh';
  activeCopilotStage = stage;
  copilotStopReason = null;
  try {
    const code = await spawnAndLog(cmd,args,{cwd:config.playwrightRoot});
    return {code, stopReason:copilotStopReason};
  } finally {
    activeCopilotStage = null;
    copilotStopReason = null;
  }
}
async function runTypecheck() {
  const cmd=process.platform==='win32'?'cmd.exe':'npm';
  const args=process.platform==='win32'?['/d','/s','/c','npx --no-install tsc --noEmit']:['exec','--','tsc','--noEmit'];
  return spawnAndLog(cmd,args,{cwd:config.playwrightRoot,env:{TEST_ENV:config.testEnv}});
}
async function fingerprintTree(dir){
  const files=[]; const stack=[dir];
  while(stack.length && files.length<10000){
    const d=stack.pop(); let ents=[];
    try{ents=await fsp.readdir(d,{withFileTypes:true});}catch{continue;}
    for(const e of ents){
      if(['.git','.gradle','.idea','build','target','node_modules','out'].includes(e.name))continue;
      const fp=path.join(d,e.name);
      if(e.isDirectory())stack.push(fp);
      else if(e.isFile() && /\.(java|xlsx|xls)$/i.test(e.name))files.push(fp);
    }
  }
  const dig=crypto.createHash('sha256');
  for(const f of files.sort()){
    const content=await fsp.readFile(f).catch(()=>null);
    if(content){dig.update(f);dig.update(content);}
  }
  return dig.digest('hex');
}
async function listSpecVersions(target){
  const base=path.join(target,'tests'),out={};
  if(!validRoot(base))return out;
  const stack=[base];
  while(stack.length){
    const d=stack.pop();let ent=[];try{ent=await fsp.readdir(d,{withFileTypes:true});}catch{continue;}
    for(const e of ent){
      const f=path.join(d,e.name);
      if(e.isDirectory())stack.push(f);
      else if(e.isFile() && e.name.endsWith('.spec.ts')){
        const st=await fsp.stat(f);out[f]=`${st.size}:${st.mtimeMs}`;
      }
    }
  }
  return out;
}
function sanitizeReportText(value) {
  // Only sanitized summaries are exposed through the HTTP API; raw reporter JSON stays local.
  return String(value||'').replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi,'[REDACTED_EMAIL]')
    .replace(/\b\d{9,19}\b/g,'[REDACTED_NUMBER]').replace(/(https?:\/\/[^\s?]+)\?[^\s]+/gi,'$1?[REDACTED]')
    .replace(/\b(?:password|ssn|socialSecurityNumber|cardNumber|routingNumber|accountNumber)\s*[:=]\s*[^\s,;]+/gi,'[REDACTED_FIELD]')
    .slice(0,1400);
}
// Safety review uses the SELECTED executable method, not arbitrary Excel column names,
// shared imports, or the entire JSON contract. A filename/data provider may contain
// "bank" even when this Test Case never performs a bank operation.
function selectedJavaMethod(source, methodName) {
  const re=new RegExp('\\b(?:public|private|protected)\\s+(?:(?:static|final|synchronized)\\s+)*[\\w<>\\[\\], ?]+?\\s+'+methodName+'\\s*\\([^)]*\\)\\s*(?:throws\\s+[\\w, ]+)?\\s*\\{','g');
  const m=re.exec(source);if(!m)return null;
  let depth=1,i=re.lastIndex,quote='',escaped=false,lineComment=false,blockComment=false;
  for(;i<source.length;i++){
    const c=source[i],n=source[i+1];
    if(lineComment){if(c==='\n')lineComment=false;continue;}
    if(blockComment){if(c==='*'&&n==='/'){blockComment=false;i++}continue;}
    if(quote){if(escaped){escaped=false;continue}if(c==='\\'){escaped=true;continue}if(c===quote)quote='';continue;}
    if(c==='/'&&n==='/'){lineComment=true;i++;continue;}
    if(c==='/'&&n==='*'){blockComment=true;i++;continue;}
    if(c==='"'||c==="'"){quote=c;continue;}
    if(c==='{')depth++;else if(c==='}'&&--depth===0)return source.slice(re.lastIndex,i);
  }
  return null;
}
function isSensitiveActionCode(text){
  const stripped=String(text).replace(/\/\/[^\n]*|\/\*[\s\S]*?\*\/|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g,' ');
  // Match executable identifiers, not words in unrelated descriptions or source data.
  return /\b(?:[\w$]*(?:quoteAndBind|policyBind|bindPolicy|completePurchase|payment|bankAccount|bankPayment|makePayment|purchasePolicy|sendEmail|sendMail|sendMessage|signDocuments|startSigning)[\w$]*)\s*\(/i.test(stripped)
      || /\bnew\s+[\w$]*(?:BankPayment|PaymentPage|PolicyBind|BankAccount)[\w$]*\s*\(/i.test(stripped);
}
async function scenarioSafety(sel,contract){
  const label=`${sel.className}#${sel.name}`;
  if(/(?:quoteAndBind|goToPayment|payment|bankAccount|bankPayment|policyBind|completePurchase|purchasePolicy|sendEmail|sendMail|startSigning)/i.test(label))
    return {sensitive:true,reason:'The selected Java test name explicitly targets a sensitive operation.'};
  const source=await fsp.readFile(sel.file,'utf8').catch(()=>null);
  const body=source&&selectedJavaMethod(source,sel.name);
  if(body===null)return {sensitive:true,reason:'Could not safely isolate the source Java test body. Manual review is required before real execution.'};
  if(isSensitiveActionCode(body))return {sensitive:true,reason:'The selected Java test body invokes a bank, payment, binding, purchase, signing or email operation.'};
  // Structured step *actions* only; ignore DataProvider fields, test metadata and generic descriptions.
  for(const step of contract?.steps||[]){
    if(!step||typeof step!=='object')continue;
    const operation=[step.action,step.operation,step.methodCall,step.invocation].filter(x=>typeof x==='string').join(' ');
    if(/\b(?:submit\s+(?:payment|bank|purchase)|(?:complete|confirm|perform|execute|click|enter|send|bind|sign|purchase|pay)\s+(?:\w+\s+){0,3}(?:payment|bank(?:ing)?|bind|policy|purchase|email|signing))\b/i.test(operation))
      return {sensitive:true,reason:'A source-contract executable action requires separate business execution approval.'};
  }
  return {sensitive:false,reason:'No explicit sensitive operation found in the selected Java test body or structured executable actions. This is a static safety precheck, not permission to ignore corporate QA policy.'};
}
function withinTarget(file) {
  const root=path.resolve(config.playwrightRoot);const resolved=path.resolve(file);
  return resolved.startsWith(root+path.sep) && resolved.endsWith('.spec.ts') && !resolved.includes(`${path.sep}node_modules${path.sep}`);
}
// Playwright is the authority for runnable titles. A Selenium method name is
// NOT automatically the Playwright title; never grep using the Java name.
function playwrightCommand(args) {
  if(process.platform==='win32') {
    const quote=x=>`"${String(x).replace(/["\r\n]/g,'')}"`;
    return {cmd:'cmd.exe',args:['/d','/s','/c',`npx --no-install playwright test ${args.map(quote).join(' ')}`]};
  }
  return {cmd:'npx',args:['--no-install','playwright','test',...args]};
}
async function discoverFocusedSpecs(sel) {
  const versions=await listSpecVersions(config.playwrightRoot);
  const candidates=[];
  for(const file of Object.keys(versions)) {
    if(!withinTarget(file))continue;
    const content=await fsp.readFile(file,'utf8').catch(()=>'');
    const relative=path.relative(config.playwrightRoot,file).replace(/\\/g,'/');
    const relevance=methodRelevance(sel,relative,'',content.includes(sel.name));
    if(content.includes(sel.name) || relevance.evidence.length>=2)
      candidates.push({file,relative,sourceMentionsMethod:content.includes(sel.name)});
  }
  const result=[];
  for(const candidate of candidates){
    const capture=[];
    // File-only discovery. Filtering by the Java method would incorrectly hide
    // established tests whose titles differ from the Selenium method name.
    const cmd=playwrightCommand([candidate.relative,'--list']);
    const exitCode=await spawnAndLog(cmd.cmd,cmd.args,{cwd:config.playwrightRoot,env:{TEST_ENV:config.testEnv}},capture);
    const tests=exitCode===0?parsePlaywrightList(capture.join('\n')):[];
    for(const test of tests){
      const relevance=methodRelevance(sel,candidate.relative,test.title,candidate.sourceMentionsMethod);
      result.push({specPath:candidate.file,relativePath:candidate.relative,sourceMentionsMethod:candidate.sourceMentionsMethod,
        project:test.project,line:test.line,column:test.column,title:test.title,
        runnable:true,eligible:relevance.eligible,score:relevance.score,
        evidence:relevance.evidence,exitCode});
    }
    if(!tests.length){
      result.push({specPath:candidate.file,relativePath:candidate.relative,sourceMentionsMethod:candidate.sourceMentionsMethod,
        project:'',line:0,column:0,title:'',runnable:false,eligible:false,score:0,
        evidence:[],exitCode,diagnostic:exitCode===0?'No registered test in this file':'Playwright discovery failed; see LIVE output'});
    }
  }
  return result;
}
async function resolveFocusedTest(sel,a,touched=[],requestedSelection=null){
  const manifest=await fsp.readFile(a.specManifest,'utf8').then(JSON.parse).catch(()=>null);
  const found=await discoverFocusedSpecs(sel);
  const chosen=chooseFocusedTest(found,sel.id,manifest,requestedSelection);
  if(!withinTarget(chosen.specPath))throw new Error('Selected test is outside the Playwright project.');
  const modified=touched.includes(chosen.specPath);
  await fsp.mkdir(a.dir,{recursive:true});
  await fsp.writeFile(a.specManifest,JSON.stringify({methodId:sel.id,specPath:chosen.specPath,
    testTitle:chosen.title,line:chosen.line,project:chosen.project,modifiedInCurrentRun:modified,
    mappingEvidence:chosen.evidence,sourceAssertionParity:'NOT_INDEPENDENTLY_VERIFIED',
    confirmedAt:new Date().toISOString()},null,2));
  log(`Mapped Java ${sel.id} to Playwright [${chosen.project}] ${chosen.relativePath}:${chosen.line} › ${chosen.title}`,'success');
  return chosen;
}
function collectPlaywrightResults(report){
  const tests=[];
  function walkSuite(suite,parents=[]){
    const pathParts=suite.title?[...parents,suite.title]:parents;
    for(const spec of suite.specs||[]){
      for(const t of spec.tests||[]){
        const result=t.results||[];
        const last=result.at(-1)||{};
        const status=t.status || last.status || 'unknown';
        const allSteps=[];
        function walkSteps(items,depth=0){
          for(const st of items||[]){
            if(allSteps.length>=2500)return;
            allSteps.push({title:sanitizeReportText(st.title),category:st.category||'',duration:st.duration||0,
              error:st.error?sanitizeReportText(st.error.message||st.error.value||''):null,depth});
            walkSteps(st.steps,depth+1);
          }
        }
        walkSteps(last.steps||[]);
        tests.push({title:sanitizeReportText([...pathParts,spec.title].filter(Boolean).join(' › ')),
          project:t.projectName||'', status, expectedStatus:t.expectedStatus||'passed',
          duration:result.reduce((n,r)=>n+(r.duration||0),0), retries:Math.max(0,result.length-1),
          errors:(last.errors||[]).map(e=>sanitizeReportText(e.message||e.value||e.stack||'')).slice(0,10),steps:allSteps});
      }
    }
    for(const sub of suite.suites||[])walkSuite(sub,pathParts);
  }
  for(const suite of report.suites||[])walkSuite(suite);
  return tests;
}
function summarizeFunctionalReport(report, exitCode, selectedSpec, jsonFile, methodId, projectName) {
  const tests=collectPlaywrightResults(report);
  const counts={total:tests.length,passed:0,failed:0,skipped:0,timedOut:0,interrupted:0,other:0};
  for(const t of tests){
    if(t.status==='expected' && t.expectedStatus==='passed')counts.passed++;
    else if(t.status==='unexpected'){counts.failed++;if(t.errors.some(e=>/timeout/i.test(e)))counts.timedOut++;}
    else if(t.status==='skipped')counts.skipped++;
    else if(t.status==='interrupted')counts.interrupted++;
    else counts.other++;
  }
  const verdict=(exitCode===0 && counts.total>0 && counts.passed===counts.total && !counts.skipped && !counts.other)
    ? 'FUNCTIONAL_PASS' : 'FUNCTIONAL_FAILED';
  return {methodId,verdict,exitCode,counts,tests,selectedSpec,projectName,
    reportPath:jsonFile,executedAt:new Date().toISOString(),javaRuntimeParity:'NOT_VERIFIED',
    note:'Playwright execution result only; Java runtime parity is separate and not verified.'};
}
async function runFunctionalCheck(sel,a,contract,touched=[],manual=false,requestedSpec=null) {
  await fsp.mkdir(a.dir,{recursive:true});
  await fsp.rm(a.functionalSummary,{force:true}); // Never display a previous run as the current result.
  const safety=await scenarioSafety(sel,contract);
  if(safety.sensitive) {
    const reason=`Safety gate: ${safety.reason} No browser was launched.`;
    currentJob.functional={verdict:'SKIPPED_SAFETY',reason,counts:{total:0,passed:0,failed:0,skipped:0},tests:[],methodId:sel.id};
    await fsp.writeFile(a.functionalSummary,JSON.stringify(currentJob.functional,null,2));
    step(5,'skipped',reason);log(reason,'warning');return;
  }
  if(!config.autoFunctionalCheck && !manual){
    currentJob.functional={verdict:'NOT_EXECUTED',reason:'Automatic functional execution was disabled in settings.',counts:{total:0,passed:0,failed:0,skipped:0},tests:[]};
    await fsp.writeFile(a.functionalSummary,JSON.stringify(currentJob.functional,null,2));
    step(5,'skipped','Automatic Functional TC Check disabled in settings.');return;
  }
  step(5,'running','Selecting the exact migrated test in the Playwright TypeScript project');
  const target=await resolveFocusedTest(sel,a,touched,requestedSpec);
  const relative=target.relativePath;
  // File:line filters the exact Playwright-registered test without depending on
  // the original Java method name. This is an official Playwright CLI feature.
  const focus=`${relative}:${target.line}`;
  const runtimeEnv={TEST_ENV:config.testEnv};
  const listArgs=[focus,'--project',target.project,'--list'];
  const listOutput=[];
  log(`Functional TC discovery: ${focus} [${target.project}] (${target.title})`);
  const listCmd=playwrightCommand(listArgs);
  const listed=await spawnAndLog(listCmd.cmd,listCmd.args,{cwd:config.playwrightRoot,env:runtimeEnv},listOutput);
  if(listed!==0)throw new Error(`Playwright focused discovery failed (${listed}); browser not launched.`);
  const actual=parsePlaywrightList(listOutput.join('\n'));
  if(actual.length!==1 || actual[0].title!==target.title || actual[0].project!==target.project)
    throw new Error(`TARGET_NOT_UNIQUE: file:line discovery returned ${actual.length} tests, not the exact registered title. Browser not launched.`);
  const project=target.project;
  await fsp.mkdir(a.dir,{recursive:true});
  const reportFile=a.functionalReport;
  await fsp.rm(reportFile,{force:true});
  const runArgs=[focus,'--project',project,'--headed','--workers=1','--retries=0','--forbid-only','--reporter=json'];
  log(`Starting focused headed Playwright execution: ${relative}${project?' ['+project+']':''}`);
  const runCmd=playwrightCommand(runArgs);
  const code=await spawnAndLog(runCmd.cmd,runCmd.args,{
    cwd:config.playwrightRoot,
    env:{...runtimeEnv,PLAYWRIGHT_JSON_OUTPUT_NAME:reportFile,CI:''}
  });
  const report=await fsp.readFile(reportFile,'utf8').then(JSON.parse).catch(()=>null);
  if(!report){
    currentJob.functional={verdict:'REPORT_MISSING',reason:'Playwright JSON report was not generated or could not be parsed.',methodId:sel.id,
      counts:{total:0,passed:0,failed:0,skipped:0},tests:[],exitCode:code};
    await fsp.writeFile(a.functionalSummary,JSON.stringify(currentJob.functional,null,2));
    throw new Error(`Playwright execution exited ${code}, but no valid JSON report exists. Functional PASS cannot be claimed.`);
  }
  const summary=summarizeFunctionalReport(report,code,target.specPath,reportFile,sel.id,project||'default');
  currentJob.functional=summary;
  await fsp.writeFile(a.functionalSummary,JSON.stringify(summary,null,2),'utf8');
  if(summary.verdict==='FUNCTIONAL_PASS'){
    step(5,'pass',`${summary.counts.passed}/${summary.counts.total} Playwright tests PASSED in headed mode; no skipped/failed tests.`);
    log(`FUNCTIONAL PASS: ${summary.counts.passed}/${summary.counts.total} Playwright tests passed; report: ${a.functionalSummary}`,'success');
  } else {
    throw new Error(`Functional TC Check FAILED: ${summary.counts.passed} passed, ${summary.counts.failed} failed, ${summary.counts.skipped} skipped, ${summary.counts.other} other. See saved per-test results.`);
  }
}
async function archivePreviousFunctionalSummary(a) {
  if(!fs.existsSync(a.functionalSummary))return;
  const historicalDir=path.join(a.dir,'functional-history');
  await fsp.mkdir(historicalDir,{recursive:true});
  const archivedName=`functional-summary-${new Date().toISOString().replace(/[:.]/g,'-')}-${crypto.randomBytes(3).toString('hex')}.json`;
  await fsp.rename(a.functionalSummary,path.join(historicalDir,archivedName));
}
async function executeJob(sel, mode, requestedSelection=null){
  const a=artifactPaths(sel);
  const stageOne=(mode==='all'||mode==='extract');
  const stageTwo=(mode==='all'||mode==='migrate');
  const functionalOnly=mode==='functional';
  // Create the current job BEFORE any asynchronous preflight. Otherwise the
  // browser can briefly display the previous completed job after Start.
  currentJob={id:crypto.randomUUID(),methodId:sel.id,status:'running',startedAt:new Date().toISOString(),endedAt:null,steps:STEP_NAMES.map(name=>({name,status:'pending',note:''})),logs:[],artifacts:{json:a.json,prompt:a.prompt, outputDir:a.dir},aiCreditsObserved:{extract:null,migrate:null},functional:null,error:null};
  sendEvent('status',jobPublic());
  try{
    const sourceFingerprint=await fingerprintTree(config.javaRoot);
    await archivePreviousFunctionalSummary(a); // Keep history, never reuse a stale verdict.
    step(0,'running','Verifying the selected Java @Test method');
    if(!fs.existsSync(sel.file))throw new Error('The selected Java source file does not exist.');
    step(0,'pass',sel.relativePath);
    if(stageOne){
      step(1,'running','Copilot is generating the contract and prompt');
      const p=await writePromptFile(a,'01-extract-instructions.txt',promptForExtraction(sel,a));
      const ret=await invokeCopilot(p,'extract'); if(ret.stopReason)throw new Error(`${ret.stopReason} during extraction. This step cannot be marked complete.`); if(ret.code!==0)throw new Error(`Copilot extraction exited with code ${ret.code}.`);
      const afterExtract=await fingerprintTree(config.javaRoot);
      if(sourceFingerprint!==afterExtract)throw new Error('ALERT: Java/Excel source files changed during extraction. Stage 2 was cancelled.');
      step(1,'pass','Copilot exited 0; Java/Excel files remained unchanged');
    }else step(1,'skipped','Existing artifacts reused');
    step(2,'running','Validating the generated JSON contract');
    let contract;
    try{contract=JSON.parse(await fsp.readFile(a.json,'utf8'))}catch{throw new Error('No valid contract.json was found. Migration stopped.');}
    if(contract.className!==sel.className || contract.methodName!==sel.name || !Array.isArray(contract.assertions) || !Array.isArray(contract.steps))throw new Error('Contract does not match the selected class/method or lacks valid steps/assertions.');
    const promptContent=await fsp.readFile(a.prompt,'utf8').catch(()=>''), promptValid=promptContent.length>=40;
    if(!promptValid)throw new Error('The generated prompt.md is missing or incomplete.');
    step(2,'pass',`${contract.assertions.length} assertion records in JSON`);
    if(stageTwo){
      step(3,'running','Copilot is implementing the TypeScript spec');
      const beforeSpecs=await listSpecVersions(config.playwrightRoot);
      const p=await writePromptFile(a,'02-migrate-instructions.txt',promptForMigration(sel,a));
      const ret=await invokeCopilot(p,'migrate'); if(ret.stopReason)throw new Error(`${ret.stopReason} during migration. Existing changes are preserved but not certified.`); if(ret.code!==0)throw new Error(`Copilot migration exited with code ${ret.code}.`);
      const afterMigration=await fingerprintTree(config.javaRoot);
      if(sourceFingerprint!==afterMigration)throw new Error('ALERT: Java/Excel source files changed during implementation.');
      const afterSpecs=await listSpecVersions(config.playwrightRoot);
      const touched=Object.entries(afterSpecs).filter(([file,version])=>beforeSpecs[file]!==version).map(([file])=>file);
      const selection=await resolveFocusedTest(sel,a,touched,requestedSelection);
      const selectedSpec=selection.specPath;
      currentJob.artifacts.specs=[selectedSpec];
      currentJob.artifacts.specMode=touched.includes(selectedSpec)?'MODIFIED':'REUSED_EXISTING';
      if(touched.includes(selectedSpec)) {
        step(3,'pass',`Source-referenced spec updated: ${path.relative(config.playwrightRoot,selectedSpec)}; functional behavior is not yet verified`);
      } else {
        log(`Existing source-referenced spec reused unchanged: ${path.relative(config.playwrightRoot,selectedSpec)}. Copilot made no spec edit; that is not a failure and not a Functional PASS.`,'warning');
        step(3,'pass',`REUSED EXISTING SPEC (unchanged); validating TypeScript and real Playwright execution next`);
      }
      if(config.autoTypecheck){step(4,'running','npx tsc --noEmit');const c=await runTypecheck();if(c===0)step(4,'pass','TypeScript typecheck passed; NOT a Functional PASS');else throw new Error(`TypeScript typecheck exited with code ${c}; implementation not verified.`);}
      else step(4,'skipped','Typecheck disabled in settings');
      // Execute the real migrated method only after typecheck and safe scenario gating.
      if(!config.autoTypecheck){
        currentJob.functional={verdict:'NOT_EXECUTED',reason:'TypeScript validation is disabled. Functional execution cannot start.',counts:{total:0,passed:0,failed:0,skipped:0},tests:[]};
        step(5,'skipped','Typecheck is disabled; functional check cannot start.');
      }else await runFunctionalCheck(sel,a,contract,[selectedSpec],false,requestedSelection);
    }else{step(3,'skipped',functionalOnly?'Using existing spec':'Extraction only');
      if(functionalOnly){step(4,'running','Validating TypeScript before the focused Playwright run');
        const c=await runTypecheck();if(c!==0)throw new Error(`TypeScript typecheck failed (${c}); functional execution aborted.`);
        step(4,'pass','TypeScript typecheck passed');await runFunctionalCheck(sel,a,contract,[],true,requestedSelection);
      }else{step(4,'skipped','Extraction only');step(5,'skipped','Extraction only');}}
    const after=await fingerprintTree(config.javaRoot);
    if(sourceFingerprint!==after)throw new Error('ALERT: a Java source file changed. Review changes immediately.');
    step(6,'pass','Java unchanged; generated files and runtime results saved in target project');
    if(currentJob.status==='cancelled')throw new Error('Job cancelled by user.');
    // Finishing the conversion is distinct from completing a REAL functional run.
    const functionalWasRequested=(stageTwo || functionalOnly);
    if(functionalWasRequested && currentJob.functional?.verdict!=='FUNCTIONAL_PASS') {
      currentJob.status='partial';
      log('Conversion steps finished, but Functional TC Check is NOT VERIFIED. See the precise reason in Section 7.','warning');
    } else {
      currentJob.status='completed';
      log('Workflow finished. See the Functional TC Check stage for real execution status.','success');
    }
  }catch(err){
    currentJob.status=currentJob.status==='cancelled'?'cancelled':'blocked';currentJob.error=err.message;
    log(`BLOCKED: ${err.message}`,'error');
    if(!currentJob.functional) {
      const reachedFunctional=currentJob.steps[5]?.status==='running';
      currentJob.functional={methodId:sel.id,verdict:reachedFunctional?'BLOCKED':'NOT_EXECUTED',
        reason:reachedFunctional?`Functional execution failed before a verified result: ${err.message}`:
          `Functional TC Check was not reached: ${err.message}`,
        counts:{total:0,passed:0,failed:0,skipped:0},tests:[]};
      await fsp.writeFile(a.functionalSummary,JSON.stringify(currentJob.functional,null,2)).catch(()=>{});
    }
    const ix=currentJob.steps.findIndex(x=>x.status==='running');if(ix>=0)step(ix,'blocked',err.message);
    if(currentJob.steps[5]?.status==='pending')step(5,'skipped','NOT EXECUTED — earlier stage blocked; no browser was launched');
  }finally{currentJob.endedAt=new Date().toISOString();sendEvent('status',jobPublic());}
}
function parseBody(req){return new Promise((resolve,reject)=>{let body='';req.on('data',d=>{body+=d; if(body.length>100000){reject(new Error('Request body too large'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(body||'{}'))}catch{reject(new Error('Invalid JSON'))}});req.on('error',reject);});}
function originAllowed(req){if(!req.headers.origin)return true;try{const u=new URL(req.headers.origin);return u.hostname==='127.0.0.1'&&Number(u.port)===PORT;}catch{return false;}}
const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,`http://${HOST}:${PORT}`);
    if(req.method==='GET' && url.pathname==='/'){const html=await fsp.readFile(path.join(HERE,'index.html'));res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'"});res.end(html);return;}
    if(req.method==='GET' && url.pathname==='/app.js'){const data=await fsp.readFile(path.join(HERE,'app.js'));res.writeHead(200,{'Content-Type':'application/javascript; charset=utf-8','Cache-Control':'no-store'});res.end(data);return;}
    if(req.method==='GET'&&url.pathname==='/api/events'){
      res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});
      res.write('retry: 2000\n\n');clients.add(res);res.write(`event: status\ndata: ${JSON.stringify(jobPublic())}\n\n`);req.on('close',()=>clients.delete(res));return;
    }
    if(req.method==='GET' && url.pathname==='/api/system'){json(res,200,await systemReadiness());return;}
    if(req.method==='GET' && url.pathname==='/api/config'){json(res,200,{...config,...rootChecks()});return;}
    if(req.method==='GET'&&url.pathname==='/api/methods'){
      if(!rootChecks().javaExists){json(res,400,{error:'Java source directory is unavailable'});return;}
      if(Date.now()-lastMethodScan>120000||!methodCache.length){methodCache=await collectMethods();lastMethodScan=Date.now();}
      const term=(url.searchParams.get('q')||'').toLowerCase();
      json(res,200,{total:methodCache.length,methods:methodCache.filter(m=>m.id.toLowerCase().includes(term)).slice(0,400).map(({id,relativePath})=>({id,relativePath}))});return;
    }
    if(req.method==='GET'&&url.pathname==='/api/method-preview'){
      const sel=await findMethod(url.searchParams.get('id')||''); const raw=await fsp.readFile(sel.file,'utf8');
      const start=Math.max(0,raw.search(new RegExp('\\b'+sel.name+'\\s*\\('))-400);
      json(res,200,{id:sel.id,relativePath:sel.relativePath,javaPreview:raw.slice(start,start+14000)});return;
    }
    if(req.method==='GET'&&url.pathname==='/api/outputs'){
      const sel=await findMethod(url.searchParams.get('id')||'');const a=artifactPaths(sel);
      const exists={json:fs.existsSync(a.json),prompt:fs.existsSync(a.prompt)};
      let contract='';let prompt='';if(exists.json)contract=(await fsp.readFile(a.json,'utf8')).slice(0,22000);if(exists.prompt)prompt=(await fsp.readFile(a.prompt,'utf8')).slice(0,22000);
      const specMap=await listSpecVersions(config.playwrightRoot);
      const manifest=await fsp.readFile(a.specManifest,'utf8').then(JSON.parse).catch(()=>null);
      let specPath=manifest?.methodId===sel.id&&specMap[manifest.specPath]?manifest.specPath:'';
      for(const f of specPath?[]:Object.keys(specMap)){
        if(path.basename(f).toLowerCase().includes(sel.className.toLowerCase())){specPath=f;break;}
      }
      if(!specPath){
        for(const f of Object.keys(specMap)){
          const source=await fsp.readFile(f,'utf8').catch(()=>'');
          if(source.includes(sel.name) && (source.includes(sel.className)||path.basename(f).toLowerCase().includes('home'))){specPath=f;break;}
        }
      }
      const specPreview=specPath?(await fsp.readFile(specPath,'utf8')).slice(0,35000):'';
      const functional=await fsp.readFile(a.functionalSummary,'utf8').then(JSON.parse).catch(()=>null);
      json(res,200,{...exists,contract,prompt,outputDir:a.dir,specPath,specPreview,specExists:!!specPath,functional});return;
    }
    if(req.method==='GET'&&url.pathname==='/api/spec-candidates'){
      if(currentJob?.status==='running'){json(res,409,{error:'Wait until the current migration finishes before discovering specs.'});return;}
      const sel=await findMethod(url.searchParams.get('id')||'');
      const entries=await discoverFocusedSpecs(sel);
      json(res,200,{methodId:sel.id,entries,registered:entries.filter(x=>x.runnable && x.eligible).length,
        note:'Playwright test titles may differ from Java method names. Choose an eligible registered test if multiple appear.'});return;
    }
    if(req.method==='GET' && url.pathname==='/api/job'){json(res,200,jobPublic());return;}
    if(req.method==='POST'){
      if(!originAllowed(req)){json(res,403,{error:'Origin not allowed'});return;}
      const body=await parseBody(req);
      if(url.pathname==='/api/config'){
        if(currentJob?.status==='running')throw new Error('Cannot change project paths while a job is running.');
        const javaRoot=String(body.javaRoot||'').trim(),playwrightRoot=String(body.playwrightRoot||'').trim();
        if(!validRoot(javaRoot)||!validRoot(playwrightRoot))throw new Error('One or both project directories do not exist.');
        if(path.resolve(javaRoot)===path.resolve(playwrightRoot))throw new Error('Source and target directories cannot be the same.');
        const testEnv=String(body.testEnv||'MA11').trim().toUpperCase();
        if(!['MA11','RA11'].includes(testEnv))throw new Error('Select MA11 (QA) or RA11 (UAT).');
        config={javaRoot,playwrightRoot,autoTypecheck:body.autoTypecheck!==false,autoFunctionalCheck:body.autoFunctionalCheck!==false,testEnv};
        await fsp.writeFile(CONFIG_FILE,JSON.stringify(config,null,2));methodCache=[];lastMethodScan=0;
        json(res,200,{ok:true,...config,...rootChecks()});return;
      }
      if(url.pathname==='/api/start'){
        if(dispatchPending||currentJob?.status==='running'){json(res,409,{error:'A migration is already running.'});return;}
        if(!rootChecks().ready)throw new Error('Verify that both project folders exist.');
        const preflight=await systemReadiness();
        if(!preflight.functionalReady)throw new Error('System Readiness FAILED. Check Node.js, project paths and Playwright dependencies before running.');
        if(body.mode!=='functional' && !preflight.migrationReady)throw new Error('GitHub Copilot CLI is not ready. Open System Readiness for details.');
        const mode=body.mode; if(!['extract','migrate','all','functional'].includes(mode))throw new Error('Invalid execution mode.');
        const sel=await findMethod(String(body.methodId||''));
        const selected=body.testSelection;
        const requestedSelection=selected && typeof selected==='object' ? {relativePath:String(selected.relativePath||''),line:Number(selected.line),title:String(selected.title||''),project:String(selected.project||'')} : null;
        if(requestedSelection && (requestedSelection.relativePath.includes('..') || path.isAbsolute(requestedSelection.relativePath)))throw new Error('Select a project-relative Playwright test.');
        dispatchPending=true;executeJob(sel,mode,requestedSelection).finally(()=>{dispatchPending=false;});json(res,202,{started:true,id:sel.id,mode});return;
      }
      if(url.pathname==='/api/cancel'){
        if(!currentJob || currentJob.status!=='running')throw new Error('No migration is currently running.');
        currentJob.status='cancelled';log('Cancellation requested; stopping only the process started by this panel.','warning');
        if(runningProcess){if(process.platform==='win32')spawn('taskkill',['/PID',String(runningProcess.pid),'/T','/F'],{windowsHide:true});else runningProcess.kill('SIGTERM');}
        json(res,200,{cancelled:true});return;
      }
    }
    json(res,404,{error:'Endpoint not found'});
  }catch(err){json(res,400,{error:err.message});}
});
server.listen(PORT,HOST,()=>console.log(`iGero Simple Migration UI: http://${HOST}:${PORT}/`));
