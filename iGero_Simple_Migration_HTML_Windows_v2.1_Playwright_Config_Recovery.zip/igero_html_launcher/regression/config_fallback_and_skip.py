"""Read-only Playwright config fallback + test.skip safety regression. No browser/AI calls."""
import json, os, pathlib, shutil, subprocess, tempfile, time, urllib.parse, urllib.request
base=pathlib.Path(__file__).resolve().parents[1]
root=pathlib.Path(tempfile.mkdtemp(prefix='igero_config_fallback_'))
java, pw, bin_, launcher=(root/x for x in ('java','pw','bin','launcher'))
proc=None
try:
    source=java/'src/test/java/com/farmers/ffq/acehome/AceHomeAboutYouPageTest.java'
    source.parent.mkdir(parents=True)
    source.write_text('public class AceHomeAboutYouPageTest { @Test public void pageContentValidationAboutYouPageHomeLob() {} }')
    spec=pw/'tests/acehome/AceHomeAboutYouPageTest.spec.ts'
    spec.parent.mkdir(parents=True)
    spec.write_text("import {test} from '@playwright/test';\ntest.skip('pageContentValidationAboutYouPageHomeLob', async()=>{});\n")
    (pw/'playwright.config.ts').write_text("export default {testDir: './nonsense'};\n")
    nested=pw/'configs/playwright.config.ts';nested.parent.mkdir();nested.write_text("export default {testDir: '../tests'};\n")
    (pw/'node_modules/@playwright/test').mkdir(parents=True)
    (pw/'node_modules/@playwright/test/package.json').write_text('{}')
    (pw/'node_modules/.bin').mkdir(parents=True);(pw/'node_modules/.bin/playwright').touch()
    artifacts=pw/'migration/pervez-json/AceHomeAboutYouPageTest__pageContentValidationAboutYouPageHomeLob'
    artifacts.mkdir(parents=True)
    (artifacts/'contract.json').write_text(json.dumps({'className':'AceHomeAboutYouPageTest','methodName':'pageContentValidationAboutYouPageHomeLob','steps':[],'assertions':[{'id':'A1'}],'testAnnotation':{'enabled':True}}))
    (artifacts/'prompt.md').write_text('Preserve all source assertions. No fake PASS. Enough prompt content to be considered valid.')
    bin_.mkdir()
    npx='''#!/usr/bin/env python3
import sys,os
args=sys.argv[1:]
if '--list' in args:
    if '--config' in args and 'configs/playwright.config.ts' in args[args.index('--config')+1].replace('\\\\','/'):
        print('[chromium] › tests/acehome/AceHomeAboutYouPageTest.spec.ts:2:1 › pageContentValidationAboutYouPageHomeLob')
        print('Total: 1 test in 1 file')
        sys.exit(0)
    print('Error: No tests found.')
    sys.exit(1)
if 'tsc' in args:sys.exit(0)
print('ERROR: Headed/browser invocation is forbidden in this test')
sys.exit(5)
'''
    (bin_/'npx').write_text(npx);(bin_/'npx').chmod(0o755)
    (bin_/'npm').write_text('#!/bin/sh\nexit 0\n');(bin_/'npm').chmod(0o755)
    launcher.mkdir()
    for x in ['server.mjs','focused-test-resolver.mjs','lob-catalog.mjs','app.js','index.html']:
        shutil.copy2(base/x,launcher/x)
    env=os.environ.copy();env['PATH']=str(bin_)+os.pathsep+env['PATH'];env['IGERO_PANEL_PORT']='18873'
    proc=subprocess.Popen(['node','server.mjs'],cwd=launcher,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
    def api(endpoint,data=None):
        req=urllib.request.Request('http://127.0.0.1:18873'+endpoint,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=30) as res:return json.loads(res.read())
    for _ in range(50):
        try:api('/api/job');break
        except Exception:time.sleep(.1)
    api('/api/config',{'javaRoot':str(java),'playwrightRoot':str(pw),'testEnv':'MA11','autoTypecheck':True,'autoFunctionalCheck':True})
    id='AceHomeAboutYouPageTest#pageContentValidationAboutYouPageHomeLob'
    diag=api('/api/playwright-diagnostics?id='+urllib.parse.quote(id))
    assert diag['status']=='REGISTERED',diag
    assert diag['activeConfig']=='configs/playwright.config.ts',diag
    assert diag['attempts'][0]['exitCode']==1,diag
    assert diag['attempts'][-1]['registered']==1,diag
    print('PASS: default Playwright config has no tests; an existing nested config supplies registered tests')
    candidates=api('/api/spec-candidates?id='+urllib.parse.quote(id))['entries']
    assert len(candidates)==1 and candidates[0]['skipDeclared'],candidates
    assert candidates[0]['configFile']==str(nested),candidates
    print('PASS: real registered test is tagged test.skip, including effective nested config')
    api('/api/start',{'methodId':id,'mode':'functional'})
    for _ in range(100):
        result=api('/api/job')
        if result['status']!='running':break
        time.sleep(.1)
    assert result['status']=='blocked',result
    assert 'JAVA_ENABLED_PLAYWRIGHT_SKIPPED' in result['error'],result
    assert result['functional']['counts']['total']==0,result
    print('PASS: Java enabled method with generated test.skip is blocked before browser; no fake Functional PASS')
    # global no-config succeeds nowhere, produce accurate report instead of a fabricated spec mapping
    nested.unlink()
    diag=api('/api/playwright-diagnostics?id='+urllib.parse.quote(id))
    assert diag['status']=='NO_REGISTERED_TESTS',diag
    assert diag['specCount']>=1,diag
    assert diag['relatedSpecs'][0]['skipDeclared'],diag
    assert pathlib.Path(artifacts/'discovery-diagnostics.json').exists()
    print('PASS: all configurations empty -> read-only diagnostic reports source file and skip status')
finally:
    if proc:
        proc.terminate()
        try:proc.wait(timeout=3)
        except:proc.kill()
    shutil.rmtree(root,ignore_errors=True)
