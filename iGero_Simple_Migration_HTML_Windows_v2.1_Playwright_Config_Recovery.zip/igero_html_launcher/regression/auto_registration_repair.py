"""CLI stubs validate one bounded automatic registration repair, never call real Copilot/QA."""
import json, os, pathlib, shutil, subprocess, tempfile, time, urllib.request
source=pathlib.Path(__file__).resolve().parents[1]
root=pathlib.Path(tempfile.mkdtemp(prefix='igero_repair_'))
try:
    java=root/'java'; pw=root/'pw'; launcher=root/'launcher'; bins=root/'bin'
    (java/'src/test/java/com/farmers/ffq/acehome').mkdir(parents=True)
    (pw/'tests/acehome').mkdir(parents=True)
    (pw/'node_modules/@playwright/test').mkdir(parents=True)
    (pw/'node_modules/.bin').mkdir(parents=True)
    (pw/'node_modules/.bin/playwright').touch()
    (pw/'node_modules/@playwright/test/package.json').write_text('{}')
    (pw/'suites/acehome').mkdir(parents=True)
    launcher.mkdir();bins.mkdir()
    (java/'src/test/java/com/farmers/ffq/acehome/AceHomeNameAndDobPageTest.java').write_text('public class AceHomeNameAndDobPageTest { @Test public void testContentValidationNameAndDobPageHomeLob() {} }')
    out=pw/'migration/pervez-json/AceHomeNameAndDobPageTest__testContentValidationNameAndDobPageHomeLob'
    out.mkdir(parents=True)
    (out/'contract.json').write_text(json.dumps({'className':'AceHomeNameAndDobPageTest','methodName':'testContentValidationNameAndDobPageHomeLob','steps':[],'assertions':[{'id':'A01'}],'unresolved':[]}))
    (out/'prompt.md').write_text('Implement Selenium Java method exactly in Playwright TypeScript with all assertions and providers.')
    # Generated initially in tests/, while mock Playwright is configured to see suites/ only.
    (pw/'tests/acehome/AceHomeNameAndDobPageTest.spec.ts').write_text('const legacyId="AceHomeNameAndDobPageTest#testContentValidationNameAndDobPageHomeLob";')
    (bins/'pwsh').write_text('#!/usr/bin/env python3\nimport sys,pathlib,os\nargs=sys.argv\np=pathlib.Path(args[args.index(\'-PromptFile\')+1])\nif \'03-repair\' in p.name:\n  d=pathlib.Path(os.environ[\'MOCK_PW_ROOT\'])/\'suites/acehome/AceHomeNameAndDobPageTest.spec.ts\'\n  d.write_text(\'import {test,expect} from "@playwright/test";\\nconst legacyId="AceHomeNameAndDobPageTest#testContentValidationNameAndDobPageHomeLob";\\ntest("testContentValidationNameAndDobPageHomeLob",async ({page})=>{expect(page).toBeTruthy();});\')\n  print(\'COPILOT MOCK: registered Playwright spec written\')\nelse: print(\'COPILOT MOCK: first migration did not register the existing file\')\nsys.exit(0)\n')
    (bins/'npx').write_text('''#!/usr/bin/env python3
import os,sys,pathlib,json
args=sys.argv[1:]
if 'playwright' not in args:sys.exit(2)
reg=pathlib.Path(os.environ['MOCK_PW_ROOT'])/'suites/acehome/AceHomeNameAndDobPageTest.spec.ts'
if '--list' in args:
 if any('tests/acehome' in a for a in args):
  print('Error: No tests found.');sys.exit(1)
 if not any('AceHomeNameAndDobPageTest.spec.ts' in a for a in args):
  print('[chromium] › suites/acehome/Unrelated.spec.ts:3:1 › Unrelated smoke test')
 if reg.exists(): print('[chromium] › suites/acehome/AceHomeNameAndDobPageTest.spec.ts:3:1 › testContentValidationNameAndDobPageHomeLob')
 sys.exit(0)
if '--reporter=json' in args:
 test_result={'projectName':'chromium','status':'expected','expectedStatus':'passed','results':[{'status':'passed','duration':22,'steps':[{'title':'expect.toBeTruthy','duration':2}]}]}
 spec={'title':'testContentValidationNameAndDobPageHomeLob','tests':[test_result]}
 report={'suites':[{'specs':[spec]}]}
 pathlib.Path(os.environ['PLAYWRIGHT_JSON_OUTPUT_NAME']).write_text(json.dumps(report));sys.exit(0)
sys.exit(1)
''')
    (bins/'npm').write_text('#!/bin/sh\nexit 0\n')
    (bins/'copilot').write_text('#!/bin/sh\necho MOCK_COPILOT_CLI\nexit 0\n')
    for n in ['npx','npm','pwsh','copilot']:(bins/n).chmod(0o755)
    for n in ['server.mjs','focused-test-resolver.mjs','lob-catalog.mjs','app.js','index.html','invoke-copilot.ps1']:
      shutil.copy2(source/n, launcher/n)
    env=os.environ.copy();env['MOCK_PW_ROOT']=str(pw);env['PATH']=str(bins)+os.pathsep+env['PATH'];env['IGERO_PANEL_PORT']='18868'
    proc=subprocess.Popen(['node','server.mjs'],cwd=launcher,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
    def api(path,data=None):
      req=urllib.request.Request('http://127.0.0.1:18868'+path,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
      try:
        with urllib.request.urlopen(req,timeout=15) as r:return json.load(r)
      except urllib.error.HTTPError as e:
        print('HTTP ERROR',e.code,e.read().decode()); raise
    try:
      for _ in range(50):
        try:api('/api/job');break
        except Exception:time.sleep(.1)
      api('/api/config',{'javaRoot':str(java),'playwrightRoot':str(pw),'testEnv':'MA11','autoTypecheck':True,'autoFunctionalCheck':True})
      api('/api/start',{'methodId':'AceHomeNameAndDobPageTest#testContentValidationNameAndDobPageHomeLob','mode':'migrate'})
      for _ in range(300):
        state=api('/api/job')
        if state['status']!='running':break
        time.sleep(.1)
      assert state['status']=='partial',state
      assert state['functional']['verdict']=='PLAYWRIGHT_PASS_PARITY_UNVERIFIED',state
      assert (pw/'suites/acehome/AceHomeNameAndDobPageTest.spec.ts').exists()
      assert (out/'03-repair-test-registration.txt').exists()
      assert any('registration repair' in x['text'].lower() for x in state['logs']),state
      print('PASS: one bounded Copilot repair fixed spec location -> Playwright registered exact test -> mock runtime PASS, parity NOT VERIFIED')
    finally:
      proc.terminate()
      try:proc.wait(timeout=3)
      except:proc.kill()
finally:
    shutil.rmtree(root,ignore_errors=True)
