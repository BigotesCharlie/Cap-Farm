"""Test V2 global Playwright discovery; mocks CLI and file system, never browsers/Copilot/MA11."""
import json, os, pathlib, shutil, subprocess, tempfile, time, urllib.request, urllib.parse
source = pathlib.Path(__file__).resolve().parents[1]
root = pathlib.Path(tempfile.mkdtemp(prefix='igero_discovery_'))
java, ts, bin_, launcher = (root/x for x in ('java','pw','bin','launcher'))
try:
    (java/'src/test/java/com/farmers/ffq/acehome').mkdir(parents=True)
    (ts/'tests/acehome').mkdir(parents=True)
    (ts/'suites/acehome').mkdir(parents=True)
    (ts/'node_modules/@playwright/test').mkdir(parents=True)
    (ts/'node_modules/.bin').mkdir(parents=True)
    bin_.mkdir(); launcher.mkdir()
    (ts/'node_modules/@playwright/test/package.json').write_text('{}')
    (ts/'node_modules/.bin/playwright').touch()
    filename='AceHomeNameAndDobPageTest.java'
    method='testContentValidationNameAndDobPageHomeLob'
    methodid=f'AceHomeNameAndDobPageTest#{method}'
    (java/'src/test/java/com/farmers/ffq/acehome'/filename).write_text(f'public class AceHomeNameAndDobPageTest {{ @Test public void {method}() {{}} }}')
    registered=ts/'suites/acehome/RegisteredNameDob.spec.ts'
    registered.write_text(f'''import {{ test }} from '@playwright/test';\nconst legacyId='AceHomeNameAndDobPageTest#{method}';\ntest('{method}', async () => {{}});''')
    contract_dir=ts/'migration/pervez-json/AceHomeNameAndDobPageTest__testContentValidationNameAndDobPageHomeLob'
    contract_dir.mkdir(parents=True)
    (contract_dir/'contract.json').write_text(json.dumps({'className':'AceHomeNameAndDobPageTest','methodName':method,'steps':[],'assertions':[{'name':'A01'}],'unresolved':[]}))
    (contract_dir/'prompt.md').write_text('Implement this complete Java test method in Playwright, preserving all source assertions and data.')
    ignored=ts/'tests/acehome/AceHomeNameAndDobPageTest.spec.ts'
    ignored.write_text(f'''import {{ test }} from '@playwright/test';\nconst legacyId='AceHomeNameAndDobPageTest#{method}';\ntest('legacy candidate',async()=>{{}});''')
    shell='''#!/usr/bin/env python3
import os,sys,json
args=sys.argv[1:]
if 'playwright' not in args: sys.exit(1)
if '--list' in args:
    if any('tests/acehome/' in a for a in args):
        print('Error: No tests found.')
        sys.exit(1)
    if os.environ.get('DISCOVERY_NO_REGISTRATION')=='1':
        print('  [chromium] › suites/acehome/Unrelated.spec.ts:4:3 › Unrelated smoke check')
        sys.exit(0)
    requested=args[args.index('--project')+1] if '--project' in args else None
    for p in ['chromium','firefox','webkit','edge','mobile-chrome','mobile-safari']:
        if requested and p != requested: continue
        print(f'  [{p}] › suites/acehome/RegisteredNameDob.spec.ts:3:1 › testContentValidationNameAndDobPageHomeLob')
    print('Total: 6 tests in 1 file')
    sys.exit(0)
if '--reporter=json' in args:
    report={'suites':[{'title':'','specs':[{'title':'testContentValidationNameAndDobPageHomeLob','tests':[{'projectName':'chromium','expectedStatus':'passed','status':'skipped','results':[]}]}]}]}
    open(os.environ['PLAYWRIGHT_JSON_OUTPUT_NAME'],'w').write(json.dumps(report));sys.exit(0)
sys.exit(1)
'''
    (bin_/'npx').write_text(shell)
    (bin_/'npx').chmod(0o755)
    (bin_/'npm').write_text('#!/bin/sh\nexit 0\n')
    (bin_/'npm').chmod(0o755)
    for n in ['server.mjs','focused-test-resolver.mjs','lob-catalog.mjs','app.js','index.html']:
        shutil.copy2(source/n,launcher/n)
    env=os.environ.copy();env['PATH']=str(bin_)+os.pathsep+env['PATH'];env['IGERO_PANEL_PORT']='18867'
    proc=subprocess.Popen(['node','server.mjs'],cwd=launcher,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
    def api(endpoint,data=None):
        b=json.dumps(data).encode() if data is not None else None
        req=urllib.request.Request('http://127.0.0.1:18867'+endpoint,data=b,headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req, timeout=15) as resp:return json.load(resp)
    try:
        for _ in range(50):
            try:api('/api/job');break
            except Exception:time.sleep(.1)
        api('/api/config',{'javaRoot':str(java),'playwrightRoot':str(ts),'testEnv':'MA11','autoTypecheck':True,'autoFunctionalCheck':True})
        entries=api('/api/spec-candidates?id='+urllib.parse.quote(methodid))['entries']
        assert len([e for e in entries if e['runnable']]) == 6, entries
        assert len([e for e in entries if not e['runnable']]) == 1, entries
        print('PASS: registered global suite/ candidate selected and ignored tests/ candidate classified')
        start=api('/api/start',{'methodId':methodid,'mode':'functional'})
        for _ in range(150):
            state=api('/api/job')
            if state['status']!='running':break
            time.sleep(.1)
        assert state['status']=='blocked' and state['functional']['verdict']=='FUNCTIONAL_FAILED',state
        assert state['functional']['counts']['skipped']==1,state
        assert 'suites/acehome/RegisteredNameDob.spec.ts' in json.dumps(state),state
        print('PASS: desktop Chromium selected; skipped real suite does NOT become Functional PASS')
        ignored.write_text(ignored.read_text()+'\n')
        registered.unlink()
        # Leave the mock --list pointing to a deleted source file; the registry must reject ghost entries.
        entries=api('/api/spec-candidates?id='+urllib.parse.quote(methodid))['entries']
        assert not any(e['runnable'] for e in entries),entries
        print('PASS: registry listing without an actual source file does not invent a runnable spec')
        api('/api/start',{'methodId':methodid,'mode':'functional'})
        for _ in range(150):
            state=api('/api/job')
            if state['status']!='running':break
            time.sleep(.1)
        assert state['status']=='blocked' and 'SPEC_NOT_REGISTERED_BY_PLAYWRIGHT' in state['error'],state
        assert state['functional']['counts']['total']==0,state
        print('PASS: source spec outside configured registered suite is accurately classified, with no fake execution')
    finally:
        proc.terminate()
        try:proc.wait(timeout=3)
        except:proc.kill()
finally:
    shutil.rmtree(root,ignore_errors=True)
