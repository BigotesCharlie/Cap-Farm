# FarmersAI Assist — MVP 0.4

FarmersAI Assist is a Java-based QA intelligence layer designed to read Rally sprint data, analyze User Stories, and later propose editable Test Cases and Tasks before publishing approved items back to Rally.

## Current MVP

This first version intentionally performs **read-only Rally scanning**.

Implemented:

- Spring Boot WebApp foundation.
- Java 17.
- Microsoft Playwright Java dependency.
- Executable sprint scanner.
- Rally WSAPI client.
- Mock mode for development without Rally credentials.
- User Story snapshot model.
- JSON scan snapshots.
- Web dashboard to launch scans.
- REST endpoint to scan a sprint.
- No Rally write operations.
- No AI generation yet.
- No Copilot dependency.

## Important terminology

Rally IDs beginning with `US` are User Stories (`HierarchicalRequirement` in WSAPI). FarmersAI Assist will later support Portfolio Features separately.

## Requirements

- JDK 17+
- Maven 3.9+
- IntelliJ IDEA
- Access to Rally
- A read-only Rally API key for real scanning

## First run — MOCK MODE

The project starts in mock mode by default.

### WebApp

Run:

`FarmersAiAssistApplication.java`

or:

`mvn spring-boot:run`

Open:

`http://localhost:8080`

Enter:

- Project: `SWAT`
- Sprint: `Sprint 42.3`

and click **Scan Sprint**.

### Scanner executable

Run directly from IntelliJ:

`SprintScannerLauncher.java`

Program arguments:

`--project=SWAT --sprint="Sprint 42.3" --mock=true`

or Maven:

`mvn exec:java -Dexec.mainClass=com.farmers.aiassist.scanner.SprintScannerLauncher -Dexec.args='--project=SWAT --sprint="Sprint 42.3" --mock=true'`

## Real Rally mode

Set environment variables:

`RALLY_BASE_URL=https://rally1.rallydev.com`

`RALLY_API_KEY=<READ_ONLY_API_KEY>`

`RALLY_PROJECT=SWAT`

`RALLY_MOCK_MODE=false`

Then run:

`--project=SWAT --sprint="Sprint 42.3" --mock=false`

The API key is never stored in source code.

## Rally endpoint used

The first scanner reads Rally User Stories using WSAPI 2.0:

`/slm/webservice/v2.0/hierarchicalrequirement`

The query is scoped to:

- Iteration.Name
- Project.Name

## Local snapshots

Each scan is stored under:

`data/snapshots/`

This gives FarmersAI Assist a historical baseline for later NEW / CHANGED / UNCHANGED / REMOVED detection.

## Next planned phases

1. Validate real Rally connectivity.
2. Add schema discovery and custom fields.
3. Read Tasks linked to each US.
4. Read Test Cases linked to each US.
5. Read attachments and relationships.
6. Add delta detection between scans.
7. Add requirement/risk analysis.
8. Generate proposed Tasks.
9. Generate proposed Test Cases.
10. Add editable TC/Task UI including Expected Result images.
11. Add human approval workflow.
12. Add Rally Publisher behind explicit approval.
13. Add MCP layer for GitHub Copilot.

## Security rule

The Rally publisher does not exist in MVP 0.1. Rally is read-only by design.


## MVP 0.4 visual update

- Approved FarmersAI Assist dashboard design.
- Farmers Insurance logo included as a local static asset.
- Blue / red / white / pink palette.
- Sidebar reduced to Dashboard only.
- Hierarchical selector: Project → Sprint / Iteration → Feature → User Story.
- User Story breadcrumb is blue.
- Mock hierarchy is intentionally isolated so the next phase can replace it with Rally MCP data.
- Rally remains read-only.


## MVP 0.4

Nine WebApp screens are now scaffolded. See `docs/SCREEN-INVENTORY.md`.


## MVP 0.4

Functional demonstrative screen navigation and Dashboard discard-confirmation modal were added.


## MVP 0.5 — Rally OAuth + Okta SSO

Set credentials in PowerShell before starting:

```powershell
$env:RALLY_CLIENT_ID="YOUR_CLIENT_ID"
$env:RALLY_CLIENT_SECRET="YOUR_CLIENT_SECRET"
$env:RALLY_REDIRECT_URI="http://localhost:8080/oauth/rally/callback"
mvn spring-boot:run
```

Open `http://localhost:8080`, click **Connect to Rally**, authorize the app, then use **Test US1209714**.

The token is stored only in the server-side HTTP session. No Rally write operation is enabled in this version.


## MVP 0.5.4 — Dashboard Visual Match

The Dashboard was rebuilt to closely match the approved FarmersAI Assist reference:
- Farmers navy sidebar with transparent Farmers Insurance logo.
- White/pink top hero area with decorative Farmers-style white flower.
- Project → Sprint → Feature → User Story controls with matching icons and colors.
- Scan & Analyze button and Auto Refresh presentation.
- Selected User Story card and metadata layout.
- Five KPI cards.
- Description, Related Items and AI Analysis Summary cards.
- Inline SVG icons to avoid external icon dependencies.

OAuth/Okta/Rally integration from MVP 0.5 remains intact.
Jackson 3 (`tools.jackson.databind`) and Playwright import corrections remain intact.


## MVP 0.5.4

Requested focused changes:
- Dashboard Rally hierarchy is now live after OAuth connection:
  Project → Sprint / Iteration → Feature → User Story.
- Feature options are derived from User Stories belonging to the selected Project + Iteration.
- Dashboard User Story details refresh when the User Story selection changes.
- `View in Rally` is clickable.
- `...` opens a functional contextual menu.
- Description action is now `Full Details` with document icon.
- Rally connection control is blue + gray dot when OFF, Farmers pink + green dot when ON.
- Test Case Proposal rows open the editor directly.
- `Open Test Case Editor` was removed.
- `Add Manual Proposal` opens a blank editor.
- Owner is always read-only and uses the FarmersAI Assist signed-in user.
- `Add Step` supports any number of steps.
- `Save Draft` validates and stores drafts in browser local storage.

No Rally write operations were enabled in this release.


## MVP 0.5.4

Focused changes only:
- Rally Project dropdown is restricted to projects under the `Marketing` project tree.
- Dashboard return confirmation is centered and uses the approved warning text:
  `When returning to the Dashboard, the information will not be saved. Do you want to continue?`


## MVP 0.5.4 — Approved Visual Reference & Bug Fixes

- Restyled the main workflow pages to align with the approved reference screenshots.
- Rally Connected uses Farmers pink (#F44783), not red.
- Fixed long Rally Description text so it wraps safely and never expands the Dashboard horizontally.
- Fixed Full Details so it opens Rally Analysis directly and never invokes the Dashboard-return warning.
- Dashboard warning remains exclusive to Dashboard navigation from screens 2–9.
- Preserved live Rally hierarchy, OAuth/Okta integration, clickable Test Case Proposals, editable Test Case Editor, Add Step, and Save Draft.
