# FFQ Playwright TypeScript: fixture migration

This project is a migration workspace for the Selenium/TestNG FFQ suite. It contains 2,941 unique Playwright test declarations. **Declaration parity does not mean that the UI scenarios are functional.** No UI scenario is certified in this release.

## What is executable now

- The 11 original Excel workbooks were converted to versioned JSON fixture catalogs: 122 sheets and 26,869 populated rows. No test reads an `.xlsx` file at runtime.
- The `legacyData` fixture selects rows using Java DataProvider metadata, supported state lists, categories, filters, and stable per-test random selection. `referenceData` provides Nearmap addresses, coverages, and umbrella applicants.
- The automatic `recoveryGuard` monitors Inconvenience, KnockOut, and TryAgain. On detection it attaches CopyDOM, screenshot, and context. It attempts at most two verified recovery actions; a terminal page never implies PASS.
- `npm run verify` checks the catalog, migration ID parity, TypeScript, and test discovery. This is **structural verification**, not an FFQ run.

## What still needs functional migration

The 2,941 specs retain their Java method contracts, but their UI behavior is not implemented. Of these, 2,691 have an execution gate and 250 were disabled in Java. The generated executor selects fixtures when the gate is enabled and then fails explicitly at the missing handler. This prevents a false PASS, but it does not reach the application break point.

Each scenario requires its own Playwright actions and assertions, reviewed against the original Java and executed against MA11 or RA11. The generated Page Objects include provisional `data-legacy-field` locators that require DOM verification. Do not add an ID to `certified-scenarios.json` before its full behavior and final assertions pass against FFQ.

One source array formula in `AutoDefaultCoveragesData/PA/P122` has a saved `#NAME?` result. The corresponding fixture fails when selected until its intended value is established.

## Commands

1. Use Node.js 22 or later, `npm ci`, and `npx playwright install chromium`.
2. Copy `.env.example` to `.env` and set the intended FFQ environment URL. Do not commit credentials.
3. Run `npm run verify` to check structure and data without opening FFQ.
4. `npm test` fails deliberately while no UI scenarios are certified, so an all-skipped suite cannot appear green.
5. To inspect one generated scenario and its fixture failure: `EXECUTE_MIGRATED_TESTS=true npm run test:diagnostic -- --grep 'scenarioMethodName' --headed`. This is a diagnostic failure, not a functional PASS.

The default local settings are headed Chromium, one worker, zero retries, and a ten-minute test timeout. Use the HTML report, trace, screenshot, and CopyDOM from a real run to migrate one scenario at a time.
