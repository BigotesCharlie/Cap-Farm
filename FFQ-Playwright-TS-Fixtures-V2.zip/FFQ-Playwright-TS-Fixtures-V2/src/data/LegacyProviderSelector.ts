import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import type { LegacyTestMetadata } from '../migration/LegacyTestMetadata.js';
import { materializeRow, rawRows, type DataRecord } from './FixtureCatalog.js';

export type SelectedCase = Readonly<{
  source: string;
  sheet: string;
  sourceId: string;
  state: string;
  data: DataRecord;
}>;

export class FixtureSelectionError extends Error {
  public override readonly name = 'FixtureSelectionError';
}

type CatalogRef = Readonly<{ book: string; sheet: string; mode?: 'one' | 'perState' | 'all' }>;
type SelectionOptions = Readonly<{ seed: string; environment: string; states?: string }>;

let constantsCache: Promise<Record<string, Record<string, string>>> | undefined;
let statesCache: Promise<Record<string, string[]>> | undefined;
async function jsonFile<T>(name: string): Promise<T> {
  return JSON.parse(await readFile(resolve('src/data/catalog', name), 'utf8')) as T;
}
async function constants(): Promise<Record<string, Record<string, string>>> {
  constantsCache ??= jsonFile('provider-constants.json');
  return constantsCache;
}
async function stateLists(): Promise<Record<string, string[]>> {
  statesCache ??= jsonFile('state-support.json');
  return statesCache;
}

function random(seed: string): () => number {
  let value = 2166136261;
  for (const char of seed) value = Math.imul(value ^ char.charCodeAt(0), 16777619);
  return () => {
    value += 0x6d2b79f5;
    let next = value;
    next = Math.imul(next ^ (next >>> 15), next | 1);
    next ^= next + Math.imul(next ^ (next >>> 7), next | 61);
    return ((next ^ (next >>> 14)) >>> 0) / 4294967296;
  };
}

function pick<T>(values: readonly T[], rng: () => number, context: string): T {
  if (!values.length) throw new FixtureSelectionError(`No eligible fixture rows: ${context}`);
  return values[Math.floor(rng() * values.length)]!;
}

function stateOf(row: DataRecord): string {
  return String(row.stateCode ?? row.state ?? row.stateAbb ?? '').trim().toUpperCase();
}

function sourceId(row: DataRecord): string {
  return String(row.applicantId ?? row.id ?? row.householdNumber ?? row.stateCode ?? 'unidentified');
}

function attributes(annotation: string): Map<string, string[]> {
  const result = new Map<string, string[]>();
  for (const match of annotation.matchAll(/@CustomAttribute\(name\s*=\s*(\w+),\s*values\s*=\s*\{([^}]*)\}/g)) {
    result.set(match[1]!, match[2]!.split(',').map((part) => part.trim().replace(/^"|"$/g, '')).filter(Boolean));
  }
  return result;
}

async function resolveConstant(expression: string): Promise<string> {
  const match = /^(\w+)\.(\w+)$/.exec(expression);
  if (!match) return expression;
  return (await constants())[match[1]!]?.[match[2]!] ?? match[2]!;
}

function sourceFor(metadata: LegacyTestMetadata): CatalogRef {
  const provider = metadata.dataProvider.split('.').pop() ?? '';
  const owner = metadata.dataProviderClass.replace(/\.class$/, '');
  if (!provider) throw new FixtureSelectionError(`No DataProvider for ${metadata.legacyId}`);
  if (owner === 'AceHomeDataProviders') {
    return { book: 'AceHomeTestData', sheet: provider === 'APPLICANT_ACE_HOME_DATA_PROVIDER' ? 'ApplicantHome' : 'PageValidationApplicantAceHome',
      mode: provider === 'APPLICANT_ACE_HOME_DATA_PROVIDER' ? 'all' : provider === 'ENVIRONMENT_STABILITY_DATA_PROVIDER' ? 'perState' : 'one' };
  }
  if (owner === 'AceBundleDataProviders') return { book: 'OneUIAutoTestData', sheet: 'applicant', mode: 'all' };
  if (owner === 'AutoDataProviders') {
    if (provider === 'AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER') return { book: 'OneUIAutoTestData', sheet: 'pageValidationApplicant', mode: 'one' };
    if (provider === 'RANDOM_ADPF_APPLICANT_DATA_PROVIDER') return { book: 'OneUIAutoTestData', sheet: 'ADPFApplicant', mode: 'one' };
    if (provider === 'BIND_ADPF_APPLICANT_DATA_PROVIDER') return { book: 'OneUIAutoTestData', sheet: 'bindOneUIApplicant' };
    if (provider === 'ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER') return { book: 'OneUIAutoTestData', sheet: 'ADPFApplicantVehicleDriverNum' };
    if (provider === 'AUTO_APPLICANT_DATA_PROVIDER') return { book: 'OneUIAutoTestData', sheet: 'applicant' };
  }
  if (owner === 'SqlDataProviders') {
    const sheets: Record<string, string> = {
      STATES_DATA_PROVIDER_NAME: 'stateValidation', AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER: 'pageValidationApplicant',
      AUTO_APPLICANT_DATA_PROVIDER: 'applicant', AUTO_APPLICANT_SAVE_AND_RETRIEVE_DATA_PROVIDER: 'retrieveQuoteApplicant',
      AUTO_APPLICANT_COMMON_DATA_PROVIDER: 'applicantTest', TEST_AUTO_APPLICANT_DATA_PROVIDER: 'testApplicant',
      ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER: 'applicantBVT', BVT_AUTO_APPLICANT_DATA_PROVIDER: 'applicantBVT',
      BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER: 'applicantBW',
      JENKINS_AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER: 'pageValidationApplicant',
      JENKINS_AUTO_APPLICANT_SMOKE_TEST_DATA_PROVIDER: 'applicantBVT',
      JENKINS_AUTO_APPLICANT_QUOTE_SCENARIOS_DATA_PROVIDER: 'applicant',
      HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER: 'applicant',
    };
    if (sheets[provider]) return { book: 'AutoTestData', sheet: sheets[provider]! };
  }
  if (owner === 'DataProviders') {
    if (/^APPLICANT_HOME_|^GET_RETRIEVE_QUOTE_APPLICANT_HOME$|^MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER$/.test(provider)) {
      return { book: 'HomeTestData', sheet: provider === 'GET_RETRIEVE_QUOTE_APPLICANT_HOME' ? 'GetRetrieveQuoteHome' : 'ApplicantHome' };
    }
    if (provider === 'APEX_HQM_DATA_PROVIDER') return { book: 'HQMApexTestData', sheet: 'ApexHQM' };
    if (provider.includes('HQM')) return { book: 'HQMTestData', sheet: 'ApplicantHome' };
    if (provider.includes('LIFE')) return { book: 'LifeTestData', sheet: 'ApplicantLife' };
    if (provider.includes('BUSINESS')) return { book: 'BusinessTestData', sheet: 'businessApplicant' };
    if (provider === 'ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER') return { book: 'AceHomeTestData', sheet: 'ApplicantHome' };
  }
  throw new FixtureSelectionError(`Unmapped Java DataProvider ${owner}.${provider} (${metadata.legacyId})`);
}

async function allowedStates(owner: string, environment: string): Promise<Set<string> | undefined> {
  const family = owner === 'AutoDataProviders' ? 'AceAuto' : owner === 'AceHomeDataProviders' ? 'AceHCR' : '';
  if (!family) return undefined;
  const key = `listOf${family}States_${environment.toUpperCase()}`;
  const list = (await stateLists())[key];
  if (!list) throw new FixtureSelectionError(`Missing Java state support list ${key}`);
  return new Set(list);
}

async function joinChildren(book: string, row: DataRecord): Promise<DataRecord> {
  if (book !== 'AutoTestData' && book !== 'OneUIAutoTestData' && book !== 'AceHomeTestData') return row;
  const id = sourceId(row);
  const sheets = book === 'AceHomeTestData' ? ['discounts'] :
    book === 'AutoTestData' ? ['vehicles', 'additionalDriver', 'incidents', 'discounts', 'payments', 'representative'] :
      ['vehicles', 'additionalDriver', 'incidents', 'discounts'];
  const result: Record<string, unknown> = { ...row };
  for (const sheet of sheets) {
    const all = await rawRows(book, sheet);
    const linked = sheet === 'representative'
      ? all.filter((child) => String(child.representativeId) === String(row.sameStateZip))
      : all.filter((child) => String(child.applicantId) === id);
    result[sheet] = await Promise.all(linked.map((child) => materializeRow(book, sheet, child)));
  }
  return Object.freeze(result);
}

export async function selectLegacyCases(metadata: LegacyTestMetadata, options: SelectionOptions): Promise<SelectedCase[]> {
  if (!metadata.dataProvider) {
    return [Object.freeze({ source: 'inline', sheet: 'none', sourceId: metadata.legacyId,
      state: '', data: Object.freeze({}) })];
  }
  const provider = sourceFor(metadata);
  const owner = metadata.dataProviderClass.replace(/\.class$/, '');
  const rng = random(`${options.seed}:${metadata.legacyId}`);
  const testName = await resolveConstant(metadata.testName);
  const suiteExpression = /suiteName\s*=\s*([\w.]+)/.exec(metadata.annotation)?.[1] ?? '';
  const category = await resolveConstant(suiteExpression);
  const attrs = attributes(metadata.annotation);
  let rows = [...await rawRows(provider.book, provider.sheet)];
  if (category && (owner === 'AceHomeDataProviders' || owner === 'AutoDataProviders')) {
    rows = rows.filter((row) => String(row.testCategory ?? '') === category);
  }
  const support = await allowedStates(owner, options.environment);
  const configured = options.states?.split(',').map((state) => state.trim().toUpperCase()).filter(Boolean);
  if (configured?.length) rows = rows.filter((row) => configured.includes(stateOf(row)));
  if (support) rows = rows.filter((row) => support.has(stateOf(row)));
  if (attrs.has('INCLUDED_STATES')) rows = rows.filter((row) => attrs.get('INCLUDED_STATES')!.includes(stateOf(row)));
  if (attrs.has('EXCLUDED_STATES')) rows = rows.filter((row) => !attrs.get('EXCLUDED_STATES')!.includes(stateOf(row)));
  const filter = attrs.get('FILTER')?.[0];
  if (filter) {
    const [field, value] = filter.split('=');
    if (!field || value === undefined) throw new FixtureSelectionError(`Invalid FILTER in ${metadata.legacyId}: ${filter}`);
    rows = rows.filter((row) => String(row[field] ?? '').trim() === value.trim());
  }
  if (testName.startsWith('row=')) {
    const ids = new Set(testName.slice(4).split(',').map((id) => id.trim()));
    rows = rows.filter((row) => ids.has(sourceId(row)));
  }
  if (testName === 'RandomAutoApplicantWithOneVehicle') {
    const vehicles = await rawRows(provider.book, 'vehicles');
    rows = rows.filter((row) => vehicles.filter((vehicle) => String(vehicle.applicantId) === sourceId(row)).length === 1);
  }
  if (owner === 'AceBundleDataProviders' && /WithIncidents|With3Vehicles/.test(testName)) {
    const sheet = testName.includes('Incidents') ? 'incidents' : 'vehicles';
    const linked = await rawRows(provider.book, sheet);
    rows = rows.filter((row) => {
      const count = linked.filter((child) => String(child.applicantId) === sourceId(row)).length;
      return testName.includes('Incidents') ? count > 0 && sourceId(row) !== '35' : count > 2;
    });
  }
  if (!rows.length) throw new FixtureSelectionError(`No data for ${metadata.legacyId}; ${provider.book}/${provider.sheet}; states=${options.states ?? 'environment default'}; category=${category}`);
  if (provider.mode === 'perState' || /OneApplicantPerState|OneBundleApplicantPerState|RandomAutoApplicantFromEachState/.test(testName)) {
    rows = [...new Set(rows.map(stateOf))].map((state) => pick(rows.filter((row) => stateOf(row) === state), rng, `${metadata.legacyId}/${state}`));
  } else if (provider.mode === 'one' || /RANDOM_ROW|RandomAutoApplicant|RandomBundleApplicant|ONE_ACE_LIFE|ONE_BUSINESS|BVT_AUTO_APPLICANT/.test(testName + ' ' + metadata.dataProvider)) {
    rows = [pick(rows, rng, metadata.legacyId)];
  }
  const selected: SelectedCase[] = [];
  for (const raw of rows) {
    let data = await materializeRow(provider.book, provider.sheet, raw);
    data = await joinChildren(provider.book, data);
    if (owner === 'AceBundleDataProviders') {
      const homes = (await rawRows('AceHomeTestData', 'ApplicantHome')).filter((home) => stateOf(home) === stateOf(data));
      const home = await materializeRow('AceHomeTestData', 'ApplicantHome', pick(homes, rng, `${metadata.legacyId}/home`));
      data = Object.freeze({ autoApplicant: data, hrcApplicant: await joinChildren('AceHomeTestData', home) });
    }
    selected.push(Object.freeze({ source: provider.book, sheet: provider.sheet, sourceId: sourceId(raw), state: stateOf(raw), data }));
  }
  return selected;
}
