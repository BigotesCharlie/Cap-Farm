import { promises as fs } from 'node:fs';
import { test as base, expect } from '@playwright/test';
import { RecoveryGuard } from '../core/RecoveryGuard.js';
import { selectLegacyCases, type SelectedCase } from '../data/LegacyProviderSelector.js';
import { ReferenceFixtures } from '../data/ReferenceFixtures.js';
import type { LegacyTestMetadata } from '../migration/LegacyTestMetadata.js';

type AutoFixtures = {
  recoveryGuard: RecoveryGuard;
  legacyData: (metadata: LegacyTestMetadata) => Promise<SelectedCase[]>;
  referenceData: ReferenceFixtures;
};

export const test = base.extend<AutoFixtures>({
  referenceData: async ({}, use, testInfo) => {
    await use(new ReferenceFixtures(process.env.FFQ_DATA_SEED || testInfo.testId));
  },
  legacyData: async ({}, use, testInfo) => {
    const cache = new Map<string, Promise<SelectedCase[]>>();
    await use((metadata) => {
      let selected = cache.get(metadata.legacyId);
      if (!selected) {
        selected = selectLegacyCases(metadata, {
          seed: process.env.FFQ_DATA_SEED || testInfo.testId,
          environment: process.env.TEST_ENV || 'MA11',
          ...(process.env.FFQ_DATA_STATES ? { states: process.env.FFQ_DATA_STATES } : {}),
        });
        cache.set(metadata.legacyId, selected);
      }
      return selected;
    });
  },
  recoveryGuard: [
    async ({ page }, use, testInfo) => {
      const guard = new RecoveryGuard(page, testInfo);
      guard.start();
      await use(guard);
      await guard.stop();
    },
    { auto: true },
  ],
});

test.afterEach(async ({ page }, testInfo) => {
  if (page.isClosed()) return;
  const dom = await page.content().catch(() => '');
  if (dom) {
    const path = testInfo.outputPath('final-dom.html');
    await fs.writeFile(path, dom, 'utf8');
    await testInfo.attach('final-dom', { path, contentType: 'text/html' });
  }
});

export { expect };
