# Two HOME E2E scenarios

This project intentionally keeps the certified Happy Path unchanged and adds the video-driven Purchase flow as an isolated second scenario.

## Scenario 1 — Certified Happy Path
- Test: `com.farmers.ffq.homehappypath.HomeHappyPathE2ETest.homeDomHappyPathE2E`
- Final state: `THANK_YOU`
- Existing data, locators, Copy-DOM, state detection and recovery code are preserved.

## Scenario 2 — Video-driven HOME Purchase flow
- Test: `com.farmers.ffq.homevideoflow.HomeVideoFlowE2ETest.reproduceVideoFlowE2E`
- Source of behavior/data: the supplied video and `reference/VideoFlow/` evidence.
- Final assertion: `Home policy payment` with `Pay in full`, `Due today`, and `Set up payment method` visible.
- No payment transaction is submitted.
- Includes Copy-DOM, Inconvenience recovery, KnockOut recovery and deterministic restart fallback.

## Commands

```powershell
.\gradlew.bat testClasses
.\gradlew.bat homeHappyPathE2E -Dheaded=true
.\gradlew.bat homeVideoFlowE2E -Dheaded=true
.\gradlew.bat homeTwoScenarioE2E -Dheaded=true
```

The `homeTwoScenarioE2E` task executes both test classes in the same Gradle invocation while each test creates an isolated Playwright browser context.
