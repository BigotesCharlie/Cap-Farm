# ffq-homeHP-e2e

Playwright Java HOME E2E project with **two isolated scenarios**.

The previously certified Happy Path remains unchanged. The video-driven Purchase flow is added as a second scenario in a separate package so it can evolve without destabilizing the certified baseline.

## Scenario 1 — Certified DOM Happy Path

**Test**

`com.farmers.ffq.homehappypath.HomeHappyPathE2ETest.homeDomHappyPathE2E`

**Final verified state:** `THANK_YOU`

**Data baseline:**
- 2331 Aperture Cir, San Diego, CA 92108
- Kuman Vontach
- DOB 06/09/1973
- Male / Engineer
- Dwelling coverage reference $518,000
- Runtime policy date = execution date + 1 day

The existing source files in `com.farmers.ffq.homehappypath` were preserved byte-for-byte from the uploaded working project.

Run:

```powershell
.\gradlew.bat homeHappyPathE2E -Dheaded=true
```

## Scenario 2 — Video-driven HOME Purchase flow

**Test**

`com.farmers.ffq.homevideoflow.HomeVideoFlowE2ETest.reproduceVideoFlowE2E`

**Video-driven path:**

LANDING → PROPERTY_TYPE → ADDRESS → QUALITY_GRADE → PROPERTY_SUMMARY → ADDITIONAL_INFO → ABOUT_YOU → CONTACT_INFO → DWELLING_COVERAGE → LOADING → HOME_COVERAGES → OPTIONAL_COVERAGES → ADDITIONAL_QUESTIONS → FINALIZING → PAYMENT_OPTIONS → PAYMENT

**Final assertion:** the `Home policy payment` page is displayed with `Pay in full`, `Due today`, and `Set up payment method` visible.

The test deliberately **does not submit a real payment transaction** because the supplied video stops at payment setup.

Video reference screenshots are retained under:

`reference/VideoFlow/`

The extracted flow/data analysis is documented in:

`VIDEO_FLOW_ANALYSIS.md`

Run:

```powershell
.\gradlew.bat homeVideoFlowE2E -Dheaded=true
```

The effective date from the recording is retained as evidence, but UAT execution defaults to tomorrow. Override when required:

```powershell
.\gradlew.bat homeVideoFlowE2E -Dheaded=true -DpolicyDate=MM/dd/yyyy
```

## Run both E2Es

```powershell
.\gradlew.bat testClasses
.\gradlew.bat homeTwoScenarioE2E -Dheaded=true
```

Each test creates its own Playwright browser/context, data object, flow, artifacts and recovery state. The second scenario does not mutate the Happy Path scenario data or Page Objects.

## Shared engineering approach

Both scenarios use the same project-level stack and engineering rules:

- Java 17
- Gradle
- Playwright Java 1.61.0
- TestNG 7.12.0
- state-driven navigation
- Playwright-native locators and waits
- Copy-DOM diagnostics
- Inconvenience recovery
- KnockOut recovery
- `Try again` first, deterministic restart fallback
- maximum two application recovery attempts
- no Selenium / WebDriver / WebElement / `Thread.sleep()`

## Copy-DOM

Scenario 1:

`artifacts/dom/HomeDOM-HappyPath/<execution-id>/`

Scenario 2:

`artifacts/dom/HomeVideoFlow-E2E/<execution-id>/`

The video scenario also writes `AUTODEBUG.txt` on a terminal failure to expose current URL, headings, controls, labels and the failure reason.

## First run on a new workstation

```powershell
.\gradlew.bat playwrightInstall
.\gradlew.bat testClasses
```

Then execute either scenario independently before running the combined task.
