package com.farmers.ffq.homehappypath;

import com.farmers.ffq.homehappypath.config.HomeScenarioData;
import com.farmers.ffq.homehappypath.flow.HomeHappyPathFlow;
import com.microsoft.playwright.*;
import org.testng.annotations.Test;

public class HomeHappyPathE2ETest {

    @Test
    public void homeDomHappyPathE2E() {
        String startUrl = System.getProperty(
                "baseUrl",
                "https://ffqautouiuat.farmers.com/quote/home/personal-info"
        );
        boolean headed = Boolean.parseBoolean(System.getProperty("headed", "true"));

        try (Playwright playwright = Playwright.create()) {
            Browser browser = playwright.chromium().launch(
                    new BrowserType.LaunchOptions().setHeadless(!headed)
            );
            BrowserContext context = browser.newContext(
                    new Browser.NewContextOptions().setViewportSize(1440, 1000)
            );
            Page page = context.newPage();
            page.setDefaultTimeout(15_000);
            page.setDefaultNavigationTimeout(30_000);

            HomeScenarioData scenario = HomeScenarioData.domHappyPath();
            new HomeHappyPathFlow(page, scenario, startUrl).run(startUrl);

            context.close();
            browser.close();
        }
    }
}
