package com.farmers.ffq.homevideoflow;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.farmers.ffq.homevideoflow.flow.HomeVideoFlow;
import com.microsoft.playwright.*;
import org.testng.annotations.Test;

public class HomeVideoFlowE2ETest {
    @Test
    public void reproduceVideoFlowE2E() {
        VideoScenarioData data = VideoScenarioData.fromVideo();
        boolean headed = Boolean.parseBoolean(System.getProperty("headed", "true"));

        try (Playwright playwright = Playwright.create()) {
            Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(!headed));
            BrowserContext context = browser.newContext(new Browser.NewContextOptions().setViewportSize(1440, 1000));
            Page page = context.newPage();
            page.setDefaultTimeout(15_000);
            page.setDefaultNavigationTimeout(30_000);

            try {
                new HomeVideoFlow(page, data).run();
            } finally {
                context.close();
                browser.close();
            }
        }
    }
}
