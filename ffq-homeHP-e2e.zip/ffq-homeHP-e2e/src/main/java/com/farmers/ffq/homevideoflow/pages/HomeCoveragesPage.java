package com.farmers.ffq.homevideoflow.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;

public final class HomeCoveragesPage extends BaseHomePage {
    public HomeCoveragesPage(Page page) { super(page); }
    public void verifyAndContinue() {
        assertHeading("Home coverages");
        Locator enhanced = page.getByText("Enhanced", new Page.GetByTextOptions().setExact(true));
        if (enhanced.count() > 0) PlaywrightAssertions.assertThat(enhanced.first()).isVisible();
        Locator deductible = page.getByText("$1,500 deductible", new Page.GetByTextOptions().setExact(false));
        if (deductible.count() > 0) PlaywrightAssertions.assertThat(deductible.first()).isVisible();
        clickButton("Continue");
    }
}
