package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;

public final class DwellingCoveragePage extends BaseHomePage {
    public DwellingCoveragePage(Page page) { super(page); }
    public void verifyAndContinue(VideoScenarioData d) {
        assertHeading("Review your dwelling coverage");
        Locator amount = page.getByText(d.observedDwellingCoverage(), new Page.GetByTextOptions().setExact(false));
        if (amount.count() > 0) PlaywrightAssertions.assertThat(amount.first()).isVisible();
        Locator cont = button("Continue");
        if (cont.count() > 0) cont.first().click();
        else clickText("Continue");
    }
}
