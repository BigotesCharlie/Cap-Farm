package com.farmers.ffq.homehappypath.support;

import com.microsoft.playwright.Page;

public final class HomeStateDetector {
    private final Page page;

    public HomeStateDetector(Page page) {
        this.page = page;
    }

    public HomeState detect() {
        String body = safeBody().toLowerCase();
        String url = page.url().toLowerCase();

        if (url.contains("/thankyou") || contains(body, "thank you for choosing farmers insurance")) return HomeState.THANK_YOU;
        if (contains(body, "what type of property is it?")) return HomeState.PROPERTY_TYPE;
        if (contains(body, "what’s the address?") || contains(body, "what's the address?")) return HomeState.ADDRESS;
        if (contains(body, "your home quality grade")) return HomeState.QUALITY_GRADE;
        if (contains(body, "here’s what we have so far") || contains(body, "here's what we have so far")) return HomeState.PROPERTY_SUMMARY;
        if (contains(body, "additional home information")) return HomeState.ADDITIONAL_INFO;
        // Check page-heading–based states BEFORE "about you" because the stepper nav
        // on post-ABOUT_YOU pages contains the step label "About you" and would otherwise
        // misidentify DWELLING_COVERAGE / HOME_COVERAGES pages.
        // HOME_COVERAGES must be checked BEFORE LOADING: the /review-quote SPA page
        // eventually renders "Home coverages" content at the same URL.
        if (contains(body, "home coverages")) return HomeState.HOME_COVERAGES;
        if (contains(body, "optional coverages")) return HomeState.OPTIONAL_COVERAGES;
        if (contains(body, "review your dwelling coverage") || url.contains("/custom-coverage")) return HomeState.DWELLING_COVERAGE;
        // LOADING only when the body shows the actual loading screen text.
        if (contains(body, "one moment, please") || contains(body, "finishing up")) return HomeState.LOADING;
        if (contains(body, "last step before your quote")) return HomeState.CONTACT_INFO;
        if (contains(body, "about you")) return HomeState.ABOUT_YOU;
        if (url.contains("/fastquote")
                && contains(body, "farmers fastquote")
                && contains(body, "get a new quote")
                && contains(body, "retrieve a saved quote")
                && contains(body, "start my quote")
                && contains(body, "zip code")) {
            return HomeState.LANDING;
        }
        if (url.contains("inconvenience") || contains(body, "inconvenience")) return HomeState.INCONVENIENCE;
        if (url.contains("knockout") || contains(body, "knockout") || contains(body, "unable to continue")) return HomeState.KNOCKOUT;
        return HomeState.UNKNOWN;
    }

    private String safeBody() {
        try {
            return page.locator("body").innerText();
        } catch (RuntimeException ex) {
            return "";
        }
    }

    private boolean contains(String value, String expected) {
        return value.contains(expected.toLowerCase());
    }
}
