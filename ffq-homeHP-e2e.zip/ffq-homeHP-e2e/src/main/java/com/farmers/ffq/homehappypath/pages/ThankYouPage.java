package com.farmers.ffq.homehappypath.pages;

import com.microsoft.playwright.Page;

public final class ThankYouPage extends BaseHomePage {
    public ThankYouPage(Page page) { super(page); }

    public void verifyComplete() {
        String body = page.locator("body").innerText().toLowerCase();
        String url = page.url().toLowerCase();
        if (!url.contains("/thankyou") && !(body.contains("thank you for choosing") && body.contains("farmers insurance"))) {
            throw new AssertionError("Final Farmers thank-you page not reached");
        }
    }
}
