package com.farmers.ffq.homevideoflow.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public final class LandingPage extends BaseHomePage {
    public LandingPage(Page page) { super(page); }
    public void startQuote() {
        Locator quote = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Get a quote").setExact(false));
        if (quote.count() == 0) quote = page.getByText("Get a quote", new Page.GetByTextOptions().setExact(false));
        if (quote.count() > 0) quote.first().click();
        else throw new IllegalStateException("Get a quote control not found on landing page");
    }
}
