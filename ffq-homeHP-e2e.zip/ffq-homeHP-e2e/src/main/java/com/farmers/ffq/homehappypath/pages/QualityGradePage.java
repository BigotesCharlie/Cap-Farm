package com.farmers.ffq.homehappypath.pages;

import com.farmers.ffq.homehappypath.config.HomeScenarioData;
import com.microsoft.playwright.Page;

public final class QualityGradePage extends BaseHomePage {
    public QualityGradePage(Page page) { super(page); }

    public void reviewAndContinue(HomeScenarioData data) {
        String body = page.locator("body").innerText();
        if (!body.contains(data.street())) {
            throw new AssertionError("Quality Grade page does not show expected address: " + data.street());
        }
        if (!body.contains("Above Average")) {
            throw new AssertionError("Expected Above Average quality grade from supplied DOM scenario");
        }
        continueButton();
    }
}
