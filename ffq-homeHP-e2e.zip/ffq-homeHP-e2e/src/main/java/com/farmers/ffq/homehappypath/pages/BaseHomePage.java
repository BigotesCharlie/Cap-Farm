package com.farmers.ffq.homehappypath.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.WaitForSelectorState;

public abstract class BaseHomePage {
    protected final Page page;

    protected BaseHomePage(Page page) {
        this.page = page;
    }

    protected Locator button(String name) {
        return page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName(name).setExact(true));
    }

    protected Locator radio(String name) {
        return page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName(name).setExact(true));
    }

    protected void clickButton(String name) {
        button(name).first().click();
    }

    protected void clickText(String text) {
        page.getByText(text, new Page.GetByTextOptions().setExact(true)).first().click();
    }

    protected void clickRadioIn(String containerCss, String option) {
        Locator radio = page.locator(containerCss)
                .getByRole(AriaRole.RADIO, new Locator.GetByRoleOptions().setName(option).setExact(true));
        waitForSpinnerToClear();
        radio.waitFor();
        if ("true".equalsIgnoreCase(radio.getAttribute("aria-checked"))) {
            return;
        }
        radio.click();
        waitForSpinnerToClear();
    }

    protected void clickRadio(String option) {
        Locator radio = page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName(option).setExact(true));
        waitForSpinnerToClear();
        radio.first().waitFor();
        if ("true".equalsIgnoreCase(radio.first().getAttribute("aria-checked"))) {
            return;
        }
        radio.first().click();
        waitForSpinnerToClear();
    }

    protected void continueButton() {
        waitForSpinnerToClear();
        Locator c = button("Continue");
        if (c.count() == 0) {
            c = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Continue"));
        }
        if (c.count() == 0) {
            c = page.locator("button").filter(new Locator.FilterOptions().setHasText("Continue"));
        }
        if (c.count() > 0) {
            c.last().click();
            waitForSpinnerToClear();
            return;
        }
        throw new IllegalStateException("Continue button not found on " + page.url());
    }

    protected void waitForBodyReady() {
        page.locator("body").waitFor();
    }

    protected void waitForSpinnerToClear() {
        page.locator(".tui-spinner-app-background")
                .waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN));
    }
}
