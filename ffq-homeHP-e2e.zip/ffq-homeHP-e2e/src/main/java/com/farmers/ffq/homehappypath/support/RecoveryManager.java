package com.farmers.ffq.homehappypath.support;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.LoadState;

public final class RecoveryManager {
    private static final int MAX_RECOVERY = 2;
    private final Page page;
    private final HomeStateDetector detector;
    private final DomArtifacts artifacts;
    private final String startUrl;
    private int recoveries;

    public RecoveryManager(Page page, HomeStateDetector detector, DomArtifacts artifacts, String startUrl) {
        this.page = page;
        this.detector = detector;
        this.artifacts = artifacts;
        this.startUrl = startUrl;
    }

    public boolean recoverIfNeeded() {
        HomeState state = detector.detect();
        if (state != HomeState.KNOCKOUT && state != HomeState.INCONVENIENCE) return false;
        if (recoveries >= MAX_RECOVERY) {
            artifacts.captureFailure();
            throw new IllegalStateException(
                    "[HOME RECOVERY] APPLICATION_BLOCKER: Exceeded MAX_RECOVERY=" + MAX_RECOVERY
                            + " on " + state + " at " + page.url());
        }
        recoveries++;
        String recTag = String.format("recovery-%03d", recoveries);
        System.out.printf("[HOME RECOVERY] Detected %s at %s%n", state, page.url());
        artifacts.capture(recTag + "-before");

        // Level 1 — Try Again (live DOM uses "Try again" with lowercase 'a')
        Locator tryAgain = page.getByRole(AriaRole.BUTTON,
                new Page.GetByRoleOptions().setName("Try again").setExact(true));
        if (tryAgain.count() == 0) {
            tryAgain = page.getByRole(AriaRole.BUTTON,
                    new Page.GetByRoleOptions().setName("Try Again").setExact(true));
        }
        if (tryAgain.count() == 0) {
            tryAgain = page.locator("button").filter(
                    new Locator.FilterOptions().setHasText("Try again"));
        }

        if (tryAgain.count() > 0 && tryAgain.first().isVisible()) {
            System.out.printf("[HOME RECOVERY] Attempt %d/%d: TRY_AGAIN%n", recoveries, MAX_RECOVERY);
            tryAgain.first().click();
            // Wait until we leave the inconvenience/knockout page.
            page.waitForFunction(
                    "() => {"
                            + "const u = document.location.href.toLowerCase();"
                            + "return !u.includes('inconvenience') && !u.includes('knockout');"
                            + "}",
                    null,
                    new Page.WaitForFunctionOptions().setTimeout(30_000));
            HomeState afterState = detector.detect();
            artifacts.capture(recTag + "-after");
            System.out.printf("[HOME RECOVERY] Resulting state: %s%n", afterState);
            return true;
        }

        // Level 2 — Application restart from entry point
        System.out.printf("[HOME RECOVERY] Attempt %d/%d: APPLICATION_RESTART%n", recoveries, MAX_RECOVERY);
        page.navigate(startUrl);
        page.waitForLoadState(LoadState.DOMCONTENTLOADED);
        HomeState afterState = detector.detect();
        artifacts.capture(recTag + "-after");
        System.out.printf("[HOME RECOVERY] Resulting state after restart: %s%n", afterState);
        return true;
    }
}
