package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;

public final class ContactInfoPage extends BaseHomePage {
    public ContactInfoPage(Page page) { super(page); }

    public void complete(VideoScenarioData d) {
        assertHeading("Last step before your quote");

        Locator date = page.getByLabel("policy", new Page.GetByLabelOptions().setExact(false));
        if (date.count() == 0) date = page.locator("input[type=date],input:visible").first();
        String runtimeDate = d.runtimePolicyStartDate();
        date.fill(runtimeDate);
        System.out.printf("[VIDEO FLOW] Policy start date: video=%s runtime=%s%n", d.videoPolicyStartDate(), runtimeDate);

        Locator mailing = page.getByText(d.address(), new Page.GetByTextOptions().setExact(false));
        if (mailing.count() > 0) mailing.first().click();

        Locator email = page.getByLabel("Email address", new Page.GetByLabelOptions().setExact(false));
        if (email.count() == 0) email = page.locator("input[type=email]:visible").first();
        email.fill(d.email());
        PlaywrightAssertions.assertThat(email).hasValue(d.email());

        Locator phone = page.getByLabel("Mobile phone", new Page.GetByLabelOptions().setExact(false));
        if (phone.count() == 0) phone = page.locator("input[type=tel]:visible").first();
        phone.fill(d.mobilePhone());

        clickButton("Agree and submit");
    }
}
