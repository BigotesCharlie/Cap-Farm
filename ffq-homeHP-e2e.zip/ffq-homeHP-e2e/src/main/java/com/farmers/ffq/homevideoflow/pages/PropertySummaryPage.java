package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;
import com.microsoft.playwright.options.AriaRole;

import java.util.LinkedHashMap;
import java.util.Map;

public final class PropertySummaryPage extends BaseHomePage {
    public PropertySummaryPage(Page page) { super(page); }

    public void applyVideoEditsAndContinue(VideoScenarioData d) {
        assertHeading("Here's what we have so far");
        PlaywrightAssertions.assertThat(page.getByText(d.address(), new Page.GetByTextOptions().setExact(false)).first()).isVisible();

        Locator edit = page.getByText("Edit details", new Page.GetByTextOptions().setExact(false));
        if (edit.count() > 0) edit.first().click();
        else throw new IllegalStateException("Edit details control not found");

        Map<String,String> edits = new LinkedHashMap<>();
        edits.put("Year built", d.yearBuilt());
        edits.put("Total finished sq. ft", d.finishedSqFt());
        edits.put("Stories", d.stories());
        edits.put("Bathrooms", d.bathrooms());
        edits.put("Fireplace", d.fireplace());
        edits.put("Floors", d.floors());
        edits.put("Garage style", d.garageStyle());
        edits.put("Garage / carport", d.garageCapacity());
        edits.put("Exterior wall finish", d.exteriorWall());
        edits.put("Foundation type", d.foundation());
        edits.put("Finished basement", d.finishedBasement());
        edits.put("Roof cover", d.roofCover());
        edits.put("Type of home", d.typeOfHome());
        edits.put("Fire sprinkler system", d.fireSprinkler());

        for (Map.Entry<String,String> e : edits.entrySet()) {
            editDrawerField(e.getKey(), e.getValue());
        }

        Locator close = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Close").setExact(false));
        if (close.count() > 0) close.first().click();
        assertSummaryValue(d.yearBuilt());
        assertSummaryValue(d.finishedSqFt());
        assertSummaryValue(d.roofCover());
        clickButton("Continue");
    }

    private void editDrawerField(String label, String value) {
        Locator row = page.getByText(label, new Page.GetByTextOptions().setExact(true));
        if (row.count() == 0) {
            System.out.printf("[VIDEO FLOW] Drawer field not present/required: %s%n", label);
            return;
        }
        row.last().click();
        page.waitForTimeout(150);

        Locator input = page.locator("input:visible");
        if (input.count() > 0) {
            Locator candidate = input.last();
            String type = candidate.getAttribute("type");
            if (type == null || !type.equalsIgnoreCase("radio")) {
                candidate.fill(value.replace(",", ""));
                Locator suggestion = page.getByText(value, new Page.GetByTextOptions().setExact(false));
                if (suggestion.count() > 0 && suggestion.last().isVisible()) suggestion.last().click();
                else candidate.press("Enter");
                return;
            }
        }

        // Multi-value fields such as Floors are represented as comma-separated video values.
        if (value.contains(",")) {
            for (String part : value.split(",")) selectOptionIfAvailable(part.trim());
            Locator done = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Done").setExact(false));
            if (done.count() > 0) done.first().click();
            return;
        }
        selectOptionIfAvailable(value);
    }

    private void selectOptionIfAvailable(String value) {
        Locator role = page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName(value).setExact(false));
        if (role.count() > 0) { role.last().click(); return; }
        Locator checkbox = page.getByRole(AriaRole.CHECKBOX, new Page.GetByRoleOptions().setName(value).setExact(false));
        if (checkbox.count() > 0) { if (!checkbox.last().isChecked()) checkbox.last().check(); return; }
        Locator text = page.getByText(value, new Page.GetByTextOptions().setExact(false));
        if (text.count() > 0) { text.last().click(); return; }
        throw new IllegalStateException("Could not select drawer option '" + value + "' at " + page.url());
    }

    private void assertSummaryValue(String value) {
        Locator l = page.getByText(value, new Page.GetByTextOptions().setExact(false));
        if (l.count() > 0) PlaywrightAssertions.assertThat(l.first()).isVisible();
    }
}
