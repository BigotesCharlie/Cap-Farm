package com.farmers.ffq.homevideoflow.support;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public final class RecoveryManager {
    public static final int MAX_RECOVERY = 2;
    private final Page page;
    private final HomeStateDetector detector;
    private final DomArtifacts artifacts;
    private final String startUrl;
    private int recoveryCount;

    public RecoveryManager(Page page, HomeStateDetector detector, DomArtifacts artifacts, String startUrl) {
        this.page = page;
        this.detector = detector;
        this.artifacts = artifacts;
        this.startUrl = startUrl;
    }

    public boolean recoverIfNeeded() {
        HomeState state = detector.detect();
        if (state != HomeState.INCONVENIENCE && state != HomeState.KNOCKOUT) return false;
        if (recoveryCount >= MAX_RECOVERY) {
            throw new IllegalStateException("Exceeded MAX_RECOVERY=" + MAX_RECOVERY + " while in " + state + " at " + page.url());
        }

        recoveryCount++;
        String id = String.format("recovery-%03d", recoveryCount);
        System.out.printf("[HOME RECOVERY] Detected %s at %s%n", state, page.url());
        artifacts.captureNamed(id + "-before");

        Locator tryAgain = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Try again").setExact(false));
        if (tryAgain.count() == 0) tryAgain = page.getByText("Try again", new Page.GetByTextOptions().setExact(false));
        if (tryAgain.count() == 0) tryAgain = page.getByText("Try Again", new Page.GetByTextOptions().setExact(false));

        if (tryAgain.count() > 0 && tryAgain.first().isVisible() && tryAgain.first().isEnabled()) {
            System.out.printf("[HOME RECOVERY] Attempt %d/%d: TRY_AGAIN%n", recoveryCount, MAX_RECOVERY);
            tryAgain.first().click();
            waitUntilLeavingBlocker();
            HomeState result = detector.detect();
            artifacts.captureNamed(id + "-after");
            System.out.printf("[HOME RECOVERY] Resulting state: %s%n", result);
            return true;
        }

        System.out.printf("[HOME RECOVERY] Attempt %d/%d: APPLICATION_RESTART%n", recoveryCount, MAX_RECOVERY);
        page.navigate(startUrl);
        page.waitForLoadState();
        artifacts.captureNamed(id + "-after-restart");
        return true;
    }

    private void waitUntilLeavingBlocker() {
        try {
            page.waitForFunction("() => !location.href.toLowerCase().includes('inconvenience') && !location.href.toLowerCase().includes('knockout')",
                    null, new Page.WaitForFunctionOptions().setTimeout(30_000));
        } catch (RuntimeException ignored) {
            // Flow loop will detect the resulting state and either continue or use level-2 recovery.
        }
    }
}
