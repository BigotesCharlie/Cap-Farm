package com.farmers.ffq.homehappypath.pages;

import com.farmers.ffq.homehappypath.config.HomeScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public final class ContactInfoPage extends BaseHomePage {
    public ContactInfoPage(Page page) { super(page); }

    public void complete(HomeScenarioData data) {
        waitForBodyReady();
        waitForSpinnerToClear();

        Locator date = page.locator("input[aria-label='When would you like your policy to begin? Policy start date in the format of mmddyyyy.']");
        if (date.count() > 0) {
            date.fill(data.policyStartDate().replace("/", ""));
        }

        Locator mailing = page.getByLabel(data.mailingAddress(), new Page.GetByLabelOptions().setExact(true));
        if (mailing.count() > 0 && !mailing.isChecked()) {
            mailing.check();
        }

        page.locator("#flex-field-emailAddress-input_contactInfo").fill(data.email());
        page.locator("#flex-field-phoneNumber-input_contactInfo").fill(data.phone());

        Locator submit = button("Agree and submit");
        if (submit.count() == 0) {
            submit = page.getByText("Agree and submit", new Page.GetByTextOptions().setExact(true));
        }
        submit.first().click();
        // Wait for the expected next state OR an INCONVENIENCE/KNOCKOUT page to exit immediately.
        page.waitForFunction(
                "() => {" +
                        "const u = document.location.href.toLowerCase();" +
                        "const text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();" +
                        "return text.includes('review your dwelling coverage')" +
                        " || text.includes('home coverages')" +
                        " || text.includes('thank you for choosing farmers insurance')" +
                        " || u.includes('inconvenience') || u.includes('knockout')" +
                        " || text.includes(\"we're sorry, we can't finish\")" +
                        " || text.includes('try again');" +
                        "}",
                null,
                new Page.WaitForFunctionOptions().setTimeout(30_000)
        );
    }
}
