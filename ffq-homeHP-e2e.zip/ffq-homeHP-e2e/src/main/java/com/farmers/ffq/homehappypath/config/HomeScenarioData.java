package com.farmers.ffq.homehappypath.config;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public record HomeScenarioData(
        String street,
        String city,
        String zip,
        String firstName,
        String lastName,
        String dob,
        String gender,
        String occupation,
        String policyStartDate,
        String email,
        String phone,
        String dwellingCoverage
) {
    // Historical supplied reference date: 08/15/2026.
    // At runtime the effective date is calculated as execution date + 1 day
    // so it always falls within the application's allowed window.
    public static HomeScenarioData domHappyPath() {
        String effectiveDate = LocalDate.now()
                .plusDays(1)
                .format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        return new HomeScenarioData(
                "2331 Aperture Cir",
                "San Diego",
                "92108",
                "Kuman",
                "Vontach",
                "06/09/1973",
                "Male",
                "Engineer",
                effectiveDate,
                "kumal_vontach@farminsqa.testinator.com",
                "(828) 523-4748",
                "$518,000"
        );
    }

    public String mailingAddress() {
        return "2331 APERTURE CIR, SAN DIEGO, CA 92108";
    }
}
