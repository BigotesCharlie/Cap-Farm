package com.farmers.ffq.homevideoflow.pages;

import com.microsoft.playwright.Page;

public final class LoadingPage extends BaseHomePage {
    public LoadingPage(Page page) { super(page); }
    public void verify() { assertHeading("One moment, please"); }
}
