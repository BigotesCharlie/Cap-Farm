package com.farmers.ffq.homevideoflow.flow;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.farmers.ffq.homevideoflow.pages.*;
import com.farmers.ffq.homevideoflow.support.*;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.LoadState;

import java.util.EnumSet;

public final class HomeVideoFlow {
    private static final int MAX_TRANSITIONS = 48;

    private final Page page;
    private final VideoScenarioData data;
    private final HomeStateDetector detector;
    private final DomArtifacts artifacts;
    private final RecoveryManager recovery;
    private final TransitionGuard guard;
    private final EnumSet<HomeState> visited = EnumSet.noneOf(HomeState.class);

    public HomeVideoFlow(Page page, VideoScenarioData data) {
        this.page = page;
        this.data = data;
        this.detector = new HomeStateDetector(page);
        this.artifacts = new DomArtifacts(page, "HomeVideoFlow-E2E");
        this.recovery = new RecoveryManager(page, detector, artifacts, data.startUrl());
        this.guard = new TransitionGuard(page, detector, recovery);
    }

    public void run() {
        System.out.println("[HOME VIDEO FLOW] Starting: " + data.startUrl());
        page.navigate(data.startUrl());
        page.waitForLoadState(LoadState.DOMCONTENTLOADED);

        for (int i = 1; i <= MAX_TRANSITIONS; i++) {
            try {
                if (recovery.recoverIfNeeded()) continue;

                HomeState state = detector.detect();
                System.out.printf("[HOME VIDEO FLOW] Transition %02d | state=%s | url=%s%n", i, state, page.url());
                artifacts.capture(state.name());
                visited.add(state);

                switch (state) {
                    case LANDING -> new LandingPage(page).startQuote();
                    case PROPERTY_TYPE -> new PropertyTypePage(page).chooseHome();
                    case ADDRESS -> new AddressPage(page).complete(data);
                    case QUALITY_GRADE -> new QualityGradePage(page).verifyAndContinue(data);
                    case PROPERTY_SUMMARY -> new PropertySummaryPage(page).applyVideoEditsAndContinue(data);
                    case ADDITIONAL_INFO -> new AdditionalInfoPage(page).complete(data);
                    case ABOUT_YOU -> new AboutYouPage(page).complete(data);
                    case CONTACT_INFO -> new ContactInfoPage(page).complete(data);
                    case DWELLING_COVERAGE -> new DwellingCoveragePage(page).verifyAndContinue(data);
                    case LOADING -> new LoadingPage(page).verify();
                    case HOME_COVERAGES -> new HomeCoveragesPage(page).verifyAndContinue();
                    case OPTIONAL_COVERAGES -> new OptionalCoveragesPage(page).continueWithoutChanges();
                    case ADDITIONAL_QUESTIONS -> new AdditionalQuestionsPage(page).complete(data);
                    case FINALIZING -> new FinalizingPage(page).verify();
                    case PAYMENT_OPTIONS -> new PaymentOptionsPage(page).choosePayInFull(data);
                    case PAYMENT -> {
                        new PaymentPage(page).verifyVideoEndState();
                        artifacts.capture("PASS-PAYMENT-PAGE");
                        System.out.println("[HOME VIDEO FLOW] PASS - video end state reached: Home policy payment / Pay in full.");
                        return;
                    }
                    case THANK_YOU -> {
                        artifacts.capture("PASS-THANK-YOU");
                        System.out.println("[HOME VIDEO FLOW] PASS - Thank You reached (alternate post-purchase end state).");
                        return;
                    }
                    case INCONVENIENCE, KNOCKOUT -> { /* recovery at top of loop */ }
                    case UNKNOWN -> throw new IllegalStateException("Unknown HOME state at " + page.url());
                }

                // Short SPA settle window only. The next loop re-detects state; no blind 60s wait.
                page.waitForTimeout(350);
            } catch (RuntimeException | AssertionError failure) {
                // One recovery check before surfacing a failure that may actually be an application blocker.
                try {
                    if (recovery.recoverIfNeeded()) continue;
                } catch (RuntimeException recoveryFailure) {
                    artifacts.captureFailure(recoveryFailure);
                    throw recoveryFailure;
                }
                artifacts.captureFailure(failure);
                throw failure;
            }
        }

        IllegalStateException failure = new IllegalStateException("Exceeded transitions. Visited=" + visited);
        artifacts.captureFailure(failure);
        throw failure;
    }
}
