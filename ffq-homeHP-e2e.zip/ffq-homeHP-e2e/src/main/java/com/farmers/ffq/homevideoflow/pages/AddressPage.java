package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;
import com.microsoft.playwright.options.AriaRole;

public final class AddressPage extends BaseHomePage {
    public AddressPage(Page page) { super(page); }

    public void complete(VideoScenarioData d) {
        assertHeading("What's the address");
        Locator address = page.getByLabel("Home Address", new Page.GetByLabelOptions().setExact(false));
        if (address.count() == 0) address = page.locator("input:visible").first();
        address.first().fill(d.address());

        // The video chooses the address suggestion; prefer a suggestion containing the full street.
        Locator suggestion = page.getByText(d.address(), new Page.GetByTextOptions().setExact(false));
        if (suggestion.count() > 1) suggestion.last().click();
        else if (suggestion.count() == 1 && suggestion.first().isVisible()) suggestion.first().click();

        clickQuestionOption("buying", d.ownedLessThanYear() ? "Yes" : "No");
        clickQuestionOption("primary residence", d.primaryResidence() ? "Yes" : "No");
        clickQuestionOption("property claims", d.claimsLastThreeYears());

        Locator agree = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Agree").setExact(false));
        if (agree.count() == 0) agree = page.getByText("Agree", new Page.GetByTextOptions().setExact(true));
        agree.first().click();
    }

    private void clickQuestionOption(String questionFragment, String option) {
        Locator q = page.getByText(questionFragment, new Page.GetByTextOptions().setExact(false));
        if (q.count() > 0) {
            Locator block = q.first().locator("xpath=ancestor::*[self::div or self::section][1]");
            Locator choice = block.getByText(option, new Locator.GetByTextOptions().setExact(true));
            if (choice.count() > 0) { choice.last().click(); return; }
        }
        Locator role = page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName(option).setExact(true));
        if (role.count() > 0) { role.last().click(); return; }
        page.getByText(option, new Page.GetByTextOptions().setExact(true)).last().click();
    }
}
