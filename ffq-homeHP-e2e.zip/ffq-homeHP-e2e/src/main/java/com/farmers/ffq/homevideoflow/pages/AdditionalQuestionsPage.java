package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public final class AdditionalQuestionsPage extends BaseHomePage {
    public AdditionalQuestionsPage(Page page) { super(page); }
    public void complete(VideoScenarioData d) {
        assertHeading("Just a few more things");
        Locator date = page.getByLabel("policy", new Page.GetByLabelOptions().setExact(false));
        if (date.count() == 0) date = page.locator("input[type=date]:visible").first();
        if (date.count() > 0) date.fill(d.runtimePolicyStartDate());

        // Video proceeds with no lender information and leaves optional questions unchecked.
        Locator no = page.getByText("No", new Page.GetByTextOptions().setExact(true));
        if (no.count() > 0) no.last().click();

        Locator cont = button("Continue");
        if (cont.count() > 0) cont.last().click();
        else {
            Locator c = page.getByText("Continue", new Page.GetByTextOptions().setExact(true));
            if (c.count() > 0) c.last().click();
            else throw new IllegalStateException("Continue not found on additional questions");
        }
    }
}
