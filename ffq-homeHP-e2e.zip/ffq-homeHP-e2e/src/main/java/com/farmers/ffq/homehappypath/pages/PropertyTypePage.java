package com.farmers.ffq.homehappypath.pages;

import com.microsoft.playwright.Page;

public final class PropertyTypePage extends BaseHomePage {
    public PropertyTypePage(Page page) { super(page); }

    public void chooseHome() {
        waitForBodyReady();
        waitForSpinnerToClear();
        page.locator("h1.page-title").waitFor();
        waitForSpinnerToClear();
        page.getByText("Townhome", new Page.GetByTextOptions().setExact(true)).first().click();
        page.waitForFunction(
                "() => {" +
                        "const text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();" +
                        "return text.includes(\"what's the address?\")" +
                        " || text.includes('what’s the address?')" +
                        " || text.includes('get started with just a few details.')" +
                        " || text.includes('your home quality grade');" +
                        "}"
        );
    }
}
