package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;

public final class QualityGradePage extends BaseHomePage {
    public QualityGradePage(Page page) { super(page); }
    public void verifyAndContinue(VideoScenarioData d) {
        assertHeading("Your home quality grade");
        PlaywrightAssertions.assertThat(page.getByText(d.address(), new Page.GetByTextOptions().setExact(false)).first()).isVisible();
        // Video keeps all four quality categories at Standard.
        if (page.getByText("Standard", new Page.GetByTextOptions().setExact(true)).count() < 4) {
            throw new AssertionError("Expected four Standard quality-grade values as shown in the video");
        }
        clickButton("Continue");
    }
}
