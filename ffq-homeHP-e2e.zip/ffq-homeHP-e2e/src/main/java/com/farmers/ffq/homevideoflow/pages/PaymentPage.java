package com.farmers.ffq.homevideoflow.pages;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;

public final class PaymentPage extends BaseHomePage {
    public PaymentPage(Page page) { super(page); }
    public void verifyVideoEndState() {
        assertHeading("Home policy payment");
        PlaywrightAssertions.assertThat(page.getByText("Pay in full", new Page.GetByTextOptions().setExact(true)).first()).isVisible();
        PlaywrightAssertions.assertThat(page.getByText("Due today", new Page.GetByTextOptions().setExact(false)).first()).isVisible();
        PlaywrightAssertions.assertThat(page.getByText("Set up payment method", new Page.GetByTextOptions().setExact(false)).first()).isVisible();
        // Deliberately stop here: the source video does not submit a real payment transaction.
    }
}
