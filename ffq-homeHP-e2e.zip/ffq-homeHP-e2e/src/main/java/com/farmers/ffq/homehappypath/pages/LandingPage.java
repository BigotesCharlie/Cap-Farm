package com.farmers.ffq.homehappypath.pages;

import com.farmers.ffq.homehappypath.config.HomeScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public final class LandingPage extends BaseHomePage {
    public LandingPage(Page page) {
        super(page);
    }

    public void startHomeQuote(HomeScenarioData data) {
        Locator homeOption = page.locator("mat-list-option[title='Select Home to get Home Quote']");
        homeOption.waitFor();
        homeOption.click();

        Locator zipCode = page.getByLabel("Zip code");
        zipCode.fill(data.zip());
        if (!data.zip().equals(zipCode.inputValue())) {
            throw new IllegalStateException("ZIP Code field did not retain value on " + page.url());
        }

        page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Start my Quote").setExact(true)).click();
        page.waitForFunction(
                "() => {" +
                        "const text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();" +
                        "return text.includes('what type of property is it?')" +
                        " || text.includes(\"what's the address?\")" +
                        " || text.includes('what’s the address?')" +
                        " || text.includes('your home quality grade')" +
                        " || text.includes(\"here's what we have so far\")" +
                        " || text.includes('here’s what we have so far')" +
                        " || text.includes('additional home information')" +
                        " || text.includes('about you');" +
                        "}"
        );
    }
}
