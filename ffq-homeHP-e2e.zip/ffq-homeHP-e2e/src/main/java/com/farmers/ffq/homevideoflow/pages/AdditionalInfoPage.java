package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public final class AdditionalInfoPage extends BaseHomePage {
    public AdditionalInfoPage(Page page) { super(page); }

    public void complete(VideoScenarioData d) {
        assertHeading("Additional home information");
        selectQuestion("Has your roof been completely replaced", d.roofReplaced() ? "Yes" : "No");
        setCheckbox("Central fire alarm", d.centralFireAlarm());
        setCheckbox("Central burglar alarm", d.centralBurglarAlarm());
        clickButton("Continue");
    }

    private void selectQuestion(String fragment, String option) {
        Locator question = page.getByText(fragment, new Page.GetByTextOptions().setExact(false));
        if (question.count() > 0) {
            Locator block = question.first().locator("xpath=ancestor::*[self::div or self::section][1]");
            Locator opt = block.getByText(option, new Locator.GetByTextOptions().setExact(true));
            if (opt.count() > 0) { opt.last().click(); return; }
        }
        page.getByText(option, new Page.GetByTextOptions().setExact(true)).first().click();
    }

    private void setCheckbox(String label, boolean expected) {
        Locator box = page.getByRole(AriaRole.CHECKBOX, new Page.GetByRoleOptions().setName(label).setExact(false));
        if (box.count() == 0) box = page.getByLabel(label, new Page.GetByLabelOptions().setExact(false));
        if (box.count() == 0) return;
        Locator b = box.first();
        if (expected && !b.isChecked()) b.check();
        if (!expected && b.isChecked()) b.uncheck();
    }
}
