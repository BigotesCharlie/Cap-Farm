package com.farmers.ffq.homevideoflow.support;

import com.microsoft.playwright.Page;

public final class HomeStateDetector {
    private final Page page;

    public HomeStateDetector(Page page) { this.page = page; }

    public HomeState detect() {
        String url = safe(page.url()).toLowerCase();
        String body = safeBody().toLowerCase();

        // Blockers first so a page-specific heading does not mask recovery state.
        if (url.contains("inconvenience") || body.contains("we can't finish your quote online") || body.contains("try again")) {
            return HomeState.INCONVENIENCE;
        }
        if (url.contains("knockout") || body.contains("knockout") || body.contains("unable to continue")) {
            return HomeState.KNOCKOUT;
        }

        if (body.contains("less ‘gotcha.’") || body.contains("less \"gotcha.\"") || (url.contains("fastquote") && body.contains("get a quote"))) return HomeState.LANDING;
        if (body.contains("what type of property is it")) return HomeState.PROPERTY_TYPE;
        if (body.contains("what’s the address") || body.contains("what's the address")) return HomeState.ADDRESS;
        if (body.contains("your home quality grade")) return HomeState.QUALITY_GRADE;
        if (body.contains("here’s what we have so far") || body.contains("here's what we have so far")) return HomeState.PROPERTY_SUMMARY;
        if (body.contains("additional home information")) return HomeState.ADDITIONAL_INFO;
        if (body.contains("about you")) return HomeState.ABOUT_YOU;
        if (body.contains("last step before your quote")) return HomeState.CONTACT_INFO;
        if (body.contains("review your dwelling coverage")) return HomeState.DWELLING_COVERAGE;
        if (body.contains("one moment, please")) return HomeState.LOADING;
        if (body.contains("optional coverages")) return HomeState.OPTIONAL_COVERAGES;
        if (body.contains("home coverages")) return HomeState.HOME_COVERAGES;
        if (body.contains("just a few more things")) return HomeState.ADDITIONAL_QUESTIONS;
        if (body.contains("finalizing your quote")) return HomeState.FINALIZING;
        if (body.contains("how would you like to pay")) return HomeState.PAYMENT_OPTIONS;
        if (body.contains("home policy payment")) return HomeState.PAYMENT;
        if (body.contains("thank you for choosing farmers insurance")) return HomeState.THANK_YOU;
        return HomeState.UNKNOWN;
    }

    private String safeBody() {
        try { return page.locator("body").innerText(); }
        catch (RuntimeException ex) { return ""; }
    }

    private String safe(String s) { return s == null ? "" : s; }
}
