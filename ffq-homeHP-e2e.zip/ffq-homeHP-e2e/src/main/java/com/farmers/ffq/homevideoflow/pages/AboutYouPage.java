package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;
import com.microsoft.playwright.options.AriaRole;

public final class AboutYouPage extends BaseHomePage {
    public AboutYouPage(Page page) { super(page); }

    public void complete(VideoScenarioData d) {
        assertHeading("About you");
        fillByLabelOrIndex("First name", 0, d.firstName());
        fillByLabelOrIndex("Last name", 1, d.lastName());
        fillByLabelOrIndex("Date of birth", 2, d.dob());

        Locator gender = page.getByText(d.gender(), new Page.GetByTextOptions().setExact(true));
        if (gender.count() > 0) gender.last().click();
        else page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName(d.gender()).setExact(false)).first().click();

        clickButton("Continue");
    }

    private void fillByLabelOrIndex(String label, int index, String value) {
        Locator l = page.getByLabel(label, new Page.GetByLabelOptions().setExact(false));
        if (l.count() == 0) l = page.locator("input:visible").nth(index);
        l.fill(value);
        PlaywrightAssertions.assertThat(l).hasValue(value);
    }
}
