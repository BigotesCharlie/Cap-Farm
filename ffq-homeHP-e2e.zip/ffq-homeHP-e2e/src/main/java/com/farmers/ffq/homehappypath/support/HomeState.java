package com.farmers.ffq.homehappypath.support;

public enum HomeState {
    LANDING,
    PROPERTY_TYPE,
    ADDRESS,
    QUALITY_GRADE,
    PROPERTY_SUMMARY,
    ADDITIONAL_INFO,
    ABOUT_YOU,
    CONTACT_INFO,
    DWELLING_COVERAGE,
    /** Intermediate server-processing state at /review-quote ("One moment, please"). */
    LOADING,
    HOME_COVERAGES,
    OPTIONAL_COVERAGES,
    THANK_YOU,
    KNOCKOUT,
    INCONVENIENCE,
    UNKNOWN
}
