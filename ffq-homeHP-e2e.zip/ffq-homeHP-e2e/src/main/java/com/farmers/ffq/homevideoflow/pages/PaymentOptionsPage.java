package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;

public final class PaymentOptionsPage extends BaseHomePage {
    public PaymentOptionsPage(Page page) { super(page); }
    public void choosePayInFull(VideoScenarioData d) {
        assertHeading("How would you like to pay");
        PlaywrightAssertions.assertThat(page.getByText("Pay in full", new Page.GetByTextOptions().setExact(true)).first()).isVisible();
        Locator card = page.getByText("Pay in full", new Page.GetByTextOptions().setExact(true)).first().locator("xpath=ancestor::*[self::div or self::section][1]");
        Locator select = card.getByText("Select & set up payment", new Locator.GetByTextOptions().setExact(false));
        if (select.count() > 0) select.first().click();
        else page.getByText("Select & set up payment", new Page.GetByTextOptions().setExact(false)).first().click();
    }
}
