package com.farmers.ffq.homehappypath.pages;

import com.farmers.ffq.homehappypath.config.HomeScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public final class DwellingCoveragePage extends BaseHomePage {
    public DwellingCoveragePage(Page page) { super(page); }

    public void verifyAndContinue(HomeScenarioData data) {
        waitForBodyReady();
        waitForSpinnerToClear();

        String body = page.locator("body").innerText();
        if (!body.contains(data.dwellingCoverage())) {
            throw new AssertionError("Expected dwelling coverage " + data.dwellingCoverage() + " was not shown");
        }

        // Button text varies: "Continue", "Get my quote", "See my quote"
        Locator btn = page.locator("button").filter(new Locator.FilterOptions().setHasText("Continue"));
        if (btn.count() == 0) btn = page.locator("button").filter(new Locator.FilterOptions().setHasText("Get my quote"));
        if (btn.count() == 0) btn = page.locator("button").filter(new Locator.FilterOptions().setHasText("See my quote"));
        if (btn.count() == 0) throw new IllegalStateException("DwellingCoverage: advance button not found on " + page.url());
        btn.last().click();
        waitForSpinnerToClear();
    }
}
