package com.farmers.ffq.homehappypath.pages;

import com.farmers.ffq.homehappypath.config.HomeScenarioData;
import com.microsoft.playwright.Page;

import java.util.List;

public final class PropertySummaryPage extends BaseHomePage {
    private static final List<String> EXPECTED = List.of(
            "2015", "1,585", "2", "3",
            "Zero clearance fireplace",
            "Carpet", "Hardwood", "Stone & tile",
            "Attached / Built-in", "2 cars",
            "Traditional hard coat", "Concrete slab",
            "Architectural shingle", "Single family attached end unit"
    );

    public PropertySummaryPage(Page page) { super(page); }

    public void verifyAndContinue(HomeScenarioData data) {
        String body = page.locator("body").innerText();
        if (!body.contains(data.street())) {
            throw new AssertionError("Property summary does not contain expected address");
        }
        for (String expected : EXPECTED) {
            if (!body.toLowerCase().contains(expected.toLowerCase())) {
                throw new AssertionError("Property summary missing DOM-proven value: " + expected);
            }
        }
        continueButton();
    }
}
