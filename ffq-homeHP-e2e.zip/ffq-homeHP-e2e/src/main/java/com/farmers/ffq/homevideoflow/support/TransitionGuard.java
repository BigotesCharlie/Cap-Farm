package com.farmers.ffq.homevideoflow.support;

import com.microsoft.playwright.Page;
import java.util.EnumSet;

public final class TransitionGuard {
    private final Page page;
    private final HomeStateDetector detector;
    private final RecoveryManager recovery;

    public TransitionGuard(Page page, HomeStateDetector detector, RecoveryManager recovery) {
        this.page = page;
        this.detector = detector;
        this.recovery = recovery;
    }

    public HomeState waitForNext(EnumSet<HomeState> allowed, double timeoutMs) {
        long end = System.currentTimeMillis() + (long) timeoutMs;
        HomeState last = HomeState.UNKNOWN;
        while (System.currentTimeMillis() < end) {
            if (recovery.recoverIfNeeded()) return detector.detect();
            last = detector.detect();
            if (allowed.contains(last)) return last;
            page.waitForTimeout(250);
        }
        return last;
    }
}
