package com.farmers.ffq.homevideoflow.pages;

import com.microsoft.playwright.Page;

public final class OptionalCoveragesPage extends BaseHomePage {
    public OptionalCoveragesPage(Page page) { super(page); }
    public void continueWithoutChanges() {
        assertHeading("Optional coverages");
        // Video reviews optional coverages and continues without adding a new option.
        clickButton("Continue");
    }
}
