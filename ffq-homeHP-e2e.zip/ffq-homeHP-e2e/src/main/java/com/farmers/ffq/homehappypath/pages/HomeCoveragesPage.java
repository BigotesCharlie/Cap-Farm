package com.farmers.ffq.homehappypath.pages;

import com.farmers.ffq.homehappypath.config.HomeScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public final class HomeCoveragesPage extends BaseHomePage {
    public HomeCoveragesPage(Page page) { super(page); }

    public void verifyAndContinue(HomeScenarioData data) {
        waitForBodyReady();
        waitForSpinnerToClear();

        String body = page.locator("body").innerText();
        if (!body.toLowerCase().contains("home coverages")) throw new AssertionError("Home coverages page not displayed");

        // The checkout/Continue button is in a fixed sidebar; use its specific class and
        // scroll into view to ensure it is interactable.
        Locator btn = page.locator("button.home-quote-start-checkout-button:visible");
        if (btn.count() == 0) {
            btn = page.locator("button:visible").filter(new Locator.FilterOptions().setHasText("Continue"));
        }
        if (btn.count() == 0) btn = page.locator("button:visible").filter(new Locator.FilterOptions().setHasText("Get my quote"));
        if (btn.count() == 0) {
            if (body.toLowerCase().contains("thank you for choosing farmers insurance")) return;
            throw new IllegalStateException("HomeCoverages: advance button not found on " + page.url());
        }
        btn.first().click();
        waitForSpinnerToClear();

        page.waitForFunction(
                "() => {"
                        + "const text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();"
                        + "return text.includes('optional coverages')"
                        + " || text.includes('thank you for choosing farmers insurance')"
                        + " || text.includes(\"we're sorry, we can't finish your quote online at this time\");"
                        + "}",
                null,
                new Page.WaitForFunctionOptions().setTimeout(30_000)
        );
    }
}
