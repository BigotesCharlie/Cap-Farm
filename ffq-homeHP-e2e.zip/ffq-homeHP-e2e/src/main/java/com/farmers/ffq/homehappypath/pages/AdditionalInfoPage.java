package com.farmers.ffq.homehappypath.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public final class AdditionalInfoPage extends BaseHomePage {
    public AdditionalInfoPage(Page page) { super(page); }

    public void complete() {
        // DOM-proven selections from AdditionalInfo1/2 screenshots.
        clickRoofReplacedNo();
        ensureCheckbox("It has a swimming pool.", true);
        clickRadio("The pool is fenced");
        ensureCheckbox("It has solar panels.", true);
        ensureCheckbox("It has a trampoline.", false);
        ensureCheckbox("Fire alarm", true);
        chooseProfessionalMonitoring();
        ensureCheckbox("Burglar alarm", false);
        ensureCheckbox("Water leak protection", false);
        ensureCheckbox("FORTIFIED Home certification", false);
        continueButton();
        page.waitForFunction(
                "() => {" +
                        "const text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();" +
                        "return text.includes('about you')" +
                        " || text.includes('let’s get to know each other.')" +
                        " || text.includes(\"let's get to know each other.\")" +
                        " || text.includes('last step before your quote');" +
                        "}"
        );
    }

    private void clickRoofReplacedNo() {
        clickRadioIn("#roofCoverage", "No");
    }

    private void ensureCheckbox(String label, boolean expectedChecked) {
        Locator cb = page.getByLabel(label, new Page.GetByLabelOptions().setExact(true));
        if (cb.count() == 0) return;
        if (expectedChecked && !cb.isChecked()) cb.check();
        if (!expectedChecked && cb.isChecked()) cb.uncheck();
    }

    private void chooseProfessionalMonitoring() {
        clickRadio("Professionally monitored");
    }
}
