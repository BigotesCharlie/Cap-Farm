package com.farmers.ffq.homehappypath.pages;

import com.farmers.ffq.homehappypath.config.HomeScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public final class AddressPage extends BaseHomePage {
    public AddressPage(Page page) { super(page); }

    public void complete(HomeScenarioData data) {
        waitForBodyReady();
        waitForSpinnerToClear();
        Locator street = page.getByLabel("Home Address (No Post Office Boxes)");
        street.fill(data.street());

        // The supplied DOM shows the manual address fields directly on this state.
        fillIfEditable(page.getByLabel("city"), data.city());
        fillIfEditable(page.getByLabel("zipCode"), data.zip());

        clickRadioIn("#formField_isNewHome", "No");
        clickRadioIn("#formField_isPrimaryResidence", "Yes");
        clickRadioIn("#formField_noOfPropertyLosses", "None");

        Locator agree = button("Agree");
        if (agree.count() == 0) {
            agree = page.getByText("Agree", new Page.GetByTextOptions().setExact(true));
        }
        agree.first().click();
        page.waitForFunction(
                "() => {" +
                        "const text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();" +
                        "return text.includes('your home quality grade')" +
                        " || text.includes(\"here's what we have so far\")" +
                        " || text.includes('here’s what we have so far')" +
                        " || text.includes('additional home information');" +
                        "}"
        );
    }

    private void fillIfEditable(Locator locator, String value) {
        if (locator.count() > 0 && locator.first().isVisible() && locator.first().isEditable()) {
            locator.first().fill(value);
        }
    }
}
