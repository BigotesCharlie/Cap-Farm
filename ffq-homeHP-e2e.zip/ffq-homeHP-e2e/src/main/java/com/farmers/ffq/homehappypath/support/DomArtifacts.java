package com.farmers.ffq.homehappypath.support;

import com.microsoft.playwright.Page;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

public final class DomArtifacts {
    private final Page page;
    private final Path runDir;
    private final AtomicInteger sequence = new AtomicInteger(1);

    public DomArtifacts(Page page, String scenarioName) {
        this.page = page;
        String runId = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        this.runDir = Path.of("artifacts", "dom", scenarioName, runId);
        try {
            Files.createDirectories(runDir);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to create DOM artifact directory", e);
        }
    }

    public void capture(String stateName) {
        int n = sequence.getAndIncrement();
        String prefix = String.format("%02d-%s", n, sanitize(stateName));
        write(runDir.resolve(prefix + ".html"), page.content());
        write(runDir.resolve(prefix + "-url.txt"), page.url());
        write(runDir.resolve(prefix + "-headings.txt"), safeHeadings());
        try {
            page.screenshot(new Page.ScreenshotOptions()
                    .setPath(runDir.resolve(prefix + ".png"))
                    .setFullPage(true));
        } catch (RuntimeException ignored) {
            // HTML is the primary artifact; screenshot capture must not hide the original failure.
        }
    }

    public void captureFailure() {
        write(runDir.resolve("failure-current-page.html"), page.content());
        write(runDir.resolve("failure-current-page-url.txt"), page.url());
        write(runDir.resolve("failure-current-page-headings.txt"), safeHeadings());
        try {
            page.screenshot(new Page.ScreenshotOptions()
                    .setPath(runDir.resolve("failure-current-page.png"))
                    .setFullPage(true));
        } catch (RuntimeException ignored) {
        }
    }

    private String safeHeadings() {
        try {
            return page.locator("h1,h2,h3,[role=heading]").allInnerTexts().toString();
        } catch (RuntimeException ex) {
            return "[]";
        }
    }

    private void write(Path path, String text) {
        try {
            Files.writeString(path, text == null ? "" : text, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to write artifact " + path, e);
        }
    }

    private String sanitize(String value) {
        return value.toLowerCase().replaceAll("[^a-z0-9]+", "-").replaceAll("(^-|-$)", "");
    }
}
