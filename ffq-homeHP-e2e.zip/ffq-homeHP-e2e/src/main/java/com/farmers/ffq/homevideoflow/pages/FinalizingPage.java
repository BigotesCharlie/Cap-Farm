package com.farmers.ffq.homevideoflow.pages;

import com.microsoft.playwright.Page;

public final class FinalizingPage extends BaseHomePage {
    public FinalizingPage(Page page) { super(page); }
    public void verify() { assertHeading("Finalizing your quote"); }
}
