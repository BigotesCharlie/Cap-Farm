package com.farmers.ffq.homehappypath.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public final class OptionalCoveragesPage extends BaseHomePage {
    public OptionalCoveragesPage(Page page) {
        super(page);
    }

    public void verifyAndContinue() {
        waitForBodyReady();
        waitForSpinnerToClear();

        String body = page.locator("body").innerText().toLowerCase();
        if (!body.contains("optional coverages")) {
            throw new AssertionError("Optional coverages page not displayed");
        }

        Locator btn = page.locator("button.home-quote-start-checkout-button:visible");
        if (btn.count() == 0) {
            btn = page.locator("button:visible").filter(new Locator.FilterOptions().setHasText("Continue"));
        }
        if (btn.count() == 0) {
            throw new IllegalStateException("OptionalCoverages: advance button not found on " + page.url());
        }

        btn.first().click();
        waitForSpinnerToClear();

        page.waitForFunction(
                "() => {"
                        + "const text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();"
                        + "const url = window.location.href.toLowerCase();"
                        + "return url.includes('/thankyou')"
                        + " || text.includes('thank you for choosing farmers insurance')"
                        + " || text.includes(\"we're sorry, we can't finish your quote online at this time\");"
                        + "}",
                null,
                new Page.WaitForFunctionOptions().setTimeout(60_000)
        );
    }
}
