package com.farmers.ffq.homevideoflow.pages;

import com.microsoft.playwright.Page;

public final class PropertyTypePage extends BaseHomePage {
    public PropertyTypePage(Page page) { super(page); }
    public void chooseHome() {
        assertHeading("What type of property is it");
        clickText("Home");
    }
}
