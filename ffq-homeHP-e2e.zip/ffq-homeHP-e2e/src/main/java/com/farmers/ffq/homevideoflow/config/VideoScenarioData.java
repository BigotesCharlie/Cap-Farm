package com.farmers.ffq.homevideoflow.config;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public record VideoScenarioData(
        String startUrl,
        String propertyType,
        String address,
        String city,
        String state,
        String zip,
        boolean ownedLessThanYear,
        boolean primaryResidence,
        String claimsLastThreeYears,
        String yearBuilt,
        String finishedSqFt,
        String stories,
        String bathrooms,
        String fireplace,
        String floors,
        String garageStyle,
        String garageCapacity,
        String exteriorWall,
        String foundation,
        String finishedBasement,
        String roofCover,
        String typeOfHome,
        String fireSprinkler,
        boolean roofReplaced,
        boolean centralFireAlarm,
        boolean centralBurglarAlarm,
        String firstName,
        String lastName,
        String dob,
        String gender,
        String email,
        String mobilePhone,
        String videoPolicyStartDate,
        String observedDwellingCoverage,
        String paymentChoice
) {
    public static VideoScenarioData fromVideo() {
        return new VideoScenarioData(
                "https://ffqautouiuat.farmers.com/quote/home/personal-info",
                "Home",
                "205 Nicholas Dr",
                "Lewiston",
                "MN",
                "55952",
                false,
                true,
                "None",
                "2017",
                "2175",
                "3 stories",
                "2",
                "Zero clearance fireplace",
                "Carpet, Hardwood",
                "Attached / Built-in",
                "1 car",
                "Vinyl",
                "Basement",
                "100% finished",
                "Impact resistant shingle",
                "Single family detached",
                "None",
                false,
                true,
                true,
                "DorisKhn",
                "FeigNy",
                "07/13/1967",
                "Female",
                "alma_larton@farminsqa.testinator.com",
                "5189387728",
                "08/11/2026",
                "$566,000",
                "Pay in full"
        );
    }

    /**
     * UAT only accepts an effective date inside its live validity window.
     * Preserve the video value for documentation, but runtime defaults to tomorrow
     * unless -DpolicyDate=MM/dd/yyyy is explicitly supplied.
     */
    public String runtimePolicyStartDate() {
        String supplied = System.getProperty("policyDate");
        if (supplied != null && !supplied.isBlank()) return supplied.trim();
        return LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
    }
}
