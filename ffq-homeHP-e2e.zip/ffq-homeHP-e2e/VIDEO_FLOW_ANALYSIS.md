# Video Flow Analysis — HOME E2E

Source: `video.mp4`, duration ~344 seconds, 682x512.

## Observed navigation

1. Farmers Fast Quote landing → **Get a quote**
2. **What type of property is it?** → Home
3. **What's the address?** → 205 Nicholas Dr, Lewiston, MN 55952
   - Owned/buying for less than a year: **No**
   - Primary residence: **Yes**
   - Claims in last 3 years: **None**
   - Click **Agree**
4. **Your home quality grade**
   - General Shape & Style: Standard
   - Exterior Features & Finishes: Standard
   - Interior Features & Finishes: Standard
   - Cabinets & Countertops: Standard
   - Click **Continue**
5. **Here's what we have so far** → click **Edit details** and update the drawer
6. **Additional home information**
7. **About you**
8. **Last step before your quote** → contact information → **Agree and submit**
9. **Review your dwelling coverage** → observed amount: **$566,000**
10. **One moment, please**
11. **Home coverages** → Enhanced package visible; Continue
12. **Optional coverages** → no new optional coverage selected; Continue
13. **Just a few more things** → policy start date / lender / other questions
14. **Finalizing your quote ...**
15. **How would you like to pay?** → **Pay in full** → Select & set up payment
16. **Home policy payment — Pay in full**
    - The video stops at the payment setup screen. The automation intentionally does **not** submit a real payment.

## Video values centralized in `VideoScenarioData`

- Address: `205 Nicholas Dr`, Lewiston, MN `55952`
- Property type: Home
- Year built: `2017`
- Total finished sq. ft.: `2175`
- Stories: `3 stories`
- Bathrooms: `2`
- Fireplace: `Zero clearance fireplace`
- Floors: `Carpet, Hardwood`
- Garage style: `Attached / Built-in`
- Garage/carport: `1 car`
- Exterior wall finish: `Vinyl`
- Foundation: `Basement`
- Finished basement: `100% finished`
- Roof cover: `Impact resistant shingle`
- Type of home: `Single family detached`
- Fire sprinkler system: `None`
- Roof completely replaced: No
- Central fire alarm: selected
- Central burglar alarm: selected
- DOB: `07/13/1967`
- Gender: Female
- Email visible in video: `alma_larton@farminsqa.testinator.com`
- Mobile phone visible in video: `(518) 938-7728`
- Policy start date shown in the recording: `08/11/2026`
- Dwelling coverage observed: `$566,000`
- Payment choice: Pay in full

### Low-resolution transcription note

The source video is 682x512. The first/last-name strings are therefore centralized in one class (`VideoScenarioData`) so they can be corrected in one location if a higher-resolution source is provided. The current best-effort transcription is `DorisKhn / FeigNy`.

### Runtime date rule

The date shown in the historical video can expire in UAT. Runtime therefore defaults to **local date + 1 day** (or `-DpolicyDate=MM/dd/yyyy`) while preserving the video value for evidence. This follows the stabilized HappyPath behavior from this project history.

## Click behavior reproduced

- Get a quote
- Home property type
- Address autocomplete suggestion
- No / Yes / None address questions
- Agree
- Continue from quality grade
- Edit details and each property-detail drawer row
- No roof replacement; central fire and burglar alarm checkboxes
- Female
- Continue / Agree and submit
- Continue through dwelling / coverages / optional coverages
- No mortgage lender path on “Just a few more things”
- Pay in full → Select & set up payment

## Assertions

The project asserts page headings and stable video values at key checkpoints. Volatile premium/quote-number values are not hard-coded as business assertions.

## Flakiness / blockers

`RecoveryManager` handles:

- `/quote/inconvenience` / Inconvenience body text
- KnockOut / `unable to continue`
- Level 1: **Try again**
- Level 2: deterministic restart from the same start URL
- `MAX_RECOVERY = 2`

Every state and recovery creates Copy-DOM HTML, URL, headings and screenshot artifacts.

## Auto-debugging

On failure the project writes:

- `failure-current-page.html`
- `failure-current-page.png`
- `failure-current-page-url.txt`
- `failure-current-page-headings.txt`
- `failure-exception.txt`
- `AUTODEBUG.txt`

The auto-debug file records current URL, headings, visible buttons/labels and the exception, explicitly instructing the next debugging iteration to inspect live DOM evidence before changing waits or locators.
