# HomeDOM Happy Path Flow Map

| State | Evidence file | Primary action |
|---|---|---|
| PROPERTY_TYPE | DOM_WhatkindofProperty.txt | Select Home |
| ADDRESS | DOM_Address.txt + WhatsTheAddress.png | Fill 2331 Aperture Cir / San Diego / 92108; No; Yes; None; Agree |
| QUALITY_GRADE | DOM_QualityGrade.txt + QualityGrade.png | Verify Above Average and continue |
| PROPERTY_SUMMARY | DOM_WeHaveSoFar.txt + WeHaveSoFar.png | Verify DOM-proven property facts and continue |
| ADDITIONAL_INFO | DOM_AdditionalHomeInformation.txt + AdditionalInfo1/2.png | Roof No; fenced pool; solar; no trampoline; fire alarm/professional monitoring |
| ABOUT_YOU | DOM_AboutYou.txt + AboutYou.png | Kuman Vontach; DOB; Male; Employed/Engineer; Continue |
| CONTACT_INFO | DOM_LastStepBYQ.txt + LSBYQ.png | Policy date, existing mailing address, email, mobile, Agree and submit |
| DWELLING_COVERAGE | ReviewYourDwellingCoverage.png | Verify $518,000 and continue |
| HOME_COVERAGES | DOM_HomeCoverages.txt | Verify $518,000 and quote number section; continue |
| THANK_YOU | DOM_ThankyouForChoosing.txt | Assert final Thank You page |
