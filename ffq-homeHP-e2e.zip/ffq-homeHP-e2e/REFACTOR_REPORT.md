# Project Refactor

- New project name: `ffq-homeHP-e2e`
- Both E2E scenarios retained.
- Happy Path functional code not intentionally modified.
- Video Flow scenario retained.
- Gradle project identity updated in `settings.gradle`.
- Documentation references updated to the new project name.
