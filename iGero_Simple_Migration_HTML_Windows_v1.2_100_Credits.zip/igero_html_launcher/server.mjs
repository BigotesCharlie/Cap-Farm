import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const HOST = '127.0.0.1';
const PORT = Number(process.env.IGERO_PANEL_PORT || 8766);
const CONFIG_FILE = path.join(HERE, 'config.local.json');
const DEFAULT = {
  javaRoot: 'D:\\Users\\CARLOS.GARCIA19\\Master\\ffq-test-master',
  playwrightRoot: 'D:\\Users\\CARLOS.GARCIA19\\PW-TS-MM\\FFQ-Playwright-TS-master',
  maxAiCredits: 30,
  autoTypecheck: true,
};
function normalizeCredits(value) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(30, Math.min(100, Math.trunc(number))) : 30;
}
let config = fs.existsSync(CONFIG_FILE) ? { ...DEFAULT, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) } : { ...DEFAULT };
// Existing Windows installs may still have config.local.json with the old invalid value 5.
config.maxAiCredits = normalizeCredits(config.maxAiCredits);
let currentJob = null;
let runningProcess = null;
let dispatchPending = false;
let methodCache = [];
let lastMethodScan = 0;
const clients = new Set();
const MAX_LOGS = 1500;
const STATUSES = ['pending','running','pass','blocked','skipped'];
const STEP_NAMES = ['Localizar método Java','Copilot: generar JSON + prompt.md','Validar contrato generado','Copilot: crear spec.ts completo','Validar TypeScript','Registrar resultados'];
function sendEvent(event, data) {
  for (const res of clients) { try { res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); } catch { clients.delete(res); } }
}
function jobPublic() {
  if (!currentJob) return null;
  const {id, methodId, status, startedAt, endedAt, steps, logs, artifacts, error} = currentJob;
  return {id, methodId, status, startedAt, endedAt, steps, logs: logs.slice(-200), artifacts, error};
}
function log(message, kind='log') {
  if (!currentJob) return;
  const line = { t: new Date().toLocaleTimeString(), text: String(message).slice(0, 1200), kind };
  currentJob.logs.push(line);
  if (currentJob.logs.length > MAX_LOGS) currentJob.logs.shift();
  sendEvent('log', line);
}
function step(index, status, note='') {
  if (!currentJob) return;
  currentJob.steps[index] = {name: STEP_NAMES[index], status, note};
  sendEvent('status', jobPublic());
}
function json(res, status, value) {
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.end(JSON.stringify(value));
}
function safeText(s){ return String(s||'').replace(/\x1b\[[0-9;]*m/g,'').replace(/\r/g,''); }
function validRoot(p) {try { return fs.statSync(p).isDirectory(); } catch { return false; }}
function rootChecks() {
  const j=validRoot(config.javaRoot), p=validRoot(config.playwrightRoot);
  return { javaExists:j, targetExists:p, javaRoot:config.javaRoot, playwrightRoot:config.playwrightRoot, ready:j&&p};
}
async function walk(root, limit=4000) {
  const result=[]; const stack=[root];
  while(stack.length && result.length < limit){
    const dir=stack.pop();
    let entries=[]; try{entries=await fsp.readdir(dir,{withFileTypes:true});}catch{continue;}
    for(const e of entries){
      if(e.name.startsWith('.') || ['build','target','node_modules','out','gradle'].includes(e.name))continue;
      const file=path.join(dir,e.name);
      if(e.isDirectory())stack.push(file);else if(e.isFile() && e.name.endsWith('.java'))result.push(file);
    }
  }
  return result;
}
async function collectMethods(){
  const javaDir = path.join(config.javaRoot, 'src','test','java');
  if(!validRoot(javaDir))return [];
  const files=await walk(javaDir);
  const found=[];
  for(const file of files){
    let txt;try{txt=await fsp.readFile(file,'utf8')}catch{continue;}
    if(!(/acehome|home/i.test(file)))continue;
    const className = (txt.match(/\bclass\s+(\w+)/)||[])[1] || path.basename(file,'.java');
    // Associate each @Test annotation with the next method declaration, not every helper.
    const re=/@Test\b/g; let match;
    while((match=re.exec(txt))!==null){
      const before=txt.slice(Math.max(0, match.index-25),match.index);
      if(/\/\/[^\n]*$/.test(before))continue;
      const rest=txt.slice(match.index,match.index+1300);
      const method=rest.match(/(?:public|protected)\s+(?:(?:static|final|synchronized)\s+)*[\w<>\[\], ?]+?\s+(\w+)\s*\([^)]*\)\s*(?:throws\s+[\w, ]+)?\s*\{/);
      if(!method)continue;
      const name=method[1]; if(['if','for','while'].includes(name))continue;
      const id=`${className}#${name}`;
      if(found.some(x=>x.id===id))continue;
      found.push({ id, className, name, relativePath:path.relative(config.javaRoot,file).replace(/\\/g,'/'), file });
    }
  }
  return found.sort((a,b)=>a.id.localeCompare(b.id));
}
async function findMethod(id) {
  if(!/^[A-Za-z_$][\w$]*#[A-Za-z_$][\w$]*$/.test(id))throw new Error('Usa ClaseJava#nombreDelMetodo');
  if(Date.now()-lastMethodScan>120000 || !methodCache.length){ methodCache=await collectMethods();lastMethodScan=Date.now(); }
  let selected=methodCache.find(x=>x.id===id);
  if(!selected){methodCache=await collectMethods();lastMethodScan=Date.now();selected=methodCache.find(x=>x.id===id);}
  if(!selected)throw new Error(`No encontré un método @Test ${id} dentro del origen Java.`);
  return selected;
}
function artifactPaths(selected){
  const dir=path.join(config.playwrightRoot,'migration','pervez-json',`${selected.className}__${selected.name}`);
  return {dir,json:path.join(dir,'contract.json'),prompt:path.join(dir,'prompt.md'),runLog:path.join(dir,'copilot-run.log')};
}
function promptForExtraction(sel,a){
return `TASK: Export the COMPLETE REAL Java Selenium/TestNG test source contract into exactly TWO files.\nJava repository (READ-ONLY): ${config.javaRoot}\nJava class: ${sel.className}\nExact @Test method: ${sel.name}\nJava source file: ${sel.file}\nOutput JSON: ${a.json}\nOutput method prompt: ${a.prompt}\n\nRead the actual Java test and follow the required helper, inherited method, Page Object, DataProvider and assertion call graphs. Preserve conditional branches, input provenance, class/method names, navigation and functional acceptance boundaries. Record unresolved dependencies explicitly instead of guessing. The JSON MUST be valid JSON and have top-level keys className, methodName, sourcePath, dataProvider, steps, assertions, unresolved; the arrays steps, assertions and unresolved must be arrays. For each reference record actual Java source location. The prompt.md should be short and instruct the subsequent agent to mirror the whole Java behavior using this contract and the original source.\nDO NOT modify ANY file under ${config.javaRoot}; do not modify original Excel. Do NOT create TypeScript during this step. Do not execute Java, Playwright, QA websites, email, bank, payment, or binding actions. Write only into ${a.dir} for this operation, with two named deliverables. End by listing those two paths, true source coverage and unresolved items. Do not claim functional PASS.\n`;
}
function promptForMigration(sel,a){
return `TASK: Implement ONE COMPLETE Selenium Java TestNG method in the EXISTING Playwright TypeScript project.\nJava source (READ-ONLY): ${config.javaRoot}\nSource method: ${sel.className}#${sel.name}\nSource file: ${sel.file}\nSource-derived JSON: ${a.json}\nSource-derived prompt: ${a.prompt}\nTarget project root: ${config.playwrightRoot}\n\nRead BOTH generated files completely, inspect original Java source when necessary. Use the method-specific prompt and JSON to faithfully mirror the complete Selenium behavior: fixture, DataProvider, source-eligible state, source Excel workbook/worksheet and filters, conditional branches, Page Objects, helpers, all required assertions, and final acceptance boundary. Use existing HOME structure under tests/acehome and reuse existing working Playwright fixtures, providers and pages. Original Java and Excel MUST remain read-only. No Faker or hardcoded applicant identities. Do not force TX; TX fallback is only allowed when source permits it. Do not change global configuration, J03, or iGero infrastructure unless a confirmed defect prevents this test.\nCreate or complete the actual dedicated .spec.ts (not just helpers). Carry out source-contract comparison and scoped offline validation. Do not execute external QA Chrome test, email, purchase, payment, banking or policy binding in this step. Do not modify unrelated suites, commit, push, or start the queue. Report the final spec path, source assertion mapping, real implementation status and unresolved issues. Never claim FUNCTIONAL_PASS without real runtime execution.\n`;
}
async function writePromptFile(a, name, prompt) {
  await fsp.mkdir(a.dir,{recursive:true}); const p=path.join(a.dir,name);await fsp.writeFile(p,prompt,'utf8');return p;
}
function spawnAndLog(command,args,opts) {
  return new Promise((resolve,reject)=>{
    const child=spawn(command,args,{...opts, windowsHide:true,env:{...process.env,NO_COLOR:'1'}});
    runningProcess=child;
    let buffer='';
    const collect=(data)=>{buffer+=safeText(data.toString()); let lines=buffer.split('\n');buffer=lines.pop();for(const line of lines){if(line.trim())log(line);}};
    child.stdout?.on('data',collect);child.stderr?.on('data',collect);
    child.once('error',e=>{runningProcess=null;reject(e)});
    child.once('close',code=>{if(buffer.trim())log(buffer);runningProcess=null;resolve(code);});
  });
}
async function invokeCopilot(promptFile, outputFile){
  // Script uses -C and --add-dir to keep access limited to the two user-selected workspaces.
  const script=path.join(HERE,'invoke-copilot.ps1');
  const args=['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',script,'-PromptFile',promptFile,'-TargetRoot',config.playwrightRoot,'-SourceRoot',config.javaRoot,'-Credits',String(config.maxAiCredits)];
  const cmd=process.platform==='win32'?'powershell.exe':'pwsh';
  return spawnAndLog(cmd,args,{cwd:config.playwrightRoot});
}
async function runTypecheck() {
  const cmd=process.platform==='win32'?'cmd.exe':'npm';
  const args=process.platform==='win32'?['/d','/s','/c','npx --no-install tsc --noEmit']:['exec','--','tsc','--noEmit'];
  return spawnAndLog(cmd,args,{cwd:config.playwrightRoot});
}
async function fingerprintTree(dir){
  const files=[]; const stack=[dir];
  while(stack.length && files.length<10000){
    const d=stack.pop(); let ents=[];
    try{ents=await fsp.readdir(d,{withFileTypes:true});}catch{continue;}
    for(const e of ents){
      if(['.git','.gradle','.idea','build','target','node_modules','out'].includes(e.name))continue;
      const fp=path.join(d,e.name);
      if(e.isDirectory())stack.push(fp);
      else if(e.isFile() && /\.(java|xlsx|xls)$/i.test(e.name))files.push(fp);
    }
  }
  const dig=crypto.createHash('sha256');
  for(const f of files.sort()){
    const content=await fsp.readFile(f).catch(()=>null);
    if(content){dig.update(f);dig.update(content);}
  }
  return dig.digest('hex');
}
async function listSpecVersions(target){
  const base=path.join(target,'tests'),out={};
  if(!validRoot(base))return out;
  const stack=[base];
  while(stack.length){
    const d=stack.pop();let ent=[];try{ent=await fsp.readdir(d,{withFileTypes:true});}catch{continue;}
    for(const e of ent){
      const f=path.join(d,e.name);
      if(e.isDirectory())stack.push(f);
      else if(e.isFile() && e.name.endsWith('.spec.ts')){
        const st=await fsp.stat(f);out[f]=`${st.size}:${st.mtimeMs}`;
      }
    }
  }
  return out;
}
async function executeJob(sel, mode){
  const a=artifactPaths(sel);
  const stageOne=(mode==='all'||mode==='extract');
  const stageTwo=(mode==='all'||mode==='migrate');
  const sourceFingerprint=await fingerprintTree(config.javaRoot);
  currentJob={id:crypto.randomUUID(),methodId:sel.id,status:'running',startedAt:new Date().toISOString(),endedAt:null,steps:STEP_NAMES.map(name=>({name,status:'pending',note:''})),logs:[],artifacts:{json:a.json,prompt:a.prompt, outputDir:a.dir},error:null};
  sendEvent('status',jobPublic());
  try{
    step(0,'running','Confirmando método @Test real');
    if(!fs.existsSync(sel.file))throw new Error('No existe el archivo Java del método.');
    step(0,'pass',sel.relativePath);
    if(stageOne){
      step(1,'running','Copilot generando contrato y prompt');
      const p=await writePromptFile(a,'01-extract-instructions.txt',promptForExtraction(sel,a));
      const ret=await invokeCopilot(p,a.dir); if(ret!==0)throw new Error(`Copilot export terminó con código ${ret}.`);
      const afterExtract=await fingerprintTree(config.javaRoot);
      if(sourceFingerprint!==afterExtract)throw new Error('ALERTA: el origen Java/Excel cambió durante la extracción. Etapa 2 cancelada.');
      step(1,'pass','Copilot devolvió código 0; Java/Excel permanecen intactos');
    }else step(1,'skipped','Se reutilizan los archivos existentes');
    step(2,'running','Validando JSON real generado');
    let contract;
    try{contract=JSON.parse(await fsp.readFile(a.json,'utf8'))}catch{throw new Error('No se encontró un contract.json válido. Se detuvo antes de migrar.');}
    if(contract.className!==sel.className || contract.methodName!==sel.name || !Array.isArray(contract.assertions) || !Array.isArray(contract.steps))throw new Error('El contrato no coincide con clase/método o no incluye steps/assertions válidos.');
    const promptContent=await fsp.readFile(a.prompt,'utf8').catch(()=>''), promptValid=promptContent.length>=40;
    if(!promptValid)throw new Error('No se encontró prompt.md suficiente.');
    step(2,'pass',`${contract.assertions.length} registros de assertions en JSON`);
    if(stageTwo){
      step(3,'running','Copilot implementando el spec TypeScript');
      const beforeSpecs=await listSpecVersions(config.playwrightRoot);
      const p=await writePromptFile(a,'02-migrate-instructions.txt',promptForMigration(sel,a));
      const ret=await invokeCopilot(p,a.dir); if(ret!==0)throw new Error(`Copilot migración terminó con código ${ret}.`);
      const afterMigration=await fingerprintTree(config.javaRoot);
      if(sourceFingerprint!==afterMigration)throw new Error('ALERTA: el origen Java/Excel cambió durante la implementación.');
      const afterSpecs=await listSpecVersions(config.playwrightRoot);
      const touched=Object.entries(afterSpecs).filter(([file,version])=>beforeSpecs[file]!==version).map(([file])=>file);
      if(!touched.length)throw new Error('Copilot terminó sin crear o modificar ningún .spec.ts. No se considera migración completada.');
      currentJob.artifacts.specs=touched;
      step(3,'pass',`${touched.length} spec(s) creadas/modificadas; cobertura funcional aún no verificada`);
      if(config.autoTypecheck){step(4,'running','npx tsc --noEmit');const c=await runTypecheck();if(c===0)step(4,'pass','Typecheck correcto; NO es Functional PASS');else {step(4,'blocked',`Typecheck terminó con código ${c}`);log('Typecheck falló. Revisar implementación, no se marca Functional PASS.','warning');}}
      else step(4,'skipped','Typecheck desactivado en configuración');
    }else{step(3,'skipped','Sólo exportación');step(4,'skipped','Sólo exportación');}
    const after=await fingerprintTree(config.javaRoot);
    if(sourceFingerprint!==after)throw new Error('ALERTA: cambió un archivo Java dentro del proyecto origen. Revisar cambios inmediatamente.');
    step(5,'pass','Java sin cambios; resultados guardados en destino');
    currentJob.status='completed';
    log('Flujo completado. El estado Functional PASS sigue NO VERIFICADO hasta ejecutar el TC real.','success');
  }catch(err){
    currentJob.status=currentJob.status==='cancelled'?'cancelled':'blocked';currentJob.error=err.message;
    log(`BLOQUEO: ${err.message}`,'error');
    const ix=currentJob.steps.findIndex(x=>x.status==='running');if(ix>=0)step(ix,'blocked',err.message);
  }finally{currentJob.endedAt=new Date().toISOString();sendEvent('status',jobPublic());}
}
function parseBody(req){return new Promise((resolve,reject)=>{let body='';req.on('data',d=>{body+=d; if(body.length>100000){reject(new Error('Solicitud demasiado grande'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(body||'{}'))}catch{reject(new Error('JSON inválido'))}});req.on('error',reject);});}
function originAllowed(req){if(!req.headers.origin)return true;try{const u=new URL(req.headers.origin);return u.hostname==='127.0.0.1'&&Number(u.port)===PORT;}catch{return false;}}
const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,`http://${HOST}:${PORT}`);
    if(req.method==='GET' && url.pathname==='/'){const html=await fsp.readFile(path.join(HERE,'index.html'));res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'"});res.end(html);return;}
    if(req.method==='GET' && url.pathname==='/app.js'){const data=await fsp.readFile(path.join(HERE,'app.js'));res.writeHead(200,{'Content-Type':'application/javascript; charset=utf-8','Cache-Control':'no-store'});res.end(data);return;}
    if(req.method==='GET'&&url.pathname==='/api/events'){
      res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});
      res.write('retry: 2000\n\n');clients.add(res);res.write(`event: status\ndata: ${JSON.stringify(jobPublic())}\n\n`);req.on('close',()=>clients.delete(res));return;
    }
    if(req.method==='GET' && url.pathname==='/api/config'){json(res,200,{...config,...rootChecks()});return;}
    if(req.method==='GET'&&url.pathname==='/api/methods'){
      if(!rootChecks().javaExists){json(res,400,{error:'Carpeta Java no disponible'});return;}
      if(Date.now()-lastMethodScan>120000||!methodCache.length){methodCache=await collectMethods();lastMethodScan=Date.now();}
      const term=(url.searchParams.get('q')||'').toLowerCase();
      json(res,200,{total:methodCache.length,methods:methodCache.filter(m=>m.id.toLowerCase().includes(term)).slice(0,400).map(({id,relativePath})=>({id,relativePath}))});return;
    }
    if(req.method==='GET'&&url.pathname==='/api/method-preview'){
      const sel=await findMethod(url.searchParams.get('id')||''); const raw=await fsp.readFile(sel.file,'utf8');
      const start=Math.max(0,raw.search(new RegExp('\\b'+sel.name+'\\s*\\('))-400);
      json(res,200,{id:sel.id,relativePath:sel.relativePath,javaPreview:raw.slice(start,start+14000)});return;
    }
    if(req.method==='GET'&&url.pathname==='/api/outputs'){
      const sel=await findMethod(url.searchParams.get('id')||'');const a=artifactPaths(sel);
      const exists={json:fs.existsSync(a.json),prompt:fs.existsSync(a.prompt)};
      let contract='';let prompt='';if(exists.json)contract=(await fsp.readFile(a.json,'utf8')).slice(0,22000);if(exists.prompt)prompt=(await fsp.readFile(a.prompt,'utf8')).slice(0,22000);
      const specMap=await listSpecVersions(config.playwrightRoot);
      let specPath='';
      for(const f of Object.keys(specMap)){
        if(path.basename(f).toLowerCase().includes(sel.className.toLowerCase())){specPath=f;break;}
      }
      if(!specPath){
        for(const f of Object.keys(specMap)){
          const source=await fsp.readFile(f,'utf8').catch(()=>'');
          if(source.includes(sel.name) && (source.includes(sel.className)||path.basename(f).toLowerCase().includes('home'))){specPath=f;break;}
        }
      }
      const specPreview=specPath?(await fsp.readFile(specPath,'utf8')).slice(0,35000):'';
      json(res,200,{...exists,contract,prompt,outputDir:a.dir,specPath,specPreview,specExists:!!specPath});return;
    }
    if(req.method==='GET' && url.pathname==='/api/job'){json(res,200,jobPublic());return;}
    if(req.method==='POST'){
      if(!originAllowed(req)){json(res,403,{error:'Origen no permitido'});return;}
      const body=await parseBody(req);
      if(url.pathname==='/api/config'){
        if(currentJob?.status==='running')throw new Error('No se puede cambiar la ruta durante una migración.');
        const javaRoot=String(body.javaRoot||'').trim(),playwrightRoot=String(body.playwrightRoot||'').trim();
        if(!validRoot(javaRoot)||!validRoot(playwrightRoot))throw new Error('Una de las rutas no existe. Verifica ambos proyectos.');
        if(path.resolve(javaRoot)===path.resolve(playwrightRoot))throw new Error('Origen y destino no pueden ser la misma carpeta.');
        config={javaRoot,playwrightRoot,maxAiCredits:normalizeCredits(body.maxAiCredits),autoTypecheck:body.autoTypecheck!==false};
        await fsp.writeFile(CONFIG_FILE,JSON.stringify(config,null,2));methodCache=[];lastMethodScan=0;
        json(res,200,{ok:true,...config,...rootChecks()});return;
      }
      if(url.pathname==='/api/start'){
        if(dispatchPending||currentJob?.status==='running'){json(res,409,{error:'Ya hay una migración en ejecución.'});return;}
        if(!rootChecks().ready)throw new Error('Verifica que ambas carpetas existen.');
        const mode=body.mode; if(!['extract','migrate','all'].includes(mode))throw new Error('Modo inválido.');
        const sel=await findMethod(String(body.methodId||''));
        dispatchPending=true;executeJob(sel,mode).finally(()=>{dispatchPending=false;});json(res,202,{started:true,id:sel.id,mode});return;
      }
      if(url.pathname==='/api/cancel'){
        if(!currentJob || currentJob.status!=='running')throw new Error('No hay una migración activa.');
        currentJob.status='cancelled';log('Cancelación solicitada; deteniendo únicamente el proceso iniciado por este panel.','warning');
        if(runningProcess){if(process.platform==='win32')spawn('taskkill',['/PID',String(runningProcess.pid),'/T','/F'],{windowsHide:true});else runningProcess.kill('SIGTERM');}
        json(res,200,{cancelled:true});return;
      }
    }
    json(res,404,{error:'Ruta no encontrada'});
  }catch(err){json(res,400,{error:err.message});}
});
server.listen(PORT,HOST,()=>console.log(`iGero Simple Migration UI: http://${HOST}:${PORT}/`));
