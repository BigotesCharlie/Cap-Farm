iGERO SIMPLE MIGRATION — PANEL HTML LOCAL (PILOTO)
=================================================

Inspirado en el HTML 'Conversor Java Selenium a Playwright' proporcionado por el usuario.
No reemplaza tu proyecto ni modifica el Java deliberadamente.

1. Copia esta carpeta a Windows (puede estar junto al proyecto Playwright).
2. Comprueba node --version y copilot --version desde la terminal de Windows.
3. Haz doble clic en Start-iGero-HTML.cmd.
4. Abre http://127.0.0.1:8766/ si no abre automaticamente.
5. Verifica rutas de origen y destino, ajustalas si fuera necesario y guarda.
6. Selecciona un metodo Java TestNG HOME.
7. Selecciona AI Credits entre 30 y 100 por etapa (minimo de Copilot CLI: 30).
8. Pulsa 'Ejecutar ambos pasos' o individualmente '1. JSON + Prompt' y '2. Migrar a TS'.
9. Observa la checklist LIVE y la salida de Copilot.

RUTAS PRECARGADAS
Origen Java: D:\Users\CARLOS.GARCIA19\Master\ffq-test-master
Destino:     D:\Users\CARLOS.GARCIA19\PW-TS-MM\FFQ-Playwright-TS-master

ARCHIVOS PRODUCIDOS (DENTRO DEL DESTINO)
migration/pervez-json/<Clase>__<Metodo>/contract.json
migration/pervez-json/<Clase>__<Metodo>/prompt.md
migration/pervez-json/<Clase>__<Metodo>/01-extract-instructions.txt
migration/pervez-json/<Clase>__<Metodo>/02-migrate-instructions.txt
La spec TypeScript se genera en tests/acehome segun instrucciones y convención real.

REGLAS IMPORTANTES
- GitHub Copilot CLI es un prerequisito. El HTML no puede ejecutar comandos locales por si solo.
- Java y Excel deben permanecer sin cambios. Se solicita read-only y se detectan cambios tras cada ejecucion;
  esta comprobacion NO es un bloqueo de permisos de Windows. Usa respaldo Git o filesystem read-only si lo necesitas.
- No se ejecuta Chrome ni operaciones de pago, correo, bank o bind automaticamente.
- El panel muestra compilacion offline si la opcion esta habilitada. NO certifica Functional PASS.
- El credit cap de Copilot es suave y no sustituye limites de organizacion/plan.
- Se inicia en 127.0.0.1 (no publicarlo en red).
- La interfaz y el backend no se han ejecutado en tu computadora corporativa;
  este paquete solo fue probado localmente con pruebas de endpoints sin Copilot real.
- Conservar un backup del workspace; Copilot con permisos puede modificar archivos en la carpeta destino.

Dependencias: Node.js y GitHub Copilot CLI (no usa npm install ni frameworks extra).

CORRECCION VERSION 1.1 (2026-11-23)
- Solucionado: Invalid value for --max-ai-credits: "5". GitHub Copilot CLI exige >= 30.
- Default 30, interfaz min 30, guardas en backend y script PS1; valor anterior 5 se normaliza.
- 30 es un limite suave por etapa, NO un consumo obligatorio y no garantiza cero sobrecostes.
- Si reemplazas los archivos mientras corre el servidor, cierralo y vuelve a lanzar Start-iGero-HTML.cmd.
- Este paquete NO ha ejecutado Copilot en tu equipo Windows; solo valida configuracion y sintaxis.

ACTUALIZACION VERSION 1.2 (2026-11-23)
- Campo de creditos AI en HTML permite cualquier entero entre 30 y 100 inclusive.
- Backend normaliza creditos antiguos por debajo de 30 o mayores de 100.
- PowerShell tambien limita creditos a 30..100 antes de invocar Copilot CLI.
- Una ejecucion de ambos pasos puede usar hasta ese limite por etapa, no como un total compartido.
- Si tienes config.local.json, conservalo; al iniciar se normaliza automaticamente.
- Cierra servidor anterior, sustituye archivos y vuelve a ejecutar Start-iGero-HTML.cmd.
