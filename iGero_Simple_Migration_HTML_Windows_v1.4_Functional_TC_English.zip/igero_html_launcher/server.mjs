import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const HOST = '127.0.0.1';
const PORT = Number(process.env.IGERO_PANEL_PORT || 8766);
const CONFIG_FILE = path.join(HERE, 'config.local.json');
const DEFAULT = {
  javaRoot: 'D:\\Users\\CARLOS.GARCIA19\\Master\\ffq-test-master',
  playwrightRoot: 'D:\\Users\\CARLOS.GARCIA19\\PW-TS-MM\\FFQ-Playwright-TS-master',
  autoTypecheck: true,
  autoFunctionalCheck: true,
};
// In automatic mode no artificial --max-ai-credits flag is supplied.
// Existing config.local.json files may still contain maxAiCredits from v1.2.
// Ignore that legacy value, but preserve their source/destination paths.
let config = fs.existsSync(CONFIG_FILE) ? { ...DEFAULT, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) } : { ...DEFAULT };
delete config.maxAiCredits;
let currentJob = null;
let runningProcess = null;
let activeCopilotStage = null;
let copilotStopReason = null;
const CREDIT_LIMIT_RE = /\b(?:session limit reached|ai credit(?:s)? (?:session )?limit reached|credit limit reached|future model calls (?:will )?stop|maximum ai credits reached|credit budget exceeded)\b/i;
const CONTINUE_LIMIT_RE = /\b(?:autopilot (?:continuation|continue) limit reached|max(?:imum)? autopilot continues reached)\b/i;
let dispatchPending = false;
let methodCache = [];
let lastMethodScan = 0;
const clients = new Set();
const MAX_LOGS = 1500;
const STATUSES = ['pending','running','pass','blocked','skipped'];
const STEP_NAMES = ['Locate Java method', 'Copilot: generate JSON + prompt.md', 'Validate generated contract', 'Copilot: implement complete spec.ts', 'Validate TypeScript', 'Functional TC Check — Playwright', 'Save results'];
function sendEvent(event, data) {
  for (const res of clients) { try { res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); } catch { clients.delete(res); } }
}
function jobPublic() {
  if (!currentJob) return null;
  const {id, methodId, status, startedAt, endedAt, steps, logs, artifacts, error, aiCreditsObserved, functional} = currentJob;
  return {id, methodId, status, startedAt, endedAt, steps, logs: logs.slice(-200), artifacts, error, aiCreditMode:'automatic', aiCreditsObserved, functional};
}
function log(message, kind='log') {
  if (!currentJob) return;
  // CLI usage information is informational, not an authoritative billing total.
  // It may be absent depending on CLI version and log format.
  if (activeCopilotStage && currentJob) {
    const raw = String(message);
    const usage = raw.match(/\bAI Credits?\s+([0-9]+(?:\.[0-9]+)?)(?=\s|$|\()/i)
      || raw.match(/\b([0-9]+(?:\.[0-9]+)?)\s*\/\s*[0-9]+(?:\.[0-9]+)?\s+AI Credits? used\b/i);
    if (usage) {
      const number = Number(usage[1]);
      if (Number.isFinite(number) && number >= 0)
        currentJob.aiCreditsObserved[activeCopilotStage] = Math.max(currentJob.aiCreditsObserved[activeCopilotStage] || 0, number);
    }
    if (CREDIT_LIMIT_RE.test(raw)) copilotStopReason = 'Copilot reached a CLI or organization AI-credit limit';
    if (CONTINUE_LIMIT_RE.test(raw)) copilotStopReason = 'Copilot reached the automatic-continuation limit';
  }
  const line = { t: new Date().toLocaleTimeString(), text: String(message).slice(0, 1200), kind };
  currentJob.logs.push(line);
  if (currentJob.logs.length > MAX_LOGS) currentJob.logs.shift();
  sendEvent('log', line);
}
function step(index, status, note='') {
  if (!currentJob) return;
  currentJob.steps[index] = {name: STEP_NAMES[index], status, note};
  sendEvent('status', jobPublic());
}
function json(res, status, value) {
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.end(JSON.stringify(value));
}
function safeText(s){ return String(s||'').replace(/\x1b\[[0-9;]*m/g,'').replace(/\r/g,''); }
function validRoot(p) {try { return fs.statSync(p).isDirectory(); } catch { return false; }}
function rootChecks() {
  const j=validRoot(config.javaRoot), p=validRoot(config.playwrightRoot);
  return { javaExists:j, targetExists:p, javaRoot:config.javaRoot, playwrightRoot:config.playwrightRoot, ready:j&&p};
}
async function walk(root, limit=4000) {
  const result=[]; const stack=[root];
  while(stack.length && result.length < limit){
    const dir=stack.pop();
    let entries=[]; try{entries=await fsp.readdir(dir,{withFileTypes:true});}catch{continue;}
    for(const e of entries){
      if(e.name.startsWith('.') || ['build','target','node_modules','out','gradle'].includes(e.name))continue;
      const file=path.join(dir,e.name);
      if(e.isDirectory())stack.push(file);else if(e.isFile() && e.name.endsWith('.java'))result.push(file);
    }
  }
  return result;
}
async function collectMethods(){
  const javaDir = path.join(config.javaRoot, 'src','test','java');
  if(!validRoot(javaDir))return [];
  const files=await walk(javaDir);
  const found=[];
  for(const file of files){
    let txt;try{txt=await fsp.readFile(file,'utf8')}catch{continue;}
    if(!(/acehome|home/i.test(file)))continue;
    const className = (txt.match(/\bclass\s+(\w+)/)||[])[1] || path.basename(file,'.java');
    // Associate each @Test annotation with the next method declaration, not every helper.
    const re=/@Test\b/g; let match;
    while((match=re.exec(txt))!==null){
      const before=txt.slice(Math.max(0, match.index-25),match.index);
      if(/\/\/[^\n]*$/.test(before))continue;
      const rest=txt.slice(match.index,match.index+1300);
      const method=rest.match(/(?:public|protected)\s+(?:(?:static|final|synchronized)\s+)*[\w<>\[\], ?]+?\s+(\w+)\s*\([^)]*\)\s*(?:throws\s+[\w, ]+)?\s*\{/);
      if(!method)continue;
      const name=method[1]; if(['if','for','while'].includes(name))continue;
      const id=`${className}#${name}`;
      if(found.some(x=>x.id===id))continue;
      found.push({ id, className, name, relativePath:path.relative(config.javaRoot,file).replace(/\\/g,'/'), file });
    }
  }
  return found.sort((a,b)=>a.id.localeCompare(b.id));
}
async function findMethod(id) {
  if(!/^[A-Za-z_$][\w$]*#[A-Za-z_$][\w$]*$/.test(id))throw new Error('Use JavaClass#methodName');
  if(Date.now()-lastMethodScan>120000 || !methodCache.length){ methodCache=await collectMethods();lastMethodScan=Date.now(); }
  let selected=methodCache.find(x=>x.id===id);
  if(!selected){methodCache=await collectMethods();lastMethodScan=Date.now();selected=methodCache.find(x=>x.id===id);}
  if(!selected)throw new Error(`Java @Test method ${id} was not found in the selected source project.`);
  return selected;
}
function artifactPaths(selected){
  const dir=path.join(config.playwrightRoot,'migration','pervez-json',`${selected.className}__${selected.name}`);
  return {dir,json:path.join(dir,'contract.json'),prompt:path.join(dir,'prompt.md'),runLog:path.join(dir,'copilot-run.log'),specManifest:path.join(dir,'spec-manifest.json'),functionalReport:path.join(dir,'functional-report.json'),functionalSummary:path.join(dir,'functional-summary.json')};
}
function promptForExtraction(sel,a){
return `TASK: Export the COMPLETE REAL Java Selenium/TestNG test source contract into exactly TWO files.\nJava repository (READ-ONLY): ${config.javaRoot}\nJava class: ${sel.className}\nExact @Test method: ${sel.name}\nJava source file: ${sel.file}\nOutput JSON: ${a.json}\nOutput method prompt: ${a.prompt}\n\nRead the actual Java test and follow the required helper, inherited method, Page Object, DataProvider and assertion call graphs. Preserve conditional branches, input provenance, class/method names, navigation and functional acceptance boundaries. Record unresolved dependencies explicitly instead of guessing. The JSON MUST be valid JSON and have top-level keys className, methodName, sourcePath, dataProvider, steps, assertions, unresolved; the arrays steps, assertions and unresolved must be arrays. For each reference record actual Java source location. The prompt.md should be short and instruct the subsequent agent to mirror the whole Java behavior using this contract and the original source.\nDO NOT modify ANY file under ${config.javaRoot}; do not modify original Excel. Do NOT create TypeScript during this step. Do not execute Java, Playwright, QA websites, email, bank, payment, or binding actions. Write only into ${a.dir} for this operation, with two named deliverables. End by listing those two paths, true source coverage and unresolved items. Do not claim functional PASS.\n`;
}
function promptForMigration(sel,a){
return `TASK: Implement ONE COMPLETE Selenium Java TestNG method in the EXISTING Playwright TypeScript project.\nJava source (READ-ONLY): ${config.javaRoot}\nSource method: ${sel.className}#${sel.name}\nSource file: ${sel.file}\nSource-derived JSON: ${a.json}\nSource-derived prompt: ${a.prompt}\nTarget project root: ${config.playwrightRoot}\n\nRead BOTH generated files completely, inspect original Java source when necessary. Use the method-specific prompt and JSON to faithfully mirror the complete Selenium behavior: fixture, DataProvider, source-eligible state, source Excel workbook/worksheet and filters, conditional branches, Page Objects, helpers, all required assertions, and final acceptance boundary. Use existing HOME structure under tests/acehome and reuse existing working Playwright fixtures, providers and pages. Original Java and Excel MUST remain read-only. No Faker or hardcoded applicant identities. Do not force TX; TX fallback is only allowed when source permits it. Do not change global configuration, J03, or iGero infrastructure unless a confirmed defect prevents this test.\nCreate or complete the actual dedicated .spec.ts (not just helpers). Carry out source-contract comparison and scoped offline validation. Do not execute external QA Chrome test, email, purchase, payment, banking or policy binding in this step. Do not modify unrelated suites, commit, push, or start the queue. Include the exact original Java method name in the Playwright test title so the runner can select only this Test Case. Keep user-facing test titles and diagnostics in English. Report the final spec path, source assertion mapping, real implementation status and unresolved issues. Never claim FUNCTIONAL_PASS without real runtime execution.\n`;
}
async function writePromptFile(a, name, prompt) {
  await fsp.mkdir(a.dir,{recursive:true}); const p=path.join(a.dir,name);await fsp.writeFile(p,prompt,'utf8');return p;
}
function spawnAndLog(command,args,opts, capture=null) {
  return new Promise((resolve,reject)=>{
    const child=spawn(command,args,{...opts, windowsHide:true,env:{...process.env,...(opts.env||{}),NO_COLOR:'1'}});
    runningProcess=child;
    let buffer='';
    const collect=(data)=>{buffer+=safeText(data.toString()); let lines=buffer.split('\n');buffer=lines.pop();for(const line of lines){if(line.trim()){if(capture)capture.push(line);log(line);}}};
    child.stdout?.on('data',collect);child.stderr?.on('data',collect);
    child.once('error',e=>{runningProcess=null;reject(e)});
    child.once('close',code=>{if(buffer.trim()){if(capture)capture.push(buffer);log(buffer);}runningProcess=null;resolve(code);});
  });
}
async function invokeCopilot(promptFile, stage){
  // The selected roots are passed to the wrapper; no manual credit cap is supplied.
  const script=path.join(HERE,'invoke-copilot.ps1');
  const args=['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',script,'-PromptFile',promptFile,'-TargetRoot',config.playwrightRoot,'-SourceRoot',config.javaRoot];
  const cmd=process.platform==='win32'?'powershell.exe':'pwsh';
  activeCopilotStage = stage;
  copilotStopReason = null;
  try {
    const code = await spawnAndLog(cmd,args,{cwd:config.playwrightRoot});
    return {code, stopReason:copilotStopReason};
  } finally {
    activeCopilotStage = null;
    copilotStopReason = null;
  }
}
async function runTypecheck() {
  const cmd=process.platform==='win32'?'cmd.exe':'npm';
  const args=process.platform==='win32'?['/d','/s','/c','npx --no-install tsc --noEmit']:['exec','--','tsc','--noEmit'];
  return spawnAndLog(cmd,args,{cwd:config.playwrightRoot});
}
async function fingerprintTree(dir){
  const files=[]; const stack=[dir];
  while(stack.length && files.length<10000){
    const d=stack.pop(); let ents=[];
    try{ents=await fsp.readdir(d,{withFileTypes:true});}catch{continue;}
    for(const e of ents){
      if(['.git','.gradle','.idea','build','target','node_modules','out'].includes(e.name))continue;
      const fp=path.join(d,e.name);
      if(e.isDirectory())stack.push(fp);
      else if(e.isFile() && /\.(java|xlsx|xls)$/i.test(e.name))files.push(fp);
    }
  }
  const dig=crypto.createHash('sha256');
  for(const f of files.sort()){
    const content=await fsp.readFile(f).catch(()=>null);
    if(content){dig.update(f);dig.update(content);}
  }
  return dig.digest('hex');
}
async function listSpecVersions(target){
  const base=path.join(target,'tests'),out={};
  if(!validRoot(base))return out;
  const stack=[base];
  while(stack.length){
    const d=stack.pop();let ent=[];try{ent=await fsp.readdir(d,{withFileTypes:true});}catch{continue;}
    for(const e of ent){
      const f=path.join(d,e.name);
      if(e.isDirectory())stack.push(f);
      else if(e.isFile() && e.name.endsWith('.spec.ts')){
        const st=await fsp.stat(f);out[f]=`${st.size}:${st.mtimeMs}`;
      }
    }
  }
  return out;
}
function sanitizeReportText(value) {
  // Only sanitized summaries are exposed through the HTTP API; raw reporter JSON stays local.
  return String(value||'').replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi,'[REDACTED_EMAIL]')
    .replace(/\b\d{9,19}\b/g,'[REDACTED_NUMBER]').replace(/(https?:\/\/[^\s?]+)\?[^\s]+/gi,'$1?[REDACTED]')
    .replace(/\b(?:password|ssn|socialSecurityNumber|cardNumber|routingNumber|accountNumber)\s*[:=]\s*[^\s,;]+/gi,'[REDACTED_FIELD]')
    .slice(0,1400);
}
function isSensitiveScenario(sel, contract) {
  const label = `${sel.className} ${sel.name}`;
  const sourceTerms = `${label} ${JSON.stringify(contract?.steps||[])} ${JSON.stringify(contract?.dataProvider||{})}`;
  const sensitive = /\b(bind(?:ing)?|payment|bank|purchase|checkout|policy\s*(?:issue|bind)|signature|e-?mail|card\s*number)\b|(?:QuoteAndBind|GoToPayment|PolicyPayment|PaymentSection|BankAccount|PolicyBind)/i;
  // Also detect camelCase method names such as testQuoteAndBindHomeLob.
  const camel = /(bind|payment|bank|purchase|checkout|policyissue|policypayment|email|signature|cardinformation)/i;
  return sensitive.test(sourceTerms) || camel.test(label);
}
function withinTarget(file) {
  const root=path.resolve(config.playwrightRoot);const resolved=path.resolve(file);
  return resolved.startsWith(root+path.sep) && resolved.endsWith('.spec.ts') && !resolved.includes(`${path.sep}node_modules${path.sep}`);
}
async function resolveFocusedSpec(sel,a,touched=[]) {
  const manifest=await fsp.readFile(a.specManifest,'utf8').then(JSON.parse).catch(()=>null);
  const candidates=touched.length ? touched : manifest?.methodId===sel.id ? [manifest.specPath] : [];
  const found=[];
  for(const file of candidates) {
    if(!file || !withinTarget(file) || !fs.existsSync(file))continue;
    const content=await fsp.readFile(file,'utf8');
    if(!content.includes(sel.name))continue;
    found.push(file);
  }
  if(found.length!==1)throw new Error(found.length===0
    ? 'No uniquely verified Playwright spec was recorded for this Java method. The generated test must include the original method name.'
    : `Multiple modified specs match this method (${found.length}). Refusing to run unrelated tests.`);
  const specPath=found[0];
  await fsp.mkdir(a.dir,{recursive:true});
  await fsp.writeFile(a.specManifest, JSON.stringify({methodId:sel.id,specPath,confirmedAt:new Date().toISOString()},null,2));
  return specPath;
}
function collectPlaywrightResults(report){
  const tests=[];
  function walkSuite(suite,parents=[]){
    const pathParts=suite.title?[...parents,suite.title]:parents;
    for(const spec of suite.specs||[]){
      for(const t of spec.tests||[]){
        const result=t.results||[];
        const last=result.at(-1)||{};
        const status=t.status || last.status || 'unknown';
        const allSteps=[];
        function walkSteps(items,depth=0){
          for(const st of items||[]){
            if(allSteps.length>=2500)return;
            allSteps.push({title:sanitizeReportText(st.title),category:st.category||'',duration:st.duration||0,
              error:st.error?sanitizeReportText(st.error.message||st.error.value||''):null,depth});
            walkSteps(st.steps,depth+1);
          }
        }
        walkSteps(last.steps||[]);
        tests.push({title:sanitizeReportText([...pathParts,spec.title].filter(Boolean).join(' › ')),
          project:t.projectName||'', status, expectedStatus:t.expectedStatus||'passed',
          duration:result.reduce((n,r)=>n+(r.duration||0),0), retries:Math.max(0,result.length-1),
          errors:(last.errors||[]).map(e=>sanitizeReportText(e.message||e.value||e.stack||'')).slice(0,10),steps:allSteps});
      }
    }
    for(const sub of suite.suites||[])walkSuite(sub,pathParts);
  }
  for(const suite of report.suites||[])walkSuite(suite);
  return tests;
}
function summarizeFunctionalReport(report, exitCode, selectedSpec, jsonFile, methodId, projectName) {
  const tests=collectPlaywrightResults(report);
  const counts={total:tests.length,passed:0,failed:0,skipped:0,timedOut:0,interrupted:0,other:0};
  for(const t of tests){
    if(t.status==='expected' && t.expectedStatus==='passed')counts.passed++;
    else if(t.status==='unexpected'){counts.failed++;if(t.errors.some(e=>/timeout/i.test(e)))counts.timedOut++;}
    else if(t.status==='skipped')counts.skipped++;
    else if(t.status==='interrupted')counts.interrupted++;
    else counts.other++;
  }
  const verdict=(exitCode===0 && counts.total>0 && counts.passed===counts.total && !counts.skipped && !counts.other)
    ? 'FUNCTIONAL_PASS' : 'FUNCTIONAL_FAILED';
  return {methodId,verdict,exitCode,counts,tests,selectedSpec,projectName,
    reportPath:jsonFile,executedAt:new Date().toISOString(),javaRuntimeParity:'NOT_VERIFIED',
    note:'Playwright execution result only; Java runtime parity is separate and not verified.'};
}
async function runFunctionalCheck(sel,a,contract,touched=[],manual=false) {
  await fsp.mkdir(a.dir,{recursive:true});
  await fsp.rm(a.functionalSummary,{force:true}); // Never display a previous run as the current result.
  if(isSensitiveScenario(sel,contract)) {
    const reason='Safety gate: Bind, bank, payment, email, purchase or policy-binding scenarios need separate explicit QA/business execution approval. No browser was launched.';
    currentJob.functional={verdict:'SKIPPED_SAFETY',reason,counts:{total:0,passed:0,failed:0,skipped:0},tests:[],methodId:sel.id};
    await fsp.writeFile(a.functionalSummary,JSON.stringify(currentJob.functional,null,2));
    step(5,'skipped',reason);log(reason,'warning');return;
  }
  if(!config.autoFunctionalCheck && !manual){
    currentJob.functional={verdict:'NOT_EXECUTED',reason:'Automatic functional execution was disabled in settings.',counts:{total:0,passed:0,failed:0,skipped:0},tests:[]};
    await fsp.writeFile(a.functionalSummary,JSON.stringify(currentJob.functional,null,2));
    step(5,'skipped','Automatic Functional TC Check disabled in settings.');return;
  }
  step(5,'running','Selecting the exact migrated test in the Playwright TypeScript project');
  const spec=await resolveFocusedSpec(sel,a,touched);
  const relative=path.relative(config.playwrightRoot,spec).replace(/\\/g,'/');
  const grep=sel.name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  // --list does not launch a browser; it is the isolation preflight for the selected method.
  const listOutput=[];
  const npmCommand=process.platform==='win32'?'cmd.exe':'npx';
  function playwrightArgs(args){
    if(process.platform==='win32'){
      // Input is validated and quoted before it is used by cmd.exe. No user-provided shell fragments.
      const quote=x=>`"${String(x).replace(/["\r\n]/g,'')}"`;
      return ['/d','/s','/c',`npx --no-install playwright test ${args.map(quote).join(' ')}`];
    }
    return ['--no-install','playwright','test',...args];
  }
  const listArgs=[relative,'--grep',grep,'--list'];
  log(`Functional TC discovery: ${relative} (method ${sel.name})`);
  const listed=await spawnAndLog(npmCommand,playwrightArgs(listArgs),{cwd:config.playwrightRoot},listOutput);
  if(listed!==0)throw new Error(`Playwright test discovery failed (${listed}); no functional test was run.`);
  const output=listOutput.join('\n');
  const total=Number((output.match(/Total:\s*(\d+)\s+tests?/i)||[])[1]||0);
  if(total<1)throw new Error('No Playwright test title matched the selected Java method. No functional test was run.');
  const projects=[...new Set([...output.matchAll(/\[([^\]]+)\]\s*›/g)].map(x=>x[1]))];
  let project=null;
  if(projects.length>1){
    const preferred=projects.filter(x=>/chrom(e|ium)/i.test(x));
    if(preferred.length!==1)throw new Error(`Multiple Playwright projects match (${projects.join(', ')}); cannot safely select one browser project.`);
    project=preferred[0];
  }else if(projects.length===1)project=projects[0];
  await fsp.mkdir(a.dir,{recursive:true});
  const reportFile=a.functionalReport;
  await fsp.rm(reportFile,{force:true});
  const runArgs=[relative,'--grep',grep,'--headed','--workers=1','--retries=0','--forbid-only','--reporter=json'];
  if(project)runArgs.push('--project',project);
  log(`Starting focused headed Playwright execution: ${relative}${project?' ['+project+']':''}`);
  const code=await spawnAndLog(npmCommand,playwrightArgs(runArgs),{
    cwd:config.playwrightRoot,
    env:{PLAYWRIGHT_JSON_OUTPUT_FILE:reportFile,CI:''}
  });
  const report=await fsp.readFile(reportFile,'utf8').then(JSON.parse).catch(()=>null);
  if(!report){
    currentJob.functional={verdict:'REPORT_MISSING',reason:'Playwright JSON report was not generated or could not be parsed.',methodId:sel.id,
      counts:{total:0,passed:0,failed:0,skipped:0},tests:[],exitCode:code};
    await fsp.writeFile(a.functionalSummary,JSON.stringify(currentJob.functional,null,2));
    throw new Error(`Playwright execution exited ${code}, but no valid JSON report exists. Functional PASS cannot be claimed.`);
  }
  const summary=summarizeFunctionalReport(report,code,spec,reportFile,sel.id,project||'default');
  currentJob.functional=summary;
  await fsp.writeFile(a.functionalSummary,JSON.stringify(summary,null,2),'utf8');
  if(summary.verdict==='FUNCTIONAL_PASS'){
    step(5,'pass',`${summary.counts.passed}/${summary.counts.total} Playwright tests PASSED in headed mode; no skipped/failed tests.`);
    log(`FUNCTIONAL PASS: ${summary.counts.passed}/${summary.counts.total} Playwright tests passed; report: ${a.functionalSummary}`,'success');
  } else {
    throw new Error(`Functional TC Check FAILED: ${summary.counts.passed} passed, ${summary.counts.failed} failed, ${summary.counts.skipped} skipped, ${summary.counts.other} other. See saved per-test results.`);
  }
}
async function executeJob(sel, mode){
  const a=artifactPaths(sel);
  const stageOne=(mode==='all'||mode==='extract');
  const stageTwo=(mode==='all'||mode==='migrate');
  const functionalOnly=mode==='functional';
  const sourceFingerprint=await fingerprintTree(config.javaRoot);
  currentJob={id:crypto.randomUUID(),methodId:sel.id,status:'running',startedAt:new Date().toISOString(),endedAt:null,steps:STEP_NAMES.map(name=>({name,status:'pending',note:''})),logs:[],artifacts:{json:a.json,prompt:a.prompt, outputDir:a.dir},aiCreditsObserved:{extract:null,migrate:null},functional:null,error:null};
  sendEvent('status',jobPublic());
  try{
    step(0,'running','Verifying the selected Java @Test method');
    if(!fs.existsSync(sel.file))throw new Error('The selected Java source file does not exist.');
    step(0,'pass',sel.relativePath);
    if(stageOne){
      step(1,'running','Copilot is generating the contract and prompt');
      const p=await writePromptFile(a,'01-extract-instructions.txt',promptForExtraction(sel,a));
      const ret=await invokeCopilot(p,'extract'); if(ret.stopReason)throw new Error(`${ret.stopReason} during extraction. This step cannot be marked complete.`); if(ret.code!==0)throw new Error(`Copilot extraction exited with code ${ret.code}.`);
      const afterExtract=await fingerprintTree(config.javaRoot);
      if(sourceFingerprint!==afterExtract)throw new Error('ALERT: Java/Excel source files changed during extraction. Stage 2 was cancelled.');
      step(1,'pass','Copilot exited 0; Java/Excel files remained unchanged');
    }else step(1,'skipped','Existing artifacts reused');
    step(2,'running','Validating the generated JSON contract');
    let contract;
    try{contract=JSON.parse(await fsp.readFile(a.json,'utf8'))}catch{throw new Error('No valid contract.json was found. Migration stopped.');}
    if(contract.className!==sel.className || contract.methodName!==sel.name || !Array.isArray(contract.assertions) || !Array.isArray(contract.steps))throw new Error('Contract does not match the selected class/method or lacks valid steps/assertions.');
    const promptContent=await fsp.readFile(a.prompt,'utf8').catch(()=>''), promptValid=promptContent.length>=40;
    if(!promptValid)throw new Error('The generated prompt.md is missing or incomplete.');
    step(2,'pass',`${contract.assertions.length} assertion records in JSON`);
    if(stageTwo){
      step(3,'running','Copilot is implementing the TypeScript spec');
      const beforeSpecs=await listSpecVersions(config.playwrightRoot);
      const p=await writePromptFile(a,'02-migrate-instructions.txt',promptForMigration(sel,a));
      const ret=await invokeCopilot(p,'migrate'); if(ret.stopReason)throw new Error(`${ret.stopReason} during migration. Existing changes are preserved but not certified.`); if(ret.code!==0)throw new Error(`Copilot migration exited with code ${ret.code}.`);
      const afterMigration=await fingerprintTree(config.javaRoot);
      if(sourceFingerprint!==afterMigration)throw new Error('ALERT: Java/Excel source files changed during implementation.');
      const afterSpecs=await listSpecVersions(config.playwrightRoot);
      const touched=Object.entries(afterSpecs).filter(([file,version])=>beforeSpecs[file]!==version).map(([file])=>file);
      if(!touched.length)throw new Error('Copilot did not create or modify a .spec.ts file. Migration is incomplete.');
      currentJob.artifacts.specs=touched;
      step(3,'pass',`${touched.length} spec(s) created/modified; functional coverage is not yet verified`);
      if(config.autoTypecheck){step(4,'running','npx tsc --noEmit');const c=await runTypecheck();if(c===0)step(4,'pass','TypeScript typecheck passed; NOT a Functional PASS');else throw new Error(`TypeScript typecheck exited with code ${c}; implementation not verified.`);}
      else step(4,'skipped','Typecheck disabled in settings');
      // Execute the real migrated method only after typecheck and safe scenario gating.
      if(!config.autoTypecheck){
        currentJob.functional={verdict:'NOT_EXECUTED',reason:'TypeScript validation is disabled. Functional execution cannot start.',counts:{total:0,passed:0,failed:0,skipped:0},tests:[]};
        step(5,'skipped','Typecheck is disabled; functional check cannot start.');
      }else await runFunctionalCheck(sel,a,contract,touched);
    }else{step(3,'skipped',functionalOnly?'Using existing spec':'Extraction only');
      if(functionalOnly){step(4,'running','Validating TypeScript before the focused Playwright run');
        const c=await runTypecheck();if(c!==0)throw new Error(`TypeScript typecheck failed (${c}); functional execution aborted.`);
        step(4,'pass','TypeScript typecheck passed');await runFunctionalCheck(sel,a,contract,[],true);
      }else{step(4,'skipped','Extraction only');step(5,'skipped','Extraction only');}}
    const after=await fingerprintTree(config.javaRoot);
    if(sourceFingerprint!==after)throw new Error('ALERT: a Java source file changed. Review changes immediately.');
    step(6,'pass','Java unchanged; generated files and runtime results saved in target project');
    if(currentJob.status==='cancelled')throw new Error('Job cancelled by user.');
    currentJob.status='completed';
    log('Workflow finished. See the Functional TC Check stage for real execution status.','success');
  }catch(err){
    currentJob.status=currentJob.status==='cancelled'?'cancelled':'blocked';currentJob.error=err.message;
    log(`BLOCKED: ${err.message}`,'error');
    if(currentJob.steps[5]?.status==='running' && !currentJob.functional) {
      const a=artifactPaths(sel);
      currentJob.functional={methodId:sel.id,verdict:'BLOCKED',reason:err.message,counts:{total:0,passed:0,failed:0,skipped:0},tests:[]};
      await fsp.writeFile(a.functionalSummary,JSON.stringify(currentJob.functional,null,2)).catch(()=>{});
    }
    const ix=currentJob.steps.findIndex(x=>x.status==='running');if(ix>=0)step(ix,'blocked',err.message);
  }finally{currentJob.endedAt=new Date().toISOString();sendEvent('status',jobPublic());}
}
function parseBody(req){return new Promise((resolve,reject)=>{let body='';req.on('data',d=>{body+=d; if(body.length>100000){reject(new Error('Request body too large'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(body||'{}'))}catch{reject(new Error('Invalid JSON'))}});req.on('error',reject);});}
function originAllowed(req){if(!req.headers.origin)return true;try{const u=new URL(req.headers.origin);return u.hostname==='127.0.0.1'&&Number(u.port)===PORT;}catch{return false;}}
const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,`http://${HOST}:${PORT}`);
    if(req.method==='GET' && url.pathname==='/'){const html=await fsp.readFile(path.join(HERE,'index.html'));res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'"});res.end(html);return;}
    if(req.method==='GET' && url.pathname==='/app.js'){const data=await fsp.readFile(path.join(HERE,'app.js'));res.writeHead(200,{'Content-Type':'application/javascript; charset=utf-8','Cache-Control':'no-store'});res.end(data);return;}
    if(req.method==='GET'&&url.pathname==='/api/events'){
      res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});
      res.write('retry: 2000\n\n');clients.add(res);res.write(`event: status\ndata: ${JSON.stringify(jobPublic())}\n\n`);req.on('close',()=>clients.delete(res));return;
    }
    if(req.method==='GET' && url.pathname==='/api/config'){json(res,200,{...config,...rootChecks()});return;}
    if(req.method==='GET'&&url.pathname==='/api/methods'){
      if(!rootChecks().javaExists){json(res,400,{error:'Java source directory is unavailable'});return;}
      if(Date.now()-lastMethodScan>120000||!methodCache.length){methodCache=await collectMethods();lastMethodScan=Date.now();}
      const term=(url.searchParams.get('q')||'').toLowerCase();
      json(res,200,{total:methodCache.length,methods:methodCache.filter(m=>m.id.toLowerCase().includes(term)).slice(0,400).map(({id,relativePath})=>({id,relativePath}))});return;
    }
    if(req.method==='GET'&&url.pathname==='/api/method-preview'){
      const sel=await findMethod(url.searchParams.get('id')||''); const raw=await fsp.readFile(sel.file,'utf8');
      const start=Math.max(0,raw.search(new RegExp('\\b'+sel.name+'\\s*\\('))-400);
      json(res,200,{id:sel.id,relativePath:sel.relativePath,javaPreview:raw.slice(start,start+14000)});return;
    }
    if(req.method==='GET'&&url.pathname==='/api/outputs'){
      const sel=await findMethod(url.searchParams.get('id')||'');const a=artifactPaths(sel);
      const exists={json:fs.existsSync(a.json),prompt:fs.existsSync(a.prompt)};
      let contract='';let prompt='';if(exists.json)contract=(await fsp.readFile(a.json,'utf8')).slice(0,22000);if(exists.prompt)prompt=(await fsp.readFile(a.prompt,'utf8')).slice(0,22000);
      const specMap=await listSpecVersions(config.playwrightRoot);
      let specPath='';
      for(const f of Object.keys(specMap)){
        if(path.basename(f).toLowerCase().includes(sel.className.toLowerCase())){specPath=f;break;}
      }
      if(!specPath){
        for(const f of Object.keys(specMap)){
          const source=await fsp.readFile(f,'utf8').catch(()=>'');
          if(source.includes(sel.name) && (source.includes(sel.className)||path.basename(f).toLowerCase().includes('home'))){specPath=f;break;}
        }
      }
      const specPreview=specPath?(await fsp.readFile(specPath,'utf8')).slice(0,35000):'';
      const functional=await fsp.readFile(a.functionalSummary,'utf8').then(JSON.parse).catch(()=>null);
      json(res,200,{...exists,contract,prompt,outputDir:a.dir,specPath,specPreview,specExists:!!specPath,functional});return;
    }
    if(req.method==='GET' && url.pathname==='/api/job'){json(res,200,jobPublic());return;}
    if(req.method==='POST'){
      if(!originAllowed(req)){json(res,403,{error:'Origin not allowed'});return;}
      const body=await parseBody(req);
      if(url.pathname==='/api/config'){
        if(currentJob?.status==='running')throw new Error('Cannot change project paths while a job is running.');
        const javaRoot=String(body.javaRoot||'').trim(),playwrightRoot=String(body.playwrightRoot||'').trim();
        if(!validRoot(javaRoot)||!validRoot(playwrightRoot))throw new Error('One or both project directories do not exist.');
        if(path.resolve(javaRoot)===path.resolve(playwrightRoot))throw new Error('Source and target directories cannot be the same.');
        config={javaRoot,playwrightRoot,autoTypecheck:body.autoTypecheck!==false,autoFunctionalCheck:body.autoFunctionalCheck!==false};
        await fsp.writeFile(CONFIG_FILE,JSON.stringify(config,null,2));methodCache=[];lastMethodScan=0;
        json(res,200,{ok:true,...config,...rootChecks()});return;
      }
      if(url.pathname==='/api/start'){
        if(dispatchPending||currentJob?.status==='running'){json(res,409,{error:'A migration is already running.'});return;}
        if(!rootChecks().ready)throw new Error('Verify that both project folders exist.');
        const mode=body.mode; if(!['extract','migrate','all','functional'].includes(mode))throw new Error('Invalid execution mode.');
        const sel=await findMethod(String(body.methodId||''));
        dispatchPending=true;executeJob(sel,mode).finally(()=>{dispatchPending=false;});json(res,202,{started:true,id:sel.id,mode});return;
      }
      if(url.pathname==='/api/cancel'){
        if(!currentJob || currentJob.status!=='running')throw new Error('No migration is currently running.');
        currentJob.status='cancelled';log('Cancellation requested; stopping only the process started by this panel.','warning');
        if(runningProcess){if(process.platform==='win32')spawn('taskkill',['/PID',String(runningProcess.pid),'/T','/F'],{windowsHide:true});else runningProcess.kill('SIGTERM');}
        json(res,200,{cancelled:true});return;
      }
    }
    json(res,404,{error:'Endpoint not found'});
  }catch(err){json(res,400,{error:err.message});}
});
server.listen(PORT,HOST,()=>console.log(`iGero Simple Migration UI: http://${HOST}:${PORT}/`));
