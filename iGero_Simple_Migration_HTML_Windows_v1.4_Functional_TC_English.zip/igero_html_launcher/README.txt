iGERO SIMPLE MIGRATION — v1.4 · ENGLISH UI + FUNCTIONAL TC CHECK
=================================================================

This local Windows dashboard automates the two-step Pervez migration method:
Java Selenium/TestNG -> contract.json + prompt.md -> Playwright TypeScript.
It now includes a final real Playwright Functional TC Check and displays
individual test/step results in English.

INSTALL / UPDATE
----------------
1. Stop the old local iGero server (close its command prompt window).
2. Unzip this package into a folder of your choice.
3. If updating an older version, replace the old application files but
   KEEP your config.local.json (if it exists).
4. Verify 'node --version' and 'copilot --version' in Windows PowerShell.
5. Double-click Start-iGero-HTML.cmd.
6. Open http://127.0.0.1:8766/ if the browser does not open automatically.
7. Press Verify paths, select the exact Java @Test method and choose
   Run full migration.

DEFAULT PROJECT PATHS
---------------------
Java source (read-only):
D:\Users\CARLOS.GARCIA19\Master\ffq-test-master

Playwright TypeScript target:
D:\Users\CARLOS.GARCIA19\PW-TS-MM\FFQ-Playwright-TS-master

NEW: AUTOMATIC FUNCTIONAL TC CHECK
----------------------------------
* After generating the .spec.ts and passing TypeScript typecheck, the dashboard
  attempts a focused Playwright run against the real test application.
* It runs only the selected source method's test title, isolated from unrelated
  cases using --grep with the exact Java method name. Generated spec titles
  are instructed to include that method name.
* Uses --headed --workers=1 --retries=0, and the Playwright project chosen
  from the test discovery output. The actual browser channel depends on your
  Playwright project configuration. The dashboard does not rewrite that config.
* Saves an official Playwright JSON report and a sanitized summary in:

  migration/pervez-json/<Class>__<Method>/functional-report.json
  migration/pervez-json/<Class>__<Method>/functional-summary.json
  migration/pervez-json/<Class>__<Method>/spec-manifest.json

* Section 7 displays test counts, results, durations, errors and recorded
  Playwright steps. The individual test result is a real Playwright result,
  never inferred from typecheck. Java runtime parity remains NOT_VERIFIED.
* 'Run Functional TC Check' can run the already migrated method without
  calling Copilot or regenerating the artifacts. It validates TypeScript first.
* Uncheck 'Run Functional TC Check automatically' to skip browser execution
  after migration. Manual execution remains possible for safe scenarios.

SENSITIVE SCENARIO SAFETY
-------------------------
Bind, payment, bank, purchase, policy binding and email tests are not
executed automatically or from the manual functional button in this pilot.
They require a separate, explicitly authorized QA/business execution process.
They are marked SKIPPED_SAFETY, not PASS.

STATUS RULES
------------
FUNCTIONAL_PASS: at least one matching Playwright test executed and all
  tests were expected passes, without skipped, failed or interrupted tests.
FUNCTIONAL_FAILED: actual Playwright execution failed or included skips.
BLOCKED: no single matching spec/test could safely be isolated, typecheck
  failed, or test discovery failed.
SKIPPED_SAFETY: no browser was started for a sensitive business scenario.
NOT_EXECUTED: functional check was explicitly disabled.

AI CREDITS
----------
AI-credit selection remains AUTOMATIC. The launcher does not specify
--max-ai-credits. Your Copilot account and corporate policies still apply.
Autopilot continuations are bounded. No claim of unlimited usage is made.

REQUIRED TOOLS / SECURITY
-------------------------
Node.js, GitHub Copilot CLI, the existing project's Playwright dependencies
and a permitted QA test environment. Do not run this local service on a
public network. It listens only on 127.0.0.1. Do not share raw runtime reports
if they contain personal/customer data.

Java and source Excel are instructed to remain read-only, and the dashboard
checks for accidental file changes. That check is not an OS permission boundary.
Back up or Git-commit your target workspace before allowing Copilot writes.

Local static/server tests were performed without running your corporate
QA application. The actual GitHub Copilot CLI and real Playwright runtime
remain to be verified on your Windows workstation.
