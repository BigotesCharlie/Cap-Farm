const $ = id => document.getElementById(id);
const stepNames = ['Locate Java method','Copilot: generate JSON + prompt.md','Validate generated contract','Copilot: implement complete spec.ts','Validate TypeScript','Functional TC Check — Playwright','Save results'];
let selected = '', selectedTab='json', cachedOutput={}, liveJob=null, methodList=[];
function text(id,s){$(id).textContent=s}
function enableControls(running){for(const id of ['extractBtn','migrateBtn','allBtn','functionalBtn','saveBtn','reloadMethods'])$(id).disabled=running; $('stopBtn').disabled=!running;}
async function request(url,body){const opts=body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)};const r=await fetch(url,opts);const obj=await r.json();if(!r.ok)throw new Error(obj.error||`HTTP ${r.status}`);return obj;}
function err(e){text('pathStatus',e.message);$('pathStatus').className='status bad';addLog({text:e.message,kind:'error',t:new Date().toLocaleTimeString()})}
function renderSystem(data){
  const grid=$('readinessGrid');grid.replaceChildren();
  const labels={node:'Node.js',copilot:'GitHub Copilot CLI',java:'Selenium Java source',target:'Playwright target',playwright:'Playwright dependencies',authentication:'Copilot authentication'};
  for(const [key,label] of Object.entries(labels)){
    const c=data.checks?.[key]||{status:'INFO',value:'UNKNOWN',detail:'No data'};
    const box=document.createElement('div');box.className='readinessitem '+c.status.toLowerCase();
    const title=document.createElement('strong');title.textContent=label;
    const badge=document.createElement('span');badge.className='readystatus';badge.textContent=c.status;
    const heading=document.createElement('strong');heading.append(document.createTextNode(label),badge);
    const value=document.createElement('code');value.textContent=c.value||'';
    const detail=document.createElement('p');detail.textContent=c.detail||'';
    box.append(heading,value,detail);grid.append(box);
  }
  const ready=data.migrationReady;
  text('systemVerdict',ready?'READY':data.functionalReady?'COPILOT NOT READY':'ACTION REQUIRED');
  $('systemVerdict').className='status '+(ready?'ok':'bad');
  text('systemNotes',data.note+' · Login is not checked by version probing. Configure QA runtime separately if test discovery reports a missing environment URL.');
}
async function refreshSystem(){
  $('systemBtn').disabled=true;text('systemVerdict','CHECKING');
  try{renderSystem(await request('/api/system'))}catch(e){text('systemVerdict','CHECK FAILED');err(e)}
  finally{$('systemBtn').disabled=false}
}
function renderSteps(steps){const cont=$('checklist');cont.replaceChildren();(steps||stepNames.map(name=>({name,status:'pending'}))).forEach(s=>{const el=document.createElement('div');el.className='checkrow '+s.status;const dot=document.createElement('div');dot.className='circle';dot.textContent={pass:'✓',running:'◌',blocked:'×',skipped:'—',pending:'·'}[s.status]||'·';const box=document.createElement('div');const title=document.createElement('b');title.textContent=s.name;const note=document.createElement('span');note.textContent=s.note||({pass:'PASS',running:'Running…',blocked:'BLOCKED',skipped:'Skipped',pending:'Pending'}[s.status]);box.append(title,note);el.append(dot,box);cont.append(el);});}
function addLog(line){const el=document.createElement('div');el.className='line '+(line.kind||'');el.textContent=`[${line.t||''}] ${line.text||''}`;$('console').append(el);$('console').scrollTop=$('console').scrollHeight;if($('console').childElementCount>280)$('console').firstChild.remove();}
function renderFunctional(result){
  const c=result?.counts||{};text('fcTotal',String(c.total||0));text('fcPassed',String(c.passed||0));text('fcFailed',String(c.failed||0));text('fcSkipped',String(c.skipped||0));
  $('downloadFunctionalBtn').disabled=!result;
  const status=result?.verdict||'NOT EXECUTED';text('statRuntime',status==='FUNCTIONAL_PASS'?'PASS':status==='FUNCTIONAL_FAILED'?'FAIL':status==='SKIPPED_SAFETY'?'SKIP':'—');text('functionalVerdict',status.replaceAll('_',' '));
  $('functionalVerdict').className='status '+(status==='FUNCTIONAL_PASS'?'ok':status==='FUNCTIONAL_FAILED'||status==='REPORT_MISSING'?'bad':'');
  const details=result?.reason || (result?.executedAt?`Executed: ${result.executedAt} · Project: ${result.projectName||'default'} · Java runtime parity: NOT VERIFIED`:
    'No real Playwright functional execution has been recorded for this method.');
  text('functionalMeta',details);
  const cont=$('functionalResults');cont.replaceChildren();
  if(!result?.tests?.length){const empty=document.createElement('p');empty.className='fine';empty.textContent='No individual test results available.';cont.append(empty);return;}
  for(const t of result.tests){
    const box=document.createElement('div');box.className='resultitem '+(t.status==='expected' && t.expectedStatus==='passed'?'pass':t.status==='skipped'?'skip':'fail');
    const name=document.createElement('div');name.className='resulttitle';name.textContent=t.title;
    const meta=document.createElement('div');meta.className='resultmeta';meta.textContent=`${(t.status||'unknown').toUpperCase()} · ${t.duration||0} ms · ${t.project||result.projectName||'default'} · Attempts: ${(t.retries||0)+1}`;
    box.append(name,meta);
    for(const e of t.errors||[]){const er=document.createElement('div');er.className='resultError';er.textContent=e;box.append(er);}
    if(t.steps?.length){const detail=document.createElement('details');const summary=document.createElement('summary');summary.textContent=`Show all ${t.steps.length} recorded Playwright steps`;detail.append(summary);
      for(const st of t.steps){const line=document.createElement('div');line.className='resultstep '+(st.error?'fail':'');line.style.paddingLeft=`${7+Math.min(st.depth||0,6)*9}px`;
        line.textContent=`${st.error?'✗ ':'• '}${st.title} (${st.duration||0} ms)`;detail.append(line);
        if(st.error){const er=document.createElement('div');er.className='resultError';er.textContent=st.error;detail.append(er);}
      }box.append(detail);}
    cont.append(box);
  }
}
function renderJob(job, full=false){
  if (job?.aiCreditsObserved) {
    const measured=Object.entries(job.aiCreditsObserved).filter(([,v])=>Number.isFinite(v));
    const total=measured.reduce((sum,[,v])=>sum+v,0);
    text('aiCreditUsage',measured.length
      ? `AI Credits reported by CLI (approx.): ${total.toFixed(2)} · no manual cap`
      : 'AI Credits: automatic · CLI usage not reported');
  } else text('aiCreditUsage','AI Credits: automatic · usage not reported');
  liveJob=job;if(job?.methodId && job.methodId===($('manualId').value.trim()||selected))renderFunctional(job.functional||null);enableControls(job?.status==='running');renderSteps(job?.steps);text('jobSummary',job?`${job.status.toUpperCase()} · ${job.methodId}`:'No active job');const m=$('jobMarker');m.textContent=job?`${job.status==='completed'?'✓ ':job.status==='blocked'?'✕ ':'◌ '}${job.methodId} · ${job.status}`:'No migration started yet';m.className='marker '+(job?.status==='completed'?'ready':job?.status==='blocked'?'block':job?.status==='partial'?'warn':'');if(full&&job?.logs){$('console').replaceChildren();job.logs.forEach(addLog)}if(job?.status==='completed'||job?.status==='blocked'||job?.status==='partial')refreshOutputs().catch(()=>{});}
function renderMethods(items){const container=$('methodList');container.replaceChildren();if(!items.length){const p=document.createElement('p');p.className='fine';p.textContent='No Java methods match this filter. Check the source repository or enter Class#method.';container.append(p);return;}for(const item of items){const btn=document.createElement('button');btn.className='method'+(selected===item.id?' on':'');const strong=document.createElement('b');strong.textContent=item.id;const small=document.createElement('small');small.textContent=item.relativePath;btn.append(strong,small);btn.addEventListener('click',()=>selectMethod(item.id));container.append(btn);}}
async function selectMethod(id){selected=id;text('manualId',id);$('manualId').value=id;renderMethods(methodList);text('javaPreview','Loading Java source…');try{const m=await request('/api/method-preview?id='+encodeURIComponent(id));text('javaPreview',m.javaPreview);$('javaPreview').classList.remove('empty');text('javaFilePath',m.relativePath);await refreshOutputs();}catch(e){err(e)}}
async function refreshMethods(){try{const q=$('methodSearch').value.trim();const data=await request('/api/methods?q='+encodeURIComponent(q));methodList=data.methods;text('methodCount',data.total);renderMethods(methodList);}catch(e){err(e)}}
async function refreshOutputs(){const id=($('manualId').value.trim()||selected);if(!id)return;try{const out=await request('/api/outputs?id='+encodeURIComponent(id));cachedOutput=out;text('statJson',out.json?'1':'0');text('statPrompt',out.prompt?'1':'0');text('outputDir',out.outputDir);displayGenerated();if(liveJob?.methodId===id)renderFunctional(liveJob.functional||null);else renderFunctional(out.functional||null);}catch(e){/* no output until selected */}}
function displayGenerated(){const display=selectedTab==='json'?(cachedOutput.contract||'contract.json does not exist yet'):(selectedTab==='prompt'?(cachedOutput.prompt||'prompt.md does not exist yet'):(cachedOutput.specPreview||'The .spec.ts has not been found yet'));text('generatedPreview',display);$('tabJson').classList.toggle('on',selectedTab==='json');$('tabPrompt').classList.toggle('on',selectedTab==='prompt');$('tabSpec').classList.toggle('on',selectedTab==='spec');}
async function start(mode){const id=$('manualId').value.trim()||selected;if(!id){err(new Error('Select a Java test method first'));return}try{const result=await request('/api/start',{methodId:id,mode});$('console').replaceChildren();addLog({t:new Date().toLocaleTimeString(),text:`Started ${mode}: ${result.id}`,kind:'success'});renderFunctional(null);const job=await request('/api/job');renderJob(job);}catch(e){err(e)}}
async function init(){renderSteps();await refreshSystem();const cfg=await request('/api/config');$('javaRoot').value=cfg.javaRoot;$('pwRoot').value=cfg.playwrightRoot;$('typecheck').checked=cfg.autoTypecheck;$('functionalCheck').checked=cfg.autoFunctionalCheck!==false;$('testEnv').value=cfg.testEnv||'MA11';showPath(cfg);await refreshMethods().catch(()=>{});const job=await request('/api/job');renderJob(job,true);}
function showPath(c){const yes=c.javaExists&&c.targetExists;text('pathStatus',`Java: ${c.javaExists?'OK':'UNAVAILABLE'} · Playwright: ${c.targetExists?'OK':'UNAVAILABLE'}`);$('pathStatus').className='status '+(yes?'ok':'bad');text('connectionBadge',yes?'● Projects connected':'● Check project paths');}
$('verifyBtn').addEventListener('click',async()=>{try{const c=await request('/api/config');showPath(c);await refreshSystem()}catch(e){err(e)}});
$('systemBtn').addEventListener('click',refreshSystem);
$('saveBtn').addEventListener('click',async()=>{try{const c=await request('/api/config',{javaRoot:$('javaRoot').value.trim(),playwrightRoot:$('pwRoot').value.trim(),autoTypecheck:$('typecheck').checked,autoFunctionalCheck:$('functionalCheck').checked,testEnv:$('testEnv').value});showPath(c);await refreshSystem();selected='';$('manualId').value='';text('javaPreview','Select a method to preview its Java code.');await refreshMethods()}catch(e){err(e)}});
$('reloadMethods').addEventListener('click',refreshMethods);
let timer; $('methodSearch').addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(refreshMethods,220)});
$('manualId').addEventListener('change',()=>{const id=$('manualId').value.trim();if(id)selectMethod(id)});
$('extractBtn').addEventListener('click',()=>start('extract'));
$('migrateBtn').addEventListener('click',()=>start('migrate'));
$('allBtn').addEventListener('click',()=>start('all'));
$('functionalBtn').addEventListener('click',()=>start('functional'));
$('stopBtn').addEventListener('click',async()=>{try{await request('/api/cancel',{});renderJob(await request('/api/job'))}catch(e){err(e)}});
$('tabJson').addEventListener('click',()=>{selectedTab='json';displayGenerated()});
$('tabPrompt').addEventListener('click',()=>{selectedTab='prompt';displayGenerated()});
$('tabSpec').addEventListener('click',()=>{selectedTab='spec';displayGenerated()});
$('refreshOutput').addEventListener('click',()=>refreshOutputs().catch(err));
$('downloadFunctionalBtn').addEventListener('click',()=>{const result=liveJob?.methodId===($('manualId').value.trim()||selected)?liveJob.functional:cachedOutput.functional;
  if(!result)return;const blob=new Blob([JSON.stringify(result,null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download='functional-tc-results.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
let previousLogLength=0; const source=new EventSource('/api/events');
source.addEventListener('status',e=>{const job=JSON.parse(e.data);renderJob(job)});
source.addEventListener('log',e=>{addLog(JSON.parse(e.data))});
source.onerror=()=>{text('jobSummary','Live connection interrupted; reconnecting…')};
init().catch(err);
