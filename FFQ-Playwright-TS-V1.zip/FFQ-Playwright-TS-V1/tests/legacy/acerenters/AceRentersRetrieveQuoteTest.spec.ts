// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acerenters.AceRentersRetrieveQuoteTest", () => {
  // legacy-id: com.farmers.ffq.acerenters.AceRentersRetrieveQuoteTest#testRetrieveNonRatedQuoteRenters
  test("testRetrieveNonRatedQuoteRenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersRetrieveQuoteTest#testRetrieveNonRatedQuoteRenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersRetrieveQuoteTest.java","sourceLine":28,"className":"AceRentersRetrieveQuoteTest","method":"testRetrieveNonRatedQuoteRenters","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_RETRIEVE_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersRetrieveQuoteTest#testRetrieveRatedQuoteRenters
  test("testRetrieveRatedQuoteRenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersRetrieveQuoteTest#testRetrieveRatedQuoteRenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersRetrieveQuoteTest.java","sourceLine":45,"className":"AceRentersRetrieveQuoteTest","method":"testRetrieveRatedQuoteRenters","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_RETRIEVE_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersRetrieveQuoteTest#testRetrieveRatedQuoteFromJFMTPageRenters
  test("testRetrieveRatedQuoteFromJFMTPageRenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersRetrieveQuoteTest#testRetrieveRatedQuoteFromJFMTPageRenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersRetrieveQuoteTest.java","sourceLine":100,"className":"AceRentersRetrieveQuoteTest","method":"testRetrieveRatedQuoteFromJFMTPageRenters","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_RETRIEVE_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersRetrieveQuoteTest#testRetrieveRatedQuoteFromPaymentPageRenters
  test("testRetrieveRatedQuoteFromPaymentPageRenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersRetrieveQuoteTest#testRetrieveRatedQuoteFromPaymentPageRenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersRetrieveQuoteTest.java","sourceLine":134,"className":"AceRentersRetrieveQuoteTest","method":"testRetrieveRatedQuoteFromPaymentPageRenters","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_RETRIEVE_FLOW})"});
  });

});
