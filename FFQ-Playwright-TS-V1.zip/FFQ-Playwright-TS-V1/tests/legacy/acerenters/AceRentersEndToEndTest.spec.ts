// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.acerenters.AceRentersEndToEndTest', () => {
  // legacy-id: com.farmers.ffq.acerenters.AceRentersEndToEndTest#testReviewQuotePagePresentmentCardRentersLob
  test('testReviewQuotePagePresentmentCardRentersLob', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId: 'com.farmers.ffq.acerenters.AceRentersEndToEndTest#testReviewQuotePagePresentmentCardRentersLob',
      domain: 'acerenters',
      sourceFile: 'src/test/java/com/farmers/ffq/acerenters/AceRentersEndToEndTest.java',
      sourceLine: 25,
      className: 'AceRentersEndToEndTest',
      method: 'testReviewQuotePagePresentmentCardRentersLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {})',
    });
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersEndToEndTest#testProdRetrieveRatedQuoteAceRenters
  test('testProdRetrieveRatedQuoteAceRenters', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId: 'com.farmers.ffq.acerenters.AceRentersEndToEndTest#testProdRetrieveRatedQuoteAceRenters',
      domain: 'acerenters',
      sourceFile: 'src/test/java/com/farmers/ffq/acerenters/AceRentersEndToEndTest.java',
      sourceLine: 45,
      className: 'AceRentersEndToEndTest',
      method: 'testProdRetrieveRatedQuoteAceRenters',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{PRODUCTION_VALIDATION}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,TX,LA,MA,MS,NC})}, groups = {PRODUCTION_VALIDATION})',
    });
  });
});
