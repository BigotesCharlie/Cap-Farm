// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acerenters.AceRentersMonthlyAutoPayTest", () => {
  // legacy-id: com.farmers.ffq.acerenters.AceRentersMonthlyAutoPayTest#testMonthlyAutoPayBankPaymentEndToEndAceRenters
  test("testMonthlyAutoPayBankPaymentEndToEndAceRenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersMonthlyAutoPayTest#testMonthlyAutoPayBankPaymentEndToEndAceRenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersMonthlyAutoPayTest.java","sourceLine":20,"className":"AceRentersMonthlyAutoPayTest","method":"testMonthlyAutoPayBankPaymentEndToEndAceRenters","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_HOME_BIND,FFQ_ACE_RENTERS_MONTHLY_AUTOPAY_BANK_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,MT,UT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_HOME_BIND,FFQ_ACE_RENTERS_MONTHLY_AUTOPAY_BANK_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersMonthlyAutoPayTest#testMonthlyAutoPayCreditCardPaymentEndToEndAceRenters
  test("testMonthlyAutoPayCreditCardPaymentEndToEndAceRenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersMonthlyAutoPayTest#testMonthlyAutoPayCreditCardPaymentEndToEndAceRenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersMonthlyAutoPayTest.java","sourceLine":41,"className":"AceRentersMonthlyAutoPayTest","method":"testMonthlyAutoPayCreditCardPaymentEndToEndAceRenters","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_MONTHLY_AUTOPAY_BANK_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MT,MO,UT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_MONTHLY_AUTOPAY_BANK_PAGE})"});
  });

});
