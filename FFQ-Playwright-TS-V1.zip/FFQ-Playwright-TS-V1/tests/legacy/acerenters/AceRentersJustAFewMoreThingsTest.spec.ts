// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acerenters.AceRentersJustAFewMoreThingsTest", () => {
  // legacy-id: com.farmers.ffq.acerenters.AceRentersJustAFewMoreThingsTest#testValidateContentOfJustFewMoreThingsPageRentersLob
  test("testValidateContentOfJustFewMoreThingsPageRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersJustAFewMoreThingsTest#testValidateContentOfJustFewMoreThingsPageRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersJustAFewMoreThingsTest.java","sourceLine":25,"className":"AceRentersJustAFewMoreThingsTest","method":"testValidateContentOfJustFewMoreThingsPageRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_JAFMT_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_JAFMT_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersJustAFewMoreThingsTest#testBusinessOperatedOnPremisesKnockOutScreenRentersLob
  test("testBusinessOperatedOnPremisesKnockOutScreenRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersJustAFewMoreThingsTest#testBusinessOperatedOnPremisesKnockOutScreenRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersJustAFewMoreThingsTest.java","sourceLine":43,"className":"AceRentersJustAFewMoreThingsTest","method":"testBusinessOperatedOnPremisesKnockOutScreenRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersJustAFewMoreThingsTest#testPetWithBiteHistoryKnockOutScreenRentersLob
  test("testPetWithBiteHistoryKnockOutScreenRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersJustAFewMoreThingsTest#testPetWithBiteHistoryKnockOutScreenRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersJustAFewMoreThingsTest.java","sourceLine":59,"className":"AceRentersJustAFewMoreThingsTest","method":"testPetWithBiteHistoryKnockOutScreenRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersJustAFewMoreThingsTest#validateJFMTBackAndForthAndRC3LoadingScreenRenters
  test("validateJFMTBackAndForthAndRC3LoadingScreenRenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersJustAFewMoreThingsTest#validateJFMTBackAndForthAndRC3LoadingScreenRenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersJustAFewMoreThingsTest.java","sourceLine":75,"className":"AceRentersJustAFewMoreThingsTest","method":"validateJFMTBackAndForthAndRC3LoadingScreenRenters","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersJustAFewMoreThingsTest#testKnockOutScreenWhenAllOtherQuestionsAreSelectedRentersLob
  test("testKnockOutScreenWhenAllOtherQuestionsAreSelectedRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersJustAFewMoreThingsTest#testKnockOutScreenWhenAllOtherQuestionsAreSelectedRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersJustAFewMoreThingsTest.java","sourceLine":92,"className":"AceRentersJustAFewMoreThingsTest","method":"testKnockOutScreenWhenAllOtherQuestionsAreSelectedRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersJustAFewMoreThingsTest#testValidateThankYouPageCannotGoBindRentersLob
  test("testValidateThankYouPageCannotGoBindRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersJustAFewMoreThingsTest#testValidateThankYouPageCannotGoBindRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersJustAFewMoreThingsTest.java","sourceLine":105,"className":"AceRentersJustAFewMoreThingsTest","method":"testValidateThankYouPageCannotGoBindRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_THANK_YOU_SCREEN_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE})"});
  });

});
