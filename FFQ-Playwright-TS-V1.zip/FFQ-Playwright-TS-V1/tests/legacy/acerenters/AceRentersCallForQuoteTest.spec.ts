// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acerenters.AceRentersCallForQuoteTest", () => {
  // legacy-id: com.farmers.ffq.acerenters.AceRentersCallForQuoteTest#testCallForQuoteToAceReviewQuoteRentersLob
  test.skip("testCallForQuoteToAceReviewQuoteRentersLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersCallForQuoteTest#testCallForQuoteToAceReviewQuoteRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersCallForQuoteTest.java","sourceLine":28,"className":"AceRentersCallForQuoteTest","method":"testCallForQuoteToAceReviewQuoteRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, AL, GA, IL, OH, VA})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE})"});
  });

});
