// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acerenters.AceRentersKnockOutTest", () => {
  // legacy-id: com.farmers.ffq.acerenters.AceRentersKnockOutTest#ppcZipMismatchKORenters
  test("ppcZipMismatchKORenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersKnockOutTest#ppcZipMismatchKORenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersKnockOutTest.java","sourceLine":19,"className":"AceRentersKnockOutTest","method":"ppcZipMismatchKORenters","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_PPC_ZIP_MISMATCH_KO, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_KNOCKOUT_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersKnockOutTest#ppcFireHydrantKORenters
  test("ppcFireHydrantKORenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersKnockOutTest#ppcFireHydrantKORenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersKnockOutTest.java","sourceLine":40,"className":"AceRentersKnockOutTest","method":"ppcFireHydrantKORenters","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_PPC_FIRE_HYDRANT_KO, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_KNOCKOUT_FLOW})"});
  });

});
