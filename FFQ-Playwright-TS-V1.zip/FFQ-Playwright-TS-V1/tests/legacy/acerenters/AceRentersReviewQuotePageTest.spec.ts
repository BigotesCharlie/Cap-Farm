// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acerenters.AceRentersReviewQuotePageTest", () => {
  // legacy-id: com.farmers.ffq.acerenters.AceRentersReviewQuotePageTest#testValidateReviewQuotePageAndRC2screenRentersLob
  test("testValidateReviewQuotePageAndRC2screenRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersReviewQuotePageTest#testValidateReviewQuotePageAndRC2screenRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersReviewQuotePageTest.java","sourceLine":21,"className":"AceRentersReviewQuotePageTest","method":"testValidateReviewQuotePageAndRC2screenRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_REVIEW_QUOTE_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_REVIEW_QUOTE_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersReviewQuotePageTest#validateDefaultDeductibleAndOptionalCoverage
  test("validateDefaultDeductibleAndOptionalCoverage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersReviewQuotePageTest#validateDefaultDeductibleAndOptionalCoverage","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersReviewQuotePageTest.java","sourceLine":68,"className":"AceRentersReviewQuotePageTest","method":"validateDefaultDeductibleAndOptionalCoverage","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_REVIEW_QUOTE_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CO, MD, MI, PA, TX})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_REVIEW_QUOTE_PAGE})"});
  });

});
