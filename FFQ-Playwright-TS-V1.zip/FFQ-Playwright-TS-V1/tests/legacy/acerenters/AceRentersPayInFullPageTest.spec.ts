// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acerenters.AceRentersPayInFullPageTest", () => {
  // legacy-id: com.farmers.ffq.acerenters.AceRentersPayInFullPageTest#validatePaymentByChangingPayInFullBankToMonthlyPayCardAceRenters
  test("validatePaymentByChangingPayInFullBankToMonthlyPayCardAceRenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersPayInFullPageTest#validatePaymentByChangingPayInFullBankToMonthlyPayCardAceRenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersPayInFullPageTest.java","sourceLine":21,"className":"AceRentersPayInFullPageTest","method":"validatePaymentByChangingPayInFullBankToMonthlyPayCardAceRenters","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MT,MO,UT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersPayInFullPageTest#testPayInFullCreditCardEndToEndTestCaseAceRenters
  test("testPayInFullCreditCardEndToEndTestCaseAceRenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersPayInFullPageTest#testPayInFullCreditCardEndToEndTestCaseAceRenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersPayInFullPageTest.java","sourceLine":50,"className":"AceRentersPayInFullPageTest","method":"testPayInFullCreditCardEndToEndTestCaseAceRenters","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL})"});
  });

});
