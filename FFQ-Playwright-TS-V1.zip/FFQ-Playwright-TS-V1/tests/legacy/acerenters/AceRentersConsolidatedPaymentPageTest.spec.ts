// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.acerenters.AceRentersConsolidatedPaymentPageTest', () => {
  // legacy-id: com.farmers.ffq.acerenters.AceRentersConsolidatedPaymentPageTest#validateAceRentersConsolidatedPaymentPage
  test('validateAceRentersConsolidatedPaymentPage', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acerenters.AceRentersConsolidatedPaymentPageTest#validateAceRentersConsolidatedPaymentPage',
      domain: 'acerenters',
      sourceFile: 'src/test/java/com/farmers/ffq/acerenters/AceRentersConsolidatedPaymentPageTest.java',
      sourceLine: 27,
      className: 'AceRentersConsolidatedPaymentPageTest',
      method: 'validateAceRentersConsolidatedPaymentPage',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONSOLIDATED_PAYMENT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONSOLIDATED_PAYMENT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersConsolidatedPaymentPageTest#consolidatePaymentPageValidatePaymentsRenters
  test('consolidatePaymentPageValidatePaymentsRenters', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acerenters.AceRentersConsolidatedPaymentPageTest#consolidatePaymentPageValidatePaymentsRenters',
      domain: 'acerenters',
      sourceFile: 'src/test/java/com/farmers/ffq/acerenters/AceRentersConsolidatedPaymentPageTest.java',
      sourceLine: 49,
      className: 'AceRentersConsolidatedPaymentPageTest',
      method: 'consolidatePaymentPageValidatePaymentsRenters',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONSOLIDATED_PAYMENT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONSOLIDATED_PAYMENT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersConsolidatedPaymentPageTest#testQuoteAndBindRentersLob
  test('testQuoteAndBindRentersLob', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId: 'com.farmers.ffq.acerenters.AceRentersConsolidatedPaymentPageTest#testQuoteAndBindRentersLob',
      domain: 'acerenters',
      sourceFile: 'src/test/java/com/farmers/ffq/acerenters/AceRentersConsolidatedPaymentPageTest.java',
      sourceLine: 61,
      className: 'AceRentersConsolidatedPaymentPageTest',
      method: 'testQuoteAndBindRentersLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{ACE_STABILITY, FFQ_ACE_RENTERS_PAYMENT_SELECTION_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {ACE_STABILITY, FFQ_ACE_RENTERS_PAYMENT_SELECTION_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersConsolidatedPaymentPageTest#verifyPremiumNotChangedOnBackAndForthFromPaymentPageToJFMTP
  test('verifyPremiumNotChangedOnBackAndForthFromPaymentPageToJFMTP', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acerenters.AceRentersConsolidatedPaymentPageTest#verifyPremiumNotChangedOnBackAndForthFromPaymentPageToJFMTP',
      domain: 'acerenters',
      sourceFile: 'src/test/java/com/farmers/ffq/acerenters/AceRentersConsolidatedPaymentPageTest.java',
      sourceLine: 85,
      className: 'AceRentersConsolidatedPaymentPageTest',
      method: 'verifyPremiumNotChangedOnBackAndForthFromPaymentPageToJFMTP',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONSOLIDATED_PAYMENT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONSOLIDATED_PAYMENT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersConsolidatedPaymentPageTest#verifyPremiumChangedOnBackAndForthFromPaymentPageToReviewQuote
  test('verifyPremiumChangedOnBackAndForthFromPaymentPageToReviewQuote', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acerenters.AceRentersConsolidatedPaymentPageTest#verifyPremiumChangedOnBackAndForthFromPaymentPageToReviewQuote',
      domain: 'acerenters',
      sourceFile: 'src/test/java/com/farmers/ffq/acerenters/AceRentersConsolidatedPaymentPageTest.java',
      sourceLine: 98,
      className: 'AceRentersConsolidatedPaymentPageTest',
      method: 'verifyPremiumChangedOnBackAndForthFromPaymentPageToReviewQuote',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONSOLIDATED_PAYMENT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONSOLIDATED_PAYMENT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersConsolidatedPaymentPageTest#testQuoteAndBindEndToEndRenters
  test('testQuoteAndBindEndToEndRenters', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId: 'com.farmers.ffq.acerenters.AceRentersConsolidatedPaymentPageTest#testQuoteAndBindEndToEndRenters',
      domain: 'acerenters',
      sourceFile: 'src/test/java/com/farmers/ffq/acerenters/AceRentersConsolidatedPaymentPageTest.java',
      sourceLine: 111,
      className: 'AceRentersConsolidatedPaymentPageTest',
      method: 'testQuoteAndBindEndToEndRenters',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{ACE_STABILITY}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {ACE_STABILITY})',
    });
  });
});
