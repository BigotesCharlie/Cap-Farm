// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acerenters.AceRentersAboutYouPageTest", () => {
  // legacy-id: com.farmers.ffq.acerenters.AceRentersAboutYouPageTest#pageContentValidationAboutYouPageRentersLob
  test("pageContentValidationAboutYouPageRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersAboutYouPageTest#pageContentValidationAboutYouPageRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersAboutYouPageTest.java","sourceLine":22,"className":"AceRentersAboutYouPageTest","method":"pageContentValidationAboutYouPageRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersAboutYouPageTest#validateErrorMessagesAboutYouPageRentersLob
  test("validateErrorMessagesAboutYouPageRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersAboutYouPageTest#validateErrorMessagesAboutYouPageRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersAboutYouPageTest.java","sourceLine":54,"className":"AceRentersAboutYouPageTest","method":"validateErrorMessagesAboutYouPageRentersLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersAboutYouPageTest#enteredDetailsRetainedWhenNavigatedBackAndForthAboutYouPageRentersLob
  test("enteredDetailsRetainedWhenNavigatedBackAndForthAboutYouPageRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersAboutYouPageTest#enteredDetailsRetainedWhenNavigatedBackAndForthAboutYouPageRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersAboutYouPageTest.java","sourceLine":121,"className":"AceRentersAboutYouPageTest","method":"enteredDetailsRetainedWhenNavigatedBackAndForthAboutYouPageRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersAboutYouPageTest#testDataNotSavedWhenNavigatedBackAboutYouPageRentersLob
  test("testDataNotSavedWhenNavigatedBackAboutYouPageRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersAboutYouPageTest#testDataNotSavedWhenNavigatedBackAboutYouPageRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersAboutYouPageTest.java","sourceLine":145,"className":"AceRentersAboutYouPageTest","method":"testDataNotSavedWhenNavigatedBackAboutYouPageRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersAboutYouPageTest#validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageRentersLob
  test("validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersAboutYouPageTest#validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersAboutYouPageTest.java","sourceLine":182,"className":"AceRentersAboutYouPageTest","method":"validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersAboutYouPageTest#aceRentersPEWCScreen
  test("aceRentersPEWCScreen", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersAboutYouPageTest#aceRentersPEWCScreen","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersAboutYouPageTest.java","sourceLine":210,"className":"AceRentersAboutYouPageTest","method":"aceRentersPEWCScreen","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{PEWC}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {PEWC})"});
  });

});
