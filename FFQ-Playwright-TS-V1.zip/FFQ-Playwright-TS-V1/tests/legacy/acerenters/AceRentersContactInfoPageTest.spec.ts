// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acerenters.AceRentersContactInfoPageTest", () => {
  // legacy-id: com.farmers.ffq.acerenters.AceRentersContactInfoPageTest#validateContactInfoPageRentersLob
  test("validateContactInfoPageRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersContactInfoPageTest#validateContactInfoPageRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersContactInfoPageTest.java","sourceLine":19,"className":"AceRentersContactInfoPageTest","method":"validateContactInfoPageRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersContactInfoPageTest#validateContactInfoPageErrorMessagesRentersLob
  test("validateContactInfoPageErrorMessagesRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersContactInfoPageTest#validateContactInfoPageErrorMessagesRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersContactInfoPageTest.java","sourceLine":39,"className":"AceRentersContactInfoPageTest","method":"validateContactInfoPageErrorMessagesRentersLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersContactInfoPageTest#validateFloorResidenceLocatedRentersLob
  test("validateFloorResidenceLocatedRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersContactInfoPageTest#validateFloorResidenceLocatedRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersContactInfoPageTest.java","sourceLine":49,"className":"AceRentersContactInfoPageTest","method":"validateFloorResidenceLocatedRentersLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersContactInfoPageTest#validateFWSInterstitialToBindableChoiceIntegrationRenters
  test("validateFWSInterstitialToBindableChoiceIntegrationRenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersContactInfoPageTest#validateFWSInterstitialToBindableChoiceIntegrationRenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersContactInfoPageTest.java","sourceLine":61,"className":"AceRentersContactInfoPageTest","method":"validateFWSInterstitialToBindableChoiceIntegrationRenters","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_BINDABLE_CHOICE, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, AL, ID, IL, IN, MO, NE, NM, OH, OK, SD, TX, TN, WI, WY})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersContactInfoPageTest#validateFWSInterstitialColpPageRenters
  test("validateFWSInterstitialColpPageRenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersContactInfoPageTest#validateFWSInterstitialColpPageRenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersContactInfoPageTest.java","sourceLine":81,"className":"AceRentersContactInfoPageTest","method":"validateFWSInterstitialColpPageRenters","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_COLP, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, AL, ID, IL, IN, MO, NE, NM, OH, OK, SD, TX, TN, WI, WY})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersContactInfoPageTest#validateFWSInterstitialQnBPageRenters
  test("validateFWSInterstitialQnBPageRenters", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersContactInfoPageTest#validateFWSInterstitialQnBPageRenters","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersContactInfoPageTest.java","sourceLine":98,"className":"AceRentersContactInfoPageTest","method":"validateFWSInterstitialQnBPageRenters","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_QNB, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, AL, ID, IL, IN, MO, NE, NM, OH, OK, SD, TX, TN, WI, WY})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE})"});
  });

});
