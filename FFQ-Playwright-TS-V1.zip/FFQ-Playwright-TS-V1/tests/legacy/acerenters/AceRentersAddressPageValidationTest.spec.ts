// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest", () => {
  // legacy-id: com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#validateRentersAddressPage
  test("validateRentersAddressPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#validateRentersAddressPage","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersAddressPageValidationTest.java","sourceLine":23,"className":"AceRentersAddressPageValidationTest","method":"validateRentersAddressPage","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_ADDRESS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#validateDataWhenNavigatedBackAndForthAddressPageRentersLob
  test("validateDataWhenNavigatedBackAndForthAddressPageRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#validateDataWhenNavigatedBackAndForthAddressPageRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersAddressPageValidationTest.java","sourceLine":41,"className":"AceRentersAddressPageValidationTest","method":"validateDataWhenNavigatedBackAndForthAddressPageRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#testFGIANotOfferingValidationRentersLob
  test.skip("testFGIANotOfferingValidationRentersLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#testFGIANotOfferingValidationRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersAddressPageValidationTest.java","sourceLine":70,"className":"AceRentersAddressPageValidationTest","method":"testFGIANotOfferingValidationRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {LA, MA, NC})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#testFGIALandingPageValidationRentersLob
  test.skip("testFGIALandingPageValidationRentersLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#testFGIALandingPageValidationRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersAddressPageValidationTest.java","sourceLine":91,"className":"AceRentersAddressPageValidationTest","method":"testFGIALandingPageValidationRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {LA, MA, NC})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#testDigitalMonetizationValidationNonAWSRentersLob
  test("testDigitalMonetizationValidationNonAWSRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#testDigitalMonetizationValidationNonAWSRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersAddressPageValidationTest.java","sourceLine":112,"className":"AceRentersAddressPageValidationTest","method":"testDigitalMonetizationValidationNonAWSRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_DIGITAL_MONETIZATION_NON_AWS, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {ME, MS, NH, NJ, NY, VT, WV})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#testDigitalMonetizationValidationAWSRentersLob
  test("testDigitalMonetizationValidationAWSRentersLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#testDigitalMonetizationValidationAWSRentersLob","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersAddressPageValidationTest.java","sourceLine":132,"className":"AceRentersAddressPageValidationTest","method":"testDigitalMonetizationValidationAWSRentersLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_DIGITAL_MONETIZATION_AWS, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {NJ, NY})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#validateLongCityNameAccepted
  test("validateLongCityNameAccepted", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acerenters.AceRentersAddressPageValidationTest#validateLongCityNameAccepted","domain":"acerenters","sourceFile":"src/test/java/com/farmers/ffq/acerenters/AceRentersAddressPageValidationTest.java","sourceLine":144,"className":"AceRentersAddressPageValidationTest","method":"validateLongCityNameAccepted","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_ADDRESS_PAGE})"});
  });

});
