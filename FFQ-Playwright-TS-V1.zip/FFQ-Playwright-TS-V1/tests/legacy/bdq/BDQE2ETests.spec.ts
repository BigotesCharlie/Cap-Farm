// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.bdq.BDQE2ETests", () => {
  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQOrganicFlowE2E_WithRandomPriorInsuranceBrightlineCondition
  test("testBDQOrganicFlowE2E_WithRandomPriorInsuranceBrightlineCondition", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQOrganicFlowE2E_WithRandomPriorInsuranceBrightlineCondition","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":28,"className":"BDQE2ETests","method":"testBDQOrganicFlowE2E_WithRandomPriorInsuranceBrightlineCondition","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQOrganicFlowE2E
  test("testBDQOrganicFlowE2E", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQOrganicFlowE2E","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":37,"className":"BDQE2ETests","method":"testBDQOrganicFlowE2E","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQOrganicFlowE2E_MultipleVehicleDriver
  test("testBDQOrganicFlowE2E_MultipleVehicleDriver", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQOrganicFlowE2E_MultipleVehicleDriver","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":46,"className":"BDQE2ETests","method":"testBDQOrganicFlowE2E_MultipleVehicleDriver","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=29\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQOrganicFlowE2E_MoreThanOneInjury
  test("testBDQOrganicFlowE2E_MoreThanOneInjury", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQOrganicFlowE2E_MoreThanOneInjury","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":53,"className":"BDQE2ETests","method":"testBDQOrganicFlowE2E_MoreThanOneInjury","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=17\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQOrganicFlowE2E_LessThan6Month
  test("testBDQOrganicFlowE2E_LessThan6Month", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQOrganicFlowE2E_LessThan6Month","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":64,"className":"BDQE2ETests","method":"testBDQOrganicFlowE2E_LessThan6Month","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=17\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E
  test("testBDQClickToBuyLiteFlowE2E", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":73,"className":"BDQE2ETests","method":"testBDQClickToBuyLiteFlowE2E","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E_WithRandomPriorInsuranceBrightlineCondition
  test("testBDQClickToBuyLiteFlowE2E_WithRandomPriorInsuranceBrightlineCondition", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E_WithRandomPriorInsuranceBrightlineCondition","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":82,"className":"BDQE2ETests","method":"testBDQClickToBuyLiteFlowE2E_WithRandomPriorInsuranceBrightlineCondition","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E_ForeignDriver
  test("testBDQClickToBuyLiteFlowE2E_ForeignDriver", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E_ForeignDriver","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":91,"className":"BDQE2ETests","method":"testBDQClickToBuyLiteFlowE2E_ForeignDriver","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E_MultipleVehicleDriver
  test("testBDQClickToBuyLiteFlowE2E_MultipleVehicleDriver", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E_MultipleVehicleDriver","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":100,"className":"BDQE2ETests","method":"testBDQClickToBuyLiteFlowE2E_MultipleVehicleDriver","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=29\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E_MoreThanOneInjury
  test("testBDQClickToBuyLiteFlowE2E_MoreThanOneInjury", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E_MoreThanOneInjury","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":107,"className":"BDQE2ETests","method":"testBDQClickToBuyLiteFlowE2E_MoreThanOneInjury","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=17\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E_LessThan6Month
  test("testBDQClickToBuyLiteFlowE2E_LessThan6Month", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E_LessThan6Month","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":118,"className":"BDQE2ETests","method":"testBDQClickToBuyLiteFlowE2E_LessThan6Month","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=17\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E
  test("testBDQClickToBuyFullFlowE2E", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":127,"className":"BDQE2ETests","method":"testBDQClickToBuyFullFlowE2E","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CT, FL, AZ, CO, GA, IA, ID, IL, KY, MI, MS, MT, NJ, OH, OR, PA, TN, TX, UT, VA, WA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E_WithRandomPriorInsuranceBrightlineCondition
  test("testBDQClickToBuyFullFlowE2E_WithRandomPriorInsuranceBrightlineCondition", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E_WithRandomPriorInsuranceBrightlineCondition","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":136,"className":"BDQE2ETests","method":"testBDQClickToBuyFullFlowE2E_WithRandomPriorInsuranceBrightlineCondition","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CT, FL, AZ, CO, GA, IA, ID, IL, KY, MI, MS, MT, NJ, OH, OR, PA, TN, TX, UT, VA, WA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E_ForeignDriver
  test("testBDQClickToBuyFullFlowE2E_ForeignDriver", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E_ForeignDriver","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":145,"className":"BDQE2ETests","method":"testBDQClickToBuyFullFlowE2E_ForeignDriver","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL}), @CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CT, FL, AZ, CO, GA, IA, ID, IL, KY, MI, MS, MT, NJ, OH, OR, PA, TN, TX, UT, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E_MultipleVehicleDriver
  test("testBDQClickToBuyFullFlowE2E_MultipleVehicleDriver", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E_MultipleVehicleDriver","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":154,"className":"BDQE2ETests","method":"testBDQClickToBuyFullFlowE2E_MultipleVehicleDriver","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=29\"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CT, FL, AZ, CO, GA, IA, ID, IL, KY, MI, MS, MT, NJ, OH, OR, PA, TN, TX, UT, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E_MoreThanOneInjury
  test("testBDQClickToBuyFullFlowE2E_MoreThanOneInjury", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E_MoreThanOneInjury","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":161,"className":"BDQE2ETests","method":"testBDQClickToBuyFullFlowE2E_MoreThanOneInjury","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=17\"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CT, FL, AZ, CO, GA, IA, ID, IL, KY, MI, MS, MT, NJ, OH, OR, PA, TN, TX, UT, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E_LessThan6Month
  test("testBDQClickToBuyFullFlowE2E_LessThan6Month", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E_LessThan6Month","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":172,"className":"BDQE2ETests","method":"testBDQClickToBuyFullFlowE2E_LessThan6Month","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=17\"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CT, FL, AZ, CO, GA, IA, ID, IL, KY, MI, MS, MT, NJ, OH, OR, PA, TN, TX, UT, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E
  test("testBDQMarkettingIdFlowE2E", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":181,"className":"BDQE2ETests","method":"testBDQMarkettingIdFlowE2E","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E_WithRandomPriorInsuranceBrightlineCondition
  test("testBDQMarkettingIdFlowE2E_WithRandomPriorInsuranceBrightlineCondition", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E_WithRandomPriorInsuranceBrightlineCondition","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":189,"className":"BDQE2ETests","method":"testBDQMarkettingIdFlowE2E_WithRandomPriorInsuranceBrightlineCondition","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E_ForeignDriver
  test("testBDQMarkettingIdFlowE2E_ForeignDriver", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E_ForeignDriver","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":198,"className":"BDQE2ETests","method":"testBDQMarkettingIdFlowE2E_ForeignDriver","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E_MultipleVehicleDriver
  test("testBDQMarkettingIdFlowE2E_MultipleVehicleDriver", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E_MultipleVehicleDriver","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":207,"className":"BDQE2ETests","method":"testBDQMarkettingIdFlowE2E_MultipleVehicleDriver","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=29\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E_MoreThanOneInjury
  test("testBDQMarkettingIdFlowE2E_MoreThanOneInjury", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E_MoreThanOneInjury","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":214,"className":"BDQE2ETests","method":"testBDQMarkettingIdFlowE2E_MoreThanOneInjury","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=17\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E_LessThan6Month
  test("testBDQMarkettingIdFlowE2E_LessThan6Month", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E_LessThan6Month","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":225,"className":"BDQE2ETests","method":"testBDQMarkettingIdFlowE2E_LessThan6Month","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=17\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQ_QuoteCustomizedFlow
  test("testBDQ_QuoteCustomizedFlow", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQ_QuoteCustomizedFlow","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":234,"className":"BDQE2ETests","method":"testBDQ_QuoteCustomizedFlow","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQ_E2E_PAY_IN_FULL
  test("testBDQ_E2E_PAY_IN_FULL", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQ_E2E_PAY_IN_FULL","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":241,"className":"BDQE2ETests","method":"testBDQ_E2E_PAY_IN_FULL","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQ_E2E_MONTHLY_AUTO_PAY_BANK
  test("testBDQ_E2E_MONTHLY_AUTO_PAY_BANK", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQ_E2E_MONTHLY_AUTO_PAY_BANK","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":248,"className":"BDQE2ETests","method":"testBDQ_E2E_MONTHLY_AUTO_PAY_BANK","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQ_E2E_MONTHLY_DIRECT_BILL
  test("testBDQ_E2E_MONTHLY_DIRECT_BILL", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQ_E2E_MONTHLY_DIRECT_BILL","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":255,"className":"BDQE2ETests","method":"testBDQ_E2E_MONTHLY_DIRECT_BILL","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQ_E2E_MONTHLY_AUTO_PAY_CARD
  test("testBDQ_E2E_MONTHLY_AUTO_PAY_CARD", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQ_E2E_MONTHLY_AUTO_PAY_CARD","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":262,"className":"BDQE2ETests","method":"testBDQ_E2E_MONTHLY_AUTO_PAY_CARD","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#bdqBindAdpf
  test("bdqBindAdpf", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#bdqBindAdpf","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":269,"className":"BDQE2ETests","method":"bdqBindAdpf","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.BIND_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.BIND_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQOrganicFlowE2E_TeslaSupport
  test("testBDQOrganicFlowE2E_TeslaSupport", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQOrganicFlowE2E_TeslaSupport","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":305,"className":"BDQE2ETests","method":"testBDQOrganicFlowE2E_TeslaSupport","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE","groups":"{BDQ_TESTS_TESLA}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS_TESLA})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E_TeslaSupport
  test("testBDQClickToBuyLiteFlowE2E_TeslaSupport", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyLiteFlowE2E_TeslaSupport","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":321,"className":"BDQE2ETests","method":"testBDQClickToBuyLiteFlowE2E_TeslaSupport","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE","groups":"{BDQ_TESTS_TESLA}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\") , @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS_TESLA})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E_TeslaSupport
  test("testBDQClickToBuyFullFlowE2E_TeslaSupport", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQClickToBuyFullFlowE2E_TeslaSupport","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":335,"className":"BDQE2ETests","method":"testBDQClickToBuyFullFlowE2E_TeslaSupport","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{BDQ_TESTS_TESLA}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS_TESLA})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E_TeslaSupport
  test("testBDQMarkettingIdFlowE2E_TeslaSupport", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQE2ETests#testBDQMarkettingIdFlowE2E_TeslaSupport","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQE2ETests.java","sourceLine":348,"className":"BDQE2ETests","method":"testBDQMarkettingIdFlowE2E_TeslaSupport","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{BDQ_TESTS_TESLA}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS_TESLA})"});
  });

});
