// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.bdq.BDQSpecificTests", () => {
  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#testBDQSpecificRequirements_OrganicFlow
  test("testBDQSpecificRequirements_OrganicFlow", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#testBDQSpecificRequirements_OrganicFlow","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":32,"className":"BDQSpecificTests","method":"testBDQSpecificRequirements_OrganicFlow","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#testBDQSpecificRequirements_Buy_Lite_Flow
  test("testBDQSpecificRequirements_Buy_Lite_Flow", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#testBDQSpecificRequirements_Buy_Lite_Flow","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":39,"className":"BDQSpecificTests","method":"testBDQSpecificRequirements_Buy_Lite_Flow","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#testBDQSpecificRequirements_Buy_Full_Flow
  test("testBDQSpecificRequirements_Buy_Full_Flow", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#testBDQSpecificRequirements_Buy_Full_Flow","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":46,"className":"BDQSpecificTests","method":"testBDQSpecificRequirements_Buy_Full_Flow","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = INCLUDED_STATES, values = {FL, AZ, CO, IA, IL, NJ, OR, PA, TN, TX, UT, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#testBDQSpecificRequirements_Marketing_ID_Flow
  test("testBDQSpecificRequirements_Marketing_ID_Flow", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#testBDQSpecificRequirements_Marketing_ID_Flow","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":53,"className":"BDQSpecificTests","method":"testBDQSpecificRequirements_Marketing_ID_Flow","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#testBDQRetrievalForNotRatedQuote
  test("testBDQRetrievalForNotRatedQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#testBDQRetrievalForNotRatedQuote","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":60,"className":"BDQSpecificTests","method":"testBDQRetrievalForNotRatedQuote","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#testBDQRetrievalForRatedQuote
  test("testBDQRetrievalForRatedQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#testBDQRetrievalForRatedQuote","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":83,"className":"BDQSpecificTests","method":"testBDQRetrievalForRatedQuote","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#validateMoreThanTwoInjuryGetsKO
  test.skip("validateMoreThanTwoInjuryGetsKO", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#validateMoreThanTwoInjuryGetsKO","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":112,"className":"BDQSpecificTests","method":"validateMoreThanTwoInjuryGetsKO","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=17\"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#validateDCMScreenIsNotShownWhenAlreadySubmitted
  test("validateDCMScreenIsNotShownWhenAlreadySubmitted", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#validateDCMScreenIsNotShownWhenAlreadySubmitted","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":141,"className":"BDQSpecificTests","method":"validateDCMScreenIsNotShownWhenAlreadySubmitted","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#validateBDQLandingPageNavigatesToPersonalInfoPage
  test.skip("validateBDQLandingPageNavigatesToPersonalInfoPage", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#validateBDQLandingPageNavigatesToPersonalInfoPage","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":157,"className":"BDQSpecificTests","method":"validateBDQLandingPageNavigatesToPersonalInfoPage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#validateRetrievalFromBindPages
  test("validateRetrievalFromBindPages", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#validateRetrievalFromBindPages","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":172,"className":"BDQSpecificTests","method":"validateRetrievalFromBindPages","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#validateJAFMTFieldsAreNotDisplayedAfterAlreadySubmitted
  test("validateJAFMTFieldsAreNotDisplayedAfterAlreadySubmitted", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#validateJAFMTFieldsAreNotDisplayedAfterAlreadySubmitted","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":219,"className":"BDQSpecificTests","method":"validateJAFMTFieldsAreNotDisplayedAfterAlreadySubmitted","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#validateAdjustmentPopUpShowsOnlyOnce
  test("validateAdjustmentPopUpShowsOnlyOnce", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#validateAdjustmentPopUpShowsOnlyOnce","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":252,"className":"BDQSpecificTests","method":"validateAdjustmentPopUpShowsOnlyOnce","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=29\"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#validateSherlockReportIsCalled
  test("validateSherlockReportIsCalled", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#validateSherlockReportIsCalled","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":276,"className":"BDQSpecificTests","method":"validateSherlockReportIsCalled","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = INCLUDED_STATES, values = {AR})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#validateRetrievalOfAlreadyBoughtQuote
  test("validateRetrievalOfAlreadyBoughtQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#validateRetrievalOfAlreadyBoughtQuote","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":296,"className":"BDQSpecificTests","method":"validateRetrievalOfAlreadyBoughtQuote","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{BDQ_TESTS}","annotation":"@Test(groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#validateOrderOfCoveragesSameAfterRetrieval
  test("validateOrderOfCoveragesSameAfterRetrieval", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#validateOrderOfCoveragesSameAfterRetrieval","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":309,"className":"BDQSpecificTests","method":"validateOrderOfCoveragesSameAfterRetrieval","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.bdq.BDQSpecificTests#testBdqCacheFunctionality
  test.skip("testBdqCacheFunctionality", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.bdq.BDQSpecificTests#testBdqCacheFunctionality","domain":"bdq","sourceFile":"src/test/java/com/farmers/ffq/bdq/BDQSpecificTests.java","sourceLine":346,"className":"BDQSpecificTests","method":"testBdqCacheFunctionality","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = INCLUDED_STATES, values = { TN, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, enabled = true)"});
  });

});
