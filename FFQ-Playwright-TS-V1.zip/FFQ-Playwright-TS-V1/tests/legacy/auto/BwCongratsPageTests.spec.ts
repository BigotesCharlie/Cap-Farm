// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.bind.bw.BwCongratsPageTests", () => {
  // legacy-id: com.farmers.ffq.auto.bind.bw.BwCongratsPageTests#bwValidateCongratsPage
  test("bwValidateCongratsPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.bind.bw.BwCongratsPageTests#bwValidateCongratsPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/bind/bw/BwCongratsPageTests.java","sourceLine":19,"className":"BwCongratsPageTests","method":"bwValidateCongratsPage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{BW_ACE_TESTS, BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {MT})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})"});
  });

});
