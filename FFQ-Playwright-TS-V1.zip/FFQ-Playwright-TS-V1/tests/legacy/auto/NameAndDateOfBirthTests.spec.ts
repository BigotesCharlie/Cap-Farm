// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.NameAndDateOfBirthTests', () => {
  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testErrorForMessageCharLimits
  test('testErrorForMessageCharLimits', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testErrorForMessageCharLimits',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 21,
      className: 'NameAndDateOfBirthTests',
      method: 'testErrorForMessageCharLimits',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{NAME_AND_DOB_ONEUI, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testErrorMessageNameAndDobOneUIAutoQuote
  test('testErrorMessageNameAndDobOneUIAutoQuote', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testErrorMessageNameAndDobOneUIAutoQuote',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 37,
      className: 'NameAndDateOfBirthTests',
      method: 'testErrorMessageNameAndDobOneUIAutoQuote',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{NAME_AND_DOB_ONEUI, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testNewTabForEnterprisePrivacyStatement
  test('testNewTabForEnterprisePrivacyStatement', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testNewTabForEnterprisePrivacyStatement',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 56,
      className: 'NameAndDateOfBirthTests',
      method: 'testNewTabForEnterprisePrivacyStatement',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{NAME_AND_DOB_ONEUI, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testNotAllowedCharactersOnDOBFields
  test('testNotAllowedCharactersOnDOBFields', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testNotAllowedCharactersOnDOBFields',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 70,
      className: 'NameAndDateOfBirthTests',
      method: 'testNotAllowedCharactersOnDOBFields',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{NAME_AND_DOB_ONEUI, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testNotAllowedCharactersOnFirstNameAndLastNameFields
  test('testNotAllowedCharactersOnFirstNameAndLastNameFields', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testNotAllowedCharactersOnFirstNameAndLastNameFields',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 78,
      className: 'NameAndDateOfBirthTests',
      method: 'testNotAllowedCharactersOnFirstNameAndLastNameFields',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{NAME_AND_DOB_ONEUI, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh
  test('testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 91,
      className: 'NameAndDateOfBirthTests',
      method: 'testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{NAME_AND_DOB_ONEUI, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testQuoteCreationRatingAndFieldUpdateReset
  test('testQuoteCreationRatingAndFieldUpdateReset', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testQuoteCreationRatingAndFieldUpdateReset',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 108,
      className: 'NameAndDateOfBirthTests',
      method: 'testQuoteCreationRatingAndFieldUpdateReset',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{NAME_AND_DOB_ONEUI, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testPersonalInfoPageTitleAndDisclaimers
  test('testPersonalInfoPageTitleAndDisclaimers', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testPersonalInfoPageTitleAndDisclaimers',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 121,
      className: 'NameAndDateOfBirthTests',
      method: 'testPersonalInfoPageTitleAndDisclaimers',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES',
      groups: '{NAME_AND_DOB_ONEUI, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {NJ,FL})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testNotAllowedCharactersOnDOBFields_BDQ
  test.skip('testNotAllowedCharactersOnDOBFields_BDQ', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testNotAllowedCharactersOnDOBFields_BDQ',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 134,
      className: 'NameAndDateOfBirthTests',
      method: 'testNotAllowedCharactersOnDOBFields_BDQ',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testNotAllowedCharactersOnFirstNameAndLastNameFields_BDQ
  test.skip('testNotAllowedCharactersOnFirstNameAndLastNameFields_BDQ', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testNotAllowedCharactersOnFirstNameAndLastNameFields_BDQ',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 143,
      className: 'NameAndDateOfBirthTests',
      method: 'testNotAllowedCharactersOnFirstNameAndLastNameFields_BDQ',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testErrorForMessageCharLimits_BDQ
  test.skip('testErrorForMessageCharLimits_BDQ', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testErrorForMessageCharLimits_BDQ',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 156,
      className: 'NameAndDateOfBirthTests',
      method: 'testErrorForMessageCharLimits_BDQ',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testErrorMessageNameAndDobOneUIAutoQuote_BDQ
  test.skip('testErrorMessageNameAndDobOneUIAutoQuote_BDQ', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testErrorMessageNameAndDobOneUIAutoQuote_BDQ',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 174,
      className: 'NameAndDateOfBirthTests',
      method: 'testErrorMessageNameAndDobOneUIAutoQuote_BDQ',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testNewTabForEnterprisePrivacyStatement_BDQ
  test.skip('testNewTabForEnterprisePrivacyStatement_BDQ', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testNewTabForEnterprisePrivacyStatement_BDQ',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 194,
      className: 'NameAndDateOfBirthTests',
      method: 'testNewTabForEnterprisePrivacyStatement_BDQ',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh_BDQ
  test.skip('testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh_BDQ', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.NameAndDateOfBirthTests#testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh_BDQ',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 209,
      className: 'NameAndDateOfBirthTests',
      method: 'testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh_BDQ',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testQuoteCreationRatingAndFieldUpdateReset_BDQ
  test.skip('testQuoteCreationRatingAndFieldUpdateReset_BDQ', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testQuoteCreationRatingAndFieldUpdateReset_BDQ',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 227,
      className: 'NameAndDateOfBirthTests',
      method: 'testQuoteCreationRatingAndFieldUpdateReset_BDQ',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.NameAndDateOfBirthTests#testPrivacyPolicy
  test('testPrivacyPolicy', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.NameAndDateOfBirthTests#testPrivacyPolicy',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/NameAndDateOfBirthTests.java',
      sourceLine: 248,
      className: 'NameAndDateOfBirthTests',
      method: 'testPrivacyPolicy',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{NAME_AND_DOB_ONEUI, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")})',
    });
  });
});
