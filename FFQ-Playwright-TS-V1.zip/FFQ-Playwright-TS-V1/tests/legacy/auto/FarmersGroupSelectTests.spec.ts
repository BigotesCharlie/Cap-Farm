// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.FarmersGroupSelectTests", () => {
  // legacy-id: com.farmers.ffq.auto.FarmersGroupSelectTests#testFarmersGroupSelectContent
  test("testFarmersGroupSelectContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.FarmersGroupSelectTests#testFarmersGroupSelectContent","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/FarmersGroupSelectTests.java","sourceLine":23,"className":"FarmersGroupSelectTests","method":"testFarmersGroupSelectContent","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, CT, MA, MS, NC, NV, CA}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")})"});
  });

  // legacy-id: com.farmers.ffq.auto.FarmersGroupSelectTests#testFarmersGroupSelectFunction
  test("testFarmersGroupSelectFunction", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.FarmersGroupSelectTests#testFarmersGroupSelectFunction","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/FarmersGroupSelectTests.java","sourceLine":43,"className":"FarmersGroupSelectTests","method":"testFarmersGroupSelectFunction","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MA, MS, NC, NV, CA}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")})"});
  });

  // legacy-id: com.farmers.ffq.auto.FarmersGroupSelectTests#redStatesFarmersGroupSelectPageValidation_F75337
  test.skip("redStatesFarmersGroupSelectPageValidation_F75337", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.FarmersGroupSelectTests#redStatesFarmersGroupSelectPageValidation_F75337","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/FarmersGroupSelectTests.java","sourceLine":65,"className":"FarmersGroupSelectTests","method":"redStatesFarmersGroupSelectPageValidation_F75337","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA})}, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.FarmersGroupSelectTests#validateFWSInterstitialToBindableChoiceIntegrationAuto
  test("validateFWSInterstitialToBindableChoiceIntegrationAuto", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.FarmersGroupSelectTests#validateFWSInterstitialToBindableChoiceIntegrationAuto","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/FarmersGroupSelectTests.java","sourceLine":78,"className":"FarmersGroupSelectTests","method":"validateFWSInterstitialToBindableChoiceIntegrationAuto","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, suiteName = \"FWS Interstitial To Bindable Choice Integration\", dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, WI, MO, TX, AL, IN, OH})})"});
  });

  // legacy-id: com.farmers.ffq.auto.FarmersGroupSelectTests#validateFWSInterstitialColpPageAuto
  test("validateFWSInterstitialColpPageAuto", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.FarmersGroupSelectTests#validateFWSInterstitialColpPageAuto","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/FarmersGroupSelectTests.java","sourceLine":106,"className":"FarmersGroupSelectTests","method":"validateFWSInterstitialColpPageAuto","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, suiteName = \"FWS Interstitial Colp Page Auto\", dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, WI, MO, TX, AL, IN, OH})})"});
  });

  // legacy-id: com.farmers.ffq.auto.FarmersGroupSelectTests#validateFWSPageDisplayedWithValidData
  test("validateFWSPageDisplayedWithValidData", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.FarmersGroupSelectTests#validateFWSPageDisplayedWithValidData","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/FarmersGroupSelectTests.java","sourceLine":143,"className":"FarmersGroupSelectTests","method":"validateFWSPageDisplayedWithValidData","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX, CA}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")})"});
  });

  // legacy-id: com.farmers.ffq.auto.FarmersGroupSelectTests#validateFWS_is_SuppressedWithMLB_SourceCode
  test("validateFWS_is_SuppressedWithMLB_SourceCode", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.FarmersGroupSelectTests#validateFWS_is_SuppressedWithMLB_SourceCode","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/FarmersGroupSelectTests.java","sourceLine":214,"className":"FarmersGroupSelectTests","method":"validateFWS_is_SuppressedWithMLB_SourceCode","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, BW_ACE_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, BW_ACE_TESTS}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")})"});
  });

});
