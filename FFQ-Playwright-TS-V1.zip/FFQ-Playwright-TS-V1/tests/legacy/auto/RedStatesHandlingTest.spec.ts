// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.RedStatesHandlingTest', () => {
  // legacy-id: com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyInsuredPage_F75337
  test.skip('validateCurrentlyInsuredPage_F75337', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyInsuredPage_F75337',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/RedStatesHandlingTest.java',
      sourceLine: 21,
      className: 'RedStatesHandlingTest',
      method: 'validateCurrentlyInsuredPage_F75337',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyInsuredValidEmployerWithDiscount_F75337
  test.skip('validateCurrentlyInsuredValidEmployerWithDiscount_F75337', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyInsuredValidEmployerWithDiscount_F75337',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/RedStatesHandlingTest.java',
      sourceLine: 32,
      className: 'RedStatesHandlingTest',
      method: 'validateCurrentlyInsuredValidEmployerWithDiscount_F75337',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyInsuredValidEmployerSkipDiscount_F75337
  test.skip('validateCurrentlyInsuredValidEmployerSkipDiscount_F75337', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyInsuredValidEmployerSkipDiscount_F75337',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/RedStatesHandlingTest.java',
      sourceLine: 48,
      className: 'RedStatesHandlingTest',
      method: 'validateCurrentlyInsuredValidEmployerSkipDiscount_F75337',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyInsuredValidEmployerSkipDiscount_SkipFGIA_F75337
  test.skip('validateCurrentlyInsuredValidEmployerSkipDiscount_SkipFGIA_F75337', async ({
    page,
    autoData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyInsuredValidEmployerSkipDiscount_SkipFGIA_F75337',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/RedStatesHandlingTest.java',
      sourceLine: 65,
      className: 'RedStatesHandlingTest',
      method: 'validateCurrentlyInsuredValidEmployerSkipDiscount_SkipFGIA_F75337',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyInsured_InValidEmployerWithDiscount_F75337
  test.skip('validateCurrentlyInsured_InValidEmployerWithDiscount_F75337', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyInsured_InValidEmployerWithDiscount_F75337',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/RedStatesHandlingTest.java',
      sourceLine: 82,
      className: 'RedStatesHandlingTest',
      method: 'validateCurrentlyInsured_InValidEmployerWithDiscount_F75337',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyNotInsured_ContinueWithBristolWest_OR_ContinueWithFGIA_F75337
  test.skip('validateCurrentlyNotInsured_ContinueWithBristolWest_OR_ContinueWithFGIA_F75337', async ({
    page,
    autoData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyNotInsured_ContinueWithBristolWest_OR_ContinueWithFGIA_F75337',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/RedStatesHandlingTest.java',
      sourceLine: 99,
      className: 'RedStatesHandlingTest',
      method: 'validateCurrentlyNotInsured_ContinueWithBristolWest_OR_ContinueWithFGIA_F75337',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyNotInsured_NOThanksBW_MonetizationPage_F75337
  test.skip('validateCurrentlyNotInsured_NOThanksBW_MonetizationPage_F75337', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.RedStatesHandlingTest#validateCurrentlyNotInsured_NOThanksBW_MonetizationPage_F75337',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/RedStatesHandlingTest.java',
      sourceLine: 133,
      className: 'RedStatesHandlingTest',
      method: 'validateCurrentlyNotInsured_NOThanksBW_MonetizationPage_F75337',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.RedStatesHandlingTest#validate_FL_ContinueWithBW_F75337
  test.skip('validate_FL_ContinueWithBW_F75337', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.RedStatesHandlingTest#validate_FL_ContinueWithBW_F75337',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/RedStatesHandlingTest.java',
      sourceLine: 159,
      className: 'RedStatesHandlingTest',
      method: 'validate_FL_ContinueWithBW_F75337',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = FL)}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.RedStatesHandlingTest#validate_FL_NoThanksBW_F75337
  test.skip('validate_FL_NoThanksBW_F75337', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.RedStatesHandlingTest#validate_FL_NoThanksBW_F75337',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/RedStatesHandlingTest.java',
      sourceLine: 177,
      className: 'RedStatesHandlingTest',
      method: 'validate_FL_NoThanksBW_F75337',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = FL)}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.RedStatesHandlingTest#validateRedirectionToBwInterstitialPage
  test('validateRedirectionToBwInterstitialPage', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.RedStatesHandlingTest#validateRedirectionToBwInterstitialPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/RedStatesHandlingTest.java',
      sourceLine: 197,
      className: 'RedStatesHandlingTest',
      method: 'validateRedirectionToBwInterstitialPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });
});
