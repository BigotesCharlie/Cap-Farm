// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA", () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_None_Unk
  test.skip("testDefaultCoverageValues_CA_None_Unk", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_None_Unk","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_CA.java","sourceLine":15,"className":"DefaultCoverageValuesTests_CA","method":"testDefaultCoverageValues_CA_None_Unk","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = CA)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_15K30K
  test("testDefaultCoverageValues_CA_15K30K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_15K30K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_CA.java","sourceLine":24,"className":"DefaultCoverageValuesTests_CA","method":"testDefaultCoverageValues_CA_15K30K","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"55\"})}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_20K40K
  test("testDefaultCoverageValues_CA_20K40K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_20K40K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_CA.java","sourceLine":29,"className":"DefaultCoverageValuesTests_CA","method":"testDefaultCoverageValues_CA_20K40K","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"56\"})}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_25K50K
  test("testDefaultCoverageValues_CA_25K50K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_25K50K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_CA.java","sourceLine":35,"className":"DefaultCoverageValuesTests_CA","method":"testDefaultCoverageValues_CA_25K50K","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"57\"})}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_30K60K
  test("testDefaultCoverageValues_CA_30K60K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_30K60K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_CA.java","sourceLine":40,"className":"DefaultCoverageValuesTests_CA","method":"testDefaultCoverageValues_CA_30K60K","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"58\"})}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_35K70K
  test("testDefaultCoverageValues_CA_35K70K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_35K70K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_CA.java","sourceLine":45,"className":"DefaultCoverageValuesTests_CA","method":"testDefaultCoverageValues_CA_35K70K","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"59\"})}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_50K100K
  test("testDefaultCoverageValues_CA_50K100K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_50K100K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_CA.java","sourceLine":50,"className":"DefaultCoverageValuesTests_CA","method":"testDefaultCoverageValues_CA_50K100K","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"60\"})}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_100K200K
  test("testDefaultCoverageValues_CA_100K200K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_100K200K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_CA.java","sourceLine":55,"className":"DefaultCoverageValuesTests_CA","method":"testDefaultCoverageValues_CA_100K200K","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"61\"})}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_100K300K
  test("testDefaultCoverageValues_CA_100K300K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_100K300K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_CA.java","sourceLine":60,"className":"DefaultCoverageValuesTests_CA","method":"testDefaultCoverageValues_CA_100K300K","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"62\"})}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_250K500K
  test("testDefaultCoverageValues_CA_250K500K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_250K500K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_CA.java","sourceLine":65,"className":"DefaultCoverageValuesTests_CA","method":"testDefaultCoverageValues_CA_250K500K","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"63\"})}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_500K500K
  test("testDefaultCoverageValues_CA_500K500K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_500K500K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_CA.java","sourceLine":70,"className":"DefaultCoverageValuesTests_CA","method":"testDefaultCoverageValues_CA_500K500K","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"64\"})}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_500K
  test("testDefaultCoverageValues_CA_500K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_CA_500K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_CA.java","sourceLine":75,"className":"DefaultCoverageValuesTests_CA","method":"testDefaultCoverageValues_CA_500K","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"65\"})}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_Non_ADPF_Defaults
  test("testDefaultCoverageValues_Non_ADPF_Defaults", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_CA#testDefaultCoverageValues_Non_ADPF_Defaults","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_CA.java","sourceLine":81,"className":"DefaultCoverageValuesTests_CA","method":"testDefaultCoverageValues_Non_ADPF_Defaults","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

});
