// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.BristolWestTests", () => {
  // legacy-id: com.farmers.ffq.auto.BristolWestTests#bwNeverHadInsuranceTest
  test("bwNeverHadInsuranceTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.BristolWestTests#bwNeverHadInsuranceTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/BristolWestTests.java","sourceLine":26,"className":"BristolWestTests","method":"bwNeverHadInsuranceTest","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, BW_TESTS}","annotation":"@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {\"testScenario=PNI never had insurance\"})}, groups = {REGRESSION, BW_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.BristolWestTests#bwInsuredLT6MonthsTest
  test("bwInsuredLT6MonthsTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.BristolWestTests#bwInsuredLT6MonthsTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/BristolWestTests.java","sourceLine":32,"className":"BristolWestTests","method":"bwInsuredLT6MonthsTest","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, BW_TESTS}","annotation":"@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {\"testScenario=PNI insured LT 6 months\"})}, groups = {REGRESSION, BW_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.BristolWestTests#bwExpiredInsuranceTest
  test("bwExpiredInsuranceTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.BristolWestTests#bwExpiredInsuranceTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/BristolWestTests.java","sourceLine":38,"className":"BristolWestTests","method":"bwExpiredInsuranceTest","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, BW_TESTS}","annotation":"@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {\"testScenario=PNI expired insurance\"})}, groups = {REGRESSION, BW_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.BristolWestTests#bwForeignDriverTest
  test("bwForeignDriverTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.BristolWestTests#bwForeignDriverTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/BristolWestTests.java","sourceLine":44,"className":"BristolWestTests","method":"bwForeignDriverTest","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, BW_TESTS}","annotation":"@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {\"testScenario=PNI foreign license\"})}, groups = {REGRESSION, BW_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.BristolWestTests#bwRideshareYesTest
  test("bwRideshareYesTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.BristolWestTests#bwRideshareYesTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/BristolWestTests.java","sourceLine":50,"className":"BristolWestTests","method":"bwRideshareYesTest","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, BW_TESTS}","annotation":"@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {\"testScenario=Rideshare vehicle\"})}, groups = {REGRESSION, BW_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.BristolWestTests#bwMoreThanOneInjuryTest
  test("bwMoreThanOneInjuryTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.BristolWestTests#bwMoreThanOneInjuryTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/BristolWestTests.java","sourceLine":63,"className":"BristolWestTests","method":"bwMoreThanOneInjuryTest","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, BW_TESTS}","annotation":"@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {\"testScenario=More than one injury\"})}, groups = {REGRESSION, BW_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.BristolWestTests#bwFinancialFilingTest
  test("bwFinancialFilingTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.BristolWestTests#bwFinancialFilingTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/BristolWestTests.java","sourceLine":69,"className":"BristolWestTests","method":"bwFinancialFilingTest","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, BW_TESTS}","annotation":"@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {\"testScenario=PNI financial filing\"})}, groups = {REGRESSION, BW_TESTS})"});
  });

});
