// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.VehiclesReviewTest', () => {
  // legacy-id: com.farmers.ffq.auto.VehiclesReviewTest#testVehicleReviewPage
  test('testVehicleReviewPage', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesReviewTest#testVehicleReviewPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesReviewTest.java',
      sourceLine: 22,
      className: 'VehiclesReviewTest',
      method: 'testVehicleReviewPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, VEHICLES_REVIEW_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, groups = {FFQ_ONEUI, VEHICLES_REVIEW_TEST})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesReviewTest#testValidateMaxOfFiveVehiclesInVehiclesReviewPage_VehiclesReviewTest
  test('testValidateMaxOfFiveVehiclesInVehiclesReviewPage_VehiclesReviewTest', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesReviewTest#testValidateMaxOfFiveVehiclesInVehiclesReviewPage_VehiclesReviewTest',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesReviewTest.java',
      sourceLine: 44,
      className: 'VehiclesReviewTest',
      method: 'testValidateMaxOfFiveVehiclesInVehiclesReviewPage_VehiclesReviewTest',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, VEHICLES_REVIEW_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=9"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLES_REVIEW_TEST})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesReviewTest#testValidateEditVehicleAndOpenSideSheetInVehiclesReviewPage_VehiclesReviewTest
  test('testValidateEditVehicleAndOpenSideSheetInVehiclesReviewPage_VehiclesReviewTest', async ({
    page,
    autoData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesReviewTest#testValidateEditVehicleAndOpenSideSheetInVehiclesReviewPage_VehiclesReviewTest',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesReviewTest.java',
      sourceLine: 52,
      className: 'VehiclesReviewTest',
      method: 'testValidateEditVehicleAndOpenSideSheetInVehiclesReviewPage_VehiclesReviewTest',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI,VEHICLES_REVIEW_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CO,MI,OR})}, groups = {FFQ_ONEUI,VEHICLES_REVIEW_TEST})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesReviewTest#testValidateYMMAndVINMaskedInVehiclesReviewPage_VehiclesReviewTest
  test('testValidateYMMAndVINMaskedInVehiclesReviewPage_VehiclesReviewTest', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesReviewTest#testValidateYMMAndVINMaskedInVehiclesReviewPage_VehiclesReviewTest',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesReviewTest.java',
      sourceLine: 58,
      className: 'VehiclesReviewTest',
      method: 'testValidateYMMAndVINMaskedInVehiclesReviewPage_VehiclesReviewTest',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, VEHICLES_REVIEW_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLES_REVIEW_TEST})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesReviewTest#testValidateDateOfPurchaseInVehiclesReviewPage_VehiclesReviewTest
  test('testValidateDateOfPurchaseInVehiclesReviewPage_VehiclesReviewTest', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesReviewTest#testValidateDateOfPurchaseInVehiclesReviewPage_VehiclesReviewTest',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesReviewTest.java',
      sourceLine: 68,
      className: 'VehiclesReviewTest',
      method: 'testValidateDateOfPurchaseInVehiclesReviewPage_VehiclesReviewTest',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{FFQ_ONEUI,VEHICLES_REVIEW_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CO,MI,OR})}, groups = {FFQ_ONEUI,VEHICLES_REVIEW_TEST})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesReviewTest#validateCommuteToggle_VehiclesReviewTest
  test.skip('validateCommuteToggle_VehiclesReviewTest', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesReviewTest#validateCommuteToggle_VehiclesReviewTest',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesReviewTest.java',
      sourceLine: 77,
      className: 'VehiclesReviewTest',
      method: 'validateCommuteToggle_VehiclesReviewTest',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{FFQ_ONEUI, ADA_SUITE, VEHICLES_REVIEW_TEST, ACE_AUTO_ADA_SUITE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CA)}, groups = {FFQ_ONEUI, ADA_SUITE, VEHICLES_REVIEW_TEST, ACE_AUTO_ADA_SUITE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesReviewTest#testValidateQuestionsInCommuteUnderVehiclesReviewPageForCAStateAndProceedToRate
  test('testValidateQuestionsInCommuteUnderVehiclesReviewPageForCAStateAndProceedToRate', async ({
    page,
    autoData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesReviewTest#testValidateQuestionsInCommuteUnderVehiclesReviewPageForCAStateAndProceedToRate',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesReviewTest.java',
      sourceLine: 86,
      className: 'VehiclesReviewTest',
      method: 'testValidateQuestionsInCommuteUnderVehiclesReviewPageForCAStateAndProceedToRate',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{FFQ_ONEUI, VEHICLES_REVIEW_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = @CustomAttribute(name = INCLUDED_STATES, values = {CA}), groups = {FFQ_ONEUI, VEHICLES_REVIEW_TEST})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesReviewTest#validateNotToShowAntiTheftRecoverySystemCheckbox_VA_VehiclesReviewTest
  test('validateNotToShowAntiTheftRecoverySystemCheckbox_VA_VehiclesReviewTest', async ({
    page,
    autoData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesReviewTest#validateNotToShowAntiTheftRecoverySystemCheckbox_VA_VehiclesReviewTest',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesReviewTest.java',
      sourceLine: 107,
      className: 'VehiclesReviewTest',
      method: 'validateNotToShowAntiTheftRecoverySystemCheckbox_VA_VehiclesReviewTest',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI, VEHICLES_REVIEW_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = VA)}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLES_REVIEW_TEST})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesReviewTest#validateNotToShowAlternativeFuelCheckbox_VehicleReviewScreen
  test('validateNotToShowAlternativeFuelCheckbox_VehicleReviewScreen', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesReviewTest#validateNotToShowAlternativeFuelCheckbox_VehicleReviewScreen',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesReviewTest.java',
      sourceLine: 119,
      className: 'VehiclesReviewTest',
      method: 'validateNotToShowAlternativeFuelCheckbox_VehicleReviewScreen',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, VEHICLES_REVIEW_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {KY, LA, MA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLES_REVIEW_TEST})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesReviewTest#validateOnlyVehicleSelectedOnHeresIsWhatWeHaveFoundIsDisplayed
  test('validateOnlyVehicleSelectedOnHeresIsWhatWeHaveFoundIsDisplayed', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesReviewTest#validateOnlyVehicleSelectedOnHeresIsWhatWeHaveFoundIsDisplayed',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesReviewTest.java',
      sourceLine: 130,
      className: 'VehiclesReviewTest',
      method: 'validateOnlyVehicleSelectedOnHeresIsWhatWeHaveFoundIsDisplayed',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.TWELVE_DRIVERS_AND_VEHICLES), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})',
    });
  });
});
