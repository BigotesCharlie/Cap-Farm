// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.e2e.QuoteE2ETests", () => {
  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#validateQuoteFlowWithSelectiveData
  test("validateQuoteFlowWithSelectiveData", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#validateQuoteFlowWithSelectiveData","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":26,"className":"QuoteE2ETests","method":"validateQuoteFlowWithSelectiveData","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, \"QuoteE2ESelective\"}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, \"QuoteE2ESelective\"})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#validateQuoteE2E_RandomSingle_Applicant_From_Each_State
  test("validateQuoteE2E_RandomSingle_Applicant_From_Each_State", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#validateQuoteE2E_RandomSingle_Applicant_From_Each_State","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":32,"className":"QuoteE2ETests","method":"validateQuoteE2E_RandomSingle_Applicant_From_Each_State","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE","groups":"{FFQ_ACE_AUTO_E2E, QUOTE_E2E}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, NC})}, groups = {FFQ_ACE_AUTO_E2E, QUOTE_E2E})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#validateQuoteFlowWithReleaseStatesAllApplicants
  test("validateQuoteFlowWithReleaseStatesAllApplicants", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#validateQuoteFlowWithReleaseStatesAllApplicants","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":44,"className":"QuoteE2ETests","method":"validateQuoteFlowWithReleaseStatesAllApplicants","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{\"partialRegression\"}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, groups = {\"partialRegression\"})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#validateQuoteFlowWithRandomSingleStateSingleApplicant
  test("validateQuoteFlowWithRandomSingleStateSingleApplicant", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#validateQuoteFlowWithRandomSingleStateSingleApplicant","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":50,"className":"QuoteE2ETests","method":"validateQuoteFlowWithRandomSingleStateSingleApplicant","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{SMOKE_ACE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#validateQuoteFlowWithRandomSingleStateWithMoreThanOneVehiclesAndTwoDrivers
  test("validateQuoteFlowWithRandomSingleStateWithMoreThanOneVehiclesAndTwoDrivers", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#validateQuoteFlowWithRandomSingleStateWithMoreThanOneVehiclesAndTwoDrivers","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":56,"className":"QuoteE2ETests","method":"validateQuoteFlowWithRandomSingleStateWithMoreThanOneVehiclesAndTwoDrivers","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE","groups":"{SMOKE_ACE, PRODUCTION_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=29\"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, MS, NV, TX})}, groups = {SMOKE_ACE, PRODUCTION_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#validateMultipleSimilarVehicles
  test("validateMultipleSimilarVehicles", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#validateMultipleSimilarVehicles","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":63,"className":"QuoteE2ETests","method":"validateMultipleSimilarVehicles","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, QUOTE_E2E}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_E2E})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#validateQuoteWithSingleVehSingleDriver
  test("validateQuoteWithSingleVehSingleDriver", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#validateQuoteWithSingleVehSingleDriver","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":78,"className":"QuoteE2ETests","method":"validateQuoteWithSingleVehSingleDriver","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE","groups":"{PRODUCTION_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, MS, NV, TX})}, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE, dataProviderClass = AutoDataProviders.class, groups = {PRODUCTION_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#validateLinksForAutoFlow
  test("validateLinksForAutoFlow", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#validateLinksForAutoFlow","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":90,"className":"QuoteE2ETests","method":"validateLinksForAutoFlow","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=34\"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, TX})}, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#validateAgentQuoteFlow
  test("validateAgentQuoteFlow", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#validateAgentQuoteFlow","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":108,"className":"QuoteE2ETests","method":"validateAgentQuoteFlow","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, \"agentFlow\"}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, \"agentFlow\"})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#validateJFMTShouldBeFinalPageToShowProgressbarInAceAuto
  test("validateJFMTShouldBeFinalPageToShowProgressbarInAceAuto", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#validateJFMTShouldBeFinalPageToShowProgressbarInAceAuto","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":131,"className":"QuoteE2ETests","method":"validateJFMTShouldBeFinalPageToShowProgressbarInAceAuto","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MI, CO, OR, KY}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, groups = {FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#validateProgressbarShouldPresentInAllScreensTillJFMTPage
  test("validateProgressbarShouldPresentInAllScreensTillJFMTPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#validateProgressbarShouldPresentInAllScreensTillJFMTPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":145,"className":"QuoteE2ETests","method":"validateProgressbarShouldPresentInAllScreensTillJFMTPage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CO, FL, MI, NJ, OR}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, groups = {FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#aceAutoEnvStabilityValidation
  test("aceAutoEnvStabilityValidation", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#aceAutoEnvStabilityValidation","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":157,"className":"QuoteE2ETests","method":"aceAutoEnvStabilityValidation","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{ACE_STABILITY}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, groups = {ACE_STABILITY})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#autoBDQPhoneNumberTest
  test("autoBDQPhoneNumberTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#autoBDQPhoneNumberTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":164,"className":"QuoteE2ETests","method":"autoBDQPhoneNumberTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, NC, NE}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, groups = {FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#autoBWPhoneNumberTest
  test("autoBWPhoneNumberTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#autoBWPhoneNumberTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":176,"className":"QuoteE2ETests","method":"autoBWPhoneNumberTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, NC}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, groups = {FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#autoFarmersPhoneNumberTest
  test("autoFarmersPhoneNumberTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#autoFarmersPhoneNumberTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":189,"className":"QuoteE2ETests","method":"autoFarmersPhoneNumberTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, groups = {FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.QuoteE2ETests#aceAutoEndToEndOneRandomApplicant
  test("aceAutoEndToEndOneRandomApplicant", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.QuoteE2ETests#aceAutoEndToEndOneRandomApplicant","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/QuoteE2ETests.java","sourceLine":202,"className":"QuoteE2ETests","method":"aceAutoEndToEndOneRandomApplicant","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ACE_STABILITY}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CO, FL, MI, NJ, OR}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, groups = {ACE_STABILITY})"});
  });

});
