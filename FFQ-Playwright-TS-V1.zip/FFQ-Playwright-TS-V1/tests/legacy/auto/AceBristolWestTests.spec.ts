// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.AceBristolWestTests", () => {
  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#bwPageValidationTests
  test("bwPageValidationTests", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#bwPageValidationTests","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":31,"className":"AceBristolWestTests","method":"bwPageValidationTests","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, CT, FL, ID, KS, MA, MI, MO, MS, NC, NE, NJ, NM, NV, NY, OK, PA, TN, VA, WA, OR})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#bwNeverHadInsuranceTest
  test("bwNeverHadInsuranceTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#bwNeverHadInsuranceTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":69,"className":"AceBristolWestTests","method":"bwNeverHadInsuranceTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, FL, ID, KS, MO, NJ, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#bwNeverHadInsuranceTestForProd
  test("bwNeverHadInsuranceTestForProd", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#bwNeverHadInsuranceTestForProd","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":80,"className":"AceBristolWestTests","method":"bwNeverHadInsuranceTestForProd","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE","groups":"{PRODUCTION_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, TX})}, dataProviderClass = AutoDataProviders.class, groups = {PRODUCTION_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#bwInsuredLT6MonthsTest
  test("bwInsuredLT6MonthsTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#bwInsuredLT6MonthsTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":92,"className":"AceBristolWestTests","method":"bwInsuredLT6MonthsTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CO, FL, ID, KS, MO, NC, NJ, NM, NV, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#bwExpiredInsuranceTest
  test("bwExpiredInsuranceTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#bwExpiredInsuranceTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":103,"className":"AceBristolWestTests","method":"bwExpiredInsuranceTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, FL, ID, KS, MA, MO, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#bwForeignDriverTest
  test("bwForeignDriverTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#bwForeignDriverTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":114,"className":"AceBristolWestTests","method":"bwForeignDriverTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, FL, ID, KS, MA, MO, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#validateAceBWInterstitialPageContent
  test.skip("validateAceBWInterstitialPageContent", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#validateAceBWInterstitialPageContent","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":130,"className":"AceBristolWestTests","method":"validateAceBWInterstitialPageContent","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#validateIfCustomerTakenToNJAceExperienceOnClickOfContinueCTAOnBWInterstitialPage
  test.skip("validateIfCustomerTakenToNJAceExperienceOnClickOfContinueCTAOnBWInterstitialPage", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#validateIfCustomerTakenToNJAceExperienceOnClickOfContinueCTAOnBWInterstitialPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":146,"className":"AceBristolWestTests","method":"validateIfCustomerTakenToNJAceExperienceOnClickOfContinueCTAOnBWInterstitialPage","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#validateFGIAInterstitialPageAndFarmersGeneralInsurancePageOnClickOfContinueToFGIACTA
  test.skip("validateFGIAInterstitialPageAndFarmersGeneralInsurancePageOnClickOfContinueToFGIACTA", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#validateFGIAInterstitialPageAndFarmersGeneralInsurancePageOnClickOfContinueToFGIACTA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":164,"className":"AceBristolWestTests","method":"validateFGIAInterstitialPageAndFarmersGeneralInsurancePageOnClickOfContinueToFGIACTA","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#createAutoQuoteAndEnsureBrightlineToBW
  test("createAutoQuoteAndEnsureBrightlineToBW", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#createAutoQuoteAndEnsureBrightlineToBW","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":179,"className":"AceBristolWestTests","method":"createAutoQuoteAndEnsureBrightlineToBW","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, FL, ID, KS, MO, NJ, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#testAutoQuoteStaysOnBWOnceBWScreenAccepted
  test("testAutoQuoteStaysOnBWOnceBWScreenAccepted", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#testAutoQuoteStaysOnBWOnceBWScreenAccepted","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":222,"className":"AceBristolWestTests","method":"testAutoQuoteStaysOnBWOnceBWScreenAccepted","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {MA, OR, AZ, CA, CO, FL, ID, KS, MO, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#testUserShouldGetFarmersQuoteIfBWConditionRemovedBeforeSwitchingToBW
  test("testUserShouldGetFarmersQuoteIfBWConditionRemovedBeforeSwitchingToBW", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#testUserShouldGetFarmersQuoteIfBWConditionRemovedBeforeSwitchingToBW","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":303,"className":"AceBristolWestTests","method":"testUserShouldGetFarmersQuoteIfBWConditionRemovedBeforeSwitchingToBW","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, FL, GA, ID, IL, KS, MO, NC, NM, OK, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#bwRideshareYesTest
  test("bwRideshareYesTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#bwRideshareYesTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":354,"className":"AceBristolWestTests","method":"bwRideshareYesTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {IL, OR, AZ, CA, CO, FL, ID, KS, MA, MO, NM, OK, PA, NJ, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#bwMoreThanOneInjuryTest
  test("bwMoreThanOneInjuryTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#bwMoreThanOneInjuryTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":380,"className":"AceBristolWestTests","method":"bwMoreThanOneInjuryTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=17\"}), @CustomAttribute(name = INCLUDED_STATES, values = {IL, AZ})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#bwFinancialFilingInStateTest
  test("bwFinancialFilingInStateTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#bwFinancialFilingInStateTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":402,"className":"AceBristolWestTests","method":"bwFinancialFilingInStateTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, ID, KS, MO, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#bwFinancialFilingInAnotherStateTest
  test("bwFinancialFilingInAnotherStateTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#bwFinancialFilingInAnotherStateTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":434,"className":"AceBristolWestTests","method":"bwFinancialFilingInAnotherStateTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, ID, KS, MO, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#validateNoBWFor_CA_State
  test("validateNoBWFor_CA_State", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#validateNoBWFor_CA_State","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":469,"className":"AceBristolWestTests","method":"validateNoBWFor_CA_State","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CA), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#bwDialogAtQuoteStartTest
  test("bwDialogAtQuoteStartTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#bwDialogAtQuoteStartTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":487,"className":"AceBristolWestTests","method":"bwDialogAtQuoteStartTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = FL)}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#validateAggregators_F90017
  test("validateAggregators_F90017", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#validateAggregators_F90017","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":515,"className":"AceBristolWestTests","method":"validateAggregators_F90017","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BW_ACE_TESTS, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = INCLUDED_STATES, values = {CO, MI, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#validateBwHomeOrRentersDiscount
  test("validateBwHomeOrRentersDiscount", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#validateBwHomeOrRentersDiscount","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":566,"className":"AceBristolWestTests","method":"validateBwHomeOrRentersDiscount","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BW_ACE_TESTS, BRISTOL_WEST_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, ID, KS, MO, NC, NM, OK, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BRISTOL_WEST_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#validateBDQClick2BuyCustomerDataAndValidVinForNJState
  test("validateBDQClick2BuyCustomerDataAndValidVinForNJState", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#validateBDQClick2BuyCustomerDataAndValidVinForNJState","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":608,"className":"AceBristolWestTests","method":"validateBDQClick2BuyCustomerDataAndValidVinForNJState","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"BDQ_TESTS","annotation":"@Test(groups = BDQ_TESTS)"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#validateVinErrorMessageForBWRateFailureAndContinueWithValidVin
  test("validateVinErrorMessageForBWRateFailureAndContinueWithValidVin", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#validateVinErrorMessageForBWRateFailureAndContinueWithValidVin","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":663,"className":"AceBristolWestTests","method":"validateVinErrorMessageForBWRateFailureAndContinueWithValidVin","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BW_ACE_TESTS, BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=36\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, ID, KS, MO, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AceBristolWestTests#validateVinErrorMessageWithOneVinOneYMM
  test("validateVinErrorMessageWithOneVinOneYMM", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AceBristolWestTests#validateVinErrorMessageWithOneVinOneYMM","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AceBristolWestTests.java","sourceLine":743,"className":"AceBristolWestTests","method":"validateVinErrorMessageWithOneVinOneYMM","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BW_ACE_TESTS, BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=36\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, ID, KS, MO, NC, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})"});
  });

});
