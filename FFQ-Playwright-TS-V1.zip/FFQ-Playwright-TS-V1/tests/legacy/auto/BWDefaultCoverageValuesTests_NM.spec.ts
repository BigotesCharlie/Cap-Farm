// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM', () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_None_Unk_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_None_Unk_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_None_Unk_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 13,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_None_Unk_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_15K30K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_15K30K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_15K30K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 22,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_15K30K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_20K40K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_20K40K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_20K40K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 29,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_20K40K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_25K50K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_25K50K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_25K50K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 36,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_25K50K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_30K60K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_30K60K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_30K60K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 44,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_30K60K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_35K70K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_35K70K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_35K70K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 51,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_35K70K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_50K100K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_50K100K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_50K100K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 58,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_50K100K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_100K200K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_100K200K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_100K200K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 65,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_100K200K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_100K300K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_100K300K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_100K300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 72,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_100K300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_300K300K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_300K300K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_300K300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 79,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_300K300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_250K500K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_250K500K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_250K500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 87,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_250K500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_500K500K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_500K500K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_500K500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 94,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_500K500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_500K1000K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_500K1000K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_500K1000K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 101,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_500K1000K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_1000K1000K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_1000K1000K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_1000K1000K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 109,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_1000K1000K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_50K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_50K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_50K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 116,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_50K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_75K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_75K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_75K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 123,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_75K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_100K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_100K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_100K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 130,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_100K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_200K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_200K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_200K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 138,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_200K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_300K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_300K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 146,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_500K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_500K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 153,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_1000K_NO_UMBRELLA
  test('testDefaultCoverageValues_NM_1000K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_NM#testDefaultCoverageValues_NM_1000K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_NM.java',
      sourceLine: 160,
      className: 'BWDefaultCoverageValuesTests_NM',
      method: 'testDefaultCoverageValues_NM_1000K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });
});
