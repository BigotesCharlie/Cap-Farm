// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA', () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_None_Unk_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_None_Unk_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_None_Unk_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 13,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_None_Unk_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_15K_30K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_15K_30K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_15K_30K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 22,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_15K_30K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_20K_40K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_20K_40K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_20K_40K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 30,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_20K_40K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_25K_50K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_25K_50K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_25K_50K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 38,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_25K_50K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_25K_65K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_25K_65K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_25K_65K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 46,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_25K_65K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_30K_60K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_30K_60K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_30K_60K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 54,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_30K_60K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_30K_65K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_30K_65K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_30K_65K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 62,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_30K_65K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_35K_70K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_35K_70K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_35K_70K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 70,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_35K_70K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_35K_80K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_35K_80K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_35K_80K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 78,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_35K_80K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_50K_100K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_50K_100K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_50K_100K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 86,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_50K_100K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_100K_200K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_100K_200K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_100K_200K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 94,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_100K_200K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_100K_300K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_100K_300K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_100K_300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 102,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_100K_300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_150K_300K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_150K_300K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_150K_300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 110,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_150K_300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_250K_500K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_250K_500K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_250K_500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 118,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_250K_500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_300K_300K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_300K_300K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_300K_300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 126,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_300K_300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_500K_500K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_500K_500K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_500K_500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 134,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_500K_500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_500K_1000K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_500K_1000K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_500K_1000K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 142,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_500K_1000K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_1000K_1000K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_1000K_1000K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_1000K_1000K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 150,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_1000K_1000K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_35K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_35K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_35K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 158,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_35K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_45K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_45K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_45K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 166,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_45K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_50K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_50K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_50K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 174,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_50K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_60K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_60K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_60K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 182,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_60K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_75K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_75K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_75K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 190,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_75K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_85K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_85K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_85K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 198,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_85K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_100K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_100K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_100K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 206,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_100K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_200K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_200K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_200K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 214,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_200K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_300K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_300K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 222,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_500K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_500K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 230,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_1000K_NO_UMBRELLA
  test('testDefaultCoverageValues_PA_1000K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_PA#testDefaultCoverageValues_PA_1000K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_PA.java',
      sourceLine: 238,
      className: 'BWDefaultCoverageValuesTests_PA',
      method: 'testDefaultCoverageValues_PA_1000K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });
});
