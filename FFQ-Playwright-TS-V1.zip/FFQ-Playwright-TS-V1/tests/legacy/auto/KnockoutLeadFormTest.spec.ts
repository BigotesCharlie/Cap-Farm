// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.KnockoutLeadFormTest", () => {
  // legacy-id: com.farmers.ffq.auto.KnockoutLeadFormTest#validateKnockoutLeadFormPage
  test.skip("validateKnockoutLeadFormPage", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutLeadFormTest#validateKnockoutLeadFormPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutLeadFormTest.java","sourceLine":19,"className":"KnockoutLeadFormTest","method":"validateKnockoutLeadFormPage","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{FFQ_ONEUI, KNOCKOUT_LEAD_FORM}","annotation":"@Test(groups = {FFQ_ONEUI, KNOCKOUT_LEAD_FORM}, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutLeadFormTest#validateKnockoutLeadFormFlow
  test("validateKnockoutLeadFormFlow", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutLeadFormTest#validateKnockoutLeadFormFlow","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutLeadFormTest.java","sourceLine":33,"className":"KnockoutLeadFormTest","method":"validateKnockoutLeadFormFlow","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, KNOCKOUT_LEAD_FORM}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MI}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, KNOCKOUT_LEAD_FORM})"});
  });

});
