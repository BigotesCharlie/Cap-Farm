// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MD", () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MD#testDefaultCoverageValues_MD_30K60K_NO_UMBRELLA
  test("testDefaultCoverageValues_MD_30K60K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MD#testDefaultCoverageValues_MD_30K60K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MD.java","sourceLine":12,"className":"DefaultCoverageValuesTests_MD","method":"testDefaultCoverageValues_MD_30K60K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MD)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MD#testDefaultCoverageValues_MD_50K100K_NO_UMBRELLA
  test("testDefaultCoverageValues_MD_50K100K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MD#testDefaultCoverageValues_MD_50K100K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MD.java","sourceLine":18,"className":"DefaultCoverageValuesTests_MD","method":"testDefaultCoverageValues_MD_50K100K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MD)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MD#testDefaultCoverageValues_MD_100K300K_NO_UMBRELLA
  test("testDefaultCoverageValues_MD_100K300K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MD#testDefaultCoverageValues_MD_100K300K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MD.java","sourceLine":24,"className":"DefaultCoverageValuesTests_MD","method":"testDefaultCoverageValues_MD_100K300K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MD)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MD#testDefaultCoverageValues_MD_250K500K_NO_UMBRELLA
  test("testDefaultCoverageValues_MD_250K500K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MD#testDefaultCoverageValues_MD_250K500K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MD.java","sourceLine":30,"className":"DefaultCoverageValuesTests_MD","method":"testDefaultCoverageValues_MD_250K500K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MD)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MD#testDefaultCoverageValues_MD_500K500K_NO_UMBRELLA
  test("testDefaultCoverageValues_MD_500K500K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MD#testDefaultCoverageValues_MD_500K500K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MD.java","sourceLine":36,"className":"DefaultCoverageValuesTests_MD","method":"testDefaultCoverageValues_MD_500K500K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MD)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

});
