// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests', () => {
  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testWhoShouldWeInsurePageSaveQuote
  test('testWhoShouldWeInsurePageSaveQuote', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testWhoShouldWeInsurePageSaveQuote',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 33,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'testWhoShouldWeInsurePageSaveQuote',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, BDQ_TESTS, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = { }), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testVehiclesPageSaveQuote
  test('testVehiclesPageSaveQuote', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testVehiclesPageSaveQuote',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 65,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'testVehiclesPageSaveQuote',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, BDQ_TESTS, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testDriversPageSaveQuote
  test('testDriversPageSaveQuote', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testDriversPageSaveQuote',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 79,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'testDriversPageSaveQuote',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, BDQ_TESTS, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testContactInfoPageSaveQuote
  test('testContactInfoPageSaveQuote', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testContactInfoPageSaveQuote',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 94,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'testContactInfoPageSaveQuote',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, BDQ_TESTS, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testQuoteSummaryPageDefaultSaveQuote
  test('testQuoteSummaryPageDefaultSaveQuote', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testQuoteSummaryPageDefaultSaveQuote',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 109,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'testQuoteSummaryPageDefaultSaveQuote',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testQuoteSummaryPagePayInFullSaveQuote
  test('testQuoteSummaryPagePayInFullSaveQuote', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testQuoteSummaryPagePayInFullSaveQuote',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 121,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'testQuoteSummaryPagePayInFullSaveQuote',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testRetrieveNonRatedQuoteWithQuoteNumber
  test('testRetrieveNonRatedQuoteWithQuoteNumber', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testRetrieveNonRatedQuoteWithQuoteNumber',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 135,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'testRetrieveNonRatedQuoteWithQuoteNumber',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testRetrieveRatedQuoteWithQuoteNumber
  test('testRetrieveRatedQuoteWithQuoteNumber', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testRetrieveRatedQuoteWithQuoteNumber',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 152,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'testRetrieveRatedQuoteWithQuoteNumber',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testRetrieveNonRatedQuoteWitEmailId
  test('testRetrieveNonRatedQuoteWitEmailId', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testRetrieveNonRatedQuoteWitEmailId',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 183,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'testRetrieveNonRatedQuoteWitEmailId',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA, NJ, FL})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testRetrieveRatedQuoteWitEmailId
  test('testRetrieveRatedQuoteWitEmailId', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testRetrieveRatedQuoteWitEmailId',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 207,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'testRetrieveRatedQuoteWitEmailId',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateBindAfterRatedQuoteRetrieval
  test('validateBindAfterRatedQuoteRetrieval', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateBindAfterRatedQuoteRetrieval',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 230,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'validateBindAfterRatedQuoteRetrieval',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT',
      groups: '{FFQ_ONEUI, SAVE_AND_RETRIEVE, FFQ_BIND_BANKPAYMENT_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, WA, PA, AZ, KS, IL, OR, NM, IA, WI, AR, CO, ID, NE})}, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE, FFQ_BIND_BANKPAYMENT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testReRateAfterRetrievalAndChange
  test('testReRateAfterRetrievalAndChange', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#testReRateAfterRetrievalAndChange',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 280,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'testReRateAfterRetrievalAndChange',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, CO, MI, CO, OR})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateUserIsAbleToGetRateAfterRetrieval_ADPF
  test('validateUserIsAbleToGetRateAfterRetrieval_ADPF', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateUserIsAbleToGetRateAfterRetrieval_ADPF',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 318,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'validateUserIsAbleToGetRateAfterRetrieval_ADPF',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI, SAVE_AND_RETRIEVE, HERE_IS_WHAT_WE_HAVE_FOUND}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.ONE_TO_FIVE_VEHICLES)}, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE, HERE_IS_WHAT_WE_HAVE_FOUND})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateAgeOfPNIisNotMissingWithRetrievalQuote
  test('validateAgeOfPNIisNotMissingWithRetrievalQuote', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateAgeOfPNIisNotMissingWithRetrievalQuote',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 364,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'validateAgeOfPNIisNotMissingWithRetrievalQuote',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{SAVE_AND_RETRIEVE, BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {NJ})}, groups = {SAVE_AND_RETRIEVE, BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateRetrievalWhenDroppedBeforeRate_BW
  test('validateRetrievalWhenDroppedBeforeRate_BW', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateRetrievalWhenDroppedBeforeRate_BW',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 398,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'validateRetrievalWhenDroppedBeforeRate_BW',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{SAVE_AND_RETRIEVE, BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MA, FL, NJ})}, groups = {SAVE_AND_RETRIEVE, BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateBDQRetrieval
  test('validateBDQRetrieval', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateBDQRetrieval',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 424,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'validateBDQRetrieval',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BDQ_TESTS, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateBwRetrieval
  test('validateBwRetrieval', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateBwRetrieval',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 437,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'validateBwRetrieval',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, BDQ_TESTS, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateUserLandsOnNewRetrievalPageWithSameZipCode_Farmers
  test('validateUserLandsOnNewRetrievalPageWithSameZipCode_Farmers', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateUserLandsOnNewRetrievalPageWithSameZipCode_Farmers',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 464,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'validateUserLandsOnNewRetrievalPageWithSameZipCode_Farmers',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES',
      groups: '{BW_ACE_TESTS, BDQ_TESTS, FFQ_ONEUI, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {GA, IL, TX, VA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS, FFQ_ONEUI, SAVE_AND_RETRIEVE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateUserLandsOnNewRetrievalPageWithSameZipCode_BW
  test('validateUserLandsOnNewRetrievalPageWithSameZipCode_BW', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.AutoSaveAndRetrieveQuoteTests#validateUserLandsOnNewRetrievalPageWithSameZipCode_BW',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoSaveAndRetrieveQuoteTests.java',
      sourceLine: 505,
      className: 'AutoSaveAndRetrieveQuoteTests',
      method: 'validateUserLandsOnNewRetrievalPageWithSameZipCode_BW',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES',
      groups: '{BW_ACE_TESTS, BDQ_TESTS, SAVE_AND_RETRIEVE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {TX, IL})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS, SAVE_AND_RETRIEVE})',
    });
  });
});
