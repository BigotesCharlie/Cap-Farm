// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.bind.BindOneUIBackAndForthValidation", () => {
  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIBackAndForthValidation#bindOneUIEndToEndBackAndForthValidation
  test.skip("bindOneUIEndToEndBackAndForthValidation", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.bind.BindOneUIBackAndForthValidation#bindOneUIEndToEndBackAndForthValidation","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/bind/BindOneUIBackAndForthValidation.java","sourceLine":21,"className":"BindOneUIBackAndForthValidation","method":"bindOneUIEndToEndBackAndForthValidation","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT","groups":"{FFQ_ONEUI, FFQ_BIND_BACKANDFORTH}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BACKANDFORTH}, enabled = false)"});
  });

});
