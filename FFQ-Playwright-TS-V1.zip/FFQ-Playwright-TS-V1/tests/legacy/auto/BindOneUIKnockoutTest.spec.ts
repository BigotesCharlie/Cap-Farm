// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.bind.BindOneUIKnockoutTest", () => {
  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIKnockoutTest#bitMoreInfoAboutVehicleKnockOutValidation
  test("bitMoreInfoAboutVehicleKnockOutValidation", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.bind.BindOneUIKnockoutTest#bitMoreInfoAboutVehicleKnockOutValidation","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/bind/BindOneUIKnockoutTest.java","sourceLine":20,"className":"BindOneUIKnockoutTest","method":"bitMoreInfoAboutVehicleKnockOutValidation","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, FFQ_BIND_VEHICLE_KNOCKOUT}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, suiteName = \"lender knockout\", groups = {FFQ_ONEUI, FFQ_BIND_VEHICLE_KNOCKOUT})"});
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIKnockoutTest#otherLenderKnockOutValidation
  test("otherLenderKnockOutValidation", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.bind.BindOneUIKnockoutTest#otherLenderKnockOutValidation","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/bind/BindOneUIKnockoutTest.java","sourceLine":60,"className":"BindOneUIKnockoutTest","method":"otherLenderKnockOutValidation","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, FFQ_BIND_LENDER_KNOCKOUT}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, suiteName = \"lender knockout\", groups = {FFQ_ONEUI, FFQ_BIND_LENDER_KNOCKOUT})"});
  });

});
