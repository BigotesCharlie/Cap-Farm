// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_GA", () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_GA#BW_testDefaultCoverageValues_GA_100K300K
  test("BW_testDefaultCoverageValues_GA_100K300K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_GA#BW_testDefaultCoverageValues_GA_100K300K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_GA.java","sourceLine":13,"className":"BWDefaultCoverageValuesTests_GA","method":"BW_testDefaultCoverageValues_GA_100K300K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{AUTO_COVERAGE_VALIDATION, BW_ACE_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = GA), @CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, groups = {AUTO_COVERAGE_VALIDATION, BW_ACE_TESTS})"});
  });

});
