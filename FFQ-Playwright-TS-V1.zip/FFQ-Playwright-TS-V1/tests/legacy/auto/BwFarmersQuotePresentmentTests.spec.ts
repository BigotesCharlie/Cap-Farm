// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.BwFarmersQuotePresentmentTests', () => {
  // legacy-id: com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testBwFarmersQuotePresentmentPageContent
  test.skip('testBwFarmersQuotePresentmentPageContent', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testBwFarmersQuotePresentmentPageContent',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/BwFarmersQuotePresentmentTests.java',
      sourceLine: 24,
      className: 'BwFarmersQuotePresentmentTests',
      method: 'testBwFarmersQuotePresentmentPageContent',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{"bwFarmersQuotePresentment", FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testRideShareDoesNotGetQuotePresentmentPage
  test.skip('testRideShareDoesNotGetQuotePresentmentPage', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testRideShareDoesNotGetQuotePresentmentPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/BwFarmersQuotePresentmentTests.java',
      sourceLine: 42,
      className: 'BwFarmersQuotePresentmentTests',
      method: 'testRideShareDoesNotGetQuotePresentmentPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{"bwFarmersQuotePresentment", FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#test500K_500K_DoesNotGetQuotePresentmentPage
  test.skip('test500K_500K_DoesNotGetQuotePresentmentPage', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#test500K_500K_DoesNotGetQuotePresentmentPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/BwFarmersQuotePresentmentTests.java',
      sourceLine: 65,
      className: 'BwFarmersQuotePresentmentTests',
      method: 'test500K_500K_DoesNotGetQuotePresentmentPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{"bwFarmersQuotePresentment", FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testOnceRenderedDoesNotShowQuotePresentmentPageAfterNavigationBack
  test.skip('testOnceRenderedDoesNotShowQuotePresentmentPageAfterNavigationBack', async ({
    page,
    autoData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testOnceRenderedDoesNotShowQuotePresentmentPageAfterNavigationBack',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/BwFarmersQuotePresentmentTests.java',
      sourceLine: 91,
      className: 'BwFarmersQuotePresentmentTests',
      method: 'testOnceRenderedDoesNotShowQuotePresentmentPageAfterNavigationBack',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{"bwFarmersQuotePresentment", FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testRetrievedQuoteLandsOnAlreadySelectedProduct
  test.skip('testRetrievedQuoteLandsOnAlreadySelectedProduct', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testRetrievedQuoteLandsOnAlreadySelectedProduct',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/BwFarmersQuotePresentmentTests.java',
      sourceLine: 131,
      className: 'BwFarmersQuotePresentmentTests',
      method: 'testRetrievedQuoteLandsOnAlreadySelectedProduct',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{"bwFarmersQuotePresentment", FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testFarmersSelectionAndBind
  test.skip('testFarmersSelectionAndBind', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testFarmersSelectionAndBind',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/BwFarmersQuotePresentmentTests.java',
      sourceLine: 164,
      className: 'BwFarmersQuotePresentmentTests',
      method: 'testFarmersSelectionAndBind',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{"bwFarmersQuotePresentment", FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testBWSelectionAndBind
  test.skip('testBWSelectionAndBind', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testBWSelectionAndBind',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/BwFarmersQuotePresentmentTests.java',
      sourceLine: 178,
      className: 'BwFarmersQuotePresentmentTests',
      method: 'testBWSelectionAndBind',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{"bwFarmersQuotePresentment", FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testReverseBrigthlineShouldWorkTheSame
  test.skip('testReverseBrigthlineShouldWorkTheSame', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testReverseBrigthlineShouldWorkTheSame',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/BwFarmersQuotePresentmentTests.java',
      sourceLine: 190,
      className: 'BwFarmersQuotePresentmentTests',
      method: 'testReverseBrigthlineShouldWorkTheSame',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{"bwFarmersQuotePresentment", FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testFarmersPremiumAmounts
  test.skip('testFarmersPremiumAmounts', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testFarmersPremiumAmounts',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/BwFarmersQuotePresentmentTests.java',
      sourceLine: 203,
      className: 'BwFarmersQuotePresentmentTests',
      method: 'testFarmersPremiumAmounts',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{"bwFarmersQuotePresentment", FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testBwPremiumAmounts
  test.skip('testBwPremiumAmounts', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testBwPremiumAmounts',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/BwFarmersQuotePresentmentTests.java',
      sourceLine: 224,
      className: 'BwFarmersQuotePresentmentTests',
      method: 'testBwPremiumAmounts',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{"bwFarmersQuotePresentment", FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testBrightlinedUserShouldNotGetQuotePresentmentPage
  test.skip('testBrightlinedUserShouldNotGetQuotePresentmentPage', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.BwFarmersQuotePresentmentTests#testBrightlinedUserShouldNotGetQuotePresentmentPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/BwFarmersQuotePresentmentTests.java',
      sourceLine: 244,
      className: 'BwFarmersQuotePresentmentTests',
      method: 'testBrightlinedUserShouldNotGetQuotePresentmentPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{"bwFarmersQuotePresentment", FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)',
    });
  });
});
