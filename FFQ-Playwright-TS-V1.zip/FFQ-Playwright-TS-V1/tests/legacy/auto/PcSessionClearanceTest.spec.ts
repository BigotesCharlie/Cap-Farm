// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.PcSessionClearanceTest', () => {
  // legacy-id: com.farmers.ffq.auto.PcSessionClearanceTest#clearInactiveUserSessionsInPC
  test('clearInactiveUserSessionsInPC', async ({ page, inlineData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, inlineData, {
      legacyId: 'com.farmers.ffq.auto.PcSessionClearanceTest#clearInactiveUserSessionsInPC',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/PcSessionClearanceTest.java',
      sourceLine: 11,
      className: 'PcSessionClearanceTest',
      method: 'clearInactiveUserSessionsInPC',
      parameters: '',
      dataProvider: '',
      dataProviderClass: '',
      testName: '',
      groups: '{"pcSessionClear"}',
      annotation: '@Test(groups = {"pcSessionClear"})',
    });
  });
});
