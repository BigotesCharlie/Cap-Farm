// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.KnockoutTests", () => {
  // legacy-id: com.farmers.ffq.auto.KnockoutTests#testExistingCustomerKnockout
  test("testExistingCustomerKnockout", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#testExistingCustomerKnockout","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":37,"className":"KnockoutTests","method":"testExistingCustomerKnockout","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{KNOCKOUT_TESTS, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, suiteName = \"existing customer knockout\", dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI}, enabled = true)"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#testRestrictedZipCodeSpecialAttention
  test.skip("testRestrictedZipCodeSpecialAttention", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#testRestrictedZipCodeSpecialAttention","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":52,"className":"KnockoutTests","method":"testRestrictedZipCodeSpecialAttention","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{KNOCKOUT_TESTS, FFQ_ONEUI}","annotation":"@Test(groups = {KNOCKOUT_TESTS, FFQ_ONEUI}, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#testSpecialAttentionKOFromAddressPage_EG005
  test.skip("testSpecialAttentionKOFromAddressPage_EG005", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#testSpecialAttentionKOFromAddressPage_EG005","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":63,"className":"KnockoutTests","method":"testSpecialAttentionKOFromAddressPage_EG005","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{KNOCKOUT_TESTS, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI}, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#testSpecialAttentionKOFromDriverReviewPage_EK32_SixDriver
  test("testSpecialAttentionKOFromDriverReviewPage_EK32_SixDriver", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#testSpecialAttentionKOFromDriverReviewPage_EK32_SixDriver","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":76,"className":"KnockoutTests","method":"testSpecialAttentionKOFromDriverReviewPage_EK32_SixDriver","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{KNOCKOUT_TESTS, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=12\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, GA, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, WI})}, dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#testSpecialAttentionKOFromVehiclePage_VEH007_High_End_Vehicle
  test("testSpecialAttentionKOFromVehiclePage_VEH007_High_End_Vehicle", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#testSpecialAttentionKOFromVehiclePage_VEH007_High_End_Vehicle","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":111,"className":"KnockoutTests","method":"testSpecialAttentionKOFromVehiclePage_VEH007_High_End_Vehicle","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{KNOCKOUT_TESTS, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA,NJ,FL})}, dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#testSpecialAttentionKOFromJAFMT_Page_VEH007_High_End_Vehicle
  test("testSpecialAttentionKOFromJAFMT_Page_VEH007_High_End_Vehicle", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#testSpecialAttentionKOFromJAFMT_Page_VEH007_High_End_Vehicle","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":138,"className":"KnockoutTests","method":"testSpecialAttentionKOFromJAFMT_Page_VEH007_High_End_Vehicle","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{KNOCKOUT_TESTS, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA})}, dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#testFarmersDoesNotOfferBusiness_EG004
  test.skip("testFarmersDoesNotOfferBusiness_EG004", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#testFarmersDoesNotOfferBusiness_EG004","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":179,"className":"KnockoutTests","method":"testFarmersDoesNotOfferBusiness_EG004","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{KNOCKOUT_TESTS, FFQ_ONEUI}","annotation":"@Test(groups = {KNOCKOUT_TESTS, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#validateKOforRestrictedAWSZIPCode_MI
  test("validateKOforRestrictedAWSZIPCode_MI", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#validateKOforRestrictedAWSZIPCode_MI","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":186,"className":"KnockoutTests","method":"validateKOforRestrictedAWSZIPCode_MI","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{KNOCKOUT_TESTS, FFQ_ONEUI}","annotation":"@Test(groups = {KNOCKOUT_TESTS, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#testFinancialFilingInAnotherStateForApplicant
  test("testFinancialFilingInAnotherStateForApplicant", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#testFinancialFilingInAnotherStateForApplicant","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":193,"className":"KnockoutTests","method":"testFinancialFilingInAnotherStateForApplicant","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, KNOCKOUT_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, KY, MA, NM}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, KNOCKOUT_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#testFinancialFilingInAnotherStateKOForAdditionalDriver
  test("testFinancialFilingInAnotherStateKOForAdditionalDriver", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#testFinancialFilingInAnotherStateKOForAdditionalDriver","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":235,"className":"KnockoutTests","method":"testFinancialFilingInAnotherStateKOForAdditionalDriver","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{KNOCKOUT_TESTS, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=5\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, KY, MA, NM})}, dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#validateKnockoutPageBecauseOfRideshareInVA
  test("validateKnockoutPageBecauseOfRideshareInVA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#validateKnockoutPageBecauseOfRideshareInVA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":292,"className":"KnockoutTests","method":"validateKnockoutPageBecauseOfRideshareInVA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{KNOCKOUT_TESTS, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=36\"}), @CustomAttribute(name = VA)}, dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#validateKO_Spouse_With_Foreign_DL_CA_State_WhoShouldWeInsurePage
  test("validateKO_Spouse_With_Foreign_DL_CA_State_WhoShouldWeInsurePage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#validateKO_Spouse_With_Foreign_DL_CA_State_WhoShouldWeInsurePage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":311,"className":"KnockoutTests","method":"validateKO_Spouse_With_Foreign_DL_CA_State_WhoShouldWeInsurePage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{KNOCKOUT_TESTS, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=32\"}), @CustomAttribute(name = CA)}, dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#validateKO_Spouse_With_Foreign_DL_CA_State_DriverReviewPage
  test("validateKO_Spouse_With_Foreign_DL_CA_State_DriverReviewPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#validateKO_Spouse_With_Foreign_DL_CA_State_DriverReviewPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":337,"className":"KnockoutTests","method":"validateKO_Spouse_With_Foreign_DL_CA_State_DriverReviewPage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{KNOCKOUT_TESTS, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = CA)}, dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#validateNY_Commuter_KO_For_NJ_User
  test("validateNY_Commuter_KO_For_NJ_User", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#validateNY_Commuter_KO_For_NJ_User","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":372,"className":"KnockoutTests","method":"validateNY_Commuter_KO_For_NJ_User","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {NJ}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#validateGoogleMapsIsNotDisplayedWhenKnockedOut
  test("validateGoogleMapsIsNotDisplayedWhenKnockedOut", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#validateGoogleMapsIsNotDisplayedWhenKnockedOut","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":396,"className":"KnockoutTests","method":"validateGoogleMapsIsNotDisplayedWhenKnockedOut","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {NJ, FL, CA}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.KnockoutTests#validateExoticVehicleKO_BW
  test("validateExoticVehicleKO_BW", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.KnockoutTests#validateExoticVehicleKO_BW","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/KnockoutTests.java","sourceLine":410,"className":"KnockoutTests","method":"validateExoticVehicleKO_BW","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{BW_ACE_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {NJ, FL, CA, GA}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS})"});
  });

});
