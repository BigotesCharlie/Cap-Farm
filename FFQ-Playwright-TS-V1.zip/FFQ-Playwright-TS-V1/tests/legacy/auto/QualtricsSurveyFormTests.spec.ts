// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.QualtricsSurveyFormTests", () => {
  // legacy-id: com.farmers.ffq.auto.QualtricsSurveyFormTests#testQualtricsTriggerQuoteSummary_40_SecondsInactivity
  test.skip("testQualtricsTriggerQuoteSummary_40_SecondsInactivity", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.QualtricsSurveyFormTests#testQualtricsTriggerQuoteSummary_40_SecondsInactivity","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QualtricsSurveyFormTests.java","sourceLine":19,"className":"QualtricsSurveyFormTests","method":"testQualtricsTriggerQuoteSummary_40_SecondsInactivity","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"FFQ_ONEUI","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = FFQ_ONEUI, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.auto.QualtricsSurveyFormTests#testQualtricsTriggerQuoteSummaryContinueButton_20_SecondsInactivity
  test.skip("testQualtricsTriggerQuoteSummaryContinueButton_20_SecondsInactivity", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.QualtricsSurveyFormTests#testQualtricsTriggerQuoteSummaryContinueButton_20_SecondsInactivity","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QualtricsSurveyFormTests.java","sourceLine":30,"className":"QualtricsSurveyFormTests","method":"testQualtricsTriggerQuoteSummaryContinueButton_20_SecondsInactivity","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"FFQ_ONEUI","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = FFQ_ONEUI, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.auto.QualtricsSurveyFormTests#testQualtricsTriggerAdditionalInfoPage_20_Delay
  test.skip("testQualtricsTriggerAdditionalInfoPage_20_Delay", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.QualtricsSurveyFormTests#testQualtricsTriggerAdditionalInfoPage_20_Delay","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QualtricsSurveyFormTests.java","sourceLine":45,"className":"QualtricsSurveyFormTests","method":"testQualtricsTriggerAdditionalInfoPage_20_Delay","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"FFQ_ONEUI","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = FFQ_ONEUI, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.auto.QualtricsSurveyFormTests#testQualtricsTriggerKnockoutPage_10_secondsDelay
  test.skip("testQualtricsTriggerKnockoutPage_10_secondsDelay", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.QualtricsSurveyFormTests#testQualtricsTriggerKnockoutPage_10_secondsDelay","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QualtricsSurveyFormTests.java","sourceLine":54,"className":"QualtricsSurveyFormTests","method":"testQualtricsTriggerKnockoutPage_10_secondsDelay","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"FFQ_ONEUI","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = FFQ_ONEUI, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.auto.QualtricsSurveyFormTests#testQualtricsTriggerFormSubmission
  test.skip("testQualtricsTriggerFormSubmission", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.QualtricsSurveyFormTests#testQualtricsTriggerFormSubmission","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QualtricsSurveyFormTests.java","sourceLine":75,"className":"QualtricsSurveyFormTests","method":"testQualtricsTriggerFormSubmission","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"FFQ_ONEUI","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = FFQ_ONEUI, enabled = false)"});
  });

});
