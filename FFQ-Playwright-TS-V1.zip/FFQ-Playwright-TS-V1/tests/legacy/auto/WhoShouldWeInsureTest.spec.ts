// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.WhoShouldWeInsureTest", () => {
  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testAddDriverDialog
  test("testAddDriverDialog", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testAddDriverDialog","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":25,"className":"WhoShouldWeInsureTest","method":"testAddDriverDialog","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testErrorMessageForMoreThanFourAdditionalDrivers
  test.skip("testErrorMessageForMoreThanFourAdditionalDrivers", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testErrorMessageForMoreThanFourAdditionalDrivers","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":52,"className":"WhoShouldWeInsureTest","method":"testErrorMessageForMoreThanFourAdditionalDrivers","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=4\"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testGuidanceMessagesForZeroDriverZeroVehicleAndZeroDriverWithZeroVehicle
  test("testGuidanceMessagesForZeroDriverZeroVehicleAndZeroDriverWithZeroVehicle", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testGuidanceMessagesForZeroDriverZeroVehicleAndZeroDriverWithZeroVehicle","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":81,"className":"WhoShouldWeInsureTest","method":"testGuidanceMessagesForZeroDriverZeroVehicleAndZeroDriverWithZeroVehicle","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=5\"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testInfoTextsAndFieldLabelTextForVehicleAndDriversDialog
  test("testInfoTextsAndFieldLabelTextForVehicleAndDriversDialog", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testInfoTextsAndFieldLabelTextForVehicleAndDriversDialog","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":155,"className":"WhoShouldWeInsureTest","method":"testInfoTextsAndFieldLabelTextForVehicleAndDriversDialog","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE}, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testListedVehiclesAndDriversInfoSavedAndDisplayedOnNavigationFromNextPageBackAndOnRefresh
  test("testListedVehiclesAndDriversInfoSavedAndDisplayedOnNavigationFromNextPageBackAndOnRefresh", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testListedVehiclesAndDriversInfoSavedAndDisplayedOnNavigationFromNextPageBackAndOnRefresh","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":173,"className":"WhoShouldWeInsureTest","method":"testListedVehiclesAndDriversInfoSavedAndDisplayedOnNavigationFromNextPageBackAndOnRefresh","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=5\"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testMaritalChangeNotificationAndPopUpMessage
  test("testMaritalChangeNotificationAndPopUpMessage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testMaritalChangeNotificationAndPopUpMessage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":221,"className":"WhoShouldWeInsureTest","method":"testMaritalChangeNotificationAndPopUpMessage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=31\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testMaritalRelationShipSelection
  test("testMaritalRelationShipSelection", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testMaritalRelationShipSelection","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":282,"className":"WhoShouldWeInsureTest","method":"testMaritalRelationShipSelection","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=31\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testVehiclePageFormFieldsErrorMessages
  test("testVehiclePageFormFieldsErrorMessages", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testVehiclePageFormFieldsErrorMessages","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":294,"className":"WhoShouldWeInsureTest","method":"testVehiclePageFormFieldsErrorMessages","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE}, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testVinHelperModal
  test("testVinHelperModal", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testVinHelperModal","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":328,"className":"WhoShouldWeInsureTest","method":"testVinHelperModal","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=5\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testVinTips
  test("testVinTips", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testVinTips","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":374,"className":"WhoShouldWeInsureTest","method":"testVinTips","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=5\"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testWhoShouldWeInsurePage
  test("testWhoShouldWeInsurePage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testWhoShouldWeInsurePage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":410,"className":"WhoShouldWeInsureTest","method":"testWhoShouldWeInsurePage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#validateAdditionalDriverFieldsAreEditable
  test("validateAdditionalDriverFieldsAreEditable", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#validateAdditionalDriverFieldsAreEditable","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":418,"className":"WhoShouldWeInsureTest","method":"validateAdditionalDriverFieldsAreEditable","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=5\"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testValidateValidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest
  test("testValidateValidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testValidateValidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":446,"className":"WhoShouldWeInsureTest","method":"testValidateValidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testValidateInvalidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest
  test("testValidateInvalidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testValidateInvalidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":452,"className":"WhoShouldWeInsureTest","method":"testValidateInvalidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testValidateReplaceValidWithInvalidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest
  test("testValidateReplaceValidWithInvalidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testValidateReplaceValidWithInvalidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":458,"className":"WhoShouldWeInsureTest","method":"testValidateReplaceValidWithInvalidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testVINFieldHasFocus
  test("testVINFieldHasFocus", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testVINFieldHasFocus","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":469,"className":"WhoShouldWeInsureTest","method":"testVINFieldHasFocus","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testFirstNameFieldHasFocus
  test("testFirstNameFieldHasFocus", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testFirstNameFieldHasFocus","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":508,"className":"WhoShouldWeInsureTest","method":"testFirstNameFieldHasFocus","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#test_CA_State_HasNoPriorInsuranceSection
  test("test_CA_State_HasNoPriorInsuranceSection", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#test_CA_State_HasNoPriorInsuranceSection","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":536,"className":"WhoShouldWeInsureTest","method":"test_CA_State_HasNoPriorInsuranceSection","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CA)}, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#testValidateCurrentInsuranceCompanyNoPrior_WhoShouldWeInsureTest
  test("testValidateCurrentInsuranceCompanyNoPrior_WhoShouldWeInsureTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#testValidateCurrentInsuranceCompanyNoPrior_WhoShouldWeInsureTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":544,"className":"WhoShouldWeInsureTest","method":"testValidateCurrentInsuranceCompanyNoPrior_WhoShouldWeInsureTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, CT})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

  // legacy-id: com.farmers.ffq.auto.WhoShouldWeInsureTest#validateOrderOfBI_Limits
  test("validateOrderOfBI_Limits", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.WhoShouldWeInsureTest#validateOrderOfBI_Limits","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/WhoShouldWeInsureTest.java","sourceLine":555,"className":"WhoShouldWeInsureTest","method":"validateOrderOfBI_Limits","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, WHO_SHOULD_WE_INSURE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA, CT, MA, KS})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})"});
  });

});
