// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.AddressOneUITests", () => {
  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#testAddressChangePopUp
  test("testAddressChangePopUp", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#testAddressChangePopUp","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":23,"className":"AddressOneUITests","method":"testAddressChangePopUp","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, ADDRESS_CHANGE_ZIP_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = INCLUDED_STATES, values = {IL})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDRESS_CHANGE_ZIP_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#testAddressOneUIAutoQuotePageContent
  test("testAddressOneUIAutoQuotePageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#testAddressOneUIAutoQuotePageContent","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":39,"className":"AddressOneUITests","method":"testAddressOneUIAutoQuotePageContent","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {UT, FL, IL, OK})})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#testErrorMessagesWhenAddressFieldIsBlankInvalidAndNotSelectedFromDropDown
  test("testErrorMessagesWhenAddressFieldIsBlankInvalidAndNotSelectedFromDropDown", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#testErrorMessagesWhenAddressFieldIsBlankInvalidAndNotSelectedFromDropDown","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":47,"className":"AddressOneUITests","method":"testErrorMessagesWhenAddressFieldIsBlankInvalidAndNotSelectedFromDropDown","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\")})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#testFieldResetOnAddressUpdate
  test("testFieldResetOnAddressUpdate", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#testFieldResetOnAddressUpdate","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":59,"className":"AddressOneUITests","method":"testFieldResetOnAddressUpdate","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#testHomeOwnerDiscount
  test("testHomeOwnerDiscount", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#testHomeOwnerDiscount","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":78,"className":"AddressOneUITests","method":"testHomeOwnerDiscount","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, NJ, MA}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, groups = {ADDRESS_ONEUI, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh
  test("testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":96,"className":"AddressOneUITests","method":"testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#testSubmitYouInfoApiCall
  test("testSubmitYouInfoApiCall", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#testSubmitYouInfoApiCall","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":115,"className":"AddressOneUITests","method":"testSubmitYouInfoApiCall","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI, BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = {ADDRESS_ONEUI, FFQ_ONEUI, BDQ_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#validateADPFIsNotCalledWithBDQ
  test.skip("validateADPFIsNotCalledWithBDQ", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#validateADPFIsNotCalledWithBDQ","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":154,"className":"AddressOneUITests","method":"validateADPFIsNotCalledWithBDQ","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = {ADDRESS_ONEUI, BDQ_TESTS}, expectedExceptions = NullPointerException.class)"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#validateManualEntrySection
  test.skip("validateManualEntrySection", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#validateManualEntrySection","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":163,"className":"AddressOneUITests","method":"validateManualEntrySection","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#validateTownDropdown_MA_State
  test("validateTownDropdown_MA_State", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#validateTownDropdown_MA_State","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":171,"className":"AddressOneUITests","method":"validateTownDropdown_MA_State","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MA)}, groups = {ADDRESS_ONEUI, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#testAutoAddressPageDisclaimers
  test("testAutoAddressPageDisclaimers", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#testAutoAddressPageDisclaimers","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":183,"className":"AddressOneUITests","method":"testAutoAddressPageDisclaimers","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI, BDQ_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI, BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\")})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#validateBrandSelectionRule
  test.skip("validateBrandSelectionRule", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#validateBrandSelectionRule","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":209,"className":"AddressOneUITests","method":"validateBrandSelectionRule","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, CONTACT_INFO, ADDRESS_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, IN, LA, MI, ND, NJ, NV, TX, WI})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, CONTACT_INFO, ADDRESS_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#validateSourceID
  test("validateSourceID", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#validateSourceID","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":217,"className":"AddressOneUITests","method":"validateSourceID","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, CONTACT_INFO, ADDRESS_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CO, CT, FL, MA, MI, MO, MS, MT, NC, NE, NJ, NM, NV, NY, PA, TN, VA, WA, WY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, CONTACT_INFO, ADDRESS_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#validateInvalidAndEmptyInputErrorMessages
  test("validateInvalidAndEmptyInputErrorMessages", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#validateInvalidAndEmptyInputErrorMessages","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":228,"className":"AddressOneUITests","method":"validateInvalidAndEmptyInputErrorMessages","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, IL, OK})})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#validateBrightVerifyAPI_EmailStatus
  test("validateBrightVerifyAPI_EmailStatus", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#validateBrightVerifyAPI_EmailStatus","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":240,"className":"AddressOneUITests","method":"validateBrightVerifyAPI_EmailStatus","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, IL, OK})})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#validateLineTypeIntelligenceServicedIsCalled
  test.skip("validateLineTypeIntelligenceServicedIsCalled", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#validateLineTypeIntelligenceServicedIsCalled","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":248,"className":"AddressOneUITests","method":"validateLineTypeIntelligenceServicedIsCalled","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = INCLUDED_STATES, values = {CA, TX})})"});
  });

  // legacy-id: com.farmers.ffq.auto.AddressOneUITests#validateTnediccaServiceIsTriggeredWhenAddressDetailsSaved
  test("validateTnediccaServiceIsTriggeredWhenAddressDetailsSaved", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AddressOneUITests#validateTnediccaServiceIsTriggeredWhenAddressDetailsSaved","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AddressOneUITests.java","sourceLine":265,"className":"AddressOneUITests","method":"validateTnediccaServiceIsTriggeredWhenAddressDetailsSaved","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{ADDRESS_ONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = {ADDRESS_ONEUI, FFQ_ONEUI})"});
  });

});
