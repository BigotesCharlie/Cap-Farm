// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.QuoteScenarios', () => {
  // legacy-id: com.farmers.ffq.auto.QuoteScenarios#getAutoQuote
  test('getAutoQuote', async ({ page, sqlAutoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, sqlAutoData, {
      legacyId: 'com.farmers.ffq.auto.QuoteScenarios#getAutoQuote',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteScenarios.java',
      sourceLine: 36,
      className: 'QuoteScenarios',
      method: 'getAutoQuote',
      parameters: 'SqlApplicant applicant',
      dataProvider: 'SqlDataProviders.HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'SqlDataProviders.class',
      testName: '',
      groups: '{REGRESSION, SPOT_TESTING}',
      annotation:
        '@Test(dataProvider = SqlDataProviders.HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = {REGRESSION, SPOT_TESTING})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteScenarios#getAutoQuoteForRetrieval
  test('getAutoQuoteForRetrieval', async ({ page, sqlAutoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, sqlAutoData, {
      legacyId: 'com.farmers.ffq.auto.QuoteScenarios#getAutoQuoteForRetrieval',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteScenarios.java',
      sourceLine: 41,
      className: 'QuoteScenarios',
      method: 'getAutoQuoteForRetrieval',
      parameters: 'SqlApplicant applicant',
      dataProvider: 'SqlDataProviders.AUTO_APPLICANT_SAVE_AND_RETRIEVE_DATA_PROVIDER',
      dataProviderClass: 'SqlDataProviders.class',
      testName: '',
      groups: '{REGRESSION}',
      annotation:
        '@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_SAVE_AND_RETRIEVE_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = {REGRESSION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteScenarios#autoBuildValidationTest
  test('autoBuildValidationTest', async ({ page, sqlAutoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, sqlAutoData, {
      legacyId: 'com.farmers.ffq.auto.QuoteScenarios#autoBuildValidationTest',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteScenarios.java',
      sourceLine: 46,
      className: 'QuoteScenarios',
      method: 'autoBuildValidationTest',
      parameters: 'SqlApplicant applicant',
      dataProvider: 'SqlDataProviders.BVT_AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'SqlDataProviders.class',
      testName: '',
      groups: '{AUTO_BVT, PEWC, ENV_STABILITY}',
      annotation:
        '@Test(dataProvider = SqlDataProviders.BVT_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = {AUTO_BVT, PEWC, ENV_STABILITY})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteScenarios#autoSmokeTests
  test('autoSmokeTests', async ({ page, sqlAutoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, sqlAutoData, {
      legacyId: 'com.farmers.ffq.auto.QuoteScenarios#autoSmokeTests',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteScenarios.java',
      sourceLine: 51,
      className: 'QuoteScenarios',
      method: 'autoSmokeTests',
      parameters: 'SqlApplicant applicant',
      dataProvider: 'SqlDataProviders.JENKINS_AUTO_APPLICANT_SMOKE_TEST_DATA_PROVIDER',
      dataProviderClass: 'SqlDataProviders.class',
      testName: '',
      groups: '"smokeTest"',
      annotation:
        '@Test(dataProvider = SqlDataProviders.JENKINS_AUTO_APPLICANT_SMOKE_TEST_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = "smokeTest")',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteScenarios#autoQuoteScenarioTests
  test('autoQuoteScenarioTests', async ({ page, sqlAutoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, sqlAutoData, {
      legacyId: 'com.farmers.ffq.auto.QuoteScenarios#autoQuoteScenarioTests',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteScenarios.java',
      sourceLine: 56,
      className: 'QuoteScenarios',
      method: 'autoQuoteScenarioTests',
      parameters: 'SqlApplicant applicant',
      dataProvider: 'SqlDataProviders.JENKINS_AUTO_APPLICANT_QUOTE_SCENARIOS_DATA_PROVIDER',
      dataProviderClass: 'SqlDataProviders.class',
      testName: '',
      groups: '"quoteScenarios"',
      annotation:
        '@Test(dataProvider = SqlDataProviders.JENKINS_AUTO_APPLICANT_QUOTE_SCENARIOS_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = "quoteScenarios")',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteScenarios#autoPageValidationTests
  test('autoPageValidationTests', async ({ page, sqlAutoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, sqlAutoData, {
      legacyId: 'com.farmers.ffq.auto.QuoteScenarios#autoPageValidationTests',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteScenarios.java',
      sourceLine: 61,
      className: 'QuoteScenarios',
      method: 'autoPageValidationTests',
      parameters: 'SqlApplicant applicant',
      dataProvider: 'SqlDataProviders.JENKINS_AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER',
      dataProviderClass: 'SqlDataProviders.class',
      testName: '',
      groups: '"pageValidation"',
      annotation:
        '@Test(dataProvider = SqlDataProviders.JENKINS_AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = "pageValidation")',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteScenarios#mobileAutoQuoteTests
  test('mobileAutoQuoteTests', async ({ page, sqlAutoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, sqlAutoData, {
      legacyId: 'com.farmers.ffq.auto.QuoteScenarios#mobileAutoQuoteTests',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteScenarios.java',
      sourceLine: 66,
      className: 'QuoteScenarios',
      method: 'mobileAutoQuoteTests',
      parameters: 'SqlApplicant applicant',
      dataProvider: 'SqlDataProviders.HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'SqlDataProviders.class',
      testName: '',
      groups: '{MOBILE_REGRESSION}',
      annotation:
        '@Test(dataProvider = SqlDataProviders.HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = {MOBILE_REGRESSION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteScenarios#bvtAutoQuotes
  test('bvtAutoQuotes', async ({ page, sqlAutoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, sqlAutoData, {
      legacyId: 'com.farmers.ffq.auto.QuoteScenarios#bvtAutoQuotes',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteScenarios.java',
      sourceLine: 72,
      className: 'QuoteScenarios',
      method: 'bvtAutoQuotes',
      parameters: 'SqlApplicant applicant',
      dataProvider: 'SqlDataProviders.ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'SqlDataProviders.class',
      testName: '',
      groups: 'CI_CD_SUITE',
      annotation:
        '@Test(dataProvider = SqlDataProviders.ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = CI_CD_SUITE)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteScenarios#createAutoQuoteWithAOR
  test('createAutoQuoteWithAOR', async ({ page, sqlAutoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, sqlAutoData, {
      legacyId: 'com.farmers.ffq.auto.QuoteScenarios#createAutoQuoteWithAOR',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteScenarios.java',
      sourceLine: 78,
      className: 'QuoteScenarios',
      method: 'createAutoQuoteWithAOR',
      parameters: 'SqlApplicant applicant',
      dataProvider: 'SqlDataProviders.TEST_AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'SqlDataProviders.class',
      testName: '',
      groups: 'REGRESSION',
      annotation:
        '@Test(dataProvider = SqlDataProviders.TEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES)}, groups = REGRESSION)',
    });
  });
});
