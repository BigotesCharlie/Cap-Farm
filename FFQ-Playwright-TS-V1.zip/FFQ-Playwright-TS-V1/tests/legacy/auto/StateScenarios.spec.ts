// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.StateScenarios", () => {
  // legacy-id: com.farmers.ffq.auto.StateScenarios#validateStateForAuto
  test("validateStateForAuto", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.StateScenarios#validateStateForAuto","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/StateScenarios.java","sourceLine":26,"className":"StateScenarios","method":"validateStateForAuto","parameters":"State state","dataProvider":"SqlDataProviders.STATES_DATA_PROVIDER_NAME","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, STATE_SCENARIOS}","annotation":"@Test(dataProvider = SqlDataProviders.STATES_DATA_PROVIDER_NAME, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AS, NH, TT})}, groups = {REGRESSION, STATE_SCENARIOS})"});
  });

  // legacy-id: com.farmers.ffq.auto.StateScenarios#validateStateForAutoUsingAOR
  test("validateStateForAutoUsingAOR", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.StateScenarios#validateStateForAutoUsingAOR","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/StateScenarios.java","sourceLine":48,"className":"StateScenarios","method":"validateStateForAutoUsingAOR","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, STATE_SCENARIOS}","annotation":"@Test(dataProvider = SqlDataProviders.ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER, attributes = {@CustomAttribute(name = MONETIZED_STATES)}, dataProviderClass = SqlDataProviders.class, groups = {REGRESSION, STATE_SCENARIOS})"});
  });

});
