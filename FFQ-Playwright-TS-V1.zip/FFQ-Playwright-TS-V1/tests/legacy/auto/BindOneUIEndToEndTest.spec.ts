// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest', () => {
  // legacy-id: com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EdWithPifBankAccountAndServiceVirtualizationData
  test('bindOneUIE2EdWithPifBankAccountAndServiceVirtualizationData', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EdWithPifBankAccountAndServiceVirtualizationData',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/e2e/BindOneUIEndToEndTest.java',
      sourceLine: 27,
      className: 'BindOneUIEndToEndTest',
      method: 'bindOneUIE2EdWithPifBankAccountAndServiceVirtualizationData',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES',
      groups: '{SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EdWithMonthlyAutopayBankAccountAndServiceVirtualizationData
  test('bindOneUIE2EdWithMonthlyAutopayBankAccountAndServiceVirtualizationData', async ({
    page,
    autoData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EdWithMonthlyAutopayBankAccountAndServiceVirtualizationData',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/e2e/BindOneUIEndToEndTest.java',
      sourceLine: 37,
      className: 'BindOneUIEndToEndTest',
      method: 'bindOneUIE2EdWithMonthlyAutopayBankAccountAndServiceVirtualizationData',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES',
      groups: '{SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EdWithPifDebitCardAndServiceVirtualizationData
  test('bindOneUIE2EdWithPifDebitCardAndServiceVirtualizationData', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EdWithPifDebitCardAndServiceVirtualizationData',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/e2e/BindOneUIEndToEndTest.java',
      sourceLine: 47,
      className: 'BindOneUIEndToEndTest',
      method: 'bindOneUIE2EdWithPifDebitCardAndServiceVirtualizationData',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES',
      groups: '{SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EdWithMonthlyAutopayDebitCardAndServiceVirtualizationData
  test('bindOneUIE2EdWithMonthlyAutopayDebitCardAndServiceVirtualizationData', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EdWithMonthlyAutopayDebitCardAndServiceVirtualizationData',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/e2e/BindOneUIEndToEndTest.java',
      sourceLine: 57,
      className: 'BindOneUIEndToEndTest',
      method: 'bindOneUIE2EdWithMonthlyAutopayDebitCardAndServiceVirtualizationData',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES',
      groups: '{SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EdWithPifCreditCardAndServiceVirtualizationData
  test('bindOneUIE2EdWithPifCreditCardAndServiceVirtualizationData', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EdWithPifCreditCardAndServiceVirtualizationData',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/e2e/BindOneUIEndToEndTest.java',
      sourceLine: 67,
      className: 'BindOneUIEndToEndTest',
      method: 'bindOneUIE2EdWithPifCreditCardAndServiceVirtualizationData',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES',
      groups: '{SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EdWithMonthlyAutopayCreditCardAndServiceVirtualizationData
  test('bindOneUIE2EdWithMonthlyAutopayCreditCardAndServiceVirtualizationData', async ({
    page,
    autoData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EdWithMonthlyAutopayCreditCardAndServiceVirtualizationData',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/e2e/BindOneUIEndToEndTest.java',
      sourceLine: 79,
      className: 'BindOneUIEndToEndTest',
      method: 'bindOneUIE2EdWithMonthlyAutopayCreditCardAndServiceVirtualizationData',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES',
      groups: '{SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EndWithDebitCardAndAdpfData
  test('bindOneUIE2EndWithDebitCardAndAdpfData', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#bindOneUIE2EndWithDebitCardAndAdpfData',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/e2e/BindOneUIEndToEndTest.java',
      sourceLine: 92,
      className: 'BindOneUIEndToEndTest',
      method: 'bindOneUIE2EndWithDebitCardAndAdpfData',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.BIND_ADPF_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_AUTO_E2E, FFQ_BIND_WITH_ADPFDATA_ENDTOEND}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.BIND_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ACE_AUTO_E2E, FFQ_BIND_WITH_ADPFDATA_ENDTOEND})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#validateBindWithDLObtainedFromDifferentState
  test('validateBindWithDLObtainedFromDifferentState', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#validateBindWithDLObtainedFromDifferentState',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/e2e/BindOneUIEndToEndTest.java',
      sourceLine: 100,
      className: 'BindOneUIEndToEndTest',
      method: 'validateBindWithDLObtainedFromDifferentState',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=5")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#validate_bind_disabled_when_fasttrackIndicator_false_otherwise_continue_with_bind
  test('validate_bind_disabled_when_fasttrackIndicator_false_otherwise_continue_with_bind', async ({
    page,
    autoData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#validate_bind_disabled_when_fasttrackIndicator_false_otherwise_continue_with_bind',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/e2e/BindOneUIEndToEndTest.java',
      sourceLine: 162,
      className: 'BindOneUIEndToEndTest',
      method: 'validate_bind_disabled_when_fasttrackIndicator_false_otherwise_continue_with_bind',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#validateOdometer_Rideshare_InfoIsSentToPC_Bind_F87642
  test('validateOdometer_Rideshare_InfoIsSentToPC_Bind_F87642', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest#validateOdometer_Rideshare_InfoIsSentToPC_Bind_F87642',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/e2e/BindOneUIEndToEndTest.java',
      sourceLine: 194,
      className: 'BindOneUIEndToEndTest',
      method: 'validateOdometer_Rideshare_InfoIsSentToPC_Bind_F87642',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"}),@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class,groups = {FFQ_ONEUI})',
    });
  });
});
