// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.AutoToAutoHomeBundleTest", () => {
  // legacy-id: com.farmers.ffq.auto.AutoToAutoHomeBundleTest#validateAutoToMonoLineAutoFromInterstitialPage
  test("validateAutoToMonoLineAutoFromInterstitialPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AutoToAutoHomeBundleTest#validateAutoToMonoLineAutoFromInterstitialPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AutoToAutoHomeBundleTest.java","sourceLine":26,"className":"AutoToAutoHomeBundleTest","method":"validateAutoToMonoLineAutoFromInterstitialPage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, AUTO_TO_MONO_LINE_OR_BUNDLE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA }), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, groups = {FFQ_ONEUI, AUTO_TO_MONO_LINE_OR_BUNDLE})"});
  });

  // legacy-id: com.farmers.ffq.auto.AutoToAutoHomeBundleTest#validateAutoToBundleHomeFlowFromInterstitialPage
  test("validateAutoToBundleHomeFlowFromInterstitialPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AutoToAutoHomeBundleTest#validateAutoToBundleHomeFlowFromInterstitialPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AutoToAutoHomeBundleTest.java","sourceLine":61,"className":"AutoToAutoHomeBundleTest","method":"validateAutoToBundleHomeFlowFromInterstitialPage","parameters":"AceBundleApplicant bundleApplicant","dataProvider":"AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER","dataProviderClass":"AceBundleDataProviders.class","testName":"AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT","groups":"{FFQ_ONEUI, AUTO_TO_MONO_LINE_OR_BUNDLE}","annotation":"@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AceBundleDataProviders.class, groups = {FFQ_ONEUI, AUTO_TO_MONO_LINE_OR_BUNDLE})"});
  });

  // legacy-id: com.farmers.ffq.auto.AutoToAutoHomeBundleTest#validateAutoHomeBundleFlowFromAutoQuoteSummaryPage
  test("validateAutoHomeBundleFlowFromAutoQuoteSummaryPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AutoToAutoHomeBundleTest#validateAutoHomeBundleFlowFromAutoQuoteSummaryPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AutoToAutoHomeBundleTest.java","sourceLine":106,"className":"AutoToAutoHomeBundleTest","method":"validateAutoHomeBundleFlowFromAutoQuoteSummaryPage","parameters":"AceBundleApplicant bundleApplicant","dataProvider":"AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER","dataProviderClass":"AceBundleDataProviders.class","testName":"AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT","groups":"{FFQ_ONEUI, AUTO_TO_MONO_LINE_OR_BUNDLE}","annotation":"@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AceBundleDataProviders.class, groups = {FFQ_ONEUI, AUTO_TO_MONO_LINE_OR_BUNDLE})"});
  });

});
