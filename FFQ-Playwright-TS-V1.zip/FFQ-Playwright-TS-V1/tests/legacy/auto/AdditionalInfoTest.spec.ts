// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.bind.AdditionalInfoTest', () => {
  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#testValidateValidVIN_AdditionalInfoTest
  test('testValidateValidVIN_AdditionalInfoTest', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.AdditionalInfoTest#testValidateValidVIN_AdditionalInfoTest',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 30,
      className: 'AdditionalInfoTest',
      method: 'testValidateValidVIN_AdditionalInfoTest',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, ADDITIONAL_INFO}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#testValidateInvalidVIN_AdditionalInfoTest
  test('testValidateInvalidVIN_AdditionalInfoTest', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.AdditionalInfoTest#testValidateInvalidVIN_AdditionalInfoTest',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 39,
      className: 'AdditionalInfoTest',
      method: 'testValidateInvalidVIN_AdditionalInfoTest',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, ADDITIONAL_INFO}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#testValidateReplaceValidWithInvalidVIN_AdditionalInfoTest
  test('testValidateReplaceValidWithInvalidVIN_AdditionalInfoTest', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.bind.AdditionalInfoTest#testValidateReplaceValidWithInvalidVIN_AdditionalInfoTest',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 50,
      className: 'AdditionalInfoTest',
      method: 'testValidateReplaceValidWithInvalidVIN_AdditionalInfoTest',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, ADDITIONAL_INFO}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#bindOneUIFullFewMoreThingsPageValidation
  test('bindOneUIFullFewMoreThingsPageValidation', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.AdditionalInfoTest#bindOneUIFullFewMoreThingsPageValidation',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 59,
      className: 'AdditionalInfoTest',
      method: 'bindOneUIFullFewMoreThingsPageValidation',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, ADDITIONAL_INFO}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#bindOneUIFullFewMoreThingsPageValidationMobileBreakPoint
  test.skip('bindOneUIFullFewMoreThingsPageValidationMobileBreakPoint', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.AdditionalInfoTest#bindOneUIFullFewMoreThingsPageValidationMobileBreakPoint',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 86,
      className: 'AdditionalInfoTest',
      method: 'bindOneUIFullFewMoreThingsPageValidationMobileBreakPoint',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI, ADDITIONAL_INFO}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, suiteName = "few more things page", dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#validateOdometerReadingDateFormatOnAdditionalInfoPage
  test.skip('validateOdometerReadingDateFormatOnAdditionalInfoPage', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.AdditionalInfoTest#validateOdometerReadingDateFormatOnAdditionalInfoPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 113,
      className: 'AdditionalInfoTest',
      method: 'validateOdometerReadingDateFormatOnAdditionalInfoPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, ADDITIONAL_INFO}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#validateAdditionalInfoPageForBW
  test('validateAdditionalInfoPageForBW', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.AdditionalInfoTest#validateAdditionalInfoPageForBW',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 134,
      className: 'AdditionalInfoTest',
      method: 'validateAdditionalInfoPageForBW',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, ADDITIONAL_INFO}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, IL, IN, MO, OH, OK, OR, TX, UT, WI, SD, MI, PA, WY, KS, CO, NM, IA, VA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, ADDITIONAL_INFO})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#testSaveAdditionalInfo_Call
  test('testSaveAdditionalInfo_Call', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.AdditionalInfoTest#testSaveAdditionalInfo_Call',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 159,
      className: 'AdditionalInfoTest',
      method: 'testSaveAdditionalInfo_Call',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{FFQ_ONEUI, ADDITIONAL_INFO}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#validate_mismatchedDrivers_performAutoVerify_JFMT
  test('validate_mismatchedDrivers_performAutoVerify_JFMT', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.AdditionalInfoTest#validate_mismatchedDrivers_performAutoVerify_JFMT',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 180,
      className: 'AdditionalInfoTest',
      method: 'validate_mismatchedDrivers_performAutoVerify_JFMT',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {NC, NV, MA, CT, FL})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#validate_mismatchedDrivers_performAutoVerify_clickingSaveQuote
  test('validate_mismatchedDrivers_performAutoVerify_clickingSaveQuote', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.bind.AdditionalInfoTest#validate_mismatchedDrivers_performAutoVerify_clickingSaveQuote',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 200,
      className: 'AdditionalInfoTest',
      method: 'validate_mismatchedDrivers_performAutoVerify_clickingSaveQuote',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {IL, WY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#validate_notTocall_mismatchedDrivers_performAutoVerify_clickingPurchaseStepper
  test('validate_notTocall_mismatchedDrivers_performAutoVerify_clickingPurchaseStepper', async ({
    page,
    autoData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.bind.AdditionalInfoTest#validate_notTocall_mismatchedDrivers_performAutoVerify_clickingPurchaseStepper',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 245,
      className: 'AdditionalInfoTest',
      method: 'validate_notTocall_mismatchedDrivers_performAutoVerify_clickingPurchaseStepper',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {IL, WY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#validate_BrightLine_Suspended_RevokedDriversLicense
  test('validate_BrightLine_Suspended_RevokedDriversLicense', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.AdditionalInfoTest#validate_BrightLine_Suspended_RevokedDriversLicense',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 282,
      className: 'AdditionalInfoTest',
      method: 'validate_BrightLine_Suspended_RevokedDriversLicense',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {IL, NM})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#validate_reverseBrightlIne
  test('validate_reverseBrightlIne', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.AdditionalInfoTest#validate_reverseBrightlIne',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 324,
      className: 'AdditionalInfoTest',
      method: 'validate_reverseBrightlIne',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=2"}), @CustomAttribute(name = EXCLUDED_STATES, values = {MA, CA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#verifyJFMTPagePrivacyPolicyLinks
  test('verifyJFMTPagePrivacyPolicyLinks', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.AdditionalInfoTest#verifyJFMTPagePrivacyPolicyLinks',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 360,
      className: 'AdditionalInfoTest',
      method: 'verifyJFMTPagePrivacyPolicyLinks',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#validateSignalSectionIsNotDisplayedForLivingAwaySpouse
  test('validateSignalSectionIsNotDisplayedForLivingAwaySpouse', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.AdditionalInfoTest#validateSignalSectionIsNotDisplayedForLivingAwaySpouse',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 384,
      className: 'AdditionalInfoTest',
      method: 'validateSignalSectionIsNotDisplayedForLivingAwaySpouse',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = INCLUDED_STATES, values = {VA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.AdditionalInfoTest#validateR03_1_2026_for_US1111703
  test('validateR03_1_2026_for_US1111703', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.AdditionalInfoTest#validateR03_1_2026_for_US1111703',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/AdditionalInfoTest.java',
      sourceLine: 422,
      className: 'AdditionalInfoTest',
      method: 'validateR03_1_2026_for_US1111703',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=9"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, NJ, CA, WA, AK, DC, DE, HI, ME, NH, NY, OR, RI, SC, VT, WV})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });
});
