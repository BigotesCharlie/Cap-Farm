// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.name", () => {
  // legacy-id: com.farmers.ffq.auto.name#getAutoQuote
  test("getAutoQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.name#getAutoQuote","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QuoteScenarios.java","sourceLine":36,"className":"name","method":"getAutoQuote","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, SPOT_TESTING}","annotation":"@Test(dataProvider = SqlDataProviders.HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = {REGRESSION, SPOT_TESTING})"});
  });

  // legacy-id: com.farmers.ffq.auto.name#getAutoQuoteForRetrieval
  test("getAutoQuoteForRetrieval", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.name#getAutoQuoteForRetrieval","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QuoteScenarios.java","sourceLine":41,"className":"name","method":"getAutoQuoteForRetrieval","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.AUTO_APPLICANT_SAVE_AND_RETRIEVE_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION}","annotation":"@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_SAVE_AND_RETRIEVE_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = {REGRESSION})"});
  });

  // legacy-id: com.farmers.ffq.auto.name#autoBuildValidationTest
  test("autoBuildValidationTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.name#autoBuildValidationTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QuoteScenarios.java","sourceLine":46,"className":"name","method":"autoBuildValidationTest","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.BVT_AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{AUTO_BVT, PEWC, ENV_STABILITY}","annotation":"@Test(dataProvider = SqlDataProviders.BVT_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = {AUTO_BVT, PEWC, ENV_STABILITY})"});
  });

  // legacy-id: com.farmers.ffq.auto.name#autoSmokeTests
  test("autoSmokeTests", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.name#autoSmokeTests","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QuoteScenarios.java","sourceLine":51,"className":"name","method":"autoSmokeTests","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.JENKINS_AUTO_APPLICANT_SMOKE_TEST_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"\"smokeTest\"","annotation":"@Test(dataProvider = SqlDataProviders.JENKINS_AUTO_APPLICANT_SMOKE_TEST_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = \"smokeTest\")"});
  });

  // legacy-id: com.farmers.ffq.auto.name#autoQuoteScenarioTests
  test("autoQuoteScenarioTests", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.name#autoQuoteScenarioTests","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QuoteScenarios.java","sourceLine":56,"className":"name","method":"autoQuoteScenarioTests","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.JENKINS_AUTO_APPLICANT_QUOTE_SCENARIOS_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"\"quoteScenarios\"","annotation":"@Test(dataProvider = SqlDataProviders.JENKINS_AUTO_APPLICANT_QUOTE_SCENARIOS_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = \"quoteScenarios\")"});
  });

  // legacy-id: com.farmers.ffq.auto.name#autoPageValidationTests
  test("autoPageValidationTests", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.name#autoPageValidationTests","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QuoteScenarios.java","sourceLine":61,"className":"name","method":"autoPageValidationTests","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.JENKINS_AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"\"pageValidation\"","annotation":"@Test(dataProvider = SqlDataProviders.JENKINS_AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = \"pageValidation\")"});
  });

  // legacy-id: com.farmers.ffq.auto.name#mobileAutoQuoteTests
  test("mobileAutoQuoteTests", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.name#mobileAutoQuoteTests","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QuoteScenarios.java","sourceLine":66,"className":"name","method":"mobileAutoQuoteTests","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{MOBILE_REGRESSION}","annotation":"@Test(dataProvider = SqlDataProviders.HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = {MOBILE_REGRESSION})"});
  });

  // legacy-id: com.farmers.ffq.auto.name#bvtAutoQuotes
  test("bvtAutoQuotes", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.name#bvtAutoQuotes","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QuoteScenarios.java","sourceLine":72,"className":"name","method":"bvtAutoQuotes","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"CI_CD_SUITE","annotation":"@Test(dataProvider = SqlDataProviders.ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = CI_CD_SUITE)"});
  });

  // legacy-id: com.farmers.ffq.auto.name#createAutoQuoteWithAOR
  test("createAutoQuoteWithAOR", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.name#createAutoQuoteWithAOR","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QuoteScenarios.java","sourceLine":78,"className":"name","method":"createAutoQuoteWithAOR","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.TEST_AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"REGRESSION","annotation":"@Test(dataProvider = SqlDataProviders.TEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES)}, groups = REGRESSION)"});
  });

});
