// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.bind.BindOneUISignalEnrollmentSectionValidationTest", () => {
  // legacy-id: com.farmers.ffq.auto.bind.BindOneUISignalEnrollmentSectionValidationTest#bindOneUIAutoQuoteAdditionalInfoSignalEnrollmentSection
  test.skip("bindOneUIAutoQuoteAdditionalInfoSignalEnrollmentSection", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.bind.BindOneUISignalEnrollmentSectionValidationTest#bindOneUIAutoQuoteAdditionalInfoSignalEnrollmentSection","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/bind/BindOneUISignalEnrollmentSectionValidationTest.java","sourceLine":18,"className":"BindOneUISignalEnrollmentSectionValidationTest","method":"bindOneUIAutoQuoteAdditionalInfoSignalEnrollmentSection","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT","groups":"{FFQ_ONEUI, FFQ_BIND_JFMT_PAGE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, FFQ_BIND_JFMT_PAGE}, enabled = false)"});
  });

});
