// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.GeoRestrictionTests", () => {
  // legacy-id: com.farmers.ffq.auto.GeoRestrictionTests#validateUserGetFWSPage_NonAWS
  test("validateUserGetFWSPage_NonAWS", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.GeoRestrictionTests#validateUserGetFWSPage_NonAWS","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/GeoRestrictionTests.java","sourceLine":37,"className":"GeoRestrictionTests","method":"validateUserGetFWSPage_NonAWS","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{FFQ_ONEUI, GEO_RESTRICTION_TEST}","annotation":"@Test(groups = {FFQ_ONEUI, GEO_RESTRICTION_TEST})"});
  });

  // legacy-id: com.farmers.ffq.auto.GeoRestrictionTests#validateUserGetFWSPage_AWS_Without_AOR
  test("validateUserGetFWSPage_AWS_Without_AOR", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.GeoRestrictionTests#validateUserGetFWSPage_AWS_Without_AOR","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/GeoRestrictionTests.java","sourceLine":67,"className":"GeoRestrictionTests","method":"validateUserGetFWSPage_AWS_Without_AOR","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{FFQ_ONEUI, GEO_RESTRICTION_TEST}","annotation":"@Test(groups = {FFQ_ONEUI, GEO_RESTRICTION_TEST})"});
  });

  // legacy-id: com.farmers.ffq.auto.GeoRestrictionTests#validateUserLandsOnCallOnlyLandingPage_NegativeTest
  test.skip("validateUserLandsOnCallOnlyLandingPage_NegativeTest", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.GeoRestrictionTests#validateUserLandsOnCallOnlyLandingPage_NegativeTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/GeoRestrictionTests.java","sourceLine":100,"className":"GeoRestrictionTests","method":"validateUserLandsOnCallOnlyLandingPage_NegativeTest","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{FFQ_ONEUI, GEO_RESTRICTION_TEST}","annotation":"@Test(groups = {FFQ_ONEUI, GEO_RESTRICTION_TEST})"});
  });

  // legacy-id: com.farmers.ffq.auto.GeoRestrictionTests#validateUserGetsAceFlowWithAWS_AOR_NegativeTesting_AZ_State
  test("validateUserGetsAceFlowWithAWS_AOR_NegativeTesting_AZ_State", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.GeoRestrictionTests#validateUserGetsAceFlowWithAWS_AOR_NegativeTesting_AZ_State","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/GeoRestrictionTests.java","sourceLine":125,"className":"GeoRestrictionTests","method":"validateUserGetsAceFlowWithAWS_AOR_NegativeTesting_AZ_State","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{FFQ_ONEUI, GEO_RESTRICTION_TEST}","annotation":"@Test(groups = {FFQ_ONEUI, GEO_RESTRICTION_TEST})"});
  });

  // legacy-id: com.farmers.ffq.auto.GeoRestrictionTests#validateUserGetsAceFlow_AWS_AOR_Negative_Testing
  test.skip("validateUserGetsAceFlow_AWS_AOR_Negative_Testing", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.GeoRestrictionTests#validateUserGetsAceFlow_AWS_AOR_Negative_Testing","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/GeoRestrictionTests.java","sourceLine":154,"className":"GeoRestrictionTests","method":"validateUserGetsAceFlow_AWS_AOR_Negative_Testing","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{FFQ_ONEUI, GEO_RESTRICTION_TEST}","annotation":"@Test(groups = {FFQ_ONEUI, GEO_RESTRICTION_TEST})"});
  });

  // legacy-id: com.farmers.ffq.auto.GeoRestrictionTests#validateToBWModalToFgia_or_BWFlow
  test("validateToBWModalToFgia_or_BWFlow", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.GeoRestrictionTests#validateToBWModalToFgia_or_BWFlow","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/GeoRestrictionTests.java","sourceLine":184,"className":"GeoRestrictionTests","method":"validateToBWModalToFgia_or_BWFlow","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{FFQ_ONEUI, GEO_RESTRICTION_TEST}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = INCLUDED_STATES, values = {MA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, GEO_RESTRICTION_TEST})"});
  });

});
