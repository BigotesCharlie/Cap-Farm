// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV', () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_25K50K_NO_UMBRELLA
  test('testDefaultCoverageValues_NV_25K50K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_25K50K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 13,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_25K50K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_25K50K_UMBRELLA
  test('testDefaultCoverageValues_NV_25K50K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_25K50K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 19,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_25K50K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_30K60K_NO_UMBRELLA
  test('testDefaultCoverageValues_NV_30K60K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_30K60K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 25,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_30K60K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_30K60K_UMBRELLA
  test('testDefaultCoverageValues_NV_30K60K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_30K60K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 31,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_30K60K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_35K70K_NO_UMBRELLA
  test('testDefaultCoverageValues_NV_35K70K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_35K70K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 37,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_35K70K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_35K70K_UMBRELLA
  test('testDefaultCoverageValues_NV_35K70K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_35K70K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 43,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_35K70K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_50K100K_NO_UMBRELLA
  test('testDefaultCoverageValues_NV_50K100K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_50K100K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 49,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_50K100K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_50K100K_UMBRELLA
  test('testDefaultCoverageValues_NV_50K100K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_50K100K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 55,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_50K100K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_100K200K_NO_UMBRELLA
  test('testDefaultCoverageValues_NV_100K200K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_100K200K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 61,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_100K200K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_100K200K_UMBRELLA
  test('testDefaultCoverageValues_NV_100K200K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_100K200K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 67,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_100K200K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_100K300K_NO_UMBRELLA
  test('testDefaultCoverageValues_NV_100K300K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_100K300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 73,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_100K300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_100K300K_UMBRELLA
  test('testDefaultCoverageValues_NV_100K300K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_100K300K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 79,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_100K300K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_250K500K_NO_UMBRELLA
  test('testDefaultCoverageValues_NV_250K500K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_250K500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 85,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_250K500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_250K500K_UMBRELLA
  test('testDefaultCoverageValues_NV_250K500K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_250K500K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 91,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_250K500K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_500K500K_NO_UMBRELLA
  test('testDefaultCoverageValues_NV_500K500K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_500K500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 97,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_500K500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_500K500K_UMBRELLA
  test('testDefaultCoverageValues_NV_500K500K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_500K500K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 103,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_500K500K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_500K_NO_UMBRELLA
  test('testDefaultCoverageValues_NV_500K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 109,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_500K_UMBRELLA
  test('testDefaultCoverageValues_NV_500K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_NV#testDefaultCoverageValues_NV_500K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_NV.java',
      sourceLine: 115,
      className: 'DefaultCoverageValuesTests_NV',
      method: 'testDefaultCoverageValues_NV_500K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });
});
