// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI', () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_50K100K_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_50K100K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_50K100K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 12,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_50K100K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_50K100K_UMBRELLA
  test('testDefaultCoverageValues_MI_50K100K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_50K100K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 18,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_50K100K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K200K_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_100K200K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K200K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 24,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_100K200K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K200K_UMBRELLA
  test('testDefaultCoverageValues_MI_100K200K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K200K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 30,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_100K200K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K300K_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_100K300K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 36,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_100K300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K300K_UMBRELLA
  test('testDefaultCoverageValues_MI_100K300K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K300K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 42,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_100K300K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_250K500K_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_250K500K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_250K500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 48,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_250K500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_250K500K_UMBRELLA
  test('testDefaultCoverageValues_MI_250K500K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_250K500K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 54,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_250K500K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_300K300K_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_300K300K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_300K300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 60,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_300K300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_300K300K_UMBRELLA
  test('testDefaultCoverageValues_MI_300K300K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_300K300K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 66,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_300K300K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K500K_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_500K500K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 72,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_500K500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K500K_UMBRELLA
  test('testDefaultCoverageValues_MI_500K500K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K500K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 78,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_500K500K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K1M_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_500K1M_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K1M_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 84,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_500K1M_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K1M_UMBRELLA
  test('testDefaultCoverageValues_MI_500K1M_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K1M_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 90,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_500K1M_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_1M1M_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_1M1M_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_1M1M_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 96,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_1M1M_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_1M1M_UMBRELLA
  test('testDefaultCoverageValues_MI_1M1M_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_1M1M_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 102,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_1M1M_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_75K_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_75K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_75K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 108,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_75K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_75K_UMBRELLA
  test('testDefaultCoverageValues_MI_75K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_75K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 114,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_75K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_100K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 120,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_100K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K_UMBRELLA
  test('testDefaultCoverageValues_MI_100K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 126,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_100K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_200K_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_200K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_200K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 132,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_200K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_200K_UMBRELLA
  test('testDefaultCoverageValues_MI_200K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_200K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 138,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_200K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_300K_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_300K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 144,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_300K_UMBRELLA
  test('testDefaultCoverageValues_MI_300K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_300K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 150,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_300K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_500K_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 156,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K_UMBRELLA
  test('testDefaultCoverageValues_MI_500K_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 162,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_500K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_1M_NO_UMBRELLA
  test('testDefaultCoverageValues_MI_1M_NO_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_1M_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 168,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_1M_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_1M_UMBRELLA
  test('testDefaultCoverageValues_MI_1M_UMBRELLA', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_1M_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MI.java',
      sourceLine: 174,
      className: 'DefaultCoverageValuesTests_MI',
      method: 'testDefaultCoverageValues_MI_1M_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });
});
