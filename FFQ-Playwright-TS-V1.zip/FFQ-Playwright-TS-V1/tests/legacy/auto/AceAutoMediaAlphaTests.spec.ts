// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests", () => {
  // legacy-id: com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#mediaAlphaFlowMarriedWith2Veh
  test("mediaAlphaFlowMarriedWith2Veh", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#mediaAlphaFlowMarriedWith2Veh","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/AceAutoMediaAlphaTests.java","sourceLine":28,"className":"AceAutoMediaAlphaTests","method":"mediaAlphaFlowMarriedWith2Veh","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{\"mediaAlphaAuto\", FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=29\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {\"mediaAlphaAuto\", FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#mediaAlphaFlowMarriedWith2VehBw
  test("mediaAlphaFlowMarriedWith2VehBw", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#mediaAlphaFlowMarriedWith2VehBw","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/AceAutoMediaAlphaTests.java","sourceLine":52,"className":"AceAutoMediaAlphaTests","method":"mediaAlphaFlowMarriedWith2VehBw","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{\"mediaAlphaAuto\", FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=29\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {\"mediaAlphaAuto\", FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#mediaAlphaFlowWith1Veh1Driver
  test("mediaAlphaFlowWith1Veh1Driver", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#mediaAlphaFlowWith1Veh1Driver","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/AceAutoMediaAlphaTests.java","sourceLine":78,"className":"AceAutoMediaAlphaTests","method":"mediaAlphaFlowWith1Veh1Driver","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{\"mediaAlphaAuto\", FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {\"mediaAlphaAuto\", FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#validateRetrievalFromQuotePageForBWFlow
  test("validateRetrievalFromQuotePageForBWFlow", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#validateRetrievalFromQuotePageForBWFlow","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/AceAutoMediaAlphaTests.java","sourceLine":103,"className":"AceAutoMediaAlphaTests","method":"validateRetrievalFromQuotePageForBWFlow","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{\"mediaAlphaAuto\", FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {\"mediaAlphaAuto\", FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#mediaAlphaFlowWithLessThan6MonthToBW
  test("mediaAlphaFlowWithLessThan6MonthToBW", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#mediaAlphaFlowWithLessThan6MonthToBW","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/AceAutoMediaAlphaTests.java","sourceLine":138,"className":"AceAutoMediaAlphaTests","method":"mediaAlphaFlowWithLessThan6MonthToBW","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{\"mediaAlphaAuto\", FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {\"mediaAlphaAuto\", FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#alphaMediaAdpfDataSkipAdpfValidation
  test("alphaMediaAdpfDataSkipAdpfValidation", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#alphaMediaAdpfDataSkipAdpfValidation","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/AceAutoMediaAlphaTests.java","sourceLine":166,"className":"AceAutoMediaAlphaTests","method":"alphaMediaAdpfDataSkipAdpfValidation","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{\"mediaAlphaAuto\", FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = INCLUDED_STATES, values = {AR})}, dataProviderClass = AutoDataProviders.class, groups = {\"mediaAlphaAuto\", FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#validateUserIsNotAbleToMoveOnWithBlankContactDetailsOnRatePage
  test("validateUserIsNotAbleToMoveOnWithBlankContactDetailsOnRatePage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#validateUserIsNotAbleToMoveOnWithBlankContactDetailsOnRatePage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/AceAutoMediaAlphaTests.java","sourceLine":190,"className":"AceAutoMediaAlphaTests","method":"validateUserIsNotAbleToMoveOnWithBlankContactDetailsOnRatePage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{\"mediaAlphaAuto\", FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {\"mediaAlphaAuto\", FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#mediaAlphaFlowMarriedWith2VehWithNoPriorInsurance
  test("mediaAlphaFlowMarriedWith2VehWithNoPriorInsurance", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#mediaAlphaFlowMarriedWith2VehWithNoPriorInsurance","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/AceAutoMediaAlphaTests.java","sourceLine":218,"className":"AceAutoMediaAlphaTests","method":"mediaAlphaFlowMarriedWith2VehWithNoPriorInsurance","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{\"mediaAlphaAuto\", FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=29\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {\"mediaAlphaAuto\", FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#validateExistingCustomerKOForAlphaMedia
  test("validateExistingCustomerKOForAlphaMedia", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.AceAutoMediaAlphaTests#validateExistingCustomerKOForAlphaMedia","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/AceAutoMediaAlphaTests.java","sourceLine":246,"className":"AceAutoMediaAlphaTests","method":"validateExistingCustomerKOForAlphaMedia","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{\"mediaAlphaAuto\", FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {\"mediaAlphaAuto\", FFQ_ONEUI})"});
  });

});
