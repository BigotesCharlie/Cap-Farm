// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN", () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testDefaultCoverageValues_MN_None_Unk
  test("testDefaultCoverageValues_MN_None_Unk", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testDefaultCoverageValues_MN_None_Unk","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MN.java","sourceLine":11,"className":"BWDefaultCoverageValuesTests_MN","method":"testDefaultCoverageValues_MN_None_Unk","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testBWDefaultCoverageValues_MN_30K60K_NO_UMBRELLA
  test("testBWDefaultCoverageValues_MN_30K60K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testBWDefaultCoverageValues_MN_30K60K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MN.java","sourceLine":20,"className":"BWDefaultCoverageValuesTests_MN","method":"testBWDefaultCoverageValues_MN_30K60K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = MN)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testDefaultCoverageValues_MN_35K70K_NO_UMBRELLA
  test("testDefaultCoverageValues_MN_35K70K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testDefaultCoverageValues_MN_35K70K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MN.java","sourceLine":27,"className":"BWDefaultCoverageValuesTests_MN","method":"testDefaultCoverageValues_MN_35K70K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testBWDefaultCoverageValues_MN_50K100K_NO_UMBRELLA
  test("testBWDefaultCoverageValues_MN_50K100K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testBWDefaultCoverageValues_MN_50K100K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MN.java","sourceLine":34,"className":"BWDefaultCoverageValuesTests_MN","method":"testBWDefaultCoverageValues_MN_50K100K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = MN)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testBWDefaultCoverageValues_MN_100K200K_NO_UMBRELLA
  test("testBWDefaultCoverageValues_MN_100K200K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testBWDefaultCoverageValues_MN_100K200K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MN.java","sourceLine":41,"className":"BWDefaultCoverageValuesTests_MN","method":"testBWDefaultCoverageValues_MN_100K200K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = MN)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testBWDefaultCoverageValues_MN_100K300K_NO_UMBRELLA
  test("testBWDefaultCoverageValues_MN_100K300K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testBWDefaultCoverageValues_MN_100K300K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MN.java","sourceLine":48,"className":"BWDefaultCoverageValuesTests_MN","method":"testBWDefaultCoverageValues_MN_100K300K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = MN)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testBWDefaultCoverageValues_MN_250K500K_NO_UMBRELLA
  test("testBWDefaultCoverageValues_MN_250K500K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testBWDefaultCoverageValues_MN_250K500K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MN.java","sourceLine":55,"className":"BWDefaultCoverageValuesTests_MN","method":"testBWDefaultCoverageValues_MN_250K500K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = MN)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testBWDefaultCoverageValues_MN_500K500K_NO_UMBRELLA
  test("testBWDefaultCoverageValues_MN_500K500K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testBWDefaultCoverageValues_MN_500K500K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MN.java","sourceLine":62,"className":"BWDefaultCoverageValuesTests_MN","method":"testBWDefaultCoverageValues_MN_500K500K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = MN)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testDefaultCoverageValues_MN_500K_NO_UMBRELLA
  test("testDefaultCoverageValues_MN_500K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MN#testDefaultCoverageValues_MN_500K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MN.java","sourceLine":69,"className":"BWDefaultCoverageValuesTests_MN","method":"testDefaultCoverageValues_MN_500K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

});
