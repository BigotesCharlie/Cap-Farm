// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.PageValidationScenarios', () => {
  // legacy-id: com.farmers.ffq.auto.PageValidationScenarios#autoPageValidationTests
  test('autoPageValidationTests', async ({ page, sqlAutoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, sqlAutoData, {
      legacyId: 'com.farmers.ffq.auto.PageValidationScenarios#autoPageValidationTests',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/PageValidationScenarios.java',
      sourceLine: 22,
      className: 'PageValidationScenarios',
      method: 'autoPageValidationTests',
      parameters: 'SqlApplicant applicant',
      dataProvider: 'SqlDataProviders.AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER',
      dataProviderClass: 'SqlDataProviders.class',
      testName: '',
      groups: 'REGRESSION',
      annotation:
        '@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {NY})}, dataProviderClass = SqlDataProviders.class, groups = REGRESSION)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.PageValidationScenarios#mobileAutoPageValidationTests
  test('mobileAutoPageValidationTests', async ({ page, sqlAutoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, sqlAutoData, {
      legacyId: 'com.farmers.ffq.auto.PageValidationScenarios#mobileAutoPageValidationTests',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/PageValidationScenarios.java',
      sourceLine: 27,
      className: 'PageValidationScenarios',
      method: 'mobileAutoPageValidationTests',
      parameters: 'SqlApplicant applicant',
      dataProvider: 'SqlDataProviders.AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER',
      dataProviderClass: 'SqlDataProviders.class',
      testName: '',
      groups: '{MOBILE_REGRESSION}',
      annotation:
        '@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {NY})}, dataProviderClass = SqlDataProviders.class, groups = {MOBILE_REGRESSION})',
    });
  });
});
