// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.DigitalMonetizationTests", () => {
  // legacy-id: com.farmers.ffq.auto.DigitalMonetizationTests#testDirectToDMPage
  test.skip("testDirectToDMPage", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DigitalMonetizationTests#testDirectToDMPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DigitalMonetizationTests.java","sourceLine":39,"className":"DigitalMonetizationTests","method":"testDirectToDMPage","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, DIGITAL_MONETIZATION}","annotation":"@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CA, GA, NY})}, groups = {REGRESSION, DIGITAL_MONETIZATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.DigitalMonetizationTests#testAutoFGIANoThanks
  test.skip("testAutoFGIANoThanks", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DigitalMonetizationTests#testAutoFGIANoThanks","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DigitalMonetizationTests.java","sourceLine":46,"className":"DigitalMonetizationTests","method":"testAutoFGIANoThanks","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, DIGITAL_MONETIZATION}","annotation":"@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {NC, NV})}, groups = {REGRESSION, DIGITAL_MONETIZATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.DigitalMonetizationTests#testAutoApplicantCurrentlyInsured
  test.skip("testAutoApplicantCurrentlyInsured", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DigitalMonetizationTests#testAutoApplicantCurrentlyInsured","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DigitalMonetizationTests.java","sourceLine":53,"className":"DigitalMonetizationTests","method":"testAutoApplicantCurrentlyInsured","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, DIGITAL_MONETIZATION}","annotation":"@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CT, KY, LA, MS, NJ})}, groups = {REGRESSION, DIGITAL_MONETIZATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.DigitalMonetizationTests#testAutoApplicantCurrentlyNotInsuredDontUseBristolWest
  test.skip("testAutoApplicantCurrentlyNotInsuredDontUseBristolWest", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DigitalMonetizationTests#testAutoApplicantCurrentlyNotInsuredDontUseBristolWest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DigitalMonetizationTests.java","sourceLine":61,"className":"DigitalMonetizationTests","method":"testAutoApplicantCurrentlyNotInsuredDontUseBristolWest","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, DIGITAL_MONETIZATION}","annotation":"@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CT, KY, LA, MS, NJ})}, groups = {REGRESSION, DIGITAL_MONETIZATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.DigitalMonetizationTests#testAutoApplicantCurrentlyNotInsuredUseBristolWest
  test.skip("testAutoApplicantCurrentlyNotInsuredUseBristolWest", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DigitalMonetizationTests#testAutoApplicantCurrentlyNotInsuredUseBristolWest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DigitalMonetizationTests.java","sourceLine":70,"className":"DigitalMonetizationTests","method":"testAutoApplicantCurrentlyNotInsuredUseBristolWest","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, DIGITAL_MONETIZATION}","annotation":"@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CT, KY, LA, MS, NJ})}, groups = {REGRESSION, DIGITAL_MONETIZATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.DigitalMonetizationTests#testAutoContinueToFGIA
  test.skip("testAutoContinueToFGIA", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DigitalMonetizationTests#testAutoContinueToFGIA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DigitalMonetizationTests.java","sourceLine":79,"className":"DigitalMonetizationTests","method":"testAutoContinueToFGIA","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, DIGITAL_MONETIZATION}","annotation":"@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {NC, NV})}, groups = {REGRESSION, DIGITAL_MONETIZATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.DigitalMonetizationTests#testAutoCurrentlyInsuredContinueToFGIA
  test.skip("testAutoCurrentlyInsuredContinueToFGIA", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DigitalMonetizationTests#testAutoCurrentlyInsuredContinueToFGIA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DigitalMonetizationTests.java","sourceLine":87,"className":"DigitalMonetizationTests","method":"testAutoCurrentlyInsuredContinueToFGIA","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, DIGITAL_MONETIZATION}","annotation":"@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CT, KY, MA})}, groups = {REGRESSION, DIGITAL_MONETIZATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.DigitalMonetizationTests#testAutoCurrentlyNotInsuredContinueToFGIA
  test.skip("testAutoCurrentlyNotInsuredContinueToFGIA", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DigitalMonetizationTests#testAutoCurrentlyNotInsuredContinueToFGIA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DigitalMonetizationTests.java","sourceLine":96,"className":"DigitalMonetizationTests","method":"testAutoCurrentlyNotInsuredContinueToFGIA","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, DIGITAL_MONETIZATION}","annotation":"@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CT, KY, MA})}, groups = {REGRESSION, DIGITAL_MONETIZATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.DigitalMonetizationTests#testAutoApplicantDontUseBristolWest
  test.skip("testAutoApplicantDontUseBristolWest", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DigitalMonetizationTests#testAutoApplicantDontUseBristolWest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DigitalMonetizationTests.java","sourceLine":106,"className":"DigitalMonetizationTests","method":"testAutoApplicantDontUseBristolWest","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, DIGITAL_MONETIZATION}","annotation":"@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {FL})}, groups = {REGRESSION, DIGITAL_MONETIZATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.DigitalMonetizationTests#testAutoApplicantUseBristolWest
  test.skip("testAutoApplicantUseBristolWest", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DigitalMonetizationTests#testAutoApplicantUseBristolWest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DigitalMonetizationTests.java","sourceLine":114,"className":"DigitalMonetizationTests","method":"testAutoApplicantUseBristolWest","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, DIGITAL_MONETIZATION}","annotation":"@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {FL})}, groups = {REGRESSION, DIGITAL_MONETIZATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.DigitalMonetizationTests#testAutoUsingAWS
  test.skip("testAutoUsingAWS", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DigitalMonetizationTests#testAutoUsingAWS","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DigitalMonetizationTests.java","sourceLine":122,"className":"DigitalMonetizationTests","method":"testAutoUsingAWS","parameters":"SqlApplicant applicant","dataProvider":"SqlDataProviders.ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{REGRESSION, DIGITAL_MONETIZATION}","annotation":"@Test(dataProvider = SqlDataProviders.ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CA, CT, FL, GA, KY, MA, MS, NC, NJ, NV, NY})}, groups = {REGRESSION, DIGITAL_MONETIZATION})"});
  });

});
