// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.ContactInfoAutoPageTest", () => {
  // legacy-id: com.farmers.ffq.auto.ContactInfoAutoPageTest#validateContactInfoPage
  test("validateContactInfoPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.ContactInfoAutoPageTest#validateContactInfoPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/ContactInfoAutoPageTest.java","sourceLine":20,"className":"ContactInfoAutoPageTest","method":"validateContactInfoPage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, CONTACT_INFO}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NC, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})"});
  });

  // legacy-id: com.farmers.ffq.auto.ContactInfoAutoPageTest#validateContactInfoPageErrorMessages
  test("validateContactInfoPageErrorMessages", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.ContactInfoAutoPageTest#validateContactInfoPageErrorMessages","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/ContactInfoAutoPageTest.java","sourceLine":32,"className":"ContactInfoAutoPageTest","method":"validateContactInfoPageErrorMessages","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, CONTACT_INFO}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CO, FL, ID, KS, MO, NC, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})"});
  });

  // legacy-id: com.farmers.ffq.auto.ContactInfoAutoPageTest#validateEarlyShoppingDiscountFunctionality
  test("validateEarlyShoppingDiscountFunctionality", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.ContactInfoAutoPageTest#validateEarlyShoppingDiscountFunctionality","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/ContactInfoAutoPageTest.java","sourceLine":45,"className":"ContactInfoAutoPageTest","method":"validateEarlyShoppingDiscountFunctionality","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, CONTACT_INFO}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NC, NJ, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})"});
  });

  // legacy-id: com.farmers.ffq.auto.ContactInfoAutoPageTest#validateBundleSaveSectionHomeOwnerCheckboxChecked
  test("validateBundleSaveSectionHomeOwnerCheckboxChecked", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.ContactInfoAutoPageTest#validateBundleSaveSectionHomeOwnerCheckboxChecked","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/ContactInfoAutoPageTest.java","sourceLine":57,"className":"ContactInfoAutoPageTest","method":"validateBundleSaveSectionHomeOwnerCheckboxChecked","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, CONTACT_INFO}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NC, NJ, NM, OK, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})"});
  });

  // legacy-id: com.farmers.ffq.auto.ContactInfoAutoPageTest#validateBundleSaveSectionHomeOwnerCheckboxCheckedForCondo
  test("validateBundleSaveSectionHomeOwnerCheckboxCheckedForCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.ContactInfoAutoPageTest#validateBundleSaveSectionHomeOwnerCheckboxCheckedForCondo","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/ContactInfoAutoPageTest.java","sourceLine":76,"className":"ContactInfoAutoPageTest","method":"validateBundleSaveSectionHomeOwnerCheckboxCheckedForCondo","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, CONTACT_INFO}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NC, NJ, NM, OK, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})"});
  });

  // legacy-id: com.farmers.ffq.auto.ContactInfoAutoPageTest#validateBundleSaveSectionHomeOwnerCheckboxNotChecked
  test("validateBundleSaveSectionHomeOwnerCheckboxNotChecked", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.ContactInfoAutoPageTest#validateBundleSaveSectionHomeOwnerCheckboxNotChecked","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/ContactInfoAutoPageTest.java","sourceLine":95,"className":"ContactInfoAutoPageTest","method":"validateBundleSaveSectionHomeOwnerCheckboxNotChecked","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, CONTACT_INFO}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NC, NM, OK, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})"});
  });

  // legacy-id: com.farmers.ffq.auto.ContactInfoAutoPageTest#validatePrimaryResidenceSection
  test("validatePrimaryResidenceSection", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.ContactInfoAutoPageTest#validatePrimaryResidenceSection","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/ContactInfoAutoPageTest.java","sourceLine":114,"className":"ContactInfoAutoPageTest","method":"validatePrimaryResidenceSection","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, CONTACT_INFO}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = MA)}, groups = {FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, CONTACT_INFO})"});
  });

  // legacy-id: com.farmers.ffq.auto.ContactInfoAutoPageTest#validateDefaultBundleSelected_MDMdata
  test("validateDefaultBundleSelected_MDMdata", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.ContactInfoAutoPageTest#validateDefaultBundleSelected_MDMdata","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/ContactInfoAutoPageTest.java","sourceLine":129,"className":"ContactInfoAutoPageTest","method":"validateDefaultBundleSelected_MDMdata","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, CONTACT_INFO}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})"});
  });

  // legacy-id: com.farmers.ffq.auto.ContactInfoAutoPageTest#validateBusinessBundleDiscountIsApplied
  test("validateBusinessBundleDiscountIsApplied", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.ContactInfoAutoPageTest#validateBusinessBundleDiscountIsApplied","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/ContactInfoAutoPageTest.java","sourceLine":142,"className":"ContactInfoAutoPageTest","method":"validateBusinessBundleDiscountIsApplied","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{FFQ_ONEUI, CONTACT_INFO}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = INCLUDED_STATES, values = {MN, NV, OH, IN, MD, IA, KS})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})"});
  });

});
