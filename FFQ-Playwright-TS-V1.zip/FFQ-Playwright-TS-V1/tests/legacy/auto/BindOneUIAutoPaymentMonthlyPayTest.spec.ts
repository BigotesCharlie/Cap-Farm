// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.bind.BindOneUIAutoPaymentMonthlyPayTest', () => {
  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPaymentMonthlyPayTest#autoPaymentMonthlyPayBankPageContentValidation
  test.skip('autoPaymentMonthlyPayBankPageContentValidation', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.bind.BindOneUIAutoPaymentMonthlyPayTest#autoPaymentMonthlyPayBankPageContentValidation',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPaymentMonthlyPayTest.java',
      sourceLine: 23,
      className: 'BindOneUIAutoPaymentMonthlyPayTest',
      method: 'autoPaymentMonthlyPayBankPageContentValidation',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT',
      groups: '{FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPaymentMonthlyPayTest#autoPaymentMonthlyPayCardPageContentValidation
  test.skip('autoPaymentMonthlyPayCardPageContentValidation', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.bind.BindOneUIAutoPaymentMonthlyPayTest#autoPaymentMonthlyPayCardPageContentValidation',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPaymentMonthlyPayTest.java',
      sourceLine: 100,
      className: 'BindOneUIAutoPaymentMonthlyPayTest',
      method: 'autoPaymentMonthlyPayCardPageContentValidation',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT',
      groups: '{FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPaymentMonthlyPayTest#autoPaymentMonthlyPayPageBackAndForthValidation
  test.skip('autoPaymentMonthlyPayPageBackAndForthValidation', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.bind.BindOneUIAutoPaymentMonthlyPayTest#autoPaymentMonthlyPayPageBackAndForthValidation',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPaymentMonthlyPayTest.java',
      sourceLine: 174,
      className: 'BindOneUIAutoPaymentMonthlyPayTest',
      method: 'autoPaymentMonthlyPayPageBackAndForthValidation',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT',
      groups: '{FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPaymentMonthlyPayTest#monthlyPayBankPaymentSidebarValidation
  test.skip('monthlyPayBankPaymentSidebarValidation', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.BindOneUIAutoPaymentMonthlyPayTest#monthlyPayBankPaymentSidebarValidation',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPaymentMonthlyPayTest.java',
      sourceLine: 196,
      className: 'BindOneUIAutoPaymentMonthlyPayTest',
      method: 'monthlyPayBankPaymentSidebarValidation',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT',
      groups: '{FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPaymentMonthlyPayTest#monthlyPayCardPaymentSidebarValidation
  test.skip('monthlyPayCardPaymentSidebarValidation', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.bind.BindOneUIAutoPaymentMonthlyPayTest#monthlyPayCardPaymentSidebarValidation',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPaymentMonthlyPayTest.java',
      sourceLine: 216,
      className: 'BindOneUIAutoPaymentMonthlyPayTest',
      method: 'monthlyPayCardPaymentSidebarValidation',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT',
      groups: '{FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}, enabled = false)',
    });
  });
});
