// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA", () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_None_Unk_NO_UMBRELLA
  test("testDefaultCoverageValues_WA_None_Unk_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_None_Unk_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_WA.java","sourceLine":13,"className":"BWDefaultCoverageValuesTests_WA","method":"testDefaultCoverageValues_WA_None_Unk_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WA)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_25K50K_NO_UMBRELLA
  test("testDefaultCoverageValues_WA_25K50K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_25K50K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_WA.java","sourceLine":22,"className":"BWDefaultCoverageValuesTests_WA","method":"testDefaultCoverageValues_WA_25K50K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WA)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_30K60K_NO_UMBRELLA
  test("testDefaultCoverageValues_WA_30K60K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_30K60K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_WA.java","sourceLine":29,"className":"BWDefaultCoverageValuesTests_WA","method":"testDefaultCoverageValues_WA_30K60K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WA)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_35K70K_NO_UMBRELLA
  test("testDefaultCoverageValues_WA_35K70K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_35K70K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_WA.java","sourceLine":36,"className":"BWDefaultCoverageValuesTests_WA","method":"testDefaultCoverageValues_WA_35K70K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WA)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_50K100K_NO_UMBRELLA
  test("testDefaultCoverageValues_WA_50K100K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_50K100K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_WA.java","sourceLine":43,"className":"BWDefaultCoverageValuesTests_WA","method":"testDefaultCoverageValues_WA_50K100K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WA)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_100K200K_NO_UMBRELLA
  test("testDefaultCoverageValues_WA_100K200K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_100K200K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_WA.java","sourceLine":50,"className":"BWDefaultCoverageValuesTests_WA","method":"testDefaultCoverageValues_WA_100K200K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WA)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_100K300K_NO_UMBRELLA
  test("testDefaultCoverageValues_WA_100K300K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_100K300K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_WA.java","sourceLine":57,"className":"BWDefaultCoverageValuesTests_WA","method":"testDefaultCoverageValues_WA_100K300K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WA)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_250K500K_NO_UMBRELLA
  test("testDefaultCoverageValues_WA_250K500K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_250K500K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_WA.java","sourceLine":64,"className":"BWDefaultCoverageValuesTests_WA","method":"testDefaultCoverageValues_WA_250K500K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WA)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_500K500K_NO_UMBRELLA
  test("testDefaultCoverageValues_WA_500K500K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_500K500K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_WA.java","sourceLine":71,"className":"BWDefaultCoverageValuesTests_WA","method":"testDefaultCoverageValues_WA_500K500K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WA)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_500K_NO_UMBRELLA
  test("testDefaultCoverageValues_WA_500K_NO_UMBRELLA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_WA#testDefaultCoverageValues_WA_500K_NO_UMBRELLA","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_WA.java","sourceLine":78,"className":"BWDefaultCoverageValuesTests_WA","method":"testDefaultCoverageValues_WA_500K_NO_UMBRELLA","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WA)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

});
