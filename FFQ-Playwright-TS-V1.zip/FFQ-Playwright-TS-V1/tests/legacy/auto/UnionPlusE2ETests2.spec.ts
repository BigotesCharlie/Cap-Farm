// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.e2e.UnionPlusE2ETests2", () => {
  // legacy-id: com.farmers.ffq.auto.e2e.UnionPlusE2ETests2#testUnionPlusE2E
  test("testUnionPlusE2E", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.e2e.UnionPlusE2ETests2#testUnionPlusE2E","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/e2e/UnionPlusE2ETests2.java","sourceLine":13,"className":"UnionPlusE2ETests2","method":"testUnionPlusE2E","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES","groups":"{FFQ_ONEUI, QUOTE_E2E}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = {\"applicantId=1\"}),}, groups = {FFQ_ONEUI, QUOTE_E2E})"});
  });

});
