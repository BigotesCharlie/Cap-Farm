// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.bind.BindOneUIAutoPaymentFullPayTest", () => {
  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPaymentFullPayTest#autoPaymentPayInFullPageContentValidation
  test.skip("autoPaymentPayInFullPageContentValidation", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.bind.BindOneUIAutoPaymentFullPayTest#autoPaymentPayInFullPageContentValidation","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPaymentFullPayTest.java","sourceLine":20,"className":"BindOneUIAutoPaymentFullPayTest","method":"autoPaymentPayInFullPageContentValidation","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT","groups":"{FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPaymentFullPayTest#autoPaymentPayInFullPageBackAndForthValidation
  test.skip("autoPaymentPayInFullPageBackAndForthValidation", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.bind.BindOneUIAutoPaymentFullPayTest#autoPaymentPayInFullPageBackAndForthValidation","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPaymentFullPayTest.java","sourceLine":67,"className":"BindOneUIAutoPaymentFullPayTest","method":"autoPaymentPayInFullPageBackAndForthValidation","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT","groups":"{FFQ_ONEUI, FFQ_BIND_PAYINFULL_PAGE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_PAYINFULL_PAGE}, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPaymentFullPayTest#autoPaymentPayInFullPageSetUpPaymentMethodValidation
  test.skip("autoPaymentPayInFullPageSetUpPaymentMethodValidation", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.bind.BindOneUIAutoPaymentFullPayTest#autoPaymentPayInFullPageSetUpPaymentMethodValidation","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPaymentFullPayTest.java","sourceLine":86,"className":"BindOneUIAutoPaymentFullPayTest","method":"autoPaymentPayInFullPageSetUpPaymentMethodValidation","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT","groups":"{FFQ_ONEUI, FFQ_BIND_PAYINFULL_PAGE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_PAYINFULL_PAGE}, enabled = false)"});
  });

});
