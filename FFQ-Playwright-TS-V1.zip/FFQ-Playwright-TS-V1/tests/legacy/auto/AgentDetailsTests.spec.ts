// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.AgentDetailsTests", () => {
  // legacy-id: com.farmers.ffq.auto.AgentDetailsTests#agentDetailsLabelAndErrorTests
  test.skip("agentDetailsLabelAndErrorTests", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AgentDetailsTests#agentDetailsLabelAndErrorTests","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AgentDetailsTests.java","sourceLine":30,"className":"AgentDetailsTests","method":"agentDetailsLabelAndErrorTests","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, AGENT_DETAILS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AGENT_DETAILS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AgentDetailsTests#agentDetailsUsageTest
  test.skip("agentDetailsUsageTest", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AgentDetailsTests#agentDetailsUsageTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AgentDetailsTests.java","sourceLine":57,"className":"AgentDetailsTests","method":"agentDetailsUsageTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, PROD_ENVIRONMENT, AGENT_DETAILS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ})}, groups = {FFQ_ONEUI, PROD_ENVIRONMENT, AGENT_DETAILS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AgentDetailsTests#validateNoDateNoTimeSlotScenarioAndSingleOneOfThem
  test.skip("validateNoDateNoTimeSlotScenarioAndSingleOneOfThem", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AgentDetailsTests#validateNoDateNoTimeSlotScenarioAndSingleOneOfThem","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AgentDetailsTests.java","sourceLine":100,"className":"AgentDetailsTests","method":"validateNoDateNoTimeSlotScenarioAndSingleOneOfThem","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, AGENT_DETAILS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AGENT_DETAILS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AgentDetailsTests#validateAgentIsDisplayedInAllPages
  test("validateAgentIsDisplayedInAllPages", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AgentDetailsTests#validateAgentIsDisplayedInAllPages","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AgentDetailsTests.java","sourceLine":118,"className":"AgentDetailsTests","method":"validateAgentIsDisplayedInAllPages","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, AGENT_DETAILS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MA, NC, FL, WA, LA, CA, MS}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AGENT_DETAILS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AgentDetailsTests#validateCustomerEmailIdAndPhoneNumberIsPrefilledInContactInfoPageIfEnteredInContactAgentSection
  test.skip("validateCustomerEmailIdAndPhoneNumberIsPrefilledInContactInfoPageIfEnteredInContactAgentSection", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AgentDetailsTests#validateCustomerEmailIdAndPhoneNumberIsPrefilledInContactInfoPageIfEnteredInContactAgentSection","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AgentDetailsTests.java","sourceLine":217,"className":"AgentDetailsTests","method":"validateCustomerEmailIdAndPhoneNumberIsPrefilledInContactInfoPageIfEnteredInContactAgentSection","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, AGENT_DETAILS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AGENT_DETAILS})"});
  });

  // legacy-id: com.farmers.ffq.auto.AgentDetailsTests#validatePEWCChangesAgentSectionAtBottom
  test("validatePEWCChangesAgentSectionAtBottom", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.AgentDetailsTests#validatePEWCChangesAgentSectionAtBottom","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/AgentDetailsTests.java","sourceLine":280,"className":"AgentDetailsTests","method":"validatePEWCChangesAgentSectionAtBottom","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, AGENT_DETAILS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AL, FL, MI, NJ, CO, OR}), @CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AGENT_DETAILS})"});
  });

});
