// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.QuoteScenariosOneUi", () => {
  // legacy-id: com.farmers.ffq.auto.QuoteScenariosOneUi#nameAndDobOneUIAutoQuote
  test("nameAndDobOneUIAutoQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.QuoteScenariosOneUi#nameAndDobOneUIAutoQuote","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QuoteScenariosOneUi.java","sourceLine":20,"className":"QuoteScenariosOneUi","method":"nameAndDobOneUIAutoQuote","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{QUOTEONEUI, FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTEONEUI, FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.QuoteScenariosOneUi#ratedQuoteWithADPFDataTest
  test("ratedQuoteWithADPFDataTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.QuoteScenariosOneUi#ratedQuoteWithADPFDataTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QuoteScenariosOneUi.java","sourceLine":27,"className":"QuoteScenariosOneUi","method":"ratedQuoteWithADPFDataTest","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"FFQ_ONEUI","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, groups = FFQ_ONEUI)"});
  });

  // legacy-id: com.farmers.ffq.auto.QuoteScenariosOneUi#testValidatePremiumAccuracyInQuote_QuoteScenariosOneUi
  test("testValidatePremiumAccuracyInQuote_QuoteScenariosOneUi", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.QuoteScenariosOneUi#testValidatePremiumAccuracyInQuote_QuoteScenariosOneUi","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QuoteScenariosOneUi.java","sourceLine":34,"className":"QuoteScenariosOneUi","method":"testValidatePremiumAccuracyInQuote_QuoteScenariosOneUi","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, QUOTEONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTEONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.QuoteScenariosOneUi#aceAutoPEWCScreen
  test("aceAutoPEWCScreen", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.QuoteScenariosOneUi#aceAutoPEWCScreen","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/QuoteScenariosOneUi.java","sourceLine":44,"className":"QuoteScenariosOneUi","method":"aceAutoPEWCScreen","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{PEWC}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {PEWC})"});
  });

});
