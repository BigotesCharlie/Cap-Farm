// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.VehicleDriverAssignmentPageTests", () => {
  // legacy-id: com.farmers.ffq.auto.VehicleDriverAssignmentPageTests#testDriversEqualToVehicles
  test.skip("testDriversEqualToVehicles", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.VehicleDriverAssignmentPageTests#testDriversEqualToVehicles","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/VehicleDriverAssignmentPageTests.java","sourceLine":28,"className":"VehicleDriverAssignmentPageTests","method":"testDriversEqualToVehicles","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, VEHICLE_DRIVER_ASSIGNMENT}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=30\"}), @CustomAttribute(name = CA)}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLE_DRIVER_ASSIGNMENT})"});
  });

  // legacy-id: com.farmers.ffq.auto.VehicleDriverAssignmentPageTests#testDriversGreaterThanVehicles
  test.skip("testDriversGreaterThanVehicles", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.VehicleDriverAssignmentPageTests#testDriversGreaterThanVehicles","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/VehicleDriverAssignmentPageTests.java","sourceLine":45,"className":"VehicleDriverAssignmentPageTests","method":"testDriversGreaterThanVehicles","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, VEHICLE_DRIVER_ASSIGNMENT}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=30\"}), @CustomAttribute(name = CA)}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLE_DRIVER_ASSIGNMENT})"});
  });

  // legacy-id: com.farmers.ffq.auto.VehicleDriverAssignmentPageTests#testDriversLessThanVehicles
  test.skip("testDriversLessThanVehicles", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.VehicleDriverAssignmentPageTests#testDriversLessThanVehicles","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/VehicleDriverAssignmentPageTests.java","sourceLine":63,"className":"VehicleDriverAssignmentPageTests","method":"testDriversLessThanVehicles","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, VEHICLE_DRIVER_ASSIGNMENT}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=4\"}), @CustomAttribute(name = CA)}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLE_DRIVER_ASSIGNMENT})"});
  });

  // legacy-id: com.farmers.ffq.auto.VehicleDriverAssignmentPageTests#pageContentAndErrorValidation
  test.skip("pageContentAndErrorValidation", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.VehicleDriverAssignmentPageTests#pageContentAndErrorValidation","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/VehicleDriverAssignmentPageTests.java","sourceLine":87,"className":"VehicleDriverAssignmentPageTests","method":"pageContentAndErrorValidation","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{ADA_SUITE, FFQ_ONEUI, ACE_AUTO_ADA_SUITE, VEHICLE_DRIVER_ASSIGNMENT}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=10\"}), @CustomAttribute(name = CA)}, dataProviderClass = AutoDataProviders.class, groups = {ADA_SUITE, FFQ_ONEUI, ACE_AUTO_ADA_SUITE, VEHICLE_DRIVER_ASSIGNMENT})"});
  });

  // legacy-id: com.farmers.ffq.auto.VehicleDriverAssignmentPageTests#validatePageIsSubmittedWithFirstCTAClick
  test.skip("validatePageIsSubmittedWithFirstCTAClick", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.VehicleDriverAssignmentPageTests#validatePageIsSubmittedWithFirstCTAClick","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/VehicleDriverAssignmentPageTests.java","sourceLine":121,"className":"VehicleDriverAssignmentPageTests","method":"validatePageIsSubmittedWithFirstCTAClick","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, VEHICLE_DRIVER_ASSIGNMENT}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=36\"}), @CustomAttribute(name = INCLUDED_STATES, values = {VA, CA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLE_DRIVER_ASSIGNMENT})"});
  });

});
