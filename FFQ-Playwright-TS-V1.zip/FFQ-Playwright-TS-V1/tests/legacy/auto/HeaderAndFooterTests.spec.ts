// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.HeaderAndFooterTests", () => {
  // legacy-id: com.farmers.ffq.auto.HeaderAndFooterTests#testHeaderAndFooterDesktopMode
  test("testHeaderAndFooterDesktopMode", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeaderAndFooterTests#testHeaderAndFooterDesktopMode","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeaderAndFooterTests.java","sourceLine":19,"className":"HeaderAndFooterTests","method":"testHeaderAndFooterDesktopMode","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, HEADER_AND_FOOTER_TEST}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeaderAndFooterTests#testHeaderNavigationDesktopMode
  test("testHeaderNavigationDesktopMode", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeaderAndFooterTests#testHeaderNavigationDesktopMode","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeaderAndFooterTests.java","sourceLine":31,"className":"HeaderAndFooterTests","method":"testHeaderNavigationDesktopMode","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HEADER_AND_FOOTER_TEST}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ}), @CustomAttribute (name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeaderAndFooterTests#testDisplayedPhoneNumberNameAndDOBPage
  test.skip("testDisplayedPhoneNumberNameAndDOBPage", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeaderAndFooterTests#testDisplayedPhoneNumberNameAndDOBPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeaderAndFooterTests.java","sourceLine":51,"className":"HeaderAndFooterTests","method":"testDisplayedPhoneNumberNameAndDOBPage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, HEADER_AND_FOOTER_TEST}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, FL, GA, KY, LA, MA, MS, NC, NJ, NV, NY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeaderAndFooterTests#testDisplayedPhoneNumberAddressPage
  test.skip("testDisplayedPhoneNumberAddressPage", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeaderAndFooterTests#testDisplayedPhoneNumberAddressPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeaderAndFooterTests.java","sourceLine":58,"className":"HeaderAndFooterTests","method":"testDisplayedPhoneNumberAddressPage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, HEADER_AND_FOOTER_TEST}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, FL, GA, KY, LA, MA, MS, NC, NJ, NV, NY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeaderAndFooterTests#testDisplayedPhoneNumberWhoShouldWeInsurePage
  test.skip("testDisplayedPhoneNumberWhoShouldWeInsurePage", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeaderAndFooterTests#testDisplayedPhoneNumberWhoShouldWeInsurePage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeaderAndFooterTests.java","sourceLine":65,"className":"HeaderAndFooterTests","method":"testDisplayedPhoneNumberWhoShouldWeInsurePage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, HEADER_AND_FOOTER_TEST}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, FL, GA, KY, LA, MA, MS, NC, NJ, NV, NY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeaderAndFooterTests#testDisplayedPhoneNumberVehicleReviewPage
  test.skip("testDisplayedPhoneNumberVehicleReviewPage", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeaderAndFooterTests#testDisplayedPhoneNumberVehicleReviewPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeaderAndFooterTests.java","sourceLine":72,"className":"HeaderAndFooterTests","method":"testDisplayedPhoneNumberVehicleReviewPage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, HEADER_AND_FOOTER_TEST}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, FL, GA, KY, LA, MA, MS, NC, NJ, NV, NY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeaderAndFooterTests#testDisplayedPhoneNumberDriverReviewPage
  test.skip("testDisplayedPhoneNumberDriverReviewPage", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeaderAndFooterTests#testDisplayedPhoneNumberDriverReviewPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeaderAndFooterTests.java","sourceLine":79,"className":"HeaderAndFooterTests","method":"testDisplayedPhoneNumberDriverReviewPage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, HEADER_AND_FOOTER_TEST}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, FL, GA, KY, LA, MA, MS, NC, NJ, NV, NY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeaderAndFooterTests#testDisplayedPhoneNumberQuoteReviewPage
  test.skip("testDisplayedPhoneNumberQuoteReviewPage", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeaderAndFooterTests#testDisplayedPhoneNumberQuoteReviewPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeaderAndFooterTests.java","sourceLine":86,"className":"HeaderAndFooterTests","method":"testDisplayedPhoneNumberQuoteReviewPage","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, HEADER_AND_FOOTER_TEST}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, FL, GA, KY, LA, MA, MS, NC, NJ, NV, NY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeaderAndFooterTests#validateKOPageHasOnlyFarmersLogoInHeader
  test.skip("validateKOPageHasOnlyFarmersLogoInHeader", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeaderAndFooterTests#validateKOPageHasOnlyFarmersLogoInHeader","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeaderAndFooterTests.java","sourceLine":94,"className":"HeaderAndFooterTests","method":"validateKOPageHasOnlyFarmersLogoInHeader","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, HEADER_AND_FOOTER_TEST}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})"});
  });

});
