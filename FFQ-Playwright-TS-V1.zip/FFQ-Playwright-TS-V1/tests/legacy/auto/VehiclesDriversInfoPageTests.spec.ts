// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.VehiclesDriversInfoPageTests', () => {
  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateEVProjectAndDiscountSectionOnVehiclesDriversReviewPage
  test('validateEVProjectAndDiscountSectionOnVehiclesDriversReviewPage', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateEVProjectAndDiscountSectionOnVehiclesDriversReviewPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 31,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateEVProjectAndDiscountSectionOnVehiclesDriversReviewPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateAdpfDataPrefilledCorrectly
  test('validateAdpfDataPrefilledCorrectly', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateAdpfDataPrefilledCorrectly',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 59,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateAdpfDataPrefilledCorrectly',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70", "72", "73", "74"})}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMarriedButtonAndNestedSpouseSideSheet
  test('validateMarriedButtonAndNestedSpouseSideSheet', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMarriedButtonAndNestedSpouseSideSheet',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 71,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateMarriedButtonAndNestedSpouseSideSheet',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70", "72"})}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateVehDriverErrorMessagesAndFilledValues
  test('validateVehDriverErrorMessagesAndFilledValues', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateVehDriverErrorMessagesAndFilledValues',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 83,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateVehDriverErrorMessagesAndFilledValues',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#testFaultyVINErrorAndVehicleCardReflectionWithUpdatedYMMDetails
  test('testFaultyVINErrorAndVehicleCardReflectionWithUpdatedYMMDetails', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#testFaultyVINErrorAndVehicleCardReflectionWithUpdatedYMMDetails',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 108,
      className: 'VehiclesDriversInfoPageTests',
      method: 'testFaultyVINErrorAndVehicleCardReflectionWithUpdatedYMMDetails',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MN, WA, IL, OK, VA, AZ, MO, OH, TN, NM, ID, IN, AR, CO, MI, OR})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateVehDriverPageToolTips
  test('validateVehDriverPageToolTips', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateVehDriverPageToolTips',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 124,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateVehDriverPageToolTips',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70"})}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateNonDriverSpouseQuestions
  test('validateNonDriverSpouseQuestions', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateNonDriverSpouseQuestions',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 142,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateNonDriverSpouseQuestions',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {IL, AZ, WA, OH, MO, OK, OR, MI}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateNonDriverSpouseValuesPassedCorrectlyForFarmers
  test('validateNonDriverSpouseValuesPassedCorrectlyForFarmers', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateNonDriverSpouseValuesPassedCorrectlyForFarmers',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 171,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateNonDriverSpouseValuesPassedCorrectlyForFarmers',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {IL, AZ, WA, OH, MO, OK, OR, MI}), @CustomAttribute(name = FILTER, values = "applicantId=12")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateNonDriverSpouseValuesPassedCorrectlyForBW
  test('validateNonDriverSpouseValuesPassedCorrectlyForBW', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateNonDriverSpouseValuesPassedCorrectlyForBW',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 208,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateNonDriverSpouseValuesPassedCorrectlyForBW',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {IL, AZ, WA, OH, MO, OK, OR, MI}), @CustomAttribute(name = FILTER, values = "applicantId=12")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_Married
  test('validateDriverCheckboxesAndContinue_Married', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_Married',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 236,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateDriverCheckboxesAndContinue_Married',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=31"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateCheckboxesAfterRetrievalOfRatedQuote
  test('validateCheckboxesAfterRetrievalOfRatedQuote', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateCheckboxesAfterRetrievalOfRatedQuote',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 259,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateCheckboxesAfterRetrievalOfRatedQuote',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, BDQ_TESTS, BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=7"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS, BW_ACE_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_YoungApplicant
  test('validateDriverCheckboxesAndContinue_YoungApplicant', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_YoungApplicant',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 290,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateDriverCheckboxesAndContinue_YoungApplicant',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=22"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_OldApplicant
  test('validateDriverCheckboxesAndContinue_OldApplicant', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_OldApplicant',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 313,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateDriverCheckboxesAndContinue_OldApplicant',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=7"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_Applicant_With_Incidents
  test('validateDriverCheckboxesAndContinue_Applicant_With_Incidents', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_Applicant_With_Incidents',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 336,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateDriverCheckboxesAndContinue_Applicant_With_Incidents',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=28"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_4_AdditionalDrivers
  test('validateDriverCheckboxesAndContinue_4_AdditionalDrivers', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_4_AdditionalDrivers',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 359,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateDriverCheckboxesAndContinue_4_AdditionalDrivers',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=12"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_3_AdditionalDrivers
  test('validateDriverCheckboxesAndContinue_3_AdditionalDrivers', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_3_AdditionalDrivers',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 386,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateDriverCheckboxesAndContinue_3_AdditionalDrivers',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=31"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_2_AdditionalDrivers
  test('validateDriverCheckboxesAndContinue_2_AdditionalDrivers', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateDriverCheckboxesAndContinue_2_AdditionalDrivers',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 409,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateDriverCheckboxesAndContinue_2_AdditionalDrivers',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=30"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#updateVehicleVinWhichWasAddedByYMMAndValidateVehicleCard
  test('updateVehicleVinWhichWasAddedByYMMAndValidateVehicleCard', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#updateVehicleVinWhichWasAddedByYMMAndValidateVehicleCard',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 450,
      className: 'VehiclesDriversInfoPageTests',
      method: 'updateVehicleVinWhichWasAddedByYMMAndValidateVehicleCard',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=8"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#updateVehicleYMMWhichWasAddedByVINAndValidateVehicleCard
  test('updateVehicleYMMWhichWasAddedByVINAndValidateVehicleCard', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#updateVehicleYMMWhichWasAddedByVINAndValidateVehicleCard',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 488,
      className: 'VehiclesDriversInfoPageTests',
      method: 'updateVehicleYMMWhichWasAddedByVINAndValidateVehicleCard',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=8"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#updateNewVehicleVinWhichWasAddedByVINAndValidateVehicleCard
  test('updateNewVehicleVinWhichWasAddedByVINAndValidateVehicleCard', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#updateNewVehicleVinWhichWasAddedByVINAndValidateVehicleCard',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 527,
      className: 'VehiclesDriversInfoPageTests',
      method: 'updateNewVehicleVinWhichWasAddedByVINAndValidateVehicleCard',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=8"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#editVehicleByAddingNewVinButDoNotSaveVehicleAndValidateVehicleCard
  test('editVehicleByAddingNewVinButDoNotSaveVehicleAndValidateVehicleCard', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#editVehicleByAddingNewVinButDoNotSaveVehicleAndValidateVehicleCard',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 568,
      className: 'VehiclesDriversInfoPageTests',
      method: 'editVehicleByAddingNewVinButDoNotSaveVehicleAndValidateVehicleCard',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=8"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateQuoteSummaryPageWith2Veh2DriverAdpfData
  test('validateQuoteSummaryPageWith2Veh2DriverAdpfData', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateQuoteSummaryPageWith2Veh2DriverAdpfData',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 613,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateQuoteSummaryPageWith2Veh2DriverAdpfData',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70"})}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMatureDriverOrDefensiveDriverDiscountFarmers
  test('validateMatureDriverOrDefensiveDriverDiscountFarmers', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMatureDriverOrDefensiveDriverDiscountFarmers',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 628,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateMatureDriverOrDefensiveDriverDiscountFarmers',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=26"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, ID, IL, MN, OH, OK, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMatureDriverDiscountNotPresentFarmers
  test('validateMatureDriverDiscountNotPresentFarmers', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMatureDriverDiscountNotPresentFarmers',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 690,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateMatureDriverDiscountNotPresentFarmers',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=7"}), @CustomAttribute(name = INCLUDED_STATES, values = {MO, IN})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMatureDefensiveDriverDiscountForBWBrightLine
  test('validateMatureDefensiveDriverDiscountForBWBrightLine', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMatureDefensiveDriverDiscountForBWBrightLine',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 720,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateMatureDefensiveDriverDiscountForBWBrightLine',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=26"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, ID, IL, MN, NM, OH, OK, TN, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMatureDefensiveDriverDiscountNotPresentBWBrightLine
  test('validateMatureDefensiveDriverDiscountNotPresentBWBrightLine', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMatureDefensiveDriverDiscountNotPresentBWBrightLine',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 772,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateMatureDefensiveDriverDiscountNotPresentBWBrightLine',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=26"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, IN, VA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMatureDriverOrDefensiveDriverDiscountBDQ
  test('validateMatureDriverOrDefensiveDriverDiscountBDQ', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMatureDriverOrDefensiveDriverDiscountBDQ',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 819,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateMatureDriverOrDefensiveDriverDiscountBDQ',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=26"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, ID, IL, MN, NM, OH, OK, TN, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMatureDefensiveDriverDiscountNotPresentBDQ
  test('validateMatureDefensiveDriverDiscountNotPresentBDQ', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateMatureDefensiveDriverDiscountNotPresentBDQ',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 857,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateMatureDefensiveDriverDiscountNotPresentBDQ',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=26"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, IN, MO, VA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateNewlyAddedVehicleGotMergedWithExistingVehicleHavingSameVin
  test('validateNewlyAddedVehicleGotMergedWithExistingVehicleHavingSameVin', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateNewlyAddedVehicleGotMergedWithExistingVehicleHavingSameVin',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 884,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateNewlyAddedVehicleGotMergedWithExistingVehicleHavingSameVin',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70", "72"})}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateVehicleWithDifferentVinGotAddedAndNotMerged
  test('validateVehicleWithDifferentVinGotAddedAndNotMerged', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateVehicleWithDifferentVinGotAddedAndNotMerged',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 908,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateVehicleWithDifferentVinGotAddedAndNotMerged',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70", "72"})}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateVehicleWithPartialInfoGetsUpdatedAndCheckboxGetsCheckedWhenWeAddAnotherVehicleWithSameVin
  test('validateVehicleWithPartialInfoGetsUpdatedAndCheckboxGetsCheckedWhenWeAddAnotherVehicleWithSameVin', async ({
    page,
    autoData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateVehicleWithPartialInfoGetsUpdatedAndCheckboxGetsCheckedWhenWeAddAnotherVehicleWithSameVin',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 932,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateVehicleWithPartialInfoGetsUpdatedAndCheckboxGetsCheckedWhenWeAddAnotherVehicleWithSameVin',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.INCOMPLETE_DRIVERS_AND_VEHICLES)}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateNewlyAddedDriverGotMergedAndNameGotUnmaskedWhenDriverWithSameDetailsAddedAgain
  test('validateNewlyAddedDriverGotMergedAndNameGotUnmaskedWhenDriverWithSameDetailsAddedAgain', async ({
    page,
    autoData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateNewlyAddedDriverGotMergedAndNameGotUnmaskedWhenDriverWithSameDetailsAddedAgain',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 967,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateNewlyAddedDriverGotMergedAndNameGotUnmaskedWhenDriverWithSameDetailsAddedAgain',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_0)}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateNewDriverGotAddedWithExistingDriverDetailsAndDifferentDOB
  test('validateNewDriverGotAddedWithExistingDriverDetailsAndDifferentDOB', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateNewDriverGotAddedWithExistingDriverDetailsAndDifferentDOB',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 992,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateNewDriverGotAddedWithExistingDriverDetailsAndDifferentDOB',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_0)}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateErrorWhenAddingVehicleWithSameVinSecondTime
  test('validateErrorWhenAddingVehicleWithSameVinSecondTime', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateErrorWhenAddingVehicleWithSameVinSecondTime',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 1019,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateErrorWhenAddingVehicleWithSameVinSecondTime',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70", "72"})}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateErrorWhenAddingDriverWithSameDetailsSecondTime
  test('validateErrorWhenAddingDriverWithSameDetailsSecondTime', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateErrorWhenAddingDriverWithSameDetailsSecondTime',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 1052,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateErrorWhenAddingDriverWithSameDetailsSecondTime',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_0)}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateGaragingAddressFunctionalityAndValidateValueAfterRetrieval
  test('validateGaragingAddressFunctionalityAndValidateValueAfterRetrieval', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateGaragingAddressFunctionalityAndValidateValueAfterRetrieval',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 1079,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateGaragingAddressFunctionalityAndValidateValueAfterRetrieval',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=26"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, ID, IL, MN, NM, OH, OK, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateIfTheYearDropdownDisplays2027ForAllStates
  test('validateIfTheYearDropdownDisplays2027ForAllStates', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#validateIfTheYearDropdownDisplays2027ForAllStates',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 1120,
      className: 'VehiclesDriversInfoPageTests',
      method: 'validateIfTheYearDropdownDisplays2027ForAllStates',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#testUpdateNewYMMAndVINAndVehicleCardReflectionWithUpdatedYMMDetails
  test('testUpdateNewYMMAndVINAndVehicleCardReflectionWithUpdatedYMMDetails', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#testUpdateNewYMMAndVINAndVehicleCardReflectionWithUpdatedYMMDetails',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 1183,
      className: 'VehiclesDriversInfoPageTests',
      method: 'testUpdateNewYMMAndVINAndVehicleCardReflectionWithUpdatedYMMDetails',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MN, WA, IL, OK, VA, AZ, MO, OH, TN, NM, ID, IN, AR, CO, MI, OR})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.VehiclesDriversInfoPageTests#createQuoteWith2VehiclesAnd3DriversAndValidateDiscountsAfterRetrievalOfRatedQuote
  test('createQuoteWith2VehiclesAnd3DriversAndValidateDiscountsAfterRetrievalOfRatedQuote', async ({
    page,
    autoData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.VehiclesDriversInfoPageTests#createQuoteWith2VehiclesAnd3DriversAndValidateDiscountsAfterRetrievalOfRatedQuote',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/VehiclesDriversInfoPageTests.java',
      sourceLine: 1237,
      className: 'VehiclesDriversInfoPageTests',
      method: 'createQuoteWith2VehiclesAnd3DriversAndValidateDiscountsAfterRetrievalOfRatedQuote',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MN, WA, IL, OK, VA, AZ, MO, OH, TN, NM, ID, IN, AR, CO, MI, OR})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });
});
