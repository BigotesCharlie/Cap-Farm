// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.AutoRentersBundleOfferingPageTests', () => {
  // legacy-id: com.farmers.ffq.auto.AutoRentersBundleOfferingPageTests#validatePageContent_AutoRentersBundleOfferingPage
  test('validatePageContent_AutoRentersBundleOfferingPage', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.AutoRentersBundleOfferingPageTests#validatePageContent_AutoRentersBundleOfferingPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoRentersBundleOfferingPageTests.java',
      sourceLine: 47,
      className: 'AutoRentersBundleOfferingPageTests',
      method: 'validatePageContent_AutoRentersBundleOfferingPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, MA, MS, NC, AK, DC, DE, FL, HI, KY, LA, ME, MT, NH, NJ, NV, NY, RI, SC, VT, WV}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoRentersBundleOfferingPageTests#validateWeDontGetPageWithHomeOwner_AutoRentersBundleOfferingPage
  test('validateWeDontGetPageWithHomeOwner_AutoRentersBundleOfferingPage', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.AutoRentersBundleOfferingPageTests#validateWeDontGetPageWithHomeOwner_AutoRentersBundleOfferingPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoRentersBundleOfferingPageTests.java',
      sourceLine: 75,
      className: 'AutoRentersBundleOfferingPageTests',
      method: 'validateWeDontGetPageWithHomeOwner_AutoRentersBundleOfferingPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, MA, MS, NC, AK, DC, DE, FL, HI, KY, LA, ME, MT, NH, NJ, NV, NY, RI, SC, VT, WV}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoRentersBundleOfferingPageTests#validateMonolineFlow_AutoRentersBundleOfferingPage
  test('validateMonolineFlow_AutoRentersBundleOfferingPage', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.AutoRentersBundleOfferingPageTests#validateMonolineFlow_AutoRentersBundleOfferingPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoRentersBundleOfferingPageTests.java',
      sourceLine: 95,
      className: 'AutoRentersBundleOfferingPageTests',
      method: 'validateMonolineFlow_AutoRentersBundleOfferingPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, MA, MS, NC, AK, DC, DE, FL, HI, KY, LA, ME, MT, NH, NJ, NV, NY, RI, SC, VT, WV}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoRentersBundleOfferingPageTests#validateRentersBundleFlow_AutoRentersBundleOfferingPage
  test('validateRentersBundleFlow_AutoRentersBundleOfferingPage', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.AutoRentersBundleOfferingPageTests#validateRentersBundleFlow_AutoRentersBundleOfferingPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoRentersBundleOfferingPageTests.java',
      sourceLine: 127,
      className: 'AutoRentersBundleOfferingPageTests',
      method: 'validateRentersBundleFlow_AutoRentersBundleOfferingPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, MA, MS, NC, AK, DC, DE, FL, HI, KY, LA, ME, MT, NH, NJ, NV, NY, RI, SC, VT, WV}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.AutoRentersBundleOfferingPageTests#verifyAutoRentersBundleOfferingPageIsSuppressedForMLSource
  test('verifyAutoRentersBundleOfferingPageIsSuppressedForMLSource', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId:
        'com.farmers.ffq.auto.AutoRentersBundleOfferingPageTests#verifyAutoRentersBundleOfferingPageIsSuppressedForMLSource',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/AutoRentersBundleOfferingPageTests.java',
      sourceLine: 204,
      className: 'AutoRentersBundleOfferingPageTests',
      method: 'verifyAutoRentersBundleOfferingPageIsSuppressedForMLSource',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {OR, MT, ID}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST})',
    });
  });
});
