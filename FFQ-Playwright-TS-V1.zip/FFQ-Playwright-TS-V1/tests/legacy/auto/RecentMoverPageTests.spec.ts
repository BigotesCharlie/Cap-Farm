// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.RecentMoverPageTests", () => {
  // legacy-id: com.farmers.ffq.auto.RecentMoverPageTests#validateRecentMoverPage
  test("validateRecentMoverPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.RecentMoverPageTests#validateRecentMoverPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/RecentMoverPageTests.java","sourceLine":26,"className":"RecentMoverPageTests","method":"validateRecentMoverPage","parameters":"ADPFApplicant adpfApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"46\"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.RecentMoverPageTests#validateManualEntryPopUp
  test("validateManualEntryPopUp", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.RecentMoverPageTests#validateManualEntryPopUp","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/RecentMoverPageTests.java","sourceLine":34,"className":"RecentMoverPageTests","method":"validateManualEntryPopUp","parameters":"ADPFApplicant adpfApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"46\"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.RecentMoverPageTests#validateManualEntrySection
  test("validateManualEntrySection", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.RecentMoverPageTests#validateManualEntrySection","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/RecentMoverPageTests.java","sourceLine":42,"className":"RecentMoverPageTests","method":"validateManualEntrySection","parameters":"ADPFApplicant adpfApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"46\"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.RecentMoverPageTests#validateRecentMoverZipCodeMismatch
  test("validateRecentMoverZipCodeMismatch", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.RecentMoverPageTests#validateRecentMoverZipCodeMismatch","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/RecentMoverPageTests.java","sourceLine":50,"className":"RecentMoverPageTests","method":"validateRecentMoverZipCodeMismatch","parameters":"ADPFApplicant adpfApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"46\"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.RecentMoverPageTests#validateUserGetKOWithIidBehaviorCode_SC
  test("validateUserGetKOWithIidBehaviorCode_SC", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.RecentMoverPageTests#validateUserGetKOWithIidBehaviorCode_SC","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/RecentMoverPageTests.java","sourceLine":58,"className":"RecentMoverPageTests","method":"validateUserGetKOWithIidBehaviorCode_SC","parameters":"ADPFApplicant adpfApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"47\",\"48\"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.RecentMoverPageTests#validateUserLandsOnWhoShouldWeInsurePageWithRecentMoved_Answer_No
  test("validateUserLandsOnWhoShouldWeInsurePageWithRecentMoved_Answer_No", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.RecentMoverPageTests#validateUserLandsOnWhoShouldWeInsurePageWithRecentMoved_Answer_No","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/RecentMoverPageTests.java","sourceLine":74,"className":"RecentMoverPageTests","method":"validateUserLandsOnWhoShouldWeInsurePageWithRecentMoved_Answer_No","parameters":"ADPFApplicant adpfApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"46\"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.RecentMoverPageTests#validateRecentMoverFlowUntilQuotePageWithGooglePrefill
  test("validateRecentMoverFlowUntilQuotePageWithGooglePrefill", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.RecentMoverPageTests#validateRecentMoverFlowUntilQuotePageWithGooglePrefill","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/RecentMoverPageTests.java","sourceLine":84,"className":"RecentMoverPageTests","method":"validateRecentMoverFlowUntilQuotePageWithGooglePrefill","parameters":"ADPFApplicant adpfApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"46\"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.RecentMoverPageTests#validateRecentMoverFlowUntilQuotePageWithManualAddress
  test("validateRecentMoverFlowUntilQuotePageWithManualAddress", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.RecentMoverPageTests#validateRecentMoverFlowUntilQuotePageWithManualAddress","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/RecentMoverPageTests.java","sourceLine":102,"className":"RecentMoverPageTests","method":"validateRecentMoverFlowUntilQuotePageWithManualAddress","parameters":"ADPFApplicant adpfApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"46\"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.RecentMoverPageTests#validateTheRecentMoverFlowWithTheSameAddress_ManualEntry
  test("validateTheRecentMoverFlowWithTheSameAddress_ManualEntry", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.RecentMoverPageTests#validateTheRecentMoverFlowWithTheSameAddress_ManualEntry","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/RecentMoverPageTests.java","sourceLine":123,"className":"RecentMoverPageTests","method":"validateTheRecentMoverFlowWithTheSameAddress_ManualEntry","parameters":"ADPFApplicant adpfApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"46\"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.RecentMoverPageTests#validateTheRecentMoverFlowWithTheSameAddress_Google_prefill
  test("validateTheRecentMoverFlowWithTheSameAddress_Google_prefill", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.RecentMoverPageTests#validateTheRecentMoverFlowWithTheSameAddress_Google_prefill","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/RecentMoverPageTests.java","sourceLine":133,"className":"RecentMoverPageTests","method":"validateTheRecentMoverFlowWithTheSameAddress_Google_prefill","parameters":"ADPFApplicant adpfApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"46\"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.RecentMoverPageTests#validateTheRecentMoverFlowWithIidCode_SD
  test("validateTheRecentMoverFlowWithIidCode_SD", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.RecentMoverPageTests#validateTheRecentMoverFlowWithIidCode_SD","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/RecentMoverPageTests.java","sourceLine":154,"className":"RecentMoverPageTests","method":"validateTheRecentMoverFlowWithIidCode_SD","parameters":"ADPFApplicant adpfApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"73\"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})"});
  });

});
