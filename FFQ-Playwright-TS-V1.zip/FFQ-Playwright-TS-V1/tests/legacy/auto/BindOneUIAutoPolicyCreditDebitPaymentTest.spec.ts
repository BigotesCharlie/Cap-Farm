// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.bind.BindOneUIAutoPolicyCreditDebitPaymentTest", () => {
  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPolicyCreditDebitPaymentTest#payInFullCreditCardToBankPaymentMethodChange
  test.skip("payInFullCreditCardToBankPaymentMethodChange", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.bind.BindOneUIAutoPolicyCreditDebitPaymentTest#payInFullCreditCardToBankPaymentMethodChange","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPolicyCreditDebitPaymentTest.java","sourceLine":25,"className":"BindOneUIAutoPolicyCreditDebitPaymentTest","method":"payInFullCreditCardToBankPaymentMethodChange","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT","groups":"{FFQ_ONEUI, FFQ_BIND_DEBITCREDITPAYMENT_PAGE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_DEBITCREDITPAYMENT_PAGE}, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPolicyCreditDebitPaymentTest#monthlyPayDebitCreditIframeValidation
  test.skip("monthlyPayDebitCreditIframeValidation", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.bind.BindOneUIAutoPolicyCreditDebitPaymentTest#monthlyPayDebitCreditIframeValidation","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPolicyCreditDebitPaymentTest.java","sourceLine":77,"className":"BindOneUIAutoPolicyCreditDebitPaymentTest","method":"monthlyPayDebitCreditIframeValidation","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT","groups":"{FFQ_ONEUI, FFQ_BIND_DEBITCREDITPAYMENT_PAGE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_DEBITCREDITPAYMENT_PAGE}, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPolicyCreditDebitPaymentTest#monthlyPayCreditCardToBankPaymentMethodChange
  test.skip("monthlyPayCreditCardToBankPaymentMethodChange", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.bind.BindOneUIAutoPolicyCreditDebitPaymentTest#monthlyPayCreditCardToBankPaymentMethodChange","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPolicyCreditDebitPaymentTest.java","sourceLine":165,"className":"BindOneUIAutoPolicyCreditDebitPaymentTest","method":"monthlyPayCreditCardToBankPaymentMethodChange","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT","groups":"{FFQ_ONEUI, FFQ_BIND_DEBITCREDITPAYMENT_PAGE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_DEBITCREDITPAYMENT_PAGE}, enabled = false)"});
  });

});
