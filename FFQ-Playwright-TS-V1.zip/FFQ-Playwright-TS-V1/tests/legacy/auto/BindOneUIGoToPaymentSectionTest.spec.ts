// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.bind.BindOneUIGoToPaymentSectionTest", () => {
  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIGoToPaymentSectionTest#bindOneUIAutoQuoteGoToPaymentSection
  test.skip("bindOneUIAutoQuoteGoToPaymentSection", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.bind.BindOneUIGoToPaymentSectionTest#bindOneUIAutoQuoteGoToPaymentSection","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/bind/BindOneUIGoToPaymentSectionTest.java","sourceLine":20,"className":"BindOneUIGoToPaymentSectionTest","method":"bindOneUIAutoQuoteGoToPaymentSection","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT","groups":"{FFQ_ONEUI, FFQ_BIND_PAYMENT_SUMMARY_PAGE, FFQ_ACE_SMOKE}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, FFQ_BIND_PAYMENT_SUMMARY_PAGE, FFQ_ACE_SMOKE}, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIGoToPaymentSectionTest#validatePaymentPageWithPreferredPaymentPlan_F67015
  test.skip("validatePaymentPageWithPreferredPaymentPlan_F67015", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.bind.BindOneUIGoToPaymentSectionTest#validatePaymentPageWithPreferredPaymentPlan_F67015","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/bind/BindOneUIGoToPaymentSectionTest.java","sourceLine":36,"className":"BindOneUIGoToPaymentSectionTest","method":"validatePaymentPageWithPreferredPaymentPlan_F67015","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT","groups":"{FFQ_ONEUI, \"preferredPaymentMethod\"}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {WY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, \"preferredPaymentMethod\"}, enabled = false)"});
  });

});
