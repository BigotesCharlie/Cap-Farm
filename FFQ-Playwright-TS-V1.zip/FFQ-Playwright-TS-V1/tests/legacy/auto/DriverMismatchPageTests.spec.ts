// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.DriverMismatchPageTests", () => {
  // legacy-id: com.farmers.ffq.auto.DriverMismatchPageTests#validateDriversMismatchPage
  test("validateDriversMismatchPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DriverMismatchPageTests#validateDriversMismatchPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DriverMismatchPageTests.java","sourceLine":30,"className":"DriverMismatchPageTests","method":"validateDriversMismatchPage","parameters":"ADPFApplicant adfpApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, FFQ_DRIVER_MISMATCH}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"74\"})}, groups = {FFQ_ONEUI, FFQ_DRIVER_MISMATCH})"});
  });

  // legacy-id: com.farmers.ffq.auto.DriverMismatchPageTests#testUS465676CompareUnselectedDriversToDriverMismatch
  test("testUS465676CompareUnselectedDriversToDriverMismatch", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DriverMismatchPageTests#testUS465676CompareUnselectedDriversToDriverMismatch","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DriverMismatchPageTests.java","sourceLine":41,"className":"DriverMismatchPageTests","method":"testUS465676CompareUnselectedDriversToDriverMismatch","parameters":"ADPFApplicant adpfApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{ADA_SUITE, FFQ_ONEUI, FFQ_DRIVER_MISMATCH, ACE_AUTO_ADA_SUITE}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"74\"})}, groups = {ADA_SUITE, FFQ_ONEUI, FFQ_DRIVER_MISMATCH, ACE_AUTO_ADA_SUITE})"});
  });

  // legacy-id: com.farmers.ffq.auto.DriverMismatchPageTests#testUS465621AddingDriverMismatchExcludedDriver
  test("testUS465621AddingDriverMismatchExcludedDriver", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DriverMismatchPageTests#testUS465621AddingDriverMismatchExcludedDriver","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DriverMismatchPageTests.java","sourceLine":73,"className":"DriverMismatchPageTests","method":"testUS465621AddingDriverMismatchExcludedDriver","parameters":"ADPFApplicant adpfApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, FFQ_DRIVER_MISMATCH}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"74\"})}, groups = {FFQ_ONEUI, FFQ_DRIVER_MISMATCH})"});
  });

  // legacy-id: com.farmers.ffq.auto.DriverMismatchPageTests#testUS465796DriverMismatchErrorHandling
  test("testUS465796DriverMismatchErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DriverMismatchPageTests#testUS465796DriverMismatchErrorHandling","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DriverMismatchPageTests.java","sourceLine":117,"className":"DriverMismatchPageTests","method":"testUS465796DriverMismatchErrorHandling","parameters":"ADPFApplicant adfpApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, FFQ_DRIVER_MISMATCH}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"74\"})}, groups = {FFQ_ONEUI, FFQ_DRIVER_MISMATCH})"});
  });

  // legacy-id: com.farmers.ffq.auto.DriverMismatchPageTests#validateSaveAndRetrieveQuoteDriversMismatchPage
  test("validateSaveAndRetrieveQuoteDriversMismatchPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DriverMismatchPageTests#validateSaveAndRetrieveQuoteDriversMismatchPage","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DriverMismatchPageTests.java","sourceLine":124,"className":"DriverMismatchPageTests","method":"validateSaveAndRetrieveQuoteDriversMismatchPage","parameters":"ADPFApplicant adfpApplicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, FFQ_DRIVER_MISMATCH}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"0\", \"1\", \"22\", \"42\", \"44\"})}, groups = {FFQ_ONEUI, FFQ_DRIVER_MISMATCH})"});
  });

  // legacy-id: com.farmers.ffq.auto.DriverMismatchPageTests#validateDriverMismatchPageForBW_Not_Required
  test("validateDriverMismatchPageForBW_Not_Required", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DriverMismatchPageTests#validateDriverMismatchPageForBW_Not_Required","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DriverMismatchPageTests.java","sourceLine":142,"className":"DriverMismatchPageTests","method":"validateDriverMismatchPageForBW_Not_Required","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BW_ACE_TESTS, FFQ_DRIVER_MISMATCH}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA,FL, WA})}, groups = {BW_ACE_TESTS, FFQ_DRIVER_MISMATCH})"});
  });

  // legacy-id: com.farmers.ffq.auto.DriverMismatchPageTests#validateDriverMismatchPageForBW_Deployed
  test("validateDriverMismatchPageForBW_Deployed", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DriverMismatchPageTests#validateDriverMismatchPageForBW_Deployed","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DriverMismatchPageTests.java","sourceLine":158,"className":"DriverMismatchPageTests","method":"validateDriverMismatchPageForBW_Deployed","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BW_ACE_TESTS, FFQ_DRIVER_MISMATCH}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {IA,CA,FL,WA})}, groups = {BW_ACE_TESTS, FFQ_DRIVER_MISMATCH})"});
  });

  // legacy-id: com.farmers.ffq.auto.DriverMismatchPageTests#validateDriverMismatchPageForBW_ForeignDl
  test("validateDriverMismatchPageForBW_ForeignDl", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DriverMismatchPageTests#validateDriverMismatchPageForBW_ForeignDl","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DriverMismatchPageTests.java","sourceLine":175,"className":"DriverMismatchPageTests","method":"validateDriverMismatchPageForBW_ForeignDl","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BW_ACE_TESTS, FFQ_DRIVER_MISMATCH}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA,FL})}, groups = {BW_ACE_TESTS, FFQ_DRIVER_MISMATCH})"});
  });

  // legacy-id: com.farmers.ffq.auto.DriverMismatchPageTests#validateBindWithAlreadyAddedToThisQuote
  test("validateBindWithAlreadyAddedToThisQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DriverMismatchPageTests#validateBindWithAlreadyAddedToThisQuote","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DriverMismatchPageTests.java","sourceLine":195,"className":"DriverMismatchPageTests","method":"validateBindWithAlreadyAddedToThisQuote","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BDQ_TESTS, BW_ACE_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {NC, MT})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS, BW_ACE_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.DriverMismatchPageTests#validateRelationshipToApplicantOptions
  test("validateRelationshipToApplicantOptions", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.DriverMismatchPageTests#validateRelationshipToApplicantOptions","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/DriverMismatchPageTests.java","sourceLine":232,"className":"DriverMismatchPageTests","method":"validateRelationshipToApplicantOptions","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{ADA_SUITE, FFQ_ONEUI, FFQ_DRIVER_MISMATCH, ACE_AUTO_ADA_SUITE}","annotation":"@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {\"74\"})}, groups = {ADA_SUITE, FFQ_ONEUI, FFQ_DRIVER_MISMATCH, ACE_AUTO_ADA_SUITE})"});
  });

});
