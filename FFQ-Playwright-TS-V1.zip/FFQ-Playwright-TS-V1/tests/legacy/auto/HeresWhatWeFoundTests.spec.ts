// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.HeresWhatWeFoundTests", () => {
  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#testADPFPrefillDataForRandomCombination
  test("testADPFPrefillDataForRandomCombination", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#testADPFPrefillDataForRandomCombination","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":21,"className":"HeresWhatWeFoundTests","method":"testADPFPrefillDataForRandomCombination","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#testADPF_applicantVehicleInfoUpdate
  test("testADPF_applicantVehicleInfoUpdate", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#testADPF_applicantVehicleInfoUpdate","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":30,"className":"HeresWhatWeFoundTests","method":"testADPF_applicantVehicleInfoUpdate","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_AND_VEHICLES)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#testAddAnotherVehicleLinkNotDisplayedWhenFiveOrMoreVehiclesSelectedOrPrefilled
  test("testAddAnotherVehicleLinkNotDisplayedWhenFiveOrMoreVehiclesSelectedOrPrefilled", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#testAddAnotherVehicleLinkNotDisplayedWhenFiveOrMoreVehiclesSelectedOrPrefilled","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":41,"className":"HeresWhatWeFoundTests","method":"testAddAnotherVehicleLinkNotDisplayedWhenFiveOrMoreVehiclesSelectedOrPrefilled","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{ADA_SUITE, FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND, ACE_AUTO_ADA_SUITE}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.VEHICLES_GT_1)}, groups = {ADA_SUITE, FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND, ACE_AUTO_ADA_SUITE})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#testAdditionalDriversCheckboxesUncheckedWhenMoreThanFourCompleteDrivers
  test("testAdditionalDriversCheckboxesUncheckedWhenMoreThanFourCompleteDrivers", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#testAdditionalDriversCheckboxesUncheckedWhenMoreThanFourCompleteDrivers","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":63,"className":"HeresWhatWeFoundTests","method":"testAdditionalDriversCheckboxesUncheckedWhenMoreThanFourCompleteDrivers","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_5)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#testAllCompleteVehiclesBoxesCheckedWhen1To5VehiclesFoundInADPFCall
  test("testAllCompleteVehiclesBoxesCheckedWhen1To5VehiclesFoundInADPFCall", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#testAllCompleteVehiclesBoxesCheckedWhen1To5VehiclesFoundInADPFCall","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":90,"className":"HeresWhatWeFoundTests","method":"testAllCompleteVehiclesBoxesCheckedWhen1To5VehiclesFoundInADPFCall","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.ONE_TO_FIVE_VEHICLES)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#testCheckboxCheckedForPrefilledCompleteVehicleDriverInfo
  test("testCheckboxCheckedForPrefilledCompleteVehicleDriverInfo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#testCheckboxCheckedForPrefilledCompleteVehicleDriverInfo","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":124,"className":"HeresWhatWeFoundTests","method":"testCheckboxCheckedForPrefilledCompleteVehicleDriverInfo","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.NO_INCOMPLETE_DRIVERS_AND_VEHICLES)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#testCheckboxUncheckedForIncompleteVehicleDriverInfo
  test("testCheckboxUncheckedForIncompleteVehicleDriverInfo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#testCheckboxUncheckedForIncompleteVehicleDriverInfo","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":155,"className":"HeresWhatWeFoundTests","method":"testCheckboxUncheckedForIncompleteVehicleDriverInfo","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.INCOMPLETE_DRIVERS_AND_VEHICLES)},groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#testDriverPNICheckboxStatus
  test("testDriverPNICheckboxStatus", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#testDriverPNICheckboxStatus","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":172,"className":"HeresWhatWeFoundTests","method":"testDriverPNICheckboxStatus","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_0)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#testDriverPNIFieldsAreNonEditableAndDobIsMasked
  test("testDriverPNIFieldsAreNonEditableAndDobIsMasked", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#testDriverPNIFieldsAreNonEditableAndDobIsMasked","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":188,"className":"HeresWhatWeFoundTests","method":"testDriverPNIFieldsAreNonEditableAndDobIsMasked","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_0)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#validateIncompleteDriverIsNotChecked
  test("validateIncompleteDriverIsNotChecked", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#validateIncompleteDriverIsNotChecked","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":226,"className":"HeresWhatWeFoundTests","method":"validateIncompleteDriverIsNotChecked","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.INCOMPLETE_DRIVERS_AND_NO_DRIVERS)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#validateIncompleteVehicleIsNotChecked
  test("validateIncompleteVehicleIsNotChecked", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#validateIncompleteVehicleIsNotChecked","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":240,"className":"HeresWhatWeFoundTests","method":"validateIncompleteVehicleIsNotChecked","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.ONE_INCOMPLETE_VEHICLE)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#validateSideSheetOpenWhenUserClicksVehicleEditButton
  test("validateSideSheetOpenWhenUserClicksVehicleEditButton", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#validateSideSheetOpenWhenUserClicksVehicleEditButton","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":255,"className":"HeresWhatWeFoundTests","method":"validateSideSheetOpenWhenUserClicksVehicleEditButton","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.ONE_INCOMPLETE_VEHICLE)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#validateLessThanFiveCompleteVehiclesChecked
  test("validateLessThanFiveCompleteVehiclesChecked", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#validateLessThanFiveCompleteVehiclesChecked","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":267,"className":"HeresWhatWeFoundTests","method":"validateLessThanFiveCompleteVehiclesChecked","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.NO_INCOMPLETE_VEHICLES_AND_LT_FIVE_VEHICLES)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#testErrorMessageForZeroVehiclesWithDriverInfoOnClickingContinue
  test("testErrorMessageForZeroVehiclesWithDriverInfoOnClickingContinue", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#testErrorMessageForZeroVehiclesWithDriverInfoOnClickingContinue","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":281,"className":"HeresWhatWeFoundTests","method":"testErrorMessageForZeroVehiclesWithDriverInfoOnClickingContinue","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_AND_NO_VEHICLES)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#testFirstNameLastNameAge_PreFilledByAPDF
  test("testFirstNameLastNameAge_PreFilledByAPDF", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#testFirstNameLastNameAge_PreFilledByAPDF","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":307,"className":"HeresWhatWeFoundTests","method":"testFirstNameLastNameAge_PreFilledByAPDF","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_0)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#testNoVehicleBoxesCheckedForSixOrMoreVehiclesInADPFResponse
  test("testNoVehicleBoxesCheckedForSixOrMoreVehiclesInADPFResponse", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#testNoVehicleBoxesCheckedForSixOrMoreVehiclesInADPFResponse","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":321,"className":"HeresWhatWeFoundTests","method":"testNoVehicleBoxesCheckedForSixOrMoreVehiclesInADPFResponse","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_5)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#testPrefilledVehicleYearMakeModelAndLastThreeVinDigits
  test("testPrefilledVehicleYearMakeModelAndLastThreeVinDigits", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#testPrefilledVehicleYearMakeModelAndLastThreeVinDigits","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":354,"className":"HeresWhatWeFoundTests","method":"testPrefilledVehicleYearMakeModelAndLastThreeVinDigits","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.VEHICLES_GT_1)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

  // legacy-id: com.farmers.ffq.auto.HeresWhatWeFoundTests#validateSnackbarMessages
  test("validateSnackbarMessages", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.HeresWhatWeFoundTests#validateSnackbarMessages","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/HeresWhatWeFoundTests.java","sourceLine":369,"className":"HeresWhatWeFoundTests","method":"validateSnackbarMessages","parameters":"ADPFApplicant applicant","dataProvider":"AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}","annotation":"@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.VEHICLES_AND_DRIVERS_AND_INCOMPLETE_DRIVERS)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})"});
  });

});
