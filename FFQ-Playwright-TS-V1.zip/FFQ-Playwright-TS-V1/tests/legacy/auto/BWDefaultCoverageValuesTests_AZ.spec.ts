// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ", () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testBWDefaultCoverageValues_AZ_None_Unk
  test("testBWDefaultCoverageValues_AZ_None_Unk", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testBWDefaultCoverageValues_AZ_None_Unk","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":12,"className":"BWDefaultCoverageValuesTests_AZ","method":"testBWDefaultCoverageValues_AZ_None_Unk","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = AZ)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_100K
  test("testDefaultCoverageValues_AZ_100K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_100K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":21,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_100K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_200K
  test("testDefaultCoverageValues_AZ_200K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_200K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":28,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_200K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_300K
  test("testDefaultCoverageValues_AZ_300K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_300K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":35,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_300K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_500K
  test("testDefaultCoverageValues_AZ_500K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_500K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":42,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_500K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_1000K
  test("testDefaultCoverageValues_AZ_1000K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_1000K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":49,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_1000K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_50K100K
  test("testDefaultCoverageValues_AZ_50K100K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_50K100K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":56,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_50K100K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_100K200K
  test("testDefaultCoverageValues_AZ_100K200K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_100K200K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":63,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_100K200K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_100K300K
  test("testDefaultCoverageValues_AZ_100K300K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_100K300K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":70,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_100K300K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_250K500K
  test("testDefaultCoverageValues_AZ_250K500K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_250K500K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":77,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_250K500K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_500K500K
  test("testDefaultCoverageValues_AZ_500K500K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_500K500K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":84,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_500K500K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_500K1000K
  test("testDefaultCoverageValues_AZ_500K1000K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_500K1000K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":91,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_500K1000K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_25K50K
  test("testDefaultCoverageValues_AZ_25K50K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_25K50K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":98,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_25K50K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_30K60K
  test("testDefaultCoverageValues_AZ_30K60K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_30K60K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":105,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_30K60K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_35K70K
  test("testDefaultCoverageValues_AZ_35K70K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_AZ#testDefaultCoverageValues_AZ_35K70K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_AZ.java","sourceLine":112,"className":"BWDefaultCoverageValuesTests_AZ","method":"testDefaultCoverageValues_AZ_35K70K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

});
