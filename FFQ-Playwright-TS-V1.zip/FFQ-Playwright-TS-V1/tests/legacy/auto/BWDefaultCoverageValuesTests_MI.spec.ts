// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI", () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_None_Unk
  test("testDefaultCoverageValues_MI_None_Unk", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_None_Unk","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":12,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_None_Unk","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_50K100K
  test("testDefaultCoverageValues_MI_50K100K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_50K100K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":22,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_50K100K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K200K
  test("testDefaultCoverageValues_MI_100K200K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K200K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":29,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_100K200K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K300K
  test("testDefaultCoverageValues_MI_100K300K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K300K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":36,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_100K300K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_250K500K
  test("testDefaultCoverageValues_MI_250K500K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_250K500K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":43,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_250K500K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_300K300K
  test("testDefaultCoverageValues_MI_300K300K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_300K300K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":50,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_300K300K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K500K
  test("testDefaultCoverageValues_MI_500K500K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K500K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":58,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_500K500K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K1000K
  test("testDefaultCoverageValues_MI_500K1000K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K1000K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":65,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_500K1000K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_1000K1000K
  test("testDefaultCoverageValues_MI_1000K1000K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_1000K1000K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":73,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_1000K1000K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_75K
  test("testDefaultCoverageValues_MI_75K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_75K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":80,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_75K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K
  test("testDefaultCoverageValues_MI_100K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_100K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":87,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_100K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_200K
  test("testDefaultCoverageValues_MI_200K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_200K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":95,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_200K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_300K
  test("testDefaultCoverageValues_MI_300K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_300K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":103,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_300K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K
  test("testDefaultCoverageValues_MI_500K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_500K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":111,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_500K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_1000K
  test("testDefaultCoverageValues_MI_1000K", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_MI#testDefaultCoverageValues_MI_1000K","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_MI.java","sourceLine":119,"className":"BWDefaultCoverageValuesTests_MI","method":"testDefaultCoverageValues_MI_1000K","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{AUTO_COVERAGE_VALIDATION}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})"});
  });

});
