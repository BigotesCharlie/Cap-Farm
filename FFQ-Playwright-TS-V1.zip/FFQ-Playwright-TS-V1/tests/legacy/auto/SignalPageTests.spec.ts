// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.SignalPageTests", () => {
  // legacy-id: com.farmers.ffq.auto.SignalPageTests#validateSignalPageContents
  test("validateSignalPageContents", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.SignalPageTests#validateSignalPageContents","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/SignalPageTests.java","sourceLine":27,"className":"SignalPageTests","method":"validateSignalPageContents","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, SIGNAL_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA})}, groups = {FFQ_ONEUI, SIGNAL_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.SignalPageTests#testAddSignalToQuoteTest
  test("testAddSignalToQuoteTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.SignalPageTests#testAddSignalToQuoteTest","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/SignalPageTests.java","sourceLine":53,"className":"SignalPageTests","method":"testAddSignalToQuoteTest","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, SIGNAL_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AL, CA, FL, MT, NJ, NY, OH, MA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SIGNAL_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.SignalPageTests#testDeclineSignalOffering
  test("testDeclineSignalOffering", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.SignalPageTests#testDeclineSignalOffering","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/SignalPageTests.java","sourceLine":82,"className":"SignalPageTests","method":"testDeclineSignalOffering","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, SIGNAL_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {WA, AL, CA, FL, MT, NJ, NY, OH})}, groups = {FFQ_ONEUI, SIGNAL_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.SignalPageTests#validateYouthfulDriverContentOnSignalPageAndSignalDiscountOnQuoteSummary
  test("validateYouthfulDriverContentOnSignalPageAndSignalDiscountOnQuoteSummary", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.SignalPageTests#validateYouthfulDriverContentOnSignalPageAndSignalDiscountOnQuoteSummary","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/SignalPageTests.java","sourceLine":105,"className":"SignalPageTests","method":"validateYouthfulDriverContentOnSignalPageAndSignalDiscountOnQuoteSummary","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, SIGNAL_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=6\"}), @CustomAttribute(name = INCLUDED_STATES, values = {OR})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SIGNAL_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.SignalPageTests#validateSignalRemovedWithReverseBrightline
  test("validateSignalRemovedWithReverseBrightline", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.SignalPageTests#validateSignalRemovedWithReverseBrightline","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/SignalPageTests.java","sourceLine":134,"className":"SignalPageTests","method":"validateSignalRemovedWithReverseBrightline","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, SIGNAL_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SIGNAL_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.SignalPageTests#validateSignalPageIsRemovedWithBWQuote
  test("validateSignalPageIsRemovedWithBWQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.SignalPageTests#validateSignalPageIsRemovedWithBWQuote","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/SignalPageTests.java","sourceLine":190,"className":"SignalPageTests","method":"validateSignalPageIsRemovedWithBWQuote","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AK, CA, DC, DE, FL, HI, ME, MT, NH, NC, NJ, NY, RI, SC, VT, WV})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.SignalPageTests#validateSignalPageIsRemovedWhenBWQuoteIsRetrieved
  test("validateSignalPageIsRemovedWhenBWQuoteIsRetrieved", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.SignalPageTests#validateSignalPageIsRemovedWhenBWQuoteIsRetrieved","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/SignalPageTests.java","sourceLine":216,"className":"SignalPageTests","method":"validateSignalPageIsRemovedWhenBWQuoteIsRetrieved","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\"), @CustomAttribute(name = EXCLUDED_STATES, values = {AK, CA, DC, DE, FL, HI, ME, MT, NH, NJ, NY, RI, SC, VT, WA, WV})}, groups = {FFQ_ONEUI})"});
  });

  // legacy-id: com.farmers.ffq.auto.SignalPageTests#validateSignalPageFarmersBWBackAndForth
  test("validateSignalPageFarmersBWBackAndForth", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.SignalPageTests#validateSignalPageFarmersBWBackAndForth","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/SignalPageTests.java","sourceLine":238,"className":"SignalPageTests","method":"validateSignalPageFarmersBWBackAndForth","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE","groups":"{FFQ_ONEUI, SIGNAL_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SIGNAL_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.SignalPageTests#validateSignalIsNotAvailableForBW_ForeignDL
  test("validateSignalIsNotAvailableForBW_ForeignDL", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.SignalPageTests#validateSignalIsNotAvailableForBW_ForeignDL","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/SignalPageTests.java","sourceLine":314,"className":"SignalPageTests","method":"validateSignalIsNotAvailableForBW_ForeignDL","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BW_ACE_TESTS, SIGNAL_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AL, CA, FL, MT, NJ, NY, OH})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, SIGNAL_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.SignalPageTests#validateSignalIsNotAvailableForBW_Not_Required
  test("validateSignalIsNotAvailableForBW_Not_Required", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.SignalPageTests#validateSignalIsNotAvailableForBW_Not_Required","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/SignalPageTests.java","sourceLine":334,"className":"SignalPageTests","method":"validateSignalIsNotAvailableForBW_Not_Required","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BW_ACE_TESTS, SIGNAL_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AL, CA, FL, MT, NJ, NY, OH})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, SIGNAL_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.SignalPageTests#validateSignalIsNotAvailableForBW_Deployed
  test("validateSignalIsNotAvailableForBW_Deployed", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.SignalPageTests#validateSignalIsNotAvailableForBW_Deployed","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/SignalPageTests.java","sourceLine":353,"className":"SignalPageTests","method":"validateSignalIsNotAvailableForBW_Deployed","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{BW_ACE_TESTS, SIGNAL_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=1\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {NC, AL, CA, FL, MT, NJ, NY, OH})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, SIGNAL_TESTS})"});
  });

  // legacy-id: com.farmers.ffq.auto.SignalPageTests#validateVerifyRateResponseIsSendingSignalIndicators
  test("validateVerifyRateResponseIsSendingSignalIndicators", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.SignalPageTests#validateVerifyRateResponseIsSendingSignalIndicators","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/SignalPageTests.java","sourceLine":379,"className":"SignalPageTests","method":"validateVerifyRateResponseIsSendingSignalIndicators","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, SIGNAL_TESTS}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {\"applicantId=5\"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AK, CA, DC, DE, FL, HI, ME, MT, NH, NJ, NY, RI, SC, VT, WV})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SIGNAL_TESTS})"});
  });

});
