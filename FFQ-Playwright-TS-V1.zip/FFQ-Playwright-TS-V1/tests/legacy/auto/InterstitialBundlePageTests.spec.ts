// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.InterstitialBundlePageTests', () => {
  // legacy-id: com.farmers.ffq.auto.InterstitialBundlePageTests#validateInterstitialPageIsDisplayed
  test('validateInterstitialPageIsDisplayed', async ({ page, autoData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, autoData, {
      legacyId: 'com.farmers.ffq.auto.InterstitialBundlePageTests#validateInterstitialPageIsDisplayed',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/InterstitialBundlePageTests.java',
      sourceLine: 24,
      className: 'InterstitialBundlePageTests',
      method: 'validateInterstitialPageIsDisplayed',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, INTERSTITIAL_TEST}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {OR})}, groups = {FFQ_ONEUI, INTERSTITIAL_TEST})',
    });
  });
});
