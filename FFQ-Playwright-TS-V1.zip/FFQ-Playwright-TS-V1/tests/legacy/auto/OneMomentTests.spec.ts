// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.auto.OneMomentTests", () => {
  // legacy-id: com.farmers.ffq.auto.OneMomentTests#validateOneMomentPageContent
  test("validateOneMomentPageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.auto.OneMomentTests#validateOneMomentPageContent","domain":"auto","sourceFile":"src/test/java/com/farmers/ffq/auto/OneMomentTests.java","sourceLine":25,"className":"OneMomentTests","method":"validateOneMomentPageContent","parameters":"AutoApplicant applicant","dataProvider":"AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER","dataProviderClass":"AutoDataProviders.class","testName":"AutoDataProviders.RANDOM_AUTO_APPLICANT","groups":"{FFQ_ONEUI, ONE_MOMENT}","annotation":"@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ONE_MOMENT})"});
  });

});
