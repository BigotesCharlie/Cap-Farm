// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.crosssell.CSStoFFQCrossSellScenarios", () => {
  // legacy-id: com.farmers.ffq.crosssell.CSStoFFQCrossSellScenarios#testCrossSellFromCSStoHQM
  test("testCrossSellFromCSStoHQM", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.crosssell.CSStoFFQCrossSellScenarios#testCrossSellFromCSStoHQM","domain":"crosssell","sourceFile":"src/test/java/com/farmers/ffq/crosssell/CSStoFFQCrossSellScenarios.java","sourceLine":36,"className":"CSStoFFQCrossSellScenarios","method":"testCrossSellFromCSStoHQM","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{CROSS_SELL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, GA, NJ, NY})}, groups = {CROSS_SELL})"});
  });

  // legacy-id: com.farmers.ffq.crosssell.CSStoFFQCrossSellScenarios#testCrossSellFromMobileToHQM
  test("testCrossSellFromMobileToHQM", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.crosssell.CSStoFFQCrossSellScenarios#testCrossSellFromMobileToHQM","domain":"crosssell","sourceFile":"src/test/java/com/farmers/ffq/crosssell/CSStoFFQCrossSellScenarios.java","sourceLine":42,"className":"CSStoFFQCrossSellScenarios","method":"testCrossSellFromMobileToHQM","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{CROSS_SELL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, GA, NJ, NY})}, groups = {CROSS_SELL})"});
  });

  // legacy-id: com.farmers.ffq.crosssell.CSStoFFQCrossSellScenarios#testCrossSellFromCSStoAuto
  test("testCrossSellFromCSStoAuto", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.crosssell.CSStoFFQCrossSellScenarios#testCrossSellFromCSStoAuto","domain":"crosssell","sourceFile":"src/test/java/com/farmers/ffq/crosssell/CSStoFFQCrossSellScenarios.java","sourceLine":205,"className":"CSStoFFQCrossSellScenarios","method":"testCrossSellFromCSStoAuto","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{CROSS_SELL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AR,AZ,IA,IL,KS,MI,MN,NM,OR,WI})}, groups = {CROSS_SELL})"});
  });

  // legacy-id: com.farmers.ffq.crosssell.CSStoFFQCrossSellScenarios#testCrossSellFromMobileToAuto
  test("testCrossSellFromMobileToAuto", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.crosssell.CSStoFFQCrossSellScenarios#testCrossSellFromMobileToAuto","domain":"crosssell","sourceFile":"src/test/java/com/farmers/ffq/crosssell/CSStoFFQCrossSellScenarios.java","sourceLine":211,"className":"CSStoFFQCrossSellScenarios","method":"testCrossSellFromMobileToAuto","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{CROSS_SELL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AR,AZ,IA,IL,KS,MI,MN,NM,OR,WI})}, groups = {CROSS_SELL})"});
  });

  // legacy-id: com.farmers.ffq.crosssell.CSStoFFQCrossSellScenarios#testCrossSellFromCSStoAutoAce
  test("testCrossSellFromCSStoAutoAce", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.crosssell.CSStoFFQCrossSellScenarios#testCrossSellFromCSStoAutoAce","domain":"crosssell","sourceFile":"src/test/java/com/farmers/ffq/crosssell/CSStoFFQCrossSellScenarios.java","sourceLine":274,"className":"CSStoFFQCrossSellScenarios","method":"testCrossSellFromCSStoAutoAce","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{CROSS_SELL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,IA,IL,NM,OR,WI})}, groups = {CROSS_SELL})"});
  });

  // legacy-id: com.farmers.ffq.crosssell.CSStoFFQCrossSellScenarios#testCrossSellFromMobileToAutoAce
  test("testCrossSellFromMobileToAutoAce", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.crosssell.CSStoFFQCrossSellScenarios#testCrossSellFromMobileToAutoAce","domain":"crosssell","sourceFile":"src/test/java/com/farmers/ffq/crosssell/CSStoFFQCrossSellScenarios.java","sourceLine":281,"className":"CSStoFFQCrossSellScenarios","method":"testCrossSellFromMobileToAutoAce","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{CROSS_SELL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,IA,IL,NM,OR,WI})}, groups = {CROSS_SELL})"});
  });

});
