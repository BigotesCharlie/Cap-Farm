// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acebundle.AceAutoCondoBundleTests", () => {
  // legacy-id: com.farmers.ffq.acebundle.AceAutoCondoBundleTests#aceAutoCondoBundleE2ETest
  test.skip("aceAutoCondoBundleE2ETest", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acebundle.AceAutoCondoBundleTests#aceAutoCondoBundleE2ETest","domain":"acebundle","sourceFile":"src/test/java/com/farmers/ffq/acebundle/AceAutoCondoBundleTests.java","sourceLine":18,"className":"AceAutoCondoBundleTests","method":"aceAutoCondoBundleE2ETest","parameters":"AceBundleApplicant bundleApplicant","dataProvider":"AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER","dataProviderClass":"AceBundleDataProviders.class","testName":"AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE","groups":"BUNDLE","annotation":"@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)"});
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoCondoBundleTests#verifyAceBundleCondoPropertyQuestionsPageContent
  test.skip("verifyAceBundleCondoPropertyQuestionsPageContent", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acebundle.AceAutoCondoBundleTests#verifyAceBundleCondoPropertyQuestionsPageContent","domain":"acebundle","sourceFile":"src/test/java/com/farmers/ffq/acebundle/AceAutoCondoBundleTests.java","sourceLine":31,"className":"AceAutoCondoBundleTests","method":"verifyAceBundleCondoPropertyQuestionsPageContent","parameters":"AceBundleApplicant bundleApplicant","dataProvider":"AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER","dataProviderClass":"AceBundleDataProviders.class","testName":"AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT","groups":"BUNDLE","annotation":"@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)"});
  });

});
