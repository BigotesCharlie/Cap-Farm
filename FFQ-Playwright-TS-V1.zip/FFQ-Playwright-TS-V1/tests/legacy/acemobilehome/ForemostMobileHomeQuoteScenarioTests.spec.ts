// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acemobilehome.ForemostMobileHomeQuoteScenarioTests", () => {
  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomeQuoteScenarioTests#createForemostMobilehomeQuote
  test("createForemostMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomeQuoteScenarioTests#createForemostMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomeQuoteScenarioTests.java","sourceLine":14,"className":"ForemostMobileHomeQuoteScenarioTests","method":"createForemostMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomeQuoteScenarioTests#expectedForemostDiscountVerification
  test("expectedForemostDiscountVerification", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomeQuoteScenarioTests#expectedForemostDiscountVerification","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomeQuoteScenarioTests.java","sourceLine":20,"className":"ForemostMobileHomeQuoteScenarioTests","method":"expectedForemostDiscountVerification","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomeQuoteScenarioTests#retrieveForemostRatedQuotePageValidationTest
  test("retrieveForemostRatedQuotePageValidationTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomeQuoteScenarioTests#retrieveForemostRatedQuotePageValidationTest","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomeQuoteScenarioTests.java","sourceLine":26,"className":"ForemostMobileHomeQuoteScenarioTests","method":"retrieveForemostRatedQuotePageValidationTest","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomeQuoteScenarioTests#retrieveForemostNonRatedQuoteKnockoutTest
  test("retrieveForemostNonRatedQuoteKnockoutTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomeQuoteScenarioTests#retrieveForemostNonRatedQuoteKnockoutTest","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomeQuoteScenarioTests.java","sourceLine":32,"className":"ForemostMobileHomeQuoteScenarioTests","method":"retrieveForemostNonRatedQuoteKnockoutTest","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

});
