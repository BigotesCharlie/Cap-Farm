// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests", () => {
  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostAddressPageContent
  test("verifyForemostAddressPageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostAddressPageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomePageValidationTests.java","sourceLine":19,"className":"ForemostMobileHomePageValidationTests","method":"verifyForemostAddressPageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#validateForemostAddressPageErrorHandling
  test("validateForemostAddressPageErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#validateForemostAddressPageErrorHandling","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomePageValidationTests.java","sourceLine":25,"className":"ForemostMobileHomePageValidationTests","method":"validateForemostAddressPageErrorHandling","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostTellUsMorePageContent
  test("verifyForemostTellUsMorePageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostTellUsMorePageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomePageValidationTests.java","sourceLine":31,"className":"ForemostMobileHomePageValidationTests","method":"verifyForemostTellUsMorePageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#validateForemostTellUsMorePageErrorHandling
  test("validateForemostTellUsMorePageErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#validateForemostTellUsMorePageErrorHandling","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomePageValidationTests.java","sourceLine":37,"className":"ForemostMobileHomePageValidationTests","method":"validateForemostTellUsMorePageErrorHandling","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostAboutYouPageContent
  test("verifyForemostAboutYouPageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostAboutYouPageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomePageValidationTests.java","sourceLine":43,"className":"ForemostMobileHomePageValidationTests","method":"verifyForemostAboutYouPageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#validateForemostAboutYouPageErrorHandling
  test("validateForemostAboutYouPageErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#validateForemostAboutYouPageErrorHandling","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomePageValidationTests.java","sourceLine":49,"className":"ForemostMobileHomePageValidationTests","method":"validateForemostAboutYouPageErrorHandling","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostLastStepPageContent
  test("verifyForemostLastStepPageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostLastStepPageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomePageValidationTests.java","sourceLine":55,"className":"ForemostMobileHomePageValidationTests","method":"verifyForemostLastStepPageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#validateForemostLastStepPageErrorHandling
  test("validateForemostLastStepPageErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#validateForemostLastStepPageErrorHandling","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomePageValidationTests.java","sourceLine":61,"className":"ForemostMobileHomePageValidationTests","method":"validateForemostLastStepPageErrorHandling","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostQuotePageContent
  test("verifyForemostQuotePageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostQuotePageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomePageValidationTests.java","sourceLine":67,"className":"ForemostMobileHomePageValidationTests","method":"verifyForemostQuotePageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostLandlordMobilehomeQuote
  test("verifyForemostLandlordMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostLandlordMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomePageValidationTests.java","sourceLine":73,"className":"ForemostMobileHomePageValidationTests","method":"verifyForemostLandlordMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostSeasonalSecondaryMobilehomeQuote
  test("verifyForemostSeasonalSecondaryMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostSeasonalSecondaryMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomePageValidationTests.java","sourceLine":81,"className":"ForemostMobileHomePageValidationTests","method":"verifyForemostSeasonalSecondaryMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostVacantMobilehomeQuote
  test("verifyForemostVacantMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.ForemostMobileHomePageValidationTests#verifyForemostVacantMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/ForemostMobileHomePageValidationTests.java","sourceLine":89,"className":"ForemostMobileHomePageValidationTests","method":"verifyForemostVacantMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MN})}, groups = {FFQ_MOBILE_HOME})"});
  });

});
