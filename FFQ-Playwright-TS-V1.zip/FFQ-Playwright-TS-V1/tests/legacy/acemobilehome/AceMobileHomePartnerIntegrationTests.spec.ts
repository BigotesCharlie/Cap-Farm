// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acemobilehome.AceMobileHomePartnerIntegrationTests", () => {
  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePartnerIntegrationTests#verifyMediaAlphaMobilehomeQuotePageContent
  test("verifyMediaAlphaMobilehomeQuotePageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePartnerIntegrationTests#verifyMediaAlphaMobilehomeQuotePageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePartnerIntegrationTests.java","sourceLine":20,"className":"AceMobileHomePartnerIntegrationTests","method":"verifyMediaAlphaMobilehomeQuotePageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePartnerIntegrationTests#verifyMediaAlphaLandlordMobilehomeQuote
  test("verifyMediaAlphaLandlordMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePartnerIntegrationTests#verifyMediaAlphaLandlordMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePartnerIntegrationTests.java","sourceLine":27,"className":"AceMobileHomePartnerIntegrationTests","method":"verifyMediaAlphaLandlordMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePartnerIntegrationTests#verifyMediaAlphaSeasonalSecondaryMobilehomeQuote
  test("verifyMediaAlphaSeasonalSecondaryMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePartnerIntegrationTests#verifyMediaAlphaSeasonalSecondaryMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePartnerIntegrationTests.java","sourceLine":36,"className":"AceMobileHomePartnerIntegrationTests","method":"verifyMediaAlphaSeasonalSecondaryMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePartnerIntegrationTests#verifyMediaAlphaVacantMobilehomeQuote
  test("verifyMediaAlphaVacantMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePartnerIntegrationTests#verifyMediaAlphaVacantMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePartnerIntegrationTests.java","sourceLine":45,"className":"AceMobileHomePartnerIntegrationTests","method":"verifyMediaAlphaVacantMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MN}), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {FFQ_MOBILE_HOME})"});
  });

});
