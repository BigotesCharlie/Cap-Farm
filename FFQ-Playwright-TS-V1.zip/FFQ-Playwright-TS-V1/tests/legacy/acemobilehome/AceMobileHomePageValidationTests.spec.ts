// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests", () => {
  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyAddressPageContent
  test("verifyAddressPageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyAddressPageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePageValidationTests.java","sourceLine":18,"className":"AceMobileHomePageValidationTests","method":"verifyAddressPageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#validateAddressPageErrorHandling
  test("validateAddressPageErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#validateAddressPageErrorHandling","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePageValidationTests.java","sourceLine":23,"className":"AceMobileHomePageValidationTests","method":"validateAddressPageErrorHandling","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyTellUsMorePageContent
  test("verifyTellUsMorePageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyTellUsMorePageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePageValidationTests.java","sourceLine":28,"className":"AceMobileHomePageValidationTests","method":"verifyTellUsMorePageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#validateTellUsMorePageErrorHandling
  test("validateTellUsMorePageErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#validateTellUsMorePageErrorHandling","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePageValidationTests.java","sourceLine":33,"className":"AceMobileHomePageValidationTests","method":"validateTellUsMorePageErrorHandling","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyAboutYouPageContent
  test("verifyAboutYouPageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyAboutYouPageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePageValidationTests.java","sourceLine":38,"className":"AceMobileHomePageValidationTests","method":"verifyAboutYouPageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#validateAboutYouPageErrorHandling
  test("validateAboutYouPageErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#validateAboutYouPageErrorHandling","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePageValidationTests.java","sourceLine":43,"className":"AceMobileHomePageValidationTests","method":"validateAboutYouPageErrorHandling","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyLastStepPageContent
  test("verifyLastStepPageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyLastStepPageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePageValidationTests.java","sourceLine":48,"className":"AceMobileHomePageValidationTests","method":"verifyLastStepPageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#validateLastStepPageErrorHandling
  test("validateLastStepPageErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#validateLastStepPageErrorHandling","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePageValidationTests.java","sourceLine":53,"className":"AceMobileHomePageValidationTests","method":"validateLastStepPageErrorHandling","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyQuotePageContent
  test("verifyQuotePageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyQuotePageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePageValidationTests.java","sourceLine":58,"className":"AceMobileHomePageValidationTests","method":"verifyQuotePageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyLandlordMobilehomeQuote
  test("verifyLandlordMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyLandlordMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePageValidationTests.java","sourceLine":63,"className":"AceMobileHomePageValidationTests","method":"verifyLandlordMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifySeasonalSecondaryMobilehomeQuote
  test("verifySeasonalSecondaryMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifySeasonalSecondaryMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePageValidationTests.java","sourceLine":70,"className":"AceMobileHomePageValidationTests","method":"verifySeasonalSecondaryMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyVacantMobilehomeQuote
  test("verifyVacantMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomePageValidationTests#verifyVacantMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomePageValidationTests.java","sourceLine":77,"className":"AceMobileHomePageValidationTests","method":"verifyVacantMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MN})}, groups = {FFQ_MOBILE_HOME})"});
  });

});
