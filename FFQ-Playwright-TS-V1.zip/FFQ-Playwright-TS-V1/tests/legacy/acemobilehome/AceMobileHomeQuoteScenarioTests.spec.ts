// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests", () => {
  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#verifyStateSupportForMobileHome
  test("verifyStateSupportForMobileHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#verifyStateSupportForMobileHome","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomeQuoteScenarioTests.java","sourceLine":28,"className":"AceMobileHomeQuoteScenarioTests","method":"verifyStateSupportForMobileHome","parameters":"State state","dataProvider":"SqlDataProviders.STATES_DATA_PROVIDER_NAME","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"FFQ_MOBILE_HOME","annotation":"@Test(dataProviderClass = SqlDataProviders.class, dataProvider = SqlDataProviders.STATES_DATA_PROVIDER_NAME, groups = FFQ_MOBILE_HOME)"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#aceMobilehomePEWCScreen
  test("aceMobilehomePEWCScreen", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#aceMobilehomePEWCScreen","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomeQuoteScenarioTests.java","sourceLine":52,"className":"AceMobileHomeQuoteScenarioTests","method":"aceMobilehomePEWCScreen","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{PEWC}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {PEWC})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#createAnAceMobilehomeQuote
  test("createAnAceMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#createAnAceMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomeQuoteScenarioTests.java","sourceLine":58,"className":"AceMobileHomeQuoteScenarioTests","method":"createAnAceMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#expectedDiscountVerification
  test("expectedDiscountVerification", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#expectedDiscountVerification","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomeQuoteScenarioTests.java","sourceLine":64,"className":"AceMobileHomeQuoteScenarioTests","method":"expectedDiscountVerification","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#noPrimaryHeatSourceButHasSecondaryTest
  test("noPrimaryHeatSourceButHasSecondaryTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#noPrimaryHeatSourceButHasSecondaryTest","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomeQuoteScenarioTests.java","sourceLine":69,"className":"AceMobileHomeQuoteScenarioTests","method":"noPrimaryHeatSourceButHasSecondaryTest","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#retrieveRatedQuotePageValidationTest
  test("retrieveRatedQuotePageValidationTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#retrieveRatedQuotePageValidationTest","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomeQuoteScenarioTests.java","sourceLine":85,"className":"AceMobileHomeQuoteScenarioTests","method":"retrieveRatedQuotePageValidationTest","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#retrieveNonRatedQuoteKnockoutTest
  test("retrieveNonRatedQuoteKnockoutTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.AceMobileHomeQuoteScenarioTests#retrieveNonRatedQuoteKnockoutTest","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/AceMobileHomeQuoteScenarioTests.java","sourceLine":90,"className":"AceMobileHomeQuoteScenarioTests","method":"retrieveNonRatedQuoteKnockoutTest","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.RANDOM_MOBILEHOME_APPLICANT","groups":"{FFQ_MOBILE_HOME}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})"});
  });

});
