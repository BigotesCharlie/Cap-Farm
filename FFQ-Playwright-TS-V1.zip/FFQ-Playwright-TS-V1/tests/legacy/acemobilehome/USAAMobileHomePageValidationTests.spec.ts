// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests", () => {
  // legacy-id: com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAAAddressPageContent
  test("verifyUSAAAddressPageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAAAddressPageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/USAAMobileHomePageValidationTests.java","sourceLine":15,"className":"USAAMobileHomePageValidationTests","method":"verifyUSAAAddressPageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE","groups":"{\"FFQ_MOBILE_HOME\"}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {\"FFQ_MOBILE_HOME\"})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#validateUSAAAddressPageErrorHandling
  test("validateUSAAAddressPageErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#validateUSAAAddressPageErrorHandling","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/USAAMobileHomePageValidationTests.java","sourceLine":21,"className":"USAAMobileHomePageValidationTests","method":"validateUSAAAddressPageErrorHandling","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE","groups":"{\"FFQ_MOBILE_HOME\"}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {\"FFQ_MOBILE_HOME\"})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAATellUsMorePageContent
  test("verifyUSAATellUsMorePageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAATellUsMorePageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/USAAMobileHomePageValidationTests.java","sourceLine":27,"className":"USAAMobileHomePageValidationTests","method":"verifyUSAATellUsMorePageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE","groups":"{\"FFQ_MOBILE_HOME\"}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {\"FFQ_MOBILE_HOME\"})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#validateUSAATellUsMorePageErrorHandling
  test("validateUSAATellUsMorePageErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#validateUSAATellUsMorePageErrorHandling","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/USAAMobileHomePageValidationTests.java","sourceLine":33,"className":"USAAMobileHomePageValidationTests","method":"validateUSAATellUsMorePageErrorHandling","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE","groups":"{\"FFQ_MOBILE_HOME\"}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {\"FFQ_MOBILE_HOME\"})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAAAboutYouPageContent
  test("verifyUSAAAboutYouPageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAAAboutYouPageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/USAAMobileHomePageValidationTests.java","sourceLine":39,"className":"USAAMobileHomePageValidationTests","method":"verifyUSAAAboutYouPageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE","groups":"{\"FFQ_MOBILE_HOME\"}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {\"FFQ_MOBILE_HOME\"})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#validateUSAAAboutYouPageErrorHandling
  test("validateUSAAAboutYouPageErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#validateUSAAAboutYouPageErrorHandling","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/USAAMobileHomePageValidationTests.java","sourceLine":45,"className":"USAAMobileHomePageValidationTests","method":"validateUSAAAboutYouPageErrorHandling","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE","groups":"{\"FFQ_MOBILE_HOME\"}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {\"FFQ_MOBILE_HOME\"})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAALastStepPageContent
  test("verifyUSAALastStepPageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAALastStepPageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/USAAMobileHomePageValidationTests.java","sourceLine":51,"className":"USAAMobileHomePageValidationTests","method":"verifyUSAALastStepPageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE","groups":"{\"FFQ_MOBILE_HOME\"}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {\"FFQ_MOBILE_HOME\"})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#validateUSAALastStepPageErrorHandling
  test("validateUSAALastStepPageErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#validateUSAALastStepPageErrorHandling","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/USAAMobileHomePageValidationTests.java","sourceLine":57,"className":"USAAMobileHomePageValidationTests","method":"validateUSAALastStepPageErrorHandling","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE","groups":"{\"FFQ_MOBILE_HOME\"}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {\"FFQ_MOBILE_HOME\"})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAAQuotePageContent
  test("verifyUSAAQuotePageContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAAQuotePageContent","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/USAAMobileHomePageValidationTests.java","sourceLine":63,"className":"USAAMobileHomePageValidationTests","method":"verifyUSAAQuotePageContent","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE","groups":"{\"FFQ_MOBILE_HOME\"}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {\"FFQ_MOBILE_HOME\"})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAALandlordMobilehomeQuote
  test("verifyUSAALandlordMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAALandlordMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/USAAMobileHomePageValidationTests.java","sourceLine":69,"className":"USAAMobileHomePageValidationTests","method":"verifyUSAALandlordMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE","groups":"{\"FFQ_MOBILE_HOME\"}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {\"FFQ_MOBILE_HOME\"})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAASeasonalSecondaryMobilehomeQuote
  test("verifyUSAASeasonalSecondaryMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAASeasonalSecondaryMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/USAAMobileHomePageValidationTests.java","sourceLine":77,"className":"USAAMobileHomePageValidationTests","method":"verifyUSAASeasonalSecondaryMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE","groups":"{\"FFQ_MOBILE_HOME\"}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {\"FFQ_MOBILE_HOME\"})"});
  });

  // legacy-id: com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAAVacantMobilehomeQuote
  test("verifyUSAAVacantMobilehomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acemobilehome.USAAMobileHomePageValidationTests#verifyUSAAVacantMobilehomeQuote","domain":"acemobilehome","sourceFile":"src/test/java/com/farmers/ffq/acemobilehome/USAAMobileHomePageValidationTests.java","sourceLine":85,"className":"USAAMobileHomePageValidationTests","method":"verifyUSAAVacantMobilehomeQuote","parameters":"ApplicantAceHome mobilehomeApplicant","dataProvider":"DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE","groups":"{\"FFQ_MOBILE_HOME\"}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {\"FFQ_MOBILE_HOME\"})"});
  });

});
