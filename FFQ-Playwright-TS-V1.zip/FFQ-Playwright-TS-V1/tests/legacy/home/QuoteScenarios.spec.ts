// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.home.QuoteScenarios", () => {
  // legacy-id: com.farmers.ffq.home.QuoteScenarios#getHomeQuote
  test("getHomeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.home.QuoteScenarios#getHomeQuote","domain":"home","sourceFile":"src/test/java/com/farmers/ffq/home/QuoteScenarios.java","sourceLine":21,"className":"QuoteScenarios","method":"getHomeQuote","parameters":"ApplicantHome applicant","dataProvider":"DataProviders.APPLICANT_HOME_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{GET_HOME, REGRESSION, SPOT_TESTING}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HOME_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {GET_HOME, REGRESSION, SPOT_TESTING})"});
  });

  // legacy-id: com.farmers.ffq.home.QuoteScenarios#legacyHomeQuoteUsingAOR
  test("legacyHomeQuoteUsingAOR", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.home.QuoteScenarios#legacyHomeQuoteUsingAOR","domain":"home","sourceFile":"src/test/java/com/farmers/ffq/home/QuoteScenarios.java","sourceLine":26,"className":"QuoteScenarios","method":"legacyHomeQuoteUsingAOR","parameters":"ApplicantHome applicant","dataProvider":"DataProviders.MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{GET_HOME, REGRESSION, SPOT_TESTING}","annotation":"@Test(dataProvider = DataProviders.MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {GET_HOME, REGRESSION, SPOT_TESTING})"});
  });

});
