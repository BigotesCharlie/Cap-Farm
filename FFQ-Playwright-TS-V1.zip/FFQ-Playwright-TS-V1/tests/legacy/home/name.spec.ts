// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.home.name", () => {
  // legacy-id: com.farmers.ffq.home.name#saveAndRetrieveHomeQuotes
  test("saveAndRetrieveHomeQuotes", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.home.name#saveAndRetrieveHomeQuotes","domain":"home","sourceFile":"src/test/java/com/farmers/ffq/home/SaveAndRetrieveHomeQuoteScenarios.java","sourceLine":28,"className":"name","method":"saveAndRetrieveHomeQuotes","parameters":"ApplicantHome applicant","dataProvider":"DataProviders.GET_RETRIEVE_QUOTE_APPLICANT_HOME","dataProviderClass":"DataProviders.class","testName":"","groups":"{GET_RETRIEVE_HOME, REGRESSION}","annotation":"@Test(dataProvider = DataProviders.GET_RETRIEVE_QUOTE_APPLICANT_HOME, dataProviderClass = DataProviders.class, groups = {GET_RETRIEVE_HOME, REGRESSION}, priority = 1)"});
  });

});
