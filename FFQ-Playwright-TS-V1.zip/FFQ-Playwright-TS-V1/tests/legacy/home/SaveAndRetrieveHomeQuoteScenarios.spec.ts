// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.home.SaveAndRetrieveHomeQuoteScenarios', () => {
  // legacy-id: com.farmers.ffq.home.SaveAndRetrieveHomeQuoteScenarios#saveAndRetrieveHomeQuotes
  test('saveAndRetrieveHomeQuotes', async ({ page, legacyHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, legacyHomeData, {
      legacyId: 'com.farmers.ffq.home.SaveAndRetrieveHomeQuoteScenarios#saveAndRetrieveHomeQuotes',
      domain: 'home',
      sourceFile: 'src/test/java/com/farmers/ffq/home/SaveAndRetrieveHomeQuoteScenarios.java',
      sourceLine: 28,
      className: 'SaveAndRetrieveHomeQuoteScenarios',
      method: 'saveAndRetrieveHomeQuotes',
      parameters: 'ApplicantHome applicant',
      dataProvider: 'DataProviders.GET_RETRIEVE_QUOTE_APPLICANT_HOME',
      dataProviderClass: 'DataProviders.class',
      testName: '',
      groups: '{GET_RETRIEVE_HOME, REGRESSION}',
      annotation:
        '@Test(dataProvider = DataProviders.GET_RETRIEVE_QUOTE_APPLICANT_HOME, dataProviderClass = DataProviders.class, groups = {GET_RETRIEVE_HOME, REGRESSION}, priority = 1)',
    });
  });
});
