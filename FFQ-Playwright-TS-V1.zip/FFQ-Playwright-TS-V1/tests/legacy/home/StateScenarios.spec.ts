// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.home.StateScenarios", () => {
  // legacy-id: com.farmers.ffq.home.StateScenarios#validateStateForHome
  test("validateStateForHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.home.StateScenarios#validateStateForHome","domain":"home","sourceFile":"src/test/java/com/farmers/ffq/home/StateScenarios.java","sourceLine":28,"className":"StateScenarios","method":"validateStateForHome","parameters":"State state","dataProvider":"SqlDataProviders.STATES_DATA_PROVIDER_NAME","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"{GET_HOME, REGRESSION, STATE_SCENARIOS}","annotation":"@Test(dataProvider = SqlDataProviders.STATES_DATA_PROVIDER_NAME, dataProviderClass = SqlDataProviders.class, groups = {GET_HOME, REGRESSION, STATE_SCENARIOS})"});
  });

  // legacy-id: com.farmers.ffq.home.StateScenarios#validateStateForLegacyHomeUsingAOR
  test("validateStateForLegacyHomeUsingAOR", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.home.StateScenarios#validateStateForLegacyHomeUsingAOR","domain":"home","sourceFile":"src/test/java/com/farmers/ffq/home/StateScenarios.java","sourceLine":56,"className":"StateScenarios","method":"validateStateForLegacyHomeUsingAOR","parameters":"ApplicantHome applicant","dataProvider":"DataProviders.MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"DataProviders.ONE_APPLICANT_PER_STATE","groups":"{GET_HOME, REGRESSION, STATE_SCENARIOS}","annotation":"@Test(dataProvider = DataProviders.MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER, testName = DataProviders.ONE_APPLICANT_PER_STATE, dataProviderClass = DataProviders.class, groups = {GET_HOME, REGRESSION, STATE_SCENARIOS})"});
  });

});
