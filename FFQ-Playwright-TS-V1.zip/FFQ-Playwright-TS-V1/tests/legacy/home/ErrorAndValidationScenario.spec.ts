// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.home.ErrorAndValidationScenario", () => {
  // legacy-id: com.farmers.ffq.home.ErrorAndValidationScenario#errorAndPageValidationScenario
  test("errorAndPageValidationScenario", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.home.ErrorAndValidationScenario#errorAndPageValidationScenario","domain":"home","sourceFile":"src/test/java/com/farmers/ffq/home/ErrorAndValidationScenario.java","sourceLine":21,"className":"ErrorAndValidationScenario","method":"errorAndPageValidationScenario","parameters":"ApplicantHome applicant","dataProvider":"DataProviders.APPLICANT_HOME_ERROR_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{PAGE_VALIDATION_HOME, REGRESSION }","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HOME_ERROR_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {PAGE_VALIDATION_HOME, REGRESSION })"});
  });

});
