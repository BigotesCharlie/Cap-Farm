// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.hqm.QuickenIntegrationScenarios', () => {
  // legacy-id: com.farmers.ffq.hqm.QuickenIntegrationScenarios#testQuickenAllData
  test('testQuickenAllData', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.hqm.QuickenIntegrationScenarios#testQuickenAllData',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/QuickenIntegrationScenarios.java',
      sourceLine: 39,
      className: 'QuickenIntegrationScenarios',
      method: 'testQuickenAllData',
      parameters: 'ApplicantHQM applicant',
      dataProvider: 'DataProviders.APPLICANT_HQM_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{HQM_QUICKEN, HQM_ALL}',
      annotation:
        '@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_QUICKEN, HQM_ALL})',
    });
  });

  // legacy-id: com.farmers.ffq.hqm.QuickenIntegrationScenarios#testQuickenNoPpcSrc
  test('testQuickenNoPpcSrc', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.hqm.QuickenIntegrationScenarios#testQuickenNoPpcSrc',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/QuickenIntegrationScenarios.java',
      sourceLine: 44,
      className: 'QuickenIntegrationScenarios',
      method: 'testQuickenNoPpcSrc',
      parameters: 'ApplicantHQM applicant',
      dataProvider: 'DataProviders.APPLICANT_HQM_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{HQM_QUICKEN, HQM_ALL}',
      annotation:
        '@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_QUICKEN, HQM_ALL})',
    });
  });

  // legacy-id: com.farmers.ffq.hqm.QuickenIntegrationScenarios#testQuickenNoEmail
  test('testQuickenNoEmail', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.hqm.QuickenIntegrationScenarios#testQuickenNoEmail',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/QuickenIntegrationScenarios.java',
      sourceLine: 214,
      className: 'QuickenIntegrationScenarios',
      method: 'testQuickenNoEmail',
      parameters: 'ApplicantHQM applicant',
      dataProvider: 'DataProviders.APPLICANT_HQM_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{HQM_QUICKEN, HQM_ALL}',
      annotation:
        '@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_QUICKEN, HQM_ALL})',
    });
  });

  // legacy-id: com.farmers.ffq.hqm.QuickenIntegrationScenarios#testQuickenNoPhone
  test('testQuickenNoPhone', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.hqm.QuickenIntegrationScenarios#testQuickenNoPhone',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/QuickenIntegrationScenarios.java',
      sourceLine: 219,
      className: 'QuickenIntegrationScenarios',
      method: 'testQuickenNoPhone',
      parameters: 'ApplicantHQM applicant',
      dataProvider: 'DataProviders.APPLICANT_HQM_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{HQM_QUICKEN, HQM_ALL}',
      annotation:
        '@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_QUICKEN, HQM_ALL})',
    });
  });

  // legacy-id: com.farmers.ffq.hqm.QuickenIntegrationScenarios#testQuickenNoEmailNoPhone
  test('testQuickenNoEmailNoPhone', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.hqm.QuickenIntegrationScenarios#testQuickenNoEmailNoPhone',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/QuickenIntegrationScenarios.java',
      sourceLine: 224,
      className: 'QuickenIntegrationScenarios',
      method: 'testQuickenNoEmailNoPhone',
      parameters: 'ApplicantHQM applicant',
      dataProvider: 'DataProviders.APPLICANT_HQM_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{HQM_QUICKEN, HQM_ALL}',
      annotation:
        '@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_QUICKEN, HQM_ALL})',
    });
  });

  // legacy-id: com.farmers.ffq.hqm.QuickenIntegrationScenarios#testQuickenNoLastName
  test('testQuickenNoLastName', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.hqm.QuickenIntegrationScenarios#testQuickenNoLastName',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/QuickenIntegrationScenarios.java',
      sourceLine: 421,
      className: 'QuickenIntegrationScenarios',
      method: 'testQuickenNoLastName',
      parameters: 'ApplicantHQM applicant',
      dataProvider: 'DataProviders.APPLICANT_HQM_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{HQM_QUICKEN, HQM_ALL}',
      annotation:
        '@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_QUICKEN, HQM_ALL})',
    });
  });

  // legacy-id: com.farmers.ffq.hqm.QuickenIntegrationScenarios#testDecrypt
  test.skip('testDecrypt', async ({ page, inlineData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, inlineData, {
      legacyId: 'com.farmers.ffq.hqm.QuickenIntegrationScenarios#testDecrypt',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/QuickenIntegrationScenarios.java',
      sourceLine: 428,
      className: 'QuickenIntegrationScenarios',
      method: 'testDecrypt',
      parameters: '',
      dataProvider: '',
      dataProviderClass: '',
      testName: '',
      groups: '{HQM_ALL}',
      annotation: '@Test(groups={HQM_ALL})',
    });
  });

  // legacy-id: com.farmers.ffq.hqm.QuickenIntegrationScenarios#testEncrypt
  test.skip('testEncrypt', async ({ page, inlineData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, inlineData, {
      legacyId: 'com.farmers.ffq.hqm.QuickenIntegrationScenarios#testEncrypt',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/QuickenIntegrationScenarios.java',
      sourceLine: 443,
      className: 'QuickenIntegrationScenarios',
      method: 'testEncrypt',
      parameters: '',
      dataProvider: '',
      dataProviderClass: '',
      testName: '',
      groups: '{HQM_ALL}',
      annotation: '@Test(groups={HQM_ALL})',
    });
  });

  // legacy-id: com.farmers.ffq.hqm.QuickenIntegrationScenarios#testEncryptRS
  test.skip('testEncryptRS', async ({ page, inlineData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, inlineData, {
      legacyId: 'com.farmers.ffq.hqm.QuickenIntegrationScenarios#testEncryptRS',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/QuickenIntegrationScenarios.java',
      sourceLine: 456,
      className: 'QuickenIntegrationScenarios',
      method: 'testEncryptRS',
      parameters: '',
      dataProvider: '',
      dataProviderClass: '',
      testName: '',
      groups: '{HQM_ALL}',
      annotation: '@Test(groups={HQM_ALL})',
    });
  });

  // legacy-id: com.farmers.ffq.hqm.QuickenIntegrationScenarios#testDecryptRS
  test.skip('testDecryptRS', async ({ page, inlineData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, inlineData, {
      legacyId: 'com.farmers.ffq.hqm.QuickenIntegrationScenarios#testDecryptRS',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/QuickenIntegrationScenarios.java',
      sourceLine: 466,
      className: 'QuickenIntegrationScenarios',
      method: 'testDecryptRS',
      parameters: '',
      dataProvider: '',
      dataProviderClass: '',
      testName: '',
      groups: '{HQM_ALL}',
      annotation: '@Test(groups={HQM_ALL})',
    });
  });
});
