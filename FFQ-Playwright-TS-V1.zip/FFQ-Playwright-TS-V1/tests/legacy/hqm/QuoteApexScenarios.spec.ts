// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.hqm.QuoteApexScenarios", () => {
  // legacy-id: com.farmers.ffq.hqm.QuoteApexScenarios#hqmApexNewQuote
  test("hqmApexNewQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteApexScenarios#hqmApexNewQuote","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteApexScenarios.java","sourceLine":38,"className":"QuoteApexScenarios","method":"hqmApexNewQuote","parameters":"ApexHQM applicant","dataProvider":"DataProviders.APEX_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{HQM_APEX_TEST, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APEX_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_APEX_TEST, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteApexScenarios#oneApexHqmNewQuote
  test.skip("oneApexHqmNewQuote", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteApexScenarios#oneApexHqmNewQuote","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteApexScenarios.java","sourceLine":44,"className":"QuoteApexScenarios","method":"oneApexHqmNewQuote","parameters":"ApexHQM applicant","dataProvider":"DataProviders.APEX_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_APEX_TEST, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APEX_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_APEX_TEST, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteApexScenarios#tempTest
  test.skip("tempTest", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteApexScenarios#tempTest","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteApexScenarios.java","sourceLine":119,"className":"QuoteApexScenarios","method":"tempTest","parameters":"ApexHQM apexHQM","dataProvider":"DataProviders.APEX_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APEX_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_ALL})"});
  });

});
