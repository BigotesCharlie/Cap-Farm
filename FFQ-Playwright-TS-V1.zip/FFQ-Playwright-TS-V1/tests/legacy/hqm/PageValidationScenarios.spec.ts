// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.hqm.PageValidationScenarios", () => {
  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testAddressPage
  test("testAddressPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testAddressPage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":35,"className":"PageValidationScenarios","method":"testAddressPage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testAddressPageMobile
  test("testAddressPageMobile", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testAddressPageMobile","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":40,"className":"PageValidationScenarios","method":"testAddressPageMobile","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_MOBILE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testPropertyPage
  test("testPropertyPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testPropertyPage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":106,"className":"PageValidationScenarios","method":"testPropertyPage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testPropertyPageMobile
  test("testPropertyPageMobile", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testPropertyPageMobile","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":111,"className":"PageValidationScenarios","method":"testPropertyPageMobile","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_MOBILE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testQualityGradePage
  test("testQualityGradePage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testQualityGradePage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":214,"className":"PageValidationScenarios","method":"testQualityGradePage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testQualityGradePageMobile
  test("testQualityGradePageMobile", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testQualityGradePageMobile","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":219,"className":"PageValidationScenarios","method":"testQualityGradePageMobile","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_MOBILE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testPropertyDetailsPage
  test("testPropertyDetailsPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testPropertyDetailsPage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":284,"className":"PageValidationScenarios","method":"testPropertyDetailsPage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testPropertyDetailsPageMobile
  test("testPropertyDetailsPageMobile", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testPropertyDetailsPageMobile","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":289,"className":"PageValidationScenarios","method":"testPropertyDetailsPageMobile","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_MOBILE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testCustomerInfoPage
  test("testCustomerInfoPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testCustomerInfoPage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":385,"className":"PageValidationScenarios","method":"testCustomerInfoPage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testCustomerInfoPageMobile
  test("testCustomerInfoPageMobile", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testCustomerInfoPageMobile","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":390,"className":"PageValidationScenarios","method":"testCustomerInfoPageMobile","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_MOBILE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testContactInfoPage
  test("testContactInfoPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testContactInfoPage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":475,"className":"PageValidationScenarios","method":"testContactInfoPage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testContactInfoPageMobile
  test("testContactInfoPageMobile", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testContactInfoPageMobile","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":480,"className":"PageValidationScenarios","method":"testContactInfoPageMobile","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_MOBILE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testDiscountsPage
  test("testDiscountsPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testDiscountsPage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":573,"className":"PageValidationScenarios","method":"testDiscountsPage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testDiscountsPageMobile
  test("testDiscountsPageMobile", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testDiscountsPageMobile","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":578,"className":"PageValidationScenarios","method":"testDiscountsPageMobile","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_MOBILE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testQuotePage
  test("testQuotePage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testQuotePage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":726,"className":"PageValidationScenarios","method":"testQuotePage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testQuotePageMobile
  test("testQuotePageMobile", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testQuotePageMobile","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":731,"className":"PageValidationScenarios","method":"testQuotePageMobile","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_MOBILE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testPrintPage
  test("testPrintPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testPrintPage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":922,"className":"PageValidationScenarios","method":"testPrintPage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testPrintPageMobile
  test("testPrintPageMobile", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testPrintPageMobile","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":927,"className":"PageValidationScenarios","method":"testPrintPageMobile","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_MOBILE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testQuoteDetailsPage1
  test("testQuoteDetailsPage1", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testQuoteDetailsPage1","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":1055,"className":"PageValidationScenarios","method":"testQuoteDetailsPage1","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testQuoteDetailsPage1Mobile
  test("testQuoteDetailsPage1Mobile", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testQuoteDetailsPage1Mobile","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":1060,"className":"PageValidationScenarios","method":"testQuoteDetailsPage1Mobile","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_MOBILE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testQuoteDetailsPage2
  test("testQuoteDetailsPage2", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testQuoteDetailsPage2","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":1180,"className":"PageValidationScenarios","method":"testQuoteDetailsPage2","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testQuoteDetailsPage2Mobile
  test("testQuoteDetailsPage2Mobile", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testQuoteDetailsPage2Mobile","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":1185,"className":"PageValidationScenarios","method":"testQuoteDetailsPage2Mobile","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_MOBILE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testThankYouPage
  test("testThankYouPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testThankYouPage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":1326,"className":"PageValidationScenarios","method":"testThankYouPage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testThankYouPageMobile
  test("testThankYouPageMobile", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testThankYouPageMobile","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":1331,"className":"PageValidationScenarios","method":"testThankYouPageMobile","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_MOBILE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testAEMCampaignPhones
  test("testAEMCampaignPhones", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testAEMCampaignPhones","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":1414,"className":"PageValidationScenarios","method":"testAEMCampaignPhones","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_REGRESSION, HQM_ALL}, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {})})"});
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationScenarios#testHQMMonetizationScenarios
  test("testHQMMonetizationScenarios", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.PageValidationScenarios#testHQMMonetizationScenarios","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/PageValidationScenarios.java","sourceLine":1537,"className":"PageValidationScenarios","method":"testHQMMonetizationScenarios","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_MONETIZATION_DP","dataProviderClass":"DataProviders.class","testName":"","groups":"{HQM_PAGE_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_MONETIZATION_DP, dataProviderClass = DataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, groups = {HQM_PAGE_REGRESSION, HQM_ALL})"});
  });

});
