// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.hqm.CrossSellScenarios", () => {
  // legacy-id: com.farmers.ffq.hqm.CrossSellScenarios#testCrossSellFromHQM
  test("testCrossSellFromHQM", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.CrossSellScenarios#testCrossSellFromHQM","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/CrossSellScenarios.java","sourceLine":38,"className":"CrossSellScenarios","method":"testCrossSellFromHQM","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_CROSS_SELL, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_CROSS_SELL, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.CrossSellScenarios#testCrossSellHQMToAutoAce
  test.skip("testCrossSellHQMToAutoAce", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.CrossSellScenarios#testCrossSellHQMToAutoAce","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/CrossSellScenarios.java","sourceLine":214,"className":"CrossSellScenarios","method":"testCrossSellHQMToAutoAce","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_CROSS_SELL, HQM_ALL, FFQ_ONEUI}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT, NV})}, groups = {HQM_CROSS_SELL, HQM_ALL, FFQ_ONEUI})"});
  });

});
