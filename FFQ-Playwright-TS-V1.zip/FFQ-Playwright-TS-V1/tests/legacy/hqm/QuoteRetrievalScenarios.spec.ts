// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.hqm.QuoteRetrievalScenarios", () => {
  // legacy-id: com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveBeforeCustomerInfo
  test("testRetrieveBeforeCustomerInfo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveBeforeCustomerInfo","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteRetrievalScenarios.java","sourceLine":32,"className":"QuoteRetrievalScenarios","method":"testRetrieveBeforeCustomerInfo","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_RETRIEVE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveOnContactInfo
  test("testRetrieveOnContactInfo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveOnContactInfo","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteRetrievalScenarios.java","sourceLine":83,"className":"QuoteRetrievalScenarios","method":"testRetrieveOnContactInfo","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_RETRIEVE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteRetrievalScenarios#testSAFLOnContactInfoNoEmail
  test("testSAFLOnContactInfoNoEmail", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteRetrievalScenarios#testSAFLOnContactInfoNoEmail","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteRetrievalScenarios.java","sourceLine":151,"className":"QuoteRetrievalScenarios","method":"testSAFLOnContactInfoNoEmail","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_RETRIEVE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteRetrievalScenarios#testSAFLOnContactInfoYesEmail
  test("testSAFLOnContactInfoYesEmail", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteRetrievalScenarios#testSAFLOnContactInfoYesEmail","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteRetrievalScenarios.java","sourceLine":156,"className":"QuoteRetrievalScenarios","method":"testSAFLOnContactInfoYesEmail","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_RETRIEVE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveOnDiscountsPage
  test("testRetrieveOnDiscountsPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveOnDiscountsPage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteRetrievalScenarios.java","sourceLine":221,"className":"QuoteRetrievalScenarios","method":"testRetrieveOnDiscountsPage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_RETRIEVE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveOnDiscountsPageByEmailId
  test("testRetrieveOnDiscountsPageByEmailId", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveOnDiscountsPageByEmailId","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteRetrievalScenarios.java","sourceLine":226,"className":"QuoteRetrievalScenarios","method":"testRetrieveOnDiscountsPageByEmailId","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_RETRIEVE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteRetrievalScenarios#testSAFLOnDiscountsPage
  test("testSAFLOnDiscountsPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteRetrievalScenarios#testSAFLOnDiscountsPage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteRetrievalScenarios.java","sourceLine":231,"className":"QuoteRetrievalScenarios","method":"testSAFLOnDiscountsPage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_RETRIEVE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveOnQuotePage
  test("testRetrieveOnQuotePage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveOnQuotePage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteRetrievalScenarios.java","sourceLine":360,"className":"QuoteRetrievalScenarios","method":"testRetrieveOnQuotePage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_RETRIEVE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveOnQuotePageByEmailId
  test("testRetrieveOnQuotePageByEmailId", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveOnQuotePageByEmailId","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteRetrievalScenarios.java","sourceLine":365,"className":"QuoteRetrievalScenarios","method":"testRetrieveOnQuotePageByEmailId","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_RETRIEVE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteRetrievalScenarios#testSAFLOnQuotePage
  test("testSAFLOnQuotePage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteRetrievalScenarios#testSAFLOnQuotePage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteRetrievalScenarios.java","sourceLine":370,"className":"QuoteRetrievalScenarios","method":"testSAFLOnQuotePage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_RETRIEVE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveQuoteDetailsPage
  test("testRetrieveQuoteDetailsPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveQuoteDetailsPage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteRetrievalScenarios.java","sourceLine":583,"className":"QuoteRetrievalScenarios","method":"testRetrieveQuoteDetailsPage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_RETRIEVE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveThankYouPage
  test("testRetrieveThankYouPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteRetrievalScenarios#testRetrieveThankYouPage","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteRetrievalScenarios.java","sourceLine":735,"className":"QuoteRetrievalScenarios","method":"testRetrieveThankYouPage","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_RETRIEVE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteRetrievalScenarios#testProdRetrieveOnQuotePageHQM
  test("testProdRetrieveOnQuotePageHQM", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteRetrievalScenarios#testProdRetrieveOnQuotePageHQM","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteRetrievalScenarios.java","sourceLine":857,"className":"QuoteRetrievalScenarios","method":"testProdRetrieveOnQuotePageHQM","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {})}, groups = {})"});
  });

});
