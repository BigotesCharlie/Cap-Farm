// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.hqm.QuoteScenarios", () => {
  // legacy-id: com.farmers.ffq.hqm.QuoteScenarios#hqmNewQuote
  test("hqmNewQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteScenarios#hqmNewQuote","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteScenarios.java","sourceLine":43,"className":"QuoteScenarios","method":"hqmNewQuote","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{HQM_E2E_REGRESSION, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_E2E_REGRESSION, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteScenarios#smokeHqmNewQuote
  test("smokeHqmNewQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteScenarios#smokeHqmNewQuote","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteScenarios.java","sourceLine":48,"className":"QuoteScenarios","method":"smokeHqmNewQuote","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_SMOKE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_SMOKE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteScenarios#hqmPEWCScreen
  test("hqmPEWCScreen", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteScenarios#hqmPEWCScreen","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteScenarios.java","sourceLine":53,"className":"QuoteScenarios","method":"hqmPEWCScreen","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{PEWC}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {PEWC})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteScenarios#smokeHqmRandomStates
  test("smokeHqmRandomStates", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteScenarios#smokeHqmRandomStates","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteScenarios.java","sourceLine":59,"className":"QuoteScenarios","method":"smokeHqmRandomStates","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"\"randomStatesByGroup\"","groups":"{HQM_SMOKE}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = \"randomStatesByGroup\", groups = {HQM_SMOKE})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteScenarios#hqmMobileQuote
  test("hqmMobileQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteScenarios#hqmMobileQuote","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteScenarios.java","sourceLine":64,"className":"QuoteScenarios","method":"hqmMobileQuote","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{HQM_E2E_MOBILE, HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_E2E_MOBILE, HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteScenarios#testProdSmokeHqm
  test("testProdSmokeHqm", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteScenarios#testProdSmokeHqm","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteScenarios.java","sourceLine":173,"className":"QuoteScenarios","method":"testProdSmokeHqm","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_PROD_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_PROD_DATA_PROVIDER, dataProviderClass = DataProviders.class, attributes = {@CustomAttribute(name = \"includedStates\", values = {MT})}, groups = {})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteScenarios#testHqmADA
  test("testHqmADA", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteScenarios#testHqmADA","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteScenarios.java","sourceLine":251,"className":"QuoteScenarios","method":"testHqmADA","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_PROD_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{HQM_ADA_SUITE,ADA_SUITE}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_PROD_DATA_PROVIDER, dataProviderClass = DataProviders.class, attributes = {@CustomAttribute(name = \"includedStates\", values = {MT})}, groups = {HQM_ADA_SUITE,ADA_SUITE})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteScenarios#updatePropertyDetailsDataProvider
  test.skip("updatePropertyDetailsDataProvider", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteScenarios#updatePropertyDetailsDataProvider","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteScenarios.java","sourceLine":365,"className":"QuoteScenarios","method":"updatePropertyDetailsDataProvider","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteScenarios#tempTestEmail
  test.skip("tempTestEmail", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteScenarios#tempTestEmail","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteScenarios.java","sourceLine":474,"className":"QuoteScenarios","method":"tempTestEmail","parameters":"ApplicantHQM applicant","dataProvider":"DataProviders.APPLICANT_HQM_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"RANDOM_ROW","groups":"{HQM_ALL}","annotation":"@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_ALL})"});
  });

  // legacy-id: com.farmers.ffq.hqm.QuoteScenarios#tempTestMixPanel
  test.skip("tempTestMixPanel", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.hqm.QuoteScenarios#tempTestMixPanel","domain":"hqm","sourceFile":"src/test/java/com/farmers/ffq/hqm/QuoteScenarios.java","sourceLine":484,"className":"QuoteScenarios","method":"tempTestMixPanel","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{HQM_ALL}","annotation":"@Test(groups = {HQM_ALL})"});
  });

});
