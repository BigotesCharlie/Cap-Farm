// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.hqm.PageValidationFWSScenarios', () => {
  // legacy-id: com.farmers.ffq.hqm.PageValidationFWSScenarios#testAddressPageFWS_PLA
  test('testAddressPageFWS_PLA', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.hqm.PageValidationFWSScenarios#testAddressPageFWS_PLA',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/PageValidationFWSScenarios.java',
      sourceLine: 29,
      className: 'PageValidationFWSScenarios',
      method: 'testAddressPageFWS_PLA',
      parameters: 'ApplicantHQM applicant',
      dataProvider: 'DataProviders.APPLICANT_HQM_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{HQM_PAGE_REGRESSION, HQM_ALL}',
      annotation:
        '@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_REGRESSION, HQM_ALL}, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MT, CT})})',
    });
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationFWSScenarios#testAddressPageFWS_PLAMobile
  test('testAddressPageFWS_PLAMobile', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.hqm.PageValidationFWSScenarios#testAddressPageFWS_PLAMobile',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/PageValidationFWSScenarios.java',
      sourceLine: 35,
      className: 'PageValidationFWSScenarios',
      method: 'testAddressPageFWS_PLAMobile',
      parameters: 'ApplicantHQM applicant',
      dataProvider: 'DataProviders.APPLICANT_HQM_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{HQM_PAGE_MOBILE, HQM_ALL}',
      annotation:
        '@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_MOBILE, HQM_ALL}, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MT, CT})})',
    });
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationFWSScenarios#testAddressPageFWSFarmersChoicePC
  test('testAddressPageFWSFarmersChoicePC', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.hqm.PageValidationFWSScenarios#testAddressPageFWSFarmersChoicePC',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/PageValidationFWSScenarios.java',
      sourceLine: 65,
      className: 'PageValidationFWSScenarios',
      method: 'testAddressPageFWSFarmersChoicePC',
      parameters: 'ApplicantHQM applicant',
      dataProvider: 'DataProviders.APPLICANT_HQM_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{HQM_PAGE_REGRESSION, HQM_ALL}',
      annotation:
        '@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_REGRESSION, HQM_ALL}, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MT, CT})})',
    });
  });

  // legacy-id: com.farmers.ffq.hqm.PageValidationFWSScenarios#testAddressPageFWSFarmersChoicePCMobile
  test('testAddressPageFWSFarmersChoicePCMobile', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.hqm.PageValidationFWSScenarios#testAddressPageFWSFarmersChoicePCMobile',
      domain: 'hqm',
      sourceFile: 'src/test/java/com/farmers/ffq/hqm/PageValidationFWSScenarios.java',
      sourceLine: 71,
      className: 'PageValidationFWSScenarios',
      method: 'testAddressPageFWSFarmersChoicePCMobile',
      parameters: 'ApplicantHQM applicant',
      dataProvider: 'DataProviders.APPLICANT_HQM_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{HQM_PAGE_MOBILE, HQM_ALL}',
      annotation:
        '@Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_MOBILE, HQM_ALL}, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MT, CT})})',
    });
  });
});
