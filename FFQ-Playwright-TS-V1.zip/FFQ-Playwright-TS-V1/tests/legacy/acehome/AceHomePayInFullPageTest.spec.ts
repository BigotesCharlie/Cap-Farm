// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.acehome.AceHomePayInFullPageTest', () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomePayInFullPageTest#testValidateContentOfPayInFullPageOnLandingAceHome
  test('testValidateContentOfPayInFullPageOnLandingAceHome', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId: 'com.farmers.ffq.acehome.AceHomePayInFullPageTest#testValidateContentOfPayInFullPageOnLandingAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomePayInFullPageTest.java',
      sourceLine: 25,
      className: 'AceHomePayInFullPageTest',
      method: 'testValidateContentOfPayInFullPageOnLandingAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePayInFullPageTest#testValidateContentOfPayInFullPageAndECheckoutWithLenderSelectedAceHome
  test('testValidateContentOfPayInFullPageAndECheckoutWithLenderSelectedAceHome', async ({
    page,
    aceHomeData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomePayInFullPageTest#testValidateContentOfPayInFullPageAndECheckoutWithLenderSelectedAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomePayInFullPageTest.java',
      sourceLine: 46,
      className: 'AceHomePayInFullPageTest',
      method: 'testValidateContentOfPayInFullPageAndECheckoutWithLenderSelectedAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePayInFullPageTest#testValidateContentOfPayInFullPageAndECheckoutWithRenewalSelectedAceHome
  test('testValidateContentOfPayInFullPageAndECheckoutWithRenewalSelectedAceHome', async ({
    page,
    aceHomeData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomePayInFullPageTest#testValidateContentOfPayInFullPageAndECheckoutWithRenewalSelectedAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomePayInFullPageTest.java',
      sourceLine: 61,
      className: 'AceHomePayInFullPageTest',
      method: 'testValidateContentOfPayInFullPageAndECheckoutWithRenewalSelectedAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePayInFullPageTest#validatePaymentByChangingPayInFullBankToMonthlyPayCardAceHome
  test('validatePaymentByChangingPayInFullBankToMonthlyPayCardAceHome', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomePayInFullPageTest#validatePaymentByChangingPayInFullBankToMonthlyPayCardAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomePayInFullPageTest.java',
      sourceLine: 82,
      className: 'AceHomePayInFullPageTest',
      method: 'validatePaymentByChangingPayInFullBankToMonthlyPayCardAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePayInFullPageTest#testPayInFullCreditCardEndToEndAceHome
  test('testPayInFullCreditCardEndToEndAceHome', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId: 'com.farmers.ffq.acehome.AceHomePayInFullPageTest#testPayInFullCreditCardEndToEndAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomePayInFullPageTest.java',
      sourceLine: 115,
      className: 'AceHomePayInFullPageTest',
      method: 'testPayInFullCreditCardEndToEndAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePayInFullPageTest#testPayInFullChangeBankPaymentToCardPaymentEndToEndAceHome
  test('testPayInFullChangeBankPaymentToCardPaymentEndToEndAceHome', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomePayInFullPageTest#testPayInFullChangeBankPaymentToCardPaymentEndToEndAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomePayInFullPageTest.java',
      sourceLine: 136,
      className: 'AceHomePayInFullPageTest',
      method: 'testPayInFullChangeBankPaymentToCardPaymentEndToEndAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePayInFullPageTest#testPayInFullChangeCreditCardPaymentToBankPaymentEndToEndAceHome
  test('testPayInFullChangeCreditCardPaymentToBankPaymentEndToEndAceHome', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomePayInFullPageTest#testPayInFullChangeCreditCardPaymentToBankPaymentEndToEndAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomePayInFullPageTest.java',
      sourceLine: 159,
      className: 'AceHomePayInFullPageTest',
      method: 'testPayInFullChangeCreditCardPaymentToBankPaymentEndToEndAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePayInFullPageTest#testQuoteToPaymentSelectionPageHome
  test('testQuoteToPaymentSelectionPageHome', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId: 'com.farmers.ffq.acehome.AceHomePayInFullPageTest#testQuoteToPaymentSelectionPageHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomePayInFullPageTest.java',
      sourceLine: 184,
      className: 'AceHomePayInFullPageTest',
      method: 'testQuoteToPaymentSelectionPageHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{ACE_STABILITY}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {ACE_STABILITY})',
    });
  });
});
