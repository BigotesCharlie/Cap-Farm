// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testRetrieveNonRatedQuoteHome
  test("testRetrieveNonRatedQuoteHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testRetrieveNonRatedQuoteHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeRetrieveQuoteTest.java","sourceLine":28,"className":"AceHomeRetrieveQuoteTest","method":"testRetrieveNonRatedQuoteHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_RETRIEVE_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testRetrieveRatedQuoteHome
  test("testRetrieveRatedQuoteHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testRetrieveRatedQuoteHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeRetrieveQuoteTest.java","sourceLine":102,"className":"AceHomeRetrieveQuoteTest","method":"testRetrieveRatedQuoteHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_RETRIEVE_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testRetrieveQuoteFromAdditionalCoveragePage
  test("testRetrieveQuoteFromAdditionalCoveragePage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testRetrieveQuoteFromAdditionalCoveragePage","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeRetrieveQuoteTest.java","sourceLine":205,"className":"AceHomeRetrieveQuoteTest","method":"testRetrieveQuoteFromAdditionalCoveragePage","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_RETRIEVE_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testRetrieveRatedQuoteFromJFMTPage
  test("testRetrieveRatedQuoteFromJFMTPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testRetrieveRatedQuoteFromJFMTPage","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeRetrieveQuoteTest.java","sourceLine":231,"className":"AceHomeRetrieveQuoteTest","method":"testRetrieveRatedQuoteFromJFMTPage","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_RETRIEVE_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testRetrieveRatedQuoteFromPaymentPage
  test("testRetrieveRatedQuoteFromPaymentPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testRetrieveRatedQuoteFromPaymentPage","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeRetrieveQuoteTest.java","sourceLine":258,"className":"AceHomeRetrieveQuoteTest","method":"testRetrieveRatedQuoteFromPaymentPage","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_RETRIEVE_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testWindHailExclusionCoverage
  test("testWindHailExclusionCoverage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testWindHailExclusionCoverage","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeRetrieveQuoteTest.java","sourceLine":299,"className":"AceHomeRetrieveQuoteTest","method":"testWindHailExclusionCoverage","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_POLICY_EXCLUSION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, TX})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testSweepStakesCampaignReviewAndRetrieveQuoteHome
  test.skip("testSweepStakesCampaignReviewAndRetrieveQuoteHome", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeRetrieveQuoteTest#testSweepStakesCampaignReviewAndRetrieveQuoteHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeRetrieveQuoteTest.java","sourceLine":319,"className":"AceHomeRetrieveQuoteTest","method":"testSweepStakesCampaignReviewAndRetrieveQuoteHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"ONE_APPLICANT_PER_STATE","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = ONE_APPLICANT_PER_STATE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_RETRIEVE_FLOW}, enabled = false)"});
  });

});
