// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.acehome.AceHomeMonthlyAutoPayCardPageTest', () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeMonthlyAutoPayCardPageTest#testValidateContentOfMonthlyAutoPayCardPageAndNavigateToJFMTPage
  test('testValidateContentOfMonthlyAutoPayCardPageAndNavigateToJFMTPage', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeMonthlyAutoPayCardPageTest#testValidateContentOfMonthlyAutoPayCardPageAndNavigateToJFMTPage',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeMonthlyAutoPayCardPageTest.java',
      sourceLine: 21,
      className: 'AceHomeMonthlyAutoPayCardPageTest',
      method: 'testValidateContentOfMonthlyAutoPayCardPageAndNavigateToJFMTPage',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeMonthlyAutoPayCardPageTest#testMonthlyAutoPayCardCreditCardPaymentEndToEndAceHome
  test('testMonthlyAutoPayCardCreditCardPaymentEndToEndAceHome', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeMonthlyAutoPayCardPageTest#testMonthlyAutoPayCardCreditCardPaymentEndToEndAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeMonthlyAutoPayCardPageTest.java',
      sourceLine: 39,
      className: 'AceHomeMonthlyAutoPayCardPageTest',
      method: 'testMonthlyAutoPayCardCreditCardPaymentEndToEndAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeMonthlyAutoPayCardPageTest#testMonthlyAutoPayCardBankPaymentEndToEndAceHome
  test('testMonthlyAutoPayCardBankPaymentEndToEndAceHome', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeMonthlyAutoPayCardPageTest#testMonthlyAutoPayCardBankPaymentEndToEndAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeMonthlyAutoPayCardPageTest.java',
      sourceLine: 58,
      className: 'AceHomeMonthlyAutoPayCardPageTest',
      method: 'testMonthlyAutoPayCardBankPaymentEndToEndAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeMonthlyAutoPayCardPageTest#testMonthlyAutoPayCardChangeCreditCardPaymentToBankEndToEndAceHome
  test('testMonthlyAutoPayCardChangeCreditCardPaymentToBankEndToEndAceHome', async ({
    page,
    aceHomeData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeMonthlyAutoPayCardPageTest#testMonthlyAutoPayCardChangeCreditCardPaymentToBankEndToEndAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeMonthlyAutoPayCardPageTest.java',
      sourceLine: 78,
      className: 'AceHomeMonthlyAutoPayCardPageTest',
      method: 'testMonthlyAutoPayCardChangeCreditCardPaymentToBankEndToEndAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeMonthlyAutoPayCardPageTest#testMonthlyAutoPayCardChangeBankPaymentToCardEndToEndAceHome
  test('testMonthlyAutoPayCardChangeBankPaymentToCardEndToEndAceHome', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeMonthlyAutoPayCardPageTest#testMonthlyAutoPayCardChangeBankPaymentToCardEndToEndAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeMonthlyAutoPayCardPageTest.java',
      sourceLine: 103,
      className: 'AceHomeMonthlyAutoPayCardPageTest',
      method: 'testMonthlyAutoPayCardChangeBankPaymentToCardEndToEndAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE})',
    });
  });
});
