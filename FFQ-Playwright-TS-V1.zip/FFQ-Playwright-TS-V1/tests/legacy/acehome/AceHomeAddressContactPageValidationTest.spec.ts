// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#testAddressContactPageHome
  test("testAddressContactPageHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#testAddressContactPageHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAddressContactPageValidationTest.java","sourceLine":19,"className":"AceHomeAddressContactPageValidationTest","method":"testAddressContactPageHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDRESS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#validateFWSInterstitialToBindableChoiceIntegrationHome
  test("validateFWSInterstitialToBindableChoiceIntegrationHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#validateFWSInterstitialToBindableChoiceIntegrationHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAddressContactPageValidationTest.java","sourceLine":49,"className":"AceHomeAddressContactPageValidationTest","method":"validateFWSInterstitialToBindableChoiceIntegrationHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_BINDABLE_CHOICE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#validateFWSInterstitialColpPageHome
  test("validateFWSInterstitialColpPageHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#validateFWSInterstitialColpPageHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAddressContactPageValidationTest.java","sourceLine":72,"className":"AceHomeAddressContactPageValidationTest","method":"validateFWSInterstitialColpPageHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_COLP, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#validateFWSInterstitialQnBPageHome
  test("validateFWSInterstitialQnBPageHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#validateFWSInterstitialQnBPageHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAddressContactPageValidationTest.java","sourceLine":89,"className":"AceHomeAddressContactPageValidationTest","method":"validateFWSInterstitialQnBPageHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_QNB, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#testFGIANotOfferingValidationHomeLob
  test("testFGIANotOfferingValidationHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#testFGIANotOfferingValidationHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAddressContactPageValidationTest.java","sourceLine":110,"className":"AceHomeAddressContactPageValidationTest","method":"testFGIANotOfferingValidationHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {MA, NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#testFGIALandingPageValidationHomeLob
  test("testFGIALandingPageValidationHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#testFGIALandingPageValidationHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAddressContactPageValidationTest.java","sourceLine":127,"className":"AceHomeAddressContactPageValidationTest","method":"testFGIALandingPageValidationHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {MA, NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#testDigitalMonetizationValidationNonAWSHomeLob
  test("testDigitalMonetizationValidationNonAWSHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAddressContactPageValidationTest#testDigitalMonetizationValidationNonAWSHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAddressContactPageValidationTest.java","sourceLine":145,"className":"AceHomeAddressContactPageValidationTest","method":"testDigitalMonetizationValidationNonAWSHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_DIGITAL_MONETIZATION_NON_AWS, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {NJ, DC, DE, HI, ME, NH, RI, VT, WV, NY})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})"});
  });

});
