// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomeKnockOutTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeKnockOutTest#oneMillionReconstructionCostKnockOutValidation
  test("oneMillionReconstructionCostKnockOutValidation", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeKnockOutTest#oneMillionReconstructionCostKnockOutValidation","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeKnockOutTest.java","sourceLine":28,"className":"AceHomeKnockOutTest","method":"oneMillionReconstructionCostKnockOutValidation","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_RECONSTRUCTION_COST_KO, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {IL})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeKnockOutTest#unfencedTrampolineSelectionKnockOutValidation
  test("unfencedTrampolineSelectionKnockOutValidation", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeKnockOutTest#unfencedTrampolineSelectionKnockOutValidation","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeKnockOutTest.java","sourceLine":60,"className":"AceHomeKnockOutTest","method":"unfencedTrampolineSelectionKnockOutValidation","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, suiteName = AceHomeDataProviders.CATEGORY_UNFENCED_POOL_TRAMPOLINE, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_KNOCKOUT_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeKnockOutTest#propertyTypeKnockOutOther
  test("propertyTypeKnockOutOther", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeKnockOutTest#propertyTypeKnockOutOther","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeKnockOutTest.java","sourceLine":74,"className":"AceHomeKnockOutTest","method":"propertyTypeKnockOutOther","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, suiteName = AceHomeDataProviders.CATEGORY_RECONSTRUCTION_COST_KO, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeKnockOutTest#propertyTypeKnockOutMobileManufactured
  test.skip("propertyTypeKnockOutMobileManufactured", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeKnockOutTest#propertyTypeKnockOutMobileManufactured","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeKnockOutTest.java","sourceLine":101,"className":"AceHomeKnockOutTest","method":"propertyTypeKnockOutMobileManufactured","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, suiteName = AceHomeDataProviders.CATEGORY_RECONSTRUCTION_COST_KO, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW}, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeKnockOutTest#testFoundationTypeDeepPilingsKnockout
  test("testFoundationTypeDeepPilingsKnockout", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeKnockOutTest#testFoundationTypeDeepPilingsKnockout","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeKnockOutTest.java","sourceLine":129,"className":"AceHomeKnockOutTest","method":"testFoundationTypeDeepPilingsKnockout","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, suiteName = AceHomeDataProviders.CATEGORY_FOUNDATIONTYPE_KO,groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeKnockOutTest#ppcFireHydrantKO
  test("ppcFireHydrantKO", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeKnockOutTest#ppcFireHydrantKO","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeKnockOutTest.java","sourceLine":148,"className":"AceHomeKnockOutTest","method":"ppcFireHydrantKO","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, suiteName = AceHomeDataProviders.CATEGORY_PPC_FIRE_HYDRANT_KO, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeKnockOutTest#ppcZipMismatchKO
  test("ppcZipMismatchKO", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeKnockOutTest#ppcZipMismatchKO","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeKnockOutTest.java","sourceLine":166,"className":"AceHomeKnockOutTest","method":"ppcZipMismatchKO","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, suiteName = AceHomeDataProviders.CATEGORY_PPC_ZIP_MISMATCH_KO, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeKnockOutTest#testPropertyTypeDuplexNonPrimaryResidenceKnockOut
  test("testPropertyTypeDuplexNonPrimaryResidenceKnockOut", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeKnockOutTest#testPropertyTypeDuplexNonPrimaryResidenceKnockOut","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeKnockOutTest.java","sourceLine":182,"className":"AceHomeKnockOutTest","method":"testPropertyTypeDuplexNonPrimaryResidenceKnockOut","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA, MO, PA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeKnockOutTest#testPolicyExclusionKnockout
  test("testPolicyExclusionKnockout", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeKnockOutTest#testPolicyExclusionKnockout","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeKnockOutTest.java","sourceLine":204,"className":"AceHomeKnockOutTest","method":"testPolicyExclusionKnockout","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, suiteName = AceHomeDataProviders.CATEGORY_POLICY_EXCLUSION, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeKnockOutTest#propertyTypeKnockOutFromPropertyDetailsSideSheet
  test("propertyTypeKnockOutFromPropertyDetailsSideSheet", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeKnockOutTest#propertyTypeKnockOutFromPropertyDetailsSideSheet","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeKnockOutTest.java","sourceLine":224,"className":"AceHomeKnockOutTest","method":"propertyTypeKnockOutFromPropertyDetailsSideSheet","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeKnockOutTest#validateUnacceptableRoofKO
  test("validateUnacceptableRoofKO", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeKnockOutTest#validateUnacceptableRoofKO","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeKnockOutTest.java","sourceLine":246,"className":"AceHomeKnockOutTest","method":"validateUnacceptableRoofKO","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_UNACCEPTABLE_ROOF_KO, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeKnockOutTest#validatePreBindContingencyKO
  test("validatePreBindContingencyKO", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeKnockOutTest#validatePreBindContingencyKO","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeKnockOutTest.java","sourceLine":265,"className":"AceHomeKnockOutTest","method":"validatePreBindContingencyKO","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_PRE_BIND_CONTINGENCY_KO, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MN})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})"});
  });

});
