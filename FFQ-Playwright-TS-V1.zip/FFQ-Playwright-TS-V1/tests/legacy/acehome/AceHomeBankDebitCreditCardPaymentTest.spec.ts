// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomeBankDebitCreditCardPaymentTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeBankDebitCreditCardPaymentTest#testValidateContentAndErrorsForPayInFullBankAndDebitCreditIFrameAceHome
  test("testValidateContentAndErrorsForPayInFullBankAndDebitCreditIFrameAceHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeBankDebitCreditCardPaymentTest#testValidateContentAndErrorsForPayInFullBankAndDebitCreditIFrameAceHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeBankDebitCreditCardPaymentTest.java","sourceLine":17,"className":"AceHomeBankDebitCreditCardPaymentTest","method":"testValidateContentAndErrorsForPayInFullBankAndDebitCreditIFrameAceHome","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL})"});
  });

});
