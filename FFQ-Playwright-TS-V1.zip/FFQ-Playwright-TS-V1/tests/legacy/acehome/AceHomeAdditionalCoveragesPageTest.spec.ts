// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomeAdditionalCoveragesPageTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeAdditionalCoveragesPageTest#testAdditionalCoveragesPageQuotePresentmentCardHome
  test("testAdditionalCoveragesPageQuotePresentmentCardHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAdditionalCoveragesPageTest#testAdditionalCoveragesPageQuotePresentmentCardHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAdditionalCoveragesPageTest.java","sourceLine":19,"className":"AceHomeAdditionalCoveragesPageTest","method":"testAdditionalCoveragesPageQuotePresentmentCardHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDITIONAL_COVERAGES_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDITIONAL_COVERAGES_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAdditionalCoveragesPageTest#testAdditionalCoveragesPageTogglesValidationHome
  test("testAdditionalCoveragesPageTogglesValidationHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAdditionalCoveragesPageTest#testAdditionalCoveragesPageTogglesValidationHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAdditionalCoveragesPageTest.java","sourceLine":46,"className":"AceHomeAdditionalCoveragesPageTest","method":"testAdditionalCoveragesPageTogglesValidationHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_COVERAGES_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_COVERAGES_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAdditionalCoveragesPageTest#testSecondarySeasonalHomeAceHome
  test("testSecondarySeasonalHomeAceHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAdditionalCoveragesPageTest#testSecondarySeasonalHomeAceHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAdditionalCoveragesPageTest.java","sourceLine":66,"className":"AceHomeAdditionalCoveragesPageTest","method":"testSecondarySeasonalHomeAceHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_COVERAGES_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA, MO, PA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_COVERAGES_PAGE})"});
  });

});
