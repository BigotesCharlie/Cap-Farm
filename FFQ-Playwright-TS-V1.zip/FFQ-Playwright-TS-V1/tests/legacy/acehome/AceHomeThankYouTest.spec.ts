// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomeThankYouTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeThankYouTest#validateContentOfThankYouPageHomeLob
  test("validateContentOfThankYouPageHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeThankYouTest#validateContentOfThankYouPageHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeThankYouTest.java","sourceLine":20,"className":"AceHomeThankYouTest","method":"validateContentOfThankYouPageHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_THANK_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_THANK_YOU_SCREEN_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_THANK_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeThankYouTest#validateThankYouPageWhenPropertyTypeDuplexHomeLob
  test("validateThankYouPageWhenPropertyTypeDuplexHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeThankYouTest#validateThankYouPageWhenPropertyTypeDuplexHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeThankYouTest.java","sourceLine":51,"className":"AceHomeThankYouTest","method":"validateThankYouPageWhenPropertyTypeDuplexHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_THANK_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_THANK_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeThankYouTest#validateThankYouPageWhenAddressIsCAHomeLob
  test.skip("validateThankYouPageWhenAddressIsCAHomeLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeThankYouTest#validateThankYouPageWhenAddressIsCAHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeThankYouTest.java","sourceLine":61,"className":"AceHomeThankYouTest","method":"validateThankYouPageWhenAddressIsCAHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_THANK_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_THANK_YOU_SCREEN_VALIDATION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_THANK_YOU_PAGE}, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeThankYouTest#testValidateMaxRCTLimitNotToExceed1n5MHomeLob
  test("testValidateMaxRCTLimitNotToExceed1n5MHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeThankYouTest#testValidateMaxRCTLimitNotToExceed1n5MHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeThankYouTest.java","sourceLine":77,"className":"AceHomeThankYouTest","method":"testValidateMaxRCTLimitNotToExceed1n5MHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_THANK_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_RECONSTRUCTION_COST_1_TO_1N_HALF, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_THANK_YOU_PAGE})"});
  });

});
