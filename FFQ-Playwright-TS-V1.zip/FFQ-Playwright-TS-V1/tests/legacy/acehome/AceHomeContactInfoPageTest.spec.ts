// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomeContactInfoPageTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeContactInfoPageTest#validateContactInfoPageHomeLob
  test("validateContactInfoPageHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeContactInfoPageTest#validateContactInfoPageHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeContactInfoPageTest.java","sourceLine":21,"className":"AceHomeContactInfoPageTest","method":"validateContactInfoPageHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeContactInfoPageTest#validateContactInfoPageErrorMessagesHomeLob
  test("validateContactInfoPageErrorMessagesHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeContactInfoPageTest#validateContactInfoPageErrorMessagesHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeContactInfoPageTest.java","sourceLine":49,"className":"AceHomeContactInfoPageTest","method":"validateContactInfoPageErrorMessagesHomeLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeContactInfoPageTest#validateEarlyShoppingDiscountFunctionalityHomeLob
  test("validateEarlyShoppingDiscountFunctionalityHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeContactInfoPageTest#validateEarlyShoppingDiscountFunctionalityHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeContactInfoPageTest.java","sourceLine":58,"className":"AceHomeContactInfoPageTest","method":"validateEarlyShoppingDiscountFunctionalityHomeLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeContactInfoPageTest#aceHomePEWCScreen
  test.skip("aceHomePEWCScreen", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeContactInfoPageTest#aceHomePEWCScreen","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeContactInfoPageTest.java","sourceLine":68,"className":"AceHomeContactInfoPageTest","method":"aceHomePEWCScreen","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{PEWC}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},groups = {PEWC})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeContactInfoPageTest#aceHomeRelocatedPEWCScreen
  test("aceHomeRelocatedPEWCScreen", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeContactInfoPageTest#aceHomeRelocatedPEWCScreen","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeContactInfoPageTest.java","sourceLine":77,"className":"AceHomeContactInfoPageTest","method":"aceHomeRelocatedPEWCScreen","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{PEWC}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})},groups = {PEWC})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeContactInfoPageTest#validateFWSInterstitialToBindableChoiceIntegrationHome
  test.skip("validateFWSInterstitialToBindableChoiceIntegrationHome", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeContactInfoPageTest#validateFWSInterstitialToBindableChoiceIntegrationHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeContactInfoPageTest.java","sourceLine":87,"className":"AceHomeContactInfoPageTest","method":"validateFWSInterstitialToBindableChoiceIntegrationHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_BINDABLE_CHOICE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeContactInfoPageTest#validateFWSInterstitialColpPageHome
  test.skip("validateFWSInterstitialColpPageHome", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeContactInfoPageTest#validateFWSInterstitialColpPageHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeContactInfoPageTest.java","sourceLine":111,"className":"AceHomeContactInfoPageTest","method":"validateFWSInterstitialColpPageHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_COLP, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeContactInfoPageTest#validateFWSInterstitialQnBPageHome
  test.skip("validateFWSInterstitialQnBPageHome", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeContactInfoPageTest#validateFWSInterstitialQnBPageHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeContactInfoPageTest.java","sourceLine":129,"className":"AceHomeContactInfoPageTest","method":"validateFWSInterstitialQnBPageHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_QNB, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})"});
  });

});
