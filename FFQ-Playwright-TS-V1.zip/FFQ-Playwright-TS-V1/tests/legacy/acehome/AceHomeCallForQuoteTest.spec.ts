// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomeCallForQuoteTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeCallForQuoteTest#testCallForQuoteToAceReviewQuoteHomeLob
  test.skip("testCallForQuoteToAceReviewQuoteHomeLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeCallForQuoteTest#testCallForQuoteToAceReviewQuoteHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeCallForQuoteTest.java","sourceLine":30,"className":"AceHomeCallForQuoteTest","method":"testCallForQuoteToAceReviewQuoteHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, AL, GA, IL, OH, VA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})"});
  });

});
