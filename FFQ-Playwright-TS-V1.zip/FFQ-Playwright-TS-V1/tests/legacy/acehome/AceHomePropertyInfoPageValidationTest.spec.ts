// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomePropertyInfoPageValidationTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomePropertyInfoPageValidationTest#testPropertyInfoPage
  test("testPropertyInfoPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePropertyInfoPageValidationTest#testPropertyInfoPage","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePropertyInfoPageValidationTest.java","sourceLine":16,"className":"AceHomePropertyInfoPageValidationTest","method":"testPropertyInfoPage","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_TYPE_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_TYPE_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePropertyInfoPageValidationTest#testPropertyInfoPageErrorMessage
  test("testPropertyInfoPageErrorMessage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePropertyInfoPageValidationTest#testPropertyInfoPageErrorMessage","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePropertyInfoPageValidationTest.java","sourceLine":29,"className":"AceHomePropertyInfoPageValidationTest","method":"testPropertyInfoPageErrorMessage","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_PROPERTY_TYPE_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, OH, OR, TX, UT})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_PROPERTY_TYPE_PAGE})"});
  });

});
