// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomePropertyDetailsPageValidationTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomePropertyDetailsPageValidationTest#testPropertyDetailsPageHome
  test("testPropertyDetailsPageHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePropertyDetailsPageValidationTest#testPropertyDetailsPageHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePropertyDetailsPageValidationTest.java","sourceLine":23,"className":"AceHomePropertyDetailsPageValidationTest","method":"testPropertyDetailsPageHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePropertyDetailsPageValidationTest#testPropertyDetailsPageTownHome
  test("testPropertyDetailsPageTownHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePropertyDetailsPageValidationTest#testPropertyDetailsPageTownHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePropertyDetailsPageValidationTest.java","sourceLine":29,"className":"AceHomePropertyDetailsPageValidationTest","method":"testPropertyDetailsPageTownHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePropertyDetailsPageValidationTest#testPropertyDetailsPageDuplex
  test("testPropertyDetailsPageDuplex", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePropertyDetailsPageValidationTest#testPropertyDetailsPageDuplex","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePropertyDetailsPageValidationTest.java","sourceLine":35,"className":"AceHomePropertyDetailsPageValidationTest","method":"testPropertyDetailsPageDuplex","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePropertyDetailsPageValidationTest#testPropertyDetailsPageEditModalHome
  test("testPropertyDetailsPageEditModalHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePropertyDetailsPageValidationTest#testPropertyDetailsPageEditModalHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePropertyDetailsPageValidationTest.java","sourceLine":121,"className":"AceHomePropertyDetailsPageValidationTest","method":"testPropertyDetailsPageEditModalHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePropertyDetailsPageValidationTest#testPropertyDetailsPageEditModalTownHome
  test("testPropertyDetailsPageEditModalTownHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePropertyDetailsPageValidationTest#testPropertyDetailsPageEditModalTownHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePropertyDetailsPageValidationTest.java","sourceLine":127,"className":"AceHomePropertyDetailsPageValidationTest","method":"testPropertyDetailsPageEditModalTownHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePropertyDetailsPageValidationTest#testPropertyDetailsPageEditModalDuplex
  test("testPropertyDetailsPageEditModalDuplex", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePropertyDetailsPageValidationTest#testPropertyDetailsPageEditModalDuplex","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePropertyDetailsPageValidationTest.java","sourceLine":133,"className":"AceHomePropertyDetailsPageValidationTest","method":"testPropertyDetailsPageEditModalDuplex","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE})"});
  });

});
