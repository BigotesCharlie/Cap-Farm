// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomeDwellingCoveragePageTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeDwellingCoveragePageTest#dwellingCoveragePageContentValidationHomeLob
  test("dwellingCoveragePageContentValidationHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeDwellingCoveragePageTest#dwellingCoveragePageContentValidationHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeDwellingCoveragePageTest.java","sourceLine":21,"className":"AceHomeDwellingCoveragePageTest","method":"dwellingCoveragePageContentValidationHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_DWELLING_COVERAGE_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_DWELLING_COVERAGE_PAGE})"});
  });

});
