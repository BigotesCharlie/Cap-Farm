// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#testAdditionalInfoPageNearMapRoofYearPrefilled
  test("testAdditionalInfoPageNearMapRoofYearPrefilled", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#testAdditionalInfoPageNearMapRoofYearPrefilled","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAdditionalInfoPageTest.java","sourceLine":76,"className":"AceHomeAdditionalInfoPageTest","method":"testAdditionalInfoPageNearMapRoofYearPrefilled","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, CT, ID, KY, LA, MA, MD, MI, MN, MS, MT, NC, NJ, NV, NY, OR, PA, UT, VA, WA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#testAdditionalInfoPageNearMapRoofYearNotPrefilled
  test("testAdditionalInfoPageNearMapRoofYearNotPrefilled", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#testAdditionalInfoPageNearMapRoofYearNotPrefilled","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAdditionalInfoPageTest.java","sourceLine":95,"className":"AceHomeAdditionalInfoPageTest","method":"testAdditionalInfoPageNearMapRoofYearNotPrefilled","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, CT, ID, KY, LA, MA, MD, MI, MN, MS, MT, NC, NJ, NV, NY, OR, PA, UT, VA, WA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#validateAdditionalInfoPageContentHomeLob
  test("validateAdditionalInfoPageContentHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#validateAdditionalInfoPageContentHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAdditionalInfoPageTest.java","sourceLine":114,"className":"AceHomeAdditionalInfoPageTest","method":"validateAdditionalInfoPageContentHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#validateAdditionalInfoErrorsHomeLob
  test("validateAdditionalInfoErrorsHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#validateAdditionalInfoErrorsHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAdditionalInfoPageTest.java","sourceLine":219,"className":"AceHomeAdditionalInfoPageTest","method":"validateAdditionalInfoErrorsHomeLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#validateFloorResidenceLocatedHomeLob
  test("validateFloorResidenceLocatedHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#validateFloorResidenceLocatedHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAdditionalInfoPageTest.java","sourceLine":229,"className":"AceHomeAdditionalInfoPageTest","method":"validateFloorResidenceLocatedHomeLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#testDataSaveChangesWhenNavigatedBackandForthAdditionalInfoPageHomeLob
  test("testDataSaveChangesWhenNavigatedBackandForthAdditionalInfoPageHomeLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#testDataSaveChangesWhenNavigatedBackandForthAdditionalInfoPageHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAdditionalInfoPageTest.java","sourceLine":242,"className":"AceHomeAdditionalInfoPageTest","method":"testDataSaveChangesWhenNavigatedBackandForthAdditionalInfoPageHomeLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE})"});
  });

});
