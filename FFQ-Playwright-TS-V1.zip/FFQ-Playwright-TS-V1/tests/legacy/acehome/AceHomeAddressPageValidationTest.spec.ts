// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.acehome.AceHomeAddressPageValidationTest', () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testAddressPageHome
  test.skip('testAddressPageHome', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testAddressPageHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeAddressPageValidationTest.java',
      sourceLine: 22,
      className: 'AceHomeAddressPageValidationTest',
      method: 'testAddressPageHome',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDRESS_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDRESS_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testAddressPageTownHome
  test.skip('testAddressPageTownHome', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testAddressPageTownHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeAddressPageValidationTest.java',
      sourceLine: 30,
      className: 'AceHomeAddressPageValidationTest',
      method: 'testAddressPageTownHome',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testAddressPageDuplex
  test.skip('testAddressPageDuplex', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testAddressPageDuplex',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeAddressPageValidationTest.java',
      sourceLine: 38,
      className: 'AceHomeAddressPageValidationTest',
      method: 'testAddressPageDuplex',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testAddressPageNonPrimaryResidence
  test.skip('testAddressPageNonPrimaryResidence', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testAddressPageNonPrimaryResidence',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeAddressPageValidationTest.java',
      sourceLine: 105,
      className: 'AceHomeAddressPageValidationTest',
      method: 'testAddressPageNonPrimaryResidence',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDRESS_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDRESS_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testAddressPageTwoOrMorePropertyClaimsInLastThreeYearsHomeLob
  test.skip('testAddressPageTwoOrMorePropertyClaimsInLastThreeYearsHomeLob', async ({
    page,
    aceHomeData,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testAddressPageTwoOrMorePropertyClaimsInLastThreeYearsHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeAddressPageValidationTest.java',
      sourceLine: 118,
      className: 'AceHomeAddressPageValidationTest',
      method: 'testAddressPageTwoOrMorePropertyClaimsInLastThreeYearsHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#validateDataWhenNavigatedBackAndForthAddressPageHomeLob
  test.skip('validateDataWhenNavigatedBackAndForthAddressPageHomeLob', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#validateDataWhenNavigatedBackAndForthAddressPageHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeAddressPageValidationTest.java',
      sourceLine: 131,
      className: 'AceHomeAddressPageValidationTest',
      method: 'validateDataWhenNavigatedBackAndForthAddressPageHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDRESS_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDRESS_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testFGIANotOfferingValidationHomeLob
  test('testFGIANotOfferingValidationHomeLob', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testFGIANotOfferingValidationHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeAddressPageValidationTest.java',
      sourceLine: 178,
      className: 'AceHomeAddressPageValidationTest',
      method: 'testFGIANotOfferingValidationHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {MA, NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testFGIALandingPageValidationHomeLob
  test('testFGIALandingPageValidationHomeLob', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testFGIALandingPageValidationHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeAddressPageValidationTest.java',
      sourceLine: 195,
      className: 'AceHomeAddressPageValidationTest',
      method: 'testFGIALandingPageValidationHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {MA, NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testDigitalMonetizationValidationNonAWSHomeLob
  test('testDigitalMonetizationValidationNonAWSHomeLob', async ({ page, aceHomeData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, aceHomeData, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeAddressPageValidationTest#testDigitalMonetizationValidationNonAWSHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeAddressPageValidationTest.java',
      sourceLine: 213,
      className: 'AceHomeAddressPageValidationTest',
      method: 'testDigitalMonetizationValidationNonAWSHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_DIGITAL_MONETIZATION_NON_AWS, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {LA, NJ, DC, DE, HI, ME, MS, NH, RI, VT, WV, NY})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})',
    });
  });
});
