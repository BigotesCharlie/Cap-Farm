// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomePropertyTypePageValidationTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomePropertyTypePageValidationTest#testPropertyTypePage
  test.skip("testPropertyTypePage", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePropertyTypePageValidationTest#testPropertyTypePage","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePropertyTypePageValidationTest.java","sourceLine":21,"className":"AceHomePropertyTypePageValidationTest","method":"testPropertyTypePage","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_TYPE_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_TYPE_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePropertyTypePageValidationTest#testPropertyTypePageNewFlow
  test("testPropertyTypePageNewFlow", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePropertyTypePageValidationTest#testPropertyTypePageNewFlow","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePropertyTypePageValidationTest.java","sourceLine":48,"className":"AceHomePropertyTypePageValidationTest","method":"testPropertyTypePageNewFlow","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_TYPE_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_TYPE_PAGE})"});
  });

});
