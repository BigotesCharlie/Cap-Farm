// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomePartnerFlowTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomePartnerFlowTest#testMediaAlphaEndToEndQuoteHome
  test("testMediaAlphaEndToEndQuoteHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePartnerFlowTest#testMediaAlphaEndToEndQuoteHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePartnerFlowTest.java","sourceLine":26,"className":"AceHomePartnerFlowTest","method":"testMediaAlphaEndToEndQuoteHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePartnerFlowTest#testToggleNonRenewalQuoteHome
  test.skip("testToggleNonRenewalQuoteHome", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePartnerFlowTest#testToggleNonRenewalQuoteHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePartnerFlowTest.java","sourceLine":144,"className":"AceHomePartnerFlowTest","method":"testToggleNonRenewalQuoteHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AR,AZ,IL,NM,OK,OR,PA,TN,WI})}, groups = {FFQ_ACE_HOME}, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePartnerFlowTest#testToggleRenewalQuoteHome
  test.skip("testToggleRenewalQuoteHome", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePartnerFlowTest#testToggleRenewalQuoteHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePartnerFlowTest.java","sourceLine":152,"className":"AceHomePartnerFlowTest","method":"testToggleRenewalQuoteHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AR,AZ,IL,NM,OK,OR,PA,TN,WI})}, groups = {FFQ_ACE_HOME}, enabled = false)"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomePartnerFlowTest#testCSSToFFQAceEndToEndQuoteHome
  test.skip("testCSSToFFQAceEndToEndQuoteHome", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomePartnerFlowTest#testCSSToFFQAceEndToEndQuoteHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomePartnerFlowTest.java","sourceLine":195,"className":"AceHomePartnerFlowTest","method":"testCSSToFFQAceEndToEndQuoteHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME}, enabled = false)"});
  });

});
