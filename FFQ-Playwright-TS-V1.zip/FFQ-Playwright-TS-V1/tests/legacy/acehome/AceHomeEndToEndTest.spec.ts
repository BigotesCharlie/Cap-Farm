// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomeEndToEndTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeEndToEndTest#testReviewQuotePagePresentmentCardHome
  test("testReviewQuotePagePresentmentCardHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeEndToEndTest#testReviewQuotePagePresentmentCardHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeEndToEndTest.java","sourceLine":25,"className":"AceHomeEndToEndTest","method":"testReviewQuotePagePresentmentCardHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {})}, groups = {})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeEndToEndTest#testSmokeReviewQuotePagePresentmentCardHome
  test("testSmokeReviewQuotePagePresentmentCardHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeEndToEndTest#testSmokeReviewQuotePagePresentmentCardHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeEndToEndTest.java","sourceLine":45,"className":"AceHomeEndToEndTest","method":"testSmokeReviewQuotePagePresentmentCardHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{ACE_HOME_SMOKE, ACE_HOME_ADA_SUITE, ADA_SUITE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {ACE_HOME_SMOKE, ACE_HOME_ADA_SUITE, ADA_SUITE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeEndToEndTest#testProdRetrieveRatedQuoteAceHome
  test("testProdRetrieveRatedQuoteAceHome", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeEndToEndTest#testProdRetrieveRatedQuoteAceHome","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeEndToEndTest.java","sourceLine":60,"className":"AceHomeEndToEndTest","method":"testProdRetrieveRatedQuoteAceHome","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{PRODUCTION_VALIDATION}","annotation":"@Test(dataProvider = AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,TX})}, groups = {PRODUCTION_VALIDATION})"});
  });

});
