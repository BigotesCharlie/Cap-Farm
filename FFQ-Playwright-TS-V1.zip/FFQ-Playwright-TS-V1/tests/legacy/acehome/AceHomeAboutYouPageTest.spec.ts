// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acehome.AceHomeAboutYouPageTest", () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeAboutYouPageTest#pageContentValidationAboutYouPageHomeLob
  test.skip("pageContentValidationAboutYouPageHomeLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAboutYouPageTest#pageContentValidationAboutYouPageHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAboutYouPageTest.java","sourceLine":24,"className":"AceHomeAboutYouPageTest","method":"pageContentValidationAboutYouPageHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ABOUT_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAboutYouPageTest#validateErrorMessagesAboutYouPageHomeLob
  test.skip("validateErrorMessagesAboutYouPageHomeLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAboutYouPageTest#validateErrorMessagesAboutYouPageHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAboutYouPageTest.java","sourceLine":97,"className":"AceHomeAboutYouPageTest","method":"validateErrorMessagesAboutYouPageHomeLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ABOUT_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAboutYouPageTest#testDataNotSavedWhenNavigatedBackAboutYouPageHomeLob
  test.skip("testDataNotSavedWhenNavigatedBackAboutYouPageHomeLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAboutYouPageTest#testDataNotSavedWhenNavigatedBackAboutYouPageHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAboutYouPageTest.java","sourceLine":183,"className":"AceHomeAboutYouPageTest","method":"testDataNotSavedWhenNavigatedBackAboutYouPageHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ABOUT_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeAboutYouPageTest#validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageHomeLob
  test.skip("validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageHomeLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acehome.AceHomeAboutYouPageTest#validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageHomeLob","domain":"acehome","sourceFile":"src/test/java/com/farmers/ffq/acehome/AceHomeAboutYouPageTest.java","sourceLine":208,"className":"AceHomeAboutYouPageTest","method":"validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageHomeLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_HOME, FFQ_ACE_HOME_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ABOUT_YOU_PAGE})"});
  });

});
