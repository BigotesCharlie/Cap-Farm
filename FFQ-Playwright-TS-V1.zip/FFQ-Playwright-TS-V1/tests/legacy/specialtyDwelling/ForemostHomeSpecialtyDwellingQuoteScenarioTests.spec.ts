// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingQuoteScenarioTests', () => {
  // legacy-id: com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingQuoteScenarioTests#verifyForemostExpectedDiscounts
  test('verifyForemostExpectedDiscounts', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingQuoteScenarioTests#verifyForemostExpectedDiscounts',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/ForemostHomeSpecialtyDwellingQuoteScenarioTests.java',
      sourceLine: 17,
      className: 'ForemostHomeSpecialtyDwellingQuoteScenarioTests',
      method: 'verifyForemostExpectedDiscounts',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES)}, groups = {SPECIALTY_DWELLING})',
    });
  });
});
