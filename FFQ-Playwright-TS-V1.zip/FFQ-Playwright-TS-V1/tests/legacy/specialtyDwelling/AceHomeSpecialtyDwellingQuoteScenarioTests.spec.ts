// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingQuoteScenarioTests', () => {
  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingQuoteScenarioTests#verifyExpectedDiscounts
  test('verifyExpectedDiscounts', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingQuoteScenarioTests#verifyExpectedDiscounts',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingQuoteScenarioTests.java',
      sourceLine: 17,
      className: 'AceHomeSpecialtyDwellingQuoteScenarioTests',
      method: 'verifyExpectedDiscounts',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES)}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingQuoteScenarioTests#domehomeKnockoutPageVerification
  test('domehomeKnockoutPageVerification', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingQuoteScenarioTests#domehomeKnockoutPageVerification',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingQuoteScenarioTests.java',
      sourceLine: 24,
      className: 'AceHomeSpecialtyDwellingQuoteScenarioTests',
      method: 'domehomeKnockoutPageVerification',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.RANDOM_MOBILEHOME_APPLICANT',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingQuoteScenarioTests#otherAsNumberOfUnitsKnockoutPageVerification
  test('otherAsNumberOfUnitsKnockoutPageVerification', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingQuoteScenarioTests#otherAsNumberOfUnitsKnockoutPageVerification',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingQuoteScenarioTests.java',
      sourceLine: 33,
      className: 'AceHomeSpecialtyDwellingQuoteScenarioTests',
      method: 'otherAsNumberOfUnitsKnockoutPageVerification',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.RANDOM_MOBILEHOME_APPLICANT',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingQuoteScenarioTests#noSmokeDetectorKnockoutPageVerification
  test('noSmokeDetectorKnockoutPageVerification', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingQuoteScenarioTests#noSmokeDetectorKnockoutPageVerification',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingQuoteScenarioTests.java',
      sourceLine: 42,
      className: 'AceHomeSpecialtyDwellingQuoteScenarioTests',
      method: 'noSmokeDetectorKnockoutPageVerification',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.RANDOM_MOBILEHOME_APPLICANT',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingQuoteScenarioTests#woodShakeRoofKnockoutPageVerification
  test('woodShakeRoofKnockoutPageVerification', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingQuoteScenarioTests#woodShakeRoofKnockoutPageVerification',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingQuoteScenarioTests.java',
      sourceLine: 51,
      className: 'AceHomeSpecialtyDwellingQuoteScenarioTests',
      method: 'woodShakeRoofKnockoutPageVerification',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.RANDOM_MOBILEHOME_APPLICANT',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {SPECIALTY_DWELLING})',
    });
  });
});
