// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.api.TestServiceCalls", () => {
  // legacy-id: com.farmers.ffq.api.TestServiceCalls#serviceCallTest
  test.skip("serviceCallTest", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.api.TestServiceCalls#serviceCallTest","domain":"api","sourceFile":"src/test/java/com/farmers/ffq/api/TestServiceCalls.java","sourceLine":37,"className":"TestServiceCalls","method":"serviceCallTest","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"{REGRESSION, SPOT_TESTING, AUTO_REDESIGN}","annotation":"@Test(groups = {REGRESSION, SPOT_TESTING, AUTO_REDESIGN})"});
  });

});
