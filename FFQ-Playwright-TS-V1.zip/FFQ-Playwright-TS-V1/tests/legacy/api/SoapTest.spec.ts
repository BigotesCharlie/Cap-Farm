// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.api.SoapTest", () => {
  // legacy-id: com.farmers.ffq.api.SoapTest#existingCustomer
  test.skip("existingCustomer", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.api.SoapTest#existingCustomer","domain":"api","sourceFile":"src/test/java/com/farmers/ffq/api/SoapTest.java","sourceLine":41,"className":"SoapTest","method":"existingCustomer","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"\"smoke\"","annotation":"@Test(groups = \"smoke\")"});
  });

  // legacy-id: com.farmers.ffq.api.SoapTest#propertyRiskAnalysis
  test.skip("propertyRiskAnalysis", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.api.SoapTest#propertyRiskAnalysis","domain":"api","sourceFile":"src/test/java/com/farmers/ffq/api/SoapTest.java","sourceLine":66,"className":"SoapTest","method":"propertyRiskAnalysis","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"\"smoke\"","annotation":"@Test(groups = \"smoke\")"});
  });

  // legacy-id: com.farmers.ffq.api.SoapTest#agentAssignment
  test.skip("agentAssignment", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.api.SoapTest#agentAssignment","domain":"api","sourceFile":"src/test/java/com/farmers/ffq/api/SoapTest.java","sourceLine":87,"className":"SoapTest","method":"agentAssignment","parameters":"","dataProvider":"","dataProviderClass":"","testName":"","groups":"\"smoke\"","annotation":"@Test(groups = \"smoke\")"});
  });

});
