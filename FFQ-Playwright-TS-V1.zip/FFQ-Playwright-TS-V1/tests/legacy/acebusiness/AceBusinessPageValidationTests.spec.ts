// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acebusiness.AceBusinessPageValidationTests", () => {
  // legacy-id: com.farmers.ffq.acebusiness.AceBusinessPageValidationTests#verifyBusinessLeadFormContent
  test("verifyBusinessLeadFormContent", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acebusiness.AceBusinessPageValidationTests#verifyBusinessLeadFormContent","domain":"acebusiness","sourceFile":"src/test/java/com/farmers/ffq/acebusiness/AceBusinessPageValidationTests.java","sourceLine":18,"className":"AceBusinessPageValidationTests","method":"verifyBusinessLeadFormContent","parameters":"ApplicantBusiness businessApplicant","dataProvider":"DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"LOB_BUSINESS","groups":"REGRESSION","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER, testName = LOB_BUSINESS, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = REGRESSION)"});
  });

  // legacy-id: com.farmers.ffq.acebusiness.AceBusinessPageValidationTests#validateBusinessLeadFormErrorHandling
  test("validateBusinessLeadFormErrorHandling", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acebusiness.AceBusinessPageValidationTests#validateBusinessLeadFormErrorHandling","domain":"acebusiness","sourceFile":"src/test/java/com/farmers/ffq/acebusiness/AceBusinessPageValidationTests.java","sourceLine":29,"className":"AceBusinessPageValidationTests","method":"validateBusinessLeadFormErrorHandling","parameters":"ApplicantBusiness businessApplicant","dataProvider":"DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"LOB_BUSINESS","groups":"REGRESSION","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER, testName = LOB_BUSINESS, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = REGRESSION)"});
  });

});
