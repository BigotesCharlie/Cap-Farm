// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acebusiness.AceBusinessQuoteScenarioTests", () => {
  // legacy-id: com.farmers.ffq.acebusiness.AceBusinessQuoteScenarioTests#verifyStateSupportForBusiness
  test("verifyStateSupportForBusiness", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acebusiness.AceBusinessQuoteScenarioTests#verifyStateSupportForBusiness","domain":"acebusiness","sourceFile":"src/test/java/com/farmers/ffq/acebusiness/AceBusinessQuoteScenarioTests.java","sourceLine":32,"className":"AceBusinessQuoteScenarioTests","method":"verifyStateSupportForBusiness","parameters":"State state","dataProvider":"SqlDataProviders.STATES_DATA_PROVIDER_NAME","dataProviderClass":"SqlDataProviders.class","testName":"","groups":"REGRESSION","annotation":"@Test(dataProviderClass = SqlDataProviders.class, dataProvider = SqlDataProviders.STATES_DATA_PROVIDER_NAME, groups = REGRESSION)"});
  });

  // legacy-id: com.farmers.ffq.acebusiness.AceBusinessQuoteScenarioTests#aceBusinessPEWCScreen
  test("aceBusinessPEWCScreen", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acebusiness.AceBusinessQuoteScenarioTests#aceBusinessPEWCScreen","domain":"acebusiness","sourceFile":"src/test/java/com/farmers/ffq/acebusiness/AceBusinessQuoteScenarioTests.java","sourceLine":69,"className":"AceBusinessQuoteScenarioTests","method":"aceBusinessPEWCScreen","parameters":"ApplicantBusiness businessApplicant","dataProvider":"DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"PEWC","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = PEWC)"});
  });

  // legacy-id: com.farmers.ffq.acebusiness.AceBusinessQuoteScenarioTests#createDefaultBusinessLead
  test("createDefaultBusinessLead", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acebusiness.AceBusinessQuoteScenarioTests#createDefaultBusinessLead","domain":"acebusiness","sourceFile":"src/test/java/com/farmers/ffq/acebusiness/AceBusinessQuoteScenarioTests.java","sourceLine":76,"className":"AceBusinessQuoteScenarioTests","method":"createDefaultBusinessLead","parameters":"ApplicantBusiness businessApplicant","dataProvider":"DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"REGRESSION","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = REGRESSION)"});
  });

  // legacy-id: com.farmers.ffq.acebusiness.AceBusinessQuoteScenarioTests#createBusinessLeadAllPolicyTypes
  test("createBusinessLeadAllPolicyTypes", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acebusiness.AceBusinessQuoteScenarioTests#createBusinessLeadAllPolicyTypes","domain":"acebusiness","sourceFile":"src/test/java/com/farmers/ffq/acebusiness/AceBusinessQuoteScenarioTests.java","sourceLine":89,"className":"AceBusinessQuoteScenarioTests","method":"createBusinessLeadAllPolicyTypes","parameters":"ApplicantBusiness businessApplicant","dataProvider":"DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"REGRESSION","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = REGRESSION)"});
  });

  // legacy-id: com.farmers.ffq.acebusiness.AceBusinessQuoteScenarioTests#createBusinessLeadWithRandomSelections
  test("createBusinessLeadWithRandomSelections", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acebusiness.AceBusinessQuoteScenarioTests#createBusinessLeadWithRandomSelections","domain":"acebusiness","sourceFile":"src/test/java/com/farmers/ffq/acebusiness/AceBusinessQuoteScenarioTests.java","sourceLine":96,"className":"AceBusinessQuoteScenarioTests","method":"createBusinessLeadWithRandomSelections","parameters":"ApplicantBusiness businessApplicant","dataProvider":"DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{REGRESSION, ADA_SUITE, BUSINESS_ADA_SUITE}","annotation":"@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = {REGRESSION, ADA_SUITE, BUSINESS_ADA_SUITE})"});
  });

  // legacy-id: com.farmers.ffq.acebusiness.AceBusinessQuoteScenarioTests#productionValidationBusinessQuote
  test("productionValidationBusinessQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acebusiness.AceBusinessQuoteScenarioTests#productionValidationBusinessQuote","domain":"acebusiness","sourceFile":"src/test/java/com/farmers/ffq/acebusiness/AceBusinessQuoteScenarioTests.java","sourceLine":106,"className":"AceBusinessQuoteScenarioTests","method":"productionValidationBusinessQuote","parameters":"ApplicantBusiness businessApplicant","dataProvider":"DataProviders.PRODUCTION_TEST_BUSINESS_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"PRODUCTION_VALIDATION","annotation":"@Test( dataProviderClass = DataProviders.class, dataProvider = DataProviders.PRODUCTION_TEST_BUSINESS_APPLICANT_DATA_PROVIDER, groups = PRODUCTION_VALIDATION)"});
  });

});
