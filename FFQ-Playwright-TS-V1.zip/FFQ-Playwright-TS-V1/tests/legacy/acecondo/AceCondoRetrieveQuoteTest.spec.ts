// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoRetrieveQuoteTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoRetrieveQuoteTest#testRetrieveNonRatedQuoteCondo
  test("testRetrieveNonRatedQuoteCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoRetrieveQuoteTest#testRetrieveNonRatedQuoteCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoRetrieveQuoteTest.java","sourceLine":23,"className":"AceCondoRetrieveQuoteTest","method":"testRetrieveNonRatedQuoteCondo","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_RETRIEVE_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoRetrieveQuoteTest#testRetrieveRatedQuoteCondo
  test("testRetrieveRatedQuoteCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoRetrieveQuoteTest#testRetrieveRatedQuoteCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoRetrieveQuoteTest.java","sourceLine":98,"className":"AceCondoRetrieveQuoteTest","method":"testRetrieveRatedQuoteCondo","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_RETRIEVE_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoRetrieveQuoteTest#testRetrieveRatedQuoteFromJFMTPageCondo
  test("testRetrieveRatedQuoteFromJFMTPageCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoRetrieveQuoteTest#testRetrieveRatedQuoteFromJFMTPageCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoRetrieveQuoteTest.java","sourceLine":194,"className":"AceCondoRetrieveQuoteTest","method":"testRetrieveRatedQuoteFromJFMTPageCondo","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_RETRIEVE_FLOW})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoRetrieveQuoteTest#testRetrieveRatedQuoteFromPaymentPageCondoLob
  test("testRetrieveRatedQuoteFromPaymentPageCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoRetrieveQuoteTest#testRetrieveRatedQuoteFromPaymentPageCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoRetrieveQuoteTest.java","sourceLine":229,"className":"AceCondoRetrieveQuoteTest","method":"testRetrieveRatedQuoteFromPaymentPageCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_RETRIEVE_FLOW}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_RETRIEVE_FLOW})"});
  });

});
