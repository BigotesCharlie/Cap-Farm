// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoAboutYouPageTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoAboutYouPageTest#pageContentValidationAboutYouPageCondoLob
  test.skip("pageContentValidationAboutYouPageCondoLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAboutYouPageTest#pageContentValidationAboutYouPageCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAboutYouPageTest.java","sourceLine":24,"className":"AceCondoAboutYouPageTest","method":"pageContentValidationAboutYouPageCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,LA,MA,MS,MT,NC,TX,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ABOUT_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoAboutYouPageTest#validateErrorMessagesAboutYouPageCondoLob
  test.skip("validateErrorMessagesAboutYouPageCondoLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAboutYouPageTest#validateErrorMessagesAboutYouPageCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAboutYouPageTest.java","sourceLine":69,"className":"AceCondoAboutYouPageTest","method":"validateErrorMessagesAboutYouPageCondoLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,LA,MA,MS,MT,NC,TX,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ABOUT_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoAboutYouPageTest#enteredDetailsRetainedWhenNavigatedBackAndForthAboutYouPageCondoLob
  test.skip("enteredDetailsRetainedWhenNavigatedBackAndForthAboutYouPageCondoLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAboutYouPageTest#enteredDetailsRetainedWhenNavigatedBackAndForthAboutYouPageCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAboutYouPageTest.java","sourceLine":153,"className":"AceCondoAboutYouPageTest","method":"enteredDetailsRetainedWhenNavigatedBackAndForthAboutYouPageCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,LA,MA,MS,MT,NC,TX,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ABOUT_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoAboutYouPageTest#testDataNotSavedWhenNavigatedBackAboutYouPageCondoLob
  test.skip("testDataNotSavedWhenNavigatedBackAboutYouPageCondoLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAboutYouPageTest#testDataNotSavedWhenNavigatedBackAboutYouPageCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAboutYouPageTest.java","sourceLine":183,"className":"AceCondoAboutYouPageTest","method":"testDataNotSavedWhenNavigatedBackAboutYouPageCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,LA,MA,MS,MT,NC,TX,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ABOUT_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoAboutYouPageTest#validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageCondoLob
  test.skip("validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageCondoLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAboutYouPageTest#validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAboutYouPageTest.java","sourceLine":206,"className":"AceCondoAboutYouPageTest","method":"validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_ABOUT_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,LA,MA,MS,MT,NC,TX,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ABOUT_YOU_PAGE})"});
  });

});
