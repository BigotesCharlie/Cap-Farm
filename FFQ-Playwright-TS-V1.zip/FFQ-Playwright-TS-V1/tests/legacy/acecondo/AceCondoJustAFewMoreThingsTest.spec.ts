// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testValidateContentOfJustFewMoreThingsPageCondoLob
  test("testValidateContentOfJustFewMoreThingsPageCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testValidateContentOfJustFewMoreThingsPageCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoJustAFewMoreThingsTest.java","sourceLine":25,"className":"AceCondoJustAFewMoreThingsTest","method":"testValidateContentOfJustFewMoreThingsPageCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_JAFMT_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_JAFMT_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testBusinessOperatedOnPremisesKnockOutScreenCondoLob
  test("testBusinessOperatedOnPremisesKnockOutScreenCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testBusinessOperatedOnPremisesKnockOutScreenCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoJustAFewMoreThingsTest.java","sourceLine":47,"className":"AceCondoJustAFewMoreThingsTest","method":"testBusinessOperatedOnPremisesKnockOutScreenCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testPetWithBiteHistoryKnockOutScreenCondoLob
  test("testPetWithBiteHistoryKnockOutScreenCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testPetWithBiteHistoryKnockOutScreenCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoJustAFewMoreThingsTest.java","sourceLine":61,"className":"AceCondoJustAFewMoreThingsTest","method":"testPetWithBiteHistoryKnockOutScreenCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testKnockOutScreenWhenAllOtherQuestionsAreSelectedCondoLob
  test("testKnockOutScreenWhenAllOtherQuestionsAreSelectedCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testKnockOutScreenWhenAllOtherQuestionsAreSelectedCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoJustAFewMoreThingsTest.java","sourceLine":75,"className":"AceCondoJustAFewMoreThingsTest","method":"testKnockOutScreenWhenAllOtherQuestionsAreSelectedCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO,FFQ_ACE_CONDO_JAFMT_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO,FFQ_ACE_CONDO_JAFMT_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testHOACoversWallsInKnockOutScreenCondoLob
  test("testHOACoversWallsInKnockOutScreenCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testHOACoversWallsInKnockOutScreenCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoJustAFewMoreThingsTest.java","sourceLine":89,"className":"AceCondoJustAFewMoreThingsTest","method":"testHOACoversWallsInKnockOutScreenCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testContinueToBindWhenCantFindLenderSelectedCondoLob
  test("testContinueToBindWhenCantFindLenderSelectedCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testContinueToBindWhenCantFindLenderSelectedCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoJustAFewMoreThingsTest.java","sourceLine":103,"className":"AceCondoJustAFewMoreThingsTest","method":"testContinueToBindWhenCantFindLenderSelectedCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO,attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testJFMTPageBackAndForthNavigationCondoLob
  test("testJFMTPageBackAndForthNavigationCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoJustAFewMoreThingsTest#testJFMTPageBackAndForthNavigationCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoJustAFewMoreThingsTest.java","sourceLine":113,"className":"AceCondoJustAFewMoreThingsTest","method":"testJFMTPageBackAndForthNavigationCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE})"});
  });

});
