// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoEndToEndTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoEndToEndTest#testReviewQuotePagePresentmentCardCondo
  test("testReviewQuotePagePresentmentCardCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoEndToEndTest#testReviewQuotePagePresentmentCardCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoEndToEndTest.java","sourceLine":22,"className":"AceCondoEndToEndTest","method":"testReviewQuotePagePresentmentCardCondo","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoEndToEndTest#testSmokeReviewQuotePagePresentmentCardCondo
  test("testSmokeReviewQuotePagePresentmentCardCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoEndToEndTest#testSmokeReviewQuotePagePresentmentCardCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoEndToEndTest.java","sourceLine":42,"className":"AceCondoEndToEndTest","method":"testSmokeReviewQuotePagePresentmentCardCondo","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{ACE_HOME_SMOKE, ACE_CONDO_ADA_SUITE, ADA_SUITE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {ACE_HOME_SMOKE, ACE_CONDO_ADA_SUITE, ADA_SUITE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoEndToEndTest#testProdRetrieveRatedQuoteAceCondo
  test("testProdRetrieveRatedQuoteAceCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoEndToEndTest#testProdRetrieveRatedQuoteAceCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoEndToEndTest.java","sourceLine":56,"className":"AceCondoEndToEndTest","method":"testProdRetrieveRatedQuoteAceCondo","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{PRODUCTION_VALIDATION}","annotation":"@Test(dataProvider = AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,TX})}, groups = {PRODUCTION_VALIDATION})"});
  });

});
