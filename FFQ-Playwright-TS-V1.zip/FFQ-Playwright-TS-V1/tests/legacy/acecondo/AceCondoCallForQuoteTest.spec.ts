// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoCallForQuoteTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoCallForQuoteTest#testCallForQuoteToAceReviewQuoteCondoLob
  test.skip("testCallForQuoteToAceReviewQuoteCondoLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoCallForQuoteTest#testCallForQuoteToAceReviewQuoteCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoCallForQuoteTest.java","sourceLine":28,"className":"AceCondoCallForQuoteTest","method":"testCallForQuoteToAceReviewQuoteCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, AL, GA, IL, OH, VA})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE})"});
  });

});
