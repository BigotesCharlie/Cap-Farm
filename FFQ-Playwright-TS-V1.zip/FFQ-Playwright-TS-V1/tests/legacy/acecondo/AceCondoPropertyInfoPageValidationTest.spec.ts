// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoPropertyInfoPageValidationTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoPropertyInfoPageValidationTest#testPropertyInfoPageCondo
  test("testPropertyInfoPageCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoPropertyInfoPageValidationTest#testPropertyInfoPageCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoPropertyInfoPageValidationTest.java","sourceLine":16,"className":"AceCondoPropertyInfoPageValidationTest","method":"testPropertyInfoPageCondo","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, OH, OR, TX, UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoPropertyInfoPageValidationTest#testPropertyInfoPageErrorMessageCondo
  test("testPropertyInfoPageErrorMessageCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoPropertyInfoPageValidationTest#testPropertyInfoPageErrorMessageCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoPropertyInfoPageValidationTest.java","sourceLine":29,"className":"AceCondoPropertyInfoPageValidationTest","method":"testPropertyInfoPageErrorMessageCondo","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, OH, OR, TX, UT})}, groups = {FFQ_ACE_CONDO})"});
  });

});
