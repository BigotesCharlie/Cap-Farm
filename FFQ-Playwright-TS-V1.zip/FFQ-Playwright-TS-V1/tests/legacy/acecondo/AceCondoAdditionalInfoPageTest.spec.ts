// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoAdditionalInfoPageTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoAdditionalInfoPageTest#validateAdditionalInfoPageContentCondoLob
  test("validateAdditionalInfoPageContentCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAdditionalInfoPageTest#validateAdditionalInfoPageContentCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAdditionalInfoPageTest.java","sourceLine":22,"className":"AceCondoAdditionalInfoPageTest","method":"validateAdditionalInfoPageContentCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ADDITIONAL_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ADDITIONAL_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoAdditionalInfoPageTest#validateFloorResidenceLocatedCondoLob
  test("validateFloorResidenceLocatedCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAdditionalInfoPageTest#validateFloorResidenceLocatedCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAdditionalInfoPageTest.java","sourceLine":79,"className":"AceCondoAdditionalInfoPageTest","method":"validateFloorResidenceLocatedCondoLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDITIONAL_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDITIONAL_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoAdditionalInfoPageTest#validateDataWhenNavigatedBackAndFrothToAdditionalInfoPageCondoLob
  test("validateDataWhenNavigatedBackAndFrothToAdditionalInfoPageCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAdditionalInfoPageTest#validateDataWhenNavigatedBackAndFrothToAdditionalInfoPageCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAdditionalInfoPageTest.java","sourceLine":92,"className":"AceCondoAdditionalInfoPageTest","method":"validateDataWhenNavigatedBackAndFrothToAdditionalInfoPageCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDITIONAL_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDITIONAL_INFO_PAGE})"});
  });

});
