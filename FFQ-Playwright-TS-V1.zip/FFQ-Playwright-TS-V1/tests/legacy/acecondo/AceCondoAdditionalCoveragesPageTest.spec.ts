// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoAdditionalCoveragesPageTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoAdditionalCoveragesPageTest#testAdditionalCoveragesPageQuotePresentmentCardCondo
  test("testAdditionalCoveragesPageQuotePresentmentCardCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAdditionalCoveragesPageTest#testAdditionalCoveragesPageQuotePresentmentCardCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAdditionalCoveragesPageTest.java","sourceLine":17,"className":"AceCondoAdditionalCoveragesPageTest","method":"testAdditionalCoveragesPageQuotePresentmentCardCondo","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ADDITIONAL_COVERAGES_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ADDITIONAL_COVERAGES_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoAdditionalCoveragesPageTest#testAdditionalCoveragesPageTogglesValidationCondo
  test("testAdditionalCoveragesPageTogglesValidationCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAdditionalCoveragesPageTest#testAdditionalCoveragesPageTogglesValidationCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAdditionalCoveragesPageTest.java","sourceLine":41,"className":"AceCondoAdditionalCoveragesPageTest","method":"testAdditionalCoveragesPageTogglesValidationCondo","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDITIONAL_COVERAGES_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDITIONAL_COVERAGES_PAGE})"});
  });

});
