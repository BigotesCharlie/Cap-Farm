// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoAddressPageValidationTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoAddressPageValidationTest#testAddressPageCondoLob
  test.skip("testAddressPageCondoLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAddressPageValidationTest#testAddressPageCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAddressPageValidationTest.java","sourceLine":21,"className":"AceCondoAddressPageValidationTest","method":"testAddressPageCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ADDRESS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoAddressPageValidationTest#testAddressPageTwoOrMorePropertyClaimsInLastThreeYearsCondoLob
  test.skip("testAddressPageTwoOrMorePropertyClaimsInLastThreeYearsCondoLob", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAddressPageValidationTest#testAddressPageTwoOrMorePropertyClaimsInLastThreeYearsCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAddressPageValidationTest.java","sourceLine":60,"className":"AceCondoAddressPageValidationTest","method":"testAddressPageTwoOrMorePropertyClaimsInLastThreeYearsCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,LA,MA,MS,MT,NC,TX,UT})}, groups = {FFQ_ACE_CONDO})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoAddressPageValidationTest#testFGIANotOfferingValidationCondoLob
  test("testFGIANotOfferingValidationCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAddressPageValidationTest#testFGIANotOfferingValidationCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAddressPageValidationTest.java","sourceLine":73,"className":"AceCondoAddressPageValidationTest","method":"testFGIANotOfferingValidationCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA, NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoAddressPageValidationTest#testFGIALandingPageValidationCondoLob
  test("testFGIALandingPageValidationCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAddressPageValidationTest#testFGIALandingPageValidationCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAddressPageValidationTest.java","sourceLine":90,"className":"AceCondoAddressPageValidationTest","method":"testFGIALandingPageValidationCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {LA, MA, NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoAddressPageValidationTest#testDigitalMonetizationValidationNonAWSCondoLob
  test("testDigitalMonetizationValidationNonAWSCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAddressPageValidationTest#testDigitalMonetizationValidationNonAWSCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAddressPageValidationTest.java","sourceLine":116,"className":"AceCondoAddressPageValidationTest","method":"testDigitalMonetizationValidationNonAWSCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_DIGITAL_MONETIZATION_NON_AWS, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {ME, MS, NH, NJ, NY, VT, WV})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoAddressPageValidationTest#testDigitalMonetizationValidationAWSCondoLob
  test("testDigitalMonetizationValidationAWSCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoAddressPageValidationTest#testDigitalMonetizationValidationAWSCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoAddressPageValidationTest.java","sourceLine":136,"className":"AceCondoAddressPageValidationTest","method":"testDigitalMonetizationValidationAWSCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_DIGITAL_MONETIZATION_AWS, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {NJ, NY})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE})"});
  });

});
