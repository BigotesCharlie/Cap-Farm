// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoThankYouTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoThankYouTest#validateContentOfThankYouPageCondoLob
  test("validateContentOfThankYouPageCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoThankYouTest#validateContentOfThankYouPageCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoThankYouTest.java","sourceLine":22,"className":"AceCondoThankYouTest","method":"validateContentOfThankYouPageCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_THANK_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_THANK_YOU_SCREEN_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_THANK_YOU_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoThankYouTest#testValidateThankYouPageCannotGoBindCondoLob
  test("testValidateThankYouPageCannotGoBindCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoThankYouTest#testValidateThankYouPageCannotGoBindCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoThankYouTest.java","sourceLine":53,"className":"AceCondoThankYouTest","method":"testValidateThankYouPageCannotGoBindCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_THANK_YOU_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_THANK_YOU_SCREEN_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_THANK_YOU_PAGE})"});
  });

});
