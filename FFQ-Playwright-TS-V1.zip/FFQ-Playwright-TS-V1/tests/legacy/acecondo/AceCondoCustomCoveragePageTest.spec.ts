// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoCustomCoveragePageTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoCustomCoveragePageTest#customCoveragePageContentValidationCondoLob
  test("customCoveragePageContentValidationCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoCustomCoveragePageTest#customCoveragePageContentValidationCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoCustomCoveragePageTest.java","sourceLine":19,"className":"AceCondoCustomCoveragePageTest","method":"customCoveragePageContentValidationCondoLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_CUSTOM_COVERAGE_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_CUSTOM_COVERAGE_PAGE})"});
  });

});
