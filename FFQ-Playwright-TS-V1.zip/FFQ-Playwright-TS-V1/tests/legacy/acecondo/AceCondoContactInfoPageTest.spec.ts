// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoContactInfoPageTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#validateContactInfoPageCondoLob
  test("validateContactInfoPageCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#validateContactInfoPageCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoContactInfoPageTest.java","sourceLine":20,"className":"AceCondoContactInfoPageTest","method":"validateContactInfoPageCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#validateContactInfoPageErrorMessagesCondoLob
  test("validateContactInfoPageErrorMessagesCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#validateContactInfoPageErrorMessagesCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoContactInfoPageTest.java","sourceLine":47,"className":"AceCondoContactInfoPageTest","method":"validateContactInfoPageErrorMessagesCondoLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#validateEarlyShoppingDiscountFunctionalityCondoLob
  test("validateEarlyShoppingDiscountFunctionalityCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#validateEarlyShoppingDiscountFunctionalityCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoContactInfoPageTest.java","sourceLine":56,"className":"AceCondoContactInfoPageTest","method":"validateEarlyShoppingDiscountFunctionalityCondoLob","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#aceCondoPEWCScreen
  test.skip("aceCondoPEWCScreen", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#aceCondoPEWCScreen","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoContactInfoPageTest.java","sourceLine":66,"className":"AceCondoContactInfoPageTest","method":"aceCondoPEWCScreen","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"RANDOM_ROW","groups":"{PEWC}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC,AZ,OH,OR,TX,UT})}, groups = {PEWC})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#validateFWSInterstitialToBindableChoiceIntegrationCondo
  test.skip("validateFWSInterstitialToBindableChoiceIntegrationCondo", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#validateFWSInterstitialToBindableChoiceIntegrationCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoContactInfoPageTest.java","sourceLine":75,"className":"AceCondoContactInfoPageTest","method":"validateFWSInterstitialToBindableChoiceIntegrationCondo","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_BINDABLE_CHOICE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,LA,MA,MS,MT,NC,OH,OR,TX,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#validateFWSInterstitialColpPageCondo
  test.skip("validateFWSInterstitialColpPageCondo", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#validateFWSInterstitialColpPageCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoContactInfoPageTest.java","sourceLine":96,"className":"AceCondoContactInfoPageTest","method":"validateFWSInterstitialColpPageCondo","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_COLP, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,LA,MA,MS,MT,NC,OH,OR,TX,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CONTACT_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#validateFWSInterstitialQnBPageCondo
  test.skip("validateFWSInterstitialQnBPageCondo", async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoContactInfoPageTest#validateFWSInterstitialQnBPageCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoContactInfoPageTest.java","sourceLine":114,"className":"AceCondoContactInfoPageTest","method":"validateFWSInterstitialQnBPageCondo","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CONTACT_INFO_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_QNB, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,LA,MA,MS,MT,NC,OH,OR,TX,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CONTACT_INFO_PAGE})"});
  });

});
