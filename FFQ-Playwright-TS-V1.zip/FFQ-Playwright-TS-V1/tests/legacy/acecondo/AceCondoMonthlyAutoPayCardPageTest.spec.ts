// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayCardPageTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayCardPageTest#testValidateContentOfMonthlyAutoPayCardPageOnLandingAceCondo
  test("testValidateContentOfMonthlyAutoPayCardPageOnLandingAceCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayCardPageTest#testValidateContentOfMonthlyAutoPayCardPageOnLandingAceCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoMonthlyAutoPayCardPageTest.java","sourceLine":17,"className":"AceCondoMonthlyAutoPayCardPageTest","method":"testValidateContentOfMonthlyAutoPayCardPageOnLandingAceCondo","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_CARD_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_CARD_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayCardPageTest#testMonthlyAutoPayCardCreditCardPaymentEndToEndAceCondo
  test("testMonthlyAutoPayCardCreditCardPaymentEndToEndAceCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayCardPageTest#testMonthlyAutoPayCardCreditCardPaymentEndToEndAceCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoMonthlyAutoPayCardPageTest.java","sourceLine":32,"className":"AceCondoMonthlyAutoPayCardPageTest","method":"testMonthlyAutoPayCardCreditCardPaymentEndToEndAceCondo","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_CARD_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_CARD_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayCardPageTest#testMonthlyAutoPayCardBankPaymentEndToEndAceCondo
  test("testMonthlyAutoPayCardBankPaymentEndToEndAceCondo", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayCardPageTest#testMonthlyAutoPayCardBankPaymentEndToEndAceCondo","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoMonthlyAutoPayCardPageTest.java","sourceLine":53,"className":"AceCondoMonthlyAutoPayCardPageTest","method":"testMonthlyAutoPayCardBankPaymentEndToEndAceCondo","parameters":"ApplicantAceHome applicantAceHome","dataProvider":"AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_CARD_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_CARD_PAGE})"});
  });

});
