// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acecondo.AceCondoGoToPaymentSectionTest", () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoGoToPaymentSectionTest#testQuoteAndBindCondoLob
  test("testQuoteAndBindCondoLob", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acecondo.AceCondoGoToPaymentSectionTest#testQuoteAndBindCondoLob","domain":"acecondo","sourceFile":"src/test/java/com/farmers/ffq/acecondo/AceCondoGoToPaymentSectionTest.java","sourceLine":16,"className":"AceCondoGoToPaymentSectionTest","method":"testQuoteAndBindCondoLob","parameters":"ApplicantAceHome applicant","dataProvider":"AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER","dataProviderClass":"AceHomeDataProviders.class","testName":"","groups":"{ACE_STABILITY, FFQ_ACE_CONDO_PAYMENT_SELECTION_PAGE}","annotation":"@Test(dataProvider = AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {ACE_STABILITY, FFQ_ACE_CONDO_PAYMENT_SELECTION_PAGE})"});
  });

});
