// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acelife.name", () => {
  // legacy-id: com.farmers.ffq.acelife.name#aceLifeQuoteOlderThan70
  test("aceLifeQuoteOlderThan70", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.name#aceLifeQuoteOlderThan70","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java","sourceLine":24,"className":"name","method":"aceLifeQuoteOlderThan70","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{FFQ_ACE_LIFE}","annotation":"@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})"});
  });

  // legacy-id: com.farmers.ffq.acelife.name#aceLifeQuoteBetweenAgesOf66And70
  test("aceLifeQuoteBetweenAgesOf66And70", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.name#aceLifeQuoteBetweenAgesOf66And70","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java","sourceLine":30,"className":"name","method":"aceLifeQuoteBetweenAgesOf66And70","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{FFQ_ACE_LIFE}","annotation":"@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})"});
  });

  // legacy-id: com.farmers.ffq.acelife.name#aceLifeQuoteBetweenAgesOf51And65
  test("aceLifeQuoteBetweenAgesOf51And65", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.name#aceLifeQuoteBetweenAgesOf51And65","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java","sourceLine":36,"className":"name","method":"aceLifeQuoteBetweenAgesOf51And65","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{FFQ_ACE_LIFE}","annotation":"@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})"});
  });

  // legacy-id: com.farmers.ffq.acelife.name#aceLifeQuoteYoungerThan50
  test("aceLifeQuoteYoungerThan50", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.name#aceLifeQuoteYoungerThan50","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java","sourceLine":42,"className":"name","method":"aceLifeQuoteYoungerThan50","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{FFQ_ACE_LIFE}","annotation":"@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})"});
  });

  // legacy-id: com.farmers.ffq.acelife.name#aceLifeSaveAndRetrieveNameAndDOBPage
  test("aceLifeSaveAndRetrieveNameAndDOBPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.name#aceLifeSaveAndRetrieveNameAndDOBPage","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java","sourceLine":55,"className":"name","method":"aceLifeSaveAndRetrieveNameAndDOBPage","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{FFQ_ACE_LIFE}","annotation":"@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})"});
  });

  // legacy-id: com.farmers.ffq.acelife.name#aceLifeSaveAndRetrievePersonalInfoPage
  test("aceLifeSaveAndRetrievePersonalInfoPage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.name#aceLifeSaveAndRetrievePersonalInfoPage","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java","sourceLine":62,"className":"name","method":"aceLifeSaveAndRetrievePersonalInfoPage","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{FFQ_ACE_LIFE}","annotation":"@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})"});
  });

  // legacy-id: com.farmers.ffq.acelife.name#aceLifeSaveAndRetrieveReviewQuotePage
  test("aceLifeSaveAndRetrieveReviewQuotePage", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.name#aceLifeSaveAndRetrieveReviewQuotePage","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java","sourceLine":69,"className":"name","method":"aceLifeSaveAndRetrieveReviewQuotePage","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{FFQ_ACE_LIFE}","annotation":"@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})"});
  });

  // legacy-id: com.farmers.ffq.acelife.name#productionValidationAceLifeQuote
  test("productionValidationAceLifeQuote", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.name#productionValidationAceLifeQuote","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java","sourceLine":77,"className":"name","method":"productionValidationAceLifeQuote","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.PRODUCTION_TEST_LIFE_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"PRODUCTION_VALIDATION","annotation":"@Test(dataProvider = DataProviders.PRODUCTION_TEST_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = PRODUCTION_VALIDATION)"});
  });

  // legacy-id: com.farmers.ffq.acelife.name#aceLifeAdaTest
  test("aceLifeAdaTest", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.name#aceLifeAdaTest","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java","sourceLine":82,"className":"name","method":"aceLifeAdaTest","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{ADA_SUITE, LIFE_ADA_SUITE}","annotation":"@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {ADA_SUITE, LIFE_ADA_SUITE})"});
  });

});
