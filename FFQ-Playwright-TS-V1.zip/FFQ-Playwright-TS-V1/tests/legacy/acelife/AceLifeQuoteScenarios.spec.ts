// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.acelife.AceLifeQuoteScenarios', () => {
  // legacy-id: com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeQuoteOlderThan70
  test('aceLifeQuoteOlderThan70', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeQuoteOlderThan70',
      domain: 'acelife',
      sourceFile: 'src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java',
      sourceLine: 24,
      className: 'AceLifeQuoteScenarios',
      method: 'aceLifeQuoteOlderThan70',
      parameters: 'ApplicantLife applicant',
      dataProvider: 'DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_LIFE}',
      annotation:
        '@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})',
    });
  });

  // legacy-id: com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeQuoteBetweenAgesOf66And70
  test('aceLifeQuoteBetweenAgesOf66And70', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeQuoteBetweenAgesOf66And70',
      domain: 'acelife',
      sourceFile: 'src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java',
      sourceLine: 30,
      className: 'AceLifeQuoteScenarios',
      method: 'aceLifeQuoteBetweenAgesOf66And70',
      parameters: 'ApplicantLife applicant',
      dataProvider: 'DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_LIFE}',
      annotation:
        '@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})',
    });
  });

  // legacy-id: com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeQuoteBetweenAgesOf51And65
  test('aceLifeQuoteBetweenAgesOf51And65', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeQuoteBetweenAgesOf51And65',
      domain: 'acelife',
      sourceFile: 'src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java',
      sourceLine: 36,
      className: 'AceLifeQuoteScenarios',
      method: 'aceLifeQuoteBetweenAgesOf51And65',
      parameters: 'ApplicantLife applicant',
      dataProvider: 'DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_LIFE}',
      annotation:
        '@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})',
    });
  });

  // legacy-id: com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeQuoteYoungerThan50
  test('aceLifeQuoteYoungerThan50', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeQuoteYoungerThan50',
      domain: 'acelife',
      sourceFile: 'src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java',
      sourceLine: 42,
      className: 'AceLifeQuoteScenarios',
      method: 'aceLifeQuoteYoungerThan50',
      parameters: 'ApplicantLife applicant',
      dataProvider: 'DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_LIFE}',
      annotation:
        '@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})',
    });
  });

  // legacy-id: com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeSaveAndRetrieveNameAndDOBPage
  test('aceLifeSaveAndRetrieveNameAndDOBPage', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeSaveAndRetrieveNameAndDOBPage',
      domain: 'acelife',
      sourceFile: 'src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java',
      sourceLine: 55,
      className: 'AceLifeQuoteScenarios',
      method: 'aceLifeSaveAndRetrieveNameAndDOBPage',
      parameters: 'ApplicantLife applicant',
      dataProvider: 'DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_LIFE}',
      annotation:
        '@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})',
    });
  });

  // legacy-id: com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeSaveAndRetrievePersonalInfoPage
  test('aceLifeSaveAndRetrievePersonalInfoPage', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeSaveAndRetrievePersonalInfoPage',
      domain: 'acelife',
      sourceFile: 'src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java',
      sourceLine: 62,
      className: 'AceLifeQuoteScenarios',
      method: 'aceLifeSaveAndRetrievePersonalInfoPage',
      parameters: 'ApplicantLife applicant',
      dataProvider: 'DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_LIFE}',
      annotation:
        '@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})',
    });
  });

  // legacy-id: com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeSaveAndRetrieveReviewQuotePage
  test('aceLifeSaveAndRetrieveReviewQuotePage', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeSaveAndRetrieveReviewQuotePage',
      domain: 'acelife',
      sourceFile: 'src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java',
      sourceLine: 69,
      className: 'AceLifeQuoteScenarios',
      method: 'aceLifeSaveAndRetrieveReviewQuotePage',
      parameters: 'ApplicantLife applicant',
      dataProvider: 'DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_LIFE}',
      annotation:
        '@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})',
    });
  });

  // legacy-id: com.farmers.ffq.acelife.AceLifeQuoteScenarios#productionValidationAceLifeQuote
  test('productionValidationAceLifeQuote', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.acelife.AceLifeQuoteScenarios#productionValidationAceLifeQuote',
      domain: 'acelife',
      sourceFile: 'src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java',
      sourceLine: 77,
      className: 'AceLifeQuoteScenarios',
      method: 'productionValidationAceLifeQuote',
      parameters: 'ApplicantLife applicant',
      dataProvider: 'DataProviders.PRODUCTION_TEST_LIFE_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: '',
      groups: 'PRODUCTION_VALIDATION',
      annotation:
        '@Test(dataProvider = DataProviders.PRODUCTION_TEST_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = PRODUCTION_VALIDATION)',
    });
  });

  // legacy-id: com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeAdaTest
  test('aceLifeAdaTest', async ({ page, classicData }, testInfo) => {
    await executeMigratedScenario(page, testInfo, classicData, {
      legacyId: 'com.farmers.ffq.acelife.AceLifeQuoteScenarios#aceLifeAdaTest',
      domain: 'acelife',
      sourceFile: 'src/test/java/com/farmers/ffq/acelife/AceLifeQuoteScenarios.java',
      sourceLine: 82,
      className: 'AceLifeQuoteScenarios',
      method: 'aceLifeAdaTest',
      parameters: 'ApplicantLife applicant',
      dataProvider: 'DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: '',
      groups: '{ADA_SUITE, LIFE_ADA_SUITE}',
      annotation:
        '@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {ADA_SUITE, LIFE_ADA_SUITE})',
    });
  });
});
