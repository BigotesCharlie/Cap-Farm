// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acelife.AceLifeReviewQuotePageTests", () => {
  // legacy-id: com.farmers.ffq.acelife.AceLifeReviewQuotePageTests#aceLifeReviewQuotePageContentVerification
  test("aceLifeReviewQuotePageContentVerification", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.AceLifeReviewQuotePageTests#aceLifeReviewQuotePageContentVerification","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifeReviewQuotePageTests.java","sourceLine":21,"className":"AceLifeReviewQuotePageTests","method":"aceLifeReviewQuotePageContentVerification","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES","dataProviderClass":"DataProviders.class","testName":"","groups":"{FFQ_ACE_LIFE, ACE_LIFE_PERSONAL_INFO_PAGE}","annotation":"@Test(dataProvider = DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE, ACE_LIFE_PERSONAL_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acelife.AceLifeReviewQuotePageTests#aceLifeReviewQuoteStepperBackNavigationAndContinueForwardValidation
  test("aceLifeReviewQuoteStepperBackNavigationAndContinueForwardValidation", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.AceLifeReviewQuotePageTests#aceLifeReviewQuoteStepperBackNavigationAndContinueForwardValidation","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifeReviewQuotePageTests.java","sourceLine":36,"className":"AceLifeReviewQuotePageTests","method":"aceLifeReviewQuoteStepperBackNavigationAndContinueForwardValidation","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{FFQ_ACE_LIFE, ACE_LIFE_PERSONAL_INFO_PAGE}","annotation":"@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE, ACE_LIFE_PERSONAL_INFO_PAGE})"});
  });

});
