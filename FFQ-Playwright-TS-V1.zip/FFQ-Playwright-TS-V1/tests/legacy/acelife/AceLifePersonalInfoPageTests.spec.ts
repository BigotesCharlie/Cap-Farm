// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acelife.AceLifePersonalInfoPageTests", () => {
  // legacy-id: com.farmers.ffq.acelife.AceLifePersonalInfoPageTests#aceLifePersonalInfoPageContentVerification
  test("aceLifePersonalInfoPageContentVerification", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.AceLifePersonalInfoPageTests#aceLifePersonalInfoPageContentVerification","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifePersonalInfoPageTests.java","sourceLine":20,"className":"AceLifePersonalInfoPageTests","method":"aceLifePersonalInfoPageContentVerification","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES","dataProviderClass":"DataProviders.class","testName":"","groups":"{FFQ_ACE_LIFE, ACE_LIFE_PERSONAL_INFO_PAGE}","annotation":"@Test(dataProvider = DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE, ACE_LIFE_PERSONAL_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acelife.AceLifePersonalInfoPageTests#aceLifePersonalInfoPageErrorValidation
  test("aceLifePersonalInfoPageErrorValidation", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.AceLifePersonalInfoPageTests#aceLifePersonalInfoPageErrorValidation","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifePersonalInfoPageTests.java","sourceLine":34,"className":"AceLifePersonalInfoPageTests","method":"aceLifePersonalInfoPageErrorValidation","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES","dataProviderClass":"DataProviders.class","testName":"","groups":"{FFQ_ACE_LIFE, ACE_LIFE_PERSONAL_INFO_PAGE}","annotation":"@Test(dataProvider = DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE, ACE_LIFE_PERSONAL_INFO_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acelife.AceLifePersonalInfoPageTests#aceLifePEWCScreen
  test("aceLifePEWCScreen", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.AceLifePersonalInfoPageTests#aceLifePEWCScreen","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifePersonalInfoPageTests.java","sourceLine":42,"className":"AceLifePersonalInfoPageTests","method":"aceLifePEWCScreen","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER","dataProviderClass":"DataProviders.class","testName":"","groups":"{PEWC}","annotation":"@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {PEWC})"});
  });

});
