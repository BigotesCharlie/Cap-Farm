// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe("com.farmers.ffq.acelife.AceLifeNameAndDOBPageTests", () => {
  // legacy-id: com.farmers.ffq.acelife.AceLifeNameAndDOBPageTests#aceLifeNameAndDOBPageContentVerification
  test("aceLifeNameAndDOBPageContentVerification", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.AceLifeNameAndDOBPageTests#aceLifeNameAndDOBPageContentVerification","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifeNameAndDOBPageTests.java","sourceLine":18,"className":"AceLifeNameAndDOBPageTests","method":"aceLifeNameAndDOBPageContentVerification","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES","dataProviderClass":"DataProviders.class","testName":"","groups":"{FFQ_ACE_LIFE, ACE_LIFE_NAME_DOB_PAGE}","annotation":"@Test(dataProvider = DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE, ACE_LIFE_NAME_DOB_PAGE})"});
  });

  // legacy-id: com.farmers.ffq.acelife.AceLifeNameAndDOBPageTests#aceLifeNameAndDOBPageErrorValidation
  test("aceLifeNameAndDOBPageErrorValidation", async ({ page }, testInfo) => {
    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');
    await executeMigratedScenario(page, testInfo, {"legacyId":"com.farmers.ffq.acelife.AceLifeNameAndDOBPageTests#aceLifeNameAndDOBPageErrorValidation","domain":"acelife","sourceFile":"src/test/java/com/farmers/ffq/acelife/AceLifeNameAndDOBPageTests.java","sourceLine":32,"className":"AceLifeNameAndDOBPageTests","method":"aceLifeNameAndDOBPageErrorValidation","parameters":"ApplicantLife applicant","dataProvider":"DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES","dataProviderClass":"DataProviders.class","testName":"","groups":"{FFQ_ACE_LIFE, ACE_LIFE_NAME_DOB_PAGE}","annotation":"@Test(dataProvider = DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE, ACE_LIFE_NAME_DOB_PAGE})"});
  });

});
