import { test, expect } from '../../src/fixtures/test.js';
import { StartQuotePage } from '../../src/pages/auto/StartQuotePage.js';

test.describe('Playwright framework readiness', () => {
  test('Start Quote page loads', async ({ page }) => {
    const startQuotePage = new StartQuotePage(page);
    await startQuotePage.goto();
    await expect(page).toHaveURL(/fastquote/i);
  });
});
