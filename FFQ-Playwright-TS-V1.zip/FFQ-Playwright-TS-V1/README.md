# FFQ Playwright TypeScript: FFQ-Playwright-TS-V1

This project is a migration workspace for the Selenium/TestNG FFQ suite. It contains 2,941 unique Playwright test declarations. **Declaration parity does not mean that the UI scenarios are functional.** The merged V1 master contributed ten scenario-specific handlers, but no UI scenario is runtime certified in this release.

## What is executable now

- The 11 original Excel workbooks were converted to versioned JSON fixture catalogs: 122 sheets and 26,869 populated rows. No test reads an `.xlsx` file at runtime.
- Separate Playwright fixtures for `AceHomeDataProviders`, `AutoDataProviders`, `AceBundleDataProviders`, `SqlDataProviders`, `DataProviders`, and inline tests select rows using Java metadata, supported state lists, categories, filters, and stable per-test random selection. `referenceData` provides Nearmap addresses, coverages, and umbrella applicants. They are composed with `mergeTests`; see `src/fixtures/README.md`.
- The automatic `recoveryGuard` monitors Inconvenience, KnockOut, and TryAgain. On detection it attaches CopyDOM, screenshot, and context. It attempts at most two verified recovery actions; a terminal page never implies PASS. The merged HOME flows can also call `waitForStateWithRecovery` during long transitions.
- The automatic `healthCheck` fixture records browser errors and network failures (Sentinel). Its `step` method checks the recovery guard and attaches CopyDOM and a screenshot after each step. `verifyOutcome` requires a final assertion before PASS; `verifyTerminal` requires an explicit assertion for an expected break. Scenario handlers must actually call these methods. The generated scenarios do not yet do so.
- IDs containing `:` that originated in Java `@FindBy(id=...)` now use valid Playwright attribute locators. Other generated Page Objects still require DOM-based migration, particularly provisional `data-legacy-field` locators and XPath.
- Ten HOME/Auto handlers and the page/flow code from the merged V1 project are wired to the exact `SelectedCase` produced by the modular fixture. They no longer read workbooks or select another applicant internally. The merged catch-all handler was removed: an unknown scenario fails rather than receiving a misleading PASS after generic navigation.
- `npm run verify:structure` checks source IDs and metadata, all 2,941 provider-to-spec connections, catalog coordinates, TypeScript, fixture behavior regressions, and test discovery. `npm run verify` additionally checks HOME/AUTO selection and every catalog formula; it fails while those audits have unresolved items. Neither command runs FFQ UI scenarios. See `migration/MERGED_MASTER_INTEGRATION.md`.

## What still needs functional migration

The 2,941 specs retain their Java method contracts. Of these, 2,691 are enabled and 250 were disabled in Java. Ten scenarios have partial handlers; all ten still require functional debugging against FFQ, and the other enabled scenarios fail explicitly at the missing handler. Even if a partial handler returns, the executor fails because there is no runtime certification or verified complete assertion set. This prevents a false PASS.

Each scenario requires its own Playwright actions and assertions, reviewed against the original Java and executed against MA11 or RA11. The generated Page Objects include provisional `data-legacy-field` locators that require DOM verification. Do not add an ID to `certified-scenarios.json` before its full behavior and final assertions pass against FFQ. See `migration/MERGED_MASTER_INTEGRATION.md` for measured gaps and the handoff sequence.

One source array formula in `AutoDefaultCoveragesData/PA/P122` has a saved `#NAME?` result. The corresponding fixture fails when selected until its intended value is established.

## Commands

1. Use Node.js 22 or later, `npm ci`, and `npx playwright install chromium`.
2. Copy `.env.example` to `.env` and set the intended FFQ environment URL. Do not commit credentials.
3. Run `npm run verify` to check structure and data without opening FFQ; unresolved source/configuration problems produce a nonzero exit code. Use `npm run verify:structure` to inspect the structural checks separately.
4. `npm run verify:quality` checks formatting, lint, generated JavaScript, source parity, skip policy, fixture wiring, catalog, TypeScript, fixture behavior and Playwright discovery. `npm run verify` adds the known data readiness audits and remains red until their blockers are resolved.
5. `npm test` fails deliberately while no UI scenarios are certified, so an all-skipped suite cannot appear green. Enabled legacy declarations no longer have an environment-driven `test.skip`; they fail explicitly at the uncategorized fixture row or the missing behavioral handler. The 250 methods disabled in Java remain declaration-level skipped.
6. To inspect one generated scenario: `npm run test:diagnostic -- --grep 'scenarioMethodName' --headed`. This is a diagnostic failure, not a functional PASS.

## V1 PR #2 tooling integration

The review titled `chore(tooling): add quality checks and remove generated JavaScript` is reflected here with ESLint, Prettier, Node 22 pinning, Husky, lint-staged, Commitlint, a generated JavaScript guard, and CI quality checks. The reusable HOME and Auto data fixtures and their JSON catalogs remain in `src/fixtures/data/` and `src/data/catalog/`. See `migration/PR2_INTEGRATION.md` for exact coverage and open limitations.

The default local settings are headed Chromium, one worker, zero retries, and a ten-minute test timeout. Use the HTML report, trace, screenshot, and CopyDOM from a real run to migrate one scenario at a time.
