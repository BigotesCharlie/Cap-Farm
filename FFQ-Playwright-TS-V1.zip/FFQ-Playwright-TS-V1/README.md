# FFQ-Playwright-TS-V1

Playwright/TypeScript migration workspace for the legacy Java/TestNG Selenium framework.

## Test cases

- Original TestNG methods: **2,941**.
- Playwright declarations: **2,941** in **218** files under `tests/legacy`.
- Enabled: **2,691** `test()` declarations.
- Legacy-disabled: **250** `test.skip()` declarations.
- Cypress cases in the supplied source: **0**.

Every declaration includes a `legacy-id` comment and points to its original class/method contract. Run `npm run audit:parity` to prove that no source test is missing or duplicated.

## Local setup

1. Install Node.js 22 LTS and the official **Playwright Test for VSCode** extension.
2. Run `npm ci`.
3. Run `npx playwright install`.
4. Copy `.env.example` to `.env` and provide only the secrets required by the selected suite.
5. Open the repository root in VS Code. Each `test()` displays Run/Debug actions through the official extension.

`EXECUTE_MIGRATED_TESTS` defaults to `false` as a safety gate. Set it to `true` only for behaviorally certified suites in a configured FFQ environment. Uncertified handlers fail closed and cannot generate false PASS results.

## Commands

- `npm test`: Chromium suite.
- `npm run test:headed`: Chromium with a visible browser.
- `npm run test:debug`: Playwright Inspector.
- `npm run test:ui`: interactive UI mode.
- `npm run verify`: strict TypeScript validation and test discovery.

## Architecture

- `src/config`: validated environment configuration.
- `src/core`: shared browser primitives and the global recovery guard.
- `src/data`: parameterized data sources.
- `src/fixtures`: project-wide Playwright fixtures.
- `src/pages`: Page Objects with `Page` constructor injection and `Locator` fields.
- `tests`: executable Playwright specs.

Secrets must be supplied through `.env` locally or through the CI secret store. The repository does not contain credentials copied from the legacy project.
