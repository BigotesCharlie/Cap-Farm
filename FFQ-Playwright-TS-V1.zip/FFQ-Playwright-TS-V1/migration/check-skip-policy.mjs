import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';

async function specs(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  return (
    await Promise.all(
      entries.map((entry) => {
        const path = join(directory, entry.name);
        return entry.isDirectory() ? specs(path) : path.endsWith('.spec.ts') ? [path] : [];
      }),
    )
  ).flat();
}

const contracts = JSON.parse(await readFile(new URL('./audit/legacy-method-contracts.json', import.meta.url), 'utf8'));
const seen = new Set();
const problems = [];
let enabled = 0;
let disabled = 0;
let runtimeSkipGates = 0;
for (const file of await specs(new URL('../tests/legacy/', import.meta.url).pathname)) {
  const source = await readFile(file, 'utf8');
  const blocks = [...source.matchAll(/\/\/ legacy-id: ([^\n]+)\n([\s\S]*?)(?=\n\s*\/\/ legacy-id: |\n\}\);\s*$)/gm)];
  for (const [, id, body] of blocks) {
    if (seen.has(id)) problems.push(`Duplicate ID: ${id}`);
    seen.add(id);
    const contract = contracts[id];
    if (!contract) {
      problems.push(`Unknown ID: ${id}`);
      continue;
    }
    const declaration = /^\s*test(\.skip)?\(/m.exec(body);
    if (!declaration) problems.push(`Missing declaration: ${id}`);
    else if (contract.enabled) {
      enabled += 1;
      if (declaration[1]) problems.push(`Enabled test declared skipped: ${id}`);
    } else {
      disabled += 1;
      if (!declaration[1]) problems.push(`Disabled test declared enabled: ${id}`);
    }
    if (/\btest\.(skip|fixme)\s*\(/.test(body.slice(body.indexOf('=> {') + 4))) {
      runtimeSkipGates += 1;
      problems.push(`Runtime skip/fixme in ${id}`);
    }
  }
}
for (const id of Object.keys(contracts)) if (!seen.has(id)) problems.push(`Missing ID: ${id}`);
const summary = { total: seen.size, enabled, disabled, runtimeSkipGates, problems };
console.log(JSON.stringify(summary, null, 2));
if (problems.length || enabled !== 2691 || disabled !== 250 || seen.size !== 2941) process.exitCode = 1;
