import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

async function filesUnder(directory) {
  const entries = await readdir(directory, { withFileTypes: true }).catch(() => []);
  const nested = await Promise.all(
    entries.map((entry) => {
      const path = join(directory, entry.name);
      return entry.isDirectory() ? filesUnder(path) : [path];
    }),
  );
  return nested.flat();
}

function csvDataRows(csv) {
  let rows = 0;
  let quoted = false;
  for (let index = 0; index < csv.length; index += 1) {
    const char = csv[index];
    if (char === '"') {
      if (quoted && csv[index + 1] === '"') index += 1;
      else quoted = !quoted;
    } else if (char === '\n' && !quoted) rows += 1;
  }
  return Math.max(0, rows - 1);
}

const inventory = await readFile(
  new URL('./audit/legacy-test-inventory.csv', import.meta.url),
  'utf8',
);
const original = csvDataRows(inventory);
const testsDirectory = fileURLToPath(new URL('../tests', import.meta.url));
const specFiles = (await filesUnder(testsDirectory)).filter((file) =>
  file.endsWith('.spec.ts'),
);
const legacyIds = [];
for (const file of specFiles) {
  const source = await readFile(file, 'utf8');
  for (const match of source.matchAll(/legacy-id:\s*([^\s]+)/g)) legacyIds.push(match[1]);
}
const unique = new Set(legacyIds);
const duplicates = legacyIds.length - unique.size;
const migrated = unique.size;
const remaining = original - migrated;

console.log(
  JSON.stringify(
    {
      original,
      migrated,
      remaining,
      duplicateLegacyIds: duplicates,
      parity: remaining === 0 && duplicates === 0,
    },
    null,
    2,
  ),
);

if (remaining !== 0 || duplicates !== 0) process.exitCode = 1;
