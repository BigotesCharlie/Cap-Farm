# Reevaluación de FFQ-Playwright-TS-V1 — 30 septiembre 2026

**Archivo histórico:** esta reevaluación precede la integración del ZIP merged. El estado actualizado de handlers y reporter se documenta en `MERGED_MASTER_INTEGRATION.md`.

El ZIP anterior tenía diferencias de selección y de identidad que su auditoría no detectaba. Esta revisión corrige las diferencias comprobables, pero **el proyecto sigue sin estar listo para ejecutar los escenarios funcionales hasta Inconvenience, KnockOut o TryAgain**. Ningún handler de UI está implementado en `ScenarioExecutor`.

| Comprobación                           | Resultado                                                           | Alcance                                                                                                                                          |
| -------------------------------------- | ------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| Java maestro frente al inventario      | 2,941 métodos; cero diferencias de identidad, ubicación o anotación | Auditoría independiente leyendo el Java original, además de la comparación de contratos y specs.                                                 |
| Excel maestro frente a JSON            | 11 libros, 26,869 filas, 641,381 celdas; cero diferencias           | Encabezados recortados, columnas duplicadas conservadas con sufijo, códigos postales numéricos convertidos a texto con cinco dígitos.            |
| Fixtures HOME/AUTO usados              | 25 variantes declaradas; 2,651 contratos conectados                 | También se incluyen las variantes declaradas pero no usadas de HOME smoke y SQL Auto principal.                                                  |
| Selección HOME/AUTO en MA11            | 2,619 contratos seleccionan filas; 32 fallan                        | Validación de datos; no acredita acciones o aserciones de UI.                                                                                    |
| Regresiones de selección y fórmulas    | 13 comprobaciones aprobadas                                         | Incluye sintaxis escalar/lista, categorías entre comillas, estados, cardinalidad, forma de objetos, determinismo y referencias de Excel.         |
| Fórmulas del catálogo                  | 9,519 de 9,520 evaluadas; una falla                                 | El maestro contiene `=P104:U122Covered` en AutoDefaultCoveragesData/PA/P122, con resultado guardado `#NAME?`; se conservó su expresión original. |
| Compilación, conexión y descubrimiento | Aprobados; 2,941 declaraciones en 218 specs                         | No hubo ejecución de navegador contra FFQ.                                                                                                       |
| Configuración preservada               | Ocho archivos archivados idénticos al maestro                       | El archivo de entorno también se conserva idéntico al ZIP anterior. No se muestran valores.                                                      |
| Verificación general                   | `npm run verify` devuelve error                                     | Las selecciones bloqueadas y la fórmula inválida impiden una verificación verde.                                                                 |

## Correcciones de esta revisión

- Reconocer `values = "applicantId=1"` además de `values = {"applicantId=1"}`, y categorías literales entre comillas. Antes se omitían filtros.
- Excluir de SQL Auto los estados habilitados en AceAuto. HOME clásico respeta la lista vacía de estados que devuelve el maestro. ADPF aleatorio y ADPF de número de vehículos/conductores no reciben restricciones de ambiente ajenas a esos proveedores.
- Dar prioridad a `stateList` y `testScenario` sobre los modos de selección de AUTO cuando el Java retorna antes de procesar `testName`. Las categorías de bind requieren la configuración correspondiente, mediante `FFQ_DATA_STATES` y `FFQ_DATA_SCENARIOS`.
- Mantener todas las filas del estado elegido por BVT, y escoger los subconjuntos de estados con una mezcla determinista, en lugar de quedarse siempre con los primeros estados ordenados.
- Construir `additionalDrivers`, `payment`, `representative`, `discounts`, `listOfAdditionalApplicants` y `listOfApplicantVehicles` con la forma correspondiente al DTO Java. Se aplican las modificaciones de garaging de SQL y MA, y las mutaciones de identidad/contacto de los proveedores revisados.
- Resolver referencias de fórmulas mediante las coordenadas originales del Excel; las filas vacías ya no desplazan las referencias. Usar el sistema de fechas seriales de Excel.
- Corregir tres clases que figuraban como `name`: AceLifeQuoteScenarios, QuoteScenarios y SaveAndRetrieveHomeQuoteScenarios. Se actualizaron 19 identidades, los contratos, el CSV y los nombres de specs. La auditoría de paridad ahora compara conjuntos de IDs y metadatos, además de contar declaraciones.
- Ejecutar la limpieza de HealthCheck y RecoveryGuard en `finally`. Mantener el gate que impide presentar como PASS un escenario sin handler y aserciones finales.

## Bloqueos restantes

Los 32 identificadores y sus errores están en `audit/home-auto-revalidation.json`. Cinco requieren configuración de escenarios y estados para categorías AUTO. Los otros 27 no encuentran filas bajo la selección actual del maestro en MA11: cuatro FGIA de Condo/Renters, tres AUTO con filtros de NJ, un ADPF, dieciséis SQL Auto y tres HOME clásico. No se reemplazan por filas ajenas al escenario.

La selección BW de `FILTER` se mantiene como predicado de datos en TS. Hay una inconsistencia adicional en el maestro: el helper Java de estados trata ese atributo como un nombre de estado por su rama `default`, lo que puede vaciar la selección. Esta diferencia está documentada y no constituye una certificación de paridad de todas las ramas Java. La aleatoriedad usa una semilla reproducible en TS; no reproduce la secuencia de Faker/Random de Java. La generación aleatoria de ZIP de `STATES_DATA_PROVIDER_NAME` tampoco está reproducida: se conserva el ZIP fuente. Otras familias (Bundle, HQM, Life, Business) tienen paridad de datos e inventario comprobada, pero sus reglas funcionales no se certificaron en esta revisión.

Persisten 3,975 expresiones `xpath=` y 1,455 locators provisionales `data-legacy-field` en los Page Objects. Deben validarse y reemplazarse con evidencia del DOM de FFQ. Recovery, Sentinel y CopyDOM están presentes como fixtures automáticos; sus selectores y su integración con pasos de negocio siguen sin validación contra la aplicación. La captura diagnóstica no equivale a una reparación automática del escenario.

El ejecutor aún falla tras seleccionar datos. Hay 2,691 declaraciones habilitadas sin skip de entorno y 250 deshabilitadas procedentes de Java. Los proveedores con múltiples filas retornan arrays dentro de una declaración; falta parametrizar cada fila como ejecución independiente de Playwright. Por estas razones, contar 2,941 specs no demuestra 2,941 casos funcionales.

## Repetir la validación

`npm run verify:structure` revisa inventario, conexiones, catálogo, compilación, regresiones de fixtures y descubrimiento. `npm run verify` agrega las auditorías de selección y fórmulas y debe fallar mientras existan sus bloqueos.

Las comparaciones independientes con el maestro son opcionales y requieren Python con `openpyxl`: `python scripts/audit-java-source.py --source <master-root>` y `python scripts/audit-excel-source.py --source <master-root>/src/test/resources`. Son auditorías fuera de los tests; ningún test lee XLSX durante su ejecución.

Las evidencias resumidas y detalladas están en `audit/revalidation-summary.json`, `audit/java-source-revalidation.json`, `audit/excel-source-revalidation.json`, `audit/home-auto-revalidation.json` y `audit/formula-revalidation.json`.
