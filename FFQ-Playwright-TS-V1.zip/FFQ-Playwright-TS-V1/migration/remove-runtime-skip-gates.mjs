import { readFile, readdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const gate =
  "    test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');\n";
async function specs(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  return (
    await Promise.all(
      entries.map((entry) => {
        const path = join(directory, entry.name);
        return entry.isDirectory() ? specs(path) : path.endsWith('.spec.ts') ? [path] : [];
      }),
    )
  ).flat();
}

let removed = 0;
for (const file of await specs(new URL('../tests/legacy/', import.meta.url).pathname)) {
  const source = await readFile(file, 'utf8');
  const occurrences = source.split(gate).length - 1;
  const updated = source.replaceAll(gate, '').replace("import { env } from '../../../src/config/env.js';\n", '');
  if (updated !== source) await writeFile(file, updated);
  removed += occurrences;
}
console.log(`Removed ${removed} runtime skip gates. Declaration-level skips are preserved.`);
