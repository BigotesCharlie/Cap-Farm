# Revisión del ZIP merged y cambios aplicados a V1

Fuente: el archivo `FFQ-Playwright-TS-master.zip` entregado como estado posterior al merge. La comparación fue de archivos y código, no una certificación de browser contra FFQ.

| Elemento        | ZIP merged                                                                                | Este proyecto V1                                                                                                                                        |
| --------------- | ----------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Inventario      | 2,941 declaraciones; 19 identidades con clases `name` que no corresponden al Java maestro | 2,941 identidades corregidas y conectadas a sus fixtures; 2,691 habilitadas, 250 deshabilitadas.                                                        |
| Datos HOME/Auto | Proveedores `ExcelDataSource` con lectura de `.xlsx` durante los tests                    | Catálogos JSON versionados, selección por fixture, mismo registro consumido por el handler. No hay lectura XLSX en ningún proveedor de runtime.         |
| Handlers        | Diez específicos y un handler genérico para el resto                                      | Se conservan diez específicos; se elimina el genérico. Nueve HOME y uno Auto. Ninguno está certificado.                                                 |
| HealthCheck     | Checkpoints, reporter y Recovery con puntos de control explícitos                         | Sentinel/CopyDOM/Recovery automáticos de V1 más checkpoints, flujos HOME/Auto y reporte de ejecución del merged. Recovery observa durante todo el test. |
| Resultado       | Los reportes del merged señalan bloqueos de HOME y Golden Auto                            | El ejecutor siempre falla sin handler y también al terminar un handler no certificado. No se registra PASS a partir de navegación parcial.              |
| Reporte Excel   | Salida de ejecución, separada de los Excel de entrada                                     | Se conserva el reporte de resultados como salida; el inventario se regeneró con los IDs corregidos de V1.                                               |

## Bloqueos observados y comprobaciones pendientes

- Los reportes incluidos en el merged señalan 0/3 PASS para `AceHomeEndToEndTest` y el Golden Auto bloqueado. No existe evidencia de PASS E2E para los diez handlers en la V1 integrada.
- Los 32 contratos HOME/Auto sin datos elegibles en MA11 y la fórmula inválida de `AutoDefaultCoveragesData/PA/P122` siguen abiertos. `npm run verify` debe permanecer rojo hasta resolverlos.
- Un DataProvider Java puede devolver varias filas para un solo método. Las declaraciones actuales seleccionan un array, pero no parametrizan una ejecución independiente por fila. Los handlers parciales toman la primera fila: no se debe presentar esto como paridad de ejecución.
- Quedan locators legacy provisionales y XPath sin validación de DOM. En los Page Objects Auto transferidos se sustituyeron dos XPath simples por locators de rol; el resto requiere evidencia de la aplicación.
- Los diez handlers conservan acciones del merged para depuración, no certificación. Al alcanzar su fin actual, el ejecutor lanza una falla explícita y se guardan la captura DOM, screenshot, trace y diagnóstico.
- La configuración sensible archivada del maestro anterior permanece sin cambios en el paquete local. No se imprimieron valores en los reportes ni se incorporaron a fixtures.

## Verificación local

`npm run verify:quality` cubre formato, ESLint, ausencia de JS generado, paridad, política de skips, wiring de fixtures, catálogo, TypeScript, regresiones de fixtures y descubrimiento de Playwright. `npm run verify` agrega las auditorías de selección y fórmulas, que continúan fallando por los datos fuente indicados arriba. `npm test` bloquea un run certificado mientras `certified-scenarios.json` esté vacío. Para analizar un caso parcial use `npm run test:diagnostic -- --grep '<nombre del escenario>' --headed` en el ambiente FFQ autorizado.
