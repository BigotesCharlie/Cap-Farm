# Legacy FFQ migration audit

## Audited baseline

Source archive: `ffq-test-master (1) 2.zip`

The archive passed ZIP integrity validation. The source tree contains 547 files, including 505 Java files and 11 Excel workbooks. Java source totals 162,262 lines.

## Test inventory

| Measure | Count |
| --- | ---: |
| Real TestNG `@Test` methods | 2,941 |
| Enabled methods | 2,691 |
| Disabled by `enabled=false`, method-level `@Skip`, or class-level `@Skip` | 250 |
| Methods using a DataProvider | 2,917 |
| Methods without a DataProvider | 24 |
| DataProvider declarations | 40 |
| Cypress `it()` blocks | 0 |
| Unresolved test methods | 0 |
| Duplicate fully-qualified test IDs | 0 |

Four additional `@Test` strings are present only inside line comments and are not executable tests. They are excluded from the 2,941 baseline.

### Tests by domain

| Domain | Test methods |
| --- | ---: |
| Auto | 2,375 |
| Ace Home | 128 |
| Ace Bundle | 93 |
| HQM | 68 |
| Ace Condo | 63 |
| Ace Mobile Home | 51 |
| BDQ | 49 |
| Ace Renters | 46 |
| Specialty Dwelling | 28 |
| Ace Life | 16 |
| Ace Business | 8 |
| Cross-sell | 6 |
| Legacy Home | 6 |
| API | 4 |
| **Total** | **2,941** |

The detailed source-to-target ledger is in `legacy-test-inventory.csv`. Disabled legacy tests remain part of the migration scope and must become `test.skip()` until an authorized decision re-enables or retires them.

## Data providers

The 40 providers are implemented across five Java classes:

- `AutoDataProviders`
- `SqlDataProviders`
- `DataProviders`
- `AceHomeDataProviders`
- `AceBundleDataProviders`

Despite the `SqlDataProviders` name, the supplied implementation primarily reads Excel workbooks. Provider cardinality is runtime-dependent because filtering uses TestNG annotation attributes, environment properties, state lists, random-row selection, and test names. A single static multiplication of method count by worksheet row count would therefore be incorrect.

The migration must preserve:

- Each original workbook and worksheet as source data.
- Filters such as `FILTER`, `INCLUDED_STATES`, and `EXCLUDED_STATES`.
- `testName`-controlled modes such as random row, one per state, selected states, and all matching rows.
- The original distinction between deterministic rows and intentionally randomized selections.
- Related child records for vehicles, drivers, incidents, discounts, payments, and representatives.

`legacy-data-provider-inventory.csv` records all provider declarations and their source style. The original workbooks are copied under `data/legacy` without modification.

## Page-object architecture

The Java code contains 162 Page Object candidates and 6,290 `@FindBy` fields:

| Locator strategy | Count |
| --- | ---: |
| XPath | 5,450 |
| ID | 480 |
| CSS | 250 |
| Class name | 78 |
| Link text | 20 |
| Partial link text | 11 |
| Name | 1 |

The migration target uses constructor-injected Playwright `Page` objects and `Locator` fields. XPath locators require semantic review; replacing `WebElement` with `page.locator(xpath)` mechanically would preserve brittleness rather than deliver Playwright best practices.

## Framework dependencies

285 source files import the proprietary `com.farmers.framework` dependency. The archive does not include that framework's source or binary. `.dependencies.txt` identifies the missing artifact as `automation-framework-25.10.1-RELEASE.jar`. Eleven external APIs are used, including `AutomationFramework`, `Property`, `ExcelDataProvider`, driver lifecycle, reporting, REST, Sauce Labs, and SoapUI adapters.

The Playwright migration must replace those services with native fixtures and adapters. It cannot compile or execute the legacy project independently without the private Artifactory dependency and credentials. A local Gradle resolution attempt could not retrieve the missing artifact because the execution environment cannot reach the external Gradle distribution or private repository.

## Mobile scope

No Java file imports `AppiumDriver`, `AndroidDriver`, `IOSDriver`, `MobileElement`, or `io.appium`. The supplied configuration defines browser-based Android/Chrome and iOS/Safari sessions. These are mobile-web tests and can move to Playwright device projects.

No native app package, activity, bundle identifier, IPA, APK, or native-context test was found. The current native-app isolation count is zero.

Internet Explorer is configured in the legacy framework but is not supported by Playwright. Edge is represented by a Chromium channel project. Any contractual IE-only requirement needs product-owner disposition because it cannot be implemented in Playwright.

## Configuration and secrets

Legacy configuration is spread across:

- `build.gradle`
- `gradle/common.gradle`
- `gradle/test.gradle`
- `gradle.properties`
- `properties.json`
- `productionProperties.json`
- `foremost.json`
- five Eclipse launch files

The archive contains non-empty credential values for private Artifactory, PostgreSQL environments, Rally, and Sauce Labs. Values were not copied or printed into the migration target. The new framework loads secrets from `.env` locally and CI secret stores remotely, with validation in `src/config/env.ts`.

Because credentials exist in the legacy archive, they should be rotated and removed from source history by the credential owners.

## Migration state

The Playwright foundation, strict environment schema, browser/device projects, VS Code integration, global recovery fixture, DOM artifact capture, CI workflow, Excel adapter, and first Page Object are implemented and pass TypeScript validation.

The 2,941-test functional rewrite is not represented as complete in this baseline. The detailed ledger intentionally shows `Not started` for legacy methods until the corresponding executable Playwright behavior exists and is reviewed. Placeholder or empty `test()` blocks are not counted as migrated.
