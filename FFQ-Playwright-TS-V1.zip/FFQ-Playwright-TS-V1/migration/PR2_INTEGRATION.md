# Integración del PR #2 del maestro en FFQ-Playwright-TS-V1

Actualización: el ZIP merged posterior al PR ya fue revisado. Para el estado integrado y la lista de handlers, consulte `MERGED_MASTER_INTEGRATION.md`. Las observaciones sobre ausencia de handlers que figuren más abajo describen la versión previa a esa integración.

Referencia: capturas de `Farmers-MarketingIT/FFQ-Playwright-TS/pull/2`, titulado `chore(tooling): add quality checks and remove generated JavaScript`. La página privada y el conector de GitHub respondieron `404` desde este entorno; no fue posible revisar el diff completo. Se implementaron los cambios identificables en las capturas y no se afirma paridad exacta con todos los archivos del PR. Las capturas también incluyen auditorías de migración; sus cifras no se copiaron cuando difieren de la auditoría verificable de V1.

| Cambio del PR           | Implementación V1                                                                | Comprobación                                                                                                                                                |
| ----------------------- | -------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Node 22 y CI            | `.nvmrc`, `package.json`, `.github/workflows/playwright.yml`                     | `npm ci`, instalación de Chromium y `npm run verify` en PR, push a main y ejecución manual.                                                                 |
| ESLint y Playwright     | `eslint.config.mjs`, `lint`, `lint:fix`                                          | Analiza el código TypeScript y los specs. Los skips de declaración heredados están permitidos y auditados explícitamente.                                   |
| Prettier                | `.prettierrc.json`, `.prettierignore`, `format`, `format:check`                  | Da formato a los archivos mantenidos, evita catálogos y respaldos del maestro.                                                                              |
| Hooks y commits         | `.husky/pre-commit`, `.husky/commit-msg`, `lint-staged`, `commitlint.config.cjs` | Solo se activan dentro de un repositorio Git, después de `npm ci`.                                                                                          |
| Sin JavaScript generado | `tsconfig.json` con `noEmit`, `.gitignore`, `scripts/check-generated-js.mjs`     | Falla por `.js`, `.js.map` o `.d.ts` bajo `src/`, `tests/` o junto al config Playwright. Los scripts `.mjs` mantenidos son fuente, no artefactos generados. |
| Política de skips       | `migration/remove-runtime-skip-gates.mjs`, `migration/check-skip-policy.mjs`     | 2,691 habilitados sin skip runtime; 250 deshabilitados conservan `test.skip` de declaración. El ejecutor falla sin handler certificado.                     |
| Datos reutilizables     | `src/fixtures/data/*.fixture.ts`, `src/data/catalog/*.json`                      | No hay lectura XLSX en runtime y la auditoría de wiring inspecciona los 2,941 casos mediante el AST de TypeScript.                                          |

## Estado funcional que el PR no resuelve

Las 2,941 declaraciones no equivalen a 2,941 flujos ejecutables. Ningún handler de UI está certificado en esta versión. Los datos HOME/Auto aún tienen 32 selecciones bloqueadas en MA11 y una fórmula fuente `#NAME?`. Los Page Objects legacy siguen necesitando validación de locators con el DOM real. Sentinel, CopyDOM y Recovery están presentes como infraestructura; no hay ejecución E2E contra FFQ que demuestre que alcanzan Inconvenience, KnockOut o TryAgain. Por ello `npm run verify` y `npm test` no se presentan como PASS.

La integración mantiene los archivos locales de configuración sensibles que estaban en el ZIP previo, sin trasladar sus valores a documentación o fixtures. No se deben subir al repositorio.
