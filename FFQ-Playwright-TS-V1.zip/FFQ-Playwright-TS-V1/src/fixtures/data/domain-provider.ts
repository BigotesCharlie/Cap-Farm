import type { TestInfo } from '@playwright/test';
import type { DataRecord } from '../../data/FixtureCatalog.js';
import type { SelectedCase, SelectionOptions } from '../../data/LegacyProviderSelector.js';
import type { LegacyTestMetadata } from '../../migration/LegacyTestMetadata.js';
import { providerFor } from './provider.js';

export type ApplicantRow = DataRecord & Readonly<{ stateCode: string }>;
export type DomainProvider<T extends ApplicantRow> = (metadata: LegacyTestMetadata) => Promise<SelectedCase<T>[]>;
export type ProviderRules<T extends ApplicantRow> = Record<
  string,
  Readonly<{
    sheet: string;
    check?: (cases: readonly SelectedCase<T>[], metadata: LegacyTestMetadata, options?: SelectionOptions) => void;
  }>
>;

/** Resolve only declared Java DataProvider variants and validate their output. */
export function createDomainProvider<T extends ApplicantRow>(
  owner: string,
  testInfo: TestInfo,
  rules: ProviderRules<T>,
): DomainProvider<T> {
  const select = providerFor(owner, testInfo);
  return async (metadata) => {
    const variant = metadata.dataProvider.split('.').pop() ?? '';
    const rule = rules[variant];
    if (!rule) throw new Error(`Missing ${owner} fixture variant ${variant || '(empty)'} for ${metadata.legacyId}`);
    const selected = (await select(metadata)) as SelectedCase<T>[];
    if (!selected.length) throw new Error(`Empty ${owner}.${variant} for ${metadata.legacyId}`);
    for (const row of selected) {
      if (row.sheet !== rule.sheet || !row.state || typeof row.data.stateCode !== 'string') {
        throw new Error(`Invalid ${owner}.${variant} row: ${row.source}/${row.sheet}/${row.sourceId}`);
      }
      if (row.state !== row.data.stateCode.toUpperCase()) {
        throw new Error(`Fixture state mismatch: ${row.source}/${row.sheet}/${row.sourceId}`);
      }
    }
    rule.check?.(selected, metadata, {
      seed: process.env.FFQ_DATA_SEED || testInfo.testId,
      environment: process.env.TEST_ENV || 'MA11',
      ...(process.env.FFQ_DATA_STATES ? { states: process.env.FFQ_DATA_STATES } : {}),
      ...(process.env.FFQ_DATA_SCENARIOS ? { scenarios: process.env.FFQ_DATA_SCENARIOS } : {}),
    });
    return selected;
  };
}

export function exactlyOne<T extends ApplicantRow>(
  cases: readonly SelectedCase<T>[],
  metadata: LegacyTestMetadata,
): void {
  if (cases.length !== 1) throw new Error(`${metadata.legacyId} expected one fixture row, received ${cases.length}`);
}

export function onePerState<T extends ApplicantRow>(
  cases: readonly SelectedCase<T>[],
  metadata: LegacyTestMetadata,
): void {
  if (new Set(cases.map((item) => item.state)).size !== cases.length) {
    throw new Error(`${metadata.legacyId} selected multiple fixture rows for one state`);
  }
}
