import { test as base } from '@playwright/test';
import {
  createDomainProvider,
  exactlyOne,
  onePerState,
  type ApplicantRow,
  type DomainProvider,
  type ProviderRules,
} from './domain-provider.js';

export type AceHomeApplicant = ApplicantRow &
  Readonly<{
    firstName: string;
    lastName: string;
    zipCode: string;
    discounts?: readonly Record<string, unknown>[];
  }>;

/** Every AceHomeDataProviders variant used by the Java inventory. */
export const aceHomeRules: ProviderRules<AceHomeApplicant> = {
  APPLICANT_ACE_HOME_DATA_PROVIDER: {
    sheet: 'ApplicantHome',
    check: (rows, meta) => {
      if (meta.testName === 'RANDOM_ROW') exactlyOne(rows, meta);
      if (meta.testName === 'ONE_APPLICANT_PER_STATE') onePerState(rows, meta);
    },
  },
  APPLICANT_ACE_HOME_CATEGORY_PROVIDER: { sheet: 'PageValidationApplicantAceHome', check: exactlyOne },
  ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME: { sheet: 'PageValidationApplicantAceHome', check: exactlyOne },
  ENVIRONMENT_STABILITY_DATA_PROVIDER: { sheet: 'PageValidationApplicantAceHome', check: onePerState },
};

export const test = base.extend<{ aceHomeData: DomainProvider<AceHomeApplicant> }>({
  aceHomeData: async ({}, use, testInfo) => {
    await use(createDomainProvider('AceHomeDataProviders', testInfo, aceHomeRules));
  },
});
