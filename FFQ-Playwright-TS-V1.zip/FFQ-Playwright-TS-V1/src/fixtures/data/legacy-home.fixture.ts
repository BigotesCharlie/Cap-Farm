import { test as base } from '@playwright/test';
import { createDomainProvider, type ApplicantRow, type DomainProvider, type ProviderRules } from './domain-provider.js';

export type LegacyHomeApplicant = ApplicantRow &
  Readonly<{
    firstName: string;
    lastName: string;
    zipCode: string;
  }>;

/** Legacy HOME variants from the shared Java DataProviders class. */
export const legacyHomeRules: ProviderRules<LegacyHomeApplicant> = {
  APPLICANT_HOME_DATA_PROVIDER: { sheet: 'ApplicantHome' },
  APPLICANT_HOME_SMOKE_DATA_PROVIDER: { sheet: 'ApplicantHome' },
  APPLICANT_HOME_ERROR_DATA_PROVIDER: { sheet: 'ApplicantHome' },
  MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER: { sheet: 'ApplicantHome' },
  GET_RETRIEVE_QUOTE_APPLICANT_HOME: { sheet: 'GetRetrieveQuoteHome' },
};

export const test = base.extend<{ legacyHomeData: DomainProvider<LegacyHomeApplicant> }>({
  legacyHomeData: async ({}, use, testInfo) => {
    await use(createDomainProvider('DataProviders', testInfo, legacyHomeRules));
  },
});
