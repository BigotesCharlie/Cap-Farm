import { test as base } from '@playwright/test';
import { createDomainProvider, type ApplicantRow, type DomainProvider, type ProviderRules } from './domain-provider.js';

export type SqlAutoApplicant = ApplicantRow &
  Readonly<{
    applicantId?: number | string;
    zipCode?: string;
    vehicles?: readonly Record<string, unknown>[];
    additionalDrivers?: readonly Record<string, unknown>[];
    incidents?: readonly Record<string, unknown>[];
    discounts?: Readonly<Record<string, unknown>> | null;
    payment?: Readonly<Record<string, unknown>> | null;
    representative?: Readonly<Record<string, unknown>> | null;
  }>;

/** Every SqlDataProviders variant referenced by the AUTO migration ledger. */
export const sqlAutoRules: ProviderRules<SqlAutoApplicant> = {
  STATES_DATA_PROVIDER_NAME: { sheet: 'stateValidation' },
  AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER: { sheet: 'pageValidationApplicant' },
  AUTO_APPLICANT_DATA_PROVIDER: { sheet: 'applicant' },
  AUTO_APPLICANT_SAVE_AND_RETRIEVE_DATA_PROVIDER: { sheet: 'retrieveQuoteApplicant' },
  AUTO_APPLICANT_COMMON_DATA_PROVIDER: { sheet: 'applicantTest' },
  TEST_AUTO_APPLICANT_DATA_PROVIDER: { sheet: 'testApplicant' },
  ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER: { sheet: 'applicantBVT' },
  BVT_AUTO_APPLICANT_DATA_PROVIDER: { sheet: 'applicantBVT' },
  BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER: { sheet: 'applicantBW' },
  JENKINS_AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER: { sheet: 'pageValidationApplicant' },
  JENKINS_AUTO_APPLICANT_SMOKE_TEST_DATA_PROVIDER: { sheet: 'applicantBVT' },
  JENKINS_AUTO_APPLICANT_QUOTE_SCENARIOS_DATA_PROVIDER: { sheet: 'applicant' },
  HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER: { sheet: 'applicant' },
};

export const test = base.extend<{ sqlAutoData: DomainProvider<SqlAutoApplicant> }>({
  sqlAutoData: async ({}, use, testInfo) => {
    await use(createDomainProvider('SqlDataProviders', testInfo, sqlAutoRules));
  },
});
