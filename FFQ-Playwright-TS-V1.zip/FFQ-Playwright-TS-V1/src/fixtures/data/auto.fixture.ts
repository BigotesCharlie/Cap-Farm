import { test as base } from '@playwright/test';
import {
  createDomainProvider,
  exactlyOne,
  onePerState,
  type ApplicantRow,
  type DomainProvider,
  type ProviderRules,
} from './domain-provider.js';

export type AutoApplicant = ApplicantRow &
  Readonly<{
    applicantId?: number | string;
    householdNumber?: number | string;
    vehicles?: readonly Record<string, unknown>[];
    additionalDrivers?: readonly Record<string, unknown>[];
    incidents?: readonly Record<string, unknown>[];
    discounts?: readonly Record<string, unknown>[];
    listOfAdditionalApplicants?: readonly Record<string, unknown>[];
    listOfApplicantVehicles?: readonly Record<string, unknown>[];
  }>;

/** All five AutoDataProviders sources, including both ADPF forms. */
export const autoRules: ProviderRules<AutoApplicant> = {
  AUTO_APPLICANT_DATA_PROVIDER: {
    sheet: 'applicant',
    check: (rows, meta, options) => {
      if (
        (options?.states?.trim() && options.states.trim().toLowerCase() !== 'all') ||
        options?.scenarios?.split(',').some((item) => item.trim() && item.trim() !== 'Assault')
      )
        return;
      if (
        /RANDOM_AUTO_APPLICANT|AUTO_APPLICANT_WITH_ONE_VEHICLE|FINANCIAL_RESPONSIBILITY_APPLICANT|SERVICE_VIRTUALIZATION_APPLICANT/.test(
          meta.testName,
        )
      )
        exactlyOne(rows, meta);
      if (/AUTO_APPLICANT_FROM_EACH_STATE|AUTO_APPLICANTS_FROM_A_FEW_STATES/.test(meta.testName))
        onePerState(rows, meta);
      if (
        meta.testName.endsWith('AUTO_APPLICANT_WITH_ONE_VEHICLE') &&
        rows.some((row) => row.data.vehicles?.length !== 1)
      ) {
        throw new Error(`${meta.legacyId} requires exactly one linked vehicle`);
      }
    },
  },
  AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER: { sheet: 'pageValidationApplicant' },
  RANDOM_ADPF_APPLICANT_DATA_PROVIDER: { sheet: 'ADPFApplicant', check: exactlyOne },
  BIND_ADPF_APPLICANT_DATA_PROVIDER: { sheet: 'bindOneUIApplicant' },
  ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER: {
    sheet: 'ADPFApplicantVehicleDriverNum',
    check: exactlyOne,
  },
};

export const test = base.extend<{ autoData: DomainProvider<AutoApplicant> }>({
  autoData: async ({}, use, testInfo) => {
    await use(createDomainProvider('AutoDataProviders', testInfo, autoRules));
  },
});
