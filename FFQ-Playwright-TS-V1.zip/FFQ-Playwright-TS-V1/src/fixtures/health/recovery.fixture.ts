import { test as base, type Page } from '@playwright/test';
import { RecoveryGuard } from '../../core/RecoveryGuard.js';

const activeGuards = new WeakMap<Page, RecoveryGuard>();
export function getRecoveryGuard(page: Page): RecoveryGuard | undefined {
  return activeGuards.get(page);
}

export const test = base.extend<{ recoveryGuard: RecoveryGuard }>({
  recoveryGuard: [
    async ({ page }, use, testInfo) => {
      const guard = new RecoveryGuard(page, testInfo);
      activeGuards.set(page, guard);
      guard.start();
      try {
        await use(guard);
      } finally {
        try {
          await guard.stop();
        } finally {
          activeGuards.delete(page);
        }
      }
    },
    { auto: true },
  ],
});
