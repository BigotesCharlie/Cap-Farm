import { test as base } from '@playwright/test';
import { HealthCheck } from '../../core/HealthCheck.js';
import { RecoveryGuard } from '../../core/RecoveryGuard.js';

export const test = base.extend<{ healthCheck: HealthCheck; recoveryGuard: RecoveryGuard }>({
  healthCheck: [
    async ({ page, recoveryGuard }, use, testInfo) => {
      const health = new HealthCheck(page, testInfo, recoveryGuard);
      health.start();
      try {
        await use(health);
      } finally {
        await health.stop();
      }
    },
    { auto: true },
  ],
});
