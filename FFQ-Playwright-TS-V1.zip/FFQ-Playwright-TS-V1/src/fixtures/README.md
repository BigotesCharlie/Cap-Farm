# FFQ Playwright fixtures

`test.ts` composes the independent fixtures with `mergeTests` and exports the only `test` that specs import. The source catalogs are JSON in `src/data/catalog`; Playwright fixtures are TypeScript definitions under this directory.

| Java source              | Fixture in spec  | Definition                    | Catalog family                      |
| ------------------------ | ---------------- | ----------------------------- | ----------------------------------- |
| `AceHomeDataProviders`   | `aceHomeData`    | `data/ace-home.fixture.ts`    | AceHomeTestData                     |
| `AutoDataProviders`      | `autoData`       | `data/auto.fixture.ts`        | OneUIAutoTestData                   |
| `AceBundleDataProviders` | `bundleData`     | `data/bundle.fixture.ts`      | OneUIAutoTestData + AceHomeTestData |
| `SqlDataProviders`       | `sqlAutoData`    | `data/sql-auto.fixture.ts`    | AutoTestData                        |
| `DataProviders` for HOME | `legacyHomeData` | `data/legacy-home.fixture.ts` | HomeTestData                        |
| Other `DataProviders`    | `classicData`    | `data/classic.fixture.ts`     | HQM, Life, Business, MobileHome     |
| No provider              | `inlineData`     | `data/inline.fixture.ts`      | No external row                     |

`data/reference.fixture.ts` exposes `referenceData` for Nearmap, coverages, and umbrella data. `health/recovery.fixture.ts` and `health/health-check.fixture.ts` are automatic fixtures active for all imported specs.

Example from `tests/legacy/acehome/AceHomeEndToEndTest.spec.ts`:

```ts
test('testReviewQuotePagePresentmentCardHome', async ({ page, aceHomeData }, testInfo) => {
  // The Java metadata is passed to the selected provider fixture.
  await executeMigratedScenario(page, testInfo, aceHomeData, metadata);
});
```

`aceHomeData(metadata)` validates the owner, selects rows using the Java attributes, seed, and environment, resolves formulas, and returns `SelectedCase[]`. It is cached only within the Playwright test. Incorrect provider wiring fails explicitly; `npm run audit:provider-wiring` checks all 2,941 declarations.

The HOME and AUTO fixture modules declare every provider variant used in their Java families: AceHome (4), Auto (5), Sql Auto (12 used; 13 declared), and legacy HOME (4 used; 5 declared). Each rule names its source sheet and checks row shape and state. Selection and child row joins live in `src/data/LegacyProviderSelector.ts`; source rows live in `src/data/catalog/*.json`. The fixture files are intentionally concise because thousands of Excel rows are stored as JSON, not copied into TypeScript functions. `npm run audit:home-auto -- --all` checks every one of the 2,651 HOME/AUTO contracts, including variant coverage and selected row invariants. A zero-row condition exits nonzero and is never replaced by an unrelated row.

The reevaluated MA11 audit selects rows for 2,619 contracts and reports 32 blockers; see `migration/REEVALUATION.md`. `FFQ_DATA_STATES` maps the explicit Java `stateList` selection and `FFQ_DATA_SCENARIOS` maps `testScenario`. The main AUTO provider returns the matching configured rows before applying its random `testName` mode, following the Java precedence. Category bind providers require these settings except for the Java assault branch or the existing-customer knockout category. Fixture identity transformations are seeded and cached once per test; `LegacyApplicantTransforms.ts` prepares them without changing the source JSON.

**Current limitation:** `executeMigratedScenario` does not navigate FFQ or perform UI assertions, and a multirow provider returns an array within one declared test. True TestNG-style per-row Playwright parameterization remains pending. These fixtures prepare data, not behavior certification.
