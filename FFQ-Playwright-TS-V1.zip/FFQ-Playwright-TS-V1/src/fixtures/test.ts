import { promises as fs } from 'node:fs';
import { test as base, expect } from '@playwright/test';
import { RecoveryGuard } from '../core/RecoveryGuard.js';

type AutoFixtures = {
  recoveryGuard: RecoveryGuard;
};

export const test = base.extend<AutoFixtures>({
  recoveryGuard: [
    async ({ page }, use, testInfo) => {
      const guard = new RecoveryGuard(page, testInfo);
      guard.start();
      await use(guard);
      await guard.stop();
    },
    { auto: true },
  ],
});

test.afterEach(async ({ page }, testInfo) => {
  if (page.isClosed()) return;
  await fs.writeFile(testInfo.outputPath('final-dom.html'), await page.content(), 'utf8');
});

export { expect };
