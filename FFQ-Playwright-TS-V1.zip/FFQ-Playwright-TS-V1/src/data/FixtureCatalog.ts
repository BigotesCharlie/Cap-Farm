import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { evaluateLegacyDateFormula, isLegacyFormula } from './LegacyDateFormula.js';

export type DataRecord = Readonly<Record<string, unknown>>;
type Workbook = Record<string, DataRecord[]>;
type Columns = Record<string, Record<string, string[]>>;
type SourceRows = Record<string, Record<string, number[]>>;

const catalogDirectory = resolve('src/data/catalog');
const workbooks = new Map<string, Promise<Workbook>>();
let columnMap: Promise<Columns> | undefined;
let sourceRowMap: Promise<SourceRows> | undefined;

async function columns(): Promise<Columns> {
  columnMap ??= readFile(`${catalogDirectory}/columns.json`, 'utf8').then((text) => JSON.parse(text) as Columns);
  return columnMap;
}

async function workbook(name: string): Promise<Workbook> {
  if (!/^[A-Za-z0-9+_-]+$/.test(name)) throw new Error(`Invalid fixture catalog: ${name}`);
  let pending = workbooks.get(name);
  if (!pending) {
    pending = readFile(`${catalogDirectory}/${name}.json`, 'utf8').then((text) => JSON.parse(text) as Workbook);
    workbooks.set(name, pending);
  }
  return pending;
}

export async function rawRows(book: string, sheet: string): Promise<readonly DataRecord[]> {
  const rows = (await workbook(book))[sheet];
  if (!rows) throw new Error(`Missing fixture sheet ${book}/${sheet}`);
  return rows;
}

/** Resolve TODAY formulas only for the selected row, on the date the test runs. */
export async function materializeRow(
  book: string,
  sheet: string,
  row: DataRecord,
  today = fixtureDate(),
): Promise<DataRecord> {
  const columnDefinitions = await columns();
  sourceRowMap ??= readFile(`${catalogDirectory}/source-rows.json`, 'utf8').then(
    (text) => JSON.parse(text) as SourceRows,
  );
  const sourceRows = await sourceRowMap;
  const workbookRows = await workbook(book);
  const visiting = new Set<string>();
  const getValue = (targetBook: string, targetSheet: string, targetRow: DataRecord, key: string): unknown => {
    const value = targetRow[key];
    if (!isLegacyFormula(value)) return value;
    const identity = `${targetBook}/${targetSheet}/${value.cell}`;
    if (visiting.has(identity)) throw new Error(`Circular fixture formula: ${identity}`);
    visiting.add(identity);
    try {
      return evaluateLegacyDateFormula(value.__excelFormula, today, (reference) => {
        const match = /^(?:(\w+)!)?\$?([A-Za-z]+)\$?(\d+)$/.exec(reference);
        if (!match) throw new Error(`Unsupported formula reference: ${reference}`);
        const refSheet = match[1] ?? targetSheet;
        const letters = match[2]!.toUpperCase();
        let index = 0;
        for (const letter of letters) index = index * 26 + letter.charCodeAt(0) - 64;
        const field = columnDefinitions[targetBook]?.[refSheet]?.[index - 1];
        if (!field) throw new Error(`Missing fixture column ${targetBook}/${refSheet}/${letters}`);
        const sourceIndex = sourceRows[targetBook]?.[refSheet]?.indexOf(Number(match[3]));
        const referenceRow =
          sourceIndex !== undefined && sourceIndex >= 0 ? workbookRows[refSheet]?.[sourceIndex] : undefined;
        if (!referenceRow) throw new Error(`Missing fixture reference ${targetBook}/${refSheet}/${reference}`);
        const referenced = getValue(targetBook, refSheet, referenceRow, field);
        if (typeof referenced !== 'number' && typeof referenced !== 'string' && typeof referenced !== 'boolean') {
          throw new Error(`Invalid referenced fixture value: ${identity}/${field}`);
        }
        return referenced;
      });
    } catch (error) {
      throw new Error(`Fixture formula ${identity}: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      visiting.delete(identity);
    }
  };
  return Object.freeze(Object.fromEntries(Object.keys(row).map((key) => [key, getValue(book, sheet, row, key)])));
}

export async function materializeRows(book: string, sheet: string, rows: readonly DataRecord[]): Promise<DataRecord[]> {
  const now = fixtureDate();
  return Promise.all(rows.map((row) => materializeRow(book, sheet, row, now)));
}

function fixtureDate(): Date {
  const zone = process.env.FFQ_DATA_TIMEZONE || 'America/Los_Angeles';
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: zone,
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
  }).formatToParts(new Date());
  const value = (type: string) => Number(parts.find((part) => part.type === type)?.value);
  return new Date(Date.UTC(value('year'), value('month') - 1, value('day')));
}
