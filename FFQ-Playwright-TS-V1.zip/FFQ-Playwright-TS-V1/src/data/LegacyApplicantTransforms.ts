import type { DataRecord } from './FixtureCatalog.js';

/** Seeded replacements for the Java Faker mutations; source catalog rows remain intact. */
export function prepareJavaApplicant(
  data: DataRecord,
  owner: string,
  variant: string,
  testName: string,
  rng: () => number,
  bindAddress?: DataRecord,
): DataRecord {
  const firstNames = ['Alex', 'Jordan', 'Taylor', 'Morgan', 'Casey', 'Robin'];
  const lastNames = ['Miller', 'Wilson', 'Clark', 'Lewis', 'Walker', 'Hall'];
  const name = (values: readonly string[]) => values[Math.floor(rng() * values.length)]!;
  const suffix = (length: number) =>
    Array.from({ length }, () => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[Math.floor(rng() * 26)]!).join('');
  const phone = () => `202555${String(Math.floor(rng() * 10000)).padStart(4, '0')}`;
  const result: Record<string, unknown> = { ...data };
  if (owner === 'AceHomeDataProviders' && variant !== 'ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME') {
    const extra = variant === 'APPLICANT_ACE_HOME_DATA_PROVIDER' ? '' : suffix(3);
    result.firstName = name(firstNames) + extra;
    result.lastName = name(lastNames) + extra;
    if (variant === 'APPLICANT_ACE_HOME_DATA_PROVIDER' && String(data.maritalStatus).toLowerCase() === 'married') {
      result.spouseFirstName = name(firstNames);
      result.spouseLastName = name(lastNames);
    }
  }
  if (owner === 'SqlDataProviders' && variant !== 'STATES_DATA_PROVIDER_NAME') {
    result.firstName = name(firstNames);
    result.lastName = name(lastNames);
  }
  if (
    owner === 'AutoDataProviders' &&
    ['AUTO_APPLICANT_DATA_PROVIDER', 'AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER'].includes(variant)
  ) {
    result.email = `${String(data.applicantId ?? '')}${suffix(15)}@farmers.testinator.com`;
    if (Array.isArray(data.additionalDrivers)) {
      result.additionalDrivers = Object.freeze(
        data.additionalDrivers.map((driver: DataRecord) =>
          Object.freeze({
            ...driver,
            firstName: name(firstNames),
            lastName: name(lastNames),
          }),
        ),
      );
    }
    if (variant === 'AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER') {
      result.email = `testesign_${suffix(4)}${String(data.lastName ?? '').replaceAll(' ', '')}@farmers.testinator.com`;
      result.phoneNumber = phone();
    }
    if (
      bindAddress &&
      ['financialResponsibility', 'ServiceVirtualizationApplicants', 'AllApplicants'].includes(testName)
    ) {
      result.firstName = name(firstNames);
      result.lastName = 'Brown';
      result.email = `testesign_${suffix(4)}${result.firstName}@farmers.testinator.com`;
      result.phoneNumber = phone();
      for (const field of ['zipCode', 'city', 'residentAddress', 'apartmentNumber', 'garagingAddress'])
        result[field] = bindAddress[field];
      if (Array.isArray(result.additionalDrivers)) {
        result.additionalDrivers = Object.freeze(
          result.additionalDrivers.map((driver: DataRecord) => Object.freeze({ ...driver, lastName: 'Brown' })),
        );
      }
    }
  }
  return Object.freeze(result);
}
