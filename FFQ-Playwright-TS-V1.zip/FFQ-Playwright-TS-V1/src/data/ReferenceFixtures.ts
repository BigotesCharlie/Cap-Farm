import { materializeRow, materializeRows, rawRows, type DataRecord } from './FixtureCatalog.js';
import { FixtureSelectionError } from './LegacyProviderSelector.js';

export class ReferenceFixtures {
  public constructor(private readonly seed: string) {}

  private pick<T>(rows: readonly T[], label: string): T {
    if (!rows.length) throw new FixtureSelectionError(`Missing reference fixture: ${label}`);
    let hash = 2166136261;
    for (const char of `${this.seed}:${label}`) hash = Math.imul(hash ^ char.charCodeAt(0), 16777619);
    return rows[(hash >>> 0) % rows.length]!;
  }

  public async rows(book: string, sheet: string): Promise<DataRecord[]> {
    return materializeRows(book, sheet, await rawRows(book, sheet));
  }

  public async nearMapAddress(state: string, evidence: '7-or-8' | 'other'): Promise<DataRecord> {
    const sheet = evidence === '7-or-8' ? 'Addresses w-Evidence 7 or 8' : 'Addresses w-Evid Type NOT 7 8';
    const book = 'Nearmap+Roof+Age+Prefill+Test+Addresses';
    const candidates = (await rawRows(book, sheet)).filter(
      (row) => String(row.state).toUpperCase() === state.toUpperCase(),
    );
    return materializeRow(book, sheet, this.pick(candidates, `${sheet}/${state}`));
  }

  public async defaultCoverages(state: string, filter: Readonly<Record<string, string>> = {}): Promise<DataRecord[]> {
    const book = 'AutoDefaultCoveragesData';
    const candidates = (await rawRows(book, state.toUpperCase())).filter((row) =>
      Object.entries(filter).every(([key, value]) => String(row[key] ?? '').trim() === value),
    );
    if (!candidates.length)
      throw new FixtureSelectionError(`No default coverages for ${state}: ${JSON.stringify(filter)}`);
    return materializeRows(book, state.toUpperCase(), candidates);
  }

  public async umbrellaApplicant(state: string, environment: string): Promise<DataRecord> {
    const book = 'AutoDefaultCoveragesData';
    const sheet = `ApplicantsUmbrellaPolicy_${environment.toUpperCase()}`;
    const candidates = (await rawRows(book, sheet)).filter(
      (row) => String(row.stateCode).toUpperCase() === state.toUpperCase(),
    );
    return materializeRow(book, sheet, this.pick(candidates, `${sheet}/${state}`));
  }
}
