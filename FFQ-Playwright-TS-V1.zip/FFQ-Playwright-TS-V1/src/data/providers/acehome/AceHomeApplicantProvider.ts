import type { LegacyTestMetadata } from '../../../migration/LegacyTestMetadata.js';
import type { SelectedCase } from '../../LegacyProviderSelector.js';
import type { DataRecord } from '../../FixtureCatalog.js';
import type {
  ApplicantAceHome,
  HomeDiscount,
  SelectedAceHomeApplicant,
} from '../../../models/acehome/ApplicantAceHome.js';

type FixtureRecord = DataRecord;

function normalizeText(value: unknown): string {
  if (value instanceof Date) {
    const mm = String(value.getMonth() + 1).padStart(2, '0');
    const dd = String(value.getDate()).padStart(2, '0');
    const yyyy = String(value.getFullYear());
    return `${mm}/${dd}/${yyyy}`;
  }
  if (typeof value === 'object' && value !== null) {
    const record = value as Record<string, unknown>;
    if (typeof record.text === 'string') return record.text.trim();
    if ('result' in record) return normalizeText(record.result);
  }
  return String(value ?? '').trim();
}

function normalizeBoolean(value: unknown): boolean {
  const normalized = normalizeText(value).toLowerCase();
  return normalized === 'true' || normalized === 'yes' || normalized === 'y' || normalized === '1';
}

function normalizeNumber(value: unknown): number {
  const parsed = Number(normalizeText(value));
  return Number.isFinite(parsed) ? parsed : 0;
}

function mapDiscount(record: FixtureRecord): HomeDiscount {
  return {
    discountId: normalizeNumber(record.discountId),
    applicantId: normalizeNumber(record.applicantId),
    paymentMethod: normalizeText(record.paymentMethod),
    startDateOfNewPolicy: normalizeText(record.startDateOfNewPolicy),
    autoInsurance: normalizeBoolean(record.autoInsurance),
    umbrellaInsurance: normalizeBoolean(record.umbrellaInsurance),
    lifeInsurance: normalizeBoolean(record.lifeInsurance),
    homeInsurance: normalizeBoolean(record.homeInsurance),
    rentersInsurance: normalizeBoolean(record.rentersInsurance),
    condoInsurance: normalizeBoolean(record.condoInsurance),
    valueTermLifeInsurance: normalizeBoolean(record.valueTermLifeInsurance),
    recreationalBoatWatercraftInsurance: normalizeBoolean(record.recreationalBoatWatercraftInsurance),
    motorcycleInsurance: normalizeBoolean(record.motorcycleInsurance),
    businessInsurance: normalizeBoolean(record.businessInsurance),
    ownOrRentHome: normalizeText(record.ownOrRentHome),
    paymentMethodForDiscount: normalizeText(record.paymentMethodForDiscount),
    mediaAlphaTimeAtResidence: normalizeText(record.mediaAlphaTimeAtResidence),
    mediaAlphaHasGarage: normalizeText(record.mediaAlphaHasGarage),
    signalSignup: normalizeBoolean(record.signalSignup),
    multiPolicyCEA: normalizeBoolean(record.multiPolicyCEA),
  };
}

function mapApplicant(record: FixtureRecord, discounts: readonly HomeDiscount[]): ApplicantAceHome {
  return {
    id: normalizeNumber(record.id),
    testCategory: normalizeText(record.testCategory),
    firstName: normalizeText(record.firstName),
    lastName: normalizeText(record.lastName),
    dateOfBirth: normalizeText(record.dateOfBirth),
    gender: normalizeText(record.gender),
    maritalStatus: normalizeText(record.maritalStatus),
    spouseFirstName: normalizeText(record.spouseFirstName),
    spouseLastName: normalizeText(record.spouseLastName),
    spouseDateOfBirth: normalizeText(record.spouseDateOfBirth),
    spouseGender: normalizeText(record.spouseGender),
    address: normalizeText(record.address),
    unit: normalizeText(record.unit),
    city: normalizeText(record.city),
    county: normalizeText(record.county),
    stateCode: normalizeText(record.stateCode),
    state: normalizeText(record.state),
    zipCode: normalizeText(record.zipCode),
    priorOrCurrentAddress: normalizeText(record.priorOrCurrentAddress),
    priorOrCurrentUnit: normalizeText(record.priorOrCurrentUnit),
    priorOrCurrentCity: normalizeText(record.priorOrCurrentCity),
    priorOrCurrentCounty: normalizeText(record.priorOrCurrentCounty),
    priorOrCurrentStateCode: normalizeText(record.priorOrCurrentStateCode),
    priorOrCurrentState: normalizeText(record.priorOrCurrentState),
    priorOrCurrentZipCode: normalizeText(record.priorOrCurrentZipCode),
    yearBuilt: normalizeText(record.yearBuilt),
    squareFeet: normalizeText(record.squareFeet),
    numberOfStories: normalizeText(record.numberOfStories),
    bathrooms: normalizeText(record.bathrooms),
    foundationType: normalizeText(record.foundationType),
    exteriorWallFinish: normalizeText(record.exteriorWallFinish),
    roofCover: normalizeText(record.roofCover),
    floorCoverings: normalizeText(record.floorCoverings),
    heatingSystem: normalizeText(record.heatingSystem),
    fireplace: normalizeText(record.fireplace),
    garageCarport: normalizeText(record.garageCarport),
    garageStyle: normalizeText(record.garageStyle),
    mailingAddressDifferent: normalizeBoolean(record.mailingAddressDifferent),
    emailAddress: normalizeText(record.emailAddress),
    phoneNumber: normalizeText(record.phoneNumber),
    occupation: normalizeText(record.occupation),
    centralBurglarAlarm: normalizeBoolean(record.centralBurglarAlarm),
    centralFireAlarm: normalizeBoolean(record.centralFireAlarm),
    localBurglarAlarm: normalizeBoolean(record.localBurglarAlarm),
    localFireAlarm: normalizeBoolean(record.localFireAlarm),
    burglarAlarm: normalizeBoolean(record.burglarAlarm),
    fireAlarm: normalizeBoolean(record.fireAlarm),
    alarmSystem: normalizeBoolean(record.alarmSystem),
    sprinklerSystem: normalizeBoolean(record.sprinklerSystem),
    smokeAlarm: normalizeBoolean(record.smokeAlarm),
    waterLeakProtection: normalizeBoolean(record.waterLeakProtection),
    fortifiedHome: normalizeText(record.fortifiedHome),
    nonSmoker: normalizeBoolean(record.nonSmoker),
    temporaryRentals: normalizeBoolean(record.temporaryRentals),
    swimmingPool: normalizeBoolean(record.swimmingPool),
    solarPanels: normalizeBoolean(record.solarPanels),
    trampoline: normalizeBoolean(record.trampoline),
    ulRoof: normalizeBoolean(record.ulRoof),
    roofReplaced: normalizeBoolean(record.roofReplaced),
    mineSubsidence: normalizeBoolean(record.mineSubsidence),
    newlyOwned: normalizeBoolean(record.newlyOwned),
    inEscrow: normalizeBoolean(record.inEscrow),
    fireHydrant: normalizeText(record.fireHydrant),
    homeVisible: normalizeText(record.homeVisible),
    secondaryHeatingSource: normalizeText(record.secondaryHeatingSource),
    wroughtIronBars: normalizeText(record.wroughtIronBars),
    previousInsurance: normalizeText(record.previousInsurance),
    wildFireRisk: normalizeText(record.wildFireRisk),
    stormShutters: normalizeText(record.stormShutters),
    electricalUpdated: normalizeText(record.electricalUpdated),
    plumbingUpdated: normalizeText(record.plumbingUpdated),
    hvacUpdated: normalizeText(record.hvacUpdated),
    earlyShoppingFactor: normalizeText(record.earlyShoppingFactor),
    agentId: normalizeText(record.agentId),
    lenderBank: normalizeText(record.lenderBank),
    lenderBankName: normalizeText(record.lenderBankName),
    lenderIncompleteSelection: normalizeText(record.lenderIncompleteSelection),
    impoundAccountSelection: normalizeText(record.impoundAccountSelection),
    plumbingOtherThanCopperPexPVC: normalizeText(record.plumbingOtherThanCopperPexPVC),
    primaryHeatingSource: normalizeText(record.primaryHeatingSource),
    updatedPrimaryHeatingSource: normalizeText(record.updatedPrimaryHeatingSource),
    unrepairedStructures: normalizeText(record.unrepairedStructures),
    businessOperatedOnPremises: normalizeText(record.businessOperatedOnPremises),
    dogsOnPremises: normalizeText(record.dogsOnPremises),
    updatedDogsOnPremises: normalizeText(record.updatedDogsOnPremises),
    petWithBiteHistory: normalizeText(record.petWithBiteHistory),
    discounts,
  };
}

export class AceHomeApplicantProvider {
  public fromFixture(metadata: LegacyTestMetadata, selected: SelectedCase | undefined): SelectedAceHomeApplicant {
    if (!selected) throw new Error(`Missing AceHome fixture row for ${metadata.legacyId}`);
    if (selected.source !== 'AceHomeTestData') throw new Error(`Wrong AceHome fixture source: ${selected.source}`);
    const record = selected.data;
    const id = normalizeNumber(record.id);
    if (!id) throw new Error(`Selected AceHome applicant has empty id for ${metadata.legacyId}`);
    const children = Array.isArray(record.discounts) ? (record.discounts as DataRecord[]) : [];
    const applicant = mapApplicant(record, children.map(mapDiscount));
    if (applicant.stateCode.toUpperCase() !== selected.state)
      throw new Error(`State mismatch for ${metadata.legacyId}`);
    return {
      workbook: `${selected.source}.json`,
      worksheet: selected.sheet,
      rowNumber: 0,
      seed: 0,
      correlationId: `${metadata.legacyId}:${selected.sourceId}:${selected.state}`,
      applicant,
    };
  }
}
