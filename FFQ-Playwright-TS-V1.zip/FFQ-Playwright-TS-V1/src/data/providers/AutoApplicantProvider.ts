import type { LegacyTestMetadata } from '../../migration/LegacyTestMetadata.js';
import type { SelectedCase } from '../LegacyProviderSelector.js';
import type { DataRecord } from '../FixtureCatalog.js';
import type {
  AutoAdditionalDriver,
  AutoApplicant,
  AutoDiscount,
  AutoIncident,
  AutoPayment,
  AutoVehicle,
  SelectedAutoApplicant,
} from '../../models/auto/AutoApplicant.js';

type FixtureRecord = DataRecord;

function formatDate(value: Date): string {
  const mm = String(value.getMonth() + 1).padStart(2, '0');
  const dd = String(value.getDate()).padStart(2, '0');
  const yyyy = String(value.getFullYear());
  return `${mm}/${dd}/${yyyy}`;
}

function asString(value: unknown): string {
  if (value instanceof Date) {
    return formatDate(value);
  }
  if (typeof value === 'object' && value !== null) {
    const record = value as Record<string, unknown>;
    if ('text' in record && typeof record.text === 'string') {
      return record.text.trim();
    }
    if ('result' in record) {
      return asString(record.result);
    }
  }
  return String(value ?? '').trim();
}

function asNumber(value: unknown): number {
  const parsed = Number(asString(value));
  return Number.isFinite(parsed) ? parsed : 0;
}

function asBoolean(value: unknown): boolean {
  const normalized = asString(value).toLowerCase();
  return normalized === 'true' || normalized === 'yes' || normalized === 'y' || normalized === '1';
}

function mapVehicle(record: FixtureRecord): AutoVehicle {
  return {
    vehicleId: asNumber(record.vehicleId),
    applicantId: asNumber(record.applicantId),
    vehicleStateCode: asString(record.vehicleStateCode),
    vehicleYear: asString(record.vehicleYear),
    vehicleMake: asString(record.vehicleMake),
    vehicleModel: asString(record.vehicleModel),
    vehicleVIN: asString(record.vehicleVIN),
    vehicleType: asString(record.vehicleType),
    ownership: asString(record.ownership),
    purchaseDate: asString(record.purchaseDate),
    vehicleUsage: asString(record.vehicleUsage),
    oneWayMiles: asString(record.oneWayMiles),
    commute: asString(record.commute),
    annualMiles: asString(record.annualMiles),
    parkInresidentAddress: asBoolean(record.parkInresidentAddress ?? record.parkInResidentAddress),
    rideSharing: asBoolean(record.rideSharing),
    alternativeFuels: asBoolean(record.alternativeFuels),
    antiTheftDevice: asString(record.antiTheftDevice),
    passiveRestraint: asString(record.passiveRestraint),
    airBagSeatBelt: asString(record.airBagSeatBelt),
    antiLockBrakes: asString(record.antiLockBrakes),
    stabilityControl: asString(record.stabilityControl),
    daytimeLights: asString(record.daytimeLights),
    theftRecoverySystem: asString(record.theftRecoverySystem),
    vinEtching: asBoolean(record.vinEtching),
    lessorStateName: asString(record.lessorStateName),
    lessor: asString(record.lessor),
    currentOdometerReading: asString(record.currentOdometerReading),
    dateOfReading: asString(record.dateOfReading),
    useVIN: asBoolean(record.useVIN),
    garagingAddress: asString(record.garagingAddress),
    garagingApt: asString(record.garagingApt),
    garagingCity: asString(record.garagingCity),
    garagingZip: asString(record.garagingZip),
    mediaAlphaModel: asString(record.mediaAlphaModel),
    submodel: asString(record.submodel),
    mediaAlphaAnnualMiles: asString(record.mediaAlphaAnnualMiles),
    collisionDeductible: asString(record.collisionDeductible),
    comprehensiveDeductible: asString(record.comprehensiveDeductible),
  };
}

function mapAdditionalDriver(record: FixtureRecord): AutoAdditionalDriver {
  return {
    additionalDriverId: asNumber(record.additionalDriverId),
    applicantId: asNumber(record.applicantId),
    incidentId: asNumber(record.incidentId),
    firstName: asString(record.firstName),
    lastName: asString(record.lastName),
    age: asNumber(record.age),
    dateOfBirth: asString(record.dateOfBirth),
    relationshipToApplicant: asString(record.relationshipToApplicant),
    maritalStatus: asString(record.maritalStatus),
    gender: asString(record.gender),
    occupation: asString(record.occupation),
    otherOccupation: asString(record.otherOccupation),
    licenseToDriveInUSA: asString(record.licenseToDriveInUSA),
    firstAgeUnitedStatesDriverLicense: asNumber(record.firstAgeUnitedStatesDriverLicense),
    firstAgeForeignDriverLicense: asNumber(record.firstAgeForeignDriverLicense),
    fullTimeStudentWithHighGPA: asBoolean(record.fullTimeStudentWithHighGPA),
    attendsDistantSchool: asBoolean(record.attendsDistantSchool),
    completedDriversSafetyCourse: asBoolean(record.completedDriversSafetyCourse),
    financialFiling: asString(record.financialFiling),
    anyIncident: asBoolean(record.anyIncident),
    driversLicense: asString(record.driversLicense),
    licenseIssueStateName: asString(record.licenseIssueStateName),
    mediaAlphaCurrentlyInsured: asString(record.mediaAlphaCurrentlyInsured),
    signalMobilePhone: asString(record.signalMobilePhone),
  };
}

function mapIncident(record: FixtureRecord): AutoIncident {
  return {
    incidentId: asNumber(record.incidentId),
    applicantId: asNumber(record.applicantId),
    additionalDriverId: asNumber(record.additionalDriverId),
    incidentType: asString(record.incidentType),
    description: asString(record.description),
    dateOccuredOffsetInDays: asString(record.dateOccuredOffsetInDays),
    dateOccured: asString(record.dateOccured),
    anyInjuries: asBoolean(record.anyInjuries),
    mediaAlphaIncidentType: asString(record.mediaAlphaIncidentType),
    mediaAlphaIncidentDescription: asString(record.mediaAlphaIncidentDescription),
    mediaAlphaAmountPaidByInsurance: asString(record.mediaAlphaAmountPaidByInsurance),
    mediaAlphaDamageTo: asString(record.mediaAlphaDamageTo),
    mediaAlphaDriverAtFault: asString(record.mediaAlphaDriverAtFault),
  };
}

function mapDiscount(record: FixtureRecord): AutoDiscount {
  return {
    discountId: asNumber(record.discountId),
    applicantId: asNumber(record.applicantId),
    paymentMethod: asString(record.paymentMethod),
    startDateOfNewPolicy: asString(record.startDateOfNewPolicy),
    homeInsurance: asBoolean(record.homeInsurance),
    rentersInsurance: asBoolean(record.rentersInsurance),
    condoInsurance: asBoolean(record.condoInsurance),
    valueTermLifeInsurance: asBoolean(record.valueTermLifeInsurance),
    umbrellaInsurance: asBoolean(record.umbrellaInsurance),
    businessInsurance: asBoolean(record.businessInsurance),
    ownOrRentHome: asString(record.ownOrRentHome),
    paymentMethodForDiscount: asString(record.paymentMethodForDiscount),
    mediaAlphaTimeAtResidence: asString(record.mediaAlphaTimeAtResidence),
    mediaAlphaHasGarage: asString(record.mediaAlphaHasGarage),
    signalSignup: asBoolean(record.signalSignup),
  };
}

function mapPayment(record: FixtureRecord): AutoPayment {
  return {
    paymentId: asNumber(record.paymentId),
    applicantId: asNumber(record.applicantId),
    paymentPlan: asString(record.paymentPlan),
    paymentMethod: asString(record.paymentMethod),
    accountHolderName: asString(record.accountHolderName),
    routingNumber: asString(record.routingNumber),
    bankAccountNumber: asString(record.bankAccountNumber),
    bankName: asString(record.bankName),
    creditCardType: asString(record.creditCardType),
    debitCardType: asString(record.debitCardType),
    nameOnCard: asString(record.nameOnCard),
    cardNumber: asString(record.cardNumber),
    expirationDate: asString(record.expirationDate),
    billingZipCode: asString(record.billingZipCode),
  };
}

function children(value: unknown): DataRecord[] {
  return Array.isArray(value) ? value.filter((row): row is DataRecord => typeof row === 'object' && row !== null) : [];
}

export class AutoApplicantProvider {
  public fromFixture(metadata: LegacyTestMetadata, selected: SelectedCase | undefined): SelectedAutoApplicant {
    if (!selected) throw new Error(`Missing Auto fixture row for ${metadata.legacyId}`);
    if (selected.source !== 'OneUIAutoTestData' && selected.source !== 'AutoTestData')
      throw new Error(`Wrong Auto fixture source: ${selected.source}`);
    const record = selected.data;
    const selectedApplicantId = asNumber(record.applicantId);
    if (!selectedApplicantId) throw new Error(`Selected Auto applicant has empty applicantId for ${metadata.legacyId}`);
    const applicant: AutoApplicant = {
      applicantId: selectedApplicantId,
      testCategory: asString(record.testCategory),
      testScenario: asString(record.testScenario),
      gender: asString(record.gender),
      residentAddress1: asString(record.residentAddress1),
      residentAddress2: asString(record.residentAddress2),
      city: asString(record.city),
      zipCode: asString(record.zipCode),
      stateCode: asString(record.stateCode),
      stateName: asString(record.stateName),
      maritalStatus: asString(record.maritalStatus),
      occupation: asString(record.occupation),
      currentlyInsuredStatus: asString(record.currentlyInsuredStatus),
      currentInsuranceCompany: asString(record.currentInsuranceCompany),
      continuosInsurancePeriod: asString(record.continuosInsurancePeriod),
      currentBodilyInjuryLimit: asString(record.currentBodilyInjuryLimit),
      financialFiling: asString(record.financialFiling),
      firstName: asString(record.firstName),
      lastName: asString(record.lastName),
      age: asNumber(record.age),
      otherOccupation: asString(record.otherOccupation),
      dateOfBirth: asString(record.dateOfBirth),
      mailingAddressDifferent: asBoolean(record.mailingAddressDifferent),
      currentlyHaveAutoInsurance: asString(record.currentlyHaveAutoInsurance),
      principalPIP: asString(record.principalPIP),
      firstAgeUnitedStatesDriverLicense: asNumber(record.firstAgeUnitedStatesDriverLicense),
      firstAgeForeignDriverLicense: asNumber(record.firstAgeForeignDriverLicense),
      fullTimeStudentWithHighGPA: asBoolean(record.fullTimeStudentWithHighGPA),
      email: asString(record.email),
      phoneNumber: asString(record.phoneNumber),
      phoneExtentionNumber: asString(record.phoneExtentionNumber),
      knockoutExpected: asBoolean(record.knockoutExpected),
      completedDriversSafetyCourse: asBoolean(record.completedDriversSafetyCourse),
      havePersonalInjuryLoss: asBoolean(record.havePersonalInjuryLoss),
      haveAccidentOrViolations: asBoolean(record.haveAccidentOrViolations),
      currentInsuranceExpirationDate: asString(record.currentInsuranceExpirationDate),
      driversLicense: asString(record.driversLicense),
      licenseIssueStateName: asString(record.licenseIssueStateName),
      attemptToBind: asString(record.attemptToBind),
      garagingAddress: asString(record.garagingAddress),
      vehicles: Object.freeze(children(record.vehicles).map(mapVehicle)),
      additionalDrivers: Object.freeze(children(record.additionalDrivers).map(mapAdditionalDriver)),
      incidents: Object.freeze(children(record.incidents).map(mapIncident)),
      discounts: Object.freeze(children(record.discounts).map(mapDiscount)),
      payments: Object.freeze(children(record.payments).map(mapPayment)),
    };

    if (applicant.stateCode.toUpperCase() !== selected.state)
      throw new Error(`State mismatch for ${metadata.legacyId}`);
    return {
      workbook: `${selected.source}.json`,
      worksheet: selected.sheet,
      rowNumber: 0,
      correlationId: `${metadata.legacyId}:${selected.sourceId}:${selected.state}`,
      applicant,
    };
  }
}
