import { resolve } from 'node:path';
import ExcelJS from 'exceljs';

export type ExcelRecord = Readonly<Record<string, unknown>>;

export class ExcelDataSource {
  public constructor(private readonly dataRoot = resolve('data')) {}

  public async rows(fileName: string, worksheetName: string): Promise<ExcelRecord[]> {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(resolve(this.dataRoot, fileName));
    const worksheet = workbook.getWorksheet(worksheetName);
    if (!worksheet) {
      throw new Error(`Worksheet ${worksheetName} was not found in ${fileName}.`);
    }
    const headerValues = worksheet.getRow(1).values;
    const headers: string[] = (Array.isArray(headerValues) ? headerValues : [])
      .slice(1)
      .map((value) => String(value ?? '').trim());
    const records: ExcelRecord[] = [];
    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return;
      const record: Record<string, unknown> = {};
      let hasValue = false;
      headers.forEach((header: string, index: number) => {
        if (!header) return;
        const value = row.getCell(index + 1).value;
        if (value !== null && value !== undefined && value !== '') hasValue = true;
        record[header] = value;
      });
      if (hasValue) records.push(Object.freeze(record));
    });
    return records;
  }

  public filter(rows: readonly ExcelRecord[], expression: string): ExcelRecord[] {
    if (!expression.trim()) return [...rows];
    const clauses = expression.split(',').map((clause) => clause.trim());
    return rows.filter((row) =>
      clauses.every((clause) => {
        const [key, ...valueParts] = clause.split('=');
        if (!key || valueParts.length === 0) throw new Error(`Invalid filter: ${clause}`);
        return String(row[key] ?? '').trim() === valueParts.join('=').trim();
      }),
    );
  }
}
