// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.AddressInformationPage. */
export class AddressInformationPage extends CoreBasePage {
  public readonly addressPageTitle: Locator;
  public readonly addressEntryField: Locator;
  public readonly addressEntryFieldErrorLabel: Locator;
  public readonly unitNumberEntryField: Locator;
  public readonly unitNumberHintLabel: Locator;
  public readonly propertyLossesLabel: Locator;
  public readonly noPropertyLossesButton: Locator;
  public readonly noPropertyLossesButtonLabel: Locator;
  public readonly onePropertyLossButton: Locator;
  public readonly onePropertyLossButtonLabel: Locator;
  public readonly twoOrMorePropertyLossesButton: Locator;
  public readonly twoOrMorePropertyLossesButtonLabel: Locator;
  public readonly creditReportDisclaimer: Locator;
  public readonly ctaDisclaimer: Locator;
  public readonly requiredFieldsErrorLabel: Locator;
  public readonly continueButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.addressPageTitle = page.locator(".personal-info_address_h1"); // @FindBy(className = "personal-info_address_h1")
    this.addressEntryField = page.locator("xpath=//address-autocomplete-input//input"); // @FindBy(xpath = "//address-autocomplete-input//input")
    this.addressEntryFieldErrorLabel = page.locator("xpath=//address-autocomplete-input//mat-error"); // @FindBy(xpath = "//address-autocomplete-input//mat-error")
    this.unitNumberEntryField = page.locator("xpath=//div[@id='formField_apartment']//input"); // @FindBy(xpath = "//div[@id='formField_apartment']//input")
    this.unitNumberHintLabel = page.locator("xpath=//div[@id='formField_apartment']//mat-hint"); // @FindBy(xpath = "//div[@id='formField_apartment']//mat-hint")
    this.propertyLossesLabel = page.locator("xpath=//div[@id='formField_noOfPropertyLosses']//label"); // @FindBy(xpath = "//div[@id='formField_noOfPropertyLosses']//label")
    this.noPropertyLossesButton = page.locator("[data-legacy-field=\"noPropertyLossesButton\"]"); // @FindBy(xpath = PROPERTY_LOSSES_GROUP_XPATH + BUTTON_ONE)
    this.noPropertyLossesButtonLabel = page.locator("[data-legacy-field=\"noPropertyLossesButtonLabel\"]"); // @FindBy(xpath = PROPERTY_LOSSES_GROUP_XPATH + BUTTON_ONE + XPATH_TO_BUTTON_LABEL)
    this.onePropertyLossButton = page.locator("[data-legacy-field=\"onePropertyLossButton\"]"); // @FindBy(xpath = PROPERTY_LOSSES_GROUP_XPATH + BUTTON_TWO)
    this.onePropertyLossButtonLabel = page.locator("[data-legacy-field=\"onePropertyLossButtonLabel\"]"); // @FindBy(xpath = PROPERTY_LOSSES_GROUP_XPATH + BUTTON_TWO + XPATH_TO_BUTTON_LABEL)
    this.twoOrMorePropertyLossesButton = page.locator("[data-legacy-field=\"twoOrMorePropertyLossesButton\"]"); // @FindBy(xpath = PROPERTY_LOSSES_GROUP_XPATH + BUTTON_THREE)
    this.twoOrMorePropertyLossesButtonLabel = page.locator("[data-legacy-field=\"twoOrMorePropertyLossesButtonLabel\"]"); // @FindBy(xpath = PROPERTY_LOSSES_GROUP_XPATH + BUTTON_THREE + XPATH_TO_BUTTON_LABEL)
    this.creditReportDisclaimer = page.locator("xpath=//div[contains(@class, 'disclaimer__credit-report')]"); // @FindBy(xpath = "//div[contains(@class, 'disclaimer__credit-report')]")
    this.ctaDisclaimer = page.locator("xpath=//div[contains(@class, 'disclaimer__color')]"); // @FindBy(xpath = "//div[contains(@class, 'disclaimer__color')]")
    this.requiredFieldsErrorLabel = page.locator("xpath=//p[contains(@class, 'multiple-fields-missing')]"); // @FindBy(xpath = "//p[contains(@class, 'multiple-fields-missing')]")
    this.continueButton = page.locator("xpath=//div[@class='address-form__continue-button']/button"); // @FindBy(xpath = "//div[@class='address-form__continue-button']/button")
  }
}
