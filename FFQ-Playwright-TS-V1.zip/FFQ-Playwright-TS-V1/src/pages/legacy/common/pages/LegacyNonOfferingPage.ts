// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.LegacyNonOfferingPage. */
export class LegacyNonOfferingPage extends CoreBasePage {
  public readonly mainArea: Locator;
  public readonly intro: Locator;
  public readonly notOfferedHeader: Locator;
  public readonly farmersDirectPage: Locator;
  public readonly mediaAlphaHeader: Locator;
  public readonly quotingUnavailableText: Locator;
  public readonly quotingTemporarilyUnavailableHeader: Locator;

  public constructor(page: Page) {
    super(page);
    this.mainArea = page.locator("[data-legacy-field=\"mainArea\"]"); // @FindBy(id = MAIN_AREA_ID)
    this.intro = page.locator("[data-legacy-field=\"intro\"]"); // @FindBy(id = BOX_AREA_ID)
    this.notOfferedHeader = page.locator("[data-legacy-field=\"notOfferedHeader\"]"); // @FindBy(id = NOT_OFFERED_HEADER_ID)
    this.farmersDirectPage = page.locator("[data-legacy-field=\"farmersDirectPage\"]"); // @FindBy(id = FARMERS_DIRECT_PAGE_ID)
    this.mediaAlphaHeader = page.locator("[data-legacy-field=\"mediaAlphaHeader\"]"); // @FindBy(id = MEDIA_ALPHA_HEADER_ID)
    this.quotingUnavailableText = page.locator("[data-legacy-field=\"quotingUnavailableText\"]"); // @FindBy(id = QUOTE_UNAVAILABLE_CONTENT_ID)
    this.quotingTemporarilyUnavailableHeader = page.locator("[data-legacy-field=\"quotingTemporarilyUnavailableHeader\"]"); // @FindBy(id = QUOTES_TEMPORARILY_UNAVAILABLE_ID)
  }
}
