// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.MediaAlphaStartPage. */
export class MediaAlphaStartPage extends CoreBasePage {
  public readonly zipCode: Locator;
  public readonly startMyQuoteButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.zipCode = page.locator("xpath=//div[@id='main-panel']//form[@id='zip-form']//input[@name='zip']"); // @FindBy(xpath = "//div[@id='main-panel']//form[@id='zip-form']//input[@name='zip']")
    this.startMyQuoteButton = page.locator("xpath=//div[@id='main-panel']//form[@id='zip-form']//button[contains(text(),'Start My Quote')]"); // @FindBy(xpath = "//div[@id='main-panel']//form[@id='zip-form']//button[contains(text(),'Start My Quote')]")
  }
}
