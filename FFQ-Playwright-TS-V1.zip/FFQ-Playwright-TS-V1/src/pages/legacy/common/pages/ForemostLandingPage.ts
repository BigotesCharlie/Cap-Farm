// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.ForemostLandingPage. */
export class ForemostLandingPage extends CoreBasePage {
  public readonly foremostTitle: Locator;
  public readonly foremostSubtitle: Locator;
  public readonly foremostLogo: Locator;
  public readonly foremostDescription: Locator;
  public readonly requestAQuoteLabel: Locator;
  public readonly foremostContinueButton: Locator;
  public readonly preferToCallLabel: Locator;
  public readonly foremostContactButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.foremostTitle = page.locator("xpath=//h1[@id='foremost_title']"); // @FindBy(xpath = "//h1[@id='foremost_title']")
    this.foremostSubtitle = page.locator("xpath=(//div[contains(@class, 'content-rebrand')])[1]"); // @FindBy(xpath = "(//div[contains(@class, 'content-rebrand')])[1]")
    this.foremostLogo = page.locator("xpath=//app-foremost-interstitial//mat-card//img"); // @FindBy(xpath = "//app-foremost-interstitial//mat-card//img")
    this.foremostDescription = page.locator("xpath=//div[contains(@class,'foremost_description')]"); // @FindBy(xpath = "//div[contains(@class,'foremost_description')]")
    this.requestAQuoteLabel = page.locator("xpath=//div[@aria-labelledby='Request a quote']"); // @FindBy(xpath = "//div[@aria-labelledby='Request a quote']")
    this.foremostContinueButton = page.locator("xpath=//button[contains(@class,'foremost_continue_button')]"); // @FindBy(xpath = "//button[contains(@class,'foremost_continue_button')]")
    this.preferToCallLabel = page.locator("xpath=//div[@aria-labelledby='prefer to call?']"); // @FindBy(xpath = "//div[@aria-labelledby='prefer to call?']")
    this.foremostContactButton = page.locator("xpath=//button[contains(@class,'foremost-rebrand-call-btn')]"); // @FindBy(xpath = "//button[contains(@class,'foremost-rebrand-call-btn')]")
  }
}
