// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.PolicyBankPayment. */
export class PolicyBankPayment extends CoreBasePage {
  public readonly bankAccountTypeHeader: Locator;
  public readonly checkingRadioButton: Locator;
  public readonly checkingRadioButtonInput: Locator;
  public readonly checkingLabel: Locator;
  public readonly savingsRadioButton: Locator;
  public readonly businessCheckingRadioButton: Locator;
  public readonly accountHolderNameLabel: Locator;
  public readonly bankRoutingNumberLabel: Locator;
  public readonly routingNumberInputField: Locator;
  public readonly accountNumberLabel: Locator;
  public readonly accountNumberInputField: Locator;
  public readonly confirmAccountNumberLabel: Locator;
  public readonly confirmBankAccountInputField: Locator;
  public readonly greenCheckMark: Locator;
  public readonly noServiceChargeWhenUsingBankTransfer: Locator;
  public readonly maskedAccountNumber: Locator;
  public readonly changeToNewPaymentMethodHeader: Locator;
  public readonly readAndAgreedToTheBulletPointTwoPayInFull: Locator;

  public constructor(page: Page) {
    super(page);
    this.bankAccountTypeHeader = page.locator("xpath=//legend[contains(text(), '"); // @FindBy(xpath = "//legend[contains(text(), '" + BANK_ACCOUNT_TYPE_HEADER + "')]")
    this.checkingRadioButton = page.locator("xpath=//fieldset//div/div[1]"); // @FindBy(xpath = "//fieldset//div/div[1]")
    this.checkingRadioButtonInput = page.locator("xpath=//fieldset//div/div[1]/input"); // @FindBy(xpath = "//fieldset//div/div[1]/input")
    this.checkingLabel = page.locator("xpath=//label[text() = '"); // @FindBy(xpath = "//label[text() = '" + CHECKING_LABEL + "']")
    this.savingsRadioButton = page.locator("xpath=//fieldset//div/div[2]"); // @FindBy(xpath = "//fieldset//div/div[2]")
    this.businessCheckingRadioButton = page.locator("xpath=//fieldset//div/div[3]"); // @FindBy(xpath = "//fieldset//div/div[3]")
    this.accountHolderNameLabel = page.locator("xpath=//label[text() = '"); // @FindBy(xpath = "//label[text() = '" + ACCOUNT_HOLDER_NAME_LABEL + "']")
    this.bankRoutingNumberLabel = page.locator("xpath=//label[text() = '"); // @FindBy(xpath = "//label[text() = '" + BANK_ROUTING_NUMBER + "']")
    this.routingNumberInputField = page.locator("xpath=//input[@id='routingNumberField']"); // @FindBy(xpath = "//input[@id='routingNumberField']")
    this.accountNumberLabel = page.locator("xpath=//label[text() = '"); // @FindBy(xpath = "//label[text() = '" + ACCOUNT_NUMBER + "']")
    this.accountNumberInputField = page.locator("xpath=//input[@id='bankAccountField']"); // @FindBy(xpath = "//input[@id='bankAccountField']")
    this.confirmAccountNumberLabel = page.locator("xpath=//label[text() = '"); // @FindBy(xpath = "//label[text() = '" + CONFIRM_ACCOUNT_NUMBER + "']")
    this.confirmBankAccountInputField = page.locator("xpath=//input[@id='confirmBankAccountField']"); // @FindBy(xpath = "//input[@id='confirmBankAccountField']")
    this.greenCheckMark = page.locator("xpath=//mat-icon[text() = '"); // @FindBy(xpath = "//mat-icon[text() = '" + CHECK_CIRCLE + "']")
    this.noServiceChargeWhenUsingBankTransfer = page.locator("xpath=//span[text() = '"); // @FindBy(xpath = "//span[text() = '" + NO_SERVICE_CHARGE_WHEN_USING_BANK + "']")
    this.maskedAccountNumber = page.locator("xpath=//*[@id='accountNumber']"); // @FindBy(xpath = "//*[@id='accountNumber']")
    this.changeToNewPaymentMethodHeader = page.locator("xpath=//span[contains(text(), 'Change to a new payment method')]"); // @FindBy(xpath = "//span[contains(text(), 'Change to a new payment method')]")
    this.readAndAgreedToTheBulletPointTwoPayInFull = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p")
  }
}
