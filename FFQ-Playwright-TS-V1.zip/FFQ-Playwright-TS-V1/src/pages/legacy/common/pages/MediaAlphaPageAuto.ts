// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.MediaAlphaPageAuto. */
export class MediaAlphaPageAuto extends CoreBasePage {
  public readonly carYear: Locator;
  public readonly checkBoxAlarm: Locator;
  public readonly radioPrimaryUseWork: Locator;
  public readonly radioPrimaryUsePleasure: Locator;
  public readonly selectAverageMileage: Locator;
  public readonly selectAnnualMileage: Locator;
  public readonly selectDeductibleCollision: Locator;
  public readonly selectDeductibleComprehensive: Locator;
  public readonly buttonSaveCar: Locator;
  public readonly buttonAddCar: Locator;
  public readonly radioCarLeasedYes: Locator;
  public readonly radioCarLeasedNo: Locator;
  public readonly streetAddress: Locator;
  public readonly aptUnit: Locator;
  public readonly selectHowLongLivedThere: Locator;
  public readonly cityStateZip: Locator;
  public readonly radioOwnedYes: Locator;
  public readonly radioOwnedNo: Locator;
  public readonly radioGarageYes: Locator;
  public readonly radioGarageNo: Locator;
  public readonly goToStep2Button: Locator;
  public readonly goToStep3Button: Locator;
  public readonly almostDoneButton: Locator;
  public readonly lastStepButton: Locator;
  public readonly currentlyInsuredCheckbox: Locator;
  public readonly goToLastStepButton: Locator;
  public readonly yourQuotesButton: Locator;
  public readonly spouseDropDown: Locator;
  public readonly childDropDown: Locator;
  public readonly otherDropDown: Locator;
  public readonly driverName: Locator;
  public readonly selectDriverGender: Locator;
  public readonly radioMarriedYes: Locator;
  public readonly radioMarriedNo: Locator;
  public readonly birthday: Locator;
  public readonly selectFirstLicensed: Locator;
  public readonly selectEducationLevel: Locator;
  public readonly selectPrimaryCar: Locator;
  public readonly selectCreditRating: Locator;
  public readonly selectOccupation: Locator;
  public readonly selectOccupationOptions: Locator;
  public readonly radioLicenseActive: Locator;
  public readonly radioLicenseSuspended: Locator;
  public readonly radioFileSR22Yes: Locator;
  public readonly radioFileSR22No: Locator;
  public readonly viewMyQuoteButton: Locator;
  public readonly email: Locator;
  public readonly phone: Locator;
  public readonly saveDriverButton: Locator;
  public readonly addDriverButton: Locator;
  public readonly currentInsuranceCompany: Locator;
  public readonly continuosCoverage: Locator;
  public readonly currentCustomer: Locator;
  public readonly currentPolicyExpires: Locator;
  public readonly radioMinimumCoverage: Locator;
  public readonly radioStandardCoverage: Locator;
  public readonly radioPremiumCoverage: Locator;
  public readonly incidentType: Locator;
  public readonly incidentDriver: Locator;
  public readonly incidentDate: Locator;
  public readonly ticketType: Locator;
  public readonly incidentDescription: Locator;
  public readonly incidentButtonAdd: Locator;
  public readonly accidentButtonYes: Locator;
  public readonly accidentButtonNo: Locator;
  public readonly redirectButton: Locator;
  public readonly proceedToFarmersButton: Locator;
  public readonly skipToContactLink: Locator;

  public constructor(page: Page) {
    super(page);
    this.carYear = page.locator("xpath=//table[@id='home-panel-content']//div[@id='car']"); // @FindBy(xpath = "//table[@id='home-panel-content']//div[@id='car']")
    this.checkBoxAlarm = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-alarm']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-alarm']")
    this.radioPrimaryUseWork = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-primary-use-work']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-primary-use-work']")
    this.radioPrimaryUsePleasure = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-primary-use-pleasure']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-primary-use-pleasure']")
    this.selectAverageMileage = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-average-mileage']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-average-mileage']")
    this.selectAnnualMileage = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-annual-mileage']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-annual-mileage']")
    this.selectDeductibleCollision = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-collision']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-collision']")
    this.selectDeductibleComprehensive = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-comprehensive']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-comprehensive']")
    this.buttonSaveCar = page.locator("xpath=//table[@id='home-panel-content']//button[@id='save-car']"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[@id='save-car']")
    this.buttonAddCar = page.locator("xpath=//table[@id='home-panel-content']//button[@id='add-car']"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[@id='add-car']")
    this.radioCarLeasedYes = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-car-leased-1']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-car-leased-1']")
    this.radioCarLeasedNo = page.locator("xpath=//table[@id='home-panel-content']//input[@id=''f-car-leased-0']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id=''f-car-leased-0']")
    this.streetAddress = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-address']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-address']")
    this.aptUnit = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-address2']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-address2']")
    this.selectHowLongLivedThere = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-home-length']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-home-length']")
    this.cityStateZip = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-city2']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-city2']")
    this.radioOwnedYes = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-type-own']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-type-own']")
    this.radioOwnedNo = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-type-rent']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-type-rent']")
    this.radioGarageYes = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-garage-yes']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-garage-yes']")
    this.radioGarageNo = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-garage-no']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-garage-no']")
    this.goToStep2Button = page.locator("xpath=//table[@id='home-panel-content']//button[contains(.,'go to step 2')]"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'go to step 2')]")
    this.goToStep3Button = page.locator("xpath=//table[@id='home-panel-content']//button[contains(.,'go to step 3')]"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'go to step 3')]")
    this.almostDoneButton = page.locator("xpath=//table[@id='home-panel-content']//button[contains(.,'almost done!')]"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'almost done!')]")
    this.lastStepButton = page.locator("xpath=//table[@id='home-panel-content']//button[contains(.,'last step')]"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'last step')]")
    this.currentlyInsuredCheckbox = page.locator("xpath=//table[@id='home-panel-content']//input[@name='currently_insured']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@name='currently_insured']")
    this.goToLastStepButton = page.locator("xpath=//table[@id='home-panel-content']//button[contains(.,'Go to Last Step')]"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'Go to Last Step')]")
    this.yourQuotesButton = page.locator("xpath=//table[@id='home-panel-content']//button[contains(.,'Get Your Quotes')]"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'Get Your Quotes')]")
    this.spouseDropDown = page.locator("xpath=//li[@id='add-spouse']"); // @FindBy(xpath = "//li[@id='add-spouse']")
    this.childDropDown = page.locator("xpath=//li[contains(@onclick,'child')]"); // @FindBy(xpath = "//li[contains(@onclick,'child')]")
    this.otherDropDown = page.locator("xpath=//li[contains(@onclick,'other')]"); // @FindBy(xpath = "//li[contains(@onclick,'other')]")
    this.driverName = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-driver-name']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-driver-name']")
    this.selectDriverGender = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-gender']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-gender']")
    this.radioMarriedYes = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-married-yes']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-married-yes']")
    this.radioMarriedNo = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-married-no']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-married-no']")
    this.birthday = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-birthday']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-birthday']")
    this.selectFirstLicensed = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-first-licensed']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-first-licensed']")
    this.selectEducationLevel = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-education']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-education']")
    this.selectPrimaryCar = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-primary-car']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-primary-car']")
    this.selectCreditRating = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-credit-rating']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-credit-rating']")
    this.selectOccupation = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-occupation']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-occupation']")
    this.selectOccupationOptions = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-occupation']//option"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-occupation']//option")
    this.radioLicenseActive = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-license-active']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-license-active']")
    this.radioLicenseSuspended = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-license-suspended']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-license-suspended']")
    this.radioFileSR22Yes = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-sr-22-yes']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-sr-22-yes']")
    this.radioFileSR22No = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-sr-22-no']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-sr-22-no']")
    this.viewMyQuoteButton = page.locator("xpath=//button[@data-cb-id='button_cta' and contains(.,'View My Quote')]"); // @FindBy(xpath = "//button[@data-cb-id='button_cta' and contains(.,'View My Quote')]")
    this.email = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-email']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-email']")
    this.phone = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-phone']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-phone']")
    this.saveDriverButton = page.locator("xpath=//table[@id='home-panel-content']//button[@id='save-driver']"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[@id='save-driver']")
    this.addDriverButton = page.locator("xpath=//table[@id='home-panel-content']//button[@id='add-driver']"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[@id='add-driver']")
    this.currentInsuranceCompany = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-current-company']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-current-company']")
    this.continuosCoverage = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-continuous-coverage']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-continuous-coverage']")
    this.currentCustomer = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-current-customer']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-current-customer']")
    this.currentPolicyExpires = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-current-policy-expires']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-current-policy-expires']")
    this.radioMinimumCoverage = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-coverage-minimum']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-coverage-minimum']")
    this.radioStandardCoverage = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-coverage-standard']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-coverage-standard']")
    this.radioPremiumCoverage = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-coverage-super']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-coverage-super']")
    this.incidentType = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-incident-type']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-incident-type']")
    this.incidentDriver = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-incident-driver']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-incident-driver']")
    this.incidentDate = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-incident-date']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-incident-date']")
    this.ticketType = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-ticket-type']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-ticket-type']")
    this.incidentDescription = page.locator("xpath=//table[@id='home-panel-content']//select[@id='f-incident-description']"); // @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-incident-description']")
    this.incidentButtonAdd = page.locator("xpath=//table[@id='home-panel-content']//button[@id='add-incident']"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[@id='add-incident']")
    this.accidentButtonYes = page.locator("xpath=//table[@id='home-panel-content']//button[contains(.,'Yes')]"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'Yes')]")
    this.accidentButtonNo = page.locator("xpath=//table[@id='home-panel-content']//button[contains(.,'No')]"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'No')]")
    this.redirectButton = page.locator("xpath=//button[@id='redirect-btn'][1]"); // @FindBy(xpath = "//button[@id='redirect-btn'][1]")
    this.proceedToFarmersButton = page.locator("xpath=//button[contains(@class,'mainForm__button')]"); // @FindBy(xpath = "//button[contains(@class,'mainForm__button')]")
    this.skipToContactLink = page.locator("xpath=//a[text()='Skip to contact']"); // @FindBy(xpath = "//a[text()='Skip to contact']")
  }
}
