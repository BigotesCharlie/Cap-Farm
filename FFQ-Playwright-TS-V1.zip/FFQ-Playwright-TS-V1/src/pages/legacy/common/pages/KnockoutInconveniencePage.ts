// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.KnockoutInconveniencePage. */
export class KnockoutInconveniencePage extends CoreBasePage {
  public readonly thankYouForYourInterestPage: Locator;
  public readonly inconvenienceTitle: Locator;
  public readonly inconvenienceHeaderTitle: Locator;
  public readonly quoteUnavailablePageTitle: Locator;
  public readonly knockoutTitle: Locator;
  public readonly foremostKnockoutPageTitle: Locator;
  public readonly foremostKnockoutMessage: Locator;
  public readonly foremostKnockoutQuoteReferenceMessage: Locator;
  public readonly foremostKnockoutClosingMessage: Locator;
  public readonly knockoutDescription: Locator;
  public readonly FGIAknockoutDescription: Locator;
  public readonly inconvenienceDescription: Locator;
  public readonly continueToFGIAButton: Locator;
  public readonly agreeAndContinueButtonFGIA: Locator;
  public readonly fgiaPageHeader: Locator;
  public readonly farmersLink: Locator;
  public readonly koQuoteNumberReference: Locator;
  public readonly koQuoteNumberReference_fgia: Locator;
  public readonly quoteNumberReference: Locator;
  public readonly monetizationButtons: Locator;
  public readonly quoteReferenceText: Locator;
  public readonly quoteNumberInKO: Locator;
  public readonly needMoreHelp: Locator;
  public readonly youCanCallCustomerService: Locator;
  public readonly youCanLabelElement: Locator;
  public readonly tryAgain: Locator;
  public readonly existingCustomerCTA: Locator;
  public readonly yourAgent: Locator;
  public readonly agentsTitle: Locator;
  public readonly agentList: Locator;
  public readonly agentContactButtons: Locator;
  public readonly agentName: Locator;
  public readonly agentsContactButtons: Locator;
  public readonly contactMeButton: Locator;
  public readonly tollFreeNumber: Locator;
  public readonly tollFreeNumber2: Locator;
  public readonly bitMoreInfoAboutVehicleKOMessage: Locator;
  public readonly agentsImage: Locator;
  public readonly agentFullNameWebElement: Locator;
  public readonly leasLoanKnockOutMessage: Locator;
  public readonly startMyQuoteButtonsOnMonetizationKOPage: Locator;
  public readonly doesntOfferBusinessTollNumberDesktop: Locator;
  public readonly doesntOfferBusinessTollNumberMobile: Locator;
  public readonly findFarmersAgent: Locator;
  public readonly koTitleText: Locator;
  public readonly koDescriptionText: Locator;
  public readonly agentImage: Locator;
  public readonly agentNameKOPage: Locator;
  public readonly agentDetailsText: Locator;
  public readonly agentEmail: Locator;
  public readonly agentPhoneDesktop: Locator;
  public readonly agentPhoneMobile: Locator;
  public readonly scheduleAppointment: Locator;
  public readonly agentAddress: Locator;
  public readonly needMoreHelpDigitalMonetization: Locator;
  public readonly callCustomerServiceDigitalMonetization: Locator;
  public readonly tollFreeDigitalMonetization: Locator;
  public readonly fgiaSubtitle: Locator;
  public readonly fgiaCantOfferText: Locator;
  public readonly fgiaPageContents: Locator;
  public readonly fgiaSoundGoodText: Locator;
  public readonly fgiaTabBelowToContinueText: Locator;
  public readonly fgiaReferenceYourQuoteText: Locator;
  public readonly quoteNumberInKO_FGIA: Locator;

  public constructor(page: Page) {
    super(page);
    this.thankYouForYourInterestPage = page.locator("xpath=//app-knockout-lead-form"); // @FindBy(xpath = "//app-knockout-lead-form")
    this.inconvenienceTitle = page.locator("h1[class='tui-h1 inconvenience__title']"); // @FindBy(css = "h1[class='tui-h1 inconvenience__title']")
    this.inconvenienceHeaderTitle = page.locator("#inconvenience_header-title"); // @FindBy(id = "inconvenience_header-title")
    this.quoteUnavailablePageTitle = page.locator("div[id='quote_unavailable_header-title']>h1"); // @FindBy(css = "div[id='quote_unavailable_header-title']>h1")
    this.knockoutTitle = page.locator("#knockout_title"); // @FindBy(id = "knockout_title"),             @FindBy(id = "heading-rebrand")     })
    this.foremostKnockoutPageTitle = page.locator("xpath=//*[contains(@class, 'mobilehome-knockout__title')]"); // @FindBy(xpath = "//*[contains(@class, 'mobilehome-knockout__title')]")
    this.foremostKnockoutMessage = page.locator("xpath=//*[contains(@class, 'mobilehome-knockout__message')]"); // @FindBy(xpath = "//*[contains(@class, 'mobilehome-knockout__message')]")
    this.foremostKnockoutQuoteReferenceMessage = page.locator("xpath=//*[contains(@class, 'mobilehome-knockout__quote-reference')]"); // @FindBy(xpath = "//*[contains(@class, 'mobilehome-knockout__quote-reference')]")
    this.foremostKnockoutClosingMessage = page.locator("xpath=//*[contains(@class, 'mobilehome-knockout__closing')]"); // @FindBy(xpath = "//*[contains(@class, 'mobilehome-knockout__closing')]")
    this.knockoutDescription = page.locator("p[class='tui-body']"); // @FindBy(css = "p[class='tui-body']")
    this.FGIAknockoutDescription = page.locator("xpath=//app-fgia-knockout//p[contains(@class,'tui-stacking-top')]"); // @FindBy(xpath = "//app-fgia-knockout//p[contains(@class,'tui-stacking-top')]")
    this.inconvenienceDescription = page.locator("span[class='tui-body']"); // @FindBy(css = "span[class='tui-body']")
    this.continueToFGIAButton = page.locator("button[class='tui-btn tui-btn-primary continue-cta']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary continue-cta']")
    this.agreeAndContinueButtonFGIA = page.locator("button[data-test-id='AGREE_AND_CONTINUE_BRANDING_BUTTON']"); // @FindBy(css = "button[data-test-id='AGREE_AND_CONTINUE_BRANDING_BUTTON']")
    this.fgiaPageHeader = page.locator("#pg_intro_title"); // @FindBy(id = "pg_intro_title")
    this.farmersLink = page.locator("xpath=//a[.='Farmers.com']"); // @FindBy(xpath = "//a[.='Farmers.com']")
    this.koQuoteNumberReference = page.locator("xpath=//div[contains(@class,'knockout__quote-number')]//span[1]"); // @FindBy(xpath = "//div[contains(@class,'knockout__quote-number')]//span[1]")
    this.koQuoteNumberReference_fgia = page.locator("xpath=//div[contains(@class,'quote-details')]//p"); // @FindBy(xpath = "//div[contains(@class,'quote-details')]//p")
    this.quoteNumberReference = page.locator("xpath=//div[contains(@class,'knockout__quote-number')]"); // @FindBy(xpath = "//div[contains(@class,'knockout__quote-number')]")
    this.monetizationButtons = page.locator("button[class='mav-partner__button']"); // @FindBy(css = "button[class='mav-partner__button']")
    this.quoteReferenceText = page.locator("xpath=//div[contains(@class,'inconvenience__quote-number')]//span[@class='tui-body']"); // @FindBy(xpath = "//div[contains(@class,'inconvenience__quote-number')]//span[@class='tui-body']")
    this.quoteNumberInKO = page.locator("xpath=//div[contains(@class,'quote-number')]//span[@class='tui-body-bold']"); // @FindBy(xpath = "//div[contains(@class,'quote-number')]//span[@class='tui-body-bold']")
    this.needMoreHelp = page.locator("xpath=//div/div[contains(.,'Need more help?')]"); // @FindBy(xpath = "//div/div[contains(.,'Need more help?')]")
    this.youCanCallCustomerService = page.locator("xpath=//div/div[contains(.,'You can call customer service at')]"); // @FindBy(xpath = "//div/div[contains(.,'You can call customer service at')]")
    this.youCanLabelElement = page.locator("xpath=//div/div[2][contains(@class, 'knockout__no-agent-text')]"); // @FindBy(xpath = "//div/div[2][contains(@class, 'knockout__no-agent-text')]")
    this.tryAgain = page.locator("xpath=//div[contains(@class,'inconvenience__cta')]"); // @FindBy(xpath = "//div[contains(@class,'inconvenience__cta')]")
    this.existingCustomerCTA = page.locator("div[class='existingCustomer__cta ng-star-inserted']>button"); // @FindBy(css = "div[class='existingCustomer__cta ng-star-inserted']>button")
    this.yourAgent = page.locator("xpath=//div[contains(text(),'"); // @FindBy(xpath = "//div[contains(text(),'" + YOUR_AGENT + "')]")
    this.agentsTitle = page.locator("xpath=div[class='yext-agents-title-text tui-body-text-bold']"); // @FindBy(xpath = "div[class='yext-agents-title-text tui-body-text-bold']")
    this.agentList = page.locator("xpath=//div[@class='yext-agents-content-container']//div[contains(@class,'auto-agent-details')]"); // @FindBy(xpath = "//div[@class='yext-agents-content-container']//div[contains(@class,'auto-agent-details')]")
    this.agentContactButtons = page.locator("xpath=//button[contains(.,'Contact')]"); // @FindBy(xpath = "//button[contains(.,'Contact')]")
    this.agentName = page.locator("div[class='tui-body-bold']"); // @FindBy(css = "div[class='tui-body-bold']")
    this.agentsContactButtons = page.locator("button[class='tui-link-button yext-agent-contact-text']"); // @FindBy(css = "button[class='tui-link-button yext-agent-contact-text']")
    this.contactMeButton = page.locator("button[class='tui-link-button']"); // @FindBy(css = "button[class='tui-link-button']")
    this.tollFreeNumber = page.locator("div[class='tui-h3 knockout__toll-free-number ng-star-inserted']"); // @FindBy(css = "div[class='tui-h3 knockout__toll-free-number ng-star-inserted']")
    this.tollFreeNumber2 = page.locator("xpath=//div[contains(@class,'agent-details-container')]//a[starts-with(@aria-label,'Contact farmers representative at')]"); // @FindBy(xpath = "//div[contains(@class,'agent-details-container')]//a[starts-with(@aria-label,'Contact farmers representative at')]")
    this.bitMoreInfoAboutVehicleKOMessage = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + BIT_MORE_INFO_ABOUT_VEHICLE + "')]")
    this.agentsImage = page.locator("xpath=//img[@class='agent-image']"); // @FindBy(xpath = "//img[@class='agent-image']")
    this.agentFullNameWebElement = page.locator("xpath=//div[contains(@class,'agent-details')]/div[2]/div/div[2]"); // @FindBy(xpath = "//div[contains(@class,'agent-details')]/div[2]/div/div[2]")
    this.leasLoanKnockOutMessage = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + LEASE_LOAN_KNOCKOUT_MSG + "')]")
    this.startMyQuoteButtonsOnMonetizationKOPage = page.locator("xpath=//app-knockout//form//div[@id='mediaAlpha']//div[contains(@class,'mav-partner__buttons')]"); // @FindBy(xpath = "//app-knockout//form//div[@id='mediaAlpha']//div[contains(@class,'mav-partner__buttons')]")
    this.doesntOfferBusinessTollNumberDesktop = page.locator("div[id='quote_unavailable_body_farmers']>a"); // @FindBy(css = "div[id='quote_unavailable_body_farmers']>a")
    this.doesntOfferBusinessTollNumberMobile = page.locator("a[id='quote_unavailable_body_farmers-mobile']"); // @FindBy(css = "a[id='quote_unavailable_body_farmers-mobile']")
    this.findFarmersAgent = page.locator("xpath=//a[text()='Find a Farmers Agent']"); // @FindBy(xpath = "//a[text()='Find a Farmers Agent']")
    this.koTitleText = page.locator("xpath=//div[@class='knock-out_header-title']"); // @FindBy(xpath = "//div[@class='knock-out_header-title']")
    this.koDescriptionText = page.locator("xpath=//div[@class='knock-out_body_knock_message']"); // @FindBy(xpath = "//div[@class='knock-out_body_knock_message']")
    this.agentImage = page.locator("xpath=//img[contains(@class,'knock-out_agent-image')]"); // @FindBy(xpath = "//img[contains(@class,'knock-out_agent-image')]")
    this.agentNameKOPage = page.locator("xpath=//div[contains(@class,'knock-out_agent-detail-name')]"); // @FindBy(xpath = "//div[contains(@class,'knock-out_agent-detail-name')]")
    this.agentDetailsText = page.locator("xpath=//div[contains(@class,'knock-out_agent-detail-text')]"); // @FindBy(xpath = "//div[contains(@class,'knock-out_agent-detail-text')]")
    this.agentEmail = page.locator("xpath=//a[contains(@class,'agent-email-link')]//div[contains(@class,'knock-out_agent-detail-email')]"); // @FindBy(xpath = "//a[contains(@class,'agent-email-link')]//div[contains(@class,'knock-out_agent-detail-email')]")
    this.agentPhoneDesktop = page.locator("xpath=//div[contains(@class,'knock-out_desktop')]//div[contains(@class,'knock-out_agent-detail-phone')]"); // @FindBy(xpath = "//div[contains(@class,'knock-out_desktop')]//div[contains(@class,'knock-out_agent-detail-phone')]")
    this.agentPhoneMobile = page.locator("xpath=//div[contains(@class,'knock-out_mobile')]//div[contains(@class,'knock-out_agent-detail-phone')]"); // @FindBy(xpath = "//div[contains(@class,'knock-out_mobile')]//div[contains(@class,'knock-out_agent-detail-phone')]")
    this.scheduleAppointment = page.locator("xpath=//div[contains(@class,'schedule-appointment-content')]"); // @FindBy(xpath = "//div[contains(@class,'schedule-appointment-content')]")
    this.agentAddress = page.locator("xpath=//a[contains(@class,'agent-adress-link')]//span"); // @FindBy(xpath = "//a[contains(@class,'agent-adress-link')]//span")
    this.needMoreHelpDigitalMonetization = page.locator("xpath=//div[@id='knock-out_body_noagent']"); // @FindBy(xpath = "//div[@id='knock-out_body_noagent']")
    this.callCustomerServiceDigitalMonetization = page.locator("xpath=//div[@id='knock-out_body_call-custome']"); // @FindBy(xpath = "//div[@id='knock-out_body_call-custome']")
    this.tollFreeDigitalMonetization = page.locator("xpath=//span[contains(@class,'knock-out_desktop')]//a[@id='default-phone']"); // @FindBy(xpath = "//span[contains(@class,'knock-out_desktop')]//a[@id='default-phone']")
    this.fgiaSubtitle = page.locator("xpath=//h2[@class='tui-h2 mt-10']"); // @FindBy(xpath = "//h2[@class='tui-h2 mt-10']")
    this.fgiaCantOfferText = page.locator("xpath=//h4[@class='tui-h4 mt-10']"); // @FindBy(xpath = "//h4[@class='tui-h4 mt-10']")
    this.fgiaPageContents = page.locator("xpath=//p[@class='tui-body tui-stacking-top-md col-11']"); // @FindBy(xpath = "//p[@class='tui-body tui-stacking-top-md col-11']")
    this.fgiaSoundGoodText = page.locator("xpath=//h4[@class='tui-h4']"); // @FindBy(xpath = "//h4[@class='tui-h4']")
    this.fgiaTabBelowToContinueText = page.locator("xpath=//p[@class='tui-body tui-stacking-top-xs']"); // @FindBy(xpath = "//p[@class='tui-body tui-stacking-top-xs']")
    this.fgiaReferenceYourQuoteText = page.locator("xpath=//div[contains(@class,'quote-details')]//span[@class='tui-body']"); // @FindBy(xpath = "//div[contains(@class,'quote-details')]//span[@class='tui-body']")
    this.quoteNumberInKO_FGIA = page.locator("xpath=//div[contains(@class,'quote-details')]//span[@class='tui-body-bold']"); // @FindBy(xpath = "//div[contains(@class,'quote-details')]//span[@class='tui-body-bold']")
  }
}
