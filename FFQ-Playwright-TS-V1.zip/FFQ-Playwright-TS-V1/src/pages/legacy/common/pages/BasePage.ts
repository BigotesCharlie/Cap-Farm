// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.BasePage. */
export class BasePage extends CoreBasePage {
  public readonly desktopStepper: Locator;
  public readonly mobileStepper: Locator;
  public readonly closeModalSurveyButton: Locator;
  public readonly headerLogo: Locator;
  public readonly zipCodeErrorMessage: Locator;
  public readonly legacySpinner: Locator;
  public readonly waitForResponseSpinner: Locator;
  public readonly recalculatingPopup: Locator;
  public readonly recalculatingAndProcessingPopup: Locator;
  public readonly sideNavBar: Locator;
  public readonly pageIsLoadingMessage: Locator;
  public readonly oneuiSpinner: Locator;
  public readonly aceSpinnerSection: Locator;
  public readonly reviewQuoteSkeleton: Locator;
  public readonly oneMomentPleasePage: Locator;
  public readonly closeIconMB: Locator;
  public readonly continueToFGIA: Locator;
  public readonly continueToDigitalMonetization: Locator;
  public readonly buttonContinue: Locator;
  public readonly startCheckOutButton: Locator;
  public readonly qualtricsPopUpSwitcher: Locator;
  public readonly listOfQualtricsCloseButtons: Locator;
  public readonly snackBar: Locator;
  public readonly saveQuoteTextContent: Locator;
  public readonly saveQuoteModalHeader: Locator;
  public readonly saveQuoteModalCloseIcon: Locator;
  public readonly saveQuoteModalQuoteNumber: Locator;
  public readonly saveQuoteModalQuoteNumberText: Locator;
  public readonly saveQuoteModalInfoText: Locator;
  public readonly saveQuoteModalEmailFieldHeader: Locator;
  public readonly saveQuoteModalEmailInputField: Locator;
  public readonly saveQuoteModalEmailFieldLabel: Locator;
  public readonly saveQuoteModalSubmitButton: Locator;
  public readonly discountAddedText: Locator;
  public readonly reviewDiscountsButton: Locator;
  public readonly closeIcon: Locator;
  public readonly discounts: Locator;
  public readonly discountsSidesheetAppliedText: Locator;
  public readonly discountPiggyBankImage: Locator;
  public readonly discountsSidesheetTitle: Locator;
  public readonly discountsSidesheetSubTitle: Locator;
  public readonly quoteNumber: Locator;
  public readonly emailInputFieldErrorMessage: Locator;
  public readonly agentImage: Locator;
  public readonly agentSectionYourAgent: Locator;
  public readonly agentSectionAgentName: Locator;
  public readonly agentMailID: Locator;
  public readonly agentAddress: Locator;
  public readonly agentPhoneNumber: Locator;
  public readonly emailLinkDesktop: Locator;
  public readonly emailLinkMobile: Locator;
  public readonly linkCloseEmailSnackBar: Locator;
  public readonly notAbleToOfferBundleQuoteMessageIcon: Locator;
  public readonly notAbleToOfferBundleQuoteCard: Locator;
  public readonly notAbleToOfferBundleQuoteMessage: Locator;
  public readonly weCanStillOfferThisLOBQuoteMessage: Locator;
  public readonly addressSelection: Locator;
  public readonly agreeAndSubmitButton: Locator;
  public readonly expandQuoteCardButton: Locator;
  public readonly acceptTargetingCookiesButton: Locator;
  public readonly closeModalButton: Locator;
  public readonly legacyQuoteNumber: Locator;
  public readonly summaryPopupOpen: Locator;
  public readonly redesignedSummaryPopupButton: Locator;
  public readonly summaryPopupClose: Locator;
  public readonly summaryLegacyQuoteNumber: Locator;
  public readonly redesignedQuoteNumber: Locator;
  public readonly yourInfoPageSmallScreenNavigationLink: Locator;
  public readonly errorMessageElement: Locator;
  public readonly policyCenterLoginPageHeader: Locator;
  public readonly userNameInput: Locator;
  public readonly passwordInput: Locator;
  public readonly pcLogInButton: Locator;
  public readonly actionsItem: Locator;
  public readonly pcBusyIndicator: Locator;
  public readonly pcRefreshButton: Locator;
  public readonly clusterMenuItem: Locator;
  public readonly membersMenuItem: Locator;
  public readonly userSessionButtons: Locator;
  public readonly customerDeamons: Locator;
  public readonly markAsInactiveButton: Locator;
  public readonly allSessions: Locator;
  public readonly returnToClusterMembers: Locator;
  public readonly footerPrivacyPolicyLink: Locator;
  public readonly footerTermsOfUseLink: Locator;
  public readonly footerContactUsLink: Locator;
  public readonly footerNoticeOfInformationLink: Locator;
  public readonly faqDialogTitle: Locator;
  public readonly faqDialogContent: Locator;
  public readonly faqDialogOKButton: Locator;
  public readonly bundleQuoteContainer: Locator;

  public constructor(page: Page) {
    super(page);
    this.desktopStepper = page.locator("[data-legacy-field=\"desktopStepper\"]"); // @FindBy(xpath = STEPPER_DESKTOP_XPATH)
    this.mobileStepper = page.locator("[data-legacy-field=\"mobileStepper\"]"); // @FindBy(xpath = STEPPER_MOBILE_XPATH)
    this.closeModalSurveyButton = page.locator("[data-legacy-field=\"closeModalSurveyButton\"]"); // @FindBy(xpath = CLOSE_SURVEY_XPATH)
    this.headerLogo = page.locator("#logoPlaceHolder"); // @FindBy(id = "logoPlaceHolder")
    this.zipCodeErrorMessage = page.locator("#ZipCodeError"); // @FindBy(id = "ZipCodeError")
    this.legacySpinner = page.locator("[data-legacy-field=\"legacySpinner\"]"); // @FindBy(className = LEGACY_WAIT_DIALOG_CLASSNAME)
    this.waitForResponseSpinner = page.locator("[data-legacy-field=\"waitForResponseSpinner\"]"); // @FindBy(id = WAIT_QUOTE_READY_ID)
    this.recalculatingPopup = page.locator("[data-legacy-field=\"recalculatingPopup\"]"); // @FindBy(id = RECALCULATING_POPUP_ID)
    this.recalculatingAndProcessingPopup = page.locator("[data-legacy-field=\"recalculatingAndProcessingPopup\"]"); // @FindBy(className = RECALCULATING_POPUP_CLASS)
    this.sideNavBar = page.locator("xpath=//app-navigation-drawer"); // @FindBy(xpath = "//app-navigation-drawer")
    this.pageIsLoadingMessage = page.locator("[data-legacy-field=\"pageIsLoadingMessage\"]"); // @FindBy(id = PAGE_LOADING_MESSAGE_ID)
    this.oneuiSpinner = page.locator("[data-legacy-field=\"oneuiSpinner\"]"); // @FindBy(xpath = ONEUI_SPINNER_XPATH)
    this.aceSpinnerSection = page.locator("[data-legacy-field=\"aceSpinnerSection\"]"); // @FindBy(xpath = ACE_SPINNER_SECTION_XPATH)
    this.reviewQuoteSkeleton = page.locator("[data-legacy-field=\"reviewQuoteSkeleton\"]"); // @FindBy(xpath = ACE_REVIEW_QUOTE_SKELETON_XPATH)
    this.oneMomentPleasePage = page.locator("[data-legacy-field=\"oneMomentPleasePage\"]"); // @FindBy(xpath = ACE_ONE_MOMENT_TITLE_XPATH)
    this.closeIconMB = page.locator("xpath=//mat-icon[contains(text(), 'close')]"); // @FindBy(xpath = "//mat-icon[contains(text(), 'close')]")
    this.continueToFGIA = page.locator("xpath=//button[contains(@class, 'auto-module_continue-to-bw-button-primary')]"); // @FindBy(xpath = "//button[contains(@class, 'auto-module_continue-to-bw-button-primary')]")
    this.continueToDigitalMonetization = page.locator("[data-legacy-field=\"continueToDigitalMonetization\"]"); // @FindBy(xpath = CONTINUE_TO_DIGITAL_MONETIZATION_BUTTON_XPATH)
    this.buttonContinue = page.locator("xpath=//button[contains(text(),'Continue') or contains(text(),'Agree')][not(@hidden)]"); // @FindBy(xpath = "//button[contains(text(),'Continue') or contains(text(),'Agree')][not(@hidden)]")
    this.startCheckOutButton = page.locator("xpath=//button[contains(@class,'tui-btn tui-quote-presentment-button')]"); // @FindBy(xpath = "//button[contains(@class,'tui-btn tui-quote-presentment-button')]")
    this.qualtricsPopUpSwitcher = page.locator("div[id='aceIndicator']"); // @FindBy(css = "div[id='aceIndicator']")
    this.listOfQualtricsCloseButtons = page.locator("xpath=//img[contains(@src,'qualtrics') and contains(@src,'close-btn')]"); // @FindBy(xpath = "//img[contains(@src,'qualtrics') and contains(@src,'close-btn')]")
    this.snackBar = page.locator("#snackbarDesc"); // @FindBy(id = "snackbarDesc")
    this.saveQuoteTextContent = page.locator("[data-legacy-field=\"saveQuoteTextContent\"]"); // @FindBy(xpath = SAVE_QUOTE_LINK_XPATH)
    this.saveQuoteModalHeader = page.locator("xpath=//div[@class='tui-save-quote-modal']//h4"); // @FindBy(xpath = "//div[@class='tui-save-quote-modal']//h4")
    this.saveQuoteModalCloseIcon = page.locator("xpath=//a[@class='close-container']//mat-icon"); // @FindBy(xpath = "//a[@class='close-container']//mat-icon")
    this.saveQuoteModalQuoteNumber = page.locator("xpath=//div[@class='tui-save-quote-modal']//h3"); // @FindBy(xpath = "//div[@class='tui-save-quote-modal']//h3")
    this.saveQuoteModalQuoteNumberText = page.locator("xpath=//div[@class='modal-content']//p"); // @FindBy(xpath = "//div[@class='modal-content']//p")
    this.saveQuoteModalInfoText = page.locator("xpath=//tui-save-quote-modal//p[contains(@class,'modal-info')]"); // @FindBy(xpath = "//tui-save-quote-modal//p[contains(@class,'modal-info')]")
    this.saveQuoteModalEmailFieldHeader = page.locator("xpath=//tui-save-quote-modal//p[@class='tui-field-label']"); // @FindBy(xpath = "//tui-save-quote-modal//p[@class='tui-field-label']")
    this.saveQuoteModalEmailInputField = page.locator("xpath=//tui-save-quote-modal//input"); // @FindBy(xpath = "//tui-save-quote-modal//input")
    this.saveQuoteModalEmailFieldLabel = page.locator("xpath=//div[contains(@class,'modal-form')]//mat-label"); // @FindBy(xpath = "//div[contains(@class,'modal-form')]//mat-label")
    this.saveQuoteModalSubmitButton = page.locator("button[class='tui-btn tui-btn-primary auto-add-vehicle-submit__button']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary auto-add-vehicle-submit__button']")
    this.discountAddedText = page.locator("xpath=//div[@class='discount-description']/p[1]"); // @FindBy(xpath = "//div[@class='discount-description']/p[1]")
    this.reviewDiscountsButton = page.locator("xpath=//div[@class='discount-description']//p[@role='button']"); // @FindBy(xpath = "//div[@class='discount-description']//p[@role='button']")
    this.closeIcon = page.locator("xpath=//mat-icon[contains(.,'close')]"); // @FindBy(xpath = "//mat-icon[contains(.,'close')]")
    this.discounts = page.locator("xpath=//span[contains(@class,'discount-name')]"); // @FindBy(xpath = "//span[contains(@class,'discount-name')]")
    this.discountsSidesheetAppliedText = page.locator("xpath=//app-home-discount-sidesheet//div[@id='appliedDiscounts']"); // @FindBy(xpath = "//app-home-discount-sidesheet//div[@id='appliedDiscounts']"),             @FindBy(xpath = "//app-auto-discount-sidesheet//div[@id='appliedDiscounts']")     })
    this.discountPiggyBankImage = page.locator("xpath=//app-home-discount//img"); // @FindBy(xpath = "//app-home-discount//img"),             @FindBy(xpath = "//app-auto-discount//img")     })
    this.discountsSidesheetTitle = page.locator("xpath=//app-home-discount-sidesheet//h1"); // @FindBy(xpath = "//app-home-discount-sidesheet//h1"),             @FindBy(xpath = "//app-auto-discount-sidesheet//h1")     })
    this.discountsSidesheetSubTitle = page.locator("xpath=//app-home-discount-sidesheet//p[contains(@class,'tui-input-text')]"); // @FindBy(xpath = "//app-home-discount-sidesheet//p[contains(@class,'tui-input-text')]"),             @FindBy(xpath = "//app-auto-discount-sidesheet//p[contains(@class,'tui-input-text')]")     })
    this.quoteNumber = page.locator("[data-legacy-field=\"quoteNumber\"]"); // @FindBy(xpath = QUOTE_NUMBER_XPATH)
    this.emailInputFieldErrorMessage = page.locator("xpath=//tui-save-quote-modal//mat-error"); // @FindBy(xpath = "//tui-save-quote-modal//mat-error")
    this.agentImage = page.locator("[data-legacy-field=\"agentImage\"]"); // @FindBy(className = AGENT_IMAGE_CLASS_NAME)
    this.agentSectionYourAgent = page.locator("xpath=//div[contains(@class,'tui-agent-box-column-2')]/div/div[1]"); // @FindBy(xpath = "//div[contains(@class,'tui-agent-box-column-2')]/div/div[1]")
    this.agentSectionAgentName = page.locator("xpath=//div[contains(@class,'tui-agent-box-column-2')]/div/div[2]"); // @FindBy(xpath = "//div[contains(@class,'tui-agent-box-column-2')]/div/div[2]")
    this.agentMailID = page.locator("xpath=//app-agent-details//a[contains(@aria-label, 'Email')]"); // @FindBy(xpath = "//app-agent-details//a[contains(@aria-label, 'Email')]")
    this.agentAddress = page.locator("xpath=//div[contains(@class,'agent-details-container')]/p/a[@target = '_blank']"); // @FindBy(xpath = "//div[contains(@class,'agent-details-container')]/p/a[@target = '_blank']")
    this.agentPhoneNumber = page.locator("xpath=//a[contains(@class,'link-footer')]"); // @FindBy(xpath = "//a[contains(@class,'link-footer')]")
    this.emailLinkDesktop = page.locator("#emailLink"); // @FindBy(id = "emailLink")
    this.emailLinkMobile = page.locator("xpath=//button[contains(text(),'Email this quote')]"); // @FindBy(xpath = "//button[contains(text(),'Email this quote')]")
    this.linkCloseEmailSnackBar = page.getByRole('link', { name: "Done", exact: true }); // @FindBy(linkText = "Done")
    this.notAbleToOfferBundleQuoteMessageIcon = page.locator("xpath=//mat-card[contains(@class,'limited-message-card-section')]//mat-icon"); // @FindBy(xpath = "//mat-card[contains(@class,'limited-message-card-section')]//mat-icon")
    this.notAbleToOfferBundleQuoteCard = page.locator("xpath=//div[contains(@class,'limited-message-card')]"); // @FindBy(xpath = "//div[contains(@class,'limited-message-card')]")
    this.notAbleToOfferBundleQuoteMessage = page.locator("xpath=//div[contains(@class,'limited-message-card-description')]//p[1]"); // @FindBy(xpath = "//div[contains(@class,'limited-message-card-description')]//p[1]")
    this.weCanStillOfferThisLOBQuoteMessage = page.locator("xpath=//div[contains(@class,'limited-message-card-description')]//p[2]"); // @FindBy(xpath = "//div[contains(@class,'limited-message-card-description')]//p[2]")
    this.addressSelection = page.locator("xpath=//div[contains(@id, 'mat-autocomplete')]/mat-option"); // @FindBy(xpath = "//div[contains(@id, 'mat-autocomplete')]/mat-option")
    this.agreeAndSubmitButton = page.locator("xpath=//button[contains(text(),'Agree and submit')]"); // @FindBy(xpath = "//button[contains(text(),'Agree and submit')]")
    this.expandQuoteCardButton = page.locator("xpath=//mat-icon[@aria-label='expand quote card']"); // @FindBy(xpath = "//mat-icon[@aria-label='expand quote card']")
    this.acceptTargetingCookiesButton = page.locator("[data-legacy-field=\"acceptTargetingCookiesButton\"]"); // @FindBy(id = ACCEPT_COOKIES_BUTTON_ID)
    this.closeModalButton = page.locator("#popupClose"); // @FindBy(id = "popupClose")
    this.legacyQuoteNumber = page.locator("xpath=//*[@id='quoteBig']"); // @FindBy(xpath = "//*[@id='quoteBig']")
    this.summaryPopupOpen = page.locator("xpath=//*[@id='mSum' or contains(@class, 'summaryBtn')]"); // @FindBy(xpath = "//*[@id='mSum' or contains(@class, 'summaryBtn')]")
    this.redesignedSummaryPopupButton = page.locator("#header_menu-icon-mobile"); // @FindBy(id = "header_menu-icon-mobile")
    this.summaryPopupClose = page.locator("xpath=//div[@id='summaryLB']//*[@id='mSum' or @id='summaryCloseBtn']"); // @FindBy(xpath = "//div[@id='summaryLB']//*[@id='mSum' or @id='summaryCloseBtn']")
    this.summaryLegacyQuoteNumber = page.locator("xpath=//*[@id='summaryquoteBig']"); // @FindBy(xpath = "//*[@id='summaryquoteBig']")
    this.redesignedQuoteNumber = page.locator("[data-legacy-field=\"redesignedQuoteNumber\"]"); // @FindBy(xpath = REDESIGNED_QUOTE_NUMBER_XPATH)
    this.yourInfoPageSmallScreenNavigationLink = page.locator("[data-legacy-field=\"yourInfoPageSmallScreenNavigationLink\"]"); // @FindBy(xpath = YOURINFOPAGE_SMALL_SCREEN_NAVIGATION_LINK_XPATH)
    this.errorMessageElement = page.locator(".errorOff"); // @FindBy(className = "errorOff")
    this.policyCenterLoginPageHeader = page.locator("#Login-LoginScreen-4"); // @FindBy(id = "Login-LoginScreen-4")
    this.userNameInput = page.locator("input[name='Login-LoginScreen-LoginDV-username']"); // @FindBy(css = "input[name='Login-LoginScreen-LoginDV-username']")
    this.passwordInput = page.locator("input[name='Login-LoginScreen-LoginDV-password']"); // @FindBy(css = "input[name='Login-LoginScreen-LoginDV-password']")
    this.pcLogInButton = page.locator("#Login-LoginScreen-LoginDV-submit"); // @FindBy(id = "Login-LoginScreen-LoginDV-submit")
    this.actionsItem = page.locator("#Desktop-DesktopMenuActions"); // @FindBy(id = "Desktop-DesktopMenuActions")
    this.pcBusyIndicator = page.locator("xpath=//div[contains(@class,'gw-busy')]"); // @FindBy(xpath = "//div[contains(@class,'gw-busy')]")
    this.pcRefreshButton = page.locator("xpath=//div[@aria-label='Refresh' or @title='Refresh']"); // @FindBy(xpath = "//div[@aria-label='Refresh' or @title='Refresh']")
    this.clusterMenuItem = page.locator("xpath=//div[@class='gw-action--inner' and contains(.,'Cluster')]"); // @FindBy(xpath = "//div[@class='gw-action--inner' and contains(.,'Cluster')]")
    this.membersMenuItem = page.locator("xpath=//div[@class='gw-action--inner' and contains(.,'Members')]"); // @FindBy(xpath = "//div[@class='gw-action--inner' and contains(.,'Members')]")
    this.userSessionButtons = page.locator("xpath=//div[contains(@id,'UserSessions_button')]"); // @FindBy(xpath = "//div[contains(@id,'UserSessions_button')]")
    this.customerDeamons = page.locator("xpath=//div[contains(@id,'Username') and contains(.,'customerdaemon')]/../../..//input"); // @FindBy(xpath = "//div[contains(@id,'Username') and contains(.,'customerdaemon')]/../../..//input")
    this.markAsInactiveButton = page.locator("#ClusterMemberUserSessionsPopup-MarkAsInactive"); // @FindBy(id = "ClusterMemberUserSessionsPopup-MarkAsInactive")
    this.allSessions = page.locator("xpath=//div[contains(@id,'ClusterMemberUserSessionsPopup-_Checkbox')]"); // @FindBy(xpath = "//div[contains(@id,'ClusterMemberUserSessionsPopup-_Checkbox')]")
    this.returnToClusterMembers = page.locator("#ClusterMemberUserSessionsPopup-__crumb__"); // @FindBy(id = "ClusterMemberUserSessionsPopup-__crumb__")
    this.footerPrivacyPolicyLink = page.locator("xpath=//*[@id='footUl']/li[1]/a"); // @FindBy(xpath = "//*[@id='footUl']/li[1]/a")
    this.footerTermsOfUseLink = page.locator("xpath=//*[@id='footUl']/li[2]/a"); // @FindBy(xpath = "//*[@id='footUl']/li[2]/a")
    this.footerContactUsLink = page.locator("xpath=//*[@id='footUl']/li[3]/a"); // @FindBy(xpath = "//*[@id='footUl']/li[3]/a")
    this.footerNoticeOfInformationLink = page.locator("xpath=//*[@id='footUl']/li[4]/a"); // @FindBy(xpath = "//*[@id='footUl']/li[4]/a")
    this.faqDialogTitle = page.locator("[data-legacy-field=\"faqDialogTitle\"]"); // @FindBy(xpath = FAQ_XPATH + "/h2")
    this.faqDialogContent = page.locator("[data-legacy-field=\"faqDialogContent\"]"); // @FindBy(xpath = FAQ_XPATH + "/p")
    this.faqDialogOKButton = page.locator("[data-legacy-field=\"faqDialogOKButton\"]"); // @FindBy(xpath = FAQ_XPATH + "//input[@type='button']")
    this.bundleQuoteContainer = page.locator("xpath=//div[contains(@class, 'container')][not(contains(@class, '-container'))]"); // @FindBy(xpath = "//div[contains(@class, 'container')][not(contains(@class, '-container'))]")
  }
}
