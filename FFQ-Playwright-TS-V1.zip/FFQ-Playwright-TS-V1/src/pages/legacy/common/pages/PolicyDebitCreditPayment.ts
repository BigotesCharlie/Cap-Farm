// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.PolicyDebitCreditPayment. */
export class PolicyDebitCreditPayment extends CoreBasePage {
  public readonly monthlyAutoPayCardHeader: Locator;
  public readonly expirationDateInputField: Locator;
  public readonly creditCardAddedMsg: Locator;
  public readonly debitCardAddedMsg: Locator;
  public readonly noServiceChargeWhenPayInFullMsg: Locator;
  public readonly amexIconOnAutoPolicyPaymentScreen: Locator;
  public readonly masterCardIconOnAutoPolicyPaymentScreen: Locator;
  public readonly discoverCardIconOnAutoPolicyPaymentScreen: Locator;
  public readonly visaCardIconOnAutoPolicyPaymentScreen: Locator;
  public readonly hiddenCardNumberAndExpDatePayInFull: Locator;
  public readonly hiddenCardNumberAndExpDateMonthlyPay: Locator;
  public readonly changeLink: Locator;
  public readonly automaticRecurringPaymentText: Locator;
  public readonly oneTimePaymentText: Locator;
  public readonly oneTimePaymentRadioButton: Locator;
  public readonly automaticRecurringPaymentRadioButton: Locator;
  public readonly futureMonthlyPaymentsServiceChargeCard: Locator;
  public readonly completerPurchaseButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.monthlyAutoPayCardHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_CARD_HEADER + "')]")
    this.expirationDateInputField = page.locator("xpath=//input[@id='ccExpirationDate']"); // @FindBy(xpath = "//input[@id='ccExpirationDate']")
    this.creditCardAddedMsg = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" +  CREDIT_CARD_ADDED_MSG + "')]")
    this.debitCardAddedMsg = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" +  DEBIT_CARD_ADDED_MSG + "')]")
    this.noServiceChargeWhenPayInFullMsg = page.locator("xpath=//p[contains(text(),'"); // @FindBy(xpath = "//p[contains(text(),'" +  NO_SERVICE_CHARGE_WHEN_PAY_IN_FULL + "')]")
    this.amexIconOnAutoPolicyPaymentScreen = page.locator("xpath=//*[contains(@src,'cc_amex')]"); // @FindBy(xpath = "//*[contains(@src,'cc_amex')]")
    this.masterCardIconOnAutoPolicyPaymentScreen = page.locator("xpath=//*[contains(@src,'cc_mastercard')]"); // @FindBy(xpath = "//*[contains(@src,'cc_mastercard')]")
    this.discoverCardIconOnAutoPolicyPaymentScreen = page.locator("xpath=//*[contains(@src,'cc_discover')]"); // @FindBy(xpath = "//*[contains(@src,'cc_discover')]")
    this.visaCardIconOnAutoPolicyPaymentScreen = page.locator("xpath=//*[contains(@src,'cc_visa')]"); // @FindBy(xpath = "//*[contains(@src,'cc_visa')]")
    this.hiddenCardNumberAndExpDatePayInFull = page.locator("xpath=//span[contains(@class,'pif-autopay-disclaimers-account-numbers')]//span"); // @FindBy(xpath = "//span[contains(@class,'pif-autopay-disclaimers-account-numbers')]//span")
    this.hiddenCardNumberAndExpDateMonthlyPay = page.locator("xpath=//span[contains(@class,'monthly-autopay-disclaimers-account-numbers')]//small"); // @FindBy(xpath = "//span[contains(@class,'monthly-autopay-disclaimers-account-numbers')]//small")
    this.changeLink = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + CHANGE_LINK + "')]")
    this.automaticRecurringPaymentText = page.locator("xpath=//p[contains(text(),'"); // @FindBy(xpath = "//p[contains(text(),'" +  AUTOMATIC_RECURRING_PAYMENT_TEXT + "')]")
    this.oneTimePaymentText = page.locator("xpath=//p[contains(text(),'"); // @FindBy(xpath = "//p[contains(text(),'" +  ONE_TIME_PAYMENT_TEXT + "')]")
    this.oneTimePaymentRadioButton = page.locator("xpath=//input[@value='one-time-payment']"); // @FindBy(xpath = "//input[@value='one-time-payment']")
    this.automaticRecurringPaymentRadioButton = page.locator("xpath=//input[@value='automatic-recurring']"); // @FindBy(xpath = "//input[@value='automatic-recurring']")
    this.futureMonthlyPaymentsServiceChargeCard = page.locator("xpath=//span[contains(text(), '$5')]/parent::span"); // @FindBy(xpath = "//span[contains(text(), '$5')]/parent::span")     private WebElement futureMonthlyPaymentInclude$5;      private static final String FUTURE_MONTHLY_PAYMENT_INCLUDE_$3 = "Future monthly payments will include a $3 service charge.";     @FindBy(xpath = "//span[contains(text(), '$3')]/parent::span")     private WebElement futureMonthlyPaymentInclude$3;      public static final String FUTURE_MONTHLY_SERVICE_CHARGE_CARD = "Future monthly payments will include a $5 service charge.";     @FindBy(xpath = "//div[contains(@class,'monthly-autopay-disclaimers-details')]//p")
    this.completerPurchaseButton = page.locator("xpath=//button[contains(text(), '"); // @FindBy(xpath = "//button[contains(text(), '" + COMPLETE_PURCHASE_BUTTON + "')]")
  }
}
