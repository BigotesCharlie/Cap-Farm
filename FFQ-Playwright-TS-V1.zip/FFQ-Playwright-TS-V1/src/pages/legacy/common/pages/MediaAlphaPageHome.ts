// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.MediaAlphaPageHome. */
export class MediaAlphaPageHome extends CoreBasePage {
  public readonly streetAddress: Locator;
  public readonly goToStep2Button: Locator;
  public readonly goToStep3Button: Locator;
  public readonly currentlyInsuredCheckbox: Locator;
  public readonly goToLastStepButton: Locator;
  public readonly yourQuotesButton: Locator;
  public readonly yourName: Locator;
  public readonly radioGenderMale: Locator;
  public readonly radioGenderFemale: Locator;
  public readonly radioMarriedYes: Locator;
  public readonly radioMarriedNo: Locator;
  public readonly birthday: Locator;
  public readonly email: Locator;
  public readonly phone: Locator;
  public readonly viewMyQuoteButton: Locator;
  public readonly redirectButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.streetAddress = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-address']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-address']")
    this.goToStep2Button = page.locator("xpath=//table[@id='home-panel-content']//button[contains(.,'go to step 2')]"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'go to step 2')]")
    this.goToStep3Button = page.locator("xpath=//table[@id='home-panel-content']//button[contains(.,'go to step 3')]"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'go to step 3')]")
    this.currentlyInsuredCheckbox = page.locator("xpath=//table[@id='home-panel-content']//input[@id='currently_insured']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='currently_insured']")
    this.goToLastStepButton = page.locator("xpath=//table[@id='home-panel-content']//button[contains(.,'Go to Last Step')]"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'Go to Last Step')]")
    this.yourQuotesButton = page.locator("xpath=//table[@id='home-panel-content']//button[contains(.,'Get Your Quotes')]"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'Get Your Quotes')]")
    this.yourName = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-name']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-name']")
    this.radioGenderMale = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-gender-m']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-gender-m']")
    this.radioGenderFemale = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-gender-m']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-gender-m']")
    this.radioMarriedYes = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-married-y']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-married-y']")
    this.radioMarriedNo = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-married-n']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-married-n']")
    this.birthday = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-birthday']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-birthday']")
    this.email = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-email']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-email']")
    this.phone = page.locator("xpath=//table[@id='home-panel-content']//input[@id='f-phone']"); // @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-phone']")
    this.viewMyQuoteButton = page.locator("xpath=//table[@id='home-panel-content']//button[contains(@class,'mav-partner__button')]"); // @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(@class,'mav-partner__button')]")
    this.redirectButton = page.locator("xpath=//button[@id='redirect-btn'][1]"); // @FindBy(xpath = "//button[@id='redirect-btn'][1]")
  }
}
