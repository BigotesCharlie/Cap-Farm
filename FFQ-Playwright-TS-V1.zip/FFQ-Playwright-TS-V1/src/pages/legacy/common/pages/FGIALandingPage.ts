// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.FGIALandingPage. */
export class FGIALandingPage extends CoreBasePage {
  public readonly noThanksButtonInFgiaPage: Locator;
  public readonly fgiaPopupHeader: Locator;
  public readonly fgiaPopUpDescription: Locator;
  public readonly noThanksButtonInFgiaPopup: Locator;
  public readonly continueButtonInFgiaPopup: Locator;
  public readonly fgiaPageHeader: Locator;
  public readonly fgiaPageDescription: Locator;
  public readonly callToFgiaPageButton: Locator;
  public readonly callToFgiaPopupButton: Locator;
  public readonly continueButtonInFgiaPage: Locator;
  public readonly weAreNotAbleToCompleteQuoteTitle: Locator;
  public readonly findExperiencedAgent: Locator;
  public readonly otherInsuranceOfferingCompanies: Locator;
  public readonly tollFreeMonetizationSection: Locator;
  public readonly fgiaIntroPage: Locator;
  public readonly farmersLogo: Locator;
  public readonly unableToProvideQuoteTitle: Locator;
  public readonly findExperiencedAgentText: Locator;
  public readonly otherOptionsText: Locator;
  public readonly otherInsuranceCompaniesList: Locator;
  public readonly findAnAgentButton: Locator;
  public readonly needMoreHelpText: Locator;

  public constructor(page: Page) {
    super(page);
    this.noThanksButtonInFgiaPage = page.locator("xpath=//app-fgia-page//a[contains(.,'No, thanks')]"); // @FindBy(xpath = "//app-fgia-page//a[contains(.,'No, thanks')]")
    this.fgiaPopupHeader = page.locator("xpath=//app-fgia-popup//*[@role='heading']"); // @FindBy(xpath = "//app-fgia-popup//*[@role='heading']")
    this.fgiaPopUpDescription = page.locator("xpath=//app-fgia-popup//mat-dialog-content//div[@id='dnqMessage']"); // @FindBy(xpath = "//app-fgia-popup//mat-dialog-content//div[@id='dnqMessage']")
    this.noThanksButtonInFgiaPopup = page.locator("xpath=//app-fgia-popup//a[contains(.,'No, thanks')]"); // @FindBy(xpath = "//app-fgia-popup//a[contains(.,'No, thanks')]")
    this.continueButtonInFgiaPopup = page.locator("xpath=//app-fgia-popup//button[contains(.,'Continue to FGIA')]"); // @FindBy(xpath = "//app-fgia-popup//button[contains(.,'Continue to FGIA')]")
    this.fgiaPageHeader = page.locator("xpath=//app-fgia-page//h1"); // @FindBy(xpath = "//app-fgia-page//h1")
    this.fgiaPageDescription = page.locator("xpath=//app-fgia-page//div[contains(@class,'fgia-page-rebrand-container')]"); // @FindBy(xpath = "//app-fgia-page//div[contains(@class,'fgia-page-rebrand-container')]")
    this.callToFgiaPageButton = page.locator("xpath=//div[contains(@class,'fgia-rebrand-cta-section')]//a"); // @FindBy(xpath = "//div[contains(@class,'fgia-rebrand-cta-section')]//a")
    this.callToFgiaPopupButton = page.locator("xpath=//app-fgia-popup//button[contains(@class, 'info-dialog-button-no-thank')]"); // @FindBy(xpath = "//app-fgia-popup//button[contains(@class, 'info-dialog-button-no-thank')]")
    this.continueButtonInFgiaPage = page.locator("xpath=//div[contains(@class,'fgia-rebrand-cta-section')]//button"); // @FindBy(xpath = "//div[contains(@class,'fgia-rebrand-cta-section')]//button")
    this.weAreNotAbleToCompleteQuoteTitle = page.locator("xpath=//h1[@id='knockout_title']"); // @FindBy(xpath = "//h1[@id='knockout_title']")
    this.findExperiencedAgent = page.locator("xpath=//app-knockout//p"); // @FindBy(xpath = "//app-knockout//p")
    this.otherInsuranceOfferingCompanies = page.locator("xpath=//div[@id='mediaAlpha']"); // @FindBy(xpath = "//div[@id='mediaAlpha']")
    this.tollFreeMonetizationSection = page.locator("xpath=//div[contains(@class, 'knockout__toll-free-monetization')]"); // @FindBy(xpath = "//div[contains(@class, 'knockout__toll-free-monetization')]")
    this.fgiaIntroPage = page.locator("xpath=//section[@id='pg_intro']"); // @FindBy(xpath = "//section[@id='pg_intro']")
    this.farmersLogo = page.locator("xpath=//div[@id='quote_unavailable-header_ffq-logo']"); // @FindBy(xpath="//div[@id='quote_unavailable-header_ffq-logo']")
    this.unableToProvideQuoteTitle = page.locator("xpath=//div[@class='quote_blocked_header-title']/h2"); // @FindBy(xpath = "//div[@class='quote_blocked_header-title']/h2")
    this.findExperiencedAgentText = page.locator("xpath=//div[contains(text(),'find an experienced Farmers agent')]"); // @FindBy(xpath = "//div[contains(text(),'find an experienced Farmers agent')]")
    this.otherOptionsText = page.locator("xpath=//div[contains(text(),'other options')]"); // @FindBy(xpath = "//div[contains(text(),'other options')]")
    this.otherInsuranceCompaniesList = page.locator("xpath=//div[contains(@class,'local-insurance-provier-list')]"); // @FindBy(xpath = "//div[contains(@class,'local-insurance-provier-list')]")
    this.findAnAgentButton = page.locator("xpath=//span[@class='find_agent_text']"); // @FindBy(xpath = "//span[@class='find_agent_text']")
    this.needMoreHelpText = page.locator("xpath=//div[text()=' Need more help?']"); // @FindBy(xpath = "//div[text()=' Need more help?']")
  }
}
