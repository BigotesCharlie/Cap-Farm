// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.PaymentSelectionBasePage. */
export class PaymentSelectionBasePage extends CoreBasePage {
  public readonly payInFullHeader: Locator;
  public readonly howWouldYouLikeToPay: Locator;
  public readonly consolidatedPaymentPageHeader: Locator;
  public readonly consolidatedPaymentPageHeaderBw: Locator;
  public readonly bestValueSubHeader: Locator;
  public readonly oneTimePaymentSubHeader: Locator;
  public readonly selectAndSetUpPayment: Locator;
  public readonly disclaimerChargeText: Locator;
  public readonly preferredPayPlanSavings: Locator;
  public readonly paymentUsIframe: Locator;
  public readonly noServiceChargeWhenPayInFull: Locator;
  public readonly excludeFeesSurchargePayInFull: Locator;
  public readonly includeAllFeesPayInFull: Locator;
  public readonly bankDebitCreditCardPayment: Locator;
  public readonly payInMonthlyPayBankHeader: Locator;
  public readonly convenientHeader: Locator;
  public readonly includedAllFeesLabel: Locator;
  public readonly changeLink: Locator;
  public readonly bankNameLabel: Locator;
  public readonly bankPaymentAddedMessage: Locator;
  public readonly bankIcon: Locator;
  public readonly savingsLabel: Locator;
  public readonly businessCheckingLabel: Locator;
  public readonly paymentusIframeHeader: Locator;
  public readonly paymentusBankPaymentToggle: Locator;
  public readonly paymentusBankPaymentToggleButton: Locator;
  public readonly paymentusDebitCreditCardToggle: Locator;
  public readonly paymentusDebitCreditCardToggleButton: Locator;
  public readonly paymentusBankAccountTypeHeader: Locator;
  public readonly paymentusCheckingAccountRadioButton: Locator;
  public readonly paymentusSavingsAccountRadioButton: Locator;
  public readonly paymentusBusinessCheckingAccountRadioButton: Locator;
  public readonly paymentusCheckingAccountLabel: Locator;
  public readonly paymentusSavingsAccountLabel: Locator;
  public readonly paymentusBusinessCheckingAccountLabel: Locator;
  public readonly visaCardIcon: Locator;
  public readonly cardNumberInputField: Locator;
  public readonly masterCardIcon: Locator;
  public readonly discoverCardIcon: Locator;
  public readonly amexCardIcon: Locator;
  public readonly paymentusAccountHolderLabel: Locator;
  public readonly paymentusCardHolderInput: Locator;
  public readonly paymentusCardHolderLabel: Locator;
  public readonly paymentusRoutingNumberInput: Locator;
  public readonly paymentusRoutingNumberLabel: Locator;
  public readonly paymentusCardNumberInput: Locator;
  public readonly paymentusCardNumberLabel: Locator;
  public readonly paymentusVisaCardIcon: Locator;
  public readonly paymentusMasterCardIcon: Locator;
  public readonly paymentusDiscoverCardIcon: Locator;
  public readonly paymentusAmexCardIcon: Locator;
  public readonly paymentusAccountNumberInput: Locator;
  public readonly paymentusAccountNumberLabel: Locator;
  public readonly paymentusCardExpirationDateInput: Locator;
  public readonly paymentusCardExpirationDateLabel: Locator;
  public readonly paymentusCardCVVFieldInput: Locator;
  public readonly paymentusCardCVVFieldLabel: Locator;
  public readonly paymentusZipCodeInput: Locator;
  public readonly paymentusZipCodeLabel: Locator;
  public readonly paymentusConfirmAccountNumberInput: Locator;
  public readonly paymentusConfirmAccountNumberLabel: Locator;
  public readonly paymentusAddButton: Locator;
  public readonly changePaymentMethodLink: Locator;
  public readonly enterValidAccountHolderNameError: Locator;
  public readonly enterValidRoutingNumberError: Locator;
  public readonly enterValidAccountNumberError: Locator;
  public readonly bankAccountNumbersDoNotMatchError: Locator;

  public constructor(page: Page) {
    super(page);
    this.payInFullHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL + "')]")
    this.howWouldYouLikeToPay = page.locator("xpath=//h1[contains(text(), '"); // @FindBy(xpath = "//h1[contains(text(), '" + HOW_WOULD_YOU_LIKE_TO_PAY + "')]")
    this.consolidatedPaymentPageHeader = page.locator("xpath=//app-payment-consolidated//h1"); // @FindBy(xpath = "//app-payment-consolidated//h1")
    this.consolidatedPaymentPageHeaderBw = page.locator("xpath=//app-payment-overview//h1"); // @FindBy(xpath = "//app-payment-overview//h1")
    this.bestValueSubHeader = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + BEST_VALUE_SUBHEADER + "')]")
    this.oneTimePaymentSubHeader = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + ONE_TIME_PAYMENT + "')]")
    this.selectAndSetUpPayment = page.locator("xpath=//mat-tab-group//button[contains(text(), '"); // @FindBy(xpath = "//mat-tab-group//button[contains(text(), '" + SELECT_SETUP_PAYMENT + "')]")
    this.disclaimerChargeText = page.locator("xpath=//*[contains(@class,'disclaimers-charge-text')]"); // @FindBy(xpath = "//*[contains(@class,'disclaimers-charge-text')]")
    this.preferredPayPlanSavings = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + PREFERRED_PAYMENT_PLAN_SAVINGS + "')]")
    this.paymentUsIframe = page.locator("xpath=//iframe[@title = '"); // @FindBy(xpath = "//iframe[@title = '" + PAYMENTUS_MANAGE_PAYMENT + "']")
    this.noServiceChargeWhenPayInFull = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL +"')]/ancestor::mat-card//p[contains(text(),'" + NO_SERVICE_CHARGE + "')]")
    this.excludeFeesSurchargePayInFull = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL +"')]/ancestor::mat-card//p[contains(text(),'" + EXCLUDE_TAXES_TEXT + "')]")
    this.includeAllFeesPayInFull = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL +"')]/ancestor::mat-card//p[contains(text(),'" + INCLUDES_ALL_FEES + "')]")
    this.bankDebitCreditCardPayment = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + BANK_DEBIT_CREDIT_PAYMENT + "')]")
    this.payInMonthlyPayBankHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_BANK_HEADER + "')]")
    this.convenientHeader = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + CONVENIENT + "')]")
    this.includedAllFeesLabel = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + INCLUDES_ALL_FEES + "')]")
    this.changeLink = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + CHANGE_LINK + "')]")
    this.bankNameLabel = page.locator("xpath=//span[@class='pm-display-bank-name bank-found']"); // @FindBy(xpath = "//span[@class='pm-display-bank-name bank-found']")
    this.bankPaymentAddedMessage = page.locator("xpath=//span[text() = '"); // @FindBy(xpath = "//span[text() = '" + BANK_PAYMENT_ACCOUNT_ADDED + "']")
    this.bankIcon = page.locator("xpath=//i[@class='tui-icon tui-icon-generic-payment ng-star-inserted']"); // @FindBy(xpath = "//i[@class='tui-icon tui-icon-generic-payment ng-star-inserted']")
    this.savingsLabel = page.locator("xpath=//label[text() = '"); // @FindBy(xpath = "//label[text() = '" + SAVING_LABEL + "']")
    this.businessCheckingLabel = page.locator("xpath=//label[text() = '"); // @FindBy(xpath = "//label[text() = '" + BUSINESS_CHECKING_LABEL + "']")
    this.paymentusIframeHeader = page.locator("xpath=//*[@aria-label='Edit payment method' and not(@role='dialog')]"); // @FindBy(xpath = "//*[@aria-label='Edit payment method' and not(@role='dialog')]")
    this.paymentusBankPaymentToggle = page.locator("xpath=//div[@role='tab'][contains(.,'"); // @FindBy(xpath = "//div[@role='tab'][contains(.,'" + BANK_PAYMENT_TOGGLE_BUTTON_TITLE + "')]")
    this.paymentusBankPaymentToggleButton = page.locator("xpath=//div[@role='tab'][contains(.,'"); // @FindBy(xpath = "//div[@role='tab'][contains(.,'" + BANK_PAYMENT_TOGGLE_BUTTON_TITLE + "')]/span")
    this.paymentusDebitCreditCardToggle = page.locator("xpath=//div[@role='tab'][contains(.,'"); // @FindBy(xpath = "//div[@role='tab'][contains(.,'" + DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE + "')]")
    this.paymentusDebitCreditCardToggleButton = page.locator("xpath=//div[@role='tab'][contains(.,'"); // @FindBy(xpath = "//div[@role='tab'][contains(.,'" + DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE + "')]/div")
    this.paymentusBankAccountTypeHeader = page.locator("xpath=//legend"); // @FindBy(xpath = "//legend")
    this.paymentusCheckingAccountRadioButton = page.locator("xpath=//fieldset//input[@id='checking']"); // @FindBy(xpath = "//fieldset//input[@id='checking']")
    this.paymentusSavingsAccountRadioButton = page.locator("xpath=//fieldset//input[@id='savings']"); // @FindBy(xpath = "//fieldset//input[@id='savings']")
    this.paymentusBusinessCheckingAccountRadioButton = page.locator("xpath=//fieldset//input[@id='busChecking']"); // @FindBy(xpath = "//fieldset//input[@id='busChecking']")
    this.paymentusCheckingAccountLabel = page.locator("xpath=//fieldset//label[@for='busChecking']"); // @FindBy(xpath = "//fieldset//label[@for='busChecking']")
    this.paymentusSavingsAccountLabel = page.locator("xpath=//fieldset//label[@for='savings']"); // @FindBy(xpath = "//fieldset//label[@for='savings']")
    this.paymentusBusinessCheckingAccountLabel = page.locator("xpath=//fieldset//label[@for='busChecking']"); // @FindBy(xpath = "//fieldset//label[@for='busChecking']")
    this.visaCardIcon = page.locator("xpath=//input[@id='accountHolderField']"); // @FindBy(xpath = "//input[@id='accountHolderField']")  // @id='cardHolderField'     protected WebElement paymentusAccountHolderInput;     @FindBy(xpath = "//span[contains(@class,'pm-display-logo-visa')]")
    this.cardNumberInputField = page.locator("xpath=//input[@id='cardNumberField']"); // @FindBy(xpath = "//input[@id='cardNumberField']")
    this.masterCardIcon = page.locator("xpath=//span[contains(@class,'pm-display-logo-mc')]"); // @FindBy(xpath = "//span[contains(@class,'pm-display-logo-mc')]")
    this.discoverCardIcon = page.locator("xpath=//span[contains(@class,'pm-display-logo-disc')]"); // @FindBy(xpath = "//span[contains(@class,'pm-display-logo-disc')]")
    this.amexCardIcon = page.locator("xpath=//span[contains(@class,'pm-display-logo-amex')]"); // @FindBy(xpath = "//span[contains(@class,'pm-display-logo-amex')]")
    this.paymentusAccountHolderLabel = page.locator("xpath=//label[@for='accountHolderField']"); // @FindBy(xpath = "//label[@for='accountHolderField']")
    this.paymentusCardHolderInput = page.locator("xpath=//input[@id='cardHolderField']"); // @FindBy(xpath = "//input[@id='cardHolderField']")
    this.paymentusCardHolderLabel = page.locator("xpath=//label[@for='cardHolderField']"); // @FindBy(xpath = "//label[@for='cardHolderField']")
    this.paymentusRoutingNumberInput = page.locator("xpath=//input[@id='routingNumberField']"); // @FindBy(xpath = "//input[@id='routingNumberField']")
    this.paymentusRoutingNumberLabel = page.locator("xpath=//label[@for='routingNumberField']"); // @FindBy(xpath = "//label[@for='routingNumberField']")
    this.paymentusCardNumberInput = page.locator("xpath=//input[@id='cardNumberField']"); // @FindBy(xpath = "//input[@id='cardNumberField']")
    this.paymentusCardNumberLabel = page.locator("xpath=//label[@for='cardNumberField']"); // @FindBy(xpath = "//label[@for='cardNumberField']")
    this.paymentusVisaCardIcon = page.locator("xpath=//div[contains(@class,'methodVisa')]"); // @FindBy(xpath = "//div[contains(@class,'methodVisa')]")
    this.paymentusMasterCardIcon = page.locator("xpath=//div[contains(@class,'methodMastercard')]"); // @FindBy(xpath = "//div[contains(@class,'methodMastercard')]")
    this.paymentusDiscoverCardIcon = page.locator("xpath=//div[contains(@class,'methodDiscover')]"); // @FindBy(xpath = "//div[contains(@class,'methodDiscover')]")
    this.paymentusAmexCardIcon = page.locator("xpath=//div[contains(@class,'methodAmex')]"); // @FindBy(xpath = "//div[contains(@class,'methodAmex')]")
    this.paymentusAccountNumberInput = page.locator("xpath=//input[@id='bankAccountField']"); // @FindBy(xpath = "//input[@id='bankAccountField']")
    this.paymentusAccountNumberLabel = page.locator("xpath=//label[@for='bankAccountField']"); // @FindBy(xpath = "//label[@for='bankAccountField']")
    this.paymentusCardExpirationDateInput = page.locator("xpath=//input[@id='ccExpirationDate']"); // @FindBy(xpath = "//input[@id='ccExpirationDate']")
    this.paymentusCardExpirationDateLabel = page.locator("xpath=//label[@for='ccExpirationDate']"); // @FindBy(xpath = "//label[@for='ccExpirationDate']")
    this.paymentusCardCVVFieldInput = page.locator("xpath=//input[@id='cardCVVField']"); // @FindBy(xpath = "//input[@id='cardCVVField']")
    this.paymentusCardCVVFieldLabel = page.locator("xpath=//label[@for='cardCVVField']"); // @FindBy(xpath = "//label[@for='cardCVVField']")
    this.paymentusZipCodeInput = page.locator("xpath=//input[@id='zipCode']"); // @FindBy(xpath = "//input[@id='zipCode']")
    this.paymentusZipCodeLabel = page.locator("xpath=//label[@for='zipCode']"); // @FindBy(xpath = "//label[@for='zipCode']")
    this.paymentusConfirmAccountNumberInput = page.locator("xpath=//input[@id='confirmBankAccountField']"); // @FindBy(xpath = "//input[@id='confirmBankAccountField']")
    this.paymentusConfirmAccountNumberLabel = page.locator("xpath=//label[@for='confirmBankAccountField']"); // @FindBy(xpath = "//label[@for='confirmBankAccountField']")
    this.paymentusAddButton = page.locator("xpath=//button[@name='submitBtn']"); // @FindBy(xpath = "//button[@name='submitBtn']")
    this.changePaymentMethodLink = page.locator("xpath=//a[contains(.,'Change')]"); // @FindBy(xpath = "//a[contains(.,'Change')]")
    this.enterValidAccountHolderNameError = page.locator("xpath=//span[text() = '"); // @FindBy(xpath = "//span[text() = '" + ENTER_VALID_ACCOUNT_HOLDER_NAME_ERROR + "']")
    this.enterValidRoutingNumberError = page.locator("xpath=//span[text() = '"); // @FindBy(xpath = "//span[text() = '" + ENTER_VALID_ROUTING_NUMBER_ERROR + "']")
    this.enterValidAccountNumberError = page.locator("xpath=//span[text() = '"); // @FindBy(xpath = "//span[text() = '" + ENTER_VALID_ACCOUNT_NUMBER_ERROR + "']")
    this.bankAccountNumbersDoNotMatchError = page.locator("xpath=//span[text() = '"); // @FindBy(xpath = "//span[text() = '" + BANK_ACCOUNT_NUMBERS_DO_NOT_MATCH_ERROR + "']")
  }
}
