// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.BristolWestLandingPage. */
export class BristolWestLandingPage extends CoreBasePage {
  public readonly pageHeader: Locator;
  public readonly zipCodeInput: Locator;
  public readonly zipCodeInputMobileView: Locator;
  public readonly startQuoteButton: Locator;
  public readonly startQuoteButtonMobileView: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageHeader = page.locator("#bw-main-content"); // @FindBy(id = "bw-main-content")
    this.zipCodeInput = page.locator("xpath=//div[@class='hero-split__input-field']//input"); // @FindBy(xpath = "//div[@class='hero-split__input-field']//input")
    this.zipCodeInputMobileView = page.locator("xpath=//div[@class='hero-split__mobile-input-inner']//input"); // @FindBy(xpath = "//div[@class='hero-split__mobile-input-inner']//input")
    this.startQuoteButton = page.locator("xpath=//button[@class='hero-split__button start-quote-btn']"); // @FindBy(xpath = "//button[@class='hero-split__button start-quote-btn']")
    this.startQuoteButtonMobileView = page.locator("xpath=//button[@class='hero-split__mobile-button start-quote-btn']"); // @FindBy(xpath = "//button[@class='hero-split__mobile-button start-quote-btn']")
  }
}
