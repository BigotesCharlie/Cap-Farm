// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.LandingPage. */
export class LandingPage extends CoreBasePage {
  public readonly landingPageDisclaimer: Locator;
  public readonly startMyQuoteButton: Locator;
  public readonly getNewQuoteRadioButton: Locator;
  public readonly retrieveSavedQuoteRadioButton: Locator;
  public readonly dropdownLOBLabel: Locator;
  public readonly dropdownLOB: Locator;
  public readonly zipCodeLabel: Locator;
  public readonly zipCodeField: Locator;
  public readonly submitButton: Locator;
  public readonly lastNameLabel: Locator;
  public readonly lastNameField: Locator;
  public readonly dateOfBirthLabel: Locator;
  public readonly dateOfBirthField: Locator;
  public readonly quoteNumberLabel: Locator;
  public readonly quoteNumberField: Locator;
  public readonly zipCodeForRetrieveLabel: Locator;
  public readonly zipCodeForRetrieveField: Locator;
  public readonly unableToLocateQuoteDialog: Locator;
  public readonly retrieveQuoteButton: Locator;
  public readonly footerStaticText: Locator;
  public readonly quoteTypeErrorMessage: Locator;
  public readonly zipCodeEntryErrorMessage: Locator;
  public readonly zipCodeErrorMessage: Locator;
  public readonly lastNameErrorMessage: Locator;
  public readonly dateOfBirthErrorMessage: Locator;
  public readonly emailQuoteNumberErrorMessage: Locator;
  public readonly zipCodeInRetrieveErrorMessage: Locator;
  public readonly quoteRetrievalErrorMessage: Locator;
  public readonly buttonCloseErrorDialog: Locator;
  public readonly getNewQuoteTab: Locator;
  public readonly retrieveSavedQuoteTab: Locator;
  public readonly selectProductErrorMessage: Locator;
  public readonly autoLOBButton: Locator;
  public readonly homeLOBButton: Locator;
  public readonly lifeLOBButton: Locator;
  public readonly businessLOBButton: Locator;
  public readonly rentersLOBButton: Locator;
  public readonly mobileHomeLOBButton: Locator;
  public readonly condoLOBButton: Locator;
  public readonly autoHomeBundleButton: Locator;
  public readonly autoRentersBundleButton: Locator;
  public readonly autoCondoBundleButton: Locator;
  public readonly infoDialogContent: Locator;
  public readonly infoDialogCloseButton: Locator;
  public readonly buttonAuto: Locator;
  public readonly buttonHome: Locator;
  public readonly buttonRenters: Locator;
  public readonly buttonMobileHome: Locator;
  public readonly buttonLife: Locator;
  public readonly buttonBusiness: Locator;
  public readonly zipCodeInput: Locator;
  public readonly buttonGetMyQuoteMobile: Locator;
  public readonly buttonGetMyQuoteDesktop: Locator;
  public readonly retrieveSavedQuoteLink: Locator;

  public constructor(page: Page) {
    super(page);
    this.landingPageDisclaimer = page.locator(".ffq-landing-disclaimer"); // @FindBy(className = "ffq-landing-disclaimer")
    this.startMyQuoteButton = page.locator("xpath=//button[contains(text(), 'START QUOTE')]"); // @FindBy(xpath = "//button[contains(text(), 'START QUOTE')]")
    this.getNewQuoteRadioButton = page.locator("#landing:DecideQuote:0"); // @FindBy(id = "landing:DecideQuote:0")
    this.retrieveSavedQuoteRadioButton = page.locator("#landing:DecideQuote:1"); // @FindBy(id = "landing:DecideQuote:1")
    this.dropdownLOBLabel = page.locator("#landing:quoteTypeLbl"); // @FindBy(id = "landing:quoteTypeLbl")
    this.dropdownLOB = page.locator("#landing:quoteType"); // @FindBy(id = "landing:quoteType")
    this.zipCodeLabel = page.locator("#landing:zipCodeLbl"); // @FindBy(id = "landing:zipCodeLbl")
    this.zipCodeField = page.locator("[data-legacy-field=\"zipCodeField\"]"); // @FindBy(xpath = XPATH_TO_ZIP_CODE_FIELD)
    this.submitButton = page.locator("button[data-gtm='FFQ_Auto_Landing_Newquote_Startmyquote_button']"); // @FindBy(xpath = XPATH_TO_SUBMIT_BUTTON),             @FindBy(css = "button[data-gtm='FFQ_Auto_Landing_Newquote_Startmyquote_button']")     })
    this.lastNameLabel = page.locator("#landing:lastNameLbl"); // @FindBy(id = "landing:lastNameLbl")
    this.lastNameField = page.locator("xpath=//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Lastname_field']//input"); // @FindBy(xpath = "//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Lastname_field']//input")
    this.dateOfBirthLabel = page.locator("#landing:dateOfBirthLbl"); // @FindBy(id = "landing:dateOfBirthLbl")
    this.dateOfBirthField = page.locator("xpath=//lib-date-picker[@data-gtm='FFQ_Auto_Landing_Retrievequote_Dateofbirth_field']//input[string-length(@aria-label)>0]"); // @FindBy(xpath = "//lib-date-picker[@data-gtm='FFQ_Auto_Landing_Retrievequote_Dateofbirth_field']//input[string-length(@aria-label)>0]")
    this.quoteNumberLabel = page.locator("#landing:emailquotenumberLbl"); // @FindBy(id = "landing:emailquotenumberLbl")
    this.quoteNumberField = page.locator("xpath=//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Quotenumber_field']//input"); // @FindBy(xpath = "//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Quotenumber_field']//input")
    this.zipCodeForRetrieveLabel = page.locator("#landing:zipcode2Lbl"); // @FindBy(id = "landing:zipcode2Lbl")
    this.zipCodeForRetrieveField = page.locator("xpath=//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Zipcode_field']//input"); // @FindBy(xpath = "//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Zipcode_field']//input")
    this.unableToLocateQuoteDialog = page.locator("[data-legacy-field=\"unableToLocateQuoteDialog\"]"); // @FindBy(id = UNABLE_TO_LOCATE_QUOTE_ID_STRING)
    this.retrieveQuoteButton = page.locator("button[data-gtm='FFQ_Auto_Landing_Retrievequote_button']"); // @FindBy(xpath = XPATH_TO_RETRIEVE_BUTTON),             @FindBy(css = "button[data-gtm='FFQ_Auto_Landing_Retrievequote_button']")     })
    this.footerStaticText = page.locator("xpath=//*[@id='DisclaimerLanding']/p/span"); // @FindBy(xpath = "//*[@id='DisclaimerLanding']/p/span")
    this.quoteTypeErrorMessage = page.locator("#quoteTypeError"); // @FindBy(id = "quoteTypeError")
    this.zipCodeEntryErrorMessage = page.locator("xpath=//div[@id='ffq-landing-zip-code']//mat-error"); // @FindBy(xpath = "//div[@id='ffq-landing-zip-code']//mat-error")
    this.zipCodeErrorMessage = page.locator("xpath=//div[@class='ffq-landing-show-zip-err ng-star-inserted'] | //p[@id='zipCodeError']"); // @FindBy(xpath = "//div[@class='ffq-landing-show-zip-err ng-star-inserted'] | //p[@id='zipCodeError']")
    this.lastNameErrorMessage = page.locator("xpath=//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Lastname_field']//mat-error"); // @FindBy(xpath = "//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Lastname_field']//mat-error")
    this.dateOfBirthErrorMessage = page.locator("xpath=//lib-date-picker[@data-gtm='FFQ_Auto_Landing_Retrievequote_Dateofbirth_field']//mat-error"); // @FindBy(xpath = "//lib-date-picker[@data-gtm='FFQ_Auto_Landing_Retrievequote_Dateofbirth_field']//mat-error")
    this.emailQuoteNumberErrorMessage = page.locator("xpath=//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Quotenumber_field']//mat-error"); // @FindBy(xpath = "//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Quotenumber_field']//mat-error")
    this.zipCodeInRetrieveErrorMessage = page.locator("xpath=//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Zipcode_field']//mat-error"); // @FindBy(xpath = "//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Zipcode_field']//mat-error")
    this.quoteRetrievalErrorMessage = page.locator("xpath=//div[h2[contains(text(),'We were unable to locate your quote')]]"); // @FindBy(xpath = "//div[h2[contains(text(),'We were unable to locate your quote')]]")
    this.buttonCloseErrorDialog = page.locator("xpath=//div[h2[contains(text(),'We were unable to locate your quote')]]//button[text()='CLOSE']"); // @FindBy(xpath = "//div[h2[contains(text(),'We were unable to locate your quote')]]//button[text()='CLOSE']")
    this.getNewQuoteTab = page.locator("#landing-quote"); // @FindBy(id = "landing-quote")
    this.retrieveSavedQuoteTab = page.locator("#landing-retrieve"); // @FindBy(id = "landing-retrieve")
    this.selectProductErrorMessage = page.locator("xpath=//div/p[@class='ffq-landing-showproduct-err ng-star-inserted']"); // @FindBy(xpath = "//div/p[@class='ffq-landing-showproduct-err ng-star-inserted']")
    this.autoLOBButton = page.locator("xpath=//*[@value='auto']"); // @FindBy(xpath = "//*[@value='auto']")
    this.homeLOBButton = page.locator("xpath=//*[@value='home']"); // @FindBy(xpath = "//*[@value='home']")
    this.lifeLOBButton = page.locator("xpath=//*[@value='life']"); // @FindBy(xpath = "//*[@value='life']")
    this.businessLOBButton = page.locator("xpath=//*[@value='business']"); // @FindBy(xpath = "//*[@value='business']")
    this.rentersLOBButton = page.locator("xpath=//*[@value='renter']"); // @FindBy(xpath = "//*[@value='renter']")
    this.mobileHomeLOBButton = page.locator("xpath=//*[@value='mobilehome']"); // @FindBy(xpath = "//*[@value='mobilehome']")
    this.condoLOBButton = page.locator("xpath=//*[@value='condo']"); // @FindBy(xpath = "//*[@value='condo']")
    this.autoHomeBundleButton = page.locator("xpath=//*[@value='autoHome']"); // @FindBy(xpath = "//*[@value='autoHome']")
    this.autoRentersBundleButton = page.locator("xpath=//*[@value='autoRenters']"); // @FindBy(xpath = "//*[@value='autoRenters']")
    this.autoCondoBundleButton = page.locator("xpath=//*[@value='autoCondo']"); // @FindBy(xpath = "//*[@value='autoCondo']")
    this.infoDialogContent = page.locator("#infoContent"); // @FindBy(css = "#infoContent")
    this.infoDialogCloseButton = page.locator(".dialog__info-dialog-button-close"); // @FindBy(css = ".dialog__info-dialog-button-close")
    this.buttonAuto = page.locator("xpath=//div//button[@data-id='Auto']"); // @FindBy(xpath ="//div//button[@data-id='Auto']")
    this.buttonHome = page.locator("xpath=//div//button[@data-id='Home']"); // @FindBy(xpath ="//div//button[@data-id='Home']")
    this.buttonRenters = page.locator("xpath=//div//button[@data-id='Renter']"); // @FindBy(xpath ="//div//button[@data-id='Renter']")
    this.buttonMobileHome = page.locator("xpath=//div//button[@data-id='mobilehome']"); // @FindBy(xpath ="//div//button[@data-id='mobilehome']")
    this.buttonLife = page.locator("xpath=//div//button[@data-id='Life']"); // @FindBy(xpath ="//div//button[@data-id='Life']")
    this.buttonBusiness = page.locator("xpath=//div//button[@data-id='Business']"); // @FindBy(xpath ="//div//button[@data-id='Business']")
    this.zipCodeInput = page.locator("xpath=//form//input[@name='Zip_Code']"); // @FindBy(xpath ="//form//input[@name='Zip_Code']")
    this.buttonGetMyQuoteMobile = page.locator("xpath=//form//button[contains(@class,'button-cta--mobile') and contains(.,'Get my quote')]"); // @FindBy(xpath ="//form//button[contains(@class,'button-cta--mobile') and contains(.,'Get my quote')]")
    this.buttonGetMyQuoteDesktop = page.locator("xpath=//form//button[contains(@class,'button-cta--desktop') and contains(.,'Get my quote')]"); // @FindBy(xpath ="//form//button[contains(@class,'button-cta--desktop') and contains(.,'Get my quote')]"),             @FindBy(xpath ="//form//button[contains(@class,'button-cta--desktop') and contains(.,'Get a quote')]")     })
    this.retrieveSavedQuoteLink = page.locator("xpath=//a[@data-gtm='Farmers_GroupLandingPage_ProductGrid_MobileTextDataLink_Body']"); // @FindBy(xpath ="//a[@data-gtm='Farmers_GroupLandingPage_ProductGrid_MobileTextDataLink_Body']")
  }
}
