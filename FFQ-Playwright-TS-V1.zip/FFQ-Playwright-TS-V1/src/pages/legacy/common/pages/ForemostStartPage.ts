// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.ForemostStartPage. */
export class ForemostStartPage extends CoreBasePage {
  public readonly seeAllOurProductsButtonElement: Locator;
  public readonly zipCodeInputField: Locator;
  public readonly shortTermRentalCheckbox: Locator;
  public readonly getAQuoteButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.seeAllOurProductsButtonElement = page.locator("xpath=//a[contains(@href, '/insurance')][@class]"); // @FindBy(xpath = "//a[contains(@href, '/insurance')][@class]")
    this.zipCodeInputField = page.locator("#zip"); // @FindBy(id = "zip")
    this.shortTermRentalCheckbox = page.locator("xpath=//input[contains(@class,'mdc-checkbox')]"); // @FindBy(xpath = "//input[contains(@class,'mdc-checkbox')]")
    this.getAQuoteButton = page.locator("xpath=//input[@data-gtm='Get a Quote'] | //a[contains(., 'Get a quote')]"); // @FindBy(xpath  = "//input[@data-gtm='Get a Quote'] | //a[contains(., 'Get a quote')]")
  }
}
