// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.common.pages.PolicyPaymentBasePage. */
export class PolicyPaymentBasePage extends CoreBasePage {
  public readonly autoPolicyPaymentHeader: Locator;
  public readonly feeSideBarHeader: Locator;
  public readonly membershipFeeMessageSideBar: Locator;
  public readonly policyFeeMessageSideBar: Locator;
  public readonly vehicleFeeMessageSideBar: Locator;
  public readonly sixMonthTermPayment: Locator;
  public readonly sixTermPriceSubHeader: Locator;
  public readonly fees: Locator;
  public readonly dueTodayLabel: Locator;
  public readonly setUpPaymentMethodButton: Locator;
  public readonly setUpPaymentMethodButtonInIframe: Locator;
  public readonly addPaymentMethodContainerCloseIcon: Locator;
  public readonly addPaymentMethodDialogContainer: Locator;
  public readonly addButton: Locator;
  public readonly addPaymentMethodLabel: Locator;
  public readonly addBankHeader: Locator;
  public readonly bankPaymentButton: Locator;
  public readonly bankButton: Locator;
  public readonly debitCreditCardButton: Locator;
  public readonly cardButtonIframe: Locator;
  public readonly cardButton: Locator;
  public readonly paperlessTermsOfUseLink: Locator;
  public readonly informationStorageAuthorizationLink: Locator;
  public readonly paymentAuthorizationLink: Locator;
  public readonly byClickingCompletePurchaseLabel: Locator;
  public readonly readAndAgreedToTheBulletPointOne: Locator;
  public readonly ifDoNotAgreeWithTermsAndConditionLabel: Locator;
  public readonly completePurchaseButton: Locator;
  public readonly finishDocumentsButton: Locator;
  public readonly finishDocumentsSection: Locator;
  public readonly paymentMethodAlreadyAdded: Locator;
  public readonly readAndAgreedToTheBulletPointTwoMonthlyPay: Locator;
  public readonly readAndAgreedToTheBulletPointTwo: Locator;
  public readonly payInFullHeader: Locator;
  public readonly selectPreferredPaymentMethod: Locator;
  public readonly useBankDebitCreditCard: Locator;
  public readonly noServiceChargesWhenPayInFull: Locator;
  public readonly monthlyAutoPayBankHeader: Locator;
  public readonly monthlyAutoPayCardHeader: Locator;
  public readonly monthlyDirectBillHeader: Locator;
  public readonly firstMonthlyPaymentLabel: Locator;
  public readonly feesLabel: Locator;
  public readonly selectPreferredPaymentLabel: Locator;
  public readonly bankPaymentRadiobutton: Locator;
  public readonly bankPaymentRadiobuttonInIframe: Locator;
  public readonly changeBankPaymentRadiobutton: Locator;
  public readonly bankPaymentRadiobuttonAlternate: Locator;
  public readonly bankPaymentRadiobuttonLabel: Locator;
  public readonly bankPaymentRadiobuttonSideSheet: Locator;
  public readonly bankPaymentLabel: Locator;
  public readonly cardPaymentLabel: Locator;
  public readonly dollarZeroLabel: Locator;
  public readonly inServiceChargesElement: Locator;
  public readonly cardPaymentRadiobutton: Locator;
  public readonly cardPaymentRadiobuttonAlternative: Locator;
  public readonly cardPaymentRadiobuttonLabel: Locator;
  public readonly changeCardPaymentRadiobutton: Locator;
  public readonly futureMonthlyChargesLabel: Locator;
  public readonly debitCardServiceChargeLabel: Locator;
  public readonly creditCardServiceChargeLabel: Locator;

  public constructor(page: Page) {
    super(page);
    this.autoPolicyPaymentHeader = page.locator("xpath=//h1[contains(text(), '"); // @FindBy(xpath = "//h1[contains(text(), '" + AUTO_POLICY_PAYMENT_HEADER + "')]")
    this.feeSideBarHeader = page.locator("xpath=//p[contains(@class,'tui-info-box-header')]"); // @FindBy(xpath = "//p[contains(@class,'tui-info-box-header')]")
    this.membershipFeeMessageSideBar = page.locator("xpath=//p[contains(text(), 'A membership fee per vehicle is applied ')]"); // @FindBy(xpath = "//p[contains(text(), 'A membership fee per vehicle is applied ')]")
    this.policyFeeMessageSideBar = page.locator("xpath=//p[contains(text(), 'A policy fee per vehicle is applied for new auto')]"); // @FindBy(xpath = "//p[contains(text(), 'A policy fee per vehicle is applied for new auto')]")
    this.vehicleFeeMessageSideBar = page.locator("xpath=//p[contains(text(), 'A fee per vehicle is applied for new auto')]"); // @FindBy(xpath = "//p[contains(text(), 'A fee per vehicle is applied for new auto')]")
    this.sixMonthTermPayment = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + SIX_MONTH_TERM_PAYMENT + "')]")
    this.sixTermPriceSubHeader = page.locator("xpath=//span[contains(text(), '6-month term price')]"); // @FindBy(xpath = "//span[contains(text(), '6-month term price')]")
    this.fees = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + FEES + "')]")
    this.dueTodayLabel = page.locator("xpath=//section[contains(@class,'autopay-details')]//*[contains(text(),'"); // @FindBy(xpath = "//section[contains(@class,'autopay-details')]//*[contains(text(),'" + DUE_TODAY_LABEL + "')]")
    this.setUpPaymentMethodButton = page.locator("[data-legacy-field=\"setUpPaymentMethodButton\"]"); // @FindBy(xpath = SET_UP_PAYMENT_METHOD_XPATH)
    this.setUpPaymentMethodButtonInIframe = page.locator("xpath=//mat-dialog-container//button[contains(text(),'"); // @FindBy(xpath = "//mat-dialog-container//button[contains(text(),'" + SET_UP_PAYMENT_METHOD + "')]")
    this.addPaymentMethodContainerCloseIcon = page.locator("xpath=//mat-icon[contains(text(), 'close')]"); // @FindBy(xpath = "//mat-icon[contains(text(), 'close')]")
    this.addPaymentMethodDialogContainer = page.locator("xpath=//mat-dialog-container[@aria-labelledby='addPaymentHeading']"); // @FindBy(xpath = "//mat-dialog-container[@aria-labelledby='addPaymentHeading']")
    this.addButton = page.locator("xpath=//button[@name='submitBtn']"); // @FindBy(xpath = "//button[@name='submitBtn']")
    this.addPaymentMethodLabel = page.locator("xpath=//h1[text() = '"); // @FindBy(xpath = "//h1[text() = '" + ADD_PAYMENT_METHOD_LABEL + "']")
    this.addBankHeader = page.locator("xpath=//h1[contains(text(), '"); // @FindBy(xpath = "//h1[contains(text(), '" + ADD_BANK + "')]")
    this.bankPaymentButton = page.locator("xpath=//app-add-payment//*[contains(text(),'"); // @FindBy(xpath = "//app-add-payment//*[contains(text(),'" + BANK_PAYMENT_BUTTON_TEXT + "')]")
    this.bankButton = page.locator("xpath=//app-add-payment//*[contains(text(),'"); // @FindBy(xpath = "//app-add-payment//*[contains(text(),'" + BANK_BUTTON_TEXT + "')]")
    this.debitCreditCardButton = page.locator("xpath=//div[@role='tab']//span[contains(text(),'Debit / Credit card')]"); // @FindBy(xpath = "//div[@role='tab']//span[contains(text(),'Debit / Credit card')]")
    this.cardButtonIframe = page.locator("xpath=//div[@role='tab']//span[contains(text(),'Card')]"); // @FindBy(xpath = "//div[@role='tab']//span[contains(text(),'Card')]")
    this.cardButton = page.locator("xpath=//div[@class='mat-tab-label-content' and contains(text(),'"); // @FindBy(xpath = "//div[@class='mat-tab-label-content' and contains(text(),'" + CARD_BUTTON + "')]")
    this.paperlessTermsOfUseLink = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]")
    this.informationStorageAuthorizationLink = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]")
    this.paymentAuthorizationLink = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + PAYMENT_AUTHORIZATION + "')]")
    this.byClickingCompletePurchaseLabel = page.locator("xpath=//div[contains(text(), '"); // @FindBy(xpath = "//div[contains(text(), '" + BY_CLICKING_COMPLETER_PURCHASE + "')]")
    this.readAndAgreedToTheBulletPointOne = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]/parent::p")
    this.ifDoNotAgreeWithTermsAndConditionLabel = page.locator("xpath=//p[contains(text(), 'If you do not agree with the Terms and Conditions above ')]"); // @FindBy(xpath = "//p[contains(text(), 'If you do not agree with the Terms and Conditions above ')]")
    this.completePurchaseButton = page.locator("xpath=//button[contains(text(), '"); // @FindBy(xpath = "//button[contains(text(), '" + COMPLETE_PURCHASE_BUTTON + "')]")
    this.finishDocumentsButton = page.locator("xpath=//button[contains(text(), '"); // @FindBy(xpath = "//button[contains(text(), '" + FINISH_DOCUMENTS_BUTTON + "')]")
    this.finishDocumentsSection = page.locator("xpath=//section[contains(@class,'document-sign-card-compact')]"); // @FindBy(xpath = "//section[contains(@class,'document-sign-card-compact')]")
    this.paymentMethodAlreadyAdded = page.locator("xpath=//li[@id='profile']"); // @FindBy(xpath = "//li[@id='profile']")
    this.readAndAgreedToTheBulletPointTwoMonthlyPay = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p")
    this.readAndAgreedToTheBulletPointTwo = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p")
    this.payInFullHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL_HEADER + "')]")
    this.selectPreferredPaymentMethod = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + ADD_YOUR_PREFERRED_PAYMENT_METHOD1 + "')]")
    this.useBankDebitCreditCard = page.locator("xpath=//p[contains(text(), 'bank payment, debit card, or credit')]"); // @FindBy(xpath = "//p[contains(text(), 'bank payment, debit card, or credit')]")
    this.noServiceChargesWhenPayInFull = page.locator("xpath=//p[contains(text(), 'No service charges when you pay in full')]"); // @FindBy(xpath = "//p[contains(text(), 'No service charges when you pay in full')]")
    this.monthlyAutoPayBankHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_BANK_HEADER + "')]")
    this.monthlyAutoPayCardHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_CARD_HEADER + "')]")
    this.monthlyDirectBillHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_DIRECT_BILL + "')]")
    this.firstMonthlyPaymentLabel = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + FIRST_MONTHLY_PAYMENT + "')]")
    this.feesLabel = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + FEES_LABEL + "')]")
    this.selectPreferredPaymentLabel = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + SELECT_PREFERRED_PAYMENT_LABEL + "')]")
    this.bankPaymentRadiobutton = page.locator("xpath=//input[@value='bank-transfer']"); // @FindBy(xpath = "//input[@value='bank-transfer']")
    this.bankPaymentRadiobuttonInIframe = page.locator("xpath=//mat-dialog-content//input[@value='bank-transfer']"); // @FindBy(xpath = "//mat-dialog-content//input[@value='bank-transfer']")
    this.changeBankPaymentRadiobutton = page.locator("xpath=//label[contains(text(),'Bank payment')]/preceding::input[@value='bank-transfer']"); // @FindBy(xpath = "//label[contains(text(),'Bank payment')]/preceding::input[@value='bank-transfer']")
    this.bankPaymentRadiobuttonAlternate = page.locator("xpath=//mat-radio-button[@value='bank-transfer']"); // @FindBy(xpath = "//mat-radio-button[@value='bank-transfer']")
    this.bankPaymentRadiobuttonLabel = page.locator("xpath=//mat-radio-button[@value='bank-transfer']//label"); // @FindBy(xpath = "//mat-radio-button[@value='bank-transfer']//label")
    this.bankPaymentRadiobuttonSideSheet = page.locator("xpath=//mat-radio-group[@name='monthly-autopay-options-sidesheet']//mat-radio-button[@value='bank-transfer']"); // @FindBy(xpath = "//mat-radio-group[@name='monthly-autopay-options-sidesheet']//mat-radio-button[@value='bank-transfer']")
    this.bankPaymentLabel = page.locator("xpath=//mat-radio-button[@value='bank-transfer']//label"); // @FindBy(xpath = "//mat-radio-button[@value='bank-transfer']//label")
    this.cardPaymentLabel = page.locator("xpath=//mat-radio-button[@value='card']//label"); // @FindBy(xpath = "//mat-radio-button[@value='card']//label")
    this.dollarZeroLabel = page.locator("xpath=//span[contains(text(), '$0')]"); // @FindBy(xpath = "//span[contains(text(), '$0')]")
    this.inServiceChargesElement = page.locator("xpath=//li[contains(.,'"); // @FindBy(xpath = "//li[contains(.,'" + IN_SERVICE_CHARGES_LABEL + "')]")
    this.cardPaymentRadiobutton = page.locator("xpath=//p[contains(text(),' Select your preferred payment method. ')]//following::mat-radio-button[@value='card']"); // @FindBy(xpath = "//p[contains(text(),' Select your preferred payment method. ')]//following::mat-radio-button[@value='card']")     @FindBy(xpath = "//input[@value='card']")
    this.cardPaymentRadiobuttonAlternative = page.locator("xpath=//mat-radio-button[@value='card']"); // @FindBy(xpath = "//mat-radio-button[@value='card']")
    this.cardPaymentRadiobuttonLabel = page.locator("xpath=//mat-radio-button[@value='card']//label"); // @FindBy(xpath = "//mat-radio-button[@value='card']//label")
    this.changeCardPaymentRadiobutton = page.locator("xpath=//label[contains(text(),'Card')]/preceding::input[@value='card']"); // @FindBy(xpath = "//label[contains(text(),'Card')]/preceding::input[@value='card']")
    this.futureMonthlyChargesLabel = page.locator("xpath=//p[contains(text(), 'Future monthly service charge:')]"); // @FindBy(xpath = "//p[contains(text(), 'Future monthly service charge:')]")
    this.debitCardServiceChargeLabel = page.locator("xpath=//li[contains(.,'Debit card')]"); // @FindBy(xpath = "//li[contains(.,'Debit card')]")
    this.creditCardServiceChargeLabel = page.locator("xpath=//li[contains(.,'Credit card')]"); // @FindBy(xpath = "//li[contains(.,'Credit card')]")
  }
}
