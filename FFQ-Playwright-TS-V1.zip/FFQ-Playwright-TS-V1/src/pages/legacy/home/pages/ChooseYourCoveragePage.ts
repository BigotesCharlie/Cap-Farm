// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.home.pages.ChooseYourCoveragePage. */
export class ChooseYourCoveragePage extends CoreBasePage {
  public readonly packagesSideBySideStaticText1: Locator;
  public readonly packagesSideBySideStaticText2: Locator;
  public readonly estimatedReconstructionCostText: Locator;
  public readonly stdPckgPremiumAmountText: Locator;
  public readonly enhancedPckgPremiumAmountText: Locator;
  public readonly premierPckgPremiumAmountText: Locator;
  public readonly preQualifiedDiscountsText: Locator;
  public readonly standardButton: Locator;
  public readonly enhancedButton: Locator;
  public readonly premierButton: Locator;
  public readonly estimatedReconstructionCostValue: Locator;
  public readonly continueBtn: Locator;
  public readonly saveAndFinishLaterBtn: Locator;
  public readonly visitFcomButton: Locator;
  public readonly arrowDownStandrtPck: Locator;
  public readonly arrowDownEnhancedPck: Locator;
  public readonly arrowDownPremierPck: Locator;
  public readonly standardPackageDescriptionText: Locator;
  public readonly enhancedPackageDescriptionText: Locator;
  public readonly premierPackageDescriptionText: Locator;
  public readonly standardPackagePremiumAmount: Locator;
  public readonly enhancedPackagePremiumAmount: Locator;
  public readonly premierPackagePremiumAmount: Locator;
  public readonly standardPckTitle: Locator;
  public readonly enhancedPckTitle: Locator;
  public readonly premierPckTitle: Locator;
  public readonly updateQuoteBtn: Locator;
  public readonly yourInfoNavBarText: Locator;
  public readonly propertyNavBarText: Locator;
  public readonly coverageNavBarText: Locator;
  public readonly quoteNavBarText: Locator;
  public readonly blueNavBar: Locator;
  public readonly headerLogo: Locator;
  public readonly reviewAndChooseSubHeaderText: Locator;
  public readonly footerDisclaimerStaticText: Locator;
  public readonly briefSummaryStaticText: Locator;
  public readonly digiCertImageLogo: Locator;

  public constructor(page: Page) {
    super(page);
    this.packagesSideBySideStaticText1 = page.locator("#homequote:packCompHeader9"); // @FindBy(id = "homequote:packCompHeader9")
    this.packagesSideBySideStaticText2 = page.locator("#homequote:packCompHeader22"); // @FindBy(id = "homequote:packCompHeader22")
    this.estimatedReconstructionCostText = page.locator("xpath=//*[@id='ComparePaymentOptions']/div[1]/p[2]"); // @FindBy(xpath = "//*[@id='ComparePaymentOptions']/div[1]/p[2]")
    this.stdPckgPremiumAmountText = page.locator("#homequote:stdPckgPremium22"); // @FindBy(id = "homequote:stdPckgPremium22")
    this.enhancedPckgPremiumAmountText = page.locator("#homequote:enhancedPckgPremium33"); // @FindBy(id = "homequote:enhancedPckgPremium33")
    this.premierPckgPremiumAmountText = page.locator("#homequote:premierPckgPremium33"); // @FindBy(id = "homequote:premierPckgPremium33")
    this.preQualifiedDiscountsText = page.locator("#homequote:homeDiscountNames"); // @FindBy(id = "homequote:homeDiscountNames")
    this.standardButton = page.locator("xpath=//*[@id='homequote:radioInfo:0:packagesMode']/tbody/tr/td/input"); // @FindBy(xpath = "//*[@id='homequote:radioInfo:0:packagesMode']/tbody/tr/td/input")
    this.enhancedButton = page.locator("xpath=//*[@id='homequote:radioInfo:1:packagesMode']/tbody/tr/td/input"); // @FindBy(xpath = "//*[@id='homequote:radioInfo:1:packagesMode']/tbody/tr/td/input")
    this.premierButton = page.locator("xpath=//*[@id='homequote:radioInfo:2:packagesMode']/tbody/tr/td/input"); // @FindBy(xpath = "//*[@id='homequote:radioInfo:2:packagesMode']/tbody/tr/td/input")
    this.estimatedReconstructionCostValue = page.locator("xpath=//*[@id='ComparePaymentOptions']/div[1]/p[2]"); // @FindBy(xpath = "//*[@id='ComparePaymentOptions']/div[1]/p[2]")
    this.continueBtn = page.locator("#homequote:submit"); // @FindBy(id = "homequote:submit")
    this.saveAndFinishLaterBtn = page.locator("#renterSave"); // @FindBy(id = "renterSave")
    this.visitFcomButton = page.locator("xpath=//*[@id='contButtonCA']/a"); // @FindBy(xpath = "//*[@id='contButtonCA']/a")
    this.arrowDownStandrtPck = page.locator(".ArrowS.arrowDown"); // @FindBy(css = ".ArrowS.arrowDown")
    this.arrowDownEnhancedPck = page.locator(".ArrowE.arrowDown"); // @FindBy(css = ".ArrowE.arrowDown")
    this.arrowDownPremierPck = page.locator(".ArrowP.arrowDown"); // @FindBy(css = ".ArrowP.arrowDown")
    this.standardPackageDescriptionText = page.locator("xpath=//*[@id='homequote:radioInfo']/tbody/tr[1]/td[1]/div/div[4]/div/span"); // @FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[1]/td[1]/div/div[4]/div/span")
    this.enhancedPackageDescriptionText = page.locator("xpath=//*[@id='homequote:radioInfo']/tbody/tr[2]/td[1]/div/div[4]/div/span"); // @FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[2]/td[1]/div/div[4]/div/span")
    this.premierPackageDescriptionText = page.locator("xpath=//*[@id='homequote:radioInfo']/tbody/tr[3]/td[1]/div/div[4]/div/span"); // @FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[3]/td[1]/div/div[4]/div/span")
    this.standardPackagePremiumAmount = page.locator("xpath=//*[@id='homequote:radioInfo']/tbody/tr[1]/td[1]/div/div[2]"); // @FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[1]/td[1]/div/div[2]")
    this.enhancedPackagePremiumAmount = page.locator("xpath=//*[@id='homequote:radioInfo']/tbody/tr[2]/td[1]/div/div[2]"); // @FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[2]/td[1]/div/div[2]")
    this.premierPackagePremiumAmount = page.locator("xpath=//*[@id='homequote:radioInfo']/tbody/tr[3]/td[1]/div/div[2]"); // @FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[3]/td[1]/div/div[2]")
    this.standardPckTitle = page.locator("xpath=//*[@id='homequote:radioInfo']/tbody/tr[1]/td[1]/div/div[3]/div[2]/span"); // @FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[1]/td[1]/div/div[3]/div[2]/span")
    this.enhancedPckTitle = page.locator("xpath=//*[@id='homequote:radioInfo']/tbody/tr[2]/td[1]/div/div[3]/div[2]/span"); // @FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[2]/td[1]/div/div[3]/div[2]/span")
    this.premierPckTitle = page.locator("xpath=//*[@id='homequote:radioInfo']/tbody/tr[3]/td[1]/div/div[3]/div[2]/span"); // @FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[3]/td[1]/div/div[3]/div[2]/span")
    this.updateQuoteBtn = page.locator("#HomeUpdateBtn"); // @FindBy(id = "HomeUpdateBtn")
    this.yourInfoNavBarText = page.locator("xpath=//*[@id='homequote:progress:0:coverages']/span[2]"); // @FindBy(xpath = "//*[@id='homequote:progress:0:coverages']/span[2]")
    this.propertyNavBarText = page.locator("xpath=//*[@id='homequote:progress:1:coverages']/span[2]"); // @FindBy(xpath = "//*[@id='homequote:progress:1:coverages']/span[2]")
    this.coverageNavBarText = page.locator("xpath=//*[@id='homequote:progress:2:coverages']/span[2]"); // @FindBy(xpath = "//*[@id='homequote:progress:2:coverages']/span[2]")
    this.quoteNavBarText = page.locator("xpath=//*[@id='homequote:progress:3:coverages']/span[2]"); // @FindBy(xpath = "//*[@id='homequote:progress:3:coverages']/span[2]")
    this.blueNavBar = page.locator("#pbMenuPlaceHolder"); // @FindBy(id = "pbMenuPlaceHolder")
    this.headerLogo = page.locator("#HeaderLogo"); // @FindBy(id = "HeaderLogo")
    this.reviewAndChooseSubHeaderText = page.locator("xpath=//*[@id='ComparePaymentOptions']/div[1]/p[1]"); // @FindBy(xpath = "//*[@id='ComparePaymentOptions']/div[1]/p[1]")
    this.footerDisclaimerStaticText = page.locator("xpath=//*[@id='BoxArea']/div[@class='quote_disclaimer3']"); // @FindBy(xpath = "//*[@id='BoxArea']/div[@class='quote_disclaimer3']")
    this.briefSummaryStaticText = page.locator("xpath=//*[@id='homequote:disclaimer_2']/p/i"); // @FindBy(xpath = "//*[@id='homequote:disclaimer_2']/p/i")
    this.digiCertImageLogo = page.locator("xpath=//*[@id='VeriSign']/img"); // @FindBy(xpath = "//*[@id='VeriSign']/img")
  }
}
