// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.home.pages.PropertyPage. */
export class PropertyPage extends CoreBasePage {
  public readonly homeTypeOfRoof: Locator;
  public readonly numberOfAdultsInHousehold: Locator;
  public readonly propertyLossesInTheLastFiveYearsDropDown: Locator;
  public readonly homeExteriorWallType: Locator;
  public readonly phoneNumber: Locator;
  public readonly whenYourHomeWasOriginallyBuilt: Locator;
  public readonly squareFootage: Locator;
  public readonly numberOfSeparateLivingUnitsDropDown: Locator;
  public readonly stuccoOnFrameElement: Locator;
  public readonly brickVeneerElement: Locator;
  public readonly woodSidingElement: Locator;
  public readonly cementFiberSidingElement: Locator;
  public readonly nextButtonWall: Locator;
  public readonly vinylSidingElement: Locator;
  public readonly stoneVeneerElement: Locator;
  public readonly clapboardWoodElement: Locator;
  public readonly stuccoOnMasonryElement: Locator;
  public readonly aluminiumSidingElement: Locator;
  public readonly solidBrickElement: Locator;
  public readonly woodShakesElement: Locator;
  public readonly cementShinglesElement: Locator;
  public readonly steelSidingElement: Locator;
  public readonly solidStoneElement: Locator;
  public readonly solidWoodElement: Locator;
  public readonly logVeneerSidingElement: Locator;
  public readonly clapboardRedwoodElement: Locator;
  public readonly adobeElement: Locator;
  public readonly dwellingStyleDropDown: Locator;
  public readonly propNoOfFullBathsDropDown: Locator;
  public readonly propNoOfHalfBathsDropDown: Locator;
  public readonly asphaltShingle: Locator;
  public readonly fiberglassDimensionalAsphalt: Locator;
  public readonly spanishTileClay: Locator;
  public readonly concreteCementFiberTile: Locator;
  public readonly steelTileOrShingle: Locator;
  public readonly rockTarGravel: Locator;
  public readonly woodShingleShake: Locator;
  public readonly sheetMetalPanel: Locator;
  public readonly singlePlyMembraneSystems: Locator;
  public readonly aluminum: Locator;
  public readonly rolledAsphaltFlat: Locator;
  public readonly syntheticShingleOrTile: Locator;
  public readonly slate: Locator;
  public readonly copper: Locator;
  public readonly howOldIsYourRoofDropDown: Locator;
  public readonly typeOfGarageDropDown: Locator;
  public readonly haveAnyDecksYesRadioButton: Locator;
  public readonly haveAnyDecksNoRadioButton: Locator;
  public readonly havePoolYesRadioButton: Locator;
  public readonly havePoolNoRadioButton: Locator;
  public readonly haveBasementYesRadioButton: Locator;
  public readonly haveBasementNoRadioButton: Locator;
  public readonly hasPlumbingSystemYesRadioButton: Locator;
  public readonly hasPlumbingSystemNoRadioButton: Locator;
  public readonly typeOfHeatingDropDown: Locator;
  public readonly emailAddressTextBox: Locator;
  public readonly agreeAndContinueButton: Locator;
  public readonly nextButtonRoof: Locator;
  public readonly lastPropertyClaim: Locator;
  public readonly numberOfStoriesDropDown: Locator;
  public readonly stormShuttersYesRadioButton: Locator;
  public readonly stormShuttersNoRadioButton: Locator;
  public readonly retrieveHavePoolErrorMessage: Locator;
  public readonly retrieveSystemReplacedLastTwentyYearsErrorMessage: Locator;
  public readonly toolTip: Locator;
  public readonly propertyLossesKnockOutMessage: Locator;
  public readonly toolTips: Locator;
  public readonly toolTipsText: Locator;
  public readonly retrieveHaveBasementErrorMsg: Locator;
  public readonly typeOfRoofTitles: Locator;
  public readonly wallTypeTitles: Locator;
  public readonly yourInfoTabButton: Locator;
  public readonly estReconstCostMsg: Locator;
  public readonly footerStaticText: Locator;
  public readonly saveAndFinishLaterBtn: Locator;
  public readonly visitFcomBtn: Locator;
  public readonly quoteHasBeenSavedOKButton: Locator;
  public readonly weApologizeForInconvenienceText: Locator;
  public readonly arrowNextBtn: Locator;
  public readonly yourQuoteReqSpecAttentTitle: Locator;
  public readonly haveConnectedYesRadioButton: Locator;
  public readonly haveConnectedNoRadioButton: Locator;
  public readonly propLossesLbl: Locator;
  public readonly propDwellingtypeLbl: Locator;
  public readonly propYearBuiltLbl: Locator;
  public readonly propSqrFootageLbl: Locator;
  public readonly exteriorWallTypeLbl: Locator;
  public readonly propGarageTypeLbl: Locator;
  public readonly priHeatingSysLbl: Locator;
  public readonly propNoOfFullBathsLbl: Locator;
  public readonly propNoOfHalfBathsLbl: Locator;
  public readonly propRoofTypeLbl: Locator;
  public readonly propAgeOfRoofLbl: Locator;
  public readonly propertyDeckQuestionSection: Locator;
  public readonly propDeckLbl: Locator;
  public readonly propPoolLbl: Locator;
  public readonly propBasementLbl: Locator;
  public readonly entirehomePlumbLbl: Locator;
  public readonly phoneLbl: Locator;
  public readonly emailLbl: Locator;
  public readonly lastProplossLbl: Locator;
  public readonly vivintSmartHomeLbl: Locator;
  public readonly stormShuttersLbl: Locator;
  public readonly agentNameLbl: Locator;
  public readonly agentAddressLbl: Locator;
  public readonly lastpropLossError: Locator;
  public readonly propLossesError: Locator;
  public readonly propDwellingtypeError: Locator;
  public readonly propYearBuiltError: Locator;
  public readonly propSqrFootageError: Locator;
  public readonly exteriorWallTypeError: Locator;
  public readonly propGarageTypeError: Locator;
  public readonly priHeatingSysError: Locator;
  public readonly propNoOfFullBathsError: Locator;
  public readonly propNoOfHalfBathsError: Locator;
  public readonly propRoofTypeError: Locator;
  public readonly propAgeOfRoofError: Locator;
  public readonly propBasementError: Locator;
  public readonly phoneError: Locator;
  public readonly emailError: Locator;
  public readonly entirehomePlumbError: Locator;
  public readonly propBasementContainer: Locator;
  public readonly sqrFootageTT: Locator;
  public readonly sqrFootageTTText: Locator;
  public readonly sqrFootageTTClodeBtn: Locator;
  public readonly extWallTypeTT: Locator;
  public readonly extWallTypeTTText: Locator;
  public readonly extWallTypeTTCloseBtn: Locator;
  public readonly roofTypeTT: Locator;
  public readonly roofTypeTTText: Locator;
  public readonly roofTypeTTCloseBtnt: Locator;
  public readonly phoneTT: Locator;
  public readonly phoneTTText: Locator;
  public readonly phoneTTCloseBtn: Locator;
  public readonly emailTT: Locator;
  public readonly emailTTText: Locator;
  public readonly emailTTCloseBtn: Locator;
  public readonly yourInfoNavBarText: Locator;
  public readonly propertyNavBarText: Locator;
  public readonly coverageNavBarText: Locator;
  public readonly quoteNavBarText: Locator;
  public readonly blueNavBar: Locator;
  public readonly homeHeaderLogo: Locator;
  public readonly completeThisInformationSubHeaderText: Locator;
  public readonly quoteRequiresSpecialAttentionText: Locator;
  public readonly addEmailToRetrieveQuote: Locator;
  public readonly continueSavingQuote: Locator;

  public constructor(page: Page) {
    super(page);
    this.homeTypeOfRoof = page.locator("#AddHome:propRoofType"); // @FindBy(id = "AddHome:propRoofType")
    this.numberOfAdultsInHousehold = page.locator("#AddHome:noOfAdult"); // @FindBy(id = "AddHome:noOfAdult")
    this.propertyLossesInTheLastFiveYearsDropDown = page.locator("#AddHome:propLosses"); // @FindBy(id = "AddHome:propLosses")
    this.homeExteriorWallType = page.locator("xpath=//*[@id='AddHome:exteriorWallType']"); // @FindBy(xpath = "//*[@id='AddHome:exteriorWallType']")
    this.phoneNumber = page.locator("xpath=//*[@id='AddHome:phone']"); // @FindBy(xpath = "//*[@id='AddHome:phone']")
    this.whenYourHomeWasOriginallyBuilt = page.locator("#AddHome:propYearBuilt"); // @FindBy(id = "AddHome:propYearBuilt")
    this.squareFootage = page.locator("#AddHome:propSqrFootage"); // @FindBy(id = "AddHome:propSqrFootage")
    this.numberOfSeparateLivingUnitsDropDown = page.locator("#AddHome:propUnits"); // @FindBy(id = "AddHome:propUnits")
    this.stuccoOnFrameElement = page.locator("#SCF"); // @FindBy(id = "SCF")
    this.brickVeneerElement = page.locator("#BKV"); // @FindBy(id = "BKV")
    this.woodSidingElement = page.locator("#WSD"); // @FindBy(id = "WSD")
    this.cementFiberSidingElement = page.locator("#CFS"); // @FindBy(id = "CFS")
    this.nextButtonWall = page.locator("xpath=//*[@id='imagesContent']/button[2]"); // @FindBy(xpath = "//*[@id='imagesContent']/button[2]")
    this.vinylSidingElement = page.locator("#VNL"); // @FindBy(id = "VNL")
    this.stoneVeneerElement = page.locator("#STV"); // @FindBy(id = "STV")
    this.clapboardWoodElement = page.locator("#CLW"); // @FindBy(id = "CLW")
    this.stuccoOnMasonryElement = page.locator("#SCM"); // @FindBy(id = "SCM")
    this.aluminiumSidingElement = page.locator("#ALS"); // @FindBy(id = "ALS")
    this.solidBrickElement = page.locator("#SDB"); // @FindBy(id = "SDB")
    this.woodShakesElement = page.locator("#WSH"); // @FindBy(id = "WSH")
    this.cementShinglesElement = page.locator("#CMT"); // @FindBy(id = "CMT")
    this.steelSidingElement = page.locator("#STS"); // @FindBy(id = "STS")
    this.solidStoneElement = page.locator("#SDS"); // @FindBy(id = "SDS")
    this.solidWoodElement = page.locator("#SDL"); // @FindBy(id = "SDL")
    this.logVeneerSidingElement = page.locator("#LVS"); // @FindBy(id = "LVS")
    this.clapboardRedwoodElement = page.locator("#CLR"); // @FindBy(id = "CLR")
    this.adobeElement = page.locator("#ADB"); // @FindBy(id = "ADB")
    this.dwellingStyleDropDown = page.locator("#AddHome:propDwellingtype"); // @FindBy(id = "AddHome:propDwellingtype")
    this.propNoOfFullBathsDropDown = page.locator("#AddHome:propNoOfFullBaths"); // @FindBy(id = "AddHome:propNoOfFullBaths")
    this.propNoOfHalfBathsDropDown = page.locator("#AddHome:propNoOfHalfBaths"); // @FindBy(id = "AddHome:propNoOfHalfBaths")
    this.asphaltShingle = page.locator("#1"); // @FindBy(id = "1")
    this.fiberglassDimensionalAsphalt = page.locator("#C"); // @FindBy(id = "C")
    this.spanishTileClay = page.locator("#5"); // @FindBy(id = "5")
    this.concreteCementFiberTile = page.locator("#6"); // @FindBy(id = "6")
    this.steelTileOrShingle = page.locator("#3"); // @FindBy(id = "3")
    this.rockTarGravel = page.locator("#8"); // @FindBy(id = "8")
    this.woodShingleShake = page.locator("#2"); // @FindBy(id = "2")
    this.sheetMetalPanel = page.locator("#B"); // @FindBy(id = "B")
    this.singlePlyMembraneSystems = page.locator("#M"); // @FindBy(id = "M")
    this.aluminum = page.locator("#O"); // @FindBy(id = "O")
    this.rolledAsphaltFlat = page.locator("#A"); // @FindBy(id = "A")
    this.syntheticShingleOrTile = page.locator("#4"); // @FindBy(id = "4")
    this.slate = page.locator("#7"); // @FindBy(id = "7")
    this.copper = page.locator("#9"); // @FindBy(id = "9")
    this.howOldIsYourRoofDropDown = page.locator("#AddHome:propAgeOfRoof"); // @FindBy(id = "AddHome:propAgeOfRoof")
    this.typeOfGarageDropDown = page.locator("#AddHome:propGarageType"); // @FindBy(id = "AddHome:propGarageType")
    this.haveAnyDecksYesRadioButton = page.locator("#AddHome:propDeck:0"); // @FindBy(id = "AddHome:propDeck:0")
    this.haveAnyDecksNoRadioButton = page.locator("#AddHome:propDeck:1"); // @FindBy(id = "AddHome:propDeck:1")
    this.havePoolYesRadioButton = page.locator("#AddHome:propPool:0"); // @FindBy(id = "AddHome:propPool:0")
    this.havePoolNoRadioButton = page.locator("#AddHome:propPool:1"); // @FindBy(id = "AddHome:propPool:1")
    this.haveBasementYesRadioButton = page.locator("#AddHome:propBasement:0"); // @FindBy(id = "AddHome:propBasement:0")
    this.haveBasementNoRadioButton = page.locator("#AddHome:propBasement:1"); // @FindBy(id = "AddHome:propBasement:1")
    this.hasPlumbingSystemYesRadioButton = page.locator("#AddHome:homePlumb:0"); // @FindBy(id = "AddHome:homePlumb:0")
    this.hasPlumbingSystemNoRadioButton = page.locator("#AddHome:homePlumb:1"); // @FindBy(id = "AddHome:homePlumb:1")
    this.typeOfHeatingDropDown = page.locator("#AddHome:priHeatingSys"); // @FindBy(id = "AddHome:priHeatingSys")
    this.emailAddressTextBox = page.locator("#AddHome:Email"); // @FindBy(id = "AddHome:Email")
    this.agreeAndContinueButton = page.locator("#AddHome:nextDiscount"); // @FindBy(id = "AddHome:nextDiscount")
    this.nextButtonRoof = page.locator("xpath=//*[@id='roofsImagesContent']/button[2]"); // @FindBy(xpath = "//*[@id='roofsImagesContent']/button[2]")
    this.lastPropertyClaim = page.locator("#AddHome:lastpropLoss"); // @FindBy(id = "AddHome:lastpropLoss")
    this.numberOfStoriesDropDown = page.locator("#AddHome:propNoOfStories"); // @FindBy(id = "AddHome:propNoOfStories")
    this.stormShuttersYesRadioButton = page.locator("xpath=//label[@for='AddHome:stormShutters:0']"); // @FindBy(xpath = "//label[@for='AddHome:stormShutters:0']")
    this.stormShuttersNoRadioButton = page.locator("xpath=//label[@for='AddHome:stormShutters:1']"); // @FindBy(xpath = "//label[@for='AddHome:stormShutters:1']")
    this.retrieveHavePoolErrorMessage = page.locator("xpath=//*[@id='AddHome:propPoolPnl']/div"); // @FindBy(xpath = "//*[@id='AddHome:propPoolPnl']/div")
    this.retrieveSystemReplacedLastTwentyYearsErrorMessage = page.locator("xpath=//*[@id='AddHome:entirehomePlumb']/div"); // @FindBy(xpath = "//*[@id='AddHome:entirehomePlumb']/div")
    this.toolTip = page.locator(".TT"); // @FindBy(className = "TT")
    this.propertyLossesKnockOutMessage = page.locator("xpath=//*[@id='propLossesError']"); // @FindBy(xpath = "//*[@id='propLossesError']")
    this.toolTips = page.locator(".TT"); // @FindBy(className = "TT")
    this.toolTipsText = page.locator(".middle"); // @FindBy(className = "middle")
    this.retrieveHaveBasementErrorMsg = page.locator("xpath=//*[@id='additionalInfomation']/div[13]"); // @FindBy(xpath = "//*[@id='additionalInfomation']/div[13]")
    this.typeOfRoofTitles = page.locator(".wallImages>label"); // @FindBy(css = ".wallImages>label")
    this.wallTypeTitles = page.locator(".wallImages>label"); // @FindBy(css = ".wallImages>label")
    this.yourInfoTabButton = page.locator("xpath=//*[@id='AddHome:progress:0:addhome']/span[contains(text(), 'Your Info')]"); // @FindBy(xpath = "//*[@id='AddHome:progress:0:addhome']/span[contains(text(), 'Your Info')]")
    this.estReconstCostMsg = page.locator("#PVError"); // @FindBy(id = "PVError")
    this.footerStaticText = page.locator("#AddHome:tcpaTxtDisLbl"); // @FindBy(id = "AddHome:tcpaTxtDisLbl")
    this.saveAndFinishLaterBtn = page.locator("#renterSave"); // @FindBy(id = "renterSave")
    this.visitFcomBtn = page.locator("#saveRetrieveLaterForm:farmersRedirectLink"); // @FindBy(id = "saveRetrieveLaterForm:farmersRedirectLink")
    this.quoteHasBeenSavedOKButton = page.locator("#saveRetrieveLaterForm:savetbuttonid"); // @FindBy(id = "saveRetrieveLaterForm:savetbuttonid")
    this.weApologizeForInconvenienceText = page.locator("xpath=//div[@class='AgentLanding']"); // @FindBy(xpath = "//div[@class='AgentLanding']")
    this.arrowNextBtn = page.locator(".slick-next.slick-arrow"); // @FindBy(css = ".slick-next.slick-arrow")
    this.yourQuoteReqSpecAttentTitle = page.locator("xpath=//*[@id='AgentIntro']/h1"); // @FindBy(xpath = "//*[@id='AgentIntro']/h1")
    this.haveConnectedYesRadioButton = page.locator("xpath=//*[@id='AddHome:vivintSmartHome']/tbody/tr/td[1]/label"); // @FindBy(xpath = "//*[@id='AddHome:vivintSmartHome']/tbody/tr/td[1]/label")
    this.haveConnectedNoRadioButton = page.locator("xpath=//*[@id='AddHome:vivintSmartHome']/tbody/tr/td[2]/label"); // @FindBy(xpath = "//*[@id='AddHome:vivintSmartHome']/tbody/tr/td[2]/label")
    this.propLossesLbl = page.locator("#AddHome:propLossesLbl"); // @FindBy(id = "AddHome:propLossesLbl")
    this.propDwellingtypeLbl = page.locator("#AddHome:propDwellingtypeLbl"); // @FindBy(id = "AddHome:propDwellingtypeLbl")
    this.propYearBuiltLbl = page.locator("#AddHome:propYearBuiltLbl"); // @FindBy(id = "AddHome:propYearBuiltLbl")
    this.propSqrFootageLbl = page.locator("#AddHome:propSqrFootageLbl"); // @FindBy(id = "AddHome:propSqrFootageLbl")
    this.exteriorWallTypeLbl = page.locator("#AddHome:exteriorWallTypeLbl"); // @FindBy(id = "AddHome:exteriorWallTypeLbl")
    this.propGarageTypeLbl = page.locator("#AddHome:propGarageTypeLbl"); // @FindBy(id = "AddHome:propGarageTypeLbl")
    this.priHeatingSysLbl = page.locator("#AddHome:priHeatingSysLbl"); // @FindBy(id = "AddHome:priHeatingSysLbl")
    this.propNoOfFullBathsLbl = page.locator("#AddHome:propNoOfFullBathsLbl"); // @FindBy(id = "AddHome:propNoOfFullBathsLbl")
    this.propNoOfHalfBathsLbl = page.locator("#AddHome:propNoOfHalfBathsLbl"); // @FindBy(id = "AddHome:propNoOfHalfBathsLbl")
    this.propRoofTypeLbl = page.locator("#AddHome:propRoofTypeLbl"); // @FindBy(id = "AddHome:propRoofTypeLbl")
    this.propAgeOfRoofLbl = page.locator("#AddHome:propAgeOfRoofLbl"); // @FindBy(id = "AddHome:propAgeOfRoofLbl")
    this.propertyDeckQuestionSection = page.locator("#AddHome:propDeckPnl"); // @FindBy(id = "AddHome:propDeckPnl")
    this.propDeckLbl = page.locator("#AddHome:propDeckLbl"); // @FindBy(id = "AddHome:propDeckLbl")
    this.propPoolLbl = page.locator("#AddHome:propPoolLbl"); // @FindBy(id = "AddHome:propPoolLbl")
    this.propBasementLbl = page.locator("#AddHome:propBasementLbl"); // @FindBy(id = "AddHome:propBasementLbl")
    this.entirehomePlumbLbl = page.locator("#AddHome:entirehomePlumbLbl"); // @FindBy(id = "AddHome:entirehomePlumbLbl")
    this.phoneLbl = page.locator("#AddHome:phoneLbl"); // @FindBy(id = "AddHome:phoneLbl")
    this.emailLbl = page.locator("#AddHome:emailLbl"); // @FindBy(id = "AddHome:emailLbl")
    this.lastProplossLbl = page.locator("#AddHome:lastProplossLbl"); // @FindBy(id = "AddHome:lastProplossLbl")
    this.vivintSmartHomeLbl = page.locator("#AddHome:vivintSmartHomeLbl"); // @FindBy(id = "AddHome:vivintSmartHomeLbl")
    this.stormShuttersLbl = page.locator("#AddHome:stormShuttersLbl"); // @FindBy(id = "AddHome:stormShuttersLbl")
    this.agentNameLbl = page.locator("#agentName"); // @FindBy(id = "agentName")
    this.agentAddressLbl = page.locator("#agentAddress"); // @FindBy(id = "agentAddress")
    this.lastpropLossError = page.locator("#lastpropLossError"); // @FindBy(id = "lastpropLossError")
    this.propLossesError = page.locator("#propLossesError"); // @FindBy(id = "propLossesError")
    this.propDwellingtypeError = page.locator("#propDwellingtypeError"); // @FindBy(id = "propDwellingtypeError")
    this.propYearBuiltError = page.locator("#propYearBuiltError"); // @FindBy(id = "propYearBuiltError")
    this.propSqrFootageError = page.locator("#propSqrFootageError"); // @FindBy(id = "propSqrFootageError")
    this.exteriorWallTypeError = page.locator("#exteriorWallTypeError"); // @FindBy(id = "exteriorWallTypeError")
    this.propGarageTypeError = page.locator("#propGarageTypeError"); // @FindBy(id = "propGarageTypeError")
    this.priHeatingSysError = page.locator("#priHeatingSysError"); // @FindBy(id = "priHeatingSysError")
    this.propNoOfFullBathsError = page.locator("#propNoOfFullBathsError"); // @FindBy(id = "propNoOfFullBathsError")
    this.propNoOfHalfBathsError = page.locator("#propNoOfHalfBathsError"); // @FindBy(id = "propNoOfHalfBathsError")
    this.propRoofTypeError = page.locator("#propRoofTypeError"); // @FindBy(id = "propRoofTypeError")
    this.propAgeOfRoofError = page.locator("#propAgeOfRoofError"); // @FindBy(id = "propAgeOfRoofError")
    this.propBasementError = page.locator("#propBasementError"); // @FindBy(id = "propBasementError")
    this.phoneError = page.locator("#phoneError"); // @FindBy(id = "phoneError")
    this.emailError = page.locator("#emailError"); // @FindBy(id = "emailError")
    this.entirehomePlumbError = page.locator("#entirehomePlumbError"); // @FindBy(id = "entirehomePlumbError")
    this.propBasementContainer = page.locator("#AddHome:propBasement"); // @FindBy(id = "AddHome:propBasement")
    this.sqrFootageTT = page.locator("#SqrFootageTT"); // @FindBy(id = "SqrFootageTT")
    this.sqrFootageTTText = page.locator("xpath=//*[@id='SqrFootagePopup']/p"); // @FindBy(xpath = "//*[@id='SqrFootagePopup']/p")
    this.sqrFootageTTClodeBtn = page.locator("xpath=//*[@id='SqrFootagePopup']/input"); // @FindBy(xpath = "//*[@id='SqrFootagePopup']/input")
    this.extWallTypeTT = page.locator("#extWallTypeTT"); // @FindBy(id = "extWallTypeTT")
    this.extWallTypeTTText = page.locator("#extWallTypePopup>p"); // @FindBy(css = "#extWallTypePopup>p")
    this.extWallTypeTTCloseBtn = page.locator("xpath=//*[@id='extWallTypePopup']/input"); // @FindBy(xpath = "//*[@id='extWallTypePopup']/input")
    this.roofTypeTT = page.locator("#roofTypeTT"); // @FindBy(id = "roofTypeTT")
    this.roofTypeTTText = page.locator("xpath=//*[@id='roofTypePopup']/p"); // @FindBy(xpath = "//*[@id='roofTypePopup']/p")
    this.roofTypeTTCloseBtnt = page.locator("xpath=//*[@id='roofTypePopup']/input"); // @FindBy(xpath = "//*[@id='roofTypePopup']/input")
    this.phoneTT = page.locator("#phoneTT"); // @FindBy(id = "phoneTT")
    this.phoneTTText = page.locator("xpath=//*[@id='phonePopup']/p"); // @FindBy(xpath = "//*[@id='phonePopup']/p")
    this.phoneTTCloseBtn = page.locator("xpath=//*[@id='phonePopup']/input"); // @FindBy(xpath = "//*[@id='phonePopup']/input")
    this.emailTT = page.locator("#emailTT"); // @FindBy(id = "emailTT")
    this.emailTTText = page.locator("xpath=//*[@id='emailPopup']/p"); // @FindBy(xpath = "//*[@id='emailPopup']/p")
    this.emailTTCloseBtn = page.locator("xpath=//*[@id='emailPopup']/input"); // @FindBy(xpath = "//*[@id='emailPopup']/input")
    this.yourInfoNavBarText = page.locator("xpath=//*[@id='AddHome:progress:0:addhome']/span[2]"); // @FindBy(xpath = "//*[@id='AddHome:progress:0:addhome']/span[2]")
    this.propertyNavBarText = page.locator("xpath=//*[@id='AddHome:progress:1:addhome']/span[2]"); // @FindBy(xpath = "//*[@id='AddHome:progress:1:addhome']/span[2]")
    this.coverageNavBarText = page.locator("xpath=//*[@id='AddHome:progress:2:addhome']/span[2]"); // @FindBy(xpath = "//*[@id='AddHome:progress:2:addhome']/span[2]")
    this.quoteNavBarText = page.locator("xpath=//*[@id='AddHome:progress:3:addhome']/span[2]"); // @FindBy(xpath = "//*[@id='AddHome:progress:3:addhome']/span[2]")
    this.blueNavBar = page.locator("#pbMenuPlaceHolder"); // @FindBy(id = "pbMenuPlaceHolder")
    this.homeHeaderLogo = page.locator("#HeaderLogo"); // @FindBy(id = "HeaderLogo")
    this.completeThisInformationSubHeaderText = page.locator("xpath=//*[@id='HomeIntro']/p"); // @FindBy(xpath = "//*[@id='HomeIntro']/p")
    this.quoteRequiresSpecialAttentionText = page.locator("#AgentIntro"); // @FindBy(id = "AgentIntro")
    this.addEmailToRetrieveQuote = page.locator("#saveRetrieveLaterForm:Email"); // @FindBy(id = "saveRetrieveLaterForm:Email")
    this.continueSavingQuote = page.locator("#saveRetrieveLaterForm:savetbuttonid"); // @FindBy(id = "saveRetrieveLaterForm:savetbuttonid")
  }
}
