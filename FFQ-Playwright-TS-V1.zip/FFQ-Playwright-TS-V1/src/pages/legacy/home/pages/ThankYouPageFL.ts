// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.home.pages.ThankYouPageFL. */
export class ThankYouPageFL extends CoreBasePage {
  public readonly thankYouHeadingTitleText: Locator;
  public readonly quoteNumberText: Locator;

  public constructor(page: Page) {
    super(page);
    this.thankYouHeadingTitleText = page.locator("#FFQHome_ThankYou_heading"); // @FindBy(id = "FFQHome_ThankYou_heading")
    this.quoteNumberText = page.locator("#FFQHome_ThankYou_quoteNumberWrap"); // @FindBy(id = "FFQHome_ThankYou_quoteNumberWrap")
  }
}
