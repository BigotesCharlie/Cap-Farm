// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.home.pages.PrintQuotePageHome. */
export class PrintQuotePageHome extends CoreBasePage {
  public readonly printQuotePageHeaderText: Locator;
  public readonly subHeaderContent: Locator;
  public readonly premiumAmountPayInFull: Locator;
  public readonly premiumAmountPayMonthly: Locator;
  public readonly discountList: Locator;
  public readonly propertyCoveragesList: Locator;
  public readonly propertyCoveragesLimitsList: Locator;
  public readonly liabilityCoveragesList: Locator;
  public readonly liabilityCoveragesLimitsList: Locator;
  public readonly policyFeaturesAndBenefitsList: Locator;
  public readonly disclamerText: Locator;

  public constructor(page: Page) {
    super(page);
    this.printQuotePageHeaderText = page.locator("xpath=//*[@id='Header']/h1"); // @FindBy(xpath = "//*[@id='Header']/h1")
    this.subHeaderContent = page.locator("xpath=//*[@id='Header']/p[string-length(@class)=0]"); // @FindBy(xpath = "//*[@id='Header']/p[string-length(@class)=0]")
    this.premiumAmountPayInFull = page.locator("xpath=//*[@id='Premium']/tr[2]/td"); // @FindBy(xpath = "//*[@id='Premium']/tr[2]/td")
    this.premiumAmountPayMonthly = page.locator("xpath=//*[@id='Premium']/tr[1]/td"); // @FindBy(xpath = "//*[@id='Premium']/tr[1]/td")
    this.discountList = page.locator("xpath=//th[@class='cover' and text()='Type']/../../../tbody/tr/td"); // @FindBy(xpath = "//th[@class='cover' and text()='Type']/../../../tbody/tr/td")
    this.propertyCoveragesList = page.locator("xpath=//table[@id='SummarySplit']/tbody[1]/tr/td/table/tbody/tr[not(contains(@style,'display:none'))]/td[1]"); // @FindBy(xpath = "//table[@id='SummarySplit']/tbody[1]/tr/td/table/tbody/tr[not(contains(@style,'display:none'))]/td[1]")
    this.propertyCoveragesLimitsList = page.locator("xpath=//table[@id='SummarySplit']/tbody[1]/tr/td/table/tbody/tr[not(contains(@style,'display:none'))]/td[2]"); // @FindBy(xpath = "//table[@id='SummarySplit']/tbody[1]/tr/td/table/tbody/tr[not(contains(@style,'display:none'))]/td[2]")
    this.liabilityCoveragesList = page.locator("xpath=//*[@id='homeAlingn']/span/span"); // @FindBy(xpath = "//*[@id='homeAlingn']/span/span")
    this.liabilityCoveragesLimitsList = page.locator("xpath=//*[@id='homesAlingn']/span"); // @FindBy(xpath = "//*[@id='homesAlingn']/span")
    this.policyFeaturesAndBenefitsList = page.locator("xpath=//td[@id='homeAlingn' and @class='Coverage' and not(descendant::span)]"); // @FindBy(xpath = "//td[@id='homeAlingn' and @class='Coverage' and not(descendant::span)]")
    this.disclamerText = page.locator("xpath=//div[@class='Disclaimer']"); // @FindBy(xpath = "//div[@class='Disclaimer']")
  }
}
