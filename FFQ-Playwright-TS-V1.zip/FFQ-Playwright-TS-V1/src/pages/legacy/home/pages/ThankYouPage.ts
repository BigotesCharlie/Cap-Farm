// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.home.pages.ThankYouPage. */
export class ThankYouPage extends CoreBasePage {
  public readonly headerText: Locator;
  public readonly nextStepsStaticText: Locator;
  public readonly premiumAmountCongratText: Locator;
  public readonly quoteNumber: Locator;
  public readonly printQuoteButton: Locator;
  public readonly emailQuoteButton: Locator;
  public readonly coverageAmount: Locator;
  public readonly startQuoteButton: Locator;
  public readonly footerDisclaimerStaticText: Locator;
  public readonly qualifyMultiPolicyStaticText: Locator;
  public readonly willHelpYouSaveStaticText: Locator;
  public readonly crossSellDropDown: Locator;
  public readonly startCrossSellQuoteButton: Locator;
  public readonly lobText: Locator;
  public readonly yourFarmersAgentStaticText: Locator;
  public readonly futurePaymentsStaticText: Locator;
  public readonly monthlyPaymentsStaticText: Locator;

  public constructor(page: Page) {
    super(page);
    this.headerText = page.locator("#PolicyIntro"); // @FindBy(id = "PolicyIntro")
    this.nextStepsStaticText = page.locator("xpath=//span[contains(@id,'nextStep')]"); // @FindBy(xpath = "//span[contains(@id,'nextStep')]")
    this.premiumAmountCongratText = page.locator("xpath=//div[@class='homeprmHeading']/span[contains(@id, 'buypolicyHome')]/b"); // @FindBy(xpath = "//div[@class='homeprmHeading']/span[contains(@id, 'buypolicyHome')]/b")
    this.quoteNumber = page.locator("xpath=//*[@id='Content']/div[3]/div[1]/p"); // @FindBy(xpath = "//*[@id='Content']/div[3]/div[1]/p")
    this.printQuoteButton = page.locator("xpath=//input[contains(@value,'PRINT')]"); // @FindBy(xpath = "//input[contains(@value,'PRINT')]")
    this.emailQuoteButton = page.locator("xpath=//input[contains(@value,'EMAIL')]"); // @FindBy(xpath = "//input[contains(@value,'EMAIL')]")
    this.coverageAmount = page.locator("xpath=//*[@id='congratzHomeThankyou']/table[3]/tbody/tr[1]/td[2]"); // @FindBy(xpath = "//*[@id='congratzHomeThankyou']/table[3]/tbody/tr[1]/td[2]")
    this.startQuoteButton = page.locator("#buypolicyHome:startQuoteDesktop"); // @FindBy(id = "buypolicyHome:startQuoteDesktop")
    this.footerDisclaimerStaticText = page.locator("#homeAgentDisclaimer"); // @FindBy(id = "homeAgentDisclaimer")
    this.qualifyMultiPolicyStaticText = page.locator("xpath=//*[@id='buypolicyHome:HomePolicyWay']/tbody/tr[1]/td/span"); // @FindBy(xpath = "//*[@id='buypolicyHome:HomePolicyWay']/tbody/tr[1]/td/span")
    this.willHelpYouSaveStaticText = page.locator("xpath=//*[@id='buypolicyHome:HomePolicyWay']/tbody/tr[1]/td/div[1]"); // @FindBy(xpath = "//*[@id='buypolicyHome:HomePolicyWay']/tbody/tr[1]/td/div[1]")
    this.crossSellDropDown = page.locator("#buypolicyHome:quoteType"); // @FindBy(id = "buypolicyHome:quoteType")
    this.startCrossSellQuoteButton = page.locator("#buypolicyHome:startQuoteDesktop"); // @FindBy(id = "buypolicyHome:startQuoteDesktop")
    this.lobText = page.locator("xpath=//*[@id='congratzHomeThankyou']/div[1]/table/tbody/tr/td/p"); // @FindBy(xpath = "//*[@id='congratzHomeThankyou']/div[1]/table/tbody/tr/td/p")
    this.yourFarmersAgentStaticText = page.locator("#homeAgentList"); // @FindBy(css = "#homeAgentList") // .homeAgentListInfo 	private WebElement agentInfo;  	@FindBy(css = "#PolicyIntro>p")
    this.futurePaymentsStaticText = page.locator(".homethankYouDisclaimer>small"); // @FindBy(css = ".homethankYouDisclaimer>small")
    this.monthlyPaymentsStaticText = page.locator("xpath=//*[@id='congratzHomeThankyou']/div[1]/table/tbody/tr/td/span"); // @FindBy(xpath = "//*[@id='congratzHomeThankyou']/div[1]/table/tbody/tr/td/span")
  }
}
