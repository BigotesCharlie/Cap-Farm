// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.home.pages.YourInfoPageFL. */
export class YourInfoPageFL extends CoreBasePage {
  public readonly firstNameTextBox: Locator;
  public readonly lastNameTextBox: Locator;
  public readonly dateOfBirthTextBox: Locator;
  public readonly maleRadioButton: Locator;
  public readonly femaleRadioButton: Locator;
  public readonly resedentialAddressTexBox: Locator;
  public readonly resedentialAppartmentTexBox: Locator;
  public readonly resedentialCityTexBox: Locator;
  public readonly zipCodeTexBox: Locator;
  public readonly phoneTextBox: Locator;
  public readonly emailTextBox: Locator;
  public readonly hasAutoInsuranceYesRadioBtn: Locator;
  public readonly hasAutoInsuranceNoRadioBtn: Locator;
  public readonly submitButton: Locator;
  public readonly consumeReportPopUpNoButton: Locator;
  public readonly consumeReportPopUpYesButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.firstNameTextBox = page.locator("#FFQHome_Yourinfo_firstName"); // @FindBy(id = "FFQHome_Yourinfo_firstName")
    this.lastNameTextBox = page.locator("#FFQHome_Yourinfo_lastName"); // @FindBy(id = "FFQHome_Yourinfo_lastName")
    this.dateOfBirthTextBox = page.locator("xpath=//input[contains(@id, 'FFQHome_Yourinfo_Dob') and contains(@class, 'ng-isolate-scope')]"); // @FindBy(xpath = "//input[contains(@id, 'FFQHome_Yourinfo_Dob') and contains(@class, 'ng-isolate-scope')]")
    this.maleRadioButton = page.locator("xpath=//*[@id='FFQHome_Yourinfo_genderWrap']/label"); // @FindBy(xpath = "//*[@id='FFQHome_Yourinfo_genderWrap']/label")
    this.femaleRadioButton = page.locator("xpath=//*[@id='FFQHome_Yourinfo_gender1Wrap']/label"); // @FindBy(xpath = "//*[@id='FFQHome_Yourinfo_gender1Wrap']/label")
    this.resedentialAddressTexBox = page.locator("#FFQHome_Yourinfo_ResedentialAddress"); // @FindBy(id = "FFQHome_Yourinfo_ResedentialAddress")
    this.resedentialAppartmentTexBox = page.locator("#FFQHome_Yourinfo_Apartment"); // @FindBy(id = "FFQHome_Yourinfo_Apartment")
    this.resedentialCityTexBox = page.locator("#FFQHome_Yourinfo_City"); // @FindBy(id = "FFQHome_Yourinfo_City")
    this.zipCodeTexBox = page.locator("#FFQHome_Yourinfo_Zipcode"); // @FindBy(id = "FFQHome_Yourinfo_Zipcode")
    this.phoneTextBox = page.locator("#FFQHome_Yourinfo_phoneNumber"); // @FindBy(id = "FFQHome_Yourinfo_phoneNumber")
    this.emailTextBox = page.locator("#FFQHome_Yourinfo_email"); // @FindBy(id = "FFQHome_Yourinfo_email")
    this.hasAutoInsuranceYesRadioBtn = page.locator("xpath=//*[@id='FFQHome_Yourinfo_questionWrap']/label"); // @FindBy(xpath = "//*[@id='FFQHome_Yourinfo_questionWrap']/label")
    this.hasAutoInsuranceNoRadioBtn = page.locator("xpath=//*[@id='FFQHome_Yourinfo_question1Wrap']/label"); // @FindBy(xpath = "//*[@id='FFQHome_Yourinfo_question1Wrap']/label")
    this.submitButton = page.locator("#FFQHome_Yourinfo_startQuoteBtn"); // @FindBy(id = "FFQHome_Yourinfo_startQuoteBtn")
    this.consumeReportPopUpNoButton = page.locator("#FFQHome_Review_ConsentNoBtn"); // @FindBy(id = "FFQHome_Review_ConsentNoBtn")
    this.consumeReportPopUpYesButton = page.locator("#FFQHome_Review_ConsentYesBtn"); // @FindBy(id = "FFQHome_Review_ConsentYesBtn")
  }
}
