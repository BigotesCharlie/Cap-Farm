// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.home.pages.YourInfoPageHome. */
export class YourInfoPageHome extends CoreBasePage {
  public readonly firstNameTextBox: Locator;
  public readonly firstNameTextBoxRedesigned: Locator;
  public readonly firstNameTextBoxErrorMsg: Locator;
  public readonly lastNameTextBox: Locator;
  public readonly lastNameTextBoxRedesigned: Locator;
  public readonly lastNameTextBoxErrorMsg: Locator;
  public readonly dateOfBirthTextBox: Locator;
  public readonly dateOfBirthTextBoxRedesigned: Locator;
  public readonly dateOfBirthTextBoxErrorMsg: Locator;
  public readonly maritalStatusDropDown: Locator;
  public readonly maritalStatusDropDownErrorMsg: Locator;
  public readonly addressTextBox: Locator;
  public readonly addressTextBoxRedesigned: Locator;
  public readonly addressTextBoxErrorMsg: Locator;
  public readonly apartmentTextBox: Locator;
  public readonly cityTextBox: Locator;
  public readonly cityTextBoxRedesigned: Locator;
  public readonly cityTextBoxErrorMsg: Locator;
  public readonly zipCodeTextBox: Locator;
  public readonly zipCodeTextBoxRedesigned: Locator;
  public readonly zipCodeErrorMsg: Locator;
  public readonly txtMailingZipErrorMsg: Locator;
  public readonly zipCodeTextBoxFLState: Locator;
  public readonly propertyTypeDropDown: Locator;
  public readonly startQuoteButton: Locator;
  public readonly mailingAddressDifferentCheckBox: Locator;
  public readonly mailingAddressTextBox: Locator;
  public readonly txtMailingStreetErrorMsg: Locator;
  public readonly mailingCityTextBox: Locator;
  public readonly txtMailCityErrorMsg: Locator;
  public readonly mailingStateDropDown: Locator;
  public readonly mailingZipCodeTextBox: Locator;
  public readonly spouseFirstNameTextBox: Locator;
  public readonly spouseFirstNameTextBoxErrorMsg: Locator;
  public readonly spouseLastNameTextBox: Locator;
  public readonly spouseLastNameTextBoxErrorMsg: Locator;
  public readonly spouseDateOfBirthTextBox: Locator;
  public readonly spouseDateOfBirthTextBoxErrorMsg: Locator;
  public readonly consumeReportPopUpYesButton: Locator;
  public readonly consumeReportPopUpNoButton: Locator;
  public readonly consumeReportPopUp: Locator;
  public readonly stateTextBox: Locator;
  public readonly stateTextBoxFLState: Locator;
  public readonly retrieveFirstNameMissingInputMessage: Locator;
  public readonly retrieveFirstNameInvalidInputMessage: Locator;
  public readonly toolTipElement: Locator;
  public readonly toolTipText: Locator;
  public readonly creditReportNotification: Locator;
  public readonly mailingAddressCheckBoxText: Locator;
  public readonly mailingAddressCheckBox: Locator;
  public readonly zipCodePopUpOKButton: Locator;
  public readonly zipCodePopUpCloseButton: Locator;
  public readonly attentionHomeOwnersPopUp: Locator;
  public readonly homeOwnContinueBtn: Locator;
  public readonly homeOwnCancelBtn: Locator;
  public readonly willLoveFarmersStaticText: Locator;
  public readonly personalServiceStaticText: Locator;
  public readonly helpPointStaticText: Locator;
  public readonly dozenDiscountsStaticText: Locator;
  public readonly yourFarmersAgentStaticText: Locator;
  public readonly exsistingCustomerTitleText: Locator;
  public readonly exsistingCustomerBodyText: Locator;
  public readonly exsistingCustomerBodyText2: Locator;
  public readonly exsistingCustomerFormDismissBtn: Locator;
  public readonly exsistingCustomerFormOKBtn: Locator;
  public readonly occupationDropDown: Locator;
  public readonly occupationDropDownErrorMsg: Locator;
  public readonly spouseOccupationDropDown: Locator;
  public readonly spouseOccupationDropDownErrorMsg: Locator;
  public readonly propertyTypeHouseRadioBtn: Locator;
  public readonly propertyTypeTownHouseRadioBtn: Locator;
  public readonly blankSpace: Locator;
  public readonly cityDropDown: Locator;
  public readonly firstNameLbl: Locator;
  public readonly lastNameLbl: Locator;
  public readonly dateOfBirthLbl: Locator;
  public readonly propOccupationLbl: Locator;
  public readonly maritalStatusLbl: Locator;
  public readonly addressLbl: Locator;
  public readonly apartmentLbl: Locator;
  public readonly cityLbl: Locator;
  public readonly stateLbl: Locator;
  public readonly zipCodeLbl: Locator;
  public readonly propTypeHouseLbl: Locator;
  public readonly propTypeTownHouseLbl: Locator;
  public readonly srtApartmentLbl: Locator;
  public readonly propertyNavBarText: Locator;
  public readonly coverageNavBarText: Locator;
  public readonly quoteNavBarText: Locator;
  public readonly yourInfoNavBarText: Locator;
  public readonly blueNavBar: Locator;
  public readonly headerLogo: Locator;
  public readonly tellAboutYourselfText: Locator;
  public readonly toProvideYouSubTitleText: Locator;
  public readonly txtMailingStreetError: Locator;
  public readonly txtMailCityError: Locator;
  public readonly txtMailStateError: Locator;
  public readonly txtMailingZipError: Locator;
  public readonly occupationToolTip: Locator;
  public readonly occupationToolTipCloseBtn: Locator;
  public readonly occupationToolTipText: Locator;
  public readonly addressToolTip: Locator;
  public readonly addressToolTipCloseBtn: Locator;
  public readonly addressToolTipText: Locator;
  public readonly summaryBtn: Locator;
  public readonly cartBtn: Locator;
  public readonly blueNavBarStep1of4Text: Locator;
  public readonly blueNavBarSmall: Locator;
  public readonly summaryquoteSmall: Locator;
  public readonly summaryYourFarmersAgentStaticText: Locator;
  public readonly summaryAgentNearYouStaticText: Locator;
  public readonly summaryTitleStaticText: Locator;
  public readonly summaryCloseBtn: Locator;
  public readonly step1Text: Locator;
  public readonly step2Text: Locator;
  public readonly step3Text: Locator;
  public readonly step4Text: Locator;
  public readonly firstNameError: Locator;
  public readonly lastNameError: Locator;
  public readonly hqmElement: Locator;

  public constructor(page: Page) {
    super(page);
    this.firstNameTextBox = page.locator("#preapp:FirstName"); // @FindBy(id = "preapp:FirstName")
    this.firstNameTextBoxRedesigned = page.locator("#FFQHome_Yourinfo_firstName"); // @FindBy(id = "FFQHome_Yourinfo_firstName")
    this.firstNameTextBoxErrorMsg = page.locator("#FirstNameError"); // @FindBy(id = "FirstNameError")
    this.lastNameTextBox = page.locator("#preapp:LastName"); // @FindBy(id = "preapp:LastName")
    this.lastNameTextBoxRedesigned = page.locator("#FFQHome_Yourinfo_lastName"); // @FindBy(id = "FFQHome_Yourinfo_lastName")
    this.lastNameTextBoxErrorMsg = page.locator("#LastNameError"); // @FindBy(id = "LastNameError")
    this.dateOfBirthTextBox = page.locator("#preapp:datepicker"); // @FindBy(id = "preapp:datepicker")
    this.dateOfBirthTextBoxRedesigned = page.locator("#FFQHome_Yourinfo_Dob"); // @FindBy(id = "FFQHome_Yourinfo_Dob")
    this.dateOfBirthTextBoxErrorMsg = page.locator("#datepickerError"); // @FindBy(id = "datepickerError")
    this.maritalStatusDropDown = page.locator("#preapp:maritalStatus"); // @FindBy(id = "preapp:maritalStatus")
    this.maritalStatusDropDownErrorMsg = page.locator("#maritalStatusError"); // @FindBy(id = "maritalStatusError")
    this.addressTextBox = page.locator("#preapp:StreetAddress"); // @FindBy(id = "preapp:StreetAddress")
    this.addressTextBoxRedesigned = page.locator("#FFQHome_Yourinfo_ResedentialAddress"); // @FindBy(id = "FFQHome_Yourinfo_ResedentialAddress")
    this.addressTextBoxErrorMsg = page.locator("#StreetAddressError"); // @FindBy(id = "StreetAddressError")
    this.apartmentTextBox = page.locator("#preapp:apartment"); // @FindBy(id = "preapp:apartment")
    this.cityTextBox = page.locator("#preapp:City"); // @FindBy(id = "preapp:City")
    this.cityTextBoxRedesigned = page.locator("#FFQHome_Yourinfo_City"); // @FindBy(id = "FFQHome_Yourinfo_City")
    this.cityTextBoxErrorMsg = page.locator("#CityError"); // @FindBy(id = "CityError")
    this.zipCodeTextBox = page.locator("#preapp:ZipCode"); // @FindBy(id = "preapp:ZipCode")
    this.zipCodeTextBoxRedesigned = page.locator("#FFQHome_Yourinfo_Zipcode"); // @FindBy(id = "FFQHome_Yourinfo_Zipcode")
    this.zipCodeErrorMsg = page.locator("#ZipCodeError"); // @FindBy(id = "ZipCodeError")
    this.txtMailingZipErrorMsg = page.locator("#txtMailingZipError"); // @FindBy(id = "txtMailingZipError")
    this.zipCodeTextBoxFLState = page.locator("#FFQHome_Yourinfo_Zipcode"); // @FindBy(id = "FFQHome_Yourinfo_Zipcode")
    this.propertyTypeDropDown = page.locator("#preapp:propType"); // @FindBy(id = "preapp:propType")
    this.startQuoteButton = page.locator("[data-legacy-field=\"startQuoteButton\"]"); // @FindBy(id = START_QUOTE_BUTTON_ID)
    this.mailingAddressDifferentCheckBox = page.locator("#preapp:chkMailingAdd"); // @FindBy(id = "preapp:chkMailingAdd")
    this.mailingAddressTextBox = page.locator("#preapp:txtMailingStreet"); // @FindBy(id = "preapp:txtMailingStreet")
    this.txtMailingStreetErrorMsg = page.locator("#txtMailingStreetError"); // @FindBy(id = "txtMailingStreetError")
    this.mailingCityTextBox = page.locator("#preapp:txtMailCity"); // @FindBy(id = "preapp:txtMailCity")
    this.txtMailCityErrorMsg = page.locator("#txtMailCityError"); // @FindBy(id = "txtMailCityError")
    this.mailingStateDropDown = page.locator("#preapp:txtMailState"); // @FindBy(id = "preapp:txtMailState")
    this.mailingZipCodeTextBox = page.locator("#preapp:txtMailingZip"); // @FindBy(id = "preapp:txtMailingZip")
    this.spouseFirstNameTextBox = page.locator("#preapp:SpouseFirstName"); // @FindBy(id = "preapp:SpouseFirstName")
    this.spouseFirstNameTextBoxErrorMsg = page.locator("#SpouseFirstNameError"); // @FindBy(id = "SpouseFirstNameError")
    this.spouseLastNameTextBox = page.locator("#preapp:SpouseLastName"); // @FindBy(id = "preapp:SpouseLastName")
    this.spouseLastNameTextBoxErrorMsg = page.locator("#SpouseLastNameError"); // @FindBy(id = "SpouseLastNameError")
    this.spouseDateOfBirthTextBox = page.locator("#preapp:spouseDatepicker"); // @FindBy(id = "preapp:spouseDatepicker")
    this.spouseDateOfBirthTextBoxErrorMsg = page.locator("#spouseDatepickerError"); // @FindBy(id = "spouseDatepickerError")
    this.consumeReportPopUpYesButton = page.locator("xpath=//*[@id='fsphConsentAcrossAffiliate']/div[4]/button[1]"); // @FindBy(xpath = "//*[@id='fsphConsentAcrossAffiliate']/div[4]/button[1]")
    this.consumeReportPopUpNoButton = page.locator("xpath=//*[@id='fsphConsentAcrossAffiliate']/div[4]/button[2]"); // @FindBy(xpath = "//*[@id='fsphConsentAcrossAffiliate']/div[4]/button[2]")
    this.consumeReportPopUp = page.locator("#fsphConsentAcrossAffiliate"); // @FindBy(id = "fsphConsentAcrossAffiliate")
    this.stateTextBox = page.locator("#preapp:State1"); // @FindBy(id = "preapp:State1")
    this.stateTextBoxFLState = page.locator("#FFQHome_Yourinfo_State"); // @FindBy(id = "FFQHome_Yourinfo_State")
    this.retrieveFirstNameMissingInputMessage = page.locator(".ToolErrorText1"); // @FindBy(css = ".ToolErrorText1")
    this.retrieveFirstNameInvalidInputMessage = page.locator(".ToolErrorText1"); // @FindBy(css = ".ToolErrorText1")
    this.toolTipElement = page.locator("#toolTipadd"); // @FindBy(id = "toolTipadd")
    this.toolTipText = page.locator("xpath=//*[@id='toolTipadd']/span/span[2]"); // @FindBy(xpath = "//*[@id='toolTipadd']/span/span[2]")
    this.creditReportNotification = page.locator("#preapp:creditReportDisLbl"); // @FindBy(id = "preapp:creditReportDisLbl")
    this.mailingAddressCheckBoxText = page.locator("#preapp:lblMailingAddress"); // @FindBy(id = "preapp:lblMailingAddress")
    this.mailingAddressCheckBox = page.locator("xpath=//*[@id='MailingCheck']"); // @FindBy(xpath = "//*[@id='MailingCheck']")
    this.zipCodePopUpOKButton = page.locator("xpath=//*[@id='zipCodeChange:states']/input"); // @FindBy(xpath = "//*[@id='zipCodeChange:states']/input")
    this.zipCodePopUpCloseButton = page.locator("#zipCodeChange:statess"); // @FindBy(id = "zipCodeChange:statess")
    this.attentionHomeOwnersPopUp = page.locator("xpath=//*[@id='jsAlert99_popupBody']/div/div[2]/h2"); // @FindBy(xpath = "//*[@id='jsAlert99_popupBody']/div/div[2]/h2")
    this.homeOwnContinueBtn = page.locator("xpath=//button[@title = 'Continue']"); // @FindBy(xpath = "//button[@title = 'Continue']")
    this.homeOwnCancelBtn = page.locator("xpath=//button[@title = 'Cancel']"); // @FindBy(xpath = "//button[@title = 'Cancel']")
    this.willLoveFarmersStaticText = page.locator("xpath=//*[@id='hasBasicInfo']/h4"); // @FindBy(xpath = "//*[@id='hasBasicInfo']/h4")
    this.personalServiceStaticText = page.locator("xpath=//*[@id='hasBasicInfo']/ul/li[1]"); // @FindBy(xpath = "//*[@id='hasBasicInfo']/ul/li[1]")
    this.helpPointStaticText = page.locator("xpath=//*[@id='hasBasicInfo']/ul/li[2]"); // @FindBy(xpath = "//*[@id='hasBasicInfo']/ul/li[2]")
    this.dozenDiscountsStaticText = page.locator("xpath=//*[@id='hasBasicInfo']/ul/li[3]"); // @FindBy(xpath = "//*[@id='hasBasicInfo']/ul/li[3]")
    this.yourFarmersAgentStaticText = page.locator("xpath=//div[@id='summaryAgentInfoBuy']/div[@class='Mon']/h3[@class='farmersAgent']"); // @FindBy(xpath = "//div[@id='summaryAgentInfoBuy']/div[@class='Mon']/h3[@class='farmersAgent']")
    this.exsistingCustomerTitleText = page.locator("xpath=//*[@id='existingCustForm']/div/div[2]/div/h2"); // @FindBy(xpath = "//*[@id='existingCustForm']/div/div[2]/div/h2")
    this.exsistingCustomerBodyText = page.locator("xpath=//*[@id='existingCustForm']/div/div[3]/div/p[1]"); // @FindBy(xpath = "//*[@id='existingCustForm']/div/div[3]/div/p[1]")
    this.exsistingCustomerBodyText2 = page.locator("xpath=//*[@id='existingCustForm']/div/div[3]/div/p[2]"); // @FindBy(xpath = "//*[@id='existingCustForm']/div/div[3]/div/p[2]")
    this.exsistingCustomerFormDismissBtn = page.locator("xpath=//*[@id='existingCustForm']/div/div[1]"); // @FindBy(xpath = "//*[@id='existingCustForm']/div/div[1]")
    this.exsistingCustomerFormOKBtn = page.locator("#image4"); // @FindBy(id = "image4")
    this.occupationDropDown = page.locator("#preapp:propOccupation"); // @FindBy(id = "preapp:propOccupation")
    this.occupationDropDownErrorMsg = page.locator("#propOccupationError"); // @FindBy(id = "propOccupationError")
    this.spouseOccupationDropDown = page.locator("#preapp:spouseOccupation"); // @FindBy(id = "preapp:spouseOccupation")
    this.spouseOccupationDropDownErrorMsg = page.locator("#spouseOccupationError"); // @FindBy(id = "spouseOccupationError")
    this.propertyTypeHouseRadioBtn = page.locator("xpath=//*[@id='preapp:propType']/tbody/tr/td[1]/label"); // @FindBy(xpath = "//*[@id='preapp:propType']/tbody/tr/td[1]/label")
    this.propertyTypeTownHouseRadioBtn = page.locator("xpath=//*[@id='preapp:propType']/tbody/tr/td[2]/label"); // @FindBy(xpath = "//*[@id='preapp:propType']/tbody/tr/td[2]/label")
    this.blankSpace = page.locator("#bgWhite"); // @FindBy(css = "#bgWhite")
    this.cityDropDown = page.locator("#preapp:propCityMtpl"); // @FindBy(id = "preapp:propCityMtpl")
    this.firstNameLbl = page.locator("#preapp:FirstNameLbl"); // @FindBy(id = "preapp:FirstNameLbl")
    this.lastNameLbl = page.locator("#preapp:LastNameLbl"); // @FindBy(id = "preapp:LastNameLbl")
    this.dateOfBirthLbl = page.locator("#preapp:dateOfBirthLbl"); // @FindBy(id = "preapp:dateOfBirthLbl")
    this.propOccupationLbl = page.locator("#preapp:propOccupationLbl"); // @FindBy(id = "preapp:propOccupationLbl")
    this.maritalStatusLbl = page.locator("#preapp:maritalStatusLbl"); // @FindBy(id = "preapp:maritalStatusLbl")
    this.addressLbl = page.locator("#preapp:StreetAddressLbl"); // @FindBy(id = "preapp:StreetAddressLbl")
    this.apartmentLbl = page.locator("#preapp:SrtApartmentLbl"); // @FindBy(id = "preapp:SrtApartmentLbl")
    this.cityLbl = page.locator("#preapp:CityLbl"); // @FindBy(id = "preapp:CityLbl")
    this.stateLbl = page.locator("#preapp:StateLbl"); // @FindBy(id = "preapp:StateLbl")
    this.zipCodeLbl = page.locator("#preapp:ZipCodeLbl"); // @FindBy(id = "preapp:ZipCodeLbl")
    this.propTypeHouseLbl = page.locator("xpath=//label[@for='preapp:propType:0']"); // @FindBy(xpath = "//label[@for='preapp:propType:0']")
    this.propTypeTownHouseLbl = page.locator("xpath=//label[@for='preapp:propType:1']"); // @FindBy(xpath = "//label[@for='preapp:propType:1']")
    this.srtApartmentLbl = page.locator("#preapp:SrtApartmentLbl"); // @FindBy(id = "preapp:SrtApartmentLbl")
    this.propertyNavBarText = page.locator("xpath=//*[@id='preapp:progress:1:basic']/span[2]"); // @FindBy(xpath = "//*[@id='preapp:progress:1:basic']/span[2]")
    this.coverageNavBarText = page.locator("xpath=//*[@id='preapp:progress:2:basic']/span[2]"); // @FindBy(xpath = "//*[@id='preapp:progress:2:basic']/span[2]")
    this.quoteNavBarText = page.locator("xpath=//*[@id='preapp:progress:3:basic']/span[2]"); // @FindBy(xpath = "//*[@id='preapp:progress:3:basic']/span[2]")
    this.yourInfoNavBarText = page.locator("xpath=//span[@id='preapp:progress:0:basic']//span[@title='Step 1: Your Info'][contains(text(),'Your Info')]"); // @FindBy(xpath = "//span[@id='preapp:progress:0:basic']//span[@title='Step 1: Your Info'][contains(text(),'Your Info')]")
    this.blueNavBar = page.locator("#pbMenuPlaceHolder"); // @FindBy(id = "pbMenuPlaceHolder")
    this.headerLogo = page.locator("#HeaderLogo"); // @FindBy(id = "HeaderLogo")
    this.tellAboutYourselfText = page.locator("xpath=//*[@id='Intropreapp']/h1"); // @FindBy(xpath = "//*[@id='Intropreapp']/h1")
    this.toProvideYouSubTitleText = page.locator("xpath=//*[@id='Intropreapp']/p"); // @FindBy(xpath = "//*[@id='Intropreapp']/p")
    this.txtMailingStreetError = page.locator("#txtMailingStreetError"); // @FindBy(id = "txtMailingStreetError")
    this.txtMailCityError = page.locator("#txtMailCityError"); // @FindBy(id = "txtMailCityError")
    this.txtMailStateError = page.locator("#txtMailStateError"); // @FindBy(id = "txtMailStateError")
    this.txtMailingZipError = page.locator("#txtMailingZipError"); // @FindBy(id = "txtMailingZipError")
    this.occupationToolTip = page.locator("#occQ"); // @FindBy(id = "occQ")
    this.occupationToolTipCloseBtn = page.locator("xpath=//*[@id='occupation-popup']/div/input"); // @FindBy(xpath = "//*[@id='occupation-popup']/div/input")
    this.occupationToolTipText = page.locator(".AddPopup>p"); // @FindBy(css = ".AddPopup>p")
    this.addressToolTip = page.locator("#toolTipadd"); // @FindBy(id = "toolTipadd")
    this.addressToolTipCloseBtn = page.locator("xpath=//*[@id='resAddPopup']/input"); // @FindBy(xpath = "//*[@id='resAddPopup']/input")
    this.addressToolTipText = page.locator("xpath=//*[@id='resAddPopup']/p"); // @FindBy(xpath = "//*[@id='resAddPopup']/p")
    this.summaryBtn = page.locator("xpath=//*[@id='Background']/input[3]"); // @FindBy(xpath = "//*[@id='Background']/input[3]")
    this.cartBtn = page.locator("xpath=//div[@id='pbMenuPlaceHolder']//div[@id='pbMenu']//div[@id='pbTitleMobile']//span[@id='pbCarat']"); // @FindBy(xpath = "//div[@id='pbMenuPlaceHolder']//div[@id='pbMenu']//div[@id='pbTitleMobile']//span[@id='pbCarat']")
    this.blueNavBarStep1of4Text = page.locator("xpath=//div[@id='ContainerNew']//div[@id='pbTitleMobile']//span[@id='pbActiveStep']"); // @FindBy(xpath = "//div[@id='ContainerNew']//div[@id='pbTitleMobile']//span[@id='pbActiveStep']")
    this.blueNavBarSmall = page.locator("xpath=//*[@id='pbMenuPlaceHolder']"); // @FindBy(xpath = "//*[@id='pbMenuPlaceHolder']")
    this.summaryquoteSmall = page.locator("#summaryquoteSmall"); // @FindBy(id = "summaryquoteSmall")
    this.summaryYourFarmersAgentStaticText = page.locator("xpath=//*[@id='summaryAgentInfoBuy']/div[2]/h3"); // @FindBy(xpath = "//*[@id='summaryAgentInfoBuy']/div[2]/h3")
    this.summaryAgentNearYouStaticText = page.locator("xpath=//div[@id='summaryLB']//form[@id='agentForm1']//div[@id='NoAgentInfo']"); // @FindBy(xpath = "//div[@id='summaryLB']//form[@id='agentForm1']//div[@id='NoAgentInfo']")
    this.summaryTitleStaticText = page.locator("xpath=//*[@id='#summaryPopup']/div[1]/h1"); // @FindBy(xpath = "//*[@id='#summaryPopup']/div[1]/h1")
    this.summaryCloseBtn = page.locator("#summaryCloseBtn"); // @FindBy(id = "summaryCloseBtn")
    this.step1Text = page.locator("xpath=//*[@id='preapp:progress:0:basic']"); // @FindBy(xpath = "//*[@id='preapp:progress:0:basic']")
    this.step2Text = page.locator("xpath=//*[@id='preapp:progress:1:basic']"); // @FindBy(xpath = "//*[@id='preapp:progress:1:basic']")
    this.step3Text = page.locator("xpath=//*[@id='preapp:progress:2:basic']"); // @FindBy(xpath = "//*[@id='preapp:progress:2:basic']")
    this.step4Text = page.locator("xpath=//*[@id='preapp:progress:3:basic']"); // @FindBy(xpath = "//*[@id='preapp:progress:3:basic']")
    this.firstNameError = page.locator("#FirstNameError"); // @FindBy(id = "FirstNameError")
    this.lastNameError = page.locator("#LastNameError"); // @FindBy(id = "LastNameError")
    this.hqmElement = page.locator("[data-legacy-field=\"hqmElement\"]"); // @FindBy(xpath = HQM_ELEMENT_XPATH)
  }
}
