// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.home.pages.QuotePageHome. */
export class QuotePageHome extends CoreBasePage {
  public readonly topContinueButton: Locator;
  public readonly btmContinueButton: Locator;
  public readonly emailQuoteSummaryBtn: Locator;
  public readonly sendEmailButton: Locator;
  public readonly allPerilLimitsDeductiblesDropDown: Locator;
  public readonly waterLimitsDeductiblesDropDown: Locator;
  public readonly limitsDeductiblesForDwellingDropDown: Locator;
  public readonly limitsDeductiblesForExtendedReplacementCostDropDown: Locator;
  public readonly limitsDeductiblesForSeparateStructuresDropDown: Locator;
  public readonly limitsDeductiblesForPersonalPropertyDropDown: Locator;
  public readonly limitsDeductiblesForHomeContentsCoverageDropDown: Locator;
  public readonly limitsDeductiblesForLossOfUseDropDown: Locator;
  public readonly limitsDeductiblesForBuildingOrdinanceOrLawCoverageDropDown: Locator;
  public readonly limitsDeductiblesForScheduledRoofPaymentsDropDown: Locator;
  public readonly limitsDeductiblesForMetalRoofDropDown: Locator;
  public readonly limitsDeductiblesMatchingCoverageDropDown: Locator;
  public readonly limitsDeductiblesForMetalRoofDropDown7: Locator;
  public readonly limitsDeductiblesForPersonalLiabilityDropDown: Locator;
  public readonly limitsDeductiblesForMedicalPaymentsToOthersDropDown: Locator;
  public readonly specialLimitsOnSpecificPropertyForLimitSelectionDropDown: Locator;
  public readonly printQuoteSummaryButton: Locator;
  public readonly startQuoteButtonSideBar: Locator;
  public readonly lineOfBusinessDropDownSideBar: Locator;
  public readonly crossSellDropDown: Locator;
  public readonly startQuoteButton: Locator;
  public readonly legalDisclaimerStaticText: Locator;
  public readonly claimForgivenesStaticText: Locator;
  public readonly claimFreeDiscountStaticText: Locator;
  public readonly premiumAmountOnBottom: Locator;
  public readonly premiumAmountOnTop: Locator;
  public readonly personalLiabilityCoverageTextBottom: Locator;
  public readonly personalLiabilityCoverageTextTop: Locator;
  public readonly decliningDeductibleStaticText: Locator;
  public readonly limitsDeductiblesForWindAndHail: Locator;
  public readonly recalculateButton: Locator;
  public readonly updateQuoteButton: Locator;
  public readonly thanksYouLable: Locator;
  public readonly saveFinishLaterBtn: Locator;
  public readonly visitFcomBtn: Locator;
  public readonly insuredPropertyAddress: Locator;
  public readonly discounts: Locator;
  public readonly premiumAmount: Locator;
  public readonly packageName: Locator;
  public readonly propertyTabBtn: Locator;
  public readonly coverageTabBtn: Locator;
  public readonly windAndHailDedErrorMessage: Locator;
  public readonly resetLinkTopBtn: Locator;
  public readonly yourInfoNavBarText: Locator;
  public readonly propertyNavBarText: Locator;
  public readonly coverageNavBarText: Locator;
  public readonly quoteNavBarText: Locator;
  public readonly blueNavBar: Locator;
  public readonly farmersHeaderLogo: Locator;
  public readonly reviewYourHeaderStaticText: Locator;
  public readonly briefSummaryStaticText: Locator;
  public readonly briefSummaryStaticText2: Locator;
  public readonly footerDisclaimerStaticText: Locator;
  public readonly footerDisclaimerStaticText2: Locator;
  public readonly digiCertImage: Locator;
  public readonly footerPrivacyPolicyLink: Locator;
  public readonly footerTermsOfUseLink: Locator;
  public readonly footerContactUsLink: Locator;
  public readonly footerNoticeOfInformationLink: Locator;
  public readonly emailQuoteSummaryPopUp: Locator;
  public readonly closewindowInsidePopUp: Locator;
  public readonly sendEmailBtn: Locator;
  public readonly emailTextFieldInsidePopUp: Locator;
  public readonly titleTextInsidePopUp: Locator;
  public readonly windAndHailDedErrorMsg: Locator;
  public readonly defaultCoverageErrorMsg: Locator;
  public readonly autoCrossSellQuote: Locator;
  public readonly vtlCrossSellQuote: Locator;
  public readonly gbwlCrossSellQuote: Locator;
  public readonly stlCrossSellQuote: Locator;

  public constructor(page: Page) {
    super(page);
    this.topContinueButton = page.locator("#homequote:buyBtnTopHome"); // @FindBy(id = "homequote:buyBtnTopHome")
    this.btmContinueButton = page.locator("#homequote:buyBtnBtmHome"); // @FindBy(id = "homequote:buyBtnBtmHome")
    this.emailQuoteSummaryBtn = page.locator("xpath=//*[@id='titleNew']/p[3]"); // @FindBy(xpath = "//*[@id='titleNew']/p[3]")
    this.sendEmailButton = page.locator(".startQuoteBtnGreen.BtnNew"); // @FindBy(css = ".startQuoteBtnGreen.BtnNew")
    this.allPerilLimitsDeductiblesDropDown = page.locator("#homequote:allPerilsDed"); // @FindBy(id = "homequote:allPerilsDed")
    this.waterLimitsDeductiblesDropDown = page.locator("#homequote:hurricaneDed"); // @FindBy(id = "homequote:hurricaneDed")
    this.limitsDeductiblesForDwellingDropDown = page.locator("#homequote:fsphHomeCvgContainer:0:plcyCvgMenu"); // @FindBy(id = "homequote:fsphHomeCvgContainer:0:plcyCvgMenu")
    this.limitsDeductiblesForExtendedReplacementCostDropDown = page.locator("#homequote:fsphHomeCvgContainer:1:plcyCvgMenu"); // @FindBy(id = "homequote:fsphHomeCvgContainer:1:plcyCvgMenu")
    this.limitsDeductiblesForSeparateStructuresDropDown = page.locator("#homequote:fsphHomeCvgContainer:2:plcyCvgMenu"); // @FindBy(id = "homequote:fsphHomeCvgContainer:2:plcyCvgMenu")
    this.limitsDeductiblesForPersonalPropertyDropDown = page.locator("#homequote:fsphHomeCvgContainer:3:plcyCvgMenu"); // @FindBy(id = "homequote:fsphHomeCvgContainer:3:plcyCvgMenu")
    this.limitsDeductiblesForHomeContentsCoverageDropDown = page.locator("#homequote:fsphHomeCvgContainer:4:plcyCvgMenu"); // @FindBy(id = "homequote:fsphHomeCvgContainer:4:plcyCvgMenu")
    this.limitsDeductiblesForLossOfUseDropDown = page.locator("#homequote:fsphHomeCvgContainer:5:plcyCvgMenu"); // @FindBy(id = "homequote:fsphHomeCvgContainer:5:plcyCvgMenu")
    this.limitsDeductiblesForBuildingOrdinanceOrLawCoverageDropDown = page.locator("#homequote:fsphHomeCvgContainer:6:plcyCvgMenu"); // @FindBy(id = "homequote:fsphHomeCvgContainer:6:plcyCvgMenu")
    this.limitsDeductiblesForScheduledRoofPaymentsDropDown = page.locator("#homequote:fsphHomeCvgContainer:7:plcyCvgMenu"); // @FindBy(id = "homequote:fsphHomeCvgContainer:7:plcyCvgMenu")
    this.limitsDeductiblesForMetalRoofDropDown = page.locator("#homequote:fsphHomeCvgContainer:8:plcyCvgMenu"); // @FindBy(id = "homequote:fsphHomeCvgContainer:8:plcyCvgMenu")
    this.limitsDeductiblesMatchingCoverageDropDown = page.locator("#homequote:fsphHomeCvgContainer:9:plcyCvgMenu"); // @FindBy(id = "homequote:fsphHomeCvgContainer:9:plcyCvgMenu")
    this.limitsDeductiblesForMetalRoofDropDown7 = page.locator("#homequote:fsphHomeCvgContainer:7:plcyCvgMenu"); // @FindBy(id = "homequote:fsphHomeCvgContainer:7:plcyCvgMenu")
    this.limitsDeductiblesForPersonalLiabilityDropDown = page.locator("#homequote:fsphLiability:0:liabilityMenu"); // @FindBy(id = "homequote:fsphLiability:0:liabilityMenu")
    this.limitsDeductiblesForMedicalPaymentsToOthersDropDown = page.locator("#homequote:fsphLiability:1:liabilityMenu"); // @FindBy(id = "homequote:fsphLiability:1:liabilityMenu")
    this.specialLimitsOnSpecificPropertyForLimitSelectionDropDown = page.locator("#homequote:splLmtCvgMenu"); // @FindBy(id = "homequote:splLmtCvgMenu")
    this.printQuoteSummaryButton = page.locator("xpath=//*[@id='PrintLink']"); // @FindBy(xpath = "//*[@id='PrintLink']")
    this.startQuoteButtonSideBar = page.locator("#accordMain:startQuote"); // @FindBy(id = "accordMain:startQuote")
    this.lineOfBusinessDropDownSideBar = page.locator("#accordMain:quoteType"); // @FindBy(id = "accordMain:quoteType")
    this.crossSellDropDown = page.locator("#buypolicyHome:quoteType"); // @FindBy(id = "buypolicyHome:quoteType")
    this.startQuoteButton = page.locator("[name=\"buypolicyHome:j_id240\"]"); // @FindBy(name = "buypolicyHome:j_id240")
    this.legalDisclaimerStaticText = page.locator("#homequote:fsphFooterOne"); // @FindBy(id = "homequote:fsphFooterOne")
    this.claimForgivenesStaticText = page.locator("xpath=//span[contains(@id,'homequote:featureContentThree2')]"); // @FindBy(xpath = "//span[contains(@id,'homequote:featureContentThree2')]")
    this.claimFreeDiscountStaticText = page.locator("xpath=//span[contains(@id,'homequote:featureContentTwo2')]"); // @FindBy(xpath = "//span[contains(@id,'homequote:featureContentTwo2')]")
    this.premiumAmountOnBottom = page.locator("#OabPriceBtmHome"); // @FindBy(id = "OabPriceBtmHome")
    this.premiumAmountOnTop = page.locator("#OabPriceTopHome"); // @FindBy(id = "OabPriceTopHome")
    this.personalLiabilityCoverageTextBottom = page.locator("#homequote:personalLiabilityBtm"); // @FindBy(id = "homequote:personalLiabilityBtm")
    this.personalLiabilityCoverageTextTop = page.locator("#homequote:personalLiabilityTop"); // @FindBy(id = "homequote:personalLiabilityTop")
    this.decliningDeductibleStaticText = page.locator("#homequote:featureContent2"); // @FindBy(id = "homequote:featureContent2")
    this.limitsDeductiblesForWindAndHail = page.locator("#homequote:windAndHailDed"); // @FindBy(id = "homequote:windAndHailDed")
    this.recalculateButton = page.locator("#homequote:recalculateBtnTopHome"); // @FindBy(id = "homequote:recalculateBtnTopHome")
    this.updateQuoteButton = page.locator("#HomeUpdateBtn"); // @FindBy(id = "HomeUpdateBtn")
    this.thanksYouLable = page.locator("xpath=//*[@id='HomeUpdaterr']/div[1]/h2"); // @FindBy(xpath = "//*[@id='HomeUpdaterr']/div[1]/h2")
    this.saveFinishLaterBtn = page.locator("#summaryBacktoQuoteCondo"); // @FindBy(id = "summaryBacktoQuoteCondo")
    this.visitFcomBtn = page.locator("xpath=//*[@id='contButtonCA']/a"); // @FindBy(xpath = "//*[@id='contButtonCA']/a")
    this.insuredPropertyAddress = page.locator("xpath=//div[@id='commonCss' and @class='propertySection']"); // @FindBy(xpath = "//div[@id='commonCss' and @class='propertySection']")
    this.discounts = page.locator("xpath=//div[@class='discountSection']//li"); // @FindBy(xpath = "//div[@class='discountSection']//li")
    this.premiumAmount = page.locator("#OabPriceTopHome"); // @FindBy(id = "OabPriceTopHome")
    this.packageName = page.locator("#homequote:PackageTypeTopHome"); // @FindBy(id = "homequote:PackageTypeTopHome")
    this.propertyTabBtn = page.locator("xpath=//*[@id='homequote:progress:1:fsphhomequote']/span[2]"); // @FindBy(xpath = "//*[@id='homequote:progress:1:fsphhomequote']/span[2]")
    this.coverageTabBtn = page.locator("xpath=//*[@id='homequote:progress:2:fsphhomequote']/span[2]"); // @FindBy(xpath = "//*[@id='homequote:progress:2:fsphhomequote']/span[2]")
    this.windAndHailDedErrorMessage = page.locator("#windAndHailDedError"); // @FindBy(id = "windAndHailDedError")
    this.resetLinkTopBtn = page.locator("#homequote:resetLinkTop"); // @FindBy(id = "homequote:resetLinkTop")
    this.yourInfoNavBarText = page.locator("xpath=//*[@id='homequote:progress:0:fsphhomequote']/span[2]"); // @FindBy(xpath = "//*[@id='homequote:progress:0:fsphhomequote']/span[2]")
    this.propertyNavBarText = page.locator("xpath=//*[@id='homequote:progress:1:fsphhomequote']/span[2]"); // @FindBy(xpath = "//*[@id='homequote:progress:1:fsphhomequote']/span[2]")
    this.coverageNavBarText = page.locator("xpath=//*[@id='homequote:progress:2:fsphhomequote']/span[2]"); // @FindBy(xpath = "//*[@id='homequote:progress:2:fsphhomequote']/span[2]")
    this.quoteNavBarText = page.locator("xpath=//*[@id='homequote:progress:3:fsphhomequote']/span[2]"); // @FindBy(xpath = "//*[@id='homequote:progress:3:fsphhomequote']/span[2]")
    this.blueNavBar = page.locator("#pbMenuPlaceHolder"); // @FindBy(id = "pbMenuPlaceHolder")
    this.farmersHeaderLogo = page.locator("#HeaderLogo"); // @FindBy(id = "HeaderLogo")
    this.reviewYourHeaderStaticText = page.locator("xpath=//*[@id='HomeIntro']/p"); // @FindBy(xpath = "//*[@id='HomeIntro']/p")
    this.briefSummaryStaticText = page.locator("xpath=//*[@id='homequote:fsphFooterOne']/p/i"); // @FindBy(xpath = "//*[@id='homequote:fsphFooterOne']/p/i")
    this.briefSummaryStaticText2 = page.locator("xpath=//*[@id='homequote:fsphFooterTwo']/p/i"); // @FindBy(xpath = "//*[@id='homequote:fsphFooterTwo']/p/i")
    this.footerDisclaimerStaticText = page.locator("xpath=//*[@id='mainSection']/div[5]/p[1]"); // @FindBy(xpath = "//*[@id='mainSection']/div[5]/p[1]")
    this.footerDisclaimerStaticText2 = page.locator("xpath=//*[@id='mainSection']/div[5]/p[2]"); // @FindBy(xpath = "//*[@id='mainSection']/div[5]/p[2]")
    this.digiCertImage = page.locator("xpath=//*[@id='VeriSign']/img"); // @FindBy(xpath = "//*[@id='VeriSign']/img")
    this.footerPrivacyPolicyLink = page.locator("xpath=//*[@id='footUl']/li[1]/a"); // @FindBy(xpath = "//*[@id='footUl']/li[1]/a")
    this.footerTermsOfUseLink = page.locator("xpath=//*[@id='footUl']/li[2]/a"); // @FindBy(xpath = "//*[@id='footUl']/li[2]/a")
    this.footerContactUsLink = page.locator("xpath=//*[@id='footUl']/li[3]/a"); // @FindBy(xpath = "//*[@id='footUl']/li[3]/a")
    this.footerNoticeOfInformationLink = page.locator("xpath=//*[@id='footUl']/li[4]/a"); // @FindBy(xpath = "//*[@id='footUl']/li[4]/a")
    this.emailQuoteSummaryPopUp = page.locator("#RegisterMyFarmers"); // @FindBy(id = "RegisterMyFarmers")
    this.closewindowInsidePopUp = page.locator("#closewindow"); // @FindBy(id = "closewindow")
    this.sendEmailBtn = page.locator("xpath=//*[@id='showButtons']/div/input"); // @FindBy(xpath = "//*[@id='showButtons']/div/input")
    this.emailTextFieldInsidePopUp = page.locator("xpath=//*[@id='changeEmail:email']"); // @FindBy(xpath = "//*[@id='changeEmail:email']")
    this.titleTextInsidePopUp = page.locator("xpath=//*[@id='ModalHdr']/h2"); // @FindBy(xpath = "//*[@id='ModalHdr']/h2")
    this.windAndHailDedErrorMsg = page.locator("#windAndHailDedError"); // @FindBy(id = "windAndHailDedError")
    this.defaultCoverageErrorMsg = page.locator("xpath=//div[@id='23000']/p[contains(text(), 'The Premier package default coverage limits are the minimum requirement for Guaranteed Replacement Cost.')]"); // @FindBy(xpath = "//div[@id='23000']/p[contains(text(), 'The Premier package default coverage limits are the minimum requirement for Guaranteed Replacement Cost.')]")
    this.autoCrossSellQuote = page.locator("[data-legacy-field=\"autoCrossSellQuote\"]"); // @FindBy(xpath = CROSS_SELL_ENTRIES + AUTO_CROSS_SELL_XPATH)
    this.vtlCrossSellQuote = page.locator("[data-legacy-field=\"vtlCrossSellQuote\"]"); // @FindBy(xpath = CROSS_SELL_ENTRIES + VTL_CROSS_SELL_XPATH)
    this.gbwlCrossSellQuote = page.locator("[data-legacy-field=\"gbwlCrossSellQuote\"]"); // @FindBy(xpath = CROSS_SELL_ENTRIES + GBW_CROSS_SELL_XPATH)
    this.stlCrossSellQuote = page.locator("[data-legacy-field=\"stlCrossSellQuote\"]"); // @FindBy(xpath = CROSS_SELL_ENTRIES + STL_CROSS_SELL_XPATH)
  }
}
