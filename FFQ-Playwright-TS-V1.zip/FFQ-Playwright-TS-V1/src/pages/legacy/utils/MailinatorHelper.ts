// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.utils.MailinatorHelper. */
export class MailinatorHelper extends CoreBasePage {
  public readonly logInButton: Locator;
  public readonly emailIdLoginInputField: Locator;
  public readonly passwordInputField: Locator;
  public readonly logInSubmit: Locator;
  public readonly emailUserNameInputField: Locator;
  public readonly emailSubject: Locator;
  public readonly farmersInsuranceLink: Locator;
  public readonly premiumAmount: Locator;
  public readonly finishMyQuote: Locator;
  public readonly finalizeMyCoverage: Locator;

  public constructor(page: Page) {
    super(page);
    this.logInButton = page.locator("#menu-item-7937"); // @FindBy(css = "#menu-item-7937")
    this.emailIdLoginInputField = page.locator("#many_login_email"); // @FindBy(id = "many_login_email")
    this.passwordInputField = page.locator("#many_login_password"); // @FindBy(id = "many_login_password")
    this.logInSubmit = page.locator("a[class='btn btn-default submit']"); // @FindBy(css = "a[class='btn btn-default submit']")
    this.emailUserNameInputField = page.locator("input[id='inbox_field']"); // @FindBy(css = "input[id='inbox_field']")
    this.emailSubject = page.locator("xpath=//div[@class='wrapper-title d-flex align-items-center']//div[2]"); // @FindBy(xpath = "//div[@class='wrapper-title d-flex align-items-center']//div[2]")
    this.farmersInsuranceLink = page.locator("img[title='Farmers Insurance']"); // @FindBy(css = "img[title='Farmers Insurance']")
    this.premiumAmount = page.locator("span[style='font-size: 28px']>b"); // @FindBy(css = "span[style='font-size: 28px']>b")
    this.finishMyQuote = page.getByRole('link', { name: "Finish my quote" }); // @FindBy(partialLinkText = "Finish my quote")
    this.finalizeMyCoverage = page.getByRole('link', { name: "Finalize my coverage" }); // @FindBy(partialLinkText = "Finalize my coverage")
  }
}
