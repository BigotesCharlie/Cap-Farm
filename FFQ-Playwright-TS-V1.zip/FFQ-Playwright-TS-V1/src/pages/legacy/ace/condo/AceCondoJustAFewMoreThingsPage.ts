// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.condo.AceCondoJustAFewMoreThingsPage. */
export class AceCondoJustAFewMoreThingsPage extends CoreBasePage {
  public readonly hoaCoversEveyThingsWallsInCheckBox: Locator;
  public readonly hoaCoversEveyThingsWallsInCheckBoxSubHeader: Locator;
  public readonly learnWhatWallsInMeanLink: Locator;
  public readonly hoaCoversWallsInHeaderSideSheet: Locator;
  public readonly hoaCoversWallsInDescriptionSideSheet: Locator;
  public readonly closeIconWhatWallsInSideSheet: Locator;

  public constructor(page: Page) {
    super(page);
    this.hoaCoversEveyThingsWallsInCheckBox = page.locator("xpath=//mat-label[contains(text(),'HOA covers everything “walls-in”')]"); // @FindBy(xpath = "//mat-label[contains(text(),'HOA covers everything \u201cwalls-in\u201d')]")
    this.hoaCoversEveyThingsWallsInCheckBoxSubHeader = page.locator("xpath=//p[contains(text(),' This is uncommon. Not sure if it applies?')]"); // @FindBy(xpath = "//p[contains(text(),' This is uncommon. Not sure if it applies?')]")
    this.learnWhatWallsInMeanLink = page.locator("xpath=//a[contains(@class,'hoaWallsInLink')]"); // @FindBy(xpath = "//a[contains(@class,'hoaWallsInLink')]")
    this.hoaCoversWallsInHeaderSideSheet = page.locator("xpath=//h1[contains(text(), 'HOA covers')]"); // @FindBy(xpath = "//h1[contains(text(), 'HOA covers')]")
    this.hoaCoversWallsInDescriptionSideSheet = page.locator("xpath=//p[contains(text(), 'Check with your HOA if you are unsure.')]"); // @FindBy(xpath = "//p[contains(text(), 'Check with your HOA if you are unsure.')]")
    this.closeIconWhatWallsInSideSheet = page.locator("xpath=//mat-icon[contains(text(),'close')]"); // @FindBy(xpath = "//mat-icon[contains(text(),'close')]")
  }
}
