// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.condo.AceCondoAdditionalCoveragesPage. */
export class AceCondoAdditionalCoveragesPage extends CoreBasePage {
  public readonly quoteAllOtherCoveragesPriceOnCardDesktop: Locator;
  public readonly quoteAllOtherCoveragesPriceOnCardMobile: Locator;
  public readonly headerSewerDrain1: Locator;
  public readonly headerSewerDrain2: Locator;
  public readonly radioButtonsSewerDrain: Locator;
  public readonly footerSewerDrain: Locator;
  public readonly footerSewerDrainLabel1: Locator;
  public readonly footerSewerDrainLabel2: Locator;
  public readonly matButtonSewerDrainBasic: Locator;
  public readonly footerSewerDrainMD: Locator;
  public readonly matButtonSewerDrainExtended: Locator;
  public readonly matButtonSewerDrainFull: Locator;
  public readonly matButtonSewerDrainPartial: Locator;
  public readonly inputSewerDrain: Locator;
  public readonly buttonSewerDrainMinus: Locator;
  public readonly buttonSewerDrainPlus: Locator;
  public readonly subTextInputSewerDrain: Locator;
  public readonly headerIncreasedValuables: Locator;
  public readonly headerIncreasedValuablesInfoIcon: Locator;
  public readonly checkboxesIncreasedValuables: Locator;
  public readonly footerIncreasedValuables: Locator;
  public readonly inputIncreasedCoverageJewelry: Locator;
  public readonly increaseCoverageJewelry: Locator;
  public readonly decreaseCoverageJewelry: Locator;
  public readonly increasedValuablesInfoDialogSubtitle: Locator;
  public readonly listIncreasedValuablesInfoDialogItems: Locator;
  public readonly headerEarthquake: Locator;
  public readonly radioButtonsEarthquake: Locator;
  public readonly headersEarthquakeSection: Locator;
  public readonly listFoundationsEarthquakeSection: Locator;
  public readonly toggleButtonsEarthquake: Locator;
  public readonly earthquakeInfoIcon: Locator;
  public readonly earthquakeCoverageInfoDialogHeader: Locator;
  public readonly earthquakeInfoDialogSubheaders: Locator;
  public readonly earthquakeInfoDialogParagraphs: Locator;
  public readonly earthquakeCoverageHeading: Locator;
  public readonly earthquakeCoverageDesc: Locator;
  public readonly earthquakeCoverageInfo: Locator;
  public readonly earthquakeCoverageInfoContent: Locator;

  public constructor(page: Page) {
    super(page);
    this.quoteAllOtherCoveragesPriceOnCardDesktop = page.locator("[data-legacy-field=\"quoteAllOtherCoveragesPriceOnCardDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + OPTIONAL_COVERAGES_XPATH)
    this.quoteAllOtherCoveragesPriceOnCardMobile = page.locator("[data-legacy-field=\"quoteAllOtherCoveragesPriceOnCardMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + OPTIONAL_COVERAGES_XPATH)
    this.headerSewerDrain1 = page.locator("xpath=//div[@id='sewer']//label[contains(@class,'tui-input-text-2')][1]"); // @FindBy(xpath = "//div[@id='sewer']//label[contains(@class,'tui-input-text-2')][1]")
    this.headerSewerDrain2 = page.locator("xpath=//div[@id='sewer']//label[contains(@class,'tui-input-text-2')][2]"); // @FindBy(xpath = "//div[@id='sewer']//label[contains(@class,'tui-input-text-2')][2]")
    this.radioButtonsSewerDrain = page.locator("xpath=//mat-radio-group[@aria-label='coverage limit for Sewer and drain']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@aria-label='coverage limit for Sewer and drain']//mat-radio-button")
    this.footerSewerDrain = page.locator("xpath=//div[@id='sewer']//label/following-sibling::div"); // @FindBy(xpath = "//div[@id='sewer']//label/following-sibling::div")
    this.footerSewerDrainLabel1 = page.locator("xpath=//div[@id='sewer']//label/following-sibling::div/label[1]"); // @FindBy(xpath = "//div[@id='sewer']//label/following-sibling::div/label[1]")
    this.footerSewerDrainLabel2 = page.locator("xpath=//div[@id='sewer']//label/following-sibling::div/label[2]"); // @FindBy(xpath = "//div[@id='sewer']//label/following-sibling::div/label[2]")
    this.matButtonSewerDrainBasic = page.locator("xpath=//mat-button-toggle-group[@aria-label='Coverage type']//button[.='Basic']"); // @FindBy(xpath = "//mat-button-toggle-group[@aria-label='Coverage type']//button[.='Basic']")
    this.footerSewerDrainMD = page.locator("xpath=//div[@id='sewer']//label/following-sibling::div/div"); // @FindBy(xpath = "//div[@id='sewer']//label/following-sibling::div/div")
    this.matButtonSewerDrainExtended = page.locator("xpath=//mat-button-toggle-group[@aria-label='Coverage type']//button[.='Extended']"); // @FindBy(xpath = "//mat-button-toggle-group[@aria-label='Coverage type']//button[.='Extended']")
    this.matButtonSewerDrainFull = page.locator("xpath=//mat-button-toggle-group[@aria-label='What level of coverage do you want?']//button[.='Full']"); // @FindBy(xpath = "//mat-button-toggle-group[@aria-label='What level of coverage do you want?']//button[.='Full']")
    this.matButtonSewerDrainPartial = page.locator("xpath=//mat-button-toggle-group[@aria-label='What level of coverage do you want?']//button[.='Partial']"); // @FindBy(xpath = "//mat-button-toggle-group[@aria-label='What level of coverage do you want?']//button[.='Partial']")
    this.inputSewerDrain = page.locator("xpath=//div[@id='sewer']//mat-card//input"); // @FindBy(xpath = "//div[@id='sewer']//mat-card//input")
    this.buttonSewerDrainMinus = page.locator("xpath=//div[@id='sewer']//mat-button-toggle[.='remove']"); // @FindBy(xpath = "//div[@id='sewer']//mat-button-toggle[.='remove']")
    this.buttonSewerDrainPlus = page.locator("xpath=//div[@id='sewer']//mat-button-toggle[.='add']"); // @FindBy(xpath = "//div[@id='sewer']//mat-button-toggle[.='add']")
    this.subTextInputSewerDrain = page.locator("xpath=//div[@id='sewer']//mat-hint"); // @FindBy(xpath = "//div[@id='sewer']//mat-hint")
    this.headerIncreasedValuables = page.locator("xpath=//div[@id='increasedValuables']//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='increasedValuables']//label[contains(@class,'tui-input-text-2')]")
    this.headerIncreasedValuablesInfoIcon = page.locator("xpath=//div[@id='increasedValuables']//button[contains(@aria-label,'info icon')]"); // @FindBy(xpath = "//div[@id='increasedValuables']//button[contains(@aria-label,'info icon')]")
    this.checkboxesIncreasedValuables = page.locator("xpath=//div[@id='increasedValuables']//mat-checkbox"); // @FindBy(xpath = "//div[@id='increasedValuables']//mat-checkbox")
    this.footerIncreasedValuables = page.locator("xpath=//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]"); // @FindBy(xpath = "//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]")
    this.inputIncreasedCoverageJewelry = page.locator("[data-legacy-field=\"inputIncreasedCoverageJewelry\"]"); // @FindBy(xpath = INCREASED_VALUABLES_CHECKBOXES_FIELD_XPATH + "[1]//input")
    this.increaseCoverageJewelry = page.locator("[data-legacy-field=\"increaseCoverageJewelry\"]"); // @FindBy(xpath = INCREASED_VALUABLES_INCREASE_LIMIT_BUTTON_XPATH + "[1]")
    this.decreaseCoverageJewelry = page.locator("[data-legacy-field=\"decreaseCoverageJewelry\"]"); // @FindBy(xpath = INCREASED_VALUABLES_DECREASE_LIMIT_BUTTON_XPATH + "[1]")
    this.increasedValuablesInfoDialogSubtitle = page.locator("xpath=//app-increase-valuables-info-dialog//div[contains(@class,'tui-field-label')]"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-field-label')]")
    this.listIncreasedValuablesInfoDialogItems = page.locator("xpath=//app-increase-valuables-info-dialog//div/ul/li"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div/ul/li")
    this.headerEarthquake = page.locator("xpath=//div[@id='Earthquake']//label"); // @FindBy(xpath = "//div[@id='Earthquake']//label")
    this.radioButtonsEarthquake = page.locator("xpath=//div[@id='Earthquake']//mat-radio-button"); // @FindBy(xpath = "//div[@id='Earthquake']//mat-radio-button")
    this.headersEarthquakeSection = page.locator("xpath=//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]")
    this.listFoundationsEarthquakeSection = page.locator("xpath=//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]/following-sibling::div//li"); // @FindBy(xpath = "//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]/following-sibling::div//li")
    this.toggleButtonsEarthquake = page.locator("xpath=//div[@id='Earthquake']//mat-button-toggle"); // @FindBy(xpath = "//div[@id='Earthquake']//mat-button-toggle")
    this.earthquakeInfoIcon = page.locator("xpath=//div[@id='Earthquake']//button[contains(@aria-label,'info icon')]"); // @FindBy(xpath = "//div[@id='Earthquake']//button[contains(@aria-label,'info icon')]")
    this.earthquakeCoverageInfoDialogHeader = page.locator("xpath=//app-earthquake-coverage-dialog//h4"); // @FindBy(xpath = "//app-earthquake-coverage-dialog//h4")
    this.earthquakeInfoDialogSubheaders = page.locator("xpath=//app-earthquake-coverage-dialog//div/span[contains(@class,'tui-subtitle-2')]"); // @FindBy(xpath = "//app-earthquake-coverage-dialog//div/span[contains(@class,'tui-subtitle-2')]")
    this.earthquakeInfoDialogParagraphs = page.locator("xpath=//app-earthquake-coverage-dialog//div[contains(@class,'tui-body')]"); // @FindBy(xpath = "//app-earthquake-coverage-dialog//div[contains(@class,'tui-body')]")
    this.earthquakeCoverageHeading = page.locator("xpath=//app-additional-coverages-page//h2[@id='earthquake-coverage-heading']"); // @FindBy(xpath = "//app-additional-coverages-page//h2[@id='earthquake-coverage-heading']")
    this.earthquakeCoverageDesc = page.locator("xpath=//app-additional-coverages-page//p[contains(@class,'earthquake_coverage_full_description')]"); // @FindBy(xpath = "//app-additional-coverages-page//p[contains(@class,'earthquake_coverage_full_description')]")
    this.earthquakeCoverageInfo = page.locator("xpath=//div[@class='earthquake-coverage-info']//div[contains(@class,'tui-info-box-header')]"); // @FindBy(xpath = "//div[@class='earthquake-coverage-info']//div[contains(@class,'tui-info-box-header')]")
    this.earthquakeCoverageInfoContent = page.locator("xpath=//div[@class='earthquake-coverage-info']//p[@class='tui-info-box-content']"); // @FindBy(xpath = "//div[@class='earthquake-coverage-info']//p[@class='tui-info-box-content']")
  }
}
