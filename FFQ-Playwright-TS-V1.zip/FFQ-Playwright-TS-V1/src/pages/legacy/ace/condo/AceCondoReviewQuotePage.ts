// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.condo.AceCondoReviewQuotePage. */
export class AceCondoReviewQuotePage extends CoreBasePage {
  public readonly quoteSummaryHeading: Locator;
  public readonly quoteSummarySubheading: Locator;
  public readonly linkChangeCoverage: Locator;
  public readonly quotePriceOnCard: Locator;
  public readonly presentmentCardPriceHeader: Locator;
  public readonly linkViewMonthlyPricing: Locator;
  public readonly linkViewPayInFullPricing: Locator;
  public readonly quotePrimaryCoverageOnCard: Locator;
  public readonly quoteAllOtherCoveragesPriceOnCard: Locator;
  public readonly primaryCoveragesPriceOnCardDesktop: Locator;
  public readonly primaryCoveragesPriceOnCardMobile: Locator;
  public readonly getQuoteAllOtherCoveragesPriceOnCardDesktop: Locator;
  public readonly getGetQuoteAllOtherCoveragesPriceOnCardMobile: Locator;
  public readonly quoteDiscountsOnCard: Locator;
  public readonly deductiblesHeader: Locator;
  public readonly deductiblesHeaders: Locator;
  public readonly deductibleLabels: Locator;
  public readonly deductibleAmount: Locator;
  public readonly coveragesHeader: Locator;
  public readonly outOfPocketCostHeader: Locator;

  public constructor(page: Page) {
    super(page);
    this.quoteSummaryHeading = page.locator("xpath=//app-condo-renters-quote-review//h1[text()='Here is your quote']"); // @FindBy(xpath = "//app-condo-renters-quote-review//h1[text()='Here is your quote']")
    this.quoteSummarySubheading = page.locator("xpath=//app-condo-renters-quote-review//div/a[text()='Change coverage']/preceding-sibling::span"); // @FindBy(xpath = "//app-condo-renters-quote-review//div/a[text()='Change coverage']/preceding-sibling::span")
    this.linkChangeCoverage = page.locator("[data-legacy-field=\"linkChangeCoverage\"]"); // @FindBy(xpath = CHANGE_COVERAGE_XPATH)
    this.quotePriceOnCard = page.locator("[data-legacy-field=\"quotePriceOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tui-price")
    this.presentmentCardPriceHeader = page.locator("[data-legacy-field=\"presentmentCardPriceHeader\"]"); // @FindBy(xpath = PRESENTMENT_CARD_PRICE_HEADER_XPATH)
    this.linkViewMonthlyPricing = page.locator("[data-legacy-field=\"linkViewMonthlyPricing\"]"); // @FindBy(xpath = VIEW_MONTHLY_PRICING_LINK_XPATH)
    this.linkViewPayInFullPricing = page.locator("[data-legacy-field=\"linkViewPayInFullPricing\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + VIEW_PAY_IN_FULL_PRICING_LINK_XPATH)
    this.quotePrimaryCoverageOnCard = page.locator("[data-legacy-field=\"quotePrimaryCoverageOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[starts-with(text(),'Primary coverages')]/following-sibling::td")
    this.quoteAllOtherCoveragesPriceOnCard = page.locator("[data-legacy-field=\"quoteAllOtherCoveragesPriceOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[text()='All other coverages']/following-sibling::td")
    this.primaryCoveragesPriceOnCardDesktop = page.locator("[data-legacy-field=\"primaryCoveragesPriceOnCardDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + PRIMARY_COVERAGES_XPATH)
    this.primaryCoveragesPriceOnCardMobile = page.locator("[data-legacy-field=\"primaryCoveragesPriceOnCardMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + PRIMARY_COVERAGES_XPATH)
    this.getQuoteAllOtherCoveragesPriceOnCardDesktop = page.locator("[data-legacy-field=\"getQuoteAllOtherCoveragesPriceOnCardDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + ALL_OTHER_COVERAGES_XPATH)
    this.getGetQuoteAllOtherCoveragesPriceOnCardMobile = page.locator("[data-legacy-field=\"getGetQuoteAllOtherCoveragesPriceOnCardMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + ALL_OTHER_COVERAGES_XPATH)
    this.quoteDiscountsOnCard = page.locator("[data-legacy-field=\"quoteDiscountsOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div")
    this.deductiblesHeader = page.locator("xpath=//app-condo-renters-quote-review//h2[contains(.,'Deductibles')]"); // @FindBy(xpath = "//app-condo-renters-quote-review//h2[contains(.,'Deductibles')]")
    this.deductiblesHeaders = page.locator("xpath=//app-condo-renters-quote-review//h2"); // @FindBy(xpath = "//app-condo-renters-quote-review//h2")
    this.deductibleLabels = page.locator("xpath=//div[contains(@class,'deductible-label')]"); // @FindBy(xpath = "//div[contains(@class,'deductible-label')]")
    this.deductibleAmount = page.locator("xpath=//div[contains(@class,'deductible-amount')]"); // @FindBy(xpath = "//div[contains(@class,'deductible-amount')]")
    this.coveragesHeader = page.locator("xpath=//div[@id='editCoverageDialogHeading']"); // @FindBy(xpath = "//div[@id='editCoverageDialogHeading']")
    this.outOfPocketCostHeader = page.locator("xpath=//app-condo-renters-quote-review//h2/following-sibling::div[1]"); // @FindBy(xpath = "//app-condo-renters-quote-review//h2/following-sibling::div[1]")
  }
}
