// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.condo.AceCondoAdditionalInfoPage. */
export class AceCondoAdditionalInfoPage extends CoreBasePage {
  public readonly temporaryRentalMatCheckBox: Locator;
  public readonly temporaryRentalCheckBoxInput: Locator;
  public readonly temporaryRentalLabel: Locator;
  public readonly centralFireAlarmMatCheckBox: Locator;
  public readonly centralFireAlarmCheckBoxInput: Locator;
  public readonly centralFireAlarmLabel: Locator;
  public readonly centralBurglarAlarmMatCheckBox: Locator;
  public readonly centralBurglarAlarmCheckBoxInput: Locator;
  public readonly centralBurglarAlarmLabel: Locator;
  public readonly localBurglarAlarmMatCheckBox: Locator;
  public readonly localBurglarAlarmCheckBoxInput: Locator;
  public readonly localBurglarAlarmLabel: Locator;
  public readonly localFireAlarmMatCheckBox: Locator;
  public readonly localFireAlarmCheckBoxInput: Locator;
  public readonly localFireAlarmLabel: Locator;

  public constructor(page: Page) {
    super(page);
    this.temporaryRentalMatCheckBox = page.locator("[data-legacy-field=\"temporaryRentalMatCheckBox\"]"); // @FindBy(xpath = TEMPORARY_RENTAL_CHECKBOX_XPATH)
    this.temporaryRentalCheckBoxInput = page.locator("[data-legacy-field=\"temporaryRentalCheckBoxInput\"]"); // @FindBy(xpath = TEMPORARY_RENTAL_CHECKBOX_XPATH + "//input")
    this.temporaryRentalLabel = page.locator("[data-legacy-field=\"temporaryRentalLabel\"]"); // @FindBy(xpath = TEMPORARY_RENTAL_CHECKBOX_XPATH + "//label")
    this.centralFireAlarmMatCheckBox = page.locator("[data-legacy-field=\"centralFireAlarmMatCheckBox\"]"); // @FindBy(xpath = CENTRAL_FIRE_CHECKBOX_XPATH)
    this.centralFireAlarmCheckBoxInput = page.locator("[data-legacy-field=\"centralFireAlarmCheckBoxInput\"]"); // @FindBy(xpath = CENTRAL_FIRE_CHECKBOX_XPATH + "//input")
    this.centralFireAlarmLabel = page.locator("[data-legacy-field=\"centralFireAlarmLabel\"]"); // @FindBy(xpath = CENTRAL_FIRE_CHECKBOX_XPATH + "//label")
    this.centralBurglarAlarmMatCheckBox = page.locator("[data-legacy-field=\"centralBurglarAlarmMatCheckBox\"]"); // @FindBy(xpath = CENTRAL_BURGLAR_CHECKBOX_XPATH)
    this.centralBurglarAlarmCheckBoxInput = page.locator("[data-legacy-field=\"centralBurglarAlarmCheckBoxInput\"]"); // @FindBy(xpath = CENTRAL_BURGLAR_CHECKBOX_XPATH + "//input")
    this.centralBurglarAlarmLabel = page.locator("[data-legacy-field=\"centralBurglarAlarmLabel\"]"); // @FindBy(xpath = CENTRAL_BURGLAR_CHECKBOX_XPATH + "//label")
    this.localBurglarAlarmMatCheckBox = page.locator("[data-legacy-field=\"localBurglarAlarmMatCheckBox\"]"); // @FindBy(xpath = LOCAL_BURGLAR_CHECKBOX_XPATH)
    this.localBurglarAlarmCheckBoxInput = page.locator("[data-legacy-field=\"localBurglarAlarmCheckBoxInput\"]"); // @FindBy(xpath = LOCAL_BURGLAR_CHECKBOX_XPATH + "//input")
    this.localBurglarAlarmLabel = page.locator("[data-legacy-field=\"localBurglarAlarmLabel\"]"); // @FindBy(xpath = LOCAL_BURGLAR_CHECKBOX_XPATH + "//label")
    this.localFireAlarmMatCheckBox = page.locator("[data-legacy-field=\"localFireAlarmMatCheckBox\"]"); // @FindBy(xpath = LOCAL_FIRE_CHECKBOX_XPATH)
    this.localFireAlarmCheckBoxInput = page.locator("[data-legacy-field=\"localFireAlarmCheckBoxInput\"]"); // @FindBy(xpath = LOCAL_FIRE_CHECKBOX_XPATH + "//input")
    this.localFireAlarmLabel = page.locator("[data-legacy-field=\"localFireAlarmLabel\"]"); // @FindBy(xpath = LOCAL_FIRE_CHECKBOX_XPATH + "//label")
  }
}
