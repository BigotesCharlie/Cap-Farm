// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.condo.AceCondoCustomCoveragePage. */
export class AceCondoCustomCoveragePage extends CoreBasePage {
  public readonly customCoverageHeading: Locator;
  public readonly customCoverageImage: Locator;
  public readonly whyHomeQualityGradeImportantInfoIcon: Locator;
  public readonly whyHomeQualityGradeImportantInfoTitle: Locator;
  public readonly whyHomeQualityGradeImportantInfoDescription: Locator;
  public readonly sideSheetInfoTitleMobile: Locator;
  public readonly sideSheetInfoDescriptionMobile: Locator;
  public readonly whyHomeQualityGradeImportantLearnMoreLink: Locator;
  public readonly whyHomeQualityGradeImportantLearnMoreLinkMobile: Locator;
  public readonly mainCoveragesTitle: Locator;
  public readonly personalPropertyValueHeader: Locator;
  public readonly buildingInteriorValueHeader: Locator;
  public readonly personalPropertyValue: Locator;
  public readonly buildingInteriorValue: Locator;
  public readonly replacementCostValueANdHomeQualityGradeSubText: Locator;
  public readonly homeQualityGrade: Locator;
  public readonly mainCoverageSubText: Locator;
  public readonly buildingInteriorInfoIcon: Locator;
  public readonly buildingInteriorInfoTitle: Locator;
  public readonly buildingInteriorInfoText: Locator;
  public readonly editCoveragesLink: Locator;
  public readonly matDivider: Locator;
  public readonly coveragesAndGradeHeader: Locator;
  public readonly closeIconInCoveragesAndGradeSheet: Locator;
  public readonly personalPropertyValueHeaderInSideSheet: Locator;
  public readonly personalPropertyValueExplanation: Locator;
  public readonly personalPropertyValueInputField: Locator;
  public readonly personalPropertyValueAriaLabel: Locator;
  public readonly personalPropertyValueHint: Locator;
  public readonly helpMeCalculateThisLink: Locator;
  public readonly nextButton: Locator;
  public readonly buildingInteriorLabel: Locator;
  public readonly trackerCirclesOnSideSheet: Locator;
  public readonly activeCircleOnOnSideSheet: Locator;
  public readonly buildingInteriorTitleOnSideSheet: Locator;
  public readonly buildingInteriorDescriptionInSideSheet: Locator;
  public readonly buildingInteriorInputBox: Locator;
  public readonly buildingInteriorAriaLabel: Locator;
  public readonly buildingInteriorLimitHint: Locator;
  public readonly buildingInteriorDottedDivider: Locator;
  public readonly standardHomeQualityGradeTitleCondo: Locator;
  public readonly standardHomeQualityGradeInfoIconCondo: Locator;
  public readonly standardHomeQualityGradeSubTextCondo: Locator;
  public readonly editYourQualityGradeLinkCondo: Locator;
  public readonly doneButtonCondo: Locator;
  public readonly closeIconWhyIsMyHomeQualityGradeImportantSideSheetCondo: Locator;
  public readonly coveragesAndGradeSideSheetCondo: Locator;
  public readonly coverageNeededWithinRangeError: Locator;
  public readonly personalPropertyCalculatorHeader: Locator;
  public readonly personalPropertyCalculatorCloseIcon: Locator;
  public readonly personalPropertyCalculatorDescription: Locator;
  public readonly personalPropertyCategoriesWebElements: Locator;
  public readonly personalPropertySliders: Locator;
  public readonly personalPropertyGrowthHeader: Locator;
  public readonly personalPropertyGrowthAmount: Locator;
  public readonly minimumAmountOfCoverageValue: Locator;
  public readonly useThisValueButton: Locator;
  public readonly mainContentInfoMobile: Locator;
  public readonly interiorValueInfoMobile: Locator;
  public readonly closeSidesheetButtonMobile: Locator;

  public constructor(page: Page) {
    super(page);
    this.customCoverageHeading = page.locator("xpath=//div[@class='condo-coverage__container']//h1"); // @FindBy(xpath = "//div[@class='condo-coverage__container']//h1")
    this.customCoverageImage = page.locator("xpath=//div[contains(@class,'coverage__main-image-section')]//div//img"); // @FindBy(xpath = "//div[contains(@class,'coverage__main-image-section')]//div//img")
    this.whyHomeQualityGradeImportantInfoIcon = page.locator("xpath=//div[contains(@class,'coverage__main-image-section')]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'coverage__main-image-section')]//mat-icon")
    this.whyHomeQualityGradeImportantInfoTitle = page.locator("xpath=//div[contains(@class,'coverage__main-image-section')]//p"); // @FindBy(xpath = "//div[contains(@class,'coverage__main-image-section')]//p")
    this.whyHomeQualityGradeImportantInfoDescription = page.locator("xpath=//div[contains(@class,'tui-info-box-content')]/span[1]"); // @FindBy(xpath = "//div[contains(@class,'tui-info-box-content')]/span[1]")
    this.sideSheetInfoTitleMobile = page.locator("xpath=//mat-dialog-container//h1"); // @FindBy(xpath = "//mat-dialog-container//h1")
    this.sideSheetInfoDescriptionMobile = page.locator("xpath=//mat-dialog-container//p"); // @FindBy(xpath = "//mat-dialog-container//p")
    this.whyHomeQualityGradeImportantLearnMoreLink = page.locator("xpath=//div[contains(@class,'tui-info-box-content')]//span[contains(@class,'tui-link-button')]"); // @FindBy(xpath = "//div[contains(@class,'tui-info-box-content')]//span[contains(@class,'tui-link-button')]")
    this.whyHomeQualityGradeImportantLearnMoreLinkMobile = page.locator("xpath=//mat-dialog-container//span[contains(@class,'tui-link-button')]"); // @FindBy(xpath = "//mat-dialog-container//span[contains(@class,'tui-link-button')]")
    this.mainCoveragesTitle = page.locator("xpath=//div[contains(@class,'coverage__main-content-subsection')]"); // @FindBy(xpath = "//div[contains(@class,'coverage__main-content-subsection')]")
    this.personalPropertyValueHeader = page.locator("xpath=//div[contains(@class,'coverage__value-section')]//div[contains(@class,'tui-body-text-bold')][1]"); // @FindBy(xpath = "//div[contains(@class,'coverage__value-section')]//div[contains(@class,'tui-body-text-bold')][1]")
    this.buildingInteriorValueHeader = page.locator("xpath=//div[contains(@class,'coverage__value-section')]//div[contains(@class,'tui-body-text-bold')]//span[1]"); // @FindBy(xpath = "//div[contains(@class,'coverage__value-section')]//div[contains(@class,'tui-body-text-bold')]//span[1]")
    this.personalPropertyValue = page.locator("xpath=//div[contains(@class,'coverage__value-section')]//div[contains(text(),'Personal property value')]/following-sibling::div[contains(@class,'tui-h2')]"); // @FindBy(xpath = "//div[contains(@class,'coverage__value-section')]//div[contains(text(),'Personal property value')]/following-sibling::div[contains(@class,'tui-h2')]")
    this.buildingInteriorValue = page.locator("xpath=//div[contains(@class,'coverage__value-subsection')]/following-sibling::div"); // @FindBy(xpath = "//div[contains(@class,'coverage__value-subsection')]/following-sibling::div")
    this.replacementCostValueANdHomeQualityGradeSubText = page.locator("xpath=//div[contains(@class,'coverage__value-section')]//div[contains(@class,'subtext')]"); // @FindBy(xpath = "//div[contains(@class,'coverage__value-section')]//div[contains(@class,'subtext')]")
    this.homeQualityGrade = page.locator("xpath=//div[contains(@class,'coverage__value-subsection')]/following-sibling::div[2]"); // @FindBy(xpath = "//div[contains(@class,'coverage__value-subsection')]/following-sibling::div[2]")
    this.mainCoverageSubText = page.locator("xpath=//div[contains(@class,'coverage__main-content-section')]//span[2]"); // @FindBy(xpath = "//div[contains(@class,'coverage__main-content-section')]//span[2]") //    private WebElement homeQualityGradeText;     @FindBy(xpath = "//div[contains(@class,'coverage__main-content-section')]/div/p")
    this.buildingInteriorInfoIcon = page.locator("xpath=//div[contains(@class,'coverage__main-content-section')]/div[2]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'coverage__main-content-section')]/div[2]//mat-icon")
    this.buildingInteriorInfoTitle = page.locator("xpath=//div[contains(@class,'coverage__main-content-section')]/div[2]//p[1]"); // @FindBy(xpath = "//div[contains(@class,'coverage__main-content-section')]/div[2]//p[1]")
    this.buildingInteriorInfoText = page.locator("xpath=//div[contains(@class,'coverage__main-content-section')]/div[2]//p[2]"); // @FindBy(xpath = "//div[contains(@class,'coverage__main-content-section')]/div[2]//p[2]")
    this.editCoveragesLink = page.locator("xpath=//div[contains(@class,'editcoverage_link')]//button"); // @FindBy(xpath = "//div[contains(@class,'editcoverage_link')]//button")
    this.matDivider = page.locator("xpath=//mat-divider"); // @FindBy(xpath = "//mat-divider")
    this.coveragesAndGradeHeader = page.locator("xpath=//app-edit-coverage-grade//h4"); // @FindBy(xpath = "//app-edit-coverage-grade//h4")
    this.closeIconInCoveragesAndGradeSheet = page.locator("xpath=//div[contains(@class,'sidesheet-close-hit-area')]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'sidesheet-close-hit-area')]//mat-icon")
    this.personalPropertyValueHeaderInSideSheet = page.locator("xpath=//div[@id='personal-property-section-title']//p"); // @FindBy(xpath = "//div[@id='personal-property-section-title']//p")
    this.personalPropertyValueExplanation = page.locator("xpath=//div[contains(@class,'personal-property-input')]//p"); // @FindBy(xpath = "//div[contains(@class,'personal-property-input')]//p")
    this.personalPropertyValueInputField = page.locator("xpath=//div[contains(@class,'personal-property-input')]//input"); // @FindBy(xpath = "//div[contains(@class,'personal-property-input')]//input")
    this.personalPropertyValueAriaLabel = page.locator("xpath=//div[contains(@class,'personal-property-input')]//mat-label"); // @FindBy(xpath = "//div[contains(@class,'personal-property-input')]//mat-label")
    this.personalPropertyValueHint = page.locator("xpath=//div[contains(@class,'personal-property-input')]//mat-hint"); // @FindBy(xpath = "//div[contains(@class,'personal-property-input')]//mat-hint")
    this.helpMeCalculateThisLink = page.locator("xpath=//mat-expansion-panel//a"); // @FindBy(xpath = "//mat-expansion-panel//a")
    this.nextButton = page.locator("xpath=//button[contains(@class,'property-next-button')]"); // @FindBy(xpath = "//button[contains(@class,'property-next-button')]")
    this.buildingInteriorLabel = page.locator("xpath=//div[@id='interior-and-quality-section-title']//p"); // @FindBy(xpath = "//div[@id='interior-and-quality-section-title']//p")
    this.trackerCirclesOnSideSheet = page.locator("xpath=//div[contains(@class,'circle')]"); // @FindBy(xpath = "//div[contains(@class,'circle')]")
    this.activeCircleOnOnSideSheet = page.locator("xpath=//div[contains(@class,'circle-active')]"); // @FindBy(xpath = "//div[contains(@class,'circle-active')]")
    this.buildingInteriorTitleOnSideSheet = page.locator("#interior-and-quality-section-title"); // @FindBy(id = "interior-and-quality-section-title")
    this.buildingInteriorDescriptionInSideSheet = page.locator("xpath=//div[contains(@class,'description-section')]//p"); // @FindBy(xpath = "//div[contains(@class,'description-section')]//p")
    this.buildingInteriorInputBox = page.locator("xpath=//div[contains(@class,'text-box-section')]//input"); // @FindBy(xpath = "//div[contains(@class,'text-box-section')]//input")
    this.buildingInteriorAriaLabel = page.locator("xpath=//div[contains(@class,'text-box-section')]//mat-label"); // @FindBy(xpath = "//div[contains(@class,'text-box-section')]//mat-label")
    this.buildingInteriorLimitHint = page.locator("xpath=//div[contains(@class,'text-box-section')]//mat-hint"); // @FindBy(xpath = "//div[contains(@class,'text-box-section')]//mat-hint")
    this.buildingInteriorDottedDivider = page.locator("xpath=//div[contains(@class,'building-interior-divider')]"); // @FindBy(xpath = "//div[contains(@class,'building-interior-divider')]")
    this.standardHomeQualityGradeTitleCondo = page.locator("xpath=//span[contains(@class,'quality-grade-title-section')]"); // @FindBy(xpath = "//span[contains(@class,'quality-grade-title-section')]")
    this.standardHomeQualityGradeInfoIconCondo = page.locator("xpath=//div[contains(@class,'home-quality-subheading')]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'home-quality-subheading')]//mat-icon")
    this.standardHomeQualityGradeSubTextCondo = page.locator("xpath=//div[contains(@class,'quality-grade-description-section')]//span[1]"); // @FindBy(xpath = "//div[contains(@class,'quality-grade-description-section')]//span[1]")
    this.editYourQualityGradeLinkCondo = page.locator("xpath=//div[contains(@class,'quality-grade-description-section')]//span[@class='tui-link-button']"); // @FindBy(xpath = "//div[contains(@class,'quality-grade-description-section')]//span[@class='tui-link-button']")
    this.doneButtonCondo = page.locator("xpath=//div[contains(@class,'page-submit-section')]//button"); // @FindBy(xpath = "//div[contains(@class,'page-submit-section')]//button")
    this.closeIconWhyIsMyHomeQualityGradeImportantSideSheetCondo = page.locator("xpath=//app-model-info-box//mat-icon[text() = 'close']"); // @FindBy(xpath = "//app-model-info-box//mat-icon[text() = 'close']")
    this.coveragesAndGradeSideSheetCondo = page.locator("xpath=//app-edit-coverage-grade"); // @FindBy(xpath = "//app-edit-coverage-grade")
    this.coverageNeededWithinRangeError = page.locator("xpath=//mat-error//span"); // @FindBy(xpath = "//mat-error//span")
    this.personalPropertyCalculatorHeader = page.locator("xpath=//app-personal-property-calculator//h4"); // @FindBy(xpath = "//app-personal-property-calculator//h4")
    this.personalPropertyCalculatorCloseIcon = page.locator("xpath=//app-personal-property-calculator//h4"); // @FindBy(xpath = "//app-personal-property-calculator//h4")
    this.personalPropertyCalculatorDescription = page.locator("xpath=//app-personal-property-calculator/div/div[2]/p"); // @FindBy(xpath = "//app-personal-property-calculator/div/div[2]/p")
    this.personalPropertyCategoriesWebElements = page.locator("xpath=//app-personal-property-calculator/div/div[2]/div"); // @FindBy(xpath = "//app-personal-property-calculator/div/div[2]/div")
    this.personalPropertySliders = page.locator("xpath=//app-personal-property-calculator/div/div[2]//mat-slider//input"); // @FindBy(xpath = "//app-personal-property-calculator/div/div[2]//mat-slider//input")
    this.personalPropertyGrowthHeader = page.locator("xpath=//app-personal-property-calculator/div/div[2]/div[6]//p[1]"); // @FindBy(xpath = "//app-personal-property-calculator/div/div[2]/div[6]//p[1]")
    this.personalPropertyGrowthAmount = page.locator("xpath=//app-personal-property-calculator/div/div[2]/div[6]//p[2]"); // @FindBy(xpath = "//app-personal-property-calculator/div/div[2]/div[6]//p[2]")
    this.minimumAmountOfCoverageValue = page.locator("xpath=//app-personal-property-calculator/div/div[2]/div[6]//p[3]"); // @FindBy(xpath = "//app-personal-property-calculator/div/div[2]/div[6]//p[3]")
    this.useThisValueButton = page.locator("xpath=//app-personal-property-calculator//button"); // @FindBy(xpath = "//app-personal-property-calculator//button")
    this.mainContentInfoMobile = page.locator("xpath=//div[contains(@class,'coverage__main-content-section')]//mat-icon[text()='info']"); // @FindBy(xpath = "//div[contains(@class,'coverage__main-content-section')]//mat-icon[text()='info']")
    this.interiorValueInfoMobile = page.locator("xpath=//div[contains(@class,'coverage__value-section')]//mat-icon[text()='info']"); // @FindBy(xpath = "//div[contains(@class,'coverage__value-section')]//mat-icon[text()='info']")
    this.closeSidesheetButtonMobile = page.locator("xpath=//mat-icon[text()='close']"); // @FindBy(xpath = "//mat-icon[text()='close']")
  }
}
