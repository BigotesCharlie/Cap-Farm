// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.bundle.AceBundleFinalReviewPage. */
export class AceBundleFinalReviewPage extends CoreBasePage {
  public readonly finalReviewPageTitleElement: Locator;
  public readonly finalReviewPageSubtitleElement: Locator;
  public readonly finalReviewPageSummaryTitleElement: Locator;
  public readonly listOfBundleSummaryTermLabels: Locator;
  public readonly editAutoCoveragesLink: Locator;
  public readonly editAutoCoveragesPencilIcon: Locator;
  public readonly editHomeCoveragesLink: Locator;
  public readonly editHomeCoveragesPencilIcon: Locator;
  public readonly editRentersCoveragesLink: Locator;
  public readonly editRentersCoveragesPencilIcon: Locator;
  public readonly continueToPaymentButton: Locator;
  public readonly bristolWestLogo: Locator;

  public constructor(page: Page) {
    super(page);
    this.finalReviewPageTitleElement = page.locator("xpath=//div[contains(@class,'final-bundle-header')]//h1"); // @FindBy(xpath = "//div[contains(@class,'final-bundle-header')]//h1")
    this.finalReviewPageSubtitleElement = page.locator("xpath=//div[contains(@class,'final-bundle-header')]/p"); // @FindBy(xpath = "//div[contains(@class,'final-bundle-header')]/p")
    this.finalReviewPageSummaryTitleElement = page.locator("xpath=//app-final-bundle-page//div[contains(@class, 'box ')]/span"); // @FindBy(xpath = "//app-final-bundle-page//div[contains(@class, 'box ')]/span")
    this.listOfBundleSummaryTermLabels = page.locator("xpath=//div[@class='tui-stacking-bottom-xs'][2]"); // @FindBy(xpath = "//div[@class='tui-stacking-bottom-xs'][2]")
    this.editAutoCoveragesLink = page.locator("xpath=//button//span[contains(text(), 'Edit auto coverages')]"); // @FindBy(xpath = "//button//span[contains(text(), 'Edit auto coverages')]")
    this.editAutoCoveragesPencilIcon = page.locator("xpath=//button//span[contains(text(), 'Edit auto coverages')]//mat-icon"); // @FindBy(xpath = "//button//span[contains(text(), 'Edit auto coverages')]//mat-icon")
    this.editHomeCoveragesLink = page.locator("xpath=//button//span[contains(text(), 'Edit home coverages')]"); // @FindBy(xpath = "//button//span[contains(text(), 'Edit home coverages')]")
    this.editHomeCoveragesPencilIcon = page.locator("xpath=//button//span[contains(text(), 'Edit home coverages')]//mat-icon"); // @FindBy(xpath = "//button//span[contains(text(), 'Edit home coverages')]//mat-icon")
    this.editRentersCoveragesLink = page.locator("xpath=//button//span[contains(text(), 'Edit renters coverages')]"); // @FindBy(xpath = "//button//span[contains(text(), 'Edit renters coverages')]")
    this.editRentersCoveragesPencilIcon = page.locator("xpath=//button//span[contains(text(), 'Edit renters coverages')]//mat-icon"); // @FindBy(xpath = "//button//span[contains(text(), 'Edit renters coverages')]//mat-icon")
    this.continueToPaymentButton = page.locator("xpath=//app-final-bundle-page//div[contains(@class,'final-bundle-continue')]//button"); // @FindBy(xpath = "//app-final-bundle-page//div[contains(@class,'final-bundle-continue')]//button")
    this.bristolWestLogo = page.locator("xpath=//img[contains(@alt, 'Bristol West')]"); // @FindBy(xpath = "//img[contains(@alt, 'Bristol West')]")
  }
}
