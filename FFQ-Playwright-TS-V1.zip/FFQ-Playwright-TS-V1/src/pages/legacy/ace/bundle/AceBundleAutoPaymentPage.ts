// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.bundle.AceBundleAutoPaymentPage. */
export class AceBundleAutoPaymentPage extends CoreBasePage {
  public readonly autoPaymentPageTitle: Locator;
  public readonly bankPreferedPaymentRadioButton: Locator;
  public readonly cardPreferedPaymentRadioButton: Locator;
  public readonly completeAutoPurchaseButton: Locator;
  public readonly autoPaymentPageBWIcon: Locator;
  public readonly autoPaymentPageBWLabel: Locator;
  public readonly listOfTabsForAvailablePaymentPlans: Locator;
  public readonly selectAndSignDocumentsPayInFullButton: Locator;
  public readonly selectAndSignDocumentsMonthlyBankButton: Locator;
  public readonly selectAndSignDocumentsMonthlyCardButton: Locator;
  public readonly selectAndSignDocumentsMonthlyDirectButton: Locator;
  public readonly activeSelectAndSignDocumentsButton: Locator;
  public readonly bwSetupPaymentButton: Locator;
  public readonly ersdDialog: Locator;
  public readonly agreeToUseERSDCheckbox: Locator;
  public readonly ersdDialogContinueButton: Locator;
  public readonly docusignDocument: Locator;
  public readonly listOfInitialHereLocations: Locator;
  public readonly listOfSignHereLocations: Locator;
  public readonly adoptSignatureDialog: Locator;
  public readonly adoptAndInitialButton: Locator;
  public readonly finishDocusignButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.autoPaymentPageTitle = page.locator("xpath=//h1[contains(@class, 'payment-overview-header-text')]"); // @FindBy(xpath = "//h1[contains(@class, 'payment-overview-header-text')]")
    this.bankPreferedPaymentRadioButton = page.locator("xpath=//input[@value='bank']"); // @FindBy(xpath = "//input[@value='bank']")
    this.cardPreferedPaymentRadioButton = page.locator("xpath=//input[@value='card']"); // @FindBy(xpath = "//input[@value='card']")
    this.completeAutoPurchaseButton = page.locator("xpath=//button[contains(@class, '-purchase-btn-bundle')]"); // @FindBy(xpath = "//button[contains(@class, '-purchase-btn-bundle')]")
    this.autoPaymentPageBWIcon = page.locator("xpath=//div[contains(@class, 'bristol-west-bundle-icon')]//img"); // @FindBy(xpath = "//div[contains(@class, 'bristol-west-bundle-icon')]//img")
    this.autoPaymentPageBWLabel = page.locator("xpath=//div[contains(@class, 'bristol-west-bundle-body')]"); // @FindBy(xpath = "//div[contains(@class, 'bristol-west-bundle-body')]")
    this.listOfTabsForAvailablePaymentPlans = page.locator("xpath=//div[contains(@class, 'mat-tab-label')][@role='tab']"); // @FindBy(xpath = "//div[contains(@class, 'mat-tab-label')][@role='tab']")
    this.selectAndSignDocumentsPayInFullButton = page.locator("xpath=//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Pay in full')]"); // @FindBy(xpath = "//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Pay in full')]")
    this.selectAndSignDocumentsMonthlyBankButton = page.locator("xpath=//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly autopay bank')]"); // @FindBy(xpath = "//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly autopay bank')]")
    this.selectAndSignDocumentsMonthlyCardButton = page.locator("xpath=//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly autopay card')]"); // @FindBy(xpath = "//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly autopay card')]")
    this.selectAndSignDocumentsMonthlyDirectButton = page.locator("xpath=//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly direct')]"); // @FindBy(xpath = "//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly direct')]")
    this.activeSelectAndSignDocumentsButton = page.locator("xpath=//mat-tab-body//button"); // @FindBy(xpath = "//mat-tab-body//button")
    this.bwSetupPaymentButton = page.locator("xpath=//button[contains(@class, 'tui-btn')]"); // @FindBy(xpath = "//button[contains(@class, 'tui-btn')]")
    this.ersdDialog = page.locator("xpath=//div[@data-qa='ersd-modal-content']"); // @FindBy(xpath = "//div[@data-qa='ersd-modal-content']")
    this.agreeToUseERSDCheckbox = page.locator("xpath=//input[@data-qa='ersd-agree-checkbox']"); // @FindBy(xpath = "//input[@data-qa='ersd-agree-checkbox']")
    this.ersdDialogContinueButton = page.locator("xpath=//button[@data-qa='ersd-modal-agree']"); // @FindBy(xpath = "//button[@data-qa='ersd-modal-agree']")
    this.docusignDocument = page.locator("#oneds-title"); // @FindBy(id = "oneds-title")
    this.listOfInitialHereLocations = page.locator("xpath=//button[contains(@data-qa,'initials-tab-required') and @aria-invalid='true']"); // @FindBy(xpath = "//button[contains(@data-qa,'initials-tab-required') and @aria-invalid='true']")
    this.listOfSignHereLocations = page.locator("xpath=//button[contains(@data-qa,'signature-tab-required') and @aria-invalid='true']"); // @FindBy(xpath = "//button[contains(@data-qa,'signature-tab-required') and @aria-invalid='true']")
    this.adoptSignatureDialog = page.locator("xpath=//div[@data-qa='adopt-signature-modal-content']"); // @FindBy(xpath = "//div[@data-qa='adopt-signature-modal-content']")
    this.adoptAndInitialButton = page.locator("xpath=//button[@data-qa='adopt-submit']"); // @FindBy(xpath = "//button[@data-qa='adopt-submit']")
    this.finishDocusignButton = page.locator("xpath=//button[contains(@data-qa,'action-bar-btn-finish')]"); // @FindBy(xpath = "//button[contains(@data-qa,'action-bar-btn-finish')]")
  }
}
