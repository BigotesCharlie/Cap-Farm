// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.bundle.AceBundleReviewQuotesPage. */
export class AceBundleReviewQuotesPage extends CoreBasePage {
  public readonly bundleReviewQuotesPageTitle: Locator;
  public readonly bundleReviewQuotesPageSubtitle: Locator;
  public readonly bundleReviewQuotePageSummaryHeader: Locator;
  public readonly monthlyAutopayColumnTitle: Locator;
  public readonly payInFullColumnTitle: Locator;
  public readonly listOfBundleLOBs: Locator;
  public readonly listOfBundleMonthlyCost: Locator;
  public readonly listOfBundlePayInFullCost: Locator;
  public readonly upToSavingsLabel: Locator;
  public readonly listOfBundleSummarySectionTitles: Locator;
  public readonly listOfProviderDescriptionLabels: Locator;
  public readonly listOfProviderLogos: Locator;
  public readonly listOfBundleSummaryTermLabels: Locator;
  public readonly listOfBundleSummaryDescriptionLabels: Locator;
  public readonly listOfLOBDiscountsLinks: Locator;
  public readonly listOfQuoteReviewEditUpdateButtons: Locator;
  public readonly paymentFlexibilityLabel: Locator;
  public readonly continueToNextPageButton: Locator;
  public readonly changePoliciesDialogTitle: Locator;
  public readonly changePolicyDialogSubtitle: Locator;
  public readonly autoPolicyMonolineLabel: Locator;
  public readonly propertyPolicyMonolineLabel: Locator;
  public readonly keepBundleLabel: Locator;
  public readonly changePoliciesDialogContinueButton: Locator;
  public readonly discountsSideSheetAppliedText: Locator;
  public readonly discountsNameInSideSheet: Locator;
  public readonly closeIconDiscountsSideSheet: Locator;
  public readonly savingsAppliedWhenBundleText: Locator;
  public readonly emailLink: Locator;
  public readonly linkCloseEmailSnackBar: Locator;
  public readonly wantOneOfThePoliciesLink: Locator;
  public readonly changePoliciesHeaderInCPPopUpModal: Locator;
  public readonly changePoliciesContentInCPPopUpModal: Locator;
  public readonly pleaseSelectOneHeaderInCPPopUpModal: Locator;
  public readonly policyOptionsRadioButtonsInCPPopUpModal: Locator;
  public readonly policyOptionsLabelsInCPPopUpModal: Locator;
  public readonly discountAmountInCPPopUpModal: Locator;
  public readonly continueButtonInCPPopUpModal: Locator;
  public readonly bWLogoAndDescriptionSectionOnAutoPage: Locator;
  public readonly bWLogoOnAutoPage: Locator;
  public readonly bWDescriptionOnAutoPage: Locator;
  public readonly thankYouTitleForBindDisabledBundle: Locator;
  public readonly thankYouSubTitleForBindDisabledBundle: Locator;
  public readonly nextReviewAutoCoveragesButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.bundleReviewQuotesPageTitle = page.locator("xpath=//div[@class='bundle-quote-review']//h1"); // @FindBy(xpath = "//div[@class='bundle-quote-review']//h1")
    this.bundleReviewQuotesPageSubtitle = page.locator("xpath=//div[contains(@class,'bundle-quote-header')]//p[@class='tui-input-text']"); // @FindBy(xpath = "//div[contains(@class,'bundle-quote-header')]//p[@class='tui-input-text']")
    this.bundleReviewQuotePageSummaryHeader = page.locator("xpath=//div[contains(@class,'bundle-quote-review')]//div[contains(@class, 'box ')]/span"); // @FindBy(xpath = "//div[contains(@class,'bundle-quote-review')]//div[contains(@class, 'box ')]/span")
    this.monthlyAutopayColumnTitle = page.locator("xpath=//thead//th[contains(@class, 'monthlyAutopay')]"); // @FindBy(xpath = "//thead//th[contains(@class, 'monthlyAutopay')]")
    this.payInFullColumnTitle = page.locator("xpath=//thead//th[contains(@class, 'payInFull')]"); // @FindBy(xpath = "//thead//th[contains(@class, 'payInFull')]")
    this.listOfBundleLOBs = page.locator("xpath=//tbody//td[contains(@class, 'column-lob')]"); // @FindBy(xpath = "//tbody//td[contains(@class, 'column-lob')]")
    this.listOfBundleMonthlyCost = page.locator("xpath=//tbody//td[contains(@class, 'column-monthly')]"); // @FindBy(xpath = "//tbody//td[contains(@class, 'column-monthly')]")
    this.listOfBundlePayInFullCost = page.locator("xpath=//tbody//td[contains(@class, 'column-pay')]"); // @FindBy(xpath = "//tbody//td[contains(@class, 'column-pay')]")
    this.upToSavingsLabel = page.locator("xpath=//div[contains(@class, 'bundle-savings')]"); // @FindBy(xpath = "//div[contains(@class, 'bundle-savings')]")
    this.listOfBundleSummarySectionTitles = page.locator(".bundle-lob-summary"); // @FindBy(className = "bundle-lob-summary")
    this.listOfProviderDescriptionLabels = page.locator("[data-legacy-field=\"listOfProviderDescriptionLabels\"]"); // @FindBy(xpath = USING_BW_AUTO_XPATH + "/span")
    this.listOfProviderLogos = page.locator("[data-legacy-field=\"listOfProviderLogos\"]"); // @FindBy(xpath = USING_BW_AUTO_XPATH + "/img")
    this.listOfBundleSummaryTermLabels = page.locator("xpath=//div[@class='tui-stacking-bottom-xs']"); // @FindBy(xpath = "//div[@class='tui-stacking-bottom-xs']")
    this.listOfBundleSummaryDescriptionLabels = page.locator("xpath=//div[@class='tui-stacking-bottom-sm']"); // @FindBy(xpath = "//div[@class='tui-stacking-bottom-sm']")
    this.listOfLOBDiscountsLinks = page.locator("xpath=//div[contains(@class, 'lob-discounts')]/a"); // @FindBy(xpath = "//div[contains(@class, 'lob-discounts')]/a")
    this.listOfQuoteReviewEditUpdateButtons = page.locator("xpath=//div[contains(@class, 'cta-container')]/button"); // @FindBy(xpath = "//div[contains(@class, 'cta-container')]/button")
    this.paymentFlexibilityLabel = page.locator(".payment-flexibility-info"); // @FindBy(className = "payment-flexibility-info")
    this.continueToNextPageButton = page.locator("xpath=//button[contains(@class, 'bundle-quote-button') and (contains(text(), 'auto coverages') or contains(text(), 'final wrap'))]"); // @FindBy(xpath = "//button[contains(@class, 'bundle-quote-button') and (contains(text(), 'auto coverages') or contains(text(), 'final wrap'))]")
    this.changePoliciesDialogTitle = page.locator("xpath=//*[@role='heading']"); // @FindBy(xpath = "//*[@role='heading']")
    this.changePolicyDialogSubtitle = page.locator("#onePolicyContent"); // @FindBy(id = "onePolicyContent")
    this.autoPolicyMonolineLabel = page.locator("[data-legacy-field=\"autoPolicyMonolineLabel\"]"); // @FindBy(xpath = AUTO_MONOLINE_XPATH)
    this.propertyPolicyMonolineLabel = page.locator("[data-legacy-field=\"propertyPolicyMonolineLabel\"]"); // @FindBy(xpath = PROPERTY_MONOLINE_XPATH)
    this.keepBundleLabel = page.locator("[data-legacy-field=\"keepBundleLabel\"]"); // @FindBy(xpath = KEEP_BUNDLE_XPATH)
    this.changePoliciesDialogContinueButton = page.locator("xpath=//app-one-policy-popup//button"); // @FindBy(xpath = "//app-one-policy-popup//button")
    this.discountsSideSheetAppliedText = page.locator("xpath=//div[@id='appliedDiscounts']"); // @FindBy(xpath = "//div[@id='appliedDiscounts']")
    this.discountsNameInSideSheet = page.locator("xpath=//div/span[contains(@class,'discount-name')]"); // @FindBy(xpath = "//div/span[contains(@class,'discount-name')]")
    this.closeIconDiscountsSideSheet = page.locator("xpath=//app-auto-discount-sidesheet//mat-icon[text()='close']"); // @FindBy(xpath = "//app-auto-discount-sidesheet//mat-icon[text()='close']")
    this.savingsAppliedWhenBundleText = page.locator("xpath=//div[contains(@class, 'bundle-savings')]"); // @FindBy(xpath = "//div[contains(@class, 'bundle-savings')]")
    this.emailLink = page.locator("xpath=//a[contains(@class,'email_Quote_CTA')]"); // @FindBy(xpath = "//a[contains(@class,'email_Quote_CTA')]")
    this.linkCloseEmailSnackBar = page.getByRole('link', { name: "Done", exact: true }); // @FindBy(linkText = "Done")
    this.wantOneOfThePoliciesLink = page.locator("xpath=//a[contains(@class, 'bundle-one-popup-link')]"); // @FindBy(xpath = "//a[contains(@class, 'bundle-one-popup-link')]")
    this.changePoliciesHeaderInCPPopUpModal = page.locator("#onePolicyHeading"); // @FindBy(id = "onePolicyHeading")
    this.changePoliciesContentInCPPopUpModal = page.locator("xpath=//div[contains(@class, 'onePolicy-popup-content')]"); // @FindBy(xpath = "//div[contains(@class, 'onePolicy-popup-content')]")
    this.pleaseSelectOneHeaderInCPPopUpModal = page.locator("xpath=//div[contains(text(), 'Please select one:')]"); // @FindBy(xpath = "//div[contains(text(), 'Please select one:')]")
    this.policyOptionsRadioButtonsInCPPopUpModal = page.locator("xpath=//mat-radio-group[contains(@class, 'bundle-radio-group')]//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[contains(@class, 'bundle-radio-group')]//mat-radio-button")
    this.policyOptionsLabelsInCPPopUpModal = page.locator("xpath=//mat-radio-group[contains(@class, 'bundle-radio-group')]//mat-radio-button//label"); // @FindBy(xpath = "//mat-radio-group[contains(@class, 'bundle-radio-group')]//mat-radio-button//label")
    this.discountAmountInCPPopUpModal = page.locator("xpath=//mat-radio-group[contains(@class, 'bundle-radio-group')]//p"); // @FindBy(xpath = "//mat-radio-group[contains(@class, 'bundle-radio-group')]//p")
    this.continueButtonInCPPopUpModal = page.locator("xpath=//app-one-policy-popup//button"); // @FindBy(xpath = "//app-one-policy-popup//button")
    this.bWLogoAndDescriptionSectionOnAutoPage = page.locator("xpath=//*[@appbristolwestbundle]"); // @FindBy(xpath = "//*[@appbristolwestbundle]")
    this.bWLogoOnAutoPage = page.locator("xpath=//*[@appbristolwestbundle]//img[contains(@class, 'bristol-west-bundle-icon-auto')]"); // @FindBy(xpath = "//*[@appbristolwestbundle]//img[contains(@class, 'bristol-west-bundle-icon-auto')]")
    this.bWDescriptionOnAutoPage = page.locator("xpath=//*[@appbristolwestbundle]//div[contains(@class, 'bristol-west-bundle-icon bristol-west-bundle-body')]//p"); // @FindBy(xpath = "//*[@appbristolwestbundle]//div[contains(@class, 'bristol-west-bundle-icon bristol-west-bundle-body')]//p")
    this.thankYouTitleForBindDisabledBundle = page.locator("xpath=//div[contains(@class, 'thank-you__title')]//h1"); // @FindBy(xpath = "//div[contains(@class, 'thank-you__title')]//h1")
    this.thankYouSubTitleForBindDisabledBundle = page.locator("xpath=//div[contains(@class, 'thank-you__subtitle')]//p"); // @FindBy(xpath = "//div[contains(@class, 'thank-you__subtitle')]//p")
    this.nextReviewAutoCoveragesButton = page.locator("button[class='bundle-quote-button tui-btn tui-btn-primary']"); // @FindBy(css = "button[class='bundle-quote-button tui-btn tui-btn-primary']")
  }
}
