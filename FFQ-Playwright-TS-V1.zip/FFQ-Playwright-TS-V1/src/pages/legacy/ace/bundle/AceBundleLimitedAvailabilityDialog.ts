// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.bundle.AceBundleLimitedAvailabilityDialog. */
export class AceBundleLimitedAvailabilityDialog extends CoreBasePage {
  public readonly dialogTitle: Locator;
  public readonly dialogTextContent: Locator;
  public readonly selectOnePolicyLabel: Locator;
  public readonly autoPolicyRadioButton: Locator;
  public readonly hrcPolicyRadioButton: Locator;
  public readonly neitherRadioButton: Locator;
  public readonly speakToRepresentativeLabel: Locator;
  public readonly continueButton: Locator;
  public readonly yesContinueButton: Locator;
  public readonly noThankYouLink: Locator;

  public constructor(page: Page) {
    super(page);
    this.dialogTitle = page.locator("xpath=//*[contains(@class, 'monoline_popup_heading')]"); // @FindBy(xpath = "//*[contains(@class, 'monoline_popup_heading')]")
    this.dialogTextContent = page.locator("#monolineContent"); // @FindBy(id = "monolineContent")
    this.selectOnePolicyLabel = page.locator("xpath=//div[@class='font-weight-bold']"); // @FindBy(xpath = "//div[@class='font-weight-bold']")
    this.autoPolicyRadioButton = page.locator("xpath=//mat-radio-button[@value = 'auto']"); // @FindBy(xpath = "//mat-radio-button[@value = 'auto']")
    this.hrcPolicyRadioButton = page.locator("xpath=//mat-radio-button[not(@value)]"); // @FindBy(xpath = "//mat-radio-button[not(@value)]")
    this.neitherRadioButton = page.locator("xpath=//mat-radio-button[@value = 'cancel']"); // @FindBy(xpath = "//mat-radio-button[@value = 'cancel']")
    this.speakToRepresentativeLabel = page.locator("xpath=//mat-radio-group//p"); // @FindBy(xpath = "//mat-radio-group//p")
    this.continueButton = page.locator("xpath=//button[text()='Continue']"); // @FindBy(xpath = "//button[text()='Continue']")
    this.yesContinueButton = page.locator("xpath=//div[contains(@class, 'monoline-popup-continue-button')]//button"); // @FindBy(xpath = "//div[contains(@class, 'monoline-popup-continue-button')]//button")
    this.noThankYouLink = page.locator("xpath=//div[contains(@class, 'monoline-popup-cancel-button')]//a"); // @FindBy(xpath = "//div[contains(@class, 'monoline-popup-cancel-button')]//a")
  }
}
