// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.mobilehome.AceMobileHomeAddressPage. */
export class AceMobileHomeAddressPage extends CoreBasePage {
  public readonly agreeButton: Locator;
  public readonly quoteLoaderPageElement: Locator;

  public constructor(page: Page) {
    super(page);
    this.agreeButton = page.locator("xpath=//button[contains(@class,'address-form__continue-cta')]"); // @FindBy(xpath = "//button[contains(@class,'address-form__continue-cta')]")
    this.quoteLoaderPageElement = page.locator("xpath=//app-start-quote-loader"); // @FindBy(xpath = "//app-start-quote-loader")
  }
}
