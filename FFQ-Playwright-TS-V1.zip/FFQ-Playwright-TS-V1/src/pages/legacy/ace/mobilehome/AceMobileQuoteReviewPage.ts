// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.mobilehome.AceMobileQuoteReviewPage. */
export class AceMobileQuoteReviewPage extends CoreBasePage {
  public readonly quoteReviewPageTitle: Locator;
  public readonly quoteReviewPageAgentIcon: Locator;
  public readonly quoteReviewPageSubtitle: Locator;
  public readonly policyDeductiblesSectionHeader: Locator;
  public readonly policyDeductiblesSectionDescription: Locator;
  public readonly listOfPolicyDeductibles: Locator;
  public readonly listOfPolicyDeductibleAmounts: Locator;
  public readonly ratedAmountInCard: Locator;
  public readonly primaryCoveragesSectionHeader: Locator;
  public readonly desktopListOfPrimaryCoverageLabels: Locator;
  public readonly mobilelistOfPrimaryCoverageLabels: Locator;
  public readonly listOfPrimaryCoverageAmounts: Locator;
  public readonly listOfCoverageHelpLinks: Locator;
  public readonly listOfAdditionalCoverageLabels: Locator;
  public readonly listOfAdditionalCoverageAmounts: Locator;
  public readonly infoSideSheetTitle: Locator;
  public readonly infoSideSheetSubtitle: Locator;
  public readonly closeInfoSideSheetButton: Locator;
  public readonly listOfCoverageTitlesInSideSheet: Locator;
  public readonly listOfCoverageTitlesWithExpandedHelpSections: Locator;
  public readonly listOfCoverageDescriptionsWithExpandedHelpSections: Locator;
  public readonly includedInPolicyHeader: Locator;
  public readonly listOfCoverageIcons: Locator;
  public readonly listOfCoverageDescriptions: Locator;
  public readonly disclaimerCardHeader: Locator;
  public readonly listOfDisclaimerCardContent: Locator;
  public readonly discountIncludedLabel: Locator;
  public readonly discountIncludedCheckmarkIcon: Locator;
  public readonly discountsAppliedLabel: Locator;
  public readonly reviewDiscountsLink: Locator;
  public readonly closeDiscountsAppliedSidesheetButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.quoteReviewPageTitle = page.locator("xpath=//app-mobilehome-review-page//h1"); // @FindBy(xpath = "//app-mobilehome-review-page//h1")
    this.quoteReviewPageAgentIcon = page.locator("xpath=//mat-card//div[contains(@class, 'call-agent-icon')]/img"); // @FindBy(xpath = "//mat-card//div[contains(@class, 'call-agent-icon')]/img")
    this.quoteReviewPageSubtitle = page.locator("xpath=//mat-card/div[contains(@class, 'call-agent-content')]"); // @FindBy(xpath = "//mat-card/div[contains(@class, 'call-agent-content')]")
    this.policyDeductiblesSectionHeader = page.locator("[data-legacy-field=\"policyDeductiblesSectionHeader\"]"); // @FindBy(xpath = POLICY_DEDUCTIBLES_XPATH)
    this.policyDeductiblesSectionDescription = page.locator("[data-legacy-field=\"policyDeductiblesSectionDescription\"]"); // @FindBy(xpath = POLICY_DEDUCTIBLES_XPATH + "/following-sibling::p")
    this.listOfPolicyDeductibles = page.locator("xpath=//div[contains (@class, 'deductible-item')]//div/span[not(contains(@class, 'bold'))]"); // @FindBy(xpath = "//div[contains (@class, 'deductible-item')]//div/span[not(contains(@class, 'bold'))]")
    this.listOfPolicyDeductibleAmounts = page.locator("xpath=//div[contains (@class, 'deductible-item')]//div/span[contains(@class, 'bold')]"); // @FindBy(xpath = "//div[contains (@class, 'deductible-item')]//div/span[contains(@class, 'bold')]")
    this.ratedAmountInCard = page.locator("xpath=//div[contains(@class, 'card-header mobilehome-header')]"); // @FindBy(xpath = "//div[contains(@class, 'card-header mobilehome-header')]")
    this.primaryCoveragesSectionHeader = page.locator("[data-legacy-field=\"primaryCoveragesSectionHeader\"]"); // @FindBy(xpath = PRIMARY_COVERAGES_CARD_XPATH + "//div[contains(@class, 'py-2')]")
    this.desktopListOfPrimaryCoverageLabels = page.locator("[data-legacy-field=\"desktopListOfPrimaryCoverageLabels\"]"); // @FindBy(xpath = PRIMARY_COVERAGE_CONTENT_XPATH + "//div[contains(@class, 'coverage-desktop')]")
    this.mobilelistOfPrimaryCoverageLabels = page.locator("[data-legacy-field=\"mobilelistOfPrimaryCoverageLabels\"]"); // @FindBy(xpath = PRIMARY_COVERAGE_CONTENT_XPATH + "//div[contains(@class, 'coverage-mobile')]")
    this.listOfPrimaryCoverageAmounts = page.locator("[data-legacy-field=\"listOfPrimaryCoverageAmounts\"]"); // @FindBy(xpath = PRIMARY_COVERAGE_CONTENT_XPATH + "//span[contains(@class, 'bold')]")
    this.listOfCoverageHelpLinks = page.locator("xpath=//button[contains(@class, 'mobilehome-info-icon-button')]"); // @FindBy(xpath = "//button[contains(@class, 'mobilehome-info-icon-button')]")
    this.listOfAdditionalCoverageLabels = page.locator("[data-legacy-field=\"listOfAdditionalCoverageLabels\"]"); // @FindBy(xpath = ADDITIONAL_COVERAGES_CARD_XPATH + "//div[contains(@class, 'tui-body')]")
    this.listOfAdditionalCoverageAmounts = page.locator("[data-legacy-field=\"listOfAdditionalCoverageAmounts\"]"); // @FindBy(xpath = ADDITIONAL_COVERAGES_CARD_XPATH + "//div[contains(@class, 'py-3')]//span[contains(@class, 'bold')]")
    this.infoSideSheetTitle = page.locator("xpath=//div[@class='heading-area']//*[contains(@class, 'tui-subtitle-text')]"); // @FindBy(xpath = "//div[@class='heading-area']//*[contains(@class, 'tui-subtitle-text')]")
    this.infoSideSheetSubtitle = page.locator(".intro-section"); // @FindBy(className = "intro-section")
    this.closeInfoSideSheetButton = page.locator("xpath=//app-mobilehome-coverage-descriptions-dialog//button[@aria-label='Close']"); // @FindBy(xpath = "//app-mobilehome-coverage-descriptions-dialog//button[@aria-label='Close']")
    this.listOfCoverageTitlesInSideSheet = page.locator("xpath=//mat-panel-title//div"); // @FindBy(xpath = "//mat-panel-title//div")
    this.listOfCoverageTitlesWithExpandedHelpSections = page.locator("xpath=//mat-expansion-panel[contains(@class, 'mat-expanded')]//mat-panel-title"); // @FindBy(xpath = "//mat-expansion-panel[contains(@class, 'mat-expanded')]//mat-panel-title")
    this.listOfCoverageDescriptionsWithExpandedHelpSections = page.locator("xpath=//mat-expansion-panel[contains(@class, 'mat-expanded')]//div[contains(@class,'mat-expansion-panel-body')]"); // @FindBy(xpath = "//mat-expansion-panel[contains(@class, 'mat-expanded')]//div[contains(@class,'mat-expansion-panel-body')]")
    this.includedInPolicyHeader = page.locator("xpath=//div[contains(@class, 'mobilehome-policy-banner')]//h2"); // @FindBy(xpath = "//div[contains(@class, 'mobilehome-policy-banner')]//h2")
    this.listOfCoverageIcons = page.locator("xpath=//div[@class='mobilehome-policy-banner_list-card']//*[self::mat-icon or self::i]"); // @FindBy(xpath = "//div[@class='mobilehome-policy-banner_list-card']//*[self::mat-icon or self::i]")
    this.listOfCoverageDescriptions = page.locator(".mobilehome-policy-banner_description"); // @FindBy(className = "mobilehome-policy-banner_description")
    this.disclaimerCardHeader = page.locator("[data-legacy-field=\"disclaimerCardHeader\"]"); // @FindBy(xpath = DISCLAIMER_CARD_XPATH + "//h2")
    this.listOfDisclaimerCardContent = page.locator("[data-legacy-field=\"listOfDisclaimerCardContent\"]"); // @FindBy(xpath = DISCLAIMER_CARD_XPATH + "//p")
    this.discountIncludedLabel = page.locator("xpath=//*[contains(@class,'discounts-included')]"); // @FindBy(xpath = "//*[contains(@class,'discounts-included')]")
    this.discountIncludedCheckmarkIcon = page.locator("xpath=//mat-list//mat-icon"); // @FindBy(xpath = "//mat-list//mat-icon")
    this.discountsAppliedLabel = page.locator("xpath=//app-home-discount//p[contains(@class, 'subtitle')]"); // @FindBy(xpath = "//app-home-discount//p[contains(@class, 'subtitle')]")
    this.reviewDiscountsLink = page.locator("xpath=//app-home-discount//p[contains(@class, 'link')]"); // @FindBy(xpath = "//app-home-discount//p[contains(@class, 'link')]")
    this.closeDiscountsAppliedSidesheetButton = page.locator("xpath=//app-home-discount-sidesheet//button[@aria-label='Close']"); // @FindBy(xpath = "//app-home-discount-sidesheet//button[@aria-label='Close']")
  }
}
