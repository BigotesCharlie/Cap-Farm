// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.mobilehome.AceMobileHomeTellUsMorePage. */
export class AceMobileHomeTellUsMorePage extends CoreBasePage {
  public readonly tellUsMorePageTitle: Locator;
  public readonly mobileHomeAddressElement: Locator;
  public readonly mobileHomeCityStateZipElement: Locator;
  public readonly yearBuiltInputField: Locator;
  public readonly sizeOfHomeLabel: Locator;
  public readonly sizeOfHomeHelpIcon: Locator;
  public readonly listOfLabelsFromWidthButtons: Locator;
  public readonly replacementCostLabel: Locator;
  public readonly replacementCostHelpIcon: Locator;
  public readonly replacementCostInputField: Locator;
  public readonly primaryHeatSourceLabel: Locator;
  public readonly primaryHeatSourceDropdown: Locator;
  public readonly secondaryHeatSourceCheckbox: Locator;
  public readonly secondaryHeatSourceLabel: Locator;
  public readonly secondaryHeatSourceSubtextElement: Locator;
  public readonly helpDialogTitle: Locator;
  public readonly helpDialogContent: Locator;

  public constructor(page: Page) {
    super(page);
    this.tellUsMorePageTitle = page.locator("xpath=//div[@class='mobile-home-details-container']//h1"); // @FindBy(xpath = "//div[@class='mobile-home-details-container']//h1")
    this.mobileHomeAddressElement = page.locator("xpath=//*[contains(@class, 'address-street')]"); // @FindBy(xpath = "//*[contains(@class, 'address-street')]")
    this.mobileHomeCityStateZipElement = page.locator("xpath=//*[contains(@class, 'address-city-state')]"); // @FindBy(xpath = "//*[contains(@class, 'address-city-state')]")
    this.yearBuiltInputField = page.locator("xpath=//input[@role='combobox']"); // @FindBy(xpath = "//input[@role='combobox']")
    this.sizeOfHomeLabel = page.locator("xpath=//*[contains(@class, 'size-label')]"); // @FindBy(xpath = "//*[contains(@class, 'size-label')]")
    this.sizeOfHomeHelpIcon = page.locator("xpath=//mat-icon[contains(@aria-label, 'Home size')]"); // @FindBy(xpath = "//mat-icon[contains(@aria-label, 'Home size')]")
    this.listOfLabelsFromWidthButtons = page.locator("[data-legacy-field=\"listOfLabelsFromWidthButtons\"]"); // @FindBy(xpath = WIDTH_BUTTON_LABEL_XPATH)
    this.replacementCostLabel = page.locator("xpath=//*[contains(@class, 'replacement-cost-label')]"); // @FindBy(xpath = "//*[contains(@class, 'replacement-cost-label')]")
    this.replacementCostHelpIcon = page.locator("xpath=//mat-icon[contains(@aria-label, 'Replacement cost')]"); // @FindBy(xpath = "//mat-icon[contains(@aria-label, 'Replacement cost')]")
    this.replacementCostInputField = page.locator("xpath=//input[@formcontrolname='replacementCost']"); // @FindBy(xpath = "//input[@formcontrolname='replacementCost']")
    this.primaryHeatSourceLabel = page.locator("xpath=//h2[contains(@class, 'mb-3')]"); // @FindBy(xpath = "//h2[contains(@class, 'mb-3')]")
    this.primaryHeatSourceDropdown = page.locator("xpath=//mat-select[@formcontrolname='primaryHeatSource']"); // @FindBy(xpath = "//mat-select[@formcontrolname='primaryHeatSource']")
    this.secondaryHeatSourceCheckbox = page.locator("#secondary-heat-source-input"); // @FindBy(id = "secondary-heat-source-input")
    this.secondaryHeatSourceLabel = page.locator("xpath=//label[@for='secondary-heat-source-input']"); // @FindBy(xpath = "//label[@for='secondary-heat-source-input']")
    this.secondaryHeatSourceSubtextElement = page.locator("xpath=//div[contains(@class, 'secondary-heat-source-group')]/p"); // @FindBy(xpath = "//div[contains(@class, 'secondary-heat-source-group')]/p")
    this.helpDialogTitle = page.locator("xpath=//div[@class='heading-area']//h1"); // @FindBy(xpath =  "//div[@class='heading-area']//h1")
    this.helpDialogContent = page.locator(".main-content"); // @FindBy(className = "main-content")
  }
}
