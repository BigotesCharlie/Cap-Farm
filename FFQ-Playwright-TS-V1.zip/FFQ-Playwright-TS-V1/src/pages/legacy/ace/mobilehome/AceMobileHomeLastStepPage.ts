// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.mobilehome.AceMobileHomeLastStepPage. */
export class AceMobileHomeLastStepPage extends CoreBasePage {
  public readonly shortTermRentalIcon: Locator;
  public readonly vacantDwellingIcon: Locator;
  public readonly rvIcon: Locator;
  public readonly motorcycleIcon: Locator;
  public readonly offroadVehicleIcon: Locator;
  public readonly boatIcon: Locator;

  public constructor(page: Page) {
    super(page);
    this.shortTermRentalIcon = page.locator("xpath=//span[contains(.,'Short-term')]/preceding-sibling::i"); // @FindBy(xpath = "//span[contains(.,'Short-term')]/preceding-sibling::i")
    this.vacantDwellingIcon = page.locator("xpath=//span[contains(.,'Vacant')]/preceding-sibling::i"); // @FindBy(xpath = "//span[contains(.,'Vacant')]/preceding-sibling::i")
    this.rvIcon = page.locator("xpath=//i[contains(@style,'recreational')]"); // @FindBy(xpath = "//i[contains(@style,'recreational')]")
    this.motorcycleIcon = page.locator("xpath=//i[contains(@style,'motorcycle_rebrand')]"); // @FindBy(xpath = "//i[contains(@style,'motorcycle_rebrand')]")
    this.offroadVehicleIcon = page.locator("xpath=//i[contains(@style,'offroad_rebrand')]"); // @FindBy(xpath = "//i[contains(@style,'offroad_rebrand')]")
    this.boatIcon = page.locator("xpath=//i[contains(@style,'rebrand_boat')]"); // @FindBy(xpath = "//i[contains(@style,'rebrand_boat')]")
  }
}
