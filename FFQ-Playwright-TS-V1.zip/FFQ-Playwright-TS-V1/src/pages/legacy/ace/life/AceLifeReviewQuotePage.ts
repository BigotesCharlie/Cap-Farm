// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.life.AceLifeReviewQuotePage. */
export class AceLifeReviewQuotePage extends CoreBasePage {
  public readonly reviewQuotePageTitle: Locator;
  public readonly reviewQuotePageSubtitle: Locator;
  public readonly coverageBenefitsSectionHeader: Locator;
  public readonly listOfCoverageBenefits: Locator;
  public readonly listOfCoverageOptionTextParagraphs: Locator;
  public readonly coverageLimitLabel: Locator;
  public readonly coverageLimitSelectionDropdown: Locator;
  public readonly listOfCoverageLimits: Locator;
  public readonly premiumLevelTermLabel: Locator;
  public readonly listOfPremiumLevelTermButtons: Locator;
  public readonly autopayPlanLabel: Locator;
  public readonly autopayAmount: Locator;
  public readonly getAllThisWithALifePolicyHeader: Locator;
  public readonly listOfGetAllThisIcons: Locator;
  public readonly listOfGetAllThisTextElements: Locator;
  public readonly listOfLifeInsuranceIssueDisclaimerText: Locator;
  public readonly callNowButton: Locator;
  public readonly emailThisQuoteLink: Locator;
  public readonly reviewQuotePageImage: Locator;
  public readonly legalDisclaimerText: Locator;
  public readonly pageLoadingSkeleton: Locator;

  public constructor(page: Page) {
    super(page);
    this.reviewQuotePageTitle = page.locator("xpath=//div[@class='personal-info_address_h1']//h1"); // @FindBy(xpath = "//div[@class='personal-info_address_h1']//h1")
    this.reviewQuotePageSubtitle = page.locator(".mb-40"); // @FindBy(className = "mb-40")
    this.coverageBenefitsSectionHeader = page.locator(".term-benefits"); // @FindBy(className = "term-benefits")
    this.listOfCoverageBenefits = page.locator("xpath=//div[@class='personal-info_address_h1']//li"); // @FindBy(xpath = "//div[@class='personal-info_address_h1']//li")
    this.listOfCoverageOptionTextParagraphs = page.locator("xpath=//div[@class='personal-info_address_h1']//div[contains(@class,'col-md')]/p"); // @FindBy(xpath = "//div[@class='personal-info_address_h1']//div[contains(@class,'col-md')]/p")
    this.coverageLimitLabel = page.locator("xpath=//label[contains(@class, 'coverage-limit-label')]"); // @FindBy(xpath = "//label[contains(@class, 'coverage-limit-label')]")
    this.coverageLimitSelectionDropdown = page.locator("xpath=//mat-select"); // @FindBy(xpath = "//mat-select")
    this.listOfCoverageLimits = page.locator("xpath=//mat-option"); // @FindBy(xpath = "//mat-option")
    this.premiumLevelTermLabel = page.locator("xpath=//label[contains(@class, 'premium-level-label') or contains(@class, 'auto-add-driver-')]"); // @FindBy(xpath = "//label[contains(@class, 'premium-level-label') or contains(@class, 'auto-add-driver-')]")
    this.listOfPremiumLevelTermButtons = page.locator("[data-legacy-field=\"listOfPremiumLevelTermButtons\"]"); // @FindBy(xpath = PREMIUM_LEVEL_TERM_BUTTONS_XPATH)
    this.autopayPlanLabel = page.locator("xpath=//label[@class='autopay']"); // @FindBy(xpath = "//label[@class='autopay']")
    this.autopayAmount = page.locator(".tui-price"); // @FindBy(className = "tui-price")
    this.getAllThisWithALifePolicyHeader = page.locator(".life-policy-header"); // @FindBy(className = "life-policy-header")
    this.listOfGetAllThisIcons = page.locator("xpath=//div[@class='fast-approval']/img"); // @FindBy(xpath = "//div[@class='fast-approval']/img")
    this.listOfGetAllThisTextElements = page.locator(".fast-div"); // @FindBy(className = "fast-div")
    this.listOfLifeInsuranceIssueDisclaimerText = page.locator("xpath=//div[@class='personal-info_address_h1']//div[contains(@class,'col-')]/div[not(@class)]/p[not(@class)]"); // @FindBy(xpath = "//div[@class='personal-info_address_h1']//div[contains(@class,'col-')]/div[not(@class)]/p[not(@class)]")
    this.callNowButton = page.locator("xpath=//button[@data-tui-tracking-id='review-quote_continue-button-cta']"); // @FindBy(xpath = "//button[@data-tui-tracking-id='review-quote_continue-button-cta']")
    this.emailThisQuoteLink = page.locator("#emailLink"); // @FindBy(id = "emailLink")
    this.reviewQuotePageImage = page.locator("xpath=//div[contains(@class, 'home-group-image-container')]/img"); // @FindBy(xpath = "//div[contains(@class, 'home-group-image-container')]/img")
    this.legalDisclaimerText = page.locator("xpath=//*[contains(@class, 'icc24_container')]"); // @FindBy(xpath = "//*[contains(@class, 'icc24_container')]")
    this.pageLoadingSkeleton = page.locator(".loading-skeleton-container"); // @FindBy(className = "loading-skeleton-container")
  }
}
