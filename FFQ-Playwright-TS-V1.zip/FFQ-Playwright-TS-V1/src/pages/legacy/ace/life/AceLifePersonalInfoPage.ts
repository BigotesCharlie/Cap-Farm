// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.life.AceLifePersonalInfoPage. */
export class AceLifePersonalInfoPage extends CoreBasePage {
  public readonly personalInfoPageTitle: Locator;
  public readonly personalInfoPageSubtitle: Locator;
  public readonly goBackLink: Locator;
  public readonly yesEnterManuallyButton: Locator;
  public readonly enterAddressManuallyLink: Locator;
  public readonly addressInputField: Locator;
  public readonly addressInputFieldErrorLabel: Locator;
  public readonly apartmentInputField: Locator;
  public readonly apartmentInputFieldLabel: Locator;
  public readonly manualEntryAddressInputField: Locator;
  public readonly manualEntryApartmentInputField: Locator;
  public readonly manualEntryCityInputField: Locator;
  public readonly manualEntryCityInputFieldErrorLabel: Locator;
  public readonly manualEntryZipCodeInputField: Locator;
  public readonly manualEntryZipCodeInputFieldErrorLabel: Locator;
  public readonly genderSelectionLabel: Locator;
  public readonly maleButton: Locator;
  public readonly femaleButton: Locator;
  public readonly genderSelectionErrorLabel: Locator;
  public readonly nicotineUseSelectionLabel: Locator;
  public readonly notUsedNicotineButton: Locator;
  public readonly haveUsedNicotineButton: Locator;
  public readonly nicotineUseSelectionErrorLabel: Locator;
  public readonly emailAndPhoneSectionLabel: Locator;
  public readonly emailInputField: Locator;
  public readonly emailInputFieldErrorLabel: Locator;
  public readonly phoneNumberInputField: Locator;
  public readonly phoneNumberInputFieldErrorLabel: Locator;
  public readonly pewcDisclaimerText: Locator;
  public readonly legalDisclaimerText: Locator;
  public readonly privacyDisclaimer: Locator;
  public readonly personalInfoPageErrorLabel: Locator;
  public readonly agreeAndSubmitButton: Locator;
  public readonly personalInfoPageImage: Locator;

  public constructor(page: Page) {
    super(page);
    this.personalInfoPageTitle = page.locator("xpath=//div[contains(@class,'personal-info_address_h1')]//h1"); // @FindBy(xpath = "//div[contains(@class,'personal-info_address_h1')]//h1")
    this.personalInfoPageSubtitle = page.locator("#auto-personal-info_address-subheading"); // @FindBy(id = "auto-personal-info_address-subheading")
    this.goBackLink = page.getByRole('link', { name: "Go back", exact: true }); // @FindBy(linkText = "Go back")
    this.yesEnterManuallyButton = page.locator("xpath=//mat-dialog-container//button[text()='Yes, enter manually']"); // @FindBy(xpath = "//mat-dialog-container//button[text()='Yes, enter manually']")
    this.enterAddressManuallyLink = page.locator("xpath=//*[@class='manual-addr-heading']/a"); // @FindBy(xpath = "//*[@class='manual-addr-heading']/a")
    this.addressInputField = page.locator("xpath=//div[contains(@class, 'address__input')]//input"); // @FindBy(xpath = "//div[contains(@class, 'address__input')]//input")
    this.addressInputFieldErrorLabel = page.locator("xpath=//div[contains(@class, 'address__input')]//mat-error"); // @FindBy(xpath = "//div[contains(@class, 'address__input')]//mat-error")
    this.apartmentInputField = page.locator("xpath=//div[@id='formField_apartment']//input"); // @FindBy(xpath = "//div[@id='formField_apartment']//input")
    this.apartmentInputFieldLabel = page.locator("xpath=//div[@id='formField_apartment']//mat-hint"); // @FindBy(xpath = "//div[@id='formField_apartment']//mat-hint")
    this.manualEntryAddressInputField = page.locator("#auto-manual-street__input-section"); // @FindBy(id = "auto-manual-street__input-section")
    this.manualEntryApartmentInputField = page.locator("#auto-manual-apartment__input-section"); // @FindBy(id = "auto-manual-apartment__input-section")
    this.manualEntryCityInputField = page.locator("xpath=//div[@id='formField_city']//input"); // @FindBy(xpath = "//div[@id='formField_city']//input")
    this.manualEntryCityInputFieldErrorLabel = page.locator("xpath=//div[@id='formField_city']//mat-error"); // @FindBy(xpath = "//div[@id='formField_city']//mat-error")
    this.manualEntryZipCodeInputField = page.locator("xpath=//div[@id='formField_zipCode']//input"); // @FindBy(xpath = "//div[@id='formField_zipCode']//input")
    this.manualEntryZipCodeInputFieldErrorLabel = page.locator("xpath=//div[@id='formField_zipCode']//mat-error"); // @FindBy(xpath = "//div[@id='formField_zipCode']//mat-error")
    this.genderSelectionLabel = page.locator("#formField_label_gender"); // @FindBy(id = "formField_label_gender")
    this.maleButton = page.locator("xpath=//button[*[normalize-space(text())='Male']]"); // @FindBy(xpath = "//button[*[normalize-space(text())='Male']]")
    this.femaleButton = page.locator("xpath=//button[*[normalize-space(text())='Female']]"); // @FindBy(xpath = "//button[*[normalize-space(text())='Female']]")
    this.genderSelectionErrorLabel = page.locator("xpath=//div[@id='formField_gender']//mat-error"); // @FindBy(xpath = "//div[@id='formField_gender']//mat-error")
    this.nicotineUseSelectionLabel = page.locator("xpath=//div[@id='formField_nicotine']/label"); // @FindBy(xpath = "//div[@id='formField_nicotine']/label")
    this.notUsedNicotineButton = page.locator("xpath=//button[*[normalize-space(text())='No']]"); // @FindBy(xpath = "//button[*[normalize-space(text())='No']]")
    this.haveUsedNicotineButton = page.locator("xpath=//button[*[normalize-space(text())='Yes']]"); // @FindBy(xpath = "//button[*[normalize-space(text())='Yes']]")
    this.nicotineUseSelectionErrorLabel = page.locator("xpath=//div[@id='formField_nicotine']//mat-error"); // @FindBy(xpath = "//div[@id='formField_nicotine']//mat-error")
    this.emailAndPhoneSectionLabel = page.locator("xpath=//p[contains(@class, 'tui-field-label-text')]"); // @FindBy(xpath = "//p[contains(@class, 'tui-field-label-text')]")
    this.emailInputField = page.locator("#flex-field-emailAddress-input_personalInfo_life"); // @FindBy(id = "flex-field-emailAddress-input_personalInfo_life")
    this.emailInputFieldErrorLabel = page.locator("xpath=//div[@class='email-address']//mat-error"); // @FindBy(xpath = "//div[@class='email-address']//mat-error")
    this.phoneNumberInputField = page.locator("#flex-field-phoneNumber-input_personalInfo_life"); // @FindBy(id = "flex-field-phoneNumber-input_personalInfo_life")
    this.phoneNumberInputFieldErrorLabel = page.locator("xpath=//div[@class='phone-number']//mat-error"); // @FindBy(xpath = "//div[@class='phone-number']//mat-error")
    this.pewcDisclaimerText = page.locator("#personal-info-phone-consent"); // @FindBy(id = "personal-info-phone-consent")
    this.legalDisclaimerText = page.locator("xpath=//*[@class='icc24_container']/parent::div"); // @FindBy(xpath = "//*[@class='icc24_container']/parent::div")
    this.privacyDisclaimer = page.locator("xpath=//*[contains(@class,'disclaimer__color')][not(@hidden)]"); // @FindBy(xpath = "//*[contains(@class,'disclaimer__color')][not(@hidden)]")
    this.personalInfoPageErrorLabel = page.locator("xpath=//p[@role='alert']"); // @FindBy(xpath = "//p[@role='alert']")
    this.agreeAndSubmitButton = page.locator("xpath=//button[contains(@class, 'address-form__continue-cta')]"); // @FindBy(xpath = "//button[contains(@class, 'address-form__continue-cta')]")
    this.personalInfoPageImage = page.locator("xpath=//div[contains(@class, 'home-group-image-container')]/img"); // @FindBy(xpath = "//div[contains(@class, 'home-group-image-container')]/img")
  }
}
