// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.life.AceLifeNameAndDOBPage. */
export class AceLifeNameAndDOBPage extends CoreBasePage {
  public readonly nameAndDOBPageTitle: Locator;
  public readonly nameAndDOBPageSubtitle: Locator;
  public readonly firstNameInputField: Locator;
  public readonly firstNameInputFieldErrorLabel: Locator;
  public readonly lastNameInputField: Locator;
  public readonly lastNameInputFieldErrorLabel: Locator;
  public readonly dobInputField: Locator;
  public readonly dobInputFieldErrorLabel: Locator;
  public readonly nameAndDOBPageErrorLabel: Locator;
  public readonly personalInformationUseLink: Locator;
  public readonly continueButton: Locator;
  public readonly nameAndDOBPageImage: Locator;

  public constructor(page: Page) {
    super(page);
    this.nameAndDOBPageTitle = page.locator("xpath=//h1[contains(@class, 'tui-h1')]"); // @FindBy(xpath = "//h1[contains(@class, 'tui-h1')]")
    this.nameAndDOBPageSubtitle = page.locator("#personal-info_name_dob-subheading"); // @FindBy(id = "personal-info_name_dob-subheading")
    this.firstNameInputField = page.locator("xpath=//div[@id='formField_firstName']//input"); // @FindBy(xpath = "//div[@id='formField_firstName']//input")
    this.firstNameInputFieldErrorLabel = page.locator("xpath=//div[@id='formField_firstName']//mat-error"); // @FindBy(xpath = "//div[@id='formField_firstName']//mat-error")
    this.lastNameInputField = page.locator("xpath=//div[@id='formField_lastName']//input"); // @FindBy(xpath = "//div[@id='formField_lastName']//input")
    this.lastNameInputFieldErrorLabel = page.locator("xpath=//div[@id='formField_lastName']//mat-error"); // @FindBy(xpath = "//div[@id='formField_lastName']//mat-error")
    this.dobInputField = page.locator("xpath=//div[@id='formField_dateOfBirth']//input[contains(@class, 'mat-mdc-input')]"); // @FindBy(xpath = "//div[@id='formField_dateOfBirth']//input[contains(@class, 'mat-mdc-input')]")
    this.dobInputFieldErrorLabel = page.locator("xpath=//div[@id='formField_dateOfBirth']//mat-error"); // @FindBy(xpath = "//div[@id='formField_dateOfBirth']//mat-error")
    this.nameAndDOBPageErrorLabel = page.locator("xpath=//p[@role='alert']"); // @FindBy(xpath = "//p[@role='alert']")
    this.personalInformationUseLink = page.locator("xpath=//div[contains(@class,'personal-info__disclaimer')]//a"); // @FindBy(xpath = "//div[contains(@class,'personal-info__disclaimer')]//a")
    this.continueButton = page.locator("xpath=//button[contains(@class, 'address-form__continue-cta')]"); // @FindBy(xpath = "//button[contains(@class, 'address-form__continue-cta')]")
    this.nameAndDOBPageImage = page.locator("xpath=//div[contains(@class, 'home-group-image-container')]/img"); // @FindBy(xpath = "//div[contains(@class, 'home-group-image-container')]/img")
  }
}
