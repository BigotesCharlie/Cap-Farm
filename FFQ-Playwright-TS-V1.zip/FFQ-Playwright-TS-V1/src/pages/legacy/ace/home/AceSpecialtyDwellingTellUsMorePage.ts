// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.home.AceSpecialtyDwellingTellUsMorePage. */
export class AceSpecialtyDwellingTellUsMorePage extends CoreBasePage {
  public readonly tellUsMorePageTitle: Locator;
  public readonly yearBuiltLabel: Locator;
  public readonly yearBuiltInputField: Locator;
  public readonly purchaseDateLabel: Locator;
  public readonly purchaseDateInputField: Locator;
  public readonly replacementCostLabel: Locator;
  public readonly replacementCostHelpIcon: Locator;
  public readonly replacementCostInputField: Locator;
  public readonly typeOfHomeLabel: Locator;
  public readonly typeOfHomeDropdown: Locator;
  public readonly townhouseRowhouseLabel: Locator;
  public readonly yesTownhouseButton: Locator;
  public readonly noTownhouseButton: Locator;
  public readonly unitsLabel: Locator;
  public readonly claimsLabel: Locator;
  public readonly cancellationLabel: Locator;
  public readonly yesCancellationButton: Locator;
  public readonly noCancellationButton: Locator;
  public readonly creditReportDisclaimer: Locator;
  public readonly consumerReportDisclaimer: Locator;
  public readonly privacyPolicyDisclaimer: Locator;
  public readonly privacyPolicyLink: Locator;
  public readonly helpDialogTitle: Locator;
  public readonly helpDialogContent: Locator;

  public constructor(page: Page) {
    super(page);
    this.tellUsMorePageTitle = page.locator("#dwelling-details-heading"); // @FindBy(id = "dwelling-details-heading")
    this.yearBuiltLabel = page.locator("xpath=//*[contains(@class, 'size-label')]"); // @FindBy(xpath = "//*[contains(@class, 'size-label')]")
    this.yearBuiltInputField = page.locator("xpath=//input[@role='combobox']"); // @FindBy(xpath = "//input[@role='combobox']")
    this.purchaseDateLabel = page.locator("xpath=//mat-form-field/preceding-sibling::h2[contains(text(), 'purchase')]"); // @FindBy(xpath = "//mat-form-field/preceding-sibling::h2[contains(text(), 'purchase')]")
    this.purchaseDateInputField = page.locator("xpath=//input[@formcontrolname='purchaseDate']"); // @FindBy(xpath = "//input[@formcontrolname='purchaseDate']")
    this.replacementCostLabel = page.locator("xpath=//*[contains(@class, 'replacement-cost-label')]"); // @FindBy(xpath = "//*[contains(@class, 'replacement-cost-label')]")
    this.replacementCostHelpIcon = page.locator("xpath=//mat-icon[contains(@aria-label, 'Replacement cost')]"); // @FindBy(xpath = "//mat-icon[contains(@aria-label, 'Replacement cost')]")
    this.replacementCostInputField = page.locator("xpath=//input[@formcontrolname='replacementCost']"); // @FindBy(xpath = "//input[@formcontrolname='replacementCost']")
    this.typeOfHomeLabel = page.locator("xpath=//mat-form-field/preceding-sibling::h2[contains(text(), 'type')]"); // @FindBy(xpath = "//mat-form-field/preceding-sibling::h2[contains(text(), 'type')]")
    this.typeOfHomeDropdown = page.locator("xpath=//mat-select[@formcontrolname='typeOfHome']"); // @FindBy(xpath = "//mat-select[@formcontrolname='typeOfHome']")
    this.townhouseRowhouseLabel = page.locator("#townhouse-row-house-label"); // @FindBy(id = "townhouse-row-house-label")
    this.yesTownhouseButton = page.locator("xpath=//mat-button-toggle-group[@formcontrolname='townhouseOrRowhouse']//span[contains(@class, 'label-content')][text()='Yes']/parent::button"); // @FindBy(xpath = "//mat-button-toggle-group[@formcontrolname='townhouseOrRowhouse']//span[contains(@class, 'label-content')][text()='Yes']/parent::button")
    this.noTownhouseButton = page.locator("xpath=//mat-button-toggle-group[@formcontrolname='townhouseOrRowhouse']//span[contains(@class, 'label-content')][text()='No']/parent::button"); // @FindBy(xpath = "//mat-button-toggle-group[@formcontrolname='townhouseOrRowhouse']//span[contains(@class, 'label-content')][text()='No']/parent::button")
    this.unitsLabel = page.locator("#units-label"); // @FindBy(id = "units-label")
    this.claimsLabel = page.locator("#claims-label"); // @FindBy(id = "claims-label")
    this.cancellationLabel = page.locator("#cancellation-label"); // @FindBy(id = "cancellation-label")
    this.yesCancellationButton = page.locator("xpath=//mat-button-toggle-group[@formcontrolname='policyCancellationIn5Yrs']//span[contains(@class, 'label-content')][text()='Yes']/parent::button"); // @FindBy(xpath = "//mat-button-toggle-group[@formcontrolname='policyCancellationIn5Yrs']//span[contains(@class, 'label-content')][text()='Yes']/parent::button")
    this.noCancellationButton = page.locator("xpath=//mat-button-toggle-group[@formcontrolname='policyCancellationIn5Yrs']//span[contains(@class, 'label-content')][text()='No']/parent::button"); // @FindBy(xpath = "//mat-button-toggle-group[@formcontrolname='policyCancellationIn5Yrs']//span[contains(@class, 'label-content')][text()='No']/parent::button")
    this.creditReportDisclaimer = page.locator("xpath=//app-dwelling-details//div[contains(@class,'disclaimer__credit-report')]//p[1]"); // @FindBy(xpath = "//app-dwelling-details//div[contains(@class,'disclaimer__credit-report')]//p[1]")
    this.consumerReportDisclaimer = page.locator("xpath=//app-dwelling-details//div[contains(@class,'disclaimer__credit-report')]//p[2]"); // @FindBy(xpath = "//app-dwelling-details//div[contains(@class,'disclaimer__credit-report')]//p[2]")
    this.privacyPolicyDisclaimer = page.locator("xpath=//app-dwelling-details//div[contains(@class,'disclaimer__color') and not(@hidden)]"); // @FindBy(xpath = "//app-dwelling-details//div[contains(@class,'disclaimer__color') and not(@hidden)]")
    this.privacyPolicyLink = page.locator("xpath=//app-dwelling-details//div[contains(@class,'disclaimer__color')]//a"); // @FindBy(xpath = "//app-dwelling-details//div[contains(@class,'disclaimer__color')]//a")
    this.helpDialogTitle = page.locator("xpath=//div[@class='heading-area']//h1"); // @FindBy(xpath =  "//div[@class='heading-area']//h1")
    this.helpDialogContent = page.locator(".main-content"); // @FindBy(className = "main-content")
  }
}
