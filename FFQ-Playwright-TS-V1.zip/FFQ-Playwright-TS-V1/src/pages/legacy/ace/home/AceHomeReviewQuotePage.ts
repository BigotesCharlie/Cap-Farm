// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.home.AceHomeReviewQuotePage. */
export class AceHomeReviewQuotePage extends CoreBasePage {
  public readonly quoteSummaryHeading: Locator;
  public readonly bundleDiscountCard: Locator;
  public readonly bundleDiscountAppliedCard: Locator;
  public readonly bundleDiscountCardImages: Locator;
  public readonly bundleCardApplyDiscountButton: Locator;
  public readonly changeYourMindText: Locator;
  public readonly removeBundleDiscountLink: Locator;
  public readonly removeBundleDiscountDialog: Locator;
  public readonly removeBundleDiscountDialogTitle: Locator;
  public readonly removeBundleDiscountDialogContent: Locator;
  public readonly buttonRemoveItBundleDiscountDialog: Locator;
  public readonly buttonKeepDiscountBundleDiscountDialog: Locator;
  public readonly buttonNextAutoDetailsDesktop: Locator;
  public readonly buttonNextAutoDetailsMobile: Locator;
  public readonly bundleDiscountInterstitialPageHeading: Locator;
  public readonly bundleDiscountInterstitialPageSubheading: Locator;
  public readonly bundleDiscountInterstitialPageImage: Locator;
  public readonly bundleDiscountInterstitialPagePromo: Locator;
  public readonly bundleDiscountSavingsText: Locator;
  public readonly quoteSummarySubheading: Locator;
  public readonly linkBackToDwellingCoverage: Locator;
  public readonly linkToContinueWithHomeOnly: Locator;
  public readonly buttonToContinueWithBundle: Locator;
  public readonly buttonToContinueWithAutoBundleDesktop: Locator;
  public readonly buttonToContinueWithAutoBundleMobile: Locator;
  public readonly quotePriceOnCard: Locator;
  public readonly quotePriceOnCardMobile: Locator;
  public readonly quoteDiscountsOnCard: Locator;
  public readonly quoteDiscountsOnCardMobile: Locator;
  public readonly quoteDiscountsOnCardWithSavings: Locator;
  public readonly quoteDiscountsOnCardWithSavingsMobile: Locator;
  public readonly quoteDiscountsSavingOnCard: Locator;
  public readonly quoteDiscountsSavingOnCardMobile: Locator;
  public readonly policyDeductibleHeader: Locator;
  public readonly outOfPocketLossForCoveredLoss: Locator;
  public readonly deductibleLabels: Locator;
  public readonly deductibleAmount: Locator;
  public readonly allPerilsDeductibleInfoIcon: Locator;
  public readonly windAndHailDeductibleInfoIcon: Locator;
  public readonly hurricaneDeductibleInfoIcon: Locator;
  public readonly tropicalCycloneDeductibleInfoIcon: Locator;
  public readonly waterDeductibleInfoIcon: Locator;
  public readonly deductibleMatDividers: Locator;
  public readonly editDeductibleIcon: Locator;
  public readonly editDeductibleText: Locator;
  public readonly editDeductibleButton: Locator;
  public readonly infoSideSheetHeaderHomeLob: Locator;
  public readonly closeIconPolicyDeductibleSideSheet: Locator;
  public readonly policyDeductibleTitlesInSideSheet: Locator;
  public readonly policyDeductibleExplanationInSideSheet: Locator;
  public readonly policyDeductibleTitlesInSideSheetTXState: Locator;
  public readonly policyDeductibleSubTitlesInSideSheetWindCycloneHailLoss: Locator;
  public readonly policyDeductibleExplanationInSideSheetTXState: Locator;
  public readonly policyDeductibleSideSheetDividers: Locator;
  public readonly deductibleHeader: Locator;
  public readonly closeIconInDeductibleSideSheet: Locator;
  public readonly allPerilLossesHeader: Locator;
  public readonly allPerilLossesDescription: Locator;
  public readonly allPerilLossesRadioButtons: Locator;
  public readonly allPerilLossesMatRadioButtons: Locator;
  public readonly windAndHailLossesHeader: Locator;
  public readonly windAndHailLossesDescription: Locator;
  public readonly waterLossesHeader: Locator;
  public readonly waterLossesDescription: Locator;
  public readonly windAndHailLossesRadioButtons: Locator;
  public readonly windAndHailLossesMatRadioButtons: Locator;
  public readonly selectTheDeductibleYouWantToChangeHeader: Locator;
  public readonly hurricaneWindHailToggleButtons: Locator;
  public readonly neitherToggleButtonNoteElement: Locator;
  public readonly windHailToggleButtonNoteElement: Locator;
  public readonly hurricaneToggleButtonNoteElement: Locator;
  public readonly hurricaneMatRadioButtons: Locator;
  public readonly hurricaneRadioButtons: Locator;
  public readonly waterMatRadioButtons: Locator;
  public readonly waterRadioButtons: Locator;
  public readonly matDividerInDeductiblesSideSheet: Locator;
  public readonly recalculateButton: Locator;
  public readonly resetChangesButton: Locator;
  public readonly resetChangesHeader: Locator;
  public readonly areYouSureYouWantToResetChangesQuestion: Locator;
  public readonly keepEditingButton: Locator;
  public readonly resetButton: Locator;
  public readonly packagePriceSubtitle: Locator;
  public readonly deductibleSelectionError: Locator;
  public readonly closeIconInPolicyDeductibleSideSheet: Locator;
  public readonly standardPackageButton: Locator;
  public readonly enhancedPackageButton: Locator;
  public readonly premierPackageButton: Locator;
  public readonly packageNameHeader: Locator;
  public readonly packageSubTotalHeader: Locator;
  public readonly packagePremiumAmount: Locator;
  public readonly choiceOfFeaturesLabel: Locator;
  public readonly comparePackageDoubleArrowIcon: Locator;
  public readonly comparePackageButton: Locator;
  public readonly coverageTypeLabels: Locator;
  public readonly coveragesLabels: Locator;
  public readonly limitLabels: Locator;
  public readonly coverageNames: Locator;
  public readonly primaryCoverageNames: Locator;
  public readonly primaryCoverageAmount: Locator;
  public readonly supplementalCoverageNames: Locator;
  public readonly supplementalCoverageAmount: Locator;
  public readonly supplementalCoverageNamesOptional: Locator;
  public readonly supplementalCoverageAmountOptional: Locator;
  public readonly specialLimitCoverageNames: Locator;
  public readonly specialLimitCoverageAmount: Locator;
  public readonly showSpecialLimitsLinkButton: Locator;
  public readonly showSpecialLimitsLinkPlusIcon: Locator;
  public readonly coverageAmountValues: Locator;
  public readonly emailLink: Locator;
  public readonly linkCloseEmailSnackBar: Locator;
  public readonly buttonReviewOptionalCoverageDesktop: Locator;
  public readonly buttonReviewOptionalCoverageMobile: Locator;
  public readonly dwellingInfoIcon: Locator;
  public readonly separateStructureInfoIcon: Locator;
  public readonly personalPropertyInfoIcon: Locator;
  public readonly lossOfUseInfoIcon: Locator;
  public readonly personalLiabilityInfoIcon: Locator;
  public readonly medicalPaymentToOthersInfoIcon: Locator;
  public readonly coveragesHeadersInInfoSideSheet: Locator;
  public readonly coveragesDescriptionsInInfoSideSheet: Locator;
  public readonly closeIconInCoverageInfoSideSheetHomeLob: Locator;
  public readonly roofMaterialInfoIcon: Locator;
  public readonly fenceInfoIcon: Locator;
  public readonly buildingOrdinanceInfoIcon: Locator;
  public readonly sidingRoofMaterialsInfoIcon: Locator;
  public readonly cyberIdentityShieldInfoIcon: Locator;
  public readonly carpetLossInfoIcon: Locator;
  public readonly limitedMatchingUndamagedPropertyInfoIcon: Locator;
  public readonly homeSharingInfoIcon: Locator;
  public readonly mineSubsidenceInfoIcon: Locator;
  public readonly accessThroughFoundationsAndWallsInfoIcon: Locator;
  public readonly doubleArrowInComparePackageLink: Locator;
  public readonly comparePackageLinkText: Locator;
  public readonly comparePackageHeaderInComparePkgSideSheet: Locator;
  public readonly subTextInComparePkgSideSheet: Locator;
  public readonly standardVsEnhancedButton: Locator;
  public readonly enhancedVsPremierButton: Locator;
  public readonly packageLabelsInComparePackageSideSheet: Locator;
  public readonly primaryAdditionalSpecialLimitsLabelsInCompareQuoteSideSheet: Locator;
  public readonly editPrimaryCoverageIcon: Locator;
  public readonly editPrimaryCoverageText: Locator;
  public readonly editPrimaryCoverageButton: Locator;
  public readonly editPrimaryCoverageCloseButton: Locator;
  public readonly editCoverageSideSheetTitle: Locator;
  public readonly editCoverageCards: Locator;
  public readonly editCoverageCardTitles: Locator;
  public readonly extendedDRC_radioButtons: Locator;
  public readonly separateStructures_radioButtons: Locator;
  public readonly personalPropertyLimit_radioButtons: Locator;
  public readonly personalPropertyLossSettlement_radioButtons: Locator;
  public readonly personalPropertyPerils_radioButtons: Locator;
  public readonly lossOfUseLimit_radioButtons: Locator;
  public readonly lossOfUseTerm_radioButtons: Locator;
  public readonly personalLiability_radioButtons: Locator;
  public readonly medicalPayments_radioButtons: Locator;
  public readonly editCoverageCardDividers: Locator;
  public readonly recalculatePrimaryCoveragesButton: Locator;
  public readonly resetPrimaryCoveragesButton: Locator;
  public readonly confirmResetButton: Locator;
  public readonly fairPlanEndorsementTitle: Locator;
  public readonly fairPlanExclusionsDescription: Locator;
  public readonly fairPlanExclusionsFooters: Locator;
  public readonly fairPlanEndorsementDialogTitle: Locator;
  public readonly fairPlanEndorsementDialogContent: Locator;
  public readonly dialogContinueButton: Locator;
  public readonly windHailExclusionPopupTitle: Locator;
  public readonly windHailExclusionPopupSubTitleContent: Locator;
  public readonly windHailExclusionPopupContinueBtn: Locator;
  public readonly windHailExclusionPopupCancelBtn: Locator;
  public readonly windHailExclusionTitle: Locator;
  public readonly sweepStakesPopup: Locator;
  public readonly sweepStakesHeading: Locator;
  public readonly sweepStakesContent: Locator;
  public readonly sweepStakesHelpText: Locator;
  public readonly sweepStakesOkButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.quoteSummaryHeading = page.locator("[data-legacy-field=\"quoteSummaryHeading\"]"); // @FindBy(xpath = PAGE_TITLE_XPATH)
    this.bundleDiscountCard = page.locator("[data-legacy-field=\"bundleDiscountCard\"]"); // @FindBy(xpath = BUNDLE_DISCOUNT_CARD_XPATH)
    this.bundleDiscountAppliedCard = page.locator("xpath=//div[contains(@class, 'bundle-discount-card tui')]"); // @FindBy(xpath = "//div[contains(@class, 'bundle-discount-card tui')]")
    this.bundleDiscountCardImages = page.locator("[data-legacy-field=\"bundleDiscountCardImages\"]"); // @FindBy(xpath = BUNDLE_DISCOUNT_CARD_XPATH + "//img")
    this.bundleCardApplyDiscountButton = page.locator("[data-legacy-field=\"bundleCardApplyDiscountButton\"]"); // @FindBy(xpath = BUNDLE_DISCOUNT_CARD_XPATH + "//button[contains(@class, 'bundle-discount-card')]")
    this.changeYourMindText = page.locator("[data-legacy-field=\"changeYourMindText\"]"); // @FindBy(xpath = BUNDLE_DISCOUNT_REMOVE_XPATH + "//p[@class = 'tui-body text-end']")
    this.removeBundleDiscountLink = page.locator("[data-legacy-field=\"removeBundleDiscountLink\"]"); // @FindBy(xpath = BUNDLE_DISCOUNT_REMOVE_XPATH + "//a[contains(@class,'tui-link')]")
    this.removeBundleDiscountDialog = page.locator("[data-legacy-field=\"removeBundleDiscountDialog\"]"); // @FindBy(xpath = REMOVE_BUNDLE_DISCOUNT_DIALOG_XPATH)
    this.removeBundleDiscountDialogTitle = page.locator("[data-legacy-field=\"removeBundleDiscountDialogTitle\"]"); // @FindBy(xpath = REMOVE_BUNDLE_DISCOUNT_DIALOG_XPATH + "//h2")
    this.removeBundleDiscountDialogContent = page.locator("[data-legacy-field=\"removeBundleDiscountDialogContent\"]"); // @FindBy(xpath = REMOVE_BUNDLE_DISCOUNT_DIALOG_XPATH + "//div[contains(@class,'dialog-body')]")
    this.buttonRemoveItBundleDiscountDialog = page.locator("[data-legacy-field=\"buttonRemoveItBundleDiscountDialog\"]"); // @FindBy(xpath = REMOVE_BUNDLE_DISCOUNT_DIALOG_XPATH + "//button[contains(@class,'remove-btn')]")
    this.buttonKeepDiscountBundleDiscountDialog = page.locator("[data-legacy-field=\"buttonKeepDiscountBundleDiscountDialog\"]"); // @FindBy(xpath = REMOVE_BUNDLE_DISCOUNT_DIALOG_XPATH + "//button[contains(@class,'keep-btn')]")
    this.buttonNextAutoDetailsDesktop = page.locator("[data-legacy-field=\"buttonNextAutoDetailsDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[contains(text(),'Next: Auto details')]")
    this.buttonNextAutoDetailsMobile = page.locator("[data-legacy-field=\"buttonNextAutoDetailsMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[contains(text(),'Next: Auto details')]")
    this.bundleDiscountInterstitialPageHeading = page.locator("[data-legacy-field=\"bundleDiscountInterstitialPageHeading\"]"); // @FindBy(xpath = BUNDLE_DISCOUNT_INTERSTITIAL_PAGE_XPATH + "/h1")
    this.bundleDiscountInterstitialPageSubheading = page.locator("[data-legacy-field=\"bundleDiscountInterstitialPageSubheading\"]"); // @FindBy(xpath = BUNDLE_DISCOUNT_INTERSTITIAL_PAGE_XPATH + "//div[contains(@class,'bundle-page-title-font')]")
    this.bundleDiscountInterstitialPageImage = page.locator("[data-legacy-field=\"bundleDiscountInterstitialPageImage\"]"); // @FindBy(xpath = BUNDLE_DISCOUNT_INTERSTITIAL_PAGE_XPATH + "//div[contains(@class,'auto-home-group-image-container')]")
    this.bundleDiscountInterstitialPagePromo = page.locator("[data-legacy-field=\"bundleDiscountInterstitialPagePromo\"]"); // @FindBy(xpath = BUNDLE_DISCOUNT_INTERSTITIAL_PAGE_XPATH + "//div[contains(@class,'bundle-page-promo-trust')]")
    this.bundleDiscountSavingsText = page.locator("[data-legacy-field=\"bundleDiscountSavingsText\"]"); // @FindBy(xpath = BUNDLE_DISCOUNT_INTERSTITIAL_PAGE_XPATH + "//div[contains(@class,'bundle-page-title-savings-font')]")
    this.quoteSummarySubheading = page.locator("xpath=//app-home-quote-review//div[contains(@class,'tui-stacking-top-xl')]/div[contains(@class,'tui-stacking-top-md') and not(contains(@class,'bundle-discount-card'))]"); // @FindBy(xpath = "//app-home-quote-review//div[contains(@class,'tui-stacking-top-xl')]/div[contains(@class,'tui-stacking-top-md') and not(contains(@class,'bundle-discount-card'))]")
    this.linkBackToDwellingCoverage = page.locator("[data-legacy-field=\"linkBackToDwellingCoverage\"]"); // @FindBy(xpath = CHANGE_COVERAGE_XPATH)
    this.linkToContinueWithHomeOnly = page.locator("[data-legacy-field=\"linkToContinueWithHomeOnly\"]"); // @FindBy(xpath = CONTINUE_WITH_HOME_ONLY_XPATH)
    this.buttonToContinueWithBundle = page.locator("[data-legacy-field=\"buttonToContinueWithBundle\"]"); // @FindBy(xpath = CONTINUE_WITH_BUNDLE_XPATH)
    this.buttonToContinueWithAutoBundleDesktop = page.locator("[data-legacy-field=\"buttonToContinueWithAutoBundleDesktop\"]"); // @FindBy(xpath = NEXT_AUTO_DETAILS_DESKTOP_XPATH)
    this.buttonToContinueWithAutoBundleMobile = page.locator("[data-legacy-field=\"buttonToContinueWithAutoBundleMobile\"]"); // @FindBy(xpath = NEXT_AUTO_DETAILS_MOBILE_XPATH)
    this.quotePriceOnCard = page.locator("[data-legacy-field=\"quotePriceOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tui-price")
    this.quotePriceOnCardMobile = page.locator("[data-legacy-field=\"quotePriceOnCardMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//tui-price")
    this.quoteDiscountsOnCard = page.locator("[data-legacy-field=\"quoteDiscountsOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div[contains(@class,'discounts-included')]")
    this.quoteDiscountsOnCardMobile = page.locator("[data-legacy-field=\"quoteDiscountsOnCardMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//mat-list-item//div[contains(@class,'discounts-included')]")
    this.quoteDiscountsOnCardWithSavings = page.locator("[data-legacy-field=\"quoteDiscountsOnCardWithSavings\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//div[contains(@class,'discount-description')]//p[contains(@class,'tui-subtitle')]")
    this.quoteDiscountsOnCardWithSavingsMobile = page.locator("[data-legacy-field=\"quoteDiscountsOnCardWithSavingsMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//div[contains(@class,'discount-description')]//p[contains(@class,'tui-subtitle')]")
    this.quoteDiscountsSavingOnCard = page.locator("[data-legacy-field=\"quoteDiscountsSavingOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//div[contains(@class,'discounts-saving')]")
    this.quoteDiscountsSavingOnCardMobile = page.locator("[data-legacy-field=\"quoteDiscountsSavingOnCardMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//div[contains(@class,'discounts-saving')]")
    this.policyDeductibleHeader = page.locator("xpath=//div[contains(@class,'main-content')]/div[1]"); // @FindBy(xpath = "//div[contains(@class,'main-content')]/div[1]")
    this.outOfPocketLossForCoveredLoss = page.locator("xpath=//div[contains(@class,'main-content')]/div[contains(@class,'tui-stacking-top-sm')]"); // @FindBy(xpath = "//div[contains(@class,'main-content')]/div[contains(@class,'tui-stacking-top-sm')]")
    this.deductibleLabels = page.locator("xpath=//div[contains(@class,'deductible-label')]"); // @FindBy(xpath = "//div[contains(@class,'deductible-label')]")
    this.deductibleAmount = page.locator("xpath=//div[contains(@class,'deductible-amount')]"); // @FindBy(xpath = "//div[contains(@class,'deductible-amount')]")
    this.allPerilsDeductibleInfoIcon = page.locator("xpath=//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_A']"); // @FindBy(xpath = "//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_A']")
    this.windAndHailDeductibleInfoIcon = page.locator("xpath=//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_W']"); // @FindBy(xpath = "//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_W']")
    this.hurricaneDeductibleInfoIcon = page.locator("xpath=//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_H']"); // @FindBy(xpath = "//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_H']")
    this.tropicalCycloneDeductibleInfoIcon = page.locator("xpath=//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_T']"); // @FindBy(xpath = "//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_T']")
    this.waterDeductibleInfoIcon = page.locator("xpath=//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_R']"); // @FindBy(xpath = "//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_R']")
    this.deductibleMatDividers = page.locator("xpath=//div[contains(@class,'deductibles')]//mat-divider"); // @FindBy(xpath = "//div[contains(@class,'deductibles')]//mat-divider")
    this.editDeductibleIcon = page.locator("xpath=//button[contains(@class,'edit-deductibles-button')]//mat-icon"); // @FindBy(xpath = "//button[contains(@class,'edit-deductibles-button')]//mat-icon")
    this.editDeductibleText = page.locator("xpath=//button[contains(@class,'edit-deductibles-button')]//span"); // @FindBy(xpath = "//button[contains(@class,'edit-deductibles-button')]//span")
    this.editDeductibleButton = page.locator("xpath=//button[contains(@class,'edit-deductibles-button')]"); // @FindBy(xpath = "//button[contains(@class,'edit-deductibles-button')]")
    this.infoSideSheetHeaderHomeLob = page.locator("xpath=//app-home-coverages-and-deductibles-info-dialog//h1"); // @FindBy(xpath = "//app-home-coverages-and-deductibles-info-dialog//h1")
    this.closeIconPolicyDeductibleSideSheet = page.locator("xpath=//app-home-coverages-and-deductibles-info-dialog//button[@aria-label='Close']"); // @FindBy(xpath = "//app-home-coverages-and-deductibles-info-dialog//button[@aria-label='Close']")
    this.policyDeductibleTitlesInSideSheet = page.locator("xpath=//mat-panel-title//div"); // @FindBy(xpath = "//mat-panel-title//div")
    this.policyDeductibleExplanationInSideSheet = page.locator("xpath=//div[contains(@class,'mat-expansion-panel-body')]//p[contains(@class,'tui-caption-text')][1]"); // @FindBy(xpath = "//div[contains(@class,'mat-expansion-panel-body')]//p[contains(@class,'tui-caption-text')][1]")
    this.policyDeductibleTitlesInSideSheetTXState = page.locator("xpath=//app-home-coverages-and-deductibles-info-dialog//mat-expansion-panel-header"); // @FindBy(xpath = "//app-home-coverages-and-deductibles-info-dialog//mat-expansion-panel-header")
    this.policyDeductibleSubTitlesInSideSheetWindCycloneHailLoss = page.locator("xpath=//app-home-coverages-and-deductibles-info-dialog//h2"); // @FindBy(xpath = "//app-home-coverages-and-deductibles-info-dialog//h2")
    this.policyDeductibleExplanationInSideSheetTXState = page.locator("xpath=//app-home-coverages-and-deductibles-info-dialog//p"); // @FindBy(xpath = "//app-home-coverages-and-deductibles-info-dialog//p")
    this.policyDeductibleSideSheetDividers = page.locator("xpath=//mat-accordion//mat-divider"); // @FindBy(xpath = "//mat-accordion//mat-divider")
    this.deductibleHeader = page.locator("xpath=//app-edit-home-deductibles-side-sheet//h1"); // @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//h1")
    this.closeIconInDeductibleSideSheet = page.locator("xpath=//app-edit-home-deductibles-side-sheet//button[@data-test-id='CLOSE_BUTTON']"); // @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//button[@data-test-id='CLOSE_BUTTON']")
    this.allPerilLossesHeader = page.locator("xpath=//app-edit-home-deductibles-side-sheet//h2[1]"); // @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//h2[1]")
    this.allPerilLossesDescription = page.locator("xpath=//div[contains(@class,'tui-caption-text')][1]"); // @FindBy(xpath = "//div[contains(@class,'tui-caption-text')][1]")
    this.allPerilLossesRadioButtons = page.locator("xpath=//mat-radio-group[@name='allPerilsCoverageSelection']//mat-radio-button//input"); // @FindBy(xpath = "//mat-radio-group[@name='allPerilsCoverageSelection']//mat-radio-button//input")
    this.allPerilLossesMatRadioButtons = page.locator("xpath=//mat-radio-group[@name='allPerilsCoverageSelection']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@name='allPerilsCoverageSelection']//mat-radio-button")
    this.windAndHailLossesHeader = page.locator("xpath=//app-edit-home-deductibles-side-sheet//h2"); // @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//h2")
    this.windAndHailLossesDescription = page.locator("xpath=//div[contains(@class,'tui-caption-text')]"); // @FindBy(xpath = "//div[contains(@class,'tui-caption-text')]")
    this.waterLossesHeader = page.locator("xpath=(//app-edit-home-deductibles-side-sheet//h2)[2]"); // @FindBy(xpath = "(//app-edit-home-deductibles-side-sheet//h2)[2]")
    this.waterLossesDescription = page.locator("xpath=(//div[contains(@class,'tui-caption-text')])[2]"); // @FindBy(xpath = "(//div[contains(@class,'tui-caption-text')])[2]")
    this.windAndHailLossesRadioButtons = page.locator("xpath=//mat-radio-group[@name='windAndHailCoverageSelection']//mat-radio-button//input"); // @FindBy(xpath = "//mat-radio-group[@name='windAndHailCoverageSelection']//mat-radio-button//input")
    this.windAndHailLossesMatRadioButtons = page.locator("xpath=//mat-radio-group[@name='windAndHailCoverageSelection']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@name='windAndHailCoverageSelection']//mat-radio-button")
    this.selectTheDeductibleYouWantToChangeHeader = page.locator("xpath=//h2[contains(@text,'Select the deductible you want to change:')]"); // @FindBy(xpath = "//h2[contains(@text,'Select the deductible you want to change:')]")
    this.hurricaneWindHailToggleButtons = page.locator("xpath=//mat-button-toggle//button[@name='hurricaneWindHailToggleGroup']"); // @FindBy(xpath = "//mat-button-toggle//button[@name='hurricaneWindHailToggleGroup']")
    this.neitherToggleButtonNoteElement = page.locator("xpath=//div[contains(text(),'Note: Both of these deductibles will match the all peril losses deductible.')]"); // @FindBy(xpath = "//div[contains(text(),'Note: Both of these deductibles will match the all peril losses deductible.')]")
    this.windHailToggleButtonNoteElement = page.locator("xpath=//div[contains(text(),'Note: The wind and hail deductible will match the all perils losses deductible.')]"); // @FindBy(xpath = "//div[contains(text(),'Note: The wind and hail deductible will match the all perils losses deductible.')]")
    this.hurricaneToggleButtonNoteElement = page.locator("xpath=//div[contains(text(),'Note: The hurricane deductible will match the all perils losses deductible.')]"); // @FindBy(xpath = "//div[contains(text(),'Note: The hurricane deductible will match the all perils losses deductible.')]")
    this.hurricaneMatRadioButtons = page.locator("xpath=//mat-radio-group[@name='hurricaneCoverageSelection']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@name='hurricaneCoverageSelection']//mat-radio-button")
    this.hurricaneRadioButtons = page.locator("xpath=//mat-radio-group[@name='hurricaneCoverageSelection']//mat-radio-button//input"); // @FindBy(xpath = "//mat-radio-group[@name='hurricaneCoverageSelection']//mat-radio-button//input")
    this.waterMatRadioButtons = page.locator("xpath=//mat-radio-group[@name='waterPerilSelection']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@name='waterPerilSelection']//mat-radio-button")
    this.waterRadioButtons = page.locator("xpath=//mat-radio-group[@name='waterPerilSelection']//mat-radio-button//input"); // @FindBy(xpath = "//mat-radio-group[@name='waterPerilSelection']//mat-radio-button//input")
    this.matDividerInDeductiblesSideSheet = page.locator("xpath=//app-edit-home-deductibles-dialog//mat-divider"); // @FindBy(xpath = "//app-edit-home-deductibles-dialog//mat-divider")
    this.recalculateButton = page.locator("xpath=//button[@data-test-id='RECALCULATE_BUTTON']"); // @FindBy(xpath = "//button[@data-test-id='RECALCULATE_BUTTON']")
    this.resetChangesButton = page.locator("xpath=//button[@data-test-id='OPEN_CONFIRM_RESET_DIALOG_BUTTON']"); // @FindBy(xpath = "//button[@data-test-id='OPEN_CONFIRM_RESET_DIALOG_BUTTON']")
    this.resetChangesHeader = page.locator("xpath=//h2[contains(@class,'reset-changes-heading')]"); // @FindBy(xpath = "//h2[contains(@class,'reset-changes-heading')]")
    this.areYouSureYouWantToResetChangesQuestion = page.locator("xpath=//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-content"); // @FindBy(xpath = "//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-content")
    this.keepEditingButton = page.locator("xpath=//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[1]"); // @FindBy(xpath = "//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[1]")
    this.resetButton = page.locator("xpath=//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[2]"); // @FindBy(xpath = "//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[2]")
    this.packagePriceSubtitle = page.locator("div.tui-subtitle"); // @FindBy(css = "div.tui-subtitle")
    this.deductibleSelectionError = page.locator("[data-legacy-field=\"deductibleSelectionError\"]"); // @FindBy(xpath = DEDUCTIBLE_SELECTION_ERROR_XPATH)
    this.closeIconInPolicyDeductibleSideSheet = page.locator("[data-legacy-field=\"closeIconInPolicyDeductibleSideSheet\"]"); // @FindBy(xpath = SIDE_SHEET_CLOSE_BUTTON_XPATH)
    this.standardPackageButton = page.locator("xpath=//div[@aria-label='Standard package']"); // @FindBy(xpath = "//div[@aria-label='Standard package']")
    this.enhancedPackageButton = page.locator("xpath=//div[@aria-label='Enhanced package']"); // @FindBy(xpath = "//div[@aria-label='Enhanced package']")
    this.premierPackageButton = page.locator("xpath=//div[@aria-label='Premier package']"); // @FindBy(xpath = "//div[@aria-label='Premier package']")
    this.packageNameHeader = page.locator("xpath=//div[contains(@class,'package-body-content')]/div[1]"); // @FindBy(xpath = "//div[contains(@class,'package-body-content')]/div[1]")
    this.packageSubTotalHeader = page.locator("xpath=//div[contains(@class,'package-body-content')]/div[2]"); // @FindBy(xpath = "//div[contains(@class,'package-body-content')]/div[2]")
    this.packagePremiumAmount = page.locator("xpath=//div[contains(@class,'package-body-content')]/div[3]"); // @FindBy(xpath = "//div[contains(@class,'package-body-content')]/div[3]")
    this.choiceOfFeaturesLabel = page.locator("xpath=//div[contains(@class,'package-body-content')]/div[4]"); // @FindBy(xpath = "//div[contains(@class,'package-body-content')]/div[4]")
    this.comparePackageDoubleArrowIcon = page.locator("xpath=//button[contains(@class,'compare-button')]//mat-icon"); // @FindBy(xpath = "//button[contains(@class,'compare-button')]//mat-icon")
    this.comparePackageButton = page.locator("xpath=//button[contains(@class,'compare-button')]"); // @FindBy(xpath = "//button[contains(@class,'compare-button')]")
    this.coverageTypeLabels = page.locator("xpath=//div[contains(@class,'coverage-section-label')]"); // @FindBy(xpath = "//div[contains(@class,'coverage-section-label')]")
    this.coveragesLabels = page.locator("xpath=//div[contains(text(),'Coverages')]"); // @FindBy(xpath = "//div[contains(text(),'Coverages')]")
    this.limitLabels = page.locator("xpath=//div[contains(text(),'Limits')]"); // @FindBy(xpath = "//div[contains(text(),'Limits')]")
    this.coverageNames = page.locator("xpath=//div[contains(@class,'coverage-description')]"); // @FindBy(xpath = "//div[contains(@class,'coverage-description')]")
    this.primaryCoverageNames = page.locator("xpath=//div[contains(text(), 'Primary')]//following-sibling::div/div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-description')]"); // @FindBy(xpath = "//div[contains(text(), 'Primary')]//following-sibling::div/div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-description')]")
    this.primaryCoverageAmount = page.locator("xpath=//div[contains(text(), 'Primary')]//following-sibling::div/div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-amount')]"); // @FindBy(xpath = "//div[contains(text(), 'Primary')]//following-sibling::div/div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-amount')]")
    this.supplementalCoverageNames = page.locator("xpath=//div[contains(text(), 'Additional')]//following-sibling::div/div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-description')]/div"); // @FindBy(xpath = "//div[contains(text(), 'Additional')]//following-sibling::div/div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-description')]/div")
    this.supplementalCoverageAmount = page.locator("xpath=//div[contains(text(), 'Additional')]//following-sibling::div/div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-amount')]/div"); // @FindBy(xpath = "//div[contains(text(), 'Additional')]//following-sibling::div/div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-amount')]/div")
    this.supplementalCoverageNamesOptional = page.locator("xpath=//div[contains(text(), 'Optional')]//following-sibling::div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-description')]"); // @FindBy(xpath = "//div[contains(text(), 'Optional')]//following-sibling::div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-description')]")
    this.supplementalCoverageAmountOptional = page.locator("xpath=//div[contains(text(), 'Optional')]//following-sibling::div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-amount')]"); // @FindBy(xpath = "//div[contains(text(), 'Optional')]//following-sibling::div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-amount')]")
    this.specialLimitCoverageNames = page.locator("xpath=//div[contains(text(), 'Special limits (Personal property)')]//following-sibling::div//div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-description')]"); // @FindBy(xpath = "//div[contains(text(), 'Special limits (Personal property)')]//following-sibling::div//div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-description')]")
    this.specialLimitCoverageAmount = page.locator("xpath=//div[contains(text(), 'Special limits (Personal property)')]//following-sibling::div//div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-amount')]"); // @FindBy(xpath = "//div[contains(text(), 'Special limits (Personal property)')]//following-sibling::div//div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-amount')]")
    this.showSpecialLimitsLinkButton = page.locator("xpath=//button[@id='specialLimitsButton']//span"); // @FindBy(xpath = "//button[@id='specialLimitsButton']//span")
    this.showSpecialLimitsLinkPlusIcon = page.locator("xpath=//button[@id='specialLimitsButton']//mat-icon[text()='add']"); // @FindBy(xpath = "//button[@id='specialLimitsButton']//mat-icon[text()='add']")
    this.coverageAmountValues = page.locator("xpath=//div[contains(@class,'coverage-amount')]"); // @FindBy(xpath = "//div[contains(@class,'coverage-amount')]")
    this.emailLink = page.locator("#emailLink"); // @FindBy(id = "emailLink")
    this.linkCloseEmailSnackBar = page.getByRole('link', { name: "Done", exact: true }); // @FindBy(linkText = "Done")
    this.buttonReviewOptionalCoverageDesktop = page.locator("[data-legacy-field=\"buttonReviewOptionalCoverageDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[contains(text(),'optional coverages')]")
    this.buttonReviewOptionalCoverageMobile = page.locator("[data-legacy-field=\"buttonReviewOptionalCoverageMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[contains(text(),'optional coverages')]")
    this.dwellingInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_24121']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_24121']//mat-icon")
    this.separateStructureInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_24404']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_24404']//mat-icon")
    this.personalPropertyInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_24321']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_24321']//mat-icon")
    this.lossOfUseInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_24507']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_24507']//mat-icon")
    this.personalLiabilityInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_10624']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_10624']//mat-icon")
    this.medicalPaymentToOthersInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_10625']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_10625']//mat-icon")
    this.coveragesHeadersInInfoSideSheet = page.locator("xpath=//mat-expansion-panel//mat-expansion-panel-header"); // @FindBy(xpath = "//mat-expansion-panel//mat-expansion-panel-header")
    this.coveragesDescriptionsInInfoSideSheet = page.locator("xpath=//div[contains(@class,'mat-expansion-panel-body')]"); // @FindBy(xpath = "//div[contains(@class,'mat-expansion-panel-body')]")
    this.closeIconInCoverageInfoSideSheetHomeLob = page.locator("xpath=//app-home-coverages-and-deductibles-info-dialog//mat-icon[contains(text(),'close')]"); // @FindBy(xpath = "//app-home-coverages-and-deductibles-info-dialog//mat-icon[contains(text(),'close')]")
    this.roofMaterialInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_23108' or @data-test-id='COVERAGE_INFO_BUTTON_23104']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_23108' or @data-test-id='COVERAGE_INFO_BUTTON_23104']//mat-icon")
    this.fenceInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_23109']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_23109']//mat-icon")
    this.buildingOrdinanceInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_24204']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_24204']//mat-icon")
    this.sidingRoofMaterialsInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_20717']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_20717']//mat-icon")
    this.cyberIdentityShieldInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_10632']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_10632']//mat-icon")
    this.carpetLossInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_23110']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_23110']//mat-icon")
    this.limitedMatchingUndamagedPropertyInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_20717']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_20717']//mat-icon")
    this.homeSharingInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_20999']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_20999']//mat-icon")
    this.mineSubsidenceInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_20630']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_20630']//mat-icon")
    this.accessThroughFoundationsAndWallsInfoIcon = page.locator("xpath=//button[@data-test-id='COVERAGE_INFO_BUTTON_20744']//mat-icon"); // @FindBy(xpath = "//button[@data-test-id='COVERAGE_INFO_BUTTON_20744']//mat-icon")
    this.doubleArrowInComparePackageLink = page.locator("xpath=//button[contains(@class,'compare-button')]//mat-icon"); // @FindBy(xpath = "//button[contains(@class,'compare-button')]//mat-icon")
    this.comparePackageLinkText = page.locator("xpath=//button[contains(@class,'compare-button')]//span"); // @FindBy(xpath = "//button[contains(@class,'compare-button')]//span")
    this.comparePackageHeaderInComparePkgSideSheet = page.locator("xpath=//app-compare-quotes-modal//h2"); // @FindBy(xpath = "//app-compare-quotes-modal//h2")
    this.subTextInComparePkgSideSheet = page.locator("xpath=//p[contains(text(),'highlighted the coverages that have different limits')]"); // @FindBy(xpath = "//p[contains(text(),'highlighted the coverages that have different limits')]")
    this.standardVsEnhancedButton = page.locator("xpath=//div[@role='tab'][contains(.,'Standard v. Enhanced')]"); // @FindBy(xpath = "//div[@role='tab'][contains(.,'Standard v. Enhanced')]")
    this.enhancedVsPremierButton = page.locator("xpath=//div[@role='tab'][contains(.,'Enhanced v. Premier')]"); // @FindBy(xpath = "//div[@role='tab'][contains(.,'Enhanced v. Premier')]")
    this.packageLabelsInComparePackageSideSheet = page.locator("xpath=//div[contains(@class,'compare-quotes-title')]"); // @FindBy(xpath = "//div[contains(@class,'compare-quotes-title')]")
    this.primaryAdditionalSpecialLimitsLabelsInCompareQuoteSideSheet = page.locator("xpath=//div[contains(@class,'compare-quotes-title')]//p"); // @FindBy(xpath = "//div[contains(@class,'compare-quotes-title')]//p")
    this.editPrimaryCoverageIcon = page.locator("xpath=//button[contains(@class,'edit-coverage-button')]//mat-icon"); // @FindBy(xpath = "//button[contains(@class,'edit-coverage-button')]//mat-icon")
    this.editPrimaryCoverageText = page.locator("xpath=//button[contains(@class,'edit-coverage-button')]//span"); // @FindBy(xpath = "//button[contains(@class,'edit-coverage-button')]//span")
    this.editPrimaryCoverageButton = page.locator("xpath=//button[contains(@class,'edit-coverage-button')]"); // @FindBy(xpath = "//button[contains(@class,'edit-coverage-button')]")
    this.editPrimaryCoverageCloseButton = page.locator("xpath=//app-edit-coverage//a[.='close']"); // @FindBy(xpath = "//app-edit-coverage//a[.='close']")
    this.editCoverageSideSheetTitle = page.locator("xpath=//app-edit-coverage//div[@id='editCoverageDialogHeading']"); // @FindBy(xpath = "//app-edit-coverage//div[@id='editCoverageDialogHeading']")
    this.editCoverageCards = page.locator("xpath=//app-edit-coverage//coverage-data-card"); // @FindBy(xpath = "//app-edit-coverage//coverage-data-card")
    this.editCoverageCardTitles = page.locator("xpath=//app-edit-coverage//coverage-data-card//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//app-edit-coverage//coverage-data-card//label[contains(@class,'tui-input-text-2')]")
    this.extendedDRC_radioButtons = page.locator("xpath=//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'23012')]/mat-radio-button"); // @FindBy(xpath = "//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'23012')]/mat-radio-button")
    this.separateStructures_radioButtons = page.locator("xpath=//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'24404')]/mat-radio-button"); // @FindBy(xpath = "//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'24404')]/mat-radio-button")
    this.personalPropertyLimit_radioButtons = page.locator("xpath=//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'24321')]/mat-radio-button"); // @FindBy(xpath = "//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'24321')]/mat-radio-button")
    this.personalPropertyLossSettlement_radioButtons = page.locator("xpath=//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'23100')]/mat-radio-button"); // @FindBy(xpath = "//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'23100')]/mat-radio-button")
    this.personalPropertyPerils_radioButtons = page.locator("xpath=//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'24322')]/mat-radio-button"); // @FindBy(xpath = "//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'24322')]/mat-radio-button")
    this.lossOfUseLimit_radioButtons = page.locator("xpath=//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'24507')]/mat-radio-button"); // @FindBy(xpath = "//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'24507')]/mat-radio-button")
    this.lossOfUseTerm_radioButtons = page.locator("xpath=//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'20645')]/mat-radio-button"); // @FindBy(xpath = "//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'20645')]/mat-radio-button")
    this.personalLiability_radioButtons = page.locator("xpath=//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'10624')]/mat-radio-button"); // @FindBy(xpath = "//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'10624')]/mat-radio-button")
    this.medicalPayments_radioButtons = page.locator("xpath=//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'10625')]/mat-radio-button"); // @FindBy(xpath = "//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'10625')]/mat-radio-button")
    this.editCoverageCardDividers = page.locator("xpath=//app-edit-coverage//div[contains(@class,'edit-coverage-coverage-card')]//mat-divider"); // @FindBy(xpath = "//app-edit-coverage//div[contains(@class,'edit-coverage-coverage-card')]//mat-divider")
    this.recalculatePrimaryCoveragesButton = page.locator("xpath=//app-edit-coverage//button[contains(@class,'edit-coverage-dialog-submit-button')]"); // @FindBy(xpath = "//app-edit-coverage//button[contains(@class,'edit-coverage-dialog-submit-button')]")
    this.resetPrimaryCoveragesButton = page.locator("xpath=//app-edit-coverage//button[text()='Reset changes']"); // @FindBy(xpath = "//app-edit-coverage//button[text()='Reset changes']")
    this.confirmResetButton = page.locator("xpath=//mat-dialog-container//button[@data-test-id='RESET_BUTTON']"); // @FindBy(xpath = "//mat-dialog-container//button[@data-test-id='RESET_BUTTON']")
    this.fairPlanEndorsementTitle = page.locator("xpath=//div[contains(@class,'documents-required-popup')]//p[contains(@class,'tui-body-text-bold')]"); // @FindBy(xpath = "//div[contains(@class,'documents-required-popup')]//p[contains(@class,'tui-body-text-bold')]")
    this.fairPlanExclusionsDescription = page.locator("xpath=//div[contains(@class,'documents-required-popup')]//ul"); // @FindBy(xpath = "//div[contains(@class,'documents-required-popup')]//ul")
    this.fairPlanExclusionsFooters = page.locator("xpath=//div[contains(@class,'documents-required-popup')]//p[contains(@class,'same-note')]"); // @FindBy(xpath = "//div[contains(@class,'documents-required-popup')]//p[contains(@class,'same-note')]")
    this.fairPlanEndorsementDialogTitle = page.locator("xpath=//mat-dialog-container[@aria-labelledby='policyExclusion']//tui-simple-dialog-title"); // @FindBy(xpath = "//mat-dialog-container[@aria-labelledby='policyExclusion']//tui-simple-dialog-title")
    this.fairPlanEndorsementDialogContent = page.locator("xpath=//mat-dialog-container[@aria-labelledby='policyExclusion']//mat-dialog-content "); // @FindBy(xpath = "//mat-dialog-container[@aria-labelledby='policyExclusion']//mat-dialog-content ")
    this.dialogContinueButton = page.locator("xpath=//mat-dialog-container[@aria-labelledby='policyExclusion']//button[text()='Continue']"); // @FindBy(xpath = "//mat-dialog-container[@aria-labelledby='policyExclusion']//button[text()='Continue']")
    this.windHailExclusionPopupTitle = page.locator("xpath=//mat-dialog-container//h2[text()='Policy exclusions']"); // @FindBy(xpath = "//mat-dialog-container//h2[text()='Policy exclusions']")
    this.windHailExclusionPopupSubTitleContent = page.locator("xpath=//mat-dialog-container//mat-dialog-content "); // @FindBy(xpath = "//mat-dialog-container//mat-dialog-content ")
    this.windHailExclusionPopupContinueBtn = page.locator("xpath=//mat-dialog-container//mat-dialog-actions//button[text()='Yes']"); // @FindBy(xpath = "//mat-dialog-container//mat-dialog-actions//button[text()='Yes']")
    this.windHailExclusionPopupCancelBtn = page.getByRole('link', { name: "No, thanks", exact: true }); // @FindBy(linkText = "No, thanks")
    this.windHailExclusionTitle = page.locator("xpath=//div[contains(@class,'documents-required-popup')]//div[@class='documents-required-card-description']/p"); // @FindBy(xpath = "//div[contains(@class,'documents-required-popup')]//div[@class='documents-required-card-description']/p")
    this.sweepStakesPopup = page.locator("xpath=//app-sweep-stakes-popup"); // @FindBy(xpath = "//app-sweep-stakes-popup")
    this.sweepStakesHeading = page.locator("xpath=//app-sweep-stakes-popup//h4[@id='sweepStakesHeading']"); // @FindBy(xpath = "//app-sweep-stakes-popup//h4[@id='sweepStakesHeading']")
    this.sweepStakesContent = page.locator("xpath=//app-sweep-stakes-popup//mat-dialog-content[@id='sweepStakesMessage']/p[1]"); // @FindBy(xpath = "//app-sweep-stakes-popup//mat-dialog-content[@id='sweepStakesMessage']/p[1]")
    this.sweepStakesHelpText = page.locator("xpath=//app-sweep-stakes-popup//mat-dialog-content[@id='sweepStakesMessage']/p[contains(@class,'sweep-stakes__help-text')]"); // @FindBy(xpath = "//app-sweep-stakes-popup//mat-dialog-content[@id='sweepStakesMessage']/p[contains(@class,'sweep-stakes__help-text')]")
    this.sweepStakesOkButton = page.locator("xpath=//app-sweep-stakes-popup//button[.='Ok']"); // @FindBy(xpath = "//app-sweep-stakes-popup//button[.='Ok']")
  }
}
