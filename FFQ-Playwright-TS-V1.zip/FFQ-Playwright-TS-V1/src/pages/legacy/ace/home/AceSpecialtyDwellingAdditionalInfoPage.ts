// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.home.AceSpecialtyDwellingAdditionalInfoPage. */
export class AceSpecialtyDwellingAdditionalInfoPage extends CoreBasePage {
  public readonly listOfCheckboxes: Locator;
  public readonly anyApplySectionHeader: Locator;
  public readonly constructedOfBrickCheckbox: Locator;
  public readonly openFoundationCheckbox: Locator;
  public readonly woodburningDeviceCheckbox: Locator;
  public readonly woodburnerOutbuildingCheckbox: Locator;
  public readonly trampolineCheckbox: Locator;
  public readonly businessOnPremisesCheckbox: Locator;
  public readonly rentedToStudentsCheckbox: Locator;
  public readonly numberOfStudentsInputField: Locator;
  public readonly safetyDevicesSectionHeader: Locator;
  public readonly deadboltsCheckbox: Locator;
  public readonly burglarAlarmCheckbox: Locator;
  public readonly smokeDetectorsCheckbox: Locator;
  public readonly centralFireAlarmCheckbox: Locator;
  public readonly smokeDetectorConfirmationDialog: Locator;
  public readonly yesHomeHasSmokeDetectorsButton: Locator;
  public readonly noHomeDoesNotHaveSmokeDetectorsButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.listOfCheckboxes = page.locator("[data-legacy-field=\"listOfCheckboxes\"]"); // @FindBy(xpath = MAT_CHECKBOX_XPATH)
    this.anyApplySectionHeader = page.locator("#doAnyApplyHeading"); // @FindBy(id = "doAnyApplyHeading")
    this.constructedOfBrickCheckbox = page.locator("xpath=//*[@id='brickConstruction']//input"); // @FindBy(xpath = "//*[@id='brickConstruction']//input")
    this.openFoundationCheckbox = page.locator("xpath=//*[@id='openFoundation']//input"); // @FindBy(xpath = "//*[@id='openFoundation']//input")
    this.woodburningDeviceCheckbox = page.locator("xpath=//*[@id='woodBurningDeviceOtherThanFireplace']//input"); // @FindBy(xpath = "//*[@id='woodBurningDeviceOtherThanFireplace']//input")
    this.woodburnerOutbuildingCheckbox = page.locator("xpath=//*[@id='woodBurnerInOutbuilding']//input"); // @FindBy(xpath = "//*[@id='woodBurnerInOutbuilding']//input")
    this.trampolineCheckbox = page.locator("xpath=//*[@id='trampolineOnPremises']//input"); // @FindBy(xpath = "//*[@id='trampolineOnPremises']//input")
    this.businessOnPremisesCheckbox = page.locator("xpath=//*[@id='businessActivityOnPremises']//input"); // @FindBy(xpath = "//*[@id='businessActivityOnPremises']//input")
    this.rentedToStudentsCheckbox = page.locator("xpath=//*[@id='rentedToStudents']//input"); // @FindBy(xpath = "//*[@id='rentedToStudents']//input")
    this.numberOfStudentsInputField = page.locator("xpath=//input[@aria-label='Number of students']"); // @FindBy(xpath = "//input[@aria-label='Number of students']")
    this.safetyDevicesSectionHeader = page.locator("#safetyDevices"); // @FindBy(id = "safetyDevices")
    this.deadboltsCheckbox = page.locator("xpath=//*[@id='deadboltLocksOnExteriorDoors']//input"); // @FindBy(xpath = "//*[@id='deadboltLocksOnExteriorDoors']//input")
    this.burglarAlarmCheckbox = page.locator("xpath=//*[@id='burglarAlarm']//input"); // @FindBy(xpath = "//*[@id='burglarAlarm']//input")
    this.smokeDetectorsCheckbox = page.locator("xpath=//*[@id='smokeDetector']//input"); // @FindBy(xpath = "//*[@id='smokeDetector']//input")
    this.centralFireAlarmCheckbox = page.locator("xpath=//*[@id='centralFireAlarm']//input"); // @FindBy(xpath = "//*[@id='centralFireAlarm']//input")
    this.smokeDetectorConfirmationDialog = page.locator("xpath=//div[contains(@class, 'dwelling-smoke-detector-popup-buttons')]"); // @FindBy(xpath = "//div[contains(@class, 'dwelling-smoke-detector-popup-buttons')]")
    this.yesHomeHasSmokeDetectorsButton = page.locator("#sameButton"); // @FindBy(id = "sameButton")
    this.noHomeDoesNotHaveSmokeDetectorsButton = page.locator("#differentButton"); // @FindBy(id = "differentButton")
  }
}
