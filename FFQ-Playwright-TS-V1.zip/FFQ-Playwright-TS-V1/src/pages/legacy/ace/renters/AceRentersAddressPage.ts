// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.renters.AceRentersAddressPage. */
export class AceRentersAddressPage extends CoreBasePage {
  public readonly formFieldAddressInput: Locator;
  public readonly unitNumberInput: Locator;
  public readonly unitNumberInputLabel: Locator;
  public readonly optionalHintText: Locator;

  public constructor(page: Page) {
    super(page);
    this.formFieldAddressInput = page.locator("[data-legacy-field=\"formFieldAddressInput\"]"); // @FindBy(xpath = ADDRESS_INPUT_FIELD_XPATH)
    this.unitNumberInput = page.locator("xpath=//app-personal-info//div[@id='formField_apartment']//input"); // @FindBy(xpath = "//app-personal-info//div[@id='formField_apartment']//input")
    this.unitNumberInputLabel = page.locator("xpath=//app-personal-info//div[@id='formField_apartment']//mat-label"); // @FindBy(xpath = "//app-personal-info//div[@id='formField_apartment']//mat-label")
    this.optionalHintText = page.locator("xpath=//app-personal-info//div[@id='formField_apartment']//mat-hint"); // @FindBy(xpath = "//app-personal-info//div[@id='formField_apartment']//mat-hint")
  }
}
