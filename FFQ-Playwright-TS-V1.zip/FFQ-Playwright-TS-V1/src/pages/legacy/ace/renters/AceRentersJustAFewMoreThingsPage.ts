// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.renters.AceRentersJustAFewMoreThingsPage. */
export class AceRentersJustAFewMoreThingsPage extends CoreBasePage {
  public readonly mailingAddressLabel: Locator;
  public readonly defaultMailingAddressRadioButton: Locator;
  public readonly defaultMailingAddressRadioButtonLabel: Locator;
  public readonly otherMailingAddressRadioButton: Locator;
  public readonly otherMailingAddressRadioButtonLabel: Locator;
  public readonly mailingAddressInputLabel: Locator;
  public readonly mailingAddressError: Locator;
  public readonly apartmentNumberInputField: Locator;
  public readonly apartmentInputLabel: Locator;
  public readonly invalidAptError: Locator;
  public readonly cityInputField: Locator;
  public readonly cityInputLabel: Locator;
  public readonly cityError: Locator;
  public readonly stateDropDown: Locator;
  public readonly stateDropDownLabel: Locator;
  public readonly stateError: Locator;
  public readonly zipCodeInputField: Locator;
  public readonly zipCodeInputLabel: Locator;
  public readonly zipCodeError: Locator;
  public readonly otherMailingAddressInputField: Locator;
  public readonly otherMailingAddressUnitInputField: Locator;
  public readonly otherMailingAddressCityInputField: Locator;
  public readonly otherMailingAddressStateDropdownField: Locator;
  public readonly otherMailingAddressZipCodeInputField: Locator;
  public readonly listOfAllTheStatesInOtherMailingAddressStateDropDown: Locator;
  public readonly personalInfoLabel: Locator;
  public readonly emailAddressFieldLabel: Locator;
  public readonly emailAddressError: Locator;

  public constructor(page: Page) {
    super(page);
    this.mailingAddressLabel = page.locator("#mailingAddressDiv>div>label"); // @FindBy(css = "#mailingAddressDiv>div>label")
    this.defaultMailingAddressRadioButton = page.locator("xpath=//mat-radio-button[@id='mailingAddressDiv_1']"); // @FindBy(xpath = "//mat-radio-button[@id='mailingAddressDiv_1']")
    this.defaultMailingAddressRadioButtonLabel = page.locator("xpath=//div[@id='mailingAddressDiv']//mat-radio-button[1]"); // @FindBy(xpath = "//div[@id='mailingAddressDiv']//mat-radio-button[1]")
    this.otherMailingAddressRadioButton = page.locator("xpath=//input[@id='mailingAddressDiv_2-input']"); // @FindBy(xpath = "//input[@id='mailingAddressDiv_2-input']")
    this.otherMailingAddressRadioButtonLabel = page.locator("xpath=//mat-radio-button[contains(.,'Other mailing address')]"); // @FindBy(xpath = "//mat-radio-button[contains(.,'Other mailing address')]")
    this.mailingAddressInputLabel = page.locator("xpath=//div[@id='formField_address']//mat-label"); // @FindBy(xpath = "//div[@id='formField_address']//mat-label")
    this.mailingAddressError = page.locator("xpath=//div[@id='formField_address']//mat-error"); // @FindBy(xpath = "//div[@id='formField_address']//mat-error")
    this.apartmentNumberInputField = page.locator("input[aria-label='Apartment number (optional)']"); // @FindBy(css = "input[aria-label='Apartment number (optional)']")
    this.apartmentInputLabel = page.locator("xpath=//div[@id='mailingAddressDiv_apartment']//mat-label"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_apartment']//mat-label")
    this.invalidAptError = page.locator("xpath=//mat-form-field[@id='auto-contact-info-apartment__input-field']//mat-error"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-info-apartment__input-field']//mat-error")
    this.cityInputField = page.locator("input[aria-label='City']"); // @FindBy(css = "input[aria-label='City']")
    this.cityInputLabel = page.locator("xpath=//div[@id='mailingAddressDiv_city']//mat-label"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_city']//mat-label")
    this.cityError = page.locator("xpath=//div[@id='mailingAddressDiv_city']//mat-error"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_city']//mat-error")
    this.stateDropDown = page.locator("mat-select[aria-label='State']"); // @FindBy(css = "mat-select[aria-label='State']")
    this.stateDropDownLabel = page.locator("xpath=//div[@id='mailingAddressDiv_state']//mat-label"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-label")
    this.stateError = page.locator("xpath=//div[@id='mailingAddressDiv_state']//mat-error/div"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-error/div")
    this.zipCodeInputField = page.locator("input[aria-label='Zip code']"); // @FindBy(css = "input[aria-label='Zip code']")
    this.zipCodeInputLabel = page.locator("xpath=//div[@id='mailingAddressDiv_zipCode']//mat-label"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//mat-label")
    this.zipCodeError = page.locator("xpath=//div[@id='mailingAddressDiv_zipCode']//mat-error/div"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//mat-error/div")
    this.otherMailingAddressInputField = page.locator("xpath=//address-autocomplete-input//input"); // @FindBy(xpath = "//address-autocomplete-input//input")
    this.otherMailingAddressUnitInputField = page.locator("xpath=//div[@id='mailingAddressDiv_apartment']//input"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_apartment']//input")
    this.otherMailingAddressCityInputField = page.locator("xpath=//div[@id='mailingAddressDiv_city']//input"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_city']//input")
    this.otherMailingAddressStateDropdownField = page.locator("xpath=//div[@id='mailingAddressDiv_state']//mat-select"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-select")
    this.otherMailingAddressZipCodeInputField = page.locator("xpath=//div[@id='mailingAddressDiv_zipCode']//input"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//input")
    this.listOfAllTheStatesInOtherMailingAddressStateDropDown = page.locator("xpath=//span[@class='mat-option-text']"); // @FindBy(xpath = "//span[@class='mat-option-text']")
    this.personalInfoLabel = page.locator("xpath=//div[@id='flex-field-emailAddress_contactInfo']/p"); // @FindBy(xpath = "//div[@id='flex-field-emailAddress_contactInfo']/p")
    this.emailAddressFieldLabel = page.locator("xpath=//div[@class='email-address']//label"); // @FindBy(xpath = "//div[@class='email-address']//label")
    this.emailAddressError = page.locator("xpath=//div[@id='flex-field-emailAddress_contactInfo']//mat-error"); // @FindBy(xpath = "//div[@id='flex-field-emailAddress_contactInfo']//mat-error")
  }
}
