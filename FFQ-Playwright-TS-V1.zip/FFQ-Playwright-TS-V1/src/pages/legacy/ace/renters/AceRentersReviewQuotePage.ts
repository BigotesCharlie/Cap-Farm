// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.renters.AceRentersReviewQuotePage. */
export class AceRentersReviewQuotePage extends CoreBasePage {
  public readonly buildingAdditionsAlterationsLabelInEditCoverageSideSheet: Locator;
  public readonly buildingAdditionsAlterationsDescriptionWebElement: Locator;
  public readonly buildingAdditionsAlterationsCoverageAmoutInputWebElement: Locator;
  public readonly buildingAdditionsAlterationsMinusAmoutWebElement: Locator;
  public readonly buildingAdditionsAlterationsPlusAmoutWebElement: Locator;
  public readonly buildingAdditionsAlterationsHintWebElement: Locator;
  public readonly editPersonalPropertyButton: Locator;
  public readonly personalPropertyLimitLabelInEditCoverageSideSheet: Locator;
  public readonly personalPropertyDescription: Locator;
  public readonly personalPropertyAmountInput: Locator;
  public readonly personalPropertyAmountInputLabel: Locator;
  public readonly personalPropertyMinusAmount: Locator;
  public readonly personalPropertyPlusAmount: Locator;
  public readonly personalPropertyHint: Locator;
  public readonly personalPropertyLossSettlementDescription: Locator;
  public readonly lossSettlementToggleRCV: Locator;
  public readonly lossSettlementToggleACV: Locator;
  public readonly closeSidesheetButton: Locator;
  public readonly optionalCoveragesHeader: Locator;
  public readonly optionalCoveragesSidesheetHeader: Locator;
  public readonly additionalCoveragesSidesheetSubheading: Locator;
  public readonly optionalCoverageNames: Locator;
  public readonly optionalCoverageAmounts: Locator;
  public readonly editOptionalCoverages: Locator;
  public readonly toggleButtons: Locator;
  public readonly headerLimitedMold: Locator;
  public readonly radioButtonsLimitedMold: Locator;
  public readonly yearBuiltInputLimitedMold: Locator;
  public readonly headerIncreasedLimitsForLimitedMold: Locator;
  public readonly radioButtonIncreasedLimitsForLimitedMold: Locator;
  public readonly yearBuiltInputIncreasedLimitsForLimitedMold: Locator;
  public readonly headerIncreasedValuables: Locator;
  public readonly headerIncreasedValuablesInfoIcon: Locator;
  public readonly checkboxesIncreasedValuables: Locator;
  public readonly checkboxesIncreasedValuable: Locator;
  public readonly footerIncreasedValuables: Locator;
  public readonly footerIncreasedValuablesStarText: Locator;
  public readonly inputIncreasedCoverageJewelry: Locator;
  public readonly increaseCoverageJewelry: Locator;
  public readonly decreaseCoverageJewelry: Locator;
  public readonly inputIncreasedCoverageSilverware: Locator;
  public readonly increaseCoverageSilverware: Locator;
  public readonly decreaseCoverageSilverware: Locator;
  public readonly inputIncreasedCoverageFirearms: Locator;
  public readonly increaseCoverageFirearms: Locator;
  public readonly decreaseCoverageFirearms: Locator;
  public readonly inputIncreasedCoverageSecurities: Locator;
  public readonly increaseCoverageSecurities: Locator;
  public readonly decreaseCoverageSecurities: Locator;
  public readonly inputIncreasedCoverageOffPremisesElectronics: Locator;
  public readonly increaseCoverageOffPremisesElectronics: Locator;
  public readonly decreaseCoverageOffPremisesElectronics: Locator;
  public readonly errorsIncreasedCoverageSection: Locator;
  public readonly increasedValuablesInfoDialogHeader: Locator;
  public readonly increasedValuablesInfoDialogCloseButton: Locator;
  public readonly increasedValuablesInfoDialogMainContent: Locator;
  public readonly increasedValuablesInfoDialogSubtitle: Locator;
  public readonly increasedValuablesInfoDialogPoints: Locator;
  public readonly increasedValuablesInfoDialogOtherArticlesTextWatches: Locator;
  public readonly increasedValuablesInfoDialogDivider1: Locator;
  public readonly increasedValuablesInfoDialogDivider2: Locator;
  public readonly increasedValuablesInfoDialogDivider3: Locator;
  public readonly headerEarthquake: Locator;
  public readonly radioButtonsEarthquake: Locator;
  public readonly radioButtonsEarthquakeLabels: Locator;
  public readonly listFoundationsEarthquakeSection: Locator;
  public readonly headersEarthquakeSection: Locator;
  public readonly toggleButtonsEarthquake: Locator;
  public readonly earthquakeInfoIcons: Locator;
  public readonly earthquakeYearBuiltLabel: Locator;
  public readonly earthquakeInfoIcon: Locator;
  public readonly earthquakeCoverageInfoDialogHeader: Locator;
  public readonly earthquakeInfoDialogSubheaders: Locator;
  public readonly earthquakeInfoDialogParagraphs: Locator;
  public readonly closeEarthquakeInfoSidesheetButton: Locator;
  public readonly yearBuiltInputEarthquake: Locator;
  public readonly watercraftCoverageDialogTitle: Locator;
  public readonly watercraftCoverageDialogContent: Locator;
  public readonly buttonRemoveCoverage: Locator;
  public readonly buttonOk: Locator;
  public readonly expandQuoteCard: Locator;
  public readonly minimizeQuoteCard: Locator;

  public constructor(page: Page) {
    super(page);
    this.buildingAdditionsAlterationsLabelInEditCoverageSideSheet = page.locator("[data-legacy-field=\"buildingAdditionsAlterationsLabelInEditCoverageSideSheet\"]"); // @FindBy(xpath = buildingAdditionsAlterationsXpath)
    this.buildingAdditionsAlterationsDescriptionWebElement = page.locator("[data-legacy-field=\"buildingAdditionsAlterationsDescriptionWebElement\"]"); // @FindBy(xpath = buildingAdditionsAlterationsXpath + COVERAGE_DESCRIPTION_XPATH)
    this.buildingAdditionsAlterationsCoverageAmoutInputWebElement = page.locator("[data-legacy-field=\"buildingAdditionsAlterationsCoverageAmoutInputWebElement\"]"); // @FindBy(xpath = buildingAdditionsAlterationsXpath + "//ancestor::coverage-data-card//app-stepper-input//input")
    this.buildingAdditionsAlterationsMinusAmoutWebElement = page.locator("[data-legacy-field=\"buildingAdditionsAlterationsMinusAmoutWebElement\"]"); // @FindBy(xpath = buildingAdditionsAlterationsXpath + "//ancestor::coverage-data-card//app-stepper-input//mat-button-toggle[1]")
    this.buildingAdditionsAlterationsPlusAmoutWebElement = page.locator("[data-legacy-field=\"buildingAdditionsAlterationsPlusAmoutWebElement\"]"); // @FindBy(xpath = buildingAdditionsAlterationsXpath + "//ancestor::coverage-data-card//app-stepper-input//mat-button-toggle[2]")
    this.buildingAdditionsAlterationsHintWebElement = page.locator("[data-legacy-field=\"buildingAdditionsAlterationsHintWebElement\"]"); // @FindBy(xpath = buildingAdditionsAlterationsXpath + "//ancestor::coverage-data-card//mat-hint")
    this.editPersonalPropertyButton = page.locator("xpath=//button[@id='editPersonalPropertyLink']"); // @FindBy(xpath = "//button[@id='editPersonalPropertyLink']")
    this.personalPropertyLimitLabelInEditCoverageSideSheet = page.locator("[data-legacy-field=\"personalPropertyLimitLabelInEditCoverageSideSheet\"]"); // @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH)
    this.personalPropertyDescription = page.locator("[data-legacy-field=\"personalPropertyDescription\"]"); // @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH + COVERAGE_DESCRIPTION_XPATH)
    this.personalPropertyAmountInput = page.locator("[data-legacy-field=\"personalPropertyAmountInput\"]"); // @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH + "//ancestor::coverage-data-card//app-stepper-input//input")
    this.personalPropertyAmountInputLabel = page.locator("[data-legacy-field=\"personalPropertyAmountInputLabel\"]"); // @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH + "//ancestor::coverage-data-card//app-stepper-input//mat-label")
    this.personalPropertyMinusAmount = page.locator("[data-legacy-field=\"personalPropertyMinusAmount\"]"); // @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH + "//ancestor::coverage-data-card//app-stepper-input//mat-button-toggle[contains(.,'remove')]")
    this.personalPropertyPlusAmount = page.locator("[data-legacy-field=\"personalPropertyPlusAmount\"]"); // @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH + "//ancestor::coverage-data-card//app-stepper-input//mat-button-toggle[contains(.,'add')]")
    this.personalPropertyHint = page.locator("[data-legacy-field=\"personalPropertyHint\"]"); // @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH + "//ancestor::coverage-data-card//mat-hint")
    this.personalPropertyLossSettlementDescription = page.locator("[data-legacy-field=\"personalPropertyLossSettlementDescription\"]"); // @FindBy(xpath = PERSONAL_PROPERTY_LOSS_SETTLEMENT_XPATH + COVERAGE_DESCRIPTION_XPATH)
    this.lossSettlementToggleRCV = page.locator("[data-legacy-field=\"lossSettlementToggleRCV\"]"); // @FindBy(xpath = PERSONAL_PROPERTY_LOSS_SETTLEMENT_XPATH +  "/ancestor::coverage-data-card//mat-button-toggle[contains(.,'RCV')]")
    this.lossSettlementToggleACV = page.locator("[data-legacy-field=\"lossSettlementToggleACV\"]"); // @FindBy(xpath = PERSONAL_PROPERTY_LOSS_SETTLEMENT_XPATH +  "/ancestor::coverage-data-card//mat-button-toggle[contains(.,'ACV')]")
    this.closeSidesheetButton = page.locator("xpath=//mat-dialog-container//mat-icon[text()='close']"); // @FindBy(xpath = "//mat-dialog-container//mat-icon[text()='close']")
    this.optionalCoveragesHeader = page.locator("xpath=//app-condo-renters-quote-review//h2[contains(text(),'"); // @FindBy(xpath = "//app-condo-renters-quote-review//h2[contains(text(),'" + OPTIONAL_COVERAGES_LABEL + "')]")
    this.optionalCoveragesSidesheetHeader = page.locator("[data-legacy-field=\"optionalCoveragesSidesheetHeader\"]"); // @FindBy(xpath = OPTIONAL_COVERAGES_SIDESHEET_HEADER_XPATH)
    this.additionalCoveragesSidesheetSubheading = page.locator("xpath=//app-renters-optional-coverages//div[contains(@class,'subheading-class')]"); // @FindBy(xpath = "//app-renters-optional-coverages//div[contains(@class,'subheading-class')]")
    this.optionalCoverageNames = page.locator("xpath=//app-condo-renters-quote-review//div[contains(@class,'coverage-name')]"); // @FindBy(xpath = "//app-condo-renters-quote-review//div[contains(@class,'coverage-name')]")
    this.optionalCoverageAmounts = page.locator("xpath=//app-condo-renters-quote-review//div[contains(@class,'coverage-name')]//following-sibling::div[contains(@class,'coverage-price-column')]"); // @FindBy(xpath = "//app-condo-renters-quote-review//div[contains(@class,'coverage-name')]//following-sibling::div[contains(@class,'coverage-price-column')]")
    this.editOptionalCoverages = page.locator("xpath=//button[@id='editOptionalCoverageLink']"); // @FindBy(xpath = "//button[@id='editOptionalCoverageLink']")
    this.toggleButtons = page.locator("xpath=//mat-slide-toggle"); // @FindBy(xpath="//mat-slide-toggle")
    this.headerLimitedMold = page.locator("xpath=//div[@id='Limitedmold']//label"); // @FindBy(xpath = "//div[@id='Limitedmold']//label")
    this.radioButtonsLimitedMold = page.locator("xpath=//div[@id='Limitedmold']//mat-radio-button"); // @FindBy(xpath = "//div[@id='Limitedmold']//mat-radio-button")
    this.yearBuiltInputLimitedMold = page.locator("xpath=//div[@id='Limitedmold']//mat-form-field//input"); // @FindBy(xpath = "//div[@id='Limitedmold']//mat-form-field//input")
    this.headerIncreasedLimitsForLimitedMold = page.locator("xpath=//div[@id='IncreasedlimitsforLimitedmold']//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='IncreasedlimitsforLimitedmold']//label[contains(@class,'tui-input-text-2')]")
    this.radioButtonIncreasedLimitsForLimitedMold = page.locator("xpath=//div[@id='IncreasedlimitsforLimitedmold']//mat-radio-button"); // @FindBy(xpath = "//div[@id='IncreasedlimitsforLimitedmold']//mat-radio-button")
    this.yearBuiltInputIncreasedLimitsForLimitedMold = page.locator("xpath=//div[@id='IncreasedlimitsforLimitedmold']//mat-form-field//input"); // @FindBy(xpath = "//div[@id='IncreasedlimitsforLimitedmold']//mat-form-field//input")
    this.headerIncreasedValuables = page.locator("xpath=//div[@id='increasedValuables']//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='increasedValuables']//label[contains(@class,'tui-input-text-2')]")
    this.headerIncreasedValuablesInfoIcon = page.locator("xpath=//div[@id='increasedValuables']//button[contains(@aria-label,'info icon')]"); // @FindBy(xpath = "//div[@id='increasedValuables']//button[contains(@aria-label,'info icon')]")
    this.checkboxesIncreasedValuables = page.locator("[data-legacy-field=\"checkboxesIncreasedValuables\"]"); // @FindBy(xpath = INCREASED_VALUABLES_CHECKBOX_XPATH)
    this.checkboxesIncreasedValuable = page.locator("[data-legacy-field=\"checkboxesIncreasedValuable\"]"); // @FindBy(xpath = INCREASED_VALUABLES_CHECKBOX_XPATH)
    this.footerIncreasedValuables = page.locator("xpath=//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]"); // @FindBy(xpath = "//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]")
    this.footerIncreasedValuablesStarText = page.locator("xpath=//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]/descendant::div[contains(.,'*')]"); // @FindBy(xpath = "//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]/descendant::div[contains(.,'*')]")
    this.inputIncreasedCoverageJewelry = page.locator("xpath=(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[1]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[1]")
    this.increaseCoverageJewelry = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[1]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[1]")
    this.decreaseCoverageJewelry = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[1]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[1]")
    this.inputIncreasedCoverageSilverware = page.locator("xpath=(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[2]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[2]")
    this.increaseCoverageSilverware = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[2]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[2]")
    this.decreaseCoverageSilverware = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[2]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[2]")
    this.inputIncreasedCoverageFirearms = page.locator("xpath=(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[3]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[3]")
    this.increaseCoverageFirearms = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[3]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[3]")
    this.decreaseCoverageFirearms = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[3]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[3]")
    this.inputIncreasedCoverageSecurities = page.locator("xpath=(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[4]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[4]")
    this.increaseCoverageSecurities = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[4]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[4]")
    this.decreaseCoverageSecurities = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[4]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[4]")
    this.inputIncreasedCoverageOffPremisesElectronics = page.locator("xpath=(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[5]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[5]")
    this.increaseCoverageOffPremisesElectronics = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[5]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[5]")
    this.decreaseCoverageOffPremisesElectronics = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[5]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[5]")
    this.errorsIncreasedCoverageSection = page.locator("xpath=//app-additional-coverage-card//mat-error"); // @FindBy(xpath = "//app-additional-coverage-card//mat-error")
    this.increasedValuablesInfoDialogHeader = page.locator("xpath=//app-increase-valuables-info-dialog//h1"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//h1")
    this.increasedValuablesInfoDialogCloseButton = page.locator("xpath=//app-increase-valuables-info-dialog//button[@aria-label='Close']"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//button[@aria-label='Close']")
    this.increasedValuablesInfoDialogMainContent = page.locator("xpath=//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[1]"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[1]")
    this.increasedValuablesInfoDialogSubtitle = page.locator("xpath=//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[2]"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[2]")
    this.increasedValuablesInfoDialogPoints = page.locator("xpath=//app-increase-valuables-info-dialog//div[@class='tui-body-text-1']//li"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[@class='tui-body-text-1']//li")
    this.increasedValuablesInfoDialogOtherArticlesTextWatches = page.locator("xpath=//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][2]"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][2]")     // Other articles     private WebElement increasedValuablesInfoDialogOtherArticles;     @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][2]/following-sibling::div[1]")     // Firearms, Security, Silverware, Fine arts     private WebElement increasedValuablesInfoDialogOtherArticlesTextFirearms;     @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][2]/following-sibling::div[2]")
    this.increasedValuablesInfoDialogDivider1 = page.locator("xpath=//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[1]"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[1]")
    this.increasedValuablesInfoDialogDivider2 = page.locator("xpath=//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[2]"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[2]")
    this.increasedValuablesInfoDialogDivider3 = page.locator("xpath=//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[3]"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[3]")
    this.headerEarthquake = page.locator("xpath=//div[@id='Earthquake']//mat-slide-toggle"); // @FindBy(xpath = "//div[@id='Earthquake']//mat-slide-toggle")
    this.radioButtonsEarthquake = page.locator("xpath=//div[@id='Earthquake']//mat-radio-button"); // @FindBy(xpath = "//div[@id='Earthquake']//mat-radio-button")
    this.radioButtonsEarthquakeLabels = page.locator("xpath=//div[@id='Earthquake']//mat-radio-button//label"); // @FindBy(xpath = "//div[@id='Earthquake']//mat-radio-button//label")
    this.listFoundationsEarthquakeSection = page.locator("xpath=//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]/following-sibling::div//li"); // @FindBy(xpath = "//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]/following-sibling::div//li")
    this.headersEarthquakeSection = page.locator("xpath=//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]")
    this.toggleButtonsEarthquake = page.locator("xpath=//div[@id='Earthquake']//mat-button-toggle"); // @FindBy(xpath = "//div[@id='Earthquake']//mat-button-toggle")
    this.earthquakeInfoIcons = page.locator("xpath=//div[@id='Earthquake']//button[contains(@aria-label,'info icon')]"); // @FindBy(xpath = "//div[@id='Earthquake']//button[contains(@aria-label,'info icon')]")
    this.earthquakeYearBuiltLabel = page.locator("xpath=//div[@id='Earthquake']//mat-form-field//label"); // @FindBy(xpath = "//div[@id='Earthquake']//mat-form-field//label")
    this.earthquakeInfoIcon = page.locator("xpath=//div[@id='Earthquake']//button[contains(@aria-label,'info icon')]"); // @FindBy(xpath = "//div[@id='Earthquake']//button[contains(@aria-label,'info icon')]")
    this.earthquakeCoverageInfoDialogHeader = page.locator("xpath=//app-earthquake-coverage-dialog//h4"); // @FindBy(xpath = "//app-earthquake-coverage-dialog//h4")
    this.earthquakeInfoDialogSubheaders = page.locator("xpath=//app-earthquake-coverage-dialog//div/span[contains(@class,'tui-subtitle-2')]"); // @FindBy(xpath = "//app-earthquake-coverage-dialog//div/span[contains(@class,'tui-subtitle-2')]")
    this.earthquakeInfoDialogParagraphs = page.locator("xpath=//app-earthquake-coverage-dialog//div[contains(@class,'tui-body')]"); // @FindBy(xpath = "//app-earthquake-coverage-dialog//div[contains(@class,'tui-body')]")
    this.closeEarthquakeInfoSidesheetButton = page.locator("xpath=//mat-dialog-container[contains(@aria-label,'earthquake')]//mat-icon[text()='close']"); // @FindBy(xpath = "//mat-dialog-container[contains(@aria-label,'earthquake')]//mat-icon[text()='close']")
    this.yearBuiltInputEarthquake = page.locator("xpath=//div[@id='Earthquake']//mat-form-field//input"); // @FindBy(xpath = "//div[@id='Earthquake']//mat-form-field//input")
    this.watercraftCoverageDialogTitle = page.locator("xpath=//mat-dialog-container/span[contains(@class,'tui-subtitle')]"); // @FindBy(xpath = "//mat-dialog-container/span[contains(@class,'tui-subtitle')]")
    this.watercraftCoverageDialogContent = page.locator("xpath=//mat-dialog-container/mat-dialog-content"); // @FindBy(xpath = "//mat-dialog-container/mat-dialog-content")
    this.buttonRemoveCoverage = page.locator("xpath=//mat-dialog-container/mat-dialog-actions/a"); // @FindBy(xpath = "//mat-dialog-container/mat-dialog-actions/a")
    this.buttonOk = page.locator("xpath=//mat-dialog-container/mat-dialog-actions/button"); // @FindBy(xpath = "//mat-dialog-container/mat-dialog-actions/button")
    this.expandQuoteCard = page.locator("xpath=//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]//mat-icon[@aria-label='expand quote card']"); // @FindBy(xpath = "//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]//mat-icon[@aria-label='expand quote card']")
    this.minimizeQuoteCard = page.locator("xpath=//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]//mat-icon[@aria-label='minimize quote card']"); // @FindBy(xpath = "//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]//mat-icon[@aria-label='minimize quote card']")
  }
}
