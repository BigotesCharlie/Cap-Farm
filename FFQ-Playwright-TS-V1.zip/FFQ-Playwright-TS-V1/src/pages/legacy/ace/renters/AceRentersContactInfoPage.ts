// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.renters.AceRentersContactInfoPage. */
export class AceRentersContactInfoPage extends CoreBasePage {
  public readonly continueToQuoteButton: Locator;
  public readonly stormShutterCheckbox: Locator;
  public readonly stormShutterCheckboxLabel: Locator;
  public readonly doesThisApplyToYourHome: Locator;

  public constructor(page: Page) {
    super(page);
    this.continueToQuoteButton = page.locator("xpath=//button[contains(@class,'rentersContinueCta')]"); // @FindBy(xpath = "//button[contains(@class,'rentersContinueCta')]")
    this.stormShutterCheckbox = page.locator("[data-legacy-field=\"stormShutterCheckbox\"]"); // @FindBy(xpath = STORM_SHUTTER_CHECKBOX_XPATH + "//mat-checkbox")
    this.stormShutterCheckboxLabel = page.locator("[data-legacy-field=\"stormShutterCheckboxLabel\"]"); // @FindBy(xpath = STORM_SHUTTER_CHECKBOX_XPATH + "//mat-label")
    this.doesThisApplyToYourHome = page.locator("xpath=//div[@id='homeDiscountsDiv']//span[contains(text(), 'Does this apply to your home?')]"); // @FindBy(xpath = "//div[@id='homeDiscountsDiv']//span[contains(text(), 'Does this apply to your home?')]")
  }
}
