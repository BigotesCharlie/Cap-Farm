// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.renters.AceRentersAboutYouPage. */
export class AceRentersAboutYouPage extends CoreBasePage {
  public readonly pageFooterDisclaimerEsign: Locator;
  public readonly pageFooterDisclaimer: Locator;
  public readonly personalInfoLabel: Locator;
  public readonly emailAddressFieldLabel: Locator;
  public readonly mobilePhoneFieldLabel: Locator;
  public readonly emailAddressError: Locator;
  public readonly phoneNumberError: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageFooterDisclaimerEsign = page.locator("xpath=//p[contains(@class,'rentersDisclaimer')]//span"); // @FindBy(xpath = "//p[contains(@class,'rentersDisclaimer')]//span")
    this.pageFooterDisclaimer = page.locator("xpath=//p[contains(@class,'rentersDisclaimer')]//following::p[1]"); // @FindBy(xpath = "//p[contains(@class,'rentersDisclaimer')]//following::p[1]")
    this.personalInfoLabel = page.locator("xpath=//app-about-you//h2[@id='contact-info-heading']"); // @FindBy(xpath = "//app-about-you//h2[@id='contact-info-heading']")
    this.emailAddressFieldLabel = page.locator("xpath=//label[@for='contact-details-emailAddress-input_email']//mat-label"); // @FindBy(xpath = "//label[@for='contact-details-emailAddress-input_email']//mat-label")
    this.mobilePhoneFieldLabel = page.locator("xpath=//label[@for='contact-details-phoneNumber-input_Field']//mat-label"); // @FindBy(xpath = "//label[@for='contact-details-phoneNumber-input_Field']//mat-label")
    this.emailAddressError = page.locator("xpath=//div[contains(@class,'email-address')]//mat-error"); // @FindBy(xpath = "//div[contains(@class,'email-address')]//mat-error")
    this.phoneNumberError = page.locator("xpath=//div[contains(@class,'phone-number')]//mat-error"); // @FindBy(xpath = "//div[contains(@class,'phone-number')]//mat-error")
  }
}
