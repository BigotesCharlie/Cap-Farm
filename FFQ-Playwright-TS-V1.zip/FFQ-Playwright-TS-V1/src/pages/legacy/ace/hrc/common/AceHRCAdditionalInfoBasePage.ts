// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCAdditionalInfoBasePage. */
export class AceHRCAdditionalInfoBasePage extends CoreBasePage {
  public readonly additionalInfoHeader: Locator;
  public readonly anyOfTheFollowingApplyToYourHomeQuestion: Locator;
  public readonly matCheckBox: Locator;
  public readonly listOfCheckedCheckBoxes: Locator;
  public readonly roofCompletelyReplacedQuestion: Locator;
  public readonly roofCompletelyReplacedQuestionAlternate: Locator;
  public readonly roofCompletelyReplacedToggleButtons: Locator;
  public readonly roofCompletelyReplacedYesButton: Locator;
  public readonly roofCompletelyReplacedNoButton: Locator;
  public readonly whenWasTheLastTimeRoofWasReplacedQuestion: Locator;
  public readonly roofYearInputField: Locator;
  public readonly yearPlaceHolderText: Locator;
  public readonly roofToggleNoButton: Locator;
  public readonly roofReplacedYearSubtitle: Locator;
  public readonly roofReplacedYearText: Locator;
  public readonly editRoofReplacedYearButton: Locator;
  public readonly roofReplacedYearInputText: Locator;
  public readonly roofReplacedYearInput: Locator;
  public readonly roofMaterialSectionLabel: Locator;
  public readonly roofMaterialDropdown: Locator;
  public readonly plumbingReplaced20YearQuestion: Locator;
  public readonly plumbingReplaced20YearYesMatButton: Locator;
  public readonly plumbingReplaced20YearYesButton: Locator;
  public readonly plumbingReplaced20YearNoMatButton: Locator;
  public readonly plumbingReplaced20YearNoButton: Locator;
  public readonly temporaryRentalInputCheckbox: Locator;
  public readonly temporaryRentalMatCheckbox: Locator;
  public readonly temporaryRentalCheckboxLabel: Locator;
  public readonly temporaryRentalSubText: Locator;
  public readonly impactResistantGlassMatCheckbox: Locator;
  public readonly impactResistantGlassCheckboxLabel: Locator;
  public readonly oilTankOnPremisesMatCheckbox: Locator;
  public readonly oilTankOnPremisesCheckboxLabel: Locator;
  public readonly swimmingPoolCheckbox: Locator;
  public readonly swimmingPoolCheckboxLabel: Locator;
  public readonly pleaseSpecifyLabelSwimmingPool: Locator;
  public readonly fencedUnfencedSwimmingPoolRadioButtons: Locator;
  public readonly fencedUnfencedSwimmingPoolRadioButton: Locator;
  public readonly solarPanelCheckbox: Locator;
  public readonly solarPanelCheckboxLabel: Locator;
  public readonly trampolineCheckbox: Locator;
  public readonly trampolineCheckboxLabel: Locator;
  public readonly pleaseSpecifyLabelTrampoline: Locator;
  public readonly fencedUnfencedTrampolineRadioButtons: Locator;
  public readonly fencedUnfencedTrampolineRadioButton: Locator;
  public readonly stormShutterCheckbox: Locator;
  public readonly stormShutterCheckboxLabel: Locator;
  public readonly matDividerDiscountSection: Locator;
  public readonly additionalDiscountHeader: Locator;
  public readonly discountCheckboxInput: Locator;
  public readonly discountMatCheckbox: Locator;
  public readonly discountCheckboxLabel: Locator;
  public readonly pleaseSpecifyLabelDiscounts: Locator;
  public readonly fireAlarmMatCheckbox: Locator;
  public readonly fireAlarmRadioButtons: Locator;
  public readonly fireAlarmRadioButton: Locator;
  public readonly fireAlarmMatRadioButtons: Locator;
  public readonly fireAlarmRadioButtonsSubtext: Locator;
  public readonly fireAlarmCheckboxLabel: Locator;
  public readonly fireAlarmPleaseSpecifyLabel: Locator;
  public readonly fireAlarmsRadioButton: Locator;
  public readonly fireProtectionSystemsCheckbox: Locator;
  public readonly fireAlarmsToggleButtonYes: Locator;
  public readonly fireAlarmsToggleButtonNo: Locator;
  public readonly smokeAlarmsToggleButtonYes: Locator;
  public readonly smokeAlarmsToggleButtonNo: Locator;
  public readonly sprinklerSystemsToggleButtonYes: Locator;
  public readonly sprinklerSystemsToggleButtonNo: Locator;
  public readonly sprinklerSystemRadioButtonPartial: Locator;
  public readonly sprinklerSystemRadioButtonFull: Locator;
  public readonly burglarAlarmMatCheckbox: Locator;
  public readonly burglarAlarmRadioButtonsInput: Locator;
  public readonly burglarAlarmRadioButton: Locator;
  public readonly burglarAlarmMatRadioButtons: Locator;
  public readonly burglarAlarmRadioButtonsSubtext: Locator;
  public readonly burglarAlarmCheckboxLabel: Locator;
  public readonly otherHomeProtectionFeaturesMatCheckbox: Locator;
  public readonly otherHomeProtectionFeaturesCheckboxLabel: Locator;
  public readonly otherHomeProtectionFeaturesRadioButtons: Locator;
  public readonly otherHomeProtectionFeaturesRadioButtonLabels: Locator;
  public readonly otherHomeProtectionSubtitleLabel: Locator;
  public readonly otherHomeProtectionHelpSideSheetLink: Locator;
  public readonly otherHomeProtectionHelpSideSheetTitle: Locator;
  public readonly otherHomeProtectionSideSheetEPASubTitle: Locator;
  public readonly otherHomeProtectionSideSheetEPAContent: Locator;
  public readonly otherHomeProtectionSideSheetFortifiedHomeSubTitle: Locator;
  public readonly otherHomeProtectionSideSheetFortifiedHomeContent: Locator;
  public readonly otherHomeProtectionSideSheetConnectedHomeSubTitle: Locator;
  public readonly otherHomeProtectionSideSheetConnectedHomeContent: Locator;
  public readonly otherHomeProtectionSideSheetConnectedHomeContentMore: Locator;
  public readonly otherHomeProtectionSideSheetAutomaticGasSubTitle: Locator;
  public readonly otherHomeProtectionSideSheetAutomaticGasContent: Locator;
  public readonly otherHomeProtectionSideSheetWaterLeakSubTitle: Locator;
  public readonly otherHomeProtectionSideSheetWaterLeakContent: Locator;
  public readonly otherHomeProtectionSideSheetCloseButton: Locator;
  public readonly fireSprinklerCheckbox: Locator;
  public readonly alarmSystemMatCheckbox: Locator;
  public readonly alarmSystemCheckboxLabel: Locator;
  public readonly localAlarmsLabel: Locator;
  public readonly localAlarmButtonYes: Locator;
  public readonly localAlarmButtonNo: Locator;
  public readonly centralAlarmsLabel: Locator;
  public readonly centralAlarmButtonYes: Locator;
  public readonly centralAlarmButtonNo: Locator;
  public readonly directSystemsLabel: Locator;
  public readonly directSystemsButtonYes: Locator;
  public readonly directSystemsButtonNo: Locator;
  public readonly waterProtectionMatCheckbox: Locator;
  public readonly waterProtectionInputCheckbox: Locator;
  public readonly waterProtectionCheckboxLabel: Locator;
  public readonly waterProtectionRadioButtons: Locator;
  public readonly waterProtectionRadioButton: Locator;
  public readonly waterProtectionMatRadioButtons: Locator;
  public readonly fortifiedHomeMatCheckbox: Locator;
  public readonly fortifiedHomeCheckboxInput: Locator;
  public readonly fortifiedHomeCheckboxLabel: Locator;
  public readonly fortifiedHomeCertRadioButtons: Locator;
  public readonly fortifiedHomeCertRadioButton: Locator;
  public readonly fortifiedHomeCertMatRadioButtons: Locator;
  public readonly fortifiedHomePleaseSpecifyLabel: Locator;
  public readonly wroughtIronBarsInputCheckbox: Locator;
  public readonly wroughtIronBarsMatCheckbox: Locator;
  public readonly wroughtIronBarsCheckboxLabel: Locator;
  public readonly previousInsuranceInputCheckbox: Locator;
  public readonly previousInsuranceMatCheckbox: Locator;
  public readonly previousInsuranceCheckboxLabel: Locator;
  public readonly previousInsuranceCheckboxSubtext: Locator;
  public readonly previousInsuranceRadioButtons: Locator;
  public readonly homeTransferDiscountHeader: Locator;
  public readonly homeTransferDiscountSubheader: Locator;
  public readonly buttonCancelHomeTransferDiscount: Locator;
  public readonly buttonSaveHomeTransferDiscount: Locator;
  public readonly homeTransferDiscountHeaderDivider: Locator;
  public readonly getHomeTransferDiscountButtonContainer: Locator;
  public readonly homeDiscountSelected: Locator;
  public readonly editHomeDiscountSelected: Locator;
  public readonly buttonCloseHomeTransferDiscount: Locator;
  public readonly wildfireRiskReductionCheckboxLabel: Locator;
  public readonly wildfireRiskReductionMatCheckbox: Locator;
  public readonly wildfireRiskReductionMatCheckboxes: Locator;
  public readonly wildfireRiskReductionCheckboxesLabel: Locator;
  public readonly electricalSystemCheckbox: Locator;
  public readonly electricalSystemCheckboxLabel: Locator;
  public readonly electricalSystemCheckboxInfoText: Locator;
  public readonly electricalSystemYearInput: Locator;
  public readonly electricalSystemYearLabel: Locator;
  public readonly plumbingSystemCheckbox: Locator;
  public readonly plumbingSystemCheckboxLabel: Locator;
  public readonly plumbingSystemCheckboxInfoText: Locator;
  public readonly plumbingSystemYearInput: Locator;
  public readonly plumbingSystemYearLabel: Locator;
  public readonly plumbingSystemReplacedYes: Locator;
  public readonly plumbingSystemReplacedNo: Locator;
  public readonly plumbingSystemReplacedMatToggleYes: Locator;
  public readonly plumbingSystemReplacedMatToggleNo: Locator;
  public readonly hvacSystemCheckbox: Locator;
  public readonly hvacSystemCheckboxLabel: Locator;
  public readonly hvacSystemCheckboxInfoText: Locator;
  public readonly hvacSystemYearInput: Locator;
  public readonly hvacSystemYearLabel: Locator;
  public readonly nonSmokerMatCheckbox: Locator;
  public readonly centralFireAlarmMatCheckbox: Locator;
  public readonly centralFireAlarmCheckboxLabel: Locator;
  public readonly centralBurglarAlarmMatCheckbox: Locator;
  public readonly centralBurglarAlarmCheckboxLabel: Locator;
  public readonly pleaseSpecifyLabelInRedColor: Locator;
  public readonly pleaseSelectAnOptionErrors: Locator;
  public readonly pleaseProvideTheYearError: Locator;
  public readonly invalidYearError: Locator;
  public readonly roofYearRangeError: Locator;
  public readonly populatedFortifiedDesignationVal: Locator;
  public readonly residenceFloorSection: Locator;
  public readonly residenceFloorCheckbox: Locator;
  public readonly residenceFloorInfoLabel: Locator;
  public readonly residenceFloorInfoDescription: Locator;
  public readonly ulRoofMatCheckbox: Locator;
  public readonly ulRoofCheckboxLabel: Locator;
  public readonly ulRoofDescriptionLabel: Locator;
  public readonly ulRoofRadioButton: Locator;
  public readonly ulRoofMatRadioButtons: Locator;
  public readonly ulRoofRadioButtonLabels: Locator;

  public constructor(page: Page) {
    super(page);
    this.additionalInfoHeader = page.locator("xpath=//div[@class='home-additional-info-info_name_dob_h1']//h1"); // @FindBy(xpath = "//div[@class='home-additional-info-info_name_dob_h1']//h1")
    this.anyOfTheFollowingApplyToYourHomeQuestion = page.locator("xpath=//div[@id='doAnyApplyHeading']//div[@id='home-additional-info_name_dob-subheading']"); // @FindBy(xpath = "//div[@id='doAnyApplyHeading']//div[@id='home-additional-info_name_dob-subheading']")
    this.matCheckBox = page.locator("[data-legacy-field=\"matCheckBox\"]"); // @FindBy(xpath = MAT_CHECKBOX_XPATH)
    this.listOfCheckedCheckBoxes = page.locator("xpath=//mat-checkbox[contains(@class,'mat-checkbox-checked')]"); // @FindBy(xpath = "//mat-checkbox[contains(@class,'mat-checkbox-checked')]")
    this.roofCompletelyReplacedQuestion = page.locator("xpath=//div[@id='roofCoverage']//div[contains(@class,'subheading')]"); // @FindBy(xpath = "//div[@id='roofCoverage']//div[contains(@class,'subheading')]")
    this.roofCompletelyReplacedQuestionAlternate = page.locator("xpath=//div[@id='roofCoverage']//h2[contains(., 'replaced')]"); // @FindBy(xpath = "//div[@id='roofCoverage']//h2[contains(., 'replaced')]")
    this.roofCompletelyReplacedToggleButtons = page.locator("xpath=//div[@id='roofCoverage']//button"); // @FindBy(xpath = "//div[@id='roofCoverage']//button")
    this.roofCompletelyReplacedYesButton = page.locator("xpath=//div[@id='roofCoverage']//button//span[contains(text(),'Yes')]"); // @FindBy(xpath = "//div[@id='roofCoverage']//button//span[contains(text(),'Yes')]")
    this.roofCompletelyReplacedNoButton = page.locator("xpath=//div[@id='roofCoverage']//button//span[contains(text(),'No')]"); // @FindBy(xpath = "//div[@id='roofCoverage']//button//span[contains(text(),'No')]")
    this.whenWasTheLastTimeRoofWasReplacedQuestion = page.locator("xpath=//p[contains(@class,'roof-label')]"); // @FindBy(xpath = "//p[contains(@class,'roof-label')]")
    this.roofYearInputField = page.locator("xpath=//div[contains(@class,'roof-question')]//input"); // @FindBy(xpath = "//div[contains(@class,'roof-question')]//input")
    this.yearPlaceHolderText = page.locator("xpath=//div[contains(@class,'roof-question')]//label"); // @FindBy(xpath = "//div[contains(@class,'roof-question')]//label")
    this.roofToggleNoButton = page.locator("[data-legacy-field=\"roofToggleNoButton\"]"); // @FindBy(xpath = ROOF_TOGGLE_BUTTON_NO_XPATH + "//ancestor::mat-button-toggle")
    this.roofReplacedYearSubtitle = page.locator("xpath=//div[@id='roofCoverage']/div[@id='roofReplacement']"); // @FindBy(xpath = "//div[@id='roofCoverage']/div[@id='roofReplacement']")
    this.roofReplacedYearText = page.locator("xpath=//div[@id='roofCoverage']//div[contains(@class,'roof-year')]/span"); // @FindBy(xpath = "//div[@id='roofCoverage']//div[contains(@class,'roof-year')]/span")
    this.editRoofReplacedYearButton = page.locator("xpath=//div[@id='roofCoverage']//div[contains(@class,'roof-year')]/button"); // @FindBy(xpath = "//div[@id='roofCoverage']//div[contains(@class,'roof-year')]/button")
    this.roofReplacedYearInputText = page.locator("xpath=//div[@id='roofCoverage']//p[@id='roofReplacedLabel']"); // @FindBy(xpath = "//div[@id='roofCoverage']//p[@id='roofReplacedLabel']")
    this.roofReplacedYearInput = page.locator("xpath=//div[@id='roofCoverage']//input[@aria-labelledby='roofReplacedLabel']"); // @FindBy(xpath = "//div[@id='roofCoverage']//input[@aria-labelledby='roofReplacedLabel']")
    this.roofMaterialSectionLabel = page.locator("xpath=//mat-select/ancestor::mat-form-field/preceding-sibling::h2"); // @FindBy(xpath = "//mat-select/ancestor::mat-form-field/preceding-sibling::h2")
    this.roofMaterialDropdown = page.locator("xpath=//mat-select"); // @FindBy(xpath = "//mat-select")
    this.plumbingReplaced20YearQuestion = page.locator("xpath=//div[@id='plumbingReplacement20yearBuiltCheck']//div[contains(@class,'subheading')]"); // @FindBy(xpath = "//div[@id='plumbingReplacement20yearBuiltCheck']//div[contains(@class,'subheading')]")
    this.plumbingReplaced20YearYesMatButton = page.locator("xpath=//div[@id='plumbingReplacement20yearBuiltCheck']//mat-button-toggle[contains(.,'Yes')]"); // @FindBy(xpath = "//div[@id='plumbingReplacement20yearBuiltCheck']//mat-button-toggle[contains(.,'Yes')]")
    this.plumbingReplaced20YearYesButton = page.locator("xpath=//div[@id='plumbingReplacement20yearBuiltCheck']//mat-button-toggle[contains(.,'Yes')]//button"); // @FindBy(xpath = "//div[@id='plumbingReplacement20yearBuiltCheck']//mat-button-toggle[contains(.,'Yes')]//button")
    this.plumbingReplaced20YearNoMatButton = page.locator("xpath=//div[@id='plumbingReplacement20yearBuiltCheck']//mat-button-toggle[contains(.,'No')]"); // @FindBy(xpath = "//div[@id='plumbingReplacement20yearBuiltCheck']//mat-button-toggle[contains(.,'No')]")
    this.plumbingReplaced20YearNoButton = page.locator("xpath=//div[@id='plumbingReplacement20yearBuiltCheck']//mat-button-toggle[contains(.,'No')]//button"); // @FindBy(xpath = "//div[@id='plumbingReplacement20yearBuiltCheck']//mat-button-toggle[contains(.,'No')]//button")
    this.temporaryRentalInputCheckbox = page.locator("[data-legacy-field=\"temporaryRentalInputCheckbox\"]"); // @FindBy(xpath = TEMPORARY_RENTAL_CHECKBOX_XPATH + "//input")
    this.temporaryRentalMatCheckbox = page.locator("[data-legacy-field=\"temporaryRentalMatCheckbox\"]"); // @FindBy(xpath = TEMPORARY_RENTAL_CHECKBOX_XPATH)
    this.temporaryRentalCheckboxLabel = page.locator("[data-legacy-field=\"temporaryRentalCheckboxLabel\"]"); // @FindBy(xpath = TEMPORARY_RENTAL_CHECKBOX_XPATH + "//mat-label")
    this.temporaryRentalSubText = page.locator("xpath=//div[contains(@class,'home-additional-info-rentals')]//p"); // @FindBy(xpath = "//div[contains(@class,'home-additional-info-rentals')]//p")
    this.impactResistantGlassMatCheckbox = page.locator("[data-legacy-field=\"impactResistantGlassMatCheckbox\"]"); // @FindBy(xpath = IMPACT_RESISTANT_GLASS_CHECKBOX_XPATH)
    this.impactResistantGlassCheckboxLabel = page.locator("[data-legacy-field=\"impactResistantGlassCheckboxLabel\"]"); // @FindBy(xpath = IMPACT_RESISTANT_GLASS_CHECKBOX_XPATH + "//mat-label")
    this.oilTankOnPremisesMatCheckbox = page.locator("[data-legacy-field=\"oilTankOnPremisesMatCheckbox\"]"); // @FindBy(xpath = OIL_TANK_ON_PREMISES_CHECKBOX_XPATH)
    this.oilTankOnPremisesCheckboxLabel = page.locator("[data-legacy-field=\"oilTankOnPremisesCheckboxLabel\"]"); // @FindBy(xpath = OIL_TANK_ON_PREMISES_CHECKBOX_XPATH + "//mat-label")
    this.swimmingPoolCheckbox = page.locator("[data-legacy-field=\"swimmingPoolCheckbox\"]"); // @FindBy(xpath = SWIMMING_POOL_CHECKBOX_XPATH)
    this.swimmingPoolCheckboxLabel = page.locator("[data-legacy-field=\"swimmingPoolCheckboxLabel\"]"); // @FindBy(xpath = SWIMMING_POOL_CHECKBOX_XPATH + "//mat-label")
    this.pleaseSpecifyLabelSwimmingPool = page.locator("xpath=//app-additional-info//div[@id='swimmingPool']//div[contains(@class,'additional-info-card')]//label[contains(@class,'tui-caption')]"); // @FindBy(xpath = "//app-additional-info//div[@id='swimmingPool']//div[contains(@class,'additional-info-card')]//label[contains(@class,'tui-caption')]")
    this.fencedUnfencedSwimmingPoolRadioButtons = page.locator("[data-legacy-field=\"fencedUnfencedSwimmingPoolRadioButtons\"]"); // @FindBy(xpath = SWIMMING_POOL_RADIO_XPATH)
    this.fencedUnfencedSwimmingPoolRadioButton = page.locator("[data-legacy-field=\"fencedUnfencedSwimmingPoolRadioButton\"]"); // @FindBy(xpath = SWIMMING_POOL_RADIO_XPATH)
    this.solarPanelCheckbox = page.locator("[data-legacy-field=\"solarPanelCheckbox\"]"); // @FindBy(xpath = SOLAR_CHECKBOX_XPATH)
    this.solarPanelCheckboxLabel = page.locator("xpath=//div[contains(@class,'home-additional-info-solar')]//mat-label"); // @FindBy(xpath = "//div[contains(@class,'home-additional-info-solar')]//mat-label")
    this.trampolineCheckbox = page.locator("[data-legacy-field=\"trampolineCheckbox\"]"); // @FindBy(xpath = TRAMPOLINE_CHECKBOX_XPATH)
    this.trampolineCheckboxLabel = page.locator("xpath=//div[contains(@class,'home-additional-info-trampoline')]//mat-label"); // @FindBy(xpath = "//div[contains(@class,'home-additional-info-trampoline')]//mat-label")
    this.pleaseSpecifyLabelTrampoline = page.locator("xpath=//app-additional-info//div[@id='trampoline']//div[contains(@class,'additional-info-card')]//label[contains(@class,'tui-caption')]"); // @FindBy(xpath = "//app-additional-info//div[@id='trampoline']//div[contains(@class,'additional-info-card')]//label[contains(@class,'tui-caption')]")
    this.fencedUnfencedTrampolineRadioButtons = page.locator("[data-legacy-field=\"fencedUnfencedTrampolineRadioButtons\"]"); // @FindBy(xpath = TRAMPOLINE_RADIO_XPATH)
    this.fencedUnfencedTrampolineRadioButton = page.locator("[data-legacy-field=\"fencedUnfencedTrampolineRadioButton\"]"); // @FindBy(xpath = TRAMPOLINE_RADIO_XPATH)
    this.stormShutterCheckbox = page.locator("[data-legacy-field=\"stormShutterCheckbox\"]"); // @FindBy(xpath = STORM_SHUTTER_CHECKBOX_XPATH)
    this.stormShutterCheckboxLabel = page.locator("xpath=//div[contains(@class,'home-additional-storm-shutter')]//mat-label"); // @FindBy(xpath = "//div[contains(@class,'home-additional-storm-shutter')]//mat-label")
    this.matDividerDiscountSection = page.locator("xpath=//mat-divider[contains(@class,'additional-discounts-divider')]"); // @FindBy(xpath = "//mat-divider[contains(@class,'additional-discounts-divider')]")
    this.additionalDiscountHeader = page.locator("xpath=//div[@id='headingDiscountDiv']//div[@id='home-additional-discount-subheading']"); // @FindBy(xpath = "//div[@id='headingDiscountDiv']//div[@id='home-additional-discount-subheading']")
    this.discountCheckboxInput = page.locator("xpath=//div[contains(@class,'additional-discounts')]//mat-checkbox//input"); // @FindBy(xpath = "//div[contains(@class,'additional-discounts')]//mat-checkbox//input")
    this.discountMatCheckbox = page.locator("xpath=//div[contains(@class,'additional-discounts')]//mat-checkbox"); // @FindBy(xpath = "//div[contains(@class,'additional-discounts')]//mat-checkbox")
    this.discountCheckboxLabel = page.locator("xpath=//div[contains(@class,'additional-discounts')]//mat-checkbox//mat-label"); // @FindBy(xpath = "//div[contains(@class,'additional-discounts')]//mat-checkbox//mat-label")
    this.pleaseSpecifyLabelDiscounts = page.locator("xpath=//div[contains(@class,'additional-discounts-card')]//mat-card/div/label"); // @FindBy(xpath = "//div[contains(@class,'additional-discounts-card')]//mat-card/div/label")
    this.fireAlarmMatCheckbox = page.locator("[data-legacy-field=\"fireAlarmMatCheckbox\"]"); // @FindBy(xpath = FIRE_ALARM_CHECKBOX_XPATH)
    this.fireAlarmRadioButtons = page.locator("[data-legacy-field=\"fireAlarmRadioButtons\"]"); // @FindBy(xpath = FIRE_ALARM_RADIO_XPATH + "//input")
    this.fireAlarmRadioButton = page.locator("[data-legacy-field=\"fireAlarmRadioButton\"]"); // @FindBy(xpath = FIRE_ALARM_RADIO_XPATH)
    this.fireAlarmMatRadioButtons = page.locator("[data-legacy-field=\"fireAlarmMatRadioButtons\"]"); // @FindBy(xpath = FIRE_ALARM_RADIO_XPATH)
    this.fireAlarmRadioButtonsSubtext = page.locator("[data-legacy-field=\"fireAlarmRadioButtonsSubtext\"]"); // @FindBy(xpath = FIRE_ALARM_RADIO_XPATH + "/following-sibling::span")
    this.fireAlarmCheckboxLabel = page.locator("[data-legacy-field=\"fireAlarmCheckboxLabel\"]"); // @FindBy(xpath = FIRE_ALARM_CHECKBOX_XPATH + "//mat-label")
    this.fireAlarmPleaseSpecifyLabel = page.locator("[data-legacy-field=\"fireAlarmPleaseSpecifyLabel\"]"); // @FindBy(xpath = FIRE_ALARM_DIV + "//mat-card/div/label")
    this.fireAlarmsRadioButton = page.locator("xpath=//div[@id='fireProtectionDiscount']//mat-radio-button"); // @FindBy(xpath = "//div[@id='fireProtectionDiscount']//mat-radio-button")
    this.fireProtectionSystemsCheckbox = page.locator("[data-legacy-field=\"fireProtectionSystemsCheckbox\"]"); // @FindBy(xpath = FIRE_PROTECTION_CHECKBOX_XPATH)
    this.fireAlarmsToggleButtonYes = page.locator("xpath=//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Fire Alarms')]]//button[contains(.,'Yes')]"); // @FindBy(xpath = "//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Fire Alarms')]]//button[contains(.,'Yes')]")
    this.fireAlarmsToggleButtonNo = page.locator("xpath=//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Fire Alarms')]]//button[contains(.,'No')]"); // @FindBy(xpath = "//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Fire Alarms')]]//button[contains(.,'No')]")
    this.smokeAlarmsToggleButtonYes = page.locator("xpath=//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Smoke Alarms')]]//button[contains(.,'Yes')]"); // @FindBy(xpath = "//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Smoke Alarms')]]//button[contains(.,'Yes')]")
    this.smokeAlarmsToggleButtonNo = page.locator("xpath=//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Smoke Alarms')]]//button[contains(.,'No')]"); // @FindBy(xpath = "//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Smoke Alarms')]]//button[contains(.,'No')]")
    this.sprinklerSystemsToggleButtonYes = page.locator("xpath=//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Sprinkler systems')]]//button[contains(.,'Yes')]"); // @FindBy(xpath = "//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Sprinkler systems')]]//button[contains(.,'Yes')]")
    this.sprinklerSystemsToggleButtonNo = page.locator("xpath=//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Sprinkler systems')]]//button[contains(.,'No')]"); // @FindBy(xpath = "//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Sprinkler systems')]]//button[contains(.,'No')]")
    this.sprinklerSystemRadioButtonPartial = page.locator("xpath=//div[@id='fireProtectionDiscount']//mat-radio-button[contains(@id,'RADIO_BUTTON_FOR_SPRINKLER_ALARM_P')]"); // @FindBy(xpath = "//div[@id='fireProtectionDiscount']//mat-radio-button[contains(@id,'RADIO_BUTTON_FOR_SPRINKLER_ALARM_P')]")
    this.sprinklerSystemRadioButtonFull = page.locator("xpath=//div[@id='fireProtectionDiscount']//mat-radio-button[contains(@id,'RADIO_BUTTON_FOR_SPRINKLER_ALARM_F')]"); // @FindBy(xpath = "//div[@id='fireProtectionDiscount']//mat-radio-button[contains(@id,'RADIO_BUTTON_FOR_SPRINKLER_ALARM_F')]")
    this.burglarAlarmMatCheckbox = page.locator("[data-legacy-field=\"burglarAlarmMatCheckbox\"]"); // @FindBy(xpath = BURGLAR_ALARM_CHECKBOX_XPATH)
    this.burglarAlarmRadioButtonsInput = page.locator("[data-legacy-field=\"burglarAlarmRadioButtonsInput\"]"); // @FindBy(xpath = BURGLAR_ALARM_RADIO_XPATH + "//input")
    this.burglarAlarmRadioButton = page.locator("[data-legacy-field=\"burglarAlarmRadioButton\"]"); // @FindBy(xpath = BURGLAR_ALARM_RADIO_XPATH)
    this.burglarAlarmMatRadioButtons = page.locator("[data-legacy-field=\"burglarAlarmMatRadioButtons\"]"); // @FindBy(xpath = BURGLAR_ALARM_RADIO_XPATH)
    this.burglarAlarmRadioButtonsSubtext = page.locator("[data-legacy-field=\"burglarAlarmRadioButtonsSubtext\"]"); // @FindBy(xpath = BURGLAR_ALARM_RADIO_XPATH + "/following-sibling::span")
    this.burglarAlarmCheckboxLabel = page.locator("[data-legacy-field=\"burglarAlarmCheckboxLabel\"]"); // @FindBy(xpath = BURGLAR_ALARM_CHECKBOX_XPATH + "//mat-label")
    this.otherHomeProtectionFeaturesMatCheckbox = page.locator("[data-legacy-field=\"otherHomeProtectionFeaturesMatCheckbox\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_XPATH)
    this.otherHomeProtectionFeaturesCheckboxLabel = page.locator("[data-legacy-field=\"otherHomeProtectionFeaturesCheckboxLabel\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_XPATH + "//label")
    this.otherHomeProtectionFeaturesRadioButtons = page.locator("[data-legacy-field=\"otherHomeProtectionFeaturesRadioButtons\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_RADIO_BUTTONS_XPATH)
    this.otherHomeProtectionFeaturesRadioButtonLabels = page.locator("[data-legacy-field=\"otherHomeProtectionFeaturesRadioButtonLabels\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_RADIO_BUTTONS_XPATH + "//label")
    this.otherHomeProtectionSubtitleLabel = page.locator("xpath=//div[@id='homeProtectionLossPreventionDiscount']//p[contains(@class,'tui-caption')]"); // @FindBy(xpath = "//div[@id='homeProtectionLossPreventionDiscount']//p[contains(@class,'tui-caption')]")
    this.otherHomeProtectionHelpSideSheetLink = page.locator("xpath=//div[@id='homeProtectionLossPreventionDiscount']//span[@role='button']"); // @FindBy(xpath = "//div[@id='homeProtectionLossPreventionDiscount']//span[@role='button']")
    this.otherHomeProtectionHelpSideSheetTitle = page.locator("[data-legacy-field=\"otherHomeProtectionHelpSideSheetTitle\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//h1")
    this.otherHomeProtectionSideSheetEPASubTitle = page.locator("[data-legacy-field=\"otherHomeProtectionSideSheetEPASubTitle\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-epa')]/p[contains(@class,'tui-subtitle-text-2')]")
    this.otherHomeProtectionSideSheetEPAContent = page.locator("[data-legacy-field=\"otherHomeProtectionSideSheetEPAContent\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-epa')]/p[contains(@class,'tui-input-text')]")
    this.otherHomeProtectionSideSheetFortifiedHomeSubTitle = page.locator("[data-legacy-field=\"otherHomeProtectionSideSheetFortifiedHomeSubTitle\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-fh')]/p[contains(@class,'tui-subtitle-text-2')]")
    this.otherHomeProtectionSideSheetFortifiedHomeContent = page.locator("[data-legacy-field=\"otherHomeProtectionSideSheetFortifiedHomeContent\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-fh')]/p[contains(@class,'tui-input-text')]")
    this.otherHomeProtectionSideSheetConnectedHomeSubTitle = page.locator("[data-legacy-field=\"otherHomeProtectionSideSheetConnectedHomeSubTitle\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-ch')]/p[contains(@class,'tui-subtitle-text-2')]")
    this.otherHomeProtectionSideSheetConnectedHomeContent = page.locator("[data-legacy-field=\"otherHomeProtectionSideSheetConnectedHomeContent\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-ch')]/p[contains(@class,'tui-input-text')]")
    this.otherHomeProtectionSideSheetConnectedHomeContentMore = page.locator("[data-legacy-field=\"otherHomeProtectionSideSheetConnectedHomeContentMore\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-ch')]/ul[contains(@class,'tui-input-text')]")
    this.otherHomeProtectionSideSheetAutomaticGasSubTitle = page.locator("[data-legacy-field=\"otherHomeProtectionSideSheetAutomaticGasSubTitle\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-automatic-gas')]/p[contains(@class,'tui-subtitle-text-2')]")
    this.otherHomeProtectionSideSheetAutomaticGasContent = page.locator("[data-legacy-field=\"otherHomeProtectionSideSheetAutomaticGasContent\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-automatic-gas')]/p[contains(@class,'tui-input-text')]")
    this.otherHomeProtectionSideSheetWaterLeakSubTitle = page.locator("[data-legacy-field=\"otherHomeProtectionSideSheetWaterLeakSubTitle\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-water-leak')]/p[contains(@class,'tui-subtitle-text-2')]")
    this.otherHomeProtectionSideSheetWaterLeakContent = page.locator("[data-legacy-field=\"otherHomeProtectionSideSheetWaterLeakContent\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-water-leak')]/p[contains(@class,'tui-input-text')]")
    this.otherHomeProtectionSideSheetCloseButton = page.locator("[data-legacy-field=\"otherHomeProtectionSideSheetCloseButton\"]"); // @FindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//mat-icon[text()='close']")
    this.fireSprinklerCheckbox = page.locator("[data-legacy-field=\"fireSprinklerCheckbox\"]"); // @FindBy(xpath = FIRE_SPRINKLER_XPATH + "//label")
    this.alarmSystemMatCheckbox = page.locator("[data-legacy-field=\"alarmSystemMatCheckbox\"]"); // @FindBy(xpath = ALARM_SYSTEM_CHECKBOX_XPATH)
    this.alarmSystemCheckboxLabel = page.locator("[data-legacy-field=\"alarmSystemCheckboxLabel\"]"); // @FindBy(xpath = ALARM_SYSTEM_CHECKBOX_XPATH + "//label")
    this.localAlarmsLabel = page.locator("[data-legacy-field=\"localAlarmsLabel\"]"); // @FindBy(xpath = LOCAL_ALARMS_LABEL_XPATH)
    this.localAlarmButtonYes = page.locator("[data-legacy-field=\"localAlarmButtonYes\"]"); // @FindBy(xpath = LOCAL_ALARMS_LABEL_XPATH + "/following::button[contains(.,'Yes')][1]")
    this.localAlarmButtonNo = page.locator("[data-legacy-field=\"localAlarmButtonNo\"]"); // @FindBy(xpath = LOCAL_ALARMS_LABEL_XPATH + "/following::button[contains(.,'No')][1]")
    this.centralAlarmsLabel = page.locator("[data-legacy-field=\"centralAlarmsLabel\"]"); // @FindBy(xpath = CENTRAL_ALARMS_LABEL_XPATH)
    this.centralAlarmButtonYes = page.locator("[data-legacy-field=\"centralAlarmButtonYes\"]"); // @FindBy(xpath = CENTRAL_ALARMS_LABEL_XPATH + "/following::button[contains(.,'Yes')][1]")
    this.centralAlarmButtonNo = page.locator("[data-legacy-field=\"centralAlarmButtonNo\"]"); // @FindBy(xpath = CENTRAL_ALARMS_LABEL_XPATH + "/following::button[contains(.,'No')][1]")
    this.directSystemsLabel = page.locator("[data-legacy-field=\"directSystemsLabel\"]"); // @FindBy(xpath = DIRECT_SYSTEMS_LABEL_XPATH)
    this.directSystemsButtonYes = page.locator("[data-legacy-field=\"directSystemsButtonYes\"]"); // @FindBy(xpath = DIRECT_SYSTEMS_LABEL_XPATH + "/following::button[contains(.,'Yes')][1]")
    this.directSystemsButtonNo = page.locator("[data-legacy-field=\"directSystemsButtonNo\"]"); // @FindBy(xpath = DIRECT_SYSTEMS_LABEL_XPATH + "/following::button[contains(.,'No')][1]")
    this.waterProtectionMatCheckbox = page.locator("[data-legacy-field=\"waterProtectionMatCheckbox\"]"); // @FindBy(xpath = WATER_PROTECTION_CHECKBOX_XPATH)
    this.waterProtectionInputCheckbox = page.locator("[data-legacy-field=\"waterProtectionInputCheckbox\"]"); // @FindBy(xpath = WATER_PROTECTION_INPUT_CHECKBOX_XPATH)
    this.waterProtectionCheckboxLabel = page.locator("[data-legacy-field=\"waterProtectionCheckboxLabel\"]"); // @FindBy(xpath = WATER_PROTECTION_CHECKBOX_XPATH + "//mat-label")
    this.waterProtectionRadioButtons = page.locator("[data-legacy-field=\"waterProtectionRadioButtons\"]"); // @FindBy(xpath = WATER_PROTECTION_RADIO_XPATH + "//input")
    this.waterProtectionRadioButton = page.locator("[data-legacy-field=\"waterProtectionRadioButton\"]"); // @FindBy(xpath = WATER_PROTECTION_RADIO_XPATH)
    this.waterProtectionMatRadioButtons = page.locator("[data-legacy-field=\"waterProtectionMatRadioButtons\"]"); // @FindBy(xpath = WATER_PROTECTION_RADIO_XPATH)
    this.fortifiedHomeMatCheckbox = page.locator("[data-legacy-field=\"fortifiedHomeMatCheckbox\"]"); // @FindBy(xpath = FORTIFIED_HOME_CHECKBOX_XPATH)
    this.fortifiedHomeCheckboxInput = page.locator("[data-legacy-field=\"fortifiedHomeCheckboxInput\"]"); // @FindBy(xpath = FORTIFIED_HOME_CHECKBOX_INPUT_XPATH)
    this.fortifiedHomeCheckboxLabel = page.locator("[data-legacy-field=\"fortifiedHomeCheckboxLabel\"]"); // @FindBy(xpath = FORTIFIED_HOME_CHECKBOX_XPATH + "//mat-label")
    this.fortifiedHomeCertRadioButtons = page.locator("[data-legacy-field=\"fortifiedHomeCertRadioButtons\"]"); // @FindBy(xpath = FORTIFIED_HOME_RADIO_XPATH + "//input")
    this.fortifiedHomeCertRadioButton = page.locator("[data-legacy-field=\"fortifiedHomeCertRadioButton\"]"); // @FindBy(xpath = FORTIFIED_HOME_RADIO_XPATH)
    this.fortifiedHomeCertMatRadioButtons = page.locator("[data-legacy-field=\"fortifiedHomeCertMatRadioButtons\"]"); // @FindBy(xpath = FORTIFIED_HOME_RADIO_XPATH)
    this.fortifiedHomePleaseSpecifyLabel = page.locator("[data-legacy-field=\"fortifiedHomePleaseSpecifyLabel\"]"); // @FindBy(xpath = FORTIFIED_HOME_DIV_XPATH + "//div[contains(@class,'additional-discounts-card')]//mat-card/div/label")
    this.wroughtIronBarsInputCheckbox = page.locator("[data-legacy-field=\"wroughtIronBarsInputCheckbox\"]"); // @FindBy(xpath = WROUGHT_IRON_BARS_CHECKBOX_XPATH + "//input")
    this.wroughtIronBarsMatCheckbox = page.locator("[data-legacy-field=\"wroughtIronBarsMatCheckbox\"]"); // @FindBy(xpath = WROUGHT_IRON_BARS_CHECKBOX_XPATH)
    this.wroughtIronBarsCheckboxLabel = page.locator("[data-legacy-field=\"wroughtIronBarsCheckboxLabel\"]"); // @FindBy(xpath = WROUGHT_IRON_BARS_CHECKBOX_XPATH + "//mat-label")
    this.previousInsuranceInputCheckbox = page.locator("[data-legacy-field=\"previousInsuranceInputCheckbox\"]"); // @FindBy(xpath = PREVIOUS_INSURANCE_CHECKBOX_XPATH + "//input")
    this.previousInsuranceMatCheckbox = page.locator("[data-legacy-field=\"previousInsuranceMatCheckbox\"]"); // @FindBy(xpath = PREVIOUS_INSURANCE_CHECKBOX_XPATH)
    this.previousInsuranceCheckboxLabel = page.locator("[data-legacy-field=\"previousInsuranceCheckboxLabel\"]"); // @FindBy(xpath = PREVIOUS_INSURANCE_CHECKBOX_XPATH + "//mat-label")
    this.previousInsuranceCheckboxSubtext = page.locator("xpath=//div[@id='transferDiscount']//div[contains(@class,'transfer-discount')]"); // @FindBy(xpath="//div[@id='transferDiscount']//div[contains(@class,'transfer-discount')]")
    this.previousInsuranceRadioButtons = page.locator("[data-legacy-field=\"previousInsuranceRadioButtons\"]"); // @FindBy(xpath = PREVIOUS_INSURANCE_RADIO_BUTTON_XPATH)
    this.homeTransferDiscountHeader = page.locator("xpath=//app-home-transfer-discount//h2"); // @FindBy(xpath = "//app-home-transfer-discount//h2")
    this.homeTransferDiscountSubheader = page.locator("xpath=//app-home-transfer-discount//div[contains(@class,'tui-input-text')]"); // @FindBy(xpath = "//app-home-transfer-discount//div[contains(@class,'tui-input-text')]")
    this.buttonCancelHomeTransferDiscount = page.locator("xpath=//app-home-transfer-discount//button[text()='Cancel']"); // @FindBy(xpath = "//app-home-transfer-discount//button[text()='Cancel']")
    this.buttonSaveHomeTransferDiscount = page.locator("xpath=//app-home-transfer-discount//button[text()='Save']"); // @FindBy(xpath = "//app-home-transfer-discount//button[text()='Save']")
    this.homeTransferDiscountHeaderDivider = page.locator("xpath=//app-home-transfer-discount//mat-divider"); // @FindBy(xpath = "//app-home-transfer-discount//mat-divider")
    this.getHomeTransferDiscountButtonContainer = page.locator("xpath=//app-home-transfer-discount//div[contains(@class,'transfer-discount-button-container')]"); // @FindBy(xpath = "//app-home-transfer-discount//div[contains(@class,'transfer-discount-button-container')]")
    this.homeDiscountSelected = page.locator("xpath=//app-additional-info//div[contains(@class,'transfer-discount-selected-text')]/p"); // @FindBy(xpath="//app-additional-info//div[contains(@class,'transfer-discount-selected-text')]/p")
    this.editHomeDiscountSelected = page.locator("xpath=//app-additional-info//div[contains(@class,'transfer-discount-selected-text')]/button"); // @FindBy(xpath="//app-additional-info//div[contains(@class,'transfer-discount-selected-text')]/button")
    this.buttonCloseHomeTransferDiscount = page.locator("xpath=//app-home-transfer-discount//button[.='close']"); // @FindBy(xpath = "//app-home-transfer-discount//button[.='close']")
    this.wildfireRiskReductionCheckboxLabel = page.locator("[data-legacy-field=\"wildfireRiskReductionCheckboxLabel\"]"); // @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//label")
    this.wildfireRiskReductionMatCheckbox = page.locator("[data-legacy-field=\"wildfireRiskReductionMatCheckbox\"]"); // @FindBy(xpath = WILDFIRE_RISK_REDUCTION_CHECKBOX_XPATH)
    this.wildfireRiskReductionMatCheckboxes = page.locator("[data-legacy-field=\"wildfireRiskReductionMatCheckboxes\"]"); // @FindBy(xpath = WILDFIRE_RISK_REDUCTION_CHECKBOXES_XPATH)
    this.wildfireRiskReductionCheckboxesLabel = page.locator("xpath=//div[@id='wildfireDiscount']//mat-card//label[@class='tui-caption']"); // @FindBy(xpath = "//div[@id='wildfireDiscount']//mat-card//label[@class='tui-caption']")
    this.electricalSystemCheckbox = page.locator("[data-legacy-field=\"electricalSystemCheckbox\"]"); // @FindBy(xpath = ELECTRICAL_SYSTEM_UPDATED_CHECKBOX_XPATH)
    this.electricalSystemCheckboxLabel = page.locator("[data-legacy-field=\"electricalSystemCheckboxLabel\"]"); // @FindBy(xpath = ELECTRICAL_SYSTEM_UPDATED_CHECKBOX_XPATH + "//mat-label")
    this.electricalSystemCheckboxInfoText = page.locator("[data-legacy-field=\"electricalSystemCheckboxInfoText\"]"); // @FindBy(xpath = ELECTRICAL_SYSTEM_UPDATED_CHECKBOX_XPATH + "/following-sibling::div")
    this.electricalSystemYearInput = page.locator("[data-legacy-field=\"electricalSystemYearInput\"]"); // @FindBy(xpath = ELECTRICAL_SYSTEM_UPDATED_XPATH + "//input[@aria-label='Select the year']")
    this.electricalSystemYearLabel = page.locator("[data-legacy-field=\"electricalSystemYearLabel\"]"); // @FindBy(xpath = ELECTRICAL_SYSTEM_UPDATED_XPATH + "//mat-card//p")
    this.plumbingSystemCheckbox = page.locator("[data-legacy-field=\"plumbingSystemCheckbox\"]"); // @FindBy(xpath = PLUMBING_SYSTEM_UPDATED_CHECKBOX_XPATH)
    this.plumbingSystemCheckboxLabel = page.locator("[data-legacy-field=\"plumbingSystemCheckboxLabel\"]"); // @FindBy(xpath = PLUMBING_SYSTEM_UPDATED_CHECKBOX_XPATH + "//mat-label")
    this.plumbingSystemCheckboxInfoText = page.locator("[data-legacy-field=\"plumbingSystemCheckboxInfoText\"]"); // @FindBy(xpath = PLUMBING_SYSTEM_UPDATED_CHECKBOX_XPATH + "/following-sibling::div")
    this.plumbingSystemYearInput = page.locator("[data-legacy-field=\"plumbingSystemYearInput\"]"); // @FindBy(xpath = PLUMBING_SYSTEM_UPDATED_XPATH + "//input[@aria-label='Select the year']")
    this.plumbingSystemYearLabel = page.locator("[data-legacy-field=\"plumbingSystemYearLabel\"]"); // @FindBy(xpath = PLUMBING_SYSTEM_UPDATED_XPATH + "//mat-card//p")
    this.plumbingSystemReplacedYes = page.locator("[data-legacy-field=\"plumbingSystemReplacedYes\"]"); // @FindBy(xpath = PLUMBING_SYSTEM_REPLACED_20_XPATH + "//button[.='Yes']")
    this.plumbingSystemReplacedNo = page.locator("[data-legacy-field=\"plumbingSystemReplacedNo\"]"); // @FindBy(xpath = PLUMBING_SYSTEM_REPLACED_20_XPATH + "//button[.='No']")
    this.plumbingSystemReplacedMatToggleYes = page.locator("[data-legacy-field=\"plumbingSystemReplacedMatToggleYes\"]"); // @FindBy(xpath = PLUMBING_SYSTEM_REPLACED_20_XPATH + "//mat-button-toggle[.='Yes']")
    this.plumbingSystemReplacedMatToggleNo = page.locator("[data-legacy-field=\"plumbingSystemReplacedMatToggleNo\"]"); // @FindBy(xpath = PLUMBING_SYSTEM_REPLACED_20_XPATH + "//mat-button-toggle[.='No']")
    this.hvacSystemCheckbox = page.locator("[data-legacy-field=\"hvacSystemCheckbox\"]"); // @FindBy(xpath = HVAC_SYSTEM_UPDATED_CHECKBOX_XPATH)
    this.hvacSystemCheckboxLabel = page.locator("[data-legacy-field=\"hvacSystemCheckboxLabel\"]"); // @FindBy(xpath = HVAC_SYSTEM_UPDATED_CHECKBOX_XPATH + "//mat-label")
    this.hvacSystemCheckboxInfoText = page.locator("[data-legacy-field=\"hvacSystemCheckboxInfoText\"]"); // @FindBy(xpath = HVAC_SYSTEM_UPDATED_CHECKBOX_XPATH + "/following-sibling::div")
    this.hvacSystemYearInput = page.locator("[data-legacy-field=\"hvacSystemYearInput\"]"); // @FindBy(xpath = HVAC_SYSTEM_UPDATED_XPATH + "//input[@aria-label='Select the year']")
    this.hvacSystemYearLabel = page.locator("[data-legacy-field=\"hvacSystemYearLabel\"]"); // @FindBy(xpath = HVAC_SYSTEM_UPDATED_XPATH + "//mat-card//p")
    this.nonSmokerMatCheckbox = page.locator("[data-legacy-field=\"nonSmokerMatCheckbox\"]"); // @FindBy(xpath = NON_SMOKER_XPATH)
    this.centralFireAlarmMatCheckbox = page.locator("[data-legacy-field=\"centralFireAlarmMatCheckbox\"]"); // @FindBy(xpath = CENTRAL_FIRE_ALARM_XPATH)
    this.centralFireAlarmCheckboxLabel = page.locator("[data-legacy-field=\"centralFireAlarmCheckboxLabel\"]"); // @FindBy(xpath = CENTRAL_FIRE_ALARM_XPATH + "//label")
    this.centralBurglarAlarmMatCheckbox = page.locator("[data-legacy-field=\"centralBurglarAlarmMatCheckbox\"]"); // @FindBy(xpath = CENTRAL_BURGLAR_ALARM_XPATH)
    this.centralBurglarAlarmCheckboxLabel = page.locator("[data-legacy-field=\"centralBurglarAlarmCheckboxLabel\"]"); // @FindBy(xpath = CENTRAL_BURGLAR_ALARM_XPATH + "//label")
    this.pleaseSpecifyLabelInRedColor = page.locator("xpath=//label[contains(@class,'tui-error')]"); // @FindBy(xpath = "//label[contains(@class,'tui-error')]")
    this.pleaseSelectAnOptionErrors = page.locator("xpath=//mat-error[contains(text(),'Please select an option.')]"); // @FindBy(xpath = "//mat-error[contains(text(),'Please select an option.')]")
    this.pleaseProvideTheYearError = page.locator("xpath=//mat-error[contains(text(),'Please provide the year.')]"); // @FindBy(xpath = "//mat-error[contains(text(),'Please provide the year.')]")
    this.invalidYearError = page.locator("xpath=//mat-error[contains(text(),'Invalid year')]"); // @FindBy(xpath = "//mat-error[contains(text(),'Invalid year')]")
    this.roofYearRangeError = page.locator("xpath=//mat-error[contains(text(),'Enter valid roof year')]"); // @FindBy(xpath = "//mat-error[contains(text(),'Enter valid roof year')]")
    this.populatedFortifiedDesignationVal = page.locator("xpath=//div[@id='fortifiedHomeDiscount']//span[contains(@class,'tui-body-text-1')]"); // @FindBy(xpath = "//div[@id='fortifiedHomeDiscount']//span[contains(@class,'tui-body-text-1')]")
    this.residenceFloorSection = page.locator("[data-legacy-field=\"residenceFloorSection\"]"); // @FindBy(xpath = FLOOR_RESIDENCE_XPATH)
    this.residenceFloorCheckbox = page.locator("[data-legacy-field=\"residenceFloorCheckbox\"]"); // @FindBy(xpath = FLOOR_RESIDENCE_XPATH + "//mat-checkbox")
    this.residenceFloorInfoLabel = page.locator("[data-legacy-field=\"residenceFloorInfoLabel\"]"); // @FindBy(xpath = FLOOR_RESIDENCE_XPATH + "//*[contains(@class,'label')]")
    this.residenceFloorInfoDescription = page.locator("[data-legacy-field=\"residenceFloorInfoDescription\"]"); // @FindBy(xpath = FLOOR_RESIDENCE_XPATH + "//*[contains(@class,'floorResidence_checkbox-description')]")
    this.ulRoofMatCheckbox = page.locator("[data-legacy-field=\"ulRoofMatCheckbox\"]"); // @FindBy(xpath = UL_ROOF_CHECKBOX + "//mat-checkbox")
    this.ulRoofCheckboxLabel = page.locator("[data-legacy-field=\"ulRoofCheckboxLabel\"]"); // @FindBy(xpath = UL_ROOF_CHECKBOX + "//mat-label")
    this.ulRoofDescriptionLabel = page.locator("[data-legacy-field=\"ulRoofDescriptionLabel\"]"); // @FindBy(xpath = UL_ROOF_CHECKBOX + "//label[@id='ulDescription']")
    this.ulRoofRadioButton = page.locator("[data-legacy-field=\"ulRoofRadioButton\"]"); // @FindBy(xpath = UL_ROOF_CHECKBOX + "//mat-radio-group")
    this.ulRoofMatRadioButtons = page.locator("[data-legacy-field=\"ulRoofMatRadioButtons\"]"); // @FindBy(xpath = UL_ROOF_CHECKBOX + "//mat-radio-button")
    this.ulRoofRadioButtonLabels = page.locator("[data-legacy-field=\"ulRoofRadioButtonLabels\"]"); // @FindBy(xpath = UL_ROOF_CHECKBOX + "//mat-radio-button//label")
  }
}
