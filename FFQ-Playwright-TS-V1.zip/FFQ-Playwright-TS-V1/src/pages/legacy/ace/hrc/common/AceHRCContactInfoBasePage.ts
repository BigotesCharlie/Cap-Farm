// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCContactInfoBasePage. */
export class AceHRCContactInfoBasePage extends CoreBasePage {
  public readonly lastStepBeforeYourPageHeader: Locator;
  public readonly fewMoreQuestionBeforeYourQuoteHeader: Locator;
  public readonly policyStartDateOrEstimatedClosingDateTitle: Locator;
  public readonly policyStartDateOrEstimatedClosingDatePlaceHolderText: Locator;
  public readonly policyStartDateOrEstimatedClosingDateInputField: Locator;
  public readonly earlyDiscountOrEstimatedClosingDateInfoTitle: Locator;
  public readonly earlyDiscountOrEstimatedClosingDateInfoDescription: Locator;
  public readonly earlyShoppingInfoIcon: Locator;
  public readonly infoModalTitle: Locator;
  public readonly infoModalText: Locator;
  public readonly infoModalButtonClose: Locator;
  public readonly earlyDiscountCongratulationMessage: Locator;
  public readonly earlyDiscountCongratulationGreenCheck: Locator;
  public readonly policyStartOrEstimatedClosingDateDatePicker: Locator;
  public readonly datePickerToggleIcon: Locator;
  public readonly policyStartOrEstimatedClosingDateInputField: Locator;
  public readonly policyStartOrEstimatedClosingDateDateError: Locator;
  public readonly selectedDateInDatePickerPopUp: Locator;
  public readonly selectedMonthYearHeaderInDatePickerPopUp: Locator;
  public readonly mailingAddressLabel: Locator;
  public readonly defaultMailingAddressRadioButton: Locator;
  public readonly defaultMailingAddressRadioButtonLabel: Locator;
  public readonly otherMailingAddressRadioButton: Locator;
  public readonly otherMailingAddressRadioButtonLabel: Locator;
  public readonly mailingAddressInputLabel: Locator;
  public readonly mailingAddressError: Locator;
  public readonly apartmentNumberInputField: Locator;
  public readonly apartmentInputLabel: Locator;
  public readonly invalidAptError: Locator;
  public readonly cityInputField: Locator;
  public readonly cityInputLabel: Locator;
  public readonly cityError: Locator;
  public readonly stateDropDown: Locator;
  public readonly stateDropDownLabel: Locator;
  public readonly stateError: Locator;
  public readonly zipCodeInputField: Locator;
  public readonly zipCodeInputLabel: Locator;
  public readonly zipCodeError: Locator;
  public readonly otherMailingAddressInputField: Locator;
  public readonly otherMailingAddressUnitInputField: Locator;
  public readonly otherMailingAddressCityInputField: Locator;
  public readonly otherMailingAddressStateDropdownField: Locator;
  public readonly otherMailingAddressZipCodeInputField: Locator;
  public readonly listOfAllTheStatesInOtherMailingAddressStateDropDown: Locator;
  public readonly personalInfoLabel: Locator;
  public readonly emailAddressFieldLabel: Locator;
  public readonly emailAddressError: Locator;
  public readonly mobilePhoneFieldLabel: Locator;
  public readonly phoneNumberInput: Locator;
  public readonly phoneNumberError: Locator;
  public readonly textMeALinkCheckboxLabel: Locator;
  public readonly textAuthorization: Locator;
  public readonly termsConditionLink: Locator;
  public readonly pageErrorMessage: Locator;
  public readonly pageFooterDisclaimer: Locator;
  public readonly linkAssociatedEntities: Locator;
  public readonly electronicSignHeader: Locator;
  public readonly ourCompaniesHeader: Locator;
  public readonly pageFooterDisclaimerEsign: Locator;
  public readonly linkDisclaimerEsign: Locator;
  public readonly mobileDisclaimerAddition: Locator;
  public readonly agreeAndSubmitButton: Locator;
  public readonly saveQuoteButton: Locator;
  public readonly progressSavedSection: Locator;
  public readonly emailAddressInput: Locator;
  public readonly mailingAddressInputField: Locator;
  public readonly bundleSaveHeadingNote: Locator;
  public readonly bundleAndSaveSection: Locator;
  public readonly bundleSaveHeading: Locator;
  public readonly otherDetailsTitle: Locator;
  public readonly bundleDiscountTitle: Locator;
  public readonly saveBundleMatCheckboxes: Locator;
  public readonly saveBundleCheckboxesText: Locator;
  public readonly saveBundleMatCheckboxInputs: Locator;
  public readonly autoBundleIcon: Locator;
  public readonly homeBundleIcon: Locator;
  public readonly lifeBundleIcon: Locator;
  public readonly umbrellaBundleIcon: Locator;
  public readonly multiPolicyCEAIcon: Locator;
  public readonly businessBundleIcon: Locator;
  public readonly boatsBundleIcon: Locator;
  public readonly offRoadVehicleBundleIcon: Locator;
  public readonly motorHomeBundleIcon: Locator;
  public readonly saveBundleCongratulationMessage: Locator;
  public readonly bundleAndSaveTipHeader: Locator;
  public readonly bundleAndSaveTipDescription: Locator;
  public readonly saveBundleInfoIcon: Locator;
  public readonly viewAdditionProductsLink: Locator;
  public readonly fireHydrantSection: Locator;
  public readonly fireHydrantSectionTitle: Locator;
  public readonly fireHydrantSectionLabel: Locator;
  public readonly fireHydrantQuestionsText: Locator;
  public readonly fireHydrantQuestion1label: Locator;
  public readonly fireHydrantQuestion2label: Locator;
  public readonly wildfireRiskReductionOptions: Locator;
  public readonly wildfireRiskReductionSpanCA: Locator;
  public readonly wildfireRiskMatButtonToggleYes: Locator;
  public readonly wildfireRiskMatButtonToggleNo: Locator;
  public readonly wildfireRiskButtonToggleYes: Locator;
  public readonly wildfireRiskButtonToggleNo: Locator;
  public readonly editWildfireRiskReduction: Locator;
  public readonly wildfireRiskReductionSubtextCA: Locator;
  public readonly closeWildfireSideSheet: Locator;
  public readonly saveButtonWildfireRisk: Locator;
  public readonly dialogNoChanges: Locator;
  public readonly buttonNoChangesOk: Locator;
  public readonly wildfireRiskReductionSideSheet: Locator;
  public readonly wildfireRiskReductionSideSheetTitle: Locator;
  public readonly wildfireRiskReductionSideSheetDivider: Locator;
  public readonly wildfireRiskReductionSideSheetSubtitle: Locator;
  public readonly wildfireRiskReductionSideSheetDivider1: Locator;
  public readonly wildfireRiskReductionSideSheetSubtitle2: Locator;
  public readonly wildfireRiskReductionSideSheetDivider2: Locator;
  public readonly wildfireRiskReductionSideSheetSection2Subtitle: Locator;
  public readonly wildfireRiskReductionSideSheetCheckboxes: Locator;
  public readonly wildfireRiskReductionSideSheetCheckboxLabels: Locator;
  public readonly residenceFloorSection: Locator;
  public readonly residenceFloorSectionSubtitle: Locator;
  public readonly residenceFloorCheckbox: Locator;
  public readonly residenceFloorInfoLabel: Locator;
  public readonly residenceFloorInfoDescription: Locator;
  public readonly contactInfoDisclaimer: Locator;
  public readonly primaryInsuranceGroupTitle: Locator;
  public readonly selectInsuranceGroupTitle: Locator;
  public readonly selectAllCheckboxLabel: Locator;
  public readonly farmersCheckboxLabel: Locator;
  public readonly BWCheckboxLabel: Locator;
  public readonly farmersLifeCheckboxLabel: Locator;
  public readonly foremostCheckboxLabel: Locator;
  public readonly selectAllCheckboxSubLabel: Locator;
  public readonly farmersCheckboxSubLabel: Locator;
  public readonly BWCheckboxSubLabel: Locator;
  public readonly farmersLifeCheckboxSubLabel: Locator;
  public readonly foremostCheckboxSubLabel: Locator;
  public readonly primaryInsuredName: Locator;
  public readonly individualBrandCheckboxes: Locator;
  public readonly allBrandsCheckbox: Locator;
  public readonly continueButtonBundleContactInfoPage: Locator;
  public readonly genderButtons: Locator;
  public readonly genderButton: Locator;
  public readonly firstNameInputBox: Locator;
  public readonly firstNameAriaLabelText: Locator;
  public readonly lastNameInputBox: Locator;
  public readonly lastNameAriaLabelText: Locator;
  public readonly dateOfBirthInputBox: Locator;
  public readonly dateOfBirthAriaLabelText: Locator;
  public readonly mmddyyyyHint: Locator;
  public readonly spouseInputFieldSection: Locator;
  public readonly spouseElements: Locator;
  public readonly spouseFirstNameInputBox: Locator;
  public readonly spouseLastNameInputBox: Locator;
  public readonly spouseDateOfBirthInputBox: Locator;
  public readonly priorOrCurrentAddressCityInputBox: Locator;
  public readonly priorOrCurrentAddressStateSelect: Locator;
  public readonly priorOrCurrentAddressZipInputBox: Locator;
  public readonly aboutYouHeader: Locator;
  public readonly spouseGenderButtons: Locator;
  public readonly marriedOrInDomesticRelationMatCheckbox: Locator;
  public readonly marriedOrInDomesticRelationCheckboxInput: Locator;
  public readonly marriedOrInDomesticRelationCheckBoxDescription: Locator;
  public readonly marriedOrInDomesticRelationLabel: Locator;
  public readonly currentFormerEmployedHeaderPersonalInfoDiv: Locator;
  public readonly currentFormerEmployedHeaderSpouseDiv: Locator;
  public readonly eligibleOccupationSavingsPersonalInfoDiv: Locator;
  public readonly eligibleOccupationSavingsSpouseDiv: Locator;
  public readonly eligibleOccupationButtonPersonalInfoDiv: Locator;
  public readonly eligibleOccupationButtonSpouseDiv: Locator;
  public readonly eligibleOccupationHeader: Locator;
  public readonly occupationRadioButtons: Locator;
  public readonly firstOccupationRadioButton: Locator;
  public readonly currentlyEmployedOrRetiredQuestion: Locator;
  public readonly currentlyEmployedOrRetiredToggleButtons: Locator;
  public readonly currentlyEmployedOrRetiredToggleButton: Locator;
  public readonly currentlyEmployedOrRetiredToggleButtonLabel: Locator;
  public readonly closeIcon: Locator;
  public readonly closeButton: Locator;
  public readonly occupationRetiredCheckBox: Locator;
  public readonly retiredFormerlyEmployedLabel: Locator;
  public readonly eligibleOccupationAddButton: Locator;
  public readonly eligibleOccupationCancelButton: Locator;
  public readonly removeOccupationLinkPrimaryApplicant: Locator;
  public readonly removeOccupationLinkSpouse: Locator;
  public readonly removeOccupationHeaderInModalBox: Locator;
  public readonly keepOccupationButton: Locator;
  public readonly removeOccupationButton: Locator;
  public readonly removeOccupationQuestion: Locator;
  public readonly homeOccupationSelectedMessagePersonalInfo: Locator;
  public readonly homeOccupationSelectedMessageSpouseDiv: Locator;
  public readonly occupationPrimary: Locator;
  public readonly occupationSpouse: Locator;
  public readonly selectedOccupation: Locator;
  public readonly closeIconInAddressInputBox: Locator;
  public readonly unitInputBox: Locator;
  public readonly unitNumberPlaceholderText: Locator;
  public readonly cityPlaceholderText: Locator;
  public readonly statePlaceholderText: Locator;
  public readonly zipPlaceholderText: Locator;
  public readonly optionalUnitNumberHint: Locator;
  public readonly priorAddressPlaceHolderText: Locator;
  public readonly priorOrCurrentHomeAddressLabel: Locator;
  public readonly currentAddressPlaceHolderText: Locator;

  public constructor(page: Page) {
    super(page);
    this.lastStepBeforeYourPageHeader = page.locator("h1[class*='tui-h1']"); // @FindBy(css = "h1[class*='tui-h1']")
    this.fewMoreQuestionBeforeYourQuoteHeader = page.locator("xpath=//div[contains(@class,'contact-info-heading-note')]"); // @FindBy(xpath = "//div[contains(@class,'contact-info-heading-note')]")
    this.policyStartDateOrEstimatedClosingDateTitle = page.locator("xpath=//div[contains(@class,'tooltip-section')]//div"); // @FindBy(xpath = "//div[contains(@class,'tooltip-section')]//div")
    this.policyStartDateOrEstimatedClosingDatePlaceHolderText = page.locator("xpath=//app-contact-info//app-date-picker//mat-label"); // @FindBy(xpath = "//app-contact-info//app-date-picker//mat-label")
    this.policyStartDateOrEstimatedClosingDateInputField = page.locator("xpath=//app-contact-info//app-date-picker//input[contains(@class,'text-field-autofill')]"); // @FindBy(xpath = "//app-contact-info//app-date-picker//input[contains(@class,'text-field-autofill')]")
    this.earlyDiscountOrEstimatedClosingDateInfoTitle = page.locator("xpath=//div[@id='policyStartDateDiv']//div[@class='discount-info']//div//div"); // @FindBy(xpath = "//div[@id='policyStartDateDiv']//div[@class='discount-info']//div//div")
    this.earlyDiscountOrEstimatedClosingDateInfoDescription = page.locator("xpath=//div[@id='policyStartDateDiv']//div[@class='discount-info']//div//p"); // @FindBy(xpath = "//div[@id='policyStartDateDiv']//div[@class='discount-info']//div//p")
    this.earlyShoppingInfoIcon = page.locator("xpath=//div[@id='policyStartDateDiv']//mat-icon[@id='policyStartDateDiv_info']"); // @FindBy(xpath = "//div[@id='policyStartDateDiv']//mat-icon[@id='policyStartDateDiv_info']")
    this.infoModalTitle = page.locator("xpath=//app-model-info-box//h1"); // @FindBy(xpath = "//app-model-info-box//h1")
    this.infoModalText = page.locator("xpath=//app-model-info-box//div/p[contains(@class,'model-caption-text')]"); // @FindBy(xpath = "//app-model-info-box//div/p[contains(@class,'model-caption-text')]")
    this.infoModalButtonClose = page.locator("xpath=//app-model-info-box//mat-icon[text()='close']"); // @FindBy(xpath = "//app-model-info-box//mat-icon[text()='close']")
    this.earlyDiscountCongratulationMessage = page.locator("#auto-contact-info-early-shopper-message-container>div"); // @FindBy(css = "#auto-contact-info-early-shopper-message-container>div")
    this.earlyDiscountCongratulationGreenCheck = page.locator("xpath=//div[@id='policyContainerDiv']//mat-icon[@alt='Congratulations']"); // @FindBy(xpath = "//div[@id='policyContainerDiv']//mat-icon[@alt='Congratulations']")
    this.policyStartOrEstimatedClosingDateDatePicker = page.locator("[data-legacy-field=\"policyStartOrEstimatedClosingDateDatePicker\"]"); // @FindBy(xpath = POLICY_START_DATE_XPATH)
    this.datePickerToggleIcon = page.locator("[data-legacy-field=\"datePickerToggleIcon\"]"); // @FindBy(xpath = DATEPICKER_TOGGLE_ICON_XPATH)
    this.policyStartOrEstimatedClosingDateInputField = page.locator("xpath=//app-date-picker//input[contains(@class,'form-field-autofill')]"); // @FindBy(xpath = "//app-date-picker//input[contains(@class,'form-field-autofill')]")
    this.policyStartOrEstimatedClosingDateDateError = page.locator("xpath=//div[@id='policyStartDateDiv']//mat-error"); // @FindBy(xpath = "//div[@id='policyStartDateDiv']//mat-error")
    this.selectedDateInDatePickerPopUp = page.locator("xpath=//button[descendant::*[contains(@class,'selected')]]"); // @FindBy(xpath = "//button[descendant::*[contains(@class,'selected')]]")
    this.selectedMonthYearHeaderInDatePickerPopUp = page.locator("xpath=//div[contains(@class,'mat-calendar-header')]//button[contains(@class,'mat-calendar-period-button')]"); // @FindBy(xpath = "//div[contains(@class,'mat-calendar-header')]//button[contains(@class,'mat-calendar-period-button')]")
    this.mailingAddressLabel = page.locator("xpath=//div[@id='mailingAddressDiv']//*[contains(@class,'tui-field-label-text')]"); // @FindBy(xpath = "//div[@id='mailingAddressDiv']//*[contains(@class,'tui-field-label-text')]")
    this.defaultMailingAddressRadioButton = page.locator("xpath=//mat-radio-button[@id='mailingAddressDiv_1']"); // @FindBy(xpath = "//mat-radio-button[@id='mailingAddressDiv_1']")
    this.defaultMailingAddressRadioButtonLabel = page.locator("xpath=//div[@id='mailingAddressDiv']//mat-radio-button[1]"); // @FindBy(xpath = "//div[@id='mailingAddressDiv']//mat-radio-button[1]")
    this.otherMailingAddressRadioButton = page.locator("xpath=//input[@id='mailingAddressDiv_2-input']"); // @FindBy(xpath = "//input[@id='mailingAddressDiv_2-input']")
    this.otherMailingAddressRadioButtonLabel = page.locator("xpath=//mat-radio-button[contains(.,'Other mailing address')]"); // @FindBy(xpath = "//mat-radio-button[contains(.,'Other mailing address')]")
    this.mailingAddressInputLabel = page.locator("xpath=//div[@id='formField_address']//mat-label"); // @FindBy(xpath = "//div[@id='formField_address']//mat-label")
    this.mailingAddressError = page.locator("xpath=//div[@id='formField_address']//mat-error"); // @FindBy(xpath = "//div[@id='formField_address']//mat-error")
    this.apartmentNumberInputField = page.locator("input[aria-label='Apartment number (optional)']"); // @FindBy(css = "input[aria-label='Apartment number (optional)']")
    this.apartmentInputLabel = page.locator("xpath=//div[@id='mailingAddressDiv_apartment']//mat-label"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_apartment']//mat-label")
    this.invalidAptError = page.locator("xpath=//mat-form-field[@id='auto-contact-info-apartment__input-field']//mat-error"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-info-apartment__input-field']//mat-error")
    this.cityInputField = page.locator("input[aria-label='City']"); // @FindBy(css = "input[aria-label='City']")
    this.cityInputLabel = page.locator("xpath=//div[@id='mailingAddressDiv_city']//mat-label"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_city']//mat-label")
    this.cityError = page.locator("xpath=//div[@id='mailingAddressDiv_city']//mat-error"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_city']//mat-error")
    this.stateDropDown = page.locator("mat-select[aria-label='State']"); // @FindBy(css = "mat-select[aria-label='State']")
    this.stateDropDownLabel = page.locator("xpath=//div[@id='mailingAddressDiv_state']//mat-label"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-label")
    this.stateError = page.locator("xpath=//div[@id='mailingAddressDiv_state']//mat-error/div"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-error/div")
    this.zipCodeInputField = page.locator("input[aria-label='Zip code']"); // @FindBy(css = "input[aria-label='Zip code']")
    this.zipCodeInputLabel = page.locator("xpath=//div[@id='mailingAddressDiv_zipCode']//mat-label"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//mat-label")
    this.zipCodeError = page.locator("xpath=//div[@id='mailingAddressDiv_zipCode']//mat-error/div"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//mat-error/div")
    this.otherMailingAddressInputField = page.locator("xpath=//address-autocomplete-input//input"); // @FindBy(xpath = "//address-autocomplete-input//input")
    this.otherMailingAddressUnitInputField = page.locator("xpath=//div[@id='mailingAddressDiv_apartment']//input"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_apartment']//input")
    this.otherMailingAddressCityInputField = page.locator("xpath=//div[@id='mailingAddressDiv_city']//input"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_city']//input")
    this.otherMailingAddressStateDropdownField = page.locator("xpath=//div[@id='mailingAddressDiv_state']//mat-select"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-select")
    this.otherMailingAddressZipCodeInputField = page.locator("xpath=//div[@id='mailingAddressDiv_zipCode']//input"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//input")
    this.listOfAllTheStatesInOtherMailingAddressStateDropDown = page.locator("xpath=//span[@class='mat-option-text']"); // @FindBy(xpath = "//span[@class='mat-option-text']")
    this.personalInfoLabel = page.locator("xpath=//div[@id='flex-field-emailAddress_contactInfo']/p"); // @FindBy(xpath = "//div[@id='flex-field-emailAddress_contactInfo']/p")
    this.emailAddressFieldLabel = page.locator("xpath=//div[@class='email-address']//label"); // @FindBy(xpath = "//div[@class='email-address']//label")
    this.emailAddressError = page.locator("xpath=//div[@id='flex-field-emailAddress_contactInfo']//mat-error"); // @FindBy(xpath = "//div[@id='flex-field-emailAddress_contactInfo']//mat-error")
    this.mobilePhoneFieldLabel = page.locator("xpath=//div[@id='flex-field-phoneNumber_contactInfo']//label"); // @FindBy(xpath = "//div[@id='flex-field-phoneNumber_contactInfo']//label")
    this.phoneNumberInput = page.locator("xpath=//div[@id='flex-field-phoneNumber_contactInfo']//input"); // @FindBy(xpath = "//div[@id='flex-field-phoneNumber_contactInfo']//input")
    this.phoneNumberError = page.locator("xpath=//div[@id='flex-field-phoneNumber_contactInfo']//mat-error"); // @FindBy(xpath = "//div[@id='flex-field-phoneNumber_contactInfo']//mat-error")
    this.textMeALinkCheckboxLabel = page.locator("xpath=//span[contains(.,'Text me a link')]"); // @FindBy(xpath = "//span[contains(.,'Text me a link')]")
    this.textAuthorization = page.locator("xpath=//mat-checkbox/following-sibling::p"); // @FindBy(xpath = "//mat-checkbox/following-sibling::p")
    this.termsConditionLink = page.locator("xpath=//p[contains(.,'terms')]/a"); // @FindBy(xpath = "//p[contains(.,'terms')]/a")
    this.pageErrorMessage = page.locator("xpath=//div[contains(@class,'contact-info-cta-validation')]"); // @FindBy(xpath = "//div[contains(@class,'contact-info-cta-validation')]")
    this.pageFooterDisclaimer = page.locator("xpath=//p[span[@class='contactInfoDisclaimer']]"); // @FindBy(xpath = "//p[span[@class='contactInfoDisclaimer']]")
    this.linkAssociatedEntities = page.getByRole('link', { name: "associated entities", exact: true }); // @FindBy(linkText = "associated entities")
    this.electronicSignHeader = page.locator("xpath=//h1"); // @FindBy(xpath = "//h1")
    this.ourCompaniesHeader = page.locator("xpath=//span[@class='h1']"); // @FindBy(xpath = "//span[@class='h1']")
    this.pageFooterDisclaimerEsign = page.locator("xpath=//p[span[@class='contactEsignDisclaimer']]"); // @FindBy(xpath = "//p[span[@class='contactEsignDisclaimer']]")
    this.linkDisclaimerEsign = page.getByRole('link', { name: "ESIGN terms and conditions", exact: true }); // @FindBy(linkText = "ESIGN terms and conditions")
    this.mobileDisclaimerAddition = page.locator("xpath=//p[contains(@class,'consent-disclaimer disclaimer-mobile-view-Margin')]/span[1]"); // @FindBy(xpath = "//p[contains(@class,'consent-disclaimer disclaimer-mobile-view-Margin')]/span[1]")
    this.agreeAndSubmitButton = page.locator("xpath=//button[@id='contactInfoCTAButton' and not(@hidden)]"); // @FindBy(xpath = "//button[@id='contactInfoCTAButton' and not(@hidden)]")
    this.saveQuoteButton = page.locator("button[class='auto-agent-details__save-link tui-link-button']"); // @FindBy(css = "button[class='auto-agent-details__save-link tui-link-button']")
    this.progressSavedSection = page.locator("xpath=//div[contains(@class,'save-in-progress-section')]/p"); // @FindBy(xpath = "//div[contains(@class,'save-in-progress-section')]/p")
    this.emailAddressInput = page.locator("[data-legacy-field=\"emailAddressInput\"]"); // @FindBy(xpath = EMAIL_ADDRESS_XPATH)
    this.mailingAddressInputField = page.locator("input[aria-label='Mailing Address']"); // @FindBy(css = "input[aria-label='Mailing Address']")
    this.bundleSaveHeadingNote = page.locator(".save-bundle-info-heading-note"); // @FindBy(className = "save-bundle-info-heading-note")
    this.bundleAndSaveSection = page.locator("xpath=//app-save-bundle-sheet"); // @FindBy(xpath = "//app-save-bundle-sheet")
    this.bundleSaveHeading = page.locator("xpath=//app-save-bundle-sheet//h2"); // @FindBy(xpath = "//app-save-bundle-sheet//h2")
    this.otherDetailsTitle = page.locator("xpath=//div[@id='saveBundleDiv']//h2[text()='Other details']"); // @FindBy(xpath = "//div[@id='saveBundleDiv']//h2[text()='Other details']")
    this.bundleDiscountTitle = page.locator("xpath=//div[@id='saveBundleDiv']//p[text()='Bundle discount']"); // @FindBy(xpath = "//div[@id='saveBundleDiv']//p[text()='Bundle discount']")
    this.saveBundleMatCheckboxes = page.locator("[data-legacy-field=\"saveBundleMatCheckboxes\"]"); // @FindBy(xpath = BUNDLE_CHECKBOXES_XPATH)
    this.saveBundleCheckboxesText = page.locator("[data-legacy-field=\"saveBundleCheckboxesText\"]"); // @FindBy(xpath = BUNDLE_CHECKBOXES_XPATH + "//following-sibling::span")
    this.saveBundleMatCheckboxInputs = page.locator("[data-legacy-field=\"saveBundleMatCheckboxInputs\"]"); // @FindBy(xpath = BUNDLE_CHECKBOXES_XPATH + "//input")
    this.autoBundleIcon = page.locator("xpath=//i[contains(@style,'rebrand-auto')]"); // @FindBy(xpath = "//i[contains(@style,'rebrand-auto')]")
    this.homeBundleIcon = page.locator("xpath=//i[contains(@style,'rebrand_home')]"); // @FindBy(xpath = "//i[contains(@style,'rebrand_home')]")
    this.lifeBundleIcon = page.locator("xpath=//i[contains(@style,'rebrand-life')]"); // @FindBy(xpath = "//i[contains(@style,'rebrand-life')]")
    this.umbrellaBundleIcon = page.locator("xpath=//i[contains(@style,'rebrand-umbrella')]"); // @FindBy(xpath = "//i[contains(@style,'rebrand-umbrella')]")
    this.multiPolicyCEAIcon = page.locator("xpath=//i[contains(@style,'rebrand_home')]"); // @FindBy(xpath = "//i[contains(@style,'rebrand_home')]")
    this.businessBundleIcon = page.locator("xpath=//i[contains(@style,'rebrand-business')]"); // @FindBy(xpath = "//i[contains(@style,'rebrand-business')]")
    this.boatsBundleIcon = page.locator("xpath=//i[contains(@style,'rebrand_boat')]"); // @FindBy(xpath = "//i[contains(@style,'rebrand_boat')]")
    this.offRoadVehicleBundleIcon = page.locator("xpath=//i[contains(@style,'atv_offroad_rebrand')]"); // @FindBy(xpath = "//i[contains(@style,'atv_offroad_rebrand')]")
    this.motorHomeBundleIcon = page.locator("xpath=//i[contains(@style,'mobilehome_rebrand')]"); // @FindBy(xpath = "//i[contains(@style,'mobilehome_rebrand')]")
    this.saveBundleCongratulationMessage = page.locator("xpath=//p[contains(@class,'auto-driver-review-save-bundle-congratulations-message')]"); // @FindBy(xpath = "//p[contains(@class,'auto-driver-review-save-bundle-congratulations-message')]")
    this.bundleAndSaveTipHeader = page.locator("xpath=//div[@id='saveBundleDiv']//div[contains(@class,'discount-info')]//div"); // @FindBy(xpath = "//div[@id='saveBundleDiv']//div[contains(@class,'discount-info')]//div")
    this.bundleAndSaveTipDescription = page.locator("xpath=//div[@id='saveBundleDiv']//div[contains(@class,'discount-info')]//p"); // @FindBy(xpath = "//div[@id='saveBundleDiv']//div[contains(@class,'discount-info')]//p")
    this.saveBundleInfoIcon = page.locator("xpath=//app-save-bundle-sheet//mat-icon"); // @FindBy(xpath = "//app-save-bundle-sheet//mat-icon")
    this.viewAdditionProductsLink = page.locator("[data-legacy-field=\"viewAdditionProductsLink\"]"); // @FindBy(xpath = ADDITIONAL_PRODUCTS_LINK_XPATH)
    this.fireHydrantSection = page.locator("[data-legacy-field=\"fireHydrantSection\"]"); // @FindBy(xpath = FIRE_HYDRANT_SECTION_XPATH)
    this.fireHydrantSectionTitle = page.locator("[data-legacy-field=\"fireHydrantSectionTitle\"]"); // @FindBy(xpath = FIRE_HYDRANT_SECTION_XPATH + "//p")
    this.fireHydrantSectionLabel = page.locator("[data-legacy-field=\"fireHydrantSectionLabel\"]"); // @FindBy(xpath = FIRE_HYDRANT_SECTION_XPATH + "//label")
    this.fireHydrantQuestionsText = page.locator("[data-legacy-field=\"fireHydrantQuestionsText\"]"); // @FindBy(xpath = FIRE_HYDRANT_RADIO_BUTTON_QUESTIONS_XPATH)
    this.fireHydrantQuestion1label = page.locator("xpath=//app-contact-info//div[@id='fireHydrantdiv']//div[contains(@class,'tui-radio-button-group')][1]/label"); // @FindBy(xpath = "//app-contact-info//div[@id='fireHydrantdiv']//div[contains(@class,'tui-radio-button-group')][1]/label")
    this.fireHydrantQuestion2label = page.locator("xpath=//app-contact-info//div[@id='fireHydrantdiv']//div[contains(@class,'tui-radio-button-group')][2]/label"); // @FindBy(xpath = "//app-contact-info//div[@id='fireHydrantdiv']//div[contains(@class,'tui-radio-button-group')][2]/label")
    this.wildfireRiskReductionOptions = page.locator("xpath=//app-wildfire-selection//mat-checkbox"); // @FindBy(xpath = "//app-wildfire-selection//mat-checkbox")
    this.wildfireRiskReductionSpanCA = page.locator("[data-legacy-field=\"wildfireRiskReductionSpanCA\"]"); // @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//label")  // text from  label + span = full sub-text     protected WebElement wildfireRiskReductionLabelCA;     @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//span")
    this.wildfireRiskMatButtonToggleYes = page.locator("[data-legacy-field=\"wildfireRiskMatButtonToggleYes\"]"); // @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//mat-button-toggle[contains(.,'Yes')]")
    this.wildfireRiskMatButtonToggleNo = page.locator("[data-legacy-field=\"wildfireRiskMatButtonToggleNo\"]"); // @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//mat-button-toggle[contains(.,'No')]")
    this.wildfireRiskButtonToggleYes = page.locator("[data-legacy-field=\"wildfireRiskButtonToggleYes\"]"); // @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//mat-button-toggle[contains(.,'Yes')]//button")
    this.wildfireRiskButtonToggleNo = page.locator("[data-legacy-field=\"wildfireRiskButtonToggleNo\"]"); // @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//mat-button-toggle[contains(.,'No')]//button")
    this.editWildfireRiskReduction = page.locator("[data-legacy-field=\"editWildfireRiskReduction\"]"); // @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//a[text()='Edit']")
    this.wildfireRiskReductionSubtextCA = page.locator("[data-legacy-field=\"wildfireRiskReductionSubtextCA\"]"); // @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//div[contains(@class,'wildfire-riskreduction-subtext')]")
    this.closeWildfireSideSheet = page.locator("xpath=//app-wildfire-selection//mat-icon[text()='close']"); // @FindBy(xpath = "//app-wildfire-selection//mat-icon[text()='close']")
    this.saveButtonWildfireRisk = page.locator("xpath=//app-wildfire-selection//button[text()='Save']"); // @FindBy(xpath = "//app-wildfire-selection//button[text()='Save']")
    this.dialogNoChanges = page.locator("xpath=//mat-dialog-container[contains(.,'No selections made')]"); // @FindBy(xpath = "//mat-dialog-container[contains(.,'No selections made')]")
    this.buttonNoChangesOk = page.locator("xpath=//mat-dialog-container[contains(.,'No selections made')]//button[text()='Ok']"); // @FindBy(xpath = "//mat-dialog-container[contains(.,'No selections made')]//button[text()='Ok']")
    this.wildfireRiskReductionSideSheet = page.locator("xpath=//app-wildfire-selection"); // @FindBy(xpath = "//app-wildfire-selection")
    this.wildfireRiskReductionSideSheetTitle = page.locator("xpath=//app-wildfire-selection//h2"); // @FindBy(xpath = "//app-wildfire-selection//h2")
    this.wildfireRiskReductionSideSheetDivider = page.locator("xpath=//app-wildfire-selection//mat-divider"); // @FindBy(xpath = "//app-wildfire-selection//mat-divider")
    this.wildfireRiskReductionSideSheetSubtitle = page.locator("xpath=//app-wildfire-selection//div[contains(@class,'tui-input-text')]/p[1]"); // @FindBy(xpath = "//app-wildfire-selection//div[contains(@class,'tui-input-text')]/p[1]")
    this.wildfireRiskReductionSideSheetDivider1 = page.locator("xpath=//app-wildfire-selection//div[contains(@class,'tui-input-text')]/hr"); // @FindBy(xpath = "//app-wildfire-selection//div[contains(@class,'tui-input-text')]/hr")
    this.wildfireRiskReductionSideSheetSubtitle2 = page.locator("xpath=//app-wildfire-selection//div[contains(@class,'tui-input-text')]/p[2]"); // @FindBy(xpath = "//app-wildfire-selection//div[contains(@class,'tui-input-text')]/p[2]")
    this.wildfireRiskReductionSideSheetDivider2 = page.locator("xpath=//app-wildfire-selection//div//hr[contains(@class,'second-divider')]"); // @FindBy(xpath = "//app-wildfire-selection//div//hr[contains(@class,'second-divider')]")
    this.wildfireRiskReductionSideSheetSection2Subtitle = page.locator("xpath=//app-wildfire-selection//div//hr[contains(@class,'second-divider')]/following-sibling::p"); // @FindBy(xpath = "//app-wildfire-selection//div//hr[contains(@class,'second-divider')]/following-sibling::p")
    this.wildfireRiskReductionSideSheetCheckboxes = page.locator("xpath=//app-wildfire-selection//mat-checkbox"); // @FindBy(xpath = "//app-wildfire-selection//mat-checkbox")
    this.wildfireRiskReductionSideSheetCheckboxLabels = page.locator("xpath=//app-wildfire-selection//mat-checkbox//label//p[contains(@class,'tui-input-text')]"); // @FindBy(xpath = "//app-wildfire-selection//mat-checkbox//label//p[contains(@class,'tui-input-text')]")
    this.residenceFloorSection = page.locator("xpath=//div[@id='floorResidenceContactInfo']"); // @FindBy(xpath = "//div[@id='floorResidenceContactInfo']")
    this.residenceFloorSectionSubtitle = page.locator("xpath=//div[@id='floorResidenceContactInfo']//*[contains(@class,'tui-subtitle-text-1')]"); // @FindBy(xpath = "//div[@id='floorResidenceContactInfo']//*[contains(@class,'tui-subtitle-text-1')]")
    this.residenceFloorCheckbox = page.locator("xpath=//div[@id='floorResidenceContactInfo']/mat-checkbox"); // @FindBy(xpath = "//div[@id='floorResidenceContactInfo']/mat-checkbox")
    this.residenceFloorInfoLabel = page.locator("xpath=//div[@id='floorResidenceContactInfo']//*[contains(@class,'label')]"); // @FindBy(xpath = "//div[@id='floorResidenceContactInfo']//*[contains(@class,'label')]")
    this.residenceFloorInfoDescription = page.locator("xpath=//div[@id='floorResidenceContactInfo']//*[contains(@class,'floorResidence-cont-info_checkbox-description')]"); // @FindBy(xpath = "//div[@id='floorResidenceContactInfo']//*[contains(@class,'floorResidence-cont-info_checkbox-description')]")
    this.contactInfoDisclaimer = page.locator("xpath=//p[contains(@class,'tui-body-text mt')]//span[@id='conactInfoDisclaimer']"); // @FindBy(xpath = "//p[contains(@class,'tui-body-text mt')]//span[@id='conactInfoDisclaimer']")
    this.primaryInsuranceGroupTitle = page.locator("xpath=//p[contains(text(),'Primary named insured')]"); // @FindBy(xpath = "//p[contains(text(),'Primary named insured')]")
    this.selectInsuranceGroupTitle = page.locator("xpath=//mat-card//div[contains(@class,'brand-selection')]/p[1]"); // @FindBy(xpath = "//mat-card//div[contains(@class,'brand-selection')]/p[1]")
    this.selectAllCheckboxLabel = page.locator("xpath=//mat-label[contains(@class,'brand-label')]"); // @FindBy(xpath = "//mat-label[contains(@class,'brand-label')]")
    this.farmersCheckboxLabel = page.locator("xpath=//mat-label[normalize-space()='Farmers®']"); // @FindBy(xpath = "//mat-label[normalize-space()='Farmers\u00ae']")
    this.BWCheckboxLabel = page.locator("xpath=//mat-label[normalize-space()='Bristol West®']"); // @FindBy(xpath = "//mat-label[normalize-space()='Bristol West\u00ae']")
    this.farmersLifeCheckboxLabel = page.locator("xpath=//mat-label[normalize-space()='Farmers Life®']"); // @FindBy(xpath = "//mat-label[normalize-space()='Farmers Life\u00ae']")
    this.foremostCheckboxLabel = page.locator("xpath=//mat-label[normalize-space()='Foremost®']"); // @FindBy(xpath = "//mat-label[normalize-space()='Foremost\u00ae']")
    this.selectAllCheckboxSubLabel = page.locator("xpath=//p[normalize-space()='Choose them individually below:']"); // @FindBy(xpath = "//p[normalize-space()='Choose them individually below:']")
    this.farmersCheckboxSubLabel = page.locator("xpath=//mat-label[normalize-space()='Farmers®']/following-sibling::p"); // @FindBy(xpath = "//mat-label[normalize-space()='Farmers\u00ae']/following-sibling::p")
    this.BWCheckboxSubLabel = page.locator("xpath=//mat-label[normalize-space()='Bristol West®']/following-sibling::p"); // @FindBy(xpath = "//mat-label[normalize-space()='Bristol West\u00ae']/following-sibling::p")
    this.farmersLifeCheckboxSubLabel = page.locator("xpath=//mat-label[normalize-space()='Farmers Life®']/following-sibling::p"); // @FindBy(xpath = "//mat-label[normalize-space()='Farmers Life\u00ae']/following-sibling::p")
    this.foremostCheckboxSubLabel = page.locator("xpath=//mat-label[normalize-space()='Foremost®']/following-sibling::p"); // @FindBy(xpath = "//mat-label[normalize-space()='Foremost\u00ae']/following-sibling::p")
    this.primaryInsuredName = page.locator("xpath=//div[@id='contactDetailsDiv']//div//li"); // @FindBy(xpath = "//div[@id='contactDetailsDiv']//div//li")
    this.individualBrandCheckboxes = page.locator("xpath=//div[@class='brand-selection']//div/mat-checkbox"); // @FindBy(xpath = "//div[@class='brand-selection']//div/mat-checkbox")
    this.allBrandsCheckbox = page.locator("[data-legacy-field=\"allBrandsCheckbox\"]"); // @FindBy(xpath = ALL_BRANDS_CHECKBOX_XPATH)
    this.continueButtonBundleContactInfoPage = page.locator("xpath=//button[contains(@class, 'continue-button')]"); // @FindBy(xpath = "//button[contains(@class, 'continue-button')]")
    this.genderButtons = page.locator("[data-legacy-field=\"genderButtons\"]"); // @FindBy(xpath = GENDER_SELECTION_XPATH)
    this.genderButton = page.locator("[data-legacy-field=\"genderButton\"]"); // @FindBy(xpath = GENDER_SELECTION_XPATH)
    this.firstNameInputBox = page.locator("xpath=//input[@aria-label='"); // @FindBy(xpath = "//input[@aria-label='" + FIRST_NAME + "']")
    this.firstNameAriaLabelText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + FIRST_NAME + "')]")
    this.lastNameInputBox = page.locator("xpath=//input[@aria-label='"); // @FindBy(xpath = "//input[@aria-label='" + LAST_NAME + "']")
    this.lastNameAriaLabelText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + LAST_NAME + "')]")
    this.dateOfBirthInputBox = page.locator("xpath=//input[@aria-label='"); // @FindBy(xpath = "//input[@aria-label='" + DATE_OF_BIRTH_ARIA_LABEL_INPUT_BOX + "']")
    this.dateOfBirthAriaLabelText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + DATE_OF_BIRTH_ARIA_LABEL + "')]")
    this.mmddyyyyHint = page.locator("xpath=//mat-hint[contains(text(), 'mm/dd/yyyy')]"); // @FindBy(xpath = "//mat-hint[contains(text(), 'mm/dd/yyyy')]")
    this.spouseInputFieldSection = page.locator("xpath=//div[@id='spouseDetailsDiv']//div[contains(@class,'home-about-you__input-fields')]"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//div[contains(@class,'home-about-you__input-fields')]")
    this.spouseElements = page.locator("xpath=//div[@id='spouseDetailsDiv']//mat-form-field//input"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//mat-form-field//input")
    this.spouseFirstNameInputBox = page.locator("xpath=//input[@aria-label=\"Spouse's First name\"]"); // @FindBy(xpath = "//input[@aria-label=\"Spouse's First name\"]")
    this.spouseLastNameInputBox = page.locator("xpath=//input[@aria-label=\"Spouse's Last name\"]"); // @FindBy(xpath = "//input[@aria-label=\"Spouse's Last name\"]")
    this.spouseDateOfBirthInputBox = page.locator("xpath=//input[@aria-label=\"Spouse's Date Of birth\"]"); // @FindBy(xpath = "//input[@aria-label=\"Spouse's Date Of birth\"]")
    this.priorOrCurrentAddressCityInputBox = page.locator("xpath=//mat-form-field[@id='auto-contact-info-city__input-field']//input"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-info-city__input-field']//input")
    this.priorOrCurrentAddressStateSelect = page.locator("xpath=//mat-form-field[@id='state']//mat-select"); // @FindBy(xpath = "//mat-form-field[@id='state']//mat-select")
    this.priorOrCurrentAddressZipInputBox = page.locator("xpath=//mat-form-field[@id='auto-contact-info-zipCode__input-field']//input"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-info-zipCode__input-field']//input")
    this.aboutYouHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + ABOUT_YOU_HEADER + "')]")
    this.spouseGenderButtons = page.locator("[data-legacy-field=\"spouseGenderButtons\"]"); // @FindBy(xpath = SPOUSE_GENDER_SELECTION_XPATH)
    this.marriedOrInDomesticRelationMatCheckbox = page.locator("xpath=//div[contains(@class,'isMarried')]//mat-checkbox"); // @FindBy(xpath = "//div[contains(@class,'isMarried')]//mat-checkbox")
    this.marriedOrInDomesticRelationCheckboxInput = page.locator("xpath=//div[contains(@class,'isMarried')]//input[@type='checkbox']"); // @FindBy(xpath = "//div[contains(@class,'isMarried')]//input[@type='checkbox']")
    this.marriedOrInDomesticRelationCheckBoxDescription = page.locator("xpath=//p[contains(@class, 'spouse__checkbox-description')]"); // @FindBy(xpath = "//p[contains(@class, 'spouse__checkbox-description')]")
    this.marriedOrInDomesticRelationLabel = page.locator("xpath=//span[contains(text(), '"); // @FindBy(xpath = "//span[contains(text(), '" + MARRIED_DOMESTIC_RELATIONSHIP_LABEL + "')]")
    this.currentFormerEmployedHeaderPersonalInfoDiv = page.locator("xpath=//div[@id='primaryOccupationDiv']//p[contains(text(), '"); // @FindBy(xpath = "//div[@id='primaryOccupationDiv']//p[contains(text(), '" + CURRENT_FORMER_EMPLOYED_PROFESSIONAL + "')]")
    this.currentFormerEmployedHeaderSpouseDiv = page.locator("xpath=//div[@id='spouseDetailsDiv']//p[contains(text(), '"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//p[contains(text(), '" + CURRENT_FORMER_EMPLOYED_PROFESSIONAL + "')]")
    this.eligibleOccupationSavingsPersonalInfoDiv = page.locator("xpath=//div[@id='primaryOccupationDiv']//p[contains(text(), '"); // @FindBy(xpath = "//div[@id='primaryOccupationDiv']//p[contains(text(), '" + ELIGIBLE_ADDITIONAL_SAVINGS + "')]")
    this.eligibleOccupationSavingsSpouseDiv = page.locator("xpath=//div[@id='spouseDetailsDiv']//p[contains(text(), '"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//p[contains(text(), '" + ELIGIBLE_ADDITIONAL_SAVINGS + "')]")
    this.eligibleOccupationButtonPersonalInfoDiv = page.locator("xpath=//button[@id='primaryOccupation']"); // @FindBy(xpath = "//button[@id='primaryOccupation']")
    this.eligibleOccupationButtonSpouseDiv = page.locator("xpath=//button[@id='spouseOccupation']"); // @FindBy(xpath = "//button[@id='spouseOccupation']")
    this.eligibleOccupationHeader = page.locator("xpath=//h1[contains(text(), '"); // @FindBy(xpath = "//h1[contains(text(), '" + ELIGIBLE_OCCUPATION_HEADER + "')]")
    this.occupationRadioButtons = page.locator("[data-legacy-field=\"occupationRadioButtons\"]"); // @FindBy(xpath = OCCUPATIONS_RADIO_BUTTONS_XPATH)
    this.firstOccupationRadioButton = page.locator("[data-legacy-field=\"firstOccupationRadioButton\"]"); // @FindBy(xpath = OCCUPATIONS_RADIO_BUTTONS_XPATH)
    this.currentlyEmployedOrRetiredQuestion = page.locator("xpath=//div[contains(@class,'col occupation-retired-checkbox-col')]//p"); // @FindBy(xpath = "//div[contains(@class,'col occupation-retired-checkbox-col')]//p")
    this.currentlyEmployedOrRetiredToggleButtons = page.locator("[data-legacy-field=\"currentlyEmployedOrRetiredToggleButtons\"]"); // @FindBy(xpath = EMPLOYED_OR_RETIRED_TOGGLE_BUTTONS_XPATH)
    this.currentlyEmployedOrRetiredToggleButton = page.locator("[data-legacy-field=\"currentlyEmployedOrRetiredToggleButton\"]"); // @FindBy(xpath = EMPLOYED_OR_RETIRED_TOGGLE_BUTTONS_XPATH)
    this.currentlyEmployedOrRetiredToggleButtonLabel = page.locator("xpath=//div[contains(@class,'col occupation-retired-checkbox-col')]//mat-button-toggle-group//mat-button-toggle//button//span"); // @FindBy(xpath = "//div[contains(@class,'col occupation-retired-checkbox-col')]//mat-button-toggle-group//mat-button-toggle//button//span")
    this.closeIcon = page.locator("xpath=//app-occupation-list//mat-icon[contains(text(), 'close')]"); // @FindBy(xpath = "//app-occupation-list//mat-icon[contains(text(), 'close')]")
    this.closeButton = page.locator("xpath=//app-occupation-list//button[contains(text(), 'Close')]"); // @FindBy(xpath = "//app-occupation-list//button[contains(text(), 'Close')]")
    this.occupationRetiredCheckBox = page.locator("xpath=//div[contains(@class,'occupation-retired-checkbox')]//mat-checkbox"); // @FindBy(xpath = "//div[contains(@class,'occupation-retired-checkbox')]//mat-checkbox")
    this.retiredFormerlyEmployedLabel = page.locator("xpath=//span[contains(text(), '"); // @FindBy(xpath = "//span[contains(text(), '" + RETIRED_FORMALLY_EMPLOYED_LABEL + "')]")
    this.eligibleOccupationAddButton = page.locator("xpath=//button[contains(text(), 'Add')]"); // @FindBy(xpath = "//button[contains(text(), 'Add')]")
    this.eligibleOccupationCancelButton = page.locator("xpath=//mat-dialog-actions//button[contains(text(), 'Cancel')]"); // @FindBy(xpath = "//mat-dialog-actions//button[contains(text(), 'Cancel')]")
    this.removeOccupationLinkPrimaryApplicant = page.locator("xpath=//div[@id='primaryOccupationDiv']//a"); // @FindBy(xpath = "//div[@id='primaryOccupationDiv']//a")
    this.removeOccupationLinkSpouse = page.locator("xpath=//div[@id='spouseDetailsDiv']//a"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//a")
    this.removeOccupationHeaderInModalBox = page.locator("xpath=//app-remove-occupation//h1[contains(text(), '"); // @FindBy(xpath = "//app-remove-occupation//h1[contains(text(), '" + REMOVE_OCCUPATION_HEADER_IN_MODAL + "')]")
    this.keepOccupationButton = page.locator("xpath=//button[contains(text(), 'Keep occupation')]"); // @FindBy(xpath = "//button[contains(text(), 'Keep occupation')]")
    this.removeOccupationButton = page.locator("xpath=//button[contains(text(), 'Remove')]"); // @FindBy(xpath = "//button[contains(text(), 'Remove')]")
    this.removeOccupationQuestion = page.locator("xpath=//mat-dialog-content[contains(text(), '"); // @FindBy(xpath = "//mat-dialog-content[contains(text(), '" + REMOVE_OCCUPATION_QUESTION + "')]")
    this.homeOccupationSelectedMessagePersonalInfo = page.locator("xpath=//div[contains(@class,'home-occupation-selected-message')]"); // @FindBy(xpath = "//div[contains(@class,'home-occupation-selected-message')]")
    this.homeOccupationSelectedMessageSpouseDiv = page.locator("xpath=//div[@id='spouseDetailsDiv']//div[contains(@class,'home-occupation-selected-message')]"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//div[contains(@class,'home-occupation-selected-message')]")
    this.occupationPrimary = page.locator("xpath=//div[@id='primaryOccupationDiv']//div[contains(@class,'home-occupation-selected-message')]"); // @FindBy(xpath = "//div[@id='primaryOccupationDiv']//div[contains(@class,'home-occupation-selected-message')]")
    this.occupationSpouse = page.locator("xpath=//div[@id='spouseDetailsDiv']//div[contains(@class,'home-occupation-selected-message')]"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//div[contains(@class,'home-occupation-selected-message')]")
    this.selectedOccupation = page.locator("xpath=//div[contains(@class,'home-occupation-selected')]"); // @FindBy(xpath = "//div[contains(@class,'home-occupation-selected')]")
    this.closeIconInAddressInputBox = page.locator("xpath=//address-autocomplete-input//mat-icon"); // @FindBy(xpath = "//address-autocomplete-input//mat-icon")
    this.unitInputBox = page.locator("xpath=//mat-form-field[@name='home-personal-info-apartment__input-field']//input"); // @FindBy(xpath = "//mat-form-field[@name='home-personal-info-apartment__input-field']//input")
    this.unitNumberPlaceholderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + UNIT_NUMBER_PLACEHOLDER_TEXT + "')]")
    this.cityPlaceholderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + CITY_PLACEHOLDER_TEXT + "')]")
    this.statePlaceholderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + STATE_PLACEHOLDER_TEXT + "')]")
    this.zipPlaceholderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + ZIP_PLACEHOLDER_TEXT + "')]")
    this.optionalUnitNumberHint = page.locator("xpath=//mat-hint[contains(text(),'"); // @FindBy(xpath = "//mat-hint[contains(text(),'" + OPTIONAL_UNIT_NUMBER_HINT + "')]")
    this.priorAddressPlaceHolderText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + PRIOR_ADDRESS_PLACEHOLDER_TEXT + "')]")
    this.priorOrCurrentHomeAddressLabel = page.locator("xpath=//div[@id='priorCurrentAddress']//div//p"); // @FindBy(xpath = "//div[@id='priorCurrentAddress']//div//p")
    this.currentAddressPlaceHolderText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + CURRENT_ADDRESS_PLACEHOLDER_TEXT + "')]")
  }
}
