// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCThankYouBasePage. */
export class AceHRCThankYouBasePage extends CoreBasePage {
  public readonly farmersLogoThankYouScreen: Locator;
  public readonly thankYouScreenTitle: Locator;
  public readonly thankYouScreenSubTitle: Locator;
  public readonly emailLinkDesktop: Locator;
  public readonly emailLinkMobile: Locator;
  public readonly linkCloseEmailSnackBar: Locator;
  public readonly saveInProgressFooter: Locator;
  public readonly quoteNumberText: Locator;
  public readonly farmersLogoFooter: Locator;
  public readonly footerPersonalInfoUseLink: Locator;
  public readonly footerDigitalAccessibilityLink: Locator;
  public readonly footerTermsOfUseLink: Locator;
  public readonly footerPrivacyCenterLink: Locator;
  public readonly footerNoticeOfInformationPracticesLink: Locator;
  public readonly footerDoNotSellLink: Locator;
  public readonly presentmentCardPriceHeader: Locator;
  public readonly quotePriceOnCard: Locator;
  public readonly linkViewMonthlyPricing: Locator;
  public readonly linkViewPayInFullPricing: Locator;
  public readonly includedCoveragesPriceOnCard: Locator;
  public readonly optionalCoveragesPriceOnCard: Locator;
  public readonly quoteDiscountsOnCard: Locator;
  public readonly quoteAllOtherCoveragesPriceOnCard: Locator;
  public readonly quotePrimaryCoverageOnCard: Locator;

  public constructor(page: Page) {
    super(page);
    this.farmersLogoThankYouScreen = page.locator("xpath=//img[@alt='Farmers Insurance Logo']"); // @FindBy(xpath = "//img[@alt='Farmers Insurance Logo']")
    this.thankYouScreenTitle = page.locator("xpath=//app-thank-you//h1"); // @FindBy(xpath = "//app-thank-you//h1")
    this.thankYouScreenSubTitle = page.locator("xpath=//app-thank-you//div[contains(@class,'thank-you__subtitle')]"); // @FindBy(xpath = "//app-thank-you//div[contains(@class,'thank-you__subtitle')]")
    this.emailLinkDesktop = page.locator("#emailLink"); // @FindBy(id = "emailLink")
    this.emailLinkMobile = page.locator("xpath=//button[@aria-label='Email this quote']"); // @FindBy(xpath = "//button[@aria-label='Email this quote']")
    this.linkCloseEmailSnackBar = page.locator("xpath=//a[contains(text(),'Done')]"); // @FindBy(xpath = "//a[contains(text(),'Done')]")
    this.saveInProgressFooter = page.locator("xpath=//div[contains(@class,'save-in-progress')]/p"); // @FindBy(xpath = "//div[contains(@class,'save-in-progress')]/p")
    this.quoteNumberText = page.locator("xpath=//div[contains(@class,'save-quote')]"); // @FindBy(xpath = "//div[contains(@class,'save-quote')]")
    this.farmersLogoFooter = page.locator("xpath=//tui-oneui-footer//div[contains(@class,'tui-oneui-footer-logo-container')]/img"); // @FindBy(xpath = "//tui-oneui-footer//div[contains(@class,'tui-oneui-footer-logo-container')]/img")
    this.footerPersonalInfoUseLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_personal-information-use']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_personal-information-use']")
    this.footerDigitalAccessibilityLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_digital-accessibility']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_digital-accessibility']")
    this.footerTermsOfUseLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_terms-of-use']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_terms-of-use']")
    this.footerPrivacyCenterLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_privacy-center']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_privacy-center']")
    this.footerNoticeOfInformationPracticesLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_notice-of-information-practices']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_notice-of-information-practices']")
    this.footerDoNotSellLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_do-not-sell']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_do-not-sell']")
    this.presentmentCardPriceHeader = page.locator("[data-legacy-field=\"presentmentCardPriceHeader\"]"); // @FindBy(xpath = PRESENTMENT_CARD_PRICE_HEADER_XPATH)
    this.quotePriceOnCard = page.locator("[data-legacy-field=\"quotePriceOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tui-price")
    this.linkViewMonthlyPricing = page.locator("[data-legacy-field=\"linkViewMonthlyPricing\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + VIEW_PAY_MONTHLY_PRICING_LINK_XPATH)
    this.linkViewPayInFullPricing = page.locator("[data-legacy-field=\"linkViewPayInFullPricing\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + VIEW_PAY_IN_FULL_PRICING_LINK_XPATH)
    this.includedCoveragesPriceOnCard = page.locator("xpath=(//tr/td[contains(@class,'coverage-prices')])[1]"); // @FindBy(xpath = "(//tr/td[contains(@class,'coverage-prices')])[1]")
    this.optionalCoveragesPriceOnCard = page.locator("xpath=(//tr/td[contains(@class,'coverage-prices')])[2]"); // @FindBy(xpath = "(//tr/td[contains(@class,'coverage-prices')])[2]")
    this.quoteDiscountsOnCard = page.locator("[data-legacy-field=\"quoteDiscountsOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div")
    this.quoteAllOtherCoveragesPriceOnCard = page.locator("[data-legacy-field=\"quoteAllOtherCoveragesPriceOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[text()='All other coverages']/following-sibling::td")
    this.quotePrimaryCoverageOnCard = page.locator("[data-legacy-field=\"quotePrimaryCoverageOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[starts-with(text(),'Primary coverages')]/following-sibling::td")
  }
}
