// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCQualityGradeBasePage. */
export class AceHRCQualityGradeBasePage extends CoreBasePage {
  public readonly yourHomeQualityGradeHeader: Locator;
  public readonly yourHomeQualityGradeHeaderSection: Locator;
  public readonly propertyDetailsYourHomeQualityGradeHeader: Locator;
  public readonly pleaseReviewQualityGradeSubText: Locator;
  public readonly customerstreetAddressWebElement: Locator;
  public readonly customerCityStateZipcodeWebElement: Locator;
  public readonly customerAddressQualityGradeSection: Locator;
  public readonly qualityGradeAddressLine1: Locator;
  public readonly qualityGradeAddressLine2: Locator;
  public readonly generalShapeAndStyleHeader: Locator;
  public readonly editButtons: Locator;
  public readonly generalShapeAndStyleQualityGrade: Locator;
  public readonly generalShapeAndStyleEditLinkButton: Locator;
  public readonly generalShapeAndStyleRadioButtons: Locator;
  public readonly generalShapeAndStyleMatRadioButtons: Locator;
  public readonly checkedGeneralShapeAndStyleRadioButton: Locator;
  public readonly generalShapeAndStyleHomeImages: Locator;
  public readonly generalShapeAndStyleDescriptions: Locator;
  public readonly generalShapeAndStyleQualityGradeFeatures: Locator;
  public readonly generalShapeAndStyleDescription: Locator;
  public readonly exteriorFeaturesAndFinishesHeader: Locator;
  public readonly exteriorFeaturesAndFinishesQualityGrade: Locator;
  public readonly exteriorFeaturesAndFinishesEditLinkButton: Locator;
  public readonly exteriorFeaturesAndFinishesRadioButtons: Locator;
  public readonly exteriorFeaturesAndFinishesMatRadioButtons: Locator;
  public readonly exteriorFeaturesAndFinishesHomeImages: Locator;
  public readonly exteriorFeaturesAndFinishesDescriptions: Locator;
  public readonly checkedExteriorFeaturesAndFinishedRadioButton: Locator;
  public readonly exteriorFeaturesAndFinishesQualityGradeFeatures: Locator;
  public readonly exteriorFeaturesAndFinishesDescription: Locator;
  public readonly interiorFeaturesAndFinishesHeader: Locator;
  public readonly interiorFeaturesAndFinishesQualityGrade: Locator;
  public readonly interiorFeaturesAndFinishesEditLinkButton: Locator;
  public readonly interiorFeaturesAndFinishesRadioButtons: Locator;
  public readonly interiorFeaturesAndFinishesMatRadioButtons: Locator;
  public readonly interiorFeaturesAndFinishesImages: Locator;
  public readonly interiorFeaturesAndFinishesDescriptions: Locator;
  public readonly checkedInteriorFeaturesAndFinishedRadioButton: Locator;
  public readonly interiorFeaturesAndFinishesQualityGradeFeatures: Locator;
  public readonly interiorFeaturesAndFinishesDescription: Locator;
  public readonly cabinetsAndCounterTopsHeader: Locator;
  public readonly cabinetsAndCounterTopsQualityGrade: Locator;
  public readonly cabinetsAndCounterTopsEditLinkButton: Locator;
  public readonly cabinetsAndCounterTopsRadioButtons: Locator;
  public readonly cabinetsAndCounterTopsMatRadioButtons: Locator;
  public readonly cabinetsAndCounterTopsHomeImages: Locator;
  public readonly cabinetsAndCounterTopsDescriptions: Locator;
  public readonly checkedCabinetsAndCountertopsRadioButton: Locator;
  public readonly cabinetsAndCountertopsQualityGradeFeatures: Locator;
  public readonly cabinetsAndCountertopsDescription: Locator;
  public readonly lightBulbIcon: Locator;
  public readonly whyIsThisImportantQuestion: Locator;
  public readonly disclaimerText: Locator;
  public readonly errorsOnQualityGradePage: Locator;
  public readonly doubleCheckYourCoverageDialogContinueButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.yourHomeQualityGradeHeader = page.locator("xpath=//app-quality-grade//h1"); // @FindBy(xpath = "//app-quality-grade//h1")
    this.yourHomeQualityGradeHeaderSection = page.locator("xpath=//app-quality-grade//h2"); // @FindBy(xpath = "//app-quality-grade//h2")
    this.propertyDetailsYourHomeQualityGradeHeader = page.locator("xpath=//app-property-details//h2[contains(@class,'home-details-section-title') and text()='Your home quality grade']"); // @FindBy(xpath = "//app-property-details//h2[contains(@class,'home-details-section-title') and text()='Your home quality grade']")
    this.pleaseReviewQualityGradeSubText = page.locator("xpath=//app-quality-grade//div[contains(text(), 'Please review')]"); // @FindBy(xpath = "//app-quality-grade//div[contains(text(), 'Please review')]")
    this.customerstreetAddressWebElement = page.locator("xpath=//h2[contains(@class,'street_address')]"); // @FindBy(xpath = "//h2[contains(@class,'street_address')]")
    this.customerCityStateZipcodeWebElement = page.locator("xpath=//span[contains(@class,'city_zipcode')]"); // @FindBy(xpath = "//span[contains(@class,'city_zipcode')]")
    this.customerAddressQualityGradeSection = page.locator("xpath=//div[contains(@class,'customer-address')]"); // @FindBy(xpath = "//div[contains(@class,'customer-address')]")
    this.qualityGradeAddressLine1 = page.locator("xpath=//app-quality-grade//div[contains(@class,'customer-address')]/div[1]"); // @FindBy(xpath = "//app-quality-grade//div[contains(@class,'customer-address')]/div[1]")
    this.qualityGradeAddressLine2 = page.locator("xpath=//app-quality-grade//div[contains(@class,'customer-address')]/div[2]"); // @FindBy(xpath = "//app-quality-grade//div[contains(@class,'customer-address')]/div[2]")
    this.generalShapeAndStyleHeader = page.locator("xpath=//div[contains(@class,'general-style')]//p"); // @FindBy(xpath = "//div[contains(@class,'general-style')]//p")
    this.editButtons = page.locator("button.edit-button.tui-link-button"); // @FindBy(css = "button.edit-button.tui-link-button")
    this.generalShapeAndStyleQualityGrade = page.locator("[data-legacy-field=\"generalShapeAndStyleQualityGrade\"]"); // @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//span[contains(@class,'quality-grade-desc')]")
    this.generalShapeAndStyleEditLinkButton = page.locator("[data-legacy-field=\"generalShapeAndStyleEditLinkButton\"]"); // @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//button")
    this.generalShapeAndStyleRadioButtons = page.locator("[data-legacy-field=\"generalShapeAndStyleRadioButtons\"]"); // @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//following::div[1]//mat-radio-button//input")
    this.generalShapeAndStyleMatRadioButtons = page.locator("[data-legacy-field=\"generalShapeAndStyleMatRadioButtons\"]"); // @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//following::div[1]//mat-radio-button")
    this.checkedGeneralShapeAndStyleRadioButton = page.locator("[data-legacy-field=\"checkedGeneralShapeAndStyleRadioButton\"]"); // @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//following::div[1]//mat-radio-button[contains(@class,'radio-checked')]")
    this.generalShapeAndStyleHomeImages = page.locator("[data-legacy-field=\"generalShapeAndStyleHomeImages\"]"); // @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//following::div[1]//div[contains(@class,'section-selector-images')]//img")
    this.generalShapeAndStyleDescriptions = page.locator("[data-legacy-field=\"generalShapeAndStyleDescriptions\"]"); // @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//following::div[1]//div[contains(@class,'section-selector-content')]")
    this.generalShapeAndStyleQualityGradeFeatures = page.locator("xpath=//div[@id='section-selector-content-for-General']"); // @FindBy(xpath = "//div[@id='section-selector-content-for-General']")
    this.generalShapeAndStyleDescription = page.locator("[data-legacy-field=\"generalShapeAndStyleDescription\"]"); // @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//span[contains(@class,'quality-grade-desc')]")
    this.exteriorFeaturesAndFinishesHeader = page.locator("[data-legacy-field=\"exteriorFeaturesAndFinishesHeader\"]"); // @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//p")
    this.exteriorFeaturesAndFinishesQualityGrade = page.locator("[data-legacy-field=\"exteriorFeaturesAndFinishesQualityGrade\"]"); // @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//span[contains(@class,'quality-grade-desc')]")
    this.exteriorFeaturesAndFinishesEditLinkButton = page.locator("[data-legacy-field=\"exteriorFeaturesAndFinishesEditLinkButton\"]"); // @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//button")
    this.exteriorFeaturesAndFinishesRadioButtons = page.locator("[data-legacy-field=\"exteriorFeaturesAndFinishesRadioButtons\"]"); // @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//following::div[1]//mat-radio-button//input")
    this.exteriorFeaturesAndFinishesMatRadioButtons = page.locator("[data-legacy-field=\"exteriorFeaturesAndFinishesMatRadioButtons\"]"); // @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//following::div[1]//mat-radio-button")
    this.exteriorFeaturesAndFinishesHomeImages = page.locator("[data-legacy-field=\"exteriorFeaturesAndFinishesHomeImages\"]"); // @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//following::div[1]//div[contains(@class,'section-selector-images')]//img")
    this.exteriorFeaturesAndFinishesDescriptions = page.locator("[data-legacy-field=\"exteriorFeaturesAndFinishesDescriptions\"]"); // @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//following::div[1]//div[contains(@class,'section-selector-content')]")
    this.checkedExteriorFeaturesAndFinishedRadioButton = page.locator("[data-legacy-field=\"checkedExteriorFeaturesAndFinishedRadioButton\"]"); // @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//following::div[1]//mat-radio-button[contains(@class,'radio-checked')]")
    this.exteriorFeaturesAndFinishesQualityGradeFeatures = page.locator("xpath=//div[@id='section-selector-content-for-Exterior']"); // @FindBy(xpath = "//div[@id='section-selector-content-for-Exterior']")
    this.exteriorFeaturesAndFinishesDescription = page.locator("[data-legacy-field=\"exteriorFeaturesAndFinishesDescription\"]"); // @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//span[contains(@class,'quality-grade-desc')]")
    this.interiorFeaturesAndFinishesHeader = page.locator("[data-legacy-field=\"interiorFeaturesAndFinishesHeader\"]"); // @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//p")
    this.interiorFeaturesAndFinishesQualityGrade = page.locator("[data-legacy-field=\"interiorFeaturesAndFinishesQualityGrade\"]"); // @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//span[contains(@class,'quality-grade-desc')]")
    this.interiorFeaturesAndFinishesEditLinkButton = page.locator("[data-legacy-field=\"interiorFeaturesAndFinishesEditLinkButton\"]"); // @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//button")
    this.interiorFeaturesAndFinishesRadioButtons = page.locator("[data-legacy-field=\"interiorFeaturesAndFinishesRadioButtons\"]"); // @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//following::div[1]//mat-radio-button//input")
    this.interiorFeaturesAndFinishesMatRadioButtons = page.locator("[data-legacy-field=\"interiorFeaturesAndFinishesMatRadioButtons\"]"); // @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//following::div[1]//mat-radio-button")
    this.interiorFeaturesAndFinishesImages = page.locator("[data-legacy-field=\"interiorFeaturesAndFinishesImages\"]"); // @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//following::div[1]//div[contains(@class,'section-selector-images')]//img")
    this.interiorFeaturesAndFinishesDescriptions = page.locator("[data-legacy-field=\"interiorFeaturesAndFinishesDescriptions\"]"); // @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//following::div[1]//div[contains(@class,'section-selector-content')]")
    this.checkedInteriorFeaturesAndFinishedRadioButton = page.locator("[data-legacy-field=\"checkedInteriorFeaturesAndFinishedRadioButton\"]"); // @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//following::div[1]//mat-radio-button[contains(@class,'radio-checked')]")
    this.interiorFeaturesAndFinishesQualityGradeFeatures = page.locator("xpath=//div[@id='section-selector-content-for-Interior']"); // @FindBy(xpath = "//div[@id='section-selector-content-for-Interior']")
    this.interiorFeaturesAndFinishesDescription = page.locator("[data-legacy-field=\"interiorFeaturesAndFinishesDescription\"]"); // @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//span[contains(@class,'quality-grade-desc')]")
    this.cabinetsAndCounterTopsHeader = page.locator("[data-legacy-field=\"cabinetsAndCounterTopsHeader\"]"); // @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//p")
    this.cabinetsAndCounterTopsQualityGrade = page.locator("[data-legacy-field=\"cabinetsAndCounterTopsQualityGrade\"]"); // @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//span[contains(@class,'quality-grade-desc')]")
    this.cabinetsAndCounterTopsEditLinkButton = page.locator("[data-legacy-field=\"cabinetsAndCounterTopsEditLinkButton\"]"); // @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//button")
    this.cabinetsAndCounterTopsRadioButtons = page.locator("[data-legacy-field=\"cabinetsAndCounterTopsRadioButtons\"]"); // @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//following::div[1]//mat-radio-button//input")
    this.cabinetsAndCounterTopsMatRadioButtons = page.locator("[data-legacy-field=\"cabinetsAndCounterTopsMatRadioButtons\"]"); // @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//following::div[1]//mat-radio-button")
    this.cabinetsAndCounterTopsHomeImages = page.locator("[data-legacy-field=\"cabinetsAndCounterTopsHomeImages\"]"); // @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//following::div[1]//div[contains(@class,'section-selector-images')]//img")
    this.cabinetsAndCounterTopsDescriptions = page.locator("[data-legacy-field=\"cabinetsAndCounterTopsDescriptions\"]"); // @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//following::div[1]//div[contains(@class,'section-selector-content')]")
    this.checkedCabinetsAndCountertopsRadioButton = page.locator("[data-legacy-field=\"checkedCabinetsAndCountertopsRadioButton\"]"); // @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//following::div[1]//mat-radio-button[contains(@class,'radio-checked')]")
    this.cabinetsAndCountertopsQualityGradeFeatures = page.locator("xpath=//div[@id='section-selector-content-for-Cabinet']"); // @FindBy(xpath = "//div[@id='section-selector-content-for-Cabinet']")
    this.cabinetsAndCountertopsDescription = page.locator("[data-legacy-field=\"cabinetsAndCountertopsDescription\"]"); // @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//span[contains(@class,'quality-grade-desc')]")
    this.lightBulbIcon = page.locator("xpath=//div[contains(@class,'lightbulb-container')]//img[contains(@class,'lightbulb-icon')]"); // @FindBy(xpath = "//div[contains(@class,'lightbulb-container')]//img[contains(@class,'lightbulb-icon')]")
    this.whyIsThisImportantQuestion = page.locator("xpath=//div[contains(@class,'disclaimer-header')]//div[contains(@class,'tui-subtitle')]"); // @FindBy(xpath = "//div[contains(@class,'disclaimer-header')]//div[contains(@class,'tui-subtitle')]")
    this.disclaimerText = page.locator("xpath=//div[contains(@class,'disclaimer-text')]"); // @FindBy(xpath = "//div[contains(@class,'disclaimer-text')]")
    this.errorsOnQualityGradePage = page.locator("xpath=//p[contains(@class,'error-highlight')]"); // @FindBy(xpath = "//p[contains(@class,'error-highlight')]")
    this.doubleCheckYourCoverageDialogContinueButton = page.locator("xpath=//mat-dialog-container//button"); // @FindBy(xpath = "//mat-dialog-container//button")
  }
}
