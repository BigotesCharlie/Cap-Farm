// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCNameAndDobBasePage. */
export class AceHRCNameAndDobBasePage extends CoreBasePage {
  public readonly letsBeginTitle: Locator;
  public readonly letsBeginSubtitle: Locator;
  public readonly firstNameInputBox: Locator;
  public readonly firstNameAriaLabelText: Locator;
  public readonly lastNameInputBox: Locator;
  public readonly lastNameAriaLabelText: Locator;
  public readonly dateOfBirthInputBox: Locator;
  public readonly dateOfBirthAriaLabelText: Locator;
  public readonly mmddyyyyHint: Locator;
  public readonly requiredOrIncompleteErrorMessage: Locator;
  public readonly footerSubtitle: Locator;
  public readonly buttonAgree: Locator;
  public readonly creditReportDisclaimer: Locator;
  public readonly consumerReportDisclaimer: Locator;
  public readonly privacyPolicyDisclaimer: Locator;
  public readonly privacyPolicyLink: Locator;

  public constructor(page: Page) {
    super(page);
    this.letsBeginTitle = page.locator("xpath=//div[contains(@class,'personal-info_name_dob_h1')][1]"); // @FindBy(xpath = "//div[contains(@class,'personal-info_name_dob_h1')][1]")
    this.letsBeginSubtitle = page.locator("xpath=//div[@id='personal-info_name_dob-subheading']"); // @FindBy(xpath = "//div[@id='personal-info_name_dob-subheading']")
    this.firstNameInputBox = page.locator("xpath=//input[contains(@aria-label,'"); // @FindBy(xpath = "//input[contains(@aria-label,'" + FIRST_NAME + "')]")
    this.firstNameAriaLabelText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + FIRST_NAME + "')]")
    this.lastNameInputBox = page.locator("xpath=//input[contains(@aria-label,'"); // @FindBy(xpath = "//input[contains(@aria-label,'" + LAST_NAME + "')]")
    this.lastNameAriaLabelText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + LAST_NAME + "')]")
    this.dateOfBirthInputBox = page.locator("xpath=//input[contains(@aria-label,'"); // @FindBy(xpath = "//input[contains(@aria-label,'" + DATE_OF_BIRTH + "')]")
    this.dateOfBirthAriaLabelText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + DATE_OF_BIRTH + "')]")
    this.mmddyyyyHint = page.locator("xpath=//mat-hint[contains(text(), 'mm/dd/yyyy')]"); // @FindBy(xpath = "//mat-hint[contains(text(), 'mm/dd/yyyy')]")
    this.requiredOrIncompleteErrorMessage = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + REQUIRED_OR_INCOMPLETE_FIELD_ERROR_MESSAGE + "')]")
    this.footerSubtitle = page.locator("xpath=//app-personal-info//div[button]/preceding-sibling::p[contains(@class, 'tui-body-text-1')]"); // @FindBy(xpath = "//app-personal-info//div[button]/preceding-sibling::p[contains(@class, 'tui-body-text-1')]")
    this.buttonAgree = page.locator("xpath=//button[contains(text(), 'Agree')]"); // @FindBy(xpath = "//button[contains(text(), 'Agree')]")
    this.creditReportDisclaimer = page.locator("xpath=//app-personal-info//div[contains(@class,'disclaimer__credit-report')]//p[1]"); // @FindBy(xpath = "//app-personal-info//div[contains(@class,'disclaimer__credit-report')]//p[1]")
    this.consumerReportDisclaimer = page.locator("xpath=//app-personal-info//div[contains(@class,'disclaimer__credit-report')]//p[2]"); // @FindBy(xpath = "//app-personal-info//div[contains(@class,'disclaimer__credit-report')]//p[2]")
    this.privacyPolicyDisclaimer = page.locator("xpath=//app-personal-info//div[contains(@class,'disclaimer__color') and not(@hidden)]"); // @FindBy(xpath = "//app-personal-info//div[contains(@class,'disclaimer__color') and not(@hidden)]")
    this.privacyPolicyLink = page.locator("xpath=//app-personal-info//div[contains(@class,'disclaimer__color')]//a"); // @FindBy(xpath = "//app-personal-info//div[contains(@class,'disclaimer__color')]//a")
  }
}
