// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCPropertyTypeBasePage. */
export class AceHRCPropertyTypeBasePage extends CoreBasePage {
  public readonly pageTitle: Locator;
  public readonly propertyTypeCard: Locator;
  public readonly togglePartnerIcon: Locator;
  public readonly togglePartnerText: Locator;
  public readonly primaryResidenceText: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageTitle = page.locator("xpath=//app-property-type//h1"); // @FindBy(xpath = "//app-property-type//h1")
    this.propertyTypeCard = page.locator("[data-legacy-field=\"propertyTypeCard\"]"); // @FindBy(xpath = PROPERTY_TYPE_CARD_XPATH)
    this.togglePartnerIcon = page.locator("xpath=//app-property-type//app-toggle-banner//div[contains(@class,'toggle-icon')]"); // @FindBy(xpath = "//app-property-type//app-toggle-banner//div[contains(@class,'toggle-icon')]")
    this.togglePartnerText = page.locator("xpath=//app-property-type//app-toggle-banner//div[contains(@class,'toggle-text')]"); // @FindBy(xpath = "//app-property-type//app-toggle-banner//div[contains(@class,'toggle-text')]")
    this.primaryResidenceText = page.locator("[data-legacy-field=\"primaryResidenceText\"]"); // @FindBy(xpath = PRIMARY_RESIDENCE_XPATH)
  }
}
