// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCFwsInterstitialPage. */
export class AceHRCFwsInterstitialPage extends CoreBasePage {
  public readonly fwsInterstitialPageTitle: Locator;
  public readonly fwsInterstitialPageSubTitle: Locator;
  public readonly farmersChoicePageContent: Locator;
  public readonly fwsInterstitialGroupQuoteContent: Locator;
  public readonly fwsRepresentativeContactNumber: Locator;
  public readonly fwsSpeakWithRepresentativeText: Locator;
  public readonly applyDiscountsButton: Locator;
  public readonly fwsInterstitialDialogContainerTitle: Locator;
  public readonly fwsInterstitialDialogContainerContent: Locator;
  public readonly fwsDialogContainerAgreeButton: Locator;
  public readonly fwsDialogContainerContinueWithoutDataButton: Locator;
  public readonly continueWithoutDiscountLink: Locator;
  public readonly selectedInsuranceType: Locator;
  public readonly fwsColpPageContent: Locator;
  public readonly fwsColpContactNumber: Locator;
  public readonly fwsQnBPageContent: Locator;
  public readonly fwsQnBCallToRepresentativeContent: Locator;
  public readonly fwsQnBGetMyQuoteButton: Locator;
  public readonly qnbPageHeader: Locator;
  public readonly fwsPageSubtitle: Locator;

  public constructor(page: Page) {
    super(page);
    this.fwsInterstitialPageTitle = page.locator("xpath=//app-fws-eligibility//div[@class='fws-content-rebrand']//h1"); // @FindBy(xpath = "//app-fws-eligibility//div[@class='fws-content-rebrand']//h1")
    this.fwsInterstitialPageSubTitle = page.locator("xpath=//app-fws-eligibility//div[@class='fws-content-rebrand']//h2"); // @FindBy(xpath = "//app-fws-eligibility//div[@class='fws-content-rebrand']//h2")
    this.farmersChoicePageContent = page.locator("xpath=//app-fws-eligibility//div[contains(text(), 'Farmers Insurance Choice')]"); // @FindBy(xpath = "//app-fws-eligibility//div[contains(text(), 'Farmers Insurance Choice')]")
    this.fwsInterstitialGroupQuoteContent = page.locator("xpath=//app-fws-eligibility//span[contains(text(), 'Farmers Insurance Group Quote site')]"); // @FindBy(xpath = "//app-fws-eligibility//span[contains(text(), 'Farmers Insurance Group Quote site')]")
    this.fwsRepresentativeContactNumber = page.locator("[data-legacy-field=\"fwsRepresentativeContactNumber\"]"); // @FindBy(xpath = CONTACT_NUMBER_XPATH)
    this.fwsSpeakWithRepresentativeText = page.locator("[data-legacy-field=\"fwsSpeakWithRepresentativeText\"]"); // @FindBy(xpath = CONTACT_NUMBER_XPATH + "/preceding-sibling::div")
    this.applyDiscountsButton = page.locator("xpath=//app-fws-eligibility//button[contains(text(),'Apply discounts')]"); // @FindBy(xpath = "//app-fws-eligibility//button[contains(text(),'Apply discounts')]")
    this.fwsInterstitialDialogContainerTitle = page.locator("xpath=//mat-dialog-container//h4[contains(@class,'consent-dialog-header-rebrand')]"); // @FindBy(xpath = "//mat-dialog-container//h4[contains(@class,'consent-dialog-header-rebrand')]")
    this.fwsInterstitialDialogContainerContent = page.locator("xpath=//mat-dialog-container//mat-dialog-content[contains(@class,'dialog-content')]"); // @FindBy(xpath = "//mat-dialog-container//mat-dialog-content[contains(@class,'dialog-content')]")
    this.fwsDialogContainerAgreeButton = page.locator("xpath=//mat-dialog-container//button[contains(@class, 'consent-dialog-agree-button')]"); // @FindBy(xpath = "//mat-dialog-container//button[contains(@class, 'consent-dialog-agree-button')]")
    this.fwsDialogContainerContinueWithoutDataButton = page.locator("xpath=//mat-dialog-container//button[contains(@class, 'consent-dialog-cwd-button')]"); // @FindBy(xpath = "//mat-dialog-container//button[contains(@class, 'consent-dialog-cwd-button')]")
    this.continueWithoutDiscountLink = page.locator("xpath=//div[contains(@class,'without-discount-link')]//a"); // @FindBy(xpath = "//div[contains(@class,'without-discount-link')]//a")
    this.selectedInsuranceType = page.locator("xpath=//span[@class='selected-indicator']/preceding-sibling::span"); // @FindBy(xpath = "//span[@class='selected-indicator']/preceding-sibling::span")
    this.fwsColpPageContent = page.locator("[data-legacy-field=\"fwsColpPageContent\"]"); // @FindBy(xpath = FWS_COLP_CONTENT_XPATH)
    this.fwsColpContactNumber = page.locator("[data-legacy-field=\"fwsColpContactNumber\"]"); // @FindBy(xpath = PHONE_NUMBER_XPATH)
    this.fwsQnBPageContent = page.locator("[data-legacy-field=\"fwsQnBPageContent\"]"); // @FindBy(xpath = FWS_QnB_CONTENT_XPATH + "//div[1]")
    this.fwsQnBCallToRepresentativeContent = page.locator("[data-legacy-field=\"fwsQnBCallToRepresentativeContent\"]"); // @FindBy(xpath = PHONE_NUMBER_XPATH + "/preceding-sibling::div")
    this.fwsQnBGetMyQuoteButton = page.locator("[data-legacy-field=\"fwsQnBGetMyQuoteButton\"]"); // @FindBy(xpath = FWS_QnB_CONTENT_XPATH + "//button[contains(text(),'Get my quote')]")
    this.qnbPageHeader = page.locator("xpath=//div[contains(@class, 'qnbContent')]//h1"); // @FindBy(xpath = "//div[contains(@class, 'qnbContent')]//h1")
    this.fwsPageSubtitle = page.locator("[data-legacy-field=\"fwsPageSubtitle\"]"); // @FindBy(xpath = FWS_PAGE_SUBTITLE_XPATH)
  }
}
