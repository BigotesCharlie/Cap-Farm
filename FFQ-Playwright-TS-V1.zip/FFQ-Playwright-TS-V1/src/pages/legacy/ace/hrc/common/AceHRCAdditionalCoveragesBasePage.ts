// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCAdditionalCoveragesBasePage. */
export class AceHRCAdditionalCoveragesBasePage extends CoreBasePage {
  public readonly additionalCoveragesHeading: Locator;
  public readonly additionalCoveragesSubheading: Locator;
  public readonly quotePriceOnCardDesktop: Locator;
  public readonly quotePriceOnCardMobile: Locator;
  public readonly presentmentCardPriceHeaderDesktop: Locator;
  public readonly presentmentCardPriceHeaderMobile: Locator;
  public readonly linkViewMonthlyPricingDesktop: Locator;
  public readonly linkViewMonthlyPricingMobile: Locator;
  public readonly linkViewPayInFullPricingDesktop: Locator;
  public readonly linkViewPayInFullPricingMobile: Locator;
  public readonly quoteAllOtherCoveragesPriceOnCardDesktop: Locator;
  public readonly quoteAllOtherCoveragesPriceOnCardMobile: Locator;
  public readonly quoteDiscountsOnCardDesktop: Locator;
  public readonly quoteDiscountsOnCardMobile: Locator;
  public readonly buttonContinueDesktop: Locator;
  public readonly buttonContinueMobile: Locator;
  public readonly buttonCallDesktop: Locator;
  public readonly buttonCallMobile: Locator;
  public readonly fallbackContinueButton: Locator;
  public readonly recalculateButtonDesktop: Locator;
  public readonly recalculateButtonMobile: Locator;
  public readonly recalculateButtonBundleMobile: Locator;
  public readonly recalculateButtonBundleDesktop: Locator;
  public readonly emailLink: Locator;
  public readonly linkCloseEmailSnackBar: Locator;
  public readonly toggleButtons: Locator;
  public readonly headerHoaLossPayment: Locator;
  public readonly radioButtonsHoaLossPayment: Locator;
  public readonly headerWaterBackup: Locator;
  public readonly footerWaterBackup: Locator;
  public readonly radioButtonsWaterBackup: Locator;
  public readonly toggleButtonsWaterBackup1: Locator;
  public readonly toggleButtonsWaterBackup2: Locator;
  public readonly toggleButtonsWaterBackupText: Locator;
  public readonly inputWaterBackup: Locator;
  public readonly buttonWaterBackupMinus: Locator;
  public readonly buttonWaterBackupPlus: Locator;
  public readonly subTextInputWaterBackup: Locator;
  public readonly headerLimitedMold: Locator;
  public readonly radioButtonsLimitedMold: Locator;
  public readonly yearBuiltInputLimitedMold: Locator;
  public readonly yearBuiltInputEarthquake: Locator;
  public readonly headerIncreasedLimitsForLimitedMold: Locator;
  public readonly radioButtonIncreasedLimitsForLimitedMold: Locator;
  public readonly headerLimitedLeakage: Locator;
  public readonly radioButtonsLimitedLeakage: Locator;
  public readonly headerIncreasedValuables: Locator;
  public readonly headerIncreasedValuablesInfoIcon: Locator;
  public readonly checkboxesIncreasedValuables: Locator;
  public readonly checkboxesIncreasedValuable: Locator;
  public readonly footerIncreasedValuables: Locator;
  public readonly footerIncreasedValuablesStarText: Locator;
  public readonly inputIncreasedCoverageJewelry: Locator;
  public readonly labelIncreasedCoverageJewelry: Locator;
  public readonly increaseCoverageJewelry: Locator;
  public readonly decreaseCoverageJewelry: Locator;
  public readonly inputIncreasedCoverageOther: Locator;
  public readonly labelIncreasedCoverageOther: Locator;
  public readonly increaseCoverageOther: Locator;
  public readonly decreaseCoverageOther: Locator;
  public readonly increaseCoverageSecurities: Locator;
  public readonly decreaseCoverageSecurities: Locator;
  public readonly errorsIncreasedCoverageSection: Locator;
  public readonly increaseCoverageJewelryCheckbox: Locator;
  public readonly increaseCoverageOtherCheckbox: Locator;
  public readonly increasedValuablesInfoDialogHeader: Locator;
  public readonly increasedValuablesInfoDialogCloseButton: Locator;
  public readonly increasedValuablesInfoDialogMainContent: Locator;
  public readonly increasedValuablesInfoDialogPackageName: Locator;
  public readonly increasedValuablesInfoDialogOtherArticlesTextWatches: Locator;
  public readonly increasedValuablesInfoDialogDivider1: Locator;
  public readonly increasedValuablesInfoDialogDivider2: Locator;
  public readonly increasedValuablesInfoDialogDivider3: Locator;
  public readonly headerLimitedEscapedLiquidFuel: Locator;
  public readonly radioButtonsLimitedEscapedLiquidFuel: Locator;
  public readonly headersLimitedEscapedLiquidFuelSection: Locator;
  public readonly headerEarthquake: Locator;
  public readonly radioButtonsEarthquake: Locator;
  public readonly radioButtonsEarthquakeLabels: Locator;
  public readonly headersEarthquakeSection: Locator;
  public readonly toggleButtonsEarthquake: Locator;
  public readonly earthquakeInfoIcons: Locator;
  public readonly earthquakeCoverageInfoDialogHeader: Locator;
  public readonly earthquakeInfoDialogSubheaders: Locator;
  public readonly earthquakeInfoDialogParagraphs: Locator;
  public readonly headerSpecialWaterLossLimit: Locator;
  public readonly radioButtonsSpecialWaterLossLimit: Locator;
  public readonly watercraftCoverageDialogTitle: Locator;
  public readonly watercraftCoverageDialogContent: Locator;
  public readonly buttonRemoveCoverage: Locator;
  public readonly buttonOk: Locator;
  public readonly closeSidesheetButton: Locator;
  public readonly expandQuoteCard: Locator;
  public readonly minimizeQuoteCard: Locator;
  public readonly dialogButtonOk: Locator;
  public readonly buttonContinueMobileAtPageBottom: Locator;
  public readonly buttonRecalculateMobileAtPageBottom: Locator;
  public readonly specialWaterLossLimitDialogTitle: Locator;
  public readonly fortifiedRoofUpgradeDialogTitle: Locator;
  public readonly dialogContent: Locator;

  public constructor(page: Page) {
    super(page);
    this.additionalCoveragesHeading = page.locator("[data-legacy-field=\"additionalCoveragesHeading\"]"); // @FindBy(xpath = PAGE_TITLE_XPATH)
    this.additionalCoveragesSubheading = page.locator("xpath=//app-additional-coverages-page//h1/following-sibling::div[contains(@class,'subheading-class')]"); // @FindBy(xpath = "//app-additional-coverages-page//h1/following-sibling::div[contains(@class,'subheading-class')]")
    this.quotePriceOnCardDesktop = page.locator("[data-legacy-field=\"quotePriceOnCardDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tui-price")
    this.quotePriceOnCardMobile = page.locator("[data-legacy-field=\"quotePriceOnCardMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//tui-price")
    this.presentmentCardPriceHeaderDesktop = page.locator("[data-legacy-field=\"presentmentCardPriceHeaderDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + PRESENTMENT_CARD_PRICE_HEADER_XPATH)
    this.presentmentCardPriceHeaderMobile = page.locator("[data-legacy-field=\"presentmentCardPriceHeaderMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + PRESENTMENT_CARD_PRICE_HEADER_XPATH)
    this.linkViewMonthlyPricingDesktop = page.locator("[data-legacy-field=\"linkViewMonthlyPricingDesktop\"]"); // @FindBy(xpath = VIEW_MONTHLY_PRICING_LINK_DESKTOP_XPATH)
    this.linkViewMonthlyPricingMobile = page.locator("[data-legacy-field=\"linkViewMonthlyPricingMobile\"]"); // @FindBy(xpath = VIEW_MONTHLY_PRICING_LINK_MOBILE_XPATH)
    this.linkViewPayInFullPricingDesktop = page.locator("[data-legacy-field=\"linkViewPayInFullPricingDesktop\"]"); // @FindBy(xpath = VIEW_PAY_IN_FULL_PRICING_LINK_DESKTOP_XPATH)
    this.linkViewPayInFullPricingMobile = page.locator("[data-legacy-field=\"linkViewPayInFullPricingMobile\"]"); // @FindBy(xpath = VIEW_PAY_IN_FULL_PRICING_LINK_MOBILE_XPATH)
    this.quoteAllOtherCoveragesPriceOnCardDesktop = page.locator("[data-legacy-field=\"quoteAllOtherCoveragesPriceOnCardDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + OPTIONAL_COVERAGES_XPATH)
    this.quoteAllOtherCoveragesPriceOnCardMobile = page.locator("[data-legacy-field=\"quoteAllOtherCoveragesPriceOnCardMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + OPTIONAL_COVERAGES_XPATH)
    this.quoteDiscountsOnCardDesktop = page.locator("[data-legacy-field=\"quoteDiscountsOnCardDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div")
    this.quoteDiscountsOnCardMobile = page.locator("[data-legacy-field=\"quoteDiscountsOnCardMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//mat-list-item//div")
    this.buttonContinueDesktop = page.locator("[data-legacy-field=\"buttonContinueDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + CONTINUE_BUTTON_XPATH)
    this.buttonContinueMobile = page.locator("[data-legacy-field=\"buttonContinueMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + CONTINUE_BUTTON_XPATH)
    this.buttonCallDesktop = page.locator("[data-legacy-field=\"buttonCallDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + CALL_BUTTON_XPATH)
    this.buttonCallMobile = page.locator("[data-legacy-field=\"buttonCallMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + CALL_BUTTON_XPATH)
    this.fallbackContinueButton = page.locator("xpath=//app-additional-coverages-page"); // @FindBy(xpath = "//app-additional-coverages-page" + CONTINUE_BUTTON_XPATH)
    this.recalculateButtonDesktop = page.locator("[data-legacy-field=\"recalculateButtonDesktop\"]"); // @FindBy(xpath = RECALCULATE_BUTTON_DESKTOP_XPATH)
    this.recalculateButtonMobile = page.locator("[data-legacy-field=\"recalculateButtonMobile\"]"); // @FindBy(xpath = RECALCULATE_BUTTON_MOBILE_XPATH)
    this.recalculateButtonBundleMobile = page.locator("xpath=//div[contains(@class,'summary-box-mobile-button')]//button"); // @FindBy(xpath = "//div[contains(@class,'summary-box-mobile-button')]//button")
    this.recalculateButtonBundleDesktop = page.locator("xpath=//div[contains(@class,'summary-box-desktop-button')]//button"); // @FindBy(xpath = "//div[contains(@class,'summary-box-desktop-button')]//button")
    this.emailLink = page.locator("#emailLink"); // @FindBy(id = "emailLink")
    this.linkCloseEmailSnackBar = page.getByRole('link', { name: "Done", exact: true }); // @FindBy(linkText = "Done")
    this.toggleButtons = page.locator("xpath=//mat-slide-toggle"); // @FindBy(xpath = "//mat-slide-toggle")
    this.headerHoaLossPayment = page.locator("xpath=//div[@id='HOAlosspayment']//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='HOAlosspayment']//label[contains(@class,'tui-input-text-2')]")
    this.radioButtonsHoaLossPayment = page.locator("xpath=//div[@id='HOAlosspayment']//mat-radio-button"); // @FindBy(xpath = "//div[@id='HOAlosspayment']//mat-radio-button")
    this.headerWaterBackup = page.locator("xpath=//div[@id='Waterbackupandsumpoverflow']//label[contains(@class,'tui-input-text-2')][1]"); // @FindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//label[contains(@class,'tui-input-text-2')][1]")
    this.footerWaterBackup = page.locator("xpath=//div[@id='Waterbackupandsumpoverflow']//label[contains(@class,'tui-input-text-2')][2]"); // @FindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//label[contains(@class,'tui-input-text-2')][2]")
    this.radioButtonsWaterBackup = page.locator("xpath=//div[@id='Waterbackupandsumpoverflow']//mat-radio-button"); // @FindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-radio-button")
    this.toggleButtonsWaterBackup1 = page.locator("xpath=//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle[1]"); // @FindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle[1]")
    this.toggleButtonsWaterBackup2 = page.locator("xpath=//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle[2]"); // @FindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle[2]")
    this.toggleButtonsWaterBackupText = page.locator("xpath=//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle-group/following-sibling::div"); // @FindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle-group/following-sibling::div")
    this.inputWaterBackup = page.locator("xpath=//div[@id='Waterbackupandsumpoverflow']//mat-card//input"); // @FindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-card//input")
    this.buttonWaterBackupMinus = page.locator("xpath=//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle[.='remove']"); // @FindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle[.='remove']")
    this.buttonWaterBackupPlus = page.locator("xpath=//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle[.='add']"); // @FindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle[.='add']")
    this.subTextInputWaterBackup = page.locator("xpath=//div[@id='Waterbackupandsumpoverflow']//mat-hint"); // @FindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-hint")
    this.headerLimitedMold = page.locator("xpath=//div[@id='Limitedmold']//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='Limitedmold']//label[contains(@class,'tui-input-text-2')]")
    this.radioButtonsLimitedMold = page.locator("xpath=//div[@id='Limitedmold']//mat-radio-button"); // @FindBy(xpath = "//div[@id='Limitedmold']//mat-radio-button")
    this.yearBuiltInputLimitedMold = page.locator("xpath=//div[@id='Limitedmold']//mat-form-field//input"); // @FindBy(xpath = "//div[@id='Limitedmold']//mat-form-field//input")
    this.yearBuiltInputEarthquake = page.locator("xpath=//div[@id='Earthquake']//mat-form-field//input"); // @FindBy(xpath = "//div[@id='Earthquake']//mat-form-field//input")
    this.headerIncreasedLimitsForLimitedMold = page.locator("xpath=//div[@id='IncreasedlimitsforLimitedmold']//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='IncreasedlimitsforLimitedmold']//label[contains(@class,'tui-input-text-2')]")
    this.radioButtonIncreasedLimitsForLimitedMold = page.locator("xpath=//div[@id='IncreasedlimitsforLimitedmold']//mat-radio-button"); // @FindBy(xpath = "//div[@id='IncreasedlimitsforLimitedmold']//mat-radio-button")
    this.headerLimitedLeakage = page.locator("xpath=//div[@id='Limitedleakage&seepage']//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='Limitedleakage&seepage']//label[contains(@class,'tui-input-text-2')]")
    this.radioButtonsLimitedLeakage = page.locator("xpath=//div[@id='Limitedleakage&seepage']//mat-radio-button"); // @FindBy(xpath = "//div[@id='Limitedleakage&seepage']//mat-radio-button")
    this.headerIncreasedValuables = page.locator("xpath=//div[@id='increasedValuables']//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='increasedValuables']//label[contains(@class,'tui-input-text-2')]")
    this.headerIncreasedValuablesInfoIcon = page.locator("xpath=//div[@id='increasedValuables']//button[contains(@aria-label,'info icon')]"); // @FindBy(xpath = "//div[@id='increasedValuables']//button[contains(@aria-label,'info icon')]")
    this.checkboxesIncreasedValuables = page.locator("xpath=//div[@id='increasedValuables']//mat-checkbox"); // @FindBy(xpath = "//div[@id='increasedValuables']//mat-checkbox")
    this.checkboxesIncreasedValuable = page.locator("xpath=//div[@id='increasedValuables']//mat-checkbox"); // @FindBy(xpath = "//div[@id='increasedValuables']//mat-checkbox")
    this.footerIncreasedValuables = page.locator("xpath=//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]"); // @FindBy(xpath = "//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]")
    this.footerIncreasedValuablesStarText = page.locator("xpath=//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]/descendant::div[contains(.,'*')]"); // @FindBy(xpath = "//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]/descendant::div[contains(.,'*')]")
    this.inputIncreasedCoverageJewelry = page.locator("xpath=(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[1]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[1]")
    this.labelIncreasedCoverageJewelry = page.locator("xpath=//div[@id='increasedValuables']//mat-checkbox[following-sibling::div[contains(text(),'Jewelry')]]//label"); // @FindBy(xpath = "//div[@id='increasedValuables']//mat-checkbox[following-sibling::div[contains(text(),'Jewelry')]]//label")
    this.increaseCoverageJewelry = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[1]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[1]")
    this.decreaseCoverageJewelry = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[1]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[1]")
    this.inputIncreasedCoverageOther = page.locator("xpath=(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[2]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[2]")
    this.labelIncreasedCoverageOther = page.locator("xpath=//div[@id='increasedValuables']//mat-checkbox[following-sibling::div[contains(text(),'Other')]]//label"); // @FindBy(xpath = "//div[@id='increasedValuables']//mat-checkbox[following-sibling::div[contains(text(),'Other')]]//label")
    this.increaseCoverageOther = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[2]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[2]")
    this.decreaseCoverageOther = page.locator("xpath=(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[2]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[2]")
    this.increaseCoverageSecurities = page.locator("xpath=//div[@id='increasedValuables']//button[contains(@aria-label,'Securities') and mat-icon[text()='add']]"); // @FindBy(xpath = "//div[@id='increasedValuables']//button[contains(@aria-label,'Securities') and mat-icon[text()='add']]")
    this.decreaseCoverageSecurities = page.locator("xpath=//div[@id='increasedValuables']//button[contains(@aria-label,'Securities') and mat-icon[text()='remove']]"); // @FindBy(xpath = "//div[@id='increasedValuables']//button[contains(@aria-label,'Securities') and mat-icon[text()='remove']]")
    this.errorsIncreasedCoverageSection = page.locator("xpath=//app-additional-coverage-card//mat-error"); // @FindBy(xpath = "//app-additional-coverage-card//mat-error")
    this.increaseCoverageJewelryCheckbox = page.locator("xpath=(//div[@id='increasedValuables']//mat-checkbox//label)[1]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//mat-checkbox//label)[1]")
    this.increaseCoverageOtherCheckbox = page.locator("xpath=(//div[@id='increasedValuables']//mat-checkbox//label)[2]"); // @FindBy(xpath = "(//div[@id='increasedValuables']//mat-checkbox//label)[2]")
    this.increasedValuablesInfoDialogHeader = page.locator("xpath=//app-increase-valuables-info-dialog//h1"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//h1")
    this.increasedValuablesInfoDialogCloseButton = page.locator("xpath=//app-increase-valuables-info-dialog//button[@aria-label='Close']"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//button[@aria-label='Close']")
    this.increasedValuablesInfoDialogMainContent = page.locator("xpath=//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]/div"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]/div")
    this.increasedValuablesInfoDialogPackageName = page.locator("xpath=//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'package-name-label')]"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'package-name-label')]")
    this.increasedValuablesInfoDialogOtherArticlesTextWatches = page.locator("xpath=//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][1]"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][1]")     // Jewelry     private WebElement increasedValuablesInfoDialogJewelry;     @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][1]/following-sibling::div[1]")     // Jewelry text content     private WebElement increasedValuablesInfoDialogJewelryText;      @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][2]")     // Other articles     private WebElement increasedValuablesInfoDialogOtherArticles;     @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][2]/following-sibling::div[1]")     // Firearms, Security, Silverware, Fine arts     private WebElement increasedValuablesInfoDialogOtherArticlesTextFirearms;     @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][2]/following-sibling::div[2]")
    this.increasedValuablesInfoDialogDivider1 = page.locator("xpath=//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[1]"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[1]")
    this.increasedValuablesInfoDialogDivider2 = page.locator("xpath=//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[2]"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[2]")
    this.increasedValuablesInfoDialogDivider3 = page.locator("xpath=//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[3]"); // @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[3]")
    this.headerLimitedEscapedLiquidFuel = page.locator("xpath=//div[@id='Limitedescapedliquidfuel']//div[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='Limitedescapedliquidfuel']//div[contains(@class,'tui-input-text-2')]")
    this.radioButtonsLimitedEscapedLiquidFuel = page.locator("xpath=//div[@id='Limitedescapedliquidfuel']//mat-radio-button"); // @FindBy(xpath = "//div[@id='Limitedescapedliquidfuel']//mat-radio-button")
    this.headersLimitedEscapedLiquidFuelSection = page.locator("xpath=//div[@id='Limitedescapedliquidfuel']//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='Limitedescapedliquidfuel']//label[contains(@class,'tui-input-text-2')]")
    this.headerEarthquake = page.locator("xpath=//div[@id='Earthquake']//div[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='Earthquake']//div[contains(@class,'tui-input-text-2')]")
    this.radioButtonsEarthquake = page.locator("xpath=//div[@id='Earthquake']//mat-radio-button"); // @FindBy(xpath = "//div[@id='Earthquake']//mat-radio-button")
    this.radioButtonsEarthquakeLabels = page.locator("xpath=//div[@id='Earthquake']//mat-radio-button//label"); // @FindBy(xpath = "//div[@id='Earthquake']//mat-radio-button//label")
    this.headersEarthquakeSection = page.locator("xpath=//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]")
    this.toggleButtonsEarthquake = page.locator("xpath=//div[@id='Earthquake']//mat-button-toggle/button"); // @FindBy(xpath = "//div[@id='Earthquake']//mat-button-toggle/button")
    this.earthquakeInfoIcons = page.locator("xpath=//div[@id='Earthquake']//button[contains(@aria-label,'info icon')]"); // @FindBy(xpath = "//div[@id='Earthquake']//button[contains(@aria-label,'info icon')]")
    this.earthquakeCoverageInfoDialogHeader = page.locator("xpath=//app-earthquake-coverage-dialog//h4"); // @FindBy(xpath = "//app-earthquake-coverage-dialog//h4")
    this.earthquakeInfoDialogSubheaders = page.locator("xpath=//app-earthquake-coverage-dialog//div/span[contains(@class,'tui-subtitle-2')]"); // @FindBy(xpath = "//app-earthquake-coverage-dialog//div/span[contains(@class,'tui-subtitle-2')]")
    this.earthquakeInfoDialogParagraphs = page.locator("xpath=//app-earthquake-coverage-dialog//div[contains(@class,'tui-body')]"); // @FindBy(xpath = "//app-earthquake-coverage-dialog//div[contains(@class,'tui-body')]")
    this.headerSpecialWaterLossLimit = page.locator("xpath=//div[@id='Specialwaterlosslimit']//label[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//div[@id='Specialwaterlosslimit']//label[contains(@class,'tui-input-text-2')]")
    this.radioButtonsSpecialWaterLossLimit = page.locator("xpath=//div[@id='Specialwaterlosslimit']//mat-radio-button"); // @FindBy(xpath = "//div[@id='Specialwaterlosslimit']//mat-radio-button")
    this.watercraftCoverageDialogTitle = page.locator("xpath=//mat-dialog-container//span[contains(@class,'tui-subtitle')]"); // @FindBy(xpath = "//mat-dialog-container//span[contains(@class,'tui-subtitle')]")
    this.watercraftCoverageDialogContent = page.locator("xpath=//mat-dialog-container//mat-dialog-content"); // @FindBy(xpath = "//mat-dialog-container//mat-dialog-content")
    this.buttonRemoveCoverage = page.locator("xpath=//mat-dialog-container//mat-dialog-actions//a"); // @FindBy(xpath = "//mat-dialog-container//mat-dialog-actions//a")
    this.buttonOk = page.locator("xpath=//mat-dialog-container//mat-dialog-actions//button"); // @FindBy(xpath = "//mat-dialog-container//mat-dialog-actions//button")
    this.closeSidesheetButton = page.locator("xpath=//a[contains(@class,'close')]//mat-icon"); // @FindBy(xpath = "//a[contains(@class,'close')]//mat-icon")
    this.expandQuoteCard = page.locator("xpath=//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]//mat-icon[@aria-label='expand quote card']"); // @FindBy(xpath = "//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]//mat-icon[@aria-label='expand quote card']")
    this.minimizeQuoteCard = page.locator("xpath=//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]//mat-icon[@aria-label='minimize quote card']"); // @FindBy(xpath = "//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]//mat-icon[@aria-label='minimize quote card']")
    this.dialogButtonOk = page.locator("xpath=//mat-dialog-container//button[text()='OK']"); // @FindBy(xpath = "//mat-dialog-container//button[text()='OK']")
    this.buttonContinueMobileAtPageBottom = page.locator("xpath=//div[contains(@class,'tui-stacking-top-sm')]//button[contains(text(),'Continue')]"); // @FindBy(xpath = "//div[contains(@class,'tui-stacking-top-sm')]//button[contains(text(),'Continue')]")
    this.buttonRecalculateMobileAtPageBottom = page.locator("xpath=//div[contains(@class,'tui-stacking-top-sm')]//button[contains(text(),'Recalculate')]"); // @FindBy(xpath = "//div[contains(@class,'tui-stacking-top-sm')]//button[contains(text(),'Recalculate')]")
    this.specialWaterLossLimitDialogTitle = page.locator("xpath=//mat-dialog-container[@aria-label='Special water loss limit dialog']//span[text()='Special water loss limit']"); // @FindBy(xpath = "//mat-dialog-container[@aria-label='Special water loss limit dialog']//span[text()='Special water loss limit']")
    this.fortifiedRoofUpgradeDialogTitle = page.locator("xpath=//mat-dialog-container//span[text()='Fortified Roof upgrade coverage']"); // @FindBy(xpath = "//mat-dialog-container//span[text()='Fortified Roof upgrade coverage']")
    this.dialogContent = page.locator("xpath=//mat-dialog-content//tui-simple-dialog-content"); // @FindBy(xpath = "//mat-dialog-content//tui-simple-dialog-content")
  }
}
