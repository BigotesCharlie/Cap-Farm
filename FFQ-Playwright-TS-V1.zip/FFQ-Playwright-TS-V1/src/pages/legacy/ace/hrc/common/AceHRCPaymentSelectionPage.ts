// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCPaymentSelectionPage. */
export class AceHRCPaymentSelectionPage extends CoreBasePage {
  public readonly howWouldYouLikeToPay: Locator;
  public readonly changeYourCoverageLink: Locator;
  public readonly baseOnThirdPartyInfoSubText: Locator;
  public readonly selectAndSetUpPaymentButtonPayInFull: Locator;
  public readonly selectAndSetUpPaymentButtonMonthlyBank: Locator;
  public readonly selectAndSetUpPaymentButtonMonthlyBankRenters: Locator;
  public readonly selectAndSetUpPaymentButtonMonthlyCard: Locator;
  public readonly selectAndSetUpPaymentButtonMonthlyCardLabel: Locator;
  public readonly selectAndSetUpPaymentButtonMonthlyBankPaymentLabel: Locator;
  public readonly payInMonthlyPayCardHeader: Locator;
  public readonly payInFullTabMobile: Locator;
  public readonly monthlyPayBankTabMobile: Locator;
  public readonly monthlyPayCardTabMobile: Locator;
  public readonly payForPropertyTitle: Locator;
  public readonly autoPaymentSuccessMessage: Locator;
  public readonly cardPaymentAmounts: Locator;

  public constructor(page: Page) {
    super(page);
    this.howWouldYouLikeToPay = page.locator("xpath=//div[contains(@class,'payment-overview')]//h1"); // @FindBy(xpath = "//div[contains(@class,'payment-overview')]//h1")
    this.changeYourCoverageLink = page.locator("xpath=//div[contains(@class,'payment-overview')]//a"); // @FindBy(xpath = "//div[contains(@class,'payment-overview')]//a")
    this.baseOnThirdPartyInfoSubText = page.locator("xpath=//div[contains(@class,'payment-overview-sub-para')]"); // @FindBy(xpath = "//div[contains(@class,'payment-overview-sub-para')]")
    this.selectAndSetUpPaymentButtonPayInFull = page.locator("xpath=//button[@aria-label='Pay in full, Select and setup payment']"); // @FindBy(xpath = "//button[@aria-label='Pay in full, Select and setup payment']")
    this.selectAndSetUpPaymentButtonMonthlyBank = page.locator("xpath=//button[@aria-label='Monthly autopay bank, Select and setup payment']"); // @FindBy(xpath = "//button[@aria-label='Monthly autopay bank, Select and setup payment']")
    this.selectAndSetUpPaymentButtonMonthlyBankRenters = page.locator("xpath=//input[@value='MTEF']"); // @FindBy(xpath = "//input[@value='MTEF']")
    this.selectAndSetUpPaymentButtonMonthlyCard = page.locator("xpath=//button[@aria-label='Monthly autopay card, Select and setup payment']"); // @FindBy(xpath = "//button[@aria-label='Monthly autopay card, Select and setup payment']")
    this.selectAndSetUpPaymentButtonMonthlyCardLabel = page.locator("xpath=//mat-radio-button[@value='card']//label"); // @FindBy(xpath = "//mat-radio-button[@value='card']//label")
    this.selectAndSetUpPaymentButtonMonthlyBankPaymentLabel = page.locator("xpath=//mat-radio-button[@value='bank']//label"); // @FindBy(xpath = "//mat-radio-button[@value='bank']//label")
    this.payInMonthlyPayCardHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_CARD_HEADER + "')]")
    this.payInFullTabMobile = page.locator("xpath=//mat-tab-group//div[@role='tab']//*[contains(text(),'"); // @FindBy(xpath = "//mat-tab-group//div[@role='tab']//*[contains(text(),'" + PAY_IN_FULL + "')]")
    this.monthlyPayBankTabMobile = page.locator("xpath=//mat-tab-group//div[@role='tab']//*[contains(text(),'"); // @FindBy(xpath = "//mat-tab-group//div[@role='tab']//*[contains(text(),'" + MONTHLY_PAY_BANK_HEADER + "')]")
    this.monthlyPayCardTabMobile = page.locator("xpath=//mat-tab-group//div[@role='tab']//*[contains(text(),'"); // @FindBy(xpath = "//mat-tab-group//div[@role='tab']//*[contains(text(),'" + MONTHLY_PAY_CARD_HEADER + "')]")
    this.payForPropertyTitle = page.locator("[data-legacy-field=\"payForPropertyTitle\"]"); // @FindBy(xpath = PAYMENT_OVERVIEW_HEADER_XPATH)
    this.autoPaymentSuccessMessage = page.locator("[data-legacy-field=\"autoPaymentSuccessMessage\"]"); // @FindBy(xpath = PAYMENT_OVERVIEW_HEADER_XPATH + "/following-sibling::div[1]")
    this.cardPaymentAmounts = page.locator("xpath=//mat-card//span[contains(@class,'payment-bank-downpayment')]"); // @FindBy(xpath = "//mat-card//span[contains(@class,'payment-bank-downpayment')]")
  }
}
