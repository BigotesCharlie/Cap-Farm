// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCCallForQuotePage. */
export class AceHRCCallForQuotePage extends CoreBasePage {
  public readonly pageTitle: Locator;
  public readonly pageSubTitle: Locator;
  public readonly pageSubHeader: Locator;
  public readonly pageSubHeader3: Locator;
  public readonly buttonToCall: Locator;
  public readonly linkToContinueFarmersQuoteOnline: Locator;
  public readonly autoIcon: Locator;
  public readonly bundleIcon: Locator;
  public readonly dollarIcon: Locator;
  public readonly autoSavingsText: Locator;
  public readonly bundleSavingsText: Locator;
  public readonly wealthDiscountText: Locator;
  public readonly farmersLogo: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageTitle = page.locator("xpath=//div//h1"); // @FindBy(xpath = "//div//h1")
    this.pageSubTitle = page.locator("xpath=//div[contains(@class,'aem-Grid aem-Grid--12 aem-Grid--default--12')]//div[@class='row justify-content-center']//p"); // @FindBy(xpath = "//div[contains(@class,'aem-Grid aem-Grid--12 aem-Grid--default--12')]//div[@class='row justify-content-center']//p")
    this.pageSubHeader = page.locator("xpath=//div//h1/following-sibling::p/span[1]"); // @FindBy(xpath = "//div//h1/following-sibling::p/span[1]")
    this.pageSubHeader3 = page.locator("xpath=//div//h1/following-sibling::p/span[2]"); // @FindBy(xpath = "//div//h1/following-sibling::p/span[2]")
    this.buttonToCall = page.locator("xpath=//a[contains(@class, 'button-cta--desktop') and @data-gtm='Farmers_COLPGS_CallLink_Header']"); // @FindBy(xpath = "//a[contains(@class, 'button-cta--desktop') and @data-gtm='Farmers_COLPGS_CallLink_Header']") //    private WebElement buttonToCallDesktop; // //    @FindBy(xpath = "//a[contains(@class, 'button-cta--mobile') and @data-gtm='Farmers_COLPGS_CallLink_Header']") //    private WebElement buttonToCallMobile;      @FindBy(xpath = "//a[contains(@href,'tel:')]")
    this.linkToContinueFarmersQuoteOnline = page.locator("[data-legacy-field=\"linkToContinueFarmersQuoteOnline\"]"); // @FindBy(linkText = CONTINUE_FARMERS_QUOTE_ONLINE_TEXT)
    this.autoIcon = page.locator("[data-legacy-field=\"autoIcon\"]"); // @FindBy(xpath = AUTO_ICON_XPATH)
    this.bundleIcon = page.locator("[data-legacy-field=\"bundleIcon\"]"); // @FindBy(xpath = BUNDLE_ICON_XPATH)
    this.dollarIcon = page.locator("[data-legacy-field=\"dollarIcon\"]"); // @FindBy(xpath = DOLLAR_ICON_XPATH)
    this.autoSavingsText = page.locator("[data-legacy-field=\"autoSavingsText\"]"); // @FindBy(xpath = AUTO_ICON_XPATH + ICON_FOLLOWING_SIBLING_XPATH)
    this.bundleSavingsText = page.locator("[data-legacy-field=\"bundleSavingsText\"]"); // @FindBy(xpath = BUNDLE_ICON_XPATH + ICON_FOLLOWING_SIBLING_XPATH)
    this.wealthDiscountText = page.locator("[data-legacy-field=\"wealthDiscountText\"]"); // @FindBy(xpath = DOLLAR_ICON_XPATH + ICON_FOLLOWING_SIBLING_XPATH)
    this.farmersLogo = page.locator("[data-legacy-field=\"farmersLogo\"]"); // @FindBy(xpath = XPATH_LOGO)
  }
}
