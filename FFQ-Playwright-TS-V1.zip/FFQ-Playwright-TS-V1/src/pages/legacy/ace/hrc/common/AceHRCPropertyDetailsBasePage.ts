// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCPropertyDetailsBasePage. */
export class AceHRCPropertyDetailsBasePage extends CoreBasePage {
  public readonly pageTitle: Locator;
  public readonly pageSubTitle: Locator;
  public readonly propertyDetailsPageSubTitle: Locator;
  public readonly propertyAddressLine1: Locator;
  public readonly propertyAddressLine2: Locator;
  public readonly editDetailsButton: Locator;
  public readonly reviewAndEditInfoButton: Locator;
  public readonly editHomeDetailsModalTitle: Locator;
  public readonly closeEditPropertyModal: Locator;
  public readonly closeEditHomeDetailsModal: Locator;
  public readonly editPropertyModalTitle: Locator;
  public readonly editPropertyModalText: Locator;
  public readonly editPropertyModalInput: Locator;
  public readonly editBathroomsPropertyModalInputs: Locator;
  public readonly editPropertyModalLabel: Locator;
  public readonly editBathroomsPropertyModalLabels: Locator;
  public readonly editPropertyModalCaption: Locator;
  public readonly editPropertyModalLightBulbText: Locator;
  public readonly editPropertyModalLowerLabel: Locator;
  public readonly editBathroomsPropertyModalSubTexts: Locator;
  public readonly updateEditPropertyModalButton: Locator;
  public readonly radioButton: Locator;
  public readonly editPropertyModalSelectedRadioButton: Locator;
  public readonly editPropertyModalSelectedAtticToggleButton: Locator;
  public readonly editPropertyModalCheckbox: Locator;
  public readonly editPropertyModalSelectedCheckbox: Locator;
  public readonly editPropertyModalLabels: Locator;
  public readonly seeExamples: Locator;
  public readonly examplesCategorySelect: Locator;
  public readonly examplesCategoryTitle: Locator;
  public readonly examplesCategorySelectArrow: Locator;
  public readonly categoryOptions: Locator;
  public readonly firstCategoryOption: Locator;
  public readonly subcategoryHeading: Locator;
  public readonly subcategoryText: Locator;
  public readonly subcategoryImage: Locator;
  public readonly closeEditPropertyExamplesModal: Locator;
  public readonly propertyUpdatedSnackbar: Locator;
  public readonly qualityGradeContainer: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageTitle = page.locator("xpath=//app-property-details//h1"); // @FindBy(xpath = "//app-property-details//h1")
    this.pageSubTitle = page.locator("xpath=//app-property-details//div[contains(@class,'home-property-details-header')]"); // @FindBy(xpath = "//app-property-details//div[contains(@class,'home-property-details-header')]")
    this.propertyDetailsPageSubTitle = page.locator("xpath=//app-property-details//div[contains(@class,'home-property-details-container')]//span[contains(text(),'Please check the information below')]"); // @FindBy(xpath = "//app-property-details//div[contains(@class,'home-property-details-container')]//span[contains(text(),'Please check the information below')]")
    this.propertyAddressLine1 = page.locator("xpath=//app-property-details//div[contains(@class,'property-details-address-holder')]/div[1]"); // @FindBy(xpath = "//app-property-details//div[contains(@class,'property-details-address-holder')]/div[1]")
    this.propertyAddressLine2 = page.locator("xpath=//app-property-details//div[contains(@class,'property-details-address-holder')]/div[2]"); // @FindBy(xpath = "//app-property-details//div[contains(@class,'property-details-address-holder')]/div[2]")
    this.editDetailsButton = page.locator("xpath=//app-property-details//button[@aria-label='Edit Home details']"); // @FindBy(xpath = "//app-property-details//button[@aria-label='Edit Home details']")
    this.reviewAndEditInfoButton = page.locator("xpath=//app-property-details//button[text()='Review & edit information']"); // @FindBy(xpath = "//app-property-details//button[text()='Review & edit information']")
    this.editHomeDetailsModalTitle = page.locator("xpath=//tui-subcategory-selector-modal//h2"); // @FindBy(xpath = "//tui-subcategory-selector-modal//h2")
    this.closeEditPropertyModal = page.locator("xpath=//tui-subcategory-modal//mat-icon[text()='close']"); // @FindBy(xpath = "//tui-subcategory-modal//mat-icon[text()='close']")
    this.closeEditHomeDetailsModal = page.locator("xpath=//tui-subcategory-selector-modal//button[contains(text(),'Close')]"); // @FindBy(xpath = "//tui-subcategory-selector-modal//button[contains(text(),'Close')]")
    this.editPropertyModalTitle = page.locator("xpath=//tui-subcategory-modal//h2"); // @FindBy(xpath = "//tui-subcategory-modal//h2")
    this.editPropertyModalText = page.locator("xpath=//tui-subcategory-modal//div[contains(@class,'tui-input-text')]"); // @FindBy(xpath = "//tui-subcategory-modal//div[contains(@class,'tui-input-text')]")
    this.editPropertyModalInput = page.locator("xpath=//tui-subcategory-modal//div[contains(@class,'tui-input-text')]/following-sibling::div//input"); // @FindBy(xpath = "//tui-subcategory-modal//div[contains(@class,'tui-input-text')]/following-sibling::div//input")
    this.editBathroomsPropertyModalInputs = page.locator("xpath=//tui-subcategory-modal//div[contains(@class,'tui-input-text')]/following-sibling::div//input"); // @FindBy(xpath = "//tui-subcategory-modal//div[contains(@class,'tui-input-text')]/following-sibling::div//input")
    this.editPropertyModalLabel = page.locator("xpath=//tui-subcategory-modal//div[contains(@class,'tui-input-text')]/following-sibling::div//label"); // @FindBy(xpath = "//tui-subcategory-modal//div[contains(@class,'tui-input-text')]/following-sibling::div//label")
    this.editBathroomsPropertyModalLabels = page.locator("xpath=//tui-subcategory-modal//div[contains(@class,'tui-input-text-2')]"); // @FindBy(xpath = "//tui-subcategory-modal//div[contains(@class,'tui-input-text-2')]")
    this.editPropertyModalCaption = page.locator("xpath=//tui-subcategory-modal//div[contains(@class,'tui-input-text')]/following-sibling::div[contains(@class,'tui-caption')]"); // @FindBy(xpath = "//tui-subcategory-modal//div[contains(@class,'tui-input-text')]/following-sibling::div[contains(@class,'tui-caption')]")
    this.editPropertyModalLightBulbText = page.locator("xpath=//tui-subcategory-modal//div[contains(@class,'tui-subcategory-lightbulb-icon-container')]//div[contains(@class,'tui-caption')]"); // @FindBy(xpath = "//tui-subcategory-modal//div[contains(@class,'tui-subcategory-lightbulb-icon-container')]//div[contains(@class,'tui-caption')]")
    this.editPropertyModalLowerLabel = page.locator("xpath=//tui-subcategory-modal//div[contains(@class,'tui-field-label')]"); // @FindBy(xpath = "//tui-subcategory-modal//div[contains(@class,'tui-field-label')]")
    this.editBathroomsPropertyModalSubTexts = page.locator("xpath=//tui-subcategory-modal//div[contains(@class,'textfield-subtext')]"); // @FindBy(xpath = "//tui-subcategory-modal//div[contains(@class,'textfield-subtext')]")
    this.updateEditPropertyModalButton = page.locator("xpath=//tui-subcategory-modal//button[text()='Update']"); // @FindBy(xpath = "//tui-subcategory-modal//button[text()='Update']")
    this.radioButton = page.locator("[data-legacy-field=\"radioButton\"]"); // @FindBy(xpath = EDIT_MODAL_RADIO_BUTTON_XPATH)
    this.editPropertyModalSelectedRadioButton = page.locator("[data-legacy-field=\"editPropertyModalSelectedRadioButton\"]"); // @FindBy(xpath = EDIT_MODAL_RADIO_BUTTON_XPATH + "[contains(@class,'radio-checked')]")
    this.editPropertyModalSelectedAtticToggleButton = page.locator("[data-legacy-field=\"editPropertyModalSelectedAtticToggleButton\"]"); // @FindBy(xpath = EDIT_MODAL_TOGGLE_BUTTON_XPATH + "[contains(@class,'toggle-checked')]")
    this.editPropertyModalCheckbox = page.locator("[data-legacy-field=\"editPropertyModalCheckbox\"]"); // @FindBy(xpath = EDIT_MODAL_CHECKBOX_XPATH)
    this.editPropertyModalSelectedCheckbox = page.locator("[data-legacy-field=\"editPropertyModalSelectedCheckbox\"]"); // @FindBy(xpath = EDIT_MODAL_CHECKBOX_XPATH + EDIT_MODAL_CHECKBOX_CHECKED_XPATH)
    this.editPropertyModalLabels = page.locator("xpath=//tui-subcategory-selector-modal//div[contains(@class,'tui-field-label')]"); // @FindBy(xpath = "//tui-subcategory-selector-modal//div[contains(@class,'tui-field-label')]")
    this.seeExamples = page.locator("xpath=//mat-dialog-container//button[contains(text(),'See examples')]"); // @FindBy(xpath = "//mat-dialog-container//button[contains(text(),'See examples')]")
    this.examplesCategorySelect = page.locator("xpath=//mat-dialog-container//mat-select"); // @FindBy(xpath = "//mat-dialog-container//mat-select")
    this.examplesCategoryTitle = page.locator("xpath=//tui-subcategory-examples-modal//h2"); // @FindBy(xpath = "//tui-subcategory-examples-modal//h2")
    this.examplesCategorySelectArrow = page.locator("xpath=//mat-dialog-container//mat-select"); // @FindBy(xpath = "//mat-dialog-container//mat-select")
    this.categoryOptions = page.locator("[data-legacy-field=\"categoryOptions\"]"); // @FindBy(xpath = CATEGORIES_LISTBOX_XPATH + "/mat-option")
    this.firstCategoryOption = page.locator("[data-legacy-field=\"firstCategoryOption\"]"); // @FindBy(xpath = CATEGORIES_LISTBOX_XPATH + "/mat-option")
    this.subcategoryHeading = page.locator("xpath=//div[contains(@class,'subcategory-examples')]/div/div[1]"); // @FindBy(xpath = "//div[contains(@class,'subcategory-examples')]/div/div[1]")
    this.subcategoryText = page.locator("xpath=//div[contains(@class,'subcategory-examples')]/div/div[2]"); // @FindBy(xpath = "//div[contains(@class,'subcategory-examples')]/div/div[2]")
    this.subcategoryImage = page.locator("xpath=//div[contains(@class,'subcategory-examples')]/div/img"); // @FindBy(xpath = "//div[contains(@class,'subcategory-examples')]/div/img")
    this.closeEditPropertyExamplesModal = page.locator("xpath=//tui-subcategory-examples-modal//mat-icon[text()='close']"); // @FindBy(xpath = "//tui-subcategory-examples-modal//mat-icon[text()='close']")
    this.propertyUpdatedSnackbar = page.locator("xpath=//tui-subcategory-selector-modal//*[contains(@class,'mat-simple-snackbar')]"); // @FindBy(xpath = "//tui-subcategory-selector-modal//*[contains(@class,'mat-simple-snackbar')]")
    this.qualityGradeContainer = page.locator("xpath=//app-property-details//div[contains(@class,'quality-grade-container')]"); // @FindBy(xpath = "//app-property-details//div[contains(@class,'quality-grade-container')]")
  }
}
