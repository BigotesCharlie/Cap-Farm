// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCConsolidatedPaymentPage. */
export class AceHRCConsolidatedPaymentPage extends CoreBasePage {
  public readonly feeInfoIcon: Locator;
  public readonly alternateInfoIcon: Locator;
  public readonly linkToCoverageSubText: Locator;

  public constructor(page: Page) {
    super(page);
    this.feeInfoIcon = page.locator("xpath=//p[contains(text(), 'Fees')]/preceding-sibling::mat-icon[@role='img']"); // @FindBy(xpath = "//p[contains(text(), 'Fees')]/preceding-sibling::mat-icon[@role='img']")
    this.alternateInfoIcon = page.locator("xpath=//mat-icon[contains(@class, 'info-box-icon')]"); // @FindBy(xpath = "//mat-icon[contains(@class, 'info-box-icon')]")
    this.linkToCoverageSubText = page.locator("xpath=//div[contains(@class, 'payment-overview-sub-para')]"); // @FindBy(xpath = "//div[contains(@class, 'payment-overview-sub-para')]")
  }
}
