// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCAddressBasePage. */
export class AceHRCAddressBasePage extends CoreBasePage {
  public readonly addressPageTitle: Locator;
  public readonly propertyTypeTitleMediaAlpha: Locator;
  public readonly addressSubheading: Locator;
  public readonly newHomeSubheading: Locator;
  public readonly inEscrowSubheading: Locator;
  public readonly primaryResidenceSubheading: Locator;
  public readonly hoaCoverageSubheading: Locator;
  public readonly hoaCoverageDetailsSubheading: Locator;
  public readonly propertyLossesSubheading: Locator;
  public readonly formFieldAddressInput: Locator;
  public readonly addressFieldCrossIcon: Locator;
  public readonly formFieldAddressManualInput: Locator;
  public readonly formFieldUnitInput: Locator;
  public readonly formFieldCityInput: Locator;
  public readonly formFieldZipCodeInput: Locator;
  public readonly closeModalPopupButton: Locator;
  public readonly homeBuyerDiscountMessage: Locator;
  public readonly hoaCoverageHelpTitle: Locator;
  public readonly hoaCoverageHelpText: Locator;
  public readonly formFieldEditAddressInput: Locator;
  public readonly formFieldEditApartmentInput: Locator;
  public readonly formFieldEditCityInput: Locator;
  public readonly formFieldEditStateSelect: Locator;
  public readonly formFieldEditZipCodeInput: Locator;
  public readonly saveButton: Locator;
  public readonly formEditAddressErrors: Locator;
  public readonly changeZipHeader: Locator;
  public readonly buttonZipChangeYes: Locator;
  public readonly buttonZipChangeGoBack: Locator;
  public readonly editAddressStreet: Locator;
  public readonly editAddressStateCode: Locator;
  public readonly editAddressZipCode: Locator;
  public readonly goBackButton: Locator;
  public readonly formFieldEmailAddressInput: Locator;
  public readonly formFieldPhoneNumberInput: Locator;
  public readonly agreeAndSubmitButton: Locator;
  public readonly linkEnterYourAddressManually: Locator;
  public readonly linkCheckYourEligibility: Locator;
  public readonly inputEmployerGroup: Locator;
  public readonly employerOption: Locator;
  public readonly continueWithGroupDiscountButton: Locator;
  public readonly groupEmployerName: Locator;

  public constructor(page: Page) {
    super(page);
    this.addressPageTitle = page.locator("xpath=//app-personal-info//div[contains(@class,'personal-info_address_h1')]//h1"); // @FindBy(xpath = "//app-personal-info//div[contains(@class,'personal-info_address_h1')]//h1")
    this.propertyTypeTitleMediaAlpha = page.locator("xpath=//app-property-type//*[@id='propertyTypeLabelSrOnly']"); // @FindBy(xpath = "//app-property-type//*[@id='propertyTypeLabelSrOnly']")
    this.addressSubheading = page.locator("xpath=//app-personal-info//div[@id='auto-personal-info_address-subheading']"); // @FindBy(xpath = "//app-personal-info//div[@id='auto-personal-info_address-subheading']")
    this.newHomeSubheading = page.locator("xpath=//app-personal-info//div[contains(@class,'new-home')]/label"); // @FindBy(xpath = "//app-personal-info//div[contains(@class,'new-home')]/label")
    this.inEscrowSubheading = page.locator("xpath=//app-personal-info//div[contains(@class,'escrow')]/label"); // @FindBy(xpath = "//app-personal-info//div[contains(@class,'escrow')]/label")
    this.primaryResidenceSubheading = page.locator("xpath=//app-personal-info//div[contains(@class,'primary-residence')]/h2"); // @FindBy(xpath = "//app-personal-info//div[contains(@class,'primary-residence')]/h2")
    this.hoaCoverageSubheading = page.locator("xpath=//app-personal-info//div[contains(@class,'HOATextValue-title')]/label"); // @FindBy(xpath = "//app-personal-info//div[contains(@class,'HOATextValue-title')]/label")
    this.hoaCoverageDetailsSubheading = page.locator("xpath=//app-personal-info//div[contains(@class,'hoa-cover_element')]/label"); // @FindBy(xpath = "//app-personal-info//div[contains(@class,'hoa-cover_element')]/label")
    this.propertyLossesSubheading = page.locator("xpath=//app-personal-info//div[contains(@class,'property-losses')]/label"); // @FindBy(xpath = "//app-personal-info//div[contains(@class,'property-losses')]/label")
    this.formFieldAddressInput = page.locator("[data-legacy-field=\"formFieldAddressInput\"]"); // @FindBy(xpath = ADDRESS_INPUT_FIELD_XPATH)
    this.addressFieldCrossIcon = page.locator("xpath=//app-personal-info//mat-form-field[@id='auto-manual-address-street__input-field']//mat-icon[contains(text(),'close')]"); // @FindBy(xpath = "//app-personal-info//mat-form-field[@id='auto-manual-address-street__input-field']//mat-icon[contains(text(),'close')]")
    this.formFieldAddressManualInput = page.locator("[data-legacy-field=\"formFieldAddressManualInput\"]"); // @FindBy(xpath = ADDRESS_INPUT_FIELD_MANUAL_XPATH)
    this.formFieldUnitInput = page.locator("xpath=//app-personal-info//div[@id='formField_apartment']//input"); // @FindBy(xpath = "//app-personal-info//div[@id='formField_apartment']//input")
    this.formFieldCityInput = page.locator("xpath=//app-personal-info//div[@id='formField_city']//input"); // @FindBy(xpath = "//app-personal-info//div[@id='formField_city']//input")
    this.formFieldZipCodeInput = page.locator("xpath=//app-personal-info//div[@id='formField_zipCode']//input"); // @FindBy(xpath = "//app-personal-info//div[@id='formField_zipCode']//input")
    this.closeModalPopupButton = page.locator("xpath=//app-edit-address//mat-icon[@role='button']"); // @FindBy(xpath = "//app-edit-address//mat-icon[@role='button']")
    this.homeBuyerDiscountMessage = page.locator("xpath=//div[@role='alert' and contains(@class,'home-buyer__congratulations-message')]"); // @FindBy(xpath = "//div[@role='alert' and contains(@class,'home-buyer__congratulations-message')]")
    this.hoaCoverageHelpTitle = page.locator("[data-legacy-field=\"hoaCoverageHelpTitle\"]"); // @FindBy(xpath = HOA_COVERAGE_HELP_SECTION_XPATH + "/h3")
    this.hoaCoverageHelpText = page.locator("[data-legacy-field=\"hoaCoverageHelpText\"]"); // @FindBy(xpath = HOA_COVERAGE_HELP_SECTION_XPATH + "/p")
    this.formFieldEditAddressInput = page.locator("xpath=(//app-edit-address//input[@id='auto-edit-street__input-section'])[2]"); // @FindBy(xpath = "(//app-edit-address//input[@id='auto-edit-street__input-section'])[2]")
    this.formFieldEditApartmentInput = page.locator("xpath=//app-edit-address//input[@id='auto-edit-apartment__input-section']"); // @FindBy(xpath = "//app-edit-address//input[@id='auto-edit-apartment__input-section']")
    this.formFieldEditCityInput = page.locator("xpath=//app-edit-address//input[@aria-label='city']"); // @FindBy(xpath = "//app-edit-address//input[@aria-label='city']")
    this.formFieldEditStateSelect = page.locator("xpath=//app-edit-address//mat-select[@aria-label='State']"); // @FindBy(xpath = "//app-edit-address//mat-select[@aria-label='State']")
    this.formFieldEditZipCodeInput = page.locator("xpath=//app-edit-address//input[@aria-label='zipCode']"); // @FindBy(xpath = "//app-edit-address//input[@aria-label='zipCode']")
    this.saveButton = page.locator("xpath=//app-edit-address//button[contains(text(),'Save')]"); // @FindBy(xpath = "//app-edit-address//button[contains(text(),'Save')]")
    this.formEditAddressErrors = page.locator("xpath=//app-edit-address//mat-error"); // @FindBy(xpath = "//app-edit-address//mat-error")
    this.changeZipHeader = page.locator("[data-legacy-field=\"changeZipHeader\"]"); // @FindBy(xpath = CHANGE_ZIP_TITLE_XPATH)
    this.buttonZipChangeYes = page.locator("xpath=//app-change-zip//button[contains(text(),'Yes')]"); // @FindBy(xpath = "//app-change-zip//button[contains(text(),'Yes')]")
    this.buttonZipChangeGoBack = page.locator("xpath=//app-change-zip//a[contains(text(),'Go back')]"); // @FindBy(xpath = "//app-change-zip//a[contains(text(),'Go back')]")
    this.editAddressStreet = page.locator("xpath=//app-edit-address//input[@aria-label='Street number and name']"); // @FindBy(xpath = "//app-edit-address//input[@aria-label='Street number and name']")
    this.editAddressStateCode = page.locator("xpath=//app-edit-address//mat-select[@aria-label='State']"); // @FindBy(xpath = "//app-edit-address//mat-select[@aria-label='State']")
    this.editAddressZipCode = page.locator("xpath=//app-edit-address//input[@aria-label='zipCode']"); // @FindBy(xpath = "//app-edit-address//input[@aria-label='zipCode']")
    this.goBackButton = page.getByRole('link', { name: "Go back", exact: true }); // @FindBy(linkText = "Go back")
    this.formFieldEmailAddressInput = page.locator("[data-legacy-field=\"formFieldEmailAddressInput\"]"); // @FindBy(xpath = EMAIL_ADDRESS_XPATH)
    this.formFieldPhoneNumberInput = page.locator("xpath=//app-personal-info//input[@name='phoneNumber']"); // @FindBy(xpath = "//app-personal-info//input[@name='phoneNumber']")
    this.agreeAndSubmitButton = page.locator("xpath=//app-personal-info//button[text()='Agree and submit']"); // @FindBy(xpath = "//app-personal-info//button[text()='Agree and submit']")
    this.linkEnterYourAddressManually = page.getByRole('link', { name: "enter your address manually", exact: true }); // @FindBy(linkText = "enter your address manually")
    this.linkCheckYourEligibility = page.getByRole('link', { name: "Check your eligibility", exact: true }); // @FindBy(linkText = "Check your eligibility")
    this.inputEmployerGroup = page.locator("xpath=//app-farmers-groupselect-sidesheet//input"); // @FindBy(xpath = "//app-farmers-groupselect-sidesheet//input")
    this.employerOption = page.locator("[data-legacy-field=\"employerOption\"]"); // @FindBy(xpath = EMPLOYER_GROUP_LIST_XPATH)
    this.continueWithGroupDiscountButton = page.locator("xpath=//app-farmers-groupselect-sidesheet//button"); // @FindBy(xpath = "//app-farmers-groupselect-sidesheet//button")
    this.groupEmployerName = page.locator("xpath=//div[@class='selected_employer_name']"); // @FindBy(xpath = "//div[@class='selected_employer_name']")
  }
}
