// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCBasePage. */
export class AceHRCBasePage extends CoreBasePage {
  public readonly farmersLogoNavbar: Locator;
  public readonly phoneLink: Locator;
  public readonly stateDropDownOptions: Locator;
  public readonly navStepperDesktop: Locator;
  public readonly navStepperMobile: Locator;
  public readonly farmersLogoFooter: Locator;
  public readonly footerPersonalInfoUseLink: Locator;
  public readonly footerDigitalAccessibilityLink: Locator;
  public readonly footerTermsOfUseLink: Locator;
  public readonly footerPrivacyCenterLink: Locator;
  public readonly footerNoticeOfInformationPracticesLink: Locator;
  public readonly footerDoNotSellLink: Locator;
  public readonly modalPrivacyChoicesTitle: Locator;
  public readonly modalPrivacyChoicesSaveButton: Locator;
  public readonly modalPrivacyChoicesCloseButton: Locator;
  public readonly discountsDescription: Locator;
  public readonly discountPiggyBankImageCard: Locator;
  public readonly reviewDiscountsLink: Locator;
  public readonly quoteProgressSavedText: Locator;
  public readonly closeDiscountsSidesheet: Locator;
  public readonly footerDiscountsSidesheet: Locator;
  public readonly tryAgainButton: Locator;
  public readonly addressListBox: Locator;
  public readonly errorMessage: Locator;
  public readonly saveInProgressFooter: Locator;
  public readonly quoteNumberText: Locator;
  public readonly termsESignContactInfoPage: Locator;
  public readonly associatedEntitiesContactInfoPage: Locator;
  public readonly yourAgent: Locator;
  public readonly agentsImage: Locator;
  public readonly agentName: Locator;
  public readonly agentPhoneLink: Locator;
  public readonly agentEmailLink: Locator;
  public readonly agentAddressLink: Locator;
  public readonly tollFreeNumber2: Locator;
  public readonly agentInfo: Locator;
  public readonly agentFXAgency: Locator;
  public readonly sideSheet: Locator;
  public readonly priorHomeAddressInputField: Locator;
  public readonly priorHomeCityInputField: Locator;
  public readonly priorHomeUnitInputField: Locator;
  public readonly priorHomeStateSelectField: Locator;
  public readonly priorHomeZipInputField: Locator;
  public readonly payrollDeductionBannerTitle: Locator;
  public readonly payrollDeductionBannerContent: Locator;
  public readonly payrollDeductionEmployer: Locator;
  public readonly payrollDeductionBannerContactInfo: Locator;
  public readonly foremostLogoIcon: Locator;
  public readonly foremostPageHeader: Locator;

  public constructor(page: Page) {
    super(page);
    this.farmersLogoNavbar = page.locator("xpath=//tui-stepper-navbar//img[@data-test-id='TUI_LOGO_NO_LINK']"); // @FindBy(xpath = "//tui-stepper-navbar//img[@data-test-id='TUI_LOGO_NO_LINK']")
    this.phoneLink = page.locator("xpath=//tui-stepper-navbar//a[@data-tui-tracking-id='navbar-phone-link']"); // @FindBy(xpath = "//tui-stepper-navbar//a[@data-tui-tracking-id='navbar-phone-link']")
    this.stateDropDownOptions = page.locator("xpath=//mat-option"); // @FindBy(xpath = "//mat-option")
    this.navStepperDesktop = page.locator("xpath=//tui-stepper-navbar//div[@class='tui-desktop-nav-stepper']"); // @FindBy(xpath = "//tui-stepper-navbar//div[@class='tui-desktop-nav-stepper']")
    this.navStepperMobile = page.locator("xpath=//tui-stepper-navbar//div[@class='tui-mobile-nav-stepper']"); // @FindBy(xpath = "//tui-stepper-navbar//div[@class='tui-mobile-nav-stepper']")
    this.farmersLogoFooter = page.locator("xpath=//tui-oneui-footer//div[contains(@class,'tui-oneui-footer-logo-container')]/img"); // @FindBy(xpath = "//tui-oneui-footer//div[contains(@class,'tui-oneui-footer-logo-container')]/img")
    this.footerPersonalInfoUseLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_personal-information-use']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_personal-information-use']")
    this.footerDigitalAccessibilityLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_digital-accessibility']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_digital-accessibility']")
    this.footerTermsOfUseLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_terms-of-use']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_terms-of-use']")
    this.footerPrivacyCenterLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_privacy-center']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_privacy-center']")
    this.footerNoticeOfInformationPracticesLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_notice-of-information-practices']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_notice-of-information-practices']")
    this.footerDoNotSellLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_do-not-sell']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_do-not-sell']")
    this.modalPrivacyChoicesTitle = page.locator("xpath=//div[@role='dialog']//h4[text()='Notice of Right to Opt-Out']"); // @FindBy(xpath = "//div[@role='dialog']//h4[text()='Notice of Right to Opt-Out']")
    this.modalPrivacyChoicesSaveButton = page.locator("xpath=//div[@role='dialog']//button[contains(@class,'save-preference-btn')]"); // @FindBy(xpath = "//div[@role='dialog']//button[contains(@class,'save-preference-btn')]")
    this.modalPrivacyChoicesCloseButton = page.locator("xpath=//div[@role='dialog']//button[@id='close-pc-btn-handler']"); // @FindBy(xpath = "//div[@role='dialog']//button[@id='close-pc-btn-handler']")
    this.discountsDescription = page.locator("xpath=//div[contains(@class,'discount-description')]/p[contains(@class,'tui-subtitle')]"); // @FindBy(xpath = "//div[contains(@class,'discount-description')]/p[contains(@class,'tui-subtitle')]")
    this.discountPiggyBankImageCard = page.locator("xpath=//app-home-discount//img[@alt='Discounts logo']"); // @FindBy(xpath = "//app-home-discount//img[@alt='Discounts logo']")
    this.reviewDiscountsLink = page.locator("xpath=//p[contains(text(),'Review discount')]"); // @FindBy(xpath = "//p[contains(text(),'Review discount')]")
    this.quoteProgressSavedText = page.locator("xpath=//div[contains(@class,'save-in-progress-section')]/p"); // @FindBy(xpath = "//div[contains(@class,'save-in-progress-section')]/p")
    this.closeDiscountsSidesheet = page.locator("xpath=//app-home-discount-sidesheet//mat-icon[text()='close']"); // @FindBy(xpath = "//app-home-discount-sidesheet//mat-icon[text()='close']")
    this.footerDiscountsSidesheet = page.locator("xpath=//app-home-discount-sidesheet//div[contains(@class,'lightbulb-container')]/following-sibling::div"); // @FindBy(xpath = "//app-home-discount-sidesheet//div[contains(@class,'lightbulb-container')]/following-sibling::div")
    this.tryAgainButton = page.locator("[data-legacy-field=\"tryAgainButton\"]"); // @FindBy(xpath = TRY_AGAIN_BUTTON_XPATH)
    this.addressListBox = page.locator("xpath=//div[@role='listbox']"); // @FindBy(xpath = "//div[@role='listbox']")
    this.errorMessage = page.locator("[data-legacy-field=\"errorMessage\"]"); // @FindBy(xpath = ERROR_MESSAGE_XPATH)
    this.saveInProgressFooter = page.locator("xpath=//div[contains(@class,'save-in-progress')]/p"); // @FindBy(xpath = "//div[contains(@class,'save-in-progress')]/p")
    this.quoteNumberText = page.locator("xpath=//div[contains(@class,'save-quote')]"); // @FindBy(xpath = "//div[contains(@class,'save-quote')]")
    this.termsESignContactInfoPage = page.locator("xpath=//a[normalize-space()='these ESIGN term and conditions']"); // @FindBy(xpath = "//a[normalize-space()='these ESIGN term and conditions']")
    this.associatedEntitiesContactInfoPage = page.locator("xpath=//a[text()='associated entities']"); // @FindBy(xpath = "//a[text()='associated entities']")
    this.yourAgent = page.locator("xpath=//app-agent-details//div[contains(text(),'"); // @FindBy(xpath = "//app-agent-details//div[contains(text(),'" + YOUR_AGENT + "')]")
    this.agentsImage = page.locator("[data-legacy-field=\"agentsImage\"]"); // @FindBy(xpath = AGENT_IMAGE_XPATH)
    this.agentName = page.locator("xpath=//app-agent-details//div[contains(@class,'tui-body-bold')]"); // @FindBy(xpath = "//app-agent-details//div[contains(@class,'tui-body-bold')]")
    this.agentPhoneLink = page.locator("xpath=//app-agent-details//a[contains(@class,'tui-link-footer') and contains(@href,'tel:')]"); // @FindBy(xpath = "//app-agent-details//a[contains(@class,'tui-link-footer') and contains(@href,'tel:')]")
    this.agentEmailLink = page.locator("xpath=//app-agent-details//a[contains(@class,'tui-link-footer') and contains(@href,'mailto:')]"); // @FindBy(xpath = "//app-agent-details//a[contains(@class,'tui-link-footer') and contains(@href,'mailto:')]")
    this.agentAddressLink = page.locator("xpath=//app-agent-details//a[contains(@class,'tui-link-footer') and contains(@href,'maps')]"); // @FindBy(xpath = "//app-agent-details//a[contains(@class,'tui-link-footer') and contains(@href,'maps')]")
    this.tollFreeNumber2 = page.locator("xpath=//div[contains(@class,'agent-details-container')]//a[starts-with(@aria-label,'Contact farmers representative at')]"); // @FindBy(xpath = "//div[contains(@class,'agent-details-container')]//a[starts-with(@aria-label,'Contact farmers representative at')]")
    this.agentInfo = page.locator("xpath=//app-agent-details//div[contains(@class,'tui-agent-box')]"); // @FindBy(xpath = "//app-agent-details//div[contains(@class,'tui-agent-box')]")
    this.agentFXAgency = page.locator("xpath=//app-agent-details//div[contains(@class,'tui-body') and contains(.,'FX Insurance Agency LLC')]"); // @FindBy(xpath = "//app-agent-details//div[contains(@class,'tui-body') and contains(.,'FX Insurance Agency LLC')]")
    this.sideSheet = page.locator("xpath=//mat-dialog-container/parent::div"); // @FindBy(xpath = "//mat-dialog-container/parent::div")
    this.priorHomeAddressInputField = page.locator("[data-legacy-field=\"priorHomeAddressInputField\"]"); // @FindBy(xpath = PRIOR_HOME_ADDRESS_INPUT_FIELD_XPATH)
    this.priorHomeCityInputField = page.locator("[data-legacy-field=\"priorHomeCityInputField\"]"); // @FindBy(xpath = PRIOR_HOME_CITY_INPUT_FIELD_XPATH)
    this.priorHomeUnitInputField = page.locator("[data-legacy-field=\"priorHomeUnitInputField\"]"); // @FindBy(xpath = PRIOR_HOME_UNIT_INPUT_FIELD_XPATH)
    this.priorHomeStateSelectField = page.locator("[data-legacy-field=\"priorHomeStateSelectField\"]"); // @FindBy(xpath = PRIOR_HOME_STATE_SELECT_FIELD_XPATH)
    this.priorHomeZipInputField = page.locator("[data-legacy-field=\"priorHomeZipInputField\"]"); // @FindBy(xpath = PRIOR_HOME_ZIP_INPUT_FIELD_XPATH)
    this.payrollDeductionBannerTitle = page.locator("[data-legacy-field=\"payrollDeductionBannerTitle\"]"); // @FindBy(xpath = PAYROLL_DEDUCTION_BANNER_XPATH + "//p[1]")
    this.payrollDeductionBannerContent = page.locator("[data-legacy-field=\"payrollDeductionBannerContent\"]"); // @FindBy(xpath = PAYROLL_DEDUCTION_BANNER_XPATH + "//p[2]")
    this.payrollDeductionEmployer = page.locator("[data-legacy-field=\"payrollDeductionEmployer\"]"); // @FindBy(xpath = PAYROLL_DEDUCTION_BANNER_XPATH + "//b")
    this.payrollDeductionBannerContactInfo = page.locator("[data-legacy-field=\"payrollDeductionBannerContactInfo\"]"); // @FindBy(xpath = PAYROLL_DEDUCTION_BANNER_XPATH + "//p[3]")
    this.foremostLogoIcon = page.locator("xpath=//img[@alt = 'Foremost logo']"); // @FindBy(xpath = "//img[@alt = 'Foremost logo']")
    this.foremostPageHeader = page.locator("xpath=//div[contains(@class, 'mobilehome-logo-body')]"); // @FindBy(xpath = "//div[contains(@class, 'mobilehome-logo-body')]")
  }
}
