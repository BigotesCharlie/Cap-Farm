// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCPropertyBasePage. */
export class AceHRCPropertyBasePage extends CoreBasePage {
  public readonly pageTitle: Locator;
  public readonly propertyAddressLine1: Locator;
  public readonly propertyAddressLine2: Locator;
  public readonly yearBuiltFormField: Locator;
  public readonly yearBuiltInput: Locator;
  public readonly totalSqFtFormField: Locator;
  public readonly totalSqFtInput: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageTitle = page.locator("xpath=//app-yearbuilt-area//h1"); // @FindBy(xpath = "//app-yearbuilt-area//h1")
    this.propertyAddressLine1 = page.locator("xpath=//app-yearbuilt-area//h2"); // @FindBy(xpath = "//app-yearbuilt-area//h2")
    this.propertyAddressLine2 = page.locator("xpath=//app-yearbuilt-area//div[contains(@class,'home-yearbuilt-area-address-holder')]"); // @FindBy(xpath = "//app-yearbuilt-area//div[contains(@class,'home-yearbuilt-area-address-holder')]")
    this.yearBuiltFormField = page.locator("[data-legacy-field=\"yearBuiltFormField\"]"); // @FindBy(xpath = YEAR_BUILT_XPATH + "//mat-form-field")
    this.yearBuiltInput = page.locator("[data-legacy-field=\"yearBuiltInput\"]"); // @FindBy(xpath = YEAR_BUILT_XPATH + "//input")
    this.totalSqFtFormField = page.locator("xpath=//app-yearbuilt-area//input[@id='sqFeet']/ancestor::mat-form-field"); // @FindBy(xpath = "//app-yearbuilt-area//input[@id='sqFeet']/ancestor::mat-form-field")
    this.totalSqFtInput = page.locator("xpath=//app-yearbuilt-area//mat-form-field//input[@id='sqFeet']"); // @FindBy(xpath = "//app-yearbuilt-area//mat-form-field//input[@id='sqFeet']")
  }
}
