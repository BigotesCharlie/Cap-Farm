// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCJustAFewMoreThingsBasePage. */
export class AceHRCJustAFewMoreThingsBasePage extends CoreBasePage {
  public readonly justFewMoreThingsTitle: Locator;
  public readonly bundlePropertyJustFewMoreThingsTitle: Locator;
  public readonly justFewMoreThingsLabelInfoSubHeader: Locator;
  public readonly lenderInfoLabel: Locator;
  public readonly lenderInfoSubLabel: Locator;
  public readonly whyDoYouNeedMyLenderInfoIcon: Locator;
  public readonly whyDoYouNeedMyLenderInfoLabel: Locator;
  public readonly whyDoYouNeedMyLenderInfoContent: Locator;
  public readonly whyDoYouNeedMyLenderInfoLabelMobile: Locator;
  public readonly whyDoYouNeedMyLenderInfoContentMobile: Locator;
  public readonly lenderInfoHeaderSideSheet: Locator;
  public readonly lenderAddressSubHeader: Locator;
  public readonly formFieldCertificateExpDate: Locator;
  public readonly formFieldCertificateExpDateFormat: Locator;
  public readonly certExpDateInputField: Locator;
  public readonly certExpDateInputFieldList: Locator;
  public readonly certificationErrorLabel: Locator;
  public readonly certificateExpDatePickerButtonFMTPHome: Locator;
  public readonly formFieldLenderZipOrState: Locator;
  public readonly formFieldLenderName: Locator;
  public readonly lenderInfoPopUpHeader: Locator;
  public readonly lenderAddressSideSheetHeader: Locator;
  public readonly lenderAddressSideSheetSubHeader: Locator;
  public readonly editButtonPrimaryHeatingSource: Locator;
  public readonly editButtonDogsOnPremises: Locator;
  public readonly nextButton: Locator;
  public readonly lenderZipOrStateTextBox: Locator;
  public readonly lenderName: Locator;
  public readonly lenderDropdownOptions: Locator;
  public readonly lenderNameSuggestedVal: Locator;
  public readonly editHyperLink: Locator;
  public readonly editLenderInfoSideSheet: Locator;
  public readonly lenderSearchTipsText: Locator;
  public readonly lenderSearchTipsTextOne: Locator;
  public readonly lenderSearchTipsTextTwo: Locator;
  public readonly lenderSearchTipsTextThree: Locator;
  public readonly lenderSearchTipsTextFour: Locator;
  public readonly lenderSearchTipsTextFive: Locator;
  public readonly iCantFindMyLenderCheckBox: Locator;
  public readonly iCantFindMyLenderLabel: Locator;
  public readonly iCantFindMyLenderDescriptionTitle: Locator;
  public readonly iCantFindMyLenderDescription: Locator;
  public readonly lenderNotFoundEditButton: Locator;
  public readonly selectedLenderName: Locator;
  public readonly selectedLenderSectionForLoanNum: Locator;
  public readonly selectedLenderNameUnderMortgageSection: Locator;
  public readonly selectedLenderSectionList: Locator;
  public readonly lenderIncompleteTitle: Locator;
  public readonly lenderInfoSideSheetCloseBtn: Locator;
  public readonly lenderNotFoundLabel: Locator;
  public readonly lenderIncompleteNoLenderOnThisProperty: Locator;
  public readonly lenderIncompleteRetryFindingLender: Locator;
  public readonly lenderIncompleteContinueBtn: Locator;
  public readonly errorMessage: Locator;
  public readonly formFieldLenderLoanNumber: Locator;
  public readonly lenderLoanNumber: Locator;
  public readonly loanErrorMessageForMaxChar: Locator;
  public readonly loanNumberHeaderInSideSheet: Locator;
  public readonly loanNumberSubHeaderInSideSheet: Locator;
  public readonly loanNumberHintText: Locator;
  public readonly impoundAccountTitle: Locator;
  public readonly impoundAccountSubTitle: Locator;
  public readonly impoundAccountNewPolicyAndRenewalRdoBtn: Locator;
  public readonly impoundAccountRenewalRdoBtn: Locator;
  public readonly impoundAccountNoRdoBtn: Locator;
  public readonly impoundAccountDoneBtn: Locator;
  public readonly emergencyMortgageAssistanceDivider: Locator;
  public readonly emergencyMortgageAssistanceToggle: Locator;
  public readonly emergencyMortgageAssistanceLabel: Locator;
  public readonly emergencyMortgageAssistanceDescription: Locator;
  public readonly emergencyMortgageAssistanceSubHeader: Locator;
  public readonly policyStartDateHeader: Locator;
  public readonly whenWouldYouLikeYourPolicyToBeginQuestion: Locator;
  public readonly policyStartDateInputFieldFMTPHome: Locator;
  public readonly policyStartDatePlaceHolderTextFMTPHome: Locator;
  public readonly policyStartDatePickerButtonFMTPHome: Locator;
  public readonly certExpirationDatePickerButtonFMTPHome: Locator;
  public readonly earlyShoppingDiscountInfoTitleFMTPHome: Locator;
  public readonly earlyShoppingDiscountDescriptionFMTPHome: Locator;
  public readonly monthYearLabelInCalenderPopUpFMTPHome: Locator;
  public readonly previousMonthButtonInCalenderPopUpFMTPHome: Locator;
  public readonly nextMonthButtonInCalenderPopUpFMTPHome: Locator;
  public readonly selectedDateInDatePickerPopUp: Locator;
  public readonly closeCalendarButton: Locator;
  public readonly earlyShoppingInfoIconMobile: Locator;
  public readonly earlyShoppingInfoTitleMobile: Locator;
  public readonly earlyShoppingInfoDescriptionMobile: Locator;
  public readonly earlyShoppingInfoButtonCloseMobile: Locator;
  public readonly plumbingOtherThanCopperCheckBox: Locator;
  public readonly plumbingGalvanizedRadioButtonLabel: Locator;
  public readonly primaryHeatingSourceCheckBox: Locator;
  public readonly unrepairedStructuresCheckBox: Locator;
  public readonly unrepairedStructuresCheckBoxSubHeader: Locator;
  public readonly businessOperatedOnPremisesCheckBox: Locator;
  public readonly businessOperatedOnPremisesCheckBoxSubHeader: Locator;
  public readonly dogsOnPremisesCheckBox: Locator;
  public readonly petWithBiteHistoryCheckBox: Locator;
  public readonly petWithBiteHistoryCheckBoxSubHeader: Locator;
  public readonly primaryHeatingSourceSideSheetRadioButtons: Locator;
  public readonly dogsOnPremisesCheckBoxes: Locator;
  public readonly dogsOnPremisesCheckBoxesLabels: Locator;
  public readonly saveButtonPrimaryHeatSideSheet: Locator;
  public readonly cancelButtonPrimaryHeatSideSheet: Locator;
  public readonly crossButtonPrimaryHeatSideSheet: Locator;
  public readonly saveButtonDogsOnPremisesSideSheet: Locator;
  public readonly cancelButtonDogsOnPremisesSideSheet: Locator;
  public readonly primaryHeatingSourceSelectedValue: Locator;
  public readonly dogsOnPremisesSelectedValue: Locator;
  public readonly fortifiedCertificationLabel: Locator;
  public readonly fortifiedCertificationLabelList: Locator;
  public readonly fortifiedCertificationSubLabel: Locator;
  public readonly fortifiedCertificationSubLabelList: Locator;
  public readonly fortifiedNoSelectionDiscountRemovalMessage: Locator;
  public readonly fortifiedNoSelectionDiscountRemovalMessageList: Locator;
  public readonly plumbingSystemsHelpLink: Locator;
  public readonly plumbingSideSheetHeader: Locator;
  public readonly primaryHeatingSourceSideSheetHeader: Locator;
  public readonly dogsOnPremisesSideSheetHeader: Locator;
  public readonly heatingSystemsSubHeaderSideSheet: Locator;
  public readonly dogsOnPremisesSubHeaderSideSheet: Locator;
  public readonly thermostatSubHeader: Locator;
  public readonly withOutThermostatSubHeader: Locator;
  public readonly noHeatingSystemSubHeader: Locator;
  public readonly withThermoStatHeatingSystemOptions: Locator;
  public readonly withoutThermoStatHeatingSystemOptions: Locator;
  public readonly noHeatingSystemOption: Locator;
  public readonly copperSubHeaderSideSheet: Locator;
  public readonly pvcSubHeaderSideSheet: Locator;
  public readonly pexSubHeaderSideSheet: Locator;
  public readonly galvanizedSubHeaderSideSheet: Locator;
  public readonly polybutyleneSubHeaderSideSheet: Locator;
  public readonly copperSubHeaderContentSideSheet: Locator;
  public readonly pvcSubHeaderContentSideSheet: Locator;
  public readonly pexSubHeaderContentSideSheet: Locator;
  public readonly galvanizedSubHeaderContentSideSheet: Locator;
  public readonly polybutyleneSubHeaderContentSideSheet: Locator;
  public readonly otherQuestionsSideSheetCloseBtn: Locator;
  public readonly listOfFortifiedCertification_Impound_RdoBtnLabels: Locator;
  public readonly escrowAccountRadioButtonOptionsLabels: Locator;
  public readonly listOfFortifiedCertification_Impound: Locator;
  public readonly designationGroupRdbBtnHeader: Locator;
  public readonly programGroupRdbBtnHeader: Locator;
  public readonly roofCategoryGroupRdbBtnHeader: Locator;
  public readonly designationGroupRdbBtnHeaderList: Locator;
  public readonly programGroupRdbBtnHeaderList: Locator;
  public readonly roofCategoryGroupRdbBtnHeaderList: Locator;
  public readonly designationRadioButtons: Locator;
  public readonly programRadioButtons: Locator;
  public readonly roofCategoryRadioButtons: Locator;
  public readonly designationRadioButtonsLabels: Locator;
  public readonly programRadioButtonsLabels: Locator;
  public readonly roofCategoryRadioButtonsLabels: Locator;
  public readonly specifyOnePerSectionLabel: Locator;
  public readonly specifyOnePerSectionLabelList: Locator;
  public readonly earlyShopperDiscountCongratulationsMessage: Locator;
  public readonly earlyShopperDiscountMessageGreenCheckMark: Locator;
  public readonly policyStartDateRangeError: Locator;
  public readonly pleaseProvidePolicyStartDateError: Locator;
  public readonly homePurchaseDateHeader: Locator;
  public readonly whenDidYouPurchaseThisHomeQuestion: Locator;
  public readonly homePurchaseDateInputField: Locator;
  public readonly homePurchaseDatePlaceHolderText: Locator;
  public readonly homePurchaseDatePickerButton: Locator;
  public readonly homePurchaseDateCantBeInFutureError: Locator;
  public readonly invalidHomePurchaseDateError: Locator;
  public readonly discountRemovalMessageFortifiedSection: Locator;
  public readonly farmersLogoThankYouScreen: Locator;
  public readonly thankYouScreenTitle: Locator;
  public readonly thankYouScreenSubTitle: Locator;
  public readonly emailLink: Locator;
  public readonly linkCloseEmailSnackBar: Locator;
  public readonly saveInProgressFooter: Locator;
  public readonly quoteNumberText: Locator;
  public readonly farmersLogoFooter: Locator;
  public readonly footerPersonalInfoUseLink: Locator;
  public readonly footerDigitalAccessibilityLink: Locator;
  public readonly footerTermsOfUseLink: Locator;
  public readonly footerPrivacyCenterLink: Locator;
  public readonly footerNoticeOfInformationPracticesLink: Locator;
  public readonly footerDoNotSellLink: Locator;
  public readonly escrowAccountPopupContinueBtn: Locator;
  public readonly escrowAccountPopupHeader: Locator;
  public readonly escrowAccountPopupSubHeader: Locator;
  public readonly escrowAccountPopupContentLink: Locator;
  public readonly selectTerritory: Locator;
  public readonly optionTerritory: Locator;
  public readonly territoryList: Locator;
  public readonly territoryPlaceHoldertext: Locator;
  public readonly selectTerritoryQuestion: Locator;
  public readonly whenIsEscrowExpectedToCloseLabel: Locator;
  public readonly lightBulbIcon: Locator;
  public readonly notSureWhenEscrowIsClosingTitle: Locator;
  public readonly notSureWhenEscrowIsClosingDescText: Locator;
  public readonly escrowInfoBoxTitle: Locator;
  public readonly escrowInfoBoxDescText: Locator;
  public readonly escrowInfoBoxNoteText: Locator;
  public readonly calenderDateCells: Locator;
  public readonly calendarMonthYearHeader: Locator;
  public readonly rc3Screen: Locator;
  public readonly rc3MainHeading: Locator;
  public readonly rc3SubHeading1: Locator;
  public readonly rc3SubHeading2: Locator;
  public readonly rnogToggleYesButtons: Locator;
  public readonly rnogToggleNoButtons: Locator;
  public readonly waterShutoffToggleYesButton: Locator;
  public readonly waterShutoffToggleNoButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.justFewMoreThingsTitle = page.locator("[data-legacy-field=\"justFewMoreThingsTitle\"]"); // @FindBy(xpath = JFMT_INFO_HEADER_XPATH)
    this.bundlePropertyJustFewMoreThingsTitle = page.locator("[data-legacy-field=\"bundlePropertyJustFewMoreThingsTitle\"]"); // @FindBy(xpath = BUNDLE_JFMT_TITLE_XPATH)
    this.justFewMoreThingsLabelInfoSubHeader = page.locator("xpath=//p[contains(text(), 'Please fill out these last few details so we can complete your purchase.')]"); // @FindBy(xpath = "//p[contains(text(), 'Please fill out these last few details so we can complete your purchase.')]")
    this.lenderInfoLabel = page.locator("xpath=//h2[contains(text(), 'Lender info')]"); // @FindBy(xpath = "//h2[contains(text(), 'Lender info')]")
    this.lenderInfoSubLabel = page.locator("xpath=//label[contains(text(), 'Do you have a mortgage on this property?')]"); // @FindBy(xpath = "//label[contains(text(), 'Do you have a mortgage on this property?')]")
    this.whyDoYouNeedMyLenderInfoIcon = page.locator("xpath=//mat-icon[starts-with(@aria-label,'Lender')]"); // @FindBy(xpath = "//mat-icon[starts-with(@aria-label,'Lender')]")
    this.whyDoYouNeedMyLenderInfoLabel = page.locator("xpath=//mat-icon[starts-with(@aria-label,'Lender')]/following-sibling::p[contains(@class,'tui-field-label-text')]"); // @FindBy(xpath = "//mat-icon[starts-with(@aria-label,'Lender')]/following-sibling::p[contains(@class,'tui-field-label-text')]")
    this.whyDoYouNeedMyLenderInfoContent = page.locator("xpath=//mat-icon[starts-with(@aria-label,'Lender')]/following-sibling::p[contains(@class,'tui-info-box-content')]"); // @FindBy(xpath = "//mat-icon[starts-with(@aria-label,'Lender')]/following-sibling::p[contains(@class,'tui-info-box-content')]")
    this.whyDoYouNeedMyLenderInfoLabelMobile = page.locator("xpath=//app-model-info-box//h1"); // @FindBy(xpath = "//app-model-info-box//h1")
    this.whyDoYouNeedMyLenderInfoContentMobile = page.locator("xpath=//app-model-info-box//p[contains(@class,'model-caption-text')]"); // @FindBy(xpath = "//app-model-info-box//p[contains(@class,'model-caption-text')]")
    this.lenderInfoHeaderSideSheet = page.locator("xpath=//div[@class='lender-info-header']//h2"); // @FindBy(xpath = "//div[@class='lender-info-header']//h2")
    this.lenderAddressSubHeader = page.locator("xpath=//div[@id='lender-address-section-title']//p"); // @FindBy(xpath = "//div[@id='lender-address-section-title']//p")
    this.formFieldCertificateExpDate = page.locator("xpath=//mat-label[contains(text(),'Certificate expiration date')]"); // @FindBy(xpath = "//mat-label[contains(text(),'Certificate expiration date')]")
    this.formFieldCertificateExpDateFormat = page.locator("xpath=//mat-hint[contains(text(),'mm/dd/yyyy')]"); // @FindBy(xpath = "//mat-hint[contains(text(),'mm/dd/yyyy')]")
    this.certExpDateInputField = page.locator("xpath=//input[contains(@aria-label,'Certification')]"); // @FindBy(xpath = "//input[contains(@aria-label,'Certification')]")
    this.certExpDateInputFieldList = page.locator("xpath=//input[contains(@aria-label,'Certification')]"); // @FindBy(xpath = "//input[contains(@aria-label,'Certification')]")
    this.certificationErrorLabel = page.locator("xpath=//mat-error[contains(text(),'Please provide your certification date.')]"); // @FindBy(xpath = "//mat-error[contains(text(),'Please provide your certification date.')]")
    this.certificateExpDatePickerButtonFMTPHome = page.locator("xpath=//app-date-picker[@id='certificationDateDiv_certificationDate']//mat-datepicker-toggle//button"); // @FindBy(xpath = "//app-date-picker[@id='certificationDateDiv_certificationDate']//mat-datepicker-toggle//button")
    this.formFieldLenderZipOrState = page.locator("xpath=//div[contains(@class,'lender-zipcode')]//div[1]//mat-label"); // @FindBy(xpath = "//div[contains(@class,'lender-zipcode')]//div[1]//mat-label")
    this.formFieldLenderName = page.locator("xpath=//mat-label[contains(text(),'Lender name')]"); // @FindBy(xpath = "//mat-label[contains(text(),'Lender name')]")
    this.lenderInfoPopUpHeader = page.locator("xpath=//div[contains(@class,'lender-info-header')]"); // @FindBy(xpath = "//div[contains(@class,'lender-info-header')]")
    this.lenderAddressSideSheetHeader = page.locator("xpath=//div[contains(@id,'lender-address-section-title')]"); // @FindBy(xpath = "//div[contains(@id,'lender-address-section-title')]")
    this.lenderAddressSideSheetSubHeader = page.locator("xpath=//div[contains(text(),'proof of insurance.')]"); // @FindBy(xpath = "//div[contains(text(),'proof of insurance.')]")
    this.editButtonPrimaryHeatingSource = page.locator("xpath=//div[contains(@class,'heating-system')]//a[contains(text(),'Edit')]"); // @FindBy(xpath = "//div[contains(@class,'heating-system')]//a[contains(text(),'Edit')]")
    this.editButtonDogsOnPremises = page.locator("xpath=//div[contains(@class,'dog-breed')]//a[contains(text(),'Edit')]"); // @FindBy(xpath = "//div[contains(@class,'dog-breed')]//a[contains(text(),'Edit')]")
    this.nextButton = page.locator("xpath=//button[contains(text(),'Next')]"); // @FindBy(xpath = "//button[contains(text(),'Next')]")
    this.lenderZipOrStateTextBox = page.locator("xpath=//div[contains(@class,'lender-zipcode-state-field')]//input"); // @FindBy(xpath = "//div[contains(@class,'lender-zipcode-state-field')]//input")
    this.lenderName = page.locator("xpath=//div[contains(@class,'lender-name-section')]//input"); // @FindBy(xpath = "//div[contains(@class,'lender-name-section')]//input")
    this.lenderDropdownOptions = page.locator("xpath=//mat-option"); // @FindBy(xpath = "//mat-option")
    this.lenderNameSuggestedVal = page.locator("xpath=//mat-option//p[1]"); // @FindBy(xpath = "//mat-option//p[1]")
    this.editHyperLink = page.getByRole('link', { name: "//a[contains(text(),'Edit')]", exact: true }); // @FindBy(linkText = "//a[contains(text(),'Edit')]")
    this.editLenderInfoSideSheet = page.getByRole('link', { name: "//h2[text()='Lender info' and @class='tui-subtitle']/following::a[contains(text(),'Edit') and @tabindex='0']", exact: true }); // @FindBy(linkText = "//h2[text()='Lender info' and @class='tui-subtitle']/following::a[contains(text(),'Edit') and @tabindex='0']")
    this.lenderSearchTipsText = page.locator("xpath=//div[contains(@class,'tui-field-label')]/span"); // @FindBy(xpath = "//div[contains(@class,'tui-field-label')]/span")
    this.lenderSearchTipsTextOne = page.locator("xpath=//li[@class='tui-input-text'][1]"); // @FindBy(xpath = "//li[@class='tui-input-text'][1]")
    this.lenderSearchTipsTextTwo = page.locator("xpath=//li[@class='tui-input-text'][2]"); // @FindBy(xpath = "//li[@class='tui-input-text'][2]")
    this.lenderSearchTipsTextThree = page.locator("xpath=//li[@class='tui-input-text'][3]"); // @FindBy(xpath = "//li[@class='tui-input-text'][3]")
    this.lenderSearchTipsTextFour = page.locator("xpath=//li[@class='tui-input-text'][4]"); // @FindBy(xpath = "//li[@class='tui-input-text'][4]")
    this.lenderSearchTipsTextFive = page.locator("xpath=//li[@class='tui-input-text'][5]"); // @FindBy(xpath = "//li[@class='tui-input-text'][5]")
    this.iCantFindMyLenderCheckBox = page.locator("xpath=//div[contains(@class,'lender-not-found-section')]/mat-checkbox"); // @FindBy(xpath = "//div[contains(@class,'lender-not-found-section')]/mat-checkbox")
    this.iCantFindMyLenderLabel = page.locator("xpath=//div[@class='lender-not-found-section']/mat-checkbox//label"); // @FindBy(xpath = "//div[@class='lender-not-found-section']/mat-checkbox//label")
    this.iCantFindMyLenderDescriptionTitle = page.locator("xpath=//div[@class='lender-not-found-section']/p"); // @FindBy(xpath = "//div[@class='lender-not-found-section']/p")
    this.iCantFindMyLenderDescription = page.locator("xpath=//div[@class='lender-not-found-section']/p/following-sibling::ul"); // @FindBy(xpath = "//div[@class='lender-not-found-section']/p/following-sibling::ul")
    this.lenderNotFoundEditButton = page.locator("xpath=//a[contains(text(),'Edit')]"); // @FindBy(xpath = "//a[contains(text(),'Edit')]")
    this.selectedLenderName = page.locator("xpath=//div[contains(@class,'lendername-selected')]/div[2]/div[1]/span[1]"); // @FindBy(xpath = "//div[contains(@class,'lendername-selected')]/div[2]/div[1]/span[1]")
    this.selectedLenderSectionForLoanNum = page.locator("xpath=//div[contains(@class,'lender-selected-section')]//div//span[4]/span"); // @FindBy(xpath = "//div[contains(@class,'lender-selected-section')]//div//span[4]/span")
    this.selectedLenderNameUnderMortgageSection = page.locator("xpath=//div[contains(@class,'lender-selected-section')]//div/span[1]"); // @FindBy(xpath = "//div[contains(@class,'lender-selected-section')]//div/span[1]")
    this.selectedLenderSectionList = page.locator("xpath=//div[contains(@class,'lender-selected-section')]"); // @FindBy(xpath = "//div[contains(@class,'lender-selected-section')]")
    this.lenderIncompleteTitle = page.locator("xpath=//span[contains(text(),'Lender incomplete')]"); // @FindBy(xpath = "//span[contains(text(),'Lender incomplete')]")
    this.lenderInfoSideSheetCloseBtn = page.locator("xpath=//button[@aria-label='close']"); // @FindBy(xpath = "//button[@aria-label='close']")
    this.lenderNotFoundLabel = page.locator("xpath=//span[@id='lenderNotFoundLabel']"); // @FindBy(xpath = "//span[@id='lenderNotFoundLabel']")
    this.lenderIncompleteNoLenderOnThisProperty = page.locator("xpath=//span[contains(text(),'No lender on this property')]"); // @FindBy(xpath = "//span[contains(text(),'No lender on this property')]")
    this.lenderIncompleteRetryFindingLender = page.locator("xpath=//span[contains(text(),'I will retry finding my lender')]"); // @FindBy(xpath = "//span[contains(text(),'I will retry finding my lender')]")
    this.lenderIncompleteContinueBtn = page.locator("xpath=//mat-dialog-actions//button"); // @FindBy(xpath = "//mat-dialog-actions//button")
    this.errorMessage = page.locator("[data-legacy-field=\"errorMessage\"]"); // @FindBy(xpath = ERROR_MESSAGE_XPATH)
    this.formFieldLenderLoanNumber = page.locator("xpath=//div[contains(@class,'loan-info-field')]//mat-label[contains(text(),'Loan #')]"); // @FindBy(xpath = "//div[contains(@class,'loan-info-field')]//mat-label[contains(text(),'Loan #')]")
    this.lenderLoanNumber = page.locator("xpath=//div[contains(@class,'loan-info-field')]//input"); // @FindBy(xpath = "//div[contains(@class,'loan-info-field')]//input")
    this.loanErrorMessageForMaxChar = page.locator("xpath=//mat-error[contains(text(),'Maximum of 25 characters for loan #.')]"); // @FindBy(xpath = "//mat-error[contains(text(),'Maximum of 25 characters for loan #.')]")
    this.loanNumberHeaderInSideSheet = page.locator("xpath=//div[contains(@id,'loan-number-section-title')]"); // @FindBy(xpath = "//div[contains(@id,'loan-number-section-title')]")
    this.loanNumberSubHeaderInSideSheet = page.locator("xpath=//div[contains(text(),'Including this helps your lender match the insurance policy')]"); // @FindBy(xpath = "//div[contains(text(),'Including this helps your lender match the insurance policy')]")
    this.loanNumberHintText = page.locator("xpath=//mat-hint[contains(text(),'Optional')]"); // @FindBy(xpath = "//mat-hint[contains(text(),'Optional')]")
    this.impoundAccountTitle = page.locator("xpath=//div[@id='impound-account-section-title']/p"); // @FindBy(xpath = "//div[@id='impound-account-section-title']/p")
    this.impoundAccountSubTitle = page.locator("xpath=//div[@class='impound-details-section tui-caption']"); // @FindBy(xpath = "//div[@class='impound-details-section tui-caption']")
    this.impoundAccountNewPolicyAndRenewalRdoBtn = page.locator("xpath=//*[@id='RADIO_BUTTON_FOR_IMPOUND_Mortgagee']//label"); // @FindBy(xpath = "//*[@id='RADIO_BUTTON_FOR_IMPOUND_Mortgagee']//label")
    this.impoundAccountRenewalRdoBtn = page.locator("xpath=//*[@id='RADIO_BUTTON_FOR_IMPOUND_mortagageePayRenewal']//label"); // @FindBy(xpath = "//*[@id='RADIO_BUTTON_FOR_IMPOUND_mortagageePayRenewal']//label")
    this.impoundAccountNoRdoBtn = page.locator("xpath=//*[@id='RADIO_BUTTON_FOR_IMPOUND_Insured']//label"); // @FindBy(xpath = "//*[@id='RADIO_BUTTON_FOR_IMPOUND_Insured']//label")
    this.impoundAccountDoneBtn = page.locator("xpath=//button[contains(text(),'Done')]"); // @FindBy(xpath = "//button[contains(text(),'Done')]")
    this.emergencyMortgageAssistanceDivider = page.locator("xpath=//mat-divider[contains(@class, 'emergency_mortgage_divider')]"); // @FindBy(xpath = "//mat-divider[contains(@class, 'emergency_mortgage_divider')]")
    this.emergencyMortgageAssistanceToggle = page.locator("[data-legacy-field=\"emergencyMortgageAssistanceToggle\"]"); // @FindBy(xpath = EMERGENCY_MORTGAGE_CARD_XPATH + "//mat-slide-toggle")
    this.emergencyMortgageAssistanceLabel = page.locator("xpath=//mat-card[contains(@class,'emergency_mortgage_card')]//mat-slide-toggle//label"); // @FindBy(xpath = "//mat-card[contains(@class,'emergency_mortgage_card')]//mat-slide-toggle//label")
    this.emergencyMortgageAssistanceDescription = page.locator("[data-legacy-field=\"emergencyMortgageAssistanceDescription\"]"); // @FindBy(xpath = EMERGENCY_MORTGAGE_CARD_XPATH + "//div[contains(@class, 'tui-caption-text')]")
    this.emergencyMortgageAssistanceSubHeader = page.locator("[data-legacy-field=\"emergencyMortgageAssistanceSubHeader\"]"); // @FindBy(xpath = EMERGENCY_MORTGAGE_CARD_XPATH + "//div[contains(@class, 'tui-subtitle-text-2')]")
    this.policyStartDateHeader = page.locator("xpath=//div[contains(@class,'policy-start-date-section')]//h2"); // @FindBy(xpath = "//div[contains(@class,'policy-start-date-section')]//h2")
    this.whenWouldYouLikeYourPolicyToBeginQuestion = page.locator("xpath=//app-date-picker[@id='policyStartDiv_policyStartDate']/preceding-sibling::p"); // @FindBy(xpath = "//app-date-picker[@id='policyStartDiv_policyStartDate']/preceding-sibling::p")
    this.policyStartDateInputFieldFMTPHome = page.locator("xpath=//input[contains(@aria-label,'Policy start date in the format of mmddyyyy.')]"); // @FindBy(xpath = "//input[contains(@aria-label,'Policy start date in the format of mmddyyyy.')]")
    this.policyStartDatePlaceHolderTextFMTPHome = page.locator("xpath=//app-date-picker[@id='policyStartDiv_policyStartDate']//mat-label[contains(text(),'date')]"); // @FindBy(xpath = "//app-date-picker[@id='policyStartDiv_policyStartDate']//mat-label[contains(text(),'date')]")
    this.policyStartDatePickerButtonFMTPHome = page.locator("xpath=//app-date-picker[@id='policyStartDiv_policyStartDate']//mat-datepicker-toggle//button"); // @FindBy(xpath = "//app-date-picker[@id='policyStartDiv_policyStartDate']//mat-datepicker-toggle//button")
    this.certExpirationDatePickerButtonFMTPHome = page.locator("xpath=//app-date-picker[@id='certificationDateDiv_certificationDate']//mat-datepicker-toggle//button"); // @FindBy(xpath = "//app-date-picker[@id='certificationDateDiv_certificationDate']//mat-datepicker-toggle//button")
    this.earlyShoppingDiscountInfoTitleFMTPHome = page.locator("xpath=//div[contains(@class,'tui-info-box')]//mat-icon[@aria-label='Early shopping discount information icon']/following-sibling::p[contains(@class,'tui-field-label-text')]"); // @FindBy(xpath = "//div[contains(@class,'tui-info-box')]//mat-icon[@aria-label='Early shopping discount information icon']/following-sibling::p[contains(@class,'tui-field-label-text')]")
    this.earlyShoppingDiscountDescriptionFMTPHome = page.locator("xpath=//div[contains(@class,'tui-info-box')]//mat-icon[@aria-label='Early shopping discount information icon']/following-sibling::p[contains(@class,'tui-info-box-content')]"); // @FindBy(xpath = "//div[contains(@class,'tui-info-box')]//mat-icon[@aria-label='Early shopping discount information icon']/following-sibling::p[contains(@class,'tui-info-box-content')]")
    this.monthYearLabelInCalenderPopUpFMTPHome = page.locator("xpath=//div[contains(@class,'mat-calendar-controls')]//button[contains(@class,'mat-calendar-period-button')]"); // @FindBy(xpath = "//div[contains(@class,'mat-calendar-controls')]//button[contains(@class,'mat-calendar-period-button')]")
    this.previousMonthButtonInCalenderPopUpFMTPHome = page.locator("xpath=//div[contains(@class,'mat-calendar-controls')]//button[contains(@class,'mat-calendar-previous-button')]"); // @FindBy(xpath = "//div[contains(@class,'mat-calendar-controls')]//button[contains(@class,'mat-calendar-previous-button')]")
    this.nextMonthButtonInCalenderPopUpFMTPHome = page.locator("xpath=//div[contains(@class,'mat-calendar-controls')]//button[contains(@class,'mat-calendar-next-button')]"); // @FindBy(xpath = "//div[contains(@class,'mat-calendar-controls')]//button[contains(@class,'mat-calendar-next-button')]")
    this.selectedDateInDatePickerPopUp = page.locator("xpath=//button[descendant::*[contains(@class,'selected')]]"); // @FindBy(xpath = "//button[descendant::*[contains(@class,'selected')]]")
    this.closeCalendarButton = page.locator("xpath=//button[contains(.,'Close calendar')]"); // @FindBy(xpath = "//button[contains(.,'Close calendar')]")
    this.earlyShoppingInfoIconMobile = page.locator("xpath=//h2[contains(text(),'Policy start')]/following-sibling::div/mat-icon[text()='info']"); // @FindBy(xpath = "//h2[contains(text(),'Policy start')]/following-sibling::div/mat-icon[text()='info']")
    this.earlyShoppingInfoTitleMobile = page.locator("xpath=//app-model-info-box//h1"); // @FindBy(xpath = "//app-model-info-box//h1")
    this.earlyShoppingInfoDescriptionMobile = page.locator("xpath=//app-model-info-box//h1/following-sibling::p"); // @FindBy(xpath = "//app-model-info-box//h1/following-sibling::p")
    this.earlyShoppingInfoButtonCloseMobile = page.locator("xpath=//app-model-info-box//mat-icon[text()='close']"); // @FindBy(xpath = "//app-model-info-box//mat-icon[text()='close']")
    this.plumbingOtherThanCopperCheckBox = page.locator("xpath=//mat-label[contains(text(),'Plumbing other than Copper, PEX, or PVC')]"); // @FindBy(xpath = "//mat-label[contains(text(),'Plumbing other than Copper, PEX, or PVC')]")
    this.plumbingGalvanizedRadioButtonLabel = page.locator("xpath=//mat-card[contains(@class,'plumbing-card')]//mat-radio-button//label[contains(.,'Galvanized')]"); // @FindBy(xpath = "//mat-card[contains(@class,'plumbing-card')]//mat-radio-button//label[contains(.,'Galvanized')]")
    this.primaryHeatingSourceCheckBox = page.locator("xpath=//mat-label[contains(text(),'Primary heating')]"); // @FindBy(xpath = "//mat-label[contains(text(),'Primary heating')]")
    this.unrepairedStructuresCheckBox = page.locator("xpath=//mat-label[contains(text(),'Unrepaired structures')]"); // @FindBy(xpath = "//mat-label[contains(text(),'Unrepaired structures')]")
    this.unrepairedStructuresCheckBoxSubHeader = page.locator("xpath=//p[contains(text(),'One (or more) separate structures may require repairs, is not properly maintained, or is being built.')]"); // @FindBy(xpath = "//p[contains(text(),'One (or more) separate structures may require repairs, is not properly maintained, or is being built.')]")
    this.businessOperatedOnPremisesCheckBox = page.locator("xpath=//mat-label[contains(text(),'Business operated')]"); // @FindBy(xpath = "//mat-label[contains(text(),'Business operated')]")
    this.businessOperatedOnPremisesCheckBoxSubHeader = page.locator("xpath=//p[contains(text(),'Excludes home offices if working remotely for an employer.')]"); // @FindBy(xpath = "//p[contains(text(),'Excludes home offices if working remotely for an employer.')]")
    this.dogsOnPremisesCheckBox = page.locator("xpath=//mat-label[contains(text(),'Dog(s) on premises')]"); // @FindBy(xpath = "//mat-label[contains(text(),'Dog(s) on premises')]")
    this.petWithBiteHistoryCheckBox = page.locator("xpath=//mat-label[contains(text(),'Pet with bite')]"); // @FindBy(xpath = "//mat-label[contains(text(),'Pet with bite')]")
    this.petWithBiteHistoryCheckBoxSubHeader = page.locator("xpath=//p[contains(text(),'A pet, such as a dog, cat, bird, or reptile who has bitten and injured a person or animal.')]"); // @FindBy(xpath = "//p[contains(text(),'A pet, such as a dog, cat, bird, or reptile who has bitten and injured a person or animal.')]")
    this.primaryHeatingSourceSideSheetRadioButtons = page.locator("xpath=//div[contains(@class,'row tui-stacking-top-md')]//mat-radio-button//input"); // @FindBy(xpath = "//div[contains(@class,'row tui-stacking-top-md')]//mat-radio-button//input")
    this.dogsOnPremisesCheckBoxes = page.locator("xpath=//app-dog-breed-selection//mat-checkbox"); // @FindBy(xpath = "//app-dog-breed-selection//mat-checkbox")
    this.dogsOnPremisesCheckBoxesLabels = page.locator("xpath=//app-dog-breed-selection//mat-checkbox//label"); // @FindBy(xpath = "//app-dog-breed-selection//mat-checkbox//label")
    this.saveButtonPrimaryHeatSideSheet = page.locator("xpath=//div[contains(@class,'heating-system-update-section')]/button[contains(text(),'Save')]"); // @FindBy(xpath = "//div[contains(@class,'heating-system-update-section')]/button[contains(text(),'Save')]")
    this.cancelButtonPrimaryHeatSideSheet = page.locator("xpath=//div[contains(@class,'heating-system-update-section')]/a[contains(text(),'Cancel')]"); // @FindBy(xpath = "//div[contains(@class,'heating-system-update-section')]/a[contains(text(),'Cancel')]")
    this.crossButtonPrimaryHeatSideSheet = page.locator("xpath=//mat-icon[@aria-label='Close']"); // @FindBy(xpath = "//mat-icon[@aria-label='Close']")
    this.saveButtonDogsOnPremisesSideSheet = page.locator("xpath=//div[contains(@class,'save-cta-section')]/button[contains(text(),'Save')]"); // @FindBy(xpath = "//div[contains(@class,'save-cta-section')]/button[contains(text(),'Save')]")
    this.cancelButtonDogsOnPremisesSideSheet = page.locator("xpath=//div[contains(@class,'save-cta-section')]/a[contains(text(),'Cancel')]"); // @FindBy(xpath = "//div[contains(@class,'save-cta-section')]/a[contains(text(),'Cancel')]")
    this.primaryHeatingSourceSelectedValue = page.locator("xpath=//div[contains(@class,'heating-system-added-value')]"); // @FindBy(xpath = "//div[contains(@class,'heating-system-added-value')]")
    this.dogsOnPremisesSelectedValue = page.locator("xpath=//div[contains(@class,'dog-breed-section')]/span"); // @FindBy(xpath = "//div[contains(@class,'dog-breed-section')]/span")
    this.fortifiedCertificationLabel = page.locator("xpath=//h2[contains(text(), 'FORTIFIED certification')]"); // @FindBy(xpath = "//h2[contains(text(), 'FORTIFIED certification')]")
    this.fortifiedCertificationLabelList = page.locator("xpath=//h2[contains(text(), 'FORTIFIED certification')]"); // @FindBy(xpath = "//h2[contains(text(), 'FORTIFIED certification')]")
    this.fortifiedCertificationSubLabel = page.locator("xpath=//p[contains(text(), 'Does your home have valid or active FORTIFIED certification, and does the certification expire after your policy start date?')]"); // @FindBy(xpath = "//p[contains(text(), 'Does your home have valid or active FORTIFIED certification, and does the certification expire after your policy start date?')]")
    this.fortifiedCertificationSubLabelList = page.locator("xpath=//p[contains(text(), 'Does your home have valid or active FORTIFIED certification, and does the certification expire after your policy start date?')]"); // @FindBy(xpath = "//p[contains(text(), 'Does your home have valid or active FORTIFIED certification, and does the certification expire after your policy start date?')]")
    this.fortifiedNoSelectionDiscountRemovalMessage = page.locator("xpath=//div[contains(@class,'tui-stacking-md ng-star-inserted')]"); // @FindBy(xpath = "//div[contains(@class,'tui-stacking-md ng-star-inserted')]")
    this.fortifiedNoSelectionDiscountRemovalMessageList = page.locator("xpath=//div[contains(@class,'tui-stacking-md ng-star-inserted')]"); // @FindBy(xpath = "//div[contains(@class,'tui-stacking-md ng-star-inserted')]")
    this.plumbingSystemsHelpLink = page.locator("xpath=//p[contains(text(),'Plumbing systems help')]"); // @FindBy(xpath = "//p[contains(text(),'Plumbing systems help')]")
    this.plumbingSideSheetHeader = page.locator("xpath=//h1[contains(text(),'Plumbing systems')]"); // @FindBy(xpath = "//h1[contains(text(),'Plumbing systems')]")
    this.primaryHeatingSourceSideSheetHeader = page.locator("xpath=//h2[contains(text(),'Heating systems')]"); // @FindBy(xpath = "//h2[contains(text(),'Heating systems')]")
    this.dogsOnPremisesSideSheetHeader = page.locator("xpath=//h2[contains(text(),'Dog(s) on premises')]"); // @FindBy(xpath = "//h2[contains(text(),'Dog(s) on premises')]")
    this.heatingSystemsSubHeaderSideSheet = page.locator("xpath=//p[contains(@class,'tui-input')]"); // @FindBy(xpath = "//p[contains(@class,'tui-input')]")
    this.dogsOnPremisesSubHeaderSideSheet = page.locator("xpath=//div[contains(text(),'"); // @FindBy(xpath = "//div[contains(text(),'" + DOGSONPREMISES_SUBHEADER_CONTENT + "')]")
    this.thermostatSubHeader = page.locator("xpath=//p[contains(text(),'With thermostat')]"); // @FindBy(xpath = "//p[contains(text(),'With thermostat')]")
    this.withOutThermostatSubHeader = page.locator("xpath=//p[contains(text(),'Without thermostat')]"); // @FindBy(xpath = "//p[contains(text(),'Without thermostat')]")
    this.noHeatingSystemSubHeader = page.locator("xpath=//p[contains(text(),'No heating system')]"); // @FindBy(xpath = "//p[contains(text(),'No heating system')]")
    this.withThermoStatHeatingSystemOptions = page.locator("xpath=//mat-radio-group//div[1]//mat-radio-button//label"); // @FindBy(xpath = "//mat-radio-group//div[1]//mat-radio-button//label")
    this.withoutThermoStatHeatingSystemOptions = page.locator("xpath=//mat-radio-group//div[2]//mat-radio-button//label"); // @FindBy(xpath = "//mat-radio-group//div[2]//mat-radio-button//label")
    this.noHeatingSystemOption = page.locator("xpath=//mat-radio-group//div[3]//mat-radio-button//label"); // @FindBy(xpath = "//mat-radio-group//div[3]//mat-radio-button//label")
    this.copperSubHeaderSideSheet = page.locator("xpath=//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'Copper')]"); // @FindBy(xpath = "//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'Copper')]")
    this.pvcSubHeaderSideSheet = page.locator("xpath=//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'PVC')]"); // @FindBy(xpath = "//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'PVC')]")
    this.pexSubHeaderSideSheet = page.locator("xpath=//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'PEX')]"); // @FindBy(xpath = "//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'PEX')]")
    this.galvanizedSubHeaderSideSheet = page.locator("xpath=//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'Galvanized')]"); // @FindBy(xpath = "//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'Galvanized')]")
    this.polybutyleneSubHeaderSideSheet = page.locator("xpath=//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'Polybutylene')]"); // @FindBy(xpath = "//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'Polybutylene')]")
    this.copperSubHeaderContentSideSheet = page.locator("xpath=//p[contains(@class,'tui-input-text') and contains(text(),'"); // @FindBy(xpath = "//p[contains(@class,'tui-input-text') and contains(text(),'" + PLUMBING_COPPER_CONTENT + "')]")
    this.pvcSubHeaderContentSideSheet = page.locator("xpath=//p[contains(@class,'tui-input-text') and contains(text(),'A white- or cream-colored plastic')]"); // @FindBy(xpath = "//p[contains(@class,'tui-input-text') and contains(text(),'A white- or cream-colored plastic')]")
    this.pexSubHeaderContentSideSheet = page.locator("xpath=//p[contains(@class,'tui-input-text') and contains(text(),'A flexible plastic pipe that is white')]"); // @FindBy(xpath = "//p[contains(@class,'tui-input-text') and contains(text(),'A flexible plastic pipe that is white')]")
    this.galvanizedSubHeaderContentSideSheet = page.locator("xpath=//p[contains(@class,'tui-input-text') and contains(text(),'"); // @FindBy(xpath = "//p[contains(@class,'tui-input-text') and contains(text(),'" + PLUMBING_GALVANIZED_CONTENT + "')]")
    this.polybutyleneSubHeaderContentSideSheet = page.locator("xpath=//p[contains(@class,'tui-input-text') and contains(text(),'A flexible plastic pipe that is usually gray,')]"); // @FindBy(xpath = "//p[contains(@class,'tui-input-text') and contains(text(),'A flexible plastic pipe that is usually gray,')]")
    this.otherQuestionsSideSheetCloseBtn = page.locator("xpath=//mat-icon[@aria-label='Close']"); // @FindBy(xpath = "//mat-icon[@aria-label='Close']")
    this.listOfFortifiedCertification_Impound_RdoBtnLabels = page.locator("xpath=//span[@class='mat-radio-label-content']"); // @FindBy(xpath = "//span[@class='mat-radio-label-content']")
    this.escrowAccountRadioButtonOptionsLabels = page.locator("xpath=//mat-radio-group[@aria-label='Does your lender include your property insurance costs in your monthly mortgage payments? (common)']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@aria-label='Does your lender include your property insurance costs in your monthly mortgage payments? (common)']//mat-radio-button")
    this.listOfFortifiedCertification_Impound = page.locator("xpath=//span[@class='mat-radio-label-content']"); // @FindBy(xpath = "//span[@class='mat-radio-label-content']")
    this.designationGroupRdbBtnHeader = page.locator("xpath=//label[contains(text(),'Designation')]"); // @FindBy(xpath = "//label[contains(text(),'Designation')]")
    this.programGroupRdbBtnHeader = page.locator("xpath=//label[contains(text(),'Program')]"); // @FindBy(xpath = "//label[contains(text(),'Program')]")
    this.roofCategoryGroupRdbBtnHeader = page.locator("xpath=//label[contains(text(),'Roof category')]"); // @FindBy(xpath = "//label[contains(text(),'Roof category')]")
    this.designationGroupRdbBtnHeaderList = page.locator("xpath=//label[contains(text(),'Designation')]"); // @FindBy(xpath = "//label[contains(text(),'Designation')]")
    this.programGroupRdbBtnHeaderList = page.locator("xpath=//label[contains(text(),'Program')]"); // @FindBy(xpath = "//label[contains(text(),'Program')]")
    this.roofCategoryGroupRdbBtnHeaderList = page.locator("xpath=//label[contains(text(),'Roof category')]"); // @FindBy(xpath = "//label[contains(text(),'Roof category')]")
    this.designationRadioButtons = page.locator("xpath=//mat-radio-group//mat-radio-button[contains(@id,'DESIGNATION')]"); // @FindBy(xpath = "//mat-radio-group//mat-radio-button[contains(@id,'DESIGNATION')]")
    this.programRadioButtons = page.locator("xpath=//mat-radio-group//mat-radio-button[contains(@id,'PROGRAM')]"); // @FindBy(xpath = "//mat-radio-group//mat-radio-button[contains(@id,'PROGRAM')]")
    this.roofCategoryRadioButtons = page.locator("xpath=//mat-radio-group//mat-radio-button[contains(@id,'ROOF')]"); // @FindBy(xpath = "//mat-radio-group//mat-radio-button[contains(@id,'ROOF')]")
    this.designationRadioButtonsLabels = page.locator("xpath=//mat-radio-button[contains(@id,'DESIGNATION')]"); // @FindBy(xpath = "//mat-radio-button[contains(@id,'DESIGNATION')]")
    this.programRadioButtonsLabels = page.locator("xpath=//mat-radio-button[contains(@id,'PROGRAM')]"); // @FindBy(xpath = "//mat-radio-button[contains(@id,'PROGRAM')]")
    this.roofCategoryRadioButtonsLabels = page.locator("xpath=//mat-radio-button[contains(@id,'ROOF')]"); // @FindBy(xpath = "//mat-radio-button[contains(@id,'ROOF')]")
    this.specifyOnePerSectionLabel = page.locator("xpath=//p[contains(text(),'Please specify one per section:')]"); // @FindBy(xpath = "//p[contains(text(),'Please specify one per section:')]")
    this.specifyOnePerSectionLabelList = page.locator("xpath=//p[contains(text(),'Please specify one per section:')]"); // @FindBy(xpath = "//p[contains(text(),'Please specify one per section:')]")
    this.earlyShopperDiscountCongratulationsMessage = page.locator("[data-legacy-field=\"earlyShopperDiscountCongratulationsMessage\"]"); // @FindBy(xpath = EARLY_SHOPPER_DISCOUNT_CONGRATULATIONS_MSG_XPATH)
    this.earlyShopperDiscountMessageGreenCheckMark = page.locator("[data-legacy-field=\"earlyShopperDiscountMessageGreenCheckMark\"]"); // @FindBy(xpath = EARLY_SHOPPER_DISCOUNT_CONGRATULATIONS_GREEN_CHECKMARK_XPATH)
    this.policyStartDateRangeError = page.locator("[data-legacy-field=\"policyStartDateRangeError\"]"); // @FindBy(xpath = POLICY_START_DATE_RANGE_MSG_XPATH)
    this.pleaseProvidePolicyStartDateError = page.locator("xpath=//app-date-picker[@id='policyStartDiv_policyStartDate']//mat-error"); // @FindBy(xpath = "//app-date-picker[@id='policyStartDiv_policyStartDate']//mat-error")
    this.homePurchaseDateHeader = page.locator("xpath=//div[contains(@class,'home-purchase-date-section')]//h2"); // @FindBy(xpath = "//div[contains(@class,'home-purchase-date-section')]//h2")
    this.whenDidYouPurchaseThisHomeQuestion = page.locator("xpath=//div[contains(@class,'home-purchase-date-section')]//p"); // @FindBy(xpath = "//div[contains(@class,'home-purchase-date-section')]//p")
    this.homePurchaseDateInputField = page.locator("xpath=//input[contains(@aria-label,'Home purchase date')]"); // @FindBy(xpath = "//input[contains(@aria-label,'Home purchase date')]")
    this.homePurchaseDatePlaceHolderText = page.locator("xpath=//app-date-picker[@id='homePurchaseDiv_homePurchaseDate']//mat-label"); // @FindBy(xpath = "//app-date-picker[@id='homePurchaseDiv_homePurchaseDate']//mat-label")
    this.homePurchaseDatePickerButton = page.locator("xpath=//app-date-picker[@id='homePurchaseDiv_homePurchaseDate']//mat-datepicker-toggle//button"); // @FindBy(xpath = "//app-date-picker[@id='homePurchaseDiv_homePurchaseDate']//mat-datepicker-toggle//button")
    this.homePurchaseDateCantBeInFutureError = page.locator("[data-legacy-field=\"homePurchaseDateCantBeInFutureError\"]"); // @FindBy(xpath = HOME_PURCHASE_DATE_ERROR_CANT_BE_IN_FUTURE_XPATH)
    this.invalidHomePurchaseDateError = page.locator("[data-legacy-field=\"invalidHomePurchaseDateError\"]"); // @FindBy(xpath = INVALID_HOME_PURCHASE_DATE_ERROR_XPATH)
    this.discountRemovalMessageFortifiedSection = page.locator("xpath=//mat-button-toggle-group/following-sibling::div"); // @FindBy(xpath = "//mat-button-toggle-group/following-sibling::div")
    this.farmersLogoThankYouScreen = page.locator("xpath=//img[@alt='Farmers Logo']"); // @FindBy(xpath = "//img[@alt='Farmers Logo']")
    this.thankYouScreenTitle = page.locator("xpath=//h1[contains(text(),'Thank you')]"); // @FindBy(xpath = "//h1[contains(text(),'Thank you')]")
    this.thankYouScreenSubTitle = page.locator("xpath=//p[contains(text(),'Because your home')]"); // @FindBy(xpath = "//p[contains(text(),'Because your home')]")
    this.emailLink = page.locator("#emailLink"); // @FindBy(id = "emailLink")
    this.linkCloseEmailSnackBar = page.getByRole('link', { name: "Done", exact: true }); // @FindBy(linkText = "Done")
    this.saveInProgressFooter = page.locator("xpath=//div[contains(@class,'save-in-progress')]/p"); // @FindBy(xpath = "//div[contains(@class,'save-in-progress')]/p")
    this.quoteNumberText = page.locator("xpath=//div[contains(@class,'save-quote')]"); // @FindBy(xpath = "//div[contains(@class,'save-quote')]")
    this.farmersLogoFooter = page.locator("xpath=//tui-oneui-footer//div[contains(@class,'tui-oneui-footer-logo-container')]/img"); // @FindBy(xpath = "//tui-oneui-footer//div[contains(@class,'tui-oneui-footer-logo-container')]/img")
    this.footerPersonalInfoUseLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_personal-information-use']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_personal-information-use']")
    this.footerDigitalAccessibilityLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_digital-accessibility']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_digital-accessibility']")
    this.footerTermsOfUseLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_terms-of-use']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_terms-of-use']")
    this.footerPrivacyCenterLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_privacy-center']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_privacy-center']")
    this.footerNoticeOfInformationPracticesLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_notice-of-information-practices']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_notice-of-information-practices']")
    this.footerDoNotSellLink = page.locator("xpath=//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_do-not-sell']"); // @FindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_do-not-sell']")
    this.escrowAccountPopupContinueBtn = page.locator("xpath=//button[contains(text(),'Continue') and @tabindex=0]"); // @FindBy(xpath = "//button[contains(text(),'Continue') and @tabindex=0]")
    this.escrowAccountPopupHeader = page.locator("xpath=//span[contains(text(),'Lender info incomplete')]"); // @FindBy(xpath = "//span[contains(text(),'Lender info incomplete')]")
    this.escrowAccountPopupSubHeader = page.locator("xpath=//span[contains(text(),'We need more information about your loan to complete your policy.')]"); // @FindBy(xpath = "//span[contains(text(),'We need more information about your loan to complete your policy.')]")
    this.escrowAccountPopupContentLink = page.locator("xpath=//a[contains(text(),'This property has no mortgage')]"); // @FindBy(xpath = "//a[contains(text(),'This property has no mortgage')]")
    this.selectTerritory = page.locator("[data-legacy-field=\"selectTerritory\"]"); // @FindBy(xpath = TERRITORY_SELECT_XPATH + "//mat-select")
    this.optionTerritory = page.locator("xpath=//mat-option"); // @FindBy(xpath = "//mat-option")
    this.territoryList = page.locator("xpath=//div[@role='listbox']"); // @FindBy(xpath = "//div[@role='listbox']")
    this.territoryPlaceHoldertext = page.locator("[data-legacy-field=\"territoryPlaceHoldertext\"]"); // @FindBy(xpath = TERRITORY_SELECT_XPATH + "//label")
    this.selectTerritoryQuestion = page.locator("xpath=//form[@id='additional-info-main-form']//div[1]/label"); // @FindBy(xpath = "//form[@id='additional-info-main-form']//div[1]/label")
    this.whenIsEscrowExpectedToCloseLabel = page.locator("xpath=//mat-label[contains(text(),'Estimated closing date')]"); // @FindBy(xpath = "//mat-label[contains(text(),'Estimated closing date')]")
    this.lightBulbIcon = page.locator("xpath=//mat-icon[contains(@class,'lightbulb-icon')]"); // @FindBy(xpath = "//mat-icon[contains(@class,'lightbulb-icon')]")
    this.notSureWhenEscrowIsClosingTitle = page.locator("xpath=//p[text()='Not sure when escrow is closing?']"); // @FindBy(xpath = "//p[text()='Not sure when escrow is closing?']")
    this.notSureWhenEscrowIsClosingDescText = page.locator("xpath=//p[contains(text(),\"Don't worry, you can change the date\")]"); // @FindBy(xpath = "//p[contains(text(),\"Don't worry, you can change the date\")]")
    this.escrowInfoBoxTitle = page.locator("xpath=(//div[@class='tui-info-box']/p)[1]"); // @FindBy(xpath = "(//div[@class='tui-info-box']/p)[1]")
    this.escrowInfoBoxDescText = page.locator("xpath=(//div[@class='tui-info-box']/p)[2]"); // @FindBy(xpath = "(//div[@class='tui-info-box']/p)[2]")
    this.escrowInfoBoxNoteText = page.locator("xpath=(//div[@class='tui-info-box']/p)[3]"); // @FindBy(xpath = "(//div[@class='tui-info-box']/p)[3]")
    this.calenderDateCells = page.locator("xpath=//td[contains(@class,'mat-calendar-body-cell-container')]/button"); // @FindBy(xpath = "//td[contains(@class,'mat-calendar-body-cell-container')]/button")
    this.calendarMonthYearHeader = page.locator("xpath=//div[@class='mat-calendar-header']//span[@id='mat-calendar-button-0']"); // @FindBy(xpath = "//div[@class='mat-calendar-header']//span[@id='mat-calendar-button-0']")
    this.rc3Screen = page.locator("[data-legacy-field=\"rc3Screen\"]"); // @FindBy(xpath = RC3_SCREEN_XPATH)
    this.rc3MainHeading = page.locator("xpath=//app-rc3-loading-hrc//h1"); // @FindBy(xpath = "//app-rc3-loading-hrc//h1")
    this.rc3SubHeading1 = page.locator("xpath=//app-rc3-loading-hrc//div[@class='tui-input-text']"); // @FindBy(xpath = "//app-rc3-loading-hrc//div[@class='tui-input-text']")
    this.rc3SubHeading2 = page.locator("xpath=//app-rc3-loading-hrc//div[@class='tui-field-label']"); // @FindBy(xpath = "//app-rc3-loading-hrc//div[@class='tui-field-label']")
    this.rnogToggleYesButtons = page.locator("[data-legacy-field=\"rnogToggleYesButtons\"]"); // @FindBy(xpath = RACE_TOGGLE_GROUP_XPATH + "//mat-button-toggle[contains(.,'Yes')]")
    this.rnogToggleNoButtons = page.locator("[data-legacy-field=\"rnogToggleNoButtons\"]"); // @FindBy(xpath = RACE_TOGGLE_GROUP_XPATH + "//mat-button-toggle[contains(.,'No')]")
    this.waterShutoffToggleYesButton = page.locator("[data-legacy-field=\"waterShutoffToggleYesButton\"]"); // @FindBy(xpath = WATER_SHUTOFF_TOGGLE_GROUP_XPATH + "//mat-button-toggle[contains(.,'Yes')]/button")
    this.waterShutoffToggleNoButton = page.locator("[data-legacy-field=\"waterShutoffToggleNoButton\"]"); // @FindBy(xpath = WATER_SHUTOFF_TOGGLE_GROUP_XPATH + "//mat-button-toggle[contains(.,'No')]/button")
  }
}
