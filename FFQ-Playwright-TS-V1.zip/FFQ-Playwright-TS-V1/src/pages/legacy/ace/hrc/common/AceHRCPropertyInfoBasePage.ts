// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCPropertyInfoBasePage. */
export class AceHRCPropertyInfoBasePage extends CoreBasePage {
  public readonly propertyInfoPageTitle: Locator;
  public readonly homeTypeLabel: Locator;
  public readonly matRadioButtonSingleFamilyHome: Locator;
  public readonly inputSingleFamilyHome: Locator;
  public readonly matRadioButtonTownhome: Locator;
  public readonly inputButtonTownhome: Locator;
  public readonly matRadioButtonDuplex: Locator;
  public readonly inputButtonDuplex: Locator;
  public readonly propertyTypeMatRadioButtons: Locator;
  public readonly propertyTypeLabels: Locator;
  public readonly propertyTypeLabelDescriptions: Locator;
  public readonly ownershipLengthLabel: Locator;
  public readonly matRadioButtonYearOrMore: Locator;
  public readonly inputYearOrMore: Locator;
  public readonly matRadioButtonUnderOneYear: Locator;
  public readonly inputUnderOneYear: Locator;
  public readonly matRadioButtonPendingEscrow: Locator;
  public readonly inputPendingEscrow: Locator;
  public readonly ownershipLengths: Locator;
  public readonly claimsSubTitle: Locator;
  public readonly matButtonToggleLossOfPropertyNone: Locator;
  public readonly buttonToggleLossOfPropertyNone: Locator;
  public readonly matButtonToggleLossOfPropertyOne: Locator;
  public readonly buttonToggleLossOfPropertyOne: Locator;
  public readonly matButtonToggleLossOfPropertyTwoOrMore: Locator;
  public readonly buttonToggleLossOfPropertyTwoOrMore: Locator;
  public readonly claimsCount: Locator;
  public readonly priorCurrentAddressCard: Locator;
  public readonly priorCurrentAddressLabel: Locator;
  public readonly priorCurrentAddressInput: Locator;
  public readonly addressFieldPlaceHolderText: Locator;
  public readonly priorOrCurrentAddressInputBox: Locator;
  public readonly priorOrCurrentAddressCityInputBox: Locator;
  public readonly priorOrCurrentAddressStateSelect: Locator;
  public readonly priorOrCurrentAddressZipInputBox: Locator;
  public readonly closeIconInAddressInputBox: Locator;
  public readonly unitInputBox: Locator;
  public readonly unitNumberPlaceholderText: Locator;
  public readonly cityPlaceholderText: Locator;
  public readonly statePlaceholderText: Locator;
  public readonly zipPlaceholderText: Locator;
  public readonly optionalUnitNumberHint: Locator;
  public readonly pleaseEnterYourStreetNumberAndNameError: Locator;
  public readonly pleaseProvideYourCityError: Locator;
  public readonly pleaseProvideYourStateError: Locator;
  public readonly pleaseProvideYourZipError: Locator;
  public readonly invalidInputZipError: Locator;
  public readonly invalidInputAddressError: Locator;
  public readonly pleaseSelectAddressFromListError: Locator;
  public readonly selectAddressFromListError: Locator;
  public readonly unitNumberNotValidEntryError: Locator;

  public constructor(page: Page) {
    super(page);
    this.propertyInfoPageTitle = page.locator("xpath=//app-home-property-info//div[contains(@class,'home-property-info__container')]//h1"); // @FindBy(xpath = "//app-home-property-info//div[contains(@class,'home-property-info__container')]//h1")
    this.homeTypeLabel = page.locator("xpath=//app-home-property-info//label[@id='homeTypeLabel']"); // @FindBy(xpath = "//app-home-property-info//label[@id='homeTypeLabel']")
    this.matRadioButtonSingleFamilyHome = page.locator("xpath=//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_DETACHED']"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_DETACHED']")
    this.inputSingleFamilyHome = page.locator("xpath=//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_DETACHED']//input"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_DETACHED']//input")
    this.matRadioButtonTownhome = page.locator("xpath=//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_TOWNHOME']"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_TOWNHOME']")
    this.inputButtonTownhome = page.locator("xpath=//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_TOWNHOME']//input"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_TOWNHOME']//input")
    this.matRadioButtonDuplex = page.locator("xpath=//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_DUPLEX']"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_DUPLEX']")
    this.inputButtonDuplex = page.locator("xpath=//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_DUPLEX']//input"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_DUPLEX']//input")
    this.propertyTypeMatRadioButtons = page.locator("xpath=//app-home-property-info//mat-radio-button[contains(@id,'HOME_TYPE')]"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[contains(@id,'HOME_TYPE')]")
    this.propertyTypeLabels = page.locator("xpath=//app-home-property-info//mat-radio-button[contains(@id,'HOME_TYPE')]//label"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[contains(@id,'HOME_TYPE')]//label")
    this.propertyTypeLabelDescriptions = page.locator("xpath=//app-home-property-info//mat-radio-button[contains(@id,'HOME_TYPE')]//label/span"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[contains(@id,'HOME_TYPE')]//label/span")
    this.ownershipLengthLabel = page.locator("xpath=//app-home-property-info//label[@id='homeDurationLabel']"); // @FindBy(xpath = "//app-home-property-info//label[@id='homeDurationLabel']")
    this.matRadioButtonYearOrMore = page.locator("xpath=//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_ONE']"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_ONE']")
    this.inputYearOrMore = page.locator("xpath=//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_ONE']//input"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_ONE']//input")
    this.matRadioButtonUnderOneYear = page.locator("xpath=//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_ZERO']"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_ZERO']")
    this.inputUnderOneYear = page.locator("xpath=//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_ZERO']//input"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_ZERO']//input")
    this.matRadioButtonPendingEscrow = page.locator("xpath=//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_PENDING']"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_PENDING']")
    this.inputPendingEscrow = page.locator("xpath=//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_PENDING']//input"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_PENDING']//input")
    this.ownershipLengths = page.locator("xpath=//app-home-property-info//mat-radio-button[contains(@id,'HOME_DURATION')]"); // @FindBy(xpath = "//app-home-property-info//mat-radio-button[contains(@id,'HOME_DURATION')]")
    this.claimsSubTitle = page.locator("xpath=//app-home-property-info//div[@id='lossOfProperty']//h2"); // @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//h2")
    this.matButtonToggleLossOfPropertyNone = page.locator("xpath=//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'None')]"); // @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'None')]")
    this.buttonToggleLossOfPropertyNone = page.locator("xpath=//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'None')]/button"); // @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'None')]/button")
    this.matButtonToggleLossOfPropertyOne = page.locator("xpath=//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'One')]"); // @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'One')]")
    this.buttonToggleLossOfPropertyOne = page.locator("xpath=//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'One')]/button"); // @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'One')]/button")
    this.matButtonToggleLossOfPropertyTwoOrMore = page.locator("xpath=//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'Two or more')]"); // @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'Two or more')]")
    this.buttonToggleLossOfPropertyTwoOrMore = page.locator("xpath=//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'Two or more')]/button"); // @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'Two or more')]/button")
    this.claimsCount = page.locator("xpath=//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle"); // @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle")
    this.priorCurrentAddressCard = page.locator("xpath=//div[@id='priorCurrentAddress']/mat-card[contains(@class,'home-address-card')]"); // @FindBy(xpath = "//div[@id='priorCurrentAddress']/mat-card[contains(@class,'home-address-card')]")
    this.priorCurrentAddressLabel = page.locator("xpath=//div[@id='priorCurrentAddress']/mat-card[contains(@class,'home-address-card')]//p[contains(@class,'tui-field-label-text')]"); // @FindBy(xpath = "//div[@id='priorCurrentAddress']/mat-card[contains(@class,'home-address-card')]//p[contains(@class,'tui-field-label-text')]")
    this.priorCurrentAddressInput = page.locator("xpath=//div[@id='priorCurrentAddress']/mat-card[contains(@class,'home-address-card')]//input[contains(@class,'address-autocomplete-input')]"); // @FindBy(xpath = "//div[@id='priorCurrentAddress']/mat-card[contains(@class,'home-address-card')]//input[contains(@class,'address-autocomplete-input')]")
    this.addressFieldPlaceHolderText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + ADDRESS_FIELD_PLACEHOLDER_TEXT + "')]")
    this.priorOrCurrentAddressInputBox = page.locator("xpath=//address-autocomplete-input//input"); // @FindBy(xpath = "//address-autocomplete-input//input")
    this.priorOrCurrentAddressCityInputBox = page.locator("xpath=//mat-form-field[@id='auto-contact-info-city__input-field']//input"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-info-city__input-field']//input")
    this.priorOrCurrentAddressStateSelect = page.locator("xpath=//mat-form-field[@id='state']//mat-select"); // @FindBy(xpath = "//mat-form-field[@id='state']//mat-select")
    this.priorOrCurrentAddressZipInputBox = page.locator("xpath=//mat-form-field[@id='auto-contact-info-zipCode__input-field']//input"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-info-zipCode__input-field']//input")
    this.closeIconInAddressInputBox = page.locator("xpath=//address-autocomplete-input//mat-icon"); // @FindBy(xpath = "//address-autocomplete-input//mat-icon")
    this.unitInputBox = page.locator("xpath=//mat-form-field[@name='home-personal-info-apartment__input-field']//input"); // @FindBy(xpath = "//mat-form-field[@name='home-personal-info-apartment__input-field']//input")
    this.unitNumberPlaceholderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + UNIT_NUMBER_PLACEHOLDER_TEXT + "')]")
    this.cityPlaceholderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + CITY_PLACEHOLDER_TEXT + "')]")
    this.statePlaceholderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + STATE_PLACEHOLDER_TEXT + "')]")
    this.zipPlaceholderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + ZIP_PLACEHOLDER_TEXT + "')]")
    this.optionalUnitNumberHint = page.locator("xpath=//mat-hint[contains(text(),'"); // @FindBy(xpath = "//mat-hint[contains(text(),'" + OPTIONAL_UNIT_NUMBER_HINT + "')]")
    this.pleaseEnterYourStreetNumberAndNameError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_ENTER_STREET_NUMBER_AND_NAME + "')]")
    this.pleaseProvideYourCityError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_PROVIDE_YOUR_CITY_ERROR + "')]")
    this.pleaseProvideYourStateError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_PROVIDE_YOUR_STATE_ERROR + "')]")
    this.pleaseProvideYourZipError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_PROVIDE_YOUR_ZIP_ERROR + "')]")
    this.invalidInputZipError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_PROVIDE_FIVE_DIGIT_ZIP_ERROR + "')]")
    this.invalidInputAddressError = page.locator("xpath=//address-autocomplete-input[@id='prior-address-autocomplete']//mat-error"); // @FindBy(xpath = "//address-autocomplete-input[@id='prior-address-autocomplete']//mat-error")
    this.pleaseSelectAddressFromListError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_SELECT_ADDRESS_FROM_LIST_ERROR + "')]")
    this.selectAddressFromListError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + SELECT_ADDRESS_FROM_LIST_ERROR + "')]")
    this.unitNumberNotValidEntryError = page.locator("xpath=//mat-form-field[@name='home-personal-info-apartment__input-field']//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-form-field[@name='home-personal-info-apartment__input-field']//mat-error[contains(text(),'" + INVALID_ENTRY + "')]")
  }
}
