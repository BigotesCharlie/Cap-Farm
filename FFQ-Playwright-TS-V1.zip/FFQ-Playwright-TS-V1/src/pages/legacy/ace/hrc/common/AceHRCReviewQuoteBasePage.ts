// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCReviewQuoteBasePage. */
export class AceHRCReviewQuoteBasePage extends CoreBasePage {
  public readonly quoteSummaryHeading: Locator;
  public readonly quoteSummarySubheading: Locator;
  public readonly linkChangeCoverage: Locator;
  public readonly quotePriceOnCardDesktop: Locator;
  public readonly quotePriceOnCardMobile: Locator;
  public readonly buttonContinueDesktop: Locator;
  public readonly buttonContinueMobile: Locator;
  public readonly buttonContinueMobileAtPageBottom: Locator;
  public readonly primaryCoveragesPriceOnCardDesktop: Locator;
  public readonly primaryCoveragesPriceOnCardMobile: Locator;
  public readonly quoteOptionalCoveragesPriceOnCardDesktop: Locator;
  public readonly quoteOptionalCoveragesPriceOnCardMobile: Locator;
  public readonly quoteDiscountsOnCardDesktop: Locator;
  public readonly quoteDiscountsOnCardMobile: Locator;
  public readonly linkViewMonthlyPricingDesktop: Locator;
  public readonly linkViewMonthlyPricingMobile: Locator;
  public readonly expandQuoteCard: Locator;
  public readonly minimizeQuoteCard: Locator;
  public readonly dialogButtonOk: Locator;
  public readonly presentmentCardPriceHeaderDesktop: Locator;
  public readonly presentmentCardPriceHeaderMobile: Locator;
  public readonly recalculateButtonDesktop: Locator;
  public readonly recalculateButtonMobile: Locator;
  public readonly linkViewPayInFullPricingDesktop: Locator;
  public readonly linkViewPayInFullPricingMobile: Locator;
  public readonly presentmentCardPriceHeader: Locator;
  public readonly linkViewMonthlyPricing: Locator;
  public readonly linkViewPayInFullPricing: Locator;
  public readonly linkPriceAlternative: Locator;
  public readonly quotePackagePriceOnCard: Locator;
  public readonly quoteAllOtherCoveragesPriceOnCard: Locator;
  public readonly quoteDiscountsOnCard: Locator;
  public readonly policyDeductibleHeader: Locator;
  public readonly outOfPocketLossForCoveredLoss: Locator;
  public readonly deductibleLabels: Locator;
  public readonly deductibleAmount: Locator;
  public readonly allPerilsDeductibleInfoIcon: Locator;
  public readonly windAndHailDeductibleInfoIcon: Locator;
  public readonly deductibleMatDividers: Locator;
  public readonly editDeductibleIcon: Locator;
  public readonly editDeductibleText: Locator;
  public readonly editDeductibleButton: Locator;
  public readonly policyDeductibleHeaderInSideSheet: Locator;
  public readonly closeIconPolicyDeductibleSideSheet: Locator;
  public readonly policyDeductibleTitlesInSideSheet: Locator;
  public readonly policyDeductibleExplanationInSideSheet: Locator;
  public readonly policyDeductibleSideSheetDividers: Locator;
  public readonly deductibleHeader: Locator;
  public readonly closeIconInDeductibleSideSheet: Locator;
  public readonly allPerilLossesHeader: Locator;
  public readonly allPerilLossesDescription: Locator;
  public readonly allPerilLossesRadioButtons: Locator;
  public readonly windAndHailLossesHeader: Locator;
  public readonly windAndHailLossesDescription: Locator;
  public readonly windAndHailLossesRadioButtons: Locator;
  public readonly matDividerInDeductiblesSideSheet: Locator;
  public readonly recalculateButtonHomeLobSideSheet: Locator;
  public readonly resetChangesButton: Locator;
  public readonly recalculateButtonRentersCondoInSideSheet: Locator;
  public readonly resetChangesButtonRentersCondoInSideSheet: Locator;
  public readonly resetChangesHeader: Locator;
  public readonly areYouSureYouWantToResetChangesQuestion: Locator;
  public readonly keepEditingButton: Locator;
  public readonly resetButton: Locator;
  public readonly windAndHailDeductibleCannotBeLowerThanAllPerilError: Locator;
  public readonly closeIconInPolicyDeductibleSideSheet: Locator;
  public readonly standardPackageButton: Locator;
  public readonly enhancedPackageButton: Locator;
  public readonly premierPackageButton: Locator;
  public readonly packageNameHeader: Locator;
  public readonly packageSubTotalHeader: Locator;
  public readonly packagePremiumAmount: Locator;
  public readonly reducedCoverageForReducedPriceLabel: Locator;
  public readonly comparePackageDoubleArrowIcon: Locator;
  public readonly comparePackageButton: Locator;
  public readonly coverageTypeLabels: Locator;
  public readonly coveragesLabels: Locator;
  public readonly limitLabels: Locator;
  public readonly coverageNames: Locator;
  public readonly showSpecialLimitsLinkButton: Locator;
  public readonly showSpecialLimitsLinkPlusIcon: Locator;
  public readonly coverageAmountValues: Locator;
  public readonly coveragesHeader: Locator;
  public readonly closeIconOnCoveragesSideSheet: Locator;
  public readonly allPerilsHeaderInCoverageSideSheet: Locator;
  public readonly allPerilExplanation: Locator;
  public readonly allPerilMatRadioButtonInCoverageSideSheet: Locator;
  public readonly uncheckedPerilMatRadioButtonInCoverageSideSheet: Locator;
  public readonly saveInProgressFooter: Locator;
  public readonly quoteNumberText: Locator;
  public readonly continueButtonMobile: Locator;
  public readonly continueButtonDesktop: Locator;
  public readonly coveragesLabel: Locator;
  public readonly limitsLabel: Locator;
  public readonly condoRentersCoveragesNamesOnReviewQuotePage: Locator;
  public readonly condoRentersCoveragesAmountOnReviewQuotePage: Locator;
  public readonly condoRentersAddEditCoverageLink: Locator;
  public readonly condoRentersCoverageSideSheetHeader: Locator;
  public readonly coverageHintEditCoverageSideSheet: Locator;
  public readonly personalPropertyLabelInEditCoverageSideSheet: Locator;
  public readonly personalPropertyDescriptionWebElement: Locator;
  public readonly unitOwnerBuildingPropertyLabelInEditCoverageSideSheet: Locator;
  public readonly unitOwnerBuildingPropertyDescriptionWebElement: Locator;
  public readonly lossOfUseLabelInEditCoverageSideSheet: Locator;
  public readonly lossOfUseDescriptionWebElement: Locator;
  public readonly lossOfUseDropDownWebElement: Locator;
  public readonly lossOfUseDropDownPlaceHolder: Locator;
  public readonly lossOfUseDropDownOptions: Locator;
  public readonly lossOfUseDropDownOption: Locator;
  public readonly selectedLossOfUseOptionWebElement: Locator;
  public readonly personalLiabilityLabelInEditCoverageSideSheet: Locator;
  public readonly personalLiabilityDescriptionWebElement: Locator;
  public readonly personalLiabilityRadioButtonElements: Locator;
  public readonly selectedPersonalLiabilityRadioButtonElement: Locator;
  public readonly medicalPaymentToOthersLabelInEditCoverageSideSheet: Locator;
  public readonly medicalPaymentToOthersDescriptionWebElement: Locator;
  public readonly medicalPaymentToOthersRadioButtonElements: Locator;
  public readonly selectedMedicalPaymentToOthersRadioButtonElement: Locator;
  public readonly unselectedMedicalPaymentToOthersRadioButtonElement: Locator;
  public readonly limitedMoldToggleButtonInEditCoverageSideSheet: Locator;
  public readonly limitedMoldLabelInEditCoverageSideSheet: Locator;
  public readonly limitedMoldDescriptionWebElement: Locator;
  public readonly limitedMoldRadioButtonElements: Locator;
  public readonly selectedLimitedMoldRadioButtonElement: Locator;
  public readonly mineSubsidenceLabelInEditCoverageSideSheet: Locator;
  public readonly mineSubsidenceDescriptionWebElement: Locator;
  public readonly mineSubsidenceCoveredValueWebElement: Locator;
  public readonly increaseLossAssessmentToggleButtonInEditCoverageSideSheet: Locator;
  public readonly increaseLossAssessmentLabelInEditCoverageSideSheet: Locator;
  public readonly increaseLossAssessmentDescriptionWebElement: Locator;
  public readonly increaseLossAssessmentCoverageLimitWebElement: Locator;
  public readonly increaseLossAssessmentRadioButtonElements: Locator;
  public readonly selectedIncreaseLossAssessmentRadioButtonElement: Locator;
  public readonly selectedDollarIncreaseLossAssessmentValue: Locator;
  public readonly buildingOrdinanceToggleButtonInEditCoverageSideSheet: Locator;
  public readonly buildingOrdinanceLabelInEditCoverageSideSheet: Locator;
  public readonly buildingOrdinanceDescriptionWebElement: Locator;
  public readonly buildingOrdinanceRadioButtonElements: Locator;
  public readonly selectedBuildingOrdinanceRadioButtonElement: Locator;
  public readonly selectedDollarBuildingOrdinanceValue: Locator;
  public readonly homeSharingLabelInEditCoverageSideSheet: Locator;
  public readonly homeSharingDescriptionWebElement: Locator;
  public readonly homeShariongCoveredValueWebElement: Locator;
  public readonly youGetAllTheseWithYourHomePolicyTitle: Locator;
  public readonly decliningDeductiblesIcon: Locator;
  public readonly decliningDeductiblesTitle: Locator;
  public readonly decliningDeductiblesDescription: Locator;
  public readonly claimForgivenessIcon: Locator;
  public readonly claimForgivenessTitle: Locator;
  public readonly claimForgivenessDescription: Locator;
  public readonly claimFreeDiscountIcon: Locator;
  public readonly claimFreeDiscountTitle: Locator;
  public readonly claimFreeDiscountDescription: Locator;
  public readonly acvToggleButtonUnderPersonalProperty: Locator;
  public readonly rcvToggleButtonUnderPersonalProperty: Locator;
  public readonly bundlePropertyQuoteReviewPageTitle: Locator;
  public readonly bundlePropertyQuoteReviewPageSubtitle: Locator;
  public readonly nextMorePropertyCoveragesButton: Locator;
  public readonly reviewMoreRentersCoveragesButton: Locator;
  public readonly monthlyAmountText: Locator;
  public readonly monthlyAmount2Text: Locator;
  public readonly viewPricingLink: Locator;

  public constructor(page: Page) {
    super(page);
    this.quoteSummaryHeading = page.locator("[data-legacy-field=\"quoteSummaryHeading\"]"); // @FindBy(xpath = PAGE_TITLE_XPATH)
    this.quoteSummarySubheading = page.locator("xpath=//app-home-quote-review//div[contains(@class,'tui-stacking-top-xl')]/div[contains(@class,'tui-stacking-top-md')]"); // @FindBy(xpath = "//app-home-quote-review//div[contains(@class,'tui-stacking-top-xl')]/div[contains(@class,'tui-stacking-top-md')]")
    this.linkChangeCoverage = page.locator("[data-legacy-field=\"linkChangeCoverage\"]"); // @FindBy(xpath = CHANGE_COVERAGE_XPATH)
    this.quotePriceOnCardDesktop = page.locator("[data-legacy-field=\"quotePriceOnCardDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tui-price")
    this.quotePriceOnCardMobile = page.locator("[data-legacy-field=\"quotePriceOnCardMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//tui-price")
    this.buttonContinueDesktop = page.locator("[data-legacy-field=\"buttonContinueDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[contains(text(),'Continue')]")
    this.buttonContinueMobile = page.locator("[data-legacy-field=\"buttonContinueMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[contains(text(),'Continue')]")
    this.buttonContinueMobileAtPageBottom = page.locator("xpath=//div[contains(@class,'quote-mobile-display')]//button[contains(text(),'Continue')]"); // @FindBy(xpath = "//div[contains(@class,'quote-mobile-display')]//button[contains(text(),'Continue')]")
    this.primaryCoveragesPriceOnCardDesktop = page.locator("[data-legacy-field=\"primaryCoveragesPriceOnCardDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + PRIMARY_COVERAGES_XPATH)
    this.primaryCoveragesPriceOnCardMobile = page.locator("[data-legacy-field=\"primaryCoveragesPriceOnCardMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + PRIMARY_COVERAGES_XPATH)
    this.quoteOptionalCoveragesPriceOnCardDesktop = page.locator("[data-legacy-field=\"quoteOptionalCoveragesPriceOnCardDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + OPTIONAL_COVERAGES_XPATH)
    this.quoteOptionalCoveragesPriceOnCardMobile = page.locator("[data-legacy-field=\"quoteOptionalCoveragesPriceOnCardMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + OPTIONAL_COVERAGES_XPATH)
    this.quoteDiscountsOnCardDesktop = page.locator("[data-legacy-field=\"quoteDiscountsOnCardDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div")
    this.quoteDiscountsOnCardMobile = page.locator("[data-legacy-field=\"quoteDiscountsOnCardMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//mat-list-item//div")
    this.linkViewMonthlyPricingDesktop = page.locator("[data-legacy-field=\"linkViewMonthlyPricingDesktop\"]"); // @FindBy(xpath = VIEW_MONTHLY_PRICING_LINK_DESKTOP_XPATH)
    this.linkViewMonthlyPricingMobile = page.locator("[data-legacy-field=\"linkViewMonthlyPricingMobile\"]"); // @FindBy(xpath = VIEW_MONTHLY_PRICING_LINK_MOBILE_XPATH)
    this.expandQuoteCard = page.locator("[data-legacy-field=\"expandQuoteCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//mat-icon[@aria-label='expand quote card']")
    this.minimizeQuoteCard = page.locator("[data-legacy-field=\"minimizeQuoteCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//mat-icon[@aria-label='minimize quote card']")
    this.dialogButtonOk = page.locator("xpath=//mat-dialog-container//button[text()='OK']"); // @FindBy(xpath = "//mat-dialog-container//button[text()='OK']")
    this.presentmentCardPriceHeaderDesktop = page.locator("[data-legacy-field=\"presentmentCardPriceHeaderDesktop\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + PRESENTMENT_CARD_PRICE_HEADER_XPATH)
    this.presentmentCardPriceHeaderMobile = page.locator("[data-legacy-field=\"presentmentCardPriceHeaderMobile\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + PRESENTMENT_CARD_PRICE_HEADER_XPATH)
    this.recalculateButtonDesktop = page.locator("[data-legacy-field=\"recalculateButtonDesktop\"]"); // @FindBy(xpath = RECALCULATE_BUTTON_DESKTOP_XPATH)
    this.recalculateButtonMobile = page.locator("[data-legacy-field=\"recalculateButtonMobile\"]"); // @FindBy(xpath = RECALCULATE_BUTTON_MOBILE_XPATH)
    this.linkViewPayInFullPricingDesktop = page.locator("[data-legacy-field=\"linkViewPayInFullPricingDesktop\"]"); // @FindBy(xpath = VIEW_PAY_IN_FULL_PRICING_LINK_DESKTOP_XPATH)
    this.linkViewPayInFullPricingMobile = page.locator("[data-legacy-field=\"linkViewPayInFullPricingMobile\"]"); // @FindBy(xpath = VIEW_PAY_IN_FULL_PRICING_LINK_MOBILE_XPATH)
    this.presentmentCardPriceHeader = page.locator("[data-legacy-field=\"presentmentCardPriceHeader\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + PRESENTMENT_CARD_PRICE_HEADER_XPATH)
    this.linkViewMonthlyPricing = page.locator("[data-legacy-field=\"linkViewMonthlyPricing\"]"); // @FindBy(xpath = VIEW_MONTHLY_PRICING_LINK_XPATH)
    this.linkViewPayInFullPricing = page.locator("[data-legacy-field=\"linkViewPayInFullPricing\"]"); // @FindBy(xpath = VIEW_PAY_IN_FULL_PRICING_LINK_XPATH)
    this.linkPriceAlternative = page.locator("xpath=//button[@data-test-id='PRICE-ALTERNATIVE-BUTTON']"); // @FindBy(xpath = "//button[@data-test-id='PRICE-ALTERNATIVE-BUTTON']")
    this.quotePackagePriceOnCard = page.locator("[data-legacy-field=\"quotePackagePriceOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[starts-with(text(),'Included coverages')]/following-sibling::td")
    this.quoteAllOtherCoveragesPriceOnCard = page.locator("[data-legacy-field=\"quoteAllOtherCoveragesPriceOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[text()='Optional coverages']/following-sibling::td")
    this.quoteDiscountsOnCard = page.locator("[data-legacy-field=\"quoteDiscountsOnCard\"]"); // @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div")
    this.policyDeductibleHeader = page.locator("xpath=//div[contains(@class,'main-content')]/div[1]"); // @FindBy(xpath = "//div[contains(@class,'main-content')]/div[1]")
    this.outOfPocketLossForCoveredLoss = page.locator("xpath=//div[contains(@class,'main-content')]/div[contains(@class,'tui-stacking-top-sm')]"); // @FindBy(xpath = "//div[contains(@class,'main-content')]/div[contains(@class,'tui-stacking-top-sm')]")
    this.deductibleLabels = page.locator("xpath=//div[contains(@class,'deductible-label')]"); // @FindBy(xpath = "//div[contains(@class,'deductible-label')]")
    this.deductibleAmount = page.locator("xpath=//div[contains(@class,'deductible-amount')]"); // @FindBy(xpath = "//div[contains(@class,'deductible-amount')]")
    this.allPerilsDeductibleInfoIcon = page.locator("xpath=//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_A']"); // @FindBy(xpath = "//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_A']")
    this.windAndHailDeductibleInfoIcon = page.locator("xpath=//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_W']"); // @FindBy(xpath = "//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_W']")
    this.deductibleMatDividers = page.locator("xpath=//div[contains(@class,'deductibles')]//mat-divider"); // @FindBy(xpath = "//div[contains(@class,'deductibles')]//mat-divider")
    this.editDeductibleIcon = page.locator("xpath=//button[contains(@class,'edit-deductibles-button')]//mat-icon"); // @FindBy(xpath = "//button[contains(@class,'edit-deductibles-button')]//mat-icon")
    this.editDeductibleText = page.locator("xpath=//button[contains(@class,'edit-deductibles-button')]//span"); // @FindBy(xpath = "//button[contains(@class,'edit-deductibles-button')]//span")
    this.editDeductibleButton = page.locator("xpath=//button[contains(@class,'edit-deductibles-button')]"); // @FindBy(xpath = "//button[contains(@class,'edit-deductibles-button')]")
    this.policyDeductibleHeaderInSideSheet = page.locator("xpath=//app-home-coverages-and-deductibles-info-dialog//h1"); // @FindBy(xpath = "//app-home-coverages-and-deductibles-info-dialog//h1")
    this.closeIconPolicyDeductibleSideSheet = page.locator("xpath=//app-home-coverages-and-deductibles-info-dialog//button[@aria-label='Close']"); // @FindBy(xpath = "//app-home-coverages-and-deductibles-info-dialog//button[@aria-label='Close']")
    this.policyDeductibleTitlesInSideSheet = page.locator("xpath=//mat-panel-title//div"); // @FindBy(xpath = "//mat-panel-title//div")
    this.policyDeductibleExplanationInSideSheet = page.locator("xpath=//div[contains(@class,'mat-expansion-panel-body')]//p[contains(@class,'tui-caption-text')][1]"); // @FindBy(xpath = "//div[contains(@class,'mat-expansion-panel-body')]//p[contains(@class,'tui-caption-text')][1]")
    this.policyDeductibleSideSheetDividers = page.locator("xpath=//mat-accordion//mat-divider"); // @FindBy(xpath = "//mat-accordion//mat-divider")
    this.deductibleHeader = page.locator("xpath=//app-edit-home-deductibles-side-sheet//h1"); // @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//h1")
    this.closeIconInDeductibleSideSheet = page.locator("xpath=//app-edit-home-deductibles-side-sheet//button//mat-icon"); // @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//button//mat-icon")
    this.allPerilLossesHeader = page.locator("xpath=//app-edit-home-deductibles-side-sheet//h2[1]"); // @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//h2[1]")
    this.allPerilLossesDescription = page.locator("xpath=//div[contains(@class,'tui-caption-text')][1]"); // @FindBy(xpath = "//div[contains(@class,'tui-caption-text')][1]")
    this.allPerilLossesRadioButtons = page.locator("xpath=//mat-radio-group[@name='allPerilsCoverageSelection']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@name='allPerilsCoverageSelection']//mat-radio-button")
    this.windAndHailLossesHeader = page.locator("xpath=//app-edit-home-deductibles-side-sheet//h2[2]"); // @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//h2[2]")
    this.windAndHailLossesDescription = page.locator("xpath=//div[contains(@class,'tui-caption-text')][2]"); // @FindBy(xpath = "//div[contains(@class,'tui-caption-text')][2]")
    this.windAndHailLossesRadioButtons = page.locator("xpath=//mat-radio-group[@name='windAndHailCoverageSelection']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@name='windAndHailCoverageSelection']//mat-radio-button")
    this.matDividerInDeductiblesSideSheet = page.locator("xpath=//app-edit-home-deductibles-side-sheet//mat-divider"); // @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//mat-divider")
    this.recalculateButtonHomeLobSideSheet = page.locator("xpath=//button[@data-test-id='RECALCULATE_BUTTON']"); // @FindBy(xpath = "//button[@data-test-id='RECALCULATE_BUTTON']")
    this.resetChangesButton = page.locator("xpath=//button[@data-test-id='OPEN_CONFIRM_RESET_DIALOG_BUTTON']"); // @FindBy(xpath = "//button[@data-test-id='OPEN_CONFIRM_RESET_DIALOG_BUTTON']")
    this.recalculateButtonRentersCondoInSideSheet = page.locator("xpath=//button[contains(@class,'edit-coverage-dialog-submit-button')]"); // @FindBy(xpath = "//button[contains(@class,'edit-coverage-dialog-submit-button')]")
    this.resetChangesButtonRentersCondoInSideSheet = page.locator("xpath=//div[contains(@class,'coverages-docked-buttons')]//button[2]"); // @FindBy(xpath = "//div[contains(@class,'coverages-docked-buttons')]//button[2]")
    this.resetChangesHeader = page.locator("xpath=//h2[contains(@class,'reset-changes-heading')]"); // @FindBy(xpath = "//h2[contains(@class,'reset-changes-heading')]")
    this.areYouSureYouWantToResetChangesQuestion = page.locator("xpath=//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-content"); // @FindBy(xpath = "//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-content")
    this.keepEditingButton = page.locator("xpath=//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[1]"); // @FindBy(xpath = "//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[1]")
    this.resetButton = page.locator("xpath=//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[2]"); // @FindBy(xpath = "//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[2]")
    this.windAndHailDeductibleCannotBeLowerThanAllPerilError = page.locator("xpath=//mat-error[contains(@class,'home-quote-deductible__error-label')]"); // @FindBy(xpath = "//mat-error[contains(@class,'home-quote-deductible__error-label')]")
    this.closeIconInPolicyDeductibleSideSheet = page.locator("xpath=//app-home-coverages-and-deductibles-info-dialog//button[@aria-label='Close']"); // @FindBy(xpath = "//app-home-coverages-and-deductibles-info-dialog//button[@aria-label='Close']")
    this.standardPackageButton = page.locator("xpath=//div[@aria-label='Standard package']"); // @FindBy(xpath = "//div[@aria-label='Standard package']")
    this.enhancedPackageButton = page.locator("xpath=//div[@aria-label='Enhanced package']"); // @FindBy(xpath = "//div[@aria-label='Enhanced package']")
    this.premierPackageButton = page.locator("xpath=//div[@aria-label='Premier package']"); // @FindBy(xpath = "//div[@aria-label='Premier package']")
    this.packageNameHeader = page.locator("xpath=//div[contains(@class,'package-body-content')]/div[1]"); // @FindBy(xpath = "//div[contains(@class,'package-body-content')]/div[1]")
    this.packageSubTotalHeader = page.locator("xpath=//div[contains(@class,'package-body-content')]/div[2]"); // @FindBy(xpath = "//div[contains(@class,'package-body-content')]/div[2]")
    this.packagePremiumAmount = page.locator("xpath=//div[contains(@class,'package-body-content')]/div[3]"); // @FindBy(xpath = "//div[contains(@class,'package-body-content')]/div[3]")
    this.reducedCoverageForReducedPriceLabel = page.locator("xpath=//div[contains(@class,'package-body-content')]/div[4]"); // @FindBy(xpath = "//div[contains(@class,'package-body-content')]/div[4]")
    this.comparePackageDoubleArrowIcon = page.locator("xpath=//button[contains(@class,'compare-button')]//mat-icon"); // @FindBy(xpath = "//button[contains(@class,'compare-button')]//mat-icon")
    this.comparePackageButton = page.locator("xpath=//button[contains(@class,'compare-button')]"); // @FindBy(xpath = "//button[contains(@class,'compare-button')]")
    this.coverageTypeLabels = page.locator("xpath=//div[contains(@class,'coverage-section-label')]"); // @FindBy(xpath = "//div[contains(@class,'coverage-section-label')]")
    this.coveragesLabels = page.locator("xpath=//div[contains(text(),'Coverages')]"); // @FindBy(xpath = "//div[contains(text(),'Coverages')]")
    this.limitLabels = page.locator("xpath=//div[contains(text(),'Limits')]"); // @FindBy(xpath = "//div[contains(text(),'Limits')]")
    this.coverageNames = page.locator("xpath=//div[contains(@class,'coverage-description')]"); // @FindBy(xpath = "//div[contains(@class,'coverage-description')]")
    this.showSpecialLimitsLinkButton = page.locator("xpath=//button[@id='specialLimitsButton']//span"); // @FindBy(xpath = "//button[@id='specialLimitsButton']//span")
    this.showSpecialLimitsLinkPlusIcon = page.locator("xpath=//button[@id='specialLimitsButton']//mat-icon[text()='add' or text()='keyboard_arrow_down']"); // @FindBy(xpath = "//button[@id='specialLimitsButton']//mat-icon[text()='add' or text()='keyboard_arrow_down']")
    this.coverageAmountValues = page.locator("xpath=//div[contains(@class,'coverage-amount')]"); // @FindBy(xpath = "//div[contains(@class,'coverage-amount')]")
    this.coveragesHeader = page.locator("xpath=//div[@id='editCoverageDialogHeading']"); // @FindBy(xpath = "//div[@id='editCoverageDialogHeading']")
    this.closeIconOnCoveragesSideSheet = page.locator("xpath=//div[contains(@class,'edit-coverage-dialog-heading')]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'edit-coverage-dialog-heading')]//mat-icon")
    this.allPerilsHeaderInCoverageSideSheet = page.locator("xpath=//div[contains(@class,'quote-coverages-slide-toggle__container')]/label"); // @FindBy(xpath = "//div[contains(@class,'quote-coverages-slide-toggle__container')]/label")
    this.allPerilExplanation = page.locator("xpath=//div[contains(@class,'quote-coverage__description')]"); // @FindBy(xpath = "//div[contains(@class,'quote-coverage__description')]")
    this.allPerilMatRadioButtonInCoverageSideSheet = page.locator("xpath=//mat-radio-group[@id='__A__radio']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@id='__A__radio']//mat-radio-button")
    this.uncheckedPerilMatRadioButtonInCoverageSideSheet = page.locator("xpath=//mat-radio-group[@id='__A__radio']//mat-radio-button[not(contains(@class,'checked'))]"); // @FindBy(xpath = "//mat-radio-group[@id='__A__radio']//mat-radio-button[not(contains(@class,'checked'))]")
    this.saveInProgressFooter = page.locator("xpath=//div[contains(@class,'save-in-progress')]/p"); // @FindBy(xpath = "//div[contains(@class,'save-in-progress')]/p")
    this.quoteNumberText = page.locator("xpath=//div[contains(@class,'save-quote')]"); // @FindBy(xpath = "//div[contains(@class,'save-quote')]")
    this.continueButtonMobile = page.locator("xpath=//button[contains(@class,'tui-quote-presentment-minimized-button')] | //tui-quote-presentment//button"); // @FindBy(xpath = "//button[contains(@class,'tui-quote-presentment-minimized-button')] | //tui-quote-presentment//button")
    this.continueButtonDesktop = page.locator("xpath=//tui-quote-presentment//button[not(contains(@class, 'inserted'))]"); // @FindBy(xpath = "//tui-quote-presentment//button[not(contains(@class, 'inserted'))]")
    this.coveragesLabel = page.locator("xpath=//div[contains(@class,'condo-renters-quote-coverages')]//p[1]"); // @FindBy(xpath = "//div[contains(@class,'condo-renters-quote-coverages')]//p[1]")
    this.limitsLabel = page.locator("xpath=//div[contains(@class,'condo-renters-quote-coverages')]//p[2]"); // @FindBy(xpath = "//div[contains(@class,'condo-renters-quote-coverages')]//p[2]")
    this.condoRentersCoveragesNamesOnReviewQuotePage = page.locator("xpath=//div[contains(@class,'condo-renters-quote-coverages')]//div[contains(@class,'row')]/div[contains(@class,'tui-body') and not(contains(@class,'coverage-price-column'))]"); // @FindBy(xpath = "//div[contains(@class,'condo-renters-quote-coverages')]//div[contains(@class,'row')]/div[contains(@class,'tui-body') and not(contains(@class,'coverage-price-column'))]")
    this.condoRentersCoveragesAmountOnReviewQuotePage = page.locator("xpath=//div[contains(@class,'condo-renters-quote-coverages')]//div[contains(@class,'row')]/div[contains(@class,'tui-body') and contains(@class,'coverage-price-column')]"); // @FindBy(xpath = "//div[contains(@class,'condo-renters-quote-coverages')]//div[contains(@class,'row')]/div[contains(@class,'tui-body') and contains(@class,'coverage-price-column')]")
    this.condoRentersAddEditCoverageLink = page.locator("xpath=//button[@id='editCoverageLink' and contains(text(),'Add/edit coverages')]"); // @FindBy(xpath = "//button[@id='editCoverageLink' and contains(text(),'Add/edit coverages')]")
    this.condoRentersCoverageSideSheetHeader = page.locator("xpath=//div[@id='editCoverageDialogHeading']"); // @FindBy(xpath = "//div[@id='editCoverageDialogHeading']")
    this.coverageHintEditCoverageSideSheet = page.locator("xpath=//app-edit-coverage//div[contains(@class,'tui-caption-text') and contains(@class,'mt-3')]"); // @FindBy(xpath = "//app-edit-coverage//div[contains(@class,'tui-caption-text') and contains(@class,'mt-3')]")
    this.personalPropertyLabelInEditCoverageSideSheet = page.locator("[data-legacy-field=\"personalPropertyLabelInEditCoverageSideSheet\"]"); // @FindBy(xpath = PERSONAL_PROPERTY_LABEL_XPATH)
    this.personalPropertyDescriptionWebElement = page.locator("[data-legacy-field=\"personalPropertyDescriptionWebElement\"]"); // @FindBy(xpath = PERSONAL_PROPERTY_LABEL_XPATH + COVERAGE_DESCRIPTION_XPATH)
    this.unitOwnerBuildingPropertyLabelInEditCoverageSideSheet = page.locator("[data-legacy-field=\"unitOwnerBuildingPropertyLabelInEditCoverageSideSheet\"]"); // @FindBy(xpath = UNIT_OWNER_BUILDING_PROPERTY_XPATH)
    this.unitOwnerBuildingPropertyDescriptionWebElement = page.locator("[data-legacy-field=\"unitOwnerBuildingPropertyDescriptionWebElement\"]"); // @FindBy(xpath = UNIT_OWNER_BUILDING_PROPERTY_XPATH + COVERAGE_DESCRIPTION_XPATH)
    this.lossOfUseLabelInEditCoverageSideSheet = page.locator("[data-legacy-field=\"lossOfUseLabelInEditCoverageSideSheet\"]"); // @FindBy(xpath = LOSS_OF_USE_XPATH)
    this.lossOfUseDescriptionWebElement = page.locator("[data-legacy-field=\"lossOfUseDescriptionWebElement\"]"); // @FindBy(xpath = LOSS_OF_USE_XPATH + COVERAGE_DESCRIPTION_XPATH)
    this.lossOfUseDropDownWebElement = page.locator("[data-legacy-field=\"lossOfUseDropDownWebElement\"]"); // @FindBy(xpath = LOSS_OF_USE_XPATH + "/ancestor::coverage-data-card//mat-select")
    this.lossOfUseDropDownPlaceHolder = page.locator("[data-legacy-field=\"lossOfUseDropDownPlaceHolder\"]"); // @FindBy(xpath = LOSS_OF_USE_XPATH + "/ancestor::coverage-data-card//mat-label")
    this.lossOfUseDropDownOptions = page.locator("xpath=//mat-option"); // @FindBy(xpath = "//mat-option")
    this.lossOfUseDropDownOption = page.locator("xpath=//mat-option"); // @FindBy(xpath = "//mat-option")
    this.selectedLossOfUseOptionWebElement = page.locator("xpath=//mat-option[contains(@class,'item--selected')]"); // @FindBy(xpath = "//mat-option[contains(@class,'item--selected')]")
    this.personalLiabilityLabelInEditCoverageSideSheet = page.locator("[data-legacy-field=\"personalLiabilityLabelInEditCoverageSideSheet\"]"); // @FindBy(xpath = PERSONAL_LIABILITY_XPATH)
    this.personalLiabilityDescriptionWebElement = page.locator("[data-legacy-field=\"personalLiabilityDescriptionWebElement\"]"); // @FindBy(xpath = PERSONAL_LIABILITY_XPATH + COVERAGE_DESCRIPTION_XPATH)
    this.personalLiabilityRadioButtonElements = page.locator("[data-legacy-field=\"personalLiabilityRadioButtonElements\"]"); // @FindBy(xpath = PERSONAL_LIABILITY_XPATH + "//ancestor::coverage-data-card//mat-radio-button")
    this.selectedPersonalLiabilityRadioButtonElement = page.locator("[data-legacy-field=\"selectedPersonalLiabilityRadioButtonElement\"]"); // @FindBy(xpath = PERSONAL_LIABILITY_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]")
    this.medicalPaymentToOthersLabelInEditCoverageSideSheet = page.locator("[data-legacy-field=\"medicalPaymentToOthersLabelInEditCoverageSideSheet\"]"); // @FindBy(xpath = MEDICAL_PAYMENT_TO_OTHERS_XPATH)
    this.medicalPaymentToOthersDescriptionWebElement = page.locator("[data-legacy-field=\"medicalPaymentToOthersDescriptionWebElement\"]"); // @FindBy(xpath = MEDICAL_PAYMENT_TO_OTHERS_XPATH + COVERAGE_DESCRIPTION_XPATH)
    this.medicalPaymentToOthersRadioButtonElements = page.locator("[data-legacy-field=\"medicalPaymentToOthersRadioButtonElements\"]"); // @FindBy(xpath = MEDICAL_PAYMENT_TO_OTHERS_XPATH + "//ancestor::coverage-data-card//mat-radio-button")
    this.selectedMedicalPaymentToOthersRadioButtonElement = page.locator("[data-legacy-field=\"selectedMedicalPaymentToOthersRadioButtonElement\"]"); // @FindBy(xpath = MEDICAL_PAYMENT_TO_OTHERS_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]")
    this.unselectedMedicalPaymentToOthersRadioButtonElement = page.locator("[data-legacy-field=\"unselectedMedicalPaymentToOthersRadioButtonElement\"]"); // @FindBy(xpath = MEDICAL_PAYMENT_TO_OTHERS_XPATH + "//ancestor::coverage-data-card//mat-radio-button[not(contains(@class,'" + RADIO_BUTTON_CHECKED + "'))]//input")
    this.limitedMoldToggleButtonInEditCoverageSideSheet = page.locator("[data-legacy-field=\"limitedMoldToggleButtonInEditCoverageSideSheet\"]"); // @FindBy(xpath = LIMITED_MOLD_XPATH + "//ancestor::mat-slide-toggle")
    this.limitedMoldLabelInEditCoverageSideSheet = page.locator("[data-legacy-field=\"limitedMoldLabelInEditCoverageSideSheet\"]"); // @FindBy(xpath = LIMITED_MOLD_XPATH)
    this.limitedMoldDescriptionWebElement = page.locator("[data-legacy-field=\"limitedMoldDescriptionWebElement\"]"); // @FindBy(xpath = LIMITED_MOLD_XPATH + COVERAGE_DESCRIPTION_XPATH)
    this.limitedMoldRadioButtonElements = page.locator("[data-legacy-field=\"limitedMoldRadioButtonElements\"]"); // @FindBy(xpath = LIMITED_MOLD_XPATH + "//ancestor::coverage-data-card//mat-radio-button")
    this.selectedLimitedMoldRadioButtonElement = page.locator("[data-legacy-field=\"selectedLimitedMoldRadioButtonElement\"]"); // @FindBy(xpath = LIMITED_MOLD_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'mat-radio-checked')]")
    this.mineSubsidenceLabelInEditCoverageSideSheet = page.locator("[data-legacy-field=\"mineSubsidenceLabelInEditCoverageSideSheet\"]"); // @FindBy(xpath = MINE_SUBSIDENCE_XPATH)
    this.mineSubsidenceDescriptionWebElement = page.locator("[data-legacy-field=\"mineSubsidenceDescriptionWebElement\"]"); // @FindBy(xpath = MINE_SUBSIDENCE_XPATH + COVERAGE_DESCRIPTION_XPATH)
    this.mineSubsidenceCoveredValueWebElement = page.locator("[data-legacy-field=\"mineSubsidenceCoveredValueWebElement\"]"); // @FindBy(xpath = MINE_SUBSIDENCE_XPATH + COVERAGE_DESCRIPTION_XPATH + "//following::div[1]")
    this.increaseLossAssessmentToggleButtonInEditCoverageSideSheet = page.locator("[data-legacy-field=\"increaseLossAssessmentToggleButtonInEditCoverageSideSheet\"]"); // @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH + "//ancestor::mat-slide-toggle")
    this.increaseLossAssessmentLabelInEditCoverageSideSheet = page.locator("[data-legacy-field=\"increaseLossAssessmentLabelInEditCoverageSideSheet\"]"); // @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH)
    this.increaseLossAssessmentDescriptionWebElement = page.locator("[data-legacy-field=\"increaseLossAssessmentDescriptionWebElement\"]"); // @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH + COVERAGE_DESCRIPTION_XPATH)
    this.increaseLossAssessmentCoverageLimitWebElement = page.locator("[data-legacy-field=\"increaseLossAssessmentCoverageLimitWebElement\"]"); // @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH + "/ancestor::coverage-data-card//p[contains(@class,'quote-coverage-limit')]")
    this.increaseLossAssessmentRadioButtonElements = page.locator("[data-legacy-field=\"increaseLossAssessmentRadioButtonElements\"]"); // @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH + "//ancestor::coverage-data-card//mat-radio-button")
    this.selectedIncreaseLossAssessmentRadioButtonElement = page.locator("[data-legacy-field=\"selectedIncreaseLossAssessmentRadioButtonElement\"]"); // @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]")
    this.selectedDollarIncreaseLossAssessmentValue = page.locator("[data-legacy-field=\"selectedDollarIncreaseLossAssessmentValue\"]"); // @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]//p[1]")
    this.buildingOrdinanceToggleButtonInEditCoverageSideSheet = page.locator("[data-legacy-field=\"buildingOrdinanceToggleButtonInEditCoverageSideSheet\"]"); // @FindBy(xpath = BUILDING_ORDINANCE_XPATH + "//ancestor::mat-slide-toggle")
    this.buildingOrdinanceLabelInEditCoverageSideSheet = page.locator("[data-legacy-field=\"buildingOrdinanceLabelInEditCoverageSideSheet\"]"); // @FindBy(xpath = BUILDING_ORDINANCE_XPATH)
    this.buildingOrdinanceDescriptionWebElement = page.locator("[data-legacy-field=\"buildingOrdinanceDescriptionWebElement\"]"); // @FindBy(xpath = BUILDING_ORDINANCE_XPATH + COVERAGE_DESCRIPTION_XPATH)
    this.buildingOrdinanceRadioButtonElements = page.locator("[data-legacy-field=\"buildingOrdinanceRadioButtonElements\"]"); // @FindBy(xpath = BUILDING_ORDINANCE_XPATH + "//ancestor::coverage-data-card//mat-radio-button")
    this.selectedBuildingOrdinanceRadioButtonElement = page.locator("[data-legacy-field=\"selectedBuildingOrdinanceRadioButtonElement\"]"); // @FindBy(xpath = BUILDING_ORDINANCE_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]")
    this.selectedDollarBuildingOrdinanceValue = page.locator("[data-legacy-field=\"selectedDollarBuildingOrdinanceValue\"]"); // @FindBy(xpath = BUILDING_ORDINANCE_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]//p[1]")
    this.homeSharingLabelInEditCoverageSideSheet = page.locator("[data-legacy-field=\"homeSharingLabelInEditCoverageSideSheet\"]"); // @FindBy(xpath = HOME_SHARING_XPATH)
    this.homeSharingDescriptionWebElement = page.locator("[data-legacy-field=\"homeSharingDescriptionWebElement\"]"); // @FindBy(xpath = HOME_SHARING_XPATH + COVERAGE_DESCRIPTION_XPATH)
    this.homeShariongCoveredValueWebElement = page.locator("[data-legacy-field=\"homeShariongCoveredValueWebElement\"]"); // @FindBy(xpath = HOME_SHARING_XPATH + COVERAGE_DESCRIPTION_XPATH + "//following::div[1]")
    this.youGetAllTheseWithYourHomePolicyTitle = page.locator("xpath=//app-home-policy-banner//mat-card/p[1]"); // @FindBy(xpath = "//app-home-policy-banner//mat-card/p[1]")
    this.decliningDeductiblesIcon = page.locator("[data-legacy-field=\"decliningDeductiblesIcon\"]"); // @FindBy(xpath = DEDUCTIBLES_SECTION_BASE + "//img")
    this.decliningDeductiblesTitle = page.locator("[data-legacy-field=\"decliningDeductiblesTitle\"]"); // @FindBy(xpath = DEDUCTIBLES_SECTION_BASE + "//span")
    this.decliningDeductiblesDescription = page.locator("[data-legacy-field=\"decliningDeductiblesDescription\"]"); // @FindBy(xpath = DEDUCTIBLES_SECTION_BASE + "//p[2]")
    this.claimForgivenessIcon = page.locator("[data-legacy-field=\"claimForgivenessIcon\"]"); // @FindBy(xpath = CLAIM_FORGIVENESS_SECTION_BASE + "//mat-icon")
    this.claimForgivenessTitle = page.locator("[data-legacy-field=\"claimForgivenessTitle\"]"); // @FindBy(xpath = CLAIM_FORGIVENESS_SECTION_BASE + "//div//p[1]")
    this.claimForgivenessDescription = page.locator("[data-legacy-field=\"claimForgivenessDescription\"]"); // @FindBy(xpath = CLAIM_FORGIVENESS_SECTION_BASE + "//div//p[2]")
    this.claimFreeDiscountIcon = page.locator("[data-legacy-field=\"claimFreeDiscountIcon\"]"); // @FindBy(xpath = CLAIM_FREE_SECTION_BASE + "//i")
    this.claimFreeDiscountTitle = page.locator("[data-legacy-field=\"claimFreeDiscountTitle\"]"); // @FindBy(xpath = CLAIM_FREE_SECTION_BASE + "//p[1]")
    this.claimFreeDiscountDescription = page.locator("[data-legacy-field=\"claimFreeDiscountDescription\"]"); // @FindBy(xpath = CLAIM_FREE_SECTION_BASE + "//p[2]")
    this.acvToggleButtonUnderPersonalProperty = page.locator("xpath=//button[@aria-label='ACV']"); // @FindBy(xpath = "//button[@aria-label='ACV']")
    this.rcvToggleButtonUnderPersonalProperty = page.locator("xpath=//button[@aria-label='RCV']"); // @FindBy(xpath = "//button[@aria-label='RCV']")
    this.bundlePropertyQuoteReviewPageTitle = page.locator("[data-legacy-field=\"bundlePropertyQuoteReviewPageTitle\"]"); // @FindBy(xpath = XPATH_TO_BUNDLE_PAGE_HEADER)
    this.bundlePropertyQuoteReviewPageSubtitle = page.locator("[data-legacy-field=\"bundlePropertyQuoteReviewPageSubtitle\"]"); // @FindBy(xpath = XPATH_TO_BUNDLE_PAGE_HEADER + "/following-sibling::*[contains(@class, 'tui-stacking')]")
    this.nextMorePropertyCoveragesButton = page.locator("xpath=//button[contains(text(),'Next: Review more')]"); // @FindBy(xpath = "//button[contains(text(),'Next: Review more')]")
    this.reviewMoreRentersCoveragesButton = page.locator("button[class='tui-btn tui-btn-primary home-quote-start-checkout-button']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary home-quote-start-checkout-button']")
    this.monthlyAmountText = page.locator("xpath=//div[contains(text(),'*The amount shown applies when premium is paid automatically')]"); // @FindBy(xpath = "//div[contains(text(),'*The amount shown applies when premium is paid automatically')]")
    this.monthlyAmount2Text = page.locator("xpath=//div[contains(text(),'is for insurance coverage you select')]"); // @FindBy(xpath = "//div[contains(text(),'is for insurance coverage you select')]")
    this.viewPricingLink = page.locator("xpath=//button[@id='priceAlternativeButton']"); // @FindBy(xpath = "//button[@id='priceAlternativeButton']")
  }
}
