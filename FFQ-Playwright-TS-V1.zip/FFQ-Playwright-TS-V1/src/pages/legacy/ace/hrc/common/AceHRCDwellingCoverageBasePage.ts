// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCDwellingCoverageBasePage. */
export class AceHRCDwellingCoverageBasePage extends CoreBasePage {
  public readonly dwellingCoverageHeading: Locator;
  public readonly dwellingCoverageImage: Locator;
  public readonly dwellingCoverageInfoIconDesktop: Locator;
  public readonly dwellingCoverageInfoIconMobile: Locator;
  public readonly dwellingCoverageInfoQuestionDesktop: Locator;
  public readonly dwellingCoverageInfoQuestionMobile: Locator;
  public readonly dwellingCoverageInfoTextDesktop: Locator;
  public readonly dwellingCoverageInfoTextMobile: Locator;
  public readonly dwellingCoverageLearnMoreLinkDesktop: Locator;
  public readonly dwellingCoverageLearnMoreLinkMobile: Locator;
  public readonly dwellingCoverageTitle: Locator;
  public readonly dwellingCoverageAmount: Locator;
  public readonly dwellingCoverageQualityGrade: Locator;
  public readonly dwellingCoverageDisclaimerPart1: Locator;
  public readonly dwellingCoverageDisclaimerPart2: Locator;
  public readonly editCoverageAndQualityGraderButtonLinkHomeLob: Locator;
  public readonly editCoverageAndQualityGraderButtonLink: Locator;
  public readonly matDivider: Locator;
  public readonly dwellingCoverageInfoHeaderQuestionSideSheet: Locator;
  public readonly dwellingCoverageInfoHeaderSubtextSideSheet: Locator;
  public readonly fiveQualityGradeHeaderSideSheet: Locator;
  public readonly qualityGradeTypesDiv: Locator;
  public readonly qualityGradeTypesHeaders: Locator;
  public readonly qualityGradeTypesDescriptions: Locator;
  public readonly closeIconOnLearnMoreSideSheet: Locator;
  public readonly dwellingListCloseIcon: Locator;
  public readonly dwellingCoverageAndGradeHeaderSideSheet: Locator;
  public readonly dwellingReconstructionSubHeaderSideSheet: Locator;
  public readonly dwellingReconstructionDescriptionSideSheet: Locator;
  public readonly matDividerDwellingCoverageSideSheet: Locator;
  public readonly editCoveragesAndQualityGrade: Locator;
  public readonly reconstructionCoverageAmountMatRadioButtons: Locator;
  public readonly reconstructionCoverageAmountLabel: Locator;
  public readonly reconstructionCoverageAmountInputRadioButtons: Locator;
  public readonly reconstructionCoverageAmountLabels: Locator;
  public readonly reconstructionCoverageAmountLabelsSubText: Locator;
  public readonly dottedHorizontalDivider: Locator;
  public readonly standardHomeQualityGradeTitle: Locator;
  public readonly standardHomeQualityGradeHintIcon: Locator;
  public readonly standardHomeQualityGradeSubText: Locator;
  public readonly editYourQualityGradeLink: Locator;
  public readonly agentContainerText: Locator;
  public readonly saveButtonOnDwellingCovSideSheet: Locator;
  public readonly cancelButtonOnDwellingCovSideSheet: Locator;
  public readonly backIconOnEditQualityGradeSideSheet: Locator;
  public readonly editHomeQualityGradeHeader: Locator;
  public readonly editHomeQualityGradeSolidDivider: Locator;
  public readonly editHomeQualityGradeSubHeader: Locator;
  public readonly editHomeQualityGradeSubHeaderDescription: Locator;
  public readonly homeQualityGradeMatRadioButtons: Locator;
  public readonly homeQualityGradeInputRadioButtons: Locator;
  public readonly coverageUncheckedRadioButtonLabel: Locator;
  public readonly homeQualityGradeRadioButtonDescriptions: Locator;
  public readonly homeQualityGradeRadioButtonLabels: Locator;
  public readonly homeQualityGradeDottedDivider: Locator;
  public readonly homeQualityGradeNote: Locator;
  public readonly upgradeGradeButton: Locator;
  public readonly cancelGradeButton: Locator;
  public readonly dwellingCoverageSideSheet: Locator;
  public readonly updateHomeQualityGradeModalDialog: Locator;
  public readonly updateHomeQualityGradeTitle: Locator;
  public readonly updateHomeQualityGradeActionDescription: Locator;
  public readonly keepPreviousGradeLink: Locator;
  public readonly updateGradeButtonInPopup: Locator;
  public readonly unsavedChangesModalDialogue: Locator;
  public readonly unsavedChangesModalTitle: Locator;
  public readonly changesHaveNotBeenSavedText: Locator;
  public readonly exitWithoutSavingButton: Locator;
  public readonly continueEditingLink: Locator;
  public readonly editHomeQualityGradeCloseIcon: Locator;
  public readonly continueButton: Locator;
  public readonly rc2Screen_MainHeading: Locator;
  public readonly rc2SubHeading: Locator;

  public constructor(page: Page) {
    super(page);
    this.dwellingCoverageHeading = page.locator("xpath=//div[contains(@class,'-coverage__container')]//h1"); // @FindBy(xpath = "//div[contains(@class,'-coverage__container')]//h1")
    this.dwellingCoverageImage = page.locator("xpath=//div[@class='dwelling-coverage-image']//img"); // @FindBy(xpath = "//div[@class='dwelling-coverage-image']//img")
    this.dwellingCoverageInfoIconDesktop = page.locator("xpath=//div[contains(@class,'dwelling-coverage-info')]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'dwelling-coverage-info')]//mat-icon")
    this.dwellingCoverageInfoIconMobile = page.locator("xpath=//div[contains(@class,'dwelling-coverage-main')]//mat-icon[contains(@class,'mobile-info-icon')]"); // @FindBy(xpath = "//div[contains(@class,'dwelling-coverage-main')]//mat-icon[contains(@class,'mobile-info-icon')]")
    this.dwellingCoverageInfoQuestionDesktop = page.locator("xpath=//div[contains(@class,'dwelling-coverage-info')]//p"); // @FindBy(xpath = "//div[contains(@class,'dwelling-coverage-info')]//p")
    this.dwellingCoverageInfoQuestionMobile = page.locator("xpath=//mat-dialog-container//h1"); // @FindBy(xpath = "//mat-dialog-container//h1")
    this.dwellingCoverageInfoTextDesktop = page.locator("xpath=//div[contains(@class,'dwelling-coverage-info')]//div//span[1]"); // @FindBy(xpath = "//div[contains(@class,'dwelling-coverage-info')]//div//span[1]")
    this.dwellingCoverageInfoTextMobile = page.locator("xpath=//mat-dialog-container//h1/following-sibling::p"); // @FindBy(xpath = "//mat-dialog-container//h1/following-sibling::p")
    this.dwellingCoverageLearnMoreLinkDesktop = page.locator("xpath=//div[contains(@class,'dwelling-coverage-info')]//div//span[contains(@class,'tui-link-button')]"); // @FindBy(xpath = "//div[contains(@class,'dwelling-coverage-info')]//div//span[contains(@class,'tui-link-button')]")
    this.dwellingCoverageLearnMoreLinkMobile = page.locator("xpath=//mat-dialog-container//h1/following-sibling::p/span"); // @FindBy(xpath = "//mat-dialog-container//h1/following-sibling::p/span")
    this.dwellingCoverageTitle = page.locator("xpath=//p[contains(@class,'dwelling-coverage-title')]"); // @FindBy(xpath = "//p[contains(@class,'dwelling-coverage-title')]")
    this.dwellingCoverageAmount = page.locator("xpath=//p[contains(@class,'dwelling-coverage-amount')]"); // @FindBy(xpath = "//p[contains(@class,'dwelling-coverage-amount')]")
    this.dwellingCoverageQualityGrade = page.locator("xpath=//div[@id='propertyGradeDiv']"); // @FindBy(xpath = "//div[@id='propertyGradeDiv']")
    this.dwellingCoverageDisclaimerPart1 = page.locator("xpath=//div[contains(@class,'dwelling-coverage-disclaimer')]//p[1]"); // @FindBy(xpath = "//div[contains(@class,'dwelling-coverage-disclaimer')]//p[1]")
    this.dwellingCoverageDisclaimerPart2 = page.locator("xpath=//div[contains(@class,'dwelling-coverage-disclaimer')]//p[2]"); // @FindBy(xpath = "//div[contains(@class,'dwelling-coverage-disclaimer')]//p[2]")
    this.editCoverageAndQualityGraderButtonLinkHomeLob = page.locator("xpath=//button[@id='editDetailsLink']/span/span"); // @FindBy(xpath = "//button[@id='editDetailsLink']/span/span")
    this.editCoverageAndQualityGraderButtonLink = page.locator("xpath=//button[@id='editDetailsLink']"); // @FindBy(xpath = "//button[@id='editDetailsLink']")
    this.matDivider = page.locator("xpath=//mat-divider"); // @FindBy(xpath = "//mat-divider")
    this.dwellingCoverageInfoHeaderQuestionSideSheet = page.locator("xpath=//div[@class='model-info-section']//h1"); // @FindBy(xpath = "//div[@class='model-info-section']//h1")
    this.dwellingCoverageInfoHeaderSubtextSideSheet = page.locator("xpath=//div[@class='model-info-section']//p[1]"); // @FindBy(xpath = "//div[@class='model-info-section']//p[1]")
    this.fiveQualityGradeHeaderSideSheet = page.locator("xpath=//div[@class='model-info-section']//p[2]"); // @FindBy(xpath = "//div[@class='model-info-section']//p[2]")
    this.qualityGradeTypesDiv = page.locator("xpath=//ul[contains(@class,'dwelling-types')]//li"); // @FindBy(xpath = "//ul[contains(@class,'dwelling-types')]//li")
    this.qualityGradeTypesHeaders = page.locator("xpath=//ul[contains(@class,'dwelling-types')]//span[contains(@class,'tui-field-label-text')]"); // @FindBy(xpath = "//ul[contains(@class,'dwelling-types')]//span[contains(@class,'tui-field-label-text')]")
    this.qualityGradeTypesDescriptions = page.locator("xpath=//ul[contains(@class,'dwelling-types')]//p"); // @FindBy(xpath = "//ul[contains(@class,'dwelling-types')]//p")
    this.closeIconOnLearnMoreSideSheet = page.locator("xpath=//app-model-info-box//mat-icon[contains(text(),'close')]"); // @FindBy(xpath = "//app-model-info-box//mat-icon[contains(text(),'close')]")
    this.dwellingListCloseIcon = page.locator("xpath=//mat-icon[contains(@class,'dwelling-list-heading-close')]"); // @FindBy(xpath = "//mat-icon[contains(@class,'dwelling-list-heading-close')]")
    this.dwellingCoverageAndGradeHeaderSideSheet = page.locator("xpath=//app-dwelling-coverage-list//h4"); // @FindBy(xpath = "//app-dwelling-coverage-list//h4")
    this.dwellingReconstructionSubHeaderSideSheet = page.locator("xpath=//app-dwelling-coverage-list//div[contains(@class,'coverage-subtitle')]"); // @FindBy(xpath = "//app-dwelling-coverage-list//div[contains(@class,'coverage-subtitle')]")
    this.dwellingReconstructionDescriptionSideSheet = page.locator("xpath=//app-dwelling-coverage-list//p[@id='increased-coverage-info']"); // @FindBy(xpath = "//app-dwelling-coverage-list//p[@id='increased-coverage-info']")
    this.matDividerDwellingCoverageSideSheet = page.locator("xpath=//app-dwelling-coverage-list//mat-divider"); // @FindBy(xpath = "//app-dwelling-coverage-list//mat-divider")
    this.editCoveragesAndQualityGrade = page.locator("xpath=//app-dwelling-coverages//button[contains(@class,'tui-link-button')]"); // @FindBy(xpath = "//app-dwelling-coverages//button[contains(@class,'tui-link-button')]")
    this.reconstructionCoverageAmountMatRadioButtons = page.locator("xpath=//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button"); // @FindBy(xpath = "//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button")
    this.reconstructionCoverageAmountLabel = page.locator("xpath=//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button//label"); // @FindBy(xpath = "//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button//label")
    this.reconstructionCoverageAmountInputRadioButtons = page.locator("xpath=//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button//input"); // @FindBy(xpath = "//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button//input")
    this.reconstructionCoverageAmountLabels = page.locator("xpath=//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button//label//p[contains(@class,'tui-body-text-bold')]"); // @FindBy(xpath = "//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button//label//p[contains(@class,'tui-body-text-bold')]")
    this.reconstructionCoverageAmountLabelsSubText = page.locator("xpath=//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button//label//p[2]"); // @FindBy(xpath = "//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button//label//p[2]")
    this.dottedHorizontalDivider = page.locator("xpath=//hr"); // @FindBy(xpath = "//hr")
    this.standardHomeQualityGradeTitle = page.locator("xpath=//div[@class='subsection-heading']//div"); // @FindBy(xpath = "//div[@class='subsection-heading']//div")
    this.standardHomeQualityGradeHintIcon = page.locator("xpath=//div[@class='subsection-heading']//mat-icon"); // @FindBy(xpath = "//div[@class='subsection-heading']//mat-icon")
    this.standardHomeQualityGradeSubText = page.locator("xpath=//div[@class='coverage-body']//span[1]"); // @FindBy(xpath = "//div[@class='coverage-body']//span[1]")
    this.editYourQualityGradeLink = page.locator("xpath=//span[@class='edit-link']"); // @FindBy(xpath = "//span[@class='edit-link']")
    this.agentContainerText = page.locator("xpath=//div[contains(@class,'dwelling-disclaimer-text')]//p"); // @FindBy(xpath = "//div[contains(@class,'dwelling-disclaimer-text')]//p")
    this.saveButtonOnDwellingCovSideSheet = page.locator("xpath=//div[contains(@class,'dwelling-submit-section')]//button[contains(text(),'Save')]"); // @FindBy(xpath = "//div[contains(@class,'dwelling-submit-section')]//button[contains(text(),'Save')]")
    this.cancelButtonOnDwellingCovSideSheet = page.locator("xpath=//div[contains(@class,'dwelling-submit-section')]//button[contains(text(),'Cancel')]"); // @FindBy(xpath = "//div[contains(@class,'dwelling-submit-section')]//button[contains(text(),'Cancel')]")
    this.backIconOnEditQualityGradeSideSheet = page.locator("xpath=//mat-icon[contains(@class,'edit-quality-grade-back__button')]"); // @FindBy(xpath = "//mat-icon[contains(@class,'edit-quality-grade-back__button')]")
    this.editHomeQualityGradeHeader = page.locator("xpath=//div[contains(@class,'edit-grade-heading-section')]//h4"); // @FindBy(xpath = "//div[contains(@class,'edit-grade-heading-section')]//h4")
    this.editHomeQualityGradeSolidDivider = page.locator("xpath=//div[contains(@class,'edit-grade-heading-section')]//mat-divider"); // @FindBy(xpath = "//div[contains(@class,'edit-grade-heading-section')]//mat-divider")
    this.editHomeQualityGradeSubHeader = page.locator("xpath=//div[contains(text(),'Home quality grade')]"); // @FindBy(xpath = "//div[contains(text(),'Home quality grade')]")
    this.editHomeQualityGradeSubHeaderDescription = page.locator("xpath=//p[contains(@class,'tui-field-label')]"); // @FindBy(xpath = "//p[contains(@class,'tui-field-label')]")
    this.homeQualityGradeMatRadioButtons = page.locator("[data-legacy-field=\"homeQualityGradeMatRadioButtons\"]"); // @FindBy(xpath = COVERAGE_RADIO_BUTTON_XPATH)
    this.homeQualityGradeInputRadioButtons = page.locator("[data-legacy-field=\"homeQualityGradeInputRadioButtons\"]"); // @FindBy(xpath = COVERAGE_RADIO_BUTTON_XPATH + "//input")
    this.coverageUncheckedRadioButtonLabel = page.locator("[data-legacy-field=\"coverageUncheckedRadioButtonLabel\"]"); // @FindBy(xpath = COVERAGE_RADIO_BUTTON_XPATH + "[not(contains(@class,'radio-checked'))]//label")
    this.homeQualityGradeRadioButtonDescriptions = page.locator("xpath=//span[contains(@class,'grade-option-subtext')]"); // @FindBy(xpath = "//span[contains(@class,'grade-option-subtext')]")
    this.homeQualityGradeRadioButtonLabels = page.locator("[data-legacy-field=\"homeQualityGradeRadioButtonLabels\"]"); // @FindBy(xpath = COVERAGE_RADIO_BUTTON_XPATH + "//span[contains(@class,'mat-radio-label-content')]")
    this.homeQualityGradeDottedDivider = page.locator("xpath=//mat-divider[contains(@class,'quality-grade-note-divider')]"); // @FindBy(xpath = "//mat-divider[contains(@class,'quality-grade-note-divider')]")
    this.homeQualityGradeNote = page.locator("xpath=//p[contains(@class,'quality-grade-note')]"); // @FindBy(xpath = "//p[contains(@class,'quality-grade-note')]")
    this.upgradeGradeButton = page.locator("xpath=//div[contains(@class,'edit-grade-update-section')]//button"); // @FindBy(xpath = "//div[contains(@class,'edit-grade-update-section')]//button")
    this.cancelGradeButton = page.locator("xpath=//div[contains(@class,'edit-grade-update-section')]//a"); // @FindBy(xpath = "//div[contains(@class,'edit-grade-update-section')]//a")
    this.dwellingCoverageSideSheet = page.locator("xpath=//app-dwelling-coverage-list"); // @FindBy(xpath = "//app-dwelling-coverage-list")
    this.updateHomeQualityGradeModalDialog = page.locator("xpath=//mat-dialog-container"); // @FindBy(xpath = "//mat-dialog-container")
    this.updateHomeQualityGradeTitle = page.locator("xpath=//span[contains(@class,'quality-grade-pop-up-title')]"); // @FindBy(xpath = "//span[contains(@class,'quality-grade-pop-up-title')]")
    this.updateHomeQualityGradeActionDescription = page.locator("xpath=//mat-dialog-content//span"); // @FindBy(xpath = "//mat-dialog-content//span")
    this.keepPreviousGradeLink = page.locator("xpath=//mat-dialog-container//mat-dialog-actions//button[2]"); // @FindBy(xpath = "//mat-dialog-container//mat-dialog-actions//button[2]")
    this.updateGradeButtonInPopup = page.locator("xpath=//mat-dialog-container//mat-dialog-actions//button[1]"); // @FindBy(xpath = "//mat-dialog-container//mat-dialog-actions//button[1]")
    this.unsavedChangesModalDialogue = page.locator("xpath=//mat-dialog-container[@aria-labelledby='unsavedChanges']"); // @FindBy(xpath = "//mat-dialog-container[@aria-labelledby='unsavedChanges']")
    this.unsavedChangesModalTitle = page.locator("xpath=//span[contains(@class,'unsaved-changes-modal-title')]"); // @FindBy(xpath = "//span[contains(@class,'unsaved-changes-modal-title')]")
    this.changesHaveNotBeenSavedText = page.locator("xpath=//span[contains(text(),'Changes that you made have not been saved yet.')]"); // @FindBy(xpath = "//span[contains(text(),'Changes that you made have not been saved yet.')]")
    this.exitWithoutSavingButton = page.locator("xpath=//button[@data-test-id='UNSAVED_CHANGES_EXIT_WITHOUT_SAVING_BUTTON']"); // @FindBy(xpath = "//button[@data-test-id='UNSAVED_CHANGES_EXIT_WITHOUT_SAVING_BUTTON']")
    this.continueEditingLink = page.locator("xpath=//button[@data-test-id='UNSAVED_CHANGES_NO_CONTINUE_EDITING_BUTTON']"); // @FindBy(xpath = "//button[@data-test-id='UNSAVED_CHANGES_NO_CONTINUE_EDITING_BUTTON']")
    this.editHomeQualityGradeCloseIcon = page.locator("xpath=//mat-icon[contains(@class,'edit-quality-grade-heading-close')]"); // @FindBy(xpath = "//mat-icon[contains(@class,'edit-quality-grade-heading-close')]")
    this.continueButton = page.locator("xpath=//button[@id='continueButton']"); // @FindBy(xpath = "//button[@id='continueButton']")
    this.rc2Screen_MainHeading = page.locator("xpath=//app-home-condo-renter-rc2-loader/h1"); // @FindBy(xpath = "//app-home-condo-renter-rc2-loader/h1")
    this.rc2SubHeading = page.locator("xpath=//app-home-condo-renter-rc2-loader//div[@class='tui-input-text']"); // @FindBy(xpath = "//app-home-condo-renter-rc2-loader//div[@class='tui-input-text']")
  }
}
