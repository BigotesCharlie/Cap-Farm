// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCAddressContactBasePage. */
export class AceHRCAddressContactBasePage extends CoreBasePage {
  public readonly addressPageTitle: Locator;
  public readonly addressSubtitle: Locator;
  public readonly formFieldAddressInput: Locator;
  public readonly addressFieldCrossIcon: Locator;
  public readonly formFieldUnitInput: Locator;
  public readonly formFieldCityInput: Locator;
  public readonly formFieldZipCodeInput: Locator;
  public readonly contactInfoLabel: Locator;
  public readonly formFieldEmailInput: Locator;
  public readonly emailAddressFieldLabel: Locator;
  public readonly emailAddressError: Locator;
  public readonly formFieldPhoneNumberInput: Locator;
  public readonly mobilePhoneFieldLabel: Locator;
  public readonly phoneNumberError: Locator;
  public readonly agreeAndSubmitButton: Locator;
  public readonly electronicSignHeader: Locator;
  public readonly ourCompaniesHeader: Locator;
  public readonly pageFooterSectionSubtitle: Locator;
  public readonly pageFooterDisclaimer: Locator;
  public readonly linkDisclaimerEsign: Locator;
  public readonly linkAssociatedEntities: Locator;

  public constructor(page: Page) {
    super(page);
    this.addressPageTitle = page.locator("xpath=//app-personal-info//div[contains(@class,'personal-info_address_h1')]//h1"); // @FindBy(xpath = "//app-personal-info//div[contains(@class,'personal-info_address_h1')]//h1")
    this.addressSubtitle = page.locator("xpath=//app-personal-info//div[@id='auto-personal-info_address-subheading']"); // @FindBy(xpath = "//app-personal-info//div[@id='auto-personal-info_address-subheading']")
    this.formFieldAddressInput = page.locator("[data-legacy-field=\"formFieldAddressInput\"]"); // @FindBy(xpath = ADDRESS_INPUT_FIELD_XPATH)
    this.addressFieldCrossIcon = page.locator("xpath=//app-personal-info//mat-form-field[@id='auto-manual-address-street__input-field']//mat-icon[contains(text(),'close')]"); // @FindBy(xpath = "//app-personal-info//mat-form-field[@id='auto-manual-address-street__input-field']//mat-icon[contains(text(),'close')]")
    this.formFieldUnitInput = page.locator("xpath=//app-personal-info//div[@id='formField_apartment']//input"); // @FindBy(xpath = "//app-personal-info//div[@id='formField_apartment']//input")
    this.formFieldCityInput = page.locator("xpath=//app-personal-info//div[@id='formField_city']//input"); // @FindBy(xpath = "//app-personal-info//div[@id='formField_city']//input")
    this.formFieldZipCodeInput = page.locator("xpath=//app-personal-info//div[@id='formField_zipCode']//input"); // @FindBy(xpath = "//app-personal-info//div[@id='formField_zipCode']//input")
    this.contactInfoLabel = page.locator("xpath=//app-personal-info//h2[@id='contact-info-heading']"); // @FindBy(xpath = "//app-personal-info//h2[@id='contact-info-heading']")
    this.formFieldEmailInput = page.locator("[data-legacy-field=\"formFieldEmailInput\"]"); // @FindBy(xpath = EMAIL_ADDRESS_XPATH)
    this.emailAddressFieldLabel = page.locator("xpath=//app-personal-info//label[contains(@for,'email')]"); // @FindBy(xpath = "//app-personal-info//label[contains(@for,'email')]")
    this.emailAddressError = page.locator("xpath=//div[contains(@class,'email-address')]//mat-error"); // @FindBy(xpath = "//div[contains(@class,'email-address')]//mat-error")
    this.formFieldPhoneNumberInput = page.locator("xpath=//app-personal-info//input[@name='phone_number']"); // @FindBy(xpath = "//app-personal-info//input[@name='phone_number']")
    this.mobilePhoneFieldLabel = page.locator("xpath=//app-personal-info//label[contains(@for,'phoneNumber')]"); // @FindBy(xpath = "//app-personal-info//label[contains(@for,'phoneNumber')]")
    this.phoneNumberError = page.locator("xpath=//div[contains(@class,'phone-number')]//mat-error"); // @FindBy(xpath = "//div[contains(@class,'phone-number')]//mat-error")
    this.agreeAndSubmitButton = page.locator("xpath=//app-personal-info//button[text()='Agree and submit']"); // @FindBy(xpath = "//app-personal-info//button[text()='Agree and submit']")
    this.electronicSignHeader = page.locator("xpath=//h1"); // @FindBy(xpath = "//h1")
    this.ourCompaniesHeader = page.locator("xpath=//span[@class='h1']"); // @FindBy(xpath = "//span[@class='h1']")
    this.pageFooterSectionSubtitle = page.locator("xpath=//app-personal-info//button[text()='Agree and submit']/ancestor::div/p[contains(@class,'tui-body-text-1')]"); // @FindBy(xpath = "//app-personal-info//button[text()='Agree and submit']/ancestor::div/p[contains(@class,'tui-body-text-1')]")
    this.pageFooterDisclaimer = page.locator("xpath=//div[contains(@class,'tui-stacking-top-md')]"); // @FindBy(xpath = "//div[contains(@class,'tui-stacking-top-md')]")
    this.linkDisclaimerEsign = page.getByRole('link', { name: "ESIGN terms and conditions", exact: true }); // @FindBy(linkText = "ESIGN terms and conditions")
    this.linkAssociatedEntities = page.getByRole('link', { name: "associated entities", exact: true }); // @FindBy(linkText = "associated entities")
  }
}
