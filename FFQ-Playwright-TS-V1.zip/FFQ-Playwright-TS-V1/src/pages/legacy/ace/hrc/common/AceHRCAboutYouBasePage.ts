// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCAboutYouBasePage. */
export class AceHRCAboutYouBasePage extends CoreBasePage {
  public readonly genderButtons: Locator;
  public readonly genderButton: Locator;
  public readonly spouseGenderButtons: Locator;
  public readonly aboutYouHeader: Locator;
  public readonly letsGetToKnowEachOtherSubHeader: Locator;
  public readonly firstNameInputBox: Locator;
  public readonly firstNameAriaLabelText: Locator;
  public readonly lastNameInputBox: Locator;
  public readonly lastNameAriaLabelText: Locator;
  public readonly dateOfBirthInputBox: Locator;
  public readonly dateOfBirthAriaLabelText: Locator;
  public readonly mmddyyyyHint: Locator;
  public readonly spouseInputFieldSection: Locator;
  public readonly spouseElements: Locator;
  public readonly spouseFirstNameInputBox: Locator;
  public readonly spouseLastNameInputBox: Locator;
  public readonly spouseDateOfBirthInputBox: Locator;
  public readonly marriedOrInDomesticRelationMatCheckbox: Locator;
  public readonly marriedOrInDomesticRelationCheckboxInput: Locator;
  public readonly marriedOrInDomesticRelationCheckBoxDescription: Locator;
  public readonly marriedOrInDomesticRelationLabel: Locator;
  public readonly requiredOrIncompleteErrorMessage: Locator;
  public readonly currentFormerEmployedHeaderPersonalInfoDiv: Locator;
  public readonly currentFormerEmployedHeaderSpouseDiv: Locator;
  public readonly eligibleOccupationSavingsPersonalInfoDiv: Locator;
  public readonly eligibleOccupationSavingsSpouseDiv: Locator;
  public readonly eligibleOccupationButtonPersonalInfoDiv: Locator;
  public readonly eligibleOccupationButtonSpouseDiv: Locator;
  public readonly eligibleOccupationHeader: Locator;
  public readonly occupationRadioButtons: Locator;
  public readonly firstOccupationRadioButton: Locator;
  public readonly currentlyEmployedOrRetiredQuestion: Locator;
  public readonly currentlyEmployedOrRetiredToggleButtons: Locator;
  public readonly currentlyEmployedOrRetiredToggleButton: Locator;
  public readonly currentlyEmployedOrRetiredToggleButtonLabel: Locator;
  public readonly closeIcon: Locator;
  public readonly closeButton: Locator;
  public readonly occupationRetiredCheckBox: Locator;
  public readonly retiredFormerlyEmployedLabel: Locator;
  public readonly eligibleOccupationAddButton: Locator;
  public readonly eligibleOccupationCancelButton: Locator;
  public readonly removeOccupationLinkPrimaryApplicant: Locator;
  public readonly removeOccupationLinkSpouse: Locator;
  public readonly removeOccupationHeaderInModalBox: Locator;
  public readonly keepOccupationButton: Locator;
  public readonly removeOccupationButton: Locator;
  public readonly removeOccupationQuestion: Locator;
  public readonly homeOccupationSelectedMessagePersonalInfo: Locator;
  public readonly homeOccupationSelectedMessageSpouseDiv: Locator;
  public readonly occupationPrimary: Locator;
  public readonly occupationSpouse: Locator;
  public readonly priorOrCurrentHomeAddressLabel: Locator;
  public readonly currentAddressPlaceHolderText: Locator;
  public readonly priorAddressPlaceHolderText: Locator;
  public readonly priorOrCurrentAddressInputBox: Locator;
  public readonly priorOrCurrentAddressCityInputBox: Locator;
  public readonly priorOrCurrentAddressStateSelect: Locator;
  public readonly priorOrCurrentAddressZipInputBox: Locator;
  public readonly closeIconInAddressInputBox: Locator;
  public readonly unitInputBox: Locator;
  public readonly unitNumberPlaceholderText: Locator;
  public readonly cityPlaceholderText: Locator;
  public readonly statePlaceholderText: Locator;
  public readonly zipPlaceholderText: Locator;
  public readonly optionalUnitNumberHint: Locator;
  public readonly pleaseEnterYourStreetNumberAndNameError: Locator;
  public readonly pleaseProvideYourCityError: Locator;
  public readonly pleaseProvideYourStateError: Locator;
  public readonly pleaseProvideYourZipError: Locator;
  public readonly invalidInputZipError: Locator;
  public readonly invalidInputAddressError: Locator;
  public readonly pleaseSelectAddressFromListError: Locator;
  public readonly selectAddressFromListError: Locator;
  public readonly unitNumberNotValidEntryError: Locator;
  public readonly continueButton: Locator;
  public readonly selectedOccupation: Locator;
  public readonly emailAddressInput: Locator;
  public readonly phoneNumberInput: Locator;

  public constructor(page: Page) {
    super(page);
    this.genderButtons = page.locator("[data-legacy-field=\"genderButtons\"]"); // @FindBy(xpath = GENDER_SELECTION_XPATH)
    this.genderButton = page.locator("[data-legacy-field=\"genderButton\"]"); // @FindBy(xpath = GENDER_SELECTION_XPATH)
    this.spouseGenderButtons = page.locator("[data-legacy-field=\"spouseGenderButtons\"]"); // @FindBy(xpath = SPOUSE_GENDER_SELECTION_XPATH)
    this.aboutYouHeader = page.locator("xpath=//h1[contains(text(), '"); // @FindBy(xpath = "//h1[contains(text(), '" + ABOUT_YOU_HEADER + "')]")
    this.letsGetToKnowEachOtherSubHeader = page.locator("xpath=//div[@id='home-about-you_name_dob-subheading']"); // @FindBy(xpath = "//div[@id='home-about-you_name_dob-subheading']")
    this.firstNameInputBox = page.locator("xpath=//input[@aria-label='"); // @FindBy(xpath = "//input[@aria-label='" + FIRST_NAME + "']")
    this.firstNameAriaLabelText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + FIRST_NAME + "')]")
    this.lastNameInputBox = page.locator("xpath=//input[@aria-label='"); // @FindBy(xpath = "//input[@aria-label='" + LAST_NAME + "']")
    this.lastNameAriaLabelText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + LAST_NAME + "')]")
    this.dateOfBirthInputBox = page.locator("xpath=//input[@aria-label='"); // @FindBy(xpath = "//input[@aria-label='" + DATE_OF_BIRTH_ARIA_LABEL_INPUT_BOX + "']")
    this.dateOfBirthAriaLabelText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + DATE_OF_BIRTH_ARIA_LABEL + "')]")
    this.mmddyyyyHint = page.locator("xpath=//mat-hint[contains(text(), 'mm/dd/yyyy')]"); // @FindBy(xpath = "//mat-hint[contains(text(), 'mm/dd/yyyy')]")
    this.spouseInputFieldSection = page.locator("xpath=//div[@id='spouseDetailsDiv']//div[contains(@class,'home-about-you__input-fields')]"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//div[contains(@class,'home-about-you__input-fields')]")
    this.spouseElements = page.locator("xpath=//div[@id='spouseDetailsDiv']//mat-form-field//input"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//mat-form-field//input")
    this.spouseFirstNameInputBox = page.locator("xpath=//input[@aria-label=\"Spouse's First name\"]"); // @FindBy(xpath = "//input[@aria-label=\"Spouse's First name\"]")
    this.spouseLastNameInputBox = page.locator("xpath=//input[@aria-label=\"Spouse's Last name\"]"); // @FindBy(xpath = "//input[@aria-label=\"Spouse's Last name\"]")
    this.spouseDateOfBirthInputBox = page.locator("xpath=//input[@aria-label=\"Spouse's Date Of birth\"]"); // @FindBy(xpath = "//input[@aria-label=\"Spouse's Date Of birth\"]")
    this.marriedOrInDomesticRelationMatCheckbox = page.locator("xpath=//div[contains(@class,'isMarried')]//mat-checkbox"); // @FindBy(xpath = "//div[contains(@class,'isMarried')]//mat-checkbox")
    this.marriedOrInDomesticRelationCheckboxInput = page.locator("xpath=//div[contains(@class,'isMarried')]//input[@type='checkbox']"); // @FindBy(xpath = "//div[contains(@class,'isMarried')]//input[@type='checkbox']")
    this.marriedOrInDomesticRelationCheckBoxDescription = page.locator("xpath=//p[contains(@class, 'spouse__checkbox-description')]"); // @FindBy(xpath = "//p[contains(@class, 'spouse__checkbox-description')]")
    this.marriedOrInDomesticRelationLabel = page.locator("xpath=//span[contains(text(), '"); // @FindBy(xpath = "//span[contains(text(), '" + MARRIED_DOMESTIC_RELATIONSHIP_LABEL + "')]")
    this.requiredOrIncompleteErrorMessage = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + REQUIRED_OR_INCOMPLETE_FIELD_ERROR_MESSAGE + "')]")
    this.currentFormerEmployedHeaderPersonalInfoDiv = page.locator("xpath=//div[@id='occupationDiv']//p[contains(text(), '"); // @FindBy(xpath = "//div[@id='occupationDiv']//p[contains(text(), '" + CURRENT_FORMER_EMPLOYED_PROFESSIONAL + "')]")
    this.currentFormerEmployedHeaderSpouseDiv = page.locator("xpath=//div[@id='spouseDetailsDiv']//p[contains(text(), '"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//p[contains(text(), '" + CURRENT_FORMER_EMPLOYED_PROFESSIONAL + "')]")
    this.eligibleOccupationSavingsPersonalInfoDiv = page.locator("xpath=//div[@id='occupationDiv']//p[contains(text(), '"); // @FindBy(xpath = "//div[@id='occupationDiv']//p[contains(text(), '" + ELIGIBLE_ADDITIONAL_SAVINGS + "')]")
    this.eligibleOccupationSavingsSpouseDiv = page.locator("xpath=//div[@id='spouseDetailsDiv']//p[contains(text(), '"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//p[contains(text(), '" + ELIGIBLE_ADDITIONAL_SAVINGS + "')]")
    this.eligibleOccupationButtonPersonalInfoDiv = page.locator("xpath=//button[@id='primaryOccupation']"); // @FindBy(xpath = "//button[@id='primaryOccupation']")
    this.eligibleOccupationButtonSpouseDiv = page.locator("xpath=//button[@id='spouseOccupation']"); // @FindBy(xpath = "//button[@id='spouseOccupation']")
    this.eligibleOccupationHeader = page.locator("xpath=//h1[contains(text(), '"); // @FindBy(xpath = "//h1[contains(text(), '" + ELIGIBLE_OCCUPATION_HEADER + "')]")
    this.occupationRadioButtons = page.locator("[data-legacy-field=\"occupationRadioButtons\"]"); // @FindBy(xpath = OCCUPATIONS_RADIO_BUTTONS_XPATH)
    this.firstOccupationRadioButton = page.locator("[data-legacy-field=\"firstOccupationRadioButton\"]"); // @FindBy(xpath = OCCUPATIONS_RADIO_BUTTONS_XPATH)
    this.currentlyEmployedOrRetiredQuestion = page.locator("xpath=//div[contains(@class,'col occupation-retired-checkbox-col')]//p"); // @FindBy(xpath = "//div[contains(@class,'col occupation-retired-checkbox-col')]//p")
    this.currentlyEmployedOrRetiredToggleButtons = page.locator("[data-legacy-field=\"currentlyEmployedOrRetiredToggleButtons\"]"); // @FindBy(xpath = EMPLOYED_OR_RETIRED_TOGGLE_BUTTONS_XPATH)
    this.currentlyEmployedOrRetiredToggleButton = page.locator("[data-legacy-field=\"currentlyEmployedOrRetiredToggleButton\"]"); // @FindBy(xpath = EMPLOYED_OR_RETIRED_TOGGLE_BUTTONS_XPATH)
    this.currentlyEmployedOrRetiredToggleButtonLabel = page.locator("xpath=//div[contains(@class,'col occupation-retired-checkbox-col')]//mat-button-toggle-group//mat-button-toggle//button//span"); // @FindBy(xpath = "//div[contains(@class,'col occupation-retired-checkbox-col')]//mat-button-toggle-group//mat-button-toggle//button//span")
    this.closeIcon = page.locator("xpath=//app-occupation-list//mat-icon[contains(text(), 'close')]"); // @FindBy(xpath = "//app-occupation-list//mat-icon[contains(text(), 'close')]")
    this.closeButton = page.locator("xpath=//app-occupation-list//button[contains(text(), 'Close')]"); // @FindBy(xpath = "//app-occupation-list//button[contains(text(), 'Close')]")
    this.occupationRetiredCheckBox = page.locator("xpath=//div[contains(@class,'occupation-retired-checkbox')]//mat-checkbox"); // @FindBy(xpath = "//div[contains(@class,'occupation-retired-checkbox')]//mat-checkbox")
    this.retiredFormerlyEmployedLabel = page.locator("xpath=//span[contains(text(), '"); // @FindBy(xpath = "//span[contains(text(), '" + RETIRED_FORMALLY_EMPLOYED_LABEL + "')]")
    this.eligibleOccupationAddButton = page.locator("xpath=//button[contains(text(), 'Add')]"); // @FindBy(xpath = "//button[contains(text(), 'Add')]")
    this.eligibleOccupationCancelButton = page.locator("xpath=//mat-dialog-actions//button[contains(text(), 'Cancel')]"); // @FindBy(xpath = "//mat-dialog-actions//button[contains(text(), 'Cancel')]")
    this.removeOccupationLinkPrimaryApplicant = page.locator("xpath=//div[@id='occupationDiv']//a"); // @FindBy(xpath = "//div[@id='occupationDiv']//a")
    this.removeOccupationLinkSpouse = page.locator("xpath=//div[@id='spouseDetailsDiv']//a"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//a")
    this.removeOccupationHeaderInModalBox = page.locator("xpath=//app-remove-occupation//h1[contains(text(), '"); // @FindBy(xpath = "//app-remove-occupation//h1[contains(text(), '" + REMOVE_OCCUPATION_HEADER_IN_MODAL + "')]")
    this.keepOccupationButton = page.locator("xpath=//button[contains(text(), 'Keep occupation')]"); // @FindBy(xpath = "//button[contains(text(), 'Keep occupation')]")
    this.removeOccupationButton = page.locator("xpath=//button[contains(text(), 'Remove')]"); // @FindBy(xpath = "//button[contains(text(), 'Remove')]")
    this.removeOccupationQuestion = page.locator("xpath=//mat-dialog-content[contains(text(), '"); // @FindBy(xpath = "//mat-dialog-content[contains(text(), '" + REMOVE_OCCUPATION_QUESTION + "')]")
    this.homeOccupationSelectedMessagePersonalInfo = page.locator("xpath=//div[contains(@class,'home-occupation-selected-message')]"); // @FindBy(xpath = "//div[contains(@class,'home-occupation-selected-message')]")
    this.homeOccupationSelectedMessageSpouseDiv = page.locator("xpath=//div[@id='spouseDetailsDiv']//div[contains(@class,'home-occupation-selected-message')]"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//div[contains(@class,'home-occupation-selected-message')]")
    this.occupationPrimary = page.locator("xpath=//div[@id='occupationDiv']//div[contains(@class,'home-occupation-selected-message')]"); // @FindBy(xpath = "//div[@id='occupationDiv']//div[contains(@class,'home-occupation-selected-message')]")
    this.occupationSpouse = page.locator("xpath=//div[@id='spouseDetailsDiv']//div[contains(@class,'home-occupation-selected-message')]"); // @FindBy(xpath = "//div[@id='spouseDetailsDiv']//div[contains(@class,'home-occupation-selected-message')]")
    this.priorOrCurrentHomeAddressLabel = page.locator("xpath=//div[@id='priorCurrentAddress']//div//p"); // @FindBy(xpath = "//div[@id='priorCurrentAddress']//div//p")
    this.currentAddressPlaceHolderText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + CURRENT_ADDRESS_PLACEHOLDER_TEXT + "')]")
    this.priorAddressPlaceHolderText = page.locator("xpath=//mat-label[contains(text(), '"); // @FindBy(xpath = "//mat-label[contains(text(), '" + PRIOR_ADDRESS_PLACEHOLDER_TEXT + "')]")
    this.priorOrCurrentAddressInputBox = page.locator("xpath=//address-autocomplete-input//input"); // @FindBy(xpath = "//address-autocomplete-input//input")
    this.priorOrCurrentAddressCityInputBox = page.locator("xpath=//mat-form-field[@id='auto-contact-info-city__input-field']//input"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-info-city__input-field']//input")
    this.priorOrCurrentAddressStateSelect = page.locator("xpath=//mat-form-field[@id='state']//mat-select"); // @FindBy(xpath = "//mat-form-field[@id='state']//mat-select")
    this.priorOrCurrentAddressZipInputBox = page.locator("xpath=//mat-form-field[@id='auto-contact-info-zipCode__input-field']//input"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-info-zipCode__input-field']//input")
    this.closeIconInAddressInputBox = page.locator("xpath=//address-autocomplete-input//mat-icon"); // @FindBy(xpath = "//address-autocomplete-input//mat-icon")
    this.unitInputBox = page.locator("xpath=//mat-form-field[@name='home-personal-info-apartment__input-field']//input"); // @FindBy(xpath = "//mat-form-field[@name='home-personal-info-apartment__input-field']//input")
    this.unitNumberPlaceholderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + UNIT_NUMBER_PLACEHOLDER_TEXT + "')]")
    this.cityPlaceholderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + CITY_PLACEHOLDER_TEXT + "')]")
    this.statePlaceholderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + STATE_PLACEHOLDER_TEXT + "')]")
    this.zipPlaceholderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + ZIP_PLACEHOLDER_TEXT + "')]")
    this.optionalUnitNumberHint = page.locator("xpath=//mat-hint[contains(text(),'"); // @FindBy(xpath = "//mat-hint[contains(text(),'" + OPTIONAL_UNIT_NUMBER_HINT + "')]")
    this.pleaseEnterYourStreetNumberAndNameError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_ENTER_STREET_NUMBER_AND_NAME + "')]")
    this.pleaseProvideYourCityError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_PROVIDE_YOUR_CITY_ERROR + "')]")
    this.pleaseProvideYourStateError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_PROVIDE_YOUR_STATE_ERROR + "')]")
    this.pleaseProvideYourZipError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_PROVIDE_YOUR_ZIP_ERROR + "')]")
    this.invalidInputZipError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_PROVIDE_FIVE_DIGIT_ZIP_ERROR + "')]")
    this.invalidInputAddressError = page.locator("xpath=//address-autocomplete-input[@id='prior-address-autocomplete']//mat-error"); // @FindBy(xpath = "//address-autocomplete-input[@id='prior-address-autocomplete']//mat-error")
    this.pleaseSelectAddressFromListError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_SELECT_ADDRESS_FROM_LIST_ERROR + "')]")
    this.selectAddressFromListError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + SELECT_ADDRESS_FROM_LIST_ERROR + "')]")
    this.unitNumberNotValidEntryError = page.locator("xpath=//mat-form-field[@name='home-personal-info-apartment__input-field']//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-form-field[@name='home-personal-info-apartment__input-field']//mat-error[contains(text(),'" + INVALID_ENTRY + "')]")
    this.continueButton = page.locator("xpath=//button[contains(text(), '"); // @FindBy(xpath = "//button[contains(text(), '" + CONTINUE_BUTTON + "')]")
    this.selectedOccupation = page.locator("xpath=//div[contains(@class,'home-occupation-selected')]"); // @FindBy(xpath = "//div[contains(@class,'home-occupation-selected')]")
    this.emailAddressInput = page.locator("xpath=//mat-form-field//input[@id='contact-details-emailAddress-input_email']"); // @FindBy(xpath = "//mat-form-field//input[@id='contact-details-emailAddress-input_email']")
    this.phoneNumberInput = page.locator("xpath=//mat-form-field//input[@id='contact-details-phoneNumber-input_Field']"); // @FindBy(xpath = "//mat-form-field//input[@id='contact-details-phoneNumber-input_Field']")
  }
}
