// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage. */
export class AceHRCPaymentBasePage extends CoreBasePage {
  public readonly policyPaymentHeader: Locator;
  public readonly twelveTermPriceSubHeader: Locator;
  public readonly twelveMonthTermPaymentLabel: Locator;
  public readonly dueTodayAmountWebElement: Locator;
  public readonly dueTodayAmountWithAmountToBeBilledWebElement: Locator;
  public readonly feesLabelModal: Locator;
  public readonly oneTimeFeesOrExpenseConstantLabel: Locator;
  public readonly feesLabel: Locator;
  public readonly oneTimeFeesOrExpenseConstantAmount: Locator;
  public readonly feesAmount: Locator;
  public readonly taxesAndSurchargesAmountPayInFull: Locator;
  public readonly taxesAndSurchargesLabelPayInFull: Locator;
  public readonly taxesAndSurchargesLabelMonthlyPay: Locator;
  public readonly taxesAndSurchargesAmountMonthlyPay: Locator;
  public readonly policyFeesDescriptionDesktop: Locator;
  public readonly policyFeesDescriptionMobile: Locator;
  public readonly expenseConstantDescriptionMobile: Locator;
  public readonly memberShipFeesDescriptionDesktop: Locator;
  public readonly memberShipFeesDescriptionCODesktop: Locator;
  public readonly memberShipFeesDescriptionMobile: Locator;
  public readonly expenseConstantDescriptionDesktop: Locator;
  public readonly monthlyAutoPayBankHeader: Locator;
  public readonly monthlyAutoPayCardHeader: Locator;
  public readonly billedToMortgageeHeader: Locator;
  public readonly newPolicyHeader: Locator;
  public readonly amountToBeBilledLabel: Locator;
  public readonly authorizeAllPaymentsByYourLenderHeader: Locator;
  public readonly yourPaymentIncludedInMortgageText: Locator;
  public readonly paperlessBillingNotApplicableForLenderBulletPoint: Locator;
  public readonly futurePaymentsHeader: Locator;
  public readonly mortgageCompanyWillStartPayingAfterFirstYearText: Locator;
  public readonly contactAgentOrFarmersDirectSalesParagraphDisclaimers: Locator;
  public readonly bankPaymentServiceChargeText: Locator;
  public readonly feesInfoIconMobile: Locator;
  public readonly feesInfoDialogCloseButton: Locator;
  public readonly paymentMethodAddedText: Locator;
  public readonly changeLink: Locator;
  public readonly debitCreditCardToggleButton: Locator;
  public readonly bankToggleButton: Locator;
  public readonly useSamePaymentMethodQuestion: Locator;
  public readonly paymentDialogConfirmation: Locator;
  public readonly savedAutoPolicyPaymentMethodLabel: Locator;
  public readonly savedAutoPolicyPaymentCardSymbol: Locator;
  public readonly savedAutoPolicyPaymentBankSymbol: Locator;
  public readonly savedAutoPolicyPaymentBankAccountNumber: Locator;
  public readonly savedAutoPolicyPaymentDetails: Locator;
  public readonly sameButton: Locator;
  public readonly differentButton: Locator;
  public readonly closeIconSamePaymentMethodModal: Locator;
  public readonly reusePaymentPopUp: Locator;
  public readonly paymentSideSheet: Locator;
  public readonly linkChangeCoverageOptions: Locator;

  public constructor(page: Page) {
    super(page);
    this.policyPaymentHeader = page.locator("xpath=//h1[contains(text(), '"); // @FindBy(xpath = "//h1[contains(text(), '" + POLICY_PAYMENT + "')]")
    this.twelveTermPriceSubHeader = page.locator("xpath=//span[contains(text(), '12-month term')]"); // @FindBy(xpath = "//span[contains(text(), '12-month term')]")
    this.twelveMonthTermPaymentLabel = page.locator("xpath=//span[contains(text(), '"); // @FindBy(xpath = "//span[contains(text(), '" + TWELVE_MONTH_TERM_PAYMENT_LABEL + "')]")
    this.dueTodayAmountWebElement = page.locator("xpath=//section[contains(@class,'autopay-details')]//*[contains(text(),'Due today')]/following-sibling::*"); // @FindBy(xpath = "//section[contains(@class,'autopay-details')]//*[contains(text(),'Due today')]/following-sibling::*")
    this.dueTodayAmountWithAmountToBeBilledWebElement = page.locator("xpath=//div[contains(@class,'autopay-details-bottom-row') and contains(.,'Amount to be billed')]//span[2]"); // @FindBy(xpath = "//div[contains(@class,'autopay-details-bottom-row') and contains(.,'Amount to be billed')]//span[2]")
    this.feesLabelModal = page.locator("xpath=//app-model-info-box-bind//h1"); // @FindBy(xpath = "//app-model-info-box-bind//h1")
    this.oneTimeFeesOrExpenseConstantLabel = page.locator("xpath=//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][2]/p[1]"); // @FindBy(xpath = "//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][2]/p[1]")
    this.feesLabel = page.locator("xpath=//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][2]/span[1]"); // @FindBy(xpath = "//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][2]/span[1]")
    this.oneTimeFeesOrExpenseConstantAmount = page.locator("xpath=//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][2]/p[2]"); // @FindBy(xpath = "//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][2]/p[2]")
    this.feesAmount = page.locator("xpath=//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][2]/span[2]"); // @FindBy(xpath = "//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][2]/span[2]")
    this.taxesAndSurchargesAmountPayInFull = page.locator("xpath=//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][3]/span[2]"); // @FindBy(xpath = "//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][3]/span[2]")
    this.taxesAndSurchargesLabelPayInFull = page.locator("xpath=//div[@class='pif-autopay-fees']//span[text()='Taxes and surcharges']"); // @FindBy(xpath = "//div[@class='pif-autopay-fees']//span[text()='Taxes and surcharges']")
    this.taxesAndSurchargesLabelMonthlyPay = page.locator("[data-legacy-field=\"taxesAndSurchargesLabelMonthlyPay\"]"); // @FindBy(xpath = TAXES_AND_SURCHARGES_LABEL_MONTHLY_PAY_XPATH)
    this.taxesAndSurchargesAmountMonthlyPay = page.locator("[data-legacy-field=\"taxesAndSurchargesAmountMonthlyPay\"]"); // @FindBy(xpath = TAXES_AND_SURCHARGES_LABEL_MONTHLY_PAY_XPATH + "//following-sibling::p")
    this.policyFeesDescriptionDesktop = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + POLICY_FEES_DESCRIPTION + "')]")
    this.policyFeesDescriptionMobile = page.locator("xpath=//mat-dialog-container//p[contains(text(), '"); // @FindBy(xpath = "//mat-dialog-container//p[contains(text(), '" + POLICY_FEES_DESCRIPTION + "')]")
    this.expenseConstantDescriptionMobile = page.locator("xpath=//mat-dialog-container//p[contains(text(), '"); // @FindBy(xpath = "//mat-dialog-container//p[contains(text(), '" + EXPENSE_CONSTANT_FEES_DESCRIPTION + "')]")
    this.memberShipFeesDescriptionDesktop = page.locator("xpath=//p[contains(@class,'tui-info-box-content')]"); // @FindBy(xpath = "//p[contains(@class,'tui-info-box-content')]")
    this.memberShipFeesDescriptionCODesktop = page.locator("xpath=//p/span[contains(text(),'No fee is applied')]"); // @FindBy(xpath = "//p/span[contains(text(),'No fee is applied')]")
    this.memberShipFeesDescriptionMobile = page.locator("xpath=//mat-dialog-container//*[contains(@class,'model-caption-text')]"); // @FindBy(xpath = "//mat-dialog-container//*[contains(@class,'model-caption-text')]")
    this.expenseConstantDescriptionDesktop = page.locator("xpath=//p[contains(@class,'tui-info-box-content')]"); // @FindBy(xpath = "//p[contains(@class,'tui-info-box-content')]")
    this.monthlyAutoPayBankHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_BANK + "')]")
    this.monthlyAutoPayCardHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_CARD + "')]")
    this.billedToMortgageeHeader = page.locator("xpath=//div[contains(@class,'pif-autopay-main-payment-row')]//h2"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-main-payment-row')]//h2")
    this.newPolicyHeader = page.locator("xpath=//div[contains(@class,'pif-autopay-main-payment-row')]//h2"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-main-payment-row')]//h2")
    this.amountToBeBilledLabel = page.locator("xpath=//span[contains(text(), '"); // @FindBy(xpath = "//span[contains(text(), '" + AMOUNT_TO_BE_BILLED + "')]")
    this.authorizeAllPaymentsByYourLenderHeader = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + AUTHORIZE_PAYMENTS_BY_LENDER_HEADER + "')]")
    this.yourPaymentIncludedInMortgageText = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + YOUR_PAYMENTS_INCLUDED_IN_MORTGAGE + "')]")
    this.paperlessBillingNotApplicableForLenderBulletPoint = page.locator("xpath=//span[contains(text(), '"); // @FindBy(xpath = "//span[contains(text(), '" + PAPERLESS_BILLING_IS_NOT_APPLICABLE_FOR_LENDER + "')]")
    this.futurePaymentsHeader = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + FUTURE_PAYMENTS + "')]")
    this.mortgageCompanyWillStartPayingAfterFirstYearText = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + MORTGAGE_COMPANY_START_PAYING_AFTER_FIRST_YEAR + "')]")
    this.contactAgentOrFarmersDirectSalesParagraphDisclaimers = page.locator("xpath=//section[contains(@class,'disclaimers-text')]//p[contains(@class,'disclaimers-final-text')]"); // @FindBy(xpath = "//section[contains(@class,'disclaimers-text')]//p[contains(@class,'disclaimers-final-text')]")
    this.bankPaymentServiceChargeText = page.locator("xpath=//p[@class='monthly-autopay-disclaimers-charge-text']"); // @FindBy(xpath = "//p[@class='monthly-autopay-disclaimers-charge-text']")
    this.feesInfoIconMobile = page.locator("xpath=//section//mat-icon[contains(text(),'info')]"); // @FindBy(xpath = "//section//mat-icon[contains(text(),'info')]")
    this.feesInfoDialogCloseButton = page.locator("xpath=//mat-dialog-container//mat-icon[contains(text(),'close')]"); // @FindBy(xpath = "//mat-dialog-container//mat-icon[contains(text(),'close')]")
    this.paymentMethodAddedText = page.locator("xpath=//div[contains(@class,'autopay-disclaimers-header')]//span"); // @FindBy(xpath = "//div[contains(@class,'autopay-disclaimers-header')]//span")
    this.changeLink = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + CHANGE_LINK + "')]")
    this.debitCreditCardToggleButton = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE + "')]")
    this.bankToggleButton = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + BANK_PAYMENT_TOGGLE_BUTTON_TITLE + "')]/parent::button")
    this.useSamePaymentMethodQuestion = page.locator("xpath=//div[@id='paymentDialogHeading']//h2"); // @FindBy(xpath = "//div[@id='paymentDialogHeading']//h2")
    this.paymentDialogConfirmation = page.locator("xpath=//p[@id='paymentDialogConfirmation']"); // @FindBy(xpath = "//p[@id='paymentDialogConfirmation']")
    this.savedAutoPolicyPaymentMethodLabel = page.locator("xpath=//div[@id='paymentDialogInfo']//p"); // @FindBy(xpath = "//div[@id='paymentDialogInfo']//p")
    this.savedAutoPolicyPaymentCardSymbol = page.locator("xpath=//div[contains(@class,'payment-dialog-details')]//img"); // @FindBy(xpath = "//div[contains(@class,'payment-dialog-details')]//img")
    this.savedAutoPolicyPaymentBankSymbol = page.locator("xpath=//div[contains(@class,'payment-dialog-details')]//i"); // @FindBy(xpath = "//div[contains(@class,'payment-dialog-details')]//i")
    this.savedAutoPolicyPaymentBankAccountNumber = page.locator("xpath=//span[contains(@class,'payment-dialog-account-numbers')]//small"); // @FindBy(xpath = "//span[contains(@class,'payment-dialog-account-numbers')]//small")
    this.savedAutoPolicyPaymentDetails = page.locator("xpath=//div[contains(@class,'payment-dialog-details')]//small"); // @FindBy(xpath = "//div[contains(@class,'payment-dialog-details')]//small")
    this.sameButton = page.locator("xpath=//button[@id='sameButton']"); // @FindBy(xpath = "//button[@id='sameButton']")
    this.differentButton = page.locator("xpath=//button[@id='differentButton']"); // @FindBy(xpath = "//button[@id='differentButton']")
    this.closeIconSamePaymentMethodModal = page.locator("xpath=//div[contains(@class, 'popup-close-hit-area')]//mat-icon"); // @FindBy(xpath = "//div[contains(@class, 'popup-close-hit-area')]//mat-icon")
    this.reusePaymentPopUp = page.locator("xpath=//app-payment-reuse-popup"); // @FindBy(xpath = "//app-payment-reuse-popup")
    this.paymentSideSheet = page.locator("xpath=//mat-dialog-container"); // @FindBy(xpath = "//mat-dialog-container")
    this.linkChangeCoverageOptions = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + CHANGE_YOUR_COVERAGE_OPTIONS + "')]")
  }
}
