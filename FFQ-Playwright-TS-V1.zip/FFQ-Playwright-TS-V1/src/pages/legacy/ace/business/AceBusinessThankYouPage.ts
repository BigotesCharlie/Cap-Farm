// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.business.AceBusinessThankYouPage. */
export class AceBusinessThankYouPage extends CoreBasePage {
  public readonly quoteNumberLabel: Locator;
  public readonly needMoreHelpSection: Locator;

  public constructor(page: Page) {
    super(page);
    this.quoteNumberLabel = page.locator("xpath=//div[contains(@class, 'thank-you__quote-number')]/span[1]"); // @FindBy(xpath = "//div[contains(@class, 'thank-you__quote-number')]/span[1]")
    this.needMoreHelpSection = page.locator("xpath=//div[contains(@class, 'leadForm__toll-free-section')]"); // @FindBy(xpath = "//div[contains(@class, 'leadForm__toll-free-section')]")
  }
}
