// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.business.AceBusinessLeadForm. */
export class AceBusinessLeadForm extends CoreBasePage {
  public readonly leadFormTitle: Locator;
  public readonly leadFormSubtitle: Locator;
  public readonly policyTypeSectionLabel: Locator;
  public readonly listOfPolicyTypeCheckboxes: Locator;
  public readonly otherPolicyTypeInputField: Locator;
  public readonly listOfPolicyTypeCheckboxLabels: Locator;
  public readonly policyTypeInfoIcon: Locator;
  public readonly typesOfPoliciesHelpDialogTitle: Locator;
  public readonly typesOfPoliciesHelpDialogContent: Locator;
  public readonly businessIndustryLabel: Locator;
  public readonly businessIndustryInputField: Locator;
  public readonly businessInfosectionLabel: Locator;
  public readonly businessNameInputField: Locator;
  public readonly businessAddressInputField: Locator;
  public readonly cityInputField: Locator;
  public readonly zipCodeInputField: Locator;
  public readonly stateInputField: Locator;
  public readonly businessWebsiteInpuField: Locator;
  public readonly currentlyInsuredSectionLabel: Locator;
  public readonly listOfInsuranceDescriptionLabels: Locator;
  public readonly listOfInsuranceRadioButtons: Locator;
  public readonly additionalInfoLabel: Locator;
  public readonly additionalInsuranceDetailsInputField: Locator;
  public readonly personalInformationLabel: Locator;
  public readonly firstNameInputField: Locator;
  public readonly lastNameInputField: Locator;
  public readonly dobInputField: Locator;
  public readonly emailInputField: Locator;
  public readonly phoneNumberInputField: Locator;
  public readonly extensionInputField: Locator;
  public readonly listOfContactSectionLabels: Locator;
  public readonly listOfContactMethodPreferenceRadioButtons: Locator;
  public readonly listOfContactTimePreferenceRadioButtons: Locator;
  public readonly disclaimerSection: Locator;
  public readonly agreeAndSubmitButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.leadFormTitle = page.locator("xpath=//app-business-info//h1"); // @FindBy(xpath = "//app-business-info//h1")
    this.leadFormSubtitle = page.locator(".section-header"); // @FindBy(className = "section-header")
    this.policyTypeSectionLabel = page.locator("[data-legacy-field=\"policyTypeSectionLabel\"]"); // @FindBy(xpath = POLICY_TYPE_SECTION_XPATH + "//div[@class='field-label-with-info']//label")
    this.listOfPolicyTypeCheckboxes = page.locator("[data-legacy-field=\"listOfPolicyTypeCheckboxes\"]"); // @FindBy(xpath = POLICY_TYPE_SECTION_XPATH + "//mat-checkbox//input")
    this.otherPolicyTypeInputField = page.locator("xpath=//div[contains(@class, 'other-policy-input')]//input"); // @FindBy(xpath = "//div[contains(@class, 'other-policy-input')]//input")
    this.listOfPolicyTypeCheckboxLabels = page.locator("[data-legacy-field=\"listOfPolicyTypeCheckboxLabels\"]"); // @FindBy(xpath = POLICY_TYPE_SECTION_XPATH + "//span[@class='mat-checkbox-label'] | " + POLICY_TYPE_SECTION_XPATH + "//label[@class='mdc-label']")
    this.policyTypeInfoIcon = page.locator("[data-legacy-field=\"policyTypeInfoIcon\"]"); // @FindBy(xpath = POLICY_TYPE_SECTION_XPATH + "//mat-icon")
    this.typesOfPoliciesHelpDialogTitle = page.locator("xpath=//mat-dialog-container//h1"); // @FindBy(xpath = "//mat-dialog-container//h1")
    this.typesOfPoliciesHelpDialogContent = page.locator(".main-content"); // @FindBy(className = "main-content")
    this.businessIndustryLabel = page.locator("[data-legacy-field=\"businessIndustryLabel\"]"); // @FindBy(xpath = BUSINESS_DESCRIPTION_FIELD_XPATH + "/label")
    this.businessIndustryInputField = page.locator("[data-legacy-field=\"businessIndustryInputField\"]"); // @FindBy(xpath = BUSINESS_DESCRIPTION_FIELD_XPATH + "//input")
    this.businessInfosectionLabel = page.locator("[data-legacy-field=\"businessInfosectionLabel\"]"); // @FindBy(xpath = BUSINESS_INFO_SECTION_XPATH + "/label")
    this.businessNameInputField = page.locator("xpath=//mat-label[text()='Business name']/ancestor-or-self::div/input"); // @FindBy(xpath = "//mat-label[text()='Business name']/ancestor-or-self::div/input")
    this.businessAddressInputField = page.locator("#auto-manual-street__input-section"); // @FindBy(id = "auto-manual-street__input-section")
    this.cityInputField = page.locator("xpath=//input[@aria-label='city']"); // @FindBy(xpath = "//input[@aria-label='city']")
    this.zipCodeInputField = page.locator("xpath=//input[@aria-label='zipCode']"); // @FindBy(xpath = "//input[@aria-label='zipCode']")
    this.stateInputField = page.locator("xpath=//div[@id='formField_state']//input"); // @FindBy(xpath = "//div[@id='formField_state']//input")
    this.businessWebsiteInpuField = page.locator("xpath=//mat-label[text()='Business Website URL']/ancestor-or-self::div/input"); // @FindBy(xpath = "//mat-label[text()='Business Website URL']/ancestor-or-self::div/input")
    this.currentlyInsuredSectionLabel = page.locator("[data-legacy-field=\"currentlyInsuredSectionLabel\"]"); // @FindBy(xpath = BUSINESS_DESCRIPTION_SECTION_XPATH + "/label")
    this.listOfInsuranceDescriptionLabels = page.locator("[data-legacy-field=\"listOfInsuranceDescriptionLabels\"]"); // @FindBy(xpath = BUSINESS_DESCRIPTION_SECTION_XPATH + "//mat-radio-button//label")
    this.listOfInsuranceRadioButtons = page.locator("[data-legacy-field=\"listOfInsuranceRadioButtons\"]"); // @FindBy(xpath = BUSINESS_DESCRIPTION_SECTION_XPATH + "//input")
    this.additionalInfoLabel = page.locator("xpath=//label[contains(@class, 'business-additional-info')]"); // @FindBy(xpath = "//label[contains(@class, 'business-additional-info')]")
    this.additionalInsuranceDetailsInputField = page.locator("xpath=//mat-label[contains(text(), 'Details about')]/ancestor-or-self::div/input"); // @FindBy(xpath = "//mat-label[contains(text(), 'Details about')]/ancestor-or-self::div/input")
    this.personalInformationLabel = page.locator("xpath=//div[@class='personal-info-section']/label"); // @FindBy(xpath = "//div[@class='personal-info-section']/label")
    this.firstNameInputField = page.locator("xpath=//mat-label[text()='First name']/ancestor-or-self::div/input"); // @FindBy(xpath = "//mat-label[text()='First name']/ancestor-or-self::div/input")
    this.lastNameInputField = page.locator("xpath=//mat-label[text()='Last name']/ancestor-or-self::div/input"); // @FindBy(xpath = "//mat-label[text()='Last name']/ancestor-or-self::div/input")
    this.dobInputField = page.locator("xpath=//mat-label[contains(text(), 'Date of birth')]/ancestor-or-self::div/input"); // @FindBy(xpath = "//mat-label[contains(text(), 'Date of birth')]/ancestor-or-self::div/input")
    this.emailInputField = page.locator("xpath=//input[@type='email']"); // @FindBy(xpath = "//input[@type='email']")
    this.phoneNumberInputField = page.locator("#contact-details-phoneNumber-input_Field"); // @FindBy(id = "contact-details-phoneNumber-input_Field")
    this.extensionInputField = page.locator("xpath=//input[@type='tel']"); // @FindBy(xpath = "//input[@type='tel']")
    this.listOfContactSectionLabels = page.locator("[data-legacy-field=\"listOfContactSectionLabels\"]"); // @FindBy(xpath = CONTACT_METHOD_SECTION_XPATH + "//label")
    this.listOfContactMethodPreferenceRadioButtons = page.locator("[data-legacy-field=\"listOfContactMethodPreferenceRadioButtons\"]"); // @FindBy(xpath = CONTACT_METHOD_SECTION_XPATH + "/mat-radio-group//input")
    this.listOfContactTimePreferenceRadioButtons = page.locator("[data-legacy-field=\"listOfContactTimePreferenceRadioButtons\"]"); // @FindBy(xpath = CONTACT_TIME_SECTION_XPATH + "/mat-radio-group//input")
    this.disclaimerSection = page.locator(".disclaimer-section"); // @FindBy(className = "disclaimer-section")
    this.agreeAndSubmitButton = page.locator("xpath=//button[@type='submit']"); // @FindBy(xpath = "//button[@type='submit']")
  }
}
