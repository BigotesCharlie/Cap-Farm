// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.ace.business.AceBusinessNavigationHelper. */
export class AceBusinessNavigationHelper extends CoreBasePage {
  public readonly footer: Locator;

  public constructor(page: Page) {
    super(page);
    this.footer = page.locator("xpath=//tui-oneui-footer"); // @FindBy(xpath = "//tui-oneui-footer")
  }
}
