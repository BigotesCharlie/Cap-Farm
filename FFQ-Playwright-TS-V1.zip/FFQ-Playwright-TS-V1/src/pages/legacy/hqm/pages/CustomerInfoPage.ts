// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.CustomerInfoPage. */
export class CustomerInfoPage extends CoreBasePage {
  public readonly inputFirstName: Locator;
  public readonly labelFirstName: Locator;
  public readonly inputLastName: Locator;
  public readonly labelLastName: Locator;
  public readonly inputDob: Locator;
  public readonly labelDob: Locator;
  public readonly radioBtnMale: Locator;
  public readonly radioBtnMaleInternal: Locator;
  public readonly radioBtnFemale: Locator;
  public readonly radioBtnFemaleInternal: Locator;
  public readonly selectOccupation: Locator;
  public readonly checkMarried: Locator;
  public readonly checkMarriedInternal: Locator;
  public readonly inputSpouseFirstName: Locator;
  public readonly labelSpouseFirstName: Locator;
  public readonly inputSpouseLastName: Locator;
  public readonly labelSpouseLastName: Locator;
  public readonly inputSpouseDob: Locator;
  public readonly labelSpouseDob: Locator;
  public readonly radioBtnSpouseMale: Locator;
  public readonly radioBtnSpouseMaleInternal: Locator;
  public readonly radioBtnSpouseFemale: Locator;
  public readonly radioBtnSpouseFemaleInternal: Locator;
  public readonly textPageTitle: Locator;
  public readonly textPageSubTitle1: Locator;
  public readonly discountSubTitleLock: Locator;
  public readonly discountSubTitlePiggy: Locator;
  public readonly discountHelpButtonPiggy: Locator;
  public readonly discountHelpDialogTitle: Locator;
  public readonly discountHelpDialogContent: Locator;
  public readonly discountCheck: Locator;
  public readonly buttonCloseDialog: Locator;
  public readonly textPageSubTitle2: Locator;

  public constructor(page: Page) {
    super(page);
    this.inputFirstName = page.locator("xpath=//ui-farmers-input[@fieldlabel='First name']//input"); // @FindBy(xpath = "//ui-farmers-input[@fieldlabel='First name']//input")
    this.labelFirstName = page.locator("xpath=//ui-farmers-input[@fieldlabel='First name']//mat-label"); // @FindBy(xpath = "//ui-farmers-input[@fieldlabel='First name']//mat-label")
    this.inputLastName = page.locator("xpath=//ui-farmers-input[@fieldlabel='Last name']//input"); // @FindBy(xpath = "//ui-farmers-input[@fieldlabel='Last name']//input")
    this.labelLastName = page.locator("xpath=//ui-farmers-input[@fieldlabel='Last name']//mat-label"); // @FindBy(xpath = "//ui-farmers-input[@fieldlabel='Last name']//mat-label")
    this.inputDob = page.locator("xpath=//ui-farmers-datepicker[@fieldlabel='Date of birth']//input[@matinput]"); // @FindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Date of birth']//input[@matinput]")
    this.labelDob = page.locator("xpath=//ui-farmers-datepicker[@fieldlabel='Date of birth']//mat-label"); // @FindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Date of birth']//mat-label")
    this.radioBtnMale = page.locator("xpath=//farmers-home-quote-customer-info//mat-radio-group[@id='gender']/mat-radio-button[@value='M']"); // @FindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='gender']/mat-radio-button[@value='M']")
    this.radioBtnMaleInternal = page.locator("xpath=//farmers-home-quote-customer-info//mat-radio-group[@id='gender']/mat-radio-button[@value='M']//input"); // @FindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='gender']/mat-radio-button[@value='M']//input")
    this.radioBtnFemale = page.locator("xpath=//farmers-home-quote-customer-info//mat-radio-group[@id='gender']/mat-radio-button[@value='F']"); // @FindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='gender']/mat-radio-button[@value='F']")
    this.radioBtnFemaleInternal = page.locator("xpath=//farmers-home-quote-customer-info//mat-radio-group[@id='gender']/mat-radio-button[@value='F']//input"); // @FindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='gender']/mat-radio-button[@value='F']//input")
    this.selectOccupation = page.locator("[data-legacy-field=\"selectOccupation\"]"); // @FindBy(xpath = SELECT_OCCUPATION_XPATH)
    this.checkMarried = page.locator("xpath=//ui-farmers-checkbox[@id='maritualStatus-input']//mat-checkbox//input"); // @FindBy(xpath = "//ui-farmers-checkbox[@id='maritualStatus-input']//mat-checkbox//input")
    this.checkMarriedInternal = page.locator("xpath=//input[@id='maritualStatus-input-input']"); // @FindBy(xpath = "//input[@id='maritualStatus-input-input']")
    this.inputSpouseFirstName = page.locator("xpath=//ui-farmers-input[@fieldlabel='Spouse first name']//input"); // @FindBy(xpath = "//ui-farmers-input[@fieldlabel='Spouse first name']//input")
    this.labelSpouseFirstName = page.locator("xpath=//ui-farmers-input[@fieldlabel='Spouse first name']//mat-label"); // @FindBy(xpath = "//ui-farmers-input[@fieldlabel='Spouse first name']//mat-label")
    this.inputSpouseLastName = page.locator("xpath=//ui-farmers-input[@fieldlabel='Spouse last name']//input"); // @FindBy(xpath = "//ui-farmers-input[@fieldlabel='Spouse last name']//input")
    this.labelSpouseLastName = page.locator("xpath=//ui-farmers-input[@fieldlabel='Spouse last name']//mat-label"); // @FindBy(xpath = "//ui-farmers-input[@fieldlabel='Spouse last name']//mat-label")
    this.inputSpouseDob = page.locator("xpath=//ui-farmers-datepicker[@fieldlabel='Spouse date of birth']//input[@matinput]"); // @FindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Spouse date of birth']//input[@matinput]")
    this.labelSpouseDob = page.locator("xpath=//ui-farmers-datepicker[@fieldlabel='Spouse date of birth']//mat-label"); // @FindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Spouse date of birth']//mat-label")
    this.radioBtnSpouseMale = page.locator("xpath=//farmers-home-quote-customer-info//mat-radio-group[@id='spouseGender']/mat-radio-button[@value='M']"); // @FindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='spouseGender']/mat-radio-button[@value='M']")
    this.radioBtnSpouseMaleInternal = page.locator("xpath=//farmers-home-quote-customer-info//mat-radio-group[@id='spouseGender']/mat-radio-button[@value='M']//input"); // @FindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='spouseGender']/mat-radio-button[@value='M']//input")
    this.radioBtnSpouseFemale = page.locator("xpath=//farmers-home-quote-customer-info//mat-radio-group[@id='spouseGender']/mat-radio-button[@value='F']"); // @FindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='spouseGender']/mat-radio-button[@value='F']")
    this.radioBtnSpouseFemaleInternal = page.locator("xpath=//farmers-home-quote-customer-info//mat-radio-group[@id='spouseGender']/mat-radio-button[@value='F']//input"); // @FindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='spouseGender']/mat-radio-button[@value='F']//input")
    this.textPageTitle = page.locator("xpath=//farmers-home-quote-customer-info//h1[@aria-label=\"WE'D LIKE TO MEET YOU\"]"); // @FindBy(xpath = "//farmers-home-quote-customer-info//h1[@aria-label=\"WE'D LIKE TO MEET YOU\"]")
    this.textPageSubTitle1 = page.locator("xpath=//farmers-home-quote-customer-info//div[@id='customer-info']//span[contains(@class,'sub-title-one')]"); // @FindBy(xpath = "//farmers-home-quote-customer-info//div[@id='customer-info']//span[contains(@class,'sub-title-one')]")
    this.discountSubTitleLock = page.locator("xpath=//farmers-home-quote-customer-info//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__image')]/../p"); // @FindBy(xpath = "//farmers-home-quote-customer-info//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__image')]/../p")
    this.discountSubTitlePiggy = page.locator("xpath=//farmers-home-quote-customer-info//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__potential')]/../p"); // @FindBy(xpath = "//farmers-home-quote-customer-info//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__potential')]/../p")
    this.discountHelpButtonPiggy = page.locator("xpath=//farmers-home-quote-customer-info//div[@class='discount-journey-card']//mat-icon[text()='info']"); // @FindBy(xpath ="//farmers-home-quote-customer-info//div[@class='discount-journey-card']//mat-icon[text()='info']")
    this.discountHelpDialogTitle = page.locator("xpath=//farmers-home-quote-discount-journey-dialog//h4"); // @FindBy(xpath = "//farmers-home-quote-discount-journey-dialog//h4")
    this.discountHelpDialogContent = page.locator("[data-legacy-field=\"discountHelpDialogContent\"]"); // @FindBy(xpath = DISCOUNT_HELP_DIALOG_CONTENT_XPATH)
    this.discountCheck = page.locator("xpath=//farmers-home-quote-customer-info//mat-card//div[@class='djm-discount-check']/../p"); // @FindBy(xpath = "//farmers-home-quote-customer-info//mat-card//div[@class='djm-discount-check']/../p")
    this.buttonCloseDialog = page.locator("xpath=//mat-dialog-actions//button[.='CLOSE']"); // @FindBy(xpath = "//mat-dialog-actions//button[.='CLOSE']")
    this.textPageSubTitle2 = page.locator("[data-legacy-field=\"textPageSubTitle2\"]"); // @FindBy(xpath = SUBTITLE_XPATH)
  }
}
