// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.QuotePage. */
export class QuotePage extends CoreBasePage {
  public readonly quoteCard: Locator;
  public readonly titleQuoteType: Locator;
  public readonly textQuotePricePerMonth: Locator;
  public readonly textQuotePricePerMonthCents: Locator;
  public readonly textQuotePricePerYear: Locator;
  public readonly textQuotePricePerYearCA: Locator;
  public readonly btnQuoteDetails: Locator;
  public readonly quoteDetailsDialog: Locator;
  public readonly btnCloseModal: Locator;
  public readonly btnRecalculate: Locator;
  public readonly btnReset: Locator;
  public readonly textSliderDwelling: Locator;
  public readonly sliderDwelling: Locator;
  public readonly textSliderExtendedReplacement: Locator;
  public readonly sliderExtendedReplacement: Locator;
  public readonly textSliderPersonalProperty: Locator;
  public readonly sliderPersonalProperty: Locator;
  public readonly textSliderAllPeril: Locator;
  public readonly sliderAllPeril: Locator;
  public readonly textSliderWindAndHail: Locator;
  public readonly sliderWindAndHail: Locator;
  public readonly sliderHurricane: Locator;
  public readonly textSliderPersonalLiability: Locator;
  public readonly sliderPersonalLiability: Locator;
  public readonly textSliderMedicalPaymentsToOthers: Locator;
  public readonly sliderMedicalPaymentsToOthers: Locator;
  public readonly popupYearlyPremium: Locator;
  public readonly popupMonthlyPremium: Locator;
  public readonly popupTitle: Locator;
  public readonly textPageTitle: Locator;
  public readonly textPageSubTitle: Locator;
  public readonly textReconstructionCost: Locator;
  public readonly discountSubTitlePiggy: Locator;
  public readonly linkViewDiscounts: Locator;
  public readonly textQuoteTypeSubtitle: Locator;
  public readonly textQuoteNoteSubtitle: Locator;
  public readonly btnEmail: Locator;
  public readonly emailDialogTitle: Locator;
  public readonly emailDialogContent: Locator;
  public readonly emailDialogBtnOK: Locator;
  public readonly textContactUs: Locator;
  public readonly btnPrint: Locator;
  public readonly autoLobLink: Locator;
  public readonly totalDiscAmt: Locator;
  public readonly policyPerksTitle: Locator;
  public readonly policyPerksHeader: Locator;
  public readonly policyPerksHeaderLink: Locator;
  public readonly imageFloByMoen: Locator;
  public readonly textFloByMoen: Locator;
  public readonly linkFloByMoen: Locator;
  public readonly contactUsFloByMoen: Locator;
  public readonly closeSurveyButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.quoteCard = page.locator("xpath=//mat-card[contains(@class,'mat-card')]"); // @FindBy(xpath = "//mat-card[contains(@class,'mat-card')]")
    this.titleQuoteType = page.locator("xpath=//mat-card[contains(@class,'mat-card')]//h2"); // @FindBy(xpath = "//mat-card[contains(@class,'mat-card')]//h2")
    this.textQuotePricePerMonth = page.locator("xpath=//mat-card[contains(@class,'mat-card')]//div[@id='monthlyPremium']"); // @FindBy(xpath = "//mat-card[contains(@class,'mat-card')]//div[@id='monthlyPremium']")
    this.textQuotePricePerMonthCents = page.locator("xpath=//mat-card[contains(@class,'mat-card')]//span[@class='cost-size']/../span[contains(@class,'sub-title-one')]"); // @FindBy(xpath = "//mat-card[contains(@class,'mat-card')]//span[@class='cost-size']/../span[contains(@class,'sub-title-one')]")
    this.textQuotePricePerYear = page.locator("xpath=//mat-card[contains(@class,'mat-card')]//span[contains(@class,'overline')]"); // @FindBy(xpath = "//mat-card[contains(@class,'mat-card')]//span[contains(@class,'overline')]")
    this.textQuotePricePerYearCA = page.locator("xpath=//mat-card[contains(@class,'mat-card')]//div[@id='yearlyPremium']"); // @FindBy(xpath = "//mat-card[contains(@class,'mat-card')]//div[@id='yearlyPremium']")
    this.btnQuoteDetails = page.locator("[data-legacy-field=\"btnQuoteDetails\"]"); // @FindBy(xpath = BUTTON_QUOTE_DETAILS_XPATH)
    this.quoteDetailsDialog = page.locator("xpath=//mat-dialog-container[@aria-modal='true']"); // @FindBy(xpath = "//mat-dialog-container[@aria-modal='true']")
    this.btnCloseModal = page.locator("xpath=//farmers-home-quote-details-dialog//mat-icon[contains(text(),'close')]"); // @FindBy(xpath = "//farmers-home-quote-details-dialog//mat-icon[contains(text(),'close')]")
    this.btnRecalculate = page.locator("xpath=//farmers-home-quote-details-dialog//button[contains(.,'RECALCULATE')]"); // @FindBy(xpath = "//farmers-home-quote-details-dialog//button[contains(.,'RECALCULATE')]")
    this.btnReset = page.locator("xpath=//farmers-home-quote-details-dialog//button[contains(text(),'RESET')]"); // @FindBy(xpath = "//farmers-home-quote-details-dialog//button[contains(text(),'RESET')]")
    this.textSliderDwelling = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Dwelling')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Dwelling')]" +             "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    this.sliderDwelling = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Dwelling')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Dwelling')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.textSliderExtendedReplacement = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Extended Replacement Cost')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Extended Replacement Cost')]" +             "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    this.sliderExtendedReplacement = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Extended Replacement Cost')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Extended Replacement Cost')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.textSliderPersonalProperty = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Personal Property')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Property')]" +             "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    this.sliderPersonalProperty = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Personal Property')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Property')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.textSliderAllPeril = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'All Peril')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'All Peril')]" +             "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    this.sliderAllPeril = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'All Peril')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'All Peril')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.textSliderWindAndHail = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Wind & Hail')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Wind & Hail')]" +             "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    this.sliderWindAndHail = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Wind & Hail')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Wind & Hail')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.sliderHurricane = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Hurricane')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Hurricane')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.textSliderPersonalLiability = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Personal Liability')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Liability')]" +             "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    this.sliderPersonalLiability = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Personal Liability')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Liability')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.textSliderMedicalPaymentsToOthers = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Medical Payments to Others')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Medical Payments to Others')]" +             "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    this.sliderMedicalPaymentsToOthers = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Medical Payments to Others')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Medical Payments to Others')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.popupYearlyPremium = page.locator("xpath=//farmers-home-quote-details-dialog//span[contains(@class,'overline')]"); // @FindBy(xpath = "//farmers-home-quote-details-dialog//span[contains(@class,'overline')]")
    this.popupMonthlyPremium = page.locator("xpath=//farmers-home-quote-details-dialog//div[contains(@class,'cost-block')]"); // @FindBy(xpath = "//farmers-home-quote-details-dialog//div[contains(@class,'cost-block')]")
    this.popupTitle = page.locator("xpath=//farmers-home-quote-details-dialog//h2[contains(@class,'header-title')]"); // @FindBy(xpath = "//farmers-home-quote-details-dialog//h2[contains(@class,'header-title')]")
    this.textPageTitle = page.locator("xpath=//farmers-home-quote//h1"); // @FindBy(xpath = "//farmers-home-quote//h1")
    this.textPageSubTitle = page.locator("xpath=//farmers-home-quote//span[@class='tui-subtitle-text-1']"); // @FindBy(xpath = "//farmers-home-quote//span[@class='tui-subtitle-text-1']")
    this.textReconstructionCost = page.locator("xpath=//farmers-home-quote//span[@class='tui-subtitle-text-1']/strong"); // @FindBy(xpath = "//farmers-home-quote//span[@class='tui-subtitle-text-1']/strong")
    this.discountSubTitlePiggy = page.locator("xpath=//farmers-home-quote//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__potential')]/.."); // @FindBy(xpath = "//farmers-home-quote//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__potential')]/..")
    this.linkViewDiscounts = page.locator("[data-legacy-field=\"linkViewDiscounts\"]"); // @FindBy(xpath = VIEW_DISCOUNTS_XPATH)
    this.textQuoteTypeSubtitle = page.locator("xpath=//farmers-home-quote//mat-card-content//p[@class='tui-subtitle-text-1']"); // @FindBy(xpath = "//farmers-home-quote//mat-card-content//p[@class='tui-subtitle-text-1']")
    this.textQuoteNoteSubtitle = page.locator("xpath=//farmers-home-quote//mat-card-content//p[@role='note']"); // @FindBy(xpath = "//farmers-home-quote//mat-card-content//p[@role='note']")
    this.btnEmail = page.locator("xpath=//farmers-home-quote//button[@id='emailIcon']"); // @FindBy(xpath = "//farmers-home-quote//button[@id='emailIcon']")
    this.emailDialogTitle = page.locator("xpath=//farmers-home-quote-email-dialog//h2[contains(@class,'mat-dialog-title')]"); // @FindBy(xpath = "//farmers-home-quote-email-dialog//h2[contains(@class,'mat-dialog-title')]")
    this.emailDialogContent = page.locator("xpath=//farmers-home-quote-email-dialog//mat-dialog-content/p[@class='sub-title-one']"); // @FindBy(xpath = "//farmers-home-quote-email-dialog//mat-dialog-content/p[@class='sub-title-one']")
    this.emailDialogBtnOK = page.locator("xpath=//farmers-home-quote-email-dialog//mat-dialog-actions/button[.='OK']"); // @FindBy(xpath = "//farmers-home-quote-email-dialog//mat-dialog-actions/button[.='OK']")
    this.textContactUs = page.locator("xpath=//farmers-home-quote//div[a[starts-with(@href,'tel:1-8')]]"); // @FindBy(xpath = "//farmers-home-quote//div[a[starts-with(@href,'tel:1-8')]]")
    this.btnPrint = page.locator("[data-legacy-field=\"btnPrint\"]"); // @FindBy(xpath = PRINT_ICON_XPATH)
    this.autoLobLink = page.locator("xpath=//mat-drawer[contains(@class,'mat-drawer-side')]//a[contains(@href,'&Flow=RS')]"); // @FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-side')]//a[contains(@href,'&Flow=RS')]")
    this.totalDiscAmt = page.locator("[data-legacy-field=\"totalDiscAmt\"]"); // @FindBy(xpath = totalDiscAmtXpath)
    this.policyPerksTitle = page.locator("xpath=//farmers-home-quote-policy-perks//div[contains(@class,'perk-title')]/img"); // @FindBy(xpath = "//farmers-home-quote-policy-perks//div[contains(@class,'perk-title')]/img")
    this.policyPerksHeader = page.locator("xpath=//farmers-home-quote-policy-perks//p[contains(@class,'tui-text-prominent')]"); // @FindBy(xpath = "//farmers-home-quote-policy-perks//p[contains(@class,'tui-text-prominent')]")
    this.policyPerksHeaderLink = page.locator("xpath=//farmers-home-quote-policy-perks//p[contains(@class,'tui-text-prominent')]//a[starts-with(@href,'https://www.farmers.com/policy-perks/')]"); // @FindBy(xpath = "//farmers-home-quote-policy-perks//p[contains(@class,'tui-text-prominent')]//a[starts-with(@href,'https://www.farmers.com/policy-perks/')]")
    this.imageFloByMoen = page.locator("[data-legacy-field=\"imageFloByMoen\"]"); // @FindBy(xpath = IMAGE_FLO_XPATH)
    this.textFloByMoen = page.locator("[data-legacy-field=\"textFloByMoen\"]"); // @FindBy(xpath = TEXT_FLO_BY_MOEN_XPATH)
    this.linkFloByMoen = page.locator("[data-legacy-field=\"linkFloByMoen\"]"); // @FindBy(xpath = LINK_FLO_BY_MOEN_XPATH)
    this.contactUsFloByMoen = page.locator("xpath=//div[contains(@class,'waterLeakProtectionDiv')]/div/a[starts-with(@href,'tel:1-8')]"); // @FindBy(xpath = "//div[contains(@class,'waterLeakProtectionDiv')]/div/a[starts-with(@href,'tel:1-8')]")
    this.closeSurveyButton = page.locator("[data-legacy-field=\"closeSurveyButton\"]"); // @FindBy(xpath = SURVEY_POPUP_XPATH)
  }
}
