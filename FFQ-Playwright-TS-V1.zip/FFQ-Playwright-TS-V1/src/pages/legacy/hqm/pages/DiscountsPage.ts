// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.DiscountsPage. */
export class DiscountsPage extends CoreBasePage {
  public readonly checkCentralFire: Locator;
  public readonly checkBurglar: Locator;
  public readonly checkCEA: Locator;
  public readonly checkADT: Locator;
  public readonly checkTheftAlarm: Locator;
  public readonly checkFireAlarm: Locator;
  public readonly checkWaterSensor: Locator;
  public readonly checkFortifiedHome: Locator;
  public readonly checkNewlyOwnedHome: Locator;
  public readonly selectTheftProtection: Locator;
  public readonly selectFireProtection: Locator;
  public readonly selectWaterProtection: Locator;
  public readonly selectFortifiedHome: Locator;
  public readonly selectCentralAlarm: Locator;
  public readonly selectDirectAlarm: Locator;
  public readonly selectLocalAlarm: Locator;
  public readonly selectAutoSmokeDetectors: Locator;
  public readonly selectAutoSprinklerSystem: Locator;
  public readonly checkAutoPolicy: Locator;
  public readonly inputPolicyStartDate: Locator;
  public readonly labelPolicyStartDate: Locator;
  public readonly checkLifeInsurance: Locator;
  public readonly checkAutoInsurance: Locator;
  public readonly checkCommercial: Locator;
  public readonly checkBoatAndWatercraft: Locator;
  public readonly checkOffRoad: Locator;
  public readonly checkMotorHome: Locator;
  public readonly checkUmbrellaInsurance: Locator;
  public readonly iconHelp: Locator;
  public readonly textPreferredPayment: Locator;
  public readonly textPaperless: Locator;
  public readonly textGoodPayer: Locator;
  public readonly textRecreationalBoat: Locator;
  public readonly textPageTitle1: Locator;
  public readonly knockOutsPageTitle: Locator;
  public readonly textPageTitle2: Locator;
  public readonly discountSubTitlePiggy: Locator;
  public readonly discountHelpButtonPiggy: Locator;
  public readonly discountHelpDialogTitle: Locator;
  public readonly discountHelpDialogContent: Locator;
  public readonly safetyFeaturesCheck: Locator;
  public readonly discountsCheck: Locator;
  public readonly helpDialogTitle: Locator;
  public readonly buttonCloseDialog: Locator;
  public readonly helpDialogContent: Locator;
  public readonly helpSubtitle: Locator;
  public readonly helpCEA: Locator;
  public readonly helpPreappliedTitle: Locator;
  public readonly helpTheftAlarm: Locator;
  public readonly helpTheftAlarmSelect: Locator;
  public readonly helpFireAlarm: Locator;
  public readonly helpFireAlarmSelect: Locator;
  public readonly helpWaterSensor: Locator;
  public readonly helpWaterSensorSelect: Locator;
  public readonly helpFortifiedHome: Locator;
  public readonly helpFortifiedHomeSelect: Locator;
  public readonly helpWindstormMitigationSelect: Locator;
  public readonly helpCentralAlarmSelect: Locator;
  public readonly helpDirectAlarmSelect: Locator;
  public readonly helpLocalAlarmSelect: Locator;
  public readonly helpAutomaticSprinklerSelect: Locator;

  public constructor(page: Page) {
    super(page);
    this.checkCentralFire = page.locator("[data-legacy-field=\"checkCentralFire\"]"); // @FindBy(xpath = CENTRAL_FIRE_XPATH)
    this.checkBurglar = page.locator("[data-legacy-field=\"checkBurglar\"]"); // @FindBy(xpath = CENTRAL_BURGLAR_XPATH)
    this.checkCEA = page.locator("[data-legacy-field=\"checkCEA\"]"); // @FindBy(xpath = CEA_XPATH)
    this.checkADT = page.locator("[data-legacy-field=\"checkADT\"]"); // @FindBy(xpath = ADT_XPATH)
    this.checkTheftAlarm = page.locator("[data-legacy-field=\"checkTheftAlarm\"]"); // @FindBy(xpath = THEFT_ALARM_XPATH)
    this.checkFireAlarm = page.locator("[data-legacy-field=\"checkFireAlarm\"]"); // @FindBy(xpath = FIRE_ALARM_XPATH)
    this.checkWaterSensor = page.locator("[data-legacy-field=\"checkWaterSensor\"]"); // @FindBy(xpath = WATER_SENSOR_XPATH)
    this.checkFortifiedHome = page.locator("[data-legacy-field=\"checkFortifiedHome\"]"); // @FindBy(xpath = FORTIFIED_HOME_XPATH)
    this.checkNewlyOwnedHome = page.locator("[data-legacy-field=\"checkNewlyOwnedHome\"]"); // @FindBy(xpath = NEWLY_OWNED_HOME_XPATH)
    this.selectTheftProtection = page.locator("xpath=//mat-select[contains(@id,'theftProtectionSelected')]"); // @FindBy(xpath = "//mat-select[contains(@id,'theftProtectionSelected')]")
    this.selectFireProtection = page.locator("xpath=//mat-select[contains(@id,'fireProtectionSelected')]"); // @FindBy(xpath = "//mat-select[contains(@id,'fireProtectionSelected')]")
    this.selectWaterProtection = page.locator("xpath=//mat-select[contains(@id,'waterProtectionSelected')]"); // @FindBy(xpath = "//mat-select[contains(@id,'waterProtectionSelected')]")
    this.selectFortifiedHome = page.locator("[data-legacy-field=\"selectFortifiedHome\"]"); // @FindBy(xpath = FORTIFIED_XPATH)
    this.selectCentralAlarm = page.locator("xpath=//mat-select[contains(@id,'centralAlarmSelected')]"); // @FindBy(xpath = "//mat-select[contains(@id,'centralAlarmSelected')]")
    this.selectDirectAlarm = page.locator("xpath=//mat-select[contains(@id,'directAlarmSelected')]"); // @FindBy(xpath = "//mat-select[contains(@id,'directAlarmSelected')]")
    this.selectLocalAlarm = page.locator("xpath=//mat-select[contains(@id,'localAlarmSelected')]"); // @FindBy(xpath = "//mat-select[contains(@id,'localAlarmSelected')]")
    this.selectAutoSmokeDetectors = page.locator("xpath=//mat-select[contains(@id,'automaticSmokeDetector')]"); // @FindBy(xpath = "//mat-select[contains(@id,'automaticSmokeDetector')]")
    this.selectAutoSprinklerSystem = page.locator("xpath=//mat-select[contains(@id,'automaticSprinkler')]"); // @FindBy(xpath = "//mat-select[contains(@id,'automaticSprinkler')]")
    this.checkAutoPolicy = page.locator("[data-legacy-field=\"checkAutoPolicy\"]"); // @FindBy(xpath = AUTO_POLICY_XPATH)
    this.inputPolicyStartDate = page.locator("xpath=//ui-farmers-datepicker[@fieldlabel='Policy start date']//input[@matinput]"); // @FindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Policy start date']//input[@matinput]")
    this.labelPolicyStartDate = page.locator("xpath=//ui-farmers-datepicker[@fieldlabel='Policy start date']//mat-label"); // @FindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Policy start date']//mat-label")
    this.checkLifeInsurance = page.locator("[data-legacy-field=\"checkLifeInsurance\"]"); // @FindBy(xpath = LIFE_INSURANCE_XPATH)
    this.checkAutoInsurance = page.locator("[data-legacy-field=\"checkAutoInsurance\"]"); // @FindBy(xpath = AUTO_INSURANCE_XPATH)
    this.checkCommercial = page.locator("[data-legacy-field=\"checkCommercial\"]"); // @FindBy(xpath = COMMERCIAL_XPATH)
    this.checkBoatAndWatercraft = page.locator("[data-legacy-field=\"checkBoatAndWatercraft\"]"); // @FindBy(xpath = BOAT_WATER_CRAFT_XPATH)
    this.checkOffRoad = page.locator("[data-legacy-field=\"checkOffRoad\"]"); // @FindBy(xpath = OFF_ROAD_XPATH)
    this.checkMotorHome = page.locator("[data-legacy-field=\"checkMotorHome\"]"); // @FindBy(xpath = MOTOR_HOME_XPATH)
    this.checkUmbrellaInsurance = page.locator("[data-legacy-field=\"checkUmbrellaInsurance\"]"); // @FindBy(xpath = UMBRELLA_INSURANCE_XPATH)
    this.iconHelp = page.locator("xpath=//mat-icon[text()='info ']"); // @FindBy(xpath = "//mat-icon[text()='info ']")
    this.textPreferredPayment = page.locator("xpath=//div//p[contains(@class,'quote-step-caption')]/span[text()='Preferred Payment']"); // @FindBy(xpath = "//div//p[contains(@class,'quote-step-caption')]/span[text()='Preferred Payment']")
    this.textPaperless = page.locator("xpath=//div//p[contains(@class,'quote-step-caption')]/span[text()='Paperless']"); // @FindBy(xpath = "//div//p[contains(@class,'quote-step-caption')]/span[text()='Paperless']")
    this.textGoodPayer = page.locator("xpath=//div//p[contains(@class,'quote-step-caption')]/span[text()='Good Payer']"); // @FindBy(xpath = "//div//p[contains(@class,'quote-step-caption')]/span[text()='Good Payer']")
    this.textRecreationalBoat = page.locator("xpath=//div//p[contains(@class,'quote-step-caption')]/span[text()='Recreational boat/watercraft insurance']"); // @FindBy(xpath = "//div//p[contains(@class,'quote-step-caption')]/span[text()='Recreational boat/watercraft insurance']")
    this.textPageTitle1 = page.locator("[data-legacy-field=\"textPageTitle1\"]"); // @FindBy(xpath = PAGE_TITLE_XPATH)
    this.knockOutsPageTitle = page.locator("xpath=//farmers-home-quote-knockouts//h1"); // @FindBy(xpath = "//farmers-home-quote-knockouts//h1")
    this.textPageTitle2 = page.locator("xpath=//farmers-home-quote-discounts//h2[@aria-label='Preapplied discounts']"); // @FindBy(xpath = "//farmers-home-quote-discounts//h2[@aria-label='Preapplied discounts']")
    this.discountSubTitlePiggy = page.locator("xpath=//farmers-home-quote-discounts//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__potential')]/../p"); // @FindBy(xpath = "//farmers-home-quote-discounts//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__potential')]/../p")
    this.discountHelpButtonPiggy = page.locator("xpath=//farmers-home-quote-discounts//div[@class='discount-journey-card']//mat-icon[text()='info']"); // @FindBy(xpath ="//farmers-home-quote-discounts//div[@class='discount-journey-card']//mat-icon[text()='info']")
    this.discountHelpDialogTitle = page.locator("xpath=//farmers-home-quote-discount-journey-dialog//h4"); // @FindBy(xpath = "//farmers-home-quote-discount-journey-dialog//h4")
    this.discountHelpDialogContent = page.locator("[data-legacy-field=\"discountHelpDialogContent\"]"); // @FindBy(xpath = DISCOUNT_HELP_DIALOG_CONTENT_XPATH)
    this.safetyFeaturesCheck = page.locator("xpath=//farmers-home-quote-discounts//mat-card//div[@id='safetyFeaturesCheckbox']//div[@class='djm-discount-check']/../p"); // @FindBy(xpath = "//farmers-home-quote-discounts//mat-card//div[@id='safetyFeaturesCheckbox']//div[@class='djm-discount-check']/../p")
    this.discountsCheck = page.locator("xpath=//farmers-home-quote-discounts//mat-card//div[@id='farmersInsuranceCheckbox']/../..//div[@class='djm-discount-check']/../p"); // @FindBy(xpath = "//farmers-home-quote-discounts//mat-card//div[@id='farmersInsuranceCheckbox']/../..//div[@class='djm-discount-check']/../p")
    this.helpDialogTitle = page.locator("xpath=//farmers-home-quote-tooltip-modal//h4"); // @FindBy(xpath = "//farmers-home-quote-tooltip-modal//h4")
    this.buttonCloseDialog = page.locator("xpath=//mat-dialog-actions//button[text()=('CLOSE' or 'close')]"); // @FindBy(xpath = "//mat-dialog-actions//button[text()=('CLOSE' or 'close')]")
    this.helpDialogContent = page.locator("xpath=//mat-dialog-container//div[@data-test-id='DIALOG_CONTENT' or @mat-dialog-content]"); // @FindBy(xpath = "//mat-dialog-container//div[@data-test-id='DIALOG_CONTENT' or @mat-dialog-content]")
    this.helpSubtitle = page.locator("xpath=//farmers-home-quote-discounts//span[contains(@class,'sub-title-one')]//mat-icon[contains(@class,'mid-blue')]"); // @FindBy(xpath = "//farmers-home-quote-discounts//span[contains(@class,'sub-title-one')]//mat-icon[contains(@class,'mid-blue')]")
    this.helpCEA = page.locator("xpath=//farmers-home-quote-discounts//span[starts-with(@aria-label,'California Earthquake Authority')]//mat-icon"); // @FindBy(xpath = "//farmers-home-quote-discounts//span[starts-with(@aria-label,'California Earthquake Authority')]//mat-icon")
    this.helpPreappliedTitle = page.locator("xpath=//farmers-home-quote-discounts//div[contains(@class,'prequalified-discounts-block')]//mat-icon[contains(@class,'mid-blue')]"); // @FindBy(xpath = "//farmers-home-quote-discounts//div[contains(@class,'prequalified-discounts-block')]//mat-icon[contains(@class,'mid-blue')]")
    this.helpTheftAlarm = page.locator("xpath=//ui-farmers-checkbox[@id='professionallyMonitoredTheftAlarm']//mat-icon"); // @FindBy(xpath = "//ui-farmers-checkbox[@id='professionallyMonitoredTheftAlarm']//mat-icon")
    this.helpTheftAlarmSelect = page.locator("xpath=//ui-farmers-select[contains(@data-gtm,'TheftProtection')]//mat-icon"); // @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'TheftProtection')]//mat-icon")
    this.helpFireAlarm = page.locator("xpath=//ui-farmers-checkbox[@id='professionallyMonitoredFireAlarm']//mat-icon"); // @FindBy(xpath = "//ui-farmers-checkbox[@id='professionallyMonitoredFireAlarm']//mat-icon")
    this.helpFireAlarmSelect = page.locator("xpath=//ui-farmers-select[contains(@data-gtm,'FireProtection')]//mat-icon"); // @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'FireProtection')]//mat-icon")
    this.helpWaterSensor = page.locator("xpath=//ui-farmers-checkbox[@id='waterSensor']//mat-icon"); // @FindBy(xpath = "//ui-farmers-checkbox[@id='waterSensor']//mat-icon")
    this.helpWaterSensorSelect = page.locator("xpath=//ui-farmers-select[contains(@data-gtm,'WaterLeakProtection')]//mat-icon"); // @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'WaterLeakProtection')]//mat-icon")
    this.helpFortifiedHome = page.locator("xpath=//ui-farmers-checkbox[@id='fortifiedHome']//mat-icon"); // @FindBy(xpath = "//ui-farmers-checkbox[@id='fortifiedHome']//mat-icon")
    this.helpFortifiedHomeSelect = page.locator("xpath=//ui-farmers-select[contains(@data-gtm,'FORTIFIEDHome')]//mat-icon"); // @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'FORTIFIEDHome')]//mat-icon")
    this.helpWindstormMitigationSelect = page.locator("xpath=//ui-farmers-select[contains(@data-gtm,'WindStormMitigation')]//mat-icon"); // @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'WindStormMitigation')]//mat-icon")
    this.helpCentralAlarmSelect = page.locator("xpath=//ui-farmers-select[contains(@data-gtm,'CentralAlarm')]//mat-icon"); // @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'CentralAlarm')]//mat-icon")
    this.helpDirectAlarmSelect = page.locator("xpath=//ui-farmers-select[contains(@data-gtm,'DirectAlarm')]//mat-icon"); // @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'DirectAlarm')]//mat-icon")
    this.helpLocalAlarmSelect = page.locator("xpath=//ui-farmers-select[contains(@data-gtm,'LocalAlarm')]//mat-icon"); // @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'LocalAlarm')]//mat-icon")
    this.helpAutomaticSprinklerSelect = page.locator("xpath=//ui-farmers-select[contains(@data-gtm,'AutomaticSprinklerSystem')]//mat-icon"); // @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'AutomaticSprinklerSystem')]//mat-icon")
  }
}
