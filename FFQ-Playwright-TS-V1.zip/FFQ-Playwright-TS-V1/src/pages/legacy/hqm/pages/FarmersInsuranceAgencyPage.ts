// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.FarmersInsuranceAgencyPage. */
export class FarmersInsuranceAgencyPage extends CoreBasePage {
  public readonly speakWithAgent: Locator;
  public readonly farmersLogo: Locator;
  public readonly cityStateZip: Locator;
  public readonly multiCityStateZip: Locator;
  public readonly citySelect: Locator;

  public constructor(page: Page) {
    super(page);
    this.speakWithAgent = page.locator("xpath=//header//div[contains(@class,'call-in')]"); // @FindBy(xpath = "//header//div[contains(@class,'call-in')]")
    this.farmersLogo = page.locator("xpath=//header//div[contains(@class,'logo')]/a[contains(@class,'partner-logo')]"); // @FindBy(xpath = "//header//div[contains(@class,'logo')]/a[contains(@class,'partner-logo')]")
    this.cityStateZip = page.locator("[data-legacy-field=\"cityStateZip\"]"); // @FindBy(xpath = CITY_STATE_ZIP_XPATH)
    this.multiCityStateZip = page.locator("[data-legacy-field=\"multiCityStateZip\"]"); // @FindBy(xpath = MULTI_CITY_STATE_ZIP_XPATH)
    this.citySelect = page.locator("[data-legacy-field=\"citySelect\"]"); // @FindBy(xpath = CITY_SELECT_XPATH)
  }
}
