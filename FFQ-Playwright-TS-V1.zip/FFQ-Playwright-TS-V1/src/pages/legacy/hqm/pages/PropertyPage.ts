// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.PropertyPage. */
export class PropertyPage extends CoreBasePage {
  public readonly inputYearBuilt: Locator;
  public readonly inputSquareFeet: Locator;
  public readonly helpYearBuilt: Locator;
  public readonly helpSquareFeet: Locator;
  public readonly discountSubTitleClock: Locator;
  public readonly discountSubTitlePiggy: Locator;
  public readonly discountHelpButtonPiggy: Locator;
  public readonly discountHelpDialogTitle: Locator;
  public readonly discountHelpDialogContent: Locator;
  public readonly discountCheck: Locator;
  public readonly buttonCloseDialog: Locator;
  public readonly helpDialogTitle: Locator;
  public readonly helpDialogContent: Locator;
  public readonly textPageTitle: Locator;
  public readonly textPageSubTitle: Locator;

  public constructor(page: Page) {
    super(page);
    this.inputYearBuilt = page.locator("xpath=//tui-typeahead[@id='yearBuild']//input"); // @FindBy(xpath = "//tui-typeahead[@id='yearBuild']//input")
    this.inputSquareFeet = page.locator("xpath=//div/ui-farmers-input[@fieldlabel='Total finished square feet']//input"); // @FindBy(xpath = "//div/ui-farmers-input[@fieldlabel='Total finished square feet']//input")
    this.helpYearBuilt = page.locator("xpath=//span[starts-with(@aria-label,'year built')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'year built')]//mat-icon")
    this.helpSquareFeet = page.locator("xpath=//span[starts-with(@aria-label,'Total finished square feet')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'Total finished square feet')]//mat-icon")
    this.discountSubTitleClock = page.locator("xpath=//farmers-home-quote-property//farmers-home-quote-discount-journey//img[@id='clock-img']/../p"); // @FindBy(xpath = "//farmers-home-quote-property//farmers-home-quote-discount-journey//img[@id='clock-img']/../p")
    this.discountSubTitlePiggy = page.locator("xpath=//farmers-home-quote-property//farmers-home-quote-discount-journey//img[@id='lock-img']/../p"); // @FindBy(xpath = "//farmers-home-quote-property//farmers-home-quote-discount-journey//img[@id='lock-img']/../p")
    this.discountHelpButtonPiggy = page.locator("[data-legacy-field=\"discountHelpButtonPiggy\"]"); // @FindBy(xpath = HELP_BUTTON_PIGGY_XPATH)
    this.discountHelpDialogTitle = page.locator("xpath=//farmers-home-quote-discount-journey-dialog//h4"); // @FindBy(xpath = "//farmers-home-quote-discount-journey-dialog//h4")
    this.discountHelpDialogContent = page.locator("[data-legacy-field=\"discountHelpDialogContent\"]"); // @FindBy(xpath = DISCOUNT_HELP_DIALOG_CONTENT_XPATH)
    this.discountCheck = page.locator("xpath=//farmers-home-quote-property//div[@class='djm-discount-check']/../p"); // @FindBy(xpath = "//farmers-home-quote-property//div[@class='djm-discount-check']/../p")
    this.buttonCloseDialog = page.locator("xpath=//mat-dialog-actions//button[.='CLOSE']"); // @FindBy(xpath = "//mat-dialog-actions//button[.='CLOSE']")
    this.helpDialogTitle = page.locator("xpath=//farmers-home-quote-tooltip-modal//h4"); // @FindBy(xpath = "//farmers-home-quote-tooltip-modal//h4")
    this.helpDialogContent = page.locator("xpath=//farmers-home-quote-tooltip-modal//div[@class='mat-dialog-content']"); // @FindBy(xpath = "//farmers-home-quote-tooltip-modal//div[@class='mat-dialog-content']")
    this.textPageTitle = page.locator("xpath=//farmers-home-quote-property//h1"); // @FindBy(xpath = "//farmers-home-quote-property//h1")
    this.textPageSubTitle = page.locator("xpath=//farmers-home-quote-property//span[contains(@class,'tui-subtitle-text-1')]"); // @FindBy(xpath = "//farmers-home-quote-property//span[contains(@class,'tui-subtitle-text-1')]")
  }
}
