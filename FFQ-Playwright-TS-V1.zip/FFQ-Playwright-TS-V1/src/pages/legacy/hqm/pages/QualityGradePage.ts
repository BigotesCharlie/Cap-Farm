// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.QualityGradePage. */
export class QualityGradePage extends CoreBasePage {
  public readonly radioButton: Locator;
  public readonly radioEconomy: Locator;
  public readonly cardEconomy: Locator;
  public readonly radioStandard: Locator;
  public readonly cardStandard: Locator;
  public readonly radioAboveAverage: Locator;
  public readonly cardAboveAverage: Locator;
  public readonly radioCustom: Locator;
  public readonly cardCustom: Locator;
  public readonly radioPremium: Locator;
  public readonly cardPremium: Locator;
  public readonly buttonSeeMoreDetails: Locator;
  public readonly buttonSeeLessDetails: Locator;
  public readonly helpEconomyWe: Locator;
  public readonly helpEconomyContent: Locator;
  public readonly helpStandardWe: Locator;
  public readonly helpStandardContent: Locator;
  public readonly helpAboveAverageWe: Locator;
  public readonly helpAboveAverageContent: Locator;
  public readonly helpCustomWe: Locator;
  public readonly helpCustomContent: Locator;
  public readonly helpPremiumWe: Locator;
  public readonly helpPremiumContent: Locator;
  public readonly textPageTitle: Locator;
  public readonly textPageSubTitle: Locator;
  public readonly discountSubTitleClock: Locator;
  public readonly discountSubTitlePiggy: Locator;
  public readonly discountHelpButtonPiggy: Locator;
  public readonly discountHelpDialogTitle: Locator;
  public readonly discountHelpDialogContent: Locator;
  public readonly buttonCloseDialog: Locator;

  public constructor(page: Page) {
    super(page);
    this.radioButton = page.locator("xpath=//mat-card//mat-radio-button[@radiogroup='quality']"); // @FindBy(xpath = "//mat-card//mat-radio-button[@radiogroup='quality']")
    this.radioEconomy = page.locator("xpath=//mat-card//input[@id='economy-input']"); // @FindBy(xpath = "//mat-card//input[@id='economy-input']")
    this.cardEconomy = page.locator("xpath=//mat-card[.//mat-radio-button[@id='economy']]"); // @FindBy(xpath = "//mat-card[.//mat-radio-button[@id='economy']]")
    this.radioStandard = page.locator("xpath=//mat-card//input[@id='standard-input']"); // @FindBy(xpath = "//mat-card//input[@id='standard-input']")
    this.cardStandard = page.locator("xpath=//mat-card[.//mat-radio-button[@id='standard']]"); // @FindBy(xpath = "//mat-card[.//mat-radio-button[@id='standard']]")
    this.radioAboveAverage = page.locator("xpath=//mat-card//input[@id='aboveaverage-input']"); // @FindBy(xpath = "//mat-card//input[@id='aboveaverage-input']")
    this.cardAboveAverage = page.locator("xpath=//mat-card[.//mat-radio-button[@id='aboveaverage']]"); // @FindBy(xpath = "//mat-card[.//mat-radio-button[@id='aboveaverage']]")
    this.radioCustom = page.locator("xpath=//mat-card//input[@id='custom-input']"); // @FindBy(xpath = "//mat-card//input[@id='custom-input']")
    this.cardCustom = page.locator("xpath=//mat-card[.//mat-radio-button[@id='custom']]"); // @FindBy(xpath = "//mat-card[.//mat-radio-button[@id='custom']]")
    this.radioPremium = page.locator("xpath=//mat-card//input[@id='premium-input']"); // @FindBy(xpath = "//mat-card//input[@id='premium-input']")
    this.cardPremium = page.locator("xpath=//mat-card[.//mat-radio-button[@id='premium']]"); // @FindBy(xpath = "//mat-card[.//mat-radio-button[@id='premium']]")
    this.buttonSeeMoreDetails = page.locator("xpath=//button[@id='expandCollapse' and contains(.,'See more details')]"); // @FindBy(xpath = "//button[@id='expandCollapse' and contains(.,'See more details')]")
    this.buttonSeeLessDetails = page.locator("xpath=//button[@id='expandCollapse' and contains(.,'See less details')]"); // @FindBy(xpath = "//button[@id='expandCollapse' and contains(.,'See less details')]")
    this.helpEconomyWe = page.locator("[data-legacy-field=\"helpEconomyWe\"]"); // @FindBy(xpath = HELP_ECONOMY_XPATH)
    this.helpEconomyContent = page.locator("[data-legacy-field=\"helpEconomyContent\"]"); // @FindBy(xpath = HELP_ECONOMY_XPATH+"/../p")
    this.helpStandardWe = page.locator("[data-legacy-field=\"helpStandardWe\"]"); // @FindBy(xpath = HELP_STANDARD_XPATH)
    this.helpStandardContent = page.locator("[data-legacy-field=\"helpStandardContent\"]"); // @FindBy(xpath = HELP_STANDARD_XPATH+"/../p")
    this.helpAboveAverageWe = page.locator("[data-legacy-field=\"helpAboveAverageWe\"]"); // @FindBy(xpath = HELP_ABOVE_AVERAGE_XPATH)
    this.helpAboveAverageContent = page.locator("[data-legacy-field=\"helpAboveAverageContent\"]"); // @FindBy(xpath = HELP_ABOVE_AVERAGE_XPATH+"/../p")
    this.helpCustomWe = page.locator("[data-legacy-field=\"helpCustomWe\"]"); // @FindBy(xpath = HELP_CUSTOM_XPATH)
    this.helpCustomContent = page.locator("[data-legacy-field=\"helpCustomContent\"]"); // @FindBy(xpath = HELP_CUSTOM_XPATH+"/../p")
    this.helpPremiumWe = page.locator("[data-legacy-field=\"helpPremiumWe\"]"); // @FindBy(xpath = HELP_PREMIUM_XPATH)
    this.helpPremiumContent = page.locator("[data-legacy-field=\"helpPremiumContent\"]"); // @FindBy(xpath = HELP_PREMIUM_XPATH+"/../p")
    this.textPageTitle = page.locator("xpath=//farmers-home-quality-grade//h1[@aria-label='HOW WOULD YOU DESCRIBE YOUR HOME?']"); // @FindBy(xpath = "//farmers-home-quality-grade//h1[@aria-label='HOW WOULD YOU DESCRIBE YOUR HOME?']")
    this.textPageSubTitle = page.locator("xpath=//farmers-home-quality-grade//span[@class='sub-title-one']"); // @FindBy(xpath = "//farmers-home-quality-grade//span[@class='sub-title-one']")
    this.discountSubTitleClock = page.locator("xpath=//farmers-home-quality-grade//farmers-home-quote-discount-journey//img[@id='clock-img']/../p"); // @FindBy(xpath = "//farmers-home-quality-grade//farmers-home-quote-discount-journey//img[@id='clock-img']/../p")
    this.discountSubTitlePiggy = page.locator("xpath=//farmers-home-quality-grade//farmers-home-quote-discount-journey//img[@id='lock-img']/../p"); // @FindBy(xpath = "//farmers-home-quality-grade//farmers-home-quote-discount-journey//img[@id='lock-img']/../p")
    this.discountHelpButtonPiggy = page.locator("xpath=//farmers-home-quality-grade//div[@class='discount-journey-card']//mat-icon[text()='info']"); // @FindBy(xpath ="//farmers-home-quality-grade//div[@class='discount-journey-card']//mat-icon[text()='info']")
    this.discountHelpDialogTitle = page.locator("xpath=//farmers-home-quote-discount-journey-dialog//h4"); // @FindBy(xpath = "//farmers-home-quote-discount-journey-dialog//h4")
    this.discountHelpDialogContent = page.locator("[data-legacy-field=\"discountHelpDialogContent\"]"); // @FindBy(xpath = DISCOUNT_HELP_DIALOG_CONTENT_XPATH)
    this.buttonCloseDialog = page.locator("xpath=//mat-dialog-actions//button[.='CLOSE']"); // @FindBy(xpath = "//mat-dialog-actions//button[.='CLOSE']")
  }
}
