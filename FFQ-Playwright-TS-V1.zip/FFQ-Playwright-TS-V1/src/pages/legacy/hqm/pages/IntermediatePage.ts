// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.IntermediatePage. */
export class IntermediatePage extends CoreBasePage {
  public readonly pageTitle: Locator;
  public readonly buttonStartMyQuote: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageTitle = page.locator("xpath=//*[@id='quote_unavailable-content']//h2"); // @FindBy(xpath = "//*[@id='quote_unavailable-content']//h2")
    this.buttonStartMyQuote = page.locator("xpath=//button[contains(text(),'Start my quote')]"); // @FindBy(xpath = "//button[contains(text(),'Start my quote')]")
  }
}
