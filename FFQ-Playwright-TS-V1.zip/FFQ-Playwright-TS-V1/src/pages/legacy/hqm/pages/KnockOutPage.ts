// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.KnockOutPage. */
export class KnockOutPage extends CoreBasePage {
  public readonly linkFarmersLogo: Locator;
  public readonly pageTitle: Locator;
  public readonly pageSubTitle1: Locator;
  public readonly pageSubTitle: Locator;
  public readonly pageSubTitle2: Locator;
  public readonly pageFooter1: Locator;
  public readonly pageFooter2: Locator;
  public readonly pageFooter3: Locator;
  public readonly buttonToStartMyQuote: Locator;
  public readonly agentNameFooter: Locator;
  public readonly agentInfoFooter: Locator;
  public readonly agentImage: Locator;
  public readonly agentEmailAddress: Locator;
  public readonly agentPhoneNumber: Locator;
  public readonly agentAddress: Locator;

  public constructor(page: Page) {
    super(page);
    this.linkFarmersLogo = page.locator("xpath=//farmers-home-quote-knockouts//div//img"); // @FindBy(xpath = "//farmers-home-quote-knockouts//div//img")
    this.pageTitle = page.locator("xpath=//farmers-home-quote-knockouts//h1"); // @FindBy(xpath = "//farmers-home-quote-knockouts//h1")
    this.pageSubTitle1 = page.locator("xpath=//farmers-home-quote-knockouts//span[contains(@class,'sub-title-one') and not(strong)]"); // @FindBy(xpath = "//farmers-home-quote-knockouts//span[contains(@class,'sub-title-one') and not(strong)]")
    this.pageSubTitle = page.locator("xpath=//farmers-home-quote-knockouts//div[contains(@class,'tui-subtitle-text-1')]/.."); // @FindBy(xpath = "//farmers-home-quote-knockouts//div[contains(@class,'tui-subtitle-text-1')]/..")
    this.pageSubTitle2 = page.locator("xpath=//farmers-home-quote-knockouts//span[contains(@class,'sub-title-one') and strong]"); // @FindBy(xpath = "//farmers-home-quote-knockouts//span[contains(@class,'sub-title-one') and strong]")
    this.pageFooter1 = page.locator("[data-legacy-field=\"pageFooter1\"]"); // @FindBy(xpath = NEED_MORE_HELP)
    this.pageFooter2 = page.locator("xpath=//farmers-home-quote-knockouts//div/p[contains(@class,'quote-agent-info-label')]"); // @FindBy(xpath = "//farmers-home-quote-knockouts//div/p[contains(@class,'quote-agent-info-label')]")
    this.pageFooter3 = page.locator("xpath=//farmers-home-quote-knockouts//div//a[starts-with(@href,'tel:1-8')]"); // @FindBy(xpath = "//farmers-home-quote-knockouts//div//a[starts-with(@href,'tel:1-8')]")
    this.buttonToStartMyQuote = page.locator("[data-legacy-field=\"buttonToStartMyQuote\"]"); // @FindBy(xpath = BUTTON_TO_START_PARTNER_QUOTE)
    this.agentNameFooter = page.locator("xpath=//farmers-home-quote-knockouts//farmers-home-quote-agent-info//div/span[contains(@class,'quote-agent-name')]"); // @FindBy(xpath = "//farmers-home-quote-knockouts//farmers-home-quote-agent-info//div/span[contains(@class,'quote-agent-name')]")
    this.agentInfoFooter = page.locator("xpath=//farmers-home-quote-knockouts//span[contains(@class,'quote-agent-p')]"); // @FindBy(xpath = "//farmers-home-quote-knockouts//span[contains(@class,'quote-agent-p')]")
    this.agentImage = page.locator("xpath=//farmers-home-quote-knockouts//img[contains(@class,'agent-img')]"); // @FindBy(xpath = "//farmers-home-quote-knockouts//img[contains(@class,'agent-img')]")
    this.agentEmailAddress = page.locator("xpath=//farmers-home-quote-knockouts//a[starts-with(@href,'mailto:')]//"); // @FindBy(xpath = "//farmers-home-quote-knockouts//a[starts-with(@href,'mailto:')]//" +             "div[contains(@class,'body-two')]")
    this.agentPhoneNumber = page.locator("xpath=//farmers-home-quote-knockouts//a[@id='phnTagId']//span[contains(@class,'body-two')]"); // @FindBy(xpath = "//farmers-home-quote-knockouts//a[@id='phnTagId']//span[contains(@class,'body-two')]")
    this.agentAddress = page.locator("xpath=//farmers-home-quote-knockouts//a[@id='locTagId']//span[contains(@class,'body-two')]"); // @FindBy(xpath = "//farmers-home-quote-knockouts//a[@id='locTagId']//span[contains(@class,'body-two')]")
  }
}
