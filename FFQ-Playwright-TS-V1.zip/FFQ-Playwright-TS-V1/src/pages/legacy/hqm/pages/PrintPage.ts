// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.PrintPage. */
export class PrintPage extends CoreBasePage {
  public readonly imgFarmersLogo: Locator;
  public readonly iconPrint: Locator;
  public readonly textQuoteNumber: Locator;
  public readonly textMonthlyPremium: Locator;
  public readonly textYearlyPremium: Locator;
  public readonly coverageDwelling: Locator;
  public readonly coverageSeparateStructures: Locator;
  public readonly coveragePersonalProperty: Locator;
  public readonly coverageExtendedReplacementCost: Locator;
  public readonly liabilityPersonalLiability: Locator;
  public readonly liabilityMedicalPaymentsToOthers: Locator;
  public readonly deductibleAllPeril: Locator;
  public readonly deductibleWindHail: Locator;
  public readonly deductibleHurricane: Locator;
  public readonly deductibleWater: Locator;
  public readonly pageTitle: Locator;
  public readonly pageSubTitle: Locator;
  public readonly textNeedHelp: Locator;
  public readonly textNeedHelpSubtitle: Locator;
  public readonly textNeedHelpSubtitleAgent: Locator;
  public readonly imgAgent: Locator;
  public readonly fullNameAgent: Locator;
  public readonly emailAgent: Locator;
  public readonly emailAgentMobile: Locator;
  public readonly phoneAgent: Locator;
  public readonly phoneAgentMobile: Locator;
  public readonly placeAgent: Locator;
  public readonly placeAgentMobile: Locator;
  public readonly phoneNumberPA: Locator;
  public readonly policyPerksTitle: Locator;
  public readonly policyPerksHeader: Locator;
  public readonly policyPerksHeaderLink: Locator;

  public constructor(page: Page) {
    super(page);
    this.imgFarmersLogo = page.locator("xpath=//farmers-print-home//mat-card//img[@alt='Farmers Insurance Logo']"); // @FindBy(xpath = "//farmers-print-home//mat-card//img[@alt='Farmers Insurance Logo']")
    this.iconPrint = page.locator("xpath=//farmers-print-home//mat-icon[text()='print']"); // @FindBy(xpath = "//farmers-print-home//mat-icon[text()='print']")
    this.textQuoteNumber = page.locator("xpath=//farmers-print-home//p[contains(@class,'tui-subtitle-text-1')]//*[starts-with(text(),'Quote #')]"); // @FindBy(xpath = "//farmers-print-home//p[contains(@class,'tui-subtitle-text-1')]//*[starts-with(text(),'Quote #')]")
    this.textMonthlyPremium = page.locator("xpath=//farmers-print-home//div/h3[text()='Home Insurance']/../div[contains(@class,'insurance-cost-block')]/strong"); // @FindBy(xpath = "//farmers-print-home//div/h3[text()='Home Insurance']/../div[contains(@class,'insurance-cost-block')]/strong")
    this.textYearlyPremium = page.locator("xpath=//farmers-print-home//div/h3[text()='Home Insurance']/../div[contains(@class,'insurance-cost-block')]/span"); // @FindBy(xpath = "//farmers-print-home//div/h3[text()='Home Insurance']/../div[contains(@class,'insurance-cost-block')]/span")
    this.coverageDwelling = page.locator("xpath=//farmers-print-home//div/h4[text()='Property Coverages']/../div//p[contains(text(),'Dwelling')]/../p[2]"); // @FindBy(xpath = "//farmers-print-home//div/h4[text()='Property Coverages']/../div//p[contains(text(),'Dwelling')]/../p[2]")
    this.coverageSeparateStructures = page.locator("xpath=//farmers-print-home//div/h4[text()='Property Coverages']/../div//p[contains(text(),'Separate Structures')]/../p[2]"); // @FindBy(xpath = "//farmers-print-home//div/h4[text()='Property Coverages']/../div//p[contains(text(),'Separate Structures')]/../p[2]")
    this.coveragePersonalProperty = page.locator("xpath=//farmers-print-home//div/h4[text()='Property Coverages']/../div//p[contains(text(),'Personal Property')]/../p[2]"); // @FindBy(xpath = "//farmers-print-home//div/h4[text()='Property Coverages']/../div//p[contains(text(),'Personal Property')]/../p[2]")
    this.coverageExtendedReplacementCost = page.locator("xpath=//farmers-print-home//div/h4[text()='Property Coverages']/../div//p[contains(text(),'Extended Replacement Cost')]/../p[2]"); // @FindBy(xpath = "//farmers-print-home//div/h4[text()='Property Coverages']/../div//p[contains(text(),'Extended Replacement Cost')]/../p[2]")
    this.liabilityPersonalLiability = page.locator("xpath=//farmers-print-home//div/h4[text()='Liability']/../div//p[contains(text(),'Personal Liability')]/../p[2]"); // @FindBy(xpath = "//farmers-print-home//div/h4[text()='Liability']/../div//p[contains(text(),'Personal Liability')]/../p[2]")
    this.liabilityMedicalPaymentsToOthers = page.locator("xpath=//farmers-print-home//div/h4[text()='Liability']/../div//p[contains(text(),'Medical Payments to Others')]/../p[2]"); // @FindBy(xpath = "//farmers-print-home//div/h4[text()='Liability']/../div//p[contains(text(),'Medical Payments to Others')]/../p[2]")
    this.deductibleAllPeril = page.locator("xpath=//farmers-print-home//div/h4[text()='Deductibles']/../div//p[contains(text(),'All Peril Losses') or "); // @FindBy(xpath = "//farmers-print-home//div/h4[text()='Deductibles']/../div//p[contains(text(),'All Peril Losses') or " +             "contains(text(),'All Other Peril Losses')]/../p[2]")
    this.deductibleWindHail = page.locator("xpath=//farmers-print-home//div/h4[text()='Deductibles']/../div//p[contains(text(),'Wind & Hail Losses')]/../p[2]"); // @FindBy(xpath = "//farmers-print-home//div/h4[text()='Deductibles']/../div//p[contains(text(),'Wind & Hail Losses')]/../p[2]")
    this.deductibleHurricane = page.locator("xpath=//farmers-print-home//div/h4[text()='Deductibles']/../div//p[contains(text(),'Hurricane Losses')]/../p[2]"); // @FindBy(xpath = "//farmers-print-home//div/h4[text()='Deductibles']/../div//p[contains(text(),'Hurricane Losses')]/../p[2]")
    this.deductibleWater = page.locator("xpath=//farmers-print-home//div/h4[text()='Deductibles']/../div//p[contains(text(),'Water Losses')]/../p[2]"); // @FindBy(xpath = "//farmers-print-home//div/h4[text()='Deductibles']/../div//p[contains(text(),'Water Losses')]/../p[2]")
    this.pageTitle = page.locator("xpath=//farmers-print-home//h2"); // @FindBy(xpath = "//farmers-print-home//h2")
    this.pageSubTitle = page.locator("xpath=//farmers-print-home//div[contains(@class,'print-personal-info')]/p[contains(@class,'tui-subtitle-text-1')]"); // @FindBy(xpath = "//farmers-print-home//div[contains(@class,'print-personal-info')]/p[contains(@class,'tui-subtitle-text-1')]")
    this.textNeedHelp = page.locator("xpath=//farmers-print-home//div[contains(@class,'need-help-caption')]"); // @FindBy(xpath = "//farmers-print-home//div[contains(@class,'need-help-caption')]")
    this.textNeedHelpSubtitle = page.locator("xpath=//farmers-print-home//div[@class='need-help-caption']/../p[contains(@class,'need-help-paragraph')]"); // @FindBy(xpath = "//farmers-print-home//div[@class='need-help-caption']/../p[contains(@class,'need-help-paragraph')]")
    this.textNeedHelpSubtitleAgent = page.locator("xpath=//farmers-print-home//div[@class='need-help-caption']/../div[@class='tui-caption-text']"); // @FindBy(xpath = "//farmers-print-home//div[@class='need-help-caption']/../div[@class='tui-caption-text']")
    this.imgAgent = page.locator("xpath=//farmers-print-home//div[@class='agent-img']/img"); // @FindBy(xpath = "//farmers-print-home//div[@class='agent-img']/img")
    this.fullNameAgent = page.locator("xpath=//farmers-print-home//div[@class='agent-img']/..//div/div[contains(@class,'need-help-caption')]"); // @FindBy(xpath = "//farmers-print-home//div[@class='agent-img']/..//div/div[contains(@class,'need-help-caption')]")
    this.emailAgent = page.locator("xpath=//farmers-print-home//mat-icon[text()='email']/../div[contains(@class,'body-two')]"); // @FindBy(xpath = "//farmers-print-home//mat-icon[text()='email']/../div[contains(@class,'body-two')]")
    this.emailAgentMobile = page.locator("xpath=//farmers-print-home//mat-icon[text()='email']/../../div[contains(@class,'body-two')]"); // @FindBy(xpath = "//farmers-print-home//mat-icon[text()='email']/../../div[contains(@class,'body-two')]")
    this.phoneAgent = page.locator("xpath=//farmers-print-home//mat-icon[text()='phone']/../span[contains(@class,'body-two')]"); // @FindBy(xpath = "//farmers-print-home//mat-icon[text()='phone']/../span[contains(@class,'body-two')]")
    this.phoneAgentMobile = page.locator("xpath=//farmers-print-home//mat-icon[text()='phone']/../../span[contains(@class,'body-two')]"); // @FindBy(xpath = "//farmers-print-home//mat-icon[text()='phone']/../../span[contains(@class,'body-two')]")
    this.placeAgent = page.locator("xpath=//farmers-print-home//mat-icon[text()='place']/../div[contains(@class,'body-two')]"); // @FindBy(xpath = "//farmers-print-home//mat-icon[text()='place']/../div[contains(@class,'body-two')]")
    this.placeAgentMobile = page.locator("xpath=//farmers-print-home//mat-icon[text()='place']/../../div[contains(@class,'body-two')]"); // @FindBy(xpath = "//farmers-print-home//mat-icon[text()='place']/../../div[contains(@class,'body-two')]")
    this.phoneNumberPA = page.locator("xpath=//farmers-print-home//mat-icon[text()='phone']/../../span[contains(@class,'quote-agent-info-label')]"); // @FindBy(xpath = "//farmers-print-home//mat-icon[text()='phone']/../../span[contains(@class,'quote-agent-info-label')]")
    this.policyPerksTitle = page.locator("xpath=//farmers-home-quote-policy-perks//div[contains(@class,'perk-title')]/img"); // @FindBy(xpath = "//farmers-home-quote-policy-perks//div[contains(@class,'perk-title')]/img")
    this.policyPerksHeader = page.locator("xpath=//farmers-home-quote-policy-perks//p[contains(@class,'tui-text-prominent')]"); // @FindBy(xpath = "//farmers-home-quote-policy-perks//p[contains(@class,'tui-text-prominent')]")
    this.policyPerksHeaderLink = page.locator("[data-legacy-field=\"policyPerksHeaderLink\"]"); // @FindBy(xpath = POLICY_PERKS_HEADER_LINK_XPATH)
  }
}
