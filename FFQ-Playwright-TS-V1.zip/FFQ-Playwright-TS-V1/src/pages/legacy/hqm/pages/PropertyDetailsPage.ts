// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.PropertyDetailsPage. */
export class PropertyDetailsPage extends CoreBasePage {
  public readonly selectNumberOfStories: Locator;
  public readonly dropdownOptionElement: Locator;
  public readonly selectFoundationType: Locator;
  public readonly selectHeatingSystem: Locator;
  public readonly selectListOptionsWe: Locator;
  public readonly inputFinishedPercent: Locator;
  public readonly readyInputFinishedPercent: Locator;
  public readonly errorInputFinishedPercent: Locator;
  public readonly selectExteriorWallFinish: Locator;
  public readonly selectListElementAny: Locator;
  public readonly selectRoofCover: Locator;
  public readonly selectSolarPanels: Locator;
  public readonly selectTrampoline: Locator;
  public readonly selectPoolOnPremises: Locator;
  public readonly cardItemDescription: Locator;
  public readonly selectListRadiosWe: Locator;
  public readonly doneDialogButton: Locator;
  public readonly selectFireplaces: Locator;
  public readonly selectGarageCarport: Locator;
  public readonly selectGarageStyle: Locator;
  public readonly undergroundOilTank: Locator;
  public readonly poolHotTubOnPremises: Locator;
  public readonly unitsAttached: Locator;
  public readonly helpDialogTitle: Locator;
  public readonly helpDialogContent: Locator;
  public readonly helpNumberOfStories: Locator;
  public readonly helpFoundationType: Locator;
  public readonly helpFinishedPercent: Locator;
  public readonly helpExteriorWallFinish: Locator;
  public readonly helpRoofCover: Locator;
  public readonly helpFloorCovering: Locator;
  public readonly helpHeatingSystem: Locator;
  public readonly helpFireplaces: Locator;
  public readonly helpGarageCarport: Locator;
  public readonly helpGarageStyle: Locator;
  public readonly helpUndergroundOilTank: Locator;
  public readonly helpNumberUfUnitsAttached: Locator;
  public readonly buttonCloseDialog: Locator;
  public readonly discountSubTitleLock: Locator;
  public readonly discountSubTitlePiggy: Locator;
  public readonly discountHelpButtonPiggy: Locator;
  public readonly discountHelpDialogTitle: Locator;
  public readonly discountHelpDialogContent: Locator;
  public readonly textPageTitle: Locator;
  public readonly textPageSubTitle: Locator;
  public readonly textPageCardSubtitle: Locator;

  public constructor(page: Page) {
    super(page);
    this.selectNumberOfStories = page.locator("xpath=//mat-select[contains(@id,'numberOfStories')]"); // @FindBy(xpath = "//mat-select[contains(@id,'numberOfStories')]")
    this.dropdownOptionElement = page.locator("[data-legacy-field=\"dropdownOptionElement\"]"); // @FindBy(xpath = SELECT_OPTION_XPATH)
    this.selectFoundationType = page.locator("xpath=//mat-select[@formcontrolname='foundationType']"); // @FindBy(xpath = "//mat-select[@formcontrolname='foundationType']")
    this.selectHeatingSystem = page.locator("xpath=//mat-select[@formcontrolname='heatingSystem']"); // @FindBy(xpath = "//mat-select[@formcontrolname='heatingSystem']")
    this.selectListOptionsWe = page.locator("[data-legacy-field=\"selectListOptionsWe\"]"); // @FindBy(xpath = LIST_OPTIONS_XPATH)
    this.inputFinishedPercent = page.locator("[data-legacy-field=\"inputFinishedPercent\"]"); // @FindBy(xpath = FINISHED_PERCENT_XPATH)
    this.readyInputFinishedPercent = page.locator("[data-legacy-field=\"readyInputFinishedPercent\"]"); // @FindBy(xpath = READY_FINISHED_PERCENT_XPATH)
    this.errorInputFinishedPercent = page.locator("[data-legacy-field=\"errorInputFinishedPercent\"]"); // @FindBy(xpath = ERROR_FINISHED_PERCENT_XPATH)
    this.selectExteriorWallFinish = page.locator("xpath=//mat-select[@formcontrolname='exteriorWallFinish']"); // @FindBy(xpath = "//mat-select[@formcontrolname='exteriorWallFinish']")
    this.selectListElementAny = page.locator("[data-legacy-field=\"selectListElementAny\"]"); // @FindBy(xpath = SELECT_LIST_ITEMS_ANY_XPATH)
    this.selectRoofCover = page.locator("xpath=//mat-select[@formcontrolname='roofCover']"); // @FindBy(xpath = "//mat-select[@formcontrolname='roofCover']")
    this.selectSolarPanels = page.locator("xpath=//mat-select[@id='solarPanelQuestion_matselect']"); // @FindBy(xpath = "//mat-select[@id='solarPanelQuestion_matselect']")
    this.selectTrampoline = page.locator("xpath=//mat-select[@id='trampolineQuestion_matselect']"); // @FindBy(xpath = "//mat-select[@id='trampolineQuestion_matselect']")
    this.selectPoolOnPremises = page.locator("xpath=//mat-select[@id='onlyPoolQuestion_matselect']"); // @FindBy(xpath = "//mat-select[@id='onlyPoolQuestion_matselect']")
    this.cardItemDescription = page.locator("[data-legacy-field=\"cardItemDescription\"]"); // @FindBy(xpath = CARD_ITEM_DESCRIPTION_XPATH)
    this.selectListRadiosWe = page.locator("[data-legacy-field=\"selectListRadiosWe\"]"); // @FindBy(xpath = LIST_RADIOS_XPATH)
    this.doneDialogButton = page.locator("[data-legacy-field=\"doneDialogButton\"]"); // @FindBy(xpath = DONE_BUTTON_XPATH)
    this.selectFireplaces = page.locator("xpath=//mat-select[@id='firePlaces_matselect']"); // @FindBy(xpath = "//mat-select[@id='firePlaces_matselect']")
    this.selectGarageCarport = page.locator("[data-legacy-field=\"selectGarageCarport\"]"); // @FindBy(xpath = GARAGE_CARPORT_XPATH)
    this.selectGarageStyle = page.locator("[data-legacy-field=\"selectGarageStyle\"]"); // @FindBy(xpath = GARAGE_STYLE_XPATH)
    this.undergroundOilTank = page.locator("[data-legacy-field=\"undergroundOilTank\"]"); // @FindBy(xpath = OIL_TANK_ONPREMISES_XPATH)
    this.poolHotTubOnPremises = page.locator("[data-legacy-field=\"poolHotTubOnPremises\"]"); // @FindBy(xpath = POOL_HOT_TUB_ONPREMISES_XPATH)
    this.unitsAttached = page.locator("[data-legacy-field=\"unitsAttached\"]"); // @FindBy(xpath = UNITS_ATTACHED_XPATH)
    this.helpDialogTitle = page.locator("xpath=//farmers-home-quote-tooltip-modal//h4"); // @FindBy(xpath = "//farmers-home-quote-tooltip-modal//h4")
    this.helpDialogContent = page.locator("xpath=//farmers-home-quote-tooltip-modal//div[@class='mat-dialog-content']"); // @FindBy(xpath = "//farmers-home-quote-tooltip-modal//div[@class='mat-dialog-content']")
    this.helpNumberOfStories = page.locator("xpath=//span[starts-with(@aria-label,'Number of stories')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'Number of stories')]//mat-icon")
    this.helpFoundationType = page.locator("xpath=//span[starts-with(@aria-label,'Foundation type')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'Foundation type')]//mat-icon")
    this.helpFinishedPercent = page.locator("xpath=//span[starts-with(@aria-label,'Finished Percentage of Lowest Level')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'Finished Percentage of Lowest Level')]//mat-icon")
    this.helpExteriorWallFinish = page.locator("xpath=//span[starts-with(@aria-label,'Exterior wall finish')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'Exterior wall finish')]//mat-icon")
    this.helpRoofCover = page.locator("xpath=//span[starts-with(@aria-label,'Roof Cover')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'Roof Cover')]//mat-icon")
    this.helpFloorCovering = page.locator("xpath=//span[starts-with(@aria-label,'Floor covering')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'Floor covering')]//mat-icon")
    this.helpHeatingSystem = page.locator("xpath=//span[starts-with(@aria-label,'Heating system')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'Heating system')]//mat-icon")
    this.helpFireplaces = page.locator("xpath=//span[starts-with(@aria-label,'Fireplace(s)')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'Fireplace(s)')]//mat-icon")
    this.helpGarageCarport = page.locator("xpath=//span[starts-with(@aria-label,'Garage/Carport')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'Garage/Carport')]//mat-icon")
    this.helpGarageStyle = page.locator("xpath=//span[starts-with(@aria-label,'Garage Style')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'Garage Style')]//mat-icon")
    this.helpUndergroundOilTank = page.locator("xpath=//span[starts-with(@aria-label,'Underground Oil Tank')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'Underground Oil Tank')]//mat-icon")
    this.helpNumberUfUnitsAttached = page.locator("xpath=//span[starts-with(@aria-label,'How many units are attached')]//mat-icon"); // @FindBy(xpath = "//span[starts-with(@aria-label,'How many units are attached')]//mat-icon")
    this.buttonCloseDialog = page.locator("xpath=//mat-dialog-actions//button[.='CLOSE']"); // @FindBy(xpath = "//mat-dialog-actions//button[.='CLOSE']")
    this.discountSubTitleLock = page.locator("xpath=//farmers-home-quote-property-details//farmers-home-quote-discount-journey//img[@id='clock-img']/../p"); // @FindBy(xpath = "//farmers-home-quote-property-details//farmers-home-quote-discount-journey//img[@id='clock-img']/../p")
    this.discountSubTitlePiggy = page.locator("xpath=//farmers-home-quote-property-details//farmers-home-quote-discount-journey//img[@id='lock-img']/../p"); // @FindBy(xpath = "//farmers-home-quote-property-details//farmers-home-quote-discount-journey//img[@id='lock-img']/../p")
    this.discountHelpButtonPiggy = page.locator("xpath=//farmers-home-quote-property-details//div[@class='discount-journey-card']//mat-icon[text()='info']"); // @FindBy(xpath ="//farmers-home-quote-property-details//div[@class='discount-journey-card']//mat-icon[text()='info']")
    this.discountHelpDialogTitle = page.locator("xpath=//farmers-home-quote-discount-journey-dialog//h4"); // @FindBy(xpath = "//farmers-home-quote-discount-journey-dialog//h4")
    this.discountHelpDialogContent = page.locator("[data-legacy-field=\"discountHelpDialogContent\"]"); // @FindBy(xpath = CONTENT_XPATH)
    this.textPageTitle = page.locator("xpath=//farmers-home-quote-property-details//h1[@id='header-text']"); // @FindBy(xpath = "//farmers-home-quote-property-details//h1[@id='header-text']")
    this.textPageSubTitle = page.locator("xpath=//farmers-home-quote-property-details//span[contains(@class,'tui-subtitle-text-1')]"); // @FindBy(xpath = "//farmers-home-quote-property-details//span[contains(@class,'tui-subtitle-text-1')]")
    this.textPageCardSubtitle = page.locator("xpath=//farmers-home-quote-property-details//ui-farmers-card//p[contains(@class,'sub-title-one')]"); // @FindBy(xpath = "//farmers-home-quote-property-details//ui-farmers-card//p[contains(@class,'sub-title-one')]")
  }
}
