// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.FarmersChoicePage. */
export class FarmersChoicePage extends CoreBasePage {
  public readonly pageTitle: Locator;
  public readonly partnerLogo: Locator;
  public readonly farmersHeroTitle: Locator;
  public readonly farmersProducts: Locator;
  public readonly inputZip: Locator;
  public readonly buttonToStartQuote: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageTitle = page.locator("xpath=//div//nav[@data-topbar]//a[contains(@class,'logo')]"); // @FindBy(xpath = "//div//nav[@data-topbar]//a[contains(@class,'logo')]")
    this.partnerLogo = page.locator("xpath=//div//nav[@data-topbar]//a[contains(@class,'partner-logo')]"); // @FindBy(xpath = "//div//nav[@data-topbar]//a[contains(@class,'partner-logo')]")
    this.farmersHeroTitle = page.locator("[data-legacy-field=\"farmersHeroTitle\"]"); // @FindBy(xpath = XPATH_HERO)
    this.farmersProducts = page.locator("[data-legacy-field=\"farmersProducts\"]"); // @FindBy(xpath = XPATH_PRODUCTS)
    this.inputZip = page.locator("[data-legacy-field=\"inputZip\"]"); // @FindBy(xpath = XPATH_ZIP)
    this.buttonToStartQuote = page.locator("[data-legacy-field=\"buttonToStartQuote\"]"); // @FindBy(xpath = XPATH_START_QUOTE)
  }
}
