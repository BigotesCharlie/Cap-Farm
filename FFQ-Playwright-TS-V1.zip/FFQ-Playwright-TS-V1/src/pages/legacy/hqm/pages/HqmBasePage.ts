// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.HqmBasePage. */
export class HqmBasePage extends CoreBasePage {
  public readonly buttonNext: Locator;
  public readonly buttonAgreeAndSubmit: Locator;
  public readonly buttonBack: Locator;
  public readonly summaryMobileIcon: Locator;
  public readonly summaryIcon: Locator;
  public readonly closeMenu: Locator;
  public readonly sideDrawer: Locator;
  public readonly sideDrawerCollapsed: Locator;
  public readonly stepperAddressHeader: Locator;
  public readonly stepperAddress: Locator;
  public readonly stepperAddressMobileDiv: Locator;
  public readonly stepperAddressMobile: Locator;
  public readonly stepperPropertyHeader: Locator;
  public readonly stepperProperty: Locator;
  public readonly stepperPropertyMobileDiv: Locator;
  public readonly stepperPropertyMobile: Locator;
  public readonly stepperPersonalInfoHeader: Locator;
  public readonly stepperPersonalInfo: Locator;
  public readonly stepperQuoteHeader: Locator;
  public readonly stepperQuote: Locator;
  public readonly txtQuoteNumber: Locator;
  public readonly btnCloseSurveyPopup: Locator;
  public readonly linkPersonalInfoUse: Locator;
  public readonly linkSaveQuote: Locator;
  public readonly inputEmailSaveFinishLaterDialog: Locator;
  public readonly needHelpText: Locator;
  public readonly linkCallFarmers: Locator;
  public readonly linkContactUs: Locator;
  public readonly linkCallUs: Locator;
  public readonly linkTermsOfUse: Locator;
  public readonly linkPrivacyPolicy: Locator;
  public readonly linkYourPrivacyChoices: Locator;
  public readonly modalPrivacyChoicesTitle: Locator;
  public readonly modalPrivacyChoicesSaveButton: Locator;
  public readonly modalPrivacyChoicesCloseButton: Locator;
  public readonly textQuoteSummary: Locator;
  public readonly linkPrivacyPolicyNext: Locator;
  public readonly linkNoticeOfInformationPractices: Locator;
  public readonly linkNoticeOfInformationPracticesCA: Locator;
  public readonly linkDigiCert: Locator;
  public readonly agentNameSide: Locator;
  public readonly agentName: Locator;
  public readonly agentImageSide: Locator;
  public readonly agentImage: Locator;
  public readonly localAgentTextSide: Locator;
  public readonly localAgentText: Locator;
  public readonly learnMoreLink: Locator;
  public readonly agentEmailIconSide: Locator;
  public readonly agentEmailIcon: Locator;
  public readonly agentEmailTextSide: Locator;
  public readonly agentEmailText: Locator;
  public readonly agentPhoneIconSide: Locator;
  public readonly agentPhoneIcon: Locator;
  public readonly agentPhoneNumberSide: Locator;
  public readonly agentPhoneNumber: Locator;
  public readonly agentAddressIconSide: Locator;
  public readonly agentAddressIcon: Locator;
  public readonly agentAddressTextSide: Locator;
  public readonly agentAddressText: Locator;
  public readonly agentInfoSection: Locator;
  public readonly retrieveDialog: Locator;
  public readonly retrieveDialogContinueBtn: Locator;
  public readonly textSaveFinishLaterDialogTitle: Locator;
  public readonly textSaveFinishLaterDialogSubTitle: Locator;
  public readonly btnContinueSaveFinishLaterDialog: Locator;
  public readonly btnSaveExitSaveFinishLaterDialog: Locator;

  public constructor(page: Page) {
    super(page);
    this.buttonNext = page.locator("[data-legacy-field=\"buttonNext\"]"); // @FindBy(xpath = NEXT_BUTTON_XPATH)
    this.buttonAgreeAndSubmit = page.locator("[data-legacy-field=\"buttonAgreeAndSubmit\"]"); // @FindBy(xpath = AGREE_N_SUBMIT_BUTTON_XPATH)
    this.buttonBack = page.locator("[data-legacy-field=\"buttonBack\"]"); // @FindBy(xpath = BACK_BUTTON_XPATH)
    this.summaryMobileIcon = page.locator("[data-legacy-field=\"summaryMobileIcon\"]"); // @FindBy(xpath = XPATH_SUMMARY_MOBILE_ICON)
    this.summaryIcon = page.locator("[data-legacy-field=\"summaryIcon\"]"); // @FindBy(xpath = XPATH_SUMMARY_ICON)
    this.closeMenu = page.locator("xpath=//mat-drawer//mat-icon[text()='close']"); // @FindBy(xpath = "//mat-drawer//mat-icon[text()='close']")
    this.sideDrawer = page.locator("xpath=//mat-drawer[contains(@class,'sidenav')]"); // @FindBy(xpath = "//mat-drawer[contains(@class,'sidenav')]")
    this.sideDrawerCollapsed = page.locator("[data-legacy-field=\"sideDrawerCollapsed\"]"); // @FindBy(xpath = sideDrawerCollapsedXpath)
    this.stepperAddressHeader = page.locator("xpath=//mat-drawer//mat-step-header[.//span[@id='address']]"); // @FindBy(xpath = "//mat-drawer//mat-step-header[.//span[@id='address']]")
    this.stepperAddress = page.locator("[data-legacy-field=\"stepperAddress\"]"); // @FindBy(xpath = STEPPER_ADDRESS_XPATH)
    this.stepperAddressMobileDiv = page.locator("[data-legacy-field=\"stepperAddressMobileDiv\"]"); // @FindBy(xpath = STEPPER_ADDRESS_MOBILE_DIV_XPATH)
    this.stepperAddressMobile = page.locator("[data-legacy-field=\"stepperAddressMobile\"]"); // @FindBy(xpath = STEPPER_ADDRESS_MOBILE_XPATH)
    this.stepperPropertyHeader = page.locator("xpath=//mat-drawer//mat-step-header[.//span[@id='property']]"); // @FindBy(xpath = "//mat-drawer//mat-step-header[.//span[@id='property']]")
    this.stepperProperty = page.locator("[data-legacy-field=\"stepperProperty\"]"); // @FindBy(xpath = STEPPER_PROPERTY_XPATH)
    this.stepperPropertyMobileDiv = page.locator("[data-legacy-field=\"stepperPropertyMobileDiv\"]"); // @FindBy(xpath = STEPPER_PROPERTY_MOBILE_DIV_XPATH)
    this.stepperPropertyMobile = page.locator("[data-legacy-field=\"stepperPropertyMobile\"]"); // @FindBy(xpath = STEPPER_PROPERTY_MOBILE_XPATH)
    this.stepperPersonalInfoHeader = page.locator("xpath=//mat-drawer//mat-step-header[.//span[@id='personalInfo']]"); // @FindBy(xpath = "//mat-drawer//mat-step-header[.//span[@id='personalInfo']]")
    this.stepperPersonalInfo = page.locator("[data-legacy-field=\"stepperPersonalInfo\"]"); // @FindBy(xpath = STEPPER_PERSONAL_INFO_XPATH)
    this.stepperQuoteHeader = page.locator("xpath=//mat-drawer//mat-step-header[.//span[@id='quotesection']]"); // @FindBy(xpath = "//mat-drawer//mat-step-header[.//span[@id='quotesection']]")
    this.stepperQuote = page.locator("[data-legacy-field=\"stepperQuote\"]"); // @FindBy(xpath = STEPPER_QUOTE_XPATH)
    this.txtQuoteNumber = page.locator("xpath=//mat-drawer//span[contains(@class,'quote-summary')]"); // @FindBy(xpath = "//mat-drawer//span[contains(@class,'quote-summary')]")
    this.btnCloseSurveyPopup = page.locator("xpath=//div[contains(@class,'PopOverContainer')]//img[contains(@src,'close-btn')]"); // @FindBy(xpath = "//div[contains(@class,'PopOverContainer')]//img[contains(@src,'close-btn')]")
    this.linkPersonalInfoUse = page.locator("[data-legacy-field=\"linkPersonalInfoUse\"]"); // @FindBy(xpath = PERSONAL_INFO_USE_XPATH)
    this.linkSaveQuote = page.locator("[data-legacy-field=\"linkSaveQuote\"]"); // @FindBy(xpath = SAVE_QUOTE_XPATH)
    this.inputEmailSaveFinishLaterDialog = page.locator("[data-legacy-field=\"inputEmailSaveFinishLaterDialog\"]"); // @FindBy(xpath = INPUT_EMAIL_SAFL_XPATH)
    this.needHelpText = page.locator("[data-legacy-field=\"needHelpText\"]"); // @FindBy(xpath = NEED_HELP_XPATH)
    this.linkCallFarmers = page.locator("[data-legacy-field=\"linkCallFarmers\"]"); // @FindBy(xpath = CALL_FARMERS_LINK_XPATH)
    this.linkContactUs = page.locator("[data-legacy-field=\"linkContactUs\"]"); // @FindBy(xpath = CONTACT_US_LINK_XPATH)
    this.linkCallUs = page.locator("[data-legacy-field=\"linkCallUs\"]"); // @FindBy(xpath = CALL_US_LINK_XPATH)
    this.linkTermsOfUse = page.locator("[data-legacy-field=\"linkTermsOfUse\"]"); // @FindBy(xpath = TERMS_OF_USE_LINK_XPATH)
    this.linkPrivacyPolicy = page.locator("[data-legacy-field=\"linkPrivacyPolicy\"]"); // @FindBy(xpath = PRIVACY_POLICY_LINK_XPATH)
    this.linkYourPrivacyChoices = page.locator("[data-legacy-field=\"linkYourPrivacyChoices\"]"); // @FindBy(xpath = YOUR_PRIVACY_LINK_XPATH)
    this.modalPrivacyChoicesTitle = page.locator("xpath=//div[@role='alertdialog']//h4[text()='Notice of Right to Opt-Out']"); // @FindBy(xpath = "//div[@role='alertdialog']//h4[text()='Notice of Right to Opt-Out']")
    this.modalPrivacyChoicesSaveButton = page.locator("xpath=//div[@role='alertdialog']//button[contains(@class,'save-preference-btn')]"); // @FindBy(xpath = "//div[@role='alertdialog']//button[contains(@class,'save-preference-btn')]")
    this.modalPrivacyChoicesCloseButton = page.locator("xpath=//div[@role='alertdialog']//button[@id='close-pc-btn-handler']"); // @FindBy(xpath = "//div[@role='alertdialog']//button[@id='close-pc-btn-handler']")
    this.textQuoteSummary = page.locator("xpath=//div[contains(@class,'left-nav-block')]//span[contains(@class,'quote-summary')]"); // @FindBy(xpath = "//div[contains(@class,'left-nav-block')]//span[contains(@class,'quote-summary')]")
    this.linkPrivacyPolicyNext = page.locator("[data-legacy-field=\"linkPrivacyPolicyNext\"]"); // @FindBy(xpath = PRIVACY_POLICY_NEXT_XPATH)
    this.linkNoticeOfInformationPractices = page.locator("[data-legacy-field=\"linkNoticeOfInformationPractices\"]"); // @FindBy(xpath = NOTICE_OF_INFORMATION_PRACTICES_LINK_XPATH)
    this.linkNoticeOfInformationPracticesCA = page.locator("[data-legacy-field=\"linkNoticeOfInformationPracticesCA\"]"); // @FindBy(xpath = NOTICE_OF_INFORMATION_PRACTICES_LINK_XPATH_CA)
    this.linkDigiCert = page.locator("[data-legacy-field=\"linkDigiCert\"]"); // @FindBy(xpath = DIGI_CERT_LINK_XPATH)
    this.agentNameSide = page.locator("xpath=//mat-drawer[contains(@class,'mat-drawer-opened')]//span[contains(@class,'quote-agent-name')]"); // @FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-opened')]//span[contains(@class,'quote-agent-name')]")
    this.agentName = page.locator("xpath=//farmers-home-quote-thank-you//span[contains(@class,'quote-agent-name')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//span[contains(@class,'quote-agent-name')]")
    this.agentImageSide = page.locator("xpath=//mat-drawer[contains(@class,'mat-drawer-opened')]//img[contains(@class,'agent-img')]"); // @FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-opened')]//img[contains(@class,'agent-img')]")
    this.agentImage = page.locator("xpath=//farmers-home-quote-thank-you//img[contains(@class,'agent-img')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//img[contains(@class,'agent-img')]")
    this.localAgentTextSide = page.locator("xpath=//mat-drawer[contains(@class,'mat-drawer-opened')]//span[contains(@class,'quote-agent-p')]"); // @FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-opened')]//span[contains(@class,'quote-agent-p')]")
    this.localAgentText = page.locator("xpath=//farmers-home-quote-thank-you//span[contains(@class,'quote-agent-p')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//span[contains(@class,'quote-agent-p')]")
    this.learnMoreLink = page.locator("[data-legacy-field=\"learnMoreLink\"]"); // @FindBy(xpath=learnMoreLinkXpath)
    this.agentEmailIconSide = page.locator("[data-legacy-field=\"agentEmailIconSide\"]"); // @FindBy(xpath = AGENT_EMAIL_ICON_SIDE_XPATH)
    this.agentEmailIcon = page.locator("[data-legacy-field=\"agentEmailIcon\"]"); // @FindBy(xpath = AGENT_EMAIL_ICON_XPATH)
    this.agentEmailTextSide = page.locator("xpath=//mat-drawer[contains(@class,'mat-drawer-opened')]//a//div[contains(@class,'body-two')]"); // @FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-opened')]//a//div[contains(@class,'body-two')]")
    this.agentEmailText = page.locator("xpath=//farmers-home-quote-thank-you//a//div[contains(@class,'body-two')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//a//div[contains(@class,'body-two')]")
    this.agentPhoneIconSide = page.locator("[data-legacy-field=\"agentPhoneIconSide\"]"); // @FindBy(xpath = AGENT_PHONE_ICON_SIDE_XPATH)
    this.agentPhoneIcon = page.locator("[data-legacy-field=\"agentPhoneIcon\"]"); // @FindBy(xpath = AGENT_PHONE_ICON_XPATH)
    this.agentPhoneNumberSide = page.locator("xpath=//mat-drawer[contains(@class,'mat-drawer-opened')]//a[@id='phnTagId']//span[@data-gtm='FFQ_Home_Agent_phone_CTA']"); // @FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-opened')]//a[@id='phnTagId']//span[@data-gtm='FFQ_Home_Agent_phone_CTA']")
    this.agentPhoneNumber = page.locator("xpath=//farmers-home-quote-thank-you//a[@id='phnTagId']//span[@data-gtm='FFQ_Home_Agent_phone_CTA']"); // @FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='phnTagId']//span[@data-gtm='FFQ_Home_Agent_phone_CTA']")
    this.agentAddressIconSide = page.locator("[data-legacy-field=\"agentAddressIconSide\"]"); // @FindBy(xpath = AGENT_ADDRESS_ICON_SIDE_XPATH)
    this.agentAddressIcon = page.locator("[data-legacy-field=\"agentAddressIcon\"]"); // @FindBy(xpath = AGENT_ADDRESS_ICON_XPATH)
    this.agentAddressTextSide = page.locator("xpath=//mat-drawer[contains(@class,'mat-drawer-opened')]//span[@data-gtm='FFQ_Home_Agent_address_link']"); // @FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-opened')]//span[@data-gtm='FFQ_Home_Agent_address_link']")
    this.agentAddressText = page.locator("xpath=//farmers-home-quote-thank-you//span[@data-gtm='FFQ_Home_Agent_address_link']"); // @FindBy(xpath = "//farmers-home-quote-thank-you//span[@data-gtm='FFQ_Home_Agent_address_link']")
    this.agentInfoSection = page.locator("[data-legacy-field=\"agentInfoSection\"]"); // @FindBy(xpath = agentInfoSectionXpath)
    this.retrieveDialog = page.locator("xpath=//farmers-home-quote-retrieve-dialog/h2[text()='Thank you for retrieving your quote']"); // @FindBy(xpath = "//farmers-home-quote-retrieve-dialog/h2[text()='Thank you for retrieving your quote']")
    this.retrieveDialogContinueBtn = page.locator("xpath=//mat-dialog-actions/button[text()='CONTINUE' or text()='Continue']"); // @FindBy(xpath = "//mat-dialog-actions/button[text()='CONTINUE' or text()='Continue']")
    this.textSaveFinishLaterDialogTitle = page.locator("xpath=//farmers-home-quote-save-finish-dialog//h4[@mat-dialog-title]"); // @FindBy(xpath = "//farmers-home-quote-save-finish-dialog//h4[@mat-dialog-title]")
    this.textSaveFinishLaterDialogSubTitle = page.locator("xpath=//farmers-home-quote-save-finish-dialog//mat-dialog-content//p[contains(@class,'sub-title-one')]"); // @FindBy(xpath = "//farmers-home-quote-save-finish-dialog//mat-dialog-content//p[contains(@class,'sub-title-one')]")
    this.btnContinueSaveFinishLaterDialog = page.locator("xpath=//farmers-home-quote-save-finish-dialog//button[.='CONTINUE QUOTE']"); // @FindBy(xpath = "//farmers-home-quote-save-finish-dialog//button[.='CONTINUE QUOTE']")
    this.btnSaveExitSaveFinishLaterDialog = page.locator("xpath=//farmers-home-quote-save-finish-dialog//button[.='SAVE AND EXIT']"); // @FindBy(xpath = "//farmers-home-quote-save-finish-dialog//button[.='SAVE AND EXIT']")
  }
}
