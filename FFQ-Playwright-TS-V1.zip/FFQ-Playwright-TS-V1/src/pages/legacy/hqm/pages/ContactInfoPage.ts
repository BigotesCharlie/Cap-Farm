// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.ContactInfoPage. */
export class ContactInfoPage extends CoreBasePage {
  public readonly inputEmail: Locator;
  public readonly labelEmail: Locator;
  public readonly inputPhoneNumber: Locator;
  public readonly labelPhoneNumber: Locator;
  public readonly textPageTitle: Locator;
  public readonly textPageSubTitle: Locator;
  public readonly buttonCloseDialog: Locator;
  public readonly discountSubTitleLock: Locator;
  public readonly discountSubTitlePiggy: Locator;
  public readonly discountHelpButtonPiggy: Locator;
  public readonly discountHelpDialogTitle: Locator;
  public readonly discountHelpDialogContent: Locator;
  public readonly discountCheck: Locator;

  public constructor(page: Page) {
    super(page);
    this.inputEmail = page.locator("xpath=//ui-farmers-input[@type='email']//input"); // @FindBy(xpath = "//ui-farmers-input[@type='email']//input")
    this.labelEmail = page.locator("xpath=//ui-farmers-input[contains(@fieldlabel,'Email address')]//mat-label"); // @FindBy(xpath = "//ui-farmers-input[contains(@fieldlabel,'Email address')]//mat-label")
    this.inputPhoneNumber = page.locator("xpath=//input[@formcontrolname='phoneNumber']"); // @FindBy(xpath = "//input[@formcontrolname='phoneNumber']")
    this.labelPhoneNumber = page.locator("xpath=//mat-form-field//label[contains(.,'Phone number')]"); // @FindBy(xpath = "//mat-form-field//label[contains(.,'Phone number')]")
    this.textPageTitle = page.locator("xpath=//farmers-home-quote-contact-info//h1[@aria-label='PLEASE LET US KNOW HOW TO CONTACT YOU.'"); // @FindBy(xpath = "//farmers-home-quote-contact-info//h1[@aria-label='PLEASE LET US KNOW HOW TO CONTACT YOU.'" + 			           " or @aria-label='PLEASE LET US\nKNOW HOW TO\nCONTACT YOU.']")
    this.textPageSubTitle = page.locator("xpath=//farmers-home-quote-contact-info//div[@class='tui-subtitle-text-1']"); // @FindBy(xpath = "//farmers-home-quote-contact-info//div[@class='tui-subtitle-text-1']")
    this.buttonCloseDialog = page.locator("xpath=//mat-dialog-actions//button[.='CLOSE']"); // @FindBy(xpath = "//mat-dialog-actions//button[.='CLOSE']")
    this.discountSubTitleLock = page.locator("xpath=//farmers-home-quote-contact-info//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__image')]/../p"); // @FindBy(xpath = "//farmers-home-quote-contact-info//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__image')]/../p")
    this.discountSubTitlePiggy = page.locator("xpath=//farmers-home-quote-contact-info//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__potential')]/../p"); // @FindBy(xpath = "//farmers-home-quote-contact-info//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__potential')]/../p")
    this.discountHelpButtonPiggy = page.locator("xpath=//farmers-home-quote-contact-info//div[@class='discount-journey-card']//mat-icon[text()='info']"); // @FindBy(xpath ="//farmers-home-quote-contact-info//div[@class='discount-journey-card']//mat-icon[text()='info']")
    this.discountHelpDialogTitle = page.locator("xpath=//farmers-home-quote-discount-journey-dialog//h4"); // @FindBy(xpath = "//farmers-home-quote-discount-journey-dialog//h4")
    this.discountHelpDialogContent = page.locator("[data-legacy-field=\"discountHelpDialogContent\"]"); // @FindBy(xpath = CONTENT_XPATH)
    this.discountCheck = page.locator("xpath=//farmers-home-quote-contact-info//mat-card//div[@class='djm-discount-check']/../p"); // @FindBy(xpath = "//farmers-home-quote-contact-info//mat-card//div[@class='djm-discount-check']/../p")
  }
}
