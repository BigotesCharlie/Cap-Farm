// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.ThankYouRedirectPage. */
export class ThankYouRedirectPage extends CoreBasePage {
  public readonly linkFarmersLogo: Locator;
  public readonly pageTitle: Locator;
  public readonly pageSubTitle: Locator;
  public readonly pageFooter: Locator;
  public readonly linkCallFarmersPA: Locator;
  public readonly pageFooterRedirect: Locator;
  public readonly agentNameFooter: Locator;
  public readonly agentInfoFooter: Locator;
  public readonly agentImage: Locator;
  public readonly agentEmailAddress: Locator;
  public readonly agentPhoneNumber: Locator;
  public readonly agentAddress: Locator;
  public readonly buttonFindAgent: Locator;

  public constructor(page: Page) {
    super(page);
    this.linkFarmersLogo = page.locator("xpath=//farmers-home-quote-thank-you//a/img[@alt='Farmers Insurance Logo']"); // @FindBy(xpath = "//farmers-home-quote-thank-you//a/img[@alt='Farmers Insurance Logo']")
    this.pageTitle = page.locator("xpath=//farmers-home-quote-thank-you//h2"); // @FindBy(xpath = "//farmers-home-quote-thank-you//h2")
    this.pageSubTitle = page.locator("xpath=//farmers-home-quote-thank-you//p[contains(@class,'card-agent-subtitle')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//p[contains(@class,'card-agent-subtitle')]")
    this.pageFooter = page.locator("xpath=//farmers-home-quote-thank-you//div[contains(@class,'need-help-agent')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'need-help-agent')]")
    this.linkCallFarmersPA = page.locator("xpath=//farmers-home-quote-thank-you//div[contains(@class,'PoliticalAgent')]//a[@id='phoneIcon']"); // @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'PoliticalAgent')]//a[@id='phoneIcon']")
    this.pageFooterRedirect = page.locator("xpath=//farmers-home-quote-thank-you//div[contains(@class,'tui-subtitle-text-1')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'tui-subtitle-text-1')]")
    this.agentNameFooter = page.locator("xpath=//farmers-home-quote-thank-you//div[contains(@class,'agents-Info')]//span[contains(@class,'quote-agent-name')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'agents-Info')]//span[contains(@class,'quote-agent-name')]")
    this.agentInfoFooter = page.locator("xpath=//farmers-home-quote-thank-you//span[contains(@class,'quote-agent-p')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//span[contains(@class,'quote-agent-p')]")
    this.agentImage = page.locator("xpath=//farmers-home-quote-thank-you//img[contains(@class,'agent-img')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//img[contains(@class,'agent-img')]")
    this.agentEmailAddress = page.locator("xpath=//farmers-home-quote-thank-you//a[@id='emailTagId']//div/mat-icon[text()='email']/../.."); // @FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='emailTagId']//div/mat-icon[text()='email']/../.." +             "/div[contains(@class,'body-two')]")
    this.agentPhoneNumber = page.locator("xpath=//farmers-home-quote-thank-you//a[@id='phnTagId']//div/mat-icon[text()='phone']/../.."); // @FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='phnTagId']//div/mat-icon[text()='phone']/../.." +             "/div/span[contains(@class,'body-two')]")
    this.agentAddress = page.locator("xpath=//farmers-home-quote-thank-you//a[@id='locTagId']//div/mat-icon[text()='place']/../.."); // @FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='locTagId']//div/mat-icon[text()='place']/../.." +             "/div/span[contains(@class,'body-two')]")
    this.buttonFindAgent = page.locator("[data-legacy-field=\"buttonFindAgent\"]"); // @FindBy(xpath = FIND_AGENT_BUTTON_XPATH)
  }
}
