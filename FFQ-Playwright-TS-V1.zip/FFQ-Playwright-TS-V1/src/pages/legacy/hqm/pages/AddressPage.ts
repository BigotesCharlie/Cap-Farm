// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.AddressPage. */
export class AddressPage extends CoreBasePage {
  public readonly inputAddress: Locator;
  public readonly inputCity: Locator;
  public readonly selectCity: Locator;
  public readonly inputZip: Locator;
  public readonly dialogZipChangeTitle: Locator;
  public readonly inputState: Locator;
  public readonly buttonChange: Locator;
  public readonly buttonCancel: Locator;
  public readonly buttonOk: Locator;
  public readonly inputStartDate: Locator;
  public readonly inputCheckboxMobileManufactured: Locator;
  public readonly labelCheckboxMobileManufactured: Locator;
  public readonly textPageTitle: Locator;
  public readonly selectCounty: Locator;
  public readonly textPageSubTitle: Locator;
  public readonly textPageSubTitle2: Locator;
  public readonly discountSubTitleLock: Locator;
  public readonly textPageEarlyShopping: Locator;
  public readonly subHeaderGroupSelect: Locator;
  public readonly subtitleHeaderGroupSelect: Locator;
  public readonly inputEmployerGroup: Locator;
  public readonly employerOption: Locator;
  public readonly radioButtonAgent: Locator;
  public readonly labelEmployerGroup: Locator;
  public readonly learnMoreLink: Locator;
  public readonly showLessLink: Locator;
  public readonly buttonAgree: Locator;

  public constructor(page: Page) {
    super(page);
    this.inputAddress = page.locator("xpath=//div/ui-farmers-input[@id='address']//input"); // @FindBy(xpath = "//div/ui-farmers-input[@id='address']//input")
    this.inputCity = page.locator("[data-legacy-field=\"inputCity\"]"); // @FindBy(xpath = INPUT_CITY_XPATH)
    this.selectCity = page.locator("xpath=//mat-select[@id='city']"); // @FindBy(xpath = "//mat-select[@id='city']")
    this.inputZip = page.locator("xpath=//ui-farmers-input[@fieldlabel='ZIP Code']//input"); // @FindBy(xpath = "//ui-farmers-input[@fieldlabel='ZIP Code']//input")
    this.dialogZipChangeTitle = page.locator("[data-legacy-field=\"dialogZipChangeTitle\"]"); // @FindBy(xpath = DIALOG_ZIP_CHANGE_XPATH)
    this.inputState = page.locator("xpath=//ui-farmers-input[@fieldlabel='State']//input"); // @FindBy(xpath = "//ui-farmers-input[@fieldlabel='State']//input")
    this.buttonChange = page.locator("[data-legacy-field=\"buttonChange\"]"); // @FindBy(xpath = BUTTON_CHANGE_XPATH)
    this.buttonCancel = page.locator("[data-legacy-field=\"buttonCancel\"]"); // @FindBy(xpath = BUTTON_CANCEL_XPATH)
    this.buttonOk = page.locator("[data-legacy-field=\"buttonOk\"]"); // @FindBy(xpath = BUTTON_OK_XPATH)
    this.inputStartDate = page.locator("xpath=//ui-farmers-datepicker[@fieldlabel='Policy start date']//input[@matinput]"); // @FindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Policy start date']//input[@matinput]")
    this.inputCheckboxMobileManufactured = page.locator("xpath=//farmers-home-quote-address//mat-checkbox//input"); // @FindBy(xpath = "//farmers-home-quote-address//mat-checkbox//input")
    this.labelCheckboxMobileManufactured = page.locator("xpath=//farmers-home-quote-address//mat-checkbox//label"); // @FindBy(xpath = "//farmers-home-quote-address//mat-checkbox//label")
    this.textPageTitle = page.locator("xpath=//farmers-home-quote-address//h1"); // @FindBy(xpath = "//farmers-home-quote-address//h1")
    this.selectCounty = page.locator("[data-legacy-field=\"selectCounty\"]"); // @FindBy(xpath = COUNTY_XPATH)
    this.textPageSubTitle = page.locator("xpath=//farmers-home-quote-address//div[h1]//span[contains(@class,'tui-subtitle-text-1')]"); // @FindBy(xpath = "//farmers-home-quote-address//div[h1]//span[contains(@class,'tui-subtitle-text-1')]")
    this.textPageSubTitle2 = page.locator("xpath=//farmers-home-quote-address//div[contains(@class,'bottom-text')]/span[contains(@class,'tui-subtitle-text-1')]"); // @FindBy(xpath = "//farmers-home-quote-address//div[contains(@class,'bottom-text')]/span[contains(@class,'tui-subtitle-text-1')]")
    this.discountSubTitleLock = page.locator("xpath=//farmers-home-quote-address//farmers-home-quote-discount-journey//img[@id='lock-img']/../p"); // @FindBy(xpath = "//farmers-home-quote-address//farmers-home-quote-discount-journey//img[@id='lock-img']/../p")
    this.textPageEarlyShopping = page.locator("xpath=//farmers-home-quote-address//span[contains(@class,'caption')]"); // @FindBy(xpath = "//farmers-home-quote-address//span[contains(@class,'caption')]")
    this.subHeaderGroupSelect = page.locator("[data-legacy-field=\"subHeaderGroupSelect\"]"); // @FindBy(xpath = SUBHEADER_GROUP_SELECT_XPATH)
    this.subtitleHeaderGroupSelect = page.locator("xpath=//farmers-home-quote-address//h5/../../div/span[@class='sub-title-one']"); // @FindBy(xpath = "//farmers-home-quote-address//h5/../../div/span[@class='sub-title-one']")
    this.inputEmployerGroup = page.locator("[data-legacy-field=\"inputEmployerGroup\"]"); // @FindBy(xpath = INPUT_EMPLOYER_GROUP_XPATH)
    this.employerOption = page.locator("[data-legacy-field=\"employerOption\"]"); // @FindBy(xpath = EMPLOYER_GROUP_LIST_XPATH)
    this.radioButtonAgent = page.locator("[data-legacy-field=\"radioButtonAgent\"]"); // @FindBy(xpath = AGENT_RADIOBUTTON_XPATH)
    this.labelEmployerGroup = page.locator("[data-legacy-field=\"labelEmployerGroup\"]"); // @FindBy(xpath = LABEL_EMPLOYER_GROUP_XPATH)
    this.learnMoreLink = page.locator("[data-legacy-field=\"learnMoreLink\"]"); // @FindBy(xpath=learnMoreLinkXpath)
    this.showLessLink = page.locator("[data-legacy-field=\"showLessLink\"]"); // @FindBy(xpath=showLessLinkXpath)
    this.buttonAgree = page.locator("xpath=//button[contains(.,'Agree')]"); // @FindBy(xpath = "//button[contains(.,'Agree')]")
  }
}
