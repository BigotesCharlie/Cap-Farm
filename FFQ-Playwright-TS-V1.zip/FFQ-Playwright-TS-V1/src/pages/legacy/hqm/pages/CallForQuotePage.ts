// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.CallForQuotePage. */
export class CallForQuotePage extends CoreBasePage {
  public readonly pageTitle: Locator;
  public readonly pageSubTitle: Locator;
  public readonly pageSubHeader: Locator;
  public readonly pageSubHeader3: Locator;
  public readonly buttonToCall: Locator;
  public readonly linkToContinueFarmersQuoteOnline: Locator;
  public readonly farmersLogo: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageTitle = page.locator("xpath=//*[@id='farmers-landing-v2']//span[contains(@class,'h1-alt2')]"); // @FindBy(xpath = "//*[@id='farmers-landing-v2']//span[contains(@class,'h1-alt2')]")
    this.pageSubTitle = page.locator("xpath=//*[@id='farmers-landing-v2']//div[contains(@class,'aem-GridColumn--offset--default--2')]/section[@data-swiftype-index]//p"); // @FindBy(xpath = "//*[@id='farmers-landing-v2']//div[contains(@class,'aem-GridColumn--offset--default--2')]/section[@data-swiftype-index]//p")
    this.pageSubHeader = page.locator("xpath=//*[@id='farmers-landing-v2']//div//h2/span[contains(@class,'h4-alt1')]"); // @FindBy(xpath = "//*[@id='farmers-landing-v2']//div//h2/span[contains(@class,'h4-alt1')]")
    this.pageSubHeader3 = page.locator("xpath=//*[@id='farmers-landing-v2']//div/p//span[contains(@class,'h4-alt1')]"); // @FindBy(xpath = "//*[@id='farmers-landing-v2']//div/p//span[contains(@class,'h4-alt1')]")
    this.buttonToCall = page.locator("xpath=//*[@id='farmers-landing-v2']//div[contains(@class,'button')]//a[@data-gtm='Farmers_COLPGS_CallLink_Header']"); // @FindBy(xpath = "//*[@id='farmers-landing-v2']//div[contains(@class,'button')]//a[@data-gtm='Farmers_COLPGS_CallLink_Header']")
    this.linkToContinueFarmersQuoteOnline = page.locator("[data-legacy-field=\"linkToContinueFarmersQuoteOnline\"]"); // @FindBy(linkText = CONTINUE_FARMERS_QUOTE_ONLINE_TEXT)
    this.farmersLogo = page.locator("[data-legacy-field=\"farmersLogo\"]"); // @FindBy(xpath = XPATH_LOGO)
  }
}
