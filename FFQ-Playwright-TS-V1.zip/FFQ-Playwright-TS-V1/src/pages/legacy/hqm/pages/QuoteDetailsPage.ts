// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.QuoteDetailsPage. */
export class QuoteDetailsPage extends CoreBasePage {
  public readonly btnCloseModal: Locator;
  public readonly btnRecalculate: Locator;
  public readonly btnReset: Locator;
  public readonly sliderDwellingDiv: Locator;
  public readonly sliderDwelling: Locator;
  public readonly sliderExtendedReplacementDiv: Locator;
  public readonly sliderExtendedReplacement: Locator;
  public readonly sliderSeparateStructuresDiv: Locator;
  public readonly sliderSeparateStructures: Locator;
  public readonly sliderPersonalPropertyDiv: Locator;
  public readonly sliderPersonalProperty: Locator;
  public readonly sliderBOLDiv: Locator;
  public readonly slidersPropertyCoverages: Locator;
  public readonly slidersDeductibles: Locator;
  public readonly slidersLiability: Locator;
  public readonly sliderAllPerilDiv: Locator;
  public readonly sliderAllPeril: Locator;
  public readonly sliderWindAndHailDiv: Locator;
  public readonly sliderWindAndHail: Locator;
  public readonly sliderHurricaneDiv: Locator;
  public readonly sliderHurricane: Locator;
  public readonly sliderWaterDiv: Locator;
  public readonly sliderWater: Locator;
  public readonly sliderPersonalLiabilityDiv: Locator;
  public readonly sliderPersonalLiability: Locator;
  public readonly sliderMedicalPaymentsToOthersDiv: Locator;
  public readonly sliderMedicalPaymentsToOthers: Locator;
  public readonly rbtnsMineSubsidence: Locator;
  public readonly rbtnMineSubsidenceYes: Locator;
  public readonly rbtnMineSubsidenceNo: Locator;
  public readonly textYearlyPremium: Locator;
  public readonly textYearlyPremiumCA: Locator;
  public readonly textYearlyPremiumCents: Locator;
  public readonly textYearlyPremiumPerYear: Locator;
  public readonly textYearlyPremiumDisclaimer: Locator;
  public readonly textMonthlyPremium: Locator;
  public readonly titleQuoteType: Locator;
  public readonly textFooterDisclaimer: Locator;
  public readonly closeSurveyButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.btnCloseModal = page.locator("xpath=//farmers-home-quote-details-dialog//mat-icon[contains(text(),'close')]"); // @FindBy(xpath = "//farmers-home-quote-details-dialog//mat-icon[contains(text(),'close')]")
    this.btnRecalculate = page.locator("xpath=//farmers-home-quote-details-dialog//button[contains(.,'RECALCULATE')]"); // @FindBy(xpath = "//farmers-home-quote-details-dialog//button[contains(.,'RECALCULATE')]")
    this.btnReset = page.locator("xpath=//farmers-home-quote-details-dialog//button[contains(text(),'RESET')]"); // @FindBy(xpath = "//farmers-home-quote-details-dialog//button[contains(text(),'RESET')]")
    this.sliderDwellingDiv = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Dwelling')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Dwelling')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.sliderDwelling = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Dwelling')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Dwelling')]" +             "/../../div//mat-slider")
    this.sliderExtendedReplacementDiv = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Extended Replacement Cost')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Extended Replacement Cost')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.sliderExtendedReplacement = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Extended Replacement Cost')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Extended Replacement Cost')]" +             "/../../div//mat-slider")
    this.sliderSeparateStructuresDiv = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Separate Structures')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Separate Structures')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.sliderSeparateStructures = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Separate Structures')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Separate Structures')]" +             "/../../div//mat-slider")
    this.sliderPersonalPropertyDiv = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Personal Property')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Property')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.sliderPersonalProperty = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Personal Property')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Property')]" +             "/../../div//mat-slider")
    this.sliderBOLDiv = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Building Ordinance or Law Coverage')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Building Ordinance or Law Coverage')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.slidersPropertyCoverages = page.locator("[data-legacy-field=\"slidersPropertyCoverages\"]"); // @FindBy(xpath = SLIDERS_PROPERTY_COVERAGES_XPATH)
    this.slidersDeductibles = page.locator("[data-legacy-field=\"slidersDeductibles\"]"); // @FindBy(xpath = SLIDERS_DEDUCTIBLES_XPATH)
    this.slidersLiability = page.locator("[data-legacy-field=\"slidersLiability\"]"); // @FindBy(xpath = SLIDERS_LIABILITY_XPATH)
    this.sliderAllPerilDiv = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'All Peril') or contains(text(),'All Other Peril')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'All Peril') or contains(text(),'All Other Peril')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.sliderAllPeril = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'All Peril') or contains(text(),'All Other Peril')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'All Peril') or contains(text(),'All Other Peril')]" +             "/../../div//mat-slider")
    this.sliderWindAndHailDiv = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Wind & Hail')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Wind & Hail')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.sliderWindAndHail = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Wind & Hail')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Wind & Hail')]" +             "/../../div//mat-slider")
    this.sliderHurricaneDiv = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Hurricane')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Hurricane')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.sliderHurricane = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Hurricane')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Hurricane')]" +             "/../../div//mat-slider")
    this.sliderWaterDiv = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Water')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Water')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.sliderWater = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Water')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Water')]" +             "/../../div//mat-slider")
    this.sliderPersonalLiabilityDiv = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Personal Liability')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Liability')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.sliderPersonalLiability = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Personal Liability')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Liability')]" +             "/../../div//mat-slider")
    this.sliderMedicalPaymentsToOthersDiv = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Medical Payments to Others')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Medical Payments to Others')]" +             "/../../div[contains(@class,'mat-slider')]")
    this.sliderMedicalPaymentsToOthers = page.locator("xpath=//div[@class='coverage-content']/h5[contains(text(),'Medical Payments to Others')]"); // @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Medical Payments to Others')]" +             "/../../div//mat-slider")
    this.rbtnsMineSubsidence = page.locator("[data-legacy-field=\"rbtnsMineSubsidence\"]"); // @FindBy(xpath = RADIOBUTTONS_MINE_SUBSIDENCE_XPATH)
    this.rbtnMineSubsidenceYes = page.locator("xpath=//mat-radio-button[contains(@class,'mineSubsidenceYes')]//input"); // @FindBy(xpath = "//mat-radio-button[contains(@class,'mineSubsidenceYes')]//input")
    this.rbtnMineSubsidenceNo = page.locator("xpath=//mat-radio-button[contains(@class,'mineSubsidenceNo')]//input"); // @FindBy(xpath = "//mat-radio-button[contains(@class,'mineSubsidenceNo')]//input")
    this.textYearlyPremium = page.locator("xpath=//farmers-home-quote-details-dialog//div[@id='yearlyPremium']//span"); // @FindBy(xpath = "//farmers-home-quote-details-dialog//div[@id='yearlyPremium']//span")
    this.textYearlyPremiumCA = page.locator("[data-legacy-field=\"textYearlyPremiumCA\"]"); // @FindBy(xpath = yearlyPremiumCAxPath)
    this.textYearlyPremiumCents = page.locator("[data-legacy-field=\"textYearlyPremiumCents\"]"); // @FindBy(xpath = YEARLY_XPATH + "/span/span")
    this.textYearlyPremiumPerYear = page.locator("[data-legacy-field=\"textYearlyPremiumPerYear\"]"); // @FindBy(xpath = YEARLY_XPATH + "/span/span/span[@aria-label='per year']")
    this.textYearlyPremiumDisclaimer = page.locator("[data-legacy-field=\"textYearlyPremiumDisclaimer\"]"); // @FindBy(xpath = YEARLY_XPATH + "/span/span/a[@aria-label='" + PREMIUM_DISCLAIMER + "']")
    this.textMonthlyPremium = page.locator("xpath=//farmers-home-quote-details-dialog//div[contains(@class,'cost-block')]"); // @FindBy(xpath = "//farmers-home-quote-details-dialog//div[contains(@class,'cost-block')]")
    this.titleQuoteType = page.locator("[data-legacy-field=\"titleQuoteType\"]"); // @FindBy(xpath = TITLE_XPATH)
    this.textFooterDisclaimer = page.locator("xpath=//farmers-home-quote-details-dialog//p[starts-with(@class,'coverages-info-text')]"); // @FindBy(xpath = "//farmers-home-quote-details-dialog//p[starts-with(@class,'coverages-info-text')]")
    this.closeSurveyButton = page.locator("[data-legacy-field=\"closeSurveyButton\"]"); // @FindBy(xpath = SURVEY_POPUP_XPATH)
  }
}
