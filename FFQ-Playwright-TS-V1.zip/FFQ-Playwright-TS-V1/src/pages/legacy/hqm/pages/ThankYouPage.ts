// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.ThankYouPage. */
export class ThankYouPage extends CoreBasePage {
  public readonly textQuoteNumber: Locator;
  public readonly textEstimatedPremium: Locator;
  public readonly linkFarmersLogo: Locator;
  public readonly pageTitle: Locator;
  public readonly pageSubTitle1: Locator;
  public readonly pageSubTitle2: Locator;
  public readonly pageFooter1: Locator;
  public readonly pageFooter2: Locator;
  public readonly linkCallFarmersPA: Locator;
  public readonly pageFooterRedirect: Locator;
  public readonly agentNameFooter: Locator;
  public readonly agentInfoFooter: Locator;
  public readonly agentImage: Locator;
  public readonly agentEmailAddress: Locator;
  public readonly agentPhoneNumber: Locator;
  public readonly agentAddress: Locator;
  public readonly pageCrossSellTitle: Locator;
  public readonly pageCrossSellSubTitle: Locator;
  public readonly selectCrossSellType: Locator;
  public readonly selectCrossSellTypeLabel: Locator;
  public readonly buttonStartSaving: Locator;

  public constructor(page: Page) {
    super(page);
    this.textQuoteNumber = page.locator("xpath=//farmers-home-quote-thank-you//div/p[text()='QUOTE NUMBER' or text()='HOME QUOTE NUMBER']/../p[2]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//div/p[text()='QUOTE NUMBER' or text()='HOME QUOTE NUMBER']/../p[2]")
    this.textEstimatedPremium = page.locator("xpath=//farmers-home-quote-thank-you//div/p[text()='ESTIMATED MONTHLY PREMIUM' or text()='ESTIMATED PRICE']/../p[2]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//div/p[text()='ESTIMATED MONTHLY PREMIUM' or text()='ESTIMATED PRICE']/../p[2]")
    this.linkFarmersLogo = page.locator("xpath=//farmers-home-quote-thank-you//a/img[@alt='Farmers Insurance Logo']"); // @FindBy(xpath = "//farmers-home-quote-thank-you//a/img[@alt='Farmers Insurance Logo']")
    this.pageTitle = page.locator("xpath=//farmers-home-quote-thank-you//h1"); // @FindBy(xpath = "//farmers-home-quote-thank-you//h1")
    this.pageSubTitle1 = page.locator("xpath=//farmers-home-quote-thank-you//p[contains(@class,'tui-subtitle-text-1')][1]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//p[contains(@class,'tui-subtitle-text-1')][1]")
    this.pageSubTitle2 = page.locator("xpath=//farmers-home-quote-thank-you//p[contains(@class,'tui-subtitle-text-1')][2]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//p[contains(@class,'tui-subtitle-text-1')][2]")
    this.pageFooter1 = page.locator("xpath=//farmers-home-quote-thank-you//div[contains(@class,'need-help-caption')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'need-help-caption')]")
    this.pageFooter2 = page.locator("xpath=//farmers-home-quote-thank-you//div[contains(@class,'need-help-caption')]/../p"); // @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'need-help-caption')]/../p")
    this.linkCallFarmersPA = page.locator("xpath=//farmers-home-quote-thank-you//div[contains(@class,'PoliticalAgent')]//a[@id='phoneIcon']"); // @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'PoliticalAgent')]//a[@id='phoneIcon']")
    this.pageFooterRedirect = page.locator("xpath=//farmers-home-quote-thank-you//div[contains(@class,'tui-subtitle-text-1')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'tui-subtitle-text-1')]")
    this.agentNameFooter = page.locator("xpath=//farmers-home-quote-thank-you//div[contains(@class,'agents-Info')]//span[contains(@class,'quote-agent-name')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'agents-Info')]//span[contains(@class,'quote-agent-name')]")
    this.agentInfoFooter = page.locator("xpath=//farmers-home-quote-thank-you//span[contains(@class,'quote-agent-p')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//span[contains(@class,'quote-agent-p')]")
    this.agentImage = page.locator("xpath=//farmers-home-quote-thank-you//img[contains(@class,'agent-img')]"); // @FindBy(xpath = "//farmers-home-quote-thank-you//img[contains(@class,'agent-img')]")
    this.agentEmailAddress = page.locator("xpath=//farmers-home-quote-thank-you//a[@id='emailTagId']//div/mat-icon[text()='email']/../.."); // @FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='emailTagId']//div/mat-icon[text()='email']/../.." +             "/div[contains(@class,'body-two')]")
    this.agentPhoneNumber = page.locator("xpath=//farmers-home-quote-thank-you//a[@id='phnTagId']//div/mat-icon[text()='phone']/../.."); // @FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='phnTagId']//div/mat-icon[text()='phone']/../.." +             "/div/span[contains(@class,'body-two')]")
    this.agentAddress = page.locator("xpath=//farmers-home-quote-thank-you//a[@id='locTagId']//div/mat-icon[text()='place']/../.."); // @FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='locTagId']//div/mat-icon[text()='place']/../.." +             "/div/span[contains(@class,'body-two')]")
    this.pageCrossSellTitle = page.locator("xpath=//farmers-home-quote-thank-you//mat-card//h4"); // @FindBy(xpath = "//farmers-home-quote-thank-you//mat-card//h4")
    this.pageCrossSellSubTitle = page.locator("xpath=//farmers-home-quote-thank-you//mat-card//p"); // @FindBy(xpath = "//farmers-home-quote-thank-you//mat-card//p")
    this.selectCrossSellType = page.locator("[data-legacy-field=\"selectCrossSellType\"]"); // @FindBy(xpath = CROSSSELL_SELECT_XPATH)
    this.selectCrossSellTypeLabel = page.locator("xpath=//farmers-home-quote-thank-you//ui-farmers-select//mat-label"); // @FindBy(xpath = "//farmers-home-quote-thank-you//ui-farmers-select//mat-label")
    this.buttonStartSaving = page.locator("xpath=//farmers-home-quote-thank-you//mat-card//button[.='START SAVING']"); // @FindBy(xpath = "//farmers-home-quote-thank-you//mat-card//button[.='START SAVING']")
  }
}
