// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.hqm.pages.InterstitialPage. */
export class InterstitialPage extends CoreBasePage {
  public readonly pageTitle: Locator;
  public readonly pageContents: Locator;
  public readonly buttonContinueToFGIA: Locator;
  public readonly buttonNoThanks: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageTitle = page.locator("xpath=//app-fgia-popup/mat-dialog-content//div[@role='heading']"); // @FindBy(xpath = "//app-fgia-popup/mat-dialog-content//div[@role='heading']")
    this.pageContents = page.locator("xpath=//app-fgia-popup/mat-dialog-content//div[@id='dnqMessage']"); // @FindBy(xpath = "//app-fgia-popup/mat-dialog-content//div[@id='dnqMessage']")
    this.buttonContinueToFGIA = page.locator("xpath=//button[contains(.,'Continue to FGIA')]"); // @FindBy(xpath = "//button[contains(.,'Continue to FGIA')]")
    this.buttonNoThanks = page.locator("xpath=//button[contains(.,'No, thanks')]"); // @FindBy(xpath = "//button[contains(.,'No, thanks')]")
  }
}
