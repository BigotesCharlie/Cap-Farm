// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.SelectAQuoteToReviewPage. */
export class SelectAQuoteToReviewPage extends CoreBasePage {
  public readonly btnContinueMyQuote: Locator;

  public constructor(page: Page) {
    super(page);
    this.btnContinueMyQuote = page.locator("xpath=//button[normalize-space(.)='Continue my quote']"); // @FindBy(xpath = "//button[normalize-space(.)='Continue my quote']")
  }
}
