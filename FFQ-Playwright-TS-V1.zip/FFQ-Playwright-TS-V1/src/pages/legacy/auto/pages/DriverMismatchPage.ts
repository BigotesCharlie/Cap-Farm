// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.DriverMismatchPage. */
export class DriverMismatchPage extends CoreBasePage {
  public readonly driverMismatchPageTitle: Locator;
  public readonly driverMismatchPageSubtitle: Locator;
  public readonly driverMismatchPageHelpTitle: Locator;
  public readonly driverMismatchPageHelpTextParagraphOne: Locator;
  public readonly driverMismatchPageHelpTextParagraphTwo: Locator;
  public readonly continueButton: Locator;
  public readonly returnToDriverSelectionLink: Locator;
  public readonly rejectReasons: Locator;
  public readonly listOfNamesOfDriversNotIncluded: Locator;
  public readonly listOfAgesOfDriversNotIncluded: Locator;
  public readonly listOfUnknownDriverRadioButtons: Locator;
  public readonly uncheckedListOfUnknownDriverRadioButtons: Locator;
  public readonly listOfErrorsInPage: Locator;
  public readonly excludeThisPersonFromMyInsuranceRadioButtons: Locator;

  public constructor(page: Page) {
    super(page);
    this.driverMismatchPageTitle = page.locator(".driver-mismatch-page-header"); // @FindBy(className = "driver-mismatch-page-header")
    this.driverMismatchPageSubtitle = page.locator(".driver-mismatch-page-subheading"); // @FindBy(className = "driver-mismatch-page-subheading")
    this.driverMismatchPageHelpTitle = page.locator("xpath=//div[@class='auto-driver-review-info-header-content']/div"); // @FindBy(xpath = "//div[@class='auto-driver-review-info-header-content']/div")
    this.driverMismatchPageHelpTextParagraphOne = page.locator("xpath=//div[@class='auto-driver-review-info-header-content']//p[1]"); // @FindBy(xpath = "//div[@class='auto-driver-review-info-header-content']//p[1]")
    this.driverMismatchPageHelpTextParagraphTwo = page.locator("xpath=//div[@class='auto-driver-review-info-header-content']//p[2]"); // @FindBy(xpath = "//div[@class='auto-driver-review-info-header-content']//p[2]")
    this.continueButton = page.locator("xpath=//button[@data-test-id='CONTINUE_BTN']"); // @FindBy(xpath = "//button[@data-test-id='CONTINUE_BTN']")
    this.returnToDriverSelectionLink = page.locator("xpath=//div[@class='driver-mismatch-page-subheading']//a"); // @FindBy(xpath = "//div[@class='driver-mismatch-page-subheading']//a")
    this.rejectReasons = page.locator("[data-legacy-field=\"rejectReasons\"]"); // @FindBy(xpath = REJECT_REASONS_XPATH)
    this.listOfNamesOfDriversNotIncluded = page.locator("[data-legacy-field=\"listOfNamesOfDriversNotIncluded\"]"); // @FindBy(xpath = NAME_OF_NON_LISTED_DRIVERS_XPATH)
    this.listOfAgesOfDriversNotIncluded = page.locator("[data-legacy-field=\"listOfAgesOfDriversNotIncluded\"]"); // @FindBy(xpath = NAME_OF_NON_LISTED_DRIVERS_XPATH + "/../div[contains(text(), 'Age')]")
    this.listOfUnknownDriverRadioButtons = page.locator("xpath=//mat-radio-button[contains(.,'know this person')]//input"); // @FindBy(xpath = "//mat-radio-button[contains(.,'know this person')]//input")
    this.uncheckedListOfUnknownDriverRadioButtons = page.locator("xpath=//mat-radio-button[contains(.,'know this person') and not(contains(@class,'checked'))]//input"); // @FindBy(xpath = "//mat-radio-button[contains(.,'know this person') and not(contains(@class,'checked'))]//input")
    this.listOfErrorsInPage = page.locator("xpath=//mat-error"); // @FindBy(xpath = "//mat-error")
    this.excludeThisPersonFromMyInsuranceRadioButtons = page.locator("xpath=//mat-radio-group[@formcontrolname='rejectReasonFormValue']//mat-radio-button[contains(.,'Exclude')]"); // @FindBy(xpath = "//mat-radio-group[@formcontrolname='rejectReasonFormValue']//mat-radio-button[contains(.,'Exclude')]")
  }
}
