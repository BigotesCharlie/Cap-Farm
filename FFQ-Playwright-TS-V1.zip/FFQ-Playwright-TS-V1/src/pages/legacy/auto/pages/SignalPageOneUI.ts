// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.SignalPageOneUI. */
export class SignalPageOneUI extends CoreBasePage {
  public readonly signalPageHeader: Locator;
  public readonly signalPageSubheader: Locator;
  public readonly tripDirectionImage: Locator;
  public readonly drivingBehaviourImage: Locator;
  public readonly saveTodayLabel: Locator;
  public readonly saveAtRenewalLabel: Locator;
  public readonly saveAtRenewalWhenYoungDriverLabel: Locator;
  public readonly findOutMoreLink: Locator;
  public readonly addSignalButton: Locator;
  public readonly notNowButton: Locator;
  public readonly signalPageDisclaimer: Locator;
  public readonly nextToMoreDiscountsButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.signalPageHeader = page.locator("xpath=//div[@class='signal-container content-wrapper']//h1"); // @FindBy(xpath = "//div[@class='signal-container content-wrapper']//h1")
    this.signalPageSubheader = page.locator("xpath=//*[contains(@class, 'sec-title')]"); // @FindBy(xpath = "//*[contains(@class, 'sec-title')]")
    this.tripDirectionImage = page.locator("xpath=//img[@class='signal-mobile-image'][1]"); // @FindBy(xpath = "//img[@class='signal-mobile-image'][1]")
    this.drivingBehaviourImage = page.locator("xpath=//img[@class='signal-mobile-image'][2]"); // @FindBy(xpath = "//img[@class='signal-mobile-image'][2]")
    this.saveTodayLabel = page.locator("xpath=//*[@class='signal-container content-wrapper']//li[1]"); // @FindBy(xpath = "//*[@class='signal-container content-wrapper']//li[1]")
    this.saveAtRenewalLabel = page.locator("xpath=//*[@class='signal-container content-wrapper']//li[2]"); // @FindBy(xpath = "//*[@class='signal-container content-wrapper']//li[2]")
    this.saveAtRenewalWhenYoungDriverLabel = page.locator("xpath=//*[@class='signal-container content-wrapper']//li[3]"); // @FindBy(xpath = "//*[@class='signal-container content-wrapper']//li[3]")
    this.findOutMoreLink = page.locator("xpath=//button[@data-test-id='FIND_OUT_MORE_BUTTON']"); // @FindBy(xpath = "//button[@data-test-id='FIND_OUT_MORE_BUTTON']")
    this.addSignalButton = page.locator("[data-legacy-field=\"addSignalButton\"]"); // @FindBy(xpath = ADD_SIGNAL_BUTTON_XPATH)
    this.notNowButton = page.locator("xpath=//button[@data-test-id='NOT_NOW_BUTTON']"); // @FindBy(xpath = "//button[@data-test-id='NOT_NOW_BUTTON']")
    this.signalPageDisclaimer = page.locator("xpath=//*[contains(@class, 'row disclosure')]"); // @FindBy(xpath = "//*[contains(@class, 'row disclosure')]")
    this.nextToMoreDiscountsButton = page.locator("xpath=//button[@data-gtm='FFQ_Auto_Signal_Discount_next_button']"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_Signal_Discount_next_button']")
  }
}
