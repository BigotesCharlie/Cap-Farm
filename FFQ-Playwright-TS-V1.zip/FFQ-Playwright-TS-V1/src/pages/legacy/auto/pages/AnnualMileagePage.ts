// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.AnnualMileagePage. */
export class AnnualMileagePage extends CoreBasePage {
  public readonly pageTitle: Locator;
  public readonly pageSubtitle: Locator;
  public readonly vehicleLabels: Locator;
  public readonly annualMileageInputFields: Locator;
  public readonly annualMileageErrorMessages: Locator;
  public readonly continueButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageTitle = page.locator("app-annual-mileage h1.tui-h1"); // @FindBy(css = "app-annual-mileage h1.tui-h1")
    this.pageSubtitle = page.locator("p.annual-mileage__subtitle"); // @FindBy(css = "p.annual-mileage__subtitle")
    this.vehicleLabels = page.locator("p.annual-mileage__vehicle-label"); // @FindBy(css = "p.annual-mileage__vehicle-label")
    this.annualMileageInputFields = page.locator("input[formcontrolname='annualMileage']"); // @FindBy(css = "input[formcontrolname='annualMileage']")
    this.annualMileageErrorMessages = page.locator("mat-error.annual-mileage__error"); // @FindBy(css = "mat-error.annual-mileage__error")
    this.continueButton = page.locator("#ANNUAL_MILEAGE_CONTINUE_CTA"); // @FindBy(id = "ANNUAL_MILEAGE_CONTINUE_CTA")
  }
}
