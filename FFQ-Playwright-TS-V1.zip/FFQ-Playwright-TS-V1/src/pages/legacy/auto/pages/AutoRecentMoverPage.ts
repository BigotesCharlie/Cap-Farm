// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.AutoRecentMoverPage. */
export class AutoRecentMoverPage extends CoreBasePage {
  public readonly pageHeader: Locator;
  public readonly pageSubHeader: Locator;
  public readonly recentMoverToggleHeader: Locator;
  public readonly yesToggleButton: Locator;
  public readonly noToggleButton: Locator;
  public readonly googlePrefilAddressInputField: Locator;
  public readonly googlePrefillAddressInputLabel: Locator;
  public readonly googlePrefillAddressErrorMessage: Locator;
  public readonly manualStreetInput: Locator;
  public readonly manualStreetInputLabel: Locator;
  public readonly manualStreetInputErrorMessage: Locator;
  public readonly apartmentInput: Locator;
  public readonly manualApartmentInput: Locator;
  public readonly apartmentInputLabel: Locator;
  public readonly manualApartmentInputLabel: Locator;
  public readonly optionalLabel: Locator;
  public readonly manualOptionalLabel: Locator;
  public readonly manualCityInputField: Locator;
  public readonly manualCityInputLabel: Locator;
  public readonly manualCityInputErrorMessage: Locator;
  public readonly manualStateDropdown: Locator;
  public readonly manualStateDropdownLabel: Locator;
  public readonly manualStateDropdownErrorMessage: Locator;
  public readonly manualZipCodeInput: Locator;
  public readonly manualZipCodeLabel: Locator;
  public readonly manualZipCodeErrorMessage: Locator;
  public readonly manualAddressPopupHeader: Locator;
  public readonly manualAddressPopupContent: Locator;
  public readonly manualAddressGoBackButton: Locator;
  public readonly manualAddressYesEnterManuallyButton: Locator;
  public readonly continueButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageHeader = page.locator("xpath=//app-recent-mover-flow//h1"); // @FindBy(xpath = "//app-recent-mover-flow//h1")
    this.pageSubHeader = page.locator("div[class='tui-body-text-1 recent-mover-sub-heading']"); // @FindBy(css = "div[class='tui-body-text-1 recent-mover-sub-heading']")
    this.recentMoverToggleHeader = page.locator("label[class='tui-field-label-text recent-mover-toggle-label mb-2']"); // @FindBy(css = "label[class='tui-field-label-text recent-mover-toggle-label mb-2']")
    this.yesToggleButton = page.locator("xpath=//mat-button-toggle[contains(.,'Yes')]"); // @FindBy(xpath = "//mat-button-toggle[contains(.,'Yes')]")
    this.noToggleButton = page.locator("xpath=//mat-button-toggle[contains(.,'No')]"); // @FindBy(xpath = "//mat-button-toggle[contains(.,'No')]")
    this.googlePrefilAddressInputField = page.locator("xpath=//address-autocomplete-input//input"); // @FindBy(xpath = "//address-autocomplete-input//input")
    this.googlePrefillAddressInputLabel = page.locator("xpath=//address-autocomplete-input//label//mat-label"); // @FindBy(xpath = "//address-autocomplete-input//label//mat-label")
    this.googlePrefillAddressErrorMessage = page.locator("xpath=//address-autocomplete-input//mat-error"); // @FindBy(xpath = "//address-autocomplete-input//mat-error")
    this.manualStreetInput = page.locator("xpath=//div[@id='formField_street']//input"); // @FindBy(xpath = "//div[@id='formField_street']//input")
    this.manualStreetInputLabel = page.locator("xpath=//div[@id='formField_street']//label//mat-label"); // @FindBy(xpath = "//div[@id='formField_street']//label//mat-label")
    this.manualStreetInputErrorMessage = page.locator("xpath=//div[@id='formField_street']//mat-error"); // @FindBy(xpath = "//div[@id='formField_street']//mat-error")
    this.apartmentInput = page.locator("xpath=//div[@id='formField_apartment']//input"); // @FindBy(xpath = "//div[@id='formField_apartment']//input")
    this.manualApartmentInput = page.locator("input[id='auto-manual-apartment__input-section']"); // @FindBy(css = "input[id='auto-manual-apartment__input-section']")
    this.apartmentInputLabel = page.locator("xpath=//div[@id='formField_apartment']//label//mat-label"); // @FindBy(xpath = "//div[@id='formField_apartment']//label//mat-label")
    this.manualApartmentInputLabel = page.locator("xpath=//div[@class='auto-manual-address-mailing-field']//label//mat-label"); // @FindBy(xpath = "//div[@class='auto-manual-address-mailing-field']//label//mat-label")
    this.optionalLabel = page.locator("xpath=//mat-hint[contains(.,'Optional')]"); // @FindBy(xpath = "//mat-hint[contains(.,'Optional')]")
    this.manualOptionalLabel = page.locator("xpath=//div[@class='auto-manual-address-mailing-field']//mat-hint"); // @FindBy(xpath = "//div[@class='auto-manual-address-mailing-field']//mat-hint")
    this.manualCityInputField = page.locator("xpath=//div[@id='formField_city']//input"); // @FindBy(xpath = "//div[@id='formField_city']//input")
    this.manualCityInputLabel = page.locator("xpath=//div[@id='formField_city']//label//mat-label"); // @FindBy(xpath = "//div[@id='formField_city']//label//mat-label")
    this.manualCityInputErrorMessage = page.locator("xpath=//div[@id='formField_city']//mat-error"); // @FindBy(xpath = "//div[@id='formField_city']//mat-error")
    this.manualStateDropdown = page.locator("xpath=//div[@id='mailingAddressDiv_state']//mat-select"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-select")
    this.manualStateDropdownLabel = page.locator("xpath=//div[@id='mailingAddressDiv_state']//label//mat-label"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//label//mat-label")
    this.manualStateDropdownErrorMessage = page.locator("xpath=//div[@id='mailingAddressDiv_state']//mat-error"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-error")
    this.manualZipCodeInput = page.locator("xpath=//mat-form-field[.//label[contains(.,'Zip Code')]]//input"); // @FindBy(xpath = "//mat-form-field[.//label[contains(.,'Zip Code')]]//input"),             @FindBy(xpath = "//div[@id='formField_zipCode']//input")     })
    this.manualZipCodeLabel = page.locator("xpath=//div[@id='formField_zipCode']//label//mat-label"); // @FindBy(xpath = "//div[@id='formField_zipCode']//label//mat-label")
    this.manualZipCodeErrorMessage = page.locator("xpath=//div[@id='formField_zipCode']//mat-error"); // @FindBy(xpath = "//div[@id='formField_zipCode']//mat-error")
    this.manualAddressPopupHeader = page.locator("#manualAddrHeading"); // @FindBy(id = "manualAddrHeading")
    this.manualAddressPopupContent = page.locator("#manualAddrContent"); // @FindBy(id = "manualAddrContent")
    this.manualAddressGoBackButton = page.locator("a[class='manual-addr_field-label-text']"); // @FindBy(css = "a[class='manual-addr_field-label-text']")
    this.manualAddressYesEnterManuallyButton = page.locator("button[class='tui-btn tui-btn-primary tui-button-text manual-addr__action-buttons']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary tui-button-text manual-addr__action-buttons']")
    this.continueButton = page.locator("button[class='tui-btn tui-btn-primary']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary']")
  }
}
