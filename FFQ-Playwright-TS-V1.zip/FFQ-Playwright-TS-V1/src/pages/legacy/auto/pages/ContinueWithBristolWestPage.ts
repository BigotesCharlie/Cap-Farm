// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.ContinueWithBristolWestPage. */
export class ContinueWithBristolWestPage extends CoreBasePage {
  public readonly farmersLogoImage: Locator;
  public readonly arrowImage: Locator;
  public readonly bristolWestLogoImage: Locator;
  public readonly continueToBWDialog: Locator;
  public readonly continueToBWDialogRebranding: Locator;
  public readonly continueToFGIAButton: Locator;
  public readonly continueToBWDialogTitleElement: Locator;
  public readonly continueToBWDialogTextElement: Locator;
  public readonly bwPageHeaderText: Locator;
  public readonly bwPageSubheadingText: Locator;
  public readonly bwAlternatePageSubheadingText: Locator;
  public readonly firstParagraphOfDisclaimerText: Locator;
  public readonly cantOfferText: Locator;
  public readonly goodNewsText: Locator;
  public readonly soundsGood: Locator;
  public readonly secondParagraphOfDisclaimerText: Locator;
  public readonly bwPageContentText: Locator;
  public readonly bwPageAgreeToTermsText: Locator;
  public readonly bwPageContinueButton: Locator;
  public readonly bwAlternatePageContinueButton: Locator;
  public readonly bwPageScrollboxText: Locator;
  public readonly thanksForChoosingBWDialog: Locator;
  public readonly thanksForChoosingBWDialogCloseButton: Locator;
  public readonly bwContactAnAgentLink: Locator;
  public readonly bwConsumerDisclosureLink: Locator;
  public readonly bwPrivacyNoticeLink: Locator;
  public readonly bwSummaryOfRightsLink: Locator;
  public readonly bwDialogTitle: Locator;
  public readonly bwAlternatePageDialogTitle: Locator;
  public readonly bwDialogBodyContent: Locator;
  public readonly bwDialogBodyContentpara1: Locator;
  public readonly bwDialogBodyContentpara2: Locator;
  public readonly bwDialogCancelButton: Locator;
  public readonly bwDialogAlternatePageCancelButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.farmersLogoImage = page.locator("#TUI_FARMERS_LOGO"); // @FindBy(id = "TUI_FARMERS_LOGO")
    this.arrowImage = page.locator("#TUI_ARROW_LOGO"); // @FindBy(id = "TUI_ARROW_LOGO")
    this.bristolWestLogoImage = page.locator("xpath=//img[@alt='Bristol West logo' and contains(@src,'svg')]"); // @FindBy(xpath = "//img[@alt='Bristol West logo' and contains(@src,'svg')]")
    this.continueToBWDialog = page.locator("xpath=//app-brightline-bw-popup"); // @FindBy(xpath="//app-brightline-bw-popup")
    this.continueToBWDialogRebranding = page.locator("xpath=//div[contains(@class,'branding-brightline-to-bw-page-container')]"); // @FindBy(xpath = "//div[contains(@class,'branding-brightline-to-bw-page-container')]")
    this.continueToFGIAButton = page.locator("div[class='fgia-rebrand-cta-section mt-10']>button"); // @FindBy(css="div[class='fgia-rebrand-cta-section mt-10']>button")
    this.continueToBWDialogTitleElement = page.locator("#bwHeaderTitle"); // @FindBy(id = "bwHeaderTitle")
    this.continueToBWDialogTextElement = page.locator("xpath=//div[contains(@class, 'brightline-to-bw-page-body')]"); // @FindBy(xpath = "//div[contains(@class, 'brightline-to-bw-page-body')]")
    this.bwPageHeaderText = page.locator(".brightline-to-bw-page__header"); // @FindBy(className = "brightline-to-bw-page__header")
    this.bwPageSubheadingText = page.locator("xpath=//div[contains(@class,'brightline-to-bw-page__subheading')] | //div[@class='brightline-to-bw-page-body'] | //h4[contains(@class,'tui-subtitle-text')]"); // @FindBy(xpath = "//div[contains(@class,'brightline-to-bw-page__subheading')] | //div[@class='brightline-to-bw-page-body'] | //h4[contains(@class,'tui-subtitle-text')]"),             @FindBy(xpath = "//h2[@class='tui-h2 mt-10']")     })
    this.bwAlternatePageSubheadingText = page.locator("xpath=//div[@class='row']/h4"); // @FindBy(xpath = "//div[@class='row']/h4"),             @FindBy(xpath = "//h2[@class='tui-h2 mt-10']"), // order is important here             @FindBy(xpath = "//h4[@class='tui-h4']")      })
    this.firstParagraphOfDisclaimerText = page.locator("xpath=//p[contains(@class,'disclaimer-text')][1]"); // @FindBy(xpath = "//p[contains(@class,'disclaimer-text')][1]")
    this.cantOfferText = page.locator("xpath=//h4[@class='tui-h4 mt-10']"); // @FindBy(xpath = "//h4[@class='tui-h4 mt-10']"),             @FindBy(xpath = "//p[contains(.,'We think')]")     })
    this.goodNewsText = page.locator("xpath=//p[@class='tui-body-bold mb-6']"); // @FindBy(xpath = "//p[@class='tui-body-bold mb-6']"),             @FindBy(xpath = "//p[contains(@class,'tui-body-bold mt-6')]")     })
    this.soundsGood = page.locator("xpath=//h4[contains(.,'Sound good?')]"); // @FindBy(xpath = "//h4[contains(.,'Sound good?')]"),             @FindBy(xpath = "//span[contains(.,'Sound good?')]")     })
    this.secondParagraphOfDisclaimerText = page.locator("xpath=//p[contains(@class,'disclaimer-text')][2]"); // @FindBy(xpath = "//p[contains(@class,'disclaimer-text')][2]")
    this.bwPageContentText = page.locator("xpath=//p[@data-test-id='DSCL_TEXT']"); // @FindBy(xpath = "//p[@data-test-id='DSCL_TEXT']")
    this.bwPageAgreeToTermsText = page.locator("xpath=//div[contains(@class, 'brightline-to-bw-page__continue-button')]//p"); // @FindBy(xpath = "//div[contains(@class, 'brightline-to-bw-page__continue-button')]//p")
    this.bwPageContinueButton = page.locator("xpath=//button[@data-test-id='BTN_TEXT']"); // @FindBy(xpath = "//button[@data-test-id='BTN_TEXT']")
    this.bwAlternatePageContinueButton = page.locator("xpath=//div/button[contains(text(),'Continue')]"); // @FindBy(xpath = "//div/button[contains(text(),'Continue')]")
    this.bwPageScrollboxText = page.locator(".brightline-to-bw-page__scroll-content"); // @FindBy(className = "brightline-to-bw-page__scroll-content")
    this.thanksForChoosingBWDialog = page.locator("xpath=//app-thank-you-brightline-bw-popup"); // @FindBy(xpath="//app-thank-you-brightline-bw-popup")
    this.thanksForChoosingBWDialogCloseButton = page.locator("xpath=//div[contains(@aria-labelledby, 'thankYouBW')]//button"); // @FindBy(xpath = "//div[contains(@aria-labelledby, 'thankYouBW')]//button")
    this.bwContactAnAgentLink = page.locator("xpath=//div[@class='brightline-to-bw-page__scroll-content']/p[1]/a"); // @FindBy(xpath = "//div[@class='brightline-to-bw-page__scroll-content']/p[1]/a")
    this.bwConsumerDisclosureLink = page.locator("xpath=//div[@class='brightline-to-bw-page__scroll-content']/p[2]/a[2]"); // @FindBy(xpath = "//div[@class='brightline-to-bw-page__scroll-content']/p[2]/a[2]")
    this.bwPrivacyNoticeLink = page.locator("xpath=//div[@class='brightline-to-bw-page__scroll-content']/p[3]/a"); // @FindBy(xpath = "//div[@class='brightline-to-bw-page__scroll-content']/p[3]/a")
    this.bwSummaryOfRightsLink = page.locator("xpath=//div[@class='brightline-to-bw-page__scroll-content']/p[4]/a"); // @FindBy(xpath = "//div[@class='brightline-to-bw-page__scroll-content']/p[4]/a")
    this.bwDialogTitle = page.locator("#bwHeaderTitle"); // @FindBy(id = "bwHeaderTitle"),             @FindBy(xpath = "//h4[@class='tui-h4']")     })
    this.bwAlternatePageDialogTitle = page.locator("xpath=//div[@class='brightline-to-bw-page-container']/h1"); // @FindBy(xpath = "//div[@class='brightline-to-bw-page-container']/h1")
    this.bwDialogBodyContent = page.locator(".brightline-to-bw-page-body"); // @FindBy(className = "brightline-to-bw-page-body")
    this.bwDialogBodyContentpara1 = page.locator("xpath=//div[@class='brightline-to-bw-page-container']//div/p[1]"); // @FindBy(xpath = "//div[@class='brightline-to-bw-page-container']//div/p[1]")
    this.bwDialogBodyContentpara2 = page.locator("xpath=//div[@class='brightline-to-bw-page-container']//div/p[2]"); // @FindBy(xpath = "//div[@class='brightline-to-bw-page-container']//div/p[2]")
    this.bwDialogCancelButton = page.locator("xpath=//div[contains(@class, 'blbw__actions-cancel-button')]"); // @FindBy(xpath = "//div[contains(@class, 'blbw__actions-cancel-button')]")
    this.bwDialogAlternatePageCancelButton = page.locator("xpath=//div/a[contains(text(),'No, thanks')]"); // @FindBy(xpath = "//div/a[contains(text(),'No, thanks')]"),             @FindBy(xpath = "//div[@class='branding-CTA-section']//button[contains(@class,'no-thanks')]")     })
  }
}
