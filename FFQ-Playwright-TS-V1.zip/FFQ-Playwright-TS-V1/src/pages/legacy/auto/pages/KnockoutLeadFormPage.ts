// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.KnockoutLeadFormPage. */
export class KnockoutLeadFormPage extends CoreBasePage {
  public readonly pageTitle: Locator;
  public readonly pageMessage: Locator;
  public readonly quoteInfoBody: Locator;
  public readonly displayedQuoteNumber: Locator;
  public readonly contactInfoTitle: Locator;
  public readonly emailAddressInputField: Locator;
  public readonly mobilePhoneNumberInputField: Locator;
  public readonly emailAddressErrorMessage: Locator;
  public readonly mobilePhoneNumberErrorMessage: Locator;
  public readonly disclaimer: Locator;
  public readonly ctaErrorMessage: Locator;
  public readonly ctaButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageTitle = page.locator("xpath=//app-knockout-lead-form//h1"); // @FindBy(xpath = "//app-knockout-lead-form//h1")
    this.pageMessage = page.locator("p[class='tui-body quote-info']"); // @FindBy(css = "p[class='tui-body quote-info']")
    this.quoteInfoBody = page.locator("xpath=//p[contains(@class,'tui-body quote-reference-number')]"); // @FindBy(xpath = "//p[contains(@class,'tui-body quote-reference-number')]")
    this.displayedQuoteNumber = page.locator("xpath=//p[@class='tui-body quote-reference-number ng-star-inserted']//span"); // @FindBy(xpath = "//p[@class='tui-body quote-reference-number ng-star-inserted']//span")
    this.contactInfoTitle = page.locator("div[class='auto-knockout-lead__fields-section']>p"); // @FindBy(css = "div[class='auto-knockout-lead__fields-section']>p")
    this.emailAddressInputField = page.locator("xpath=//div[@class='email-address']//input"); // @FindBy(xpath = "//div[@class='email-address']//input")
    this.mobilePhoneNumberInputField = page.locator("xpath=//div[@class='phone-number']//input"); // @FindBy(xpath = "//div[@class='phone-number']//input")
    this.emailAddressErrorMessage = page.locator("xpath=//div[@class='email-address']//mat-error"); // @FindBy(xpath = "//div[@class='email-address']//mat-error")
    this.mobilePhoneNumberErrorMessage = page.locator("xpath=//div[@class='phone-number']//mat-error"); // @FindBy(xpath = "//div[@class='phone-number']//mat-error")
    this.disclaimer = page.locator("xpath=//p[contains(@class,'ffq-lead-form-disclaimer')]"); // @FindBy(xpath = "//p[contains(@class,'ffq-lead-form-disclaimer')]")
    this.ctaErrorMessage = page.locator("xpath=//div[contains(@class,'auto-knockout-cta-validation-text-holder')]//span"); // @FindBy(xpath = "//div[contains(@class,'auto-knockout-cta-validation-text-holder')]//span")
    this.ctaButton = page.locator("#ffq-lead-form-submit-button"); // @FindBy(id = "ffq-lead-form-submit-button")
  }
}
