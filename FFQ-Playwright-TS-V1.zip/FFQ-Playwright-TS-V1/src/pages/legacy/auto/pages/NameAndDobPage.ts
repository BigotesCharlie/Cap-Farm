// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.NameAndDobPage. */
export class NameAndDobPage extends CoreBasePage {
  public readonly continueButtons: Locator;
  public readonly agreeButton: Locator;
  public readonly firstNameInputField: Locator;
  public readonly nameAndDobTitle: Locator;
  public readonly nameAndDobSubtitle: Locator;
  public readonly creditCheckDisclaimerTextElement: Locator;
  public readonly privacyPolicyDisclaimerTextElement: Locator;
  public readonly disclaimerCredit: Locator;
  public readonly drivingScore: Locator;
  public readonly drivingScoreExtended: Locator;
  public readonly showMoreButton: Locator;
  public readonly ctaDisclaimer: Locator;
  public readonly personalInfoUseLink: Locator;
  public readonly privacyPolicy: Locator;
  public readonly privacyCenterPageHeader: Locator;
  public readonly mediaAlphaCreditCheckDisclaimerTextElement: Locator;
  public readonly mediaAlphaConsumerReportDisclaimerTextElement: Locator;
  public readonly mediaAlphaExtraordinaryCircumstancesTextElement: Locator;
  public readonly mediaAlphaPrivacyPolicyDisclaimerTextElement: Locator;
  public readonly mediaAlphaConsumerReportDisclaimerTextAlternateElement: Locator;
  public readonly mediaAlphaConsumerReportEntititesTextAlternateElement: Locator;
  public readonly mediaAlphaPrivacyPolicyDisclaimerTextAlternateElement: Locator;
  public readonly listOfDisclaimerTextElements: Locator;
  public readonly highlightedTooltipRebrandContainer: Locator;
  public readonly highlightedTooltipBulbIcon: Locator;
  public readonly highlightedTooltipTitle: Locator;
  public readonly highlightedTooltipContent: Locator;

  public constructor(page: Page) {
    super(page);
    this.continueButtons = page.locator("xpath=//button[@data-tui-tracking-id='personal-info__continue-button-cta' or contains(@class, 'partner-premium-details__cta')]"); // @FindBy(xpath = "//button[@data-tui-tracking-id='personal-info__continue-button-cta' or contains(@class, 'partner-premium-details__cta')]")
    this.agreeButton = page.locator("xpath=//button[@class='tui-btn tui-btn-primary address-form__continue-cta']"); // @FindBy(xpath = "//button[@class='tui-btn tui-btn-primary address-form__continue-cta']")
    this.firstNameInputField = page.locator("xpath=//input[contains(@aria-label, '"); // @FindBy(xpath = "//input[contains(@aria-label, '"+ FIRST_NAME + "')]")
    this.nameAndDobTitle = page.locator("xpath=//app-personal-info//h1[@class='tui-h1 ng-star-inserted']"); // @FindBy(xpath = "//app-personal-info//h1[@class='tui-h1 ng-star-inserted']"),             @FindBy(xpath = "//*[contains(@class, 'personal-info_name_dob_h1')]/h1")     })
    this.nameAndDobSubtitle = page.locator("#personal-info_name_dob-subheading"); // @FindBy(id = "personal-info_name_dob-subheading")
    this.creditCheckDisclaimerTextElement = page.locator("xpath=//*[contains(@class, 'disclaimer__credit-report')]"); // @FindBy(xpath = "//*[contains(@class, 'disclaimer__credit-report')]")
    this.privacyPolicyDisclaimerTextElement = page.locator("xpath=//*[starts-with(@class, 'disclaimer__color')]"); // @FindBy(xpath = "//*[starts-with(@class, 'disclaimer__color')]")
    this.disclaimerCredit = page.locator("xpath=//div[contains(@class,'disclaimer__credit')]//p[1]"); // @FindBy(xpath = "//div[contains(@class,'disclaimer__credit')]//p[1]")
    this.drivingScore = page.locator("xpath=//div[contains(@class,'disclaimer__credit')]//p[2]"); // @FindBy(xpath = "//div[contains(@class,'disclaimer__credit')]//p[2]")
    this.drivingScoreExtended = page.locator("xpath=//div[contains(@class,'auto-disclaimer__color d-grid gap-4')]"); // @FindBy(xpath = "//div[contains(@class,'auto-disclaimer__color d-grid gap-4')]")
    this.showMoreButton = page.locator("#showMoreButton"); // @FindBy(id = "showMoreButton")
    this.ctaDisclaimer = page.locator("xpath=//div[starts-with(@class,'disclaimer__color')]"); // @FindBy(xpath = "//div[starts-with(@class,'disclaimer__color')]")
    this.personalInfoUseLink = page.getByRole('link', { name: "Personal information use", exact: true }); // @FindBy(linkText = "Personal information use")
    this.privacyPolicy = page.locator("xpath=//a[contains(@data-tui-tracking-id, 'privacy-policy-hyperlink')]"); // @FindBy(xpath = "//a[contains(@data-tui-tracking-id, 'privacy-policy-hyperlink')]")
    this.privacyCenterPageHeader = page.locator("xpath=//span[contains(text(),'Privacy Center') or contains(text(),'Privacy Policy') or contains(text(),'Enterprise Privacy Statement')]"); // @FindBy(xpath = "//span[contains(text(),'Privacy Center') or contains(text(),'Privacy Policy') or contains(text(),'Enterprise Privacy Statement')]")
    this.mediaAlphaCreditCheckDisclaimerTextElement = page.locator("xpath=//div[contains(@class,'tui-stacking-top-md disclaimer__credit-report')]/p[1]"); // @FindBy(xpath = "//div[contains(@class,'tui-stacking-top-md disclaimer__credit-report')]/p[1]"),             @FindBy (xpath = MEDIA_ALPHA_COMMON_XPATH + "//p[1]")     })
    this.mediaAlphaConsumerReportDisclaimerTextElement = page.locator("xpath=//div[contains(@class,'tui-stacking-top-md disclaimer__credit-report')]/p[3]"); // @FindBy(xpath = "//div[contains(@class,'tui-stacking-top-md disclaimer__credit-report')]/p[3]"),             @FindBy (xpath = MEDIA_ALPHA_COMMON_XPATH + "//p[2]")     })
    this.mediaAlphaExtraordinaryCircumstancesTextElement = page.locator("[data-legacy-field=\"mediaAlphaExtraordinaryCircumstancesTextElement\"]"); // @FindBy(xpath = MEDIA_ALPHA_COMMON_XPATH + "//p[3]")
    this.mediaAlphaPrivacyPolicyDisclaimerTextElement = page.locator("xpath=//div[contains(@class,'disclaimer__color mt-3 ng-star-inserted')]//p"); // @FindBy(xpath = MEDIA_ALPHA_COMMON_XPATH + "//p[4]"),             @FindBy (xpath = "//div[contains(@class,'disclaimer__color mt-3 ng-star-inserted')]//p")     })
    this.mediaAlphaConsumerReportDisclaimerTextAlternateElement = page.locator("[data-legacy-field=\"mediaAlphaConsumerReportDisclaimerTextAlternateElement\"]"); // @FindBy(xpath = MEDIA_ALPHA_COMMON_XPATH + "//p[5]")
    this.mediaAlphaConsumerReportEntititesTextAlternateElement = page.locator("[data-legacy-field=\"mediaAlphaConsumerReportEntititesTextAlternateElement\"]"); // @FindBy(xpath = MEDIA_ALPHA_COMMON_XPATH + "//p[6]")
    this.mediaAlphaPrivacyPolicyDisclaimerTextAlternateElement = page.locator("[data-legacy-field=\"mediaAlphaPrivacyPolicyDisclaimerTextAlternateElement\"]"); // @FindBy(xpath = MEDIA_ALPHA_COMMON_XPATH + "/p[1]")
    this.listOfDisclaimerTextElements = page.locator("[data-legacy-field=\"listOfDisclaimerTextElements\"]"); // @FindBy(xpath = MEDIA_ALPHA_COMMON_XPATH + "//p")
    this.highlightedTooltipRebrandContainer = page.locator("div.highlighted-tooltip-rebrand"); // @FindBy(css = "div.highlighted-tooltip-rebrand")
    this.highlightedTooltipBulbIcon = page.locator("div.highlighted-tooltip img.lightbulbblue-icon"); // @FindBy(css = "div.highlighted-tooltip img.lightbulbblue-icon")
    this.highlightedTooltipTitle = page.locator("div.label-text span.tui-body-text-bold"); // @FindBy(css = "div.label-text span.tui-body-text-bold")
    this.highlightedTooltipContent = page.locator("div.label-text span.tui-body-text-1"); // @FindBy(css = "div.label-text span.tui-body-text-1")
  }
}
