// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.KnockOutPage. */
export class KnockOutPage extends CoreBasePage {
  public readonly knockOutHeader: Locator;
  public readonly knockOutQuoteNumber: Locator;
  public readonly agentPhoneNumber: Locator;
  public readonly emailAgentButton: Locator;
  public readonly agentImage: Locator;
  public readonly farmersDotComLink: Locator;
  public readonly needmoreHelp: Locator;
  public readonly callCustomerService: Locator;
  public readonly phoneNumber: Locator;
  public readonly inconvenienceHeader: Locator;
  public readonly inconvenienceQuoteNumber: Locator;
  public readonly inconvenienceCallCustomerService: Locator;
  public readonly invconveniencePhoneNumber: Locator;
  public readonly inconvenienceFarmersDotComLink: Locator;
  public readonly restrictedKO_PageHeader: Locator;
  public readonly restrictedKO_body_content: Locator;
  public readonly restrictedKO_agentPhoneNumber: Locator;

  public constructor(page: Page) {
    super(page);
    this.knockOutHeader = page.locator("xpath=//*[@id='knock-out_header-title'] | //*[@class='knock-out_header-title']"); // @FindBy(xpath = "//*[@id='knock-out_header-title'] | //*[@class='knock-out_header-title']")
    this.knockOutQuoteNumber = page.locator("xpath=//*[@id='knock-out_body_quote_number'] | //*[@class='knock-out_body_quote_number']"); // @FindBy(xpath = "//*[@id='knock-out_body_quote_number'] | //*[@class='knock-out_body_quote_number']")
    this.agentPhoneNumber = page.locator("#FFQAuto_Modal_discountOutAgentPhone"); // @FindBy(id = "FFQAuto_Modal_discountOutAgentPhone")
    this.emailAgentButton = page.locator("#FFQAuto_Modal_discountOutMailBtn"); // @FindBy(id = "FFQAuto_Modal_discountOutMailBtn")
    this.agentImage = page.locator("#FFQAuto_Modal_discountOutAgentImg"); // @FindBy(id = "FFQAuto_Modal_discountOutAgentImg")
    this.farmersDotComLink = page.locator("#FFQAuto_Modal_discountOutGoToFarmersTag"); // @FindBy(id = "FFQAuto_Modal_discountOutGoToFarmersTag")
    this.needmoreHelp = page.locator("#knock-out_body_noagent"); // @FindBy(id = "knock-out_body_noagent")
    this.callCustomerService = page.locator("#knock-out_body_call-custome"); // @FindBy(id = "knock-out_body_call-custome")
    this.phoneNumber = page.locator("#default-phone"); // @FindBy(id = "default-phone")
    this.inconvenienceHeader = page.locator("#FFQAuto_Commonpage_inconvHeader"); // @FindBy(id = "FFQAuto_Commonpage_inconvHeader")
    this.inconvenienceQuoteNumber = page.locator("xpath=//*[@class='qteNumber ng-binding']"); // @FindBy(xpath = "//*[@class='qteNumber ng-binding']")
    this.inconvenienceCallCustomerService = page.locator("#FFQAuto_Commonpage_inconvContent"); // @FindBy(id = "FFQAuto_Commonpage_inconvContent")
    this.invconveniencePhoneNumber = page.locator("#FFQAuto_Commonpage_inconvPhone"); // @FindBy(id = "FFQAuto_Commonpage_inconvPhone")
    this.inconvenienceFarmersDotComLink = page.locator("#FFQAuto_Commonpage_inconvFarmersLink"); // @FindBy(id = "FFQAuto_Commonpage_inconvFarmersLink")
    this.restrictedKO_PageHeader = page.locator("#knockout_title"); // @FindBy(id = "knockout_title")
    this.restrictedKO_body_content = page.locator("xpath=//app-knockout/form/p"); // @FindBy(xpath = "//app-knockout/form/p")
    this.restrictedKO_agentPhoneNumber = page.locator("xpath=//app-agent-details//div/div[contains(@class,'agent-details-container')]/p/a[contains(@aria-label,'Contact farmers representative')]"); // @FindBy(xpath = "//app-agent-details//div/div[contains(@class,'agent-details-container')]/p/a[contains(@aria-label,'Contact farmers representative')]")
  }
}
