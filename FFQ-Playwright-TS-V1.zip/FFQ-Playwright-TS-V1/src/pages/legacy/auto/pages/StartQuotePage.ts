// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.StartQuotePage. */
export class StartQuotePage extends CoreBasePage {
  public readonly dropdownArrow: Locator;
  public readonly autoDropDownOption: Locator;
  public readonly zipCodeInput: Locator;
  public readonly startQuoteButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.dropdownArrow = page.locator("div.mat-select-arrow-wrapper"); // @FindBy(css = "div.mat-select-arrow-wrapper")
    this.autoDropDownOption = page.locator("xpath=//mat-option[./span[text() = 'Auto']]"); // @FindBy(xpath = "//mat-option[./span[text() = 'Auto']]")
    this.zipCodeInput = page.locator("input[formcontrolname]"); // @FindBy(css = "input[formcontrolname]")
    this.startQuoteButton = page.locator("xpath=//button[text()='START QUOTE']"); // @FindBy(xpath = "//button[text()='START QUOTE']")
  }
}
