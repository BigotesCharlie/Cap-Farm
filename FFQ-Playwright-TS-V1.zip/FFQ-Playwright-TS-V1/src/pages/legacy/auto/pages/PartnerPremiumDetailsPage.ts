// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.PartnerPremiumDetailsPage. */
export class PartnerPremiumDetailsPage extends CoreBasePage {
  public readonly partnerDetailsPageTitle: Locator;

  public constructor(page: Page) {
    super(page);
    this.partnerDetailsPageTitle = page.locator("xpath=//app-partner-premium-details//h1"); // @FindBy(xpath = "//app-partner-premium-details//h1")
  }
}
