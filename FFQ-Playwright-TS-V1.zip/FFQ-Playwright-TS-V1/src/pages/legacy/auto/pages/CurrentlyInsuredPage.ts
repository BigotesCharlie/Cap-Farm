// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.CurrentlyInsuredPage. */
export class CurrentlyInsuredPage extends CoreBasePage {
  public readonly getStartedHeading: Locator;
  public readonly currentlyInsuredOrNot: Locator;
  public readonly yesButton: Locator;
  public readonly noButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.getStartedHeading = page.locator("xpath=//h1[@class='tui-h1 insured-Model__title']"); // @FindBy(xpath = "//h1[@class='tui-h1 insured-Model__title']")
    this.currentlyInsuredOrNot = page.locator("xpath=//div[@class='interstitial-page-inner-padding']/p"); // @FindBy(xpath = "//div[@class='interstitial-page-inner-padding']/p")
    this.yesButton = page.locator("xpath=*//button[contains(text(),'Yes')]"); // @FindBy(xpath = "*//button[contains(text(),'Yes')]")
    this.noButton = page.locator("xpath=*//button[contains(text(),'No')]"); // @FindBy(xpath = "*//button[contains(text(),'No')]")
  }
}
