// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.FarmersGroupSelectPage. */
export class FarmersGroupSelectPage extends CoreBasePage {
  public readonly farmersGroupSelectPageTitle: Locator;
  public readonly farmersGroupSelectPageDescription: Locator;
  public readonly farmersGroupSelectPageDisclaimer: Locator;
  public readonly headerPhoneNumberLink: Locator;
  public readonly callNowButton: Locator;
  public readonly quoteWithFarmersOnlineLink: Locator;
  public readonly employerGroupAffinity: Locator;
  public readonly pageContent: Locator;
  public readonly imageContainer: Locator;
  public readonly whereYouWorkContext: Locator;
  public readonly employerSelectDropdown: Locator;
  public readonly cardMessage: Locator;
  public readonly cardErrorMessage: Locator;
  public readonly cardSuccessMessage: Locator;
  public readonly farmersGroupSelectBenefitsTitle: Locator;
  public readonly discountDescriptions: Locator;
  public readonly disclaimerContent: Locator;
  public readonly continueWithDiscountButton: Locator;
  public readonly skipThisDiscountButton: Locator;
  public readonly selectedInsuranceType: Locator;

  public constructor(page: Page) {
    super(page);
    this.farmersGroupSelectPageTitle = page.locator("xpath=//div[@class='fws-page-container']//h1"); // @FindBy(xpath = "//div[@class='fws-page-container']//h1")
    this.farmersGroupSelectPageDescription = page.locator(".landing-text"); // @FindBy(className = "landing-text")
    this.farmersGroupSelectPageDisclaimer = page.locator("xpath=//div[@class='container']//p/span[@class='small-text']"); // @FindBy(xpath = "//div[@class='container']//p/span[@class='small-text']")
    this.headerPhoneNumberLink = page.locator("xpath=//p/a[contains(@href,'tel:')]"); // @FindBy(xpath = "//p/a[contains(@href,'tel:')]")
    this.callNowButton = page.locator("xpath=//a[contains(@class, 'button-cta--desktop')][contains(@href,'tel:')]"); // @FindBy(xpath = "//a[contains(@class, 'button-cta--desktop')][contains(@href,'tel:')]")
    this.quoteWithFarmersOnlineLink = page.locator("xpath=//a[contains(@class, 'button-cta--desktop')][@data-gtm='Farmers_COLPGS_FFQLINK_Header']"); // @FindBy(xpath = "//a[contains(@class, 'button-cta--desktop')][@data-gtm='Farmers_COLPGS_FFQLINK_Header']")
    this.employerGroupAffinity = page.locator("#employerdiv"); // @FindBy(id = "employerdiv")
    this.pageContent = page.locator("xpath=//div[@class='tui-info-box-content mt-8']//p"); // @FindBy(xpath = "//div[@class='tui-info-box-content mt-8']//p")
    this.imageContainer = page.locator("#fws-page-employer-img-container"); // @FindBy(id = "fws-page-employer-img-container")
    this.whereYouWorkContext = page.locator("#whereYouWork"); // @FindBy(id = "whereYouWork")
    this.employerSelectDropdown = page.locator("xpath=//input[@id='mat-input-fwsField']"); // @FindBy(xpath = "//input[@id='mat-input-fwsField']")
    this.cardMessage = page.locator("#cardMessage"); // @FindBy(id = "cardMessage")
    this.cardErrorMessage = page.locator("#cardErrorMessage"); // @FindBy(id = "cardErrorMessage")
    this.cardSuccessMessage = page.locator("#cardSuccessMessage"); // @FindBy(id = "cardSuccessMessage")
    this.farmersGroupSelectBenefitsTitle = page.locator("xpath=//div[@class='fgs_employer-card-success_title tui-body-bold']"); // @FindBy(xpath = "//div[@class='fgs_employer-card-success_title tui-body-bold']")
    this.discountDescriptions = page.locator("xpath=//span[@class='fgs_employer-card-success_desc']//li"); // @FindBy(xpath = "//span[@class='fgs_employer-card-success_desc']//li")
    this.disclaimerContent = page.locator("xpath=//span[@id='disclaimer']"); // @FindBy(xpath = "//span[@id='disclaimer']")
    this.continueWithDiscountButton = page.locator("xpath=//button[contains(text(),'Continue')]"); // @FindBy(xpath = "//button[contains(text(),'Continue')]")
    this.skipThisDiscountButton = page.locator("xpath=//a[contains(text(),' Skip this discount ')]"); // @FindBy(xpath = "//a[contains(text(),' Skip this discount ')]")
    this.selectedInsuranceType = page.locator("xpath=//span[@class='selected-indicator']/preceding-sibling::span"); // @FindBy(xpath = "//span[@class='selected-indicator']/preceding-sibling::span")
  }
}
