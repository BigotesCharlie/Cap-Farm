// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.CallForQuotePage. */
export class CallForQuotePage extends CoreBasePage {
  public readonly pageHeader: Locator;
  public readonly subHeaderText: Locator;
  public readonly phoneNumber: Locator;
  public readonly imageContainer: Locator;
  public readonly disclaimerContent: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageHeader = page.locator("xpath=*//span[contains(text(),'Thanks for starting')]"); // @FindBy(xpath = "*//span[contains(text(),'Thanks for starting')]")
    this.subHeaderText = page.locator("xpath=//div/p[contains(text(),'Speaking with one')]"); // @FindBy(xpath = "//div/p[contains(text(),'Speaking with one')]")
    this.phoneNumber = page.locator("xpath=//p[@class='landing-text']//a"); // @FindBy(xpath = "//p[@class='landing-text']//a")
    this.imageContainer = page.locator("xpath=*//img[@class='lozad FarmersTestImage']"); // @FindBy(xpath = "*//img[@class='lozad FarmersTestImage']")
    this.disclaimerContent = page.locator("xpath=//div[contains(@class,'container-flex farmerscolorsection  with-bgcolor ')]//span[@class='small-text']"); // @FindBy(xpath = "//div[contains(@class,'container-flex farmerscolorsection  with-bgcolor ')]//span[@class='small-text']")
  }
}
