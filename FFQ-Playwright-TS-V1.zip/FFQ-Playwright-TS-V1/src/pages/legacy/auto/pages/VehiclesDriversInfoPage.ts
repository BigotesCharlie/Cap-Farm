// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.VehiclesDriversInfoPage. */
export class VehiclesDriversInfoPage extends CoreBasePage {
  public readonly vehiclesDriversPageTitle: Locator;
  public readonly listOfAllEditButtonOfAdditionalDriverDetails: Locator;
  public readonly pageDesc: Locator;
  public readonly addAnotherDriverButton: Locator;
  public readonly addAnotherVehicleButton: Locator;
  public readonly foundVehicles: Locator;
  public readonly editVehicleLinks: Locator;
  public readonly selectedVehiclesCheckboxes: Locator;
  public readonly selectedVehiclesEditReviewButton: Locator;
  public readonly uncheckedVehiclesCheckboxes: Locator;
  public readonly foundDrivers: Locator;
  public readonly selectedDrivers: Locator;
  public readonly uncheckedDriversCheckboxes: Locator;
  public readonly uncheckedDriversNames: Locator;
  public readonly continueButton: Locator;
  public readonly infoSideSheetBackButton: Locator;
  public readonly occupationSelectionModalLeftChevron: Locator;
  public readonly infoSideSheetHeader: Locator;
  public readonly infoSideSheetCloseButton: Locator;
  public readonly infoSideSheetContentHeaders: Locator;
  public readonly infoSideSheetContents: Locator;
  public readonly addOrEditVehicleSideSheetHeader: Locator;
  public readonly vinInputField: Locator;
  public readonly vinInputFieldErrorMessage: Locator;
  public readonly weWillVerifyYourVinText: Locator;
  public readonly yearErrorMessage: Locator;
  public readonly acquireErrorMessage: Locator;
  public readonly firstNameErrorMessage: Locator;
  public readonly firstName: Locator;
  public readonly lastNameErrorMessage: Locator;
  public readonly dobEntryField: Locator;
  public readonly dobErrorMessage: Locator;
  public readonly genderErrorMessage: Locator;
  public readonly spouseGenderErrorMessage: Locator;
  public readonly usOrCaErrorMessage: Locator;
  public readonly willBeDrivingErrorMessage: Locator;
  public readonly currentlyInsuredErrorMessage: Locator;
  public readonly closeButtonForSpouseNestedSheet: Locator;
  public readonly vinHelperInfoTip: Locator;
  public readonly helperVinContent: Locator;
  public readonly driverSideDoorText: Locator;
  public readonly driverSideDoorImage: Locator;
  public readonly driverSideDashboardText: Locator;
  public readonly driverSideDashboardImage: Locator;
  public readonly registrationAndInsuranceCardImage: Locator;
  public readonly vinInfoIcon: Locator;
  public readonly vinDescHeader: Locator;
  public readonly vinDescCarImage: Locator;
  public readonly vinDescGreenCheck: Locator;
  public readonly vinDescContent: Locator;
  public readonly vinRemoveButtonDeleteIcon: Locator;
  public readonly vinRemoveButton: Locator;
  public readonly vinTipsText: Locator;
  public readonly vinTipsLists: Locator;
  public readonly yearDropDown: Locator;
  public readonly yearDropDownLabel: Locator;
  public readonly makeInputField: Locator;
  public readonly makeInputLabel: Locator;
  public readonly modelInputField: Locator;
  public readonly modelInputLabel: Locator;
  public readonly typeDropDown: Locator;
  public readonly typeDropDownLabel: Locator;
  public readonly usedForSectionLabel: Locator;
  public readonly usedForSInfoIcon: Locator;
  public readonly defaultPressedUsedForButton: Locator;
  public readonly personalButton: Locator;
  public readonly businessButton: Locator;
  public readonly rideshareCheckboxInput: Locator;
  public readonly rideshareCheckboxText: Locator;
  public readonly uberLiftParenthesisInfo: Locator;
  public readonly ownershipSectionHeader: Locator;
  public readonly ownershipSectionInfoIcon: Locator;
  public readonly defaultPressedOwnershipToggle: Locator;
  public readonly ownedToggle: Locator;
  public readonly leasedToggle: Locator;
  public readonly financedToggle: Locator;
  public readonly acquiredSectionHeader: Locator;
  public readonly acquiredSectionMatIcon: Locator;
  public readonly acquiredSectionDateInputField: Locator;
  public readonly acquiredSectionDatePicker: Locator;
  public readonly acquiredSectionDateInputFieldHint: Locator;
  public readonly parkedAtSectionHeader: Locator;
  public readonly parkedAtSectionInfoIcon: Locator;
  public readonly parkedAtPrimaryRadioButton: Locator;
  public readonly parkedAtOtherRadioButton: Locator;
  public readonly otherGarageAddressInputField: Locator;
  public readonly otherGarageApartmentInputField: Locator;
  public readonly otherGarageCityInputField: Locator;
  public readonly otherGarageStateInputField: Locator;
  public readonly otherGarageZipInputField: Locator;
  public readonly theftRecoveryCheckbox: Locator;
  public readonly addVehicleButton: Locator;
  public readonly cancelButton: Locator;
  public readonly addAnotherVehicleButtonSideSheet: Locator;
  public readonly doneAddingVehiclesSideSheet: Locator;
  public readonly continueToDriversButtonSideSheet: Locator;
  public readonly addVehiclesSaveChangesButton: Locator;
  public readonly addEditDriverHeader: Locator;
  public readonly addAnotherIncident: Locator;
  public readonly addAnotherIncidentNestedSpouse: Locator;
  public readonly changeSpouseSelectionLink: Locator;
  public readonly someoneNotOnThisQuoteButton: Locator;
  public readonly addASpouseSideSheetHeader: Locator;
  public readonly letsFindMyOccupationButton: Locator;
  public readonly letsFindMyOccupationButtonSpouse: Locator;
  public readonly occupationSideSheetHeader: Locator;
  public readonly displayedOccupations: Locator;
  public readonly driverSaveButton: Locator;
  public readonly occupationSaveButton: Locator;
  public readonly occupationCancelButton: Locator;
  public readonly addDriverSaveChangesButton: Locator;
  public readonly ageDriverRecievedLicenseInput: Locator;
  public readonly doneAddingDriverButton: Locator;
  public readonly addDriverButton: Locator;
  public readonly priorPolicyExpDateDropDown: Locator;
  public readonly priorPolicyExpDateDropDownBeforeOption: Locator;
  public readonly priorPolicyExpDateDropDownOnOrAfterOption: Locator;
  public readonly checkboxLabels: Locator;
  public readonly currentPrincipalPersonalInjuryDropDown: Locator;
  public readonly financialFilingMatIcon: Locator;
  public readonly financialFilingTooltipHeader1: Locator;
  public readonly financialFilingTooltipHeader2: Locator;
  public readonly financialFilingTooltipDescription1: Locator;
  public readonly financialFilingTooltipDescription2: Locator;
  public readonly addVehicleSideSheetHeader: Locator;
  public readonly editVehicleSideSheetHeader: Locator;
  public readonly insuredInPast6MonthsRadioButtons: Locator;
  public readonly pageCTAErrorMessage: Locator;

  public constructor(page: Page) {
    super(page);
    this.vehiclesDriversPageTitle = page.locator("xpath=//app-vehicles-drivers-main-screen//h1"); // @FindBy(xpath = "//app-vehicles-drivers-main-screen//h1")
    this.listOfAllEditButtonOfAdditionalDriverDetails = page.locator("xpath=//div[contains(@class,'auto-drivers-card') and contains(text(),'Additional driver')]/../../following-sibling::div/div/a[contains(text(),'Edit driver')]"); // @FindBy(xpath = "//div[contains(@class,'auto-drivers-card') and contains(text(),'Additional driver')]/../../following-sibling::div/div/a[contains(text(),'Edit driver')]")
    this.pageDesc = page.locator("xpath=//div[contains(@class,'highlighted-tooltip-card')]/div"); // @FindBy(xpath = "//div[contains(@class,'highlighted-tooltip-card')]/div")
    this.addAnotherDriverButton = page.locator("xpath=//button[@class='tui-btn tui-btn-cta add-button ng-star-inserted' and contains(.,'Add another driver')]"); // @FindBy(xpath = "//button[@class='tui-btn tui-btn-cta add-button ng-star-inserted' and contains(.,'Add another driver')]")
    this.addAnotherVehicleButton = page.locator("xpath=//button[@class='tui-btn tui-btn-cta add-button ng-star-inserted' and contains(.,'Add another vehicle')]"); // @FindBy(xpath = "//button[@class='tui-btn tui-btn-cta add-button ng-star-inserted' and contains(.,'Add another vehicle')]")
    this.foundVehicles = page.locator("xpath=//app-vehicle-card//div[@class='h6 custom-h6 fw-semibold']"); // @FindBy(xpath = "//app-vehicle-card//div[@class='h6 custom-h6 fw-semibold']")
    this.editVehicleLinks = page.locator("xpath=//app-vehicle-card//a[contains(text(),'Edit')]"); // @FindBy(xpath = "//app-vehicle-card//a[contains(text(),'Edit')]")
    this.selectedVehiclesCheckboxes = page.locator("xpath=//div[@class='card auto-vehicles-card-item vehicle-selected']//input"); // @FindBy(xpath = "//div[@class='card auto-vehicles-card-item vehicle-selected']//input")
    this.selectedVehiclesEditReviewButton = page.locator("xpath=//div[@class='card auto-vehicles-card-item vehicle-selected']//a"); // @FindBy(xpath = "//div[@class='card auto-vehicles-card-item vehicle-selected']//a")
    this.uncheckedVehiclesCheckboxes = page.locator("[data-legacy-field=\"uncheckedVehiclesCheckboxes\"]"); // @FindBy(xpath = UNSELECTED_VEHICLE_CARD_XPATH + "//input[@type='checkbox']")
    this.foundDrivers = page.locator("xpath=//app-driver-card//div[contains(@class,'driver-name-header')]"); // @FindBy(xpath = "//app-driver-card//div[contains(@class,'driver-name-header')]")
    this.selectedDrivers = page.locator("xpath=//div[@class='card auto-drivers-card-item driver-selected']//div[contains(@class,'driver-name-header')]"); // @FindBy(xpath = "//div[@class='card auto-drivers-card-item driver-selected']//div[contains(@class,'driver-name-header')]")
    this.uncheckedDriversCheckboxes = page.locator("[data-legacy-field=\"uncheckedDriversCheckboxes\"]"); // @FindBy(xpath = UNSELECTED_DRIVER_CARD_XPATH + "//input[@type='checkbox']")
    this.uncheckedDriversNames = page.locator("[data-legacy-field=\"uncheckedDriversNames\"]"); // @FindBy(xpath = UNSELECTED_DRIVER_CARD_XPATH + "//div[contains(@class,'driver-name-header')]")
    this.continueButton = page.locator("xpath=//div[contains(@class,'cta-section')]//button[@class='tui-btn tui-btn-primary']"); // @FindBy(xpath = "//div[contains(@class,'cta-section')]//button[@class='tui-btn tui-btn-primary']")
    this.infoSideSheetBackButton = page.locator("xpath=//div[@class='heading-area']//mat-icon[contains(.,'chevron_left')]"); // @FindBy(xpath = "//div[@class='heading-area']//mat-icon[contains(.,'chevron_left')]")
    this.occupationSelectionModalLeftChevron = page.locator("xpath=//app-occupation-selection//mat-icon[.='chevron_left']"); // @FindBy(xpath = "//app-occupation-selection//mat-icon[.='chevron_left']")
    this.infoSideSheetHeader = page.locator("xpath=//app-help-text-sidesheet//h1"); // @FindBy(xpath = "//app-help-text-sidesheet//h1")
    this.infoSideSheetCloseButton = page.locator("xpath=//app-help-text-sidesheet//div[@class='heading-area']//button[contains(.,'close')]"); // @FindBy(xpath = "//app-help-text-sidesheet//div[@class='heading-area']//button[contains(.,'close')]")
    this.infoSideSheetContentHeaders = page.locator("xpath=//div[contains(@class,'help-text-sidesheet-container')]//h2"); // @FindBy(xpath = "//div[contains(@class,'help-text-sidesheet-container')]//h2")
    this.infoSideSheetContents = page.locator("xpath=//div[contains(@class,'help-text-sidesheet-container')]//p"); // @FindBy(xpath = "//div[contains(@class,'help-text-sidesheet-container')]//p")
    this.addOrEditVehicleSideSheetHeader = page.locator("xpath=//app-vehicle-form//h1"); // @FindBy(xpath = "//app-vehicle-form//h1")
    this.vinInputField = page.locator("input[formcontrolname='vin']"); // @FindBy(css = "input[formcontrolname='vin']")
    this.vinInputFieldErrorMessage = page.locator("xpath=//mat-form-field[contains(.,'VIN')]//mat-error"); // @FindBy(xpath = "//mat-form-field[contains(.,'VIN')]//mat-error")
    this.weWillVerifyYourVinText = page.locator("xpath=//mat-form-field[contains(.,'VIN')]//mat-hint"); // @FindBy(xpath = "//mat-form-field[contains(.,'VIN')]//mat-hint")
    this.yearErrorMessage = page.locator("xpath=//mat-form-field[contains(.,'Year')]//mat-error"); // @FindBy(xpath = "//mat-form-field[contains(.,'Year')]//mat-error")
    this.acquireErrorMessage = page.locator("xpath=//div[@class='section ng-star-inserted' and contains(.,'When did you acquire')]//mat-error"); // @FindBy(xpath = "//div[@class='section ng-star-inserted' and contains(.,'When did you acquire')]//mat-error")
    this.firstNameErrorMessage = page.locator("xpath=//mat-form-field[contains(.,'First name')]//mat-error"); // @FindBy(xpath = "//mat-form-field[contains(.,'First name')]//mat-error")
    this.firstName = page.locator("xpath=//mat-form-field[contains(.,'First name')]//input"); // @FindBy(xpath = "//mat-form-field[contains(.,'First name')]//input")
    this.lastNameErrorMessage = page.locator("xpath=//mat-form-field[contains(.,'Last name')]//mat-error"); // @FindBy(xpath = "//mat-form-field[contains(.,'Last name')]//mat-error")
    this.dobEntryField = page.locator("xpath=//mat-form-field[contains(.,'Date of birth')]//input"); // @FindBy(xpath = "//mat-form-field[contains(.,'Date of birth')]//input")
    this.dobErrorMessage = page.locator("xpath=//mat-form-field[contains(.,'Date of birth')]//mat-error"); // @FindBy(xpath = "//mat-form-field[contains(.,'Date of birth')]//mat-error")
    this.genderErrorMessage = page.locator("xpath=//div[@aria-label='Please select your gender']//mat-error"); // @FindBy(xpath = "//div[@aria-label='Please select your gender']//mat-error")
    this.spouseGenderErrorMessage = page.locator("xpath=//div[@aria-label=\"Please select spouse's gender\"]//mat-error"); // @FindBy(xpath = "//div[@aria-label=\"Please select spouse's gender\"]//mat-error")
    this.usOrCaErrorMessage = page.locator("xpath=//div[@aria-label=\"Is this driverâs license issued by a U.S. state, U.S. territory, or Canadian province?\"]//mat-error"); // @FindBy(xpath = "//div[@aria-label=\"Is this driver’s license issued by a U.S. state, U.S. territory, or Canadian province?\"]//mat-error")
    this.willBeDrivingErrorMessage = page.locator("xpath=//div[contains(@aria-label,'be driving')]//mat-error"); // @FindBy(xpath = "//div[contains(@aria-label,'be driving')]//mat-error")
    this.currentlyInsuredErrorMessage = page.locator("xpath=//div[@aria-label='Are you currently insured?']//mat-error"); // @FindBy(xpath = "//div[@aria-label='Are you currently insured?']//mat-error")
    this.closeButtonForSpouseNestedSheet = page.locator("#close-button"); // @FindBy(id = "close-button")
    this.vinHelperInfoTip = page.locator("xpath=//div[@class='row']//mat-icon[contains(.,'info')]"); // @FindBy(xpath = "//div[@class='row']//mat-icon[contains(.,'info')]")
    this.helperVinContent = page.locator("div[class='vin-content']"); // @FindBy(css = "div[class='vin-content']")
    this.driverSideDoorText = page.locator("xpath=//div[@class='tui-vin-modal ng-star-inserted']//div[2]/p"); // @FindBy(xpath = "//div[@class='tui-vin-modal ng-star-inserted']//div[2]/p")
    this.driverSideDoorImage = page.locator("xpath=//div[@class='tui-vin-modal ng-star-inserted']//div[2]/div"); // @FindBy(xpath = "//div[@class='tui-vin-modal ng-star-inserted']//div[2]/div")
    this.driverSideDashboardText = page.locator("xpath=//div[@class='tui-vin-modal ng-star-inserted']//div[3]/p"); // @FindBy(xpath = "//div[@class='tui-vin-modal ng-star-inserted']//div[3]/p")
    this.driverSideDashboardImage = page.locator("xpath=//div[@class='tui-vin-modal ng-star-inserted']//div[3]/div"); // @FindBy(xpath = "//div[@class='tui-vin-modal ng-star-inserted']//div[3]/div")
    this.registrationAndInsuranceCardImage = page.locator("xpath=//div[@class='tui-vin-modal ng-star-inserted']//div[4]/div"); // @FindBy(xpath = "//div[@class='tui-vin-modal ng-star-inserted']//div[4]/div")
    this.vinInfoIcon = page.locator("mat-icon[aria-label='VIN information icon']"); // @FindBy(css = "mat-icon[aria-label='VIN information icon']")
    this.vinDescHeader = page.locator("div[class='vin-description-header']>p"); // @FindBy(css = "div[class='vin-description-header']>p")
    this.vinDescCarImage = page.locator("div[class='vin-description-header']>svg"); // @FindBy(css = "div[class='vin-description-header']>svg")
    this.vinDescGreenCheck = page.locator("xpath=//div[@class='vin-description-content mt-1']//mat-icon"); // @FindBy(xpath = "//div[@class='vin-description-content mt-1']//mat-icon")
    this.vinDescContent = page.locator("xpath=//div[@class='vin-description-content mt-1']//p"); // @FindBy(xpath = "//div[@class='vin-description-content mt-1']//p")
    this.vinRemoveButtonDeleteIcon = page.locator("button[class*='tui-btn tui-btn-link vin-remove-button']>mat-icon"); // @FindBy(css = "button[class*='tui-btn tui-btn-link vin-remove-button']>mat-icon")
    this.vinRemoveButton = page.locator("button[class='tui-btn tui-btn-link vin-remove-button']"); // @FindBy(css = "button[class='tui-btn tui-btn-link vin-remove-button']")
    this.vinTipsText = page.locator("xpath=//ul[contains(@class,'tips-list')]/..//p"); // @FindBy(xpath = "//ul[contains(@class,'tips-list')]/..//p")
    this.vinTipsLists = page.locator("xpath=//ul[contains(@class,'tips-list')]//li"); // @FindBy(xpath = "//ul[contains(@class,'tips-list')]//li")
    this.yearDropDown = page.locator("mat-select[formcontrolname='year']"); // @FindBy(css = "mat-select[formcontrolname='year']")
    this.yearDropDownLabel = page.locator("xpath=//mat-select[@formcontrolname='year']/..//label"); // @FindBy(xpath = "//mat-select[@formcontrolname='year']/..//label")
    this.makeInputField = page.locator("xpath=//mat-form-field[contains(.,'make')]//input"); // @FindBy(xpath = "//mat-form-field[contains(.,'make')]//input")
    this.makeInputLabel = page.locator("xpath=//mat-form-field[contains(.,'make')]//label"); // @FindBy(xpath = "//mat-form-field[contains(.,'make')]//label")
    this.modelInputField = page.locator("xpath=//mat-form-field[contains(.,'model')]//input"); // @FindBy(xpath = "//mat-form-field[contains(.,'model')]//input")
    this.modelInputLabel = page.locator("xpath=//mat-form-field[contains(.,'model')]//label"); // @FindBy(xpath = "//mat-form-field[contains(.,'model')]//label")
    this.typeDropDown = page.locator("mat-select[formcontrolname='type']"); // @FindBy(css = "mat-select[formcontrolname='type']")
    this.typeDropDownLabel = page.locator("xpath=//mat-select[@formcontrolname='type']/..//label"); // @FindBy(xpath = "//mat-select[@formcontrolname='type']/..//label")
    this.usedForSectionLabel = page.locator("xpath=//div[@class='section' and contains(.,'Used for')]//div[contains(@class,'section-label')]/div[1]"); // @FindBy(xpath = "//div[@class='section' and contains(.,'Used for')]//div[contains(@class,'section-label')]/div[1]")
    this.usedForSInfoIcon = page.locator("xpath=//div[@class='section' and contains(.,'Used for')]//div[contains(@class,'section-label')]//mat-icon"); // @FindBy(xpath = "//div[@class='section' and contains(.,'Used for')]//div[contains(@class,'section-label')]//mat-icon")
    this.defaultPressedUsedForButton = page.locator("xpath=//div[@class='section' and contains(.,'Used for')]//button[@aria-pressed='true']"); // @FindBy(xpath = "//div[@class='section' and contains(.,'Used for')]//button[@aria-pressed='true']")
    this.personalButton = page.locator("xpath=//button[contains(.,'Personal')]"); // @FindBy(xpath = "//button[contains(.,'Personal')]")
    this.businessButton = page.locator("xpath=//button[contains(.,'Business')]"); // @FindBy(xpath = "//button[contains(.,'Business')]")
    this.rideshareCheckboxInput = page.locator("xpath=//mat-checkbox[@formcontrolname='rideshare']//input"); // @FindBy(xpath = "//mat-checkbox[@formcontrolname='rideshare']//input")
    this.rideshareCheckboxText = page.locator("xpath=//mat-checkbox[@formcontrolname='rideshare']//div[@class='column']//div[1]"); // @FindBy(xpath = "//mat-checkbox[@formcontrolname='rideshare']//div[@class='column']//div[1]")
    this.uberLiftParenthesisInfo = page.locator("xpath=//mat-checkbox[@formcontrolname='rideshare']//div[@class='column']//div[2]"); // @FindBy(xpath = "//mat-checkbox[@formcontrolname='rideshare']//div[@class='column']//div[2]")
    this.ownershipSectionHeader = page.locator("xpath=//div[@class='section' and contains(.,'Ownership')]//div[contains(@class,' label')]"); // @FindBy(xpath = "//div[@class='section' and contains(.,'Ownership')]//div[contains(@class,' label')]")
    this.ownershipSectionInfoIcon = page.locator("xpath=//div[@class='section' and contains(.,'Ownership')]//div[contains(@class,'section-label')]//mat-icon"); // @FindBy(xpath = "//div[@class='section' and contains(.,'Ownership')]//div[contains(@class,'section-label')]//mat-icon")
    this.defaultPressedOwnershipToggle = page.locator("xpath=//div[@class='section' and contains(.,'Ownership')]//button[@aria-pressed='true']"); // @FindBy(xpath = "//div[@class='section' and contains(.,'Ownership')]//button[@aria-pressed='true']")
    this.ownedToggle = page.locator("xpath=//button[contains(.,'Owned')]"); // @FindBy(xpath = "//button[contains(.,'Owned')]")
    this.leasedToggle = page.locator("xpath=//button[contains(.,'Leased')]"); // @FindBy(xpath = "//button[contains(.,'Leased')]")
    this.financedToggle = page.locator("xpath=//button[contains(.,'Financed')]"); // @FindBy(xpath = "//button[contains(.,'Financed')]")
    this.acquiredSectionHeader = page.locator("xpath=//div[@class='section' and contains(.,'When')]//div[contains(@class,' label')]"); // @FindBy(xpath = "//div[@class='section' and contains(.,'When')]//div[contains(@class,' label')]")
    this.acquiredSectionMatIcon = page.locator("xpath=//div[@class='section' and contains(.,'When')]//div[contains(@class,'section-label')]//mat-icon"); // @FindBy(xpath = "//div[@class='section' and contains(.,'When')]//div[contains(@class,'section-label')]//mat-icon")
    this.acquiredSectionDateInputField = page.locator("xpath=//div[contains(@class,'section') and contains(.,'When')]//input"); // @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'When')]//input")
    this.acquiredSectionDatePicker = page.locator("xpath=//div[contains(@class,'section') and contains(.,'When')]//button"); // @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'When')]//button")
    this.acquiredSectionDateInputFieldHint = page.locator("xpath=//div[contains(@class,'section') and contains(.,'When')]//mat-hint"); // @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'When')]//mat-hint")
    this.parkedAtSectionHeader = page.locator("xpath=//div[contains(@class,'section') and contains(.,'Where is the vehicle usually parked?')]//div//span"); // @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'Where is the vehicle usually parked?')]//div//span")
    this.parkedAtSectionInfoIcon = page.locator("xpath=//div[contains(@class,'section') and contains(.,'Where is the vehicle usually parked?')]//div//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'Where is the vehicle usually parked?')]//div//mat-icon")
    this.parkedAtPrimaryRadioButton = page.locator("xpath=//div[contains(@class,'section') and contains(.,'Where is the vehicle usually parked?')]//mat-radio-button[@value='primary']"); // @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'Where is the vehicle usually parked?')]//mat-radio-button[@value='primary']")
    this.parkedAtOtherRadioButton = page.locator("xpath=//div[contains(@class,'section') and contains(.,'Where is the vehicle usually parked?')]//mat-radio-button[@value='other']//input"); // @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'Where is the vehicle usually parked?')]//mat-radio-button[@value='other']//input")
    this.otherGarageAddressInputField = page.locator("xpath=//input[@aria-label='Garaging address']"); // @FindBy(xpath = "//input[@aria-label='Garaging address']")
    this.otherGarageApartmentInputField = page.locator("xpath=//input[@formcontrolname='apartment']"); // @FindBy(xpath = "//input[@formcontrolname='apartment']")
    this.otherGarageCityInputField = page.locator("xpath=//input[@formcontrolname='city']"); // @FindBy(xpath = "//input[@formcontrolname='city']")
    this.otherGarageStateInputField = page.locator("xpath=//input[@formcontrolname='state']"); // @FindBy(xpath = "//input[@formcontrolname='state']")
    this.otherGarageZipInputField = page.locator("xpath=//input[@formcontrolname='zip']"); // @FindBy(xpath = "//input[@formcontrolname='zip']")
    this.theftRecoveryCheckbox = page.locator("mat-checkbox[formcontrolname='theftRecovery']"); // @FindBy(css = "mat-checkbox[formcontrolname='theftRecovery']")
    this.addVehicleButton = page.locator("button[class='tui-btn tui-btn-primary ng-star-inserted']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary ng-star-inserted']"),             @FindBy(xpath = "//app-vehicle-form//button[contains(.,'Add Vehicle')]")     })
    this.cancelButton = page.locator("button[class='tui-btn tui-btn-link base-cancel-button ng-star-inserted']"); // @FindBy(css = "button[class='tui-btn tui-btn-link base-cancel-button ng-star-inserted']")
    this.addAnotherVehicleButtonSideSheet = page.locator("xpath=//app-base-sidesheet//button[contains(@class,'tui-btn tui-btn-cta add-button')]"); // @FindBy(xpath = "//app-base-sidesheet//button[contains(@class,'tui-btn tui-btn-cta add-button')]")
    this.doneAddingVehiclesSideSheet = page.locator("xpath=//app-base-sidesheet//button[contains(.,'Done adding vehicles')]"); // @FindBy(xpath = "//app-base-sidesheet//button[contains(.,'Done adding vehicles')]")
    this.continueToDriversButtonSideSheet = page.locator("xpath=//app-base-sidesheet//button[contains(.,'Continue to drivers')]"); // @FindBy(xpath = "//app-base-sidesheet//button[contains(.,'Continue to drivers')]")
    this.addVehiclesSaveChangesButton = page.locator("xpath=//app-vehicle-form//button[.='Save changes']"); // @FindBy(xpath = "//app-vehicle-form//button[.='Save changes']")
    this.addEditDriverHeader = page.locator("xpath=//app-driver//h1"); // @FindBy(xpath = "//app-driver//h1")
    this.addAnotherIncident = page.locator("a[id='add-incident-button']"); // @FindBy(css = "a[id='add-incident-button']")
    this.addAnotherIncidentNestedSpouse = page.locator("xpath=//app-base-sidesheet[contains(.,'Add a spouse')]//a[@id='add-incident-button']"); // @FindBy(xpath = "//app-base-sidesheet[contains(.,'Add a spouse')]//a[@id='add-incident-button']")
    this.changeSpouseSelectionLink = page.locator("xpath=//a[@aria-label='Change Spouse Selection']"); // @FindBy(xpath = "//a[@aria-label='Change Spouse Selection']")
    this.someoneNotOnThisQuoteButton = page.locator("xpath=//mat-radio-button[contains(.,'not ')]"); // @FindBy(xpath = "//mat-radio-button[contains(.,'not ')]")
    this.addASpouseSideSheetHeader = page.locator("xpath=//app-driver//h1[contains(.,'Add a spouse')]"); // @FindBy(xpath = "//app-driver//h1[contains(.,'Add a spouse')]")
    this.letsFindMyOccupationButton = page.locator("xpath=//div[contains(@class,'ss-driver-occupation')]//button"); // @FindBy(xpath = "//div[contains(@class,'ss-driver-occupation')]//button")
    this.letsFindMyOccupationButtonSpouse = page.locator("xpath=//app-base-sidesheet[contains(.,'Add a spouse')]//button[@id='add-occupation-button']"); // @FindBy(xpath = "//app-base-sidesheet[contains(.,'Add a spouse')]//button[@id='add-occupation-button']")
    this.occupationSideSheetHeader = page.locator("xpath=//app-occupation-selection//h1"); // @FindBy(xpath = "//app-occupation-selection//h1")
    this.displayedOccupations = page.locator("xpath=//app-occupation-selection//mat-radio-button//label"); // @FindBy(xpath = "//app-occupation-selection//mat-radio-button//label")
    this.driverSaveButton = page.locator("xpath=//app-driver//button[.='Save']"); // @FindBy(xpath = "//app-driver//button[.='Save']")
    this.occupationSaveButton = page.locator("xpath=//app-occupation-selection//button[.='Save']"); // @FindBy(xpath = "//app-occupation-selection//button[.='Save']")
    this.occupationCancelButton = page.locator("xpath=//app-occupation-selection//button[.='Cancel']"); // @FindBy(xpath = "//app-occupation-selection//button[.='Cancel']")
    this.addDriverSaveChangesButton = page.locator("xpath=//app-driver//button[.='Save changes']"); // @FindBy(xpath = "//app-driver//button[.='Save changes']")
    this.ageDriverRecievedLicenseInput = page.locator("input[formcontrolname='ageFirstLicensed']"); // @FindBy(css = "input[formcontrolname='ageFirstLicensed']")
    this.doneAddingDriverButton = page.locator("xpath=//div[@class='button-area']//button[contains(.,'Done adding drivers')]"); // @FindBy(xpath = "//div[@class='button-area']//button[contains(.,'Done adding drivers')]"),             @FindBy(xpath = "//button[contains(.,'Done adding drivers')]")     })
    this.addDriverButton = page.locator("xpath=//button[@class='tui-btn tui-btn-primary ng-star-inserted' and contains(.,'Add driver')]"); // @FindBy(xpath = "//button[@class='tui-btn tui-btn-primary ng-star-inserted' and contains(.,'Add driver')]")
    this.priorPolicyExpDateDropDown = page.locator("xpath=//label[contains(.,'When did your prior policy expire?')]/..//mat-select"); // @FindBy(xpath = "//label[contains(.,'When did your prior policy expire?')]/..//mat-select")
    this.priorPolicyExpDateDropDownBeforeOption = page.locator("xpath=//span[contains(.,'Before')]/parent::mat-option"); // @FindBy(xpath = "//span[contains(.,'Before')]/parent::mat-option")
    this.priorPolicyExpDateDropDownOnOrAfterOption = page.locator("xpath=//span[contains(.,'On or after')]/parent::mat-option"); // @FindBy(xpath = "//span[contains(.,'On or after')]/parent::mat-option")
    this.checkboxLabels = page.locator("xpath=//span[@class='checkbox-label-inline']"); // @FindBy(xpath = "//span[@class='checkbox-label-inline']")
    this.currentPrincipalPersonalInjuryDropDown = page.locator("xpath=//mat-form-field[contains(.,'Current Principal Personal Injury')]//mat-select"); // @FindBy(xpath = "//mat-form-field[contains(.,'Current Principal Personal Injury')]//mat-select")
    this.financialFilingMatIcon = page.locator("mat-icon[aria-label='Financial responsibility filing information icon']"); // @FindBy(css = "mat-icon[aria-label='Financial responsibility filing information icon']")
    this.financialFilingTooltipHeader1 = page.locator("xpath=//app-help-text-sidesheet//h1"); // @FindBy(xpath = "//app-help-text-sidesheet//h1")
    this.financialFilingTooltipHeader2 = page.locator("xpath=//div[@class='model-info-section']//h2"); // @FindBy(xpath = "//div[@class='model-info-section']//h2")
    this.financialFilingTooltipDescription1 = page.locator("xpath=//div[@class='model-info-section']//p[1]"); // @FindBy(xpath = "//div[@class='model-info-section']//p[1]")
    this.financialFilingTooltipDescription2 = page.locator("xpath=//div[@class='model-info-section']//p[2]"); // @FindBy(xpath = "//div[@class='model-info-section']//p[2]")
    this.addVehicleSideSheetHeader = page.locator("xpath=//app-base-sidesheet//h1[contains(text(), 'Add a vehicle')]"); // @FindBy(xpath = "//app-base-sidesheet//h1[contains(text(), 'Add a vehicle')]")
    this.editVehicleSideSheetHeader = page.locator("xpath=//h1[contains(text(), 'Edit vehicle')]"); // @FindBy(xpath = "//h1[contains(text(), 'Edit vehicle')]")
    this.insuredInPast6MonthsRadioButtons = page.locator("xpath=//mat-radio-group[@aria-labelledby='aria-labelledby']//label"); // @FindBy(xpath = "//mat-radio-group[@aria-labelledby='aria-labelledby']//label"),             @FindBy(xpath = "//label[contains(.,'nsured for the past 6 months with any')]/..//mat-radio-button")      })
    this.pageCTAErrorMessage = page.locator("xpath=//div[contains(@class,'cta-section')]//div[contains(@class,'error')]"); // @FindBy(xpath = "//div[contains(@class,'cta-section')]//div[contains(@class,'error')]")
  }
}
