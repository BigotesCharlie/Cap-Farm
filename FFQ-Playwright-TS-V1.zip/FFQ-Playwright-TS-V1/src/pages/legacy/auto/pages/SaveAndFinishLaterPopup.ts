// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.SaveAndFinishLaterPopup. */
export class SaveAndFinishLaterPopup extends CoreBasePage {
  public readonly saveAndFinishLaterForm: Locator;
  public readonly saveAndFinishLaterFormHeader: Locator;
  public readonly emailTextbox: Locator;
  public readonly saveAndExitButton: Locator;
  public readonly continueWithQuoteButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.saveAndFinishLaterForm = page.locator("#FFQAuto_Modal_saveFinishForm"); // @FindBy(id = "FFQAuto_Modal_saveFinishForm")
    this.saveAndFinishLaterFormHeader = page.locator("#FFQAuto_Modal_saveFinishHeader"); // @FindBy(id = "FFQAuto_Modal_saveFinishHeader")
    this.emailTextbox = page.locator("#FFQAuto_Modal_saveFinishEmailAddress"); // @FindBy(id = "FFQAuto_Modal_saveFinishEmailAddress")
    this.saveAndExitButton = page.locator("#FFQAuto_Modal_saveFinishOk"); // @FindBy(id = "FFQAuto_Modal_saveFinishOk")
    this.continueWithQuoteButton = page.locator("#FFQAuto_Modal_saveFinishClose"); // @FindBy(id = "FFQAuto_Modal_saveFinishClose")
  }
}
