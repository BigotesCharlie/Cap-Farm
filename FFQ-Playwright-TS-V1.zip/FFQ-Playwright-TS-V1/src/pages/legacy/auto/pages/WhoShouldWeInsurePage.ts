// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.WhoShouldWeInsurePage. */
export class WhoShouldWeInsurePage extends CoreBasePage {
  public readonly actualLisOfDriversWithAges: Locator;
  public readonly lblDriversList: Locator;
  public readonly actualListOfVehicleInfo: Locator;
  public readonly lblVehiclesList: Locator;
  public readonly actualListOfVinTips: Locator;
  public readonly addAnotherVehicleButton: Locator;
  public readonly addAnotherVehicleButtonFromMainScreen: Locator;
  public readonly addAnotherVehicleButtonFromMainScreen2: Locator;
  public readonly addDriverCloseIcon: Locator;
  public readonly addVehicleDialogHeader: Locator;
  public readonly howToFindVinHeader: Locator;
  public readonly editDriverLink: Locator;
  public readonly ctaErrorMessageForVehicleEditSideSheet: Locator;
  public readonly addDriverDialogHeader: Locator;
  public readonly addEditVehicleDialogHeader: Locator;
  public readonly addMoreDriverDialogHeader: Locator;
  public readonly addMoreVehiclesHeading: Locator;
  public readonly addVehicleAndDriversButton: Locator;
  public readonly addAVehicleButton: Locator;
  public readonly addAnotherVehicleLink: Locator;
  public readonly addAnotherVehicleLinkAlternative: Locator;
  public readonly addAnotherVehicleLinkAlternative2: Locator;
  public readonly addVehicleButton: Locator;
  public readonly addVehicleSideDialogSubtitle: Locator;
  public readonly addVehiclesButton: Locator;
  public readonly backToVinButton: Locator;
  public readonly cancelAddVehicleLink: Locator;
  public readonly continueButton: Locator;
  public readonly dateOfBirthEntryField: Locator;
  public readonly checkedVehicles: Locator;
  public readonly doneAddingVehiclesButton: Locator;
  public readonly addDriverButton: Locator;
  public readonly addAnotherDriverButton: Locator;
  public readonly saveDriverCTAErrorMessage: Locator;
  public readonly addAnotherDriverButtonSideSheet: Locator;
  public readonly doneAddingDriversButton: Locator;
  public readonly doneAddingDriversButtonAlternative: Locator;
  public readonly driverSection: Locator;
  public readonly driverSideDoorText: Locator;
  public readonly dropDownOptions: Locator;
  public readonly errorMessageForVehicleAndDriverSelection: Locator;
  public readonly fieldErrorMessage: Locator;
  public readonly flexEmailAddressEntryField: Locator;
  public readonly flexMobilePhoneEntryField: Locator;
  public readonly formFieldLabels: Locator;
  public readonly genderSelectForm: Locator;
  public readonly insuredSelectForm: Locator;
  public readonly currentlyInsuredYes: Locator;
  public readonly currentlyInsuredNo: Locator;
  public readonly keepBothButton: Locator;
  public readonly licenseSelectForm: Locator;
  public readonly nonAdpfPageSubTitle: Locator;
  public readonly nonAdpfPageTitle: Locator;
  public readonly notInsuredReasonDropdownField: Locator;
  public readonly priorInsuranceExpiredDropdownField: Locator;
  public readonly quoteNumberText: Locator;
  public readonly removeBothButton: Locator;
  public readonly requiredFieldErrorMessage: Locator;
  public readonly vehicleSaveChangesButton: Locator;
  public readonly driverSaveChangesButton: Locator;
  public readonly saveDriverInfoButton: Locator;
  public readonly saveQuoteLink: Locator;
  public readonly spouseSelectPopUpContext: Locator;
  public readonly spouseSelectPopUpHeader: Locator;
  public readonly subNote: Locator;
  public readonly vehicleMakeEntryField: Locator;
  public readonly vehicleMakeEntryFieldAlternate: Locator;
  public readonly vehicleModelEntryField: Locator;
  public readonly vehicleModelEntryFieldAlternate: Locator;
  public readonly vehicleSection: Locator;
  public readonly editVehicleLink: Locator;
  public readonly editVehicleLinksForVinVehicle: Locator;
  public readonly vehicleVinLabel: Locator;
  public readonly vehicleTypeDropdown: Locator;
  public readonly vehicleTypeDropdownValue: Locator;
  public readonly vehicleVINButton: Locator;
  public readonly vehicleVINEntryField: Locator;
  public readonly vehicleYMMButton: Locator;
  public readonly vehicleYearDropdown: Locator;
  public readonly vehicleYearDropdownAlternate: Locator;
  public readonly vehicleYearDropdownValue: Locator;
  public readonly vinHelperImageOne: Locator;
  public readonly vinHelperImageThree: Locator;
  public readonly vinHelperImageTwo: Locator;
  public readonly vinHelperModalContent: Locator;
  public readonly vinHelperModalHeader: Locator;
  public readonly vinLocations: Locator;
  public readonly vinLocationsList: Locator;
  public readonly whereCanIFindThisLink: Locator;
  public readonly whoShouldWeInsurePageContent: Locator;
  public readonly whoShouldWeInsureTitle: Locator;
  public readonly xButton: Locator;
  public readonly txtVINUnmasked: Locator;
  public readonly lblVINDescription: Locator;
  public readonly saveButton: Locator;
  public readonly pageCTAErrorMessage: Locator;
  public readonly listOfCheckedVehicles: Locator;
  public readonly listOfEditButtonsOfCheckedVehicles: Locator;

  public constructor(page: Page) {
    super(page);
    this.actualLisOfDriversWithAges = page.locator("[data-legacy-field=\"actualLisOfDriversWithAges\"]"); // @FindBy(css = ACTUAL_LIST_OF_DRIVERS_WITH_AGES_CSS_SELECTOR)
    this.lblDriversList = page.locator("xpath=//ul[contains(@class,'auto-vehicles-drivers-review__drivers-list-section')]/li//label[@class='mdc-label']"); // @FindBy(xpath = "//ul[contains(@class,'auto-vehicles-drivers-review__drivers-list-section')]/li//label[@class='mdc-label']")
    this.actualListOfVehicleInfo = page.locator("div.auto-vehicles-drivers-review__vehicles-list-details label.mdc-label"); // @FindBy(css = "div.auto-vehicles-drivers-review__vehicles-list-details label.mdc-label")
    this.lblVehiclesList = page.locator("xpath=//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-section')]/div//label[@class='mdc-label']"); // @FindBy(xpath = "//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-section')]/div//label[@class='mdc-label']")
    this.actualListOfVinTips = page.locator("li.auto-add-vehicle-vin-tips__list-rules"); // @FindBy(css = "li.auto-add-vehicle-vin-tips__list-rules")
    this.addAnotherVehicleButton = page.locator("xpath=//button[contains(@class,'tui-btn tui-btn-cta add-vehicle-button')]"); // @FindBy(xpath = "//button[contains(@class,'tui-btn tui-btn-cta add-vehicle-button')]")
    this.addAnotherVehicleButtonFromMainScreen = page.locator(".auto-vehicles-drivers-review__multi-vehicle-add-link"); // @FindBy(css = ".auto-vehicles-drivers-review__multi-vehicle-add-link")
    this.addAnotherVehicleButtonFromMainScreen2 = page.locator("xpath=//button[contains(.,'Add another vehicle')]"); // @FindBy(xpath = "//button[contains(.,'Add another vehicle')]")
    this.addDriverCloseIcon = page.locator("#auto-add-driver__dialog-close-icon"); // @FindBy(id = "auto-add-driver__dialog-close-icon")
    this.addVehicleDialogHeader = page.locator("h2[id='addVehicleHeading']"); // @FindBy(css = "h2[id='addVehicleHeading']")
    this.howToFindVinHeader = page.locator(".tui-vin-modal-header"); // @FindBy(className = "tui-vin-modal-header")
    this.editDriverLink = page.locator("div.auto-vehicles-drivers-review__drivers-list-details-section>a"); // @FindBy(css = "div.auto-vehicles-drivers-review__drivers-list-details-section>a")
    this.ctaErrorMessageForVehicleEditSideSheet = page.locator("div.auto-vehicles-drivers-review__drivers-list-details-section>a"); // @FindBy(css = "div.auto-vehicles-drivers-review__drivers-list-details-section>a")
    this.addDriverDialogHeader = page.locator("#addDriverHeading"); // @FindBy(id = "addDriverHeading")
    this.addEditVehicleDialogHeader = page.locator("h2.auto-add-vehicle-heading"); // @FindBy(css = "h2.auto-add-vehicle-heading"),             @FindBy(xpath = "//app-vehicle-form//h1")     })
    this.addMoreDriverDialogHeader = page.locator("h4[id='addMoreDriversHeading']"); // @FindBy(css = "h4[id='addMoreDriversHeading']")
    this.addMoreVehiclesHeading = page.locator("xpath=//h4[text()='Do you have more vehicles? ']"); // @FindBy(xpath = "//h4[text()='Do you have more vehicles? ']")
    this.addVehicleAndDriversButton = page.locator("#addVehiclesDriversButton"); // @FindBy(id = "addVehiclesDriversButton")
    this.addAVehicleButton = page.locator("button[class='tui-btn tui-btn-primary ng-star-inserted']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary ng-star-inserted']"),                     @FindBy(xpath = "//*[@id='addVehicleButton' or @class='tui-btn tui-btn-primary auto-add-vehicle-submit__button']")             })
    this.addAnotherVehicleLink = page.locator("#multiVehicleAddLink"); // @FindBy(id = "multiVehicleAddLink")
    this.addAnotherVehicleLinkAlternative = page.locator("#addAnotherVehicleLink"); // @FindBy(id = "addAnotherVehicleLink")
    this.addAnotherVehicleLinkAlternative2 = page.locator("xpath=//button[contains(@class, 'add-button') and contains(., 'another vehicle')]"); // @FindBy(xpath = "//button[contains(@class, 'add-button') and contains(., 'another vehicle')]")
    this.addVehicleButton = page.locator("xpath=//button[@class='tui-btn tui-btn-primary auto-add-vehicle-submit__button'] | //button[contains(@class,'add-button')][contains(.,'Add another vehicle')]"); // @FindBy(xpath = "//button[@class='tui-btn tui-btn-primary auto-add-vehicle-submit__button'] | //button[contains(@class,'add-button')][contains(.,'Add another vehicle')]")
    this.addVehicleSideDialogSubtitle = page.locator("p.auto-add-vehicle-start__subtitle"); // @FindBy(css = "p.auto-add-vehicle-start__subtitle")
    this.addVehiclesButton = page.locator("xpath=//button[text()='Add a vehicle']"); // @FindBy(xpath = "//button[text()='Add a vehicle']")
    this.backToVinButton = page.locator("button.tui-vin-back-to-vin-button"); // @FindBy(css = "button.tui-vin-back-to-vin-button"),             @FindBy(xpath = "//button[@id='back-button']//mat-icon")     })
    this.cancelAddVehicleLink = page.locator("xpath=//div[contains(@class,'auto-add-vehicle-submit')]//a"); // @FindBy(xpath = "//div[contains(@class,'auto-add-vehicle-submit')]//a")
    this.continueButton = page.locator("xpath=//button[contains(@class, 'auto-vehicles-drivers-review__continue-button')]"); // @FindBy(xpath = "//button[contains(@class, 'auto-vehicles-drivers-review__continue-button')]")
    this.dateOfBirthEntryField = page.locator("xpath=//mat-form-field//input[contains(@aria-label, 'Date of birth')] | //mat-form-field[contains(.,'Date of birth')]//input"); // @FindBy(xpath = "//mat-form-field//input[contains(@aria-label, 'Date of birth')] | //mat-form-field[contains(.,'Date of birth')]//input")
    this.checkedVehicles = page.locator("mat-checkbox[class='mat-checkbox auto-vehicles-drivers-review__vehicles-list-details-checkbox mat-accent mat-checkbox-checked']"); // @FindBy(css = "mat-checkbox[class='mat-checkbox auto-vehicles-drivers-review__vehicles-list-details-checkbox mat-accent mat-checkbox-checked']")
    this.doneAddingVehiclesButton = page.locator("button.close-button"); // @FindBy(css = "button.close-button")
    this.addDriverButton = page.locator("#addDriverButton"); // @FindBy(id = "addDriverButton")
    this.addAnotherDriverButton = page.locator("xpath=//a[contains(@id,'addAnotherDriverLink')]"); // @FindBy(xpath = "//a[contains(@id,'addAnotherDriverLink')]")
    this.saveDriverCTAErrorMessage = page.locator("xpath=//p[contains(@class,'auto-add-driver__error-message')]"); // @FindBy(xpath = "//p[contains(@class,'auto-add-driver__error-message')]")
    this.addAnotherDriverButtonSideSheet = page.locator("button[class='tui-btn tui-btn-cta add-drivers-button']"); // @FindBy(css = "button[class='tui-btn tui-btn-cta add-drivers-button']")
    this.doneAddingDriversButton = page.locator("xpath=//div[contains(@class,'auto-add-more-drivers-done__button')]//button"); // @FindBy(xpath = "//div[contains(@class,'auto-add-more-drivers-done__button')]//button")
    this.doneAddingDriversButtonAlternative = page.locator("xpath=//app-transition-sidesheet//button[text()='Done adding drivers']"); // @FindBy(xpath = "//app-transition-sidesheet//button[text()='Done adding drivers']")
    this.driverSection = page.locator("div.auto-vehicles-drivers-review__drivers"); // @FindBy(css = "div.auto-vehicles-drivers-review__drivers")
    this.driverSideDoorText = page.locator("xpath=//div[@class='tui-vin-section tui-stacking-bottom-md'][1]//p"); // @FindBy(xpath = VIN_HELPER_IMAGE_ONE + SECTION_DESCRIPTION_XPATH),             @FindBy(xpath = "//div[@class='tui-vin-section tui-stacking-bottom-md'][1]//p")     })
    this.dropDownOptions = page.locator("[data-legacy-field=\"dropDownOptions\"]"); // @FindBy(xpath = DROP_DOWN_OPTIONS_XPATH)
    this.errorMessageForVehicleAndDriverSelection = page.locator("p[class*='error-message']"); // @FindBy(css = "p[class*='error-message']") ,             @FindBy(css = "div[class='error-message pb-4 ng-star-inserted']")     })
    this.fieldErrorMessage = page.locator("mat-error.mat-mdc-form-field-error"); // @FindBy(css = "mat-error.mat-mdc-form-field-error")
    this.flexEmailAddressEntryField = page.locator("[data-legacy-field=\"flexEmailAddressEntryField\"]"); // @FindBy(xpath = XPATH_FOR_FLEX_EMAIL_ENTRY_FIELD)
    this.flexMobilePhoneEntryField = page.locator("xpath=//div[@id='flex-field-phoneNumber_vehiclesDriversReview']//input"); // @FindBy(xpath = "//div[@id='flex-field-phoneNumber_vehiclesDriversReview']//input")
    this.formFieldLabels = page.locator("xpath=//label[not(contains(@for,'flex-field'))]/mat-label"); // @FindBy(xpath = "//label[not(contains(@for,'flex-field'))]/mat-label")
    this.genderSelectForm = page.locator("[data-legacy-field=\"genderSelectForm\"]"); // @FindBy(xpath = GENDER_SECTION_XPATH)
    this.insuredSelectForm = page.locator("#formField_currentlyInsured"); // @FindBy(id = "formField_currentlyInsured")
    this.currentlyInsuredYes = page.locator("#//div[contains(@id,'currentlyInsured')]//input[contains(@value,'Yes')]"); // @FindBy(id = "//div[contains(@id,'currentlyInsured')]//input[contains(@value,'Yes')]")
    this.currentlyInsuredNo = page.locator("#//div[contains(@id,'currentlyInsured')]//input[contains(@value,'NN')]"); // @FindBy(id = "//div[contains(@id,'currentlyInsured')]//input[contains(@value,'NN')]")
    this.keepBothButton = page.locator("mat-dialog-container button.tui-btn-primary"); // @FindBy(css = "mat-dialog-container button.tui-btn-primary")
    this.licenseSelectForm = page.locator("#formField_licenseIssued"); // @FindBy(id = "formField_licenseIssued")
    this.nonAdpfPageSubTitle = page.locator("xpath=//div[@class='auto-vehicles-drivers-review__non-adpf__subheading row']//span"); // @FindBy(xpath = "//div[@class='auto-vehicles-drivers-review__non-adpf__subheading row']//span")
    this.nonAdpfPageTitle = page.locator("xpath=//h1[contains(@class,'auto-vehicles-drivers-review__non-adpf-heading tui-h1')]"); // @FindBy(xpath = "//h1[contains(@class,'auto-vehicles-drivers-review__non-adpf-heading tui-h1')]")
    this.notInsuredReasonDropdownField = page.locator("xpath=//mat-form-field[@id='currentlyUninsuredReason']//mat-select"); // @FindBy(xpath = "//mat-form-field[@id='currentlyUninsuredReason']//mat-select")
    this.priorInsuranceExpiredDropdownField = page.locator("xpath=//mat-form-field[@id='priorInsuranceExpiredInfo']//mat-select"); // @FindBy(xpath = "//mat-form-field[@id='priorInsuranceExpiredInfo']//mat-select")
    this.quoteNumberText = page.locator("xpath=//p[text()][./span[text()='Quote number']]"); // @FindBy(xpath = "//p[text()][./span[text()='Quote number']]")
    this.removeBothButton = page.locator("mat-dialog-actions button.tui-btn-link"); // @FindBy(css = "mat-dialog-actions button.tui-btn-link")
    this.requiredFieldErrorMessage = page.locator("p.auto-add-vehicle-ymm__multiple-fields-missing"); // @FindBy(css = "p.auto-add-vehicle-ymm__multiple-fields-missing")
    this.vehicleSaveChangesButton = page.locator("xpath=//button[contains(text(),'Save changes')]"); // @FindBy(xpath = "//button[contains(text(),'Save changes')]")
    this.driverSaveChangesButton = page.locator("xpath=//button[contains(text(),'Save changes')]"); // @FindBy(xpath = "//button[contains(text(),'Save changes')]")
    this.saveDriverInfoButton = page.locator("xpath=//button[text()=' Save']"); // @FindBy(xpath = "//button[text()=' Save']")
    this.saveQuoteLink = page.locator("xpath=//a[text()='Save quote']"); // @FindBy(xpath = "//a[text()='Save quote']")
    this.spouseSelectPopUpContext = page.locator("#spouseSelectContent"); // @FindBy(id = "spouseSelectContent")
    this.spouseSelectPopUpHeader = page.locator("h1.spouse-select__title"); // @FindBy(css = "h1.spouse-select__title")
    this.subNote = page.locator("p.auto-add-vehicle-ymm__disclaimer-text"); // @FindBy(css = "p.auto-add-vehicle-ymm__disclaimer-text")
    this.vehicleMakeEntryField = page.locator(".auto-add-vehicle-make__input input:not([disabled])"); // @FindBy(css = ".auto-add-vehicle-make__input input:not([disabled])")
    this.vehicleMakeEntryFieldAlternate = page.locator("xpath=//div[contains(@class, 'auto-add-vehicle-make__input')]//input"); // @FindBy(xpath = "//div[contains(@class, 'auto-add-vehicle-make__input')]//input")
    this.vehicleModelEntryField = page.locator(".auto-add-vehicle-model__input input:not([disabled])"); // @FindBy(css = ".auto-add-vehicle-model__input input:not([disabled])")
    this.vehicleModelEntryFieldAlternate = page.locator("#//div[contains(@class, 'auto-add-vehicle-model__input')]//input"); // @FindBy(id = "//div[contains(@class, 'auto-add-vehicle-model__input')]//input")
    this.vehicleSection = page.locator("div.auto-vehicles-drivers-review__vehicles"); // @FindBy(css = "div.auto-vehicles-drivers-review__vehicles")
    this.editVehicleLink = page.locator("div.auto-vehicles-drivers-review__vehicles-list-details-section>a"); // @FindBy(css = "div.auto-vehicles-drivers-review__vehicles-list-details-section>a")
    this.editVehicleLinksForVinVehicle = page.locator("[data-legacy-field=\"editVehicleLinksForVinVehicle\"]"); // @FindBy(xpath = EDIT_LINK_XPATH_FOR_VIN_PROVIDED_VEHICLES)
    this.vehicleVinLabel = page.locator("xpath=//*[@aria-label='VIN ending with 341']"); // @FindBy(xpath = "//*[@aria-label='VIN ending with 341']")
    this.vehicleTypeDropdown = page.locator("#auto-add-vehicle-vehicleType__input-section"); // @FindBy(id = "auto-add-vehicle-vehicleType__input-section")
    this.vehicleTypeDropdownValue = page.locator("xpath=(//span[starts-with(@class,'mat-mdc-select-min-line')])[2]"); // @FindBy(xpath = "(//span[starts-with(@class,'mat-mdc-select-min-line')])[2]")
    this.vehicleVINButton = page.locator("xpath=//mat-button-toggle[@value='vin']/button"); // @FindBy(xpath = "//mat-button-toggle[@value='vin']/button")
    this.vehicleVINEntryField = page.locator("xpath=//input[@id='auto-add-vehicle-vin__input-section' or @formcontrolname='vin']"); // @FindBy(xpath = "//input[@id='auto-add-vehicle-vin__input-section' or @formcontrolname='vin']")
    this.vehicleYMMButton = page.locator("xpath=//mat-button-toggle[@value='ymm']/button"); // @FindBy(xpath = "//mat-button-toggle[@value='ymm']/button")
    this.vehicleYearDropdown = page.locator(".auto-add-vehicle-year__input mat-select[aria-disabled='false']"); // @FindBy(css = ".auto-add-vehicle-year__input mat-select[aria-disabled='false']")
    this.vehicleYearDropdownAlternate = page.locator("xpath=//div[contains(@class, 'auto-add-vehicle-year__input')]//mat-select"); // @FindBy(xpath = "//div[contains(@class, 'auto-add-vehicle-year__input')]//mat-select")
    this.vehicleYearDropdownValue = page.locator("xpath=(//span[starts-with(@class,'mat-mdc-select-min-line')])[1]"); // @FindBy(xpath = "(//span[starts-with(@class,'mat-mdc-select-min-line')])[1]")
    this.vinHelperImageOne = page.locator("[data-legacy-field=\"vinHelperImageOne\"]"); // @FindBy(xpath = VIN_HELPER_IMAGE_ONE)
    this.vinHelperImageThree = page.locator("[data-legacy-field=\"vinHelperImageThree\"]"); // @FindBy(xpath = VIN_HELPER_IMAGE_THREE)
    this.vinHelperImageTwo = page.locator("[data-legacy-field=\"vinHelperImageTwo\"]"); // @FindBy(xpath = VIN_HELPER_IMAGE_TWO)
    this.vinHelperModalContent = page.locator("xpath=//p[@class='tui-body-text-1']"); // @FindBy(xpath = "//p[@class='tui-body-text-1']")
    this.vinHelperModalHeader = page.locator(".tui-subtitle"); // @FindBy(css = ".tui-subtitle"),             @FindBy(id = "baseSidesheetHeader")     })
    this.vinLocations = page.locator("xpath=//p[contains(@class,'tui-field-label-text auto-vin-helper__body')]"); // @FindBy(xpath = "//p[contains(@class,'tui-field-label-text auto-vin-helper__body')]")
    this.vinLocationsList = page.locator("xpath=//ol//li"); // @FindBy(xpath = "//ol//li")
    this.whereCanIFindThisLink = page.locator("xpath=//a[text()=' Where can I find this?']"); // @FindBy(xpath = "//a[text()=' Where can I find this?']")
    this.whoShouldWeInsurePageContent = page.locator("[data-legacy-field=\"whoShouldWeInsurePageContent\"]"); // @FindBy(xpath = PAGE_DESCRIPTION_XPATH)
    this.whoShouldWeInsureTitle = page.locator("xpath=//h1[contains(text(), 'Who should we insure?')]"); // @FindBy(xpath = "//h1[contains(text(), 'Who should we insure?')]")
    this.xButton = page.locator("xpath=//div[@class='auto-add-vehicle-heading__div row']//div[./mat-icon]"); // @FindBy(xpath = "//div[@class='auto-add-vehicle-heading__div row']//div[./mat-icon]")
    this.txtVINUnmasked = page.locator("xpath=//mat-label[contains(normalize-space(text()),'VIN')]/ancestor::div[1]/input[1]"); // @FindBy(xpath = "//mat-label[contains(normalize-space(text()),'VIN')]/ancestor::div[1]/input[1]")
    this.lblVINDescription = page.locator("xpath=//div[contains(@class,'vehicle-desc')]/div"); // @FindBy(xpath = "//div[contains(@class,'vehicle-desc')]/div")
    this.saveButton = page.locator("button[class='tui-btn tui-btn-primary auto-add-driver-save__button']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary auto-add-driver-save__button']")
    this.pageCTAErrorMessage = page.locator("p[class='auto-vehicles-drivers-review__error-message tui-body-text-2 ng-star-inserted']"); // @FindBy(css = "p[class='auto-vehicles-drivers-review__error-message tui-body-text-2 ng-star-inserted']")
    this.listOfCheckedVehicles = page.locator("[data-legacy-field=\"listOfCheckedVehicles\"]"); // @FindBy(xpath = CHECKED_VEHICLES_XPATH)
    this.listOfEditButtonsOfCheckedVehicles = page.locator("[data-legacy-field=\"listOfEditButtonsOfCheckedVehicles\"]"); // @FindBy(xpath = CHECKED_VEHICLES_XPATH + "//ancestor::mat-checkbox/.." + EDIT_BUTTON)
  }
}
