// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.DriverReviewPage. */
export class DriverReviewPage extends CoreBasePage {
  public readonly driverReviewPageHeader: Locator;
  public readonly driverReviewPageDescription: Locator;
  public readonly driversRevisionHyperlink: Locator;
  public readonly additionalDriverInfoIcon: Locator;
  public readonly pniInfoIcon: Locator;
  public readonly sniInfoIcon: Locator;
  public readonly infoBoxHeader: Locator;
  public readonly infoBoxContent: Locator;
  public readonly infoBoxCloseButton: Locator;
  public readonly editDriverButtons: Locator;
  public readonly editDriverDialog: Locator;
  public readonly genderToggleLabels: Locator;
  public readonly editDriverDialogCloseLink: Locator;
  public readonly addDriverHeading: Locator;
  public readonly driverLicenseQuestionLabel: Locator;
  public readonly currentlyInsuredQuestionLabel: Locator;
  public readonly saveChangesButton: Locator;
  public readonly editDriverCancelButton: Locator;
  public readonly occupationSidePanelCancelButton: Locator;
  public readonly listOfFirstNameFields: Locator;
  public readonly firstNameErrorMessage: Locator;
  public readonly listOfLastNameFields: Locator;
  public readonly lastNameErrorMessage: Locator;
  public readonly dateOfBirthErrorMessage: Locator;
  public readonly listOfDateOfBirthFields: Locator;
  public readonly listOfFemaleGenderButtons: Locator;
  public readonly genderErrorMessage: Locator;
  public readonly drivingSpouseErrorMessage: Locator;
  public readonly licenseErrorMessageForDrivingSpouse: Locator;
  public readonly licenseIssuedErrorMessages: Locator;
  public readonly editDriverModalErrorMessage: Locator;
  public readonly listOfSaveButtons: Locator;
  public readonly changeStatusHeading: Locator;
  public readonly changeStatusContent: Locator;
  public readonly maritalCheckboxSubtexts: Locator;
  public readonly removeStatusButton: Locator;
  public readonly keepAsIsButton: Locator;
  public readonly accidentCheckboxes: Locator;
  public readonly accidentQuestions: Locator;
  public readonly employedCheckboxes: Locator;
  public readonly occupationInputField: Locator;
  public readonly occupationInputFieldLabel: Locator;
  public readonly occupationInputFieldHint: Locator;
  public readonly employmentDiscountQualification: Locator;
  public readonly employmentDiscountNotEligible: Locator;
  public readonly minAgeSection: Locator;
  public readonly accidentSubTexts: Locator;
  public readonly bundleCheckbox: Locator;
  public readonly bundleCheckboxLabel: Locator;
  public readonly ctaErrorMessage: Locator;
  public readonly continueButton: Locator;
  public readonly ctaDescription: Locator;
  public readonly addAdditionalFarmersProductsLink: Locator;
  public readonly bundleCardHeader: Locator;
  public readonly bundleCardContent: Locator;
  public readonly bundleLink: Locator;
  public readonly bundleLinkText: Locator;
  public readonly bundleInfoIcon: Locator;
  public readonly bundleInfoHeader: Locator;
  public readonly bundleInfoContent: Locator;
  public readonly bundleModalHeader: Locator;
  public readonly bundleCancelLink: Locator;
  public readonly saveBundleItems: Locator;
  public readonly bundleCheckboxes: Locator;
  public readonly saveBundleErrorMessage: Locator;
  public readonly saveAndBundleAddButton: Locator;
  public readonly saveBundleSelectedItem: Locator;
  public readonly removeBundleHeader: Locator;
  public readonly removeBundleContent: Locator;
  public readonly removeBundleKeepItButton: Locator;
  public readonly removeBundleButton: Locator;
  public readonly addEditAdditionalPolicies: Locator;
  public readonly bundleCongratsMessage: Locator;
  public readonly bundleDialogueCloseIcon: Locator;
  public readonly studentDiscountCheckboxLabels: Locator;
  public readonly eligibleOccupationModalHeader: Locator;
  public readonly employedOrRetiredTitle: Locator;
  public readonly selectEligibleOccupationsTitle: Locator;
  public readonly discountUnavailableMessage: Locator;
  public readonly occupationSidePanelErrorMessage: Locator;
  public readonly occupationsSidePanelToggles: Locator;
  public readonly employedToggle: Locator;
  public readonly retiredToggle: Locator;
  public readonly discountUnavailable: Locator;
  public readonly occupationRadioButtons: Locator;
  public readonly occupationAddedConfirmation: Locator;
  public readonly removeOccupationButton: Locator;
  public readonly removeOccupationPanelHeader: Locator;
  public readonly keepOccupation: Locator;
  public readonly removeButton: Locator;
  public readonly closeOrSaveButtonOccupationSideSheet: Locator;
  public readonly occupationHeaders: Locator;
  public readonly occupationSubtexts: Locator;
  public readonly driverLicenseNumberInfoBoxHeaderBrowser: Locator;
  public readonly driverLicenseNumberInfoBoxTextBrowser: Locator;
  public readonly driverLicenseNumberInfoBoxMobileIcon: Locator;
  public readonly driverLicenseNumberInfoBoxHeaderMobile: Locator;
  public readonly driverLicenseAgeInfoHeaderBrowser: Locator;
  public readonly driverLicenseInfoInfoHeaderBrowser: Locator;
  public readonly driverLicenseAtWhatAgeBrowser: Locator;
  public readonly driverLicenseGapBrowser: Locator;
  public readonly licensingInfoHelpContent: Locator;
  public readonly driverLicenseAgeMobileHelpIcon: Locator;
  public readonly driverLicensingInfoMobileHelpIcon: Locator;
  public readonly driverLicenseNumberInputError: Locator;
  public readonly driverLicenseAgeError: Locator;
  public readonly lblGPAOver30: Locator;
  public readonly chkGPAOver30: Locator;
  public readonly chkAttendsSchoolMoreThan300Miles: Locator;
  public readonly lblMustBeAFullTimeStudent: Locator;
  public readonly lblMustBeAFullTimeStudentAndLicensedForLessThan10Yrs: Locator;
  public readonly lblAttendsSchoolMoreThan100Miles: Locator;
  public readonly lblSharesVehicleUsage: Locator;
  public readonly lblMustBeAFullTimeStudentAndChildOfPNI: Locator;
  public readonly chkSharesVehicleUsage: Locator;
  public readonly noOccupationToggleOptions: Locator;

  public constructor(page: Page) {
    super(page);
    this.driverReviewPageHeader = page.locator("#auto-driver-review-header"); // @FindBy(id = "auto-driver-review-header")
    this.driverReviewPageDescription = page.locator("xpath=//div[@class='auto-driver-review-heading-note']//p[@class='tui-field-label-text']"); // @FindBy(xpath = "//div[@class='auto-driver-review-heading-note']//p[@class='tui-field-label-text']")
    this.driversRevisionHyperlink = page.locator("xpath=//*[@data-tui-tracking-id='auto-drivers-review__drivers-overview-hyperlink']"); // @FindBy(xpath = "//*[@data-tui-tracking-id='auto-drivers-review__drivers-overview-hyperlink']")
    this.additionalDriverInfoIcon = page.locator("mat-icon[data-tui-tracking-id='auto-drivers-review__additional-info']"); // @FindBy(css = "mat-icon[data-tui-tracking-id='auto-drivers-review__additional-info']")
    this.pniInfoIcon = page.locator("mat-icon[data-tui-tracking-id='auto-drivers-review__pni-info']"); // @FindBy(css = "mat-icon[data-tui-tracking-id='auto-drivers-review__pni-info']")
    this.sniInfoIcon = page.locator("mat-icon[data-tui-tracking-id='auto-drivers-review__sni-info']"); // @FindBy(css = "mat-icon[data-tui-tracking-id='auto-drivers-review__sni-info']")
    this.infoBoxHeader = page.locator("xpath=//h1[@class='model-caption-head']"); // @FindBy(xpath = "//h1[@class='model-caption-head']")
    this.infoBoxContent = page.locator("xpath=//p[contains(@class,'model-caption-text')]"); // @FindBy(xpath = "//p[contains(@class,'model-caption-text')]")
    this.infoBoxCloseButton = page.locator("xpath=//mat-icon[.='close']"); // @FindBy(xpath = "//mat-icon[.='close']")
    this.editDriverButtons = page.locator("[data-legacy-field=\"editDriverButtons\"]"); // @FindBy(xpath = EDIT_DRIVER_BUTTON_XPATH)
    this.editDriverDialog = page.locator("xpath=//mat-dialog-container"); // @FindBy(xpath = "//mat-dialog-container")
    this.genderToggleLabels = page.locator(".mat-button-toggle-label-content"); // @FindBy(className = "mat-button-toggle-label-content")
    this.editDriverDialogCloseLink = page.locator("[data-legacy-field=\"editDriverDialogCloseLink\"]"); // @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_CLOSE_LINK_XPATH + OR_OPERATOR + DIALOG_CLOSE_LINK_XPATH)
    this.addDriverHeading = page.locator("#addDriverHeading"); // @FindBy(id = "addDriverHeading")
    this.driverLicenseQuestionLabel = page.locator("xpath=//label[contains(@class,'auto-add-driver-license__label')]"); // @FindBy(xpath = "//label[contains(@class,'auto-add-driver-license__label')]")
    this.currentlyInsuredQuestionLabel = page.locator("xpath=//label[contains(@class,'auto-add-driver-currently-insured__label')]"); // @FindBy(xpath = "//label[contains(@class,'auto-add-driver-currently-insured__label')]")
    this.saveChangesButton = page.locator("xpath=//div[contains(@class,'auto-add-driver-submit')]//button"); // @FindBy(xpath = "//div[contains(@class,'auto-add-driver-submit')]//button")
    this.editDriverCancelButton = page.getByRole('link', { name: "Cancel" }); // @FindBy(partialLinkText = "Cancel")
    this.occupationSidePanelCancelButton = page.locator("xpath=//mat-dialog-actions//button[contains(.,'Cancel')]"); // @FindBy(xpath = "//mat-dialog-actions//button[contains(.,'Cancel')]")
    this.listOfFirstNameFields = page.locator("xpath=//mat-form-field[contains(.,'First name')]"); // @FindBy(xpath = "//mat-form-field[contains(.,'First name')]")
    this.firstNameErrorMessage = page.locator("[data-legacy-field=\"firstNameErrorMessage\"]"); // @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_FIRST_NAME_ERROR_LABEL_XPATH + OR_OPERATOR + DIALOG_FIRST_NAME_ERROR_LABEL_XPATH)
    this.listOfLastNameFields = page.locator("xpath=//mat-form-field[contains(.,'Last name')]"); // @FindBy(xpath = "//mat-form-field[contains(.,'Last name')]")
    this.lastNameErrorMessage = page.locator("[data-legacy-field=\"lastNameErrorMessage\"]"); // @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_LAST_NAME_ERROR_LABEL_XPATH + OR_OPERATOR + DIALOG_LAST_NAME_ERROR_LABEL_XPATH)
    this.dateOfBirthErrorMessage = page.locator("[data-legacy-field=\"dateOfBirthErrorMessage\"]"); // @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_DATE_OF_BIRTH_ERROR_LABEL_XPATH + OR_OPERATOR + DIALOG_DATE_OF_BIRTH_ERROR_LABEL_XPATH)
    this.listOfDateOfBirthFields = page.locator("xpath=//mat-form-field[contains(.,'Date of birth')]"); // @FindBy(xpath = "//mat-form-field[contains(.,'Date of birth')]")
    this.listOfFemaleGenderButtons = page.locator("[data-legacy-field=\"listOfFemaleGenderButtons\"]"); // @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_GENDER_BUTTONS_XPATH + OR_OPERATOR + "//div[@id='gender']//button[string-length(@tabindex)>0]/span[contains(text(),'Female')]")
    this.genderErrorMessage = page.locator("[data-legacy-field=\"genderErrorMessage\"]"); // @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_GENDER_ERROR_LABEL_XPATH + OR_OPERATOR + DIALOG_GENDER_ERROR_LABEL_XPATH)
    this.drivingSpouseErrorMessage = page.locator("xpath=//div[contains(@class,'licenseToggleQuestion')]//mat-error"); // @FindBy(xpath = "//div[contains(@class,'licenseToggleQuestion')]//mat-error")
    this.licenseErrorMessageForDrivingSpouse = page.locator("xpath=//div[@id='formField_licenseIssued']//mat-error[not(contains(@aria-hidden,'true'))]"); // @FindBy(xpath = "//div[@id='formField_licenseIssued']//mat-error[not(contains(@aria-hidden,'true'))]")
    this.licenseIssuedErrorMessages = page.locator("xpath=//div[@id='formField_licenseIssued']//mat-error"); // @FindBy(xpath = "//div[@id='formField_licenseIssued']//mat-error")
    this.editDriverModalErrorMessage = page.locator("xpath=//p[contains(@class,'auto-add-driver__error-message')]"); // @FindBy(xpath = "//p[contains(@class,'auto-add-driver__error-message')]")
    this.listOfSaveButtons = page.locator("[data-legacy-field=\"listOfSaveButtons\"]"); // @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_SAVE_BUTTON_XPATH + OR_OPERATOR + DIALOG_SAVE_BUTTON_XPATH)
    this.changeStatusHeading = page.locator("#changeStatusHeading"); // @FindBy(id = "changeStatusHeading")
    this.changeStatusContent = page.locator("#changeStatusContent"); // @FindBy(id = "changeStatusContent")
    this.maritalCheckboxSubtexts = page.locator("xpath=//div[@class='auto-driver-review-question-married']//p"); // @FindBy(xpath = "//div[@class='auto-driver-review-question-married']//p")
    this.removeStatusButton = page.locator("[data-legacy-field=\"removeStatusButton\"]"); // @FindBy(xpath = REMOVE_STATUS_XPATH)
    this.keepAsIsButton = page.locator("button[class='tui-btn tui-btn-secondary tui-button-text']"); // @FindBy(css = "button[class='tui-btn tui-btn-secondary tui-button-text']")
    this.accidentCheckboxes = page.locator("xpath=//div[contains(@id,'hadAccidentOrViolation')]//mat-checkbox//input[contains(@aria-label,'Had an accident')]"); // @FindBy(xpath = "//div[contains(@id,'hadAccidentOrViolation')]//mat-checkbox//input[contains(@aria-label,'Had an accident')]")
    this.accidentQuestions = page.locator("xpath=//div[contains(@id,'ordered-field-placeholder_hadAccidentOrViolation')]//label[@class='mdc-label']"); // @FindBy(xpath = "//div[contains(@id,'ordered-field-placeholder_hadAccidentOrViolation')]//label[@class='mdc-label']")
    this.employedCheckboxes = page.locator("xpath=//mat-checkbox[@formcontrolname='isEmployed']//input"); // @FindBy(xpath = "//mat-checkbox[@formcontrolname='isEmployed']//input")
    this.occupationInputField = page.locator("xpath=//occupation-typeahead//input"); // @FindBy(xpath = "//occupation-typeahead//input")
    this.occupationInputFieldLabel = page.locator("xpath=//occupation-typeahead//mat-label"); // @FindBy(xpath = "//occupation-typeahead//mat-label")
    this.occupationInputFieldHint = page.locator("xpath=//occupation-typeahead//mat-hint"); // @FindBy(xpath = "//occupation-typeahead//mat-hint")
    this.employmentDiscountQualification = page.locator("xpath=//div[contains(@class,'auto-occupation-selected-message')]"); // @FindBy(xpath = "//div[contains(@class,'auto-occupation-selected-message')]")
    this.employmentDiscountNotEligible = page.locator("div[class='auto-occupation-not-found-message tui-body-text-1 ng-star-inserted']"); // @FindBy(css = "div[class='auto-occupation-not-found-message tui-body-text-1 ng-star-inserted']")
    this.minAgeSection = page.locator("div[class='auto-driver-review-question-min-age-section']"); // @FindBy(css = "div[class='auto-driver-review-question-min-age-section']")
    this.accidentSubTexts = page.locator("xpath=//*[contains(@id,'ordered-field-placeholder_hadAccidentOrViolation')]//p"); // @FindBy(xpath = "//*[contains(@id,'ordered-field-placeholder_hadAccidentOrViolation')]//p")
    this.bundleCheckbox = page.locator("xpath=//div[@class='col auto-driver-discount-save-bundle-checkbox ng-star-inserted']//input"); // @FindBy(xpath = "//div[@class='col auto-driver-discount-save-bundle-checkbox ng-star-inserted']//input")
    this.bundleCheckboxLabel = page.locator("xpath=//mat-checkbox[@attr.aria-label=\"Farmers Bundle and Save Discount\"]//span[@class='mat-checkbox-label']"); // @FindBy(xpath = "//mat-checkbox[@attr.aria-label=\"Farmers Bundle and Save Discount\"]//span[@class='mat-checkbox-label']")
    this.ctaErrorMessage = page.locator("xpath=//div[contains(@class,'auto-driver-review-cta-validation-text-holder')]//span"); // @FindBy(xpath = "//div[contains(@class,'auto-driver-review-cta-validation-text-holder')]//span")
    this.continueButton = page.locator("#auto-driver-review-cta-continue"); // @FindBy(id = "auto-driver-review-cta-continue")
    this.ctaDescription = page.locator("xpath=//div[contains(@class,'auto-driver-review-cta-button-container')]//div"); // @FindBy(xpath = "//div[contains(@class,'auto-driver-review-cta-button-container')]//div")
    this.addAdditionalFarmersProductsLink = page.locator("xpath=//a[contains(@class, 'auto-drivers-review__save-bundle-link')]"); // @FindBy(xpath = "//a[contains(@class, 'auto-drivers-review__save-bundle-link')]")
    this.bundleCardHeader = page.locator("p[class='tui-body-text-bold auto-driver-review-save-bundle-text']"); // @FindBy(css = "p[class='tui-body-text-bold auto-driver-review-save-bundle-text']")
    this.bundleCardContent = page.locator("xpath=//div[contains(@class,'auto-driver-review-save-bundle-content')]/p[2]"); // @FindBy(xpath = "//div[contains(@class,'auto-driver-review-save-bundle-content')]/p[2]")
    this.bundleLink = page.locator("a[class='auto-drivers-review__save-bundle-link tui-anchor']"); // @FindBy(css = "a[class='auto-drivers-review__save-bundle-link tui-anchor']")
    this.bundleLinkText = page.locator("a[class='auto-drivers-review__save-bundle-link tui-anchor']"); // @FindBy(css = "a[class='auto-drivers-review__save-bundle-link tui-anchor']")
    this.bundleInfoIcon = page.locator("div[class='auto-driver-review-save-bundle-info-icon']>mat-icon"); // @FindBy(css = "div[class='auto-driver-review-save-bundle-info-icon']>mat-icon")
    this.bundleInfoHeader = page.locator("div[class='auto-driver-review-save-bundle-info-header-content']>h5"); // @FindBy(css = "div[class='auto-driver-review-save-bundle-info-header-content']>h5")
    this.bundleInfoContent = page.locator("div[class='auto-driver-review-save-bundle-info-header-content']>p"); // @FindBy(css = "div[class='auto-driver-review-save-bundle-info-header-content']>p")
    this.bundleModalHeader = page.locator("xpath=//div[@class='auto-driver-review-save-bundle-side-sheet-title']//h4"); // @FindBy(xpath = "//div[@class='auto-driver-review-save-bundle-side-sheet-title']//h4")
    this.bundleCancelLink = page.locator("div[class='auto-driver-review-cancel-button']>button"); // @FindBy(css = "div[class='auto-driver-review-cancel-button']>button")
    this.saveBundleItems = page.locator("xpath=//div[contains(@class,'auto-driver-review-save-bundle-items')]//span[@class='mat-checkbox-label']"); // @FindBy(xpath = "//div[contains(@class,'auto-driver-review-save-bundle-items')]//span[@class='mat-checkbox-label']")
    this.bundleCheckboxes = page.locator("xpath=//div[contains(@class,'auto-driver-review-save-bundle-items')]//mat-checkbox"); // @FindBy(xpath = "//div[contains(@class,'auto-driver-review-save-bundle-items')]//mat-checkbox")
    this.saveBundleErrorMessage = page.locator("xpath=//span[contains(text(),'Please select a product to be eligible for discount.')]"); // @FindBy(xpath = "//span[contains(text(),'Please select a product to be eligible for discount.')]")
    this.saveAndBundleAddButton = page.locator("button[class='tui-btn tui-btn-primary auto-save-bundle-sheet-add-button']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary auto-save-bundle-sheet-add-button']")
    this.saveBundleSelectedItem = page.locator("span[class='auto-driver-discount-save-bundle-selected-item']"); // @FindBy(css = "span[class='auto-driver-discount-save-bundle-selected-item']")
    this.removeBundleHeader = page.locator("xpath=//app-remove-bundle//h5"); // @FindBy(xpath = "//app-remove-bundle//h5")
    this.removeBundleContent = page.locator("#remove-bundle-content"); // @FindBy(id = "remove-bundle-content")
    this.removeBundleKeepItButton = page.locator("xpath=//button[contains(@class,'tui-btn tui-btn-link tui-button-text')]"); // @FindBy(xpath = "//button[contains(@class,'tui-btn tui-btn-link tui-button-text')]")
    this.removeBundleButton = page.locator("div[class='col remove-action-button']"); // @FindBy(css = "div[class='col remove-action-button']")
    this.addEditAdditionalPolicies = page.locator("div[class='col auto-driver-discount-save-bundle-add-edit-link']"); // @FindBy(css = "div[class='col auto-driver-discount-save-bundle-add-edit-link']")
    this.bundleCongratsMessage = page.locator("p[class='auto-driver-review-save-bundle-congratulations-message']"); // @FindBy(css = "p[class='auto-driver-review-save-bundle-congratulations-message']")
    this.bundleDialogueCloseIcon = page.locator("xpath=//app-save-bundle-sheet//mat-icon"); // @FindBy(xpath = "//app-save-bundle-sheet//mat-icon")
    this.studentDiscountCheckboxLabels = page.locator("xpath=//div[contains(@class,'auto-driver-discount-full-time')]//div[contains(@class,'auto-driver-review-student-container')]"); // @FindBy(xpath = "//div[contains(@class,'auto-driver-discount-full-time')]//div[contains(@class,'auto-driver-review-student-container')]")
    this.eligibleOccupationModalHeader = page.locator("[data-legacy-field=\"eligibleOccupationModalHeader\"]"); // @FindBy(xpath = OCCUPATION_SIDE_PANEL_HEADER_XPATH)
    this.employedOrRetiredTitle = page.locator("xpath=//div[contains(@class,'row occupation-retired-checkbox')]//p"); // @FindBy(xpath = "//div[contains(@class,'row occupation-retired-checkbox')]//p")
    this.selectEligibleOccupationsTitle = page.locator("xpath=//p[contains(.,'Select from the list of eligible occupation(s). Verification of occupation will be required.')]"); // @FindBy(xpath = "//p[contains(.,'Select from the list of eligible occupation(s). Verification of occupation will be required.')]")
    this.discountUnavailableMessage = page.locator("[data-legacy-field=\"discountUnavailableMessage\"]"); // @FindBy(xpath = DISCOUNT_UNAVAILABLE_MESSAGE_XPATH)
    this.occupationSidePanelErrorMessage = page.locator("[data-legacy-field=\"occupationSidePanelErrorMessage\"]"); // @FindBy(xpath = OCCUPATION_SIDE_PANEL_ERROR_MESSAGE_XPATH)
    this.occupationsSidePanelToggles = page.locator("xpath=//div[contains(@class,'row occupation-retired-checkbox')]//mat-button-toggle"); // @FindBy(xpath = "//div[contains(@class,'row occupation-retired-checkbox')]//mat-button-toggle")
    this.employedToggle = page.locator("xpath=//mat-button-toggle[contains(.,'Employed')]"); // @FindBy(xpath = "//mat-button-toggle[contains(.,'Employed')]")
    this.retiredToggle = page.locator("xpath=//mat-button-toggle[contains(.,'Retired')]"); // @FindBy(xpath = "//mat-button-toggle[contains(.,'Retired')]")
    this.discountUnavailable = page.locator("xpath=//div[contains(@class,'discount-unavailable')]"); // @FindBy(xpath = "//div[contains(@class,'discount-unavailable')]")
    this.occupationRadioButtons = page.locator("[data-legacy-field=\"occupationRadioButtons\"]"); // @FindBy(xpath = occupationRadioButtonsXpath)
    this.occupationAddedConfirmation = page.locator("[data-legacy-field=\"occupationAddedConfirmation\"]"); // @FindBy(xpath = OCCUPATION_ADDED_CONFIRMATION_XPATH)
    this.removeOccupationButton = page.getByRole('link', { name: "Remove occupation" }); // @FindBy(partialLinkText = "Remove occupation"),             @FindBy(xpath = "//a[@class='auto-drivers-review-occupation-remove tui-link-footer offset-1 text-decoration-none']")     })
    this.removeOccupationPanelHeader = page.locator("xpath=//h1[contains(@class,'remove-occupation-title')]"); // @FindBy(xpath = "//h1[contains(@class,'remove-occupation-title')]")
    this.keepOccupation = page.locator("xpath=//button[contains(@class,'keep-it-action-button')]"); // @FindBy(xpath = "//button[contains(@class,'keep-it-action-button')]")
    this.removeButton = page.locator("xpath=//div[contains(@class,'remove-action-button')]//button"); // @FindBy(xpath = "//div[contains(@class,'remove-action-button')]//button")
    this.closeOrSaveButtonOccupationSideSheet = page.locator("[data-legacy-field=\"closeOrSaveButtonOccupationSideSheet\"]"); // @FindBy(css = ADD_BUTTON_CSS)
    this.occupationHeaders = page.locator("xpath=//div[contains(@class,'occupation-ab-section-card') or contains(@class,'auto-driver-review-occupation-heading')]//p"); // @FindBy(xpath = "//div[contains(@class,'occupation-ab-section-card') or contains(@class,'auto-driver-review-occupation-heading')]//p"),             @FindBy(id = "occupationLabel")     })
    this.occupationSubtexts = page.locator("xpath=//div[contains(@class,'occupation-ab-section-card') or contains(@class,'auto-driver-review-occupation-heading')]//p[2]"); // @FindBy(xpath = "//div[contains(@class,'occupation-ab-section-card') or contains(@class,'auto-driver-review-occupation-heading')]//p[2]"),             @FindBy(id = "occupationDesc")     })
    this.driverLicenseNumberInfoBoxHeaderBrowser = page.locator("xpath=//div[contains(@class,'license-info')]//p[@class='tui-info-box-header tui-field-label-text']"); // @FindBy(xpath = "//div[contains(@class,'license-info')]//p[@class='tui-info-box-header tui-field-label-text']")
    this.driverLicenseNumberInfoBoxTextBrowser = page.locator("xpath=//div[contains(@class,'license-info')]//p[@class='tui-info-box-content']"); // @FindBy(xpath = "//div[contains(@class,'license-info')]//p[@class='tui-info-box-content']")
    this.driverLicenseNumberInfoBoxMobileIcon = page.locator("xpath=//mat-icon[@data-tui-tracking-id='auto-drivers-review__driver-license']"); // @FindBy(xpath = "//mat-icon[@data-tui-tracking-id='auto-drivers-review__driver-license']")
    this.driverLicenseNumberInfoBoxHeaderMobile = page.locator("xpath=//mat-icon[@data-tui-tracking-id='auto-drivers-review__driver-license']"); // @FindBy(xpath = "//mat-icon[@data-tui-tracking-id='auto-drivers-review__driver-license']")
    this.driverLicenseAgeInfoHeaderBrowser = page.locator("xpath=//div[contains(@class,'auto-driver-review-age-licensed')]//div[@class='auto-driver-review-info-header-content']//p[1]"); // @FindBy(xpath = "//div[contains(@class,'auto-driver-review-age-licensed')]//div[@class='auto-driver-review-info-header-content']//p[1]")
    this.driverLicenseInfoInfoHeaderBrowser = page.locator("xpath=//div[contains(@class,'licensing-Info')]//p[@class='tui-info-box-header tui-field-label-text']"); // @FindBy(xpath = "//div[contains(@class,'licensing-Info')]//p[@class='tui-info-box-header tui-field-label-text']")
    this.driverLicenseAtWhatAgeBrowser = page.locator("xpath=//div[contains(@class,'auto-driver-review-age-licensed')]//div[@class='auto-driver-review-info-header-content']//p[2]"); // @FindBy(xpath = "//div[contains(@class,'auto-driver-review-age-licensed')]//div[@class='auto-driver-review-info-header-content']//p[2]")
    this.driverLicenseGapBrowser = page.locator("xpath=//div[contains(@class,'auto-driver-review-age-licensed')]//div[@class='auto-driver-review-info-header-content']//p[3]"); // @FindBy(xpath = "//div[contains(@class,'auto-driver-review-age-licensed')]//div[@class='auto-driver-review-info-header-content']//p[3]")
    this.licensingInfoHelpContent = page.locator("xpath=//div[contains(@class,'licensing-Info')]//p[@class='tui-info-box-content']"); // @FindBy(xpath = "//div[contains(@class,'licensing-Info')]//p[@class='tui-info-box-content']")
    this.driverLicenseAgeMobileHelpIcon = page.locator("xpath=//mat-icon[contains(@class,'mat-icon notranslate auto-driver-review-age-licensed-info tui-info-box-icon mobile-info-icon')]"); // @FindBy(xpath = "//mat-icon[contains(@class,'mat-icon notranslate auto-driver-review-age-licensed-info tui-info-box-icon mobile-info-icon')]")
    this.driverLicensingInfoMobileHelpIcon = page.locator("xpath=//mat-icon[@data-tui-tracking-id='auto-drivers-review__licensing-info']"); // @FindBy(xpath = "//mat-icon[@data-tui-tracking-id='auto-drivers-review__licensing-info']")
    this.driverLicenseNumberInputError = page.locator("[data-legacy-field=\"driverLicenseNumberInputError\"]"); // @FindBy(xpath = DRIVER_LICENSE_NUMBER_INPUT_ERROR_XPATH)
    this.driverLicenseAgeError = page.locator("xpath=//mat-error[contains(@class,'age-license-eror') and not(@hidden)]"); // @FindBy(xpath = "//mat-error[contains(@class,'age-license-eror') and not(@hidden)]")
    this.lblGPAOver30 = page.locator("[data-legacy-field=\"lblGPAOver30\"]"); // @FindBy(xpath = GPA_OVER_3_CHECKBOX_XPATH)
    this.chkGPAOver30 = page.locator("[data-legacy-field=\"chkGPAOver30\"]"); // @FindBy(xpath = GPA_OVER_3_INPUT_XPATH)
    this.chkAttendsSchoolMoreThan300Miles = page.locator("[data-legacy-field=\"chkAttendsSchoolMoreThan300Miles\"]"); // @FindBy(xpath = DISTANT_STUDENT_CHECKBOX_INPUT_XPATH)
    this.lblMustBeAFullTimeStudent = page.locator("[data-legacy-field=\"lblMustBeAFullTimeStudent\"]"); // @FindBy(xpath = MUST_BE_A_FULL_TIME_STUDENT_LABEL_XPATH)
    this.lblMustBeAFullTimeStudentAndLicensedForLessThan10Yrs = page.locator("[data-legacy-field=\"lblMustBeAFullTimeStudentAndLicensedForLessThan10Yrs\"]"); // @FindBy(xpath = MUST_BE_A_FULL_TIME_STUDENT_AND_LICENSED_LESS_THAN_10_YEARS_XPATH)
    this.lblAttendsSchoolMoreThan100Miles = page.locator("[data-legacy-field=\"lblAttendsSchoolMoreThan100Miles\"]"); // @FindBy(xpath = DISTANT_STUDENT_XPATH)
    this.lblSharesVehicleUsage = page.locator("xpath=//div[normalize-space(text())='Shares vehicle usage in household']"); // @FindBy(xpath = "//div[normalize-space(text())='Shares vehicle usage in household']")
    this.lblMustBeAFullTimeStudentAndChildOfPNI = page.locator("[data-legacy-field=\"lblMustBeAFullTimeStudentAndChildOfPNI\"]"); // @FindBy(xpath = DISTANT_STUDENT_SUBTEXT_XPATH)
    this.chkSharesVehicleUsage = page.locator("xpath=//div[normalize-space(text())='Shares vehicle usage in household']//input"); // @FindBy(xpath = "//div[normalize-space(text())='Shares vehicle usage in household']//input")
    this.noOccupationToggleOptions = page.locator("xpath=//mat-button-toggle-group[contains(@class,'occupation-affinity-toggle')]//button[@aria-label='No']"); // @FindBy(xpath = "//mat-button-toggle-group[contains(@class,'occupation-affinity-toggle')]//button[@aria-label='No']")
  }
}
