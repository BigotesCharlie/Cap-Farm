// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.legacy.PaymentPage. */
export class PaymentPage extends CoreBasePage {
  public readonly paymentPageTitle: Locator;
  public readonly paymentPageDescription: Locator;
  public readonly termPremium: Locator;
  public readonly paymentPlanHeader: Locator;
  public readonly changePaymentPlanLink: Locator;
  public readonly continueToSignButton: Locator;
  public readonly agreeToUseESign: Locator;
  public readonly continueFromESign: Locator;
  public readonly bwFinishDocReviewButton: Locator;
  public readonly selectPaymentDialogTitle: Locator;
  public readonly payInFullOption: Locator;
  public readonly payInFullRadioButtonSection: Locator;
  public readonly payInFullDueTodaySection: Locator;
  public readonly payInFullNextPaymentSection: Locator;
  public readonly payInFullPaymentScheduleSection: Locator;
  public readonly monthlyBankAccountOption: Locator;
  public readonly monthlyBankAccountRadioButtonSection: Locator;
  public readonly monthlyBankAccountDueTodaySection: Locator;
  public readonly monthlyBankAccountNextPaymentSection: Locator;
  public readonly monthlyBankAccountPaymentScheduleSection: Locator;
  public readonly monthlyCreditCardOption: Locator;
  public readonly monthlyCreditCardRadioButtonSection: Locator;
  public readonly monthlyCreditCardDueTodaySection: Locator;
  public readonly monthlyCreditCardNextPaymentSection: Locator;
  public readonly monthlyCreditCardPaymentScheduleSection: Locator;
  public readonly monthlyDebitCardOption: Locator;
  public readonly monthlyDebitCardRadioButtonSection: Locator;
  public readonly monthlyDebitCardDueTodaySection: Locator;
  public readonly monthlyDebitCardNextPaymentSection: Locator;
  public readonly monthlyDebitCardPaymentScheduleSection: Locator;
  public readonly monthlyBillingOption: Locator;
  public readonly monthlyBillingRadioButtonSection: Locator;
  public readonly monthlyBillingDueTodaySection: Locator;
  public readonly monthlyBillingNextPaymentSection: Locator;
  public readonly monthlyBillingPaymentScheduleSection: Locator;
  public readonly bwPayInFullOption: Locator;
  public readonly bwPayInFullRadioButtonSection: Locator;
  public readonly bwPayInFullDueTodaySection: Locator;
  public readonly bwPayInFullNextPaymentSection: Locator;
  public readonly bwPayInFullPaymentScheduleSection: Locator;
  public readonly bwMonthlyBankAccountOption: Locator;
  public readonly bwMonthlyBankAccountRadioButtonSection: Locator;
  public readonly bwMonthlyBankAccountDueTodaySection: Locator;
  public readonly bwMonthlyBankAccountNextPaymentSection: Locator;
  public readonly bwMonthlyBankAccountPaymentScheduleSection: Locator;
  public readonly bwMonthlyCreditCardOption: Locator;
  public readonly bwMonthlyCreditCardRadioButtonSection: Locator;
  public readonly bwMonthlyCreditCardDueTodaySection: Locator;
  public readonly bwMonthlyCreditCardNextPaymentSection: Locator;
  public readonly bwMonthlyCreditCardPaymentScheduleSection: Locator;
  public readonly bwMonthlyDebitCardOption: Locator;
  public readonly bwMonthlyDebitCardRadioButtonSection: Locator;
  public readonly bwMonthlyDebitCardDueTodaySection: Locator;
  public readonly bwMonthlyDebitCardNextPaymentSection: Locator;
  public readonly bwMonthlyDebitCardPaymentScheduleSection: Locator;
  public readonly bwMonthlyBillingOption: Locator;
  public readonly bwMonthlyBillingRadioButtonSection: Locator;
  public readonly bwMonthlyBillingDueTodaySection: Locator;
  public readonly bwMonthlyBillingNextPaymentSection: Locator;
  public readonly bwMonthlyBillingPaymentScheduleSection: Locator;
  public readonly continueButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.paymentPageTitle = page.locator("[data-legacy-field=\"paymentPageTitle\"]"); // @FindBy(xpath = PAYMENT_PAGE_HEADER + "/p[@title='PAYMENT DETAILS']")
    this.paymentPageDescription = page.locator("[data-legacy-field=\"paymentPageDescription\"]"); // @FindBy(xpath = PAYMENT_PAGE_HEADER + "/p[@class='subTitleAlign']")
    this.termPremium = page.locator("[data-legacy-field=\"termPremium\"]"); // @FindBy(xpath = PAYMENT_PAGE_HEADER + "/p[@id='termPremiumSecText']")
    this.paymentPlanHeader = page.locator("xpath=//span[contains(@id,'payment:paymentHeaderText')]"); // @FindBy(xpath = "//span[contains(@id,'payment:paymentHeaderText')]")
    this.changePaymentPlanLink = page.locator("#MoreOptions"); // @FindBy(id = "MoreOptions")
    this.continueToSignButton = page.locator("#payment:doInitiateESignature"); // @FindBy(id = "payment:doInitiateESignature")
    this.agreeToUseESign = page.locator("#disclosureAccepted"); // @FindBy(id = "disclosureAccepted")
    this.continueFromESign = page.locator("#action-bar-btn-continue"); // @FindBy(id = "action-bar-btn-continue")
    this.bwFinishDocReviewButton = page.locator("#action-bar-btn-finish"); // @FindBy(id = "action-bar-btn-finish")
    this.selectPaymentDialogTitle = page.locator("xpath=//div[contains(@class, 'selectPaymentOptionHeading')]"); // @FindBy(xpath = "//div[contains(@class, 'selectPaymentOptionHeading')]")
    this.payInFullOption = page.locator("[data-legacy-field=\"payInFullOption\"]"); // @FindBy(xpath = PAY_IN_FULL_SECTION)
    this.payInFullRadioButtonSection = page.locator("[data-legacy-field=\"payInFullRadioButtonSection\"]"); // @FindBy(xpath = PAY_IN_FULL_SECTION + RADIO_BUTTON_SECTION)
    this.payInFullDueTodaySection = page.locator("[data-legacy-field=\"payInFullDueTodaySection\"]"); // @FindBy(xpath = PAY_IN_FULL_SECTION + DUE_TODAY_SECTION)
    this.payInFullNextPaymentSection = page.locator("[data-legacy-field=\"payInFullNextPaymentSection\"]"); // @FindBy(xpath = PAY_IN_FULL_SECTION + NEXT_PAYMENT_SECTION)
    this.payInFullPaymentScheduleSection = page.locator("[data-legacy-field=\"payInFullPaymentScheduleSection\"]"); // @FindBy(xpath = PAY_IN_FULL_SECTION + PAYMENT_SCHEDULE_SECTION)
    this.monthlyBankAccountOption = page.locator("[data-legacy-field=\"monthlyBankAccountOption\"]"); // @FindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION)
    this.monthlyBankAccountRadioButtonSection = page.locator("[data-legacy-field=\"monthlyBankAccountRadioButtonSection\"]"); // @FindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION + RADIO_BUTTON_SECTION)
    this.monthlyBankAccountDueTodaySection = page.locator("[data-legacy-field=\"monthlyBankAccountDueTodaySection\"]"); // @FindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION + DUE_TODAY_SECTION)
    this.monthlyBankAccountNextPaymentSection = page.locator("[data-legacy-field=\"monthlyBankAccountNextPaymentSection\"]"); // @FindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION + NEXT_PAYMENT_SECTION)
    this.monthlyBankAccountPaymentScheduleSection = page.locator("[data-legacy-field=\"monthlyBankAccountPaymentScheduleSection\"]"); // @FindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION + PAYMENT_SCHEDULE_SECTION)
    this.monthlyCreditCardOption = page.locator("[data-legacy-field=\"monthlyCreditCardOption\"]"); // @FindBy(xpath = MONTHLY_CREDIT_CARD_SECTION)
    this.monthlyCreditCardRadioButtonSection = page.locator("[data-legacy-field=\"monthlyCreditCardRadioButtonSection\"]"); // @FindBy(xpath = MONTHLY_CREDIT_CARD_SECTION + RADIO_BUTTON_SECTION)
    this.monthlyCreditCardDueTodaySection = page.locator("[data-legacy-field=\"monthlyCreditCardDueTodaySection\"]"); // @FindBy(xpath = MONTHLY_CREDIT_CARD_SECTION + DUE_TODAY_SECTION)
    this.monthlyCreditCardNextPaymentSection = page.locator("[data-legacy-field=\"monthlyCreditCardNextPaymentSection\"]"); // @FindBy(xpath = MONTHLY_CREDIT_CARD_SECTION + NEXT_PAYMENT_SECTION)
    this.monthlyCreditCardPaymentScheduleSection = page.locator("[data-legacy-field=\"monthlyCreditCardPaymentScheduleSection\"]"); // @FindBy(xpath = MONTHLY_CREDIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION)
    this.monthlyDebitCardOption = page.locator("[data-legacy-field=\"monthlyDebitCardOption\"]"); // @FindBy(xpath = MONTHLY_DEBIT_CARD_SECTION)
    this.monthlyDebitCardRadioButtonSection = page.locator("[data-legacy-field=\"monthlyDebitCardRadioButtonSection\"]"); // @FindBy(xpath = MONTHLY_DEBIT_CARD_SECTION + RADIO_BUTTON_SECTION)
    this.monthlyDebitCardDueTodaySection = page.locator("[data-legacy-field=\"monthlyDebitCardDueTodaySection\"]"); // @FindBy(xpath = MONTHLY_DEBIT_CARD_SECTION + DUE_TODAY_SECTION)
    this.monthlyDebitCardNextPaymentSection = page.locator("[data-legacy-field=\"monthlyDebitCardNextPaymentSection\"]"); // @FindBy(xpath = MONTHLY_DEBIT_CARD_SECTION + NEXT_PAYMENT_SECTION)
    this.monthlyDebitCardPaymentScheduleSection = page.locator("[data-legacy-field=\"monthlyDebitCardPaymentScheduleSection\"]"); // @FindBy(xpath = MONTHLY_DEBIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION)
    this.monthlyBillingOption = page.locator("[data-legacy-field=\"monthlyBillingOption\"]"); // @FindBy(xpath = MONTHLY_BILLING_SECTION)
    this.monthlyBillingRadioButtonSection = page.locator("[data-legacy-field=\"monthlyBillingRadioButtonSection\"]"); // @FindBy(xpath = MONTHLY_BILLING_SECTION + RADIO_BUTTON_SECTION)
    this.monthlyBillingDueTodaySection = page.locator("[data-legacy-field=\"monthlyBillingDueTodaySection\"]"); // @FindBy(xpath = MONTHLY_BILLING_SECTION + DUE_TODAY_SECTION)
    this.monthlyBillingNextPaymentSection = page.locator("[data-legacy-field=\"monthlyBillingNextPaymentSection\"]"); // @FindBy(xpath = MONTHLY_BILLING_SECTION + NEXT_PAYMENT_SECTION)
    this.monthlyBillingPaymentScheduleSection = page.locator("[data-legacy-field=\"monthlyBillingPaymentScheduleSection\"]"); // @FindBy(xpath = MONTHLY_BILLING_SECTION + PAYMENT_SCHEDULE_SECTION)
    this.bwPayInFullOption = page.locator("[data-legacy-field=\"bwPayInFullOption\"]"); // @FindBy(xpath = BW_PAY_IN_FULL_SECTION)
    this.bwPayInFullRadioButtonSection = page.locator("[data-legacy-field=\"bwPayInFullRadioButtonSection\"]"); // @FindBy(xpath = BW_PAY_IN_FULL_SECTION + RADIO_BUTTON_SECTION)
    this.bwPayInFullDueTodaySection = page.locator("[data-legacy-field=\"bwPayInFullDueTodaySection\"]"); // @FindBy(xpath = BW_PAY_IN_FULL_SECTION + DUE_TODAY_SECTION)
    this.bwPayInFullNextPaymentSection = page.locator("[data-legacy-field=\"bwPayInFullNextPaymentSection\"]"); // @FindBy(xpath = BW_PAY_IN_FULL_SECTION + NEXT_PAYMENT_SECTION)
    this.bwPayInFullPaymentScheduleSection = page.locator("[data-legacy-field=\"bwPayInFullPaymentScheduleSection\"]"); // @FindBy(xpath = BW_PAY_IN_FULL_SECTION + PAYMENT_SCHEDULE_SECTION)
    this.bwMonthlyBankAccountOption = page.locator("[data-legacy-field=\"bwMonthlyBankAccountOption\"]"); // @FindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION)
    this.bwMonthlyBankAccountRadioButtonSection = page.locator("[data-legacy-field=\"bwMonthlyBankAccountRadioButtonSection\"]"); // @FindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION + RADIO_BUTTON_SECTION)
    this.bwMonthlyBankAccountDueTodaySection = page.locator("[data-legacy-field=\"bwMonthlyBankAccountDueTodaySection\"]"); // @FindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION + DUE_TODAY_SECTION)
    this.bwMonthlyBankAccountNextPaymentSection = page.locator("[data-legacy-field=\"bwMonthlyBankAccountNextPaymentSection\"]"); // @FindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION + NEXT_PAYMENT_SECTION)
    this.bwMonthlyBankAccountPaymentScheduleSection = page.locator("[data-legacy-field=\"bwMonthlyBankAccountPaymentScheduleSection\"]"); // @FindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION + PAYMENT_SCHEDULE_SECTION)
    this.bwMonthlyCreditCardOption = page.locator("[data-legacy-field=\"bwMonthlyCreditCardOption\"]"); // @FindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION)
    this.bwMonthlyCreditCardRadioButtonSection = page.locator("[data-legacy-field=\"bwMonthlyCreditCardRadioButtonSection\"]"); // @FindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION + RADIO_BUTTON_SECTION)
    this.bwMonthlyCreditCardDueTodaySection = page.locator("[data-legacy-field=\"bwMonthlyCreditCardDueTodaySection\"]"); // @FindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION + DUE_TODAY_SECTION)
    this.bwMonthlyCreditCardNextPaymentSection = page.locator("[data-legacy-field=\"bwMonthlyCreditCardNextPaymentSection\"]"); // @FindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION + NEXT_PAYMENT_SECTION)
    this.bwMonthlyCreditCardPaymentScheduleSection = page.locator("[data-legacy-field=\"bwMonthlyCreditCardPaymentScheduleSection\"]"); // @FindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION)
    this.bwMonthlyDebitCardOption = page.locator("[data-legacy-field=\"bwMonthlyDebitCardOption\"]"); // @FindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION)
    this.bwMonthlyDebitCardRadioButtonSection = page.locator("[data-legacy-field=\"bwMonthlyDebitCardRadioButtonSection\"]"); // @FindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION + RADIO_BUTTON_SECTION)
    this.bwMonthlyDebitCardDueTodaySection = page.locator("[data-legacy-field=\"bwMonthlyDebitCardDueTodaySection\"]"); // @FindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION + DUE_TODAY_SECTION)
    this.bwMonthlyDebitCardNextPaymentSection = page.locator("[data-legacy-field=\"bwMonthlyDebitCardNextPaymentSection\"]"); // @FindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION + NEXT_PAYMENT_SECTION)
    this.bwMonthlyDebitCardPaymentScheduleSection = page.locator("[data-legacy-field=\"bwMonthlyDebitCardPaymentScheduleSection\"]"); // @FindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION)
    this.bwMonthlyBillingOption = page.locator("[data-legacy-field=\"bwMonthlyBillingOption\"]"); // @FindBy(xpath = BW_MONTHLY_BILLING_SECTION)
    this.bwMonthlyBillingRadioButtonSection = page.locator("[data-legacy-field=\"bwMonthlyBillingRadioButtonSection\"]"); // @FindBy(xpath = BW_MONTHLY_BILLING_SECTION + RADIO_BUTTON_SECTION)
    this.bwMonthlyBillingDueTodaySection = page.locator("[data-legacy-field=\"bwMonthlyBillingDueTodaySection\"]"); // @FindBy(xpath = BW_MONTHLY_BILLING_SECTION + DUE_TODAY_SECTION)
    this.bwMonthlyBillingNextPaymentSection = page.locator("[data-legacy-field=\"bwMonthlyBillingNextPaymentSection\"]"); // @FindBy(xpath = BW_MONTHLY_BILLING_SECTION + NEXT_PAYMENT_SECTION)
    this.bwMonthlyBillingPaymentScheduleSection = page.locator("[data-legacy-field=\"bwMonthlyBillingPaymentScheduleSection\"]"); // @FindBy(xpath = BW_MONTHLY_BILLING_SECTION + PAYMENT_SCHEDULE_SECTION)
    this.continueButton = page.locator("xpath=//input[@value='Continue']"); // @FindBy(xpath = "//input[@value='Continue']")
  }
}
