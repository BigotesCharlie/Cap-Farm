// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.legacy.ThankYouPage. */
export class ThankYouPage extends CoreBasePage {
  public readonly textQuoteNumber: Locator;
  public readonly textEstimatedPremium: Locator;
  public readonly pageTitle: Locator;
  public readonly selectCrossSellType: Locator;
  public readonly buttonStartSaving: Locator;
  public readonly learnMoreLink: Locator;

  public constructor(page: Page) {
    super(page);
    this.textQuoteNumber = page.locator("xpath=//div[@id='thank-you-page-container']//div/h2[contains(text(),'QUOTE NUMBER')]/../p"); // @FindBy(xpath = "//div[@id='thank-you-page-container']//div/h2[contains(text(),'QUOTE NUMBER')]/../p")
    this.textEstimatedPremium = page.locator("xpath=//div[@id='thank-you-page-container']//div/h2[contains(text(), 'ESTIMATED')]/../span"); // @FindBy(xpath = "//div[@id='thank-you-page-container']//div/h2[contains(text(), 'ESTIMATED')]/../span")
    this.pageTitle = page.locator("xpath=//farmers-home-quote-thank-you//h1"); // @FindBy(xpath = "//farmers-home-quote-thank-you//h1")
    this.selectCrossSellType = page.locator("xpath=//div[@id='thank-you-footer']//mat-select"); // @FindBy(xpath = "//div[@id='thank-you-footer']//mat-select")
    this.buttonStartSaving = page.locator("[data-legacy-field=\"buttonStartSaving\"]"); // @FindBy(xpath = START_SAVING_BUTTON_XPATH)
    this.learnMoreLink = page.locator("xpath=//a[@data-gtm='FFQ_Auto_Signal_Discount_Learn_More_Link']"); // @FindBy(xpath = "//a[@data-gtm='FFQ_Auto_Signal_Discount_Learn_More_Link']")
  }
}
