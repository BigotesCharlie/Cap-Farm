// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.legacy.AdditionalInformationPage. */
export class AdditionalInformationPage extends CoreBasePage {
  public readonly additionalInformationPageHeader: Locator;
  public readonly vehicleList: Locator;
  public readonly driverList: Locator;
  public readonly continueToPaymentButton: Locator;
  public readonly bwContinueToPaymentButton: Locator;
  public readonly generatingPremiumPopUpWindow: Locator;
  public readonly generatingPremiumPopUpMessage: Locator;
  public readonly residencyCountyDropdownList: Locator;
  public readonly continueToAdditionalInfoButton: Locator;
  public readonly signalMobilePhoneNumber: Locator;
  public readonly agreeToSignalTerms: Locator;
  public readonly bwInfoPopup: Locator;
  public readonly bwInfoPopupNoButton: Locator;
  public readonly bwInfoPopupYesButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.additionalInformationPageHeader = page.locator("#additionalInfo:AdditionalInformation"); // @FindBy(id = "additionalInfo:AdditionalInformation")
    this.vehicleList = page.locator("#additionalInfo:vehInfo"); // @FindBy(id = "additionalInfo:vehInfo")
    this.driverList = page.locator("#additionalInfo:drvInfo"); // @FindBy(id = "additionalInfo:drvInfo")
    this.continueToPaymentButton = page.locator("[data-legacy-field=\"continueToPaymentButton\"]"); // @FindBy(xpath = CONTINUE_TO_PAYMENT_BUTTON_XPATH)
    this.bwContinueToPaymentButton = page.locator("#additionalDrv:continue"); // @FindBy(id = "additionalDrv:continue")
    this.generatingPremiumPopUpWindow = page.locator("xpath=//*[@id='RegisterMyFarmers']"); // @FindBy(xpath = "//*[@id='RegisterMyFarmers']")
    this.generatingPremiumPopUpMessage = page.locator("xpath=//*[@id='RegisterMyFarmers']/div/p"); // @FindBy(xpath = "//*[@id='RegisterMyFarmers']/div/p")
    this.residencyCountyDropdownList = page.locator("#additionalInfo:countyCity"); // @FindBy(id = "additionalInfo:countyCity")
    this.continueToAdditionalInfoButton = page.locator("[data-legacy-field=\"continueToAdditionalInfoButton\"]"); // @FindBy(xpath = CONTINUE_TO_ADDITIONAL_INFO_BUTTON_XPATH)
    this.signalMobilePhoneNumber = page.locator("#additionalInfo:signalInfo:0:signalMobNum"); // @FindBy(id = "additionalInfo:signalInfo:0:signalMobNum")
    this.agreeToSignalTerms = page.locator("#additionalInfo:termsChk"); // @FindBy(id = "additionalInfo:termsChk")
    this.bwInfoPopup = page.locator("#BwPopup"); // @FindBy(id = "BwPopup")
    this.bwInfoPopupNoButton = page.locator("xpath=//button[@id='btnClose' and @title='No']"); // @FindBy(xpath = "//button[@id='btnClose' and @title='No']")
    this.bwInfoPopupYesButton = page.locator("xpath=//button[@id='btnClose' and @title='Yes']"); // @FindBy(xpath = "//button[@id='btnClose' and @title='Yes']")
  }
}
