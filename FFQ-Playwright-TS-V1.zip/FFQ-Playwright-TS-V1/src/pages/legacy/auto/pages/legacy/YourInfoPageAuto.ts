// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.legacy.YourInfoPageAuto. */
export class YourInfoPageAuto extends CoreBasePage {
  public readonly yourInfoPageHeader: Locator;
  public readonly yourInfoPageSubtitle: Locator;
  public readonly yourInfoPageSaveTime: Locator;
  public readonly yourInfoPageNeverSellInfo: Locator;
  public readonly nameAndDOBSectionLabel: Locator;
  public readonly firstNameEntryField: Locator;
  public readonly firstNameErrorMessage: Locator;
  public readonly lastNameEntryField: Locator;
  public readonly lastNameErrorMessage: Locator;
  public readonly dobEntryField: Locator;
  public readonly dobErrorMessage: Locator;
  public readonly addressSectionLabel: Locator;
  public readonly addressFAQButton: Locator;
  public readonly addressEntryField: Locator;
  public readonly addressErrorMessage: Locator;
  public readonly addressFAQTitle: Locator;
  public readonly addressFAQContent: Locator;
  public readonly apartmentEntryField: Locator;
  public readonly cityEntryField: Locator;
  public readonly cityEntryFieldErrorMessage: Locator;
  public readonly citySelectField: Locator;
  public readonly citySelectErrorMessage: Locator;
  public readonly townSelectField: Locator;
  public readonly zipCodeEntryField: Locator;
  public readonly stateCodeEntryField: Locator;
  public readonly currentlyInsuredRadioButton: Locator;
  public readonly currentlyInsuredRadioButtonLabel: Locator;
  public readonly notCurrentlyInsuredRadioButton: Locator;
  public readonly notCurrentlyInsuredRadioButtonLabel: Locator;
  public readonly nextPageButton: Locator;
  public readonly workGroupSavingsText: Locator;
  public readonly qualifyingText: Locator;
  public readonly yourInfoEmployerGroupDropdown: Locator;
  public readonly quoteWithFarmersOnlineDesktopLink: Locator;
  public readonly quoteWithFarmersOnlineMobileLink: Locator;
  public readonly yourInfoPageDisclaimer: Locator;
  public readonly yourInfoPageAlternateStateDisclaimer: Locator;
  public readonly yipAdditionalDisclaimer: Locator;
  public readonly contactUsLink: Locator;
  public readonly termsOfUseLink: Locator;
  public readonly privacyPolicyLink: Locator;
  public readonly noticeOfInformationPracticesLink: Locator;
  public readonly personalInfoUseLink: Locator;
  public readonly bottomOfYourInfoPageAuto: Locator;
  public readonly txtQuoteNumber: Locator;
  public readonly assignedAgentName: Locator;
  public readonly subscriptionAgreementCheckbox: Locator;
  public readonly continueButton: Locator;
  public readonly closeContinueDialogButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.yourInfoPageHeader = page.locator("#auto-module_header-title"); // @FindBy(id = "auto-module_header-title")
    this.yourInfoPageSubtitle = page.locator("xpath=//div[contains(@class, 'auto-module__discount-journey-text')]"); // @FindBy(xpath = "//div[contains(@class, 'auto-module__discount-journey-text')]")
    this.yourInfoPageSaveTime = page.locator("xpath=//div[contains(@class, 'auto-module__discount-journey-card')]/div[2]"); // @FindBy(xpath = "//div[contains(@class, 'auto-module__discount-journey-card')]/div[2]")
    this.yourInfoPageNeverSellInfo = page.locator("xpath=//div[contains(@class, 'auto-module__discount-journey-card')]/div[3]"); // @FindBy(xpath = "//div[contains(@class, 'auto-module__discount-journey-card')]/div[3]")
    this.nameAndDOBSectionLabel = page.locator("xpath=//div[@class='auto-module__your-info-card-detail-text-message-header' and contains(text(), 'Name')]"); // @FindBy(xpath = "//div[@class='auto-module__your-info-card-detail-text-message-header' and contains(text(), 'Name')]")
    this.firstNameEntryField = page.locator("xpath=//div[@id='auto-module__your-info-card-input-fname']/lib-input-text/mat-form-field/div/div/div/input"); // @FindBy(xpath = "//div[@id='auto-module__your-info-card-input-fname']/lib-input-text/mat-form-field/div/div/div/input")
    this.firstNameErrorMessage = page.locator("xpath=//div[@id='auto-module__your-info-card-input-fname']/lib-input-text/mat-form-field/div/div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error"); // @FindBy(xpath = "//div[@id='auto-module__your-info-card-input-fname']/lib-input-text/mat-form-field/div/div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
    this.lastNameEntryField = page.locator("xpath=//div[@id='auto-module__your-info-card-input-lname']/lib-input-text/mat-form-field/div/div/div/input"); // @FindBy(xpath = "//div[@id='auto-module__your-info-card-input-lname']/lib-input-text/mat-form-field/div/div/div/input")
    this.lastNameErrorMessage = page.locator("xpath=//div[@id='auto-module__your-info-card-input-lname']/lib-input-text/mat-form-field/div/div/div/mat-error"); // @FindBy(xpath = "//div[@id='auto-module__your-info-card-input-lname']/lib-input-text/mat-form-field/div/div/div/mat-error")
    this.dobEntryField = page.locator("xpath=//lib-date-picker/mat-form-field/div/div/div/input[@data-gtm]"); // @FindBy(xpath = "//lib-date-picker/mat-form-field/div/div/div/input[@data-gtm]")
    this.dobErrorMessage = page.locator("[data-legacy-field=\"dobErrorMessage\"]"); // @FindBy(xpath = DOB_ERROR_MESSAGE_XPATH)
    this.addressSectionLabel = page.locator("#auto-module__your-info-card-detail-residential-address-header"); // @FindBy(id = "auto-module__your-info-card-detail-residential-address-header")
    this.addressFAQButton = page.locator(".info-icon"); // @FindBy(className = "info-icon")
    this.addressEntryField = page.locator("xpath=//div[@id='auto-module__your-info-card-input-address']//input"); // @FindBy(xpath = "//div[@id='auto-module__your-info-card-input-address']//input")
    this.addressErrorMessage = page.locator("xpath=//div[@id='auto-module__your-info-card-input-address']//mat-error"); // @FindBy(xpath = "//div[@id='auto-module__your-info-card-input-address']//mat-error")
    this.addressFAQTitle = page.locator("xpath=//div[@class='cdk-overlay-container']/div[@class='cdk-global-overlay-wrapper']/div[@class='cdk-overlay-pane ffq-info-dialog']/mat-dialog-container/lib-info-dialog/div"); // @FindBy(xpath = "//div[@class='cdk-overlay-container']/div[@class='cdk-global-overlay-wrapper']/div[@class='cdk-overlay-pane ffq-info-dialog']/mat-dialog-container/lib-info-dialog/div")
    this.addressFAQContent = page.locator("xpath=//div[@class='cdk-overlay-container']/div[@class='cdk-global-overlay-wrapper']/div[@class='cdk-overlay-pane ffq-info-dialog']/mat-dialog-container/lib-info-dialog/div[@class='dialog_info-dialog-content']"); // @FindBy(xpath = "//div[@class='cdk-overlay-container']/div[@class='cdk-global-overlay-wrapper']/div[@class='cdk-overlay-pane ffq-info-dialog']/mat-dialog-container/lib-info-dialog/div[@class='dialog_info-dialog-content']")
    this.apartmentEntryField = page.locator("xpath=//div[@id='auto-module__your-info-card-input-apt']/lib-input-text/mat-form-field/div/div/div/input"); // @FindBy(xpath = "//div[@id='auto-module__your-info-card-input-apt']/lib-input-text/mat-form-field/div/div/div/input")
    this.cityEntryField = page.locator("xpath=//div[@id='auto-module__your-info-card-input-city']/lib-input-text/mat-form-field/div/div/div/input"); // @FindBy(xpath = "//div[@id='auto-module__your-info-card-input-city']/lib-input-text/mat-form-field/div/div/div/input")
    this.cityEntryFieldErrorMessage = page.locator("xpath=//div[@id='auto-module__your-info-card-input-city']/lib-input-text/mat-form-field/div/div/div/mat-error"); // @FindBy(xpath = "//div[@id='auto-module__your-info-card-input-city']/lib-input-text/mat-form-field/div/div/div/mat-error")
    this.citySelectField = page.locator("xpath=//div[@id='auto-module__your-info-card-select-city']/lib-select/mat-form-field/div/div/div/mat-select"); // @FindBy(xpath = "//div[@id='auto-module__your-info-card-select-city']/lib-select/mat-form-field/div/div/div/mat-select")
    this.citySelectErrorMessage = page.locator("xpath=//div[@id='auto-module__your-info-card-select-city']/lib-select/mat-form-field/div/div/div/mat-error"); // @FindBy(xpath = "//div[@id='auto-module__your-info-card-select-city']/lib-select/mat-form-field/div/div/div/mat-error")
    this.townSelectField = page.locator("[data-legacy-field=\"townSelectField\"]"); // @FindBy(xpath = TOWN_DROPDOWN_XPATH)
    this.zipCodeEntryField = page.locator("xpath=//div[@id='auto-module__your-info-card-input-zip']/lib-input-text/mat-form-field/div/div/div/input"); // @FindBy(xpath = "//div[@id='auto-module__your-info-card-input-zip']/lib-input-text/mat-form-field/div/div/div/input")
    this.stateCodeEntryField = page.locator("xpath=//div[@id='auto-module__your-info-card-input-state']/lib-input-text/mat-form-field/div/div/div/input"); // @FindBy(xpath = "//div[@id='auto-module__your-info-card-input-state']/lib-input-text/mat-form-field/div/div/div/input")
    this.currentlyInsuredRadioButton = page.locator("[data-legacy-field=\"currentlyInsuredRadioButton\"]"); // @FindBy(xpath = CURRENTLY_INSURED_RADIO_BUTTON_XPATH)
    this.currentlyInsuredRadioButtonLabel = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Yourinfo_haveins_yes_radio']"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Yourinfo_haveins_yes_radio']")
    this.notCurrentlyInsuredRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Yourinfo_haveins_no_radio']/label/div"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Yourinfo_haveins_no_radio']/label/div")
    this.notCurrentlyInsuredRadioButtonLabel = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Yourinfo_haveins_no_radio']"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Yourinfo_haveins_no_radio']")
    this.nextPageButton = page.locator("[data-legacy-field=\"nextPageButton\"]"); // @FindBy(xpath = YIP_NEXT_BUTTON_XPATH)
    this.workGroupSavingsText = page.locator("xpath=//div[contains(@class, 'auto-module__your-info-card')]/div[@class='auto-module__your-info-employer-box']/div[@class='auto-module__your-info-card-detail-text-employer-header']"); // @FindBy(xpath = "//div[contains(@class, 'auto-module__your-info-card')]/div[@class='auto-module__your-info-employer-box']/div[@class='auto-module__your-info-card-detail-text-employer-header']")
    this.qualifyingText = page.locator("xpath=//div[contains(@class, 'auto-module__your-info-card')]/div[@class='auto-module__your-info-employer-box']/div[@class='auto-module__your-info-card-detail-text-employer-subheader']"); // @FindBy(xpath = "//div[contains(@class, 'auto-module__your-info-card')]/div[@class='auto-module__your-info-employer-box']/div[@class='auto-module__your-info-card-detail-text-employer-subheader']")
    this.yourInfoEmployerGroupDropdown = page.locator("[data-legacy-field=\"yourInfoEmployerGroupDropdown\"]"); // @FindBy(id = EMPLOYER_GROUP_ID)
    this.quoteWithFarmersOnlineDesktopLink = page.locator("xpath=//a[@data-gtm='Farmers_COLPGS_FFQLINK_Header' and contains(@class, 'button-cta--desktop')]"); // @FindBy(xpath = "//a[@data-gtm='Farmers_COLPGS_FFQLINK_Header' and contains(@class, 'button-cta--desktop')]")
    this.quoteWithFarmersOnlineMobileLink = page.locator("xpath=//a[@data-gtm='Farmers_COLPGS_FFQLINK_Header' and contains(@class, 'button-cta--mobile')]"); // @FindBy(xpath = "//a[@data-gtm='Farmers_COLPGS_FFQLINK_Header' and contains(@class, 'button-cta--mobile')]")
    this.yourInfoPageDisclaimer = page.locator("xpath=//div[@class='auto-module__your-info-card-text-disclaimer']"); // @FindBy(xpath = "//div[@class='auto-module__your-info-card-text-disclaimer']")
    this.yourInfoPageAlternateStateDisclaimer = page.locator("xpath=//div[@class='auto-module__your-info-card-text-disclaimer']//p[contains(@class, 'p_disclaimer_text')]"); // @FindBy(xpath = "//div[@class='auto-module__your-info-card-text-disclaimer']//p[contains(@class, 'p_disclaimer_text')]")
    this.yipAdditionalDisclaimer = page.locator("xpath=//div[@class='auto-module__your-info-card-text-disclaimer']/p[2]"); // @FindBy(xpath = "//div[@class='auto-module__your-info-card-text-disclaimer']/p[2]")
    this.contactUsLink = page.locator("xpath=//a[@data-gtm='FFQ_Auto_sidepanel_contactus_link']"); // @FindBy(xpath = "//a[@data-gtm='FFQ_Auto_sidepanel_contactus_link']")
    this.termsOfUseLink = page.locator("xpath=//a[@data-gtm='FFQ_Auto_sidepanel_termsofuse_link']"); // @FindBy(xpath = "//a[@data-gtm='FFQ_Auto_sidepanel_termsofuse_link']")
    this.privacyPolicyLink = page.locator("xpath=//a[@data-gtm='FFQ_Auto_sidepanel_privacypolicy_link']"); // @FindBy(xpath = "//a[@data-gtm='FFQ_Auto_sidepanel_privacypolicy_link']")
    this.noticeOfInformationPracticesLink = page.locator("xpath=//a[@data-gtm='FFQ_Auto_sidepanel_noticeinfoprac_link']"); // @FindBy(xpath = "//a[@data-gtm='FFQ_Auto_sidepanel_noticeinfoprac_link']")
    this.personalInfoUseLink = page.getByRole('link', { name: "Personal information use", exact: true }); // @FindBy(linkText = "Personal information use")
    this.bottomOfYourInfoPageAuto = page.locator("#auto-module__your-info-next-buttton-holder"); // @FindBy(id = "auto-module__your-info-next-buttton-holder")
    this.txtQuoteNumber = page.locator("xpath=//mat-sidenav//div[starts-with(text(), ' Auto Quote ')]"); // @FindBy(xpath = "//mat-sidenav//div[starts-with(text(), ' Auto Quote ')]")
    this.assignedAgentName = page.locator(".agent-detail-name"); // @FindBy(className = "agent-detail-name")
    this.subscriptionAgreementCheckbox = page.locator("#mat-checkbox-1"); // @FindBy(id = "mat-checkbox-1")
    this.continueButton = page.locator(".btn-confirm"); // @FindBy(className = "btn-confirm")
    this.closeContinueDialogButton = page.locator("xpath=//button[@data-gtm='FFQ_Auto_savefinishmodal_Contquote_button']"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_savefinishmodal_Contquote_button']")
  }
}
