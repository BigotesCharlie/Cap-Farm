// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.legacy.DriversPage. */
export class DriversPage extends CoreBasePage {
  public readonly driversPageHeader: Locator;
  public readonly disabledAddDriverLink: Locator;
  public readonly addSpouseDriverLink: Locator;
  public readonly addAdditionalDriverLink: Locator;
  public readonly checkSelectSpouseDriver: Locator;
  public readonly driverNotMarriedLink: Locator;
  public readonly maximumNumberOfDriversMessage: Locator;
  public readonly backButton: Locator;
  public readonly nextButton: Locator;
  public readonly buttonNext: Locator;
  public readonly closeAddDriverDetailsDialog: Locator;
  public readonly addDriverDetailsDialogHeader: Locator;
  public readonly saveDriverDetailsLink: Locator;
  public readonly closeDetailsConfirmationDialogContent: Locator;
  public readonly closeConfirmationDialogContinueButton: Locator;
  public readonly closeConfirmationDialogCloseButton: Locator;
  public readonly maritalStatusFAQLink: Locator;
  public readonly marriedRadioButton: Locator;
  public readonly notMarriedRadioButton: Locator;
  public readonly additionalDriverMaritalStatusFAQLink: Locator;
  public readonly additionalDriverMarriedRadioButton: Locator;
  public readonly additionalDriverNotMarriedRadioButton: Locator;
  public readonly maritalStatusDropdown: Locator;
  public readonly maritalStatusDropdownErrorMessage: Locator;
  public readonly maritalStatusRadioButtonsErrorMessage: Locator;
  public readonly occupationEntryField: Locator;
  public readonly occupationOption: Locator;
  public readonly activeMilitaryDutyStationedInStateFAQLink: Locator;
  public readonly activeMilitaryDutyStationedInStateRadioButton: Locator;
  public readonly notActiveMilitaryDutyStationedInStateRadioButton: Locator;
  public readonly currentlyInsuredRadioButton: Locator;
  public readonly currentlyInsuredFAQLink: Locator;
  public readonly insuranceExpiredRadioButton: Locator;
  public readonly priorInsuranceFAQLink: Locator;
  public readonly neverInsuredRadioButton: Locator;
  public readonly deployedRadioButton: Locator;
  public readonly notRequiredRadioButton: Locator;
  public readonly notOwnAVehicleRadioButton: Locator;
  public readonly had6MonthCoverageInPastRadioButton: Locator;
  public readonly deploymentReasonForNoInsuranceRadioButton: Locator;
  public readonly otherRadioButton: Locator;
  public readonly currentlyInsuredStatusErrorMessage: Locator;
  public readonly currentAutoInsuranceCompanyEntryField: Locator;
  public readonly priorAutoInsuranceCompanyEntryField: Locator;
  public readonly insuranceCompanyOption: Locator;
  public readonly continuousCoverageLengthFAQLink: Locator;
  public readonly continuousCoverageLengthDropDown: Locator;
  public readonly yesSixMonthsRadioButton: Locator;
  public readonly noSixMonthsRadioButton: Locator;
  public readonly bodilyInjuryLimitsFAQLink: Locator;
  public readonly bodilyInjuryLimitsDropDown: Locator;
  public readonly policyExpirationDateFAQLink: Locator;
  public readonly policyExpirationDateEntryField: Locator;
  public readonly policyExpirationDateErrorMessage: Locator;
  public readonly spouseLicensedToDriveInUSLabel: Locator;
  public readonly spouseLicensedinUSADropdown: Locator;
  public readonly spouseLicensedToDriveRadioButton: Locator;
  public readonly spouseNotLicensedToDriveRadioButton: Locator;
  public readonly spouseLivesAwayRadioButton: Locator;
  public readonly ageFirstLicensedFAQLink: Locator;
  public readonly ageAdditionalDriverFirstLicensedFAQLink: Locator;
  public readonly ageFirstLicensedEntryField: Locator;
  public readonly ageFirstLicensedErrorMessage: Locator;
  public readonly licenseIssuedInForeignCountryCheckbox: Locator;
  public readonly licenseIssuedByUSStateFAQLink: Locator;
  public readonly licensedByUSStateRadioButton: Locator;
  public readonly notLicensedByUSStateRadioButton: Locator;
  public readonly driversLicenseFAQLink: Locator;
  public readonly driversLicenseEntryField: Locator;
  public readonly driversLicenseIssueStateDropdown: Locator;
  public readonly spouseActiveMilitaryDutyStationedInStateRadioButton: Locator;
  public readonly spouseNotActiveMilitaryDutyStationedInStateRadioButton: Locator;
  public readonly accidentsInLastYearsHeader: Locator;
  public readonly accidentsInLastYearsRadioButton: Locator;
  public readonly noAccidentsInLastYearsRadioButton: Locator;
  public readonly accidentsOrViolationsErrorMessage: Locator;
  public readonly incident1SectionHeader: Locator;
  public readonly removeIncident1Link: Locator;
  public readonly incident2SectionHeader: Locator;
  public readonly removeIncident2Link: Locator;
  public readonly doNotRemoveIncidentButton: Locator;
  public readonly confirmRemoveIncidentButton: Locator;
  public readonly accidentRadioButton: Locator;
  public readonly citationRadioButton: Locator;
  public readonly incidentTypeErrorMessage: Locator;
  public readonly incidentDescriptionDropdown: Locator;
  public readonly incidentDescriptionErrorMessage: Locator;
  public readonly incidentDateEntryField: Locator;
  public readonly incidentDateErrorMessage: Locator;
  public readonly injuriesRadioButton: Locator;
  public readonly noInjuriesRadioButton: Locator;
  public readonly addAnotherIncidentButton: Locator;
  public readonly fullTimeStudentSectionLabel: Locator;
  public readonly fullTimeStudentWithGPARadioButton: Locator;
  public readonly notFullTimeStudentWithGPARadioButton: Locator;
  public readonly attendingDistantSchoolRadioButton: Locator;
  public readonly notAttendingDistantSchoolRadioButton: Locator;
  public readonly financialResponsibilityFAQLink: Locator;
  public readonly noFinancialFilingRadioButton: Locator;
  public readonly sr22RadioButton: Locator;
  public readonly fr22RadioButton: Locator;
  public readonly financialFilingErrorMessage: Locator;
  public readonly personalInjuryFAQLink: Locator;
  public readonly personalInjuryRadioButton: Locator;
  public readonly noPersonalInjuryRadioButton: Locator;
  public readonly principalPIPFAQLink: Locator;
  public readonly principalPIPDropdown: Locator;
  public readonly principalPIPErrorMessage: Locator;
  public readonly safetyCourseFAQLink: Locator;
  public readonly safetyCourseCompletedRadioButton: Locator;
  public readonly noSafetyCourseCompletedRadioButton: Locator;
  public readonly safetyCourseCompletedErrorMessage: Locator;
  public readonly safetyCourseCompletedateEntryField: Locator;
  public readonly commutersFAQLink: Locator;
  public readonly commutersToOtherStateRadioButton: Locator;
  public readonly noCommutersToOtherStateRadioButton: Locator;
  public readonly commutersErrorMessage: Locator;
  public readonly addAdditionalDriverDetailsDialogHeader: Locator;
  public readonly saveAdditionalDriverDetailsLink: Locator;
  public readonly firstNameADEntryField: Locator;
  public readonly firstNameADErrorMessage: Locator;
  public readonly lastNameADEntryField: Locator;
  public readonly lastNameADErrorMessage: Locator;
  public readonly dobADEntryField: Locator;
  public readonly dobADErrorMessage: Locator;
  public readonly relationshipToApplicantDropdown: Locator;
  public readonly relationshipToApplicantErrorMessage: Locator;
  public readonly genderSectionLabel: Locator;
  public readonly maleRadioButton: Locator;
  public readonly maleRadioButtonInternal: Locator;
  public readonly femaleRadioButton: Locator;
  public readonly femaleRadioButtonInternal: Locator;
  public readonly genderNotSpecifiedRadioButton: Locator;
  public readonly nonbinaryRadioButton: Locator;
  public readonly intersexRadioButton: Locator;
  public readonly genderErrorMessage: Locator;
  public readonly emailEntryField: Locator;
  public readonly emailEntryFieldErrorMessage: Locator;
  public readonly phoneNumberEntryField: Locator;
  public readonly phoneNumberEntryFieldErrorMessage: Locator;
  public readonly differentMailingAddressCheckbox: Locator;
  public readonly mailingAddressEntryField: Locator;
  public readonly mailingAddressErrorMessage: Locator;
  public readonly mailingCityEntryField: Locator;
  public readonly mailingCityErrorMessage: Locator;
  public readonly mailingStateDropdown: Locator;
  public readonly mailingStateErrorMessage: Locator;
  public readonly mailingZipEntryField: Locator;
  public readonly mailingZipErrorMessage: Locator;
  public readonly additionalDetailsBackButton: Locator;
  public readonly additionalDetailsNextButton: Locator;
  public readonly additionalDetailsDisclaimer: Locator;
  public readonly consentSelectionDisclaimerTextElement: Locator;
  public readonly pewcDisclaimerTextElement: Locator;
  public readonly rideshareTitle: Locator;
  public readonly rideshareDescription: Locator;
  public readonly vehiclesUsedForRideshareRadioButton: Locator;
  public readonly vehiclesUsedForRideshareGTMElement: Locator;
  public readonly vehiclesNotUsedForRideshareRadioButton: Locator;
  public readonly vehiclesNotUsedForRideshareGTMElement: Locator;
  public readonly vehicleToDriversAssignmentDescription: Locator;
  public readonly vehicleToDriversAssignmentErrorMessage: Locator;
  public readonly driverWhoUsesVehicleMostRadioButton: Locator;
  public readonly agreeDriverUsesMostAndNextButton: Locator;
  public readonly confirmDeleteIncident: Locator;
  public readonly vehicleToDriversAssignmentBackButton: Locator;
  public readonly vehicleToDriversAssignmentNextButton: Locator;
  public readonly radioMarriedYes: Locator;
  public readonly radioMarriedNo: Locator;

  public constructor(page: Page) {
    super(page);
    this.driversPageHeader = page.locator(".ffq-main-title"); // @FindBy(className = "ffq-main-title")
    this.disabledAddDriverLink = page.locator(".auto__driver__add-new-disabled"); // @FindBy(className = "auto__driver__add-new-disabled")
    this.addSpouseDriverLink = page.locator("xpath=//*[@data-gtm='FFQ_Auto_Driver_addspouse_button']"); // @FindBy(xpath = "//*[@data-gtm='FFQ_Auto_Driver_addspouse_button']")
    this.addAdditionalDriverLink = page.locator("xpath=//*[@data-gtm='FFQ_Auto_Driver_addadriver_button']"); // @FindBy(xpath = "//*[@data-gtm='FFQ_Auto_Driver_addadriver_button']")
    this.checkSelectSpouseDriver = page.locator("xpath=//*[@data-gtm='FFQ_Auto_Driver_selectSpouse_checkbox']"); // @FindBy(xpath = "//*[@data-gtm='FFQ_Auto_Driver_selectSpouse_checkbox']")
    this.driverNotMarriedLink = page.locator("xpath=//*[@data-gtm='FFQ_Auto_Driver_notmarried_button']"); // @FindBy(xpath = "//*[@data-gtm='FFQ_Auto_Driver_notmarried_button']")
    this.maximumNumberOfDriversMessage = page.locator("xpath=//span[contains(@class,'max-driver-info-text')]"); // @FindBy(xpath = "//span[contains(@class,'max-driver-info-text')]")
    this.backButton = page.locator("xpath=//button[@data-gtm='FFQ_Auto_Driversummary_back_button']"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_Driversummary_back_button']")
    this.nextButton = page.locator("xpath=//button[@data-gtm='FFQ_Auto_Driversummary_next_button']"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_Driversummary_next_button']")
    this.buttonNext = page.locator("[data-legacy-field=\"buttonNext\"]"); // @FindBy(xpath = NEXT_BUTTON_XPATH)
    this.closeAddDriverDetailsDialog = page.locator("[data-legacy-field=\"closeAddDriverDetailsDialog\"]"); // @FindBy(xpath = CLOSE_DIALOG_XPATH)
    this.addDriverDetailsDialogHeader = page.locator(".auto-module__add-driver-header-text"); // @FindBy(className = "auto-module__add-driver-header-text")
    this.saveDriverDetailsLink = page.locator("xpath=//button[contains(@class, 'auto-module__add-driver-save-button')]"); // @FindBy(xpath = "//button[contains(@class, 'auto-module__add-driver-save-button')]")
    this.closeDetailsConfirmationDialogContent = page.locator("#infoDialog"); // @FindBy(id = "infoDialog")
    this.closeConfirmationDialogContinueButton = page.locator("xpath=//mat-dialog-actions/button/span[text()='No, continue'] | //mat-dialog-actions/button/span[text()='NO, CONTINUE']"); // @FindBy(xpath = "//mat-dialog-actions/button/span[text()='No, continue'] | //mat-dialog-actions/button/span[text()='NO, CONTINUE']")
    this.closeConfirmationDialogCloseButton = page.locator("xpath=//mat-dialog-actions/button/span[text()='Yes, navigate away'] | //mat-dialog-actions/button/span[text()='YES, NAVIGATE AWAY']"); // @FindBy(xpath = "//mat-dialog-actions/button/span[text()='Yes, navigate away'] | //mat-dialog-actions/button/span[text()='YES, NAVIGATE AWAY']")
    this.maritalStatusFAQLink = page.locator("xpath=//div[contains(text(), 'Are you married')]/a"); // @FindBy(xpath = "//div[contains(text(), 'Are you married')]/a")
    this.marriedRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_MaritalStatus_yes_radio']/label/div"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_MaritalStatus_yes_radio']/label/div")
    this.notMarriedRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_MaritalStatus_no_radio']/label/div"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_MaritalStatus_no_radio']/label/div")
    this.additionalDriverMaritalStatusFAQLink = page.locator("xpath=//div[contains(text(), 'Is this driver married')]/a"); // @FindBy(xpath = "//div[contains(text(), 'Is this driver married')]/a")
    this.additionalDriverMarriedRadioButton = page.locator("xpath=//div[contains(text(), 'Is this driver married')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]"); // @FindBy(xpath = "//div[contains(text(), 'Is this driver married')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]")
    this.additionalDriverNotMarriedRadioButton = page.locator("xpath=//div[contains(text(), 'Is this driver married')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]"); // @FindBy(xpath = "//div[contains(text(), 'Is this driver married')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]")
    this.maritalStatusDropdown = page.locator("xpath=//span/label/mat-label[text()='Marital status']/../../../mat-select"); // @FindBy(xpath = "//span/label/mat-label[text()='Marital status']/../../../mat-select")
    this.maritalStatusDropdownErrorMessage = page.locator("xpath=//div[@class='auto-module__add-driver-input-text']/lib-select/mat-form-field/div/div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error"); // @FindBy(xpath = "//div[@class='auto-module__add-driver-input-text']/lib-select/mat-form-field/div/div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
    this.maritalStatusRadioButtonsErrorMessage = page.locator("xpath=//div[@class='auto-module__add-driver-input-text']/lib-radio-button/div[@id='opt_maritalStatus']/mat-error"); // @FindBy(xpath = "//div[@class='auto-module__add-driver-input-text']/lib-radio-button/div[@id='opt_maritalStatus']/mat-error")
    this.occupationEntryField = page.locator("[data-legacy-field=\"occupationEntryField\"]"); // @FindBy(xpath = OCCUPATION_ENTRY_FIELD_XPATH)
    this.occupationOption = page.locator("[data-legacy-field=\"occupationOption\"]"); // @FindBy(xpath = OCCUPATION_XPATH)
    this.activeMilitaryDutyStationedInStateFAQLink = page.locator("xpath=//div[contains(text(), 'active military duty stationed')]/a"); // @FindBy(xpath = "//div[contains(text(), 'active military duty stationed')]/a")
    this.activeMilitaryDutyStationedInStateRadioButton = page.locator("xpath=//mat-radio-button[contains(@data-gtm,'FFQ_Auto_driver_activemilitary_yes_radio')]//input"); // @FindBy(xpath = "//mat-radio-button[contains(@data-gtm,'FFQ_Auto_driver_activemilitary_yes_radio')]//input")
    this.notActiveMilitaryDutyStationedInStateRadioButton = page.locator("xpath=//mat-radio-button[contains(@data-gtm,'FFQ_Auto_driver_activemilitary_No_radio')]//input"); // @FindBy(xpath = "//mat-radio-button[contains(@data-gtm,'FFQ_Auto_driver_activemilitary_No_radio')]//input")
    this.currentlyInsuredRadioButton = page.locator("[data-legacy-field=\"currentlyInsuredRadioButton\"]"); // @FindBy(xpath = CURRENTLY_INSURED_XPATH)
    this.currentlyInsuredFAQLink = page.locator("xpath=//a[contains(@aria-label, 'Current Auto Insurance Company')]"); // @FindBy(xpath = "//a[contains(@aria-label, 'Current Auto Insurance Company')]")
    this.insuranceExpiredRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'insurance expired')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'insurance expired')]")
    this.priorInsuranceFAQLink = page.locator("xpath=//a[contains(@aria-label, 'Prior auto insurance company')]"); // @FindBy(xpath = "//a[contains(@aria-label, 'Prior auto insurance company')]")
    this.neverInsuredRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'never had insurance')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'never had insurance')]")
    this.deployedRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'deployed or overseas')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'deployed or overseas')]")
    this.notRequiredRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'not required')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'not required')]")
    this.notOwnAVehicleRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'not own a vehicle')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'not own a vehicle')]")
    this.had6MonthCoverageInPastRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_6Mconticoverage_yes_radio']/label/div[contains(text(), 'Yes')]"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_6Mconticoverage_yes_radio']/label/div[contains(text(), 'Yes')]")
    this.deploymentReasonForNoInsuranceRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_militarydepreason_yes_radio']/label/div[contains(text(), 'Yes')]"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_militarydepreason_yes_radio']/label/div[contains(text(), 'Yes')]")
    this.otherRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'Other')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Other')]")
    this.currentlyInsuredStatusErrorMessage = page.locator("xpath=//div[contains(text(), 'Are you currently')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-error"); // @FindBy(xpath = "//div[contains(text(), 'Are you currently')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-error")
    this.currentAutoInsuranceCompanyEntryField = page.locator("xpath=//div/span/label/mat-label[contains(text(), 'Current')]/../../../input"); // @FindBy(xpath = "//div/span/label/mat-label[contains(text(), 'Current')]/../../../input")
    this.priorAutoInsuranceCompanyEntryField = page.locator("xpath=//div/span/label/mat-label[contains(text(), 'Prior auto insurance')]/../../../input"); // @FindBy(xpath = "//div/span/label/mat-label[contains(text(), 'Prior auto insurance')]/../../../input")
    this.insuranceCompanyOption = page.locator("xpath=//mat-option[contains(@data-gtm, 'FFQ_Auto_Driver_company')]"); // @FindBy(xpath = "//mat-option[contains(@data-gtm, 'FFQ_Auto_Driver_company')]")
    this.continuousCoverageLengthFAQLink = page.locator("xpath=//a[contains(@aria-label, 'Insurance Coverage')]"); // @FindBy(xpath = "//a[contains(@aria-label, 'Insurance Coverage')]")
    this.continuousCoverageLengthDropDown = page.locator("xpath=//span/label/mat-label[contains(text(), 'Length of continuous')]/../../../mat-select"); // @FindBy(xpath = "//span/label/mat-label[contains(text(), 'Length of continuous')]/../../../mat-select")
    this.yesSixMonthsRadioButton = page.locator("[data-legacy-field=\"yesSixMonthsRadioButton\"]"); // @FindBy(xpath = SIX_MONTHS_COVERAGE_YES_XPATH)
    this.noSixMonthsRadioButton = page.locator("[data-legacy-field=\"noSixMonthsRadioButton\"]"); // @FindBy(xpath = SIX_MONTHS_COVERAGE_NO_XPATH)
    this.bodilyInjuryLimitsFAQLink = page.locator("xpath=//*[contains(text(), 'bodily injury limits')]/a"); // @FindBy(xpath = "//*[contains(text(), 'bodily injury limits')]/a")
    this.bodilyInjuryLimitsDropDown = page.locator("xpath=//span/label/mat-label[contains(text(), 'Bodily injury')]/../../../mat-select"); // @FindBy(xpath = "//span/label/mat-label[contains(text(), 'Bodily injury')]/../../../mat-select")
    this.policyExpirationDateFAQLink = page.locator("xpath=//a[contains(@aria-label, 'Policy Expiration')]"); // @FindBy(xpath = "//a[contains(@aria-label, 'Policy Expiration')]")
    this.policyExpirationDateEntryField = page.locator("xpath=//span/label/mat-label[text()='Policy expiration date']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='Policy expiration date']/../../../input")
    this.policyExpirationDateErrorMessage = page.locator("[data-legacy-field=\"policyExpirationDateErrorMessage\"]"); // @FindBy(xpath = POLICY_EXPIRATION_DATE_ERROR_MESSAGE_XPATH)
    this.spouseLicensedToDriveInUSLabel = page.locator("xpath=//div[contains(text(), 'Is your spouse licensed to drive')]"); // @FindBy(xpath = "//div[contains(text(), 'Is your spouse licensed to drive')]")
    this.spouseLicensedinUSADropdown = page.locator("[data-legacy-field=\"spouseLicensedinUSADropdown\"]"); // @FindBy(xpath = SPOUSE_LICENSED_IN_USA_DROPDOWN_XPATH)
    this.spouseLicensedToDriveRadioButton = page.locator("[data-legacy-field=\"spouseLicensedToDriveRadioButton\"]"); // @FindBy(xpath = SPOUSE_LICENSED_TO_DRIVE_XPATH)
    this.spouseNotLicensedToDriveRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_licensedtodrive_no']//input"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_licensedtodrive_no']//input")
    this.spouseLivesAwayRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_licensedtodrive_yesbutaway']//input"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_licensedtodrive_yesbutaway']//input")
    this.ageFirstLicensedFAQLink = page.locator("xpath=//*[contains(text(), 'Age you first')]/a"); // @FindBy(xpath = "//*[contains(text(), 'Age you first')]/a")
    this.ageAdditionalDriverFirstLicensedFAQLink = page.locator("xpath=//*[contains(text(), 'driver first received')]/a"); // @FindBy(xpath = "//*[contains(text(), 'driver first received')]/a")
    this.ageFirstLicensedEntryField = page.locator("xpath=//input[@data-gtm='FFQ_Auto_Driver_Licenseage_text']"); // @FindBy(xpath = "//input[@data-gtm='FFQ_Auto_Driver_Licenseage_text']")
    this.ageFirstLicensedErrorMessage = page.locator("xpath=//lib-input-text[@id='inputForAge']/mat-form-field/div/div[contains(@class,'mat-form-field-subscript-wrapper')]/div/mat-error"); // @FindBy(xpath = "//lib-input-text[@id='inputForAge']/mat-form-field/div/div[contains(@class,'mat-form-field-subscript-wrapper')]/div/mat-error")
    this.licenseIssuedInForeignCountryCheckbox = page.locator("xpath=//mat-checkbox/label/span/span[contains(text(), 'foreign country')]"); // @FindBy(xpath = "//mat-checkbox/label/span/span[contains(text(), 'foreign country')]")
    this.licenseIssuedByUSStateFAQLink = page.locator("xpath=//div[contains(text(), 'license issued by a')]/a"); // @FindBy(xpath = "//div[contains(text(), 'license issued by a')]/a")
    this.licensedByUSStateRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_LicenseCountryUS_Yes_radio']//input"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_LicenseCountryUS_Yes_radio']//input")
    this.notLicensedByUSStateRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_LicenseCountryUS_No_radio']//input"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_LicenseCountryUS_No_radio']//input")
    this.driversLicenseFAQLink = page.locator("xpath=//a[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicense_Ihelp_icon']"); // @FindBy(xpath = "//a[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicense_Ihelp_icon']")
    this.driversLicenseEntryField = page.locator("xpath=//input[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicense_text']"); // @FindBy(xpath = "//input[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicense_text']")
    this.driversLicenseIssueStateDropdown = page.locator("xpath=//mat-select[@aria-label='License issue state']"); // @FindBy(xpath = "//mat-select[@aria-label='License issue state']")
    this.spouseActiveMilitaryDutyStationedInStateRadioButton = page.locator("xpath=//mat-radio-button[contains(@data-gtm,'FFQ_Auto_driverspouse_activemilitary_yes_radio')]//input"); // @FindBy(xpath = "//mat-radio-button[contains(@data-gtm,'FFQ_Auto_driverspouse_activemilitary_yes_radio')]//input")
    this.spouseNotActiveMilitaryDutyStationedInStateRadioButton = page.locator("xpath=//mat-radio-button[contains(@data-gtm,'FFQ_Auto_driverspouse_activemilitary_No_radio')]//input"); // @FindBy(xpath = "//mat-radio-button[contains(@data-gtm,'FFQ_Auto_driverspouse_activemilitary_No_radio')]//input")
    this.accidentsInLastYearsHeader = page.locator("xpath=//div[contains(text(), 'accidents or violations')]"); // @FindBy(xpath = "//div[contains(text(), 'accidents or violations')]")
    this.accidentsInLastYearsRadioButton = page.locator("xpath=//div[contains(text(), 'accidents or violations')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]"); // @FindBy(xpath = "//div[contains(text(), 'accidents or violations')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]")
    this.noAccidentsInLastYearsRadioButton = page.locator("xpath=//div[contains(text(), 'accidents or violations')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]"); // @FindBy(xpath = "//div[contains(text(), 'accidents or violations')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]")
    this.accidentsOrViolationsErrorMessage = page.locator("xpath=//div[contains(text(), 'accidents or violations')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-error"); // @FindBy(xpath = "//div[contains(text(), 'accidents or violations')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-error")
    this.incident1SectionHeader = page.locator("xpath=//span/mat-panel-title[contains(text(), 'Incident 1')]"); // @FindBy(xpath = "//span/mat-panel-title[contains(text(), 'Incident 1')]")
    this.removeIncident1Link = page.locator("xpath=//mat-expansion-panel-header[@id='mat-expansion-panel-header-1']/span/mat-panel-description/a"); // @FindBy(xpath = "//mat-expansion-panel-header[@id='mat-expansion-panel-header-1']/span/mat-panel-description/a")
    this.incident2SectionHeader = page.locator("xpath=//span/mat-panel-title[contains(text(), 'Incident 2')]"); // @FindBy(xpath = "//span/mat-panel-title[contains(text(), 'Incident 2')]")
    this.removeIncident2Link = page.locator("xpath=//mat-expansion-panel-header[@id='mat-expansion-panel-header-2']/span/mat-panel-description/a"); // @FindBy(xpath = "//mat-expansion-panel-header[@id='mat-expansion-panel-header-2']/span/mat-panel-description/a")
    this.doNotRemoveIncidentButton = page.locator("xpath=//mat-dialog-actions/button[contains(text(), 'NO')]"); // @FindBy(xpath = "//mat-dialog-actions/button[contains(text(), 'NO')]")
    this.confirmRemoveIncidentButton = page.locator("xpath=//mat-dialog-actions/button[contains(text(), 'REMOVE IT')]"); // @FindBy(xpath = "//mat-dialog-actions/button[contains(text(), 'REMOVE IT')]")
    this.accidentRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'Accident')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Accident')]")
    this.citationRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'Citation')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Citation')]")
    this.incidentTypeErrorMessage = page.locator("xpath=//div[@id='opt_incidentType']//mat-error"); // @FindBy(xpath = "//div[@id='opt_incidentType']//mat-error")
    this.incidentDescriptionDropdown = page.locator("xpath=//span/label/mat-label[text()='Description']/../../../mat-select"); // @FindBy(xpath = "//span/label/mat-label[text()='Description']/../../../mat-select")
    this.incidentDescriptionErrorMessage = page.locator("xpath=//label/mat-label[text()='Description']/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error"); // @FindBy(xpath = "//label/mat-label[text()='Description']/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
    this.incidentDateEntryField = page.locator("xpath=//span/label/mat-label[contains(text(),'Date the violation or accident')]/../../../input"); // @FindBy(xpath = "//span/label/mat-label[contains(text(),'Date the violation or accident')]/../../../input")
    this.incidentDateErrorMessage = page.locator("xpath=//span/label/mat-label[contains(text(),'Date the violation or accident')]/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error"); // @FindBy(xpath = "//span/label/mat-label[contains(text(),'Date the violation or accident')]/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
    this.injuriesRadioButton = page.locator("xpath=//app-incident/mat-expansion-panel/div/div/div/div/lib-radio-button/div/mat-radio-group/mat-radio-button/label/div[contains(text(), 'Yes')]"); // @FindBy(xpath = "//app-incident/mat-expansion-panel/div/div/div/div/lib-radio-button/div/mat-radio-group/mat-radio-button/label/div[contains(text(), 'Yes')]")
    this.noInjuriesRadioButton = page.locator("xpath=//app-incident/mat-expansion-panel/div/div/div/div/lib-radio-button/div/mat-radio-group/mat-radio-button/label/div[contains(text(), 'No')]"); // @FindBy(xpath = "//app-incident/mat-expansion-panel/div/div/div/div/lib-radio-button/div/mat-radio-group/mat-radio-button/label/div[contains(text(), 'No')]")
    this.addAnotherIncidentButton = page.locator("xpath=//div[@class='auto-module__add-driver-incidents__add-new-incident-box']/a"); // @FindBy(xpath = "//div[@class='auto-module__add-driver-incidents__add-new-incident-box']/a")
    this.fullTimeStudentSectionLabel = page.locator("xpath=//div[@class='auto-module__add-driver-text' and contains(text(), 'GPA of 3')]"); // @FindBy(xpath = "//div[@class='auto-module__add-driver-text' and contains(text(), 'GPA of 3')]")
    this.fullTimeStudentWithGPARadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_GPA_Yes_radio']//input"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_GPA_Yes_radio']//input")
    this.notFullTimeStudentWithGPARadioButton = page.locator("[data-legacy-field=\"notFullTimeStudentWithGPARadioButton\"]"); // @FindBy(xpath = NOT_FULLTIME_STUDENT_XPATH)
    this.attendingDistantSchoolRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Away_Yes_radio']//input"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Away_Yes_radio']//input")
    this.notAttendingDistantSchoolRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Away_No_radio']//input"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Away_No_radio']//input")
    this.financialResponsibilityFAQLink = page.locator("xpath=//div[contains(text(), 'financial')]/a"); // @FindBy(xpath = "//div[contains(text(), 'financial')]/a")
    this.noFinancialFilingRadioButton = page.locator("[data-legacy-field=\"noFinancialFilingRadioButton\"]"); // @FindBy(xpath = NO_FINANCIAL_FILING_XPATH)
    this.sr22RadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'SR-22')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'SR-22')]")
    this.fr22RadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'FR-22')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'FR-22')]")
    this.financialFilingErrorMessage = page.locator("xpath=//div[contains(text(), 'financial')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-error"); // @FindBy(xpath = "//div[contains(text(), 'financial')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-error")
    this.personalInjuryFAQLink = page.locator("xpath=//div[contains(text(), 'one personal injury')]/a"); // @FindBy(xpath = "//div[contains(text(), 'one personal injury')]/a")
    this.personalInjuryRadioButton = page.locator("xpath=//div[contains(text(), 'one personal injury')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]"); // @FindBy(xpath = "//div[contains(text(), 'one personal injury')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]")
    this.noPersonalInjuryRadioButton = page.locator("xpath=//div[contains(text(), 'one personal injury')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]"); // @FindBy(xpath = "//div[contains(text(), 'one personal injury')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]")
    this.principalPIPFAQLink = page.locator("xpath=//div[contains(text(), 'Principal PIP')]/a"); // @FindBy(xpath = "//div[contains(text(), 'Principal PIP')]/a")
    this.principalPIPDropdown = page.locator("xpath=//span/label/mat-label[text()='Principal PIP']/../../../mat-select"); // @FindBy(xpath = "//span/label/mat-label[text()='Principal PIP']/../../../mat-select")
    this.principalPIPErrorMessage = page.locator("xpath=//span/label/mat-label[contains(text(),'Principal PIP')]/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error"); // @FindBy(xpath = "//span/label/mat-label[contains(text(),'Principal PIP')]/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
    this.safetyCourseFAQLink = page.locator("xpath=//div[contains(text(), 'safety course')]/a"); // @FindBy(xpath = "//div[contains(text(), 'safety course')]/a")
    this.safetyCourseCompletedRadioButton = page.locator("[data-legacy-field=\"safetyCourseCompletedRadioButton\"]"); // @FindBy(xpath = SAFETY_COURSE_COMPLETED_XPATH)
    this.noSafetyCourseCompletedRadioButton = page.locator("xpath=//div[contains(text(), 'safety course')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]"); // @FindBy(xpath = "//div[contains(text(), 'safety course')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]")
    this.safetyCourseCompletedErrorMessage = page.locator("xpath=//div[contains(text(), 'safety course')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-error"); // @FindBy(xpath = "//div[contains(text(), 'safety course')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-error")
    this.safetyCourseCompletedateEntryField = page.locator("xpath=//span/label/mat-label[text()='Safety course completion date']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='Safety course completion date']/../../../input")
    this.commutersFAQLink = page.locator("xpath=//div[contains(text(), 'commuters to')]/a"); // @FindBy(xpath = "//div[contains(text(), 'commuters to')]/a")
    this.commutersToOtherStateRadioButton = page.locator("[data-legacy-field=\"commutersToOtherStateRadioButton\"]"); // @FindBy(xpath = COMMUTERS_TO_OTHER_STATE_RADIO_BUTTON_XPATH)
    this.noCommutersToOtherStateRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Commutestate_No_radio']//input"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Commutestate_No_radio']//input")
    this.commutersErrorMessage = page.locator("#error_opt_commutQues"); // @FindBy(id = "error_opt_commutQues")
    this.addAdditionalDriverDetailsDialogHeader = page.locator(".auto-module__add-driver-header-text"); // @FindBy(className = "auto-module__add-driver-header-text")
    this.saveAdditionalDriverDetailsLink = page.locator("xpath=//div[@class='auto-module__add-driver-header-save']/a"); // @FindBy(xpath = "//div[@class='auto-module__add-driver-header-save']/a")
    this.firstNameADEntryField = page.locator("xpath=//span/label/mat-label[text()='First name']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='First name']/../../../input")
    this.firstNameADErrorMessage = page.locator("xpath=//div[@class='auto-module__add-driver-input-text']/lib-input-text/mat-form-field/div/div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error"); // @FindBy(xpath = "//div[@class='auto-module__add-driver-input-text']/lib-input-text/mat-form-field/div/div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
    this.lastNameADEntryField = page.locator("xpath=//span/label/mat-label[text()='Last name']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='Last name']/../../../input")
    this.lastNameADErrorMessage = page.locator("xpath=//label/mat-label[text()='Last name']/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error"); // @FindBy(xpath = "//label/mat-label[text()='Last name']/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
    this.dobADEntryField = page.locator("xpath=//span/label/mat-label[text()='Date of birth']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='Date of birth']/../../../input")
    this.dobADErrorMessage = page.locator("[data-legacy-field=\"dobADErrorMessage\"]"); // @FindBy(xpath = DOB_ADDITIONAL_DRIVER_ERROR_MESSAGE_XPATH)
    this.relationshipToApplicantDropdown = page.locator("xpath=//span/label/mat-label[text()='Relationship to applicant']/../../../mat-select"); // @FindBy(xpath = "//span/label/mat-label[text()='Relationship to applicant']/../../../mat-select")
    this.relationshipToApplicantErrorMessage = page.locator("xpath=//label/mat-label[text()='Relationship to applicant']/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error"); // @FindBy(xpath = "//label/mat-label[text()='Relationship to applicant']/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
    this.genderSectionLabel = page.locator("xpath=//div[contains(text(),'ender:')]"); // @FindBy(xpath = "//div[contains(text(),'ender:')]")
    this.maleRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'Male')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Male')]")
    this.maleRadioButtonInternal = page.locator("xpath=//mat-radio-button[contains(@data-gtm,'gender_male_radio')]//input[@value='M']"); // @FindBy(xpath = "//mat-radio-button[contains(@data-gtm,'gender_male_radio')]//input[@value='M']")
    this.femaleRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'Female')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Female')]")
    this.femaleRadioButtonInternal = page.locator("xpath=//mat-radio-button[contains(@data-gtm,'gender_female_radio')]//input[@value='F']"); // @FindBy(xpath = "//mat-radio-button[contains(@data-gtm,'gender_female_radio')]//input[@value='F']")
    this.genderNotSpecifiedRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'Binary')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Binary')]")
    this.nonbinaryRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'Nonbinary')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Nonbinary')]")
    this.intersexRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'Intersex')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Intersex')]")
    this.genderErrorMessage = page.locator("xpath=//mat-error[@id='error_opt_gender']"); // @FindBy(xpath = "//mat-error[@id='error_opt_gender']")
    this.emailEntryField = page.locator("xpath=//span/label/mat-label[text()='Email address']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='Email address']/../../../input")
    this.emailEntryFieldErrorMessage = page.locator("xpath=//span/label/mat-label[text()='Email address']/../../../../../div/div/mat-error"); // @FindBy(xpath = "//span/label/mat-label[text()='Email address']/../../../../../div/div/mat-error")
    this.phoneNumberEntryField = page.locator("xpath=//span/label/mat-label[text()='Phone number']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='Phone number']/../../../input")
    this.phoneNumberEntryFieldErrorMessage = page.locator("[data-legacy-field=\"phoneNumberEntryFieldErrorMessage\"]"); // @FindBy(xpath = PHONE_NUMBER_ENTRY_FIELD_ERROR_MESSAGE_XPATH)
    this.differentMailingAddressCheckbox = page.locator("xpath=//span[contains(text(), 'address is different')]"); // @FindBy(xpath = "//span[contains(text(), 'address is different')]")
    this.mailingAddressEntryField = page.locator("xpath=//span/label/mat-label[text()='Mailing address']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='Mailing address']/../../../input")
    this.mailingAddressErrorMessage = page.locator("xpath=//span/label/mat-label[text()='Mailing address']/../../../../../div/div/mat-error"); // @FindBy(xpath = "//span/label/mat-label[text()='Mailing address']/../../../../../div/div/mat-error")
    this.mailingCityEntryField = page.locator("xpath=//span/label/mat-label[text()='City']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='City']/../../../input")
    this.mailingCityErrorMessage = page.locator("xpath=//span/label/mat-label[text()='City']/../../../../../div/div/mat-error"); // @FindBy(xpath = "//span/label/mat-label[text()='City']/../../../../../div/div/mat-error")
    this.mailingStateDropdown = page.locator("xpath=//span/label/mat-label[text()='State']/../../../mat-select"); // @FindBy(xpath = "//span/label/mat-label[text()='State']/../../../mat-select")
    this.mailingStateErrorMessage = page.locator("xpath=//span/label/mat-label[text()='State']/../../../../../div/div/mat-error"); // @FindBy(xpath = "//span/label/mat-label[text()='State']/../../../../../div/div/mat-error")
    this.mailingZipEntryField = page.locator("xpath=//span/label/mat-label[text()='ZIP Code']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='ZIP Code']/../../../input")
    this.mailingZipErrorMessage = page.locator("xpath=//span/label/mat-label[text()='ZIP Code']/../../../../../div/div/mat-error"); // @FindBy(xpath = "//span/label/mat-label[text()='ZIP Code']/../../../../../div/div/mat-error")
    this.additionalDetailsBackButton = page.locator("xpath=//button[@id='addDet_backbt']"); // @FindBy(xpath = "//button[@id='addDet_backbt']")
    this.additionalDetailsNextButton = page.locator("xpath=//button[@id='addDet_nextbtn']"); // @FindBy(xpath = "//button[@id='addDet_nextbtn']")
    this.additionalDetailsDisclaimer = page.locator(".p_addnl_disclaimer_text"); // @FindBy(className = "p_addnl_disclaimer_text")
    this.consentSelectionDisclaimerTextElement = page.locator(".disclaimer_consent"); // @FindBy(className = "disclaimer_consent")
    this.pewcDisclaimerTextElement = page.locator(".auto-module_PEWC"); // @FindBy(className = "auto-module_PEWC")
    this.rideshareTitle = page.locator(".ffq-main-title"); // @FindBy(className = "ffq-main-title")
    this.rideshareDescription = page.locator("xpath=//div[contains(@class, 'auto__rideshare')]/p"); // @FindBy(xpath = "//div[contains(@class, 'auto__rideshare')]/p")
    this.vehiclesUsedForRideshareRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Rideshare_Yes_radio']/label/div/input"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Rideshare_Yes_radio']/label/div/input")
    this.vehiclesUsedForRideshareGTMElement = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Rideshare_Yes_radio']//input"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Rideshare_Yes_radio']//input")
    this.vehiclesNotUsedForRideshareRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Rideshare_No_radio']/label/div/input"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Rideshare_No_radio']/label/div/input")
    this.vehiclesNotUsedForRideshareGTMElement = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Rideshare_No_radio']//input"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Rideshare_No_radio']//input")
    this.vehicleToDriversAssignmentDescription = page.locator("xpath=//div[contains(@class, 'auto-module__driver_assignment_message-header')]"); // @FindBy(xpath = "//div[contains(@class, 'auto-module__driver_assignment_message-header')]")
    this.vehicleToDriversAssignmentErrorMessage = page.locator(".auto-module__driver_assignment_error_message"); // @FindBy(className = "auto-module__driver_assignment_error_message")
    this.driverWhoUsesVehicleMostRadioButton = page.locator("[data-legacy-field=\"driverWhoUsesVehicleMostRadioButton\"]"); // @FindBy(xpath = WHO_DRIVES_VEHICLE_MOST_RADIOBUTTON_XPATH)
    this.agreeDriverUsesMostAndNextButton = page.locator("xpath=//button[@data-gtm='FFQ_Auto_AssignVehiclesDrivers_Discounts_button']"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_AssignVehiclesDrivers_Discounts_button']")
    this.confirmDeleteIncident = page.locator("xpath=//mat-dialog-actions/button[contains(text(), 'Delete')]"); // @FindBy(xpath = "//mat-dialog-actions/button[contains(text(), 'Delete')]")
    this.vehicleToDriversAssignmentBackButton = page.locator("xpath=//div[contains(@class, 'auto__driver__footer')]/button[1]"); // @FindBy(xpath = "//div[contains(@class, 'auto__driver__footer')]/button[1]")
    this.vehicleToDriversAssignmentNextButton = page.locator("xpath=//button[@data-gtm='FFQ_Auto_VDassign_next_button' and contains(@class, 'right_button')]"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_VDassign_next_button' and contains(@class, 'right_button')]")
    this.radioMarriedYes = page.locator("[data-legacy-field=\"radioMarriedYes\"]"); // @FindBy(xpath = MARRIED_RADIO_BUTTON_XPATH)
    this.radioMarriedNo = page.locator("xpath=//div[@id='opt_maritalStatus']//input[@value='S']"); // @FindBy(xpath = "//div[@id='opt_maritalStatus']//input[@value='S']")
  }
}
