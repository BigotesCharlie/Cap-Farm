// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.legacy.SignalPage. */
export class SignalPage extends CoreBasePage {
  public readonly signalPageHeader: Locator;
  public readonly signalPageDescription: Locator;
  public readonly learnMoreLink: Locator;
  public readonly yesSignUpForSignalRadioButton: Locator;
  public readonly noThanksRadioButton: Locator;
  public readonly signalPageDisclaimer: Locator;
  public readonly nextToMoreDiscountsButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.signalPageHeader = page.locator("xpath=//h3"); // @FindBy(xpath = "//h3")
    this.signalPageDescription = page.locator("xpath=//div[@class='auto__signal-maincontent']//p"); // @FindBy(xpath = "//div[@class='auto__signal-maincontent']//p")
    this.learnMoreLink = page.locator("xpath=//a[@data-gtm='FFQ_Auto_Signal_Discount_Learn_More_Link'"); // @FindBy(xpath = "//a[@data-gtm='FFQ_Auto_Signal_Discount_Learn_More_Link'")
    this.yesSignUpForSignalRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Signal_Discount_Yes_radio']"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Signal_Discount_Yes_radio']")
    this.noThanksRadioButton = page.locator("[data-legacy-field=\"noThanksRadioButton\"]"); // @FindBy(xpath = SIGNAL_NO_THANKS_RADIO_BUTTON_XPATH)
    this.signalPageDisclaimer = page.locator(".auto-module__signal-card-text-disclaimer"); // @FindBy(className = "auto-module__signal-card-text-disclaimer")
    this.nextToMoreDiscountsButton = page.locator("xpath=//button[@data-gtm='FFQ_Auto_Signal_Discount_next_button']"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_Signal_Discount_next_button']")
  }
}
