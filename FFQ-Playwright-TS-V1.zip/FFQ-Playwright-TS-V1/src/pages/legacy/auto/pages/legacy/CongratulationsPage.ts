// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.legacy.CongratulationsPage. */
export class CongratulationsPage extends CoreBasePage {
  public readonly congratulationsPageTitle: Locator;
  public readonly thankYouText: Locator;
  public readonly paymentConfirmationNumber: Locator;
  public readonly importantNextSteps: Locator;
  public readonly printButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.congratulationsPageTitle = page.locator("#PolicyIntro"); // @FindBy(id = "PolicyIntro")
    this.thankYouText = page.locator("#Thanks"); // @FindBy(id = "Thanks")
    this.paymentConfirmationNumber = page.locator("#ConfirmationNumber"); // @FindBy(id = "ConfirmationNumber")
    this.importantNextSteps = page.locator("#NextStepss"); // @FindBy(id = "NextStepss")
    this.printButton = page.locator("xpath=//*[@id='buypolicy:printbtn']"); // @FindBy(xpath = "//*[@id='buypolicy:printbtn']")
  }
}
