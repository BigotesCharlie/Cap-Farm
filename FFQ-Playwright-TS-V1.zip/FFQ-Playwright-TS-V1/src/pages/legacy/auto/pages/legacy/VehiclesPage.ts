// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.legacy.VehiclesPage. */
export class VehiclesPage extends CoreBasePage {
  public readonly vehiclesPageHeader: Locator;
  public readonly addVehicleLink: Locator;
  public readonly backButton: Locator;
  public readonly nextButton: Locator;
  public readonly buttonNext: Locator;
  public readonly listOfVehicles: Locator;
  public readonly listOfVINs: Locator;
  public readonly closeAddVehicleDialogButton: Locator;
  public readonly navigateAwayDialog: Locator;
  public readonly continueChangingButton: Locator;
  public readonly navigateAwayButton: Locator;
  public readonly checkAddVehicle: Locator;
  public readonly addVehicleDialogHeader: Locator;
  public readonly saveVehicleInformationLink: Locator;
  public readonly addVehicleInformationLink: Locator;
  public readonly selectYMMTHeader: Locator;
  public readonly addVehicleButton: Locator;
  public readonly saveVehicleButton: Locator;
  public readonly continueWithChangesButton: Locator;
  public readonly ymmtLabel: Locator;
  public readonly enterVINLink: Locator;
  public readonly enterVINLabel: Locator;
  public readonly vinEntryField: Locator;
  public readonly carNotFoundLabel: Locator;
  public readonly carNotFoundFAQButton: Locator;
  public readonly enterYMMLink: Locator;
  public readonly whereVINLabel: Locator;
  public readonly vinFAQButton: Locator;
  public readonly vinErrorMessage: Locator;
  public readonly vehicleYearDropdown: Locator;
  public readonly ymmtErrorMessage: Locator;
  public readonly vehicleMakeDropdownOld: Locator;
  public readonly vehicleModelDropdownOld: Locator;
  public readonly vehicleMakeDropdown: Locator;
  public readonly vehicleModelDropdown: Locator;
  public readonly vehicleTypeDropdown: Locator;
  public readonly alternativeFuelLabel: Locator;
  public readonly alternativeFuelFAQButton: Locator;
  public readonly alternativeFuelCheckbox: Locator;
  public readonly antiTheftLabel: Locator;
  public readonly antiTheftFAQButton: Locator;
  public readonly antiTheftCheckbox: Locator;
  public readonly ownershipLabel: Locator;
  public readonly ownershipFAQButton: Locator;
  public readonly financedRadioButton: Locator;
  public readonly leasedRadioButton: Locator;
  public readonly ownedRadioButton: Locator;
  public readonly purchaseDateLabel: Locator;
  public readonly purchaseDateEntryField: Locator;
  public readonly purchaseDateErrorMessage: Locator;
  public readonly primaryUsageLabel: Locator;
  public readonly primaryUsageFAQButton: Locator;
  public readonly commuteRadioButtonCircle: Locator;
  public readonly commuteRadioButton: Locator;
  public readonly businessRadioButton: Locator;
  public readonly pleasureRadioButton: Locator;
  public readonly primaryUsageErrorMessage: Locator;
  public readonly vehicleUsageErrorText: Locator;
  public readonly ridesharingLabel: Locator;
  public readonly ridesharingFAQButton: Locator;
  public readonly usedForRideshareRadioButton: Locator;
  public readonly usedForRideshareRadioButtonGTMElement: Locator;
  public readonly notUsedForRideshareRadioButton: Locator;
  public readonly notUsedForRideshareRadioButtonGTMElement: Locator;
  public readonly notUsedForRideshareNoRadioButtonCircle: Locator;
  public readonly ridesharingErrorMessage: Locator;
  public readonly parkingOvernightAtResidenceRadioButtonCircle: Locator;
  public readonly parkingOvernightAtResidenceRadioButton: Locator;
  public readonly notParkingOvernightAtResidenceRadioButton: Locator;
  public readonly overnightParkingLabel: Locator;
  public readonly overnightParkingFAQButton: Locator;
  public readonly overnightParkingErrorMessage: Locator;
  public readonly whereDoYouParklLabel: Locator;
  public readonly garagingAddressEntryField: Locator;
  public readonly garagingApartmentEntryField: Locator;
  public readonly garagingCityEntryField: Locator;
  public readonly garagingZipcodeEntryField: Locator;
  public readonly garagingTownSelectField: Locator;
  public readonly milesDrivenOneWayEntryField: Locator;
  public readonly milesDrivenOneWayErrorMessage: Locator;
  public readonly commuteDropdown: Locator;
  public readonly milesDrivenPerYearEntryField: Locator;
  public readonly txtQuoteNumber: Locator;

  public constructor(page: Page) {
    super(page);
    this.vehiclesPageHeader = page.locator(".ffq-main-title"); // @FindBy(className = "ffq-main-title")
    this.addVehicleLink = page.locator("xpath=//a[@data-gtm='FFQ_Auto_Vehicle_addVeh_button']"); // @FindBy(xpath = "//a[@data-gtm='FFQ_Auto_Vehicle_addVeh_button']")
    this.backButton = page.locator("xpath=//div[contains(@class,'auto__vehicles__footer')]/button[contains(@data-gtm, 'back')]"); // @FindBy(xpath = "//div[contains(@class,'auto__vehicles__footer')]/button[contains(@data-gtm, 'back')]")
    this.nextButton = page.locator("xpath=//div[contains(@class,'auto__vehicles__footer')]/button[contains(@data-gtm, 'next')]"); // @FindBy(xpath = "//div[contains(@class,'auto__vehicles__footer')]/button[contains(@data-gtm, 'next')]")
    this.buttonNext = page.locator("xpath=//button[@data-gtm='FFQ_Auto_Vehsummary_next_button' and contains(@class, 'right_button')]"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_Vehsummary_next_button' and contains(@class, 'right_button')]")
    this.listOfVehicles = page.locator("xpath=//lib-card//div[@data-gtm='FFQ_Auto_Vehicle_selectVehicle_checkbox']//h3"); // @FindBy(xpath = "//lib-card//div[@data-gtm='FFQ_Auto_Vehicle_selectVehicle_checkbox']//h3")
    this.listOfVINs = page.locator("xpath=//lib-card//span[contains (@aria-label, 'Vehicle Identification Number : VIN')]"); // @FindBy(xpath = "//lib-card//span[contains (@aria-label, 'Vehicle Identification Number : VIN')]")
    this.closeAddVehicleDialogButton = page.locator("[data-legacy-field=\"closeAddVehicleDialogButton\"]"); // @FindBy(xpath = CLOSE_DIALOG_BUTTON_XPATH)
    this.navigateAwayDialog = page.locator("#infoDialog"); // @FindBy(id = "infoDialog")
    this.continueChangingButton = page.locator("[data-legacy-field=\"continueChangingButton\"]"); // @FindBy(xpath = CONTINUE_CHANGING_XPATH)
    this.navigateAwayButton = page.locator("[data-legacy-field=\"navigateAwayButton\"]"); // @FindBy(xpath = NAVIGATE_AWAY_XPATH)
    this.checkAddVehicle = page.locator("[data-legacy-field=\"checkAddVehicle\"]"); // @FindBy(xpath = CHECK_VEHICLE_XPATH)
    this.addVehicleDialogHeader = page.locator(".auto-module__add-vehicle-header-text"); // @FindBy(className = "auto-module__add-vehicle-header-text") 	private static final String ADD_VEHICLE_DIALOG_HEADER_XPATH = "//div[contains(@class, 'auto-module__add-vehicle-header-text')]";  	@FindBy (xpath = ADD_VEHICLE_DIALOG_HEADER_XPATH)
    this.saveVehicleInformationLink = page.locator("xpath=//button[@data-gtm='FFQ_Auto_Vehicle_Save_button']"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_Vehicle_Save_button']")
    this.addVehicleInformationLink = page.locator("xpath=//button[@data-gtm='FFQ_Auto_Vehicle_Add_button']"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_Vehicle_Add_button']")
    this.selectYMMTHeader = page.locator("xpath=//div[@id='auto-module__add-vehicle-forms']/form/p"); // @FindBy(xpath = "//div[@id='auto-module__add-vehicle-forms']/form/p")
    this.addVehicleButton = page.locator("[data-legacy-field=\"addVehicleButton\"]"); // @FindBy(xpath = ADD_VEHICLE_BUTTON_XPATH)
    this.saveVehicleButton = page.locator("[data-legacy-field=\"saveVehicleButton\"]"); // @FindBy(xpath = SAVE_VEHICLE_BUTTON_XPATH)
    this.continueWithChangesButton = page.locator("[data-legacy-field=\"continueWithChangesButton\"]"); // @FindBy(xpath = CONTINUE_WITH_CHANGES_XPATH)
    this.ymmtLabel = page.locator("#yearMake"); // @FindBy(id = "yearMake")
    this.enterVINLink = page.locator("#vinId"); // @FindBy(id = "vinId")
    this.enterVINLabel = page.locator("[data-legacy-field=\"enterVINLabel\"]"); // @FindBy(xpath = VIN_LABEL_XPATH)
    this.vinEntryField = page.locator("xpath=//input[@aria-label='Vehicle Identification Number']"); // @FindBy(xpath = "//input[@aria-label='Vehicle Identification Number']")
    this.carNotFoundLabel = page.locator("[data-legacy-field=\"carNotFoundLabel\"]"); // @FindBy(xpath = FIND_CAR_LABEL_XPATH)
    this.carNotFoundFAQButton = page.locator("[data-legacy-field=\"carNotFoundFAQButton\"]"); // @FindBy(xpath = FIND_CAR_LABEL_XPATH + "/a[contains(@class,'info-icon')]")
    this.enterYMMLink = page.locator("[data-legacy-field=\"enterYMMLink\"]"); // @FindBy(xpath = ENTER_YMM_LINK_XPATH)
    this.whereVINLabel = page.locator("[data-legacy-field=\"whereVINLabel\"]"); // @FindBy(xpath = WHERES_MY_VIN_LABEL_XPATH)
    this.vinFAQButton = page.locator("[data-legacy-field=\"vinFAQButton\"]"); // @FindBy(xpath = WHERES_MY_VIN_LABEL_XPATH + LINK_XPATH)
    this.vinErrorMessage = page.locator("[data-legacy-field=\"vinErrorMessage\"]"); // @FindBy(xpath = VIN_ERROR_MESSAGE_XPATH)
    this.vehicleYearDropdown = page.locator("xpath=//span/label/mat-label[text()='Vehicle Year']/../../../mat-select"); // @FindBy(xpath = "//span/label/mat-label[text()='Vehicle Year']/../../../mat-select")
    this.ymmtErrorMessage = page.locator("xpath=//div[contains(@class,'addVehicleBody')]/div/lib-select/mat-form-field/div/div[contains(@class,'mat-form-field-subscript-wrapper')]/div/mat-error"); // @FindBy(xpath = "//div[contains(@class,'addVehicleBody')]/div/lib-select/mat-form-field/div/div[contains(@class,'mat-form-field-subscript-wrapper')]/div/mat-error")
    this.vehicleMakeDropdownOld = page.locator("xpath=//span/label/mat-label[text()='Vehicle Make']/../../../mat-select"); // @FindBy(xpath = "//span/label/mat-label[text()='Vehicle Make']/../../../mat-select")
    this.vehicleModelDropdownOld = page.locator("xpath=//span/label/mat-label[text()='Vehicle Model']/../../../mat-select"); // @FindBy(xpath = "//span/label/mat-label[text()='Vehicle Model']/../../../mat-select")
    this.vehicleMakeDropdown = page.locator("xpath=//span/label/mat-label[text()='Vehicle Make']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='Vehicle Make']/../../../input")
    this.vehicleModelDropdown = page.locator("xpath=//span/label/mat-label[text()='Vehicle Model']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='Vehicle Model']/../../../input")
    this.vehicleTypeDropdown = page.locator("xpath=//span/label/mat-label[text()='Vehicle type']/../../../mat-select"); // @FindBy(xpath = "//span/label/mat-label[text()='Vehicle type']/../../../mat-select")
    this.alternativeFuelLabel = page.locator("[data-legacy-field=\"alternativeFuelLabel\"]"); // @FindBy(xpath = ALTERNATIVE_FUELS_LABEL_XPATH)
    this.alternativeFuelFAQButton = page.locator("[data-legacy-field=\"alternativeFuelFAQButton\"]"); // @FindBy(xpath = ALTERNATIVE_FUELS_LABEL_XPATH + XPATH_TO_FAQ)
    this.alternativeFuelCheckbox = page.locator("xpath=//input[@aria-label='Alternative fuels']"); // @FindBy(xpath = "//input[@aria-label='Alternative fuels']")
    this.antiTheftLabel = page.locator("[data-legacy-field=\"antiTheftLabel\"]"); // @FindBy(xpath = ANTI_THEFT_LABEL_XPATH)
    this.antiTheftFAQButton = page.locator("[data-legacy-field=\"antiTheftFAQButton\"]"); // @FindBy(xpath = ANTI_THEFT_LABEL_XPATH + XPATH_TO_FAQ)
    this.antiTheftCheckbox = page.locator("xpath=//input[@aria-label='Anti-theft device']"); // @FindBy(xpath = "//input[@aria-label='Anti-theft device']")
    this.ownershipLabel = page.locator("[data-legacy-field=\"ownershipLabel\"]"); // @FindBy(xpath = OWNERSHIP_LABEL_XPATH)
    this.ownershipFAQButton = page.locator("[data-legacy-field=\"ownershipFAQButton\"]"); // @FindBy(xpath = OWNERSHIP_LABEL_XPATH + LINK_XPATH)
    this.financedRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Vehicle_ownership_financed_radio']"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Vehicle_ownership_financed_radio']")
    this.leasedRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Vehicle_ownership_leased_radio']"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Vehicle_ownership_leased_radio']")
    this.ownedRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Vehicle_ownership_Owned_radio']"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Vehicle_ownership_Owned_radio']")
    this.purchaseDateLabel = page.locator("[data-legacy-field=\"purchaseDateLabel\"]"); // @FindBy(xpath = PURCHASE_LABEL_XPATH)
    this.purchaseDateEntryField = page.locator("[data-legacy-field=\"purchaseDateEntryField\"]"); // @FindBy(xpath = PURCHASE_DATE_XPATH)
    this.purchaseDateErrorMessage = page.locator("xpath=//lib-date-picker-monthyear-format/mat-form-field/div/div/div/mat-error"); // @FindBy(xpath = "//lib-date-picker-monthyear-format/mat-form-field/div/div/div/mat-error")
    this.primaryUsageLabel = page.locator("[data-legacy-field=\"primaryUsageLabel\"]"); // @FindBy(xpath = PRIMARY_USAGE_LABEL_XPATH)
    this.primaryUsageFAQButton = page.locator("[data-legacy-field=\"primaryUsageFAQButton\"]"); // @FindBy(xpath = PRIMARY_USAGE_LABEL_XPATH + LINK_XPATH)
    this.commuteRadioButtonCircle = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'Commuting')]/../div/input"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Commuting')]/../div/input")
    this.commuteRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'Commuting')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Commuting')]")
    this.businessRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'Business')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Business')]")
    this.pleasureRadioButton = page.locator("xpath=//mat-radio-button/label/div[contains(text(), 'Pleasure')]"); // @FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Pleasure')]")
    this.primaryUsageErrorMessage = page.locator("xpath=//div/p[contains(text(), 'primary use')]/../lib-radio-button/div/mat-error"); // @FindBy(xpath = "//div/p[contains(text(), 'primary use')]/../lib-radio-button/div/mat-error")
    this.vehicleUsageErrorText = page.locator("[data-legacy-field=\"vehicleUsageErrorText\"]"); // @FindBy(id = VEHICLE_USAGE_ERROR_TEXT_ID)
    this.ridesharingLabel = page.locator("[data-legacy-field=\"ridesharingLabel\"]"); // @FindBy(xpath = RIDESHARING_LABEL_XPATH)
    this.ridesharingFAQButton = page.locator("[data-legacy-field=\"ridesharingFAQButton\"]"); // @FindBy(xpath = RIDESHARING_LABEL_XPATH + LINK_XPATH)
    this.usedForRideshareRadioButton = page.locator("xpath=//div/p[contains(text(), 'ridesharing')]/..//div[contains(text(), 'Yes')]"); // @FindBy(xpath = "//div/p[contains(text(), 'ridesharing')]/..//div[contains(text(), 'Yes')]")
    this.usedForRideshareRadioButtonGTMElement = page.locator("xpath=//div/p[contains(text(), 'ridesharing')]/..//mat-radio-button[contains(@data-gtm, 'FFQ_Auto_Vehicle_rideshareYes_radio')]"); // @FindBy(xpath = "//div/p[contains(text(), 'ridesharing')]/..//mat-radio-button[contains(@data-gtm, 'FFQ_Auto_Vehicle_rideshareYes_radio')]")
    this.notUsedForRideshareRadioButton = page.locator("xpath=//div/p[contains(text(), 'ridesharing')]/..//div[contains(text(), 'No')]"); // @FindBy(xpath = "//div/p[contains(text(), 'ridesharing')]/..//div[contains(text(), 'No')]")
    this.notUsedForRideshareRadioButtonGTMElement = page.locator("xpath=//div/p[contains(text(), 'ridesharing')]/..//mat-radio-button[contains(@data-gtm, 'FFQ_Auto_Vehicle_rideshareNo_radio')]"); // @FindBy(xpath = "//div/p[contains(text(), 'ridesharing')]/..//mat-radio-button[contains(@data-gtm, 'FFQ_Auto_Vehicle_rideshareNo_radio')]")
    this.notUsedForRideshareNoRadioButtonCircle = page.locator("xpath=//div/p[contains(text(), 'ridesharing')]/..//div[contains(text(), 'No')]/../div/input"); // @FindBy(xpath = "//div/p[contains(text(), 'ridesharing')]/..//div[contains(text(), 'No')]/../div/input")
    this.ridesharingErrorMessage = page.locator("xpath=//div/p[contains(text(), 'for ridesharing')]/../lib-radio-button/div/mat-error"); // @FindBy(xpath = "//div/p[contains(text(), 'for ridesharing')]/../lib-radio-button/div/mat-error")
    this.parkingOvernightAtResidenceRadioButtonCircle = page.locator("xpath=//div/p[contains(text(), 'overnight')]/../lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]/../div/input"); // @FindBy(xpath = "//div/p[contains(text(), 'overnight')]/../lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]/../div/input")
    this.parkingOvernightAtResidenceRadioButton = page.locator("xpath=//div/p[contains(text(), 'overnight')]/../lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]"); // @FindBy(xpath = "//div/p[contains(text(), 'overnight')]/../lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]")
    this.notParkingOvernightAtResidenceRadioButton = page.locator("xpath=//div/p[contains(text(), 'overnight')]/../lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]"); // @FindBy(xpath = "//div/p[contains(text(), 'overnight')]/../lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]")
    this.overnightParkingLabel = page.locator("[data-legacy-field=\"overnightParkingLabel\"]"); // @FindBy(xpath = OVERNIGHT_PARKING_LABEL_XPATH)
    this.overnightParkingFAQButton = page.locator("[data-legacy-field=\"overnightParkingFAQButton\"]"); // @FindBy(xpath = OVERNIGHT_PARKING_LABEL_XPATH + LINK_XPATH)
    this.overnightParkingErrorMessage = page.locator("xpath=//div/p[contains(text(), 'vehicle overnight')]/../lib-radio-button/div/mat-error"); // @FindBy(xpath = "//div/p[contains(text(), 'vehicle overnight')]/../lib-radio-button/div/mat-error")
    this.whereDoYouParklLabel = page.locator("[data-legacy-field=\"whereDoYouParklLabel\"]"); // @FindBy(xpath = WHERE_DO_YOU_PARK_LABEL_XPATH)
    this.garagingAddressEntryField = page.locator("xpath=//span/label/mat-label[text()='Garaging address']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='Garaging address']/../../../input")
    this.garagingApartmentEntryField = page.locator("xpath=//input[@data-gtm='FFQ_Auto_Vehicle_garaptnumber_text']"); // @FindBy(xpath = "//input[@data-gtm='FFQ_Auto_Vehicle_garaptnumber_text']")
    this.garagingCityEntryField = page.locator("xpath=//span/label/mat-label[text()='City']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='City']/../../../input")
    this.garagingZipcodeEntryField = page.locator("xpath=//span/label/mat-label[text()='Zip Code']/../../../input"); // @FindBy(xpath = "//span/label/mat-label[text()='Zip Code']/../../../input")
    this.garagingTownSelectField = page.locator("[data-legacy-field=\"garagingTownSelectField\"]"); // @FindBy(xpath = TOWN_DROPDOWN_XPATH)
    this.milesDrivenOneWayEntryField = page.locator("[data-legacy-field=\"milesDrivenOneWayEntryField\"]"); // @FindBy(xpath = MILES_DRIVEN_ONE_WAY_XPATH)
    this.milesDrivenOneWayErrorMessage = page.locator("xpath=//mat-form-field/div/div/div/mat-error[contains(text(),'Please enter the miles you drive one-way.')]"); // @FindBy(xpath = "//mat-form-field/div/div/div/mat-error[contains(text(),'Please enter the miles you drive one-way.')]")
    this.commuteDropdown = page.locator("[data-legacy-field=\"commuteDropdown\"]"); // @FindBy(xpath = COMMUTE_DROPDOWN_XPATH)
    this.milesDrivenPerYearEntryField = page.locator("[data-legacy-field=\"milesDrivenPerYearEntryField\"]"); // @FindBy(xpath = MILES_DRIVEN_PER_YEAR_XPATH)
    this.txtQuoteNumber = page.locator("xpath=//mat-sidenav//div[starts-with(text(), ' Auto Quote ')]"); // @FindBy(xpath = "//mat-sidenav//div[starts-with(text(), ' Auto Quote ')]")
  }
}
