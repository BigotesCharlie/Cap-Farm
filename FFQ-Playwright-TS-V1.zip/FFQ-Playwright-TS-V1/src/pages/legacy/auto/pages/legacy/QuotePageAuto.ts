// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.legacy.QuotePageAuto. */
export class QuotePageAuto extends CoreBasePage {
  public readonly quotePageHeader: Locator;
  public readonly quotePageDescription: Locator;
  public readonly packageHeader: Locator;
  public readonly packageDescription: Locator;
  public readonly viewAllPackagesLink: Locator;
  public readonly buyNowButton: Locator;
  public readonly quoteRentersButton: Locator;
  public readonly quoteRentersProgressPopup: Locator;
  public readonly rentersQuoteSummaryHeader: Locator;
  public readonly quoteAmountField: Locator;
  public readonly quoteAmountFieldStruckthrough: Locator;
  public readonly quotePeriodField: Locator;
  public readonly membershipFee: Locator;
  public readonly discountsListHeader: Locator;
  public readonly listOfDiscounts: Locator;
  public readonly disclosureLabel: Locator;
  public readonly quotePageDisclosure1: Locator;
  public readonly quotePageRentersDisclosure: Locator;
  public readonly quotePageDisclosure2: Locator;
  public readonly quotePageDisclosure3: Locator;
  public readonly liabilityCoverageHeader: Locator;
  public readonly liabilityCoverageHeaderButton: Locator;
  public readonly vehicleCoveragesHeaderButton: Locator;
  public readonly minimizeChatbotDialog: Locator;
  public readonly basicCoveragePackage: Locator;
  public readonly enhancedCoveragePackage: Locator;
  public readonly fullCoveragePackage: Locator;
  public readonly customCoveragePackage: Locator;
  public readonly cancelButton: Locator;
  public readonly confirmButton: Locator;
  public readonly accidentalDeathLiabilityLabel: Locator;
  public readonly accidentalDeathLiabilityDropdown: Locator;
  public readonly accidentalDeathLiabilityFAQ: Locator;
  public readonly accidentalDeathLiabilityAmount: Locator;
  public readonly accidentalDeathLiabilityRefreshIcon: Locator;
  public readonly accidentalDeathBenefitsLiabilityLabel: Locator;
  public readonly accidentalDeathBenefitsLiabilityDropdown: Locator;
  public readonly accidentalDeathBenefitsLiabilityFAQ: Locator;
  public readonly accidentalDeathBenefitsLiabilityAmount: Locator;
  public readonly accidentalDeathBenefitsLiabilityRefreshIcon: Locator;
  public readonly bodilyInjuryLiabilityLabel: Locator;
  public readonly bodilyInjuryLiabilityDropdown: Locator;
  public readonly bodilyInjuryLiabilityFAQ: Locator;
  public readonly bodilyInjuryLiabilityAmount: Locator;
  public readonly bodilyInjuryLiabilityRefreshIcon: Locator;
  public readonly bodilyInjuryLiabilityErrorLabel: Locator;
  public readonly bodilyInjuryLiabilityErrorMessage: Locator;
  public readonly essentialServicesLiabilityLabel: Locator;
  public readonly essentialServicesLiabilityDropdown: Locator;
  public readonly essentialServicesLiabilityFAQ: Locator;
  public readonly essentialServicesLiabilityAmount: Locator;
  public readonly essentialServicesLiabilityRefreshIcon: Locator;
  public readonly extendedMedicalPaymentsLiabilityLabel: Locator;
  public readonly extendedMedicalPaymentsLiabilityDropdown: Locator;
  public readonly extendedMedicalPaymentsLiabilityFAQ: Locator;
  public readonly extendedMedicalPaymentsLiabilityAmount: Locator;
  public readonly extendedMedicalPaymentsLiabilityRefreshIcon: Locator;
  public readonly extraPIPPackageLiabilityLabel: Locator;
  public readonly extraPIPPackageLiabilityDropdown: Locator;
  public readonly extraPIPPackageLiabilityFAQ: Locator;
  public readonly extraPIPPackageLiabilityAmount: Locator;
  public readonly extraPIPPackageLiabilityRefreshIcon: Locator;
  public readonly extraPIPPackageLiabilityErrorLabel: Locator;
  public readonly extraPIPPackageLiabilityErrorMessage: Locator;
  public readonly funeralExpenseBenefitsLiabilityLabel: Locator;
  public readonly funeralExpenseBenefitsLiabilityDropdown: Locator;
  public readonly funeralExpenseBenefitsLiabilityFAQ: Locator;
  public readonly funeralExpenseBenefitsLiabilityAmount: Locator;
  public readonly funeralExpenseBenefitsLiabilityRefreshIcon: Locator;
  public readonly guestPIPLiabilityLabel: Locator;
  public readonly guestPIPLiabilityDropdown: Locator;
  public readonly guestPIPLiabilityFAQ: Locator;
  public readonly guestPIPLiabilityAmount: Locator;
  public readonly guestPIPLiabilityRefreshIcon: Locator;
  public readonly incomeContinuationLiabilityLabel: Locator;
  public readonly incomeContinuationLiabilityDropdown: Locator;
  public readonly incomeContinuationLiabilityFAQ: Locator;
  public readonly incomeContinuationLiabilityAmount: Locator;
  public readonly incomeContinuationLiabilityRefreshIcon: Locator;
  public readonly lawsuitOptionLiabilityLabel: Locator;
  public readonly lawsuitOptionLiabilityDropdown: Locator;
  public readonly lawsuitOptionLiabilityFAQ: Locator;
  public readonly lawsuitOptionLiabilityAmount: Locator;
  public readonly lawsuitOptionLiabilityRefreshIcon: Locator;
  public readonly medicalLiabilityLabel: Locator;
  public readonly medicalLiabilityDropdown: Locator;
  public readonly medicalLiabilityFAQ: Locator;
  public readonly medicalLiabilityAmount: Locator;
  public readonly medicalLiabilityRefreshIcon: Locator;
  public readonly medicalLiabilityErrorLabel: Locator;
  public readonly medicalLiabilityErrorMessage: Locator;
  public readonly medicalAndHospitalLiabilityLabel: Locator;
  public readonly medicalAndHospitalLiabilityDropdown: Locator;
  public readonly medicalAndHospitalLiabilityFAQ: Locator;
  public readonly medicalAndHospitalLiabilityAmount: Locator;
  public readonly medicalAndHospitalLiabilityRefreshIcon: Locator;
  public readonly medicalCoverageLiabilityLabel: Locator;
  public readonly medicalCoverageLiabilityDropdown: Locator;
  public readonly medicalCoverageLiabilityFAQ: Locator;
  public readonly medicalCoverageLiabilityAmount: Locator;
  public readonly medicalCoverageLiabilityRefreshIcon: Locator;
  public readonly medicalCoverageLiabilityErrorLabel: Locator;
  public readonly medicalCoverageLiabilityErrorMessage: Locator;
  public readonly medicalExpenseLabel: Locator;
  public readonly medicalExpenseDropdown: Locator;
  public readonly medicalExpenseFAQ: Locator;
  public readonly medicalExpenseAmount: Locator;
  public readonly medicalExpenseRefreshIcon: Locator;
  public readonly optionalPIPLiabilityLabel: Locator;
  public readonly optionalPIPLiabilityDropdown: Locator;
  public readonly optionalPIPLiabilityFAQ: Locator;
  public readonly optionalPIPLiabilityAmount: Locator;
  public readonly optionalPIPLiabilityRefreshIcon: Locator;
  public readonly permissiveUserLimitLiabilityLabel: Locator;
  public readonly permissiveUserLimitLiabilityDropdown: Locator;
  public readonly permissiveUserLimitLiabilityFAQ: Locator;
  public readonly permissiveUserLimitLiabilityAmount: Locator;
  public readonly permissiveUserLimitLiabilityRefreshIcon: Locator;
  public readonly personalInjuryProtectionLiabilityLabel: Locator;
  public readonly personalInjuryProtectionLiabilityDropdown: Locator;
  public readonly personalInjuryProtectionLiabilityFAQ: Locator;
  public readonly personalInjuryProtectionLiabilityAmount: Locator;
  public readonly personalInjuryProtectionLiabilityRefreshIcon: Locator;
  public readonly personalInjuryProtectionExclusionLiabilityLabel: Locator;
  public readonly personalInjuryProtectionExclusionLiabilityDropdown: Locator;
  public readonly personalInjuryProtectionExclusionLiabilityFAQ: Locator;
  public readonly personalInjuryProtectionExclusionLiabilityAmount: Locator;
  public readonly personalInjuryProtectionExclusionLiabilityRefreshIcon: Locator;
  public readonly personalInjuryProtectionDeductibleAppliesToLiabilityLabel: Locator;
  public readonly personalInjuryProtectionDeductibleAppliesToLiabilityDropdown: Locator;
  public readonly personalInjuryProtectionDeductibleAppliesToLiabilityFAQ: Locator;
  public readonly personalInjuryProtectionDeductibleAppliesToLiabilityAmount: Locator;
  public readonly personalInjuryProtectionDeductibleAppliesToLiabilityRefreshIcon: Locator;
  public readonly principalPIPLiabilityLabel: Locator;
  public readonly principalPIPLiabilityDropdown: Locator;
  public readonly principalPIPLiabilityFAQ: Locator;
  public readonly principalPIPLiabilityAmount: Locator;
  public readonly principalPIPLiabilityRefreshIcon: Locator;
  public readonly principalPIPMedicalExpensesLiabilityLabel: Locator;
  public readonly principalPIPMedicalExpensesLiabilityDropdown: Locator;
  public readonly principalPIPMedicalExpensesLiabilityFAQ: Locator;
  public readonly principalPIPMedicalExpensesLiabilityAmount: Locator;
  public readonly principalPIPMedicalExpensesLiabilityRefreshIcon: Locator;
  public readonly principalPIPMedicalExpensesLiabilityErrorLabel: Locator;
  public readonly principalPIPMedicalExpensesLiabilityErrorMessage: Locator;
  public readonly propertyDamageLiabilityLabel: Locator;
  public readonly propertyDamageLiabilityDropdown: Locator;
  public readonly propertyDamageLiabilityFAQ: Locator;
  public readonly propertyDamageLiabilityAmount: Locator;
  public readonly propertyDamageLiabilityRefreshIcon: Locator;
  public readonly propertyDamageLiabilityErrorLabel: Locator;
  public readonly propertyDamageLiabilityErrorMessage: Locator;
  public readonly propertyDamageLabel: Locator;
  public readonly propertyDamageDropdown: Locator;
  public readonly propertyDamageFAQ: Locator;
  public readonly propertyDamageAmount: Locator;
  public readonly propertyDamageRefreshIcon: Locator;
  public readonly propertyDamageErrorLabel: Locator;
  public readonly propertyDamageErrorMessage: Locator;
  public readonly tortLiabilityLabel: Locator;
  public readonly tortLiabilityDropdown: Locator;
  public readonly tortLiabilityFAQ: Locator;
  public readonly tortLiabilityAmount: Locator;
  public readonly tortLiabilityRefreshIcon: Locator;
  public readonly underSpaceInsuredMotoristBodilyInjuryLiabilityLabel: Locator;
  public readonly underSpaceInsuredMotoristBodilyInjuryLiabilityDropdown: Locator;
  public readonly underSpaceInsuredMotoristBodilyInjuryLiabilityFAQ: Locator;
  public readonly underSpaceInsuredMotoristBodilyInjuryLiabilityAmount: Locator;
  public readonly underSpaceInsuredMotoristBodilyInjuryLiabilityRefreshIcon: Locator;
  public readonly underinsuredMotoristBodilyInjuryStackingOptionLiabilityLabel: Locator;
  public readonly underinsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown: Locator;
  public readonly underinsuredMotoristBodilyInjuryStackingOptionLiabilityFAQ: Locator;
  public readonly underinsuredMotoristBodilyInjuryStackingOptionLiabilityAmount: Locator;
  public readonly underinsuredMotoristBodilyInjuryStackingOptionLiabilityRefreshIcon: Locator;
  public readonly underinsuredMotoristBodilyInjuryStackingOptionLiabilityErrorLabel: Locator;
  public readonly underinsuredMotoristBodilyInjuryStackingOptionLiabilityErrorMessage: Locator;
  public readonly underSpaceInsuredMotoristPropertyDamageLiabilityLabel: Locator;
  public readonly underSpaceInsuredMotoristPropertyDamageLiabilityDropdown: Locator;
  public readonly underSpaceInsuredMotoristPropertyDamageLiabilityFAQ: Locator;
  public readonly underSpaceInsuredMotoristPropertyDamageLiabilityAmount: Locator;
  public readonly underSpaceInsuredMotoristPropertyDamageLiabilityRefreshIcon: Locator;
  public readonly uninsuredMotoristBodilyInjuryStackingLiabilityLabel: Locator;
  public readonly uninsuredMotoristBodilyInjuryStackingLiabilityDropdown: Locator;
  public readonly uninsuredMotoristBodilyInjuryStackingLiabilityFAQ: Locator;
  public readonly uninsuredMotoristBodilyInjuryStackingLiabilityAmount: Locator;
  public readonly uninsuredMotoristBodilyInjuryStackingLiabilityRefreshIcon: Locator;
  public readonly uninsuredMotoristBodilyInjuryStackingOptionLiabilityLabel: Locator;
  public readonly uninsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown: Locator;
  public readonly uninsuredMotoristBodilyInjuryStackingOptionLiabilityFAQ: Locator;
  public readonly uninsuredMotoristBodilyInjuryWithoutStackingLiabilityLabel: Locator;
  public readonly uninsuredMotoristBodilyInjuryWithoutStackingLiabilityDropdown: Locator;
  public readonly uninsuredMotoristBodilyInjuryWithoutStackingLiabilityFAQ: Locator;
  public readonly uninsuredMotoristBodilyInjuryWithoutStackingLiabilityAmount: Locator;
  public readonly uninsuredMotoristBodilyInjuryWithoutStackingLiabilityRefreshIcon: Locator;
  public readonly uninsuredMotoristLiabilityLabel: Locator;
  public readonly uninsuredMotoristLiabilityDropdown: Locator;
  public readonly uninsuredMotoristLiabilityFAQ: Locator;
  public readonly uninsuredMotoristLiabilityAmount: Locator;
  public readonly uninsuredMotoristLiabilityRefreshIcon: Locator;
  public readonly uninsuredMotoristLiabilityErrorLabel: Locator;
  public readonly uninsuredMotoristLiabilityErrorMessage: Locator;
  public readonly uninsuredMotoristNYLiabilityLabel: Locator;
  public readonly uninsuredMotoristNYLiabilityDropdown: Locator;
  public readonly uninsuredMotoristNYLiabilityFAQ: Locator;
  public readonly uninsuredMotoristNYLiabilityAmount: Locator;
  public readonly uninsuredMotoristNYLiabilityRefreshIcon: Locator;
  public readonly uninsuredMotoristNYLiabilityErrorLabel: Locator;
  public readonly uninsuredMotoristNYLiabilityErrorMessage: Locator;
  public readonly underSpaceInsuredMotoristLiabilityLabel: Locator;
  public readonly underSpaceInsuredMotoristLiabilityDropdown: Locator;
  public readonly underSpaceInsuredMotoristLiabilityFAQ: Locator;
  public readonly underSpaceInsuredMotoristLiabilityAmount: Locator;
  public readonly underSpaceInsuredMotoristLiabilityRefreshIcon: Locator;
  public readonly underSpaceInsuredMotoristLiabilityErrorLabel: Locator;
  public readonly underSpaceInsuredMotoristLiabilityErrorMessage: Locator;
  public readonly underinsuredMotoristLiabilityLabel: Locator;
  public readonly underinsuredMotoristLiabilityDropdown: Locator;
  public readonly underinsuredMotoristLiabilityFAQ: Locator;
  public readonly underinsuredMotoristLiabilityAmount: Locator;
  public readonly underinsuredMotoristLiabilityRefreshIcon: Locator;
  public readonly uninsuredMotoristBodilyInjuryLiabilityLabel: Locator;
  public readonly uninsuredMotoristBodilyInjuryLiabilityAlternateLabel: Locator;
  public readonly uninsuredMotoristBodilyInjuryLiabilityDropdown: Locator;
  public readonly uninsuredMotoristBodilyInjuryLiabilityAlternateDropdown: Locator;
  public readonly uninsuredMotoristBodilyInjuryLiabilityFAQ: Locator;
  public readonly uninsuredMotoristBodilyInjuryLiabilityAmount: Locator;
  public readonly uninsuredMotoristBodilyInjuryLiabilityRefreshIcon: Locator;
  public readonly uninsuredMotoristBILiabilityLabel: Locator;
  public readonly uninsuredMotoristBILiabilityDropdown: Locator;
  public readonly uninsuredMotoristBILiabilityFAQ: Locator;
  public readonly uninsuredMotoristBILiabilityAmount: Locator;
  public readonly uninsuredMotoristBILiabilityRefreshIcon: Locator;
  public readonly uninsuredMotoristBIOptionsLiabilityLabel: Locator;
  public readonly uninsuredMotoristBIOptionsLiabilityDropdown: Locator;
  public readonly uninsuredMotoristBIOptionsLiabilityFAQ: Locator;
  public readonly uninsuredMotoristBIOptionsLiabilityAmount: Locator;
  public readonly uninsuredMotoristBIOptionsLiabilityRefreshIcon: Locator;
  public readonly underinsuredMotoristBodilyInjuryLiabilityLabel: Locator;
  public readonly underinsuredMotoristBodilyInjuryLiabilityDropdown: Locator;
  public readonly underinsuredMotoristBodilyInjuryLiabilityFAQ: Locator;
  public readonly underinsuredMotoristBodilyInjuryLiabilityAmount: Locator;
  public readonly underinsuredMotoristBodilyInjuryLiabilityRefreshIcon: Locator;
  public readonly underinsuredMotoristBodilyInjuryLiabilityErrorLabel: Locator;
  public readonly underinsuredMotoristBodilyInjuryLiabilityErrorMessage: Locator;
  public readonly uninsuredUnderinsuredMotoristBodilyInjuryLiabilityLabel: Locator;
  public readonly uninsuredUnderinsuredMotoristBodilyInjuryLiabilityDropdown: Locator;
  public readonly uninsuredUnderinsuredMotoristBodilyInjuryLiabilityFAQ: Locator;
  public readonly uninsuredUnderinsuredMotoristBodilyInjuryLiabilityAmount: Locator;
  public readonly uninsuredUnderinsuredMotoristBodilyInjuryLiabilityRefreshIcon: Locator;
  public readonly uninsuredUnderinsuredMotoristBILiabilityLabel: Locator;
  public readonly uninsuredUnderinsuredMotoristBILiabilityDropdown: Locator;
  public readonly uninsuredUnderinsuredMotoristBILiabilityFAQ: Locator;
  public readonly uninsuredUnderinsuredMotoristBILiabilityAmount: Locator;
  public readonly uninsuredUnderinsuredMotoristBILiabilityRefreshIcon: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityLabel: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityDropdown: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityFAQ: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityAmount: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityRefreshIcon: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityLabel: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityDropdown: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityFAQ: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityAmount: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityRefreshIcon: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBILiabilityLabel: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBILiabilityDropdown: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBILiabilityFAQ: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBILiabilityAmount: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristBILiabilityRefreshIcon: Locator;
  public readonly uninsuredUnderInsuredMotoristBIConversionLiabilityLabel: Locator;
  public readonly uninsuredUnderInsuredMotoristBIConversionLiabilityDropdown: Locator;
  public readonly uninsuredUnderInsuredMotoristBIConversionLiabilityFAQ: Locator;
  public readonly uninsuredUnderInsuredMotoristBIConversionLiabilityAmount: Locator;
  public readonly uninsuredUnderInsuredMotoristBIConversionLiabilityRefreshIcon: Locator;
  public readonly uninsuredUnderInsuredMotoristBIConversionLiabilityErrorLabel: Locator;
  public readonly uninsuredUnderInsuredMotoristBIConversionLiabilityErrorMessage: Locator;
  public readonly underinsuredMotoristBILiabilityLabel: Locator;
  public readonly underinsuredMotoristBILiabilityDropdown: Locator;
  public readonly underinsuredMotoristBILiabilityFAQ: Locator;
  public readonly underinsuredMotoristBILiabilityAmount: Locator;
  public readonly underinsuredMotoristBILiabilityRefreshIcon: Locator;
  public readonly underinsuredMotoristBILiabilityErrorLabel: Locator;
  public readonly underinsuredMotoristBILiabilityErrorMessage: Locator;
  public readonly underinsuredMotoristPropertyDamageLiabilityLabel: Locator;
  public readonly underinsuredMotoristPropertyDamageLiabilityDropdown: Locator;
  public readonly underinsuredMotoristPropertyDamageLiabilityFAQ: Locator;
  public readonly underinsuredMotoristPropertyDamageLiabilityAmount: Locator;
  public readonly underinsuredMotoristPropertyDamageLiabilityRefreshIcon: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityLabel: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityDropdown: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityFAQ: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityAmount: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityRefreshIcon: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityErrorLabel: Locator;
  public readonly uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityErrorMessage: Locator;
  public readonly uninsuredUnderinsuredMotoristPropertyDamageLiabilityLabel: Locator;
  public readonly uninsuredUnderinsuredMotoristPropertyDamageLiabilityDropdown: Locator;
  public readonly uninsuredUnderinsuredMotoristPropertyDamageLiabilityFAQ: Locator;
  public readonly uninsuredUnderinsuredMotoristPropertyDamageLiabilityAmount: Locator;
  public readonly uninsuredUnderinsuredMotoristPropertyDamageLiabilityRefreshIcon: Locator;
  public readonly uninsuredUnderinsuredMotoristPropertyDamageLiabilityErrorLabel: Locator;
  public readonly uninsuredUnderinsuredMotoristPropertyDamageLiabilityErrorMessage: Locator;
  public readonly uninsuredUnderInsuredMotoristPDLiabilityLabel: Locator;
  public readonly uninsuredUnderInsuredMotoristPDLiabilityDropdown: Locator;
  public readonly uninsuredUnderInsuredMotoristPDLiabilityFAQ: Locator;
  public readonly uninsuredUnderInsuredMotoristPDLiabilityAmount: Locator;
  public readonly uninsuredUnderInsuredMotoristPDLiabilityRefreshIcon: Locator;
  public readonly vehicleCoverageHeaders: Locator;
  public readonly accidentForgivenessCoverageLabel: Locator;
  public readonly accidentForgivenessCoverageDropdown: Locator;
  public readonly accidentForgivenessCoverageFAQ: Locator;
  public readonly accidentForgivenessCoverageAmount: Locator;
  public readonly accidentForgivenessCoverageRefreshIcon: Locator;
  public readonly collisionCoverageLabel: Locator;
  public readonly collisionCoverageDropdown: Locator;
  public readonly collisionCoverageFAQ: Locator;
  public readonly collisionCoverageAmount: Locator;
  public readonly collisionCoverageRefreshIcon: Locator;
  public readonly collisionPlusLossOfUseCoverageLabel: Locator;
  public readonly collisionPlusLossOfUseCoverageDropdown: Locator;
  public readonly collisionPlusLossOfUseCoverageFAQ: Locator;
  public readonly collisionPlusLossOfUseCoverageAmount: Locator;
  public readonly collisionPlusLossOfUseCoverageRefreshIcon: Locator;
  public readonly collisionPlusLossOfUseK5CoverageLabel: Locator;
  public readonly collisionPlusLossOfUseK5CoverageDropdown: Locator;
  public readonly collisionPlusLossOfUseK5CoverageFAQ: Locator;
  public readonly collisionPlusLossOfUseK5CoverageAmount: Locator;
  public readonly collisionPlusLossOfUseK5CoverageRefreshIcon: Locator;
  public readonly comprehensiveCoverageLabel: Locator;
  public readonly comprehensiveCoverageDropdown: Locator;
  public readonly comprehensiveCoverageFAQ: Locator;
  public readonly comprehensiveCoverageAmount: Locator;
  public readonly comprehensiveCoverageRefreshIcon: Locator;
  public readonly deathBenefitCoverageLabel: Locator;
  public readonly deathBenefitCoverageDropdown: Locator;
  public readonly deathBenefitCoverageFAQ: Locator;
  public readonly deathBenefitCoverageAmount: Locator;
  public readonly deathBenefitCoverageRefreshIcon: Locator;
  public readonly extraPIPPackageCoverageLabel: Locator;
  public readonly extraPIPPackageCoverageDropdown: Locator;
  public readonly extraPIPPackageCoverageFAQ: Locator;
  public readonly extraPIPPackageCoverageAmount: Locator;
  public readonly extraPIPPackageCoverageRefreshIcon: Locator;
  public readonly funeralExpensesCoverageLabel: Locator;
  public readonly funeralExpensesCoverageDropdown: Locator;
  public readonly funeralExpensesCoverageFAQ: Locator;
  public readonly funeralExpensesCoverageAmount: Locator;
  public readonly funeralExpensesCoverageRefreshIcon: Locator;
  public readonly glassDeductibleBuybackCoverageLabel: Locator;
  public readonly glassDeductibleBuybackCoverageDropdown: Locator;
  public readonly glassDeductibleBuybackCoverageFAQ: Locator;
  public readonly glassDeductibleBuybackCoverageAmount: Locator;
  public readonly glassDeductibleBuybackCoverageRefreshIcon: Locator;
  public readonly glassCoverage100Label: Locator;
  public readonly glassCoverage100Dropdown: Locator;
  public readonly glassCoverage100FAQ: Locator;
  public readonly glassCoverage100Amount: Locator;
  public readonly glassCoverage100RefreshIcon: Locator;
  public readonly glassCoverage100ErrorLabel: Locator;
  public readonly glassCoverage100ErrorMessage: Locator;
  public readonly healthInsurerPrimaryCoverageLabel: Locator;
  public readonly healthInsurerPrimaryCoverageDropdown: Locator;
  public readonly healthInsurerPrimaryCoverageFAQ: Locator;
  public readonly healthInsurerPrimaryCoverageAmount: Locator;
  public readonly healthInsurerPrimaryCoverageRefreshIcon: Locator;
  public readonly incomeDisabilityCoverageLabel: Locator;
  public readonly incomeDisabilityCoverageDropdown: Locator;
  public readonly incomeDisabilityCoverageFAQ: Locator;
  public readonly incomeDisabilityCoverageAmount: Locator;
  public readonly incomeDisabilityCoverageRefreshIcon: Locator;
  public readonly incomeLossCoverageLabel: Locator;
  public readonly incomeLossCoverageDropdown: Locator;
  public readonly incomeLossCoverageFAQ: Locator;
  public readonly incomeLossCoverageAmount: Locator;
  public readonly incomeLossCoverageRefreshIcon: Locator;
  public readonly lossOfUseCoverageLabel: Locator;
  public readonly lossOfUseCoverageDropdown: Locator;
  public readonly lossOfUseCoverageFAQ: Locator;
  public readonly lossOfUseCoverageAmount: Locator;
  public readonly lossOfUseCoverageRefreshIcon: Locator;
  public readonly medicalExpenseCoverageLabel: Locator;
  public readonly medicalExpenseCoverageDropdown: Locator;
  public readonly medicalExpenseCoverageFAQ: Locator;
  public readonly medicalExpenseCoverageAmount: Locator;
  public readonly medicalExpenseCoverageRefreshIcon: Locator;
  public readonly rentalCoverageLabel: Locator;
  public readonly rentalCoverageDropdown: Locator;
  public readonly rentalCoverageFAQ: Locator;
  public readonly rentalCoverageAmount: Locator;
  public readonly rentalCoverageRefreshIcon: Locator;
  public readonly rentalCoverageErrorLabel: Locator;
  public readonly rentalCoverageErrorMessage: Locator;
  public readonly rentalReimbursementCoverageLabel: Locator;
  public readonly rentalReimbursementCoverageDropdown: Locator;
  public readonly rentalReimbursementCoverageFAQ: Locator;
  public readonly rentalReimbursementCoverageAmount: Locator;
  public readonly rentalReimbursementCoverageRefreshIcon: Locator;
  public readonly rideshareCoverageLabel: Locator;
  public readonly rideshareCoverageDropdown: Locator;
  public readonly rideshareCoverageFAQ: Locator;
  public readonly rideshareCoverageAmount: Locator;
  public readonly rideshareCoverageRefreshIcon: Locator;
  public readonly rideshareAndFoodDeliveryCoverageLabel: Locator;
  public readonly rideshareAndFoodDeliveryCoverageDropdown: Locator;
  public readonly rideshareAndFoodDeliveryCoverageFAQ: Locator;
  public readonly rideshareAndFoodDeliveryCoverageAmount: Locator;
  public readonly rideshareAndFoodDeliveryCoverageRefreshIcon: Locator;
  public readonly roadsideAssistanceCoverageLabel: Locator;
  public readonly roadsideAssistanceCoverageDropdown: Locator;
  public readonly roadsideAssistanceCoverageFAQ: Locator;
  public readonly roadsideAssistanceCoverageAmount: Locator;
  public readonly roadsideAssistanceCoverageRefreshIcon: Locator;
  public readonly safetyGlassWaiverOfDeductibleCoverageLabel: Locator;
  public readonly safetyGlassWaiverOfDeductibleCoverageDropdown: Locator;
  public readonly safetyGlassWaiverOfDeductibleCoverageFAQ: Locator;
  public readonly safetyGlassWaiverOfDeductibleCoverageAmount: Locator;
  public readonly safetyGlassWaiverOfDeductibleCoverageRefreshIcon: Locator;
  public readonly towingAndRoadServiceCoverageLabel: Locator;
  public readonly towingAndRoadServiceCoverageDropdown: Locator;
  public readonly towingAndRoadServiceCoverageFAQ: Locator;
  public readonly towingAndRoadServiceCoverageAmount: Locator;
  public readonly towingAndRoadServiceCoverageRefreshIcon: Locator;
  public readonly towingAmpRoadServiceCoverageLabel: Locator;
  public readonly towingAmpRoadServiceCoverageDropdown: Locator;
  public readonly towingAmpRoadServiceCoverageFAQ: Locator;
  public readonly towingAmpRoadServiceCoverageAmount: Locator;
  public readonly towingAmpRoadServiceCoverageRefreshIcon: Locator;
  public readonly towingAndLaborCoverageLabel: Locator;
  public readonly towingAndLaborCoverageDropdown: Locator;
  public readonly towingAndLaborCoverageFAQ: Locator;
  public readonly towingAndLaborCoverageAmount: Locator;
  public readonly towingAndLaborCoverageRefreshIcon: Locator;
  public readonly towingAndLaborCostsCoverageLabel: Locator;
  public readonly towingAndLaborCostsCoverageDropdown: Locator;
  public readonly towingAndLaborCostsCoverageFAQ: Locator;
  public readonly towingAndLaborCostsCoverageAmount: Locator;
  public readonly towingAndLaborCostsCoverageRefreshIcon: Locator;
  public readonly uninsuredMotoristPDCoverageLabel: Locator;
  public readonly uninsuredMotoristPDCoverageDropdown: Locator;
  public readonly uninsuredMotoristPDCoverageFAQ: Locator;
  public readonly uninsuredMotoristPDCoverageAmount: Locator;
  public readonly uninsuredMotoristPDCoverageRefreshIcon: Locator;
  public readonly uninsuredMotoristPDCoverageErrorLabel: Locator;
  public readonly uninsuredMotoristPDCoverageErrorMessage: Locator;
  public readonly uninsuredMotoristPDWithoutUppercaseCollisionCoverageLabel: Locator;
  public readonly uninsuredMotoristPDWithoutUppercaseCollisionCoverageDropdown: Locator;
  public readonly uninsuredMotoristPDWithoutUppercaseCollisionCoverageFAQ: Locator;
  public readonly uninsuredMotoristPDWithoutUppercaseCollisionCoverageAmount: Locator;
  public readonly uninsuredMotoristPDWithoutUppercaseCollisionCoverageRefreshIcon: Locator;
  public readonly uninsuredMotoristPDWithoutUppercaseCollisionCoverageErrorLabel: Locator;
  public readonly uninsuredMotoristPDWithoutUppercaseCollisionCoverageErrorMessage: Locator;
  public readonly uninsuredMotoristPropertyDamageCoverageLabel: Locator;
  public readonly uninsuredMotoristPropertyDamageCoverageAlternateLabel: Locator;
  public readonly uninsuredMotoristPropertyDamageCoverageDropdown: Locator;
  public readonly uninsuredMotoristPropertyDamageCoverageAlternateDropdown: Locator;
  public readonly uninsuredMotoristPropertyDamageCoverageFAQ: Locator;
  public readonly uninsuredMotoristPropertyDamageCoverageAmount: Locator;
  public readonly uninsuredMotoristPropertyDamageCoverageRefreshIcon: Locator;
  public readonly uninsuredMotoristPropertyDamageCoverageErrorLabel: Locator;
  public readonly uninsuredMotoristPropertyDamageCoverageErrorMessage: Locator;
  public readonly uninsuredMotoristPropertyDamageWithoutCollisionCoverageLabel: Locator;
  public readonly uninsuredMotoristPropertyDamageWithoutCollisionCoverageDropdown: Locator;
  public readonly uninsuredMotoristPropertyDamageWithoutCollisionCoverageFAQ: Locator;
  public readonly uninsuredMotoristPropertyDamageWithoutCollisionCoverageAmount: Locator;
  public readonly uninsuredMotoristPropertyDamageWithoutCollisionCoverageRefreshIcon: Locator;
  public readonly uninsuredMotoristPropertyDamageWithoutCollisionCoverageErrorLabel: Locator;
  public readonly uninsuredMotoristPropertyDamageWithoutCollisionCoverageErrorMessage: Locator;
  public readonly uninsuredMotoristPropertyDamageWithCollisionCoverageLabel: Locator;
  public readonly uninsuredMotoristPropertyDamageWithCollisionCoverageDropdown: Locator;
  public readonly uninsuredMotoristPropertyDamageWithCollisionCoverageFAQ: Locator;
  public readonly uninsuredMotoristPropertyDamageWithCollisionCoverageAmount: Locator;
  public readonly uninsuredMotoristPropertyDamageWithCollisionCoverageRefreshIcon: Locator;
  public readonly vehicleReplacementCoverageLabel: Locator;
  public readonly vehicleReplacementCoverageDropdown: Locator;
  public readonly vehicleReplacementCoverageFAQ: Locator;
  public readonly vehicleReplacementCoverageAmount: Locator;
  public readonly vehicleReplacementCoverageRefreshIcon: Locator;
  public readonly vehicleReplacementCoverageErrorLabel: Locator;
  public readonly vehicleReplacementCoverageErrorMessage: Locator;
  public readonly waiverOfWorkLossCoverageLabel: Locator;
  public readonly waiverOfWorkLossCoverageDropdown: Locator;
  public readonly waiverOfWorkLossCoverageFAQ: Locator;
  public readonly waiverOfWorkLossCoverageAmount: Locator;
  public readonly waiverOfWorkLossCoverageRefreshIcon: Locator;
  public readonly compulsoryBodilyInjuryLiabilityLabel: Locator;
  public readonly compulsoryBodilyInjuryLiabilityDropdown: Locator;
  public readonly compulsoryBodilyInjuryLiabilityFAQ: Locator;
  public readonly compulsoryBodilyInjuryLiabilityAmount: Locator;
  public readonly compulsoryBodilyInjuryLiabilityRefreshIcon: Locator;
  public readonly optionalBodilyInjuryLiabilityLabel: Locator;
  public readonly optionalBodilyInjuryLiabilityDropdown: Locator;
  public readonly optionalBodilyInjuryLiabilityFAQ: Locator;
  public readonly optionalBodilyInjuryLiabilityAmount: Locator;
  public readonly optionalBodilyInjuryLiabilityRefreshIcon: Locator;
  public readonly propertyDamageMALabel: Locator;
  public readonly propertyDamageMADropdown: Locator;
  public readonly propertyDamageMAFAQ: Locator;
  public readonly propertyDamageMAAmount: Locator;
  public readonly propertyDamageMARefreshIcon: Locator;
  public readonly uninsuredMotoristBodilyInjuryMALiabilityLabel: Locator;
  public readonly uninsuredMotoristBodilyInjuryMALiabilityDropdown: Locator;
  public readonly uninsuredMotoristBodilyInjuryMALiabilityFAQ: Locator;
  public readonly uninsuredMotoristBodilyInjuryMALiabilityAmount: Locator;
  public readonly uninsuredMotoristBodilyInjuryMALiabilityRefreshIcon: Locator;
  public readonly underinsuredMotoristBodilyInjuryMALiabilityLabel: Locator;
  public readonly underinsuredMotoristBodilyInjuryMALiabilityDropdown: Locator;
  public readonly underinsuredMotoristBodilyInjuryMALiabilityFAQ: Locator;
  public readonly underinsuredMotoristBodilyInjuryMALiabilityAmount: Locator;
  public readonly underinsuredMotoristBodilyInjuryMALiabilityRefreshIcon: Locator;
  public readonly medicalPaymentsLiabilityLabel: Locator;
  public readonly medicalPaymentsLiabilityDropdown: Locator;
  public readonly medicalPaymentsLiabilityFAQ: Locator;
  public readonly medicalPaymentsLiabilityAmount: Locator;
  public readonly medicalPaymentsLiabilityRefreshIcon: Locator;
  public readonly medicalPaymentsLiabilityErrorLabel: Locator;
  public readonly medicalPaymentsLiabilityErrorMessage: Locator;
  public readonly personalInjuryProtectionMALiabilityLabel: Locator;
  public readonly personalInjuryProtectionMALiabilityDropdown: Locator;
  public readonly personalInjuryProtectionMALiabilityFAQ: Locator;
  public readonly personalInjuryProtectionMALiabilityAmount: Locator;
  public readonly personalInjuryProtectionMALiabilityRefreshIcon: Locator;
  public readonly personalInjuryProtectionDeductibleLiabilityLabel: Locator;
  public readonly personalInjuryProtectionDeductibleLiabilityDropdown: Locator;
  public readonly personalInjuryProtectionDeductibleLiabilityFAQ: Locator;
  public readonly personalInjuryProtectionDeductibleLiabilityAmount: Locator;
  public readonly personalInjuryProtectionDeductibleLiabilityRefreshIcon: Locator;
  public readonly comprehensiveMACoverageLabel: Locator;
  public readonly comprehensiveMACoverageDropdown: Locator;
  public readonly comprehensiveMACoverageFAQ: Locator;
  public readonly comprehensiveMACoverageAmount: Locator;
  public readonly comprehensiveMACoverageRefreshIcon: Locator;
  public readonly collisionMACoverageLabel: Locator;
  public readonly collisionMACoverageDropdown: Locator;
  public readonly collisionMACoverageFAQ: Locator;
  public readonly collisionMACoverageAmount: Locator;
  public readonly collisionMACoverageRefreshIcon: Locator;
  public readonly limitedCollisionCoverageLabel: Locator;
  public readonly limitedCollisionCoverageDropdown: Locator;
  public readonly limitedCollisionCoverageFAQ: Locator;
  public readonly limitedCollisionCoverageAmount: Locator;
  public readonly limitedCollisionCoverageRefreshIcon: Locator;
  public readonly towingAndLaborMACoverageLabel: Locator;
  public readonly towingAndLaborMACoverageDropdown: Locator;
  public readonly towingAndLaborMACoverageFAQ: Locator;
  public readonly towingAndLaborMACoverageAmount: Locator;
  public readonly towingAndLaborMACoverageRefreshIcon: Locator;
  public readonly substituteTransportationCoverageLabel: Locator;
  public readonly substituteTransportationCoverageDropdown: Locator;
  public readonly substituteTransportationCoverageFAQ: Locator;
  public readonly substituteTransportationCoverageAmount: Locator;
  public readonly substituteTransportationCoverageRefreshIcon: Locator;
  public readonly crossSellCondoQuote: Locator;
  public readonly crossSellHomeQuote: Locator;
  public readonly crossSellRentersQuote: Locator;
  public readonly crossSellVTLQuote: Locator;

  public constructor(page: Page) {
    super(page);
    this.quotePageHeader = page.locator("#auto-module_header-title"); // @FindBy(id = "auto-module_header-title")
    this.quotePageDescription = page.locator(".quote-module_title-description-text"); // @FindBy(className = "quote-module_title-description-text")
    this.packageHeader = page.locator("#auto-quote_header-title"); // @FindBy(id = "auto-quote_header-title")
    this.packageDescription = page.locator(".auto-quote-description-text"); // @FindBy(className = "auto-quote-description-text")
    this.viewAllPackagesLink = page.locator("[data-legacy-field=\"viewAllPackagesLink\"]"); // @FindBy(xpath = VIEW_ALL_PACKAGES_XPATH)
    this.buyNowButton = page.locator("[data-legacy-field=\"buyNowButton\"]"); // @FindBy(xpath = ACTION_BUTTON_XPATH)
    this.quoteRentersButton = page.locator("#auto-quote-renters_quoteBtn"); // @FindBy(id = "auto-quote-renters_quoteBtn")
    this.quoteRentersProgressPopup = page.locator("[data-legacy-field=\"quoteRentersProgressPopup\"]"); // @FindBy(className = QUOTE_RENTERS_PROGRESS_POPUP_CLASSNAME)
    this.rentersQuoteSummaryHeader = page.locator("#summaryquoteSmall"); // @FindBy(id = "summaryquoteSmall")
    this.quoteAmountField = page.locator("#auto-quote_coverageInfoPckAmtSpan"); // @FindBy(id = "auto-quote_coverageInfoPckAmtSpan")
    this.quoteAmountFieldStruckthrough = page.locator(".auto-quote-red-line"); // @FindBy(className = "auto-quote-red-line")
    this.quotePeriodField = page.locator("#auto-quote_coverageInfoPCkDura"); // @FindBy(id = "auto-quote_coverageInfoPCkDura")
    this.membershipFee = page.locator("#auto-quote-policyFee"); // @FindBy(id = "auto-quote-policyFee")
    this.discountsListHeader = page.locator(".auto__quote-your-discounts-header"); // @FindBy(className = "auto__quote-your-discounts-header")
    this.listOfDiscounts = page.locator(".auto__quote-your-discounts-text"); // @FindBy(className = "auto__quote-your-discounts-text")
    this.disclosureLabel = page.locator("xpath=//div[@id='auto-module__quote-card-text-disclaimer']/label"); // @FindBy(xpath = "//div[@id='auto-module__quote-card-text-disclaimer']/label")
    this.quotePageDisclosure1 = page.locator("xpath=//p[contains(@id, 'service-fee-disclaimer1')]"); // @FindBy(xpath = "//p[contains(@id, 'service-fee-disclaimer1')]")
    this.quotePageRentersDisclosure = page.locator("#service-fee-disclaimer2"); // @FindBy(id = "service-fee-disclaimer2")
    this.quotePageDisclosure2 = page.locator("xpath=//div[@class='disclaimer_txt']//p[contains(text(), 'BristolWest')]"); // @FindBy(xpath = "//div[@class='disclaimer_txt']//p[contains(text(), 'BristolWest')]")
    this.quotePageDisclosure3 = page.locator("xpath=//p[contains(@id,'FFQAuto_Quote_legalDisclosure3')]"); // @FindBy(xpath = "//p[contains(@id,'FFQAuto_Quote_legalDisclosure3')]")
    this.liabilityCoverageHeader = page.locator("xpath=//div[@class='ffq-quote-liability-coverages-containter']/lib-coverage-panel/mat-accordion/mat-expansion-panel/mat-expansion-panel-header/span/mat-panel-title/div/div[@class='ffq-coverage-panel-coverage-heading']"); // @FindBy(xpath = "//div[@class='ffq-quote-liability-coverages-containter']/lib-coverage-panel/mat-accordion/mat-expansion-panel/mat-expansion-panel-header/span/mat-panel-title/div/div[@class='ffq-coverage-panel-coverage-heading']")
    this.liabilityCoverageHeaderButton = page.locator("xpath=//div[@class='ffq-quote-liability-coverages-containter']/lib-coverage-panel/mat-accordion/mat-expansion-panel"); // @FindBy(xpath = "//div[@class='ffq-quote-liability-coverages-containter']/lib-coverage-panel/mat-accordion/mat-expansion-panel")
    this.vehicleCoveragesHeaderButton = page.locator("xpath=//form/lib-coverage-panel/mat-accordion/mat-expansion-panel"); // @FindBy(xpath = "//form/lib-coverage-panel/mat-accordion/mat-expansion-panel")
    this.minimizeChatbotDialog = page.locator("#minLogo"); // @FindBy(id = "minLogo")
    this.basicCoveragePackage = page.locator("[data-legacy-field=\"basicCoveragePackage\"]"); // @FindBy(xpath = COVERAGE_PACKAGE_XPATH + BASIC_COVERAGE_PACKAGE)
    this.enhancedCoveragePackage = page.locator("[data-legacy-field=\"enhancedCoveragePackage\"]"); // @FindBy(xpath = COVERAGE_PACKAGE_XPATH + ENHANCED_COVERAGE_PACKAGE)
    this.fullCoveragePackage = page.locator("[data-legacy-field=\"fullCoveragePackage\"]"); // @FindBy(xpath = COVERAGE_PACKAGE_XPATH + FULL_COVERAGE_PACKAGE)
    this.customCoveragePackage = page.locator("[data-legacy-field=\"customCoveragePackage\"]"); // @FindBy(xpath = COVERAGE_PACKAGE_XPATH + CUSTOM_COVERAGE_PACKAGE)
    this.cancelButton = page.locator("xpath=//button[@aria-label='Cancel']"); // @FindBy(xpath = "//button[@aria-label='Cancel']")
    this.confirmButton = page.locator("xpath=//button[@aria-label='Confirm']"); // @FindBy(xpath = "//button[@aria-label='Confirm']")
    this.accidentalDeathLiabilityLabel = page.locator("[data-legacy-field=\"accidentalDeathLiabilityLabel\"]"); // @FindBy(xpath = ACCIDENTAL_DEATH_FAQ_XPATH + XPATH_TO_LABEL)
    this.accidentalDeathLiabilityDropdown = page.locator("[data-legacy-field=\"accidentalDeathLiabilityDropdown\"]"); // @FindBy(xpath = ACCIDENTAL_DEATH_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.accidentalDeathLiabilityFAQ = page.locator("[data-legacy-field=\"accidentalDeathLiabilityFAQ\"]"); // @FindBy(xpath = ACCIDENTAL_DEATH_FAQ_XPATH)
    this.accidentalDeathLiabilityAmount = page.locator("[data-legacy-field=\"accidentalDeathLiabilityAmount\"]"); // @FindBy(xpath = ACCIDENTAL_DEATH_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.accidentalDeathLiabilityRefreshIcon = page.locator("[data-legacy-field=\"accidentalDeathLiabilityRefreshIcon\"]"); // @FindBy(xpath = ACCIDENTAL_DEATH_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.accidentalDeathBenefitsLiabilityLabel = page.locator("[data-legacy-field=\"accidentalDeathBenefitsLiabilityLabel\"]"); // @FindBy(xpath = ADB_FAQ_XPATH + XPATH_TO_LABEL)
    this.accidentalDeathBenefitsLiabilityDropdown = page.locator("[data-legacy-field=\"accidentalDeathBenefitsLiabilityDropdown\"]"); // @FindBy(xpath = ADB_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.accidentalDeathBenefitsLiabilityFAQ = page.locator("[data-legacy-field=\"accidentalDeathBenefitsLiabilityFAQ\"]"); // @FindBy(xpath = ADB_FAQ_XPATH)
    this.accidentalDeathBenefitsLiabilityAmount = page.locator("[data-legacy-field=\"accidentalDeathBenefitsLiabilityAmount\"]"); // @FindBy(xpath = ADB_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.accidentalDeathBenefitsLiabilityRefreshIcon = page.locator("[data-legacy-field=\"accidentalDeathBenefitsLiabilityRefreshIcon\"]"); // @FindBy(xpath = ADB_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.bodilyInjuryLiabilityLabel = page.locator("[data-legacy-field=\"bodilyInjuryLiabilityLabel\"]"); // @FindBy(xpath = BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
    this.bodilyInjuryLiabilityDropdown = page.locator("[data-legacy-field=\"bodilyInjuryLiabilityDropdown\"]"); // @FindBy(xpath = BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.bodilyInjuryLiabilityFAQ = page.locator("[data-legacy-field=\"bodilyInjuryLiabilityFAQ\"]"); // @FindBy(xpath = BODILY_INJURY_FAQ_XPATH)
    this.bodilyInjuryLiabilityAmount = page.locator("[data-legacy-field=\"bodilyInjuryLiabilityAmount\"]"); // @FindBy(xpath = BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.bodilyInjuryLiabilityRefreshIcon = page.locator("[data-legacy-field=\"bodilyInjuryLiabilityRefreshIcon\"]"); // @FindBy(xpath = BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.bodilyInjuryLiabilityErrorLabel = page.locator("[data-legacy-field=\"bodilyInjuryLiabilityErrorLabel\"]"); // @FindBy(xpath = BODILY_INJURY_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.bodilyInjuryLiabilityErrorMessage = page.locator("[data-legacy-field=\"bodilyInjuryLiabilityErrorMessage\"]"); // @FindBy(xpath = BODILY_INJURY_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.essentialServicesLiabilityLabel = page.locator("[data-legacy-field=\"essentialServicesLiabilityLabel\"]"); // @FindBy(xpath = ESSENTIAL_SERVICES_FAQ_XPATH + XPATH_TO_LABEL)
    this.essentialServicesLiabilityDropdown = page.locator("[data-legacy-field=\"essentialServicesLiabilityDropdown\"]"); // @FindBy(xpath = ESSENTIAL_SERVICES_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.essentialServicesLiabilityFAQ = page.locator("[data-legacy-field=\"essentialServicesLiabilityFAQ\"]"); // @FindBy(xpath = ESSENTIAL_SERVICES_FAQ_XPATH)
    this.essentialServicesLiabilityAmount = page.locator("[data-legacy-field=\"essentialServicesLiabilityAmount\"]"); // @FindBy(xpath = ESSENTIAL_SERVICES_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.essentialServicesLiabilityRefreshIcon = page.locator("[data-legacy-field=\"essentialServicesLiabilityRefreshIcon\"]"); // @FindBy(xpath = ESSENTIAL_SERVICES_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.extendedMedicalPaymentsLiabilityLabel = page.locator("[data-legacy-field=\"extendedMedicalPaymentsLiabilityLabel\"]"); // @FindBy(xpath = EXTENDED_MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_LABEL)
    this.extendedMedicalPaymentsLiabilityDropdown = page.locator("[data-legacy-field=\"extendedMedicalPaymentsLiabilityDropdown\"]"); // @FindBy(xpath = EXTENDED_MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.extendedMedicalPaymentsLiabilityFAQ = page.locator("[data-legacy-field=\"extendedMedicalPaymentsLiabilityFAQ\"]"); // @FindBy(xpath = EXTENDED_MEDICAL_PAYMENTS_FAQ_XPATH)
    this.extendedMedicalPaymentsLiabilityAmount = page.locator("[data-legacy-field=\"extendedMedicalPaymentsLiabilityAmount\"]"); // @FindBy(xpath = EXTENDED_MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.extendedMedicalPaymentsLiabilityRefreshIcon = page.locator("[data-legacy-field=\"extendedMedicalPaymentsLiabilityRefreshIcon\"]"); // @FindBy(xpath = EXTENDED_MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.extraPIPPackageLiabilityLabel = page.locator("[data-legacy-field=\"extraPIPPackageLiabilityLabel\"]"); // @FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH + XPATH_TO_LABEL)
    this.extraPIPPackageLiabilityDropdown = page.locator("[data-legacy-field=\"extraPIPPackageLiabilityDropdown\"]"); // @FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.extraPIPPackageLiabilityFAQ = page.locator("[data-legacy-field=\"extraPIPPackageLiabilityFAQ\"]"); // @FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH)
    this.extraPIPPackageLiabilityAmount = page.locator("[data-legacy-field=\"extraPIPPackageLiabilityAmount\"]"); // @FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.extraPIPPackageLiabilityRefreshIcon = page.locator("[data-legacy-field=\"extraPIPPackageLiabilityRefreshIcon\"]"); // @FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.extraPIPPackageLiabilityErrorLabel = page.locator("[data-legacy-field=\"extraPIPPackageLiabilityErrorLabel\"]"); // @FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.extraPIPPackageLiabilityErrorMessage = page.locator("[data-legacy-field=\"extraPIPPackageLiabilityErrorMessage\"]"); // @FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.funeralExpenseBenefitsLiabilityLabel = page.locator("[data-legacy-field=\"funeralExpenseBenefitsLiabilityLabel\"]"); // @FindBy(xpath = FUNERAL_EXPENSE_BENEFITS_FAQ_XPATH + XPATH_TO_LABEL)
    this.funeralExpenseBenefitsLiabilityDropdown = page.locator("[data-legacy-field=\"funeralExpenseBenefitsLiabilityDropdown\"]"); // @FindBy(xpath = FUNERAL_EXPENSE_BENEFITS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.funeralExpenseBenefitsLiabilityFAQ = page.locator("[data-legacy-field=\"funeralExpenseBenefitsLiabilityFAQ\"]"); // @FindBy(xpath = FUNERAL_EXPENSE_BENEFITS_FAQ_XPATH)
    this.funeralExpenseBenefitsLiabilityAmount = page.locator("[data-legacy-field=\"funeralExpenseBenefitsLiabilityAmount\"]"); // @FindBy(xpath = FUNERAL_EXPENSE_BENEFITS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.funeralExpenseBenefitsLiabilityRefreshIcon = page.locator("[data-legacy-field=\"funeralExpenseBenefitsLiabilityRefreshIcon\"]"); // @FindBy(xpath = FUNERAL_EXPENSE_BENEFITS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.guestPIPLiabilityLabel = page.locator("[data-legacy-field=\"guestPIPLiabilityLabel\"]"); // @FindBy(xpath = GUEST_PIP_FAQ_XPATH + XPATH_TO_LABEL)
    this.guestPIPLiabilityDropdown = page.locator("[data-legacy-field=\"guestPIPLiabilityDropdown\"]"); // @FindBy(xpath = GUEST_PIP_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.guestPIPLiabilityFAQ = page.locator("[data-legacy-field=\"guestPIPLiabilityFAQ\"]"); // @FindBy(xpath = GUEST_PIP_FAQ_XPATH)
    this.guestPIPLiabilityAmount = page.locator("[data-legacy-field=\"guestPIPLiabilityAmount\"]"); // @FindBy(xpath = GUEST_PIP_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.guestPIPLiabilityRefreshIcon = page.locator("[data-legacy-field=\"guestPIPLiabilityRefreshIcon\"]"); // @FindBy(xpath = GUEST_PIP_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.incomeContinuationLiabilityLabel = page.locator("[data-legacy-field=\"incomeContinuationLiabilityLabel\"]"); // @FindBy(xpath = INCOME_CONTINUATION_FAQ_XPATH + XPATH_TO_LABEL)
    this.incomeContinuationLiabilityDropdown = page.locator("[data-legacy-field=\"incomeContinuationLiabilityDropdown\"]"); // @FindBy(xpath = INCOME_CONTINUATION_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.incomeContinuationLiabilityFAQ = page.locator("[data-legacy-field=\"incomeContinuationLiabilityFAQ\"]"); // @FindBy(xpath = INCOME_CONTINUATION_FAQ_XPATH)
    this.incomeContinuationLiabilityAmount = page.locator("[data-legacy-field=\"incomeContinuationLiabilityAmount\"]"); // @FindBy(xpath = INCOME_CONTINUATION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.incomeContinuationLiabilityRefreshIcon = page.locator("[data-legacy-field=\"incomeContinuationLiabilityRefreshIcon\"]"); // @FindBy(xpath = INCOME_CONTINUATION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.lawsuitOptionLiabilityLabel = page.locator("[data-legacy-field=\"lawsuitOptionLiabilityLabel\"]"); // @FindBy(xpath = LAWSUIT_OPTION_FAQ_XPATH + XPATH_TO_LABEL)
    this.lawsuitOptionLiabilityDropdown = page.locator("[data-legacy-field=\"lawsuitOptionLiabilityDropdown\"]"); // @FindBy(xpath = LAWSUIT_OPTION_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.lawsuitOptionLiabilityFAQ = page.locator("[data-legacy-field=\"lawsuitOptionLiabilityFAQ\"]"); // @FindBy(xpath = LAWSUIT_OPTION_FAQ_XPATH)
    this.lawsuitOptionLiabilityAmount = page.locator("[data-legacy-field=\"lawsuitOptionLiabilityAmount\"]"); // @FindBy(xpath = LAWSUIT_OPTION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.lawsuitOptionLiabilityRefreshIcon = page.locator("[data-legacy-field=\"lawsuitOptionLiabilityRefreshIcon\"]"); // @FindBy(xpath = LAWSUIT_OPTION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.medicalLiabilityLabel = page.locator("[data-legacy-field=\"medicalLiabilityLabel\"]"); // @FindBy(xpath = MEDICAL_FAQ_XPATH + XPATH_TO_LABEL)
    this.medicalLiabilityDropdown = page.locator("[data-legacy-field=\"medicalLiabilityDropdown\"]"); // @FindBy(xpath = MEDICAL_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.medicalLiabilityFAQ = page.locator("[data-legacy-field=\"medicalLiabilityFAQ\"]"); // @FindBy(xpath = MEDICAL_FAQ_XPATH)
    this.medicalLiabilityAmount = page.locator("[data-legacy-field=\"medicalLiabilityAmount\"]"); // @FindBy(xpath = MEDICAL_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.medicalLiabilityRefreshIcon = page.locator("[data-legacy-field=\"medicalLiabilityRefreshIcon\"]"); // @FindBy(xpath = MEDICAL_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.medicalLiabilityErrorLabel = page.locator("[data-legacy-field=\"medicalLiabilityErrorLabel\"]"); // @FindBy(xpath = MEDICAL_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.medicalLiabilityErrorMessage = page.locator("[data-legacy-field=\"medicalLiabilityErrorMessage\"]"); // @FindBy(xpath = MEDICAL_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.medicalAndHospitalLiabilityLabel = page.locator("[data-legacy-field=\"medicalAndHospitalLiabilityLabel\"]"); // @FindBy(xpath = MEDICAL_AND_HOSPITAL_FAQ_XPATH + XPATH_TO_LABEL)
    this.medicalAndHospitalLiabilityDropdown = page.locator("[data-legacy-field=\"medicalAndHospitalLiabilityDropdown\"]"); // @FindBy(xpath = MEDICAL_AND_HOSPITAL_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.medicalAndHospitalLiabilityFAQ = page.locator("[data-legacy-field=\"medicalAndHospitalLiabilityFAQ\"]"); // @FindBy(xpath = MEDICAL_AND_HOSPITAL_FAQ_XPATH)
    this.medicalAndHospitalLiabilityAmount = page.locator("[data-legacy-field=\"medicalAndHospitalLiabilityAmount\"]"); // @FindBy(xpath = MEDICAL_AND_HOSPITAL_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.medicalAndHospitalLiabilityRefreshIcon = page.locator("[data-legacy-field=\"medicalAndHospitalLiabilityRefreshIcon\"]"); // @FindBy(xpath = MEDICAL_AND_HOSPITAL_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.medicalCoverageLiabilityLabel = page.locator("[data-legacy-field=\"medicalCoverageLiabilityLabel\"]"); // @FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH + XPATH_TO_LABEL)
    this.medicalCoverageLiabilityDropdown = page.locator("[data-legacy-field=\"medicalCoverageLiabilityDropdown\"]"); // @FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.medicalCoverageLiabilityFAQ = page.locator("[data-legacy-field=\"medicalCoverageLiabilityFAQ\"]"); // @FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH)
    this.medicalCoverageLiabilityAmount = page.locator("[data-legacy-field=\"medicalCoverageLiabilityAmount\"]"); // @FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.medicalCoverageLiabilityRefreshIcon = page.locator("[data-legacy-field=\"medicalCoverageLiabilityRefreshIcon\"]"); // @FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.medicalCoverageLiabilityErrorLabel = page.locator("[data-legacy-field=\"medicalCoverageLiabilityErrorLabel\"]"); // @FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.medicalCoverageLiabilityErrorMessage = page.locator("[data-legacy-field=\"medicalCoverageLiabilityErrorMessage\"]"); // @FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.medicalExpenseLabel = page.locator("[data-legacy-field=\"medicalExpenseLabel\"]"); // @FindBy(xpath = MEDICAL_EXPENSE_FAQ_XPATH + XPATH_TO_LABEL)
    this.medicalExpenseDropdown = page.locator("[data-legacy-field=\"medicalExpenseDropdown\"]"); // @FindBy(xpath = MEDICAL_EXPENSE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.medicalExpenseFAQ = page.locator("[data-legacy-field=\"medicalExpenseFAQ\"]"); // @FindBy(xpath = MEDICAL_EXPENSE_FAQ_XPATH)
    this.medicalExpenseAmount = page.locator("[data-legacy-field=\"medicalExpenseAmount\"]"); // @FindBy(xpath = MEDICAL_EXPENSE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.medicalExpenseRefreshIcon = page.locator("[data-legacy-field=\"medicalExpenseRefreshIcon\"]"); // @FindBy(xpath = MEDICAL_EXPENSE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.optionalPIPLiabilityLabel = page.locator("[data-legacy-field=\"optionalPIPLiabilityLabel\"]"); // @FindBy(xpath = OPTIONAL_PIP_FAQ_XPATH + XPATH_TO_LABEL)
    this.optionalPIPLiabilityDropdown = page.locator("[data-legacy-field=\"optionalPIPLiabilityDropdown\"]"); // @FindBy(xpath = OPTIONAL_PIP_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.optionalPIPLiabilityFAQ = page.locator("[data-legacy-field=\"optionalPIPLiabilityFAQ\"]"); // @FindBy(xpath = OPTIONAL_PIP_FAQ_XPATH)
    this.optionalPIPLiabilityAmount = page.locator("[data-legacy-field=\"optionalPIPLiabilityAmount\"]"); // @FindBy(xpath = OPTIONAL_PIP_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.optionalPIPLiabilityRefreshIcon = page.locator("[data-legacy-field=\"optionalPIPLiabilityRefreshIcon\"]"); // @FindBy(xpath = OPTIONAL_PIP_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.permissiveUserLimitLiabilityLabel = page.locator("[data-legacy-field=\"permissiveUserLimitLiabilityLabel\"]"); // @FindBy(xpath = PERMISSIVE_USER_LIMIT_FAQ_XPATH + XPATH_TO_LABEL)
    this.permissiveUserLimitLiabilityDropdown = page.locator("[data-legacy-field=\"permissiveUserLimitLiabilityDropdown\"]"); // @FindBy(xpath = PERMISSIVE_USER_LIMIT_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.permissiveUserLimitLiabilityFAQ = page.locator("[data-legacy-field=\"permissiveUserLimitLiabilityFAQ\"]"); // @FindBy(xpath = PERMISSIVE_USER_LIMIT_FAQ_XPATH)
    this.permissiveUserLimitLiabilityAmount = page.locator("[data-legacy-field=\"permissiveUserLimitLiabilityAmount\"]"); // @FindBy(xpath = PERMISSIVE_USER_LIMIT_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.permissiveUserLimitLiabilityRefreshIcon = page.locator("[data-legacy-field=\"permissiveUserLimitLiabilityRefreshIcon\"]"); // @FindBy(xpath = PERMISSIVE_USER_LIMIT_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.personalInjuryProtectionLiabilityLabel = page.locator("[data-legacy-field=\"personalInjuryProtectionLiabilityLabel\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_FAQ_XPATH + XPATH_TO_LABEL)
    this.personalInjuryProtectionLiabilityDropdown = page.locator("[data-legacy-field=\"personalInjuryProtectionLiabilityDropdown\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.personalInjuryProtectionLiabilityFAQ = page.locator("[data-legacy-field=\"personalInjuryProtectionLiabilityFAQ\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_FAQ_XPATH)
    this.personalInjuryProtectionLiabilityAmount = page.locator("[data-legacy-field=\"personalInjuryProtectionLiabilityAmount\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.personalInjuryProtectionLiabilityRefreshIcon = page.locator("[data-legacy-field=\"personalInjuryProtectionLiabilityRefreshIcon\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.personalInjuryProtectionExclusionLiabilityLabel = page.locator("[data-legacy-field=\"personalInjuryProtectionExclusionLiabilityLabel\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_EXCLUSION_FAQ_XPATH + XPATH_TO_LABEL)
    this.personalInjuryProtectionExclusionLiabilityDropdown = page.locator("[data-legacy-field=\"personalInjuryProtectionExclusionLiabilityDropdown\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_EXCLUSION_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.personalInjuryProtectionExclusionLiabilityFAQ = page.locator("[data-legacy-field=\"personalInjuryProtectionExclusionLiabilityFAQ\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_EXCLUSION_FAQ_XPATH)
    this.personalInjuryProtectionExclusionLiabilityAmount = page.locator("[data-legacy-field=\"personalInjuryProtectionExclusionLiabilityAmount\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_EXCLUSION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.personalInjuryProtectionExclusionLiabilityRefreshIcon = page.locator("[data-legacy-field=\"personalInjuryProtectionExclusionLiabilityRefreshIcon\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_EXCLUSION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.personalInjuryProtectionDeductibleAppliesToLiabilityLabel = page.locator("[data-legacy-field=\"personalInjuryProtectionDeductibleAppliesToLiabilityLabel\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO_FAQ_XPATH + XPATH_TO_LABEL)
    this.personalInjuryProtectionDeductibleAppliesToLiabilityDropdown = page.locator("[data-legacy-field=\"personalInjuryProtectionDeductibleAppliesToLiabilityDropdown\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.personalInjuryProtectionDeductibleAppliesToLiabilityFAQ = page.locator("[data-legacy-field=\"personalInjuryProtectionDeductibleAppliesToLiabilityFAQ\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO_FAQ_XPATH)
    this.personalInjuryProtectionDeductibleAppliesToLiabilityAmount = page.locator("[data-legacy-field=\"personalInjuryProtectionDeductibleAppliesToLiabilityAmount\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.personalInjuryProtectionDeductibleAppliesToLiabilityRefreshIcon = page.locator("[data-legacy-field=\"personalInjuryProtectionDeductibleAppliesToLiabilityRefreshIcon\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.principalPIPLiabilityLabel = page.locator("[data-legacy-field=\"principalPIPLiabilityLabel\"]"); // @FindBy(xpath = PRINCIPAL_PIP_FAQ_XPATH + XPATH_TO_LABEL)
    this.principalPIPLiabilityDropdown = page.locator("[data-legacy-field=\"principalPIPLiabilityDropdown\"]"); // @FindBy(xpath = PRINCIPAL_PIP_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.principalPIPLiabilityFAQ = page.locator("[data-legacy-field=\"principalPIPLiabilityFAQ\"]"); // @FindBy(xpath = PRINCIPAL_PIP_FAQ_XPATH)
    this.principalPIPLiabilityAmount = page.locator("[data-legacy-field=\"principalPIPLiabilityAmount\"]"); // @FindBy(xpath = PRINCIPAL_PIP_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.principalPIPLiabilityRefreshIcon = page.locator("[data-legacy-field=\"principalPIPLiabilityRefreshIcon\"]"); // @FindBy(xpath = PRINCIPAL_PIP_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.principalPIPMedicalExpensesLiabilityLabel = page.locator("[data-legacy-field=\"principalPIPMedicalExpensesLiabilityLabel\"]"); // @FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH + XPATH_TO_LABEL)
    this.principalPIPMedicalExpensesLiabilityDropdown = page.locator("[data-legacy-field=\"principalPIPMedicalExpensesLiabilityDropdown\"]"); // @FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.principalPIPMedicalExpensesLiabilityFAQ = page.locator("[data-legacy-field=\"principalPIPMedicalExpensesLiabilityFAQ\"]"); // @FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH)
    this.principalPIPMedicalExpensesLiabilityAmount = page.locator("[data-legacy-field=\"principalPIPMedicalExpensesLiabilityAmount\"]"); // @FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.principalPIPMedicalExpensesLiabilityRefreshIcon = page.locator("[data-legacy-field=\"principalPIPMedicalExpensesLiabilityRefreshIcon\"]"); // @FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.principalPIPMedicalExpensesLiabilityErrorLabel = page.locator("[data-legacy-field=\"principalPIPMedicalExpensesLiabilityErrorLabel\"]"); // @FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.principalPIPMedicalExpensesLiabilityErrorMessage = page.locator("[data-legacy-field=\"principalPIPMedicalExpensesLiabilityErrorMessage\"]"); // @FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.propertyDamageLiabilityLabel = page.locator("[data-legacy-field=\"propertyDamageLiabilityLabel\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH + XPATH_TO_LABEL)
    this.propertyDamageLiabilityDropdown = page.locator("[data-legacy-field=\"propertyDamageLiabilityDropdown\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.propertyDamageLiabilityFAQ = page.locator("[data-legacy-field=\"propertyDamageLiabilityFAQ\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH)
    this.propertyDamageLiabilityAmount = page.locator("[data-legacy-field=\"propertyDamageLiabilityAmount\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.propertyDamageLiabilityRefreshIcon = page.locator("[data-legacy-field=\"propertyDamageLiabilityRefreshIcon\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.propertyDamageLiabilityErrorLabel = page.locator("[data-legacy-field=\"propertyDamageLiabilityErrorLabel\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.propertyDamageLiabilityErrorMessage = page.locator("[data-legacy-field=\"propertyDamageLiabilityErrorMessage\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.propertyDamageLabel = page.locator("[data-legacy-field=\"propertyDamageLabel\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL)
    this.propertyDamageDropdown = page.locator("[data-legacy-field=\"propertyDamageDropdown\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.propertyDamageFAQ = page.locator("[data-legacy-field=\"propertyDamageFAQ\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH)
    this.propertyDamageAmount = page.locator("[data-legacy-field=\"propertyDamageAmount\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.propertyDamageRefreshIcon = page.locator("[data-legacy-field=\"propertyDamageRefreshIcon\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.propertyDamageErrorLabel = page.locator("[data-legacy-field=\"propertyDamageErrorLabel\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.propertyDamageErrorMessage = page.locator("[data-legacy-field=\"propertyDamageErrorMessage\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.tortLiabilityLabel = page.locator("[data-legacy-field=\"tortLiabilityLabel\"]"); // @FindBy(xpath = TORT_FAQ_XPATH + XPATH_TO_LABEL)
    this.tortLiabilityDropdown = page.locator("[data-legacy-field=\"tortLiabilityDropdown\"]"); // @FindBy(xpath = TORT_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.tortLiabilityFAQ = page.locator("[data-legacy-field=\"tortLiabilityFAQ\"]"); // @FindBy(xpath = TORT_FAQ_XPATH)
    this.tortLiabilityAmount = page.locator("[data-legacy-field=\"tortLiabilityAmount\"]"); // @FindBy(xpath = TORT_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.tortLiabilityRefreshIcon = page.locator("[data-legacy-field=\"tortLiabilityRefreshIcon\"]"); // @FindBy(xpath = TORT_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.underSpaceInsuredMotoristBodilyInjuryLiabilityLabel = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristBodilyInjuryLiabilityLabel\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
    this.underSpaceInsuredMotoristBodilyInjuryLiabilityDropdown = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristBodilyInjuryLiabilityDropdown\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.underSpaceInsuredMotoristBodilyInjuryLiabilityFAQ = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristBodilyInjuryLiabilityFAQ\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH)
    this.underSpaceInsuredMotoristBodilyInjuryLiabilityAmount = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristBodilyInjuryLiabilityAmount\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.underSpaceInsuredMotoristBodilyInjuryLiabilityRefreshIcon = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristBodilyInjuryLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.underinsuredMotoristBodilyInjuryStackingOptionLiabilityLabel = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryStackingOptionLiabilityLabel\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_LABEL)
    this.underinsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.underinsuredMotoristBodilyInjuryStackingOptionLiabilityFAQ = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryStackingOptionLiabilityFAQ\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH)
    this.underinsuredMotoristBodilyInjuryStackingOptionLiabilityAmount = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryStackingOptionLiabilityAmount\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.underinsuredMotoristBodilyInjuryStackingOptionLiabilityRefreshIcon = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryStackingOptionLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.underinsuredMotoristBodilyInjuryStackingOptionLiabilityErrorLabel = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryStackingOptionLiabilityErrorLabel\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.underinsuredMotoristBodilyInjuryStackingOptionLiabilityErrorMessage = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryStackingOptionLiabilityErrorMessage\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.underSpaceInsuredMotoristPropertyDamageLiabilityLabel = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristPropertyDamageLiabilityLabel\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL)
    this.underSpaceInsuredMotoristPropertyDamageLiabilityDropdown = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristPropertyDamageLiabilityDropdown\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.underSpaceInsuredMotoristPropertyDamageLiabilityFAQ = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristPropertyDamageLiabilityFAQ\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH)
    this.underSpaceInsuredMotoristPropertyDamageLiabilityAmount = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristPropertyDamageLiabilityAmount\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.underSpaceInsuredMotoristPropertyDamageLiabilityRefreshIcon = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristPropertyDamageLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristBodilyInjuryStackingLiabilityLabel = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryStackingLiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredMotoristBodilyInjuryStackingLiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryStackingLiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredMotoristBodilyInjuryStackingLiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryStackingLiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_FAQ_XPATH)
    this.uninsuredMotoristBodilyInjuryStackingLiabilityAmount = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryStackingLiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredMotoristBodilyInjuryStackingLiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryStackingLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristBodilyInjuryStackingOptionLiabilityLabel = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryStackingOptionLiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_LABEL_XPATH)
    this.uninsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_LABEL_XPATH + "/../..//div[contains(@class, 'ffq-coverage-items-dropdown')]/lib-select/mat-form-field/div/div/div/mat-select")
    this.uninsuredMotoristBodilyInjuryStackingOptionLiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryStackingOptionLiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_LABEL_XPATH)
    this.uninsuredMotoristBodilyInjuryWithoutStackingLiabilityLabel = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryWithoutStackingLiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredMotoristBodilyInjuryWithoutStackingLiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryWithoutStackingLiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredMotoristBodilyInjuryWithoutStackingLiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryWithoutStackingLiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_FAQ_XPATH)
    this.uninsuredMotoristBodilyInjuryWithoutStackingLiabilityAmount = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryWithoutStackingLiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredMotoristBodilyInjuryWithoutStackingLiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryWithoutStackingLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristLiabilityLabel = page.locator("[data-legacy-field=\"uninsuredMotoristLiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredMotoristLiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristLiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredMotoristLiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristLiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH)
    this.uninsuredMotoristLiabilityAmount = page.locator("[data-legacy-field=\"uninsuredMotoristLiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredMotoristLiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredMotoristLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristLiabilityErrorLabel = page.locator("[data-legacy-field=\"uninsuredMotoristLiabilityErrorLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.uninsuredMotoristLiabilityErrorMessage = page.locator("[data-legacy-field=\"uninsuredMotoristLiabilityErrorMessage\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.uninsuredMotoristNYLiabilityLabel = page.locator("[data-legacy-field=\"uninsuredMotoristNYLiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredMotoristNYLiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristNYLiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredMotoristNYLiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristNYLiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH)
    this.uninsuredMotoristNYLiabilityAmount = page.locator("[data-legacy-field=\"uninsuredMotoristNYLiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredMotoristNYLiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredMotoristNYLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristNYLiabilityErrorLabel = page.locator("[data-legacy-field=\"uninsuredMotoristNYLiabilityErrorLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.uninsuredMotoristNYLiabilityErrorMessage = page.locator("[data-legacy-field=\"uninsuredMotoristNYLiabilityErrorMessage\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.underSpaceInsuredMotoristLiabilityLabel = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristLiabilityLabel\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH + XPATH_TO_LABEL)
    this.underSpaceInsuredMotoristLiabilityDropdown = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristLiabilityDropdown\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.underSpaceInsuredMotoristLiabilityFAQ = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristLiabilityFAQ\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH)
    this.underSpaceInsuredMotoristLiabilityAmount = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristLiabilityAmount\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.underSpaceInsuredMotoristLiabilityRefreshIcon = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.underSpaceInsuredMotoristLiabilityErrorLabel = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristLiabilityErrorLabel\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.underSpaceInsuredMotoristLiabilityErrorMessage = page.locator("[data-legacy-field=\"underSpaceInsuredMotoristLiabilityErrorMessage\"]"); // @FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.underinsuredMotoristLiabilityLabel = page.locator("[data-legacy-field=\"underinsuredMotoristLiabilityLabel\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_LABEL)
    this.underinsuredMotoristLiabilityDropdown = page.locator("[data-legacy-field=\"underinsuredMotoristLiabilityDropdown\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.underinsuredMotoristLiabilityFAQ = page.locator("[data-legacy-field=\"underinsuredMotoristLiabilityFAQ\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_FAQ_XPATH)
    this.underinsuredMotoristLiabilityAmount = page.locator("[data-legacy-field=\"underinsuredMotoristLiabilityAmount\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.underinsuredMotoristLiabilityRefreshIcon = page.locator("[data-legacy-field=\"underinsuredMotoristLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristBodilyInjuryLiabilityLabel = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryLiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredMotoristBodilyInjuryLiabilityAlternateLabel = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryLiabilityAlternateLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL_ALTERNATE)
    this.uninsuredMotoristBodilyInjuryLiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryLiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredMotoristBodilyInjuryLiabilityAlternateDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryLiabilityAlternateDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN_ALTERNATE)
    this.uninsuredMotoristBodilyInjuryLiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryLiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH)
    this.uninsuredMotoristBodilyInjuryLiabilityAmount = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryLiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredMotoristBodilyInjuryLiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristBILiabilityLabel = page.locator("[data-legacy-field=\"uninsuredMotoristBILiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredMotoristBILiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristBILiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredMotoristBILiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristBILiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BI_FAQ_XPATH)
    this.uninsuredMotoristBILiabilityAmount = page.locator("[data-legacy-field=\"uninsuredMotoristBILiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredMotoristBILiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredMotoristBILiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristBIOptionsLiabilityLabel = page.locator("[data-legacy-field=\"uninsuredMotoristBIOptionsLiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BI_OPTIONS_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredMotoristBIOptionsLiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristBIOptionsLiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BI_OPTIONS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredMotoristBIOptionsLiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristBIOptionsLiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BI_OPTIONS_FAQ_XPATH)
    this.uninsuredMotoristBIOptionsLiabilityAmount = page.locator("[data-legacy-field=\"uninsuredMotoristBIOptionsLiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BI_OPTIONS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredMotoristBIOptionsLiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredMotoristBIOptionsLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BI_OPTIONS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.underinsuredMotoristBodilyInjuryLiabilityLabel = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryLiabilityLabel\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
    this.underinsuredMotoristBodilyInjuryLiabilityDropdown = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryLiabilityDropdown\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.underinsuredMotoristBodilyInjuryLiabilityFAQ = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryLiabilityFAQ\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH)
    this.underinsuredMotoristBodilyInjuryLiabilityAmount = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryLiabilityAmount\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.underinsuredMotoristBodilyInjuryLiabilityRefreshIcon = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.underinsuredMotoristBodilyInjuryLiabilityErrorLabel = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryLiabilityErrorLabel\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.underinsuredMotoristBodilyInjuryLiabilityErrorMessage = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryLiabilityErrorMessage\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.uninsuredUnderinsuredMotoristBodilyInjuryLiabilityLabel = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristBodilyInjuryLiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredUnderinsuredMotoristBodilyInjuryLiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristBodilyInjuryLiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredUnderinsuredMotoristBodilyInjuryLiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristBodilyInjuryLiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH)
    this.uninsuredUnderinsuredMotoristBodilyInjuryLiabilityAmount = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristBodilyInjuryLiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredUnderinsuredMotoristBodilyInjuryLiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristBodilyInjuryLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredUnderinsuredMotoristBILiabilityLabel = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristBILiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredUnderinsuredMotoristBILiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristBILiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredUnderinsuredMotoristBILiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristBILiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI_FAQ_XPATH)
    this.uninsuredUnderinsuredMotoristBILiabilityAmount = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristBILiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredUnderinsuredMotoristBILiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristBILiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityLabel = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH)
    this.uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityAmount = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityLabel = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_ALTERNATE_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_ALTERNATE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_ALTERNATE_FAQ_XPATH)
    this.uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityAmount = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_ALTERNATE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_ALTERNATE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredUnderSpaceInsuredMotoristBILiabilityLabel = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBILiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredUnderSpaceInsuredMotoristBILiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBILiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredUnderSpaceInsuredMotoristBILiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBILiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_FAQ_XPATH)
    this.uninsuredUnderSpaceInsuredMotoristBILiabilityAmount = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBILiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredUnderSpaceInsuredMotoristBILiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristBILiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredUnderInsuredMotoristBIConversionLiabilityLabel = page.locator("[data-legacy-field=\"uninsuredUnderInsuredMotoristBIConversionLiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredUnderInsuredMotoristBIConversionLiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredUnderInsuredMotoristBIConversionLiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredUnderInsuredMotoristBIConversionLiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredUnderInsuredMotoristBIConversionLiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH)
    this.uninsuredUnderInsuredMotoristBIConversionLiabilityAmount = page.locator("[data-legacy-field=\"uninsuredUnderInsuredMotoristBIConversionLiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredUnderInsuredMotoristBIConversionLiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredUnderInsuredMotoristBIConversionLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredUnderInsuredMotoristBIConversionLiabilityErrorLabel = page.locator("[data-legacy-field=\"uninsuredUnderInsuredMotoristBIConversionLiabilityErrorLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.uninsuredUnderInsuredMotoristBIConversionLiabilityErrorMessage = page.locator("[data-legacy-field=\"uninsuredUnderInsuredMotoristBIConversionLiabilityErrorMessage\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.underinsuredMotoristBILiabilityLabel = page.locator("[data-legacy-field=\"underinsuredMotoristBILiabilityLabel\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_LABEL)
    this.underinsuredMotoristBILiabilityDropdown = page.locator("[data-legacy-field=\"underinsuredMotoristBILiabilityDropdown\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.underinsuredMotoristBILiabilityFAQ = page.locator("[data-legacy-field=\"underinsuredMotoristBILiabilityFAQ\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH)
    this.underinsuredMotoristBILiabilityAmount = page.locator("[data-legacy-field=\"underinsuredMotoristBILiabilityAmount\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.underinsuredMotoristBILiabilityRefreshIcon = page.locator("[data-legacy-field=\"underinsuredMotoristBILiabilityRefreshIcon\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.underinsuredMotoristBILiabilityErrorLabel = page.locator("[data-legacy-field=\"underinsuredMotoristBILiabilityErrorLabel\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.underinsuredMotoristBILiabilityErrorMessage = page.locator("[data-legacy-field=\"underinsuredMotoristBILiabilityErrorMessage\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.underinsuredMotoristPropertyDamageLiabilityLabel = page.locator("[data-legacy-field=\"underinsuredMotoristPropertyDamageLiabilityLabel\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL)
    this.underinsuredMotoristPropertyDamageLiabilityDropdown = page.locator("[data-legacy-field=\"underinsuredMotoristPropertyDamageLiabilityDropdown\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.underinsuredMotoristPropertyDamageLiabilityFAQ = page.locator("[data-legacy-field=\"underinsuredMotoristPropertyDamageLiabilityFAQ\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH)
    this.underinsuredMotoristPropertyDamageLiabilityAmount = page.locator("[data-legacy-field=\"underinsuredMotoristPropertyDamageLiabilityAmount\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.underinsuredMotoristPropertyDamageLiabilityRefreshIcon = page.locator("[data-legacy-field=\"underinsuredMotoristPropertyDamageLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityLabel = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH)
    this.uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityAmount = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityErrorLabel = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityErrorLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityErrorMessage = page.locator("[data-legacy-field=\"uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityErrorMessage\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.uninsuredUnderinsuredMotoristPropertyDamageLiabilityLabel = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristPropertyDamageLiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredUnderinsuredMotoristPropertyDamageLiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristPropertyDamageLiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredUnderinsuredMotoristPropertyDamageLiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristPropertyDamageLiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH)
    this.uninsuredUnderinsuredMotoristPropertyDamageLiabilityAmount = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristPropertyDamageLiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredUnderinsuredMotoristPropertyDamageLiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristPropertyDamageLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredUnderinsuredMotoristPropertyDamageLiabilityErrorLabel = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristPropertyDamageLiabilityErrorLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.uninsuredUnderinsuredMotoristPropertyDamageLiabilityErrorMessage = page.locator("[data-legacy-field=\"uninsuredUnderinsuredMotoristPropertyDamageLiabilityErrorMessage\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.uninsuredUnderInsuredMotoristPDLiabilityLabel = page.locator("[data-legacy-field=\"uninsuredUnderInsuredMotoristPDLiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredUnderInsuredMotoristPDLiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredUnderInsuredMotoristPDLiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredUnderInsuredMotoristPDLiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredUnderInsuredMotoristPDLiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_FAQ_XPATH)
    this.uninsuredUnderInsuredMotoristPDLiabilityAmount = page.locator("[data-legacy-field=\"uninsuredUnderInsuredMotoristPDLiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredUnderInsuredMotoristPDLiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredUnderInsuredMotoristPDLiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.vehicleCoverageHeaders = page.locator("xpath=//app-vehicle-coverage/form/lib-coverage-panel/mat-accordion/mat-expansion-panel/mat-expansion-panel-header/span/mat-panel-title/div/div[@class='ffq-coverage-panel-coverage-heading']"); // @FindBy(xpath = "//app-vehicle-coverage/form/lib-coverage-panel/mat-accordion/mat-expansion-panel/mat-expansion-panel-header/span/mat-panel-title/div/div[@class='ffq-coverage-panel-coverage-heading']")
    this.accidentForgivenessCoverageLabel = page.locator("[data-legacy-field=\"accidentForgivenessCoverageLabel\"]"); // @FindBy(xpath = ACCIDENT_FORGIVENESS_FAQ_XPATH + XPATH_TO_LABEL)
    this.accidentForgivenessCoverageDropdown = page.locator("[data-legacy-field=\"accidentForgivenessCoverageDropdown\"]"); // @FindBy(xpath = ACCIDENT_FORGIVENESS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.accidentForgivenessCoverageFAQ = page.locator("[data-legacy-field=\"accidentForgivenessCoverageFAQ\"]"); // @FindBy(xpath = ACCIDENT_FORGIVENESS_FAQ_XPATH)
    this.accidentForgivenessCoverageAmount = page.locator("[data-legacy-field=\"accidentForgivenessCoverageAmount\"]"); // @FindBy(xpath = ACCIDENT_FORGIVENESS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.accidentForgivenessCoverageRefreshIcon = page.locator("[data-legacy-field=\"accidentForgivenessCoverageRefreshIcon\"]"); // @FindBy(xpath = ACCIDENT_FORGIVENESS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.collisionCoverageLabel = page.locator("[data-legacy-field=\"collisionCoverageLabel\"]"); // @FindBy(xpath = COLLISION_FAQ_XPATH + XPATH_TO_LABEL)
    this.collisionCoverageDropdown = page.locator("[data-legacy-field=\"collisionCoverageDropdown\"]"); // @FindBy(xpath = COLLISION_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.collisionCoverageFAQ = page.locator("[data-legacy-field=\"collisionCoverageFAQ\"]"); // @FindBy(xpath = COLLISION_FAQ_XPATH)
    this.collisionCoverageAmount = page.locator("[data-legacy-field=\"collisionCoverageAmount\"]"); // @FindBy(xpath = COLLISION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.collisionCoverageRefreshIcon = page.locator("[data-legacy-field=\"collisionCoverageRefreshIcon\"]"); // @FindBy(xpath = COLLISION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.collisionPlusLossOfUseCoverageLabel = page.locator("[data-legacy-field=\"collisionPlusLossOfUseCoverageLabel\"]"); // @FindBy(xpath = COLLISION_LOSS_OF_USE_FAQ_XPATH + XPATH_TO_LABEL)
    this.collisionPlusLossOfUseCoverageDropdown = page.locator("[data-legacy-field=\"collisionPlusLossOfUseCoverageDropdown\"]"); // @FindBy(xpath = COLLISION_LOSS_OF_USE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.collisionPlusLossOfUseCoverageFAQ = page.locator("[data-legacy-field=\"collisionPlusLossOfUseCoverageFAQ\"]"); // @FindBy(xpath = COLLISION_LOSS_OF_USE_FAQ_XPATH)
    this.collisionPlusLossOfUseCoverageAmount = page.locator("[data-legacy-field=\"collisionPlusLossOfUseCoverageAmount\"]"); // @FindBy(xpath = COLLISION_LOSS_OF_USE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.collisionPlusLossOfUseCoverageRefreshIcon = page.locator("[data-legacy-field=\"collisionPlusLossOfUseCoverageRefreshIcon\"]"); // @FindBy(xpath = COLLISION_LOSS_OF_USE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.collisionPlusLossOfUseK5CoverageLabel = page.locator("[data-legacy-field=\"collisionPlusLossOfUseK5CoverageLabel\"]"); // @FindBy(xpath = COLLISION_LOSS_OF_USE_K5_FAQ_XPATH + XPATH_TO_LABEL)
    this.collisionPlusLossOfUseK5CoverageDropdown = page.locator("[data-legacy-field=\"collisionPlusLossOfUseK5CoverageDropdown\"]"); // @FindBy(xpath = COLLISION_LOSS_OF_USE_K5_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.collisionPlusLossOfUseK5CoverageFAQ = page.locator("[data-legacy-field=\"collisionPlusLossOfUseK5CoverageFAQ\"]"); // @FindBy(xpath = COLLISION_LOSS_OF_USE_K5_FAQ_XPATH)
    this.collisionPlusLossOfUseK5CoverageAmount = page.locator("[data-legacy-field=\"collisionPlusLossOfUseK5CoverageAmount\"]"); // @FindBy(xpath = COLLISION_LOSS_OF_USE_K5_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.collisionPlusLossOfUseK5CoverageRefreshIcon = page.locator("[data-legacy-field=\"collisionPlusLossOfUseK5CoverageRefreshIcon\"]"); // @FindBy(xpath = COLLISION_LOSS_OF_USE_K5_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.comprehensiveCoverageLabel = page.locator("[data-legacy-field=\"comprehensiveCoverageLabel\"]"); // @FindBy(xpath = COMPREHENSIVE_FAQ_XPATH + XPATH_TO_LABEL)
    this.comprehensiveCoverageDropdown = page.locator("[data-legacy-field=\"comprehensiveCoverageDropdown\"]"); // @FindBy(xpath = COMPREHENSIVE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.comprehensiveCoverageFAQ = page.locator("[data-legacy-field=\"comprehensiveCoverageFAQ\"]"); // @FindBy(xpath = COMPREHENSIVE_FAQ_XPATH)
    this.comprehensiveCoverageAmount = page.locator("[data-legacy-field=\"comprehensiveCoverageAmount\"]"); // @FindBy(xpath = COMPREHENSIVE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.comprehensiveCoverageRefreshIcon = page.locator("[data-legacy-field=\"comprehensiveCoverageRefreshIcon\"]"); // @FindBy(xpath = COMPREHENSIVE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.deathBenefitCoverageLabel = page.locator("[data-legacy-field=\"deathBenefitCoverageLabel\"]"); // @FindBy(xpath = DEATH_BENEFIT_FAQ_XPATH + XPATH_TO_LABEL)
    this.deathBenefitCoverageDropdown = page.locator("[data-legacy-field=\"deathBenefitCoverageDropdown\"]"); // @FindBy(xpath = DEATH_BENEFIT_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.deathBenefitCoverageFAQ = page.locator("[data-legacy-field=\"deathBenefitCoverageFAQ\"]"); // @FindBy(xpath = DEATH_BENEFIT_FAQ_XPATH)
    this.deathBenefitCoverageAmount = page.locator("[data-legacy-field=\"deathBenefitCoverageAmount\"]"); // @FindBy(xpath = DEATH_BENEFIT_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.deathBenefitCoverageRefreshIcon = page.locator("[data-legacy-field=\"deathBenefitCoverageRefreshIcon\"]"); // @FindBy(xpath = DEATH_BENEFIT_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.extraPIPPackageCoverageLabel = page.locator("[data-legacy-field=\"extraPIPPackageCoverageLabel\"]"); // @FindBy(xpath = EXTRA_PIP_COVERAGE_FAQ_XPATH + XPATH_TO_LABEL)
    this.extraPIPPackageCoverageDropdown = page.locator("[data-legacy-field=\"extraPIPPackageCoverageDropdown\"]"); // @FindBy(xpath = EXTRA_PIP_COVERAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.extraPIPPackageCoverageFAQ = page.locator("[data-legacy-field=\"extraPIPPackageCoverageFAQ\"]"); // @FindBy(xpath = EXTRA_PIP_COVERAGE_FAQ_XPATH)
    this.extraPIPPackageCoverageAmount = page.locator("[data-legacy-field=\"extraPIPPackageCoverageAmount\"]"); // @FindBy(xpath = EXTRA_PIP_COVERAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.extraPIPPackageCoverageRefreshIcon = page.locator("[data-legacy-field=\"extraPIPPackageCoverageRefreshIcon\"]"); // @FindBy(xpath = EXTRA_PIP_COVERAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.funeralExpensesCoverageLabel = page.locator("[data-legacy-field=\"funeralExpensesCoverageLabel\"]"); // @FindBy(xpath = FUNERAL_EXPENSES_FAQ_XPATH + XPATH_TO_LABEL)
    this.funeralExpensesCoverageDropdown = page.locator("[data-legacy-field=\"funeralExpensesCoverageDropdown\"]"); // @FindBy(xpath = FUNERAL_EXPENSES_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.funeralExpensesCoverageFAQ = page.locator("[data-legacy-field=\"funeralExpensesCoverageFAQ\"]"); // @FindBy(xpath = FUNERAL_EXPENSES_FAQ_XPATH)
    this.funeralExpensesCoverageAmount = page.locator("[data-legacy-field=\"funeralExpensesCoverageAmount\"]"); // @FindBy(xpath = FUNERAL_EXPENSES_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.funeralExpensesCoverageRefreshIcon = page.locator("[data-legacy-field=\"funeralExpensesCoverageRefreshIcon\"]"); // @FindBy(xpath = FUNERAL_EXPENSES_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.glassDeductibleBuybackCoverageLabel = page.locator("[data-legacy-field=\"glassDeductibleBuybackCoverageLabel\"]"); // @FindBy(xpath = GLASS_DEDUCTIBLE_BUYBACK_FAQ_XPATH + XPATH_TO_LABEL)
    this.glassDeductibleBuybackCoverageDropdown = page.locator("[data-legacy-field=\"glassDeductibleBuybackCoverageDropdown\"]"); // @FindBy(xpath = GLASS_DEDUCTIBLE_BUYBACK_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.glassDeductibleBuybackCoverageFAQ = page.locator("[data-legacy-field=\"glassDeductibleBuybackCoverageFAQ\"]"); // @FindBy(xpath = GLASS_DEDUCTIBLE_BUYBACK_FAQ_XPATH)
    this.glassDeductibleBuybackCoverageAmount = page.locator("[data-legacy-field=\"glassDeductibleBuybackCoverageAmount\"]"); // @FindBy(xpath = GLASS_DEDUCTIBLE_BUYBACK_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.glassDeductibleBuybackCoverageRefreshIcon = page.locator("[data-legacy-field=\"glassDeductibleBuybackCoverageRefreshIcon\"]"); // @FindBy(xpath = GLASS_DEDUCTIBLE_BUYBACK_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.glassCoverage100Label = page.locator("[data-legacy-field=\"glassCoverage100Label\"]"); // @FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH + XPATH_TO_LABEL)
    this.glassCoverage100Dropdown = page.locator("[data-legacy-field=\"glassCoverage100Dropdown\"]"); // @FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.glassCoverage100FAQ = page.locator("[data-legacy-field=\"glassCoverage100FAQ\"]"); // @FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH)
    this.glassCoverage100Amount = page.locator("[data-legacy-field=\"glassCoverage100Amount\"]"); // @FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.glassCoverage100RefreshIcon = page.locator("[data-legacy-field=\"glassCoverage100RefreshIcon\"]"); // @FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.glassCoverage100ErrorLabel = page.locator("[data-legacy-field=\"glassCoverage100ErrorLabel\"]"); // @FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.glassCoverage100ErrorMessage = page.locator("[data-legacy-field=\"glassCoverage100ErrorMessage\"]"); // @FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.healthInsurerPrimaryCoverageLabel = page.locator("[data-legacy-field=\"healthInsurerPrimaryCoverageLabel\"]"); // @FindBy(xpath = HEALTH_INSURER_FAQ_XPATH + XPATH_TO_LABEL)
    this.healthInsurerPrimaryCoverageDropdown = page.locator("[data-legacy-field=\"healthInsurerPrimaryCoverageDropdown\"]"); // @FindBy(xpath = HEALTH_INSURER_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.healthInsurerPrimaryCoverageFAQ = page.locator("[data-legacy-field=\"healthInsurerPrimaryCoverageFAQ\"]"); // @FindBy(xpath = HEALTH_INSURER_FAQ_XPATH)
    this.healthInsurerPrimaryCoverageAmount = page.locator("[data-legacy-field=\"healthInsurerPrimaryCoverageAmount\"]"); // @FindBy(xpath = HEALTH_INSURER_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.healthInsurerPrimaryCoverageRefreshIcon = page.locator("[data-legacy-field=\"healthInsurerPrimaryCoverageRefreshIcon\"]"); // @FindBy(xpath = HEALTH_INSURER_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.incomeDisabilityCoverageLabel = page.locator("[data-legacy-field=\"incomeDisabilityCoverageLabel\"]"); // @FindBy(xpath = INCOME_DISABILITY_FAQ_XPATH + XPATH_TO_LABEL)
    this.incomeDisabilityCoverageDropdown = page.locator("[data-legacy-field=\"incomeDisabilityCoverageDropdown\"]"); // @FindBy(xpath = INCOME_DISABILITY_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.incomeDisabilityCoverageFAQ = page.locator("[data-legacy-field=\"incomeDisabilityCoverageFAQ\"]"); // @FindBy(xpath = INCOME_DISABILITY_FAQ_XPATH)
    this.incomeDisabilityCoverageAmount = page.locator("[data-legacy-field=\"incomeDisabilityCoverageAmount\"]"); // @FindBy(xpath = INCOME_DISABILITY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.incomeDisabilityCoverageRefreshIcon = page.locator("[data-legacy-field=\"incomeDisabilityCoverageRefreshIcon\"]"); // @FindBy(xpath = INCOME_DISABILITY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.incomeLossCoverageLabel = page.locator("[data-legacy-field=\"incomeLossCoverageLabel\"]"); // @FindBy(xpath = INCOME_LOSS_FAQ_XPATH + XPATH_TO_LABEL)
    this.incomeLossCoverageDropdown = page.locator("[data-legacy-field=\"incomeLossCoverageDropdown\"]"); // @FindBy(xpath = INCOME_LOSS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.incomeLossCoverageFAQ = page.locator("[data-legacy-field=\"incomeLossCoverageFAQ\"]"); // @FindBy(xpath = INCOME_LOSS_FAQ_XPATH)
    this.incomeLossCoverageAmount = page.locator("[data-legacy-field=\"incomeLossCoverageAmount\"]"); // @FindBy(xpath = INCOME_LOSS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.incomeLossCoverageRefreshIcon = page.locator("[data-legacy-field=\"incomeLossCoverageRefreshIcon\"]"); // @FindBy(xpath = INCOME_LOSS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.lossOfUseCoverageLabel = page.locator("[data-legacy-field=\"lossOfUseCoverageLabel\"]"); // @FindBy(xpath = LOSS_OF_USE_FAQ_XPATH + XPATH_TO_LABEL)
    this.lossOfUseCoverageDropdown = page.locator("[data-legacy-field=\"lossOfUseCoverageDropdown\"]"); // @FindBy(xpath = LOSS_OF_USE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.lossOfUseCoverageFAQ = page.locator("[data-legacy-field=\"lossOfUseCoverageFAQ\"]"); // @FindBy(xpath = LOSS_OF_USE_FAQ_XPATH)
    this.lossOfUseCoverageAmount = page.locator("[data-legacy-field=\"lossOfUseCoverageAmount\"]"); // @FindBy(xpath = LOSS_OF_USE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.lossOfUseCoverageRefreshIcon = page.locator("[data-legacy-field=\"lossOfUseCoverageRefreshIcon\"]"); // @FindBy(xpath = LOSS_OF_USE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.medicalExpenseCoverageLabel = page.locator("[data-legacy-field=\"medicalExpenseCoverageLabel\"]"); // @FindBy(xpath = MEDICAL_EXPENSE_COVERAGE_FAQ_XPATH + XPATH_TO_LABEL)
    this.medicalExpenseCoverageDropdown = page.locator("[data-legacy-field=\"medicalExpenseCoverageDropdown\"]"); // @FindBy(xpath = MEDICAL_EXPENSE_COVERAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.medicalExpenseCoverageFAQ = page.locator("[data-legacy-field=\"medicalExpenseCoverageFAQ\"]"); // @FindBy(xpath = MEDICAL_EXPENSE_COVERAGE_FAQ_XPATH)
    this.medicalExpenseCoverageAmount = page.locator("[data-legacy-field=\"medicalExpenseCoverageAmount\"]"); // @FindBy(xpath = MEDICAL_EXPENSE_COVERAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.medicalExpenseCoverageRefreshIcon = page.locator("[data-legacy-field=\"medicalExpenseCoverageRefreshIcon\"]"); // @FindBy(xpath = MEDICAL_EXPENSE_COVERAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.rentalCoverageLabel = page.locator("[data-legacy-field=\"rentalCoverageLabel\"]"); // @FindBy(xpath = RENTAL_FAQ_XPATH + XPATH_TO_LABEL)
    this.rentalCoverageDropdown = page.locator("[data-legacy-field=\"rentalCoverageDropdown\"]"); // @FindBy(xpath = RENTAL_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.rentalCoverageFAQ = page.locator("[data-legacy-field=\"rentalCoverageFAQ\"]"); // @FindBy(xpath = RENTAL_FAQ_XPATH)
    this.rentalCoverageAmount = page.locator("[data-legacy-field=\"rentalCoverageAmount\"]"); // @FindBy(xpath = RENTAL_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.rentalCoverageRefreshIcon = page.locator("[data-legacy-field=\"rentalCoverageRefreshIcon\"]"); // @FindBy(xpath = RENTAL_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.rentalCoverageErrorLabel = page.locator("[data-legacy-field=\"rentalCoverageErrorLabel\"]"); // @FindBy(xpath = RENTAL_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.rentalCoverageErrorMessage = page.locator("[data-legacy-field=\"rentalCoverageErrorMessage\"]"); // @FindBy(xpath = RENTAL_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.rentalReimbursementCoverageLabel = page.locator("[data-legacy-field=\"rentalReimbursementCoverageLabel\"]"); // @FindBy(xpath = RENTAL_REIMBURSEMENT_FAQ_XPATH + XPATH_TO_LABEL)
    this.rentalReimbursementCoverageDropdown = page.locator("[data-legacy-field=\"rentalReimbursementCoverageDropdown\"]"); // @FindBy(xpath = RENTAL_REIMBURSEMENT_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.rentalReimbursementCoverageFAQ = page.locator("[data-legacy-field=\"rentalReimbursementCoverageFAQ\"]"); // @FindBy(xpath = RENTAL_REIMBURSEMENT_FAQ_XPATH)
    this.rentalReimbursementCoverageAmount = page.locator("[data-legacy-field=\"rentalReimbursementCoverageAmount\"]"); // @FindBy(xpath = RENTAL_REIMBURSEMENT_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.rentalReimbursementCoverageRefreshIcon = page.locator("[data-legacy-field=\"rentalReimbursementCoverageRefreshIcon\"]"); // @FindBy(xpath = RENTAL_REIMBURSEMENT_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.rideshareCoverageLabel = page.locator("[data-legacy-field=\"rideshareCoverageLabel\"]"); // @FindBy(xpath = RIDESHARE_FAQ_XPATH + XPATH_TO_LABEL)
    this.rideshareCoverageDropdown = page.locator("[data-legacy-field=\"rideshareCoverageDropdown\"]"); // @FindBy(xpath = RIDESHARE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.rideshareCoverageFAQ = page.locator("[data-legacy-field=\"rideshareCoverageFAQ\"]"); // @FindBy(xpath = RIDESHARE_FAQ_XPATH)
    this.rideshareCoverageAmount = page.locator("[data-legacy-field=\"rideshareCoverageAmount\"]"); // @FindBy(xpath = RIDESHARE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.rideshareCoverageRefreshIcon = page.locator("[data-legacy-field=\"rideshareCoverageRefreshIcon\"]"); // @FindBy(xpath = RIDESHARE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.rideshareAndFoodDeliveryCoverageLabel = page.locator("[data-legacy-field=\"rideshareAndFoodDeliveryCoverageLabel\"]"); // @FindBy(xpath = RIDESHARE_AND_FOOD_FAQ_XPATH + XPATH_TO_LABEL)
    this.rideshareAndFoodDeliveryCoverageDropdown = page.locator("[data-legacy-field=\"rideshareAndFoodDeliveryCoverageDropdown\"]"); // @FindBy(xpath = RIDESHARE_AND_FOOD_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.rideshareAndFoodDeliveryCoverageFAQ = page.locator("[data-legacy-field=\"rideshareAndFoodDeliveryCoverageFAQ\"]"); // @FindBy(xpath = RIDESHARE_AND_FOOD_FAQ_XPATH)
    this.rideshareAndFoodDeliveryCoverageAmount = page.locator("[data-legacy-field=\"rideshareAndFoodDeliveryCoverageAmount\"]"); // @FindBy(xpath = RIDESHARE_AND_FOOD_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.rideshareAndFoodDeliveryCoverageRefreshIcon = page.locator("[data-legacy-field=\"rideshareAndFoodDeliveryCoverageRefreshIcon\"]"); // @FindBy(xpath = RIDESHARE_AND_FOOD_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.roadsideAssistanceCoverageLabel = page.locator("[data-legacy-field=\"roadsideAssistanceCoverageLabel\"]"); // @FindBy(xpath = ROADSIDE_ASSISTANCE_FAQ_XPATH + XPATH_TO_LABEL)
    this.roadsideAssistanceCoverageDropdown = page.locator("[data-legacy-field=\"roadsideAssistanceCoverageDropdown\"]"); // @FindBy(xpath = ROADSIDE_ASSISTANCE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.roadsideAssistanceCoverageFAQ = page.locator("[data-legacy-field=\"roadsideAssistanceCoverageFAQ\"]"); // @FindBy(xpath = ROADSIDE_ASSISTANCE_FAQ_XPATH)
    this.roadsideAssistanceCoverageAmount = page.locator("[data-legacy-field=\"roadsideAssistanceCoverageAmount\"]"); // @FindBy(xpath = ROADSIDE_ASSISTANCE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.roadsideAssistanceCoverageRefreshIcon = page.locator("[data-legacy-field=\"roadsideAssistanceCoverageRefreshIcon\"]"); // @FindBy(xpath = ROADSIDE_ASSISTANCE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.safetyGlassWaiverOfDeductibleCoverageLabel = page.locator("[data-legacy-field=\"safetyGlassWaiverOfDeductibleCoverageLabel\"]"); // @FindBy(xpath = SAFETY_GLASS_WAIVER_FAQ_XPATH + XPATH_TO_LABEL)
    this.safetyGlassWaiverOfDeductibleCoverageDropdown = page.locator("[data-legacy-field=\"safetyGlassWaiverOfDeductibleCoverageDropdown\"]"); // @FindBy(xpath = SAFETY_GLASS_WAIVER_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.safetyGlassWaiverOfDeductibleCoverageFAQ = page.locator("[data-legacy-field=\"safetyGlassWaiverOfDeductibleCoverageFAQ\"]"); // @FindBy(xpath = SAFETY_GLASS_WAIVER_FAQ_XPATH)
    this.safetyGlassWaiverOfDeductibleCoverageAmount = page.locator("[data-legacy-field=\"safetyGlassWaiverOfDeductibleCoverageAmount\"]"); // @FindBy(xpath = SAFETY_GLASS_WAIVER_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.safetyGlassWaiverOfDeductibleCoverageRefreshIcon = page.locator("[data-legacy-field=\"safetyGlassWaiverOfDeductibleCoverageRefreshIcon\"]"); // @FindBy(xpath = SAFETY_GLASS_WAIVER_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.towingAndRoadServiceCoverageLabel = page.locator("[data-legacy-field=\"towingAndRoadServiceCoverageLabel\"]"); // @FindBy(xpath = TOWING_AND_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_LABEL)
    this.towingAndRoadServiceCoverageDropdown = page.locator("[data-legacy-field=\"towingAndRoadServiceCoverageDropdown\"]"); // @FindBy(xpath = TOWING_AND_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.towingAndRoadServiceCoverageFAQ = page.locator("[data-legacy-field=\"towingAndRoadServiceCoverageFAQ\"]"); // @FindBy(xpath = TOWING_AND_ROAD_SERVICE_FAQ_XPATH)
    this.towingAndRoadServiceCoverageAmount = page.locator("[data-legacy-field=\"towingAndRoadServiceCoverageAmount\"]"); // @FindBy(xpath = TOWING_AND_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.towingAndRoadServiceCoverageRefreshIcon = page.locator("[data-legacy-field=\"towingAndRoadServiceCoverageRefreshIcon\"]"); // @FindBy(xpath = TOWING_AND_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.towingAmpRoadServiceCoverageLabel = page.locator("[data-legacy-field=\"towingAmpRoadServiceCoverageLabel\"]"); // @FindBy(xpath = TOWING_AMP_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_LABEL)
    this.towingAmpRoadServiceCoverageDropdown = page.locator("[data-legacy-field=\"towingAmpRoadServiceCoverageDropdown\"]"); // @FindBy(xpath = TOWING_AMP_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.towingAmpRoadServiceCoverageFAQ = page.locator("[data-legacy-field=\"towingAmpRoadServiceCoverageFAQ\"]"); // @FindBy(xpath = TOWING_AMP_ROAD_SERVICE_FAQ_XPATH)
    this.towingAmpRoadServiceCoverageAmount = page.locator("[data-legacy-field=\"towingAmpRoadServiceCoverageAmount\"]"); // @FindBy(xpath = TOWING_AMP_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.towingAmpRoadServiceCoverageRefreshIcon = page.locator("[data-legacy-field=\"towingAmpRoadServiceCoverageRefreshIcon\"]"); // @FindBy(xpath = TOWING_AMP_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.towingAndLaborCoverageLabel = page.locator("[data-legacy-field=\"towingAndLaborCoverageLabel\"]"); // @FindBy(xpath = TOWING_LABOR_FAQ_XPATH + XPATH_TO_LABEL)
    this.towingAndLaborCoverageDropdown = page.locator("[data-legacy-field=\"towingAndLaborCoverageDropdown\"]"); // @FindBy(xpath = TOWING_LABOR_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.towingAndLaborCoverageFAQ = page.locator("[data-legacy-field=\"towingAndLaborCoverageFAQ\"]"); // @FindBy(xpath = TOWING_LABOR_FAQ_XPATH)
    this.towingAndLaborCoverageAmount = page.locator("[data-legacy-field=\"towingAndLaborCoverageAmount\"]"); // @FindBy(xpath = TOWING_LABOR_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.towingAndLaborCoverageRefreshIcon = page.locator("[data-legacy-field=\"towingAndLaborCoverageRefreshIcon\"]"); // @FindBy(xpath = TOWING_LABOR_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.towingAndLaborCostsCoverageLabel = page.locator("[data-legacy-field=\"towingAndLaborCostsCoverageLabel\"]"); // @FindBy(xpath = TOWING_LABOR_COSTS_FAQ_XPATH + XPATH_TO_LABEL)
    this.towingAndLaborCostsCoverageDropdown = page.locator("[data-legacy-field=\"towingAndLaborCostsCoverageDropdown\"]"); // @FindBy(xpath = TOWING_LABOR_COSTS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.towingAndLaborCostsCoverageFAQ = page.locator("[data-legacy-field=\"towingAndLaborCostsCoverageFAQ\"]"); // @FindBy(xpath = TOWING_LABOR_COSTS_FAQ_XPATH)
    this.towingAndLaborCostsCoverageAmount = page.locator("[data-legacy-field=\"towingAndLaborCostsCoverageAmount\"]"); // @FindBy(xpath = TOWING_LABOR_COSTS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.towingAndLaborCostsCoverageRefreshIcon = page.locator("[data-legacy-field=\"towingAndLaborCostsCoverageRefreshIcon\"]"); // @FindBy(xpath = TOWING_LABOR_COSTS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristPDCoverageLabel = page.locator("[data-legacy-field=\"uninsuredMotoristPDCoverageLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredMotoristPDCoverageDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristPDCoverageDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredMotoristPDCoverageFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristPDCoverageFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH)
    this.uninsuredMotoristPDCoverageAmount = page.locator("[data-legacy-field=\"uninsuredMotoristPDCoverageAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredMotoristPDCoverageRefreshIcon = page.locator("[data-legacy-field=\"uninsuredMotoristPDCoverageRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristPDCoverageErrorLabel = page.locator("[data-legacy-field=\"uninsuredMotoristPDCoverageErrorLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.uninsuredMotoristPDCoverageErrorMessage = page.locator("[data-legacy-field=\"uninsuredMotoristPDCoverageErrorMessage\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.uninsuredMotoristPDWithoutUppercaseCollisionCoverageLabel = page.locator("[data-legacy-field=\"uninsuredMotoristPDWithoutUppercaseCollisionCoverageLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredMotoristPDWithoutUppercaseCollisionCoverageDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristPDWithoutUppercaseCollisionCoverageDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredMotoristPDWithoutUppercaseCollisionCoverageFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristPDWithoutUppercaseCollisionCoverageFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH)
    this.uninsuredMotoristPDWithoutUppercaseCollisionCoverageAmount = page.locator("[data-legacy-field=\"uninsuredMotoristPDWithoutUppercaseCollisionCoverageAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredMotoristPDWithoutUppercaseCollisionCoverageRefreshIcon = page.locator("[data-legacy-field=\"uninsuredMotoristPDWithoutUppercaseCollisionCoverageRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristPDWithoutUppercaseCollisionCoverageErrorLabel = page.locator("[data-legacy-field=\"uninsuredMotoristPDWithoutUppercaseCollisionCoverageErrorLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.uninsuredMotoristPDWithoutUppercaseCollisionCoverageErrorMessage = page.locator("[data-legacy-field=\"uninsuredMotoristPDWithoutUppercaseCollisionCoverageErrorMessage\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.uninsuredMotoristPropertyDamageCoverageLabel = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageCoverageLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredMotoristPropertyDamageCoverageAlternateLabel = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageCoverageAlternateLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL_ALTERNATE)
    this.uninsuredMotoristPropertyDamageCoverageDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageCoverageDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredMotoristPropertyDamageCoverageAlternateDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageCoverageAlternateDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN_ALTERNATE)
    this.uninsuredMotoristPropertyDamageCoverageFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageCoverageFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH)
    this.uninsuredMotoristPropertyDamageCoverageAmount = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageCoverageAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredMotoristPropertyDamageCoverageRefreshIcon = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageCoverageRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristPropertyDamageCoverageErrorLabel = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageCoverageErrorLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.uninsuredMotoristPropertyDamageCoverageErrorMessage = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageCoverageErrorMessage\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.uninsuredMotoristPropertyDamageWithoutCollisionCoverageLabel = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageWithoutCollisionCoverageLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredMotoristPropertyDamageWithoutCollisionCoverageDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageWithoutCollisionCoverageDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredMotoristPropertyDamageWithoutCollisionCoverageFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageWithoutCollisionCoverageFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH)
    this.uninsuredMotoristPropertyDamageWithoutCollisionCoverageAmount = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageWithoutCollisionCoverageAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredMotoristPropertyDamageWithoutCollisionCoverageRefreshIcon = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageWithoutCollisionCoverageRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristPropertyDamageWithoutCollisionCoverageErrorLabel = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageWithoutCollisionCoverageErrorLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.uninsuredMotoristPropertyDamageWithoutCollisionCoverageErrorMessage = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageWithoutCollisionCoverageErrorMessage\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.uninsuredMotoristPropertyDamageWithCollisionCoverageLabel = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageWithCollisionCoverageLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredMotoristPropertyDamageWithCollisionCoverageDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageWithCollisionCoverageDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredMotoristPropertyDamageWithCollisionCoverageFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageWithCollisionCoverageFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION_FAQ_XPATH)
    this.uninsuredMotoristPropertyDamageWithCollisionCoverageAmount = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageWithCollisionCoverageAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredMotoristPropertyDamageWithCollisionCoverageRefreshIcon = page.locator("[data-legacy-field=\"uninsuredMotoristPropertyDamageWithCollisionCoverageRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.vehicleReplacementCoverageLabel = page.locator("[data-legacy-field=\"vehicleReplacementCoverageLabel\"]"); // @FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH + XPATH_TO_LABEL)
    this.vehicleReplacementCoverageDropdown = page.locator("[data-legacy-field=\"vehicleReplacementCoverageDropdown\"]"); // @FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.vehicleReplacementCoverageFAQ = page.locator("[data-legacy-field=\"vehicleReplacementCoverageFAQ\"]"); // @FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH)
    this.vehicleReplacementCoverageAmount = page.locator("[data-legacy-field=\"vehicleReplacementCoverageAmount\"]"); // @FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.vehicleReplacementCoverageRefreshIcon = page.locator("[data-legacy-field=\"vehicleReplacementCoverageRefreshIcon\"]"); // @FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.vehicleReplacementCoverageErrorLabel = page.locator("[data-legacy-field=\"vehicleReplacementCoverageErrorLabel\"]"); // @FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.vehicleReplacementCoverageErrorMessage = page.locator("[data-legacy-field=\"vehicleReplacementCoverageErrorMessage\"]"); // @FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.waiverOfWorkLossCoverageLabel = page.locator("[data-legacy-field=\"waiverOfWorkLossCoverageLabel\"]"); // @FindBy(xpath = WAIVER_WORK_LOSS_FAQ_XPATH + XPATH_TO_LABEL)
    this.waiverOfWorkLossCoverageDropdown = page.locator("[data-legacy-field=\"waiverOfWorkLossCoverageDropdown\"]"); // @FindBy(xpath = WAIVER_WORK_LOSS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.waiverOfWorkLossCoverageFAQ = page.locator("[data-legacy-field=\"waiverOfWorkLossCoverageFAQ\"]"); // @FindBy(xpath = WAIVER_WORK_LOSS_FAQ_XPATH)
    this.waiverOfWorkLossCoverageAmount = page.locator("[data-legacy-field=\"waiverOfWorkLossCoverageAmount\"]"); // @FindBy(xpath = WAIVER_WORK_LOSS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.waiverOfWorkLossCoverageRefreshIcon = page.locator("[data-legacy-field=\"waiverOfWorkLossCoverageRefreshIcon\"]"); // @FindBy(xpath = WAIVER_WORK_LOSS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.compulsoryBodilyInjuryLiabilityLabel = page.locator("[data-legacy-field=\"compulsoryBodilyInjuryLiabilityLabel\"]"); // @FindBy(xpath = COMPULSORY_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
    this.compulsoryBodilyInjuryLiabilityDropdown = page.locator("[data-legacy-field=\"compulsoryBodilyInjuryLiabilityDropdown\"]"); // @FindBy(xpath = COMPULSORY_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.compulsoryBodilyInjuryLiabilityFAQ = page.locator("[data-legacy-field=\"compulsoryBodilyInjuryLiabilityFAQ\"]"); // @FindBy(xpath = COMPULSORY_BODILY_INJURY_FAQ_XPATH)
    this.compulsoryBodilyInjuryLiabilityAmount = page.locator("[data-legacy-field=\"compulsoryBodilyInjuryLiabilityAmount\"]"); // @FindBy(xpath = COMPULSORY_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.compulsoryBodilyInjuryLiabilityRefreshIcon = page.locator("[data-legacy-field=\"compulsoryBodilyInjuryLiabilityRefreshIcon\"]"); // @FindBy(xpath = COMPULSORY_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.optionalBodilyInjuryLiabilityLabel = page.locator("[data-legacy-field=\"optionalBodilyInjuryLiabilityLabel\"]"); // @FindBy(xpath = OPTIONAL_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
    this.optionalBodilyInjuryLiabilityDropdown = page.locator("[data-legacy-field=\"optionalBodilyInjuryLiabilityDropdown\"]"); // @FindBy(xpath = OPTIONAL_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.optionalBodilyInjuryLiabilityFAQ = page.locator("[data-legacy-field=\"optionalBodilyInjuryLiabilityFAQ\"]"); // @FindBy(xpath = OPTIONAL_BODILY_INJURY_FAQ_XPATH)
    this.optionalBodilyInjuryLiabilityAmount = page.locator("[data-legacy-field=\"optionalBodilyInjuryLiabilityAmount\"]"); // @FindBy(xpath = OPTIONAL_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.optionalBodilyInjuryLiabilityRefreshIcon = page.locator("[data-legacy-field=\"optionalBodilyInjuryLiabilityRefreshIcon\"]"); // @FindBy(xpath = OPTIONAL_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.propertyDamageMALabel = page.locator("[data-legacy-field=\"propertyDamageMALabel\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_MASS_FAQ_XPATH + XPATH_TO_LABEL)
    this.propertyDamageMADropdown = page.locator("[data-legacy-field=\"propertyDamageMADropdown\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.propertyDamageMAFAQ = page.locator("[data-legacy-field=\"propertyDamageMAFAQ\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_MASS_FAQ_XPATH)
    this.propertyDamageMAAmount = page.locator("[data-legacy-field=\"propertyDamageMAAmount\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.propertyDamageMARefreshIcon = page.locator("[data-legacy-field=\"propertyDamageMARefreshIcon\"]"); // @FindBy(xpath = PROPERTY_DAMAGE_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.uninsuredMotoristBodilyInjuryMALiabilityLabel = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryMALiabilityLabel\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_LABEL)
    this.uninsuredMotoristBodilyInjuryMALiabilityDropdown = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryMALiabilityDropdown\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.uninsuredMotoristBodilyInjuryMALiabilityFAQ = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryMALiabilityFAQ\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH)
    this.uninsuredMotoristBodilyInjuryMALiabilityAmount = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryMALiabilityAmount\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.uninsuredMotoristBodilyInjuryMALiabilityRefreshIcon = page.locator("[data-legacy-field=\"uninsuredMotoristBodilyInjuryMALiabilityRefreshIcon\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.underinsuredMotoristBodilyInjuryMALiabilityLabel = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryMALiabilityLabel\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_LABEL)
    this.underinsuredMotoristBodilyInjuryMALiabilityDropdown = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryMALiabilityDropdown\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.underinsuredMotoristBodilyInjuryMALiabilityFAQ = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryMALiabilityFAQ\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH)
    this.underinsuredMotoristBodilyInjuryMALiabilityAmount = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryMALiabilityAmount\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.underinsuredMotoristBodilyInjuryMALiabilityRefreshIcon = page.locator("[data-legacy-field=\"underinsuredMotoristBodilyInjuryMALiabilityRefreshIcon\"]"); // @FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.medicalPaymentsLiabilityLabel = page.locator("[data-legacy-field=\"medicalPaymentsLiabilityLabel\"]"); // @FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_LABEL)
    this.medicalPaymentsLiabilityDropdown = page.locator("[data-legacy-field=\"medicalPaymentsLiabilityDropdown\"]"); // @FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.medicalPaymentsLiabilityFAQ = page.locator("[data-legacy-field=\"medicalPaymentsLiabilityFAQ\"]"); // @FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH)
    this.medicalPaymentsLiabilityAmount = page.locator("[data-legacy-field=\"medicalPaymentsLiabilityAmount\"]"); // @FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.medicalPaymentsLiabilityRefreshIcon = page.locator("[data-legacy-field=\"medicalPaymentsLiabilityRefreshIcon\"]"); // @FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.medicalPaymentsLiabilityErrorLabel = page.locator("[data-legacy-field=\"medicalPaymentsLiabilityErrorLabel\"]"); // @FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
    this.medicalPaymentsLiabilityErrorMessage = page.locator("[data-legacy-field=\"medicalPaymentsLiabilityErrorMessage\"]"); // @FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_ERROR_MSG)
    this.personalInjuryProtectionMALiabilityLabel = page.locator("[data-legacy-field=\"personalInjuryProtectionMALiabilityLabel\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_MASS_FAQ_XPATH + XPATH_TO_LABEL)
    this.personalInjuryProtectionMALiabilityDropdown = page.locator("[data-legacy-field=\"personalInjuryProtectionMALiabilityDropdown\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.personalInjuryProtectionMALiabilityFAQ = page.locator("[data-legacy-field=\"personalInjuryProtectionMALiabilityFAQ\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_MASS_FAQ_XPATH)
    this.personalInjuryProtectionMALiabilityAmount = page.locator("[data-legacy-field=\"personalInjuryProtectionMALiabilityAmount\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.personalInjuryProtectionMALiabilityRefreshIcon = page.locator("[data-legacy-field=\"personalInjuryProtectionMALiabilityRefreshIcon\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.personalInjuryProtectionDeductibleLiabilityLabel = page.locator("[data-legacy-field=\"personalInjuryProtectionDeductibleLiabilityLabel\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_FAQ_XPATH + XPATH_TO_LABEL)
    this.personalInjuryProtectionDeductibleLiabilityDropdown = page.locator("[data-legacy-field=\"personalInjuryProtectionDeductibleLiabilityDropdown\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.personalInjuryProtectionDeductibleLiabilityFAQ = page.locator("[data-legacy-field=\"personalInjuryProtectionDeductibleLiabilityFAQ\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_FAQ_XPATH)
    this.personalInjuryProtectionDeductibleLiabilityAmount = page.locator("[data-legacy-field=\"personalInjuryProtectionDeductibleLiabilityAmount\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.personalInjuryProtectionDeductibleLiabilityRefreshIcon = page.locator("[data-legacy-field=\"personalInjuryProtectionDeductibleLiabilityRefreshIcon\"]"); // @FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.comprehensiveMACoverageLabel = page.locator("[data-legacy-field=\"comprehensiveMACoverageLabel\"]"); // @FindBy(xpath = COMPREHENSIVE_MASS_FAQ_XPATH + XPATH_TO_LABEL)
    this.comprehensiveMACoverageDropdown = page.locator("[data-legacy-field=\"comprehensiveMACoverageDropdown\"]"); // @FindBy(xpath = COMPREHENSIVE_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.comprehensiveMACoverageFAQ = page.locator("[data-legacy-field=\"comprehensiveMACoverageFAQ\"]"); // @FindBy(xpath = COMPREHENSIVE_MASS_FAQ_XPATH)
    this.comprehensiveMACoverageAmount = page.locator("[data-legacy-field=\"comprehensiveMACoverageAmount\"]"); // @FindBy(xpath = COMPREHENSIVE_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.comprehensiveMACoverageRefreshIcon = page.locator("[data-legacy-field=\"comprehensiveMACoverageRefreshIcon\"]"); // @FindBy(xpath = COMPREHENSIVE_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.collisionMACoverageLabel = page.locator("[data-legacy-field=\"collisionMACoverageLabel\"]"); // @FindBy(xpath = COLLISION_MASS_FAQ_XPATH + XPATH_TO_LABEL)
    this.collisionMACoverageDropdown = page.locator("[data-legacy-field=\"collisionMACoverageDropdown\"]"); // @FindBy(xpath = COLLISION_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.collisionMACoverageFAQ = page.locator("[data-legacy-field=\"collisionMACoverageFAQ\"]"); // @FindBy(xpath = COLLISION_MASS_FAQ_XPATH)
    this.collisionMACoverageAmount = page.locator("[data-legacy-field=\"collisionMACoverageAmount\"]"); // @FindBy(xpath = COLLISION_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.collisionMACoverageRefreshIcon = page.locator("[data-legacy-field=\"collisionMACoverageRefreshIcon\"]"); // @FindBy(xpath = COLLISION_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.limitedCollisionCoverageLabel = page.locator("[data-legacy-field=\"limitedCollisionCoverageLabel\"]"); // @FindBy(xpath = LIMITED_COLLISION_FAQ_XPATH + XPATH_TO_LABEL)
    this.limitedCollisionCoverageDropdown = page.locator("[data-legacy-field=\"limitedCollisionCoverageDropdown\"]"); // @FindBy(xpath = LIMITED_COLLISION_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.limitedCollisionCoverageFAQ = page.locator("[data-legacy-field=\"limitedCollisionCoverageFAQ\"]"); // @FindBy(xpath = LIMITED_COLLISION_FAQ_XPATH)
    this.limitedCollisionCoverageAmount = page.locator("[data-legacy-field=\"limitedCollisionCoverageAmount\"]"); // @FindBy(xpath = LIMITED_COLLISION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.limitedCollisionCoverageRefreshIcon = page.locator("[data-legacy-field=\"limitedCollisionCoverageRefreshIcon\"]"); // @FindBy(xpath = LIMITED_COLLISION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.towingAndLaborMACoverageLabel = page.locator("[data-legacy-field=\"towingAndLaborMACoverageLabel\"]"); // @FindBy(xpath = TOWING_LABOR_MASS_FAQ_XPATH + XPATH_TO_LABEL)
    this.towingAndLaborMACoverageDropdown = page.locator("[data-legacy-field=\"towingAndLaborMACoverageDropdown\"]"); // @FindBy(xpath = TOWING_LABOR_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.towingAndLaborMACoverageFAQ = page.locator("[data-legacy-field=\"towingAndLaborMACoverageFAQ\"]"); // @FindBy(xpath = TOWING_LABOR_MASS_FAQ_XPATH)
    this.towingAndLaborMACoverageAmount = page.locator("[data-legacy-field=\"towingAndLaborMACoverageAmount\"]"); // @FindBy(xpath = TOWING_LABOR_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.towingAndLaborMACoverageRefreshIcon = page.locator("[data-legacy-field=\"towingAndLaborMACoverageRefreshIcon\"]"); // @FindBy(xpath = TOWING_LABOR_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.substituteTransportationCoverageLabel = page.locator("[data-legacy-field=\"substituteTransportationCoverageLabel\"]"); // @FindBy(xpath = SUBSTITUTE_TRANSPORTATION_FAQ_XPATH + XPATH_TO_LABEL)
    this.substituteTransportationCoverageDropdown = page.locator("[data-legacy-field=\"substituteTransportationCoverageDropdown\"]"); // @FindBy(xpath = SUBSTITUTE_TRANSPORTATION_FAQ_XPATH + XPATH_TO_DROPDOWN)
    this.substituteTransportationCoverageFAQ = page.locator("[data-legacy-field=\"substituteTransportationCoverageFAQ\"]"); // @FindBy(xpath = SUBSTITUTE_TRANSPORTATION_FAQ_XPATH)
    this.substituteTransportationCoverageAmount = page.locator("[data-legacy-field=\"substituteTransportationCoverageAmount\"]"); // @FindBy(xpath = SUBSTITUTE_TRANSPORTATION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
    this.substituteTransportationCoverageRefreshIcon = page.locator("[data-legacy-field=\"substituteTransportationCoverageRefreshIcon\"]"); // @FindBy(xpath = SUBSTITUTE_TRANSPORTATION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
    this.crossSellCondoQuote = page.locator("[data-legacy-field=\"crossSellCondoQuote\"]"); // @FindBy(xpath = CONDO_CROSSSELL_TEXT_XPATH)
    this.crossSellHomeQuote = page.locator("[data-legacy-field=\"crossSellHomeQuote\"]"); // @FindBy(xpath = HOME_CROSSSELL_TEXT_XPATH)
    this.crossSellRentersQuote = page.locator("[data-legacy-field=\"crossSellRentersQuote\"]"); // @FindBy(xpath = RENTERS_CROSSSELL_TEXT_XPATH)
    this.crossSellVTLQuote = page.locator("[data-legacy-field=\"crossSellVTLQuote\"]"); // @FindBy(xpath = VTL_CROSSSELL_TEXT_XPATH)
  }
}
