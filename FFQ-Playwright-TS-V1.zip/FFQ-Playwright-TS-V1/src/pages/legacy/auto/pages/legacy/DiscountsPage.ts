// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.legacy.DiscountsPage. */
export class DiscountsPage extends CoreBasePage {
  public readonly discountsPageHeader: Locator;
  public readonly discountsPageDescription: Locator;
  public readonly backButton: Locator;
  public readonly backButtonBW: Locator;
  public readonly nextYourQuoteButton: Locator;
  public readonly bwNextYourQuoteButton: Locator;
  public readonly policyStartDateDescription: Locator;
  public readonly policyStartDateEntryField: Locator;
  public readonly residenceOwnershipDescription: Locator;
  public readonly bwResidenceOwnershipDescription: Locator;
  public readonly bwOldResidenceOwnershipDescription: Locator;
  public readonly ownAHomeRadioButton: Locator;
  public readonly rentRadioButton: Locator;
  public readonly otherRadioButton: Locator;
  public readonly bwOwnAHomeRadioButton: Locator;
  public readonly bwRentRadioButton: Locator;
  public readonly bwNoInsuranceRadioButton: Locator;
  public readonly bwMobileHomeRadioButton: Locator;
  public readonly bwOldOwnAHomeRadioButton: Locator;
  public readonly bwOldRentRadioButton: Locator;
  public readonly bwOtherRadioButton: Locator;
  public readonly residenceOwnershipDropDown: Locator;
  public readonly noInsuranceRadioButton: Locator;
  public readonly rentersInsuranceRadioButton: Locator;
  public readonly homeCondoInsuranceRadioButton: Locator;
  public readonly mobilehomeInsuranceRadioButton: Locator;
  public readonly bundleInsuranceDescription: Locator;
  public readonly bundleInsuranceDescriptionBW: Locator;
  public readonly bundleHomeInsuranceCheckbox: Locator;
  public readonly bundleBWHomeInsuranceCheckbox: Locator;
  public readonly bundleRentersInsuranceCheckbox: Locator;
  public readonly bundleBWRentersInsuranceCheckbox: Locator;
  public readonly bundleCondoInsuranceCheckbox: Locator;
  public readonly bundleBWCondoInsuranceCheckbox: Locator;
  public readonly bundleVTLInsuranceCheckbox: Locator;
  public readonly bundleBWVTLInsuranceCheckbox: Locator;
  public readonly bundleUmbrellaInsuranceCheckbox: Locator;
  public readonly bundleBWUmbrellaInsuranceCheckbox: Locator;
  public readonly bundleBusinessInsuranceCheckbox: Locator;
  public readonly bundleBWBusinessInsuranceCheckbox: Locator;
  public readonly bundleBoatInsuranceCheckbox: Locator;
  public readonly bundleORVInsuranceCheckbox: Locator;
  public readonly bundleMotorhomeInsuranceCheckbox: Locator;
  public readonly disabilityCoverageDescription: Locator;
  public readonly disabilityCoverageRadioButton: Locator;
  public readonly noDisabilityCoverageRadioButton: Locator;
  public readonly otherInsurancePoliciesDescription: Locator;
  public readonly otherInsurancePoliciesDropDown: Locator;
  public readonly dwellersInHouseholdDescription: Locator;
  public readonly dwellersInHouseholdDropDown: Locator;

  public constructor(page: Page) {
    super(page);
    this.discountsPageHeader = page.locator("#auto-module_header-title"); // @FindBy(id = "auto-module_header-title")
    this.discountsPageDescription = page.locator(".auto-module_title-description-text"); // @FindBy(className = "auto-module_title-description-text")
    this.backButton = page.locator("xpath=//button[@data-gtm='FFQ_Auto_Discount_back_button']"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_Discount_back_button']")
    this.backButtonBW = page.locator("xpath=//button[@data-gtm='FFQ_Auto_BWDiscount_back_button']"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_BWDiscount_back_button']")
    this.nextYourQuoteButton = page.locator("xpath=//div[@class='auto-module__discount-button-container']//button[3]"); // @FindBy(xpath = "//div[@class='auto-module__discount-button-container']//button[3]")
    this.bwNextYourQuoteButton = page.locator("xpath=//button[@data-gtm='FFQ_Auto_BWDiscount_next_button' and contains(@class, 'right_button')]"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_BWDiscount_next_button' and contains(@class, 'right_button')]")
    this.policyStartDateDescription = page.locator("xpath=//p[@class='auto-module__discount-text' and contains(text(), 'new policy to start')]"); // @FindBy(xpath = "//p[@class='auto-module__discount-text' and contains(text(), 'new policy to start')]")
    this.policyStartDateEntryField = page.locator("xpath=//span/label/mat-label[contains(text(),'policy start date')]/../../../input"); // @FindBy(xpath = "//span/label/mat-label[contains(text(),'policy start date')]/../../../input")
    this.residenceOwnershipDescription = page.locator("xpath=//p[@class='auto-module__discount_subheader-text' and contains(text(), 'Do you own or rent')]"); // @FindBy(xpath = "//p[@class='auto-module__discount_subheader-text' and contains(text(), 'Do you own or rent')]")
    this.bwResidenceOwnershipDescription = page.locator(".auto-module__discount-text"); // @FindBy(className = "auto-module__discount-text")
    this.bwOldResidenceOwnershipDescription = page.locator(".auto-module__discount-text"); // @FindBy(className = "auto-module__discount-text")
    this.ownAHomeRadioButton = page.locator("[data-legacy-field=\"ownAHomeRadioButton\"]"); // @FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_Auto_Discounts_ownHome_radio']")
    this.rentRadioButton = page.locator("[data-legacy-field=\"rentRadioButton\"]"); // @FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_Auto_Discounts_Rent_radio']")
    this.otherRadioButton = page.locator("[data-legacy-field=\"otherRadioButton\"]"); // @FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_Auto_Discounts_NoAns_radio']")
    this.bwOwnAHomeRadioButton = page.locator("[data-legacy-field=\"bwOwnAHomeRadioButton\"]"); // @FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_Primaryresidenceinsurance_HomeCondo_radio']")
    this.bwRentRadioButton = page.locator("[data-legacy-field=\"bwRentRadioButton\"]"); // @FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_Primaryresidenceinsurance_Renters_radio']")
    this.bwNoInsuranceRadioButton = page.locator("[data-legacy-field=\"bwNoInsuranceRadioButton\"]"); // @FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_Primaryresidenceinsurance_None_radio']")
    this.bwMobileHomeRadioButton = page.locator("[data-legacy-field=\"bwMobileHomeRadioButton\"]"); // @FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_Primaryresidenceinsurance_Mobilehome_radio']")
    this.bwOldOwnAHomeRadioButton = page.locator("[data-legacy-field=\"bwOldOwnAHomeRadioButton\"]"); // @FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_ownHome_radio']")
    this.bwOldRentRadioButton = page.locator("[data-legacy-field=\"bwOldRentRadioButton\"]"); // @FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_Rent_radio']")
    this.bwOtherRadioButton = page.locator("[data-legacy-field=\"bwOtherRadioButton\"]"); // @FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_NoAns_radio']")
    this.residenceOwnershipDropDown = page.locator("xpath=//div/p[contains(text(),'Do you own or rent')]/../div[@class='auto-module__discount-form-element']/lib-select/mat-form-field/div/div/div/mat-select"); // @FindBy(xpath = "//div/p[contains(text(),'Do you own or rent')]/../div[@class='auto-module__discount-form-element']/lib-select/mat-form-field/div/div/div/mat-select")
    this.noInsuranceRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_Primaryresidenceinsurance_None_radio']"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_Primaryresidenceinsurance_None_radio']")
    this.rentersInsuranceRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_Primaryresidenceinsurance_Renters_radio']"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_Primaryresidenceinsurance_Renters_radio']")
    this.homeCondoInsuranceRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_Primaryresidenceinsurance_HomeCondo_radio']"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_Primaryresidenceinsurance_HomeCondo_radio']")
    this.mobilehomeInsuranceRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_Primaryresidenceinsurance_Mobilehome_radio']"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_Primaryresidenceinsurance_Mobilehome_radio']")
    this.bundleInsuranceDescription = page.locator("xpath=//p[@class='auto-module__discount_subheader-text' and contains(text(), 'interested in bundling')]"); // @FindBy(xpath = "//p[@class='auto-module__discount_subheader-text' and contains(text(), 'interested in bundling')]")
    this.bundleInsuranceDescriptionBW = page.locator("xpath=//p[@class='auto-module__discount-text' and contains(text(), 'Do you own')]"); // @FindBy(xpath = "//p[@class='auto-module__discount-text' and contains(text(), 'Do you own')]")
    this.bundleHomeInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_homecrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_homecrosssell_checkbox']")
    this.bundleBWHomeInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_homecrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_homecrosssell_checkbox']")
    this.bundleRentersInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_renterscrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_renterscrosssell_checkbox']")
    this.bundleBWRentersInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_renterscrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_renterscrosssell_checkbox']")
    this.bundleCondoInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_condocrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_condocrosssell_checkbox']")
    this.bundleBWCondoInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_condocrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_condocrosssell_checkbox']")
    this.bundleVTLInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_Lifecrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_Lifecrosssell_checkbox']")
    this.bundleBWVTLInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_Lifecrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_Lifecrosssell_checkbox']")
    this.bundleUmbrellaInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_Umbrellacrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_Umbrellacrosssell_checkbox']")
    this.bundleBWUmbrellaInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_Umbrellacrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_Umbrellacrosssell_checkbox']")
    this.bundleBusinessInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_businesscrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_businesscrosssell_checkbox']")
    this.bundleBWBusinessInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_businesscrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_businesscrosssell_checkbox']")
    this.bundleBoatInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_recreationalcrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_recreationalcrosssell_checkbox']")
    this.bundleORVInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_offroadcrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_offroadcrosssell_checkbox']")
    this.bundleMotorhomeInsuranceCheckbox = page.locator("xpath=//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_motorhomecrosssell_checkbox']"); // @FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_motorhomecrosssell_checkbox']")
    this.disabilityCoverageDescription = page.locator("[data-legacy-field=\"disabilityCoverageDescription\"]"); // @FindBy(xpath = XPATH_TO_DISABILITY_INSURANCE)
    this.disabilityCoverageRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_disabilitycoverage_yes_radio']"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_disabilitycoverage_yes_radio']")
    this.noDisabilityCoverageRadioButton = page.locator("xpath=//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_disabilitycoverage_no_radio']"); // @FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_disabilitycoverage_no_radio']")
    this.otherInsurancePoliciesDescription = page.locator("xpath=//p[@class='auto-module__discount-text' and contains(text(), 'following insurance policies')]"); // @FindBy(xpath = "//p[@class='auto-module__discount-text' and contains(text(), 'following insurance policies')]")
    this.otherInsurancePoliciesDropDown = page.locator("xpath=//mat-select[@data-gtm='FFQ_Auto_Discounts_Insurancepolicies_dropdown']"); // @FindBy(xpath = "//mat-select[@data-gtm='FFQ_Auto_Discounts_Insurancepolicies_dropdown']")
    this.dwellersInHouseholdDescription = page.locator("xpath=//p[@class='auto-module__discount-text' and contains(text(), 'many people')]"); // @FindBy(xpath = "//p[@class='auto-module__discount-text' and contains(text(), 'many people')]")
    this.dwellersInHouseholdDropDown = page.locator("xpath=//mat-select[contains(@aria-label, 'people in household')]"); // @FindBy(xpath = "//mat-select[contains(@aria-label, 'people in household')]")
  }
}
