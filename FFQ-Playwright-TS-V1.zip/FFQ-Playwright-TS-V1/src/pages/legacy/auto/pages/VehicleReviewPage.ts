// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.VehicleReviewPage. */
export class VehicleReviewPage extends CoreBasePage {
  public readonly vehicleReviewPageTitle: Locator;
  public readonly vehicleReviewPageDescription: Locator;
  public readonly reviseVehiclesLink: Locator;
  public readonly continueToDriversButton: Locator;
  public readonly lblVIN: Locator;
  public readonly lblEditVehicleHeader: Locator;
  public readonly inputVINMasked: Locator;
  public readonly inputYearFilled: Locator;
  public readonly vinToggleOnTheSideSheet: Locator;
  public readonly whereICanFindThisLink: Locator;
  public readonly vinHelperHeader: Locator;
  public readonly vinHelperHeaderLabel: Locator;
  public readonly backToVinButton: Locator;
  public readonly vehicleUsageMatIcon: Locator;
  public readonly btnClose: Locator;
  public readonly lblFirstVehicleHeader: Locator;
  public readonly btnOpenDateOfPurchaseCalendar: Locator;
  public readonly alternativeFuelCheckBox: Locator;
  public readonly antiTheftCheckBox: Locator;
  public readonly lblFirstEnabledDateOfPurchaseCalendar: Locator;
  public readonly vehicleSideSheetHeader: Locator;
  public readonly sideSheetVINInputField: Locator;
  public readonly defaultGarageRadioButtons: Locator;
  public readonly otherLocationRadioButtons: Locator;
  public readonly editButtons: Locator;
  public readonly personalToggles: Locator;
  public readonly datePickers: Locator;
  public readonly pageCtaErrorMessage: Locator;
  public readonly listOfVehicleDescriptions: Locator;

  public constructor(page: Page) {
    super(page);
    this.vehicleReviewPageTitle = page.locator("xpath=//app-vehicles-review//h1"); // @FindBy(xpath = "//app-vehicles-review//h1")
    this.vehicleReviewPageDescription = page.locator("xpath=//button[@id='reviseButton']/parent::div"); // @FindBy(xpath = "//button[@id='reviseButton']/parent::div")
    this.reviseVehiclesLink = page.locator("xpath=//*[contains(@class, 'auto-vehicles-review__revise-button')]"); // @FindBy(xpath = "//*[contains(@class, 'auto-vehicles-review__revise-button')]")
    this.continueToDriversButton = page.locator("xpath=//button[contains(@class,'auto-vehicles-review__continue-button')]"); // @FindBy(xpath = "//button[contains(@class,'auto-vehicles-review__continue-button')]")
    this.lblVIN = page.locator("xpath=//div[contains(@id,'vehicleSection')]//h2[@class='tui-h2']"); // @FindBy(xpath = "//div[contains(@id,'vehicleSection')]//h2[@class='tui-h2']")
    this.lblEditVehicleHeader = page.locator("xpath=//h4[normalize-space(text())='Edit vehicle']"); // @FindBy(xpath = "//h4[normalize-space(text())='Edit vehicle']"),             @FindBy(xpath = "//h2[normalize-space(text())='Edit vehicle']")     })
    this.inputVINMasked = page.locator("xpath=//mat-label[contains(normalize-space(text()),'VIN')]/ancestor::div[1]/input[contains(@class,'ng-valid')]"); // @FindBy(xpath = "//mat-label[contains(normalize-space(text()),'VIN')]/ancestor::div[1]/input[contains(@class,'ng-valid')]")
    this.inputYearFilled = page.locator("xpath=//mat-label[contains(normalize-space(text()),'Year')]/ancestor::div[1]//span[contains(@class,'mat-select-min-line')]"); // @FindBy(xpath = "//mat-label[contains(normalize-space(text()),'Year')]/ancestor::div[1]//span[contains(@class,'mat-select-min-line')]")
    this.vinToggleOnTheSideSheet = page.locator("xpath=//button[contains(.,'VIN')]"); // @FindBy(xpath = "//button[contains(.,'VIN')]")
    this.whereICanFindThisLink = page.locator("xpath=//div[contains(@class,'auto-add-vehicle-vin__disclaimer row pt-4')]//a"); // @FindBy(xpath = "//div[contains(@class,'auto-add-vehicle-vin__disclaimer row pt-4')]//a")
    this.vinHelperHeader = page.locator("div[class='tui-vin-modal-header']"); // @FindBy(css = "div[class='tui-vin-modal-header']")
    this.vinHelperHeaderLabel = page.locator("xpath=//div[@class='tui-vin-modal-header']//p"); // @FindBy(xpath = "//div[@class='tui-vin-modal-header']//p")
    this.backToVinButton = page.locator("xpath=//button[@class='tui-btn tui-btn-primary tui-vin-back-to-vin-button']"); // @FindBy(xpath = "//button[@class='tui-btn tui-btn-primary tui-vin-back-to-vin-button']")
    this.vehicleUsageMatIcon = page.locator("xpath=//mat-icon[@data-tui-tracking-id='auto-vehicles-review__vehicle-usage-info']"); // @FindBy(xpath = "//mat-icon[@data-tui-tracking-id='auto-vehicles-review__vehicle-usage-info']")
    this.btnClose = page.locator("xpath=//mat-icon[@role='button' and text()='close']"); // @FindBy(xpath = "//mat-icon[@role='button' and text()='close']")
    this.lblFirstVehicleHeader = page.locator("xpath=//div[@id='vehicleSection0']/h2"); // @FindBy(xpath = "//div[@id='vehicleSection0']/h2")
    this.btnOpenDateOfPurchaseCalendar = page.locator("xpath=//button[@aria-label='Open calendar']"); // @FindBy(xpath = "//button[@aria-label='Open calendar']")
    this.alternativeFuelCheckBox = page.locator("xpath=//div//mat-checkbox[contains(@data-test-id,'ALTERNATIVE_FUEL_CHECKBOX')]"); // @FindBy(xpath = "//div//mat-checkbox[contains(@data-test-id,'ALTERNATIVE_FUEL_CHECKBOX')]")
    this.antiTheftCheckBox = page.locator("xpath=//div//mat-checkbox[contains(@data-test-id,'ANTI_THEFT_CHECKBOX')]"); // @FindBy(xpath = "//div//mat-checkbox[contains(@data-test-id,'ANTI_THEFT_CHECKBOX')]")
    this.lblFirstEnabledDateOfPurchaseCalendar = page.locator("xpath=(//tbody[@class='mat-calendar-body']//button[not(contains(@class,'disabled'))]/span[contains(@class,'cell-content')])[1]"); // @FindBy(xpath = "(//tbody[@class='mat-calendar-body']//button[not(contains(@class,'disabled'))]/span[contains(@class,'cell-content')])[1]")
    this.vehicleSideSheetHeader = page.locator("#addVehicleHeading"); // @FindBy(id = "addVehicleHeading")
    this.sideSheetVINInputField = page.locator("#auto-add-vehicle-vin__input-section"); // @FindBy(id = "auto-add-vehicle-vin__input-section")
    this.defaultGarageRadioButtons = page.locator("xpath=//mat-radio-group[@aria-labelledBy='parkingInfo_ariaLabel']//input[not(contains(@aria-label,'Other location'))]"); // @FindBy(xpath = "//mat-radio-group[@aria-labelledBy='parkingInfo_ariaLabel']//input[not(contains(@aria-label,'Other location'))]")
    this.otherLocationRadioButtons = page.locator("xpath=//mat-radio-button[contains(.,'Other location')]//input"); // @FindBy(xpath = "//mat-radio-button[contains(.,'Other location')]//input")
    this.editButtons = page.locator("xpath=//button[contains(@aria-label,'Edit')]"); // @FindBy(xpath = "//button[contains(@aria-label,'Edit')]")
    this.personalToggles = page.locator("xpath=//mat-button-toggle[contains(.,'Personal')]//button"); // @FindBy(xpath = "//mat-button-toggle[contains(.,'Personal')]//button")
    this.datePickers = page.locator("[data-legacy-field=\"datePickers\"]"); // @FindBy(xpath = VEHICLE_ACQUIRED_DATE_PICKER)
    this.pageCtaErrorMessage = page.locator("[data-legacy-field=\"pageCtaErrorMessage\"]"); // @FindBy(xpath = CTA_ERROR_MESSAGE_XPATH)
    this.listOfVehicleDescriptions = page.locator("[data-legacy-field=\"listOfVehicleDescriptions\"]"); // @FindBy(xpath = VEHICLE_DESCRIPTION_XPATH)
  }
}
