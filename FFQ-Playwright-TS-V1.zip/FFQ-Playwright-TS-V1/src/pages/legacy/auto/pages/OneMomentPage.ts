// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.OneMomentPage. */
export class OneMomentPage extends CoreBasePage {
  public readonly pageContent: Locator;
  public readonly pageTitle: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageContent = page.locator("xpath=//p[contains(@class, 'auto-spinner__subheading')]"); // @FindBy(xpath = "//p[contains(@class, 'auto-spinner__subheading')]")
    this.pageTitle = page.locator("xpath=//app-one-moment//h1"); // @FindBy(xpath = "//app-one-moment//h1")
  }
}
