// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.AutoBasePage. */
export class AutoBasePage extends CoreBasePage {
  public readonly genericHelpPopupTitle: Locator;
  public readonly genericHelpPopupContent: Locator;
  public readonly helpPopupNeedMoreHelp: Locator;
  public readonly retrievedQuoteModalContinueButton: Locator;
  public readonly continueOnlineWithBWButton: Locator;
  public readonly speakToBWFarmersAgentButton: Locator;
  public readonly continueOnlineWithForemostButton: Locator;
  public readonly speakToForemostFarmersAgentButton: Locator;
  public readonly buttonNext: Locator;
  public readonly buttonBack: Locator;
  public readonly brandSelectionErrorMessage: Locator;
  public readonly faqDialogCloseButton: Locator;
  public readonly faqDialogTitle: Locator;
  public readonly faqDialogContent: Locator;
  public readonly qualtricsSurveyPopUp: Locator;
  public readonly yesIWillGiveFeedbackButton: Locator;
  public readonly willYouRecommendQuestion: Locator;
  public readonly notAtAllLikely: Locator;
  public readonly nextButton: Locator;
  public readonly extremelyLikely: Locator;
  public readonly whyDidYouGiveARating: Locator;
  public readonly whyDidYouGiveARatingTextArea: Locator;
  public readonly qualtricsErrorMessage: Locator;
  public readonly ratingRadioButtonsLabels: Locator;
  public readonly ratingRadioButtons: Locator;
  public readonly navigateAwayButton: Locator;
  public readonly yourInfoPageNavigationLink: Locator;
  public readonly vehiclesPageNavigationLink: Locator;
  public readonly vehiclesPageSmallScreenNavigationLink: Locator;
  public readonly driversPageNavigationLink: Locator;
  public readonly driversPageSmallScreenNavigationLink: Locator;
  public readonly discountsPageNavigationLink: Locator;
  public readonly discountsPageSmallScreenNavigationLink: Locator;
  public readonly quotePageNavigationLink: Locator;
  public readonly quotePageSmallScreenNavigationLink: Locator;
  public readonly saveQuoteAndFinishLaterSidePanelLink: Locator;
  public readonly saveQuoteAndFinishLaterPageLink: Locator;
  public readonly agentImage: Locator;
  public readonly agentSectionYourAgent: Locator;
  public readonly agentSectionAgentName: Locator;
  public readonly agentMailID: Locator;
  public readonly agentAddress: Locator;
  public readonly agentPhoneNumber: Locator;
  public readonly agentContactMeButton: Locator;
  public readonly noAgentAssigned: Locator;
  public readonly farmersPhoneNumber: Locator;
  public readonly bristolWestModalContent: Locator;
  public readonly doNotContinueOnBristolWest: Locator;
  public readonly continueOnBristolWest: Locator;
  public readonly continueOnForemost: Locator;
  public readonly bristolWestLogoByClass: Locator;
  public readonly inconveniencePageHeader: Locator;
  public readonly aceCantFinishQuotePage: Locator;
  public readonly aceCantFinishQuoteNumber: Locator;
  public readonly inconveniencePageQuoteNumber: Locator;
  public readonly specialAttentionPageHeader: Locator;
  public readonly saveAndExitButton: Locator;
  public readonly enterInfoNavigationBarStepper: Locator;
  public readonly enterInfoNavigationBarStepperMobile: Locator;
  public readonly reviewQuoteNavigationBarStepper: Locator;
  public readonly reviewQuoteNavigationBarStepperMobile: Locator;
  public readonly purchaseNavigationBarStepper: Locator;

  public constructor(page: Page) {
    super(page);
    this.genericHelpPopupTitle = page.locator("#FFQAuto_Modal_header"); // @FindBy(id = "FFQAuto_Modal_header")
    this.genericHelpPopupContent = page.locator("#FFQAuto_Modal_popUpBody"); // @FindBy(id = "FFQAuto_Modal_popUpBody")
    this.helpPopupNeedMoreHelp = page.locator("#FFQAuto_Modal_needHelp"); // @FindBy(id = "FFQAuto_Modal_needHelp")
    this.retrievedQuoteModalContinueButton = page.locator("#FFQAuto_Modal_ContBtn"); // @FindBy(id = "FFQAuto_Modal_ContBtn")
    this.continueOnlineWithBWButton = page.locator("#FFQAuto_Modal_discountBWConBWBtn"); // @FindBy(id = "FFQAuto_Modal_discountBWConBWBtn")
    this.speakToBWFarmersAgentButton = page.locator("#FFQAuto_Modal_discountBWConFarmersBtn"); // @FindBy(id = "FFQAuto_Modal_discountBWConFarmersBtn")
    this.continueOnlineWithForemostButton = page.locator("#FFQAuto_Modal_discountBWConBWBtnForeMost"); // @FindBy(id = "FFQAuto_Modal_discountBWConBWBtnForeMost")
    this.speakToForemostFarmersAgentButton = page.locator("#FFQAuto_Modal_discountBWConFarmersBtnForeMost"); // @FindBy(id = "FFQAuto_Modal_discountBWConFarmersBtnForeMost")
    this.buttonNext = page.locator("xpath=//button//span[contains(text(),'NEXT')]"); // @FindBy(xpath = "//button//span[contains(text(),'NEXT')]")
    this.buttonBack = page.locator("xpath=//button//span[contains(text()='BACK')]"); // @FindBy(xpath = "//button//span[contains(text()='BACK')]")
    this.brandSelectionErrorMessage = page.locator("p[class='tui-small-text brand-error-message ng-star-inserted']"); // @FindBy(css = "p[class='tui-small-text brand-error-message ng-star-inserted']")
    this.faqDialogCloseButton = page.locator("xpath=//button[@class='dialog__info-dialog-button-close']"); // @FindBy(xpath = "//button[@class='dialog__info-dialog-button-close']")
    this.faqDialogTitle = page.locator(".dialog_info-dialog-title"); // @FindBy(className = "dialog_info-dialog-title")
    this.faqDialogContent = page.locator(".dialog_info-dialog-content"); // @FindBy(className = "dialog_info-dialog-content")
    this.qualtricsSurveyPopUp = page.locator("div[class*='_PopOverContainer'] > div:first-child"); // @FindBy(css = "div[class*='_PopOverContainer'] > div:first-child")
    this.yesIWillGiveFeedbackButton = page.locator("div[class*='_PopOverContainer'] > div:last-child img"); // @FindBy(css = "div[class*='_PopOverContainer'] > div:last-child img")
    this.willYouRecommendQuestion = page.locator("xpath=//legend//div//span[text()]"); // @FindBy(xpath = "//legend//div//span[text()]")
    this.notAtAllLikely = page.locator(".ColumnLabel.First"); // @FindBy(css = ".ColumnLabel.First")
    this.nextButton = page.locator(".NextButton.Button"); // @FindBy(css = ".NextButton.Button")
    this.extremelyLikely = page.locator(".ColumnLabel.Last"); // @FindBy(css = ".ColumnLabel.Last")
    this.whyDidYouGiveARating = page.locator("legend > label"); // @FindBy(css = "legend > label")
    this.whyDidYouGiveARatingTextArea = page.locator(".ChoiceStructure .InputText"); // @FindBy(css = ".ChoiceStructure .InputText")
    this.qualtricsErrorMessage = page.locator("//div[@class='ValidationError']/../div[1]"); // @FindBy(css = "//div[@class='ValidationError']/../div[1]")
    this.ratingRadioButtonsLabels = page.locator("xpath=//td[./label]//label/span[text()]"); // @FindBy(xpath = "//td[./label]//label/span[text()]")
    this.ratingRadioButtons = page.locator("xpath=//td[./label]//label/span[text()]/ancestor::td/label"); // @FindBy(xpath = "//td[./label]//label/span[text()]/ancestor::td/label")
    this.navigateAwayButton = page.locator("[data-legacy-field=\"navigateAwayButton\"]"); // @FindBy(xpath = NAVIGATE_AWAY_XPATH)
    this.yourInfoPageNavigationLink = page.locator("xpath=//a[contains(@data-gtm,'FFQ_Auto_sidepanel_YourInfostepper_button')]"); // @FindBy(xpath = "//a[contains(@data-gtm,'FFQ_Auto_sidepanel_YourInfostepper_button')]")
    this.vehiclesPageNavigationLink = page.locator("xpath=//a[contains(@data-gtm,'FFQ_Auto_sidepanel_Vehiclestepper_button')]"); // @FindBy(xpath = "//a[contains(@data-gtm,'FFQ_Auto_sidepanel_Vehiclestepper_button')]")
    this.vehiclesPageSmallScreenNavigationLink = page.locator("xpath=//div[@class='navigationStepperTop']/div/a[2]"); // @FindBy(xpath = "//div[@class='navigationStepperTop']/div/a[2]")
    this.driversPageNavigationLink = page.locator("xpath=//a[contains(@data-gtm,'FFQ_Auto_sidepanel_Driverstepper_button')]"); // @FindBy(xpath = "//a[contains(@data-gtm,'FFQ_Auto_sidepanel_Driverstepper_button')]")
    this.driversPageSmallScreenNavigationLink = page.locator("xpath=//div[@class='navigationStepperTop']/div/a[3]"); // @FindBy(xpath = "//div[@class='navigationStepperTop']/div/a[3]")
    this.discountsPageNavigationLink = page.locator("xpath=//a[contains(@data-gtm,'FFQ_Auto_sidepanel_Discountstepper_button')]"); // @FindBy(xpath = "//a[contains(@data-gtm,'FFQ_Auto_sidepanel_Discountstepper_button')]")
    this.discountsPageSmallScreenNavigationLink = page.locator("xpath=//div[@class='navigationStepperTop']/div/a[4]"); // @FindBy(xpath = "//div[@class='navigationStepperTop']/div/a[4]")
    this.quotePageNavigationLink = page.locator("xpath=//a[contains(@data-gtm,'FFQ_Auto_sidepanel_Quotestepper_button')]"); // @FindBy(xpath = "//a[contains(@data-gtm,'FFQ_Auto_sidepanel_Quotestepper_button')]")
    this.quotePageSmallScreenNavigationLink = page.locator("xpath=//div[@class='navigationStepperTop']/div/a[5]"); // @FindBy(xpath = "//div[@class='navigationStepperTop']/div/a[5]")
    this.saveQuoteAndFinishLaterSidePanelLink = page.locator("xpath=//div[@class='ffq-sidepanel-save-content']"); // @FindBy(xpath = "//div[@class='ffq-sidepanel-save-content']")
    this.saveQuoteAndFinishLaterPageLink = page.locator("xpath=//div[@class='ffq-panel-save-text']"); // @FindBy(xpath = "//div[@class='ffq-panel-save-text']")
    this.agentImage = page.locator("img[class='agent-image']"); // @FindBy(css = "img[class='agent-image']")
    this.agentSectionYourAgent = page.locator("xpath=//div[contains(@class,'tui-agent-box-column-2')]/div/div[1]"); // @FindBy(xpath = "//div[contains(@class,'tui-agent-box-column-2')]/div/div[1]")
    this.agentSectionAgentName = page.locator("xpath=//div[contains(@class,'tui-agent-box-column-2')]/div/div[2]"); // @FindBy(xpath = "//div[contains(@class,'tui-agent-box-column-2')]/div/div[2]")
    this.agentMailID = page.locator("xpath=//div[@class='pre-footer']//p[1]/a/span"); // @FindBy(xpath = "//div[@class='pre-footer']//p[1]/a/span")
    this.agentAddress = page.locator("xpath=//div[contains(@class,'agent-details-container')]/p/a[@target = '_blank']"); // @FindBy(xpath = "//div[contains(@class,'agent-details-container')]/p/a[@target = '_blank']")
    this.agentPhoneNumber = page.locator("xpath=(//a[contains(@aria-label,'Contact farmers representative')])[2]"); // @FindBy(xpath = "(//a[contains(@aria-label,'Contact farmers representative')])[2]")
    this.agentContactMeButton = page.locator("#auto-agent-details__contact-me-link"); // @FindBy(id = "auto-agent-details__contact-me-link")
    this.noAgentAssigned = page.locator(".need-help-caption"); // @FindBy(className = "need-help-caption")
    this.farmersPhoneNumber = page.locator("xpath=//*[contains(@class,'tui-call-phone-number-text')]"); // @FindBy(xpath = "//*[contains(@class,'tui-call-phone-number-text')]")
    this.bristolWestModalContent = page.locator("[data-legacy-field=\"bristolWestModalContent\"]"); // @FindBy(xpath = BRISTOL_WEST_MODAL_CONTENT_XPATH)
    this.doNotContinueOnBristolWest = page.locator("xpath=//button[@data-gtm='FFQ_Auto_BWmodal_close_button']"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_BWmodal_close_button']")
    this.continueOnBristolWest = page.locator("xpath=//button[contains(@class, 'auto-module_continue-to-bw-button-primary')] | //button[@data-gtm='FFQ_Auto_BWmodal_close_button']/span[text()='Continue']"); // @FindBy(xpath = "//button[contains(@class, 'auto-module_continue-to-bw-button-primary')] | //button[@data-gtm='FFQ_Auto_BWmodal_close_button']/span[text()='Continue']")
    this.continueOnForemost = page.locator("[data-legacy-field=\"continueOnForemost\"]"); // @FindBy(xpath = CONTINUE_ON_FOREMOST_XPATH)
    this.bristolWestLogoByClass = page.locator(".bright-line-logo"); // @FindBy(className = "bright-line-logo")
    this.inconveniencePageHeader = page.locator("#inconvenience_header-title"); // @FindBy(id = "inconvenience_header-title")
    this.aceCantFinishQuotePage = page.locator("[data-legacy-field=\"aceCantFinishQuotePage\"]"); // @FindBy(xpath = ACE_CANT_FINISH_QUOTE_TITLE_XPATH)
    this.aceCantFinishQuoteNumber = page.locator("xpath=//*[contains(@class, 'inconvenience__quote-number')]"); // @FindBy(xpath = "//*[contains(@class, 'inconvenience__quote-number')]")
    this.inconveniencePageQuoteNumber = page.locator(".quote_number"); // @FindBy(className = "quote_number")
    this.specialAttentionPageHeader = page.locator(".knock-out_header-title"); // @FindBy(className = "knock-out_header-title")
    this.saveAndExitButton = page.locator("xpath=//button[@data-gtm='FFQ_Auto_savefinishmodal_saveandexit_button']"); // @FindBy(xpath = "//button[@data-gtm='FFQ_Auto_savefinishmodal_saveandexit_button']")
    this.enterInfoNavigationBarStepper = page.locator("xpath=//div[@class='tui-desktop-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-enter-info']"); // @FindBy(xpath = "//div[@class='tui-desktop-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-enter-info']")
    this.enterInfoNavigationBarStepperMobile = page.locator("xpath=//div[@class='tui-mobile-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-enter-info']"); // @FindBy(xpath = "//div[@class='tui-mobile-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-enter-info']")
    this.reviewQuoteNavigationBarStepper = page.locator("xpath=//div[@class='tui-desktop-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-review-quote']"); // @FindBy(xpath = "//div[@class='tui-desktop-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-review-quote']")
    this.reviewQuoteNavigationBarStepperMobile = page.locator("xpath=//div[@class='tui-mobile-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-review-quote']"); // @FindBy(xpath = "//div[@class='tui-mobile-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-review-quote']")
    this.purchaseNavigationBarStepper = page.locator("xpath=//div[@class='tui-desktop-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-purchase']"); // @FindBy(xpath = "//div[@class='tui-desktop-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-purchase']")
  }
}
