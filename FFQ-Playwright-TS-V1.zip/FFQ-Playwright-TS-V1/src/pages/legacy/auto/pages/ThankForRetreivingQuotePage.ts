// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.ThankForRetreivingQuotePage. */
export class ThankForRetreivingQuotePage extends CoreBasePage {
  public readonly thankYouForRetreivingYourQuoteText: Locator;
  public readonly continueButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.thankYouForRetreivingYourQuoteText = page.locator(".auto-module__retrieve-confirmation-header-text"); // @FindBy(className = "auto-module__retrieve-confirmation-header-text")
    this.continueButton = page.locator("xpath=//mat-dialog-actions/button"); // @FindBy(xpath = "//mat-dialog-actions/button")
  }
}
