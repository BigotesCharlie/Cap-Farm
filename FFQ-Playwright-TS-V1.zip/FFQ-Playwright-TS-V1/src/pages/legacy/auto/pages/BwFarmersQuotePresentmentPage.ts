// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.BwFarmersQuotePresentmentPage. */
export class BwFarmersQuotePresentmentPage extends CoreBasePage {
  public readonly pageHeader: Locator;
  public readonly pageSubtitle: Locator;
  public readonly presentmentCardFarmers: Locator;
  public readonly presentmentCardBw: Locator;
  public readonly farmersCardLogo: Locator;
  public readonly bwCardLogo: Locator;
  public readonly learnMoreAboutBwBwLink: Locator;
  public readonly learnMoreAboutBwDialogueHeader: Locator;
  public readonly learnMoreAboutBwDialogueCloseIcon: Locator;
  public readonly learnMoreAboutBwDialogueBwLogo: Locator;
  public readonly learnMoreAboutBwDialogueDescription: Locator;
  public readonly learnMoreAboutBwDialogueCloseButton: Locator;
  public readonly farmersPrice: Locator;
  public readonly bwPrice: Locator;
  public readonly farmersPriceDescription: Locator;
  public readonly bwPriceDescription: Locator;
  public readonly farmersEstimatedText: Locator;
  public readonly bwEstimatedText: Locator;
  public readonly continueWithFarmersButton: Locator;
  public readonly continueWithBwButton: Locator;
  public readonly farmersBrandMessageOne: Locator;
  public readonly farmersBrandMessageTwo: Locator;
  public readonly bristolWestBrandMessageOne: Locator;
  public readonly bristolWestBrandMessageTwo: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageHeader = page.locator("xpath=//app-bw-farmers-quote//h1"); // @FindBy(xpath = "//app-bw-farmers-quote//h1")
    this.pageSubtitle = page.locator("div[class='presentment-stitle']"); // @FindBy(css = "div[class='presentment-stitle']")
    this.presentmentCardFarmers = page.locator("xpath=//mat-card[contains(@class,'presentment-card-farmers')]"); // @FindBy(xpath = "//mat-card[contains(@class,'presentment-card-farmers')]")
    this.presentmentCardBw = page.locator("xpath=//mat-card[contains(@class,'presentment-card-bristol')]"); // @FindBy(xpath = "//mat-card[contains(@class,'presentment-card-bristol')]")
    this.farmersCardLogo = page.locator("xpath=//mat-card[contains(@class,'farmers')]//img"); // @FindBy(xpath = "//mat-card[contains(@class,'farmers')]//img")
    this.bwCardLogo = page.locator("xpath=//mat-card[contains(@class,'bristol')]//img"); // @FindBy(xpath = "//mat-card[contains(@class,'bristol')]//img")
    this.learnMoreAboutBwBwLink = page.locator("xpath=//mat-card[contains(@class,'bristol')]//a"); // @FindBy(xpath = "//mat-card[contains(@class,'bristol')]//a")
    this.learnMoreAboutBwDialogueHeader = page.locator("xpath=//mat-dialog-container//div[@class='bw-farmers-heading-area']//span"); // @FindBy(xpath = "//mat-dialog-container//div[@class='bw-farmers-heading-area']//span")
    this.learnMoreAboutBwDialogueCloseIcon = page.locator("xpath=//mat-dialog-container//div[@class='bw-farmers-heading-area']//button"); // @FindBy(xpath = "//mat-dialog-container//div[@class='bw-farmers-heading-area']//button")
    this.learnMoreAboutBwDialogueBwLogo = page.locator("xpath=//mat-dialog-content//img"); // @FindBy(xpath = "//mat-dialog-content//img")
    this.learnMoreAboutBwDialogueDescription = page.locator("xpath=//mat-dialog-content//div[@class='tui-body-text-1']"); // @FindBy(xpath = "//mat-dialog-content//div[@class='tui-body-text-1']")
    this.learnMoreAboutBwDialogueCloseButton = page.locator("xpath=//button[@class='tui-btn tui-btn-primary popup-action-button']"); // @FindBy(xpath = "//button[@class='tui-btn tui-btn-primary popup-action-button']")
    this.farmersPrice = page.locator("xpath=//mat-card[contains(@class,'farmers')]//div[contains(@class,'tui-price')]"); // @FindBy(xpath = "//mat-card[contains(@class,'farmers')]//div[contains(@class,'tui-price')]")
    this.bwPrice = page.locator("xpath=//mat-card[contains(@class,'bristol')]//div[contains(@class,'tui-price')]"); // @FindBy(xpath = "//mat-card[contains(@class,'bristol')]//div[contains(@class,'tui-price')]")
    this.farmersPriceDescription = page.locator("xpath=//mat-card[contains(@class,'farmers')]//div[contains(@class,'price-description')]"); // @FindBy(xpath = "//mat-card[contains(@class,'farmers')]//div[contains(@class,'price-description')]")
    this.bwPriceDescription = page.locator("xpath=//mat-card[contains(@class,'bristol')]//div[contains(@class,'price-description')]"); // @FindBy(xpath = "//mat-card[contains(@class,'bristol')]//div[contains(@class,'price-description')]")
    this.farmersEstimatedText = page.locator("xpath=//mat-card[contains(@class,'farmers')]//div[contains(@class,'price-text')]"); // @FindBy(xpath = "//mat-card[contains(@class,'farmers')]//div[contains(@class,'price-text')]")
    this.bwEstimatedText = page.locator("xpath=//mat-card[contains(@class,'bristol')]//div[contains(@class,'price-text')]"); // @FindBy(xpath = "//mat-card[contains(@class,'bristol')]//div[contains(@class,'price-text')]")
    this.continueWithFarmersButton = page.locator("xpath=//mat-card[contains(@class,'farmers')]//button"); // @FindBy(xpath = "//mat-card[contains(@class,'farmers')]//button")
    this.continueWithBwButton = page.locator("xpath=//mat-card[contains(@class,'bristol')]//button"); // @FindBy(xpath = "//mat-card[contains(@class,'bristol')]//button")
    this.farmersBrandMessageOne = page.locator("xpath=//mat-card[contains(@class,'farmers')]//div[contains(@class,'presentment-content')][1]"); // @FindBy(xpath = "//mat-card[contains(@class,'farmers')]//div[contains(@class,'presentment-content')][1]")
    this.farmersBrandMessageTwo = page.locator("xpath=//mat-card[contains(@class,'farmers')]//div[contains(@class,'presentment-content')][2]"); // @FindBy(xpath = "//mat-card[contains(@class,'farmers')]//div[contains(@class,'presentment-content')][2]")
    this.bristolWestBrandMessageOne = page.locator("xpath=//mat-card[contains(@class,'bristol')]//div[contains(@class,'presentment-content')][1]"); // @FindBy(xpath = "//mat-card[contains(@class,'bristol')]//div[contains(@class,'presentment-content')][1]")
    this.bristolWestBrandMessageTwo = page.locator("xpath=//mat-card[contains(@class,'bristol')]//div[contains(@class,'presentment-content')][2]"); // @FindBy(xpath = "//mat-card[contains(@class,'bristol')]//div[contains(@class,'presentment-content')][2]")
  }
}
