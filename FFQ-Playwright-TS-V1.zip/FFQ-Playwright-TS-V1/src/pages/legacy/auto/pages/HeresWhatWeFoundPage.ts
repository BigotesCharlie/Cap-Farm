// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.HeresWhatWeFoundPage. */
export class HeresWhatWeFoundPage extends CoreBasePage {
  public readonly addAnotherVehicleLink: Locator;
  public readonly addVehicleDialog: Locator;
  public readonly checkBoxOfPNIDriver: Locator;
  public readonly continueToDriversButton: Locator;
  public readonly dateOfBirthEntryField: Locator;
  public readonly driversSectionTitle: Locator;
  public readonly editButtonOfPNIDriver: Locator;
  public readonly editDriverDialogHeader: Locator;
  public readonly errorMessage: Locator;
  public readonly duplicateDriverErrorMessage: Locator;
  public readonly heresWhatWeFoundPageHeader: Locator;
  public readonly heresWhatWeFoundPageDescription: Locator;
  public readonly heresWhatWeFoundPageTitle: Locator;
  public readonly listOfADPFDriversWithAges: Locator;
  public readonly listOfADPFVehicles: Locator;
  public readonly listOfADPFVehiclesCheckboxes: Locator;
  public readonly listOfADPFVehiclesNames: Locator;
  public readonly listOfAllDriverAges: Locator;
  public readonly listOfAllDriverDetailsSections: Locator;
  public readonly listOfAllDriverNames: Locator;
  public readonly listOfAllEditButtonOfAdditionalDriverDetails: Locator;
  public readonly listOfCheckedDriverAges: Locator;
  public readonly listOfCheckedDriverNames: Locator;
  public readonly listOfCheckedDrivers: Locator;
  public readonly listOfUncheckedDriverAges: Locator;
  public readonly listOfUncheckedDriverNames: Locator;
  public readonly selectedCurrentlyInsuredRadioButton: Locator;
  public readonly selectedDriverLicenseIssuedInUs: Locator;
  public readonly selectedGenderButton: Locator;
  public readonly sniApplicantRemovalNotification: Locator;
  public readonly vehiclesSectionTitle: Locator;

  public constructor(page: Page) {
    super(page);
    this.addAnotherVehicleLink = page.locator("xpath=//div[contains(@class, 'auto-vehicles-drivers-review__vehicles-list')]//a/span[contains(text(), 'Add another vehicle')]"); // @FindBy(xpath = "//div[contains(@class, 'auto-vehicles-drivers-review__vehicles-list')]//a/span[contains(text(), 'Add another vehicle')]")
    this.addVehicleDialog = page.locator("#addVehicleDialog"); // @FindBy(id = "addVehicleDialog")
    this.checkBoxOfPNIDriver = page.locator("[data-legacy-field=\"checkBoxOfPNIDriver\"]"); // @FindBy(xpath = PNI_DRIVER_SECTION + MATCHECKBOX_XPATH)
    this.continueToDriversButton = page.locator("xpath=//div[@class='auto-vehicles-drivers-review__continue-button-section']/button"); // @FindBy(xpath = "//div[@class='auto-vehicles-drivers-review__continue-button-section']/button")
    this.dateOfBirthEntryField = page.locator("xpath=//mat-form-field//input[contains(@aria-label, 'Date of birth')]"); // @FindBy(xpath = "//mat-form-field//input[contains(@aria-label, 'Date of birth')]")
    this.driversSectionTitle = page.locator("xpath=//h2[text()='Drivers']"); // @FindBy(xpath = "//h2[text()='Drivers']")
    this.editButtonOfPNIDriver = page.locator("[data-legacy-field=\"editButtonOfPNIDriver\"]"); // @FindBy(xpath = PNI_DRIVER_SECTION + EDIT_BUTTON)
    this.editDriverDialogHeader = page.locator("#addDriverHeading"); // @FindBy(id = "addDriverHeading")
    this.errorMessage = page.locator("p.auto-vehicles-drivers-review__error-message"); // @FindBy(css = "p.auto-vehicles-drivers-review__error-message")
    this.duplicateDriverErrorMessage = page.locator("xpath=//p[contains(@class, 'auto-add-driver__error-message') and contains(text(), 'The person you are adding appears to already be listed on your quote')]"); // @FindBy(xpath = "//p[contains(@class, 'auto-add-driver__error-message') and contains(text(), 'The person you are adding appears to already be listed on your quote')]")
    this.heresWhatWeFoundPageHeader = page.locator("xpath=//h1[contains(@class,'auto-vehicles-drivers-review__heading tui-h1') or contains(text(), 'what we found') or @class='tui-h1 page-title ng-star-inserted']"); // @FindBy(xpath = "//h1[contains(@class,'auto-vehicles-drivers-review__heading tui-h1') or contains(text(), 'what we found') or @class='tui-h1 page-title ng-star-inserted']")
    this.heresWhatWeFoundPageDescription = page.locator("xpath=//div[contains(@class, 'auto-vehicles-drivers-review__subheading')]"); // @FindBy(xpath = "//div[contains(@class, 'auto-vehicles-drivers-review__subheading')]")
    this.heresWhatWeFoundPageTitle = page.locator(".tui-h1"); // @FindBy(className = "tui-h1")
    this.listOfADPFDriversWithAges = page.locator("[data-legacy-field=\"listOfADPFDriversWithAges\"]"); // @FindBy(xpath = ADPF_DRIVERS_FOUND_XPATH + "/li")
    this.listOfADPFVehicles = page.locator("div.auto-vehicles-drivers-review__vehicles-list-details"); // @FindBy(css = "div.auto-vehicles-drivers-review__vehicles-list-details")
    this.listOfADPFVehiclesCheckboxes = page.locator("[data-legacy-field=\"listOfADPFVehiclesCheckboxes\"]"); // @FindBy(xpath = ADPF_VEHICLES_FOUND_XPATH + MATCHECKBOX_XPATH + INPUT_XPATH)
    this.listOfADPFVehiclesNames = page.locator("[data-legacy-field=\"listOfADPFVehiclesNames\"]"); // @FindBy(xpath = ADPF_VEHICLES_FOUND_XPATH + "//mat-checkbox/label/span[2]")
    this.listOfAllDriverAges = page.locator("[data-legacy-field=\"listOfAllDriverAges\"]"); // @FindBy(xpath = ADPF_DRIVERS_FOUND_XPATH + CHECKBOX_XPATH + SECTIONS_ANCESTOR_LI_XPATH + DRIVER_AGE_XPATH)
    this.listOfAllDriverDetailsSections = page.locator("[data-legacy-field=\"listOfAllDriverDetailsSections\"]"); // @FindBy(xpath = ADPF_DRIVERS_FOUND_XPATH + CHECKBOX_XPATH + SECTIONS_ANCESTOR_LI_XPATH)
    this.listOfAllDriverNames = page.locator("[data-legacy-field=\"listOfAllDriverNames\"]"); // @FindBy(xpath = ADPF_DRIVERS_FOUND_XPATH + CHECKBOX_XPATH + SECTIONS_ANCESTOR_LI_XPATH + DRIVER_NAME_XPATH)
    this.listOfAllEditButtonOfAdditionalDriverDetails = page.locator("xpath=//ul[contains(@class,'drivers-list-section')]//mat-checkbox[not(@id='driver__checkbox1')]"); // @FindBy(xpath = "//ul[contains(@class,'drivers-list-section')]//mat-checkbox[not(@id='driver__checkbox1')]" + "/../..//a")
    this.listOfCheckedDriverAges = page.locator("[data-legacy-field=\"listOfCheckedDriverAges\"]"); // @FindBy(xpath = CHECKED_DRIVERS_XPATH + SECTIONS_ANCESTOR_LI_XPATH + DRIVER_AGE_XPATH)
    this.listOfCheckedDriverNames = page.locator("[data-legacy-field=\"listOfCheckedDriverNames\"]"); // @FindBy(xpath = CHECKED_DRIVERS_XPATH + SECTIONS_ANCESTOR_LI_XPATH + DRIVER_NAME_XPATH)
    this.listOfCheckedDrivers = page.locator("xpath=//mat-checkbox[contains(@id,'driver__checkbox') and contains(@class,'checked')]"); // @FindBy(xpath = "//mat-checkbox[contains(@id,'driver__checkbox') and contains(@class,'checked')]")
    this.listOfUncheckedDriverAges = page.locator("[data-legacy-field=\"listOfUncheckedDriverAges\"]"); // @FindBy(xpath = UNCHECKED_DRIVERS_XPATH + SECTIONS_ANCESTOR_LI_XPATH + DRIVER_AGE_XPATH)
    this.listOfUncheckedDriverNames = page.locator("xpath=//mat-checkbox[contains(@id,'driver') and not(contains(@class,'mat-mdc-checkbox-checked'))]"); // @FindBy(xpath = "//mat-checkbox[contains(@id,'driver') and not(contains(@class,'mat-mdc-checkbox-checked'))]")
    this.selectedCurrentlyInsuredRadioButton = page.locator(".auto-add-driver-currently-insured__section.row mat-radio-button.mat-mdc-radio-checked"); // @FindBy(css = ".auto-add-driver-currently-insured__section.row mat-radio-button.mat-mdc-radio-checked")
    this.selectedDriverLicenseIssuedInUs = page.locator("mat-radio-button.mat-mdc-radio-checked"); // @FindBy(css = "mat-radio-button.mat-mdc-radio-checked")
    this.selectedGenderButton = page.locator("mat-button-toggle-group[aria-label*='gender'] mat-button-toggle[class*='checked']"); // @FindBy(css = "mat-button-toggle-group[aria-label*='gender'] mat-button-toggle[class*='checked']")
    this.sniApplicantRemovalNotification = page.locator("xpath=//li[.//mat-checkbox[@id='driver__checkbox2']]/div[2]//div"); // @FindBy(xpath = "//li[.//mat-checkbox[@id='driver__checkbox2']]/div[2]//div")
    this.vehiclesSectionTitle = page.locator("xpath=//h2[text()='Vehicles']"); // @FindBy(xpath = "//h2[text()='Vehicles']")
  }
}
