// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.InterstitialBundlePage. */
export class InterstitialBundlePage extends CoreBasePage {
  public readonly pageHeader: Locator;
  public readonly pageSubTitle: Locator;
  public readonly bundleImage: Locator;
  public readonly savingMessageUnderImage: Locator;
  public readonly savingSubMessageUnderImage: Locator;
  public readonly continueWithBundleDiscountButton: Locator;
  public readonly continueWithAutoOnlyButton: Locator;
  public readonly pageDisclaimer: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageHeader = page.locator("#bundlePageHeaderTitle"); // @FindBy(id = "bundlePageHeaderTitle")
    this.pageSubTitle = page.locator("div[class='bundle-page-title-savings bundle-page-title-font']"); // @FindBy(css = "div[class='bundle-page-title-savings bundle-page-title-font']")
    this.bundleImage = page.locator("img[class='auto-home-group-image']"); // @FindBy(css = "img[class='auto-home-group-image']")
    this.savingMessageUnderImage = page.locator("div[class='bundle-page-promo-trust']>span"); // @FindBy(css = "div[class='bundle-page-promo-trust']>span")
    this.savingSubMessageUnderImage = page.locator("div[class='bundle-page-title-savings bundle-page-title-savings-font']>span"); // @FindBy(css = "div[class='bundle-page-title-savings bundle-page-title-savings-font']>span")
    this.continueWithBundleDiscountButton = page.locator("xpath=//div[@class='bundle-page__bundle-continue-button']//button"); // @FindBy(xpath = "//div[@class='bundle-page__bundle-continue-button']//button")
    this.continueWithAutoOnlyButton = page.locator("button[data-tui-tracking-id='auto__continue-button-cta']"); // @FindBy(css = "button[data-tui-tracking-id='auto__continue-button-cta']")
    this.pageDisclaimer = page.locator("xpath=//div[contains(@class,'bundle-page-disclaimer-section')]/span"); // @FindBy(xpath = "//div[contains(@class,'bundle-page-disclaimer-section')]/span")
  }
}
