// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.NewRetrievalPage. */
export class NewRetrievalPage extends CoreBasePage {
  public readonly lblWelcomeBack: Locator;
  public readonly txtLastName: Locator;
  public readonly txtDateOfBirth: Locator;
  public readonly btnRetrieveMyQuote: Locator;
  public readonly lnkStartNewQuote: Locator;

  public constructor(page: Page) {
    super(page);
    this.lblWelcomeBack = page.locator("xpath=//h1[contains(text(),'Welcome back')]"); // @FindBy(xpath = "//h1[contains(text(),'Welcome back')]")
    this.txtLastName = page.locator("xpath=//input[@aria-label='Last name']"); // @FindBy(xpath = "//input[@aria-label='Last name']")
    this.txtDateOfBirth = page.locator("xpath=//input[contains(@aria-label,'Date of birth')]"); // @FindBy(xpath = "//input[contains(@aria-label,'Date of birth')]")
    this.btnRetrieveMyQuote = page.locator("xpath=//button[@aria-label='Retrieve my quote button']"); // @FindBy(xpath = "//button[@aria-label='Retrieve my quote button']")
    this.lnkStartNewQuote = page.locator("xpath=//a[contains(normalize-space(),'Start a new quote instead')]"); // @FindBy(xpath = "//a[contains(normalize-space(),'Start a new quote instead')]")
  }
}
