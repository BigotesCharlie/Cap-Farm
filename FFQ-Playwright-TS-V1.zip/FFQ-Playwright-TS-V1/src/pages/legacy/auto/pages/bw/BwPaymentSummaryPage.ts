// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.bw.BwPaymentSummaryPage. */
export class BwPaymentSummaryPage extends CoreBasePage {
  public readonly pageHeader: Locator;
  public readonly rateAdjustmentMessage: Locator;
  public readonly changeCoverageText: Locator;
  public readonly changeYourCoverageLink: Locator;
  public readonly leftRightScrollButton: Locator;
  public readonly discountTitle: Locator;
  public readonly quoteNumberElement: Locator;
  public readonly sixMonthTermPrice: Locator;
  public readonly appRateChangeNotificationHeader: Locator;
  public readonly appRateChangeNotificationDescription: Locator;
  public readonly appRateChangeNotificationTermLabel: Locator;
  public readonly appRateChangeNotificationOkButton: Locator;
  public readonly pifPageSubHeader: Locator;
  public readonly pifSixMonthTermPriceLabel: Locator;
  public readonly sixTermPaymentIncludingAllFeesLabel: Locator;
  public readonly sixTermPaymentIncludingAllFeesAmount: Locator;
  public readonly pifDueTodayIncludesAllFeesLabel: Locator;
  public readonly pifDueTodayIncludesAllFeesAmount: Locator;
  public readonly pifAddPreferredPaymentMethodHeader: Locator;
  public readonly pifUseBankDebitCreditCardBulletPoint: Locator;
  public readonly pifNoServiceChargeWhenYouPayInFullBulletPoint: Locator;
  public readonly pifSetUpPaymentMethodButton: Locator;
  public readonly pifPaymentCardAddedLabel: Locator;
  public readonly pifPaymentCardAddedGreenMatIcon: Locator;
  public readonly pifNoServiceChargeLabel: Locator;
  public readonly pifAddedPaymentIcon: Locator;
  public readonly pifAddedPaymentMethodMaskedNumbersAndExpDate: Locator;
  public readonly pifAddedPaymentMethodChangeButton: Locator;
  public readonly pifDisclaimerTextHeader: Locator;
  public readonly pifDisclaimerTextBulletPointOne: Locator;
  public readonly pifDisclaimerTextBulletPointTwo: Locator;
  public readonly pifOneTimeAndRecurringPaymentRadioButtonInput: Locator;
  public readonly pifOneTimeAndRecurringPaymentRadioButtonLabel: Locator;
  public readonly pifOneTimeOnlyPaymentRadioButtonInput: Locator;
  public readonly pifOneTimeOnlyPaymentRadioButtonLabel: Locator;
  public readonly pifDisclaimerFinalText: Locator;
  public readonly monthlyAutoPayBankPageSubHeader: Locator;
  public readonly monthlyAutoPayBankSixMonthTermPriceLabel: Locator;
  public readonly monthlyAutoPayBankSixTermPaymentIncludingAllFeesLabel: Locator;
  public readonly monthlyAutoPayBankSixTermPaymentIncludingAllFeesAmount: Locator;
  public readonly monthlyAutoPayBankDueTodayIncludesAllFeesLabel: Locator;
  public readonly monthlyAutoPayBankDueTodayIncludesAllFeesAmount: Locator;
  public readonly monthlyAutoPayCardDueTodayIncludesAllFeesAmount: Locator;
  public readonly monthlyAutoPayBankDownPaymentHeader: Locator;
  public readonly monthlyAutoPayBankFuturePaymentsSectionHeader: Locator;
  public readonly monthlyAutoPayBankDownPaymentAndFuturePaymentsBoldDescriptions: Locator;
  public readonly monthlyAutoPayBankDownPaymentAndFuturePaymentsBulletPointsDescriptions: Locator;
  public readonly monthlyAutoPayBankDownPaymentSetUpPaymentMethodButton: Locator;
  public readonly monthlyAutoPayBankAddedAccountMessages: Locator;
  public readonly monthlyAutoPayBankAddedAccountGreenChecks: Locator;
  public readonly monthlyAutoPayBankDownPaymentAddedCreditCardIcon: Locator;
  public readonly monthlyAutoPayBankAddedAccountNumbers: Locator;
  public readonly monthlyAutoPayBankChangeLinks: Locator;
  public readonly monthlyDirectBillPageSubHeader: Locator;
  public readonly monthlyDirectBillSixMonthTermPriceLabel: Locator;
  public readonly monthlyDirectBillFirstMonthlyPaymentIncludingAllFeesLabel: Locator;
  public readonly monthlyDirectBillFirstMonthlyPaymentIncludingAllFeesAmount: Locator;
  public readonly monthlyDirectBillDueTodayIncludesAllFeesLabel: Locator;
  public readonly monthlyDirectBillDueTodayIncludesAllFeesAmount: Locator;
  public readonly paymentDeclinedModalHeader: Locator;
  public readonly paymentDeclinedModalMessages: Locator;
  public readonly paymentDeclinedModalOkButton: Locator;
  public readonly nextSignDocumentButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageHeader = page.locator("xpath=//app-payment-overview//h1"); // @FindBy(xpath = "//app-payment-overview//h1")
    this.rateAdjustmentMessage = page.locator("xpath=//div[@class='tui-input-text payment-overview-sub-para tui-stacking-bottom-xl ng-star-inserted']"); // @FindBy(xpath = "//div[@class='tui-input-text payment-overview-sub-para tui-stacking-bottom-xl ng-star-inserted']")
    this.changeCoverageText = page.locator("xpath=//p[@class='pov2__change-coverage-text tui-body ng-star-inserted']"); // @FindBy(xpath = "//p[@class='pov2__change-coverage-text tui-body ng-star-inserted']")
    this.changeYourCoverageLink = page.locator("a[data-gtm='Auto_Bind_Payplan_CustomCoverage_link']"); // @FindBy(css = "a[data-gtm='Auto_Bind_Payplan_CustomCoverage_link']")
    this.leftRightScrollButton = page.locator("xpath=//button[contains(@class,'mat-tab-header-pagination') and not(contains(@class,'disabled'))]"); // @FindBy(xpath = "//button[contains(@class,'mat-tab-header-pagination') and not(contains(@class,'disabled'))]")
    this.discountTitle = page.locator("xpath=//div[@class='discount-description']//p[1]"); // @FindBy(xpath = "//div[@class='discount-description']//p[1]")
    this.quoteNumberElement = page.locator("xpath=//div[contains(@class,'auto-agent-details__save-quote')]//span"); // @FindBy(xpath = "//div[contains(@class,'auto-agent-details__save-quote')]//span")
    this.sixMonthTermPrice = page.locator("div[class='tui-body-text-bold monthly-autopay-details-header']>span"); // @FindBy(css = "div[class='tui-body-text-bold monthly-autopay-details-header']>span")
    this.appRateChangeNotificationHeader = page.locator("xpath=//app-rate-change-notification//h2"); // @FindBy(xpath = "//app-rate-change-notification//h2")
    this.appRateChangeNotificationDescription = page.locator("xpath=//app-rate-change-notification//p"); // @FindBy(xpath = "//app-rate-change-notification//p")
    this.appRateChangeNotificationTermLabel = page.locator("xpath=//app-rate-change-notification//div[@class='term-label']"); // @FindBy(xpath = "//app-rate-change-notification//div[@class='term-label']")
    this.appRateChangeNotificationOkButton = page.locator("xpath=//app-rate-change-notification//button[@class='ok-button']"); // @FindBy(xpath = "//app-rate-change-notification//button[@class='ok-button']")
    this.pifPageSubHeader = page.locator("xpath=//app-full-auto-pay//h2"); // @FindBy(xpath = "//app-full-auto-pay//h2")
    this.pifSixMonthTermPriceLabel = page.locator("xpath=//section[@class='pif-autopay-details']/div[1]/span[@class='tui-body-bold']"); // @FindBy(xpath = "//section[@class='pif-autopay-details']/div[1]/span[@class='tui-body-bold']")
    this.sixTermPaymentIncludingAllFeesLabel = page.locator("xpath=//div[@class='pif-autopay-fees']/div/span[1]"); // @FindBy(xpath = "//div[@class='pif-autopay-fees']/div/span[1]")
    this.sixTermPaymentIncludingAllFeesAmount = page.locator("xpath=//div[@class='pif-autopay-fees']/div/span[2]"); // @FindBy(xpath = "//div[@class='pif-autopay-fees']/div/span[2]")
    this.pifDueTodayIncludesAllFeesLabel = page.locator("xpath=//div[contains(@class,'pif-autopay-details-bottom')]/span[1]"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-details-bottom')]/span[1]")
    this.pifDueTodayIncludesAllFeesAmount = page.locator("xpath=//div[contains(@class,'pif-autopay-details-bottom')]/span[2]"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-details-bottom')]/span[2]")
    this.pifAddPreferredPaymentMethodHeader = page.locator("xpath=//section[contains(@class,'pif-autopay-selection')]/span[1]"); // @FindBy(xpath = "//section[contains(@class,'pif-autopay-selection')]/span[1]")
    this.pifUseBankDebitCreditCardBulletPoint = page.locator("xpath=//section[contains(@class,'pif-autopay-selection')]//ul/li[1]"); // @FindBy(xpath = "//section[contains(@class,'pif-autopay-selection')]//ul/li[1]")
    this.pifNoServiceChargeWhenYouPayInFullBulletPoint = page.locator("xpath=//section[contains(@class,'pif-autopay-selection')]//ul/li[2]"); // @FindBy(xpath = "//section[contains(@class,'pif-autopay-selection')]//ul/li[2]")
    this.pifSetUpPaymentMethodButton = page.locator("xpath=//section[contains(@class,'pif-autopay-selection')]//button"); // @FindBy(xpath = "//section[contains(@class,'pif-autopay-selection')]//button")
    this.pifPaymentCardAddedLabel = page.locator("xpath=//section[contains(@class,'pif-autopay-payment-confirmation')]/div[1]/span"); // @FindBy(xpath = "//section[contains(@class,'pif-autopay-payment-confirmation')]/div[1]/span")
    this.pifPaymentCardAddedGreenMatIcon = page.locator("xpath=//section[contains(@class,'pif-autopay-payment-confirmation')]/div[1]/mat-icon"); // @FindBy(xpath = "//section[contains(@class,'pif-autopay-payment-confirmation')]/div[1]/mat-icon")
    this.pifNoServiceChargeLabel = page.locator("xpath=//p[contains(@class,'pif-autopay-disclaimers-charge-text')]"); // @FindBy(xpath = "//p[contains(@class,'pif-autopay-disclaimers-charge-text')]")
    this.pifAddedPaymentIcon = page.locator("xpath=//div[@class='pif-autopay-disclaimers-charge-info']/img"); // @FindBy(xpath = "//div[@class='pif-autopay-disclaimers-charge-info']/img")
    this.pifAddedPaymentMethodMaskedNumbersAndExpDate = page.locator("xpath=//div[@class='pif-autopay-disclaimers-charge-info']/span"); // @FindBy(xpath = "//div[@class='pif-autopay-disclaimers-charge-info']/span")
    this.pifAddedPaymentMethodChangeButton = page.locator("xpath=//div[@class='pif-autopay-disclaimers-charge-info']/a"); // @FindBy(xpath = "//div[@class='pif-autopay-disclaimers-charge-info']/a")
    this.pifDisclaimerTextHeader = page.locator("xpath=//section[contains(@class,'pif-autopay-disclaimers-text')]/div"); // @FindBy(xpath = "//section[contains(@class,'pif-autopay-disclaimers-text')]/div")
    this.pifDisclaimerTextBulletPointOne = page.locator("xpath=//section[contains(@class,'pif-autopay-disclaimers-text')]/ul/li[1]"); // @FindBy(xpath = "//section[contains(@class,'pif-autopay-disclaimers-text')]/ul/li[1]")
    this.pifDisclaimerTextBulletPointTwo = page.locator("xpath=//section[contains(@class,'pif-autopay-disclaimers-text')]/ul/li[2]"); // @FindBy(xpath = "//section[contains(@class,'pif-autopay-disclaimers-text')]/ul/li[2]")
    this.pifOneTimeAndRecurringPaymentRadioButtonInput = page.locator("xpath=//section[contains(@class,'pif-autopay-disclaimers-text')]/mat-radio-group/mat-radio-button[1]//input"); // @FindBy(xpath = "//section[contains(@class,'pif-autopay-disclaimers-text')]/mat-radio-group/mat-radio-button[1]//input")
    this.pifOneTimeAndRecurringPaymentRadioButtonLabel = page.locator("xpath=//section[contains(@class,'pif-autopay-disclaimers-text')]/mat-radio-group/mat-radio-button[1]//span[@class='mat-radio-label-content']"); // @FindBy(xpath = "//section[contains(@class,'pif-autopay-disclaimers-text')]/mat-radio-group/mat-radio-button[1]//span[@class='mat-radio-label-content']")
    this.pifOneTimeOnlyPaymentRadioButtonInput = page.locator("xpath=//section[contains(@class,'pif-autopay-disclaimers-text')]/mat-radio-group/mat-radio-button[2]//input"); // @FindBy(xpath = "//section[contains(@class,'pif-autopay-disclaimers-text')]/mat-radio-group/mat-radio-button[2]//input")
    this.pifOneTimeOnlyPaymentRadioButtonLabel = page.locator("xpath=//section[contains(@class,'pif-autopay-disclaimers-text')]/mat-radio-group/mat-radio-button[2]//span[@class='mat-radio-label-content']"); // @FindBy(xpath = "//section[contains(@class,'pif-autopay-disclaimers-text')]/mat-radio-group/mat-radio-button[2]//span[@class='mat-radio-label-content']")
    this.pifDisclaimerFinalText = page.locator("xpath=//p[contains(@class,'tui-input-text pif-autopay-disclaimers-final-text')]"); // @FindBy(xpath = "//p[contains(@class,'tui-input-text pif-autopay-disclaimers-final-text')]")
    this.monthlyAutoPayBankPageSubHeader = page.locator("xpath=//app-monthly-auto-pay//h2"); // @FindBy(xpath = "//app-monthly-auto-pay//h2")
    this.monthlyAutoPayBankSixMonthTermPriceLabel = page.locator("xpath=//div[contains(@class,'monthly-autopay-details-header')]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-details-header')]")
    this.monthlyAutoPayBankSixTermPaymentIncludingAllFeesLabel = page.locator("xpath=//div[contains(@class,'monthly-autopay-fees-row')]/p[1]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')]/p[1]")
    this.monthlyAutoPayBankSixTermPaymentIncludingAllFeesAmount = page.locator("xpath=//div[contains(@class,'monthly-autopay-fees-row')]/p[2]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')]/p[2]")
    this.monthlyAutoPayBankDueTodayIncludesAllFeesLabel = page.locator("xpath=//div[contains(@class,'monthly-autopay-details-bottom-row')]/p[1]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-details-bottom-row')]/p[1]")
    this.monthlyAutoPayBankDueTodayIncludesAllFeesAmount = page.locator("xpath=//div[contains(@class,'monthly-autopay-details-bottom-row')]/span"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-details-bottom-row')]/span")
    this.monthlyAutoPayCardDueTodayIncludesAllFeesAmount = page.locator("xpath=//div[contains(@class,'monthly-autopay-details-bottom-row')]/span"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-details-bottom-row')]/span")
    this.monthlyAutoPayBankDownPaymentHeader = page.locator("xpath=//span[contains(.,'Down payment')]"); // @FindBy(xpath = "//span[contains(.,'Down payment')]")
    this.monthlyAutoPayBankFuturePaymentsSectionHeader = page.locator("xpath=//span[contains(.,'Future payments')]"); // @FindBy(xpath = "//span[contains(.,'Future payments')]")
    this.monthlyAutoPayBankDownPaymentAndFuturePaymentsBoldDescriptions = page.locator("xpath=//p[contains(@class,'monthly-autopay-selection-header')]"); // @FindBy(xpath = "//p[contains(@class,'monthly-autopay-selection-header')]")
    this.monthlyAutoPayBankDownPaymentAndFuturePaymentsBulletPointsDescriptions = page.locator("xpath=//div[@class='monthly-autopay-selection-sub-section']"); // @FindBy(xpath = "//div[@class='monthly-autopay-selection-sub-section']")
    this.monthlyAutoPayBankDownPaymentSetUpPaymentMethodButton = page.locator("xpath=//section[contains(@class,'monthly-autopay-selection')]//button"); // @FindBy(xpath = "//section[contains(@class,'monthly-autopay-selection')]//button")
    this.monthlyAutoPayBankAddedAccountMessages = page.locator("xpath=//div[contains(@class,'monthly-autopay-disclaimers-header')]//span"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-disclaimers-header')]//span")
    this.monthlyAutoPayBankAddedAccountGreenChecks = page.locator("xpath=//div[contains(@class,'monthly-autopay-disclaimers-header')]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-disclaimers-header')]//mat-icon")
    this.monthlyAutoPayBankDownPaymentAddedCreditCardIcon = page.locator("xpath=//div[@class='monthly-autopay-disclaimers-details']//img"); // @FindBy(xpath = "//div[@class='monthly-autopay-disclaimers-details']//img")
    this.monthlyAutoPayBankAddedAccountNumbers = page.locator("xpath=//span[contains(@class,'monthly-autopay-disclaimers-account-numbers')]"); // @FindBy(xpath = "//span[contains(@class,'monthly-autopay-disclaimers-account-numbers')]")
    this.monthlyAutoPayBankChangeLinks = page.locator("xpath=//section[contains(@class,'monthly-autopay-payment')]//a"); // @FindBy(xpath = "//section[contains(@class,'monthly-autopay-payment')]//a")
    this.monthlyDirectBillPageSubHeader = page.locator("xpath=//app-monthly-auto-pay//h2"); // @FindBy(xpath = "//app-monthly-auto-pay//h2")
    this.monthlyDirectBillSixMonthTermPriceLabel = page.locator("xpath=//div[contains(@class,'monthly-autopay-details-header')]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-details-header')]")
    this.monthlyDirectBillFirstMonthlyPaymentIncludingAllFeesLabel = page.locator("xpath=//div[contains(@class,'monthly-autopay-fees-row')]/p[1]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')]/p[1]")
    this.monthlyDirectBillFirstMonthlyPaymentIncludingAllFeesAmount = page.locator("xpath=//div[contains(@class,'monthly-autopay-fees-row')]/p[2]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')]/p[2]")
    this.monthlyDirectBillDueTodayIncludesAllFeesLabel = page.locator("xpath=//div[contains(@class,'monthly-autopay-details-bottom-row')]/p[1]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-details-bottom-row')]/p[1]")
    this.monthlyDirectBillDueTodayIncludesAllFeesAmount = page.locator("xpath=//div[contains(@class,'monthly-autopay-details-bottom-row')]/span"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-details-bottom-row')]/span")
    this.paymentDeclinedModalHeader = page.locator("xpath=//app-payment-decline-modal//h4"); // @FindBy(xpath = "//app-payment-decline-modal//h4")
    this.paymentDeclinedModalMessages = page.locator("xpath=//app-payment-decline-modal//p[@class='tui-body']"); // @FindBy(xpath = "//app-payment-decline-modal//p[@class='tui-body']")
    this.paymentDeclinedModalOkButton = page.locator("xpath=//app-payment-decline-modal//button"); // @FindBy(xpath = "//app-payment-decline-modal//button")
    this.nextSignDocumentButton = page.locator("button[class='pov2__next-btn tui-btn tui-btn-primary']"); // @FindBy(css = "button[class='pov2__next-btn tui-btn tui-btn-primary']")
  }
}
