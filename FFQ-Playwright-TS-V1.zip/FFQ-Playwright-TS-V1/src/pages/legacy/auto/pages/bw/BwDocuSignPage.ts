// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.bw.BwDocuSignPage. */
export class BwDocuSignPage extends CoreBasePage {
  public readonly disclosureCheckbox: Locator;
  public readonly disclosurePopUpContinueButton: Locator;
  public readonly startButton: Locator;
  public readonly startButtonAlternative: Locator;
  public readonly nextButton: Locator;
  public readonly initialButton: Locator;
  public readonly yellowInitials: Locator;
  public readonly yellowSignature: Locator;
  public readonly signByRadioButton: Locator;
  public readonly adoptAndInitial: Locator;
  public readonly finishButton: Locator;
  public readonly finishButtonMobile: Locator;
  public readonly requiredFieldLeft: Locator;

  public constructor(page: Page) {
    super(page);
    this.disclosureCheckbox = page.locator("xpath=//input[contains(@data-qa,'ersd-agree-checkbox')]"); // @FindBy(xpath = "//input[contains(@data-qa,'ersd-agree-checkbox')]")
    this.disclosurePopUpContinueButton = page.locator("xpath=//button[@aria-describedby='continue-btn-a11y-desc']"); // @FindBy(xpath = "//button[@aria-describedby='continue-btn-a11y-desc']")
    this.startButton = page.locator("button[class='btn btn-primary autoNav-relative']"); // @FindBy(css = "button[class='btn btn-primary autoNav-relative']")
    this.startButtonAlternative = page.locator("button[data-qa='auto-nav-caret']"); // @FindBy(css = "button[data-qa='auto-nav-caret']")
    this.nextButton = page.locator("button[data-qa='action-bar-btn-finish-mobile']"); // @FindBy(css = "button[data-qa='action-bar-btn-finish-mobile']")
    this.initialButton = page.locator("button[class='btn btn-primary autoNav-relative btn-caret-right']"); // @FindBy(css = "button[class='btn btn-primary autoNav-relative btn-caret-right']")
    this.yellowInitials = page.locator("xpath=//button[contains(@data-qa,'initials-tab-required') and @aria-invalid='true']"); // @FindBy(xpath = "//button[contains(@data-qa,'initials-tab-required') and @aria-invalid='true']")
    this.yellowSignature = page.locator("xpath=//div[contains(@class,'signature-tab-content')]"); // @FindBy(xpath = "//div[contains(@class,'signature-tab-content')]")
    this.signByRadioButton = page.locator("xpath=//input[contains(@name,'signature-style-radio-buttons')]"); // @FindBy(xpath = "//input[contains(@name,'signature-style-radio-buttons')]")
    this.adoptAndInitial = page.locator("button[data-qa='adopt-submit']"); // @FindBy(css = "button[data-qa='adopt-submit']")
    this.finishButton = page.locator("button[id='action-bar-btn-finish']"); // @FindBy(css = "button[id='action-bar-btn-finish']")
    this.finishButtonMobile = page.locator("button[id='action-bar-btn-finish-mobile']"); // @FindBy(css = "button[id='action-bar-btn-finish-mobile']")
    this.requiredFieldLeft = page.locator("xpath=//div[@data-qa='butter-bar-countdown-content' and contains(.,'required field left')]"); // @FindBy(xpath = "//div[@data-qa='butter-bar-countdown-content' and contains(.,'required field left')]")
  }
}
