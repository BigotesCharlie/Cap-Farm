// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage. */
export class BristolWestAdditionalDiscountsPage extends CoreBasePage {
  public readonly pageHeader: Locator;
  public readonly pageSubheader: Locator;
  public readonly otherPolicyGroupLabel: Locator;
  public readonly homeownerPolicyRadioButton: Locator;
  public readonly homeownerPolicyRadioButtonLabel: Locator;
  public readonly mobileHomeownerPolicyRadioButton: Locator;
  public readonly mobileHomeownerPolicyRadioButtonLabel: Locator;
  public readonly rentersPolicyRadioButton: Locator;
  public readonly rentersPolicyRadioButtonLabel: Locator;
  public readonly noPolicyRadioButton: Locator;
  public readonly noPolicyRadioButtonLabel: Locator;
  public readonly otherPeopleInHouseholdLabel: Locator;
  public readonly otherPeopleLivingInHouseholdButton: Locator;
  public readonly noOtherPeopleLivingInHouseholdButton: Locator;
  public readonly continueButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageHeader = page.locator("xpath=//app-additional-discounts//h1"); // @FindBy(xpath = "//app-additional-discounts//h1")
    this.pageSubheader = page.locator("xpath=//app-additional-discounts//h1/../p"); // @FindBy(xpath = "//app-additional-discounts//h1/../p")
    this.otherPolicyGroupLabel = page.locator("xpath=//app-additional-discounts//h1/../div[1]"); // @FindBy(xpath = "//app-additional-discounts//h1/../div[1]")
    this.homeownerPolicyRadioButton = page.locator("#RADIO_BUTTON_FOR_H"); // @FindBy(id = "RADIO_BUTTON_FOR_H")
    this.homeownerPolicyRadioButtonLabel = page.locator("xpath=//label[contains (@for, 'RADIO_BUTTON_FOR_H')]"); // @FindBy(xpath = "//label[contains (@for, 'RADIO_BUTTON_FOR_H')]")
    this.mobileHomeownerPolicyRadioButton = page.locator("#RADIO_BUTTON_FOR_M"); // @FindBy(id = "RADIO_BUTTON_FOR_M")
    this.mobileHomeownerPolicyRadioButtonLabel = page.locator("xpath=//label[contains (@for, 'RADIO_BUTTON_FOR_M')]"); // @FindBy(xpath = "//label[contains (@for, 'RADIO_BUTTON_FOR_M')]")
    this.rentersPolicyRadioButton = page.locator("#RADIO_BUTTON_FOR_R"); // @FindBy(id = "RADIO_BUTTON_FOR_R")
    this.rentersPolicyRadioButtonLabel = page.locator("xpath=//label[contains (@for, 'RADIO_BUTTON_FOR_R')]"); // @FindBy(xpath = "//label[contains (@for, 'RADIO_BUTTON_FOR_R')]")
    this.noPolicyRadioButton = page.locator("#RADIO_BUTTON_FOR_N"); // @FindBy(id = "RADIO_BUTTON_FOR_N")
    this.noPolicyRadioButtonLabel = page.locator("xpath=//label[contains (@for, 'RADIO_BUTTON_FOR_N')]"); // @FindBy(xpath = "//label[contains (@for, 'RADIO_BUTTON_FOR_N')]")
    this.otherPeopleInHouseholdLabel = page.locator("xpath=//app-additional-discounts//h1/../div[2]"); // @FindBy(xpath = "//app-additional-discounts//h1/../div[2]")
    this.otherPeopleLivingInHouseholdButton = page.locator("#SHOW_HOUSEHOLD_COUNT_YES"); // @FindBy(id = "SHOW_HOUSEHOLD_COUNT_YES")
    this.noOtherPeopleLivingInHouseholdButton = page.locator("#SHOW_HOUSEHOLD_COUNT_NO"); // @FindBy(id = "SHOW_HOUSEHOLD_COUNT_NO")
    this.continueButton = page.locator("#CONTINUE_CTA"); // @FindBy(id = "CONTINUE_CTA")
  }
}
