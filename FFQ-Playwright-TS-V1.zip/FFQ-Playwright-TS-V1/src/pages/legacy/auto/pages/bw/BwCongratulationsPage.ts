// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.bw.BwCongratulationsPage. */
export class BwCongratulationsPage extends CoreBasePage {
  public readonly pageTitle: Locator;
  public readonly pageSubTitle: Locator;
  public readonly downloadIdCardsLink: Locator;
  public readonly downloadPolicyDocuments: Locator;
  public readonly passwordInput: Locator;
  public readonly createAccountButton: Locator;
  public readonly createdConfirmation: Locator;
  public readonly yourAccountCreatedConfirmation: Locator;
  public readonly loginToMyAccountButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageTitle = page.locator("h1[class='mb-10 rebrand-heading']"); // @FindBy(css = "h1[class='mb-10 rebrand-heading']"),             @FindBy(xpath = "//h1[contains(.,'Congratulations')]")     })
    this.pageSubTitle = page.locator("p[class='tui-field-label-text']"); // @FindBy(css = "p[class='tui-field-label-text']")
    this.downloadIdCardsLink = page.locator("button[id='download-id-cards']"); // @FindBy(css = "button[id='download-id-cards']")
    this.downloadPolicyDocuments = page.locator("#download-policy-documents"); // @FindBy(id = "download-policy-documents")
    this.passwordInput = page.locator("input[formcontrolname='password']"); // @FindBy(css = "input[formcontrolname='password']")
    this.createAccountButton = page.locator("button[class='tui-btn tui-btn-primary']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary']")
    this.createdConfirmation = page.locator("xpath=//p[@class='text_align' and  contains(.,'created')]"); // @FindBy(xpath = "//p[@class='text_align' and  contains(.,'created')]")
    this.yourAccountCreatedConfirmation = page.locator("xpath=//p[contains(.,'Your account has been created!')]"); // @FindBy(xpath = "//p[contains(.,'Your account has been created!')]")
    this.loginToMyAccountButton = page.locator("xpath=//button[contains(.,'Log in to my account')]"); // @FindBy(xpath = "//button[contains(.,'Log in to my account')]")
  }
}
