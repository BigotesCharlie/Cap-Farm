// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.LeadFormThankYouPage. */
export class LeadFormThankYouPage extends CoreBasePage {
  public readonly pageTitle: Locator;
  public readonly pageSubtitle: Locator;
  public readonly quoteNumberText: Locator;
  public readonly quoteNumberElement: Locator;
  public readonly needMoreHelp: Locator;
  public readonly youCanCallCustomerService: Locator;
  public readonly tollNumber: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageTitle = page.locator("div[class='thank-you__title']>h1"); // @FindBy(css = "div[class='thank-you__title']>h1")
    this.pageSubtitle = page.locator("div[class='tui-body thank-you__subtitle']>p"); // @FindBy(css = "div[class='tui-body thank-you__subtitle']>p")
    this.quoteNumberText = page.locator("div[class='thank-you__quote-number ng-star-inserted']>span[class='tui-body-bold']"); // @FindBy(css = "div[class='thank-you__quote-number ng-star-inserted']>span[class='tui-body-bold']")
    this.quoteNumberElement = page.locator("div[class='thank-you__quote-number ng-star-inserted']>span[class='tui-body']"); // @FindBy(css = "div[class='thank-you__quote-number ng-star-inserted']>span[class='tui-body']")
    this.needMoreHelp = page.locator("xpath=//div[contains(text(),'Need more help?')]"); // @FindBy(xpath = "//div[contains(text(),'Need more help?')]")
    this.youCanCallCustomerService = page.locator("xpath=//div[contains(text(),'You can call customer service at')]"); // @FindBy(xpath = "//div[contains(text(),'You can call customer service at')]")
    this.tollNumber = page.locator("xpath=//div[contains(@class,'toll-free-number')]"); // @FindBy(xpath = "//div[contains(@class,'toll-free-number')]")
  }
}
