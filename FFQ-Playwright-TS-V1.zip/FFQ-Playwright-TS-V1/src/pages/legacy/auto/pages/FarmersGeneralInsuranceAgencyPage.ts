// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.FarmersGeneralInsuranceAgencyPage. */
export class FarmersGeneralInsuranceAgencyPage extends CoreBasePage {
  public readonly fgiaPromptPageHeader: Locator;
  public readonly fgiaPromptPageSubHeader: Locator;
  public readonly fgiaPromptPageContinueButton: Locator;
  public readonly fgiaPromptPageNoThanksButton: Locator;
  public readonly pageHeaderText: Locator;
  public readonly pageSubHeaderText_1: Locator;
  public readonly pageSubHeaderText_2: Locator;
  public readonly autoLOBCard: Locator;
  public readonly homeOwnersLOBCard: Locator;
  public readonly rentersLOBCard: Locator;
  public readonly personalInfromationUseLink: Locator;
  public readonly continueButton: Locator;
  public readonly fgiaTryAgain: Locator;
  public readonly fgiaTellUsAboutYourselfButton: Locator;
  public readonly fgiaZipCode: Locator;

  public constructor(page: Page) {
    super(page);
    this.fgiaPromptPageHeader = page.locator("xpath=//div[contains(@class,'fgia-page-container')]/h1"); // @FindBy(xpath = "//div[contains(@class,'fgia-page-container')]/h1"),             @FindBy(id = "heading-rebrand")     })
    this.fgiaPromptPageSubHeader = page.locator("xpath=//div[contains(@class,'fgia-page-container')]/div/div/p"); // @FindBy(xpath = "//div[contains(@class,'fgia-page-container')]/div/div/p"),             @FindBy(css = "h2[class='tui-h2 mt-10']")     })
    this.fgiaPromptPageContinueButton = page.locator("xpath=//button/span[contains(text(),'Continue to FGIA')]"); // @FindBy(xpath = "//button/span[contains(text(),'Continue to FGIA')]"),             @FindBy(xpath = "//div[contains(@class,'fgia-rebrand-cta-section')]//button")     })
    this.fgiaPromptPageNoThanksButton = page.locator("xpath=*//button[contains(text(),'No, thanks')]"); // @FindBy(xpath = "*//button[contains(text(),'No, thanks')]")
    this.pageHeaderText = page.locator("xpath=//h1/span[contains(text(),'Welcome to the Farmers General')]"); // @FindBy(xpath = "//h1/span[contains(text(),'Welcome to the Farmers General')]")
    this.pageSubHeaderText_1 = page.locator("xpath=//h2/span[contains(text(),'What insurance')]"); // @FindBy(xpath = "//h2/span[contains(text(),'What insurance')]")
    this.pageSubHeaderText_2 = page.locator("xpath=//fieldset[@id='in_insurance_type']/legend/h3"); // @FindBy(xpath = "//fieldset[@id='in_insurance_type']/legend/h3")
    this.autoLOBCard = page.locator("xpath=//div[@class=' s12 10m l7 clm center']/ul/li[1]"); // @FindBy(xpath = "//div[@class=' s12 10m l7 clm center']/ul/li[1]")
    this.homeOwnersLOBCard = page.locator("xpath=//div[@class=' s12 10m l7 clm center']/ul/li[2]"); // @FindBy(xpath = "//div[@class=' s12 10m l7 clm center']/ul/li[2]")
    this.rentersLOBCard = page.locator("xpath=//div[@class=' s12 10m l7 clm center']/ul/li[3]"); // @FindBy(xpath = "//div[@class=' s12 10m l7 clm center']/ul/li[3]")
    this.personalInfromationUseLink = page.locator("xpath=//a[@class='personal-info-farmers']/div"); // @FindBy(xpath = "//a[@class='personal-info-farmers']/div")
    this.continueButton = page.locator("xpath=//button[contains(text(),'Tell us about yourself')]"); // @FindBy(xpath = "//button[contains(text(),'Tell us about yourself')]")
    this.fgiaTryAgain = page.locator("xpath=//button[contains(@aria-label,'Try That Again')]"); // @FindBy(xpath = "//button[contains(@aria-label,'Try That Again')]")
    this.fgiaTellUsAboutYourselfButton = page.locator("xpath=//button[@class='button medium action fill primary-btn next-step next']"); // @FindBy(xpath = "//button[@class='button medium action fill primary-btn next-step next']")
    this.fgiaZipCode = page.locator("xpath=//div[@id='container_in_alt_address']//div//span//span[2]"); // @FindBy(xpath = "//div[@id='container_in_alt_address']//div//span//span[2]")
  }
}
