// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.ThankYouPageAce. */
export class ThankYouPageAce extends CoreBasePage {
  public readonly pageTitle: Locator;
  public readonly pageSubTitle: Locator;
  public readonly thankYouPageQuoteNumber: Locator;
  public readonly bristolWestIcon: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageTitle = page.locator("xpath=//div[@class='thank-you__title']//h1"); // @FindBy(xpath = "//div[@class='thank-you__title']//h1")
    this.pageSubTitle = page.locator("xpath=//div[@class='tui-body thank-you__subtitle']//p"); // @FindBy(xpath = "//div[@class='tui-body thank-you__subtitle']//p")
    this.thankYouPageQuoteNumber = page.locator("xpath=//div[@class='thank-you__quote-number ng-star-inserted']//span[2]"); // @FindBy(xpath = "//div[@class='thank-you__quote-number ng-star-inserted']//span[2]")
    this.bristolWestIcon = page.locator("xpath=//img[@alt='Bristol West logo']"); // @FindBy(xpath = "//img[@alt='Bristol West logo']")
  }
}
