// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.AceAutoNavigationHelper. */
export class AceAutoNavigationHelper extends CoreBasePage {
  public readonly progressbarAceAuto: Locator;

  public constructor(page: Page) {
    super(page);
    this.progressbarAceAuto = page.locator("xpath=//mat-progress-bar"); // @FindBy(xpath = "//mat-progress-bar")
  }
}
