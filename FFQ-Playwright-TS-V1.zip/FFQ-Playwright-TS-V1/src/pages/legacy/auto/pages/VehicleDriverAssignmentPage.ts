// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.VehicleDriverAssignmentPage. */
export class VehicleDriverAssignmentPage extends CoreBasePage {
  public readonly vehicleDriverAssignmentPageTitle: Locator;
  public readonly vehicleDriverAssignmentPageSubTitle: Locator;
  public readonly vehicleList: Locator;
  public readonly listOfErrorLabels: Locator;
  public readonly requiredFieldDataMissingLabel: Locator;
  public readonly saveButton: Locator;
  public readonly resetButton: Locator;
  public readonly vehicleMatSelections: Locator;
  public readonly availableDriverMatOptions: Locator;

  public constructor(page: Page) {
    super(page);
    this.vehicleDriverAssignmentPageTitle = page.locator("xpath=//app-vehicle-driver-assignment//h1"); // @FindBy(xpath = "//app-vehicle-driver-assignment//h1")
    this.vehicleDriverAssignmentPageSubTitle = page.locator("[data-legacy-field=\"vehicleDriverAssignmentPageSubTitle\"]"); // @FindBy(xpath = VEHICLE_DRIVER_ASSIGNMENT_PAGE_XPATH + "//p")
    this.vehicleList = page.locator("[data-legacy-field=\"vehicleList\"]"); // @FindBy(xpath = VEHICLE_SECTION_XPATH)
    this.listOfErrorLabels = page.locator("xpath=//mat-error"); // @FindBy(xpath = "//mat-error")
    this.requiredFieldDataMissingLabel = page.locator("xpath=//*[contains(@class, 'vehicles-driver-assignment-fields-missing')]"); // @FindBy(xpath = "//*[contains(@class, 'vehicles-driver-assignment-fields-missing')]")
    this.saveButton = page.locator("xpath=//div[@class='continue-button']//button"); // @FindBy(xpath = "//div[@class='continue-button']//button")
    this.resetButton = page.locator("xpath=//div[@class='continue-button']//span"); // @FindBy(xpath = "//div[@class='continue-button']//span")
    this.vehicleMatSelections = page.locator("xpath=//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-details row')]//mat-select[@aria-invalid]"); // @FindBy(xpath = "//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-details row')]//mat-select[@aria-invalid]")
    this.availableDriverMatOptions = page.locator("xpath=//mat-option[@aria-disabled='false']"); // @FindBy(xpath = "//mat-option[@aria-disabled='false']")
  }
}
