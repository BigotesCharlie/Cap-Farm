// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.AutoEnterAddressPage. */
export class AutoEnterAddressPage extends CoreBasePage {
  public readonly addressPageTitle: Locator;
  public readonly addressPageSubtitle: Locator;
  public readonly enterAddressManuallyLink: Locator;
  public readonly manualStreetInputField: Locator;
  public readonly manualCityInputField: Locator;
  public readonly manualZipCodeInputField: Locator;
  public readonly manualApartmentInputField: Locator;
  public readonly townDropDown: Locator;
  public readonly townDropDownOptions: Locator;
  public readonly addressFieldErrorMessage: Locator;
  public readonly townSelectionMatError: Locator;
  public readonly addressInputField: Locator;
  public readonly streetInputField: Locator;
  public readonly streetInputFieldErrorMessage: Locator;
  public readonly changeButton: Locator;
  public readonly changeZipCodeContent: Locator;
  public readonly changeZipCodeGoBack: Locator;
  public readonly changeZipCodeHeading: Locator;
  public readonly changeZipCodePopUp: Locator;
  public readonly congratulationsMessage: Locator;
  public readonly editAddressHeading: Locator;
  public readonly editAddressStreetInputField: Locator;
  public readonly editAddressSubmitButton: Locator;
  public readonly generalErrorMessage: Locator;
  public readonly isHomeOwner: Locator;
  public readonly yourAddressSubheading: Locator;
  public readonly manualAddressEntryPopUpHeader: Locator;
  public readonly manualAddressEntryPopUpContent: Locator;
  public readonly enterManuallyButton: Locator;
  public readonly enterManuallyCancelButton: Locator;
  public readonly addressInputFieldLabel: Locator;
  public readonly unitInputFieldLabel: Locator;
  public readonly cityInputFieldLabel: Locator;
  public readonly zipCodeInputField: Locator;
  public readonly zipCodeInputFieldLabel: Locator;
  public readonly zipCodeInputFieldErrorMessage: Locator;
  public readonly manulaAddressFieldErrorMessage: Locator;
  public readonly cityErrorMessage: Locator;
  public readonly emailIdInput: Locator;
  public readonly phoneNumberInput: Locator;
  public readonly emailIdInputLabel: Locator;
  public readonly phoneNumberInputLabel: Locator;
  public readonly emailAddressError: Locator;
  public readonly phoneNumberError: Locator;
  public readonly warningPhoneNumberMsg: Locator;
  public readonly invalidEmailAddressError: Locator;
  public readonly invalidPhoneNumberError: Locator;
  public readonly agreeAndSubmitButton: Locator;
  public readonly agreeAndSubmitButtonDesc: Locator;
  public readonly goBackToEnterAddressLink: Locator;
  public readonly enterAddressManuallyButton: Locator;
  public readonly addressPageCreditDisclaimer: Locator;
  public readonly addressPageConsentDisclaimer: Locator;
  public readonly showMoreButton: Locator;
  public readonly showLessButton: Locator;
  public readonly employeeAffinitySectionIcon: Locator;
  public readonly employeeAffinitySectionHeader: Locator;
  public readonly employeeAffinitySectionDescription: Locator;
  public readonly checkYourFGSEligibilityLink: Locator;
  public readonly selectedEmployerName: Locator;
  public readonly removeEmployerGroupLink: Locator;
  public readonly fgsSidesheetHeader: Locator;
  public readonly fgsSidesheetDescription: Locator;
  public readonly fgsSidesheetEmployerGroupInputField: Locator;
  public readonly fgsSidesheetMessage: Locator;
  public readonly fgsSidesheetContinueButton: Locator;
  public readonly fgsSidesheetBenefitsTitle: Locator;
  public readonly fgsSidesheetBenefitsDescription: Locator;
  public readonly fgsSidesheetSkipDiscountLink: Locator;
  public readonly fgsSidesheetSkipDisclaimer: Locator;
  public readonly creditCheckDisclaimerTextElement: Locator;
  public readonly privacyPolicyDisclaimerTextElement: Locator;
  public readonly pageErrorMessage: Locator;
  public readonly esignAndContactDisclaimerSection: Locator;
  public readonly iHaveAutoInsuranceWithAnotherCompanyButton: Locator;
  public readonly iDontHaveAutoInsuranceWithAnotherCompanyButton: Locator;
  public readonly selectAllInsuranceProductsCheckbox: Locator;
  public readonly homeInsuranceCheckbox: Locator;
  public readonly rentersInsuranceCheckbox: Locator;
  public readonly mobilehomeInsuranceCheckbox: Locator;
  public readonly motorcycleInsuranceCheckbox: Locator;
  public readonly recVehicleInsuranceCheckbox: Locator;
  public readonly umbrellaInsuranceCheckbox: Locator;

  public constructor(page: Page) {
    super(page);
    this.addressPageTitle = page.locator("xpath=//div[contains(@class,'personal-info_address_h1')]"); // @FindBy(xpath = "//div[contains(@class,'personal-info_address_h1')]")
    this.addressPageSubtitle = page.locator("#auto-personal-info_address-subheading"); // @FindBy(id = "auto-personal-info_address-subheading")
    this.enterAddressManuallyLink = page.locator("xpath=//span[@class='manual-addr-heading']//a"); // @FindBy(xpath = "//span[@class='manual-addr-heading']//a")
    this.manualStreetInputField = page.locator("xpath=//div[@id='formField_street']//input"); // @FindBy(xpath = "//div[@id='formField_street']//input")
    this.manualCityInputField = page.locator("xpath=//div[@id='formField_city']//input"); // @FindBy(xpath = "//div[@id='formField_city']//input")
    this.manualZipCodeInputField = page.locator("xpath=//div[@id='formField_zipCode']//input"); // @FindBy(xpath = "//div[@id='formField_zipCode']//input")
    this.manualApartmentInputField = page.locator("xpath=//div[@id='formField_apartment']//input"); // @FindBy(xpath = "//div[@id='formField_apartment']//input")
    this.townDropDown = page.locator("[data-legacy-field=\"townDropDown\"]"); // @FindBy(xpath = TOWN_DROPDOWN_XPATH)
    this.townDropDownOptions = page.locator("xpath=//mat-option[contains(@class,'town__input')]"); // @FindBy(xpath = "//mat-option[contains(@class,'town__input')]")
    this.addressFieldErrorMessage = page.locator("xpath=//mat-form-field[@id='auto-manual-address-street__input-field']//mat-error"); // @FindBy(xpath = "//mat-form-field[@id='auto-manual-address-street__input-field']//mat-error")
    this.townSelectionMatError = page.locator("[data-legacy-field=\"townSelectionMatError\"]"); // @FindBy(xpath = TOWN_SELECTION_ERROR_MESSAGE_XPATH)
    this.addressInputField = page.locator("xpath=//input[@id='auto-manual-street__input-section']"); // @FindBy(xpath = "//input[@id='auto-manual-street__input-section']")
    this.streetInputField = page.locator("input[id='auto-manual-street__input-section']"); // @FindBy(css = "input[id='auto-manual-street__input-section']")
    this.streetInputFieldErrorMessage = page.locator("xpath=//mat-form-field[@id='auto-manual-address-street__input-field']//mat-error"); // @FindBy(xpath = "//mat-form-field[@id='auto-manual-address-street__input-field']//mat-error")
    this.changeButton = page.locator("xpath=//div[contains(@class,'actions-change')]//button"); // @FindBy(xpath = "//div[contains(@class,'actions-change')]//button")
    this.changeZipCodeContent = page.locator("#changeZipContent"); // @FindBy(id = "changeZipContent")
    this.changeZipCodeGoBack = page.locator("xpath=//div[contains(@class,'change-zip__actions-cancel-button')]"); // @FindBy(xpath = "//div[contains(@class,'change-zip__actions-cancel-button')]")
    this.changeZipCodeHeading = page.locator("#changeZipHeading"); // @FindBy(id = "changeZipHeading")
    this.changeZipCodePopUp = page.locator("[data-legacy-field=\"changeZipCodePopUp\"]"); // @FindBy(css = CHANGE_ZIPCODE_POPUP_CSS)
    this.congratulationsMessage = page.locator("xpath=//span/mat-icon[@alt='Congratulations'] | // div[text()=' Congratulations â You get the Homeowner discount']"); // @FindBy(xpath = "//span/mat-icon[@alt='Congratulations'] | // div[text()=' Congratulations — You get the Homeowner discount']")
    this.editAddressHeading = page.locator("[data-legacy-field=\"editAddressHeading\"]"); // @FindBy(xpath = EDIT_ADDRESS_HEADING)
    this.editAddressStreetInputField = page.locator("#auto-edit-street__input-section"); // @FindBy(id = "auto-edit-street__input-section")
    this.editAddressSubmitButton = page.locator("button[class='tui-btn tui-btn-primary auto-edit-address-submit__button']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary auto-edit-address-submit__button']")
    this.generalErrorMessage = page.locator("xpath=//p[contains(text(),'One or more required fields is incomplete or incorrect. Please review.')]"); // @FindBy(xpath = "//p[contains(text(),'One or more required fields is incomplete or incorrect. Please review.')]")
    this.isHomeOwner = page.locator("xpath=//input[contains(@id,'spouse_chkbox-input')]"); // @FindBy(xpath = "//input[contains(@id,'spouse_chkbox-input')]")
    this.yourAddressSubheading = page.locator("xpath=//div[@id='auto-personal-info_address-subheading']"); // @FindBy(xpath = "//div[@id='auto-personal-info_address-subheading']")
    this.manualAddressEntryPopUpHeader = page.locator("#manualAddrHeading"); // @FindBy(id = "manualAddrHeading")
    this.manualAddressEntryPopUpContent = page.locator("#manualAddrContent"); // @FindBy(id = "manualAddrContent")
    this.enterManuallyButton = page.locator("xpath=//button[contains(@class,'manual-addr__action-buttons')]"); // @FindBy(xpath = "//button[contains(@class,'manual-addr__action-buttons')]")
    this.enterManuallyCancelButton = page.locator("xpath=//div[contains(@class,'manual-addr__actions-cancel-button')]"); // @FindBy(xpath = "//div[contains(@class,'manual-addr__actions-cancel-button')]")
    this.addressInputFieldLabel = page.locator("xpath=//div[@id='formField_street']//label"); // @FindBy(xpath = "//div[@id='formField_street']//label")
    this.unitInputFieldLabel = page.locator("xpath=//div[@id='formField_apartment']//label"); // @FindBy(xpath = "//div[@id='formField_apartment']//label")
    this.cityInputFieldLabel = page.locator("xpath=//div[@id='formField_city']//label"); // @FindBy(xpath = "//div[@id='formField_city']//label")
    this.zipCodeInputField = page.locator("xpath=//div[@id='formField_zipCode']//input"); // @FindBy(xpath = "//div[@id='formField_zipCode']//input")
    this.zipCodeInputFieldLabel = page.locator("xpath=//div[@id='formField_zipCode']//label"); // @FindBy(xpath = "//div[@id='formField_zipCode']//label")
    this.zipCodeInputFieldErrorMessage = page.locator("xpath=//div[@id='formField_zipCode']//mat-error"); // @FindBy(xpath = "//div[@id='formField_zipCode']//mat-error")
    this.manulaAddressFieldErrorMessage = page.locator("xpath=//div[@id='formField_street']//div[@class='manual-address-error-text ng-star-inserted']"); // @FindBy(xpath = "//div[@id='formField_street']//div[@class='manual-address-error-text ng-star-inserted']")
    this.cityErrorMessage = page.locator("xpath=//mat-form-field[@id='manual-address-city__input-field']//mat-error"); // @FindBy(xpath = "//mat-form-field[@id='manual-address-city__input-field']//mat-error")
    this.emailIdInput = page.locator("xpath=//input[@formcontrolname='email' or @formcontrolname='emailAddress' and @aria-required='true']"); // @FindBy(xpath = "//input[@formcontrolname='email' or @formcontrolname='emailAddress' and @aria-required='true']")
    this.phoneNumberInput = page.locator("xpath=//input[(@formcontrolname='phoneNumber' or @formcontrolname='phone_number') and (@aria-required='true')]"); // @FindBy(xpath = "//input[(@formcontrolname='phoneNumber' or @formcontrolname='phone_number') and (@aria-required='true')]")
    this.emailIdInputLabel = page.locator("xpath=//input[@formcontrolname='email' or @formcontrolname='emailAddress' and @aria-required='true']/..//label"); // @FindBy(xpath = "//input[@formcontrolname='email' or @formcontrolname='emailAddress' and @aria-required='true']/..//label")
    this.phoneNumberInputLabel = page.locator("xpath=//input[(@formcontrolname='phoneNumber' or @formcontrolname='phone_number') and (@aria-required='true')]/..//label"); // @FindBy(xpath = "//input[(@formcontrolname='phoneNumber' or @formcontrolname='phone_number') and (@aria-required='true')]/..//label")
    this.emailAddressError = page.locator("xpath=//mat-error[contains(text(), 'email address')]"); // @FindBy(xpath = "//mat-error[contains(text(), 'email address')]")
    this.phoneNumberError = page.locator("xpath=//mat-error[contains(text(), 'phone number')]"); // @FindBy(xpath = "//mat-error[contains(text(), 'phone number')]")
    this.warningPhoneNumberMsg = page.locator("xpath=//span[contains(@class, 'warning-text')]"); // @FindBy(xpath="//span[contains(@class, 'warning-text')]")
    this.invalidEmailAddressError = page.locator("xpath=//mat-error[contains(text(), 'Email address')]"); // @FindBy(xpath = "//mat-error[contains(text(), 'Email address')]")
    this.invalidPhoneNumberError = page.locator("xpath=//mat-error[contains(text(), 'not a valid')]"); // @FindBy(xpath = "//mat-error[contains(text(), 'not a valid')]")
    this.agreeAndSubmitButton = page.locator("xpath=//div[contains(@class,'personal-info-cards-footer')]//button"); // @FindBy(xpath = "//div[contains(@class,'personal-info-cards-footer')]//button"),             @FindBy(xpath = "//div[contains(@class,'personal-info__disclaimer')] /following-sibling::div //button[@data-tui-tracking-id='personal-info__continue-button-cta' and contains(@class,'address-form__agree-cta') and normalize-space()='Agree and submit']")     })
    this.agreeAndSubmitButtonDesc = page.locator("xpath=//div[@class='address-form__continue-button']//span"); // @FindBy(xpath = "//div[@class='address-form__continue-button']//span")
    this.goBackToEnterAddressLink = page.locator(".manual-addr_field-label-text"); // @FindBy(className = "manual-addr_field-label-text")
    this.enterAddressManuallyButton = page.locator("xpath=//button[contains(@class, 'manual-addr__action-buttons')]"); // @FindBy(xpath = "//button[contains(@class, 'manual-addr__action-buttons')]")
    this.addressPageCreditDisclaimer = page.locator("xpath=//div[contains(@class, 'disclaimer__credit-report')]"); // @FindBy(xpath = "//div[contains(@class, 'disclaimer__credit-report')]")
    this.addressPageConsentDisclaimer = page.locator("xpath=//div[contains(@class, 'disclaimer__color') and contains(@class, 'inserted')]"); // @FindBy(xpath = "//div[contains(@class, 'disclaimer__color') and contains(@class, 'inserted')]")
    this.showMoreButton = page.locator("#showMoreButton"); // @FindBy(id = "showMoreButton")
    this.showLessButton = page.locator("#showLessButton"); // @FindBy(id = "showLessButton")
    this.employeeAffinitySectionIcon = page.locator("xpath=//div[contains(@class, 'employer_div_icon')]/mat-icon"); // @FindBy(xpath = "//div[contains(@class, 'employer_div_icon')]/mat-icon")
    this.employeeAffinitySectionHeader = page.locator("xpath=//span[contains(@class, 'info-box-header')]"); // @FindBy(xpath = "//span[contains(@class, 'info-box-header')]")
    this.employeeAffinitySectionDescription = page.locator("xpath=//p[contains(@class, 'employer-description')]"); // @FindBy(xpath = "//p[contains(@class, 'employer-description')]")
    this.checkYourFGSEligibilityLink = page.locator("[data-legacy-field=\"checkYourFGSEligibilityLink\"]"); // @FindBy(xpath = CHECK_YOUR_ELIGIBILITY_XPATH)
    this.selectedEmployerName = page.locator(".selected_employer_name"); // @FindBy(className = "selected_employer_name")
    this.removeEmployerGroupLink = page.locator("xpath=//a[contains(@class, 'remove_selected_employer')]"); // @FindBy(xpath = "//a[contains(@class, 'remove_selected_employer')]")
    this.fgsSidesheetHeader = page.locator("#fgs_sidesheet_heading"); // @FindBy(id = "fgs_sidesheet_heading")
    this.fgsSidesheetDescription = page.locator(".fgs-sidesheet-text-employer-header"); // @FindBy(className = "fgs-sidesheet-text-employer-header")
    this.fgsSidesheetEmployerGroupInputField = page.locator("#mat-input-fwsField"); // @FindBy(id = "mat-input-fwsField")
    this.fgsSidesheetMessage = page.locator("xpath=//div[contains(@class, 'employer-card-message')]"); // @FindBy(xpath = "//div[contains(@class, 'employer-card-message')]")
    this.fgsSidesheetContinueButton = page.locator("xpath=//div[@class='fgs-sidesheet_content']//button"); // @FindBy(xpath = "//div[@class='fgs-sidesheet_content']//button")
    this.fgsSidesheetBenefitsTitle = page.locator(".fgs_employer-card-success_title"); // @FindBy(className = "fgs_employer-card-success_title")
    this.fgsSidesheetBenefitsDescription = page.locator(".fgs_employer-card-success_desc"); // @FindBy(className = "fgs_employer-card-success_desc")
    this.fgsSidesheetSkipDiscountLink = page.locator(".fgs_employer-card-success_skip_btn"); // @FindBy(className = "fgs_employer-card-success_skip_btn")
    this.fgsSidesheetSkipDisclaimer = page.locator(".fgs_employer-card-success_disclaimer"); // @FindBy(className = "fgs_employer-card-success_disclaimer")
    this.creditCheckDisclaimerTextElement = page.locator("xpath=//*[contains(@class, 'disclaimer__credit-report')]"); // @FindBy(xpath = "//*[contains(@class, 'disclaimer__credit-report')]")
    this.privacyPolicyDisclaimerTextElement = page.locator("xpath=//*[starts-with(@class, 'disclaimer__color')]"); // @FindBy(xpath = "//*[starts-with(@class, 'disclaimer__color')]")
    this.pageErrorMessage = page.locator("xpath=//p[contains(@class,'personal-info__multiple-fields-missing')]"); // @FindBy(xpath = "//p[contains(@class,'personal-info__multiple-fields-missing')]")
    this.esignAndContactDisclaimerSection = page.locator("xpath=//a[contains(@href, 'electronic')]/ancestor::div[1][contains(@class, 'tui-stacking')]"); // @FindBy(xpath = "//a[contains(@href, 'electronic')]/ancestor::div[1][contains(@class, 'tui-stacking')]")
    this.iHaveAutoInsuranceWithAnotherCompanyButton = page.locator("xpath=//mat-button-toggle-group[contains(@aria-label, 'auto insurance with another insurance company')]//button[contains(., 'Yes')]"); // @FindBy(xpath = "//mat-button-toggle-group[contains(@aria-label, 'auto insurance with another insurance company')]//button[contains(., 'Yes')]")
    this.iDontHaveAutoInsuranceWithAnotherCompanyButton = page.locator("xpath=//mat-button-toggle-group[contains(@aria-label, 'auto insurance with another insurance company')]//button[contains(., 'No')]"); // @FindBy(xpath = "//mat-button-toggle-group[contains(@aria-label, 'auto insurance with another insurance company')]//button[contains(., 'No')]")
    this.selectAllInsuranceProductsCheckbox = page.locator("[data-legacy-field=\"selectAllInsuranceProductsCheckbox\"]"); // @FindBy(xpath = SELECT_ALL_PRODUCTS_XPATH)
    this.homeInsuranceCheckbox = page.locator("xpath=//img[contains(@src, 'rebrand_home')]/preceding-sibling::mat-checkbox//input"); // @FindBy(xpath = "//img[contains(@src, 'rebrand_home')]/preceding-sibling::mat-checkbox//input")
    this.rentersInsuranceCheckbox = page.locator("xpath=//img[contains(@src, 'rebrand_renter')]/preceding-sibling::mat-checkbox//input"); // @FindBy(xpath = "//img[contains(@src, 'rebrand_renter')]/preceding-sibling::mat-checkbox//input")
    this.mobilehomeInsuranceCheckbox = page.locator("xpath=//img[contains(@src, 'home-icon')]/preceding-sibling::mat-checkbox//input"); // @FindBy(xpath = "//img[contains(@src, 'home-icon')]/preceding-sibling::mat-checkbox//input")
    this.motorcycleInsuranceCheckbox = page.locator("xpath=//img[contains(@src, 'motorcycle')]/preceding-sibling::mat-checkbox//input"); // @FindBy(xpath = "//img[contains(@src, 'motorcycle')]/preceding-sibling::mat-checkbox//input")
    this.recVehicleInsuranceCheckbox = page.locator("xpath=//img[contains(@src, 'mobilehome')]/preceding-sibling::mat-checkbox//input"); // @FindBy(xpath = "//img[contains(@src, 'mobilehome')]/preceding-sibling::mat-checkbox//input")
    this.umbrellaInsuranceCheckbox = page.locator("xpath=//img[contains(@src, 'rebrand-umbrella')]/preceding-sibling::mat-checkbox//input"); // @FindBy(xpath = "//img[contains(@src, 'rebrand-umbrella')]/preceding-sibling::mat-checkbox//input")
  }
}
