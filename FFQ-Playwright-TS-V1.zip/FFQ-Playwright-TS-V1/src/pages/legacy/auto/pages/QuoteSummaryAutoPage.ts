// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.QuoteSummaryAutoPage. */
export class QuoteSummaryAutoPage extends CoreBasePage {
  public readonly alternativePaymentMethodLink: Locator;
  public readonly allDisplayedCoverages: Locator;
  public readonly allDisplayedLimits: Locator;
  public readonly allDisplayedPrices: Locator;
  public readonly bwDisclaimerFooter: Locator;
  public readonly gotItButton: Locator;
  public readonly byDefaultSelectedRadioButtons: Locator;
  public readonly liabilitySideDialogCloseIcon: Locator;
  public readonly vehicleSideDialogCloseIcon: Locator;
  public readonly liabilitySideDialogTitle: Locator;
  public readonly discountsIncluded: Locator;
  public readonly discountsIncludedCount: Locator;
  public readonly emailLink: Locator;
  public readonly mobileEmailButton: Locator;
  public readonly homeRateValue: Locator;
  public readonly liabilityCoverageSection: Locator;
  public readonly liabilityToggle: Locator;
  public readonly medicalCoverageToggle: Locator;
  public readonly uncheckedBodilyInjuryRadioButtons: Locator;
  public readonly allBodilyInjuryRadioButtons: Locator;
  public readonly bodilyInjuryErrorMessage: Locator;
  public readonly allBodilyInjuryPart5RadioButtons: Locator;
  public readonly uncheckedBodilyInjuryRadioButtonsForBW: Locator;
  public readonly allBodilyInjuryRadioButtonsBW: Locator;
  public readonly unInsuredMotoristToggle: Locator;
  public readonly unInsuredMotoristToggleBW: Locator;
  public readonly unInsuredMotoristRadioButtons: Locator;
  public readonly unInsuredMotoristRadioButtonsBW: Locator;
  public readonly unInsuredMotoristErrorMessage: Locator;
  public readonly underInsuredMotoristToggle: Locator;
  public readonly underInsuredMotoristToggleBW: Locator;
  public readonly underInsuredMotoristRadioButtons: Locator;
  public readonly underInsuredMotoristRadioButtonsBW: Locator;
  public readonly underInsuredMotoristErrorMessage: Locator;
  public readonly UMBISideSheetToggle: Locator;
  public readonly UMBISideSheetRadioButtons: Locator;
  public readonly UMBI_rule_message: Locator;
  public readonly UMBI_rule_error_message: Locator;
  public readonly uncheckedPropertyDamageRadioButtons: Locator;
  public readonly allPropertyDamageRadioButtons: Locator;
  public readonly propertyDamageErrorMessage: Locator;
  public readonly uncheckedPropertyDamageRadioButtonsForBW: Locator;
  public readonly allPropertyDamageRadioButtonsForBW: Locator;
  public readonly allMedicalPaymentsRadioButtonsForBW: Locator;
  public readonly medicalPaymentToggle: Locator;
  public readonly checkedAccidentDeathRadioButton: Locator;
  public readonly uncheckedAccidentDeathRadioButtons: Locator;
  public readonly uncheckedCompRadioButtons: Locator;
  public readonly uncheckedCompRadioButtonsForBW: Locator;
  public readonly comprehensiveToggle: Locator;
  public readonly comprehensiveToggleForBW: Locator;
  public readonly allComprehensiveRadioButtons_BW: Locator;
  public readonly collToggle: Locator;
  public readonly limitedCollisionToggle: Locator;
  public readonly limitedCollisionErrorMessage: Locator;
  public readonly collToggle_BW: Locator;
  public readonly uimPD_collisonToggle_BW: Locator;
  public readonly uncheckedCollRadioButtons: Locator;
  public readonly uncheckedCollRadioButtonsForBW: Locator;
  public readonly allRadioCollisionRadioButtons_BW: Locator;
  public readonly liabilityCoverageSectionLimits: Locator;
  public readonly liabilityCoverageExpansionPanel: Locator;
  public readonly vehicleCoverageExpansionPanel: Locator;
  public readonly umpdToggle: Locator;
  public readonly umUimToggle: Locator;
  public readonly umUimToggleErrorMessage: Locator;
  public readonly umpdErrorMessage: Locator;
  public readonly includedItems: Locator;
  public readonly defaultVehicleCoverageSectionLimitsBrowser: Locator;
  public readonly defaultVehicleCoverageSectionLimitsMobile: Locator;
  public readonly linkSeeAllMyQuotes: Locator;
  public readonly myFarmersQuotesTitle: Locator;
  public readonly pageTitle: Locator;
  public readonly totalPriceDescMobile: Locator;
  public readonly totalPriceDescDesktop: Locator;
  public readonly priceInCents: Locator;
  public readonly priceInCentsMobile: Locator;
  public readonly priceInDollars: Locator;
  public readonly priceInDollarsMobile: Locator;
  public readonly quoteCardExpandIcon: Locator;
  public readonly quoteNumber: Locator;
  public readonly recalculateButton: Locator;
  public readonly bwAdjustmentPopUpContents: Locator;
  public readonly resetChangesButton: Locator;
  public readonly recalculateErrorMessage: Locator;
  public readonly sectionsOnSideDialog: Locator;
  public readonly seeAllMyQuotes: Locator;
  public readonly mobileStartCheckoutButtonExpended: Locator;
  public readonly startCheckoutButton: Locator;
  public readonly bundleAndContinueButton: Locator;
  public readonly agreeAndSubmitButton: Locator;
  public readonly subTitleRegardingCurrentCoverage: Locator;
  public readonly subTitleRegardingCustomizing: Locator;
  public readonly vehicleCoverageSection: Locator;
  public readonly viewMonthlyOrFullPriceButton: Locator;
  public readonly mobileviewMonthlyOrFullPriceButton: Locator;
  public readonly contactEsignDisclaimer: Locator;
  public readonly contactInfoDisclaimer: Locator;
  public readonly bundleContinueToPropertyReviewCoveragePageButton: Locator;
  public readonly lblMainPremiumAmount: Locator;
  public readonly btnEditLiabilityCoverage: Locator;
  public readonly btnEditSingleVehicleCoverage: Locator;
  public readonly lblEditLiabilityCoverageHeader: Locator;
  public readonly lblEditVehicleCoverageHeader: Locator;
  public readonly membershipFeePrice: Locator;
  public readonly liabilityCoverages: Locator;
  public readonly vehicleCoverages: Locator;
  public readonly liabilityLimits: Locator;
  public readonly vehicleLimits: Locator;
  public readonly liabilityPrices: Locator;
  public readonly vehiclePrices: Locator;
  public readonly vehicleReplacementPlusCoverage: Locator;
  public readonly vehicleReplacementPlusLimit: Locator;
  public readonly vehicleReplacementPlusPrice: Locator;
  public readonly adjustmentDialogCloseButton: Locator;
  public readonly priceTooHighTitles: Locator;
  public readonly priceTooHighDescriptions: Locator;
  public readonly priceTooHighPhoneNumbers: Locator;
  public readonly quoteUpdateDialogCtaButton: Locator;
  public readonly monthlyAutoPayPriceInBundleQuoteLedger: Locator;
  public readonly payInFullPriceInBundleQuoteLedger: Locator;
  public readonly pipSideSheetCoverageLabel: Locator;
  public readonly pipSideSheetCoverageDescription: Locator;
  public readonly pb3Question: Locator;
  public readonly pipDeductibleYesButton: Locator;
  public readonly pipDeductibleNoButton: Locator;
  public readonly pipDeductibleButtonsHeader: Locator;
  public readonly pipRadioButtons: Locator;
  public readonly pipCheckedRadioButton: Locator;
  public readonly zeroDeductibleAppliesElement: Locator;
  public readonly emailInputFieldMediaAlpha: Locator;
  public readonly phoneInputFieldMediaAlpha: Locator;
  public readonly medialAlphaPrefilledAddress: Locator;
  public readonly comboCoverageTooltipHeader: Locator;
  public readonly comboCoverageTooltipLightBulb: Locator;
  public readonly comboCoverageTooltipContent: Locator;
  public readonly additionalCoverageToggles: Locator;
  public readonly continueWithSignalDiscountDialog: Locator;
  public readonly yesContinueWithSignalDiscount: Locator;
  public readonly dontContinueWithSignalDiscount: Locator;
  public readonly permissiveUserLimitUpdatedValue: Locator;
  public readonly resetOriginalQuoteButton: Locator;
  public readonly sourceCodePopUpHeader: Locator;
  public readonly sourceCodePopUpContentParagraph1: Locator;
  public readonly sourceCodePopUpContentParagraph2: Locator;
  public readonly sourceCodePopUpOkButton: Locator;
  public readonly liabilityCoveragePrice: Locator;
  public readonly liabilityCoveragePrice1: Locator;
  public readonly vehicleCoveragePrice: Locator;
  public readonly vehicleCoveragePrice1: Locator;
  public readonly payRollBanner: Locator;
  public readonly payRollContactButton: Locator;
  public readonly payRollBannerContent: Locator;
  public readonly bwPromoCard: Locator;
  public readonly bwPromoLogo: Locator;
  public readonly bwPromoInfoIcon: Locator;
  public readonly bwPromoInfoIconContent: Locator;
  public readonly bwPromoHeader: Locator;
  public readonly bwPromoContent: Locator;
  public readonly bwPromoPhoneLink: Locator;
  public readonly marinePopUp: Locator;
  public readonly marinePopUpHeader: Locator;
  public readonly marinePopUpContent: Locator;
  public readonly marinePopUpOkButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.alternativePaymentMethodLink = page.locator("xpath=//div[contains(@class,'price-alternative')]"); // @FindBy(xpath = "//div[contains(@class,'price-alternative')]")
    this.allDisplayedCoverages = page.locator("xpath=//div[@class='row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted']/div[1]"); // @FindBy(xpath = "//div[@class='row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted']/div[1]")
    this.allDisplayedLimits = page.locator("xpath=//div[@class='row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted']/div[2]"); // @FindBy(xpath = "//div[@class='row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted']/div[2]")
    this.allDisplayedPrices = page.locator("xpath=//div[@class='row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted']/div[3]"); // @FindBy(xpath = "//div[@class='row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted']/div[3]")
    this.bwDisclaimerFooter = page.locator("xpath=//footer[contains(@class, 'autoBW')]//div[contains(@class, 'footer-disclaimer-container')]"); // @FindBy(xpath = "//footer[contains(@class, 'autoBW')]//div[contains(@class, 'footer-disclaimer-container')]")
    this.gotItButton = page.locator("xpath=//a[@id='emailLink']"); // @FindBy(xpath = "//a[@id='emailLink']"),             @FindBy(xpath = "//a[@id='emailLinkSnackBar']")     })
    this.byDefaultSelectedRadioButtons = page.locator("xpath=//coverage-input-card/div[4][not(contains(@class,'d-none'))]//mat-radio-button[contains(@class,'checked')]//label"); // @FindBy(xpath = "//coverage-input-card/div[4][not(contains(@class,'d-none'))]//mat-radio-button[contains(@class,'checked')]//label")
    this.liabilitySideDialogCloseIcon = page.locator("#auto-quote-liability__dialog-close-icon"); // @FindBy(id = "auto-quote-liability__dialog-close-icon")
    this.vehicleSideDialogCloseIcon = page.locator("#auto-quote-vehicle__dialog-close-icon"); // @FindBy(id = "auto-quote-vehicle__dialog-close-icon")
    this.liabilitySideDialogTitle = page.locator("xpath=//app-edit-liability-coverage//h2"); // @FindBy(xpath = "//app-edit-liability-coverage//h2")
    this.discountsIncluded = page.locator("xpath=//span[contains(@class,'discount-name')]"); // @FindBy(xpath = "//span[contains(@class,'discount-name')]")
    this.discountsIncludedCount = page.locator("xpath=//div[contains(@class,'discount-description')]/p[contains(@class,'tui-subtitle')]"); // @FindBy(xpath = "//div[contains(@class,'discount-description')]/p[contains(@class,'tui-subtitle')]")
    this.emailLink = page.locator("div.tui-email-link"); // @FindBy(css = "div.tui-email-link")
    this.mobileEmailButton = page.locator("xpath=//button[contains(@class, 'tui-email-link tui-link') and not(contains(@class,'hide'))]"); // @FindBy(xpath = "//button[contains(@class, 'tui-email-link tui-link') and not(contains(@class,'hide'))]")
    this.homeRateValue = page.locator("xpath=//mat-dialog-container/app-manage-quotes//div[contains(text(),'Home')]/../div[contains(@class,'rate-value')]"); // @FindBy(xpath = "//mat-dialog-container/app-manage-quotes//div[contains(text(),'Home')]/../div[contains(@class,'rate-value')]")
    this.liabilityCoverageSection = page.locator("xpath=//app-coverage[not(@class)]"); // @FindBy(xpath = "//app-coverage[not(@class)]")
    this.liabilityToggle = page.locator("xpath=//input[@id='Liability__BI__toggle-input']"); // @FindBy(xpath = "//input[@id='Liability__BI__toggle-input']")
    this.medicalCoverageToggle = page.locator("xpath=//mat-slide-toggle[@id='Liability__MP__toggle']//input"); // @FindBy(xpath = "//mat-slide-toggle[@id='Liability__MP__toggle']//input")
    this.uncheckedBodilyInjuryRadioButtons = page.locator("[data-legacy-field=\"uncheckedBodilyInjuryRadioButtons\"]"); // @FindBy(xpath = BI_RADIO_BUTTON_SIDE_SHEET_GROUP_XPATH + "//mat-radio-button[not(contains(@class,'mat-radio-checked'))]")
    this.allBodilyInjuryRadioButtons = page.locator("[data-legacy-field=\"allBodilyInjuryRadioButtons\"]"); // @FindBy(xpath = BI_RADIO_BUTTON_SIDE_SHEET_GROUP_XPATH + "//mat-radio-button//label")
    this.bodilyInjuryErrorMessage = page.locator("xpath=//mat-radio-group[@aria-label='select Bodily Injury (required)' or @id='Liability__13023__radio' or @id='Liability__BI__radio']/../../../..//coverage-input-card//mat-error"); // @FindBy(xpath = "//mat-radio-group[@aria-label='select Bodily Injury (required)' or @id='Liability__13023__radio' or @id='Liability__BI__radio']/../../../..//coverage-input-card//mat-error")
    this.allBodilyInjuryPart5RadioButtons = page.locator("xpath=//mat-radio-group[@id='Liability__13045__radio']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__13045__radio']//mat-radio-button")
    this.uncheckedBodilyInjuryRadioButtonsForBW = page.locator("xpath=//mat-radio-group[@id='Liability__BI__radio' or @id='Liability__OBI__radio']//mat-radio-button[not(contains(@class,'mat-mdc-radio-checked'))]"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__BI__radio' or @id='Liability__OBI__radio']//mat-radio-button[not(contains(@class,'mat-mdc-radio-checked'))]")
    this.allBodilyInjuryRadioButtonsBW = page.locator("xpath=//mat-radio-group[@id='Liability__BI__radio' or @id='Liability__OBI__radio']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__BI__radio' or @id='Liability__OBI__radio']//mat-radio-button")
    this.unInsuredMotoristToggle = page.locator("[data-legacy-field=\"unInsuredMotoristToggle\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_TOGGLE_XPATH)
    this.unInsuredMotoristToggleBW = page.locator("[data-legacy-field=\"unInsuredMotoristToggleBW\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_TOGGLE_XPATH_BW)
    this.unInsuredMotoristRadioButtons = page.locator("xpath=//mat-radio-group[@id='Liability__11101__radio' or @id='Liability__13137__radio']//mat-radio-button//label"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__11101__radio' or @id='Liability__13137__radio']//mat-radio-button//label")
    this.unInsuredMotoristRadioButtonsBW = page.locator("xpath=//mat-radio-group[@id='Liability__UM__radio']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__UM__radio']//mat-radio-button")
    this.unInsuredMotoristErrorMessage = page.locator("[data-legacy-field=\"unInsuredMotoristErrorMessage\"]"); // @FindBy(xpath = UNINSURED_MOTORIST_TOGGLE_XPATH + "/ancestor::coverage-input-card//mat-error")
    this.underInsuredMotoristToggle = page.locator("[data-legacy-field=\"underInsuredMotoristToggle\"]"); // @FindBy(xpath = UNDERINSURED_TOGGLE_XPATH)
    this.underInsuredMotoristToggleBW = page.locator("[data-legacy-field=\"underInsuredMotoristToggleBW\"]"); // @FindBy(xpath = UNDERINSURED_TOGGLE_XPATH_BW)
    this.underInsuredMotoristRadioButtons = page.locator("xpath=//mat-radio-group[@id='Liability__13103__radio' or @id='Liability__13138__radio']//mat-radio-button//label"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__13103__radio' or @id='Liability__13138__radio']//mat-radio-button//label")
    this.underInsuredMotoristRadioButtonsBW = page.locator("xpath=//mat-radio-group[@id='Liability__UNDUM__radio']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__UNDUM__radio']//mat-radio-button")
    this.underInsuredMotoristErrorMessage = page.locator("[data-legacy-field=\"underInsuredMotoristErrorMessage\"]"); // @FindBy(xpath = UNDERINSURED_TOGGLE_XPATH + "/ancestor::coverage-input-card//mat-error")
    this.UMBISideSheetToggle = page.locator("[data-legacy-field=\"UMBISideSheetToggle\"]"); // @FindBy(xpath = UMBI_TOGGLE_XPATH)
    this.UMBISideSheetRadioButtons = page.locator("[data-legacy-field=\"UMBISideSheetRadioButtons\"]"); // @FindBy(xpath = UMUIM_SIDE_RADIO_BUTTONS_SHEET_XPATH)
    this.UMBI_rule_message = page.locator("xpath=//p[contains(@class,'auto-quote-liability__notes')]"); // @FindBy(xpath = "//p[contains(@class,'auto-quote-liability__notes')]")
    this.UMBI_rule_error_message = page.locator("[data-legacy-field=\"UMBI_rule_error_message\"]"); // @FindBy(xpath = UMBI_TOGGLE_XPATH + "/../../..//mat-error")
    this.uncheckedPropertyDamageRadioButtons = page.locator("xpath=//mat-radio-group[@id='Liability__13024__radio']//mat-radio-button[not(contains(@class,'mat-radio-checked'))]"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__13024__radio']//mat-radio-button[not(contains(@class,'mat-radio-checked'))]")
    this.allPropertyDamageRadioButtons = page.locator("xpath=//mat-radio-group[@id='Liability__13024__radio' or @id='Liability__PD__radio']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__13024__radio' or @id='Liability__PD__radio']//mat-radio-button")
    this.propertyDamageErrorMessage = page.locator("xpath=//mat-radio-group[@id='Liability__13024__radio' or @id='Liability__PD__radio']/../../..//mat-error"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__13024__radio' or @id='Liability__PD__radio']/../../..//mat-error")
    this.uncheckedPropertyDamageRadioButtonsForBW = page.locator("xpath=//mat-radio-group[@id='Liability__PD__radio']//mat-radio-button[not(contains(@class,'mat-radio-checked'))]"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__PD__radio']//mat-radio-button[not(contains(@class,'mat-radio-checked'))]")
    this.allPropertyDamageRadioButtonsForBW = page.locator("xpath=//mat-radio-group[@id='Liability__PD__radio']"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__PD__radio']")
    this.allMedicalPaymentsRadioButtonsForBW = page.locator("xpath=//mat-radio-group[@id='Liability__MP__radio' or @id='Liability__MEDPM__radio']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__MP__radio' or @id='Liability__MEDPM__radio']//mat-radio-button")
    this.medicalPaymentToggle = page.locator("xpath=//mat-slide-toggle[@id='Liability__MP__toggle' or @id='Liability__MEDPM__toggle']"); // @FindBy(xpath = "//mat-slide-toggle[@id='Liability__MP__toggle' or @id='Liability__MEDPM__toggle']")
    this.checkedAccidentDeathRadioButton = page.locator("[data-legacy-field=\"checkedAccidentDeathRadioButton\"]"); // @FindBy(xpath = CHECKED_ACCIDENT_DEATH_RADIO_BUTTON_XPATH)
    this.uncheckedAccidentDeathRadioButtons = page.locator("[data-legacy-field=\"uncheckedAccidentDeathRadioButtons\"]"); // @FindBy(xpath = UNCHECKED_ACCIDENT_DEATH_RADIO_BUTTON_XPATH)
    this.uncheckedCompRadioButtons = page.locator("xpath=//mat-radio-group[@id='Vehicle__21000__radio' or @id='Vehicle__21031__radio']//mat-radio-button[not(contains(@class,'checked'))]//label"); // @FindBy(xpath = "//mat-radio-group[@id='Vehicle__21000__radio' or @id='Vehicle__21031__radio']//mat-radio-button[not(contains(@class,'checked'))]//label")
    this.uncheckedCompRadioButtonsForBW = page.locator("[data-legacy-field=\"uncheckedCompRadioButtonsForBW\"]"); // @FindBy(xpath = COMP_UNCHECKED_RADIO_BUTTONS_BW)
    this.comprehensiveToggle = page.locator("xpath=//mat-slide-toggle[@id='Vehicle__COMP__toggle' or @id='Vehicle__21000__toggle' or @id='Vehicle__21031__toggle' or @id='Vehicle__OTC__toggle']//button"); // @FindBy(xpath = "//mat-slide-toggle[@id='Vehicle__COMP__toggle' or @id='Vehicle__21000__toggle' or @id='Vehicle__21031__toggle' or @id='Vehicle__OTC__toggle']//button")
    this.comprehensiveToggleForBW = page.locator("xpath=//button[@id='Vehicle__COMP__toggle-button']"); // @FindBy(xpath = "//button[@id='Vehicle__COMP__toggle-button']"),             @FindBy(css = "button[id='Vehicle__OTC__toggle-button']")     })
    this.allComprehensiveRadioButtons_BW = page.locator("xpath=//mat-radio-group[@id='Vehicle__COMP__radio' or @id='Vehicle__OTC__toggle']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@id='Vehicle__COMP__radio' or @id='Vehicle__OTC__toggle']//mat-radio-button")
    this.collToggle = page.locator("xpath=//mat-slide-toggle[@id='Vehicle__22000__toggle' or @id='Vehicle__22031__toggle' or @id='Vehicle__COL__toggle']//button"); // @FindBy(xpath = "//mat-slide-toggle[@id='Vehicle__22000__toggle' or @id='Vehicle__22031__toggle' or @id='Vehicle__COL__toggle']//button")
    this.limitedCollisionToggle = page.locator("xpath=//mat-slide-toggle[@id='Vehicle__LC__toggle']//button"); // @FindBy(xpath = "//mat-slide-toggle[@id='Vehicle__LC__toggle']//button")
    this.limitedCollisionErrorMessage = page.locator("xpath=//coverage-input-card[contains(.,'Limited Collision')]//mat-error"); // @FindBy(xpath = "//coverage-input-card[contains(.,'Limited Collision')]//mat-error")
    this.collToggle_BW = page.locator("xpath=//mat-slide-toggle[@id='Vehicle__COLL__toggle' or @id='Vehicle__COL__toggle']"); // @FindBy(xpath = "//mat-slide-toggle[@id='Vehicle__COLL__toggle' or @id='Vehicle__COL__toggle']")
    this.uimPD_collisonToggle_BW = page.locator("xpath=//mat-slide-toggle[@id='Vehicle__UMPD__toggle']"); // @FindBy(xpath = "//mat-slide-toggle[@id='Vehicle__UMPD__toggle']")
    this.uncheckedCollRadioButtons = page.locator("xpath=//mat-radio-group[@id='Vehicle__22000__radio' or @id='Vehicle__22031__radio' or @id='Vehicle__COL__radio']//mat-radio-button[not(contains(@class,'checked'))]//label"); // @FindBy(xpath = "//mat-radio-group[@id='Vehicle__22000__radio' or @id='Vehicle__22031__radio' or @id='Vehicle__COL__radio']//mat-radio-button[not(contains(@class,'checked'))]//label")
    this.uncheckedCollRadioButtonsForBW = page.locator("[data-legacy-field=\"uncheckedCollRadioButtonsForBW\"]"); // @FindBy(xpath = COLL_UNCHECKED_RADIO_BUTTONS_BW)
    this.allRadioCollisionRadioButtons_BW = page.locator("xpath=//mat-radio-group[@id='Vehicle__COLL__radio' or @id='Vehicle__COL__radio']//mat-radio-button"); // @FindBy(xpath = "//mat-radio-group[@id='Vehicle__COLL__radio' or @id='Vehicle__COL__radio']//mat-radio-button")
    this.liabilityCoverageSectionLimits = page.locator("xpath=//app-coverage[contains(.,'Liability')]//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted')]//div[2]"); // @FindBy(xpath = "//app-coverage[contains(.,'Liability')]//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted')]//div[2]")
    this.liabilityCoverageExpansionPanel = page.locator("xpath=//app-coverage[contains(.,'Liability')]//mat-expansion-panel"); // @FindBy(xpath = "//app-coverage[contains(.,'Liability')]//mat-expansion-panel")
    this.vehicleCoverageExpansionPanel = page.locator("xpath=//app-coverage[contains(.,'Vehicle')]//mat-expansion-panel"); // @FindBy(xpath = "//app-coverage[contains(.,'Vehicle')]//mat-expansion-panel")
    this.umpdToggle = page.locator("#Liability__UMPD__toggle"); // @FindBy(id = "Liability__UMPD__toggle"))
    this.umUimToggle = page.locator("#Liability__UMUIM__toggle"); // @FindBy(id = "Liability__UMUIM__toggle"))
    this.umUimToggleErrorMessage = page.locator("xpath=//coverage-input-card[contains(.,'UM/UIM Bodily Injury') or contains(.,'UM/UIM Bodily injury')]//mat-error"); // @FindBy(xpath = "//coverage-input-card[contains(.,'UM/UIM Bodily Injury') or contains(.,'UM/UIM Bodily injury')]//mat-error"))
    this.umpdErrorMessage = page.locator("xpath=//coverage-input-card[contains(.,'Uninsured Motorist Property Damage')]//mat-error"); // @FindBy(xpath = "//coverage-input-card[contains(.,'Uninsured Motorist Property Damage')]//mat-error"))
    this.includedItems = page.locator("xpath=//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and contains(.,'Included')]"); // @FindBy(xpath = "//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and contains(.,'Included')]")
    this.defaultVehicleCoverageSectionLimitsBrowser = page.locator("xpath=//app-coverage[contains(.,'Vehicle')]//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and not(contains(.,'--'))]//div[2]"); // @FindBy(xpath = "//app-coverage[contains(.,'Vehicle')]//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and not(contains(.,'--'))]//div[2]")
    this.defaultVehicleCoverageSectionLimitsMobile = page.locator("xpath=//app-coverage[contains(.,'Vehicle')]//div[contains(@class,'row auto-quote-liability-coverages-item-row auto-quote-coverages-mobile d-flex d-md-none ng-star-inserted')]//div[1]"); // @FindBy(xpath = "//app-coverage[contains(.,'Vehicle')]//div[contains(@class,'row auto-quote-liability-coverages-item-row auto-quote-coverages-mobile d-flex d-md-none ng-star-inserted')]//div[1]")
    this.linkSeeAllMyQuotes = page.locator("xpath=//tui-quote-presentment//div[.='See all my quotes']"); // @FindBy(xpath = "//tui-quote-presentment//div[.='See all my quotes']")
    this.myFarmersQuotesTitle = page.locator("xpath=//app-manage-quotes[contains(.,'My Farmers quotes')]"); // @FindBy(xpath = "//app-manage-quotes[contains(.,'My Farmers quotes')]")
    this.pageTitle = page.locator("xpath=//app-quote//h1[contains(@class, 'page-title')]"); // @FindBy(xpath = "//app-quote//h1[contains(@class, 'page-title')]")
    this.totalPriceDescMobile = page.locator("xpath=//mat-card[contains(@class,'mobile')]//div[contains(@class,'tui-price')]"); // @FindBy(xpath = "//mat-card[contains(@class,'mobile')]//div[contains(@class,'tui-price')]")
    this.totalPriceDescDesktop = page.locator("xpath=//mat-card[contains(@class,'desktop')]//div[contains(@class,'tui-price')]"); // @FindBy(xpath = "//mat-card[contains(@class,'desktop')]//div[contains(@class,'tui-price')]")
    this.priceInCents = page.locator(".tui-price>div.lg-price-sides:nth-child(3)"); // @FindBy(css = ".tui-price>div.lg-price-sides:nth-child(3)")
    this.priceInCentsMobile = page.locator("xpath=//div[@class='md-price-sides' and contains(.,'.')]"); // @FindBy(xpath = "//div[@class='md-price-sides' and contains(.,'.')]")
    this.priceInDollars = page.locator(".tui-price .lg-price-main"); // @FindBy(css = ".tui-price .lg-price-main")
    this.priceInDollarsMobile = page.locator("xpath=//div[contains(@class,'tui-quote-presentment-minimized')]//div[@class='md-price-main']"); // @FindBy(xpath = "//div[contains(@class,'tui-quote-presentment-minimized')]//div[@class='md-price-main']")
    this.quoteCardExpandIcon = page.locator("xpath=//div[contains(@class,'tui-quote-presentment-expand-button')]"); // @FindBy(xpath = "//div[contains(@class,'tui-quote-presentment-expand-button')]")
    this.quoteNumber = page.locator("div.auto-agent-details__save-quote"); // @FindBy(css = "div.auto-agent-details__save-quote")
    this.recalculateButton = page.locator("xpath=//button[contains(text(), 'Recalculate')]"); // @FindBy(xpath = "//button[contains(text(), 'Recalculate')]")
    this.bwAdjustmentPopUpContents = page.locator("mat-dialog-content[id='bwInfoDialogContent']>ul>li"); // @FindBy(css = "mat-dialog-content[id='bwInfoDialogContent']>ul>li")
    this.resetChangesButton = page.locator("xpath=//div[contains(@class,'auto-quote-liability__button-section')]//a"); // @FindBy(xpath = "//div[contains(@class,'auto-quote-liability__button-section')]//a")
    this.recalculateErrorMessage = page.locator("p[class='tui-caption-text coverage-error']"); // @FindBy(css = "p[class='tui-caption-text coverage-error']")
    this.sectionsOnSideDialog = page.locator("xpath=//app-edit-liability-coverage//div[@class='ng-star-inserted']"); // @FindBy(xpath = "//app-edit-liability-coverage//div[@class='ng-star-inserted']")
    this.seeAllMyQuotes = page.locator("div.tui-print-link"); // @FindBy(css = "div.tui-print-link")
    this.mobileStartCheckoutButtonExpended = page.locator("xpath=(//button[@id='track-ctn-btn'])[1]"); // @FindBy(xpath = MOBILE_CHECKOUT_BUTTON_XPATH),             @FindBy(partialLinkText = CONTINUE_WITH_AUTO),             @FindBy(xpath = "(//button[@id='track-ctn-btn'])[1]"),             @FindBy(xpath = "//button[contains(@class, 'auto-quote-start-checkout-button') and not(contains(text(),'Bundle'))]"),     })
    this.startCheckoutButton = page.locator("xpath=//mat-card[contains(@class,'tui-quote-presentment-desktop')]//button[contains(@class,'tui-quote-presentment-button') or contains(@class,'tui-btn tui-btn-cta tui-stacking-bottom')]"); // @FindBy(xpath = "//mat-card[contains(@class,'tui-quote-presentment-desktop')]//button[contains(@class,'tui-quote-presentment-button') or contains(@class,'tui-btn tui-btn-cta tui-stacking-bottom')]"),             @FindBy(partialLinkText = CONTINUE_WITH_AUTO),             @FindBy(partialLinkText = CONTINUE_WITH_THIS_QUOTE),             @FindBy(xpath = "//button[contains(@class, 'auto-quote-start-checkout-button')]")     })
    this.bundleAndContinueButton = page.locator("[data-legacy-field=\"bundleAndContinueButton\"]"); // @FindBy(partialLinkText = BUNDLE_AND_SAVE)
    this.agreeAndSubmitButton = page.locator("xpath=//button[@class='tui-btn tui-btn-primary']"); // @FindBy(xpath = "//button[@class='tui-btn tui-btn-primary']")
    this.subTitleRegardingCurrentCoverage = page.locator("xpath=//p[./span]"); // @FindBy(xpath = "//p[./span]")
    this.subTitleRegardingCustomizing = page.locator("xpath=//p//span[@class='tui-body-bold']"); // @FindBy(xpath = "//p//span[@class='tui-body-bold']")
    this.vehicleCoverageSection = page.locator("xpath=//app-coverage[@class]"); // @FindBy(xpath = "//app-coverage[@class]")
    this.viewMonthlyOrFullPriceButton = page.locator("#priceAlternativeButton"); // @FindBy(id = "priceAlternativeButton")
    this.mobileviewMonthlyOrFullPriceButton = page.locator("xpath=//mat-card[contains(@class,'tui-quote-presentment-mobile')]//button[@id='priceAlternativeButton']"); // @FindBy(xpath = "//mat-card[contains(@class,'tui-quote-presentment-mobile')]//button[@id='priceAlternativeButton']")
    this.contactEsignDisclaimer = page.locator("xpath=//span[contains(@class,'contactEsignDisclaimer')]"); // @FindBy(xpath = "//span[contains(@class,'contactEsignDisclaimer')]")
    this.contactInfoDisclaimer = page.locator("xpath=//p[contains(@class,'tui-body-text tui-stacking-top-sm')]"); // @FindBy(xpath = "//p[contains(@class,'tui-body-text tui-stacking-top-sm')]")
    this.bundleContinueToPropertyReviewCoveragePageButton = page.locator("xpath=//button[contains(@class, 'auto-quote-bundle-continue-button') or contains(@class, 'auto-quote-bundle-button')]"); // @FindBy(xpath = "//button[contains(@class, 'auto-quote-bundle-continue-button') or contains(@class, 'auto-quote-bundle-button')]")
    this.lblMainPremiumAmount = page.locator("xpath=//div[contains(@class,'tui-quote-presentment-header')]/div[contains(text(),'starting at')]/following::tui-price//div[@class='lg-price-main']"); // @FindBy(xpath = "//div[contains(@class,'tui-quote-presentment-header')]/div[contains(text(),'starting at')]/following::tui-price//div[@class='lg-price-main']")
    this.btnEditLiabilityCoverage = page.locator("xpath=//button[@id='liabilitySection' or contains(@id,'vwo-liability-coverage-button-white-background')]"); // @FindBy(xpath = "//button[@id='liabilitySection' or contains(@id,'vwo-liability-coverage-button-white-background')]")
    this.btnEditSingleVehicleCoverage = page.locator("xpath=//button[@id='vehicle0Section']"); // @FindBy(xpath = "//button[@id='vehicle0Section']"),             @FindBy(xpath = "//button[@id='vwo-vehicle-coverage-button-0-white-background']")     })
    this.lblEditLiabilityCoverageHeader = page.locator("xpath=//app-edit-liability-coverage//h2"); // @FindBy(xpath = "//app-edit-liability-coverage//h2"),             @FindBy(xpath = "//p[normalize-space(text())='Liability coverage']")     })
    this.lblEditVehicleCoverageHeader = page.locator("xpath=//p[@aria-label='Vehicle Coverage dialog']"); // @FindBy(xpath = "//p[@aria-label='Vehicle Coverage dialog']")
    this.membershipFeePrice = page.locator("[data-legacy-field=\"membershipFeePrice\"]"); // @FindBy(xpath = MEMBERSHIP_PRICE_XPATH)
    this.liabilityCoverages = page.locator("xpath=//div[@class='col-4 tui-body ng-star-inserted'][2]"); // @FindBy(xpath = "//div[@class='col-4 tui-body ng-star-inserted'][2]")
    this.vehicleCoverages = page.locator("xpath=//div[@class='col-4 tui-body'][1]"); // @FindBy(xpath = "//div[@class='col-4 tui-body'][1]")
    this.liabilityLimits = page.locator("xpath=//div[@class='col-4 tui-body ng-star-inserted'][2]"); // @FindBy(xpath = "//div[@class='col-4 tui-body ng-star-inserted'][2]")
    this.vehicleLimits = page.locator("xpath=//div[@class='col-4 tui-body'][2]"); // @FindBy(xpath = "//div[@class='col-4 tui-body'][2]")
    this.liabilityPrices = page.locator("xpath=//div[@class='col-2 tui-body liability-price-column ng-star-inserted']"); // @FindBy(xpath = "//div[@class='col-2 tui-body liability-price-column ng-star-inserted']")
    this.vehiclePrices = page.locator("xpath=//div[@class='col-2 liability-price-column tui-body']"); // @FindBy(xpath = "//div[@class='col-2 liability-price-column tui-body']")
    this.vehicleReplacementPlusCoverage = page.locator("xpath=//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and contains(.,'Vehicle Replacement Plus')]/div[1]"); // @FindBy(xpath = "//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and contains(.,'Vehicle Replacement Plus')]/div[1]")
    this.vehicleReplacementPlusLimit = page.locator("xpath=//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and contains(.,'Vehicle Replacement Plus')]/div[2]"); // @FindBy(xpath = "//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and contains(.,'Vehicle Replacement Plus')]/div[2]")
    this.vehicleReplacementPlusPrice = page.locator("xpath=//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and contains(.,'Vehicle Replacement Plus')]/div[3]"); // @FindBy(xpath = "//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and contains(.,'Vehicle Replacement Plus')]/div[3]")
    this.adjustmentDialogCloseButton = page.locator("button[class='tui-btn tui-btn-primary tui-button-text bw-info-dialog__action-buttons']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary tui-button-text bw-info-dialog__action-buttons']")
    this.priceTooHighTitles = page.locator("xpath=//p[contains(@class,'price-to-high-text')]"); // @FindBy(xpath = "//p[contains(@class,'price-to-high-text')]")
    this.priceTooHighDescriptions = page.locator("xpath=//p[contains(@class,'price-to-high-text')]/following-sibling::p"); // @FindBy(xpath = "//p[contains(@class,'price-to-high-text')]/following-sibling::p")
    this.priceTooHighPhoneNumbers = page.locator("xpath=//p[contains(@class,'price-to-high-text')]/following-sibling::a"); // @FindBy(xpath = "//p[contains(@class,'price-to-high-text')]/following-sibling::a")
    this.quoteUpdateDialogCtaButton = page.locator("button[class='tui-btn tui-btn-primary tui-button-text content-info-dialog__action-buttons']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary tui-button-text content-info-dialog__action-buttons']")
    this.monthlyAutoPayPriceInBundleQuoteLedger = page.locator("xpath=//app-bundle-presentment/div/table/tbody/tr[1]/td[3]"); // @FindBy(xpath = "//app-bundle-presentment/div/table/tbody/tr[1]/td[3]")
    this.payInFullPriceInBundleQuoteLedger = page.locator("xpath=//app-bundle-presentment/div/table/tbody/tr[1]/td[4]"); // @FindBy(xpath = "//app-bundle-presentment/div/table/tbody/tr[1]/td[4]")
    this.pipSideSheetCoverageLabel = page.locator("xpath=//mat-slide-toggle[@id='Liability__35090__toggle' or @id='Liability__PIP__toggle']/..//h3[@class='tui-input-text-2 coverage-card-label ng-star-inserted']"); // @FindBy(xpath = "//mat-slide-toggle[@id='Liability__35090__toggle' or @id='Liability__PIP__toggle']/..//h3[@class='tui-input-text-2 coverage-card-label ng-star-inserted']")
    this.pipSideSheetCoverageDescription = page.locator("xpath=//mat-slide-toggle[@id='Liability__35090__toggle' or @id='Liability__PIP__toggle']/../../..//div[@class='col tui-input-text auto-quote-coverage__description mt-1 ng-star-inserted']"); // @FindBy(xpath = "//mat-slide-toggle[@id='Liability__35090__toggle' or @id='Liability__PIP__toggle']/../../..//div[@class='col tui-input-text auto-quote-coverage__description mt-1 ng-star-inserted']")
    this.pb3Question = page.locator("p[class='pb-3 questionText']"); // @FindBy(css = "p[class='pb-3 questionText']")
    this.pipDeductibleYesButton = page.locator("#SHOW_YES-button"); // @FindBy(id = "SHOW_YES-button")
    this.pipDeductibleNoButton = page.locator("#SHOW_NO-button"); // @FindBy(id = "SHOW_NO-button")
    this.pipDeductibleButtonsHeader = page.locator("p[class='pt-3']"); // @FindBy(css = "p[class='pt-3']")
    this.pipRadioButtons = page.locator("xpath=//mat-radio-group[@id='Liability__35090__radio' or @id='Liability__PIP__radio']//mat-radio-button//label"); // @FindBy(xpath = "//mat-radio-group[@id='Liability__35090__radio' or @id='Liability__PIP__radio']//mat-radio-button//label")
    this.pipCheckedRadioButton = page.locator("[data-legacy-field=\"pipCheckedRadioButton\"]"); // @FindBy(xpath = CHECKED_PIP_RADIO_BUTTON)
    this.zeroDeductibleAppliesElement = page.locator("p[class='deductibleMsg ng-star-inserted']"); // @FindBy(css = "p[class='deductibleMsg ng-star-inserted']")
    this.emailInputFieldMediaAlpha = page.locator("input[formcontrolname='emailAddress']"); // @FindBy(css = "input[formcontrolname='emailAddress']")
    this.phoneInputFieldMediaAlpha = page.locator("input[formcontrolname='phoneNumber']"); // @FindBy(css = "input[formcontrolname='phoneNumber']")
    this.medialAlphaPrefilledAddress = page.locator("div[class='personalInfo-address']"); // @FindBy(css = "div[class='personalInfo-address']")
    this.comboCoverageTooltipHeader = page.locator("xpath=//div[contains(@class,'combo-coverage')]//div[@class='tooltip-content']//div"); // @FindBy(xpath = "//div[contains(@class,'combo-coverage')]//div[@class='tooltip-content']//div")
    this.comboCoverageTooltipLightBulb = page.locator("xpath=//div[contains(@class,'lightbulb-container')]"); // @FindBy(xpath = "//div[contains(@class,'lightbulb-container')]")
    this.comboCoverageTooltipContent = page.locator("xpath=//div[contains(@class,'combo-coverage')]//div[@class='tooltip-content']//span"); // @FindBy(xpath = "//div[contains(@class,'combo-coverage')]//div[@class='tooltip-content']//span")
    this.additionalCoverageToggles = page.locator("[data-legacy-field=\"additionalCoverageToggles\"]"); // @FindBy(xpath = ADDITIONAL_COVERAGE_TOGGLE_XPATH)
    this.continueWithSignalDiscountDialog = page.locator("xpath=//div[contains(@class, 'signal-confirmation-container')]"); // @FindBy(xpath = "//div[contains(@class, 'signal-confirmation-container')]")
    this.yesContinueWithSignalDiscount = page.locator("#signalABTestYesBtn"); // @FindBy(id = "signalABTestYesBtn")
    this.dontContinueWithSignalDiscount = page.locator("#signalABTestNoBtn"); // @FindBy(id = "signalABTestNoBtn")
    this.permissiveUserLimitUpdatedValue = page.locator("xpath=//div[text()='Permissive User Limit of Liability']/following::div"); // @FindBy(xpath = "//div[text()='Permissive User Limit of Liability']/following::div")
    this.resetOriginalQuoteButton = page.locator("xpath=//div[contains(@class,'reset-org-quote')]"); // @FindBy(xpath = "//div[contains(@class,'reset-org-quote')]")
    this.sourceCodePopUpHeader = page.locator("xpath=//app-sweep-stakes-popup//h4"); // @FindBy(xpath = "//app-sweep-stakes-popup//h4")
    this.sourceCodePopUpContentParagraph1 = page.locator("xpath=//app-sweep-stakes-popup//mat-dialog-content/p[1]"); // @FindBy(xpath = "//app-sweep-stakes-popup//mat-dialog-content/p[1]")
    this.sourceCodePopUpContentParagraph2 = page.locator("xpath=//app-sweep-stakes-popup//mat-dialog-content/p[2]"); // @FindBy(xpath = "//app-sweep-stakes-popup//mat-dialog-content/p[2]")
    this.sourceCodePopUpOkButton = page.locator("xpath=//app-sweep-stakes-popup//button"); // @FindBy(xpath = "//app-sweep-stakes-popup//button")
    this.liabilityCoveragePrice = page.locator("xpath=//app-coverage[not(@class)]//div[@class='row auto-quote-liability-coverages-item-row']//div[contains(@class,'liability-price-column')]"); // @FindBy(xpath = "//app-coverage[not(@class)]//div[@class='row auto-quote-liability-coverages-item-row']//div[contains(@class,'liability-price-column')]")
    this.liabilityCoveragePrice1 = page.locator("xpath=//app-coverage[not(@class)]//span[contains(@class,'coverage-total-amount')]"); // @FindBy(xpath = "//app-coverage[not(@class)]//span[contains(@class,'coverage-total-amount')]")
    this.vehicleCoveragePrice = page.locator("xpath=//app-coverage[(@class)]//div[@class='row auto-quote-liability-coverages-item-row']//div[contains(@class,'liability-price-column')]"); // @FindBy(xpath = "//app-coverage[(@class)]//div[@class='row auto-quote-liability-coverages-item-row']//div[contains(@class,'liability-price-column')]")
    this.vehicleCoveragePrice1 = page.locator("xpath=//app-coverage[(@class)]//span[contains(@class,'coverage-total-amount')]"); // @FindBy(xpath = "//app-coverage[(@class)]//span[contains(@class,'coverage-total-amount')]")
    this.payRollBanner = page.locator("xpath=//div[contains(@class,'banner-content')]"); // @FindBy(xpath = "//div[contains(@class,'banner-content')]")
    this.payRollContactButton = page.locator("xpath=//div[contains(@class,'tui-quote-presentment-content')]/a"); // @FindBy(xpath = "//div[contains(@class,'tui-quote-presentment-content')]/a")
    this.payRollBannerContent = page.locator("xpath=//div[contains(@class,'banner-content')]//p[2]"); // @FindBy(xpath =  "//div[contains(@class,'banner-content')]//p[2]")
    this.bwPromoCard = page.locator("div.bw-promo-card"); // @FindBy(css = "div.bw-promo-card")
    this.bwPromoLogo = page.locator("div.bw-promo-logo img[alt='Bristol West logo']"); // @FindBy(css = "div.bw-promo-logo img[alt='Bristol West logo']")
    this.bwPromoInfoIcon = page.locator("mat-icon.bw-promo-info-icon"); // @FindBy(css = "mat-icon.bw-promo-info-icon")
    this.bwPromoInfoIconContent = page.locator("xpath=//div[contains(@class,'bw-custom-tooltip')]"); // @FindBy(xpath = "//div[contains(@class,'bw-custom-tooltip')]")
    this.bwPromoHeader = page.locator("h2.bw-promo-header"); // @FindBy(css = "h2.bw-promo-header")
    this.bwPromoContent = page.locator("p.bw-promo-content"); // @FindBy(css = "p.bw-promo-content")
    this.bwPromoPhoneLink = page.locator("p.bw-promo-content a.textlink-color"); // @FindBy(css = "p.bw-promo-content a.textlink-color")
    this.marinePopUp = page.locator("xpath=//mat-dialog-container[@id='sweepStakesPopupDialog']/div[contains(@class,'mdc-dialog__container')]"); // @FindBy(xpath = "//mat-dialog-container[@id='sweepStakesPopupDialog']/div[contains(@class,'mdc-dialog__container')]")
    this.marinePopUpHeader = page.locator("xpath=//mat-dialog-container[@id='sweepStakesPopupDialog']//app-sweep-stakes-popup//h4"); // @FindBy(xpath = "//mat-dialog-container[@id='sweepStakesPopupDialog']//app-sweep-stakes-popup//h4")
    this.marinePopUpContent = page.locator("xpath=//mat-dialog-container[@id='sweepStakesPopupDialog']//app-sweep-stakes-popup//mat-dialog-content//p"); // @FindBy(xpath = "//mat-dialog-container[@id='sweepStakesPopupDialog']//app-sweep-stakes-popup//mat-dialog-content//p")
    this.marinePopUpOkButton = page.locator("xpath=//mat-dialog-container[@id='sweepStakesPopupDialog']/div[contains(@class,'mdc-dialog__container')]//button"); // @FindBy(xpath = "//mat-dialog-container[@id='sweepStakesPopupDialog']/div[contains(@class,'mdc-dialog__container')]//button")
  }
}
