// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.AgentDetails. */
export class AgentDetails extends CoreBasePage {
  public readonly quoteNumberSection: Locator;
  public readonly saveQuoteLink: Locator;
  public readonly yourAgentLabel: Locator;
  public readonly agentName: Locator;
  public readonly phoneIcon: Locator;
  public readonly phoneNumber: Locator;
  public readonly emailIcon: Locator;
  public readonly agentEmail: Locator;
  public readonly addressIcon: Locator;
  public readonly agentAddress: Locator;
  public readonly contactMeButton: Locator;
  public readonly contactFarmersRepresentativeLink: Locator;
  public readonly sidePanelTitle: Locator;
  public readonly sidePanelCloseButton: Locator;
  public readonly sidePanelYourAgentLabel: Locator;
  public readonly sidePanelAgentName: Locator;
  public readonly sidePanelAgentAddress: Locator;
  public readonly sidePanelAgentEmail: Locator;
  public readonly sidePanelAgentPhoneNumber: Locator;
  public readonly sidePanelRequiredFieldLabel: Locator;
  public readonly sidePanelReasonForContactLabel: Locator;
  public readonly sidePanelReasonForContactTextArea: Locator;
  public readonly remainingCharacter: Locator;
  public readonly sidePanelReasonForContactErrorMessageLabel: Locator;
  public readonly sidePanelContactInfoLabel: Locator;
  public readonly sidePanelCustomerFirstName: Locator;
  public readonly sidePanelCustomerLastName: Locator;
  public readonly sidePanelPreferredContactLabel: Locator;
  public readonly sidePanelCustomerEmailEntryField: Locator;
  public readonly sidePanelCustomerEmailEntryFieldErrorMessageLabel: Locator;
  public readonly sidePanelCustomerPhoneNumberEntryField: Locator;
  public readonly sidePanelCustomerPhoneNumberEntryFieldErrorMessageLabel: Locator;
  public readonly sidePanelExistingCustomerLabel: Locator;
  public readonly sidePanelYesExistingCustomerRadioButton: Locator;
  public readonly sidePanelNoExistingCustomerRadioButton: Locator;
  public readonly sidePanelExistingCustomerErrorMessageLabel: Locator;
  public readonly sidePanelQuoteNumber: Locator;
  public readonly sidePanelScheduleAnAppointmentLabel: Locator;
  public readonly sidePanelScheduleAnAppointmentText: Locator;
  public readonly sidePanelPreferredDateAndTimeLabel: Locator;
  public readonly sidePanelChooseADateEntryField: Locator;
  public readonly sidePanelChooseADateEntryFieldErrorLabel: Locator;
  public readonly sidePanelTimeSlotLabel: Locator;
  public readonly sidePanelMorningCheckbox: Locator;
  public readonly sidePanelMorningLabel: Locator;
  public readonly sidePanelAfternoonCheckbox: Locator;
  public readonly sidePanelAfternoonLabel: Locator;
  public readonly sidePanelEveningCheckbox: Locator;
  public readonly sidePanelEveningLabel: Locator;
  public readonly sidePanelTimeSlotSelectionErrorLabel: Locator;
  public readonly sidePanelDisclaimerText: Locator;
  public readonly sidePanelErrorsFoundInPageLabel: Locator;
  public readonly sidePanelPersonalInformationLink: Locator;
  public readonly sidePanelAgreeAndSubmitButton: Locator;
  public readonly sidePanelRequestSubmittedLabel: Locator;
  public readonly sidePanelAppointmentRequestSubmittedLabel: Locator;
  public readonly sidePanelThanksForSubmittingRequestLabel: Locator;
  public readonly sidePanelAppointmentRequestSubmittedAgentNameLabel: Locator;
  public readonly sidePanelAppointmentRequestSubmittedDateLabel: Locator;
  public readonly sidePanelAppointmentRequestSubmittedTimeslotLabels: Locator;
  public readonly sidePanelAppointmentRequestSubmittedDoneButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.quoteNumberSection = page.locator("xpath=//div[contains(@class, 'auto-agent-details__save-quote')]"); // @FindBy(xpath = "//div[contains(@class, 'auto-agent-details__save-quote')]")
    this.saveQuoteLink = page.locator("xpath=//button[contains(@class, 'auto-agent-details__save-link')]"); // @FindBy(xpath = "//button[contains(@class, 'auto-agent-details__save-link')]")
    this.yourAgentLabel = page.locator("[data-legacy-field=\"yourAgentLabel\"]"); // @FindBy(xpath = AGENT_INFO_SECTION_XPATH + "//div[@class='tui-caption']")
    this.agentName = page.locator("[data-legacy-field=\"agentName\"]"); // @FindBy(xpath = AGENT_NAME_XPATH)
    this.phoneIcon = page.locator("xpath=//div[contains(@class,'agent-details-container tui-stacking-top-md')][1]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'agent-details-container tui-stacking-top-md')][1]//mat-icon")
    this.phoneNumber = page.locator("xpath=//div[contains(@class,'agent-details-container tui-stacking-top-md')][1]//a[contains(@class,'footer')]"); // @FindBy(xpath = "//div[contains(@class,'agent-details-container tui-stacking-top-md')][1]//a[contains(@class,'footer')]")
    this.emailIcon = page.locator("xpath=//div[contains(@class,'agent-details-container tui-stacking-top-md')][2]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'agent-details-container tui-stacking-top-md')][2]//mat-icon")
    this.agentEmail = page.locator("xpath=//div[contains(@class,'agent-details-container tui-stacking-top-md')][2]//a[contains(@class,'footer')]"); // @FindBy(xpath = "//div[contains(@class,'agent-details-container tui-stacking-top-md')][2]//a[contains(@class,'footer')]")
    this.addressIcon = page.locator("xpath=//div[contains(@class,'agent-details-container tui-stacking-top-md')][3]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'agent-details-container tui-stacking-top-md')][3]//mat-icon")
    this.agentAddress = page.locator("xpath=//div[contains(@class,'agent-details-container tui-stacking-top-md')][3]//a[contains(@class,'footer')]"); // @FindBy(xpath = "//div[contains(@class,'agent-details-container tui-stacking-top-md')][3]//a[contains(@class,'footer')]")
    this.contactMeButton = page.locator("[data-legacy-field=\"contactMeButton\"]"); // @FindBy(xpath = AGENT_INFO_SECTION_XPATH + "//button")
    this.contactFarmersRepresentativeLink = page.locator("[data-legacy-field=\"contactFarmersRepresentativeLink\"]"); // @FindBy(xpath = AGENT_INFO_SECTION_XPATH + "//a[starts-with(@aria-label,'" + CONTACT_FARMERS_REPRESENTATIVE + "')]")
    this.sidePanelTitle = page.locator("#addDriverHeading"); // @FindBy(id = "addDriverHeading")
    this.sidePanelCloseButton = page.locator("xpath=//app-contact-agent//mat-icon"); // @FindBy(xpath = "//app-contact-agent//mat-icon")
    this.sidePanelYourAgentLabel = page.locator("xpath=//div[@class='auto-schedule-appointment-agent-text']/p[contains(@class,'tui-caption-text')]"); // @FindBy(xpath = "//div[@class='auto-schedule-appointment-agent-text']/p[contains(@class,'tui-caption-text')]")
    this.sidePanelAgentName = page.locator("xpath=//div[contains(@class, 'auto-contact-agent__fields-section')]//h5"); // @FindBy(xpath = "//div[contains(@class, 'auto-contact-agent__fields-section')]//h5")
    this.sidePanelAgentAddress = page.locator("xpath=//p/a[@class='auto-contact-agent-anchor']"); // @FindBy(xpath = "//p/a[@class='auto-contact-agent-anchor']")
    this.sidePanelAgentEmail = page.locator("xpath=//div[@class='auto-schedule-appointment-agent-text']/a[contains(@class, 'auto-contact-agent-anchor')]"); // @FindBy(xpath = "//div[@class='auto-schedule-appointment-agent-text']/a[contains(@class, 'auto-contact-agent-anchor')]")
    this.sidePanelAgentPhoneNumber = page.locator("xpath=//p[@class='tui-small-text']/a[contains(@class,'auto-contact-agent-anchor')]"); // @FindBy(xpath = "//p[@class='tui-small-text']/a[contains(@class,'auto-contact-agent-anchor')]")
    this.sidePanelRequiredFieldLabel = page.locator(".required-caption"); // @FindBy(className = "required-caption")
    this.sidePanelReasonForContactLabel = page.locator("xpath=//div[@class='auto-contact-agent__fields-section']/div[@class='auto-contact-agent-subheading__section']/label[@class='tui-field-label-text']"); // @FindBy(xpath = "//div[@class='auto-contact-agent__fields-section']/div[@class='auto-contact-agent-subheading__section']/label[@class='tui-field-label-text']")
    this.sidePanelReasonForContactTextArea = page.locator("xpath=//textarea"); // @FindBy(xpath = "//textarea")
    this.remainingCharacter = page.locator("span[class='tui-caption ng-star-inserted']"); // @FindBy(css = "span[class='tui-caption ng-star-inserted']")
    this.sidePanelReasonForContactErrorMessageLabel = page.locator("xpath=//div[@id='formField_reasonForContact']//mat-error"); // @FindBy(xpath = "//div[@id='formField_reasonForContact']//mat-error")
    this.sidePanelContactInfoLabel = page.locator("#contact-info"); // @FindBy(id = "contact-info")
    this.sidePanelCustomerFirstName = page.locator("xpath=//div[@id='formField_firstName']//input"); // @FindBy(xpath = "//div[@id='formField_firstName']//input")
    this.sidePanelCustomerLastName = page.locator("xpath=//mat-form-field[@id='auto-contact-agent-lname__input-field']//input"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-agent-lname__input-field']//input")
    this.sidePanelPreferredContactLabel = page.locator("#preferred-contact"); // @FindBy(id = "preferred-contact")
    this.sidePanelCustomerEmailEntryField = page.locator("xpath=//mat-form-field[@id='auto-contact-agent-email__input-field']//input"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-agent-email__input-field']//input")
    this.sidePanelCustomerEmailEntryFieldErrorMessageLabel = page.locator("xpath=//mat-form-field[@id='auto-contact-agent-email__input-field']//mat-error"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-agent-email__input-field']//mat-error")
    this.sidePanelCustomerPhoneNumberEntryField = page.locator("xpath=//mat-form-field[@id='auto-contact-agent-phonenumber__input-field']//input"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-agent-phonenumber__input-field']//input")
    this.sidePanelCustomerPhoneNumberEntryFieldErrorMessageLabel = page.locator("xpath=//mat-form-field[@id='auto-contact-agent-phonenumber__input-field']//mat-error"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-agent-phonenumber__input-field']//mat-error")
    this.sidePanelExistingCustomerLabel = page.locator("#existing-customerlabel"); // @FindBy(id = "existing-customerlabel")
    this.sidePanelYesExistingCustomerRadioButton = page.locator("[data-legacy-field=\"sidePanelYesExistingCustomerRadioButton\"]"); // @FindBy(xpath = EXISTING_CUSTOMER_RADIOBUTTON_XPATH)
    this.sidePanelNoExistingCustomerRadioButton = page.locator("[data-legacy-field=\"sidePanelNoExistingCustomerRadioButton\"]"); // @FindBy(xpath = NOT_EXISTING_CUSTOMER_RADIOBUTTON_XPATH)
    this.sidePanelExistingCustomerErrorMessageLabel = page.locator("xpath=//div[@class='auto-contact-agent-subheading__section']//mat-error"); // @FindBy(xpath = "//div[@class='auto-contact-agent-subheading__section']//mat-error")
    this.sidePanelQuoteNumber = page.locator("xpath=//mat-form-field[@id='auto-contact-agent-quotenumber__input-field']//input"); // @FindBy(xpath = "//mat-form-field[@id='auto-contact-agent-quotenumber__input-field']//input")
    this.sidePanelScheduleAnAppointmentLabel = page.locator("#schedule-agent-appointment"); // @FindBy(id = "schedule-agent-appointment")
    this.sidePanelScheduleAnAppointmentText = page.locator("#contact-agent-text"); // @FindBy(id = "contact-agent-text")
    this.sidePanelPreferredDateAndTimeLabel = page.locator("xpath=//div[@class ='auto-contact-agent-preferred-date__section']/label"); // @FindBy(xpath = "//div[@class ='auto-contact-agent-preferred-date__section']/label")
    this.sidePanelChooseADateEntryField = page.locator("xpath=//input[@formcontrolname='preferredDate']"); // @FindBy(xpath = "//input[@formcontrolname='preferredDate']")
    this.sidePanelChooseADateEntryFieldErrorLabel = page.locator("xpath=//div[@aria-labelledby='schedule-agent-appointment']//mat-error"); // @FindBy(xpath = "//div[@aria-labelledby='schedule-agent-appointment']//mat-error")
    this.sidePanelTimeSlotLabel = page.locator("#timeslot-checkox"); // @FindBy(id = "timeslot-checkox")
    this.sidePanelMorningCheckbox = page.locator("[data-legacy-field=\"sidePanelMorningCheckbox\"]"); // @FindBy(xpath = FIRST_TIMESLOT_XPATH + CHECKBOX_XPATH)
    this.sidePanelMorningLabel = page.locator("[data-legacy-field=\"sidePanelMorningLabel\"]"); // @FindBy(xpath = FIRST_TIMESLOT_XPATH + LABEL_XPATH)
    this.sidePanelAfternoonCheckbox = page.locator("[data-legacy-field=\"sidePanelAfternoonCheckbox\"]"); // @FindBy(xpath = SECOND_TIMESLOT_XPATH + CHECKBOX_XPATH)
    this.sidePanelAfternoonLabel = page.locator("[data-legacy-field=\"sidePanelAfternoonLabel\"]"); // @FindBy(xpath = SECOND_TIMESLOT_XPATH + LABEL_XPATH)
    this.sidePanelEveningCheckbox = page.locator("[data-legacy-field=\"sidePanelEveningCheckbox\"]"); // @FindBy(xpath = THIRD_TIMESLOT_XPATH + CHECKBOX_XPATH)
    this.sidePanelEveningLabel = page.locator("[data-legacy-field=\"sidePanelEveningLabel\"]"); // @FindBy(xpath = THIRD_TIMESLOT_XPATH + LABEL_XPATH)
    this.sidePanelTimeSlotSelectionErrorLabel = page.locator("xpath=//div[@aria-labelledby='timeslot-checkox']//mat-error"); // @FindBy(xpath = "//div[@aria-labelledby='timeslot-checkox']//mat-error")
    this.sidePanelDisclaimerText = page.locator("#disclaimerText"); // @FindBy(id = "disclaimerText")
    this.sidePanelErrorsFoundInPageLabel = page.locator("xpath=//p[contains(@class, 'auto-contact-agent-multiple-fields-missing')]"); // @FindBy(xpath = "//p[contains(@class, 'auto-contact-agent-multiple-fields-missing')]")
    this.sidePanelPersonalInformationLink = page.locator("xpath=//a[contains(@aria-label, 'Personal information')]"); // @FindBy(xpath = "//a[contains(@aria-label, 'Personal information')]")
    this.sidePanelAgreeAndSubmitButton = page.locator("[data-legacy-field=\"sidePanelAgreeAndSubmitButton\"]"); // @FindBy(xpath = SIDE_PANEL_AGREE_SUBMIT_BUTTON_XPATH)
    this.sidePanelRequestSubmittedLabel = page.locator("#requestSubmittedHeading"); // @FindBy(id = "requestSubmittedHeading")
    this.sidePanelAppointmentRequestSubmittedLabel = page.locator(".auto-schedule-appointment-heading"); // @FindBy(className = "auto-schedule-appointment-heading")
    this.sidePanelThanksForSubmittingRequestLabel = page.locator("#confirmationMessage"); // @FindBy(id = "confirmationMessage")
    this.sidePanelAppointmentRequestSubmittedAgentNameLabel = page.locator("xpath=//div[@class='auto-contact-agent-confirmation-schedule__section']//label"); // @FindBy(xpath = "//div[@class='auto-contact-agent-confirmation-schedule__section']//label")
    this.sidePanelAppointmentRequestSubmittedDateLabel = page.locator("xpath=//div[@class='auto-contact-agent-confirmation-date__section']//label"); // @FindBy(xpath = "//div[@class='auto-contact-agent-confirmation-date__section']//label")
    this.sidePanelAppointmentRequestSubmittedTimeslotLabels = page.locator("[data-legacy-field=\"sidePanelAppointmentRequestSubmittedTimeslotLabels\"]"); // @FindBy(xpath = SIDE_PANEL_SUBMITTED_TIMESLOT_LABEL_XPATH)
    this.sidePanelAppointmentRequestSubmittedDoneButton = page.locator(".auto-contact-agent-confirmation-button"); // @FindBy(className = "auto-contact-agent-confirmation-button")
  }
}
