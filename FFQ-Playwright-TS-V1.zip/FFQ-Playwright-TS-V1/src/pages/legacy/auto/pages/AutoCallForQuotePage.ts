// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.AutoCallForQuotePage. */
export class AutoCallForQuotePage extends CoreBasePage {
  public readonly callForAQuotePageTitle: Locator;
  public readonly letsGetStartedText: Locator;
  public readonly pageDescription: Locator;
  public readonly mobileCallNowButton: Locator;
  public readonly desktopCallNowButton: Locator;
  public readonly quickAndEasy: Locator;
  public readonly farmersImage: Locator;
  public readonly tileSectionImages: Locator;
  public readonly tileSectionTexts: Locator;
  public readonly noteSectionText: Locator;
  public readonly savingPercentageNote: Locator;
  public readonly disclaimers: Locator;

  public constructor(page: Page) {
    super(page);
    this.callForAQuotePageTitle = page.locator("xpath=//span[@class='h1-alt1']"); // @FindBy(xpath = "//span[@class='h1-alt1']"),             @FindBy(xpath = "//span[@class='h1-alt2']"),             @FindBy(css = "h1[id='main-content1']")     })
    this.letsGetStartedText = page.locator("xpath=//span[contains(.,'get started')]"); // @FindBy(xpath = "//span[contains(.,'get started')]")
    this.pageDescription = page.locator("span[class='p-style']"); // @FindBy(css = "span[class='p-style']"),             @FindBy(xpath = "//div[@class='productgrid__heading rich-text']//p"),             @FindBy(css = "p[class='pb-3']")     })
    this.mobileCallNowButton = page.locator("xpath=//a[@data-gtm='Check_ call_colp' and contains(@class,'mobile mobile button-cta')]"); // @FindBy(xpath = "//a[@data-gtm='Check_ call_colp' and contains(@class,'mobile mobile button-cta')]")
    this.desktopCallNowButton = page.locator("xpath=//a[@data-gtm='Check_ call_colp' and contains(@class,'desktop desktop button-cta')]"); // @FindBy(xpath = "//a[@data-gtm='Check_ call_colp' and contains(@class,'desktop desktop button-cta')]")
    this.quickAndEasy = page.locator("xpath=//span[@class='font-blue']//span[@class='h4-alt1']"); // @FindBy(xpath = "//span[@class='font-blue']//span[@class='h4-alt1']")
    this.farmersImage = page.locator("xpath=//img[contains(@src,'auto-landing')]"); // @FindBy(xpath = "//img[contains(@src,'auto-landing')]")
    this.tileSectionImages = page.locator("xpath=//div[contains(@class,'tile tile--one-col col-12 mt-3 mb-1')]//img"); // @FindBy(xpath = "//div[contains(@class,'tile tile--one-col col-12 mt-3 mb-1')]//img")
    this.tileSectionTexts = page.locator("xpath=//div[contains(@class,'tile tile--one-col col-12 mt-3 mb-1')]//section"); // @FindBy(xpath = "//div[contains(@class,'tile tile--one-col col-12 mt-3 mb-1')]//section")
    this.noteSectionText = page.locator("xpath=//p[contains(.,'NOTE')]"); // @FindBy(xpath = "//p[contains(.,'NOTE')]")
    this.savingPercentageNote = page.locator("xpath=//span[contains(.,'*')]"); // @FindBy(xpath = "//span[contains(.,'*')]")
    this.disclaimers = page.locator("xpath=//div[@class='footernav__notes-section row pt-3 pb-5']"); // @FindBy(xpath = "//div[@class='footernav__notes-section row pt-3 pb-5']")
  }
}
