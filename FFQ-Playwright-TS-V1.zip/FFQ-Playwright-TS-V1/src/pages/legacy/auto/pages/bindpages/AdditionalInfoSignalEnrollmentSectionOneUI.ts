// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.bindpages.AdditionalInfoSignalEnrollmentSectionOneUI. */
export class AdditionalInfoSignalEnrollmentSectionOneUI extends CoreBasePage {
  public readonly signalEnrollmentHeader: Locator;
  public readonly signalDiscountAllEligibleDrivers: Locator;
  public readonly downloadTheSignalApp: Locator;
  public readonly signalEnrollmentCheckbox: Locator;
  public readonly byClickingContinueToPaymentText: Locator;
  public readonly signalEnrollmentConsentPoint1: Locator;
  public readonly signalEnrollmentConsentPoint2: Locator;
  public readonly signalEnrollmentConsentPoint3: Locator;
  public readonly signalEnrollmentConsentPoint4: Locator;
  public readonly readAgreementAndSelectCheckboxError: Locator;
  public readonly termsOfUseAnchorTagElement: Locator;
  public readonly changeYourMindQuestion: Locator;
  public readonly cancelSignalEnrollmentLink: Locator;
  public readonly cancelSignalEnrollmentQuestion: Locator;
  public readonly signalCancelDialogContentDescripton: Locator;
  public readonly cancelEnrollmentButton: Locator;
  public readonly keepSignalLink: Locator;
  public readonly cancelSignalModalPopUp: Locator;
  public readonly mobileNumberInputBoxElements: Locator;
  public readonly emptyMobileNumberInputBoxElements: Locator;
  public readonly listOfMissingMobileNumberInputBoxElements: Locator;
  public readonly emailInputBoxElements: Locator;
  public readonly mobileNumberPlaceHolderText: Locator;
  public readonly emailPlaceHolderText: Locator;
  public readonly greenCheckMarkMobileNumberInputTextBox: Locator;
  public readonly pleaseEnterYourPhoneNumberError: Locator;
  public readonly pleaseEnterValidPhoneNumberError: Locator;
  public readonly phoneNumberShouldBeDistinct: Locator;
  public readonly optionEmailIDHitWebElements: Locator;
  public readonly invalidEmailIdError: Locator;
  public readonly distinctEmailIdError: Locator;
  public readonly enrollThisDriverText: Locator;
  public readonly enrollThisDriverSlider: Locator;
  public readonly enrollThisDriverSliderInputTags: Locator;
  public readonly youthfulDriverDiscountMessage: Locator;
  public readonly continueToPaymentButton: Locator;
  public readonly safeDrivingLeadsToBiggerRewardsAtRenewalText: Locator;
  public readonly fillOutInfoTextElement: Locator;

  public constructor(page: Page) {
    super(page);
    this.signalEnrollmentHeader = page.locator("xpath=//div[contains(@class,'additional-info-signal-enrollment')]//h2"); // @FindBy(xpath = "//div[contains(@class,'additional-info-signal-enrollment')]//h2")
    this.signalDiscountAllEligibleDrivers = page.locator("xpath=//p[contains(@class, 'tui-body-text-1 ng-star-inserted')]"); // @FindBy(xpath = "//p[contains(@class, 'tui-body-text-1 ng-star-inserted')]")
    this.downloadTheSignalApp = page.locator("#signalText2"); // @FindBy(id = "signalText2")
    this.signalEnrollmentCheckbox = page.locator("xpath=//mat-checkbox[@formcontrolname='signalAgreement']"); // @FindBy(xpath = "//mat-checkbox[@formcontrolname='signalAgreement']")
    this.byClickingContinueToPaymentText = page.locator("xpath=//span[contains(text(), 'I confirm that I:')]"); // @FindBy(xpath = "//span[contains(text(), 'I confirm that I:')]")
    this.signalEnrollmentConsentPoint1 = page.locator("xpath=//li[contains(text(), '"); // @FindBy(xpath = "//li[contains(text(), '" + SIGNAL_ENROLLMENT_CONSENT_POINT1 + "')]")
    this.signalEnrollmentConsentPoint2 = page.locator("xpath=//li[contains(text(), '"); // @FindBy(xpath = "//li[contains(text(), '" + SIGNAL_ENROLLMENT_CONSENT_POINT2 + "')]")
    this.signalEnrollmentConsentPoint3 = page.locator("xpath=//li[contains(text(), '"); // @FindBy(xpath = "//li[contains(text(), '" + SIGNAL_ENROLLMENT_CONSENT_POINT3 + "')]")
    this.signalEnrollmentConsentPoint4 = page.locator("xpath=//li[contains(text(), '"); // @FindBy(xpath = "//li[contains(text(), '" + SIGNAL_ENROLLMENT_CONSENT_POINT4  + "')]")
    this.readAgreementAndSelectCheckboxError = page.locator("xpath=//mat-error[contains(text(), '"); // @FindBy(xpath = "//mat-error[contains(text(), '" +READ_AGREEMENT_SELECT_CHECKBOX_ERROR + "')]")
    this.termsOfUseAnchorTagElement = page.locator("xpath=//a[contains(text(), 'Terms of use')]"); // @FindBy(xpath = "//a[contains(text(), 'Terms of use')]")
    this.changeYourMindQuestion = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'"+CHANGE_YOUR_MIND_QUESTION+"')]")
    this.cancelSignalEnrollmentLink = page.locator("xpath=//a[contains(text(),'"); // @FindBy(xpath = "//a[contains(text(),'"+CANCEL_SIGNAL_ENROLLMENT+"')]")
    this.cancelSignalEnrollmentQuestion = page.locator("xpath=//mat-dialog-container//span"); // @FindBy(xpath = "//mat-dialog-container//span")
    this.signalCancelDialogContentDescripton = page.locator("xpath=//mat-dialog-content//p"); // @FindBy(xpath = "//mat-dialog-content//p")
    this.cancelEnrollmentButton = page.locator("xpath=//button[contains(text(),'"); // @FindBy(xpath = "//button[contains(text(),'"+CANCEL_ENROLLMENT_BUTTON+"')]")
    this.keepSignalLink = page.locator("xpath=//a[contains(text(),'"); // @FindBy(xpath = "//a[contains(text(),'"+KEEP_SIGNAL_LINK+"')]")
    this.cancelSignalModalPopUp = page.locator("xpath=mat-dialog-container[@aria-labelledby=\"addEditSignal\"]"); // @FindBy(xpath = "mat-dialog-container[@aria-labelledby=\"addEditSignal\"]")
    this.mobileNumberInputBoxElements = page.locator("[data-legacy-field=\"mobileNumberInputBoxElements\"]"); // @FindBy(xpath = PHONE_NUMBER_TEXT_FIELD_XPATH)
    this.emptyMobileNumberInputBoxElements = page.locator("xpath=//input[@formcontrolname='phoneNumber' and contains(@class,'ng-invalid')]"); // @FindBy(xpath = "//input[@formcontrolname='phoneNumber' and contains(@class,'ng-invalid')]")
    this.listOfMissingMobileNumberInputBoxElements = page.locator("[data-legacy-field=\"listOfMissingMobileNumberInputBoxElements\"]"); // @FindBy(xpath = PHONE_NUMBER_TEXT_FIELD_XPATH + "[not(following-sibling::*)]")
    this.emailInputBoxElements = page.locator("xpath=//input[@formcontrolname='emailAddress']"); // @FindBy(xpath = "//input[@formcontrolname='emailAddress']")
    this.mobileNumberPlaceHolderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + MOBILE_NUMBER_PLACEHOLDER_TEXT + "')]")
    this.emailPlaceHolderText = page.locator("xpath=//mat-label[contains(text(),'"); // @FindBy(xpath = "//mat-label[contains(text(),'" + EMAIL_ADDRESS_PLACEHOLDER_TEXT + "')]")
    this.greenCheckMarkMobileNumberInputTextBox = page.locator("xpath=//mat-icon[contains(text(), 'done')]"); // @FindBy(xpath = "//mat-icon[contains(text(), 'done')]")
    this.pleaseEnterYourPhoneNumberError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_ENTER_YOUR_PHONE_NUMBER + "')]")
    this.pleaseEnterValidPhoneNumberError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_ENTER_VALID_PHONE_NUMBER + "')]")
    this.phoneNumberShouldBeDistinct = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + PHONE_NUMBER_SHOULD_BE_DISTINCT +  "')]")
    this.optionEmailIDHitWebElements = page.locator("xpath=//mat-hint[contains(text(),'"); // @FindBy(xpath = "//mat-hint[contains(text(),'" + OPTIONAL_HINT_TEXT + "')]")
    this.invalidEmailIdError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + INVALID_EMAIL_ID_ERROR + "')]")
    this.distinctEmailIdError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + DISTINCT_EMAIL_ID_ERROR + "')]")
    this.enrollThisDriverText = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + ENROLL_THIS_DRIVER + "')]")
    this.enrollThisDriverSlider = page.locator("xpath=//mat-slide-toggle[@formcontrolname='signalAddRemoveOption']"); // @FindBy(xpath = "//mat-slide-toggle[@formcontrolname='signalAddRemoveOption']")
    this.enrollThisDriverSliderInputTags = page.locator("xpath=//mat-slide-toggle[@formcontrolname='signalAddRemoveOption']//button"); // @FindBy(xpath = "//mat-slide-toggle[@formcontrolname='signalAddRemoveOption']//button")
    this.youthfulDriverDiscountMessage = page.locator("xpath=//div[contains(text(),'"); // @FindBy(xpath = "//div[contains(text(),'" +  YOUTHFUL_DRIVER_DISCOUNT + "')]")
    this.continueToPaymentButton = page.locator("xpath=//button[contains(text(), 'Continue')]"); // @FindBy(xpath = "//button[contains(text(), 'Continue')]")
    this.safeDrivingLeadsToBiggerRewardsAtRenewalText = page.locator("#signalText1"); // @FindBy(id = "signalText1"),             @FindBy(id = "signalTextLatest")     })
    this.fillOutInfoTextElement = page.locator("xpath=//*[@id='signalText2']"); // @FindBy(xpath = "//*[@id='signalText2']")
  }
}
