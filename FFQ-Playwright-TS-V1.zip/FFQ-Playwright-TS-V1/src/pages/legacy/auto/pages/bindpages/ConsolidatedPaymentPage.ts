// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.bindpages.ConsolidatedPaymentPage. */
export class ConsolidatedPaymentPage extends CoreBasePage {
  public readonly pageHeader: Locator;
  public readonly rateAdjustmentMessageInCaseOfDecrease: Locator;
  public readonly rateAdjustmentMessage: Locator;
  public readonly changeYourCoverageLink: Locator;
  public readonly discountTitle: Locator;
  public readonly discountTitleMobile: Locator;
  public readonly payInFullRadioButton: Locator;
  public readonly payInFullRadioButtonLabel: Locator;
  public readonly monthlyAutoPayRadioButton: Locator;
  public readonly monthlyAutoPayRadioButtonLabel: Locator;
  public readonly availablePaymentOptions: Locator;
  public readonly feeInfoBoxHeader: Locator;
  public readonly feeInfoBoxDescription: Locator;
  public readonly feeInfoIcon: Locator;
  public readonly feeInfoIconMobileView: Locator;
  public readonly feeInfoBoxHeaderMobileView: Locator;
  public readonly feeInfoBoxDescriptionMobileView: Locator;
  public readonly monthlyAutoPaySectionHeader: Locator;
  public readonly firstMonthlyPaymentText: Locator;
  public readonly firstMonthlyPaymentAmount: Locator;
  public readonly monthlyPayOneTimeFeeText: Locator;
  public readonly monthlyPayFeeAmount: Locator;
  public readonly monthlyPaySurchargeText: Locator;
  public readonly monthlyPaySurchargeAmount: Locator;
  public readonly monthlyPayFeeAmountAuto: Locator;
  public readonly dueTodayLabel: Locator;
  public readonly dueTodayAmount: Locator;
  public readonly monthlyAutoPayTotalHeader: Locator;
  public readonly viewBreakDownLink: Locator;
  public readonly monthByMonthInstallmentsTexts: Locator;
  public readonly monthByMonthInstallmentsAmounts: Locator;
  public readonly monthlyAutopayBottomTotalTermPriceText: Locator;
  public readonly monthlyAutopayBottomTotalTermPriceAmount: Locator;
  public readonly payInFullPaySectionHeader: Locator;
  public readonly payInFullSixMonthTermPriceText: Locator;
  public readonly payInFullSixMonthTermPriceAmount: Locator;
  public readonly payInFullOneTimeFeesText: Locator;
  public readonly payInFullOneTimeFeesAmount: Locator;
  public readonly payInFullTaxesAndSurchargeText: Locator;
  public readonly payInFullTaxesAndSurchargeAmount: Locator;
  public readonly payInFullDueTodayText: Locator;
  public readonly payInFullDueTodayAmount: Locator;
  public readonly payInFullBottomPaymentDetails: Locator;
  public readonly bankPaymentRadioButton: Locator;
  public readonly bankPaymentRadioButtonLabel: Locator;
  public readonly cardRadioButton: Locator;
  public readonly paymentMethodSelectionHeader: Locator;
  public readonly paymentSelectionBankPaymentRadioButton: Locator;
  public readonly paymentSelectionCardRadioButton: Locator;
  public readonly bankCardPaymentServiceChargesText: Locator;
  public readonly californiaCardPaymentRadioButton: Locator;
  public readonly californiaCardNotAvailableMonthlyPayMessage: Locator;
  public readonly californiaCardPaymentServiceChargesText: Locator;
  public readonly usingCardIncreaseMessage: Locator;
  public readonly addedBankIcon: Locator;
  public readonly maskedAddedPaymentDetails: Locator;
  public readonly bankAccountAddedMessage: Locator;
  public readonly debitCardAddedMessage: Locator;
  public readonly creditCardAddedMessage: Locator;
  public readonly paymentAddedGreenCheck: Locator;
  public readonly addedPaymentMethodIconCard: Locator;
  public readonly addedPaymentMethodIconBank: Locator;
  public readonly chargeDisclaimerText: Locator;
  public readonly paymentAddedDueMonthlyText: Locator;
  public readonly paymentAddedDueMonthlyAmount: Locator;
  public readonly infoIcon: Locator;
  public readonly serviceChargeTitle: Locator;
  public readonly serviceChargeMessage: Locator;
  public readonly changeSuggestionLink: Locator;
  public readonly disclaimerHeaderText: Locator;
  public readonly disclaimerContentBulletPointOne: Locator;
  public readonly paperlessTermsOfUseLink: Locator;
  public readonly disclaimerContentBulletPointTwo: Locator;
  public readonly informationStorageAuthorizationLink: Locator;
  public readonly paymentAuthorizationTermsAndConditionsLink: Locator;
  public readonly disclaimerContentBulletPointThree: Locator;
  public readonly oneTimePaymentRadioButton: Locator;
  public readonly recurringPaymentsRadioButton: Locator;
  public readonly termsAndConditionsDisclaimer: Locator;
  public readonly progressbarInConsolidatedPaymentPageAceAuto: Locator;
  public readonly rateChangeModalOkButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageHeader = page.locator("xpath=//app-payment-consolidated//h1[@role='heading']"); // @FindBy(xpath = "//app-payment-consolidated//h1[@role='heading']"),             @FindBy(xpath = "//app-payment-overview//h1")     })
    this.rateAdjustmentMessageInCaseOfDecrease = page.locator("xpath=//div[contains(@class,'tui-input-text payment-overview-sub-para')]"); // @FindBy(xpath = "//div[contains(@class,'tui-input-text payment-overview-sub-para')]")
    this.rateAdjustmentMessage = page.locator("xpath=//div[contains(@class,'tui-input-text payment-overview-sub-para')]"); // @FindBy(xpath = "//div[contains(@class,'tui-input-text payment-overview-sub-para')]")
    this.changeYourCoverageLink = page.locator("a[data-gtm='Auto_Bind_Payplan_CustomCoverage_link']"); // @FindBy(css = "a[data-gtm='Auto_Bind_Payplan_CustomCoverage_link']")
    this.discountTitle = page.locator("xpath=//h2[@class='discount-title']"); // @FindBy(xpath = "//h2[@class='discount-title']")
    this.discountTitleMobile = page.locator("xpath=//h2[@class='discount-title mt-4 mb-0']"); // @FindBy(xpath = "//h2[@class='discount-title mt-4 mb-0']")
    this.payInFullRadioButton = page.locator("xpath=//mat-radio-button[contains(.,'Pay in full')]"); // @FindBy(xpath = "//mat-radio-button[contains(.,'Pay in full')]")
    this.payInFullRadioButtonLabel = page.locator("xpath=//mat-radio-button[contains(.,'Pay in full')]//label"); // @FindBy(xpath = "//mat-radio-button[contains(.,'Pay in full')]//label")
    this.monthlyAutoPayRadioButton = page.locator("xpath=//mat-radio-button[contains(.,'Monthly Autopay')]"); // @FindBy(xpath = "//mat-radio-button[contains(.,'Monthly Autopay')]")
    this.monthlyAutoPayRadioButtonLabel = page.locator("xpath=//mat-radio-button[contains(.,'Monthly Autopay')]//label"); // @FindBy(xpath = "//mat-radio-button[contains(.,'Monthly Autopay')]//label")
    this.availablePaymentOptions = page.locator("xpath=//mat-radio-button//h2"); // @FindBy(xpath = "//mat-radio-button//h2"),         @FindBy(xpath = "//mat-tab-header//*[@role='tab']")     })
    this.feeInfoBoxHeader = page.locator("xpath=//p[@class='tui-info-box-header tui-field-label-text']"); // @FindBy(xpath = "//p[@class='tui-info-box-header tui-field-label-text']")
    this.feeInfoBoxDescription = page.locator("xpath=//p[@class='tui-info-box-content']"); // @FindBy(xpath = "//p[@class='tui-info-box-content']")
    this.feeInfoIcon = page.locator("xpath=//mat-icon[contains(@class,'mat-icon notranslate tui-info-box-icon material-icons mat-ligature-font mat-icon-no-color')]"); // @FindBy(xpath = "//mat-icon[contains(@class,'mat-icon notranslate tui-info-box-icon material-icons mat-ligature-font mat-icon-no-color')]")
    this.feeInfoIconMobileView = page.locator("xpath=//mat-icon[contains(@class,'mat-icon notranslate tui-info-box-icon mobile-info-icon material-icons mat-icon-no-color')]"); // @FindBy(xpath = "//mat-icon[contains(@class,'mat-icon notranslate tui-info-box-icon mobile-info-icon material-icons mat-icon-no-color')]")
    this.feeInfoBoxHeaderMobileView = page.locator("xpath=//app-model-info-box-bind//h1[@aria-label='Fee info']"); // @FindBy(xpath = "//app-model-info-box-bind//h1[@aria-label='Fee info']")
    this.feeInfoBoxDescriptionMobileView = page.locator("xpath=//app-model-info-box-bind//p"); // @FindBy(xpath = "//app-model-info-box-bind//p")
    this.monthlyAutoPaySectionHeader = page.locator("xpath=//app-monthly-auto-pay-consolidated//h2"); // @FindBy(xpath = "//app-monthly-auto-pay-consolidated//h2")
    this.firstMonthlyPaymentText = page.locator("xpath=//div[contains(@class,'monthly-autopay-fees-row d-flex justify')][1]/p[1]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row d-flex justify')][1]/p[1]")
    this.firstMonthlyPaymentAmount = page.locator("xpath=//div[contains(@class,'monthly-autopay-fees-row d-flex justify')][1]/p[2]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row d-flex justify')][1]/p[2]")
    this.monthlyPayOneTimeFeeText = page.locator("xpath=//div[contains(@class,'monthly-autopay-fees-row')][2]/descendant::*[1]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')][2]/descendant::*[1]")
    this.monthlyPayFeeAmount = page.locator("xpath=//div[contains(@class,'monthly-autopay-fees-row')][2]/descendant::*[2]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')][2]/descendant::*[2]")
    this.monthlyPaySurchargeText = page.locator("xpath=//div[contains(@class,'monthly-autopay-fees-row')][3]/descendant::*[1]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')][3]/descendant::*[1]")
    this.monthlyPaySurchargeAmount = page.locator("xpath=//div[contains(@class,'monthly-autopay-fees-row')][3]/descendant::*[2]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')][3]/descendant::*[2]")
    this.monthlyPayFeeAmountAuto = page.locator("xpath=//div[contains(@class,'monthly-autopay-fees-row')][2]//p"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')][2]//p")
    this.dueTodayLabel = page.locator("xpath=//div[contains(@class,'details-bottom')]/span[1]"); // @FindBy(xpath = "//div[contains(@class,'details-bottom')]/span[1]")
    this.dueTodayAmount = page.locator("xpath=//div[contains(@class,'details-bottom')]/span[2]"); // @FindBy(xpath = "//div[contains(@class,'details-bottom')]/span[2]")
    this.monthlyAutoPayTotalHeader = page.locator("xpath=//div[contains(@class,'monthly-autopay-details-header')]/span"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-details-header')]/span")
    this.viewBreakDownLink = page.locator("#view-breakdown-link"); // @FindBy(id = "view-breakdown-link")
    this.monthByMonthInstallmentsTexts = page.locator("xpath=//div[@class='show-breakdown ng-star-inserted']//div[@class='ng-star-inserted']//span[1]"); // @FindBy(xpath = "//div[@class='show-breakdown ng-star-inserted']//div[@class='ng-star-inserted']//span[1]")
    this.monthByMonthInstallmentsAmounts = page.locator("xpath=//div[@class='show-breakdown ng-star-inserted']//div[@class='ng-star-inserted']//span[2]"); // @FindBy(xpath = "//div[@class='show-breakdown ng-star-inserted']//div[@class='ng-star-inserted']//span[2]")
    this.monthlyAutopayBottomTotalTermPriceText = page.locator("xpath=//div[contains(@class,'tui-body-text-bold monthly-autopay-details-bottom-row d-flex mb-2 justify-content-between')]//span[1]"); // @FindBy(xpath = "//div[contains(@class,'tui-body-text-bold monthly-autopay-details-bottom-row d-flex mb-2 justify-content-between')]//span[1]")
    this.monthlyAutopayBottomTotalTermPriceAmount = page.locator("xpath=//div[contains(@class,'tui-body-text-bold monthly-autopay-details-bottom-row d-flex mb-2 justify-content-between')]//span[2]"); // @FindBy(xpath = "//div[contains(@class,'tui-body-text-bold monthly-autopay-details-bottom-row d-flex mb-2 justify-content-between')]//span[2]")
    this.payInFullPaySectionHeader = page.locator("xpath=//app-full-auto-pay-consolidated//h2"); // @FindBy(xpath = "//app-full-auto-pay-consolidated//h2")
    this.payInFullSixMonthTermPriceText = page.locator("xpath=//div[contains(@class,'pif-autopay-fees-row d-flex justify-content-between w-100 tui-body')][1]/span[1]"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-fees-row d-flex justify-content-between w-100 tui-body')][1]/span[1]")
    this.payInFullSixMonthTermPriceAmount = page.locator("xpath=//div[contains(@class,'pif-autopay-fees-row d-flex justify-content-between w-100 tui-body')][1]/span[2]"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-fees-row d-flex justify-content-between w-100 tui-body')][1]/span[2]")
    this.payInFullOneTimeFeesText = page.locator("xpath=//div[contains(@class,'pif-autopay-fees-row')][2]/span[1]"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-fees-row')][2]/span[1]")
    this.payInFullOneTimeFeesAmount = page.locator("xpath=//div[contains(@class,'pif-autopay-fees-row')][2]/span[2]"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-fees-row')][2]/span[2]")
    this.payInFullTaxesAndSurchargeText = page.locator("xpath=//div[contains(@class,'pif-autopay-surcharge-fees')]//span[1]"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-surcharge-fees')]//span[1]")
    this.payInFullTaxesAndSurchargeAmount = page.locator("xpath=//div[contains(@class,'pif-autopay-surcharge-fees')]//span[2]"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-surcharge-fees')]//span[2]")
    this.payInFullDueTodayText = page.locator("xpath=//div[contains(@class,'pif-autopay-details-bottom-row d-flex justify-content-between')][1]/span[1]"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-details-bottom-row d-flex justify-content-between')][1]/span[1]")
    this.payInFullDueTodayAmount = page.locator("xpath=//div[contains(@class,'pif-autopay-details-bottom-row d-flex justify-content-between')][1]/span[2]"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-details-bottom-row d-flex justify-content-between')][1]/span[2]")
    this.payInFullBottomPaymentDetails = page.locator("xpath=//div[contains(@class,'pif-autopay-details-header')]"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-details-header')]")
    this.bankPaymentRadioButton = page.locator("mat-radio-button[value='bank']"); // @FindBy(css = "mat-radio-button[value='bank']")
    this.bankPaymentRadioButtonLabel = page.locator("xpath=//mat-radio-button[@value='bank']//label"); // @FindBy(xpath = "//mat-radio-button[@value='bank']//label")
    this.cardRadioButton = page.locator("mat-radio-button[value='card']"); // @FindBy(css = "mat-radio-button[value='card']")
    this.paymentMethodSelectionHeader = page.locator("xpath=//p[contains(@class,'selection-header')]"); // @FindBy(xpath = "//p[contains(@class,'selection-header')]")
    this.paymentSelectionBankPaymentRadioButton = page.locator("xpath=//mat-radio-button[@value='bank']//label"); // @FindBy(xpath = "//mat-radio-button[@value='bank']//label")
    this.paymentSelectionCardRadioButton = page.locator("xpath=//mat-radio-button[@value='card']//label"); // @FindBy(xpath = "//mat-radio-button[@value='card']//label")
    this.bankCardPaymentServiceChargesText = page.locator("xpath=//div[contains(@class,'monthly-autopay-selection-option')]//div[contains(@class,'monthly-autopay-selection-sub-section')]"); // @FindBy(xpath = "//div[contains(@class,'monthly-autopay-selection-option')]//div[contains(@class,'monthly-autopay-selection-sub-section')]")
    this.californiaCardPaymentRadioButton = page.locator("xpath=//mat-radio-button[contains(@class,'mat-radio-button ca-card-payment-radio-option mat-radio-disabled mat-accent')]"); // @FindBy(xpath = "//mat-radio-button[contains(@class,'mat-radio-button ca-card-payment-radio-option mat-radio-disabled mat-accent')]")
    this.californiaCardNotAvailableMonthlyPayMessage = page.locator("xpath=//span[contains(@class,'card-NA-text')]"); // @FindBy(xpath = "//span[contains(@class,'card-NA-text')]")
    this.californiaCardPaymentServiceChargesText = page.locator("xpath=//span[contains(@class,'ca-card-payment-service-text')]"); // @FindBy(xpath = "//span[contains(@class,'ca-card-payment-service-text')]")
    this.usingCardIncreaseMessage = page.locator("xpath=//section[@class='monthly-autopay-selection ng-star-inserted']/div/div"); // @FindBy(xpath = "//section[@class='monthly-autopay-selection ng-star-inserted']/div/div")
    this.addedBankIcon = page.locator("xpath=//div[contains(@class,'disclaimers-charge-info')]//*[contains(@class,'generic-payment')]"); // @FindBy(xpath = "//div[contains(@class,'disclaimers-charge-info')]//*[contains(@class,'generic-payment')]")
    this.maskedAddedPaymentDetails = page.locator("xpath=//span[contains(@class,'account-numbers')]"); // @FindBy(xpath = "//span[contains(@class,'account-numbers')]")
    this.bankAccountAddedMessage = page.locator("xpath=//span[contains(.,'Bank payment account added.')]"); // @FindBy(xpath = "//span[contains(.,'Bank payment account added.')]")
    this.debitCardAddedMessage = page.locator("xpath=//span[contains(.,'Debit card added.')]"); // @FindBy(xpath = "//span[contains(.,'Debit card added.')]"),             @FindBy(xpath = "//span[contains(.,' card added.')]")     })
    this.creditCardAddedMessage = page.locator("xpath=//span[contains(.,'Credit card added.')]"); // @FindBy(xpath = "//span[contains(.,'Credit card added.')]")
    this.paymentAddedGreenCheck = page.locator("xpath=//section[contains(@class,'payment-confirmation')]/div[1]//mat-icon"); // @FindBy(xpath = "//section[contains(@class,'payment-confirmation')]/div[1]//mat-icon")
    this.addedPaymentMethodIconCard = page.locator("xpath=//div[contains(@class,'disclaimers-charge-info')]//i"); // @FindBy(xpath = "//div[contains(@class,'disclaimers-charge-info')]//i")
    this.addedPaymentMethodIconBank = page.locator("xpath=//div[contains(@class,'disclaimers-charge-info')]//i"); // @FindBy(xpath = "//div[contains(@class,'disclaimers-charge-info')]//i")
    this.chargeDisclaimerText = page.locator("xpath=//*[contains(@class,'disclaimers-charge-text')]"); // @FindBy(xpath = "//*[contains(@class,'disclaimers-charge-text')]")
    this.paymentAddedDueMonthlyText = page.locator("xpath=//section[contains(@class,'payment-confirmation')]//div[3]/span[1]"); // @FindBy(xpath = "//section[contains(@class,'payment-confirmation')]//div[3]/span[1]")
    this.paymentAddedDueMonthlyAmount = page.locator("xpath=//section[contains(@class,'payment-confirmation')]//div[3]/span[2]"); // @FindBy(xpath = "//section[contains(@class,'payment-confirmation')]//div[3]/span[2]")
    this.infoIcon = page.locator("xpath=//*[contains(@class,'disclaimers-charge-text')]//mat-icon"); // @FindBy(xpath = "//*[contains(@class,'disclaimers-charge-text')]//mat-icon")
    this.serviceChargeTitle = page.locator("xpath=//*[contains(@class,'disclaimers-charge-text')]//p[@class='tui-info-box-content']/p[1]"); // @FindBy(xpath = "//*[contains(@class,'disclaimers-charge-text')]//p[@class='tui-info-box-content']/p[1]")
    this.serviceChargeMessage = page.locator("xpath=//*[contains(@class,'disclaimers-charge-text')]//p[@class='tui-info-box-content']/p[2]"); // @FindBy(xpath = "//*[contains(@class,'disclaimers-charge-text')]//p[@class='tui-info-box-content']/p[2]")
    this.changeSuggestionLink = page.locator("xpath=//*[contains(@class,'disclaimers-charge-text')]//p[@class='tui-info-box-content']/p[3]"); // @FindBy(xpath = "//*[contains(@class,'disclaimers-charge-text')]//p[@class='tui-info-box-content']/p[3]")
    this.disclaimerHeaderText = page.locator("xpath=//div[contains(@class,'disclaimers-text-header')]"); // @FindBy(xpath = "//div[contains(@class,'disclaimers-text-header')]")
    this.disclaimerContentBulletPointOne = page.locator("xpath=//section[contains(@class,'disclaimers-text')]//li[1]//p"); // @FindBy(xpath = "//section[contains(@class,'disclaimers-text')]//li[1]//p")
    this.paperlessTermsOfUseLink = page.getByRole('link', { name: "Paperless Terms of Use" }); // @FindBy(partialLinkText = "Paperless Terms of Use")
    this.disclaimerContentBulletPointTwo = page.locator("xpath=//section[contains(@class,'disclaimers-text')]//li[2]//p"); // @FindBy(xpath = "//section[contains(@class,'disclaimers-text')]//li[2]//p")
    this.informationStorageAuthorizationLink = page.getByRole('link', { name: "Information Storage Authorization" }); // @FindBy(partialLinkText = "Information Storage Authorization")
    this.paymentAuthorizationTermsAndConditionsLink = page.getByRole('link', { name: "Payment Authorization Terms & Conditions." }); // @FindBy(partialLinkText = "Payment Authorization Terms & Conditions.")
    this.disclaimerContentBulletPointThree = page.locator("xpath=//section[contains(@class,'disclaimers-text')]//li[3]//p"); // @FindBy(xpath = "//section[contains(@class,'disclaimers-text')]//li[3]//p")
    this.oneTimePaymentRadioButton = page.locator("mat-radio-button[value='one-time-payment']"); // @FindBy(css = "mat-radio-button[value='one-time-payment']")
    this.recurringPaymentsRadioButton = page.locator("mat-radio-button[value='automatic-recurring']"); // @FindBy(css = "mat-radio-button[value='automatic-recurring']")
    this.termsAndConditionsDisclaimer = page.locator("xpath=//section[contains(@class,'disclaimers-text')]//p[contains(@class, 'stacking')]"); // @FindBy(xpath = "//section[contains(@class,'disclaimers-text')]//p[contains(@class, 'stacking')]")
    this.progressbarInConsolidatedPaymentPageAceAuto = page.locator("xpath=//mat-progress-bar"); // @FindBy(xpath= "//mat-progress-bar")
    this.rateChangeModalOkButton = page.locator("xpath=//button[contains(@class,'ok-button')]"); // @FindBy(xpath = "//button[contains(@class,'ok-button')]")
  }
}
