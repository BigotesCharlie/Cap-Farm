// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.bindpages.AdditionalInfoContinueToPaymentOneUI. */
export class AdditionalInfoContinueToPaymentOneUI extends CoreBasePage {
  public readonly continueToPaymentButton: Locator;
  public readonly baseOnThirdPartyInfo: Locator;
  public readonly paymentDiscountList: Locator;
  public readonly discountsIncludedHeader: Locator;
  public readonly payInMonthlyPayBankHeader: Locator;
  public readonly monthlyBankPaymentTabHeader: Locator;
  public readonly monthlyCardPaymentTabHeader: Locator;
  public readonly payInMonthlyPayCardHeader: Locator;
  public readonly sixMonthTermTotalCost: Locator;
  public readonly payInFullH2WebElement: Locator;
  public readonly paymentPageSubheader: Locator;
  public readonly paymentPageAlternatePaymentMethodLink: Locator;
  public readonly paymentPageDueTodayAmount: Locator;
  public readonly setUpPaymentMethod: Locator;
  public readonly priceUpdateContainerHeader: Locator;
  public readonly updatedPriceContentPaymentMethodText: Locator;
  public readonly updatedPriceContentPaymentMethod: Locator;
  public readonly updatePriceContainerReviewDisclaimer: Locator;
  public readonly updatePriceContainerEditDisclaimer: Locator;
  public readonly updatePriceContainerOkButton: Locator;
  public readonly changeYourCoverageLink: Locator;
  public readonly convenientHeader: Locator;
  public readonly monthlyAutoPayHeader: Locator;
  public readonly sizMonthlyPayments: Locator;
  public readonly autoPaySavings: Locator;
  public readonly bankPaymentAdministrationFee: Locator;
  public readonly creditCardAdministrationFee: Locator;
  public readonly debitCardAdministrationFee: Locator;
  public readonly bankPayment: Locator;

  public constructor(page: Page) {
    super(page);
    this.continueToPaymentButton = page.locator("xpath=//div[contains(@class,'additional-info-submit-button')]//button"); // @FindBy(xpath = "//div[contains(@class,'additional-info-submit-button')]//button")
    this.baseOnThirdPartyInfo = page.locator("xpath=//a[contains(text(), 'change your coverage options')]/parent::*"); // @FindBy(xpath = "//a[contains(text(), 'change your coverage options')]/parent::*")
    this.paymentDiscountList = page.locator("xpath=//div[contains(@class, 'payment-overview-discount-name')]//span"); // @FindBy(xpath = "//div[contains(@class, 'payment-overview-discount-name')]//span")
    this.discountsIncludedHeader = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + DISCOUNTS_INCLUDED + "')]")
    this.payInMonthlyPayBankHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_BANK_HEADER + "')]")
    this.monthlyBankPaymentTabHeader = page.locator("xpath=//mat-tab-header//div[contains(text(),'Monthly - bank')]"); // @FindBy(xpath = "//mat-tab-header//div[contains(text(),'Monthly - bank')]")
    this.monthlyCardPaymentTabHeader = page.locator("xpath=//mat-tab-header//div[contains(text(),'Monthly - card')]"); // @FindBy(xpath = "//mat-tab-header//div[contains(text(),'Monthly - card')]")
    this.payInMonthlyPayCardHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_CARD_HEADER + "')]")
    this.sixMonthTermTotalCost = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + SIX_MONTH_TERM_TOTAL_COST + "')]")
    this.payInFullH2WebElement = page.locator("xpath=//h2[contains(text(), 'Pay in full')]"); // @FindBy(xpath = "//h2[contains(text(), 'Pay in full')]")
    this.paymentPageSubheader = page.locator("xpath=//div[@class='row pif-autopay-main-payment-row']//h2"); // @FindBy(xpath = "//div[@class='row pif-autopay-main-payment-row']//h2")
    this.paymentPageAlternatePaymentMethodLink = page.locator("xpath=//div[@class='row pif-autopay-main-payment-row']//h2"); // @FindBy(xpath = "//div[@class='row pif-autopay-main-payment-row']//h2")
    this.paymentPageDueTodayAmount = page.locator("xpath=//div[contains(@class,'pif-autopay-details-bottom')]//span[2]"); // @FindBy(xpath = "//div[contains(@class,'pif-autopay-details-bottom')]//span[2]")
    this.setUpPaymentMethod = page.locator("button[class='tui-btn tui-btn-primary ng-star-inserted']"); // @FindBy(css = "button[class='tui-btn tui-btn-primary ng-star-inserted']")
    this.priceUpdateContainerHeader = page.locator("xpath=//app-price-update-dialog//h1"); // @FindBy(xpath = "//app-price-update-dialog//h1")
    this.updatedPriceContentPaymentMethodText = page.locator("xpath=//mat-dialog-content[@class='mat-dialog-content updated-price-content']/p[1]"); // @FindBy(xpath = "//mat-dialog-content[@class='mat-dialog-content updated-price-content']/p[1]")
    this.updatedPriceContentPaymentMethod = page.locator("xpath=//mat-dialog-content[@class='mat-dialog-content updated-price-content']/ul"); // @FindBy(xpath = "//mat-dialog-content[@class='mat-dialog-content updated-price-content']/ul")
    this.updatePriceContainerReviewDisclaimer = page.locator("xpath=//mat-dialog-content[@class='mat-dialog-content updated-price-content']/p[2]"); // @FindBy(xpath = "//mat-dialog-content[@class='mat-dialog-content updated-price-content']/p[2]")
    this.updatePriceContainerEditDisclaimer = page.locator("xpath=//mat-dialog-content[@class='mat-dialog-content updated-price-content']/p[3]"); // @FindBy(xpath = "//mat-dialog-content[@class='mat-dialog-content updated-price-content']/p[3]")
    this.updatePriceContainerOkButton = page.locator("xpath=//app-price-update-dialog//button"); // @FindBy(xpath = "//app-price-update-dialog//button")
    this.changeYourCoverageLink = page.locator("[data-legacy-field=\"changeYourCoverageLink\"]"); // @FindBy(xpath = CHANGE_YOUR_COVERAGE_XPATH)
    this.convenientHeader = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + CONVENIENT + "')]")
    this.monthlyAutoPayHeader = page.locator("xpath=//h2[contains(text(), '"); // @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTOPAY_HEADER + "')]")
    this.sizMonthlyPayments = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + SIX_MONTHLY_PAYMENT + "')]")
    this.autoPaySavings = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + AUTO_PAY_SAVINGS + "')]")
    this.bankPaymentAdministrationFee = page.locator("xpath=//p[contains(.,'Bank payment') and contains(.,'$')]"); // @FindBy(xpath = "//p[contains(.,'Bank payment') and contains(.,'$')]")
    this.creditCardAdministrationFee = page.locator("xpath=//p[contains(.,'Credit card')]"); // @FindBy(xpath = "//p[contains(.,'Credit card')]")
    this.debitCardAdministrationFee = page.locator("xpath=//p[contains(.,'Debit card')]"); // @FindBy(xpath = "//p[contains(.,'Debit card')]")
    this.bankPayment = page.locator("xpath=//li[@class='payment-overview-list-icon']//p[contains(text(),'Bank payment')]"); // @FindBy(xpath = "//li[@class='payment-overview-list-icon']//p[contains(text(),'Bank payment')]")
  }
}
