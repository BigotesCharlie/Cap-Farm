// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI. */
export class AdditionalInfoPolicyStartDateOneUI extends CoreBasePage {
  public readonly justFewMoreThingsLabel: Locator;
  public readonly privacyPolicyLink: Locator;
  public readonly privacyCenterHeading: Locator;
  public readonly additionalInfoPageHeader: Locator;
  public readonly progressbarAceAuto: Locator;
  public readonly policyStartDateLabel: Locator;
  public readonly insuranceBeginLabel: Locator;
  public readonly policyStartDatePicker: Locator;
  public readonly policyStartDatePlaceHolder: Locator;
  public readonly earlyShopperDiscountLabelBrowser: Locator;
  public readonly earlyShopperDiscountLabelH1: Locator;
  public readonly earlyShopperMobileMatIcon: Locator;
  public readonly discountCongratulationMessage: Locator;
  public readonly sidesheet: Locator;
  public readonly greenCheckCircle: Locator;
  public readonly earlyShopperDiscountText: Locator;
  public readonly policyPurchaseDateError: Locator;
  public readonly policyStartDateRequiredMessage: Locator;
  public readonly datePickerToggleIcon: Locator;
  public readonly selectedDateInDatePickerPopUp: Locator;
  public readonly signalEnrollmentConfirmationCheckbox: Locator;
  public readonly continueToPaymentButton: Locator;
  public readonly additionalInfoTipMediumIconMobileDevice: Locator;
  public readonly closeIcon: Locator;
  public readonly getEarlyShopperDiscountTextInMb: Locator;
  public readonly continueButtonAutoFewMoreThingsPageBundle: Locator;
  public readonly distantSchoolName: Locator;
  public readonly distantSchoolCity: Locator;
  public readonly distantSchoolState: Locator;

  public constructor(page: Page) {
    super(page);
    this.justFewMoreThingsLabel = page.locator("xpath=//div[contains(@class, 'additional-info-main-page')]//h1"); // @FindBy(xpath = "//div[contains(@class, 'additional-info-main-page')]//h1")
    this.privacyPolicyLink = page.locator("xpath=//a[contains(text(),'Privacy Policy')]"); // @FindBy(xpath = "//a[contains(text(),'Privacy Policy')]")
    this.privacyCenterHeading = page.locator("xpath=//h1/span/span[contains(text(),'Privacy Center')]"); // @FindBy(xpath="//h1/span/span[contains(text(),'Privacy Center')]")
    this.additionalInfoPageHeader = page.locator("xpath=//div[@class='additional-info-main-page ng-star-inserted']//h1"); // @FindBy(xpath = "//div[@class='additional-info-main-page ng-star-inserted']//h1")
    this.progressbarAceAuto = page.locator("xpath=//mat-progress-bar"); // @FindBy(xpath= "//mat-progress-bar")
    this.policyStartDateLabel = page.locator("xpath=//span[contains(text(), 'Please fill out these last few details so we can complete your purchase.')]"); // @FindBy(xpath = "//span[contains(text(), 'Please fill out these last few details so we can complete your purchase.')]") //    private WebElement additionalInfoSubHeader;      private static final String POLICY_START_DATE_LABEL = "Auto policy start date";     @FindBy(xpath = "//div[contains(@class, 'additional-info-effective-date-section')]//h2")
    this.insuranceBeginLabel = page.locator("xpath=//p[contains(text(), 'like your insurance to begin.')]"); // @FindBy(xpath = "//p[contains(text(), 'like your insurance to begin.')]")
    this.policyStartDatePicker = page.locator("[data-legacy-field=\"policyStartDatePicker\"]"); // @FindBy(xpath = POLICY_START_DATE_XPATH)
    this.policyStartDatePlaceHolder = page.locator("xpath=//mat-label[contains(text(), 'Policy start date')]"); // @FindBy(xpath = "//mat-label[contains(text(), 'Policy start date')]")
    this.earlyShopperDiscountLabelBrowser = page.locator("xpath=//p[contains(text(), 'Early shopping discount')]"); // @FindBy(xpath = "//p[contains(text(), 'Early shopping discount')]")
    this.earlyShopperDiscountLabelH1 = page.locator("xpath=//h1[contains(text(), 'Early shopper discount')]"); // @FindBy(xpath = "//h1[contains(text(), 'Early shopper discount')]")
    this.earlyShopperMobileMatIcon = page.locator("xpath=//div[@class='additional-info-effective-date-section']//mat-icon[contains(@class,'mobile')]"); // @FindBy(xpath = "//div[@class='additional-info-effective-date-section']//mat-icon[contains(@class,'mobile')]")
    this.discountCongratulationMessage = page.locator("[data-legacy-field=\"discountCongratulationMessage\"]"); // @FindBy(xpath = DISCOUNT_CONGRATULATIONS_MESSAGE_XPATH)
    this.sidesheet = page.locator("div[id='tui-save-quote-modal']"); // @FindBy(css="div[id='tui-save-quote-modal']")
    this.greenCheckCircle = page.locator("[data-legacy-field=\"greenCheckCircle\"]"); // @FindBy(xpath = GREEN_CHECK_CIRCLE_XPATH)
    this.earlyShopperDiscountText = page.locator("xpath=//p[contains(text(), 'If your policy start date is 7 or more days from today')]"); // @FindBy(xpath = "//p[contains(text(), 'If your policy start date is 7 or more days from today')]")
    this.policyPurchaseDateError = page.locator("[data-legacy-field=\"policyPurchaseDateError\"]"); // @FindBy(xpath = POLICY_PURCHASE_DATE_ERROR_XPATH)
    this.policyStartDateRequiredMessage = page.locator("xpath=//mat-error[contains(text(), '"); // @FindBy(xpath = "//mat-error[contains(text(), '" + POLICY_START_DATE_REQUIRED_MESSAGE + "')]")
    this.datePickerToggleIcon = page.locator("[data-legacy-field=\"datePickerToggleIcon\"]"); // @FindBy(xpath = DATEPICKER_TOGGLE_ICON_XPATH)
    this.selectedDateInDatePickerPopUp = page.locator("xpath=//div[contains(@class,'mat-calendar-body-selected')]"); // @FindBy(xpath = "//div[contains(@class,'mat-calendar-body-selected')]")
    this.signalEnrollmentConfirmationCheckbox = page.locator("xpath=//mat-checkbox[@formcontrolname='signalAgreement']"); // @FindBy(xpath = "//mat-checkbox[@formcontrolname='signalAgreement']")
    this.continueToPaymentButton = page.locator("xpath=//button[contains(text(), 'Continue')]"); // @FindBy(xpath = "//button[contains(text(), 'Continue')]")
    this.additionalInfoTipMediumIconMobileDevice = page.locator("xpath=//div[contains(@class,'additional_info_tips_section_medium')]"); // @FindBy(xpath = "//div[contains(@class,'additional_info_tips_section_medium')]")
    this.closeIcon = page.locator("xpath=//mat-icon[contains(text(), 'close')]"); // @FindBy(xpath = "//mat-icon[contains(text(), 'close')]")
    this.getEarlyShopperDiscountTextInMb = page.locator("xpath=//p[contains(@class,'model-caption-text')]"); // @FindBy(xpath = "//p[contains(@class,'model-caption-text')]")
    this.continueButtonAutoFewMoreThingsPageBundle = page.locator("xpath=//button[contains(@class, 'additional-info-submit-button-style-bundle')]"); // @FindBy(xpath = "//button[contains(@class, 'additional-info-submit-button-style-bundle')]")
    this.distantSchoolName = page.locator("xpath=//input[@formcontrolname='distStudSchool']"); // @FindBy(xpath = "//input[@formcontrolname='distStudSchool']")
    this.distantSchoolCity = page.locator("xpath=//input[@formcontrolname='distStudCity']"); // @FindBy(xpath = "//input[@formcontrolname='distStudCity']")
    this.distantSchoolState = page.locator("xpath=//mat-select[@formcontrolname='distStudState']"); // @FindBy(xpath = "//mat-select[@formcontrolname='distStudState']")
  }
}
