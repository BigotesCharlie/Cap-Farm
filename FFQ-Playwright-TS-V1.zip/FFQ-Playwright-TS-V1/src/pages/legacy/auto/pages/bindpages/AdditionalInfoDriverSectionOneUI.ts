// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.bindpages.AdditionalInfoDriverSectionOneUI. */
export class AdditionalInfoDriverSectionOneUI extends CoreBasePage {
  public readonly driverLabel: Locator;
  public readonly whyNeedDriverLicenseQuestion: Locator;
  public readonly whyNeedDriverLicenseQuestionMB: Locator;
  public readonly whyNeedDriverLicenseExplanation: Locator;
  public readonly getWhyNeedDriverLicenseQuestionTipMB: Locator;
  public readonly parentNodeForDriverList: Locator;
  public readonly driverLicenseNumberInputTextBoxes: Locator;
  public readonly driverLicenseStateDropDownWebElementList: Locator;
  public readonly test: Locator;
  public readonly driverLicenseNumberInputPlaceHolders: Locator;
  public readonly enterDriverLicenseNumberErrors: Locator;
  public readonly listOfAllTheStatesInLicenseStateDropdown: Locator;
  public readonly invalidLicenseError: Locator;
  public readonly completedMatureDriverSafetyCourseLastThreeYears: Locator;
  public readonly disabledMatureSafetyCourseToggleButton: Locator;
  public readonly enabledMatureSafetyCourseToggleButton: Locator;
  public readonly mddSafetyCourseDateInputBox: Locator;
  public readonly provideCompletionDateOrToggleOffHint: Locator;
  public readonly provideCompletionDateOrCheckCheckboxHint: Locator;
  public readonly mddSafetyCourseDateIDoNotKnowCheckbox: Locator;
  public readonly mddSafetyCourseDateIDoNotKnowLabel: Locator;
  public readonly mddSafetyCourseDateRangeError: Locator;
  public readonly mddMustBeInMMYYYYFormatError: Locator;
  public readonly countryDropDowns: Locator;
  public readonly foreignDlInputField: Locator;
  public readonly fdlStartDateInputFields: Locator;

  public constructor(page: Page) {
    super(page);
    this.driverLabel = page.locator("xpath=//h3[contains(text(), 'license info')]"); // @FindBy(xpath = "//h3[contains(text(), 'license info')]")
    this.whyNeedDriverLicenseQuestion = page.locator("xpath=//p[contains(text(), 'Why do you need my driver')]"); // @FindBy(xpath = "//p[contains(text(), 'Why do you need my driver')]")
    this.whyNeedDriverLicenseQuestionMB = page.locator("xpath=//h1[contains(text(), 'Why do you need my driver')]"); // @FindBy(xpath = "//h1[contains(text(), 'Why do you need my driver')]")
    this.whyNeedDriverLicenseExplanation = page.locator("xpath=//p[contains(text(), 'This is required to check your driving history')]"); // @FindBy(xpath = "//p[contains(text(), 'This is required to check your driving history')]")
    this.getWhyNeedDriverLicenseQuestionTipMB = page.locator("xpath=//div[contains(@class,'additional-info-driver-section')]//div[contains(@class,'additional_info_tips_section_medium')]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'additional-info-driver-section')]//div[contains(@class,'additional_info_tips_section_medium')]//mat-icon")
    this.parentNodeForDriverList = page.locator("xpath=//div[@formarrayname ='drivers']"); // @FindBy(xpath = "//div[@formarrayname ='drivers']")
    this.driverLicenseNumberInputTextBoxes = page.locator("xpath=//input[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicense_text']"); // @FindBy(xpath = "//input[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicense_text']")
    this.driverLicenseStateDropDownWebElementList = page.locator("xpath=//mat-select[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicenseState_text']"); // @FindBy(xpath = "//mat-select[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicenseState_text']")
    this.test = page.locator("xpath=//mat-label[contains(text(),'State')]"); // @FindBy(xpath = "//mat-label[contains(text(),'State')]")
    this.driverLicenseNumberInputPlaceHolders = page.locator("xpath=//mat-label[contains(text(),\"Driver's license #\")]"); // @FindBy(xpath = "//mat-label[contains(text(),\"Driver's license #\")]")
    this.enterDriverLicenseNumberErrors = page.locator("xpath=//mat-error[contains(text(),'license number')]"); // @FindBy(xpath = "//mat-error[contains(text(),'license number')]")
    this.listOfAllTheStatesInLicenseStateDropdown = page.locator("xpath=//span[@class='mat-option-text']"); // @FindBy(xpath = "//span[@class='mat-option-text']")
    this.invalidLicenseError = page.locator("xpath=//mat-error[contains(text(),'License # not valid for this state.')]"); // @FindBy(xpath = "//mat-error[contains(text(),'License # not valid for this state.')]")
    this.completedMatureDriverSafetyCourseLastThreeYears = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + COMPLETED_MATURE_DRIVER_SAFETY_COURSE_LAST_3_YEARS + "')]")
    this.disabledMatureSafetyCourseToggleButton = page.locator("xpath=//mat-slide-toggle[@formcontrolname='mddCourseToggle']//input[@aria-checked='false']"); // @FindBy(xpath = "//mat-slide-toggle[@formcontrolname='mddCourseToggle']//input[@aria-checked='false']")
    this.enabledMatureSafetyCourseToggleButton = page.locator("xpath=//mat-slide-toggle[@formcontrolname='mddCourseToggle']//input[@aria-checked='true']"); // @FindBy(xpath = "//mat-slide-toggle[@formcontrolname='mddCourseToggle']//input[@aria-checked='true']")
    this.mddSafetyCourseDateInputBox = page.locator("xpath=//input[@formcontrolname='mddSafetyCourseDate']"); // @FindBy(xpath = "//input[@formcontrolname='mddSafetyCourseDate']")
    this.provideCompletionDateOrToggleOffHint = page.locator("xpath=//mat-hint[contains(text(),'"); // @FindBy(xpath = "//mat-hint[contains(text(),'" + PROVIDE_COMPLETION_DATE_TOGGLE_OFF_HINT + "')]")
    this.provideCompletionDateOrCheckCheckboxHint = page.locator("xpath=//mat-hint[contains(text(),'"); // @FindBy(xpath = "//mat-hint[contains(text(),'" + PROVIDE_COMPLETION_DATE_CHECK_CHECKBOX_HINT + "')]")
    this.mddSafetyCourseDateIDoNotKnowCheckbox = page.locator("xpath=//mat-checkbox[@formcontrolname='mddSafetyCourseDateIDoNotKnow']//label//input[@type='checkbox']"); // @FindBy(xpath = "//mat-checkbox[@formcontrolname='mddSafetyCourseDateIDoNotKnow']//label//input[@type='checkbox']")
    this.mddSafetyCourseDateIDoNotKnowLabel = page.locator("xpath=//mat-checkbox[@formcontrolname='mddSafetyCourseDateIDoNotKnow']//label//span[@class='mat-checkbox-label']"); // @FindBy(xpath = "//mat-checkbox[@formcontrolname='mddSafetyCourseDateIDoNotKnow']//label//span[@class='mat-checkbox-label']")
    this.mddSafetyCourseDateRangeError = page.locator("xpath=//mat-error[contains(text(),'The date must be between')]"); // @FindBy(xpath = "//mat-error[contains(text(),'The date must be between')]")
    this.mddMustBeInMMYYYYFormatError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + MDD_MUST_BE_MMYYYY_FORMAT + "')]")
    this.countryDropDowns = page.locator("mat-select[formcontrolname='licenseCountry']"); // @FindBy(css = "mat-select[formcontrolname='licenseCountry']")
    this.foreignDlInputField = page.locator("input[formcontrolname='countryLicenseNumber']"); // @FindBy(css = "input[formcontrolname='countryLicenseNumber']")
    this.fdlStartDateInputFields = page.locator("xpath=//input[contains(@aria-label,'Select license start')]"); // @FindBy(xpath = "//input[contains(@aria-label,'Select license start')]")
  }
}
