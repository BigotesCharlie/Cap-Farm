// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.bindpages.EcheckoutSuccessfulPageOneUI. */
export class EcheckoutSuccessfulPageOneUI extends CoreBasePage {
  public readonly paymentSuccessfulMessage: Locator;
  public readonly welcomeToFarmersMessage: Locator;
  public readonly signElectronicallyMessage: Locator;
  public readonly joiningAsAPolicyHolderMessage: Locator;
  public readonly startSigningButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.paymentSuccessfulMessage = page.locator("xpath=//div[contains(text(),"); // @FindBy(xpath = "//div[contains(text()," + PAYMENT_SUCCESSFUL + ")]")
    this.welcomeToFarmersMessage = page.locator("xpath=//h1[contains(text(),"); // @FindBy(xpath = "//h1[contains(text()," + WELCOME_TO_FARMERS + ")]")
    this.signElectronicallyMessage = page.locator("[data-legacy-field=\"signElectronicallyMessage\"]"); // @FindBy(xpath = SIGN_ELECTRONICALLY_XPATH)
    this.joiningAsAPolicyHolderMessage = page.locator("xpath=//h1[contains(text(),"); // @FindBy(xpath = "//h1[contains(text()," + JOINING_POLICY_HOLDER_MESSAGE + ")]")
    this.startSigningButton = page.locator("xpath=//button[contains(@class, 'cta-sign')]"); // @FindBy(xpath = "//button[contains(@class, 'cta-sign')]")
  }
}
