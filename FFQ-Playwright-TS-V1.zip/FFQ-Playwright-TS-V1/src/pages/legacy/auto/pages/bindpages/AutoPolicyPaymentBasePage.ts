// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.bindpages.AutoPolicyPaymentBasePage. */
export class AutoPolicyPaymentBasePage extends CoreBasePage {
  public readonly autoPolicyPaymentHeader: Locator;
  public readonly feeSideBarHeader: Locator;
  public readonly membershipFeeMessageSideBar: Locator;
  public readonly policyFeeMessageSideBar: Locator;
  public readonly vehicleFeeMessageSideBar: Locator;
  public readonly sixMonthTermPayment: Locator;
  public readonly sixTermPriceSubHeader: Locator;
  public readonly fees: Locator;
  public readonly setUpPaymentMethodButton: Locator;
  public readonly addPaymentMethodContainerCloseIcon: Locator;
  public readonly addPaymentMethodDialogContainer: Locator;
  public readonly paymentUsIframe: Locator;
  public readonly addButton: Locator;
  public readonly addPaymentMethodLabel: Locator;
  public readonly paperlessTermsOfUseLink: Locator;
  public readonly informationStorageAuthorizationLink: Locator;
  public readonly paymentAuthorizationLink: Locator;
  public readonly byClickingCompletePurchaseLabel: Locator;
  public readonly readAndAgreedToTheBulletPointOne: Locator;
  public readonly ifDoNotAgreeWithTermsAndConditionLabel: Locator;
  public readonly paymentMethodAlreadyAdded: Locator;
  public readonly readAndAgreedToTheBulletPointTwoMonthlyPay: Locator;
  public readonly readAndAgreedToTheBulletPointTwo: Locator;
  public readonly cardNumberLabel: Locator;
  public readonly expirationDateLabel: Locator;
  public readonly cardSecurityCodeLabel: Locator;
  public readonly billingZipCodeLabel: Locator;
  public readonly visaCardIconInARow: Locator;
  public readonly masterCardIconInARow: Locator;
  public readonly discoverCardIconInARow: Locator;
  public readonly amexCardIconInARow: Locator;
  public readonly nameOnCardLabel: Locator;
  public readonly nameOnCardInPutField: Locator;
  public readonly enterYourNameOnCardError: Locator;
  public readonly enterValidCardNumberError: Locator;
  public readonly enterValidExpDateError: Locator;
  public readonly enterValidCVVNumberError: Locator;
  public readonly enterValidZipNumberError: Locator;
  public readonly cardSecurityCodeInputField: Locator;
  public readonly billingZipCodeInputField: Locator;

  public constructor(page: Page) {
    super(page);
    this.autoPolicyPaymentHeader = page.locator("xpath=//h1[contains(text(), '"); // @FindBy(xpath = "//h1[contains(text(), '" + AUTO_POLICY_PAYMENT_HEADER + "')]")
    this.feeSideBarHeader = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + FEES + "')]")
    this.membershipFeeMessageSideBar = page.locator("xpath=//p[contains(text(), 'A membership fee per vehicle is applied ')]"); // @FindBy(xpath = "//p[contains(text(), 'A membership fee per vehicle is applied ')]")
    this.policyFeeMessageSideBar = page.locator("xpath=//p[contains(text(), 'A policy fee per vehicle is applied for new auto')]"); // @FindBy(xpath = "//p[contains(text(), 'A policy fee per vehicle is applied for new auto')]")
    this.vehicleFeeMessageSideBar = page.locator("xpath=//p[contains(text(), 'A fee per vehicle is applied for new auto')]"); // @FindBy(xpath = "//p[contains(text(), 'A fee per vehicle is applied for new auto')]")
    this.sixMonthTermPayment = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + SIX_MONTH_TERM_PAYMENT + "')]")
    this.sixTermPriceSubHeader = page.locator("xpath=//span[contains(text(), '6-month term price')]"); // @FindBy(xpath = "//span[contains(text(), '6-month term price')]")
    this.fees = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + FEES + "')]")
    this.setUpPaymentMethodButton = page.locator("xpath=//button[contains(text(),'"); // @FindBy(xpath = "//button[contains(text(),'" + SET_UP_PAYMENT_METHOD + "')]")
    this.addPaymentMethodContainerCloseIcon = page.locator("xpath=//mat-icon[contains(text(), 'close')]"); // @FindBy(xpath = "//mat-icon[contains(text(), 'close')]")
    this.addPaymentMethodDialogContainer = page.locator("xpath=//mat-dialog-container[@aria-labelledby='addPaymentHeading']"); // @FindBy(xpath = "//mat-dialog-container[@aria-labelledby='addPaymentHeading']")
    this.paymentUsIframe = page.locator("xpath=//iframe[@title = '"); // @FindBy(xpath = "//iframe[@title = '" + PAYMENTUS_MANAGE_PAYMENT + "']")
    this.addButton = page.locator("xpath=//button[text() = '"); // @FindBy(xpath = "//button[text() = '" + ADD_BUTTON + "']")
    this.addPaymentMethodLabel = page.locator("xpath=//span[text() = '"); // @FindBy(xpath = "//span[text() = '" + ADD_PAYMENT_METHOD_LABEL + "']")
    this.paperlessTermsOfUseLink = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]")
    this.informationStorageAuthorizationLink = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]")
    this.paymentAuthorizationLink = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + PAYMENT_AUTHORIZATION + "')]")
    this.byClickingCompletePurchaseLabel = page.locator("xpath=//div[contains(text(), '"); // @FindBy(xpath = "//div[contains(text(), '" + BY_CLICKING_COMPLETER_PURCHASE + "')]")
    this.readAndAgreedToTheBulletPointOne = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]/parent::p")
    this.ifDoNotAgreeWithTermsAndConditionLabel = page.locator("xpath=//p[contains(text(), 'If you do not agree with the Terms and Conditions above ')]"); // @FindBy(xpath = "//p[contains(text(), 'If you do not agree with the Terms and Conditions above ')]")
    this.paymentMethodAlreadyAdded = page.locator("xpath=//li[@id='profile']"); // @FindBy(xpath = "//li[@id='profile']")
    this.readAndAgreedToTheBulletPointTwoMonthlyPay = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p")
    this.readAndAgreedToTheBulletPointTwo = page.locator("xpath=//a[contains(text(), '"); // @FindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p")
    this.cardNumberLabel = page.locator("xpath=//label[text() = '"); // @FindBy(xpath = "//label[text() = '" + CARD_NUMBER_LABEL + "']")
    this.expirationDateLabel = page.locator("xpath=//label[text() = '"); // @FindBy(xpath = "//label[text() = '" + EXPIRATION_DATE_LABEL + "']")
    this.cardSecurityCodeLabel = page.locator("xpath=//label[text() = '"); // @FindBy(xpath = "//label[text() = '" + CARD_SECURITY_CODE_LABEL + "']")
    this.billingZipCodeLabel = page.locator("xpath=//label[text() = '"); // @FindBy(xpath = "//label[text() = '" + BILLING_ZIP_CODE_LABEL + "']")
    this.visaCardIconInARow = page.locator("xpath=//div[contains(@class,'methodVisa')]"); // @FindBy(xpath = "//div[contains(@class,'methodVisa')]")
    this.masterCardIconInARow = page.locator("xpath=//div[contains(@class,'methodDiscover')]"); // @FindBy(xpath = "//div[contains(@class,'methodDiscover')]")
    this.discoverCardIconInARow = page.locator("xpath=//div[contains(@class,'methodDiscover')]"); // @FindBy(xpath = "//div[contains(@class,'methodDiscover')]")
    this.amexCardIconInARow = page.locator("xpath=//div[contains(@class,'methodAmex')]"); // @FindBy(xpath = "//div[contains(@class,'methodAmex')]")
    this.nameOnCardLabel = page.locator("xpath=//label[text() = '"); // @FindBy(xpath = "//label[text() = '" + NAME_ON_CARD_LABEL + "']")
    this.nameOnCardInPutField = page.locator("xpath=//input[@id='cardHolderField']"); // @FindBy(xpath = "//input[@id='cardHolderField']")
    this.enterYourNameOnCardError = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + ENTER_YOUR_NAME_ERROR + "')]")
    this.enterValidCardNumberError = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + ENTER_VALID_CARD_NUMBER_ERROR + "')]")
    this.enterValidExpDateError = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + ENTER_VALID_EXP_DATE_ERROR + "')]")
    this.enterValidCVVNumberError = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + ENTER_VALID_CVV_NUMBER_ERROR + "')]")
    this.enterValidZipNumberError = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + ENTER_VALID_BILLING_ZIP_ERROR + "')]")
    this.cardSecurityCodeInputField = page.locator("xpath=//input[@id='cardCVVField']"); // @FindBy(xpath = "//input[@id='cardCVVField']")
    this.billingZipCodeInputField = page.locator("xpath=//input[@id='zipCode']"); // @FindBy(xpath = "//input[@id='zipCode']")
  }
}
