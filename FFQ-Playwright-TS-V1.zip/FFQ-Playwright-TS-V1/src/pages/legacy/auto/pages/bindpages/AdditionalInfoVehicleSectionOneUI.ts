// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.bindpages.AdditionalInfoVehicleSectionOneUI. */
export class AdditionalInfoVehicleSectionOneUI extends CoreBasePage {
  public readonly whenDidYouGetThisVehicleQuestion: Locator;
  public readonly lessThanTwoYearsButton: Locator;
  public readonly twoToFiveYearsAgoButton: Locator;
  public readonly aboveFiveYearsButton: Locator;
  public readonly loanCompanyParentTextBoxElementList: Locator;
  public readonly enterLoanCompanyErrorElementList: Locator;
  public readonly enterValidLoanCompanyErrorElementList: Locator;
  public readonly leasingCompanyParentTextBoxElementList: Locator;
  public readonly enterLeasingCompanyErrorElementList: Locator;
  public readonly enterValidLeasingCompanyErrorElementList: Locator;
  public readonly vinNumberTextBoxElementList: Locator;
  public readonly enterVinNumberErrorElement: Locator;
  public readonly enterValidVinErrorElement: Locator;
  public readonly vinIsNotFormattedCorrectly: Locator;
  public readonly whyDoYouNeedMyFinanceCompanyInfo: Locator;
  public readonly whyDoYouNeedMyFinanceCompanyInfoMB: Locator;
  public readonly whyDoYouNeedMyFinanceCompanyInfoExplanation: Locator;
  public readonly whereCanIFindTheVin: Locator;
  public readonly useThisGuide: Locator;
  public readonly useThisGuideText: Locator;
  public readonly howToFindVINLabel: Locator;
  public readonly driverSideDoorLabel: Locator;
  public readonly dashboardOnDriverSideDoor: Locator;
  public readonly vinHelperImg1: Locator;
  public readonly vinHelperImg2: Locator;
  public readonly vinHelperImg3: Locator;
  public readonly backToVINButton: Locator;
  public readonly backArrowIconVINPopUp: Locator;
  public readonly closeButton: Locator;
  public readonly matIconCloseButton: Locator;
  public readonly continueToPaymentButton: Locator;
  public readonly confirmYourVINLabel: Locator;
  public readonly initiallyQuotedVehicleLabel: Locator;
  public readonly newlyEnteredVehicleLabel: Locator;
  public readonly pleaseSelectLabel: Locator;
  public readonly editVINIfItIsWrong: Locator;
  public readonly vINIsCorrect: Locator;
  public readonly editVINLink: Locator;
  public readonly vinIsCorrectLink: Locator;
  public readonly vinErrorMessage: Locator;
  public readonly enterCorrectVINError: Locator;
  public readonly ninthDigitNumberOrTextError: Locator;
  public readonly vehicleLeaseOrFinanceMobileInfoIcons: Locator;
  public readonly vehicleVinMobileInfoIcons: Locator;
  public readonly leanOrLeaseInputFields: Locator;
  public readonly vinInputFields: Locator;
  public readonly registeredOwnerDropDowns: Locator;
  public readonly currentOdometerFields: Locator;
  public readonly odometerReadingDateInputFields: Locator;
  public readonly currentOdometerErrorMessage: Locator;
  public readonly odometerDateErrorMessage: Locator;
  public readonly odometerMobileInfoIcon: Locator;
  public readonly odometerInfoHeaderLabel: Locator;
  public readonly odometerInfoHeaderDescription: Locator;
  public readonly mobileInfoModalHeader: Locator;
  public readonly mobileInfoModalDesc: Locator;

  public constructor(page: Page) {
    super(page);
    this.whenDidYouGetThisVehicleQuestion = page.locator("xpath=//p[contains(text(), 'When did you get this vehicle?')]"); // @FindBy(xpath = "//p[contains(text(), 'When did you get this vehicle?')]")
    this.lessThanTwoYearsButton = page.locator("xpath=//mat-button-toggle[@value='lessThanTwo']"); // @FindBy(xpath = "//mat-button-toggle[@value='lessThanTwo']")
    this.twoToFiveYearsAgoButton = page.locator("xpath=//mat-button-toggle[@value='twoToFive']"); // @FindBy(xpath = "//mat-button-toggle[@value='twoToFive']")
    this.aboveFiveYearsButton = page.locator("xpath=//mat-button-toggle[@value='aboveFive']"); // @FindBy(xpath = "//mat-button-toggle[@value='aboveFive']")
    this.loanCompanyParentTextBoxElementList = page.locator("xpath=//mat-label[contains(text(),'Enter loan company')]"); // @FindBy(xpath = "//mat-label[contains(text(),'Enter loan company')]")
    this.enterLoanCompanyErrorElementList = page.locator("xpath=//mat-error[contains(text(), 'Please enter loan company.')]"); // @FindBy(xpath = "//mat-error[contains(text(), 'Please enter loan company.')]")
    this.enterValidLoanCompanyErrorElementList = page.locator("xpath=//mat-error[contains(text(), 'Please select a valid loan company.')]"); // @FindBy(xpath = "//mat-error[contains(text(), 'Please select a valid loan company.')]")
    this.leasingCompanyParentTextBoxElementList = page.locator("xpath=//mat-label[contains(text(),'Enter leasing company')]/ancestor::mat-form-field"); // @FindBy(xpath = "//mat-label[contains(text(),'Enter leasing company')]/ancestor::mat-form-field")
    this.enterLeasingCompanyErrorElementList = page.locator("xpath=//mat-error[contains(text(), 'Please enter leasing company.')]"); // @FindBy(xpath = "//mat-error[contains(text(), 'Please enter leasing company.')]")
    this.enterValidLeasingCompanyErrorElementList = page.locator("xpath=//mat-error[contains(text(), 'Please select a valid leasing company.')]"); // @FindBy(xpath = "//mat-error[contains(text(), 'Please select a valid leasing company.')]")
    this.vinNumberTextBoxElementList = page.locator("xpath=//input[@aria-label='Vehicle Identification Number']"); // @FindBy(xpath = "//input[@aria-label='Vehicle Identification Number']")
    this.enterVinNumberErrorElement = page.locator("xpath=//mat-error[contains(text(), 'Please enter the VIN.')]"); // @FindBy(xpath = "//mat-error[contains(text(), 'Please enter the VIN.')]")
    this.enterValidVinErrorElement = page.locator("xpath=//mat-error[contains(text(), 'Please enter a valid VIN.')]"); // @FindBy(xpath = "//mat-error[contains(text(), 'Please enter a valid VIN.')]")
    this.vinIsNotFormattedCorrectly = page.locator("xpath=//mat-error[contains(text(), 'formatted correctly.')]"); // @FindBy(xpath = "//mat-error[contains(text(), 'formatted correctly.')]")
    this.whyDoYouNeedMyFinanceCompanyInfo = page.locator("xpath=//p[contains(text(), 'Why do you need my finance company info?')]"); // @FindBy(xpath = "//p[contains(text(), 'Why do you need my finance company info?')]")
    this.whyDoYouNeedMyFinanceCompanyInfoMB = page.locator("xpath=//h1[contains(text(), 'Why do you need my finance company info?')]"); // @FindBy(xpath = "//h1[contains(text(), 'Why do you need my finance company info?')]")
    this.whyDoYouNeedMyFinanceCompanyInfoExplanation = page.locator("xpath=//p[contains(text(), 'Leasing and lending companies require us to list')]"); // @FindBy(xpath = "//p[contains(text(), 'Leasing and lending companies require us to list')]")
    this.whereCanIFindTheVin = page.locator("xpath=//p[contains(text(),'"); // @FindBy(xpath = "//p[contains(text(),'" + WHERE_CAN_I_FIND_THE_VIN + "')]")
    this.useThisGuide = page.locator("xpath=//a[contains(text(),'"); // @FindBy(xpath = "//a[contains(text(),'" + USE_THIS_GUIDE + "')]")
    this.useThisGuideText = page.locator("xpath=//a[contains(text(),'"); // @FindBy(xpath = "//a[contains(text(),'" + USE_THIS_GUIDE + "')]/parent::p")
    this.howToFindVINLabel = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + HOW_TO_FIND_THE_VIN + "')]")
    this.driverSideDoorLabel = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + USE_DRIVER_SIDE_DOOR + "')]")
    this.dashboardOnDriverSideDoor = page.locator("xpath=//p[contains(text(), '"); // @FindBy(xpath = "//p[contains(text(), '" + DASHBOARD_ON_DRIVER_SIDE_LABEL + "')]")
    this.vinHelperImg1 = page.locator("xpath=//div[@title = '"); // @FindBy(xpath = "//div[@title = '" + VIN_HELPER_IMG_1 + "']")
    this.vinHelperImg2 = page.locator("xpath=//div[@title = '"); // @FindBy(xpath = "//div[@title = '" + VIN_HELPER_IMG_2 + "']")
    this.vinHelperImg3 = page.locator("xpath=//div[@title = '"); // @FindBy(xpath = "//div[@title = '" + VIN_HELPER_IMG_3 + "']")
    this.backToVINButton = page.locator("xpath=//button[contains(text(), '"); // @FindBy(xpath = "//button[contains(text(), '" + BACK_TO_VIN + "')]")
    this.backArrowIconVINPopUp = page.locator("xpath=//mat-icon[contains(text(), '"); // @FindBy(xpath = "//mat-icon[contains(text(), '" + BACK_ARROW + "')]")
    this.closeButton = page.locator("xpath=//button[contains(text(),'"); // @FindBy(xpath = "//button[contains(text(),'" + CLOSE + "')]")
    this.matIconCloseButton = page.locator("xpath=//mat-icon[contains(text(),'close')]"); // @FindBy(xpath = "//mat-icon[contains(text(),'close')]")
    this.continueToPaymentButton = page.locator("xpath=//button[contains(text(), 'Continue')]"); // @FindBy(xpath = "//button[contains(text(), 'Continue')]")
    this.confirmYourVINLabel = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + CONFIRM_YOUR_VIN + "')]")
    this.initiallyQuotedVehicleLabel = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + INITIALLY_QUOTED_VEHICLE_LABEL + "')]")
    this.newlyEnteredVehicleLabel = page.locator("xpath=//p[contains(text(),'"); // @FindBy(xpath = "//p[contains(text(),'" + NEWLY_ENTERED_VEHICLE_LABEL + "')]")
    this.pleaseSelectLabel = page.locator("xpath=//span[contains(text(),'"); // @FindBy(xpath = "//span[contains(text(),'" + PLEASE_SELECT_LABEL + "')]")
    this.editVINIfItIsWrong = page.locator("xpath=//li[contains(text(),'wrong, or')]"); // @FindBy(xpath = "//li[contains(text(),'wrong, or')]")
    this.vINIsCorrect = page.locator("xpath=//li[contains(text(),'update your quote')]"); // @FindBy(xpath = "//li[contains(text(),'update your quote')]")
    this.editVINLink = page.locator("xpath=//a[contains(text(),'"); // @FindBy(xpath = "//a[contains(text(),'" + EDIT_VIN_LINK + "')]")
    this.vinIsCorrectLink = page.locator("xpath=//a[contains(text(),'"); // @FindBy(xpath = "//a[contains(text(),'" + VIN_IS_CORRECT_LINK + "')]")
    this.vinErrorMessage = page.locator("xpath=//div[contains(@class,'additional-info-vehicle-info-section') and contains(.,'VIN')]//mat-error"); // @FindBy(xpath = "//div[contains(@class,'additional-info-vehicle-info-section') and contains(.,'VIN')]//mat-error")
    this.enterCorrectVINError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + ENTER_CORRECT_VIN + "')]")
    this.ninthDigitNumberOrTextError = page.locator("xpath=//mat-error[contains(text(),'"); // @FindBy(xpath = "//mat-error[contains(text(),'" + NINTH_DIGIT_NUM_OR_X + "')]")
    this.vehicleLeaseOrFinanceMobileInfoIcons = page.locator("xpath=//div[contains(@class,'additional-info-vehicle-info-section')]//div[@class='col' and contains(.,'company')]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'additional-info-vehicle-info-section')]//div[@class='col' and contains(.,'company')]//mat-icon")
    this.vehicleVinMobileInfoIcons = page.locator("xpath=//div[contains(@class,'additional-info-vehicle-info-section')]//div[@class='col' and contains(.,'VIN')]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'additional-info-vehicle-info-section')]//div[@class='col' and contains(.,'VIN')]//mat-icon")
    this.leanOrLeaseInputFields = page.locator("xpath=//mat-form-field[contains(.,'company')]//input"); // @FindBy(xpath = "//mat-form-field[contains(.,'company')]//input")
    this.vinInputFields = page.locator("input[formcontrolname='vin']"); // @FindBy(css = "input[formcontrolname='vin']")
    this.registeredOwnerDropDowns = page.locator("mat-select[formcontrolname='registeredOwner']"); // @FindBy(css = "mat-select[formcontrolname='registeredOwner']")
    this.currentOdometerFields = page.locator("xpath=//mat-form-field[contains(.,'Current odometer')]//input"); // @FindBy(xpath = "//mat-form-field[contains(.,'Current odometer')]//input")
    this.odometerReadingDateInputFields = page.locator("xpath=//mat-form-field[contains(.,'Odometer reading date')]//input[not(contains(@class,'picker'))]"); // @FindBy(xpath = "//mat-form-field[contains(.,'Odometer reading date')]//input[not(contains(@class,'picker'))]")
    this.currentOdometerErrorMessage = page.locator("xpath=//div[contains(@class,'odometer') and contains(.,'Current odometer')]//mat-error"); // @FindBy(xpath = "//div[contains(@class,'odometer') and contains(.,'Current odometer')]//mat-error")
    this.odometerDateErrorMessage = page.locator("xpath=//div[contains(@class,'odometer') and contains(.,'Odometer reading')]//mat-error"); // @FindBy(xpath = "//div[contains(@class,'odometer') and contains(.,'Odometer reading')]//mat-error")
    this.odometerMobileInfoIcon = page.locator("xpath=//div[contains(@class,'odometer')]//mat-icon"); // @FindBy(xpath = "//div[contains(@class,'odometer')]//mat-icon")
    this.odometerInfoHeaderLabel = page.locator("xpath=//p[contains(.,'What is an odometer?')]"); // @FindBy(xpath = "//p[contains(.,'What is an odometer?')]")
    this.odometerInfoHeaderDescription = page.locator("xpath=//p[contains(.,'An odometer is a device')]"); // @FindBy(xpath = "//p[contains(.,'An odometer is a device')]")
    this.mobileInfoModalHeader = page.locator("h1[class='model-caption-head']"); // @FindBy(css = "h1[class='model-caption-head']")
    this.mobileInfoModalDesc = page.locator("p[class='model-caption-text']"); // @FindBy(css = "p[class='model-caption-text']")
  }
}
