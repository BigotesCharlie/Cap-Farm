// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.ContactInfoAutoPage. */
export class ContactInfoAutoPage extends CoreBasePage {
  public readonly pageHeader: Locator;
  public readonly pageHeaderNote: Locator;
  public readonly policyStartDateTitle: Locator;
  public readonly earlyShoppingBanner: Locator;
  public readonly earlyShoppingBannerHeader: Locator;
  public readonly earlyShoppingBannerDesc: Locator;
  public readonly mobileEarlyDiscountInfoIcon: Locator;
  public readonly bundleAndSaveInfoIcon: Locator;
  public readonly mobileEarlyDiscountInfoTitle: Locator;
  public readonly mobileEarlyDiscountInfoDescription: Locator;
  public readonly closeInfoDialogIcon: Locator;
  public readonly earlyDiscountInfoTitle: Locator;
  public readonly earlyDiscountInfoDescription: Locator;
  public readonly bundleSaveHelpInfoHeader: Locator;
  public readonly bundleSaveHelpInfoDescription: Locator;
  public readonly datePickerFieldLabel: Locator;
  public readonly policyStartDateInputField: Locator;
  public readonly policyStartDateInputFieldPlaceHolderText: Locator;
  public readonly policyStartDateError: Locator;
  public readonly earlyDiscountCongratulationMessage: Locator;
  public readonly datePickerToggle: Locator;
  public readonly datePickerButton: Locator;
  public readonly defaultPeriodButton: Locator;
  public readonly defaultSelectedYear: Locator;
  public readonly previousMonthButton: Locator;
  public readonly disabledPreviousMonth: Locator;
  public readonly nextMonthButton: Locator;
  public readonly disabledDaysOfMonth: Locator;
  public readonly selectableDaysOfMonth: Locator;
  public readonly selectedDayOfMonth: Locator;
  public readonly bundleSaveHeading: Locator;
  public readonly bundleSaveHeadingNote: Locator;
  public readonly saveBundleCheckboxes: Locator;
  public readonly saveBundleInputs: Locator;
  public readonly checkedBundleOptions: Locator;
  public readonly viewAdditionProductsLink: Locator;
  public readonly saveBundleCongratulationMessage: Locator;
  public readonly primaryResidenceInsuranceRadioButtons: Locator;
  public readonly primaryResidenceInsuranceRadioButtonGroup: Locator;
  public readonly mailingAddressLabel: Locator;
  public readonly defaultMailingAddressRadioButton: Locator;
  public readonly defaultMailingAddressRadioButtonLabel: Locator;
  public readonly otherMailingAddressRadioButton: Locator;
  public readonly otherMailingAddressRadioButtonLabel: Locator;
  public readonly mailingAddressInputField: Locator;
  public readonly mailingAddressInputLabel: Locator;
  public readonly mailingAddressError: Locator;
  public readonly apartmentNumberInputField: Locator;
  public readonly apartmentInputLabel: Locator;
  public readonly cityInputField: Locator;
  public readonly cityInputLabel: Locator;
  public readonly cityError: Locator;
  public readonly stateDropDown: Locator;
  public readonly stateDropDownLabel: Locator;
  public readonly stateError: Locator;
  public readonly zipCodeInputField: Locator;
  public readonly zipCodeInputLabel: Locator;
  public readonly zipCodeError: Locator;
  public readonly primaryNamedInsured: Locator;
  public readonly pniFullName: Locator;
  public readonly contactInformation: Locator;
  public readonly personalInfoLabel: Locator;
  public readonly emailAddressFieldLabel: Locator;
  public readonly emailAddressInput: Locator;
  public readonly emailAddressError: Locator;
  public readonly mobilePhoneFieldLabel: Locator;
  public readonly phoneNumberInput: Locator;
  public readonly phoneNumberError: Locator;
  public readonly esignTermsAndConditionsLink: Locator;
  public readonly chooseFromInsuranceCompaniesTitle: Locator;
  public readonly selectAllCheckbox: Locator;
  public readonly selectAllCheckboxLabel: Locator;
  public readonly chooseThemIndividuallyBelow: Locator;
  public readonly brandCheckboxes: Locator;
  public readonly brandCheckboxLabels: Locator;
  public readonly brandCheckboxLabelDescriptions: Locator;
  public readonly textMeALinkCheckboxLabel: Locator;
  public readonly textAuthorization: Locator;
  public readonly termsConditionLink: Locator;
  public readonly pageErrorMessage: Locator;
  public readonly contactEsignDisclaimer: Locator;
  public readonly contactInfoDisclaimer: Locator;
  public readonly associatedEntititesLink: Locator;
  public readonly mobileDisclaimerAddition: Locator;
  public readonly agreeAndSubmitButton: Locator;
  public readonly dontForgetMakeYourSelection: Locator;
  public readonly continueButton: Locator;
  public readonly saveQuoteButton: Locator;
  public readonly progressSavedSection: Locator;
  public readonly bristolWestLogoImage: Locator;
  public readonly rc2Screen_MainHeading: Locator;
  public readonly rc2SubHeading: Locator;
  public readonly rc2SubHeading1ForBundle: Locator;
  public readonly rc2SubHeading2ForBundle: Locator;
  public readonly rc3ScreenPageTitle: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageHeader = page.locator("xpath=//h1[contains(@class,'tui-h1')]"); // @FindBy(xpath = "//h1[contains(@class,'tui-h1')]")
    this.pageHeaderNote = page.locator("xpath=//div[contains(@class,'contact-info-heading-note')]"); // @FindBy(xpath = "//div[contains(@class,'contact-info-heading-note')]")
    this.policyStartDateTitle = page.locator("xpath=//div[contains(@class,'tooltip-section')]//p"); // @FindBy(xpath = "//div[contains(@class,'tooltip-section')]//p")
    this.earlyShoppingBanner = page.locator("xpath=//div[contains(@class,'discount-banner')]"); // @FindBy(xpath = "//div[contains(@class,'discount-banner')]")
    this.earlyShoppingBannerHeader = page.locator("xpath=//div[contains(@class,'discount-banner')]//p[@class='tui-field-label']"); // @FindBy(xpath = "//div[contains(@class,'discount-banner')]//p[@class='tui-field-label']")
    this.earlyShoppingBannerDesc = page.locator("xpath=//div[contains(@class,'discount-banner')]//p[@class='body']"); // @FindBy(xpath = "//div[contains(@class,'discount-banner')]//p[@class='body']")
    this.mobileEarlyDiscountInfoIcon = page.locator("xpath=//div[@id='policyStartDateDiv']//mat-icon"); // @FindBy(xpath = "//div[@id='policyStartDateDiv']//mat-icon")
    this.bundleAndSaveInfoIcon = page.locator("xpath=//div[@id='saveBundleDiv']//mat-icon[contains(@class,'info-box-icon')]"); // @FindBy(xpath = "//div[@id='saveBundleDiv']//mat-icon[contains(@class,'info-box-icon')]")
    this.mobileEarlyDiscountInfoTitle = page.locator("xpath=//app-model-info-box//h1"); // @FindBy(xpath = "//app-model-info-box//h1")
    this.mobileEarlyDiscountInfoDescription = page.locator("xpath=//app-model-info-box//p"); // @FindBy(xpath = "//app-model-info-box//p")
    this.closeInfoDialogIcon = page.locator("xpath=//mat-dialog-container//mat-icon[@aria-label='Close']"); // @FindBy(xpath = "//mat-dialog-container//mat-icon[@aria-label='Close']")
    this.earlyDiscountInfoTitle = page.locator("div[class='discount-info']>div"); // @FindBy(css = "div[class='discount-info']>div")
    this.earlyDiscountInfoDescription = page.locator("div[class='discount-info']>p"); // @FindBy(css = "div[class='discount-info']>p")
    this.bundleSaveHelpInfoHeader = page.locator("xpath=//div[@id='saveBundleDiv']//div[contains(@class,'tui-info-box')]//div[contains(@class,'info-box-header')]"); // @FindBy(xpath = "//div[@id='saveBundleDiv']//div[contains(@class,'tui-info-box')]//div[contains(@class,'info-box-header')]")
    this.bundleSaveHelpInfoDescription = page.locator("xpath=//div[@id='saveBundleDiv']//div[contains(@class,'tui-info-box')]//p"); // @FindBy(xpath = "//div[@id='saveBundleDiv']//div[contains(@class,'tui-info-box')]//p")
    this.datePickerFieldLabel = page.locator("xpath=//app-date-picker//mat-label"); // @FindBy(xpath = "//app-date-picker//mat-label")
    this.policyStartDateInputField = page.locator("xpath=//mat-form-field[@id='policyStartDate']//input[@matinput and not(@hidden)]"); // @FindBy(xpath = "//mat-form-field[@id='policyStartDate']//input[@matinput and not(@hidden)]")
    this.policyStartDateInputFieldPlaceHolderText = page.locator("xpath=//app-date-picker[@id='policyStartDateDiv_policyStartDate']//mat-label"); // @FindBy(xpath = "//app-date-picker[@id='policyStartDateDiv_policyStartDate']//mat-label")
    this.policyStartDateError = page.locator("xpath=//div[@id='policyStartDateDiv']//mat-error"); // @FindBy(xpath = "//div[@id='policyStartDateDiv']//mat-error")
    this.earlyDiscountCongratulationMessage = page.locator("#auto-contact-info-early-shopper-message-container>div"); // @FindBy(css = "#auto-contact-info-early-shopper-message-container>div")
    this.datePickerToggle = page.locator("xpath=//mat-datepicker-toggle"); // @FindBy(xpath = "//mat-datepicker-toggle")
    this.datePickerButton = page.locator("xpath=//mat-datepicker-toggle//button"); // @FindBy(xpath = "//mat-datepicker-toggle//button")
    this.defaultPeriodButton = page.locator("button[class='mat-focus-indicator mat-calendar-period-button mat-button mat-button-base']"); // @FindBy(css = "button[class='mat-focus-indicator mat-calendar-period-button mat-button mat-button-base']")
    this.defaultSelectedYear = page.locator("div[class='mat-calendar-body-cell-content mat-focus-indicator mat-calendar-body-selected mat-calendar-body-today']"); // @FindBy(css = "div[class='mat-calendar-body-cell-content mat-focus-indicator mat-calendar-body-selected mat-calendar-body-today']")
    this.previousMonthButton = page.locator("button[class='mat-focus-indicator mat-calendar-previous-button mat-icon-button mat-button-base']"); // @FindBy(css = "button[class='mat-focus-indicator mat-calendar-previous-button mat-icon-button mat-button-base']")
    this.disabledPreviousMonth = page.locator("button[class='mat-focus-indicator mat-calendar-previous-button mat-icon-button mat-button-base mat-button-disabled']"); // @FindBy(css = "button[class='mat-focus-indicator mat-calendar-previous-button mat-icon-button mat-button-base mat-button-disabled']")
    this.nextMonthButton = page.locator("button[class='mat-focus-indicator mat-calendar-next-button mat-icon-button mat-button-base']"); // @FindBy(css = "button[class='mat-focus-indicator mat-calendar-next-button mat-icon-button mat-button-base']")
    this.disabledDaysOfMonth = page.locator("xpath=//button[@class='mat-calendar-body-cell mat-calendar-body-disabled']//div[contains(@class,'mat-focus-indicator')]"); // @FindBy(xpath = "//button[@class='mat-calendar-body-cell mat-calendar-body-disabled']//div[contains(@class,'mat-focus-indicator')]")
    this.selectableDaysOfMonth = page.locator("xpath=//button[@class='mat-calendar-body-cell']//div[contains(@class,'indicator')]"); // @FindBy(xpath = "//button[@class='mat-calendar-body-cell']//div[contains(@class,'indicator')]")
    this.selectedDayOfMonth = page.locator("xpath=//button[@class='mat-calendar-body-cell mat-calendar-body-active']//div[contains(@class,'indicator')]"); // @FindBy(xpath = "//button[@class='mat-calendar-body-cell mat-calendar-body-active']//div[contains(@class,'indicator')]")
    this.bundleSaveHeading = page.locator("xpath=//div[@class='auto-driver-review-save-bundle-side-sheet-title']//h2"); // @FindBy(xpath = "//div[@class='auto-driver-review-save-bundle-side-sheet-title']//h2")
    this.bundleSaveHeadingNote = page.locator(".save-bundle-info-heading-note"); // @FindBy(className = "save-bundle-info-heading-note")
    this.saveBundleCheckboxes = page.locator("xpath=//div[contains(@class,'auto-driver-review-save-bundle-items')]//label/span"); // @FindBy(xpath = "//div[contains(@class,'auto-driver-review-save-bundle-items')]//label/span")
    this.saveBundleInputs = page.locator("xpath=//fieldset[@class='save-bundle-discount-sheet']//mat-checkbox//input"); // @FindBy(xpath = "//fieldset[@class='save-bundle-discount-sheet']//mat-checkbox//input")
    this.checkedBundleOptions = page.locator("xpath=//div[@class='save-bundle-discount-sheet']//mat-checkbox"); // @FindBy(xpath = "//div[@class='save-bundle-discount-sheet']//mat-checkbox")
    this.viewAdditionProductsLink = page.locator("[data-legacy-field=\"viewAdditionProductsLink\"]"); // @FindBy(xpath = VIEW_ADDITIONAL_PRODUCTS_XPATH)
    this.saveBundleCongratulationMessage = page.locator("[data-legacy-field=\"saveBundleCongratulationMessage\"]"); // @FindBy(xpath = BUNDLE_CONRATS_MESSAGE_XPATH)
    this.primaryResidenceInsuranceRadioButtons = page.locator("xpath=//mat-radio-button[contains(@id,'RADIO_BUTTON_FOR_PRIMARY_RESIDENCE')]//input"); // @FindBy(xpath = "//mat-radio-button[contains(@id,'RADIO_BUTTON_FOR_PRIMARY_RESIDENCE')]//input")
    this.primaryResidenceInsuranceRadioButtonGroup = page.locator("xpath=//div[contains(@class,'contact_info_primary_residence')]//mat-radio-group"); // @FindBy(xpath = "//div[contains(@class,'contact_info_primary_residence')]//mat-radio-group")
    this.mailingAddressLabel = page.locator("#mailingAddressDiv>div>h2"); // @FindBy(css = "#mailingAddressDiv>div>h2")
    this.defaultMailingAddressRadioButton = page.locator("xpath=//mat-radio-button[1]"); // @FindBy(xpath = "//mat-radio-button[1]")
    this.defaultMailingAddressRadioButtonLabel = page.locator("xpath=//mat-radio-button[@id='mailingAddressDiv_1']//label"); // @FindBy(xpath = "//mat-radio-button[@id='mailingAddressDiv_1']//label")
    this.otherMailingAddressRadioButton = page.locator("[data-legacy-field=\"otherMailingAddressRadioButton\"]"); // @FindBy(xpath = OTHER_MAILING_ADDRESS_RADIO_BUTTON_XPATH)
    this.otherMailingAddressRadioButtonLabel = page.locator("xpath=//mat-radio-button[contains(.,'Other mailing address')]"); // @FindBy(xpath = "//mat-radio-button[contains(.,'Other mailing address')]")
    this.mailingAddressInputField = page.locator("input[aria-label='Mailing Address']"); // @FindBy(css = "input[aria-label='Mailing Address']")
    this.mailingAddressInputLabel = page.locator("xpath=//div[@id='formField_address']//mat-label"); // @FindBy(xpath = "//div[@id='formField_address']//mat-label")
    this.mailingAddressError = page.locator("xpath=//div[@id='formField_address']//mat-error"); // @FindBy(xpath = "//div[@id='formField_address']//mat-error")
    this.apartmentNumberInputField = page.locator("input[aria-label='Apartment number (optional)']"); // @FindBy(css = "input[aria-label='Apartment number (optional)']")
    this.apartmentInputLabel = page.locator("xpath=//div[@id='mailingAddressDiv_apartment']//mat-label"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_apartment']//mat-label")
    this.cityInputField = page.locator("input[aria-label='City']"); // @FindBy(css = "input[aria-label='City']")
    this.cityInputLabel = page.locator("xpath=//div[@id='mailingAddressDiv_city']//mat-label"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_city']//mat-label")
    this.cityError = page.locator("xpath=//div[@id='mailingAddressDiv_city']//mat-error"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_city']//mat-error")
    this.stateDropDown = page.locator("mat-select[aria-label='State']"); // @FindBy(css = "mat-select[aria-label='State']")
    this.stateDropDownLabel = page.locator("xpath=//div[@id='mailingAddressDiv_state']//mat-label"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-label")
    this.stateError = page.locator("xpath=//div[@id='mailingAddressDiv_state']//mat-error/div"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-error/div")
    this.zipCodeInputField = page.locator("input[aria-label='Zip code']"); // @FindBy(css = "input[aria-label='Zip code']")
    this.zipCodeInputLabel = page.locator("xpath=//div[@id='mailingAddressDiv_zipCode']//mat-label"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//mat-label")
    this.zipCodeError = page.locator("xpath=//div[@id='mailingAddressDiv_zipCode']//mat-error/div"); // @FindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//mat-error/div")
    this.primaryNamedInsured = page.locator("p[class='tui-field-label-text mb-2']"); // @FindBy(css = "p[class='tui-field-label-text mb-2']")
    this.pniFullName = page.locator("xpath=//div[@class='auto-personal-info__fields-section']//li"); // @FindBy(xpath = "//div[@class='auto-personal-info__fields-section']//li")
    this.contactInformation = page.locator("xpath=//p[contains(.,'Contact information')]"); // @FindBy(xpath = "//p[contains(.,'Contact information')]")
    this.personalInfoLabel = page.locator("xpath=//div[@id='flex-field-emailAddress_contactInfo']/p"); // @FindBy(xpath = "//div[@id='flex-field-emailAddress_contactInfo']/p")
    this.emailAddressFieldLabel = page.locator("xpath=//div[@class='email-address']//label"); // @FindBy(xpath = "//div[@class='email-address']//label")
    this.emailAddressInput = page.locator("[data-legacy-field=\"emailAddressInput\"]"); // @FindBy(xpath = EMAIL_ADDRESS_INPUT_FIELD_XPATH)
    this.emailAddressError = page.locator("xpath=//div[@id='flex-field-emailAddress_contactInfo']//mat-error"); // @FindBy(xpath = "//div[@id='flex-field-emailAddress_contactInfo']//mat-error")
    this.mobilePhoneFieldLabel = page.locator("xpath=//div[@id='flex-field-phoneNumber_contactInfo']//label"); // @FindBy(xpath = "//div[@id='flex-field-phoneNumber_contactInfo']//label")
    this.phoneNumberInput = page.locator("xpath=//div[@id='flex-field-phoneNumber_contactInfo']//input"); // @FindBy(xpath = "//div[@id='flex-field-phoneNumber_contactInfo']//input")
    this.phoneNumberError = page.locator("xpath=//div[@id='flex-field-phoneNumber_contactInfo']//mat-error"); // @FindBy(xpath = "//div[@id='flex-field-phoneNumber_contactInfo']//mat-error")
    this.esignTermsAndConditionsLink = page.locator("xpath=//a[contains(.,'ESIGN')]"); // @FindBy(xpath = "//a[contains(.,'ESIGN')]")
    this.chooseFromInsuranceCompaniesTitle = page.locator("div[class='brand-selection']>p[class='tui-field-label']"); // @FindBy(css = "div[class='brand-selection']>p[class='tui-field-label']")
    this.selectAllCheckbox = page.locator("xpath=//mat-checkbox[contains(@class,'mat-checkbox tui-stacking')]"); // @FindBy(xpath = "//mat-checkbox[contains(@class,'mat-checkbox tui-stacking')]")
    this.selectAllCheckboxLabel = page.locator("xpath=//mat-label[contains(@class,'tui-field-label brand-label tui-stacking')]"); // @FindBy(xpath = "//mat-label[contains(@class,'tui-field-label brand-label tui-stacking')]")
    this.chooseThemIndividuallyBelow = page.locator("div[class='brand-selection']>p[class='tui-small-text checkbox-description']"); // @FindBy(css = "div[class='brand-selection']>p[class='tui-small-text checkbox-description']")
    this.brandCheckboxes = page.locator("xpath=//div[@class='tui-stacking-top-sm ms-8 ng-star-inserted']//mat-checkbox"); // @FindBy(xpath = "//div[@class='tui-stacking-top-sm ms-8 ng-star-inserted']//mat-checkbox")
    this.brandCheckboxLabels = page.locator("xpath=//div[@class='tui-stacking-top-sm ms-8 ng-star-inserted']//mat-label"); // @FindBy(xpath = "//div[@class='tui-stacking-top-sm ms-8 ng-star-inserted']//mat-label")
    this.brandCheckboxLabelDescriptions = page.locator("xpath=//div[@class='tui-stacking-top-sm ms-8 ng-star-inserted']//p"); // @FindBy(xpath = "//div[@class='tui-stacking-top-sm ms-8 ng-star-inserted']//p")
    this.textMeALinkCheckboxLabel = page.locator("xpath=//span[contains(.,'Text me a link')]"); // @FindBy(xpath = "//span[contains(.,'Text me a link')]")
    this.textAuthorization = page.locator("xpath=//mat-checkbox/following-sibling::p"); // @FindBy(xpath = "//mat-checkbox/following-sibling::p")
    this.termsConditionLink = page.locator("xpath=//p[contains(.,'terms')]/a"); // @FindBy(xpath = "//p[contains(.,'terms')]/a")
    this.pageErrorMessage = page.locator("xpath=//div[contains(@class,'contact-info-cta-validation')]"); // @FindBy(xpath = "//div[contains(@class,'contact-info-cta-validation')]")
    this.contactEsignDisclaimer = page.locator("span[class='contactEsignDisclaimer']"); // @FindBy(css = "span[class='contactEsignDisclaimer']")
    this.contactInfoDisclaimer = page.locator("p:has(span[class='contactInfoDisclaimer'])"); // @FindBy(css = "p:has(span[class='contactInfoDisclaimer'])")
    this.associatedEntititesLink = page.locator("xpath=//a[contains(.,'associated')]"); // @FindBy(xpath = "//a[contains(.,'associated')]")
    this.mobileDisclaimerAddition = page.locator("xpath=//p[contains(@class,'consent-disclaimer disclaimer-mobile-view-Margin')]/span[1]"); // @FindBy(xpath = "//p[contains(@class,'consent-disclaimer disclaimer-mobile-view-Margin')]/span[1]")
    this.agreeAndSubmitButton = page.locator("xpath=//button[contains(@class,'tui-btn tui-btn-primary submit-button')]"); // @FindBy(xpath = "//button[contains(@class,'tui-btn tui-btn-primary submit-button')]")
    this.dontForgetMakeYourSelection = page.locator("xpath=//span[contains(.,'forget to make your selection(s).')]"); // @FindBy(xpath = "//span[contains(.,'forget to make your selection(s).')]")
    this.continueButton = page.locator("xpath=//button[contains(@class,'tui-btn tui-btn-primary continue-button')]"); // @FindBy(xpath = "//button[contains(@class,'tui-btn tui-btn-primary continue-button')]")
    this.saveQuoteButton = page.locator("button[class='auto-agent-details__save-link tui-link-button']"); // @FindBy(css = "button[class='auto-agent-details__save-link tui-link-button']")
    this.progressSavedSection = page.locator("xpath=//div[contains(@class,'save-in-progress-section')]/p"); // @FindBy(xpath = "//div[contains(@class,'save-in-progress-section')]/p")
    this.bristolWestLogoImage = page.locator("xpath=//img[@alt='Bristol West logo' and contains(@src,'svg')]"); // @FindBy(xpath = "//img[@alt='Bristol West logo' and contains(@src,'svg')]")
    this.rc2Screen_MainHeading = page.locator("xpath=//app-rc2-loading//h1"); // @FindBy(xpath = "//app-rc2-loading//h1")
    this.rc2SubHeading = page.locator("xpath=//app-rc2-loading//div[contains(.,'Based on the information')]"); // @FindBy(xpath = "//app-rc2-loading//div[contains(.,'Based on the information')]")
    this.rc2SubHeading1ForBundle = page.locator("xpath=//*[contains(text(), 'reviewing your auto details now, then getting questions ready for your property policy.')]"); // @FindBy(xpath = "//*[contains(text(), 'reviewing your auto details now, then getting questions ready for your property policy.')]")
    this.rc2SubHeading2ForBundle = page.locator("xpath=//*[contains(text(), 'Based on the information you provided and your current coverage,')]"); // @FindBy(xpath = "//*[contains(text(), 'Based on the information you provided and your current coverage,')]")
    this.rc3ScreenPageTitle = page.locator("xpath=//app-rc3-loading//h1"); // @FindBy(xpath = "//app-rc3-loading//h1")
  }
}
