// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.HeaderAndFooter. */
export class HeaderAndFooter extends CoreBasePage {
  public readonly famersHeaderLogo: Locator;
  public readonly logoElementsInHeader: Locator;
  public readonly koHeaderFarmersLogo: Locator;
  public readonly listOfDesktopSteps: Locator;
  public readonly listOfMobileSteps: Locator;
  public readonly phoneIcon: Locator;
  public readonly farmersPhoneNumber: Locator;
  public readonly famersDesktopFooterLogo: Locator;
  public readonly listOfDesktopFooterLinks: Locator;
  public readonly desktopFooterDisclaimer: Locator;
  public readonly mobileFooterDisclaimer: Locator;
  public readonly desktopCopyright: Locator;
  public readonly mobileCopyright: Locator;
  public readonly listOfExternalLinks: Locator;

  public constructor(page: Page) {
    super(page);
    this.famersHeaderLogo = page.locator("[data-legacy-field=\"famersHeaderLogo\"]"); // @FindBy(xpath = FARMERS_LOGO_XPATH)
    this.logoElementsInHeader = page.locator("xpath=//app-basic-header//img"); // @FindBy(xpath = "//app-basic-header//img")
    this.koHeaderFarmersLogo = page.locator("xpath=//app-basic-header//img[@alt='Farmers logo']"); // @FindBy(xpath = "//app-basic-header//img[@alt='Farmers logo']")
    this.listOfDesktopSteps = page.locator("xpath=//div[@class='tui-desktop-nav-stepper']//span[2]"); // @FindBy(xpath = "//div[@class='tui-desktop-nav-stepper']//span[2]")
    this.listOfMobileSteps = page.locator("xpath=//div[@class='tui-mobile-nav-stepper']//span[2]"); // @FindBy(xpath = "//div[@class='tui-mobile-nav-stepper']//span[2]")
    this.phoneIcon = page.locator("[data-legacy-field=\"phoneIcon\"]"); // @FindBy(xpath = PHONE_NUMBER_GROUP_XPATH + "//mat-icon")
    this.farmersPhoneNumber = page.locator("[data-legacy-field=\"farmersPhoneNumber\"]"); // @FindBy(xpath = PHONE_NUMBER_GROUP_XPATH + "//span")
    this.famersDesktopFooterLogo = page.locator("[data-legacy-field=\"famersDesktopFooterLogo\"]"); // @FindBy(xpath = DESKTOP_FOOTER_GROUP_XPATH + "//img[@alt='Farmers logo']")
    this.listOfDesktopFooterLinks = page.locator("xpath=//div[@class='tui-oneui-footer-links']//a"); // @FindBy(xpath = "//div[@class='tui-oneui-footer-links']//a")
    this.desktopFooterDisclaimer = page.locator("xpath=//div[contains(@class,'footer-disclaimer-container tui')]"); // @FindBy(xpath = "//div[contains(@class,'footer-disclaimer-container tui')]")
    this.mobileFooterDisclaimer = page.locator("xpath=//div[contains(@class,'footer-disclaimer-container-mobile')]"); // @FindBy(xpath = "//div[contains(@class,'footer-disclaimer-container-mobile')]")
    this.desktopCopyright = page.locator("xpath=//div[contains(@class, 'tui-oneui-footer-copyright') and not(contains(@class, 'mobile'))]"); // @FindBy(xpath = "//div[contains(@class, 'tui-oneui-footer-copyright') and not(contains(@class, 'mobile'))]")
    this.mobileCopyright = page.locator("xpath=//div[@class='tui-oneui-footer-copyright-mobile tui-link-text-3']"); // @FindBy(xpath = "//div[@class='tui-oneui-footer-copyright-mobile tui-link-text-3']")
    this.listOfExternalLinks = page.locator("xpath=//div[@class='tui-oneui-footer-socials-and-downloads-container']/a"); // @FindBy(xpath = "//div[@class='tui-oneui-footer-socials-and-downloads-container']/a")
  }
}
