// Generated locator migration from Selenium @FindBy declarations.
import type { Locator, Page } from '@playwright/test';
import { BasePage as CoreBasePage } from "../../../../core/BasePage.js";

/** Legacy POM: com.farmers.ffq.auto.pages.AutoRentersBundleOfferingPage. */
export class AutoRentersBundleOfferingPage extends CoreBasePage {
  public readonly autoRentersBundleOfferingPageTitle: Locator;
  public readonly autoRentersBundleOfferingPageDescription: Locator;
  public readonly autoRentersBundleCarAndCouchIcon: Locator;
  public readonly autoRentersBundleCardDescription: Locator;
  public readonly autoRentersBundleCard6MonthTermText: Locator;
  public readonly autoRentersBundleCardPremium: Locator;
  public readonly autoRentersBundleCardComparisonText: Locator;
  public readonly addRentersDiscountButton: Locator;
  public readonly onlyAutoCardCarIcon: Locator;
  public readonly justAutoText: Locator;
  public readonly autoMonolinePremiumAmount: Locator;
  public readonly estimatedText: Locator;
  public readonly continueWithAutoOnlyButton: Locator;
  public readonly rentersDiscountDialog: Locator;
  public readonly rentersDiscountDialogHeader: Locator;
  public readonly rentersDiscountDialogContent: Locator;
  public readonly yesContinueButton: Locator;
  public readonly noRemoveDiscountLink: Locator;
  public readonly noRentersDiscountDialog: Locator;
  public readonly noRentersDiscountDialogHeader: Locator;
  public readonly noRentersDiscountDialogContent: Locator;
  public readonly letsAddDiscountButton: Locator;
  public readonly continueWithoutDiscountButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.autoRentersBundleOfferingPageTitle = page.locator("xpath=//app-auto-renters-bundle-offering//h1"); // @FindBy(xpath = "//app-auto-renters-bundle-offering//h1")
    this.autoRentersBundleOfferingPageDescription = page.locator("div[class='title-description']"); // @FindBy(css = "div[class='title-description']")
    this.autoRentersBundleCarAndCouchIcon = page.locator("xpath=//mat-card[contains(.,'Add renters')]//img[contains(@class,'rebrand-card-bundle-icon')]"); // @FindBy(xpath = "//mat-card[contains(.,'Add renters')]//img[contains(@class,'rebrand-card-bundle-icon')]")
    this.autoRentersBundleCardDescription = page.locator("xpath=//mat-card[contains(.,'Add renters')]//p[contains(@class,'tui-input-text tui-input-text-mobile')]"); // @FindBy(xpath = "//mat-card[contains(.,'Add renters')]//p[contains(@class,'tui-input-text tui-input-text-mobile')]")
    this.autoRentersBundleCard6MonthTermText = page.locator("xpath=//mat-card[contains(.,'Add renters')]//p[contains(@class,'tui-h3 semi-bold')]"); // @FindBy(xpath = "//mat-card[contains(.,'Add renters')]//p[contains(@class,'tui-h3 semi-bold')]")
    this.autoRentersBundleCardPremium = page.locator("xpath=//mat-card[contains(.,'Add renters')]//div[contains(@class,'pricing')]"); // @FindBy(xpath = "//mat-card[contains(.,'Add renters')]//div[contains(@class,'pricing')]")
    this.autoRentersBundleCardComparisonText = page.locator("xpath=//mat-card[contains(.,'Add renters')]//p[contains(@class,'comparison-text tui-input-text')]"); // @FindBy(xpath = "//mat-card[contains(.,'Add renters')]//p[contains(@class,'comparison-text tui-input-text')]")
    this.addRentersDiscountButton = page.locator("xpath=//button[contains(.,'Add renters discount')]"); // @FindBy(xpath = "//button[contains(.,'Add renters discount')]")
    this.onlyAutoCardCarIcon = page.locator("xpath=//img[contains(@class,'rebrand-card-icon')]"); // @FindBy(xpath = "//img[contains(@class,'rebrand-card-icon')]")
    this.justAutoText = page.locator("xpath=//mat-card[contains(.,'Continue with auto')]//p[@class='tui-input-text']"); // @FindBy(xpath = "//mat-card[contains(.,'Continue with auto')]//p[@class='tui-input-text']")
    this.autoMonolinePremiumAmount = page.locator("xpath=//mat-card[contains(.,'Continue with auto')]//div[@class='pricing']"); // @FindBy(xpath = "//mat-card[contains(.,'Continue with auto')]//div[@class='pricing']")
    this.estimatedText = page.locator("xpath=//mat-card[contains(.,'Continue with auto')]//p[@class='estimated-text']"); // @FindBy(xpath = "//mat-card[contains(.,'Continue with auto')]//p[@class='estimated-text']")
    this.continueWithAutoOnlyButton = page.locator("xpath=//button[contains(.,'Continue with auto')]"); // @FindBy(xpath = "//button[contains(.,'Continue with auto')]")
    this.rentersDiscountDialog = page.locator("#rentersDiscountDialog"); // @FindBy(id = "rentersDiscountDialog")
    this.rentersDiscountDialogHeader = page.locator("xpath=//mat-dialog-container[@id='rentersDiscountDialog']//h1"); // @FindBy(xpath = "//mat-dialog-container[@id='rentersDiscountDialog']//h1")
    this.rentersDiscountDialogContent = page.locator("xpath=//mat-dialog-container[@id='rentersDiscountDialog']//mat-dialog-content"); // @FindBy(xpath = "//mat-dialog-container[@id='rentersDiscountDialog']//mat-dialog-content")
    this.yesContinueButton = page.locator("xpath=//mat-dialog-container[@id='rentersDiscountDialog']//button"); // @FindBy(xpath = "//mat-dialog-container[@id='rentersDiscountDialog']//button")
    this.noRemoveDiscountLink = page.locator("xpath=//mat-dialog-container[@id='rentersDiscountDialog']//a"); // @FindBy(xpath = "//mat-dialog-container[@id='rentersDiscountDialog']//a")
    this.noRentersDiscountDialog = page.locator("#autoDiscountDialog"); // @FindBy(id = "autoDiscountDialog")
    this.noRentersDiscountDialogHeader = page.locator("xpath=//mat-dialog-container[@id='autoDiscountDialog']//h1"); // @FindBy(xpath = "//mat-dialog-container[@id='autoDiscountDialog']//h1")
    this.noRentersDiscountDialogContent = page.locator("xpath=//mat-dialog-container[@id='autoDiscountDialog']//mat-dialog-content"); // @FindBy(xpath = "//mat-dialog-container[@id='autoDiscountDialog']//mat-dialog-content")
    this.letsAddDiscountButton = page.locator("xpath=//mat-dialog-container[@id='autoDiscountDialog']//button"); // @FindBy(xpath = "//mat-dialog-container[@id='autoDiscountDialog']//button")
    this.continueWithoutDiscountButton = page.locator("xpath=//mat-dialog-container[@id='autoDiscountDialog']//a"); // @FindBy(xpath = "//mat-dialog-container[@id='autoDiscountDialog']//a")
  }
}
