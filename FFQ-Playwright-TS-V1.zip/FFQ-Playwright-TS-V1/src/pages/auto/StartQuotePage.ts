import { type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';

export class StartQuotePage extends BasePage {
  private readonly newQuoteTab: Locator;
  private readonly newQuoteTabByGtm: Locator;
  private readonly cookieRejectButton: Locator;
  private readonly cookieAcceptButton: Locator;
  private readonly autoCardOption: Locator;
  private readonly autoCardOptionByGtm: Locator;
  private readonly autoCardTextOption: Locator;
  private readonly modernZipCode: Locator;
  private readonly modernStartQuoteButton: Locator;
  private readonly lineOfBusiness: Locator;
  private readonly autoOption: Locator;
  private readonly zipCode: Locator;
  private readonly startQuoteButton: Locator;
  private readonly legacyDropdownArrow: Locator;
  private readonly legacyAutoOption: Locator;
  private readonly legacyZipCode: Locator;
  private readonly legacyStartQuoteButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.newQuoteTab = page.getByRole('tab', { name: /get a new quote/i }).first();
    this.newQuoteTabByGtm = page.locator('[data-gtm="FFQ_Auto_Landing_Newquote_toggle"]').first();
    this.cookieRejectButton = page.getByRole('button', { name: /reject/i }).first();
    this.cookieAcceptButton = page.getByRole('button', { name: /accept/i }).first();
    this.autoCardOption = page.locator('mat-list-option[value="auto"]').first();
    this.autoCardOptionByGtm = page.locator('[data-gtm="FFQ_Auto_Landing_Newquote_Auto_link"]').first();
    this.autoCardTextOption = page.getByText('Auto', { exact: true }).first();
    this.modernZipCode = page.locator('input#removeLastpass').first();
    this.modernStartQuoteButton = page
      .locator('button[data-gtm="FFQ_Auto_Landing_Newquote_Startmyquote_button"]')
      .first();
    this.lineOfBusiness = page.getByRole('combobox').first();
    this.autoOption = page.getByRole('option', { name: 'Auto', exact: true });
    this.zipCode = page.getByRole('textbox', { name: /zip code/i }).first();
    this.startQuoteButton = page.getByRole('button', { name: /start my quote|start quote/i }).first();
    this.legacyDropdownArrow = page.locator('div.mat-select-arrow-wrapper').first();
    this.legacyAutoOption = page.getByRole('option', { name: 'Auto', exact: true }).first();
    this.legacyZipCode = page.locator('input[formcontrolname]').first();
    this.legacyStartQuoteButton = page.getByRole('button', { name: 'START QUOTE', exact: true }).first();
  }

  public async goto(): Promise<void> {
    await this.open('');
  }

  public async startQuote(zipCode: string): Promise<void> {
    const normalizedZip = this.normalizeZip(zipCode);

    if (await this.cookieRejectButton.isVisible().catch(() => false)) {
      await this.cookieRejectButton.click();
    } else if (await this.cookieAcceptButton.isVisible().catch(() => false)) {
      await this.cookieAcceptButton.click();
    }

    const newQuoteTab = (await this.newQuoteTabByGtm.isVisible({ timeout: 2_000 }).catch(() => false))
      ? this.newQuoteTabByGtm
      : this.newQuoteTab;
    if (await newQuoteTab.isVisible().catch(() => false)) {
      const isSelected = ((await newQuoteTab.getAttribute('aria-selected')) ?? '').toLowerCase() === 'true';
      if (!isSelected) {
        await newQuoteTab.click();
        await this.page.waitForLoadState('domcontentloaded');
      }
    }

    const modernAutoOption = await this.resolveModernAutoOption();
    const modernAutoVisible = modernAutoOption !== null;
    if (modernAutoVisible && modernAutoOption) {
      await this.selectModernAutoOption(modernAutoOption);
    }

    const lob = (await this.lineOfBusiness.isVisible().catch(() => false))
      ? this.lineOfBusiness
      : this.legacyDropdownArrow;
    if (!modernAutoVisible) {
      await this.click(lob);
    }

    const auto = (await this.autoOption.isVisible().catch(() => false)) ? this.autoOption : this.legacyAutoOption;
    if (!modernAutoVisible) {
      await this.click(auto);
    }

    const zip = (await this.modernZipCode.isVisible().catch(() => false))
      ? this.modernZipCode
      : (await this.zipCode.isVisible().catch(() => false))
        ? this.zipCode
        : this.legacyZipCode;
    await this.fill(zip, normalizedZip);

    if ((await zip.inputValue().catch(() => '')).trim() === '') {
      await zip.click();
      await zip.type(normalizedZip);
    }

    const start = (await this.modernStartQuoteButton.isVisible().catch(() => false))
      ? this.modernStartQuoteButton
      : (await this.startQuoteButton.isVisible().catch(() => false))
        ? this.startQuoteButton
        : this.legacyStartQuoteButton;
    await this.click(start);
  }

  private async resolveModernAutoOption(): Promise<Locator | null> {
    const candidates = [this.autoCardOptionByGtm, this.autoCardOption, this.autoOption, this.autoCardTextOption];
    for (const candidate of candidates) {
      if (await candidate.isVisible({ timeout: 2_000 }).catch(() => false)) {
        return candidate;
      }
    }
    return null;
  }

  private async selectModernAutoOption(option: Locator): Promise<void> {
    const selectedAuto = this.page.locator('mat-list-option[value="auto"][aria-selected="true"]').first();
    if (await selectedAuto.isVisible({ timeout: 500 }).catch(() => false)) return;

    for (let attempt = 0; attempt < 3; attempt += 1) {
      await option.click({ force: true });
      if (await selectedAuto.isVisible({ timeout: 1_000 }).catch(() => false)) return;
      if (await this.autoCardTextOption.isVisible({ timeout: 500 }).catch(() => false)) {
        await this.autoCardTextOption.click({ force: true });
      }
      if (await selectedAuto.isVisible({ timeout: 1_000 }).catch(() => false)) return;
    }

    throw new Error('Unable to select Auto product on Start Quote page.');
  }

  private normalizeZip(zipCode: string): string {
    const digits = zipCode.replace(/\D/g, '').slice(0, 5);
    if (digits.length !== 5) {
      throw new Error(`Invalid or missing ZIP for start quote: "${zipCode}"`);
    }
    return digits;
  }
}
