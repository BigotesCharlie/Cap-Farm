import { type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';

export class StartQuotePage extends BasePage {
  private readonly lineOfBusiness: Locator;
  private readonly autoOption: Locator;
  private readonly zipCode: Locator;
  private readonly startQuoteButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.lineOfBusiness = page.getByRole('combobox').first();
    this.autoOption = page.getByRole('option', { name: 'Auto', exact: true });
    this.zipCode = page.getByRole('textbox', { name: /zip code/i });
    this.startQuoteButton = page.getByRole('button', { name: /start quote/i });
  }

  public async goto(): Promise<void> {
    await this.open('');
  }

  public async startQuote(zipCode: string): Promise<void> {
    await this.click(this.lineOfBusiness);
    await this.click(this.autoOption);
    await this.fill(this.zipCode, zipCode);
    await this.click(this.startQuoteButton);
  }
}
