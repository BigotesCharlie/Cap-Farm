import { promises as fs } from 'node:fs';
import type { Locator, Page, TestInfo } from '@playwright/test';
import { env } from '../config/env.js';

type RecoveryKind = 'knockout' | 'inconvenience' | 'try-again';

interface RecoveryTarget {
  readonly kind: RecoveryKind;
  readonly marker: Locator;
  readonly action: Locator;
}

export class RecoveryGuard {
  private stopped = false;
  private attempts = 0;
  private failure: Error | undefined;
  private loop: Promise<void> | undefined;

  public constructor(
    private readonly page: Page,
    private readonly testInfo: TestInfo,
  ) {}

  public start(): void {
    this.loop = this.monitor();
  }

  public async stop(): Promise<void> {
    this.stopped = true;
    await this.loop;
    if (this.failure) throw this.failure;
  }

  private targets(): readonly RecoveryTarget[] {
    return [
      {
        kind: 'try-again',
        marker: this.page.getByText(/try again/i).first(),
        action: this.page.getByRole('button', { name: /try again/i }).first(),
      },
      {
        kind: 'inconvenience',
        marker: this.page.getByText(/sorry for the inconvenience|inconvenience/i).first(),
        action: this.page.getByRole('button', { name: /try again|continue|restart/i }).first(),
      },
      {
        kind: 'knockout',
        marker: this.page.getByText(/unable to continue|cannot continue|call.*quote/i).first(),
        action: this.page.getByRole('button', { name: /try again|start over|continue/i }).first(),
      },
    ];
  }

  private async monitor(): Promise<void> {
    while (!this.stopped) {
      try {
        if (!this.page.isClosed()) await this.recoverIfPresent();
      } catch (error) {
        this.failure = error instanceof Error ? error : new Error(String(error));
        this.stopped = true;
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, env.RECOVERY_POLL_INTERVAL_MS));
    }
  }

  private async recoverIfPresent(): Promise<void> {
    for (const target of this.targets()) {
      if (!(await target.marker.isVisible({ timeout: 100 }).catch(() => false))) continue;
      if (this.attempts >= env.RECOVERY_MAX_ATTEMPTS) {
        throw new Error(
          `Recovery limit (${env.RECOVERY_MAX_ATTEMPTS}) exceeded after detecting ${target.kind}.`,
        );
      }
      this.attempts += 1;
      await this.capture(target.kind);
      if (await target.action.isVisible({ timeout: 500 }).catch(() => false)) {
        await target.action.click();
        await this.page.waitForLoadState('domcontentloaded').catch(() => undefined);
      } else {
        await this.page.reload({ waitUntil: 'domcontentloaded' });
      }
      return;
    }
  }

  private async capture(kind: RecoveryKind): Promise<void> {
    const prefix = `recovery-${this.attempts}-${kind}`;
    await this.page.screenshot({
      path: this.testInfo.outputPath(`${prefix}.png`),
      fullPage: true,
    });
    await fs.writeFile(
      this.testInfo.outputPath(`${prefix}.html`),
      await this.page.content(),
      'utf8',
    );
    await fs.writeFile(
      this.testInfo.outputPath(`${prefix}.json`),
      JSON.stringify(
        {
          kind,
          attempt: this.attempts,
          url: this.page.url(),
          title: await this.page.title().catch(() => ''),
          timestamp: new Date().toISOString(),
        },
        null,
        2,
      ),
      'utf8',
    );
  }
}
