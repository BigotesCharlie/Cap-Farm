import { promises as fs } from 'node:fs';
import { test, type ConsoleMessage, type Page, type Request, type TestInfo } from '@playwright/test';
import { RecoveryGuard, type RecoveryKind } from './RecoveryGuard.js';

type Event = Readonly<{ at: string; kind: string; detail: string; checkpoint: string }>;

/** Per-test Sentinel. A scenario needs observable steps and a verified outcome to PASS. */
export class HealthCheck {
  private readonly events: Event[] = [];
  private stepCount = 0;
  private outcomeVerified = false;
  private checkpoint = 'setup';

  public constructor(
    private readonly page: Page,
    private readonly testInfo: TestInfo,
    private readonly recovery: RecoveryGuard,
  ) {}

  private readonly onPageError = (error: Error): void => this.record('pageerror', error.message);
  private readonly onRequestFailed = (request: Request): void =>
    this.record('requestfailed', `${request.method()} ${request.url()}: ${request.failure()?.errorText ?? 'unknown'}`);
  private readonly onConsole = (message: ConsoleMessage): void => {
    if (message.type() === 'error') this.record('console-error', message.text());
  };

  public start(): void {
    this.page.on('pageerror', this.onPageError);
    this.page.on('requestfailed', this.onRequestFailed);
    this.page.on('console', this.onConsole);
  }

  /** One observable screen transition. Capture the DOM after each step and on failure. */
  public async step<T>(label: string, action: () => Promise<T>, verify?: () => Promise<void>): Promise<T> {
    return test.step(label, async () => {
      this.checkpoint = label;
      await this.recovery.checkpoint(`before ${label}`);
      try {
        const result = await action();
        await this.recovery.checkpoint(`after ${label}`);
        if (verify) await verify();
        this.stepCount += 1;
        await this.capture(`step-${this.stepCount}`);
        return result;
      } catch (error) {
        this.record('step-failure', error instanceof Error ? error.message : String(error));
        await this.capture(`failure-${this.stepCount + 1}`).catch(() => undefined);
        throw error;
      }
    });
  }

  /** Call only after the scenario's own final UI assertions pass. */
  public async verifyOutcome(label: string, assertion: () => Promise<void>): Promise<void> {
    await this.step(label, async () => {
      await assertion();
    });
    this.outcomeVerified = true;
  }

  /** Expected KnockOut/Inconvenience/TryAgain still requires an explicit assertion. */
  public async verifyTerminal(kind: RecoveryKind, assertion: () => Promise<void>): Promise<void> {
    this.recovery.expectTerminal(kind);
    await this.step(`expected-${kind}`, async () => {
      await this.recovery.checkpoint(`expected ${kind}`);
      this.recovery.assertExpectedTerminal(kind);
      await assertion();
    });
    this.outcomeVerified = true;
  }

  public async stop(): Promise<void> {
    this.page.off('pageerror', this.onPageError);
    this.page.off('requestfailed', this.onRequestFailed);
    this.page.off('console', this.onConsole);
    await this.testInfo.attach('sentinel-events.json', {
      body: Buffer.from(JSON.stringify(this.events, null, 2)),
      contentType: 'application/json',
    });
    if (this.testInfo.status === 'passed' && (!this.stepCount || !this.outcomeVerified)) {
      throw new Error(`Sentinel: scenario has ${this.stepCount} observed steps and no verified final outcome`);
    }
    if (this.testInfo.status === 'passed' && this.events.some((event) => event.kind === 'pageerror')) {
      throw new Error('Sentinel: uncaught browser error; see sentinel-events.json');
    }
  }

  private record(kind: string, detail: string): void {
    this.events.push({ at: new Date().toISOString(), kind, detail, checkpoint: this.checkpoint });
  }

  private async capture(label: string): Promise<void> {
    if (this.page.isClosed()) return;
    const prefix = label.replace(/[^a-z0-9-]/gi, '-').toLowerCase();
    const html = this.testInfo.outputPath(`${prefix}-CopyDOM.html`);
    const image = this.testInfo.outputPath(`${prefix}.png`);
    await fs.writeFile(html, await this.page.content(), 'utf8');
    await this.page.screenshot({ path: image, fullPage: true });
    await this.testInfo.attach(`${prefix}-CopyDOM`, { path: html, contentType: 'text/html' });
    await this.testInfo.attach(`${prefix}-screenshot`, { path: image, contentType: 'image/png' });
  }
}
