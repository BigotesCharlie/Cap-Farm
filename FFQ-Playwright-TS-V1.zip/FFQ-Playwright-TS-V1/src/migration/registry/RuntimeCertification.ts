import certifiedScenarios from '../certified-scenarios.json';

/** Single source of truth shared with the npm test safety gate. */
export const RUNTIME_CERTIFIED_LEGACY_IDS: readonly string[] = certifiedScenarios;

const certifiedSet = new Set<string>(RUNTIME_CERTIFIED_LEGACY_IDS);

export function isRuntimeCertified(legacyId: string): boolean {
  return certifiedSet.has(legacyId);
}

export function getRuntimeCertifiedIds(): readonly string[] {
  return [...certifiedSet.values()];
}
