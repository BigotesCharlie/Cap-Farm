import { AceAutoEndToEndOneRandomApplicantHandler } from '../handlers/auto/AceAutoEndToEndOneRandomApplicantHandler.js';
import {
  ACE_HOME_ADDITIONAL_INFO_CONTENT_LEGACY_ID,
  ACE_HOME_ADDITIONAL_INFO_ERRORS_LEGACY_ID,
  ACE_HOME_ADDITIONAL_INFO_FLOOR_RESIDENCE_LEGACY_ID,
  ACE_HOME_ADDITIONAL_INFO_NEARMAP_NOT_PREFILLED_LEGACY_ID,
  ACE_HOME_ADDITIONAL_INFO_NEARMAP_PREFILLED_LEGACY_ID,
  ACE_HOME_ADDITIONAL_INFO_PERSISTENCE_LEGACY_ID,
  AceHomeAdditionalInfoHandler,
} from '../handlers/acehome/AceHomeAdditionalInfoHandler.js';
import { AceHomeProdRetrieveRatedQuoteHandler } from '../handlers/acehome/AceHomeProdRetrieveRatedQuoteHandler.js';
import { AceHomeReviewQuotePresentmentHandler } from '../handlers/acehome/AceHomeReviewQuotePresentmentHandler.js';
import { AceHomeSmokePresentmentHandler } from '../handlers/acehome/AceHomeSmokePresentmentHandler.js';
import { ScenarioHandlerRegistry } from './ScenarioHandlerRegistry.js';

const registry = new ScenarioHandlerRegistry();

registry.register(new AceAutoEndToEndOneRandomApplicantHandler());
registry.register(
  new AceHomeAdditionalInfoHandler(ACE_HOME_ADDITIONAL_INFO_NEARMAP_PREFILLED_LEGACY_ID, 'NEARMAP_PREFILLED'),
);
registry.register(
  new AceHomeAdditionalInfoHandler(ACE_HOME_ADDITIONAL_INFO_NEARMAP_NOT_PREFILLED_LEGACY_ID, 'NEARMAP_NOT_PREFILLED'),
);
registry.register(new AceHomeAdditionalInfoHandler(ACE_HOME_ADDITIONAL_INFO_CONTENT_LEGACY_ID, 'VALIDATE_CONTENT'));
registry.register(new AceHomeAdditionalInfoHandler(ACE_HOME_ADDITIONAL_INFO_ERRORS_LEGACY_ID, 'VALIDATE_ERRORS'));
registry.register(
  new AceHomeAdditionalInfoHandler(ACE_HOME_ADDITIONAL_INFO_FLOOR_RESIDENCE_LEGACY_ID, 'VALIDATE_FLOOR_RESIDENCE'),
);
registry.register(
  new AceHomeAdditionalInfoHandler(ACE_HOME_ADDITIONAL_INFO_PERSISTENCE_LEGACY_ID, 'BACK_FORWARD_PERSISTENCE'),
);
registry.register(new AceHomeReviewQuotePresentmentHandler());
registry.register(new AceHomeSmokePresentmentHandler());
registry.register(new AceHomeProdRetrieveRatedQuoteHandler());

export function getHandlerRegistry(): ScenarioHandlerRegistry {
  return registry;
}
