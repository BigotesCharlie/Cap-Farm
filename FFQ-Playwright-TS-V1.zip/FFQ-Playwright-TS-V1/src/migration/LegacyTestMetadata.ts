export interface LegacyTestMetadata {
  readonly legacyId: string;
  readonly domain: string;
  readonly sourceFile: string;
  readonly sourceLine: number;
  readonly className: string;
  readonly method: string;
  readonly parameters: string;
  readonly dataProvider: string;
  readonly dataProviderClass: string;
  readonly testName: string;
  readonly groups: string;
  readonly annotation: string;
}

export interface LegacyMethodContract extends LegacyTestMetadata {
  readonly enabled: boolean;
  readonly javaSource: string;
}
