import { readFile } from 'node:fs/promises';
import type { Page, TestInfo } from '@playwright/test';
import type { SelectedCase } from '../data/LegacyProviderSelector.js';
import type { LegacyMethodContract, LegacyTestMetadata } from './LegacyTestMetadata.js';
import { getHandlerRegistry } from './registry/HandlerCatalog.js';
import { getRecoveryGuard } from '../fixtures/health/recovery.fixture.js';
import type { ScenarioExecutionContext } from './handlers/ScenarioTypes.js';

let contracts: Promise<Record<string, LegacyMethodContract>> | undefined;

async function loadContracts(): Promise<Record<string, LegacyMethodContract>> {
  contracts ??= readFile('migration/audit/legacy-method-contracts.json', 'utf8').then(
    (source) => JSON.parse(source) as Record<string, LegacyMethodContract>,
  );
  return contracts;
}

/**
 * Auditable execution boundary for generated tests.
 *
 * A behavioral handler must be registered for a test before the safety gate is
 * enabled. This deliberately fails closed: an unmigrated scenario can never be
 * reported as a false PASS merely because the FFQ landing page loaded.
 */
export async function executeMigratedScenario(
  page: Page,
  testInfo: TestInfo,
  legacyData: (metadata: LegacyTestMetadata) => Promise<SelectedCase[]>,
  metadata: LegacyTestMetadata,
): Promise<void> {
  const contract = (await loadContracts())[metadata.legacyId];
  if (!contract) throw new Error(`Missing immutable migration contract: ${metadata.legacyId}`);

  testInfo.annotations.push(
    { type: 'legacy-id', description: metadata.legacyId },
    { type: 'legacy-source', description: `${metadata.sourceFile}:${metadata.sourceLine}` },
    { type: 'data-provider', description: metadata.dataProvider || 'none' },
  );
  await testInfo.attach('legacy-contract.json', {
    body: Buffer.from(JSON.stringify(contract, null, 2)),
    contentType: 'application/json',
  });

  const selected = await legacyData(metadata);
  await testInfo.attach('selected-fixture-rows.json', {
    body: Buffer.from(
      JSON.stringify(
        selected.map(({ source, sheet, sourceId, state }) => ({
          source,
          sheet,
          sourceId,
          state,
        })),
        null,
        2,
      ),
    ),
    contentType: 'application/json',
  });

  const handler = getHandlerRegistry().resolve(metadata.legacyId);
  if (!handler) {
    throw new Error(
      `Behavioral handler not implemented for ${metadata.legacyId}; selected ${selected.length} fixture row(s). ` +
        'No generic navigation is allowed to produce PASS.',
    );
  }
  testInfo.annotations.push({ type: 'handler-status', description: 'implemented; not runtime certified' });
  const context: ScenarioExecutionContext = {
    page,
    testInfo,
    metadata,
    contract,
    selectedCases: selected,
    recoveryGuard: getRecoveryGuard(page),
    checkpoint: async (name) => {
      testInfo.annotations.push({ type: 'logical-checkpoint', description: name });
      const { captureDomCheckpoint } = await import('../core/DomCheckpoint.js');
      await captureDomCheckpoint(page, testInfo, name);
    },
    annotate: (type, description) => {
      testInfo.annotations.push({ type, description });
    },
  };
  await handler.execute(context);
  throw new Error(
    `Behavioral handler for ${metadata.legacyId} reached its current end but is not runtime certified. ` +
      'Record and verify the original end-to-end assertions before allowing PASS.',
  );
}
