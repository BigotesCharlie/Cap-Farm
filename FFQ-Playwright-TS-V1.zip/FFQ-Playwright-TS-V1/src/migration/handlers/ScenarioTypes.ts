import type { Page, TestInfo } from '@playwright/test';
import type { SelectedCase } from '../../data/LegacyProviderSelector.js';
import type { RecoveryGuard } from '../../core/RecoveryGuard.js';
import type { LegacyMethodContract, LegacyTestMetadata } from '../LegacyTestMetadata.js';

export type ScenarioCertificationStatus = 'mapped' | 'implemented' | 'runtime-certified';

export interface ScenarioExecutionContext {
  readonly page: Page;
  readonly testInfo: TestInfo;
  readonly metadata: LegacyTestMetadata;
  readonly contract: LegacyMethodContract;
  readonly selectedCases: readonly SelectedCase[];
  readonly recoveryGuard?: RecoveryGuard | undefined;
  checkpoint(name: string): Promise<void>;
  annotate(type: string, description: string): void;
}

export interface ScenarioHandler {
  readonly legacyId: string;
  readonly domain: string;
  readonly status: Exclude<ScenarioCertificationStatus, 'mapped'>;
  execute(context: ScenarioExecutionContext): Promise<void>;
}
