import { SoftAssertCollector } from '../../../core/SoftAssertCollector.js';
import { AceHomeApplicantProvider } from '../../../data/providers/acehome/AceHomeApplicantProvider.js';
import { AceHomeNavigationFlow } from '../../../flows/acehome/AceHomeNavigationFlow.js';
import type { ApplicantAceHome } from '../../../models/acehome/ApplicantAceHome.js';
import { AceHomeAdditionalInfoPage, AceHomePropertyDetailsPage } from '../../../pages/acehome/AceHomePages.js';
import type { ScenarioExecutionContext, ScenarioHandler } from '../ScenarioTypes.js';

export const ACE_HOME_ADDITIONAL_INFO_NEARMAP_PREFILLED_LEGACY_ID =
  'com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#testAdditionalInfoPageNearMapRoofYearPrefilled';
export const ACE_HOME_ADDITIONAL_INFO_NEARMAP_NOT_PREFILLED_LEGACY_ID =
  'com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#testAdditionalInfoPageNearMapRoofYearNotPrefilled';
export const ACE_HOME_ADDITIONAL_INFO_CONTENT_LEGACY_ID =
  'com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#validateAdditionalInfoPageContentHomeLob';
export const ACE_HOME_ADDITIONAL_INFO_ERRORS_LEGACY_ID =
  'com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#validateAdditionalInfoErrorsHomeLob';
export const ACE_HOME_ADDITIONAL_INFO_FLOOR_RESIDENCE_LEGACY_ID =
  'com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#validateFloorResidenceLocatedHomeLob';
export const ACE_HOME_ADDITIONAL_INFO_PERSISTENCE_LEGACY_ID =
  'com.farmers.ffq.acehome.AceHomeAdditionalInfoPageTest#testDataSaveChangesWhenNavigatedBackandForthAdditionalInfoPageHomeLob';

type AdditionalInfoScenarioMode =
  | 'NEARMAP_PREFILLED'
  | 'NEARMAP_NOT_PREFILLED'
  | 'VALIDATE_CONTENT'
  | 'VALIDATE_ERRORS'
  | 'VALIDATE_FLOOR_RESIDENCE'
  | 'BACK_FORWARD_PERSISTENCE';

const NEARMAP_BLOCKER =
  'BLOCKED: NearMap dependency is not implemented in this repository. Missing AddressNearMap data/provider and applicant update flow required by the legacy contract.';

function cloneApplicant(applicant: ApplicantAceHome, overrides: Partial<ApplicantAceHome>): ApplicantAceHome {
  return {
    ...applicant,
    ...overrides,
  };
}

export class AceHomeAdditionalInfoHandler implements ScenarioHandler {
  public readonly domain = 'acehome';
  public readonly status = 'implemented' as const;

  private readonly provider = new AceHomeApplicantProvider();

  public constructor(
    public readonly legacyId: string,
    private readonly mode: AdditionalInfoScenarioMode,
  ) {}

  public async execute(context: ScenarioExecutionContext): Promise<void> {
    const selected = await this.provider.fromFixture(context.metadata, context.selectedCases[0]);
    let applicant = selected.applicant;

    if (this.mode === 'VALIDATE_FLOOR_RESIDENCE') {
      applicant = cloneApplicant(applicant, {
        address: '26072 Perdido Beach',
        unit: '100E',
        city: 'Orange Beach',
        zipCode: '36561',
      });
    }

    context.annotate('applicant-correlation-id', selected.correlationId);
    context.annotate('provider-workbook', `${selected.workbook}:${selected.worksheet}`);
    context.annotate('provider-source-id', context.selectedCases[0]?.sourceId ?? 'unknown');
    context.annotate('provider-seed', process.env.FFQ_DATA_SEED || context.testInfo.testId);
    context.annotate('scenario-variant', this.mode);

    const fsa = new SoftAssertCollector(context.page, context.testInfo, context.metadata.legacyId);
    const flow = new AceHomeNavigationFlow(
      context.page,
      {
        checkpoint: context.checkpoint,
        annotate: context.annotate,
      },
      context.recoveryGuard,
    );

    const additionalInfoPage = await flow.navigateToAdditionalInfoPage(applicant);
    await context.checkpoint('additional-info-entry');

    switch (this.mode) {
      case 'NEARMAP_PREFILLED': {
        throw new Error(
          `${NEARMAP_BLOCKER} Legacy contract requires evidence 7 or 8 roof-installation-year validation for state ${applicant.stateCode}.`,
        );
      }
      case 'NEARMAP_NOT_PREFILLED': {
        throw new Error(
          `${NEARMAP_BLOCKER} Legacy contract requires non-7/8 NearMap evidence selection for state ${applicant.stateCode}.`,
        );
      }
      case 'VALIDATE_CONTENT': {
        await context.checkpoint('additional-info-before-action');
        await additionalInfoPage.validateCoreContent(fsa, applicant.stateCode);
        await additionalInfoPage.validateSelections(fsa);
        await context.checkpoint('additional-info-after-action');
        break;
      }
      case 'VALIDATE_ERRORS': {
        await context.checkpoint('additional-info-before-action');
        await additionalInfoPage.triggerValidationErrors();
        await context.checkpoint('additional-info-validation-state');
        const errors = await additionalInfoPage.visibleValidationErrors();
        await fsa.check(
          errors.length > 0,
          'Additional Info validation errors were not displayed.',
          'additional-info-errors',
          errors.join(' | '),
        );
        await context.checkpoint('additional-info-after-action');
        break;
      }
      case 'VALIDATE_FLOOR_RESIDENCE': {
        await context.checkpoint('additional-info-before-action');
        await fsa.check(
          await additionalInfoPage.validateFloorResidenceIsLocatedOnSection(),
          'Floor residence section is not displayed.',
          'additional-info-floor-residence',
        );
        await context.checkpoint('additional-info-after-action');
        break;
      }
      case 'BACK_FORWARD_PERSISTENCE': {
        await context.checkpoint('additional-info-before-action');
        const mutation = await additionalInfoPage.mutateForPersistence();
        await context.annotate('persistence-field', mutation.field);
        await context.annotate('persistence-value', mutation.value);
        await context.checkpoint('additional-info-before-forward');
        await additionalInfoPage.navigateBack();

        const propertyDetails = new AceHomePropertyDetailsPage(context.page);
        await propertyDetails.assertOnPage();
        await context.checkpoint('additional-info-after-back');
        await propertyDetails.clickContinue();

        const additionalInfoAfterReturn = new AceHomeAdditionalInfoPage(context.page);
        await additionalInfoAfterReturn.assertOnPage();
        await context.checkpoint('additional-info-after-forward');
        const valuePersistedWithoutContinue = await additionalInfoAfterReturn.validateMutationValue(mutation);
        await fsa.check(
          !valuePersistedWithoutContinue,
          'Data should not be saved when navigating back without continue.',
          'additional-info-no-persist-before-continue',
          `${mutation.field}=${mutation.value}`,
        );

        const mutationForSave = await additionalInfoAfterReturn.mutateForPersistence();
        await context.checkpoint('additional-info-persistence-verified');
        await additionalInfoAfterReturn.clickContinue();

        const backTarget = await flow['page'].goBack({ waitUntil: 'domcontentloaded' }).catch(() => undefined);
        void backTarget;
        const additionalInfoAfterContinue = new AceHomeAdditionalInfoPage(context.page);
        await additionalInfoAfterContinue.assertOnPage();
        const savedAfterContinue = await additionalInfoAfterContinue.validateMutationValue(mutationForSave);
        await fsa.check(
          savedAfterContinue,
          'Data should persist after continue and browser back.',
          'additional-info-persist-after-continue',
          `${mutationForSave.field}=${mutationForSave.value}`,
        );
        break;
      }
    }

    await fsa.assertAll(`Ace Home Additional Info scenario failed: ${this.mode}`);
  }
}
