import { env } from '../../../config/env.js';
import { SoftAssertCollector } from '../../../core/SoftAssertCollector.js';
import { AceHomeApplicantProvider } from '../../../data/providers/acehome/AceHomeApplicantProvider.js';
import { AceHomeBindFlow } from '../../../flows/acehome/AceHomeBindFlow.js';
import { AceHomeNavigationFlow } from '../../../flows/acehome/AceHomeNavigationFlow.js';
import { AceHomeRetrieveQuoteFlow } from '../../../flows/acehome/AceHomeRetrieveQuoteFlow.js';
import type { HomeQuoteState } from '../../../models/acehome/HomeQuoteState.js';
import {
  AceHomeAboutYouPage,
  AceHomeAdditionalInfoPage,
  AceHomeContactInfoPage,
  AceHomeDwellingCoveragePage,
  AceHomePropertyDetailsPage,
  AceHomePropertyInfoPage,
  AceHomeQualityGradePage,
  AceHomeReviewQuotePage,
} from '../../../pages/acehome/AceHomePages.js';
import type { ScenarioExecutionContext, ScenarioHandler } from '../ScenarioTypes.js';

export const ACE_HOME_PROD_RETRIEVE_RATED_QUOTE_LEGACY_ID =
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testProdRetrieveRatedQuoteAceHome';

function isProductionEnvironment(): boolean {
  const name = env.TEST_ENV.toUpperCase();
  return name === 'PROD' || name === 'PRODUCTION';
}

function updateApplicantForProdValidationUnavailableMessage(): string {
  return (
    'BLOCKED: Missing dependency implementation for AceHRCBasePage.updateApplicantForProdValidation(ApplicantAceHome). ' +
    'Exact Java method body is not available in repository contracts or source archive.'
  );
}

export class AceHomeProdRetrieveRatedQuoteHandler implements ScenarioHandler {
  public readonly legacyId = ACE_HOME_PROD_RETRIEVE_RATED_QUOTE_LEGACY_ID;
  public readonly domain = 'acehome';
  public readonly status = 'implemented' as const;

  private readonly provider = new AceHomeApplicantProvider();

  public async execute(context: ScenarioExecutionContext): Promise<void> {
    if (isProductionEnvironment() && !env.FFQ_ALLOW_PRODUCTION_EXECUTION) {
      throw new Error(
        'Production execution is blocked. Set FFQ_ALLOW_PRODUCTION_EXECUTION=true only when explicitly authorized.',
      );
    }

    const selected = await this.provider.fromFixture(context.metadata, context.selectedCases[0]);
    context.annotate('applicant-correlation-id', selected.correlationId);
    context.annotate('provider-workbook', `${selected.workbook}:${selected.worksheet}`);
    context.annotate('provider-source-id', context.selectedCases[0]?.sourceId ?? 'unknown');
    context.annotate('provider-seed', process.env.FFQ_DATA_SEED || context.testInfo.testId);

    throw new Error(updateApplicantForProdValidationUnavailableMessage());
  }

  public async executeWhenDependencyResolved(context: ScenarioExecutionContext): Promise<void> {
    const selected = await this.provider.fromFixture(context.metadata, context.selectedCases[0]);
    const applicant = selected.applicant;
    const fsa = new SoftAssertCollector(context.page, context.testInfo, context.metadata.legacyId);
    const flow = new AceHomeNavigationFlow(
      context.page,
      {
        checkpoint: context.checkpoint,
        annotate: context.annotate,
      },
      context.recoveryGuard,
    );

    const state: HomeQuoteState = {
      quoteNumber: '',
      dwellingCoverageAmount: '',
      dwellingCoverageQualityGrade: '',
      quotePriceBeforeRetrieve: '',
      discountsBeforeRetrieve: [],
    };

    const dwellingPage = await flow.navigateToDwellingCoveragePage(applicant);
    state.dwellingCoverageAmount = await dwellingPage.dwellingCoverageAmount();
    state.dwellingCoverageQualityGrade = await dwellingPage.dwellingCoverageQualityGrade();
    await dwellingPage.clickContinue();

    const reviewPage = new AceHomeReviewQuotePage(context.page);
    await reviewPage.assertOnPage();
    state.discountsBeforeRetrieve = (await reviewPage.discounts()).sort();

    await reviewPage.validatePageLinksText(fsa);
    await reviewPage.validatePageLinksNavigationTitles(fsa);

    await reviewPage.clickChangeCoverage();
    await dwellingPage.assertOnPage();
    await dwellingPage.changeDwellingCoverage();
    await dwellingPage.clickContinue();

    await reviewPage.assertOnPage();
    state.quotePriceBeforeRetrieve = await reviewPage.quotePriceOnCard();

    const retrieveFlow = new AceHomeRetrieveQuoteFlow(context.page, {
      checkpoint: context.checkpoint,
      annotate: context.annotate,
    });
    state.quoteNumber = await dwellingPage.displayedQuoteNumber();
    await retrieveFlow.retrieveByQuoteNumber(state.quoteNumber);

    await fsa.check(
      await reviewPage.isWelcomeBackMessageDisplayed(applicant.firstName),
      'Welcome back snackbar not displayed after quote retrieval.',
      'retrieve-welcome-back',
    );

    await fsa.equal(
      await reviewPage.quotePriceOnCard(),
      state.quotePriceBeforeRetrieve,
      'Quote price mismatch after retrieval.',
      'retrieve-price-compare',
    );

    await reviewPage.verifyQuotePresentmentCard(applicant.stateCode, fsa);
    await reviewPage.validateQuoteSavedText(state.quoteNumber, fsa);
    await fsa.equal(
      (await reviewPage.discounts()).sort().join('|'),
      state.discountsBeforeRetrieve.join('|'),
      'Discounts mismatch after retrieval on Review Quote page.',
      'retrieve-discounts-compare',
    );

    await reviewPage.selectEnterInfoStepper();
    const propertyInfo = new AceHomePropertyInfoPage(context.page);
    await propertyInfo.assertOnPage();
    await propertyInfo.clickContinue();

    const quality = new AceHomeQualityGradePage(context.page);
    if (await quality.isQualityGradePageAlone()) {
      await quality.assertStandalone(fsa);
      await quality.validateAddressAndFeatures(fsa);
      await quality.clickContinueIfVisible();
    } else {
      await quality.assertCombined(fsa);
      await quality.validateAddressAndFeatures(fsa);
    }

    const propertyDetails = new AceHomePropertyDetailsPage(context.page);
    await propertyDetails.assertOnPage();
    await fsa.equal(
      await propertyDetails.pageTitle(),
      "Here's what we have so far",
      'Property Details title mismatch.',
      'property-details-title',
    );
    await propertyDetails.validateSavedQuote(state.quoteNumber, fsa);
    await propertyDetails.validateDiscounts(state.discountsBeforeRetrieve, fsa);
    await propertyDetails.clickContinue();

    const additionalInfo = new AceHomeAdditionalInfoPage(context.page);
    await additionalInfo.assertOnPage();
    await additionalInfo.validateSelections(fsa);
    await additionalInfo.clickContinue();

    if (!(await additionalInfo.isNewFlowEnabledState(applicant.stateCode))) {
      const aboutYou = new AceHomeAboutYouPage(context.page);
      await aboutYou.assertOnPage();
      await aboutYou.validateSelections(fsa);
      await aboutYou.clickContinue();
    }

    const contactInfo = new AceHomeContactInfoPage(context.page);
    await contactInfo.assertOnPage();
    await contactInfo.validateSelections(applicant, fsa);
    await contactInfo.clickAgreeAndSubmit();

    const dwellingAfterRetrieve = new AceHomeDwellingCoveragePage(context.page);
    await dwellingAfterRetrieve.assertOnPage();
    await fsa.equal(
      await dwellingAfterRetrieve.dwellingCoverageAmount(),
      state.dwellingCoverageAmount,
      'Dwelling coverage amount mismatch after retrieval.',
      'dwelling-after-retrieve-amount',
    );
    await fsa.equal(
      await dwellingAfterRetrieve.dwellingCoverageQualityGrade(),
      state.dwellingCoverageQualityGrade,
      'Dwelling quality grade mismatch after retrieval.',
      'dwelling-after-retrieve-quality-grade',
    );
    await fsa.equal(
      (await dwellingAfterRetrieve.discounts()).join('|'),
      state.discountsBeforeRetrieve.join('|'),
      'Dwelling discounts mismatch after retrieval.',
      'dwelling-after-retrieve-discounts',
    );
    await fsa.equal(
      await dwellingAfterRetrieve.displayedQuoteNumber(),
      state.quoteNumber,
      'Dwelling quote number mismatch after retrieval.',
      'dwelling-after-retrieve-quote-number',
    );
    await dwellingAfterRetrieve.clickContinue();

    await reviewPage.assertOnPage();
    await reviewPage.verifyQuotePresentmentCard(applicant.stateCode, fsa);
    await reviewPage.validateQuoteSavedText(state.quoteNumber, fsa);

    const bindFlow = new AceHomeBindFlow(context.page, {
      checkpoint: context.checkpoint,
      annotate: context.annotate,
    });
    await bindFlow.continueFromReviewQuote(applicant);

    await fsa.assertAll('Ace Home - Prod Retrieve rated quote.');
  }
}
