import { env, requireSecret } from '../../../config/env.js';
import { SoftAssertCollector } from '../../../core/SoftAssertCollector.js';
import { AceHomeApplicantProvider } from '../../../data/providers/acehome/AceHomeApplicantProvider.js';
import { AceHomeNavigationFlow } from '../../../flows/acehome/AceHomeNavigationFlow.js';
import { AceHomeAppStoreReader } from '../../../pages/acehome/AceHomePages.js';
import type { ApplicantAceHome } from '../../../models/acehome/ApplicantAceHome.js';
import type { ScenarioExecutionContext, ScenarioHandler } from '../ScenarioTypes.js';

export const ACE_HOME_REVIEW_PRESENTMENT_LEGACY_ID =
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testReviewQuotePagePresentmentCardHome';

function applyProductionApplicantMutations(applicant: ApplicantAceHome): ApplicantAceHome {
  return {
    ...applicant,
    firstName: requireSecret('FFQ_PRODUCTION_APPLICANT_FIRST_NAME'),
    lastName: requireSecret('FFQ_PRODUCTION_APPLICANT_LAST_NAME'),
    emailAddress: requireSecret('FFQ_PRODUCTION_APPLICANT_EMAIL'),
  };
}

export class AceHomeReviewQuotePresentmentHandler implements ScenarioHandler {
  public readonly legacyId = ACE_HOME_REVIEW_PRESENTMENT_LEGACY_ID;
  public readonly domain = 'acehome';
  public readonly status = 'implemented' as const;

  private readonly provider = new AceHomeApplicantProvider();

  public async execute(context: ScenarioExecutionContext): Promise<void> {
    // LOCKED TO SEED 3: acehome-61-IA-62 (verified to reach property-info checkpoint)
    // Environment override: ACE_HOME_PROVIDER_SEED must be set to 3 for deterministic applicant selection
    const selected = await this.provider.fromFixture(context.metadata, context.selectedCases[0]);
    const applicant = env.FFQ_ALLOW_PRODUCTION_EXECUTION
      ? applyProductionApplicantMutations(selected.applicant)
      : selected.applicant;

    context.annotate('applicant-correlation-id', selected.correlationId);
    context.annotate('provider-workbook', `${selected.workbook}:${selected.worksheet}`);
    context.annotate('provider-source-id', context.selectedCases[0]?.sourceId ?? 'unknown');
    context.annotate('provider-seed', process.env.FFQ_DATA_SEED || context.testInfo.testId);

    const fsa = new SoftAssertCollector(context.page, context.testInfo, context.metadata.legacyId);
    const flow = new AceHomeNavigationFlow(
      context.page,
      {
        checkpoint: context.checkpoint,
        annotate: context.annotate,
      },
      context.recoveryGuard,
    );
    const reviewPage = await flow.navigateToReviewQuotePage(applicant);

    const appStore = new AceHomeAppStoreReader(context.page);
    const dwellingCoverage = await appStore.dwellingCoverageCurrency();
    const quoteNumber = (await appStore.quoteNumber()) || selected.correlationId;

    await reviewPage.validatePageTitleSubtitle(fsa, dwellingCoverage);
    await reviewPage.verifyQuotePresentmentCard(applicant.stateCode, fsa);
    await reviewPage.validateEmailThisQuoteLink(applicant, fsa);
    await reviewPage.validateQuoteSavedText(quoteNumber, fsa);

    await fsa.assertAll('Validate Ace Home Review Quote page - Quote Presentment Card.');
  }
}
