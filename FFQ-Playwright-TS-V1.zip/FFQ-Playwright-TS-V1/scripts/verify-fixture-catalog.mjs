import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';

const root = 'src/data/catalog';
const manifest = JSON.parse(await readFile(join(root, 'manifest.json'), 'utf8'));
const sourceRows = JSON.parse(await readFile(join(root, 'source-rows.json'), 'utf8'));
const names = (await readdir(root)).filter((name) => name.endsWith('.json'));
const books = Object.keys(manifest);
let sheets = 0;
let rows = 0;
let formulas = 0;
const errors = [];
for (const book of books) {
  if (!names.includes(`${book}.json`)) {
    errors.push(`Missing ${book}`);
    continue;
  }
  const data = JSON.parse(await readFile(join(root, `${book}.json`), 'utf8'));
  for (const [sheet, expected] of Object.entries(manifest[book])) {
    const records = data[sheet];
    if (!Array.isArray(records)) {
      errors.push(`Missing ${book}/${sheet}`);
      continue;
    }
    const coordinates = sourceRows[book]?.[sheet];
    if (
      !Array.isArray(coordinates) ||
      coordinates.length !== records.length ||
      new Set(coordinates).size !== records.length ||
      coordinates.some((row) => !Number.isInteger(row) || row < 2)
    )
      errors.push(`Invalid source row map ${book}/${sheet}`);
    const foundFormulas = records.reduce(
      (count, record) =>
        count +
        Object.values(record).filter((value) => value && typeof value === 'object' && '__excelFormula' in value).length,
      0,
    );
    if (records.length !== expected.rows || foundFormulas !== expected.formulas) {
      errors.push(
        `Count mismatch ${book}/${sheet}: ${records.length}/${foundFormulas} versus ${expected.rows}/${expected.formulas}`,
      );
    }
    sheets += 1;
    rows += records.length;
    formulas += foundFormulas;
  }
}
if ((await readdir(root)).some((name) => /\.xlsx?$/i.test(name)))
  errors.push('An Excel workbook remains in the fixture catalog');
console.log(JSON.stringify({ books: books.length, sheets, rows, formulas, errors }, null, 2));
if (errors.length) process.exitCode = 1;
