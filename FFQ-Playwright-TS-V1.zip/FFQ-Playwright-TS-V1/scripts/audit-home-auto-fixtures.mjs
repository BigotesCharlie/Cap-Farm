import { readFile, mkdtemp, rm } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const output = await mkdtemp(resolve('.ffq-home-auto-audit-'));
try {
  const compiler = spawnSync(resolve('node_modules/.bin/tsc'), ['--outDir', output, '--noEmit', 'false'], {
    stdio: 'inherit',
  });
  if (compiler.status !== 0) process.exit(compiler.status ?? 1);
  const importModule = (path) => import(pathToFileURL(join(output, path)).href);
  const { selectLegacyCases } = await importModule('src/data/LegacyProviderSelector.js');
  const rulesByOwner = {
    AceHomeDataProviders: (await importModule('src/fixtures/data/ace-home.fixture.js')).aceHomeRules,
    AutoDataProviders: (await importModule('src/fixtures/data/auto.fixture.js')).autoRules,
    SqlDataProviders: (await importModule('src/fixtures/data/sql-auto.fixture.js')).sqlAutoRules,
    DataProviders: (await importModule('src/fixtures/data/legacy-home.fixture.js')).legacyHomeRules,
  };
  const contracts = Object.values(JSON.parse(await readFile('migration/audit/legacy-method-contracts.json', 'utf8')));
  const applicable = contracts.filter((c) => {
    const owner = c.dataProviderClass.replace(/\.class$/, '');
    return owner in rulesByOwner && (owner !== 'DataProviders' || c.domain === 'home');
  });
  const representatives = new Map();
  const variants = new Map();
  const failures = [];
  for (const contract of applicable) {
    const owner = contract.dataProviderClass.replace(/\.class$/, '');
    const variant = contract.dataProvider.split('.').at(-1);
    const key = `${owner}.${variant}`;
    variants.set(key, (variants.get(key) ?? 0) + 1);
    if (!rulesByOwner[owner][variant]) {
      failures.push({ legacyId: contract.legacyId, reason: `Missing fixture variant ${key}` });
      continue;
    }
    const attrs = contract.annotation.match(/@CustomAttribute[^)]*\)/g)?.join('') ?? '';
    const suite = contract.annotation.match(/suiteName\s*=\s*("[^"]*"|[\w.]+)/)?.[1] ?? '';
    const signature = `${key}|${contract.testName}|${attrs}|${suite}`;
    if (!representatives.has(signature)) representatives.set(signature, contract);
  }
  let successful = 0;
  const selectedContracts = process.argv.includes('--all') ? applicable : [...representatives.values()];
  for (const contract of selectedContracts) {
    const owner = contract.dataProviderClass.replace(/\.class$/, '');
    const variant = contract.dataProvider.split('.').at(-1);
    const rule = rulesByOwner[owner][variant];
    try {
      const rows = await selectLegacyCases(contract, {
        seed: 'home-auto-audit',
        environment: process.env.TEST_ENV || 'MA11',
      });
      for (const row of rows) {
        if (row.sheet !== rule.sheet || !row.state || String(row.data.stateCode).toUpperCase() !== row.state) {
          throw Error(`Invalid source/sheet/state ${row.source}/${row.sheet}/${row.sourceId}/${row.state}`);
        }
      }
      rule.check?.(rows, contract);
      successful++;
    } catch (error) {
      failures.push({
        legacyId: contract.legacyId,
        variant: `${owner}.${variant}`,
        reason: String(error?.message ?? error),
      });
    }
  }
  console.log(
    JSON.stringify(
      {
        contracts: applicable.length,
        variants: Object.fromEntries(variants),
        representativeSelections: representatives.size,
        auditedSelections: selectedContracts.length,
        successful,
        failures,
      },
      null,
      2,
    ),
  );
  if (failures.length) process.exitCode = 1;
} finally {
  await rm(output, { recursive: true, force: true });
}
