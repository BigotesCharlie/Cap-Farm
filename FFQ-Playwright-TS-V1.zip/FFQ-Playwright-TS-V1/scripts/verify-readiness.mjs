import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';

const results = [];
for (const [name, file, args] of [
  ['home-auto-selection', 'scripts/audit-home-auto-fixtures.mjs', ['--all']],
  ['catalog-formulas', 'scripts/audit-fixture-formulas.mjs', []],
]) {
  const result = spawnSync(process.execPath, [resolve(file), ...args], { encoding: 'utf8' });
  process.stdout.write(result.stdout ?? '');
  process.stderr.write(result.stderr ?? '');
  results.push({ name, status: result.status === 0 ? 'passed' : 'failed' });
}
console.log(
  JSON.stringify({ readinessChecks: results, ready: results.every((result) => result.status === 'passed') }, null, 2),
);
if (results.some((result) => result.status !== 'passed')) process.exitCode = 1;
