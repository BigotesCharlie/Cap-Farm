import { readFile } from 'node:fs/promises';

const certified = JSON.parse(await readFile('src/migration/certified-scenarios.json', 'utf8'));
if (!Array.isArray(certified) || certified.length === 0) {
  console.error('No behaviorally certified UI scenarios. A skipped suite must not report a green test run.');
  console.error(
    'Use npm run verify:quality for structural checks or npm run test:diagnostic for a failing diagnostic run.',
  );
  process.exitCode = 1;
}
