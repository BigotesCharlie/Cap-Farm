import assert from 'node:assert/strict';
import { readFile, mkdtemp, rm } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';

const output = await mkdtemp(resolve('.ffq-fixture-check-'));
try {
  const compilation = spawnSync(resolve('node_modules/.bin/tsc'), ['--outDir', output, '--noEmit', 'false'], {
    stdio: 'inherit',
  });
  if (compilation.status !== 0) throw Error('TypeScript compilation failed');
  const load = (file) => import(pathToFileURL(join(output, file)).href);
  const { selectLegacyCases } = await load('src/data/LegacyProviderSelector.js');
  const { materializeRow, rawRows } = await load('src/data/FixtureCatalog.js');
  const { evaluateLegacyDateFormula } = await load('src/data/LegacyDateFormula.js');
  const contracts = Object.values(JSON.parse(await readFile('migration/audit/legacy-method-contracts.json', 'utf8')));
  const options = { seed: 'regression', environment: 'MA11' };
  const find = (owner, variant, testName) => {
    const item = contracts.find(
      (c) =>
        c.dataProviderClass === `${owner}.class` &&
        c.dataProvider.split('.').at(-1) === variant &&
        (testName === undefined || c.testName === testName),
    );
    assert.ok(item, `Missing regression contract ${owner}.${variant}`);
    return item;
  };
  let checks = 0;
  const sql = find('SqlDataProviders', 'AUTO_APPLICANT_COMMON_DATA_PROVIDER');
  const sqlRows = await selectLegacyCases({ ...sql, annotation: '', testName: '' }, options);
  const aceStates = JSON.parse(await readFile('src/data/catalog/state-support.json', 'utf8')).listOfAceAutoStates_MA11;
  assert.ok(
    sqlRows.every((r) => !aceStates.includes(r.state)),
    'SQL Auto must exclude AceAuto states',
  );
  checks++;
  assert.ok(
    sqlRows.every(
      (r) =>
        Array.isArray(r.data.additionalDrivers) &&
        !Array.isArray(r.data.discounts) &&
        !Array.isArray(r.data.payment) &&
        !Array.isArray(r.data.representative),
    ),
    'SQL object and list shape',
  );
  checks++;
  const bvt = find('SqlDataProviders', 'BVT_AUTO_APPLICANT_DATA_PROVIDER');
  const selectedBvt = await selectLegacyCases({ ...bvt, annotation: '' }, options);
  const expectedBvt = (await rawRows('AutoTestData', 'applicantBVT')).filter(
    (r) => r.stateCode === selectedBvt[0].state,
  );
  assert.equal(selectedBvt.length, expectedBvt.length, 'BVT must return every row from its selected state');
  checks++;
  const home = find('DataProviders', 'APPLICANT_HOME_DATA_PROVIDER');
  await assert.rejects(
    selectLegacyCases({ ...home, annotation: '' }, options),
    /No data/,
    'Master legacy HOME state list is empty',
  );
  checks++;
  const adpf = find('AutoDataProviders', 'RANDOM_ADPF_APPLICANT_DATA_PROVIDER');
  const adpfRows = await selectLegacyCases({ ...adpf, annotation: '' }, { ...options, environment: 'NO_STATE_LIST' });
  assert.equal(adpfRows.length, 1);
  assert.ok(
    Array.isArray(adpfRows[0].data.listOfAdditionalApplicants) &&
      Array.isArray(adpfRows[0].data.listOfApplicantVehicles),
  );
  checks++;
  const auto = find(
    'AutoDataProviders',
    'AUTO_APPLICANT_DATA_PROVIDER',
    'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
  );
  const regular = await selectLegacyCases({ ...auto, annotation: '' }, options);
  assert.equal(regular.length, 1);
  assert.equal(regular[0].data.vehicles.length, 1);
  checks++;
  const stateRows = await selectLegacyCases({ ...auto, annotation: '' }, { ...options, states: regular[0].state });
  assert.equal(
    stateRows.length,
    (await rawRows('OneUIAutoTestData', 'applicant')).filter((r) => r.stateCode === regular[0].state).length,
    'Explicit stateList precedes testName filters',
  );
  checks++;
  assert.deepEqual(
    await selectLegacyCases({ ...auto, annotation: '' }, options),
    regular,
    'Same seed produces same fixture',
  );
  checks++;
  const scalar = await selectLegacyCases(
    {
      ...auto,
      testName: '',
      annotation: '@Test(attributes = {@CustomAttribute(name = FILTER, values = "applicantId=17")})',
    },
    options,
  );
  const array = await selectLegacyCases(
    {
      ...auto,
      testName: '',
      annotation: '@Test(attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"})})',
    },
    options,
  );
  assert.ok(scalar.length > 0 && scalar.every((row) => String(row.data.applicantId) === '17'));
  assert.deepEqual(scalar, array, 'Scalar and array attribute syntax produce the same selection');
  checks++;
  const category = find('AutoDataProviders', 'AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER');
  const categoryRows = await selectLegacyCases(
    { ...category, annotation: '@Test(suiteName = "existing customer knockout")', testName: '' },
    options,
  );
  assert.ok(
    categoryRows.length > 0 && categoryRows.every((row) => row.data.testCategory === 'existing customer knockout'),
    'Quoted suiteName filters the intended category',
  );
  checks++;
  const today = new Date('2026-09-30T00:00:00Z');
  const lookup = () => {
    throw Error('Unexpected reference');
  };
  assert.equal(evaluateLegacyDateFormula('=TEXT(TODAY()+2,"mmddyyyy")', today, lookup), '10022026');
  assert.equal(evaluateLegacyDateFormula('=TEXT(46295,"mmddyyyy")', today, lookup), '09302026');
  checks++;
  const columns = JSON.parse(await readFile('src/data/catalog/columns.json', 'utf8'));
  const source = (await rawRows('OneUIAutoTestData', 'applicant'))[0];
  const key = columns.OneUIAutoTestData.applicant[0];
  const local = await materializeRow(
    'OneUIAutoTestData',
    'applicant',
    { probe: { __excelFormula: '=A2', cached: null, cell: 'ZZ999' } },
    today,
  );
  assert.equal(local.probe, source[key], 'Same-sheet references use the requested Excel row');
  checks++;
  const cross = await materializeRow(
    'OneUIAutoTestData',
    'vehicles',
    { probe: { __excelFormula: '=applicant!A2', cached: null, cell: 'ZZ999' } },
    today,
  );
  assert.equal(cross.probe, source[key], 'Cross-sheet references use source coordinates');
  checks++;
  console.log(JSON.stringify({ behaviorChecks: checks, status: 'passed', browserExecution: false }, null, 2));
} finally {
  await rm(output, { recursive: true, force: true });
}
