"""Read-only comparison with master workbooks; no cell values are printed."""
import argparse
import datetime
import json
from pathlib import Path
import openpyxl

parser = argparse.ArgumentParser()
parser.add_argument('--source', required=True, type=Path, help='Master src/test/resources directory')
args = parser.parse_args()
catalog = Path('src/data/catalog')
manifest = json.loads((catalog / 'manifest.json').read_text())
coordinates = json.loads((catalog / 'source-rows.json').read_text())
errors = []
total_rows = total_cells = 0
for book in manifest:
    paths = list(args.source.rglob(f'{book}.xlsx'))
    if len(paths) != 1:
        errors.append({'book': book, 'reason': 'Source workbook missing or ambiguous'})
        continue
    source = openpyxl.load_workbook(paths[0], read_only=True, data_only=False)
    target = json.loads((catalog / f'{book}.json').read_text())
    if set(source.sheetnames) != set(target):
        errors.append({'book': book, 'reason': 'Sheet names differ'})
    for sheet in source:
        header = []
        seen = set()
        for column, cell in enumerate(next(sheet.rows), 1):
            name = str(cell.value).strip() if cell.value is not None else None
            if name in seen:
                name = f'{name}__column_{column}'
            if name is not None:
                seen.add(name)
            header.append(name)
        actual = target.get(sheet.title, [])
        row_index = 0
        for excel_row, cells in enumerate(list(sheet.rows)[1:], 2):
            expected = {}
            for column, cell in enumerate(cells):
                if column >= len(header) or header[column] is None or cell.value is None:
                    continue
                key, value = str(header[column]), cell.value
                if hasattr(value, 'text') and hasattr(value, 'ref'):
                    value = {'__excelFormula': value.text, 'cell': cell.coordinate, 'arrayRef': value.ref}
                elif cell.data_type == 'f':
                    value = {'__excelFormula': value, 'cell': cell.coordinate}
                elif isinstance(value, (datetime.datetime, datetime.date)):
                    value = value.isoformat()
                elif not isinstance(value, bool) and isinstance(value, (int, float)) and 'zip' in key.lower() and key != 'sameStateZip':
                    value = str(int(value)).zfill(5)
                expected[key] = value
            if not expected:
                continue
            if row_index >= len(actual):
                errors.append({'book': book, 'sheet': sheet.title, 'row': excel_row, 'reason': 'Missing JSON row'})
                row_index += 1
                continue
            row = actual[row_index]
            if coordinates[book][sheet.title][row_index] != excel_row:
                errors.append({'book': book, 'sheet': sheet.title, 'row': excel_row, 'reason': 'Source coordinate differs'})
            if set(row) != set(expected):
                errors.append({'book': book, 'sheet': sheet.title, 'row': excel_row, 'reason': 'Field names differ'})
            for key, value in expected.items():
                target_value = row.get(key)
                same = all(isinstance(target_value, dict) and target_value.get(k) == v for k, v in value.items()) if isinstance(value, dict) else target_value == value
                if not same:
                    errors.append({'book': book, 'sheet': sheet.title, 'row': excel_row, 'field': key, 'reason': 'Cell differs'})
                total_cells += 1
            row_index += 1
            total_rows += 1
        if row_index != len(actual):
            errors.append({'book': book, 'sheet': sheet.title, 'reason': 'Row count differs'})
    source.close()
print(json.dumps({'workbooks': len(manifest), 'rowsCompared': total_rows, 'cellsCompared': total_cells, 'errors': errors}, indent=2))
raise SystemExit(1 if errors else 0)
