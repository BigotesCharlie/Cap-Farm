import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import ts from 'typescript';

const expected = {
  'AceHomeDataProviders.class': 'aceHomeData',
  'AutoDataProviders.class': 'autoData',
  'AceBundleDataProviders.class': 'bundleData',
  'SqlDataProviders.class': 'sqlAutoData',
  'DataProviders.class': 'classicData',
  '': 'inlineData',
};
async function specs(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const nested = await Promise.all(
    entries.map((entry) => (entry.isDirectory() ? specs(join(directory, entry.name)) : [join(directory, entry.name)])),
  );
  return nested.flat().filter((file) => file.endsWith('.spec.ts'));
}
const failures = [];
const contracts = JSON.parse(await readFile('migration/audit/legacy-method-contracts.json', 'utf8'));
let checked = 0;
for (const file of await specs('tests/legacy')) {
  const tree = ts.createSourceFile(file, await readFile(file, 'utf8'), ts.ScriptTarget.Latest, true);
  const declarations = [];
  const calls = [];
  function visit(node) {
    if (ts.isCallExpression(node)) {
      const name = node.expression.getText(tree);
      if ((name === 'test' || name === 'test.skip') && node.arguments.length === 2) {
        const callback = node.arguments[1];
        const binding = ts.isArrowFunction(callback) && callback.parameters[0]?.name;
        declarations.push(
          binding && ts.isObjectBindingPattern(binding) ? binding.elements[1]?.name.getText(tree) : undefined,
        );
      }
      if (name === 'executeMigratedScenario') calls.push(node);
    }
    ts.forEachChild(node, visit);
  }
  visit(tree);
  if (declarations.length !== calls.length)
    failures.push(`${file}: declarations=${declarations.length}, calls=${calls.length}`);
  for (const [index, call] of calls.entries()) {
    const fixtureArg = call.arguments[2]?.getText(tree);
    const metadataArg = call.arguments[3];
    if (!metadataArg || !ts.isObjectLiteralExpression(metadataArg)) {
      failures.push(`${file}: missing metadata at ${index}`);
      continue;
    }
    const metadata = {};
    for (const property of metadataArg.properties) {
      if (!ts.isPropertyAssignment(property)) continue;
      const key = property.name.getText(tree).replace(/^['"]|['"]$/g, '');
      const value = property.initializer;
      if (ts.isStringLiteral(value)) metadata[key] = value.text;
      else if (ts.isNumericLiteral(value)) metadata[key] = Number(value.text);
      else failures.push(`${file}: non-literal metadata ${key}`);
    }
    const contract = contracts[metadata.legacyId];
    if (!contract) failures.push(`${file}: metadata identity has no Java contract`);
    else
      for (const key of Object.keys(metadata)) {
        if (metadata[key] !== contract[key])
          failures.push(`${metadata.legacyId}: inline metadata differs from contract for ${key}`);
      }
    const fixture =
      metadata.domain === 'home' && metadata.dataProviderClass === 'DataProviders.class'
        ? 'legacyHomeData'
        : expected[metadata.dataProviderClass];
    if (!fixture || fixtureArg !== fixture || declarations[index] !== fixture) {
      failures.push(
        `${metadata.legacyId}: expected ${fixture ?? 'unmapped'}, got ${declarations[index]} / ${fixtureArg}`,
      );
    }
    checked++;
  }
}
console.log(JSON.stringify({ checked, failures }, null, 2));
if (failures.length || checked !== 2941) process.exitCode = 1;
