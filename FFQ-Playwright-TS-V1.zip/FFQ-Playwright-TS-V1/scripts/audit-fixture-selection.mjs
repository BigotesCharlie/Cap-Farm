import { readFile, mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const output = await mkdtemp(join(tmpdir(), 'ffq-fixture-audit-'));
try {
  const compiler = spawnSync(resolve('node_modules/.bin/tsc'), ['--outDir', output, '--noEmit', 'false'], {
    stdio: 'inherit',
  });
  if (compiler.status !== 0) process.exit(compiler.status ?? 1);
  const { selectLegacyCases } = await import(pathToFileURL(join(output, 'src/data/LegacyProviderSelector.js')).href);
  const contracts = JSON.parse(await readFile('migration/audit/legacy-method-contracts.json', 'utf8'));
  const distinct = new Map();
  for (const contract of Object.values(contracts)) {
    const attrs = contract.annotation.match(/@CustomAttribute[^)]*\)/g)?.join('') ?? '';
    const suite = contract.annotation.match(/suiteName\s*=\s*("[^"]*"|[\w.]+)/)?.[1] ?? '';
    const key = `${contract.dataProvider}|${contract.testName}|${attrs}|${suite}`;
    if (!distinct.has(key)) distinct.set(key, contract);
  }
  const errors = [];
  for (const contract of distinct.values()) {
    try {
      await selectLegacyCases(contract, { seed: 'fixture-audit', environment: process.env.TEST_ENV || 'MA11' });
    } catch (error) {
      errors.push({ legacyId: contract.legacyId, error: String(error?.message ?? error) });
    }
  }
  console.log(
    JSON.stringify({ representatives: distinct.size, selected: distinct.size - errors.length, errors }, null, 2),
  );
  if (errors.length) process.exitCode = 1;
} finally {
  await rm(output, { recursive: true, force: true });
}
