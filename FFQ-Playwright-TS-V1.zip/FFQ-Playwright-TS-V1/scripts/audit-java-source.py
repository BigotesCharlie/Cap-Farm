"""Independent Java @Test identity/annotation check against the migration ledger."""
import argparse
import json
import re
from pathlib import Path

def without_comments(source):
    pattern = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/')
    return pattern.sub(lambda m: re.sub(r'[^\n]', ' ', m.group()) if m.group().startswith(('/',)) else m.group(), source)

def annotation_end(source, start):
    cursor = start
    while cursor < len(source) and source[cursor].isspace():
        cursor += 1
    if cursor >= len(source) or source[cursor] != '(':
        return cursor
    depth = 0
    quoted = False
    escaped = False
    for i in range(cursor, len(source)):
        char = source[i]
        if escaped:
            escaped = False
            continue
        if char == '\\' and quoted:
            escaped = True
        elif char == '"':
            quoted = not quoted
        elif not quoted:
            if char == '(':
                depth += 1
            elif char == ')':
                depth -= 1
                if depth == 0:
                    return i + 1
    raise ValueError('Unclosed Java annotation')

parser = argparse.ArgumentParser()
parser.add_argument('--source', required=True, type=Path, help='Master project root')
args = parser.parse_args()
contracts = json.loads(Path('migration/audit/legacy-method-contracts.json').read_text())
found = {}
errors = []
for path in args.source.joinpath('src/test/java').rglob('*.java'):
    source = without_comments(path.read_text(errors='replace'))
    package = re.search(r'^\s*package\s+([\w.]+)\s*;', source, re.M)
    declaration = re.search(r'^\s*public\s+(?:abstract\s+|final\s+)?class\s+(\w+)', source, re.M)
    if not package or not declaration:
        continue
    for match in re.finditer(r'@Test\b', source):
        end = annotation_end(source, match.end())
        cursor = end
        while True:
            tail = source[cursor:].lstrip()
            offset = len(source[cursor:]) - len(tail)
            other = re.match(r'@[\w.]+', tail)
            if not other:
                cursor += offset
                break
            cursor = annotation_end(source, cursor + offset + other.end())
        method = re.match(r'(?:public|protected|private)\s+(?:(?:static|final|synchronized)\s+)*(?:[\w.<>\[\]?]+)\s+(\w+)\s*\(', source[cursor:])
        if not method:
            errors.append({'file': str(path.relative_to(args.source)), 'line': source.count('\n', 0, match.start()) + 1, 'reason': 'Could not resolve @Test method'})
            continue
        identity = f'{package[1]}.{declaration[1]}#{method[1]}'
        if identity in found:
            errors.append({'identity': identity, 'reason': 'Duplicate Java identity'})
        found[identity] = {'file': str(path.relative_to(args.source)), 'line': source.count('\n', 0, match.start()) + 1, 'annotation': source[match.start():end]}
        contract = contracts.get(identity)
        if contract:
            if contract['sourceFile'] != found[identity]['file'] or contract['sourceLine'] != found[identity]['line']:
                errors.append({'identity': identity, 'reason': 'Source location differs'})
            if re.sub(r'\s+', '', contract['annotation']) != re.sub(r'\s+', '', found[identity]['annotation']):
                errors.append({'identity': identity, 'reason': 'Annotation differs'})
        else:
            errors.append({'identity': identity, 'reason': 'Missing migration contract'})
for identity in set(contracts) - set(found):
    errors.append({'identity': identity, 'reason': 'No Java @Test method'})
print(json.dumps({'javaMethods': len(found), 'contracts': len(contracts), 'errors': errors}, indent=2))
raise SystemExit(1 if errors else 0)
