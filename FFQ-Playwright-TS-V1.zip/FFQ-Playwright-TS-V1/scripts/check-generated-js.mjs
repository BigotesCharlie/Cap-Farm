import { readdir } from 'node:fs/promises';
import { join, relative } from 'node:path';

async function collect(directory) {
  const entries = await readdir(directory, { withFileTypes: true }).catch(() => []);
  return (
    await Promise.all(
      entries.map((entry) => {
        const path = join(directory, entry.name);
        return entry.isDirectory() ? collect(path) : [path];
      }),
    )
  ).flat();
}

const offenders = (await Promise.all(['src', 'tests'].map(collect)))
  .flat()
  .concat(['playwright.config.js', 'playwright.config.js.map', 'playwright.config.d.ts'])
  .filter((file) => /\.(?:js|js\.map|d\.ts)$/.test(file));
const { access } = await import('node:fs/promises');
const present = [];
for (const file of offenders) {
  if (
    await access(file)
      .then(() => true)
      .catch(() => false)
  )
    present.push(relative('.', file));
}
console.log(JSON.stringify({ generatedJsArtifacts: present, count: present.length }, null, 2));
if (present.length) process.exitCode = 1;
