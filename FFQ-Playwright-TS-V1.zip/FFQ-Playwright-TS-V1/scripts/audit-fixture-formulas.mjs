import { readFile, mkdtemp, rm } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';

const output = await mkdtemp(resolve('.ffq-formula-audit-'));
try {
  const compilation = spawnSync(resolve('node_modules/.bin/tsc'), ['--outDir', output, '--noEmit', 'false'], {
    stdio: 'inherit',
  });
  if (compilation.status !== 0) throw Error('TypeScript compilation failed');
  const { materializeRow, rawRows } = await import(pathToFileURL(join(output, 'src/data/FixtureCatalog.js')).href);
  const manifest = JSON.parse(await readFile('src/data/catalog/manifest.json', 'utf8'));
  const failures = [];
  let checked = 0;
  for (const [book, sheets] of Object.entries(manifest)) {
    for (const sheet of Object.keys(sheets)) {
      for (const row of await rawRows(book, sheet)) {
        for (const [field, value] of Object.entries(row)) {
          if (!value || typeof value !== 'object' || !('__excelFormula' in value)) continue;
          checked++;
          try {
            await materializeRow(book, sheet, { [field]: value });
          } catch (error) {
            failures.push({ book, sheet, field, cell: value.cell, reason: String(error?.message ?? error) });
          }
        }
      }
    }
  }
  console.log(JSON.stringify({ checked, successful: checked - failures.length, failures }, null, 2));
  if (failures.length) process.exitCode = 1;
} finally {
  await rm(output, { recursive: true, force: true });
}
