param(
  [Parameter(Mandatory=$true)][string]$PromptFile,
  [Parameter(Mandatory=$true)][string]$TargetRoot,
  [Parameter(Mandatory=$true)][string]$SourceRoot,
  [switch]$PromptViaStdin
)
$ErrorActionPreference='Stop'
if (!(Test-Path -LiteralPath $PromptFile -PathType Leaf)) { throw "Prompt file not found" }
if (!(Test-Path -LiteralPath $TargetRoot -PathType Container)) { throw "Target project not found" }
if (!(Test-Path -LiteralPath $SourceRoot -PathType Container)) { throw "Java source project not found" }
if (!(Get-Command copilot -ErrorAction SilentlyContinue)) {
 Write-Error "GitHub Copilot CLI not installed or not available on PATH. Check 'copilot --version'."
 exit 21
}
# AI credits: automatic. We intentionally do not send --max-ai-credits.
# Copilot consumes what is needed for this task, subject to the company/account plan.
# Autopilot continuations remain bounded; no infinite unattended task loops.
$prompt=Get-Content -LiteralPath $PromptFile -Raw -Encoding UTF8
Push-Location -LiteralPath $TargetRoot
try {
  # --add-dir limits additional project access to the selected Java checkout.
  # --allow-all-tools is optional tool permission, not access to arbitrary paths/URLs.
  # Corporate policy may restrict this flag. Java read-only is an agent instruction,
  # with a post-execution change detector (not an OS-enforced filesystem boundary).
  if ($PromptViaStdin) {
    # GitHub Copilot CLI officially accepts a prompt from stdin. On Windows,
    # passing a multi-line repair prompt through -p can be split/reinterpreted
    # by the native process command-line layer, resulting in
    # "Invalid command format" before Copilot does any work.
    # Only the targeted SKIPPED repair uses this transport. Existing migration
    # and extraction calls deliberately keep their proven -p behavior.
    $OutputEncoding = [System.Text.UTF8Encoding]::new($false)
    Get-Content -LiteralPath $PromptFile -Raw -Encoding UTF8 |
      & copilot --add-dir=$SourceRoot --allow-all-tools --no-ask-user --autopilot --max-autopilot-continues=10
  } else {
    & copilot -p $prompt --add-dir=$SourceRoot --allow-all-tools --no-ask-user --autopilot --max-autopilot-continues=10
  }
  $rc=$LASTEXITCODE
  if ($null -eq $rc) { $rc=1 }
  exit $rc
} finally { Pop-Location }
