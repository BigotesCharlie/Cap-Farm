import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const base=path.resolve(path.dirname(new URL(import.meta.url).pathname),'..');
const server=fs.readFileSync(path.join(base,'server.mjs'),'utf8');
const wrapper=fs.readFileSync(path.join(base,'invoke-copilot.ps1'),'utf8');

test('targeted SKIPPED repair sends the prompt through stdin, not Windows -p',()=>{
 assert.match(server,/const outcome=await invokeCopilot\(prompt,'migrate',\{promptViaStdin:true\}\);/);
 assert.match(server,/if\(options\.promptViaStdin\)args\.push\('-PromptViaStdin'\)/);
 assert.match(wrapper,/\[switch\]\$PromptViaStdin/);
 assert.match(wrapper,/if \(\$PromptViaStdin\) \{/);
 assert.match(wrapper,/Get-Content -LiteralPath \$PromptFile -Raw -Encoding UTF8 \|\s*& copilot --add-dir=\$SourceRoot/);
 assert.doesNotMatch(wrapper.slice(wrapper.indexOf('if ($PromptViaStdin) {'),wrapper.indexOf('} else {')),/& copilot\s+-p/);
});
test('existing migration and extraction preserve known -p interface',()=>{
 assert.match(wrapper,/\} else \{\s*& copilot -p \$prompt --add-dir=\$SourceRoot/);
 assert.match(server,/invokeCopilot\(p,'extract'\)/);
 assert.match(server,/invokeCopilot\(p,'migrate'\)/);
});
test('repair remains explicit and limited in scope',()=>{
 assert.match(server,/SOURCE_TEST_SKIPPED/);
 assert.match(server,/SKIP_REPAIR_BLOCKED_SAFETY/);
 assert.match(server,/Original spec backup/);
 assert.match(server,/Do not blindly remove test.skip/);
 assert.match(server,/DO NOT run browser/);
});
