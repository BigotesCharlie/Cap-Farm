"""Isolated iGero functional-run integration with a fake local Playwright CLI.
No Farmers access, no Copilot call and no Java/Excel mutation.
"""
import json, os, pathlib, shutil, subprocess, tempfile, time, urllib.request, urllib.parse, urllib.error

src = pathlib.Path(__file__).resolve().parents[1]
root = pathlib.Path(tempfile.mkdtemp(prefix='igero-v211-focused-env-'))
java, target, launcher = root/'java', root/'target', root/'launcher'
java_file = java/'src/test/java/com/farmers/ffq/acehome/AceHomeAboutYouPageTest.java'
java_file.parent.mkdir(parents=True)
java_file.write_text('public class AceHomeAboutYouPageTest {\n @Test public void pageContentValidationAboutYouPageHomeLob() { System.out.println("check"); }\n}')
method = 'AceHomeAboutYouPageTest#pageContentValidationAboutYouPageHomeLob'
disabled_java = java/'src/test/java/com/farmers/ffq/acehome/AceHomeDisabledPageTest.java'
disabled_java.write_text('public class AceHomeDisabledPageTest {\n @Test(enabled=false) public void disabledContentTest() { }\n}')
disabled_method='AceHomeDisabledPageTest#disabledContentTest'
spec_rel='tests/acehome/AceHomeAboutYouPageTest.pageContentValidationAboutYouPageHomeLob.spec.ts'
spec=target/spec_rel; spec.parent.mkdir(parents=True)
spec.write_text("import { test } from '@playwright/test';\ntest('AceHomeAboutYouPageTest#pageContentValidationAboutYouPageHomeLob', async () => {});\n")
cli=target/'node_modules/playwright/cli.js';cli.parent.mkdir(parents=True)
cli.write_text('''const fs=require('node:fs');
const args=process.argv.slice(2);
const title='AceHomeAboutYouPageTest#pageContentValidationAboutYouPageHomeLob';
const file='tests/acehome/AceHomeAboutYouPageTest.pageContentValidationAboutYouPageHomeLob.spec.ts';
if(args.includes('--list')){console.log('Listing tests:');console.log('  [chromium] › '+file+':2:1 › '+title);console.log('Total: 1 test in 1 file');process.exit(0)}
const guard=(process.env.TEST_ENV==='MA11' && process.env.HEADLESS==='false' && process.env.WORKERS==='1' && process.env.RETRIES==='0' && args.includes('--headed') && args.includes('--workers=1') && args.includes('--retries=0'));
const status=guard?'expected':'skipped';
const report={suites:[{title:'',specs:[{title,tests:[{projectName:'chromium',expectedStatus:'passed',status,annotations:guard?[]:[{type:'skip',description:'Runtime requires TEST_ENV=MA11, HEADLESS=false, WORKERS=1, RETRIES=0'}],results:[{status:guard?'passed':'skipped',duration:5,steps:guard?[{title:'source content check',duration:5}]:[]}]}]}]}]};
fs.writeFileSync(process.env.PLAYWRIGHT_JSON_OUTPUT_NAME,JSON.stringify(report));
console.log('MOCK LOCAL PLAYWRIGHT: '+(guard?'GUARD SATISFIED: one test executed':'GUARD MISSING: skipped'));
process.exit(0);
''')
(target/'node_modules/@playwright/test').mkdir(parents=True)
(target/'node_modules/@playwright/test/package.json').write_text('{"version":"1.64.0"}')
(target/'node_modules/.bin').mkdir(parents=True)
(target/'node_modules/.bin/playwright').touch()
art = target/'migration/pervez-json/AceHomeAboutYouPageTest__pageContentValidationAboutYouPageHomeLob'
art.mkdir(parents=True)
(art/'contract.json').write_text(json.dumps(dict(className='AceHomeAboutYouPageTest', methodName='pageContentValidationAboutYouPageHomeLob',testAnnotation={'enabled':True},steps=[],assertions=[{'id':'one'}],unresolved=[])))
(art/'prompt.md').write_text('Source mirror. Read Java source only. Do not edit Java.')
art_disabled=target/'migration/pervez-json/AceHomeDisabledPageTest__disabledContentTest'
art_disabled.mkdir(parents=True)
(art_disabled/'contract.json').write_text(json.dumps(dict(className='AceHomeDisabledPageTest',methodName='disabledContentTest',testAnnotation={'enabled':False},steps=[],assertions=[],unresolved=[])))
(art_disabled/'prompt.md').write_text('Original Java @Test(enabled=false) is disabled by the source contract. Keep this scenario skipped in Playwright and retain every assertion and business condition.')

launcher.mkdir()
for f in ['server.mjs','playwright-launcher.mjs','focused-test-resolver.mjs','skip-result-classifier.mjs','lob-catalog.mjs','registry-isolation.mjs','index.html','app.js']:
    shutil.copy2(src/f, launcher/f)
(launcher/'config.local.json').write_text(json.dumps(dict(javaRoot=str(java),playwrightRoot=str(target),testEnv='MA11',autoTypecheck=True,autoFunctionalCheck=True)))
# The fake npm only verifies typecheck; Playwright discovery and run use project-local cli.js
bin = root/'bin'; bin.mkdir()
(bin/'npm').write_text('#!/bin/sh\necho "MOCK TypeScript typecheck passed"\nexit 0\n')
(bin/'npm').chmod(0o755)
port='18889'
env=os.environ.copy();env['IGERO_PANEL_PORT']=port;env['PATH']=str(bin)+os.pathsep+env['PATH']
# Deliberately hostile inherited environment; focused runtime MUST override it.
env.update(HEADLESS='true',WORKERS='8',RETRIES='3',TEST_ENV='RA11')
proc=subprocess.Popen(['node','server.mjs'],cwd=launcher,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
def api(uri, body=None):
    req=urllib.request.Request('http://127.0.0.1:'+port+uri,headers={'Content-Type':'application/json'},data=json.dumps(body).encode() if body is not None else None)
    with urllib.request.urlopen(req,timeout=10) as response:return json.load(response)
try:
    for _ in range(70):
        try:api('/api/job');break
        except Exception:time.sleep(.07)
    method_uri=urllib.parse.quote(method)
    listed=api('/api/spec-candidates?id='+method_uri)
    assert listed['registered']==1, listed
    print('PASS: Java source method identified + Playwright test registered, no browser launched')
    start=api('/api/start',{'methodId':method,'mode':'functional'})
    for _ in range(200):
        job=api('/api/job')
        if job and job['status']!='running':break
        time.sleep(.10)
    else:raise AssertionError('Functional check timed out')
    print('final status:',job['status'],'verdict:',job['functional']['verdict'])
    assert job['functional']['verdict']=='PLAYWRIGHT_PASS_PARITY_UNVERIFIED',job
    assert job['functional']['counts']['passed']==1,job
    assert job['functional']['counts']['skipped']==0,job
    assert any('Functional runtime: TEST_ENV=MA11, HEADLESS=false, WORKERS=1, RETRIES=0' in item['text'] for item in job['logs'])
    assert any('MOCK LOCAL PLAYWRIGHT: GUARD SATISFIED' in item['text'] for item in job['logs'])
    assert spec.read_text().startswith('import { test }'), 'Test spec should remain unchanged'
    assert java_file.read_text().startswith('public class'), 'Source Java should remain unchanged'
    print('PASS: focused run propagated all four runtime environment flags, test was executed, no SKIP, correct unverified-parity verdict')
    # Old report with skip from missing launcher variables triggers a zero-credit repair result
    previous={'methodId':method,'verdict':'SKIPPED_RUNTIME','reason':'Playwright reported skip/fixme annotation: skip: Runtime requires TEST_ENV=MA11, HEADLESS=false, WORKERS=1, RETRIES=0','selectedSpec':str(spec), 'projectName':'chromium','tests':[]}
    (art/'functional-summary.json').write_text(json.dumps(previous))
    repair=api('/api/repair-skipped-test',{'methodId':method})
    assert repair['repairKind']=='RUNTIME_CONFIGURATION',repair
    assert not repair['changed']
    assert not list((art/'repair-backups').glob('*')) if (art/'repair-backups').exists() else True
    print('PASS: Repair skipped TC correctly redirects old launcher skip to runtime flags without Copilot or spec edits')
    disabled=api('/api/methods?q=disabledContentTest')['methods']
    assert len(disabled)==1 and disabled[0]['skipped'] is True, disabled
    api('/api/start',{'methodId':disabled_method,'mode':'functional'})
    for _ in range(100):
        disabled_job=api('/api/job')
        if disabled_job and disabled_job['status']!='running':break
        time.sleep(.07)
    assert disabled_job['functional']['verdict']=='SOURCE_TEST_SKIPPED', disabled_job
    assert disabled_job['functional']['counts']['total']==0
    print('PASS: Java @Test(enabled=false) remains SOURCE_TEST_SKIPPED with zero executed tests')
finally:
    proc.terminate()
    try:proc.communicate(timeout=6)
    except subprocess.TimeoutExpired:proc.kill();proc.communicate()
    shutil.rmtree(root,ignore_errors=True)
