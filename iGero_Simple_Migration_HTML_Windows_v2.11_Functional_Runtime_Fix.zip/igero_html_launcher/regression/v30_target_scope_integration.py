"""V3.0: real server + simulated Playwright list; no Copilot, no Farmers browser."""
from pathlib import Path
import os, tempfile, subprocess, shutil, urllib.request, urllib.parse, json, time, socket
root=Path(tempfile.mkdtemp(prefix='igero-v30-target-'))
base=Path(__file__).resolve().parents[1]
java=root/'java';pw=root/'pw';bin_dir=root/'bin';launcher=root/'launcher'
cls='AceHomeGoToPaymentSectionTest';meth='testQuoteAndBindHomeLob'
s=(java/f'src/test/java/com/farmers/ffq/acehome/{cls}.java');s.parent.mkdir(parents=True,exist_ok=True)
s.write_text(f'public class {cls} {{ @Test public void {meth}() {{}} }}',encoding='utf8')
files={
 f'tests/legacy/acehome/{cls}.spec.ts':f"test.skip('{meth}',()=>{{}});",
 'tests/acehome/HomePaymentSectionDiagnostic.spec.ts':f"test('diagnostic',()=>{{/* {meth} */}});",
 'tests/acehome/HomeStateEligibility.spec.ts':f"test('eligibility',()=>{{/* {meth} */}});",
 'tools/igero/java-runner/tests/result-parser.test.mjs':f"test('meta',{repr(meth)});",
 'tests/aceauto/UnrelatedAuto.spec.ts':"test('unrelated',()=>{});",
}
for relative,content in files.items():
 p=pw/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content,encoding='utf8')
(pw/'node_modules/@playwright/test').mkdir(parents=True)
(pw/'node_modules/@playwright/test/package.json').write_text('{}')
bin_dir.mkdir();launcher.mkdir()
for name in ('server.mjs','app.js','index.html','playwright-launcher.mjs','focused-test-resolver.mjs','lob-catalog.mjs','registry-isolation.mjs','skip-result-classifier.mjs'):
 shutil.copy2(base/name,launcher/name)
listing='Listing tests:\n  [chromium] › tests/aceauto/UnrelatedAuto.spec.ts:1:1 › Unrelated Auto\nTotal: 1 test in 1 file\n'
cli=bin_dir/'npx'
cli.write_text('#!/usr/bin/env python3\nimport sys\nif "--list" in sys.argv:\n print('+repr(listing)+')\n sys.exit(0)\nsys.exit(1)\n')
cli.chmod(0o755)
sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
env=os.environ.copy();env.update(PATH=str(bin_dir)+os.pathsep+env['PATH'],IGERO_PANEL_PORT=str(port))
p=subprocess.Popen(['node','server.mjs'],cwd=launcher,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT)
def api(path,data=None):
 q=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(q,timeout=20) as r:return json.load(r)
try:
 for i in range(80):
  try:api('/api/job');break
  except Exception:time.sleep(.1)
 api('/api/config',{'javaRoot':str(java),'playwrightRoot':str(pw),'autoFunctionalCheck':True,'autoTypecheck':True,'testEnv':'MA11'})
 result=api('/api/spec-candidates?id='+urllib.parse.quote(cls+'#'+meth))
 assert result['globallyListed']==1,result
 cand=[x['relativePath'] for x in result['entries']]
 assert cand==[f'tests/legacy/acehome/{cls}.spec.ts'],result
 assert result['registered']==0,result
 assert result['entries'][0]['skipDeclared'],result
 print('PASS v3.0: global Playwright registry healthy; only exact selected source suite reported as unregistered')
 print('PASS v3.0: excludes unrelated diagnostics and iGero helper tests from candidate mapping')
finally:
 p.terminate()
 try:p.wait(timeout=3)
 except:p.kill()
 shutil.rmtree(root,ignore_errors=True)
