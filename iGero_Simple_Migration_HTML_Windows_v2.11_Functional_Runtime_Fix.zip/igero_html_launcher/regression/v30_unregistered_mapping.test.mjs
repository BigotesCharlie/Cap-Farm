import test from 'node:test';
import assert from 'node:assert/strict';
import {isPlausibleUnregisteredSpec} from '../focused-test-resolver.mjs';
const sel={className:'AceHomeGoToPaymentSectionTest',name:'testQuoteAndBindHomeLob'};
test('does not mistake iGero java-runner helper tests for migrated specs',()=>{
  assert.equal(isPlausibleUnregisteredSpec(sel,'tools/igero/java-runner/tests/result-parser.test.mjs',`const fixture = '${sel.name}';`),false);
});
test('does not mistake unrelated HOME utilities that merely mention the Java method',()=>{
  assert.equal(isPlausibleUnregisteredSpec(sel,'tests/acehome/HomeStateEligibility.spec.ts',`test('checks',()=>{/* ${sel.name} */});`),false);
});
test('does not mistake payment diagnostic spec that only quotes method name',()=>{
  assert.equal(isPlausibleUnregisteredSpec(sel,'tests/acehome/HomePaymentSectionDiagnostic.spec.ts',`test('diagnostic',()=>{/* ${sel.name} */});`),false);
});
test('does accept class-specific skipped legacy spec',()=>{
  assert.equal(isPlausibleUnregisteredSpec(sel,'tests/legacy/acehome/AceHomeGoToPaymentSectionTest.spec.ts',`test.skip('placeholder',()=>{});`),true);
});
test('does accept unique dedicated method-specific file',()=>{
  assert.equal(isPlausibleUnregisteredSpec(sel,'tests/acehome/AceHomeGoToPaymentSectionTest.testQuoteAndBindHomeLob.spec.ts',"test('quoted test',()=>{});"),true);
});
test('does accept descriptive filenames with exact legacy ID and test declaration',()=>{
  assert.equal(isPlausibleUnregisteredSpec(sel,'tests/acehome/PaymentBoundaryValidation.spec.ts',`// legacy-id: ${sel.className}#${sel.name}\ntest.skip('boundary',()=>{});`),true);
});
test('does not accept just an exact ID in a README-like text or non-test',()=>{
  assert.equal(isPlausibleUnregisteredSpec(sel,'tests/acehome/PaymentBoundaryValidation.spec.ts',`// legacy-id: ${sel.className}#${sel.name}\nconst x=1;`),false);
});
test('does not accept migration artifacts or node_modules',()=>{
  assert.equal(isPlausibleUnregisteredSpec(sel,'migration/pervez-json/AceHomeGoToPaymentSectionTest.spec.ts','test("",()=>{})'),false);
  assert.equal(isPlausibleUnregisteredSpec(sel,'node_modules/tests/AceHomeGoToPaymentSectionTest.spec.ts','test("",()=>{})'),false);
});
