iGero Simple Migration v2.11 — Focused Functional TC Check fix
===========================================================
BASELINE: v2.10 Targeted Test Mapping; do not modify global Playwright config.

ROOT CAUSE:
In v2.10 Functional TC Check used Playwright CLI switches --headed,
--workers=1 and --retries=0, but passed only TEST_ENV=MA11 into the spawned
process. Source-enabled specs with guards inspecting process.env.HEADLESS,
WORKERS and RETRIES therefore called test.skip() before any page.goto,
so the Chrome window appeared momentarily and closed.

MINIMAL FIX:
- project launcher playwright-launcher.mjs exports functionalRuntimeEnvironment().
- server.mjs calls it for focused --list AND the real headed Playwright process:
  TEST_ENV=<existing selected QA lane>
  HEADLESS=false
  WORKERS=1
  RETRIES=0
- Repair skipped TC recognizes the old missing-launch-flags skip and does not
  call Copilot or rewrite a working spec. Select Run Functional TC Check again.
- Migration prompt says Java-enabled scenarios must not acquire a blanket
  test.skip only to compensate for launch flags. Real source exclusions and
  missing mandatory prerequisites still remain blockers, never false PASS.
- The footer/version was updated so the installed hotfix can be identified.

UNCHANGED:
HTML layout/style/control IDs, Copilot CLI integration, source extraction,
JSON validation, Playwright registry/mapping, existing JS modules, generated
files, financial safety gates, method/suite selectors, AI-credit behavior,
Excel/Java read-only policy, prior evidence and skip classifications.

PATCH UPDATE (recommended):
1. Close the iGero server/window and back up the existing launcher folder.
2. Replace only server.mjs, playwright-launcher.mjs, index.html and VERSION.txt
   in the SAME existing igero_html_launcher folder.
3. Do NOT replace config.local.json and do not overwrite the Playwright repo.
4. Start Start-iGero-HTML.cmd; Ctrl+F5 the browser; verify footer v2.11.
5. Select the SAME source-enabled, non-sensitive HOME test and press only
   Run Functional TC Check. There is no need to re-run JSON/Prompt/TypeScript.
6. A Java source-disabled test or a genuinely unsupported dependency should
   still show SKIPPED/BLOCKED, not FUNCTIONAL PASS.

VALIDATION PERFORMED HERE:
- 69/69 JavaScript regressions passed.
- Isolated mock-CLI integration verified the exact runtime flags even with
  inherited HEADLESS=true/WORKERS=8/RETRIES=3/TEST_ENV=RA11, producing one
  executed test rather than one skipped.
- Old skip repair returned RUNTIME_CONFIGURATION with no Copilot/spec edit.
- Java @Test(enabled=false) still returned SOURCE_TEST_SKIPPED without Chrome.
- This is NOT a real Farmers QA browser run, nor independent source parity.
