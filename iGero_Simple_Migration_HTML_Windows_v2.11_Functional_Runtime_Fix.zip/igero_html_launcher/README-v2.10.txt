iGero Simple Migration v2.10 — Focused source-candidate mapping hotfix
=======================================================================
BASE: v2.9, preserved. This is not a new framework.

OBSERVED FAILURE
- Playwright correctly registers thousands of tests globally.
- For AceHomeGoToPaymentSectionTest#testQuoteAndBindHomeLob, the launcher
  reported unrelated iGero helper/diagnostic specs as "unregistered".
- This was misleading: a source code mention is not a dedicated executable TC.

TARGETED CHANGE
- Exclude tools/igero/, regression/, migration/, and unrelated diagnostics
  from unregistered spec candidates for the selected Java method.
- Require a method/class-specific filename or exact class#method legacy ID
  with a real test declaration, inside a legitimate tests/ or suites/ tree.
- Report TARGET_TC_NOT_REGISTERED for a real method-specific unregistered
  spec and TARGET_TC_NOT_IMPLEMENTED if no dedicated source spec is present.
- Retain the existing single bounded Copilot repair attempt, test registry,
  mapping, skip handling, safety gates and live UI.

UNCHANGED
- Java/Excel read-only policy and both project paths.
- Generate JSON + Prompt, generate TS, automatic AI-credit behavior.
- Playwright registry discovery, headed Chromium runtime gate and reports.
- Repair skipped TC (stdin CLI), backup/recovery behavior, skipped suite.
- Sticky buttons, LOB/Suite dropdowns, expandable checks, colors and spinners.
- No changes to global playwright.config.ts or test source files.

IMPORTANT
- This patch fixes incorrect discovery diagnostics. It DOES NOT certify the
  selected method has been implemented, and it cannot make an absent test PASS.
- If TARGET_TC_NOT_REGISTERED remains after the existing one-shot repair,
  inspect the actual source-aligned test. A legacy skipped stub is not a PASS.
- Bank/payment/Bind scenarios remain blocked for real Chrome execution
  without separate authorization.

VERIFICATION (local isolated, not user's checkout)
- node --test regression/*.test.mjs: 64/64 PASS.
- regression/v30_target_scope_integration.py: PASS.
- regression/v27_api_candidates.py: PASS.
- regression/v28_skipped_integration.py: PASS.
- regression/v29_repair_cli_integration.py: PASS.
- regression/v26_source_skip_api.py: PASS.
- node --check server.mjs, focused-test-resolver.mjs, app.js: PASS.
- Actual Farmers MA11 Chrome functional execution: NOT VERIFIED.

INSTALL
1. Close the old iGero server.
2. Back up the launcher directory.
3. Unzip and replace launcher files only; keep config.local.json unchanged.
4. Start Start-iGero-HTML.cmd and press Ctrl+F5 in the browser.
5. Use a safe HOME content test to check discovery and functional execution.
   For a Bind or payment TC, inspect generated contract/spec only; never
   bypass the financial-operation execution safety gate.
