iGero Simple Migration v2.9 — Targeted SKIPPED Repair CLI Hotfix
================================================================

BASELINE: v2.8 retained.

PROBLEM OBSERVED ON WINDOWS
  Repair skipped TC -> Copilot exited 1 with:
  'Invalid command format. It looks like your prompt was not quoted...'
  The original .spec.ts backup was saved. Chrome was not executed.

MINIMAL CORRECTION
  - ONLY for the opt-in Repair skipped TC operation, forward the multiline
    repair prompt to Copilot CLI using its documented standard-input mode.
  - The existing extraction and TypeScript migration stages continue to use
    their previous -p invocation. They were not refactored.
  - The active Windows PowerShell wrapper still runs in the target project.
    UTF-8 is explicitly selected for the piped prompt.
  - No changes to Playwright discovery, mapping, validation, browser safety,
    Java, Excel, dashboard appearance, selected LOB/suite, AI credits, or config.
  - Java-disablement, authorization, targeted-backup, scope checks and typecheck
    are preserved. Repair never launches Chrome or silently removes a skip.

INSTALL
  1. Close the current iGero server and back up the launcher folder.
  2. Copy files from this zip over your installed launcher.
  3. Keep your existing config.local.json. This zip does not contain one.
  4. Start Start-iGero-HTML.cmd and refresh the browser (Ctrl+F5).
  5. Use Repair skipped TC only after a genuine focused SKIPPED result.
  6. On success, use Run Functional TC Check to verify in the existing browser
     workflow. Never infer Functional PASS from a successful code repair.

VERIFICATION
  - node --check server.mjs and app.js: PASS
  - node --test regression/*.test.mjs: 56/56 PASS
  - baseline skipped integration: PASS (mock Playwright)
  - new focused repair endpoint integration: PASS (mock PowerShell/Copilot)
  - Java disabled and focused candidate regression: PASS
  - Real GitHub Copilot CLI on the user's Windows machine: NOT VERIFIED.

REFERENCE
  GitHub documents stdin-based prompts for Copilot CLI:
  https://docs.github.com/en/copilot/how-tos/copilot-cli/automate-copilot-cli/run-cli-programmatically
