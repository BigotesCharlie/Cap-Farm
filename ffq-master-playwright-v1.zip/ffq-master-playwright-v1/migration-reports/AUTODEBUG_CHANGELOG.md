# AutoDebug / Copy-DOM / Recovery Integration Changelog

## Added framework components

- `AutoDebugConfig.java`
- `AutoDebugManager.java`
- `CopyDomDiagnostics.java`
- `PageState.java`
- `PageStateSnapshot.java`
- `PageStateDetector.java`
- `RecoveryManager.java`
- `RecoveryExhaustedException.java`
- `TestExecutionContext.java`

## Central runtime wiring

- `AutomationFramework`: initializes per-test diagnostic context and finalizes debug evidence from TestNG result.
- `PlaywrightSession`: starts Playwright tracing with the browser context and clears diagnostic thread state on close.
- `PWElement`: click actions are recoverable transitions.
- `PWDriver`: navigation, refresh/back/forward and JavaScript click actions are recoverable transitions.
- `PWSelect`: selection actions participate in rendered-state detection/recovery.
- `PWActions`: raw mouse-click fallback participates in transition diagnostics.

## Configuration

AutoDebug, Copy-DOM and Recovery defaults were added to the FFQ JSON test configuration. All flags can be overridden with JVM `-D` properties and are propagated by the Gradle `test`, `e2eTest`, and `allMigratedTests` tasks.

## Coverage impact

- Test methods before integration: **2,936**
- Test methods after integration: **2,936**
- Missing: **0**
- Added test methods: **0**
- Test classes before/after: **217 / 217**
- Raw `@Test` annotations before/after: **2,942 / 2,942**
- E2E deterministic inventory: **132 methods / 23 classes**
