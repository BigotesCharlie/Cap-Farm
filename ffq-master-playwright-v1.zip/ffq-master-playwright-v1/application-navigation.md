# Application Navigation — Farmers Fast Quote (FFQ)

---

## Application Overview

The **Farmers Fast Quote (FFQ)** application is Farmers Insurance's online quoting and policy-binding platform. It allows prospective customers to receive insurance quotes and purchase policies across multiple **Lines of Business (LOBs)**:

| LOB Identifier | Display Name |
|---|---|
| Auto Insurance | Personal automobile quotes and bind |
| Home Insurance | Homeowner quotes and bind (ACE/HRC flow) |
| Condo Insurance | Condominium quotes and bind |
| Renters Insurance | Renters quotes and bind |
| Life Insurance | Term life quotes |
| Mobile Home Insurance | Mobile / manufactured home quotes |
| Business Insurance | Small business lead capture |
| Auto & Home Bundle | Combined auto + home quoting |
| Auto & Renters Bundle | Combined auto + renters quoting |
| Auto & Condo Bundle | Combined auto + condo quoting |

### Key Sub-Systems and Flows

- **ACE (Ace Quote Engine)** – Modern Angular-based quote UI used for Home, Condo, Renters, Life, Mobile Home, Business. Also used as the backbone of the auto quote redesign.
- **ACE HRC (Home/Renters/Condo)** – Shared base-page hierarchy for Home, Condo, Renters under the ACE umbrella.
- **Auto OneUI / Bind** – Post-quote auto-bind flow with additional info, signal enrollment, payment.
- **Bristol West (BW)** – Alternate carrier bind flow for auto applicants who do not qualify for Farmers standard auto.
- **FGIA (Farmers General Insurance Agency)** / **Foremost** – Partner carrier pages shown when applicant qualifies for a partner product rather than the standard Farmers product.
- **BDQ (Bristol Direct Quote)** – A Bristol West entry flow activated via `Source_Indicator=BW`.
- **HQM (Home Quote Management)** – Legacy home quoting sub-system with its own page hierarchy.
- **Legacy Auto** – Older auto quote pages still in use for certain states/scenarios.
- **Media Alpha** – Third-party partner aggregator flow shown after knockout.
- **Cross-Sell** – Paths that lead from one LOB quote into a second LOB quote.

### Entry Modes

1. **Organic / Landing Page** – User navigates to the FFQ landing page, selects a product and enters ZIP code.
2. **Agent Flow** – Pre-populated applicant data passed via URL for agent-assisted quoting (states: CT, MA, NC, NV, NY, PA, NM, TN, MI, MO, CO, NE, WA).
3. **Partner / Toggle Flow** – Encrypted `?param=` URL parameter with pre-filled customer data (Toggle/Foremost/CSS cross-sell).
4. **BDQ / Bristol West Direct** – `?Source_Indicator=BW&Lob=Auto&SRC=BW…&zip=` entry URL.
5. **CSS-to-FFQ Cross-Sell** – Encrypted URL from CSS system into FFQ with agent/flow parameters.
6. **Retrieve Quote** – Returning user retrieves a saved quote using last name, DOB, quote number/email, and ZIP.

---

## Site Map

```
Landing Page
├── Auto Insurance Quote
│   ├── Name & Date of Birth
│   ├── Address (Enter Address / Heres What We Found)
│   ├── Vehicles & Drivers Info (confirm/edit vehicles & drivers found)
│   │   ├── Vehicle Review / Edit (side-sheet)
│   │   ├── Driver Review / Edit (side-sheet)
│   │   └── Vehicle Driver Assignment
│   ├── Quote Summary (coverage customisation)
│   │   ├── Liability Coverage (side-sheet edit)
│   │   ├── Vehicle Coverage (side-sheet edit)
│   │   └── Discounts
│   ├── [Knockout → Call-For-Quote / Media Alpha / FGIA / Bristol West path]
│   ├── Additional Info - OneUI (bind section)
│   │   ├── Policy Start Date
│   │   ├── Driver Section
│   │   ├── Vehicle Section
│   │   └── Signal Enrollment
│   ├── Consolidated Payment Page (Auto Bind)
│   │   ├── Bank Payment
│   │   └── Debit / Credit Card Payment
│   └── eCheckout / Policy Confirmation
│
├── Bristol West (BW) Auto Sub-Flow
│   ├── BW Additional Discounts
│   ├── BW Payment Summary
│   ├── BW DocuSign
│   └── BW Congratulations
│
├── Home Insurance Quote (ACE/HRC)
│   ├── [New Flow] Address & Contact Page  OR  [Legacy] Name & DOB Page
│   ├── Property Type Page (Home / Townhome / Duplex / Condo / Other)
│   ├── Property Info Page
│   ├── Address Page (property address lookup)
│   ├── Property Details Page (year built, sq ft, stories, bathrooms…)
│   ├── Quality Grade Page
│   ├── Additional Info Page (alarm, pool, trampoline, roof, solar…)
│   ├── About You Page (occupation, prior insurance, marital status…)
│   ├── Contact Info Page (policy start date, email, phone, mailing address)
│   ├── Just A Few More Things (JFMT) Page
│   ├── Review Quote Page (coverage customisation, deductibles)
│   │   ├── Edit Deductibles (side-sheet)
│   │   └── Discounts (side-sheet)
│   ├── [Knockout → Call-For-Quote / FGIA / Media Alpha]
│   ├── Payment Selection Page
│   ├── Policy Payment Page
│   │   ├── Monthly Autopay - Bank
│   │   ├── Monthly Autopay - Card
│   │   └── Pay In Full
│   └── Thank You Page
│
├── Condo Insurance Quote (ACE/HRC)
│   ├── Address / Property Type Page
│   ├── Property Details Page
│   ├── Quality Grade Page
│   ├── Additional Info Page
│   ├── About You / Contact Info Page
│   ├── Custom Coverage Page
│   ├── Just A Few More Things (JFMT) Page
│   ├── Review Quote Page
│   ├── [Knockout → Call-For-Quote]
│   ├── Payment Page
│   └── Thank You Page
│
├── Renters Insurance Quote (ACE)
│   ├── Address Page
│   ├── About You Page
│   ├── Property Type Page
│   ├── Contact Info Page
│   ├── Just A Few More Things (JFMT) Page
│   ├── Review Quote Page
│   ├── [Knockout → Call-For-Quote]
│   ├── Payment (Consolidated) Page
│   └── Thank You (via Thank You page from HRC base)
│
├── Life Insurance Quote (ACE)
│   ├── Name & Date of Birth Page
│   ├── Personal Info Page
│   └── Review Quote Page
│
├── Mobile Home Insurance Quote (ACE)
│   ├── Address Page
│   ├── Tell Us More Page
│   ├── About You Page (Name & DOB)
│   ├── Last Step / Contact Info Page
│   └── Quote Review Page
│       └── [Foremost path → Foremost Landing Page]
│
├── Business Insurance Quote (ACE)
│   ├── Business Lead Form Page
│   └── Thank You Page
│
├── Auto & Home Bundle
│   ├── [Full Auto flow to Quote Summary]
│   ├── [Auto Just A Few More Things / Additional Info]
│   ├── Bundle Review Quotes Page (side-by-side auto + home quotes)
│   ├── [Full HRC Home flow from Property Type]
│   ├── Bundle Final Review Page
│   ├── Bundle Auto Payment Page
│   ├── HRC Payment Selection Page
│   └── eCheckout / Confirmation
│
├── Auto & Renters Bundle
│   └── [Same combined flow with Renters replacing Home]
│
├── Auto & Condo Bundle
│   └── [Same combined flow with Condo replacing Home]
│
├── HQM (Home Quote Management — Legacy)
│   ├── Address Page
│   ├── Property Page
│   ├── Property Details Page
│   ├── Quality Grade Page
│   ├── Customer Info Page
│   ├── Quote Page
│   ├── Discounts Page
│   ├── Contact Info Page
│   ├── Intermediate Page
│   ├── Interstitial Page
│   ├── Print Page
│   ├── Thank You Page
│   ├── Thank You Redirect Page
│   ├── Knockout Page
│   ├── Farmers Insurance Agency Page
│   └── Farmers Choice Page
│
└── Common / Shared
    ├── Landing Page (New Quote / Retrieve Quote tabs)
    ├── Knockout / Inconvenience Page
    ├── Call For Quote Page
    ├── Bristol West Landing Page
    ├── FGIA Landing Page
    ├── Foremost Landing Page
    ├── MediaAlpha Start Page (Auto / Home)
    ├── Legacy Non-Offering Page
    └── Save & Finish Later Popup
```

---

## Navigation Flows

### Flow 1 — Auto Insurance (Standard/Organic)
```
Landing Page (select Auto, enter ZIP)
→ Name & Date of Birth Page
→ Address Page (enter address)
→ "Here's What We Found" Page (confirm DMV data)
→ Vehicles & Drivers Info Page (review/edit vehicles, drivers)
→ Quote Summary Page (select coverages)
→ Additional Info OneUI (policy start date, driver, vehicle, signal sections)
→ Consolidated Payment Page (select pay plan, add bank/card)
→ eCheckout Success Page
```

### Flow 2 — Auto Insurance (Bristol West / BW)
```
BDQ Starting Page OR Landing Page (BW organic URL)
→ Name & Date of Birth Page
→ Address Page
→ Vehicles & Drivers Info Page
→ Quote Summary Page → "Continue with Bristol West" dialog
→ BW Additional Discounts Page
→ BW Payment Summary Page
→ BW DocuSign Page
→ BW Congratulations Page
```

### Flow 3 — Auto Insurance (Agent Flow)
```
Agent-specific URL (?Agent_Code=…)
→ Name & Date of Birth Page (pre-populated)
→ Address Page
→ Vehicles & Drivers Info Page
→ Quote Summary Page
→ Additional Info → Payment → eCheckout
```

### Flow 4 — Auto Insurance (Knockout → FGIA/Foremost)
```
Landing Page → ... → Quote Summary
→ Knockout / Inconvenience Page
→ Continue to FGIA / Foremost
→ FGIA Landing Page OR Foremost Landing Page
```

### Flow 5 — Auto Insurance (Knockout → Media Alpha)
```
Landing Page → ... → Knockout
→ Media Alpha Start Page
→ Partner Premium Details Page
```

### Flow 6 — Home Insurance (New Flow States)
```
Landing Page (select Home, enter ZIP)
→ Address & Contact Page (combined name/DOB + address)
→ Property Type Page (Home / Townhome / Duplex / Condo / Other)
→ Property Info Page
→ Property Details Page (pre-filled, review & edit)
→ Quality Grade Page
→ Additional Info Page
→ About You Page
→ Contact Info Page (policy start date, mailing address)
→ Just A Few More Things (JFMT) Page
→ Review Quote Page (edit coverages, deductibles, discounts)
→ Payment Selection Page
→ Policy Payment Page (Monthly Autopay Bank/Card or Pay In Full)
→ eCheckout Success / Thank You Page
```

### Flow 7 — Home Insurance (Legacy Flow States)
```
Landing Page
→ Name & Date of Birth Page
→ Property Type Page
→ Address Page → Property Details → Quality Grade
→ Additional Info → About You → Contact Info
→ JFMT → Review Quote → Payment → Thank You
```

### Flow 8 — Home Insurance (Call For Quote)
```
Landing Page → ... → Contact Info Page
→ Call For Quote Page (phone number displayed, no online bind)
→ Option: "I'd rather quote with Farmers online" → Back to quote
```

### Flow 9 — Condo Insurance
```
Landing Page (select Condo, enter ZIP)
→ Address / Property Type Page
→ Property Details Page
→ Quality Grade Page
→ Additional Info Page
→ About You / Contact Info Page
→ Custom Coverage Page
→ JFMT Page
→ Review Quote Page
→ Payment Page → Thank You Page
```

### Flow 10 — Renters Insurance
```
Landing Page (select Renters, enter ZIP)
→ Address Page
→ About You Page (DOB, name, marital status)
→ Property Type Page
→ Contact Info Page (policy start date, email)
→ JFMT Page
→ Review Quote Page
→ Consolidated Payment Page → Thank You Page
```

### Flow 11 — Life Insurance
```
Landing Page (select Life, enter ZIP)
→ Name & Date of Birth Page
→ Personal Info Page
→ Review Quote Page
```

### Flow 12 — Mobile Home Insurance (ACE)
```
Landing Page (select Mobile Home, enter ZIP)
→ Address Page (mobile home property address)
→ Tell Us More Page (home details)
→ About You Page (Name & DOB)
→ Last Step / Contact Info Page (email, phone, policy start date)
→ Quote Review Page
```

### Flow 13 — Mobile Home (Foremost Redirect)
```
Landing Page → ... → Mobile Home Quote Review
→ [Foremost path detected]
→ Foremost Landing Page
```

### Flow 14 — Business Insurance
```
Landing Page (select Business, enter ZIP)
→ Business Lead Form Page
→ Thank You Page
```

### Flow 15 — Auto & Home Bundle
```
Landing Page (select Auto & Home, enter ZIP)
→ Auto quote flow (Name & DOB → Vehicles/Drivers → Quote Summary)
→ Auto Just A Few More Things (Additional Info)
→ Bundle Review Quotes Page (auto + home side by side)
→ Home quote flow (Property Type → Details → Review)
→ Bundle Final Review Page
→ Auto Payment Page
→ HRC Payment Selection Page
→ eCheckout
```

### Flow 16 — Auto & Renters Bundle
```
[Same as Auto & Home Bundle with Renters replacing Home flow]
→ Renters flow (Address → About You → Contact Info → JFMT → Review)
```

### Flow 17 — Auto & Condo Bundle
```
[Same as Auto & Home Bundle with Condo replacing Home flow]
→ Condo flow (Address → Property Details → Review)
```

### Flow 18 — Retrieve Quote
```
Landing Page (Retrieve tab selected)
→ Enter: Last Name, Date of Birth, Quote Number OR Email, ZIP Code
→ Redirected to last saved page of existing quote
→ Continue quote from saved state
```

### Flow 19 — Partner / Toggle (Pre-populated) Flow
```
Encrypted URL (?param=…&Flow=TG&SRC=TOGREHBZFQ)
→ [Skip Landing] → Auto/Home quote begins with pre-filled data
```

### Flow 20 — CSS-to-FFQ Cross-Sell
```
CSS system redirect → Encrypted URL → FFQ Home Quote
→ Normal Home flow from Address/Contact Page
```

---

## Page Inventory

---

### Landing Page

#### Purpose
Entry point for the entire FFQ application. Users start a new quote or retrieve a previously saved quote.

#### Entry Points
- Direct URL navigation (organic)
- Partner/agent redirect URL (with query parameters)
- BDQ/Bristol West URL (`?Source_Indicator=BW`)

#### Exit Paths
- Product selected → LOB-specific first page
- Retrieve quote → resumes saved quote
- Invalid ZIP/product → inline error message

#### Key UI Elements
- LOB selection buttons: Auto, Home, Condo, Renters, Life, Mobile Home, Business, Auto & Home, Auto & Renters, Auto & Condo
- ZIP code input field (`aria-label='Zip code'`)
- "Start My Quote" / "GET A QUOTE" button
- "Retrieve Your Quote" tab with: Last Name, Date of Birth, Quote Number or Email, ZIP
- Error dialogs: "We were unable to locate your quote", ZIP code errors, product selection errors

#### Important Actions
- `enterLandingPageData(lob, zipCode)` — select product + enter ZIP + click Start
- `retrieveQuoteFromLandingPage(lastName, dob, quoteNumberOrEmail, zip)` — populate retrieve fields
- Toggle between New Quote tab and Retrieve Saved Quote tab

#### Related Pages
- All LOB first pages (NameAndDobPage, AceRentersAddressPage, AceMobileHomeAddressPage, etc.)

---

### Name & Date of Birth Page (Auto / Life)

#### Purpose
Collects primary applicant's personal identification for auto and life insurance quoting.

#### Entry Points
- Landing Page (Auto or Life LOB selected)
- BDQ Starting Page → auto-filled from session storage

#### Exit Paths
- Continue → Address Page (Auto) or Personal Info Page (Life)
- Validation errors → stay on page

#### Key UI Elements
- First Name input (`aria-label='First name'`)
- Last Name input (`aria-label='Last name'`)
- Date of Birth input (`aria-label='Date of birth'`)
- Continue button (`data-tui-tracking-id='personal-info__continue-button-cta'`)
- Privacy Policy / ESIGN disclaimer text
- Credit check disclaimer
- "Show More" button for extended disclaimers
- Media Alpha variant: additional disclaimer paragraphs

#### Important Actions
- `filloutApplicantForm(AutoApplicant)` — fills name + DOB and clicks Continue
- `filloutApplicantFormWithNoInput()` — clicks Continue without filling (triggers validation)
- Age validation: 15–99 years

#### Related Pages
- Address Page (Auto), Personal Info Page (Life), Landing Page

---

### Address Page / Auto Enter Address Page

#### Purpose
Collects or confirms the applicant's home/garaging address for auto quotes.

#### Entry Points
- Name & DOB Page → Continue

#### Exit Paths
- Continue → "Here's What We Found" Page (DMV data pre-population)
- Knockout → Knockout/Inconvenience Page

#### Key UI Elements
- Address autocomplete input
- Street, City, State, ZIP fields
- "Recent Mover" toggle/link

#### Important Actions
- Enter and confirm address
- Handle address disambiguation

#### Related Pages
- Name & DOB Page, HeresWhatWeFoundPage, AutoRecentMoverPage

---

### "Here's What We Found" Page (Auto)

#### Purpose
Displays vehicles and drivers retrieved from DMV/database lookup. User confirms or adds vehicles and drivers before quoting.

#### Entry Points
- Address Page → Continue

#### Exit Paths
- Continue → Vehicles & Drivers Info Page
- Add vehicle / Add driver → side-sheets open inline

#### Key UI Elements
- Found vehicles list (year, make, model)
- Found drivers list (names)
- "Add another vehicle" button
- "Add another driver" button

#### Related Pages
- Vehicles & Drivers Info Page

---

### Vehicles & Drivers Info Page (Auto)

#### Purpose
Review, select, and edit vehicles and drivers for the auto quote. Users can select which vehicles/drivers to include and modify their details.

#### Entry Points
- "Here's What We Found" Page → Continue

#### Exit Paths
- Continue → Quote Summary Page (Auto)
- Knockout

#### Key UI Elements
- Vehicle cards (checkbox selected/unselected, Edit link)
- Driver cards (checkbox, name, Edit link)
- Add another vehicle button (`tui-btn-cta add-button`)
- Add another driver button
- Info side-sheets (VIN helper, driver info)
- VIN input field (`formcontrolname='vin'`)
- Year/Make/Model/Type dropdowns
- Driver details: First Name, Last Name, DOB, Gender, Occupation, Marital status, Accidents/Violations, Safety course, SR-22
- Continue button

#### Important Actions
- `addAnotherVehicleButton` click → Vehicle form side-sheet opens
- `addAnotherDriverButton` click → Driver form side-sheet opens
- Select/deselect vehicles and drivers via checkboxes
- Edit vehicle opens a side-sheet with full vehicle form
- Edit driver opens a side-sheet

#### Related Pages
- Quote Summary Page, Driver Review Page, Vehicle Review Page

---

### Quote Summary Auto Page

#### Purpose
Displays the priced auto insurance quote. Users can customise coverage levels and payment plans.

#### Entry Points
- Vehicles & Drivers Info Page → Continue

#### Exit Paths
- Start Checkout / Continue → Additional Info / Bind flow
- Bundle & Save → Bundle path
- Knockout → Knockout page
- Email quote link → email dialog

#### Key UI Elements
- Liability coverage section (Bodily Injury, Property Damage, Uninsured Motorist, Underinsured Motorist, Medical Payments)
- Per-vehicle coverage section (Comprehensive, Collision, Rental, Towing)
- Discounts section (names and count)
- "Edit Liability Coverage" side-sheet button
- Quote price display (6-month term)
- Alternative payment method link
- Email quote link
- "Start checkout" / "Continue with auto" / "Continue with this quote" CTA
- "Bundle and save" button
- Bristol West disclaimer footer (if BW path)

#### Important Actions
- Toggle coverage on/off (Comp, Coll, UM, UIM, Medical)
- Select radio button for coverage limits
- Click "Edit Liability Coverage" → opens edit side-sheet with close icon
- View discounts side-sheet

#### Related Pages
- Additional Info OneUI / Bind Flow pages, Bundle Review Quotes Page

---

### Consolidated Payment Page (Auto Bind)

#### Purpose
Auto insurance payment selection and completion. Displays pay-in-full vs. monthly autopay options with bank or card payment setup.

#### Entry Points
- Additional Info (Signal, Driver, Vehicle, Policy Start Date sections complete) → Continue

#### Exit Paths
- Complete purchase → eCheckout Success Page
- Knockout (payment error) → Knockout page
- Change coverage link → Quote Summary

#### Key UI Elements
- Pay In Full radio button
- Monthly Autopay radio button
- Payment method: Bank radio button / Card radio button
- Pay plan details: 6-month term price, fees, surcharges, due today
- Monthly breakdown: View Breakdown link
- Bank added confirmation / Card added confirmation
- Charge disclaimer text
- "Complete Purchase" button
- Fee info icon (modal on click)
- California-specific card payment restrictions

#### Important Actions
- Select pay plan (pay in full vs monthly)
- Select payment method (bank vs card)
- Enter bank details (routing + account number) — via Paymentus iframe
- Enter card details — via Paymentus iframe
- Click "Complete Purchase"

#### Related Pages
- eCheckout Success Page, Quote Summary (via "Change coverage" link)

---

### eCheckout Successful Page (Auto Bind)

#### Purpose
Confirms successful auto policy purchase.

#### Entry Points
- Consolidated Payment Page → Complete Purchase

#### Key UI Elements
- "Payment successful" message
- Policy number
- Download/print confirmation

---

### ACE HRC Property Type Page (Home / Condo)

#### Purpose
Allows user to select the type of property being insured.

#### Entry Points
- Landing Page (Home/Condo selected) → first page, OR
- Address & Contact Page (new flow states) → Continue

#### Exit Paths
- Select property type + Continue → Property Info Page / Address Page
- Knockout for unsupported property types

#### Key UI Elements
- Image cards: Home, Townhome, Duplex, Condo, Other (each with description)
- Primary Residence Yes/No toggle
- If Not Primary: reason radio buttons (Long-term rental, Seasonal, Vacant, Short-term rental)
- Continue button

#### Important Actions
- `selectPropertyType(String)` — click appropriate image card
- `selectPrimaryResidence(boolean)` — toggle Yes/No
- `selectNotPrimaryResidenceReason(String)` — select reason radio

#### Related Pages
- Property Info Page, Address Page

---

### Property Details Page (Home / HRC)

#### Purpose
Displays pre-filled property information from public records. Users review and correct home details.

#### Entry Points
- Property Type or Property Info Page → Continue

#### Exit Paths
- Continue → Quality Grade Page (or next in sequence)

#### Key UI Elements
- Property address display (Line 1, Line 2)
- Edit Home Details button / Review & Edit Information button
- Property attributes: Year Built, Total sq ft, Stories, Bathrooms, Roof Cover, Exterior Wall, Garage Style, Foundation Type, Finished Basement, Fireplace, Floor Coverings, Type of Home, Market Value, Fire Sprinkler System
- Edit modal (side-sheet) per attribute with radio buttons, toggles, dropdowns, and inputs
- "Update" button in edit modal
- "See examples" link for visual guidance
- Property updated snackbar confirmation

#### Important Actions
- Click "Edit Home Details" / "Review & edit information"
- Select property attribute values in modal
- Click "Update" to save changes

#### Related Pages
- Quality Grade Page

---

### Quality Grade Page (Home / HRC)

#### Purpose
Captures the interior quality/grade of the home (Standard, Semi-Custom, Custom, etc.).

#### Entry Points
- Property Details Page → Continue

#### Exit Paths
- Continue → Additional Info Page

#### Key UI Elements
- Quality grade selection cards or radio buttons
- Descriptions per grade

---

### Additional Info Page (Home / HRC)

#### Purpose
Collects information about home features that affect coverage and discounts (security systems, pool, trampoline, roof replacement, solar panels, etc.).

#### Entry Points
- Quality Grade Page → Continue

#### Exit Paths
- Continue → About You Page

#### Key UI Elements
- Checkboxes for: Swimming Pool, Trampoline, Oil Tank, Solar Panels, Temporary Rental, Impact Resistant Glass
- Radio buttons: Fenced vs Unfenced (Pool/Trampoline)
- Roof Replacement toggle (Yes/No) + year input
- Plumbing replacement question
- Alarm type radio buttons: Unmonitored, Professionally Monitored, Self-monitored
- FORTIFIED home certification options
- Sprinkler system (Full / Partial)
- UL Roof certification checkbox

#### Important Actions
- Check/uncheck feature checkboxes
- If swimming pool or trampoline selected → specify fenced/unfenced

#### Related Pages
- About You Page

---

### About You Page (Home / HRC)

#### Purpose
Collects applicant personal information: occupation, marital status, prior insurance, and bundling options.

#### Entry Points
- Additional Info Page → Continue

#### Exit Paths
- Continue → Contact Info Page

#### Key UI Elements
- Occupation dropdown/selector
- Marital status options
- Prior insurance questions
- Bundle discount triggers: Auto policy, Life policy, Umbrella, Business, Watercraft, Off-road, RV
- Discount confirmation snack-bars (e.g. "Nice! We'll add an auto bundle discount.")

---

### Contact Info Page (Home / HRC / Renters / Condo)

#### Purpose
Collects contact information, policy start date, and mailing address.

#### Entry Points
- About You Page → Continue (or after Address/Property Type for some LOBs)

#### Exit Paths
- Agree & Submit → Review Quote Page
- Knockout → Call For Quote Page

#### Key UI Elements
- Policy start date date-picker (1 day to 60 days from today)
- Early Shopping discount message (≥7 days = discount applied)
- Email field
- Phone number field
- Mailing address radio: same as property address vs. Other
- If Other: Street, Apt, City, State, ZIP fields
- ESIGN disclaimer
- CTA disclaimer (marketing consent)
- "Agree and submit" button

#### Important Actions
- Enter policy start date
- Select mailing address option
- Click "Agree and submit" → triggers rating call (RC2/RC3)

#### Related Pages
- Review Quote Page, Call For Quote Page

---

### Review Quote Page (Home / Condo / Renters / HRC)

#### Purpose
Displays the rated insurance quote with coverage breakdown and discounts. User can customise coverages, deductibles, and see pricing.

#### Entry Points
- Contact Info Page → rating complete

#### Exit Paths
- Continue → Just A Few More Things (JFMT) Page
- Knockout → Call For Quote or Thank You (non-purchasable)
- Email this quote → email confirmation
- Change coverage → coverage edit side-sheet

#### Key UI Elements
- Quote presentment card (desktop + mobile variants) with price (`tui-price`)
- "12-month plan starting at" header
- Primary coverages price
- Optional coverages price
- Discounts list
- "View monthly pricing" / "View pay-in-full pricing" links
- Deductibles section: All Perils, Wind & Hail with radio button options
- "Edit deductibles" button → side-sheet
- "Recalculate" button (after coverage changes)
- "Reset changes" link
- Discounts side-sheet (piggy bank icon)
- Change coverage link
- Email quote button (desktop/mobile variants)

#### Important Actions
- Click Continue (desktop or mobile)
- Edit deductibles → choose All Perils / Wind & Hail amounts
- Click Recalculate after changes
- Open discounts side-sheet
- Email quote

#### Related Pages
- JFMT Page, Payment Selection Page, Call For Quote Page

---

### Just A Few More Things (JFMT) Page (Home / Condo / Renters)

#### Purpose
Final questions before payment, including additional discounts or property questions specific to the state.

#### Entry Points
- Review Quote Page → Continue

#### Exit Paths
- Continue → Payment Selection Page

---

### Payment Selection Page (HRC)

#### Purpose
Allows the applicant to choose between available payment plans before entering payment details.

#### Entry Points
- JFMT Page → Continue

#### Exit Paths
- Select plan + Continue → Policy Payment Page

#### Key UI Elements
- Payment plan cards: Monthly Autopay - Bank, Monthly Autopay - Card, Pay In Full
- Price breakdown per plan
- "Select and set up payment" button per card

---

### Policy Payment Page (HRC / Home / Condo / Renters)

#### Purpose
Captures bank or card payment details to complete the policy purchase.

#### Entry Points
- Payment Selection Page

#### Exit Paths
- "Complete purchase" → eCheckout / Thank You Page
- Knockout → Knockout page

#### Key UI Elements
- Monthly Autopay - Bank section: 12-month term price, first month due today, one-time fee, taxes/surcharges
- Monthly Autopay - Card section: same breakdown
- Pay In Full section: 6-month price, fees, total due today
- Payment method toggle: Bank Payment / Debit & Credit Card
- Bank form: Account Holder Name, Routing Number (9 digits), Account Number, Confirm Account Number; account type (Checking/Savings/Business Checking)
- Card form: via Paymentus iframe
- "Complete purchase" button
- Disclaimers: Information Storage Authorization, Payment Authorization Terms & Conditions
- "Change" link to switch payment method
- Fee info icon (opens modal with fee description)
- "Same payment as auto" modal (for bundles)

#### Related Pages
- Thank You Page, Knockout Page

---

### Thank You Page (HRC)

#### Purpose
Confirms quote submission or policy purchase. For non-bindable quotes (CA, duplex, etc.) confirms the quote is saved and asks user to contact an agent.

#### Entry Points
- Policy Payment complete OR non-bindable quote submitted

#### Key UI Elements
- Farmers Insurance Logo
- "Thank you for choosing Farmers Insurance®" heading
- Sub-header message (varies by state/property type)
- Quote presentment card (price, coverages, discounts)
- "Email this quote" link
- Quote number display
- Agent details section (if agent flow)
- Footer links: Personal information use, Digital accessibility, Terms of use, Privacy center, Notice of information practices, Do not sell or share

---

### Knockout / Inconvenience Page

#### Purpose
Shown when a quote cannot be completed online. Provides alternatives (call for quote, partner carriers, existing customer CTA).

#### Entry Points
- Any page where a knockout condition is detected

#### Exit Paths
- "Try again" link
- "Continue to FGIA/Foremost" button
- Agent contact buttons
- Toll-free number call-to-action
- Media Alpha monetisation buttons

#### Key UI Elements
- Title variants: "We apologize, but we can't finish your quote online at this time", "We aren't able to complete your quote at this time", "We're sorry!"
- Quote number reference
- Toll-free number
- Agent list (Yext agent results)
- Contact me button
- Media Alpha partner comparison buttons

---

### Call For Quote Page (HRC)

#### Purpose
Directs the applicant to call a phone number to complete their quote with an agent.

#### Entry Points
- Contact Info Page after rating failure or specific state/group routing

#### Exit Paths
- "I'd rather quote with Farmers Insurance® online" link → back to quote

#### Key UI Elements
- "Call for your quote" title
- "Let's get started!" sub-header
- Phone number call button (`href='tel:8…'`)
- "I'd rather quote with Farmers Insurance® online" link
- Farmers Insurance logo

---

### Bundle Review Quotes Page (Auto + HRC)

#### Purpose
Side-by-side display of both the auto and the property (home/condo/renters) quote with pricing and bundle savings.

#### Entry Points
- Auto Additional Info Page → after completing auto quote

#### Exit Paths
- Continue → property quote flow
- Toggle individual LOBs to monoline

---

### Bristol West (BW) Auto Flow Pages

#### Purpose
Provides an alternative auto quote through Bristol West carrier for applicants who don't qualify for standard Farmers auto.

**BW Additional Discounts Page**
- Displays additional discount options specific to BW
- Exit → BW Payment Summary Page

**BW Payment Summary Page**
- Shows the BW payment breakdown and plan options
- Exit → BW DocuSign Page

**BW DocuSign Page**
- Electronic signature collection for BW policy
- Exit → BW Congratulations Page

**BW Congratulations Page**
- Confirms BW policy purchase

---

### Renters About You Page

#### Purpose
Collects applicant's personal info (name, DOB, marital status) for renters insurance.

#### Entry Points
- Renters Address Page → Continue

#### Key UI Elements
- First Name, Last Name, DOB fields
- Marital status options
- Pets question (dog breed, number of animals)
- Prior insurance question

---

### Ace Life Name & DOB Page

#### Purpose
Entry point for Life insurance quote. Collects name and date of birth.

#### Entry Points
- Landing Page (Life LOB) → Continue

#### Exit Paths
- Continue → Personal Info Page

---

### Ace Life Personal Info Page

#### Purpose
Collects additional personal information for life insurance rating (health, height/weight, tobacco use, etc.).

#### Entry Points
- Life Name & DOB Page → Continue

#### Exit Paths
- Continue → Life Review Quote Page

---

### Ace Life Review Quote Page

#### Purpose
Displays term life insurance quote options.

#### Entry Points
- Life Personal Info Page → Continue

---

### Mobile Home Address Page

#### Purpose
Collects the mobile/manufactured home address.

#### Entry Points
- Landing Page (Mobile Home LOB)

#### Exit Paths
- Continue → Tell Us More Page

---

### Mobile Home Tell Us More Page

#### Purpose
Collects details about the mobile home (year, size, construction).

#### Exit Paths
- Continue → About You (Name & DOB) Page

---

### Mobile Home About You Page (Name & DOB)

#### Purpose
Collects applicant's name and date of birth for mobile home quote.

#### Exit Paths
- Continue → Last Step / Contact Info Page

---

### Mobile Home Last Step / Contact Info Page

#### Purpose
Collects contact info and policy start date for mobile home insurance.

#### Exit Paths
- Continue → Quote Review Page (or Foremost Landing Page)

---

### Mobile Home Quote Review Page

#### Purpose
Displays the rated mobile home insurance quote. May route to Foremost for non-ACE states.

---

### HQM (Legacy Home) Pages

#### Purpose
Legacy home quoting system used for HQM-specific states and scenarios.

**Pages in sequence:**
1. Address Page
2. Property Page
3. Property Details Page
4. Quality Grade Page
5. Customer Info Page
6. Quote Page
7. Discounts Page
8. Contact Info Page
9. Intermediate Page
10. Interstitial Page (agent/partner interstitial)
11. Print Page
12. Thank You Page / Thank You Redirect Page
13. Knockout Page
14. Farmers Insurance Agency Page
15. Farmers Choice Page (partner selection)

---

## Component Inventory

### Stepper / Progress Navigation Bar

- **Description:** Step-by-step progress indicator displayed at the top of each page. Shows current step and allows backward navigation via named step links.
- **Pages where used:** All ACE and OneUI pages (Auto, Home, Condo, Renters)
- **Key interactions:**
  - Click a step link to navigate back to that step
  - Desktop stepper (`tui-desktop-nav-stepper`) and mobile stepper (`tui-mobile-nav-stepper`) variants
  - Side-panel contains `Your Info`, `Vehicles`, `Drivers`, `Discounts` stepper links (Auto)

---

### Farmers Header / Navbar

- **Description:** Top navigation bar with Farmers logo and phone number.
- **Pages where used:** All pages
- **Key interactions:**
  - Logo: `data-test-id='TUI_LOGO_NO_LINK'` (non-clickable on quote pages) or Bristol West logo
  - Phone link: `data-tui-tracking-id='navbar-phone-link'`

---

### Farmers Footer

- **Description:** Bottom footer with legal links.
- **Pages where used:** All ACE/OneUI pages
- **Key interactions:**
  - Links: Personal information use, Digital accessibility, Terms of use, Privacy center, Notice of information practices, Do not sell or share my personal information
  - "Notice of Right to Opt-Out" modal from Privacy choices link

---

### Quote Presentment Card

- **Description:** Price summary card shown on Review Quote and Thank You pages. Has desktop (`tui-quote-presentment-desktop`) and mobile (`tui-quote-presentment-mobile`) variants.
- **Pages where used:** Review Quote Page (HRC), Thank You Page, Auto Quote Summary
- **Key interactions:**
  - View price breakdown (primary/optional coverages)
  - Expand/minimize card on mobile
  - View monthly or pay-in-full pricing link
  - Continue button embedded in card

---

### Side-Sheets (Info / Edit)

- **Description:** Slide-in overlay panels for editing details or viewing contextual help. Used throughout the ACE quote flow.
- **Pages where used:** Vehicles & Drivers Info, Quote Summary, Property Details, Review Quote (deductibles, discounts)
- **Key interactions:**
  - Open via edit/info icon click
  - Close via `mat-icon[text()='close']` or back chevron
  - Contains form fields, radio buttons, toggles, Update/Save buttons

---

### Discounts Side-Sheet

- **Description:** Lists all applied discounts with names and descriptions.
- **Pages where used:** Review Quote Page, Quote Summary Page
- **Key interactions:**
  - Open via discounts section or "Review discounts" link
  - Close via `closeDiscountsSidesheet`
  - Footer text with lightbulb icon

---

### Qualtrics Survey Pop-up

- **Description:** Survey feedback overlay that may appear during the quote flow.
- **Pages where used:** Auto Quote pages
- **Key interactions:**
  - "Yes I will give feedback" button
  - Survey questions with rating scale
  - Close via close button

---

### Address Autocomplete Component

- **Description:** Address lookup field with Google-style autocomplete suggestions.
- **Pages where used:** Landing Page, Property Address, Mailing Address, Prior Home Address
- **Key interactions:**
  - Type address → suggestions appear in `div[@role='listbox']`
  - Select suggestion → fields auto-fill

---

### Date Picker Component

- **Description:** Calendar-based date input used for DOB and policy start date.
- **Pages where used:** Landing Page (Retrieve), Name & DOB, Contact Info, Vehicles & Drivers
- **Key interactions:**
  - Type directly or click calendar icon (`mat-datepicker-toggle`)
  - Calendar popup: navigate month/year, select day

---

### Agent Details Component

- **Description:** Displays the assigned Farmers agent's name, photo, phone, email, and address.
- **Pages where used:** Review Quote, Thank You, Call For Quote pages (agent flow)
- **Key interactions:**
  - "Contact me" button
  - Agent phone/email/address links
  - Toll-free number as fallback

---

### Save & Finish Later Popup

- **Description:** Dialog allowing the user to save progress and return later via email.
- **Pages where used:** Auto Quote pages
- **Key interactions:**
  - Appears after "Save quote" button click
  - Email entry field

---

### Spinner / Loading Indicators

- **Description:** Loading overlays shown during API calls.
- **Types:**
  - `mat-progress-spinner` (OneUI/ACE)
  - `tui-spinner-center-content` (ACE spinner)
  - `app-loading-skeleton` (Review Quote skeleton)
  - Legacy spinner (`legacySpinner`)
  - `waitForResponseSpinner` (ID-based)
  - `oneMomentPleasePage` — full-screen "One moment, please" overlay
- **Pages where used:** All pages during transitions

---

### Digital Monetisation Dialog

- **Description:** Dialog offering alternative insurance products or partner offers after a knockout.
- **Pages where used:** Knockout / Media Alpha flow
- **Key interactions:**
  - "No thanks" button (`dialog__info-dialog-button-no-thanks`) → continues to existing result
  - Partner offer buttons

---

## Locator Inventory

### Landing Page

| Element | Locator Type | Locator Value | Usage |
|---|---|---|---|
| ZIP Code Input | XPath | `//input[@aria-label='Zip code']` | Enter ZIP code |
| Start My Quote Button | XPath | `//button[@title='Start My Quote']` | Submit new quote |
| Auto LOB Button | XPath | `//*[@value='auto']` | Select Auto |
| Home LOB Button | XPath | `//*[@value='home']` | Select Home |
| Condo LOB Button | XPath | `//*[@value='condo']` | Select Condo |
| Renters LOB Button | XPath | `//*[@value='renter']` | Select Renters |
| Life LOB Button | XPath | `//*[@value='life']` | Select Life |
| Mobile Home Button | XPath | `//*[@value='mobilehome']` | Select Mobile Home |
| Business LOB Button | XPath | `//*[@value='business']` | Select Business |
| Auto & Home Bundle | XPath | `//*[@value='autoHome']` | Select bundle |
| Auto & Renters Bundle | XPath | `//*[@value='autoRenters']` | Select bundle |
| Auto & Condo Bundle | XPath | `//*[@value='autoCondo']` | Select bundle |
| Retrieve Quote Tab | ID | `landing-retrieve` | Switch to retrieve tab |
| New Quote Tab | ID | `landing-quote` | Switch to new quote tab |
| Last Name (Retrieve) | XPath | `//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Lastname_field']//input` | Enter last name |
| DOB (Retrieve) | XPath | `//lib-date-picker[@data-gtm='FFQ_Auto_Landing_Retrievequote_Dateofbirth_field']//input[string-length(@aria-label)>0]` | Enter DOB |
| Quote Number (Retrieve) | XPath | `//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Quotenumber_field']//input` | Enter quote number/email |
| ZIP (Retrieve) | XPath | `//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Zipcode_field']//input` | Enter ZIP |
| Retrieve Button | XPath | `//button[@title='Retrieve Your Quote']` | Submit retrieve |
| ZIP Error Message | XPath | `//div[@id='ffq-landing-zip-code']//mat-error` | Validation error |

---

### Name & Date of Birth Page (Auto / Life)

| Element | Locator Type | Locator Value | Usage |
|---|---|---|---|
| First Name | XPath | `//input[contains(@aria-label,'First name')]` | Enter first name |
| Last Name | XPath | `//input[contains(@aria-label,'Last name')]` | Enter last name |
| Date of Birth | XPath | `//input[contains(@aria-label,'Date of birth')]` | Enter DOB |
| Continue Button | XPath | `//button[@data-tui-tracking-id='personal-info__continue-button-cta']` | Submit form |
| Page Title | XPath | `//app-personal-info//h1[@class='tui-h1 ng-star-inserted']` | Verify page |
| Privacy Policy Link | XPath | `//a[contains(@data-tui-tracking-id,'privacy-policy-hyperlink')]` | Open privacy policy |

---

### Vehicles & Drivers Info Page

| Element | Locator Type | Locator Value | Usage |
|---|---|---|---|
| Page Title | XPath | `//app-vehicles-drivers-main-screen//h1` | Verify on page |
| Add Another Vehicle | XPath | `//button[contains(.,'Add another vehicle')]` | Open vehicle side-sheet |
| Add Another Driver | XPath | `//button[contains(.,'Add another driver')]` | Open driver side-sheet |
| Vehicle Cards (found) | XPath | `//app-vehicle-card//div[@class='h6 custom-h6 fw-semibold']` | List vehicles |
| Selected Vehicle Checkboxes | XPath | `//div[@class='card auto-vehicles-card-item vehicle-selected']//input` | Check selections |
| Driver Names (found) | XPath | `//app-driver-card//div[contains(@class,'driver-name-header')]` | List drivers |
| VIN Input | CSS | `input[formcontrolname='vin']` | Enter VIN |
| Year Dropdown | CSS | `mat-select[formcontrolname='year']` | Select year |
| Make Input | XPath | `//mat-form-field[contains(.,'make')]//input` | Enter make |
| Model Input | XPath | `//mat-form-field[contains(.,'model')]//input` | Enter model |
| Continue Button | XPath | `//button[@class='tui-btn tui-btn-primary']` | Proceed |
| Side-Sheet Close | XPath | `//app-help-text-sidesheet//div[@class='heading-area']//button[contains(.,'close')]` | Close side-sheet |

---

### Quote Summary Auto Page

| Element | Locator Type | Locator Value | Usage |
|---|---|---|---|
| Liability Edit Button | CSS | `.tui-link-button.auto-quote-liability-edit-button` | Open edit side-sheet |
| Coverage Row Names | XPath | `//div[@class='row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted']/div[1]` | List coverages |
| Coverage Values | XPath | same row `/div[2]` | Show limits |
| Coverage Prices | XPath | same row `/div[3]` | Show prices |
| Discounts Included | XPath | `//span[contains(@class,'discount-name')]` | List discount names |
| Email Link (desktop) | XPath | `//a[@id='emailLink']` | Email quote |
| Email Button (mobile) | XPath | `//button[contains(@class,'tui-email-link tui-link')]` | Email quote |
| Comprehensive Toggle | XPath | `//mat-slide-toggle[@id='Vehicle__21000__toggle']//button` | Toggle Comp |
| Collision Toggle | XPath | `//mat-slide-toggle[@id='Vehicle__22000__toggle']//button` | Toggle Coll |
| BI Radio Buttons | XPath | `//mat-radio-group[@id='Liability__BI__radio']//mat-radio-button` | BI limits |

---

### Consolidated Payment Page (Auto)

| Element | Locator Type | Locator Value | Usage |
|---|---|---|---|
| Page Header | XPath | `//app-payment-consolidated//h1[@role='heading']` | Verify page |
| Pay In Full Radio | XPath | `//mat-radio-button[contains(.,'Pay in full')]` | Select pay-in-full |
| Monthly Autopay Radio | XPath | `//mat-radio-button[contains(.,'Monthly Autopay')]` | Select monthly |
| Bank Radio Button | CSS | `mat-radio-button[value='bank']` | Select bank |
| Card Radio Button | CSS | `mat-radio-button[value='card']` | Select card |
| Due Today Label | XPath | `//div[contains(@class,'details-bottom')]/span[1]` | Read due today label |
| Due Today Amount | XPath | `//div[contains(@class,'details-bottom')]/span[2]` | Read due today amount |
| Bank Account Added | XPath | `//span[contains(.,'Bank payment account added.')]` | Confirm bank added |
| Card Added | XPath | `//span[contains(.,'Debit card added.')]` | Confirm card added |
| Fee Info Icon | XPath | `//mat-icon[contains(@class,'tui-info-box-icon material-icons')]` | Open fee modal |

---

### ACE HRC Review Quote Page

| Element | Locator Type | Locator Value | Usage |
|---|---|---|---|
| Quote Price (Desktop) | XPath | `//mat-card[contains(@class,'tui-quote-presentment-desktop')]//tui-price` | Read quoted price |
| Quote Price (Mobile) | XPath | `//mat-card[contains(@class,'tui-quote-presentment-mobile')]//tui-price` | Read quoted price |
| Continue Desktop | XPath | `//mat-card[contains(@class,'tui-quote-presentment-desktop')]//button[contains(text(),'Continue')]` | Click continue |
| Continue Mobile | XPath | `//mat-card[contains(@class,'tui-quote-presentment-mobile')]//button[contains(text(),'Continue')]` | Click continue (mobile) |
| Edit Deductibles Button | XPath | `//button[contains(@class,'edit-deductibles-button')]` | Open deductibles |
| Recalculate Button | XPath | `//button[text()='Recalculate']` | Recalculate after edit |
| Reset Changes Link | XPath | link text `Reset changes` | Reset to original |
| Discounts Review Link | XPath | `//p[contains(text(),'Review discount')]` | Open discounts |
| Close Discounts | XPath | `//app-home-discount-sidesheet//mat-icon[text()='close']` | Close discounts |
| Email Quote (desktop) | ID | `emailLink` | Email quote |

---

### Property Details Page

| Element | Locator Type | Locator Value | Usage |
|---|---|---|---|
| Edit Details Button | XPath | `//app-property-details//button[@aria-label='Edit Home details']` | Open edit modal |
| Review & Edit Button | XPath | `//app-property-details//button[text()='Review & edit information']` | Open edit modal |
| Edit Modal Title | XPath | `//tui-subcategory-selector-modal//h2` | Verify modal open |
| Close Modal | XPath | `//tui-subcategory-selector-modal//button[contains(text(),'Close')]` | Close modal |
| Update Button | XPath | `//tui-subcategory-modal//button[text()='Update']` | Save changes |
| Property Updated Snackbar | XPath | `//tui-subcategory-selector-modal//*[contains(@class,'mat-simple-snackbar')]` | Confirm update |
| Address Line 1 | XPath | `//app-property-details//div[contains(@class,'property-details-address-holder')]/div[1]` | Read address |

---

### Contact Info Page (HRC)

| Element | Locator Type | Locator Value | Usage |
|---|---|---|---|
| Policy Start Date Input | XPath | `//app-contact-info//app-date-picker//input` | Enter start date |
| Early Shopping Message | CSS | `#auto-contact-info-early-shopper-message-container>div` | Read discount message |
| Default Mailing Address | ID | `mailingAddressDiv_1` | Select same as property |
| Other Mailing Radio | ID | `mailingAddressDiv_2-input` | Select other address |
| City Input | CSS | `input[aria-label='City']` | Enter city |
| State Dropdown | CSS | `mat-select[aria-label='State']` | Select state |
| Agree & Submit Button | XPath | see BasePage continue button pattern | Submit contact info |
| Error Messages | XPath | `//mat-error[not(@hidden)]` | Read validation errors |

---

### Property Type Page

| Element | Locator Type | Locator Value | Usage |
|---|---|---|---|
| Page Title | XPath | `//app-property-type//h1` | Verify page |
| Property Type Cards | XPath | `//app-property-type//app-image-card` | List property types |
| Select Home | XPath | `//app-image-card[contains(.,'Home')]//div[@data-test-id='IMAGE_CARD']` | Select Home |
| Select Condo | XPath | `//app-image-card[contains(.,'Condo')]//div[@data-test-id='IMAGE_CARD']` | Select Condo |
| Primary Residence Toggle | XPath | `//app-property-type//div[@id='formField_isPrimaryResidence']//button` | Toggle Yes/No |
| Non-Primary Reason | XPath | `//div[@id='formField_notPrimaryResidenceReason']//mat-radio-button` | Select reason |

---

### Knockout / Inconvenience Page

| Element | Locator Type | Locator Value | Usage |
|---|---|---|---|
| Inconvenience Title | CSS | `h1[class='tui-h1 inconvenience__title']` | Read KO title |
| KO Description | CSS | `p[class='tui-body']` | Read KO body |
| Try Again | XPath | `//div[contains(@class,'inconvenience__cta')]` | Try again button |
| Toll-Free Number | XPath | `//div[contains(@class,'agent-details-container')]//a[starts-with(@aria-label,'Contact farmers representative')]` | Read phone |
| Continue to FGIA | CSS | `button[class='tui-btn tui-btn-primary continue-cta']` | Go to FGIA |
| Quote Number | XPath | `//div[contains(@class,'knockout__quote-number')]//span[1]` | Read quote number |

---

### Common / Shared

| Element | Locator Type | Locator Value | Usage |
|---|---|---|---|
| Farmers Logo | XPath | `//img[@data-test-id='TUI_LOGO_NO_LINK' and @alt='Farmers Insurance logo']` | Verify branding |
| Bristol West Logo | XPath | `//img[@alt='Bristol West logo']` | Verify BW branding |
| ACE Spinner | XPath | `//div[contains(@class,'tui-spinner-center-content')]` | Wait for loading |
| Review Quote Skeleton | XPath | `//app-loading-skeleton` | Wait for quote load |
| OneUI Spinner | XPath | `//mat-progress-spinner` | Wait for loading |
| Close Survey | XPath | `//div[contains(@class,'QSIPopOver')]//img[contains(@src,'close-btn')]` | Dismiss Qualtrics |
| Save Quote Button | XPath | `//button[contains(.,'Save quote')]` | Save quote |
| Navigate Away Confirm | XPath | `//mat-dialog-actions/button/span[text()='YES, NAVIGATE AWAY']` | Confirm navigation |
| Generic Continue | XPath | `//button[contains(text(),'Continue') or contains(text(),'Agree')][not(@hidden)]` | Generic continue |
| Footer Privacy Link | XPath | `//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_privacy-center']` | Footer privacy |

---

## Common User Workflows

### Workflow 1 — Complete Auto Quote & Bind (Standard)

- **Trigger Page:** Landing Page
- **Navigation Path:** Landing → Name & DOB → Address → Vehicles & Drivers Info → Quote Summary → Additional Info (OneUI) → Consolidated Payment → eCheckout
- **User Actions:**
  1. Select Auto Insurance, enter ZIP, click Start My Quote
  2. Enter First Name, Last Name, Date of Birth → Continue
  3. Enter or confirm address → Continue
  4. Review/edit vehicles and drivers → Continue
  5. Review auto quote, optionally adjust coverage limits → Start Checkout
  6. Complete policy start date, driver details, vehicle details, Signal enrollment
  7. Select payment plan (Pay In Full or Monthly Autopay)
  8. Select payment method (Bank or Card), enter payment details
  9. Click Complete Purchase
- **Validation Points:**
  - Name/DOB: Age between 15–99
  - Address: Valid US address
  - Coverage: At least BI coverage selected
  - Payment: Valid bank routing/account number or card number

---

### Workflow 2 — Auto Quote Save & Retrieve

- **Trigger Page:** Any quote page (during quoting)
- **Navigation Path:** Any page → Save Quote → Email confirmation → Landing Page → Retrieve tab → Resume quote
- **User Actions:**
  1. Click "Save quote" button during quoting
  2. Enter email address
  3. Later: navigate to Landing Page
  4. Click Retrieve tab, enter Last Name, DOB, Quote Number (or email), ZIP
  5. Click "Retrieve Your Quote"
- **Validation Points:** Quote number/email matches, last name/DOB match, ZIP matches

---

### Workflow 3 — Home Insurance Quote (ACE New Flow)

- **Trigger Page:** Landing Page
- **Navigation Path:** Landing → Address & Contact → Property Type → Property Info → Property Details → Quality Grade → Additional Info → About You → Contact Info → Review Quote → JFMT → Payment Selection → Payment → Thank You
- **User Actions:**
  1. Select Home Insurance, enter ZIP → Start
  2. Enter address and contact name/DOB → Continue
  3. Select property type (Home/Townhome/etc.) and primary residence → Continue
  4. Review pre-filled property info → Continue
  5. Review/edit property details (year built, sq ft, stories…) → Continue
  6. Select quality grade → Continue
  7. Answer additional info questions (alarms, pool, roof, solar…) → Continue
  8. Enter occupation, marital status, bundle options → Continue
  9. Enter policy start date, mailing address, agree to ESIGN → Agree & Submit
  10. Review quote, edit deductibles/coverages → Continue
  11. Answer JFMT questions → Continue
  12. Select payment plan → Set up payment
  13. Enter bank/card details → Complete Purchase
- **Validation Points:**
  - Policy start date: 1–60 days from today
  - Early shopping discount: ≥7 days from today
  - Deductibles: valid selection required before Continue

---

### Workflow 4 — Bundle Quote (Auto + Home)

- **Trigger Page:** Landing Page (Auto & Home selected)
- **Navigation Path:** Landing → Auto flow → Quote Summary → Additional Info → Bundle Review Quotes → Home flow → Bundle Final Review → Auto Payment → Home Payment → eCheckout
- **User Actions:**
  1. Select Auto & Home bundle, enter ZIP
  2. Complete auto quote flow through Quote Summary
  3. Complete auto Additional Info
  4. Review bundle quotes side-by-side
  5. Complete home property flow
  6. Review final bundle
  7. Set up auto payment
  8. Set up home payment
  9. Complete purchase
- **Validation Points:**
  - Both quotes must be ratable
  - Bundle discount applied: "Nice! We'll add an auto bundle discount"

---

### Workflow 5 — Bristol West Auto Quote & Bind

- **Trigger Page:** BDQ URL or Standard Auto flow with BW-qualifying data
- **Navigation Path:** BDQ/Landing → Auto flow → Quote Summary → "Continue with Bristol West" → BW Additional Discounts → BW Payment Summary → BW DocuSign → BW Congratulations
- **User Actions:**
  1. Enter BW-specific applicant data (last name: "Threeoabaa", SR-22, low continuous coverage)
  2. Complete standard auto quote flow
  3. Dialog appears: "Continue online with Bristol West"
  4. Select BW additional discounts
  5. Review BW payment summary
  6. Complete DocuSign
- **Validation Points:**
  - BW modal appears when standard Farmers auto is not available
  - BW disclaimer footer displayed on Quote Summary

---

### Workflow 6 — Auto Quote Knockout

- **Trigger Page:** Any Auto page (address, vehicles, quote)
- **Navigation Path:** ... → Knockout / Inconvenience Page → [FGIA / Media Alpha / Call agent]
- **User Actions:**
  - System detects ineligibility → Knockout page shown
  - User calls toll-free number, or
  - User clicks "Continue to FGIA" / "Continue to Foremost"
  - Or user clicks "Try again"
- **Validation Points:**
  - KO title matches expected variant
  - Quote number reference is displayed
  - Appropriate toll-free number shown

---

### Workflow 7 — Life Insurance Quote

- **Trigger Page:** Landing Page (Life LOB)
- **Navigation Path:** Landing → Name & DOB → Personal Info → Review Quote
- **User Actions:**
  1. Select Life Insurance, enter ZIP
  2. Enter name and DOB
  3. Enter personal health and lifestyle information
  4. Review life insurance quote options

---

### Workflow 8 — Renters Insurance Quote & Bind

- **Trigger Page:** Landing Page (Renters LOB)
- **Navigation Path:** Landing → Address → About You → Property Type → Contact Info → JFMT → Review Quote → Consolidated Payment → Thank You
- **User Actions:**
  1. Select Renters Insurance, enter ZIP
  2. Enter property address
  3. Enter applicant name, DOB, marital status, prior insurance
  4. Select property type
  5. Enter contact info and policy start date
  6. Answer JFMT questions
  7. Review and adjust renters quote
  8. Complete payment

---

### Workflow 9 — Partner/Toggle Pre-filled Flow (Cross-Sell)

- **Trigger Page:** Encrypted URL from partner system
- **Navigation Path:** Encrypted URL → ACE auto/home quote begins with pre-filled data (skips Landing)
- **User Actions:**
  - User lands mid-flow with customer data already populated
  - Review/confirm pre-filled data → continue normal quote flow
- **Validation Points:** Data from AppStore session storage matches pre-populated values

---

## Form Inventory

### Landing Page — New Quote Form

| Field | Required | Validation | Submit Action |
|---|---|---|---|
| LOB Selection | Yes | Must select a product | "Please select a product." |
| ZIP Code | Yes | 5-digit US ZIP | "Please enter a 5-digit ZIP Code." |

### Landing Page — Retrieve Quote Form

| Field | Required | Validation | Submit Action |
|---|---|---|---|
| Last Name | Yes | Text only | "Please enter Last Name." |
| Date of Birth | Yes | Valid date | "Please enter Date of Birth." |
| Quote Number OR Email | Yes | Either field | "Please enter Quote Number Or Email Address." |
| ZIP Code | Yes | 5-digit US ZIP | "Please enter a 5-digit ZIP Code." |

**Success Condition:** Redirects to saved quote state. Error: "We were unable to locate your quote" dialog.

---

### Name & DOB Form (Auto / Life)

| Field | Required | Validation |
|---|---|---|
| First Name | Yes | Alpha + hyphen/space, no numbers, max 50 chars |
| Last Name | Yes | Alpha + hyphen/space, no numbers |
| Date of Birth | Yes | Age 15–99 years; format MM/DD/YYYY |

**Submit Action:** Continue button  
**Success Condition:** Navigates to next page in flow

---

### Vehicle Form (Side-Sheet)

| Field | Required | Validation |
|---|---|---|
| VIN | Optional | 17-char VIN; verified against DB |
| Year | Yes | Valid model year |
| Make | Yes | Valid make |
| Model | Yes | Valid model |
| Type | Yes | Select from dropdown |
| When acquired | Yes | Date |
| Primary use | Yes | Personal/Business/etc. |
| Park at residence | Yes | Yes/No |

---

### Driver Form (Side-Sheet)

| Field | Required | Validation |
|---|---|---|
| First Name | Yes | Alpha |
| Last Name | Yes | Alpha |
| Date of Birth | Yes | Valid date |
| Gender | Yes | Radio select |
| US/CA license | Yes | Radio |
| Will be driving | Yes | Radio |
| Currently insured | Yes | Radio |
| Relationship | Conditional | If additional driver |
| Accidents/Violations | Conditional | Checkbox |
| Financial responsibility (SR-22) | Conditional | State-dependent |
| Safety course completed | Conditional | For mature driver discount |
| GPA > 3.0 | Conditional | For good student discount |

---

### Contact Info Form (HRC)

| Field | Required | Validation |
|---|---|---|
| Policy Start Date | Yes | 1–60 days from today |
| Email Address | Yes | Valid email format |
| Phone Number | Yes | Valid US phone |
| Mailing Address (if Other) | Conditional | Valid US address |

**Submit Action:** "Agree & Submit" button  
**Success Condition:** RC2/RC3 rating call completes, navigates to Review Quote Page

---

### Bank Payment Form

| Field | Required | Validation |
|---|---|---|
| Account Type | Yes | Checking / Savings / Business Checking |
| Account Holder Name | Yes | Full name |
| Bank Routing Number | Yes | Exactly 9 digits |
| Account Number | Yes | Numeric |
| Confirm Account Number | Yes | Must match Account Number |

**Success Condition:** "Bank payment account added." snack-bar message

---

### Debit/Credit Card Form (via Paymentus iframe)

| Field | Required | Validation |
|---|---|---|
| Card Number | Yes | Valid card number (Visa, MC, Amex, Discover) |
| Expiration Date | Yes | Future date |
| CVV | Yes | 3–4 digits |
| Cardholder Name | Yes | Full name |
| Billing ZIP | Yes | 5-digit ZIP |

**Success Condition:** "Debit card added." / "Credit card added." message

---

### Property Details Edit Modal

| Field | Required | Validation |
|---|---|---|
| Type of Home | Yes | Radio selection |
| Roof Cover | Yes | Radio |
| Exterior Wall Finish | Yes | Radio |
| Garage Style | Conditional | Radio |
| Stories | Yes | Numeric input |
| Bathrooms | Yes | Full + Half numeric inputs |
| Basement | Conditional | Toggle |
| Foundation Type | Yes | Radio |
| Finished Basement | Conditional | Toggle |
| Total Sq Ft | Yes | Numeric |
| Year Built | Yes | 4-digit year |

**Submit Action:** "Update" button  
**Success Condition:** "Property updated" snack-bar

---

## Table / Grid Inventory

### Quote Summary — Coverage Table (Auto)

| Feature | Detail |
|---|---|
| **Columns** | Coverage Name, Limit/Value, Price per 6-month term |
| **Sections** | Liability, Per-Vehicle (one section per vehicle) |
| **Sorting** | Not applicable |
| **Filtering** | Not applicable |
| **Paging** | Not applicable |
| **Row Actions** | Toggle coverage on/off (mat-slide-toggle), select limit via radio buttons |

---

### Review Quote — Coverages Table (HRC)

| Feature | Detail |
|---|---|
| **Columns** | Coverage Name, Value/Limit, Price |
| **Sections** | Primary Coverages, Optional Coverages, Deductibles |
| **Row Actions** | Edit Deductibles button, Recalculate |

---

### Vehicles & Drivers — Vehicle Card Grid

| Feature | Detail |
|---|---|
| **Display** | Card-based list of found vehicles |
| **Selection** | Checkbox per card (selected/unselected state) |
| **Row Actions** | Edit vehicle (opens side-sheet), checkbox toggle |
| **Add** | "Add another vehicle" opens a side-sheet |

---

### Vehicles & Drivers — Driver Card Grid

| Feature | Detail |
|---|---|
| **Display** | Card-based list of found drivers |
| **Selection** | Checkbox per card |
| **Row Actions** | Edit driver (side-sheet) |
| **Add** | "Add another driver" opens a side-sheet |

---

### Discounts Side-Sheet List

| Feature | Detail |
|---|---|
| **Display** | List of discount names and descriptions |
| **Filter** | Not applicable |
| **Paging** | Not applicable |
| **Source** | Driven by SQL discount data and applicant eligibility |

---

## Browser Automation Patterns

### Wait Strategies

| Strategy | Implementation | When Used |
|---|---|---|
| `waitElementBeVisible(element)` | Explicit wait for `visibilityOf` | Before interacting with any element |
| `waitForSpinnerToBeGone()` | Waits for spinner element to disappear | After each page action that triggers API |
| `waitForPageToBeReady()` | Combination spinner + Angular ready wait | After navigation |
| `waitUntilAngular5Ready()` | Checks Angular stability | Before clicking links |
| `waitForSkeletonToBeGone()` | Waits for `app-loading-skeleton` to disappear | Review Quote page load |
| `waitForRC2ScreenToFinish()` | Waits for rating calculation to complete | After Contact Info submit |
| `isElementVisible(element, seconds)` | Checks element presence with timeout | Conditional checks |
| `isElementPresent(By locator, seconds)` | Checks by locator presence | Page verification |

---

### Utility Functions (`BasePage` / `AutoBasePage`)

| Function | Purpose |
|---|---|
| `enterValueInField(value, element, log)` | Clear + type value into input |
| `clickElement(element)` | Click with wait |
| `waitAndClickElement(element)` | Wait visible then click |
| `scrollAndClickOnElement(element)` | Scroll into view then click |
| `clickOnHiddenElement(element)` | JS click for hidden elements |
| `getTextFromElement(element)` | Get visible text |
| `getAttributeData(element, attr)` | Get attribute value |
| `getInputFieldValue(element)` | Get input value |
| `isElementInViewport(element)` | Assert element is visible in viewport |
| `getSessionStorageAppStore()` | Read `appStore` from session storage (AppStore DTO) |
| `getItemFromSessionStorage(key)` | Read arbitrary session storage key |
| `acceptCookies()` | Dismiss cookie consent |
| `testStep(description)` | Log test step to report |
| `isSnackBarMessageDisplayed(text)` | Assert snack-bar message |
| `navigateBack()` | Browser back button |
| `scrollToBottomOfPage()` | Scroll page to bottom |
| `isUseMobileViewEnabled()` | Check if mobile viewport active |
| `isNewFlowEnabledState(stateCode)` | Check if state uses new ACE flow |
| `isBDQFlowEnabled()` | Check if BDQ feature flag is active |
| `isSafariBrowser()` | Browser-specific workaround check |
| `findFormFieldWebElement(label)` | Find form field by aria-label text |
| `areNotAllowedCharactersNotAccepted(field, chars)` | Validate character restrictions |

---

### Base Page Methods (Page Objects)

Each NavigationHelper class exposes a `navigateTo<PageName>(applicant)` method that:
1. Calls the previous page's navigation method (chain)
2. Fills out the previous page's form
3. Waits for spinner
4. Asserts the new page is reached
5. Returns the new page object

This pattern is used consistently across:
- `AceAutoNavigationHelper` → Auto quote flow
- `AceHRCNavigationHelperBasePage` → Home/Condo/Renters flow
- `AceRentersNavigationHelper` → Renters-specific
- `AceMobileHomeNavigationHelper` → Mobile Home flow
- `AceLifeNavigationHelper` → Life flow
- `AceBundleNavigationHelper` → Bundle flow

---

### Shared Workflows in Tests

| Pattern | Description |
|---|---|
| `randomizeApplicantPersonalData(applicant)` | Randomises name/DOB/email using Faker |
| `updateApplicantDataToAvoidPossibleBw(applicant)` | Sets data to avoid triggering BW path |
| `bwSpecificDataSetUp(applicant)` | Sets up BW-triggering data (last name, SR-22, insurance gap) |
| `updateLastNameForBristolWest(applicant)` | Sets last name to "Threeoabaa" for BW trigger |
| `setResumeFromPage(pageName)` | Allows navigation helper to skip pages and resume mid-flow |
| `writeRatedQuoteInformationToFile(…)` | Appends rated quote info to log file |
| `writeDataToKnockoutLogFile(…)` | Appends KO data to log file |
| `logQuoteNumber(applicant, lob, quoteNumber)` | Logs quote number with LOB context |
| `checkForPropertyKnockoutAndReset(…)` | Detects property KO and attempts auto-recovery |

---

## Playwright Migration Guidance

### Suggested Playwright Page Object Structure

```
pages/
  common/
    LandingPage.ts
    KnockoutPage.ts
    CallForQuotePage.ts
    BristolWestLandingPage.ts
    FGIALandingPage.ts
    ForemostLandingPage.ts
    MediaAlphaPage.ts
    PolicyBankPaymentPage.ts
    PolicyCardPaymentPage.ts
  auto/
    NameAndDobPage.ts
    AutoEnterAddressPage.ts
    HeresWhatWeFoundPage.ts
    VehiclesDriversInfoPage.ts
    QuoteSummaryPage.ts
    AdditionalInfoPage.ts           (OneUI bind: PolicyStartDate, Driver, Vehicle, Signal)
    ConsolidatedPaymentPage.ts
    EcheckoutSuccessPage.ts
    bw/
      BwAdditionalDiscountsPage.ts
      BwPaymentSummaryPage.ts
      BwDocuSignPage.ts
      BwCongratulationsPage.ts
  home/
    PropertyTypePage.ts
    AddressContactPage.ts           (new flow combined name/DOB + address)
    PropertyInfoPage.ts
    PropertyDetailsPage.ts
    QualityGradePage.ts
    AdditionalInfoPage.ts
    AboutYouPage.ts
    ContactInfoPage.ts
    ReviewQuotePage.ts
    JustAFewMoreThingsPage.ts
    PaymentSelectionPage.ts
    PolicyPaymentPage.ts
    ThankYouPage.ts
  condo/
    [inherits from home with custom coverage additions]
    CustomCoveragePage.ts
  renters/
    RentersAddressPage.ts
    AboutYouPage.ts
    PropertyTypePage.ts
    ContactInfoPage.ts
    ReviewQuotePage.ts
    ConsolidatedPaymentPage.ts
  life/
    NameAndDobPage.ts
    PersonalInfoPage.ts
    ReviewQuotePage.ts
  mobilehome/
    AddressPage.ts
    TellUsMorePage.ts
    AboutYouPage.ts
    LastStepPage.ts
    QuoteReviewPage.ts
  bundle/
    BundleReviewQuotesPage.ts
    BundleFinalReviewPage.ts
  hqm/
    AddressPage.ts
    PropertyPage.ts
    CustomerInfoPage.ts
    QuotePage.ts
    DiscountsPage.ts
    ThankYouPage.ts
fixtures/
  autoApplicant.ts
  homeApplicant.ts
  rentersApplicant.ts
  lifeApplicant.ts
  bundleApplicant.ts
helpers/
  navigationHelper.ts
  waitHelper.ts
  paymentHelper.ts
  sessionStorageHelper.ts
```

---

### Recommended Locator Strategy

Prefer in this order:
1. `data-tui-tracking-id` attributes (stable, purpose-built for testing)
2. `data-gtm` attributes (stable, analytics-driven)
3. `data-test-id` attributes
4. `aria-label` on inputs
5. `id` attributes
6. Semantic element + text content XPath (fallback only)

```typescript
// Examples
page.locator('[data-tui-tracking-id="personal-info__continue-button-cta"]')
page.locator('[data-gtm="FFQ_Auto_Landing_Newquote_Startmyquote_button"]')
page.locator('[data-test-id="IMAGE_CARD"]')
page.getByRole('textbox', { name: 'First name' })
page.getByRole('textbox', { name: 'Zip code' })
page.getByRole('button', { name: 'Continue' })
```

---

### Reusable Methods Per Page (Examples)

```typescript
// LandingPage.ts
async startNewQuote(lob: string, zipCode: string): Promise<void>
async retrieveQuote(lastName: string, dob: string, quoteNumberOrEmail: string, zip: string): Promise<void>
async selectLOB(lob: 'auto' | 'home' | 'condo' | 'renter' | 'life' | 'mobilehome' | 'business' | 'autoHome' | 'autoRenters' | 'autoCondo'): Promise<void>

// NameAndDobPage.ts
async fillForm(firstName: string, lastName: string, dob: string): Promise<void>
async clickContinue(): Promise<void>
async getValidationErrors(): Promise<string[]>

// VehiclesDriversInfoPage.ts
async addVehicle(vehicle: VehicleData): Promise<void>
async editVehicle(index: number, vehicle: VehicleData): Promise<void>
async addDriver(driver: DriverData): Promise<void>
async selectVehicle(index: number): Promise<void>
async selectDriver(index: number): Promise<void>
async getFoundVehicles(): Promise<string[]>
async getFoundDrivers(): Promise<string[]>
async clickContinue(): Promise<void>

// QuoteSummaryPage.ts (Auto)
async getQuotePrice(): Promise<string>
async editLiabilityCoverage(): Promise<void>
async toggleComprehensive(enabled: boolean): Promise<void>
async toggleCollision(enabled: boolean): Promise<void>
async getDiscounts(): Promise<string[]>
async startCheckout(): Promise<void>
async emailQuote(): Promise<void>

// ReviewQuotePage.ts (HRC)
async getQuotePrice(): Promise<string>
async editDeductibles(): Promise<void>
async setAllPerilsDeductible(amount: string): Promise<void>
async setWindHailDeductible(amount: string): Promise<void>
async recalculate(): Promise<void>
async clickContinue(): Promise<void>
async openDiscountsSideSheet(): Promise<void>
async emailQuote(): Promise<void>

// ConsolidatedPaymentPage.ts (Auto)
async selectPayPlan(plan: 'payInFull' | 'monthlyAutopay'): Promise<void>
async selectPaymentMethod(method: 'bank' | 'card'): Promise<void>
async enterBankDetails(routing: string, account: string, type: 'checking' | 'savings'): Promise<void>
async completePurchase(): Promise<void>
async getDueTodayAmount(): Promise<string>
```

---

### Recommended Assertions

```typescript
// Page landing assertions
await expect(page.locator('[data-test-id="IMAGE_CARD"]').first()).toBeVisible()
await expect(page.locator('h1')).toContainText('What type of property is it?')
await expect(page.locator('app-loading-skeleton')).not.toBeVisible()

// Quote price assertion
await expect(page.locator('tui-price')).toBeVisible()

// Snack-bar / toast
await expect(page.getByText('Bank payment account added.')).toBeVisible()
await expect(page.getByText("Nice! We'll add an auto bundle discount.")).toBeVisible()

// Knockout detection
const isKnockedOut = await page.locator("h1.tui-h1.inconvenience__title").isVisible()

// Spinner gone
await expect(page.locator('mat-progress-spinner')).not.toBeVisible({ timeout: 30000 })
await expect(page.locator('.tui-spinner-center-content')).not.toBeVisible({ timeout: 30000 })
```

---

### Fixtures (Applicant Data)

```typescript
// fixtures/autoApplicant.ts
export const standardAutoApplicant = {
  firstName: 'John',
  lastName: 'Smith',
  dateOfBirth: '01011985',   // MMDDYYYY
  zipCode: '90210',
  stateCode: 'CA',
  vehicles: [{ useVIN: false, year: 2020, make: 'Toyota', model: 'Camry' }],
  haveAccidentOrViolations: false,
  financialFiling: 'No',
  continuousInsurancePeriod: '> 3 years'
}

export const bwTriggerAutoApplicant = {
  ...standardAutoApplicant,
  lastName: 'Threeoabaa',    // triggers Bristol West path
  financialFiling: 'SR-22',
  continuousInsurancePeriod: '< 6 Months'
}

// fixtures/homeApplicant.ts
export const standardHomeApplicant = {
  firstName: 'Jane',
  lastName: 'Doe',
  dateOfBirth: '05151980',
  zipCode: '60601',
  stateCode: 'IL',
  propertyType: 'Home',
  isPrimaryResidence: true,
  yearBuilt: 1995,
  sqFt: 1800,
  stories: 2
}
```

---

## AI Consumption Section

```yaml
pages:
  - name: LandingPage
    url_pattern: "/fastquote"
    entry: direct_navigation
    lob_selection:
      - auto
      - home
      - condo
      - renter
      - life
      - mobilehome
      - business
      - autoHome
      - autoRenters
      - autoCondo
    key_actions:
      - startNewQuote
      - retrieveQuote
    key_locators:
      zip_input: "//input[@aria-label='Zip code']"
      start_button: "button[title='Start My Quote']"
      retrieve_button: "button[title='Retrieve Your Quote']"

  - name: NameAndDobPage
    lob: [auto, life]
    key_fields: [firstName, lastName, dateOfBirth]
    validation:
      age_range: "15-99"
    continue_locator: "[data-tui-tracking-id='personal-info__continue-button-cta']"

  - name: VehiclesDriversInfoPage
    lob: [auto]
    key_actions: [addVehicle, editVehicle, addDriver, editDriver, selectVehicle, selectDriver, continue]
    side_sheets: [vehicleForm, driverForm, vinHelper]

  - name: QuoteSummaryAutoPage
    lob: [auto]
    key_actions: [editLiabilityCoverage, toggleComp, toggleColl, startCheckout, emailQuote, bundleAndSave]
    coverages: [BI, PD, UM, UIM, MP, Comp, Coll, Rental, Towing]

  - name: ConsolidatedPaymentAutoPage
    lob: [auto]
    pay_plans: [payInFull, monthlyAutopay]
    payment_methods: [bank, card]
    key_actions: [selectPayPlan, selectPaymentMethod, completePurchase]

  - name: PropertyTypePage
    lob: [home, condo]
    property_types: [Home, Townhome, Duplex, Condo, Other]
    primary_residence: boolean

  - name: PropertyDetailsPage
    lob: [home, condo]
    fields: [yearBuilt, sqFt, stories, bathrooms, roofCover, exteriorWall, garageStyle, foundationType, finishedBasement, fireplace, marketValue]
    edit_modal: true

  - name: AdditionalInfoPageHRC
    lob: [home, condo]
    features: [swimmingPool, trampoline, oilTank, solarPanels, temporaryRental, alarmType, roofReplacement, sprinkler]

  - name: ContactInfoPageHRC
    lob: [home, condo, renters]
    fields: [policyStartDate, email, phone, mailingAddress]
    policy_start_date_range: "1-60 days from today"
    early_shopping_threshold: "7+ days"
    submit_action: agreeAndSubmit

  - name: ReviewQuotePageHRC
    lob: [home, condo, renters]
    key_actions: [editDeductibles, recalculate, resetChanges, continue, emailQuote, openDiscounts]
    price_display: "12-month plan"

  - name: PolicyPaymentPageHRC
    lob: [home, condo, renters]
    pay_plans: [monthlyAutopayBank, monthlyAutopayCard, payInFull]
    payment_methods: [bank, card]
    key_actions: [selectPlan, setupPayment, completePurchase]

  - name: ThankYouPageHRC
    lob: [home, condo, renters]
    type: [purchasable, non_purchasable_CA, non_purchasable_duplex]

  - name: KnockoutPage
    triggers: [ineligible_property, rate_failure, state_restriction, vehicle_info_needed]
    exit_paths: [tryAgain, continueToFGIA, callTollFree, mediaAlpha]

  - name: BristolWestFlowPages
    lob: [auto]
    trigger: bw_qualifying_data
    pages: [BwAdditionalDiscounts, BwPaymentSummary, BwDocuSign, BwCongrats]

  - name: AceLifePages
    lob: [life]
    flow: [NameAndDobPage, PersonalInfoPage, ReviewQuotePage]

  - name: MobileHomePages
    lob: [mobilehome]
    flow: [AddressPage, TellUsMorePage, AboutYouPage, LastStepPage, QuoteReviewPage]
    alternate_carrier: Foremost

  - name: BusinessPage
    lob: [business]
    type: lead_capture
    flow: [BusinessLeadForm, ThankYouPage]

flows:
  - name: AutoStandardQuoteAndBind
    lob: auto
    steps: [LandingPage, NameAndDob, AddressPage, VehiclesDrivers, QuoteSummary, AdditionalInfo, ConsolidatedPayment, eCheckout]

  - name: AutoBristolWestBind
    lob: auto
    trigger: bw_data
    steps: [BDQStart, NameAndDob, AddressPage, VehiclesDrivers, QuoteSummary, BwAdditionalDiscounts, BwPaymentSummary, BwDocuSign, BwCongrats]

  - name: HomeQuoteAndBind
    lob: home
    steps: [LandingPage, AddressContact, PropertyType, PropertyInfo, PropertyDetails, QualityGrade, AdditionalInfo, AboutYou, ContactInfo, ReviewQuote, JFMT, PaymentSelection, PolicyPayment, ThankYou]

  - name: CondoQuoteAndBind
    lob: condo
    steps: [LandingPage, PropertyType, PropertyDetails, QualityGrade, AdditionalInfo, AboutYou, ContactInfo, CustomCoverage, JFMT, ReviewQuote, Payment, ThankYou]

  - name: RentersQuoteAndBind
    lob: renters
    steps: [LandingPage, AddressPage, AboutYou, PropertyType, ContactInfo, JFMT, ReviewQuote, ConsolidatedPayment, ThankYou]

  - name: LifeQuote
    lob: life
    steps: [LandingPage, NameAndDob, PersonalInfo, ReviewQuote]

  - name: MobileHomeQuote
    lob: mobilehome
    steps: [LandingPage, AddressPage, TellUsMore, AboutYou, LastStep, QuoteReview]

  - name: AutoHomeBundleQuoteAndBind
    lob: autoHome
    steps: [LandingPage, AutoFlow..., BundleReviewQuotes, HomeFlow..., BundleFinalReview, AutoPayment, HomePayment, eCheckout]

  - name: RetrieveQuote
    steps: [LandingPage(retrieve_tab), resume_saved_quote]

  - name: KnockoutToCallForQuote
    trigger: rating_failure
    steps: [anyPage, KnockoutPage, CallForQuotePage]

components:
  - name: StepperNavBar
    type: progress_indicator
    variants: [desktop, mobile]
    pages: all_ace_oneui

  - name: FarmersHeader
    type: navigation
    pages: all

  - name: FarmersFooter
    type: footer
    links: [personalInfoUse, digitalAccessibility, termsOfUse, privacyCenter, noticeOfInfoPractices, doNotSell]
    pages: all_ace_oneui

  - name: QuotePresentmentCard
    type: price_display
    variants: [desktop, mobile]
    pages: [ReviewQuote, ThankYou, BundleReview]
    interactions: [viewMonthlyPricing, viewPayInFull, continue, expandMinimize]

  - name: SideSheet
    type: overlay_panel
    pages: [VehiclesDrivers, QuoteSummary, PropertyDetails, ReviewQuote]
    interactions: [open, close, save, back]

  - name: DiscountsSideSheet
    type: overlay_panel
    pages: [ReviewQuote, QuoteSummary]

  - name: AddressAutocomplete
    type: input_with_suggestions
    pages: [LandingPage, PropertyAddress, ContactInfo, PriorAddress]

  - name: DatePicker
    type: calendar_input
    pages: [LandingPage, NameAndDob, ContactInfo, VehiclesDrivers]

  - name: AgentDetails
    type: contact_card
    pages: [ReviewQuote, ThankYou, CallForQuote]
    agent_flow_only: true

  - name: Spinner
    type: loading_overlay
    variants: [aceSpinner, oneuiSpinner, skeleton, oneMomentPlease]
    pages: all

  - name: QualtricsPopup
    type: survey_overlay
    pages: [AutoQuote]
    dismissible: true

  - name: SaveAndFinishLaterPopup
    type: modal
    pages: [AutoQuote]

forms:
  - name: LandingNewQuote
    fields: [LOBSelection, zipCode]
    required: [LOBSelection, zipCode]

  - name: LandingRetrieveQuote
    fields: [lastName, dateOfBirth, quoteNumberOrEmail, zipCode]
    required: all

  - name: NameAndDob
    fields: [firstName, lastName, dateOfBirth]
    required: all
    validation:
      age: "15-99 years"

  - name: VehicleForm
    fields: [vin, year, make, model, type, dateAcquired, primaryUse, parkAtResidence]
    required: [year, make, model, type, dateAcquired, primaryUse, parkAtResidence]

  - name: DriverForm
    fields: [firstName, lastName, dob, gender, usOrCaLicense, willBeDriving, currentlyInsured, relationship, maritalStatus, accidents, financialResponsibility]
    conditionally_required: [financialResponsibility, accidents, safetyCourseTaken]

  - name: ContactInfoHRC
    fields: [policyStartDate, email, phone, mailingAddress]
    required: [policyStartDate, email, phone]
    validation:
      policyStartDate: "1-60 days from today"

  - name: BankPayment
    fields: [accountType, accountHolderName, routingNumber, accountNumber, confirmAccountNumber]
    required: all
    validation:
      routingNumber: "exactly 9 digits"
      accountNumber: "numeric"
      confirmAccountNumber: "must match accountNumber"

  - name: PropertyDetailsEdit
    fields: [yearBuilt, sqFt, stories, bathrooms, roofCover, exteriorWall, garageStyle, foundationType, finishedBasement, fireplace, marketValue]
    required: [yearBuilt, sqFt, stories, bathrooms, roofCover, exteriorWall, foundationType]

tables:
  - name: AutoCoverageTable
    page: QuoteSummaryAutoPage
    columns: [coverageName, limitValue, price]
    sections: [Liability, PerVehicle]
    row_actions: [toggleCoverage, selectLimit]

  - name: HRCCoverageTable
    page: ReviewQuotePageHRC
    columns: [coverageName, value, price]
    sections: [PrimaryCoverages, OptionalCoverages, Deductibles]
    row_actions: [editDeductibles]

  - name: VehicleCardGrid
    page: VehiclesDriversInfoPage
    type: card_grid
    actions: [editVehicle, selectVehicle, addVehicle]

  - name: DriverCardGrid
    page: VehiclesDriversInfoPage
    type: card_grid
    actions: [editDriver, selectDriver, addDriver]

  - name: DiscountsList
    page: DiscountsSideSheet
    columns: [discountName, description]

locators:
  landing:
    zip_input: "//input[@aria-label='Zip code']"
    start_button: "//button[@title='Start My Quote']"
    retrieve_button: "//button[@title='Retrieve Your Quote']"
    auto_lob: "//*[@value='auto']"
    home_lob: "//*[@value='home']"
    retrieve_last_name: "//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Lastname_field']//input"

  name_dob:
    first_name: "//input[contains(@aria-label,'First name')]"
    last_name: "//input[contains(@aria-label,'Last name')]"
    dob: "//input[contains(@aria-label,'Date of birth')]"
    continue: "[data-tui-tracking-id='personal-info__continue-button-cta']"

  vehicles_drivers:
    page_title: "//app-vehicles-drivers-main-screen//h1"
    add_vehicle: "//button[contains(.,'Add another vehicle')]"
    add_driver: "//button[contains(.,'Add another driver')]"
    vin_input: "input[formcontrolname='vin']"
    continue: "//button[@class='tui-btn tui-btn-primary']"

  auto_quote_summary:
    edit_liability: ".tui-link-button.auto-quote-liability-edit-button"
    comp_toggle: "//mat-slide-toggle[@id='Vehicle__21000__toggle']//button"
    coll_toggle: "//mat-slide-toggle[@id='Vehicle__22000__toggle']//button"
    email_link: "//a[@id='emailLink']"

  hrc_review_quote:
    price_desktop: "//mat-card[contains(@class,'tui-quote-presentment-desktop')]//tui-price"
    continue_desktop: "//mat-card[contains(@class,'tui-quote-presentment-desktop')]//button[contains(text(),'Continue')]"
    edit_deductibles: "//button[contains(@class,'edit-deductibles-button')]"
    recalculate: "//button[text()='Recalculate']"

  contact_info:
    policy_start_date: "//app-contact-info//app-date-picker//input"
    agree_submit: "//button[contains(text(),'Agree') or contains(text(),'Continue')][not(@hidden)]"
    error: "//mat-error[not(@hidden)]"

  consolidated_payment:
    pay_in_full: "//mat-radio-button[contains(.,'Pay in full')]"
    monthly_autopay: "//mat-radio-button[contains(.,'Monthly Autopay')]"
    bank_radio: "mat-radio-button[value='bank']"
    card_radio: "mat-radio-button[value='card']"
    bank_added: "//span[contains(.,'Bank payment account added.')]"

  common:
    farmers_logo: "//img[@data-test-id='TUI_LOGO_NO_LINK']"
    ace_spinner: "//div[contains(@class,'tui-spinner-center-content')]"
    skeleton: "//app-loading-skeleton"
    oneui_spinner: "//mat-progress-spinner"
    knockout_title: "h1.tui-h1.inconvenience__title"
    try_again_button: "//button[text()='Try again']"
    generic_continue: "//button[contains(text(),'Continue') or contains(text(),'Agree')][not(@hidden)]"
    save_quote_button: "//button[contains(.,'Save quote')]"
```
