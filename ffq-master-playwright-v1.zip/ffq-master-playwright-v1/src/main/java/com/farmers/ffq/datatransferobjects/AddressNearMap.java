package com.farmers.ffq.datatransferobjects;

import com.farmers.ffq.dataproviderframework.DataObjectBase;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class AddressNearMap extends DataObjectBase {
    private String street_address;
    private String city;
    private String state;
    private String zip_code;
    private String roof_installation_year;
    private String evidence_type;

    /**
     * String Representation of AddressNearMap class.
     */
    public String toString() {
        return String.format("%s: %s %s %s %s %s ", street_address, city, state, zip_code, roof_installation_year, evidence_type);
    }

}
