package com.farmers.ffq.datatransferobjects;

import lombok.Data;

@Data
public class SqlApplicantOneUI {

    private int applicantId;
    private String dateOfBirth;
    private String firstName;
    private String lastName;
    private String quoteID;
    private String rawDateOfBirth;
    private String stateCode;
    private String address;
    private String city;
    private String testCategory;
    private String testScenario;
    private String zipCode;

    public String toString() {
        return "SqlApplicantOneUI{" +
                "applicantId=" + applicantId +
                ", dateOfBirth='" + dateOfBirth + '\'' +
                ", lastName='" + lastName + '\'' +
                ", quoteID='" + quoteID + '\'' +
                ", testCategory='" + testCategory + '\'' +
                ", testScenario='" + testScenario + '\'' +
                ", zipCode='" + zipCode + '\'' +
                '}';
    }
}
