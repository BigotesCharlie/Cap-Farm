package com.farmers.ffq.datatransferobjects.hqm;

import com.farmers.ffq.dataproviderframework.DataObjectBase;

public class ApexHQM extends DataObjectBase implements Cloneable {

    public int id;
    public String testScenario;
    public String firstName;
    public String lastName;
    public String dateOfBirth;
//    public String gender;
    public String maritalStatus;
    public String spouseFirstName;
    public String spouseLastName;
    public String spouseDateOfBirth;
//    public String spouseGender;
    public String addressApt;
    public String city;
    public String stateCode;
    public String state;
    public String zipCode;
    public String agentId;
    public int yearBuilt;
    public String squareFeet;
    public String emailAddress;
    public String phoneNumber;
    public String quoteNumber;
    public String premium;
    public boolean isKnockOutScenario;
    public boolean isIncompleteQuoteScenario;
    public boolean isRerateScenario;
    public boolean isCustomRateScenario;
    public boolean isResetRateScenario;
    public boolean isMultiRerateScenario;
    public boolean isMultiCustomRateScenario;


    @Override
    public ApexHQM clone() throws CloneNotSupportedException {
        return (ApexHQM) super.clone();
    }

    /**
     * String Representation of Applicant class.
     */
    public String toString() {
        return String.format("%s %s %s %s %s %s %s", id, firstName, lastName, addressApt, city, state, zipCode );
    }

    /**
     * String Representation of Applicant class.
     */
    public String toStringMore() {
        return String.format("%s %s %s %s %s %s %s %s %s %s %s %s %s",
                id, firstName, lastName, addressApt, city, state, zipCode, yearBuilt, squareFeet,
                emailAddress, phoneNumber, quoteNumber, premium);
    }

}
