package com.farmers.ffq.auto.pages.legacy;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;

import static com.farmers.ffq.utils.GlobalVariables.SPACE;

public class CongratulationsPage extends BasePage   {

	  @PWFindBy(id = "PolicyIntro")
	  private PWElement congratulationsPageTitle;

	  @PWFindBy(id = "Thanks")
	  private PWElement thankYouText;

	  @PWFindBy(id = "ConfirmationNumber")
	  private PWElement paymentConfirmationNumber;

	  @PWFindBy(id = "NextStepss")
	  private PWElement importantNextSteps;

	  @PWFindBy(xpath = "//*[@id='buypolicy:printbtn']")
	  private PWElement printButton;

	  public CongratulationsPage() throws Exception {
		super();
		waitForSpinnerToBeGone();
	}
	  
	public void verifyCongratulationsPage(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		if(isElementPresentByClass(errorMessageElement)) {
			Log.warn("Error found in quote process", true);
		} else {
			if (isElementPresentByID(thankYouText)) {
				Log.info("Verifying Congratulations page...");
				scrollToTopOfPage();
				waitElementBeVisible(congratulationsPageTitle);
				fsa.assertTrue(getTextFromElement(congratulationsPageTitle).contains("Congratulations"), "Congratulations should be visible as header of the page.");
				String thankYouTextDisplayed = getTextFromElement(thankYouText);
				fsa.assertTrue(thankYouTextDisplayed.contains("Thanks, " + applicant.getFirstName() + SPACE + applicant.getLastName()), "Applicant's first and last name displayed..");
				fsa.assertTrue(thankYouTextDisplayed.contains(applicant.getEmail()), "Applicant's email displayed.");

				String accountNumber = "XXXX-XXXX-XXXX-" + applicant.getPayment().getCardNumber().substring(15);
				fsa.assertTrue(getTextFromElement(paymentConfirmationNumber).contains(accountNumber), "Partial card number is correct.");

				String nextSteps = getTextFromElement(importantNextSteps);
				fsa.assertTrue(nextSteps.contains("Sign your Policy Documents with your Farmers agent."), "Sign your Policy Documents text should be visible.");
				fsa.assertTrue(nextSteps.contains("Print your Temporary Evidence of Insurance Card."), "Print your Temporary Evidence of Insurance Card text should be visible.");

				fsa.assertTrue(printButton.isDisplayed(), "Print button should be visible.");
				fsa.assertTrue(printButton.isEnabled(), "Print button should be enable.");
			} else {
				Log.warn("Never made it to Congratulations screen", true);
			}
		}
	  }

}
