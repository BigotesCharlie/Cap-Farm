package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonIgnoreProperties
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class FCCAuditServiceEnded {
    @JsonProperty("CustomerConsentDataResponse")
    private CustomerConsentDataResponse customerConsentDataResponse;

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class CustomerConsentDataResponse {
        private IidResponseBean.TransactionNotification transactionNotification;
    }
}
