package com.farmers.ffq.utils;

import com.farmers.ffq.datatransferobjects.hqm.EventData;
import com.farmers.framework.AutomationFramework;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class MixpanelApiHelper extends AutomationFramework {

    public static JSONArray getEvents(String projectId, String lob, String quoteNumber) throws Exception {
        projectId = "2543177";
        lob = "H";
        String dateFrom = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String dateTo = dateFrom;
        String url = "https://data.mixpanel.com/api/2.0/export?project_id=" + projectId +
                "&from_date=" + dateFrom + "&to_date=" + dateTo + "&where=properties[\"lob\"] in [\"" + lob +
                "\"] and properties[\"quote_number\"] in [\"" + quoteNumber + "\"]";

        System.out.println(url);
        System.out.println();

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("Accept", "text/plain")
                .addHeader("Authorization",
                        "Basic ZmFybWVycy1yZWctc2VydmljZS4yMWNkMTgubXAtc2VydmljZS1hY2NvdW50OmY3NDR5em5IMllKaTU5eHVaMmhra1ptbGxFVk1MSFcy")
                .build();

        Response response = client.newCall(request).execute();
        String sResponse = Objects.requireNonNull(response.body()).string();

//        System.out.println(">>> Response String:");
//        System.out.println(sResponse);
//        System.out.println();

        JSONParser jsonParser = new JSONParser();
        JSONArray jsa = (JSONArray) jsonParser.parse("[" + sResponse + "]");
        return jsa;
    }

    public static EventData getEventData(String eventJson) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);
        return mapper.readValue(eventJson, EventData.class);
    }
}
