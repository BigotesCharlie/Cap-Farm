package com.farmers.ffq.datatransferobjects;

import com.farmers.ffq.dataproviderframework.DataObjectBase;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter @Setter
public class ApplicantAceHome extends DataObjectBase {

    private String testCategory;
    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private String gender;
    private String maritalStatus;
    private String spouseFirstName;
    private String spouseLastName;
    private String spouseDateOfBirth;
    private String spouseGender;
    private String address;
    private String unit;
    private String city;
    private String county;
    private String stateCode;
    private String state;
    private String zipCode;
    private String priorOrCurrentAddress;
    private String priorOrCurrentUnit;
    private String priorOrCurrentCity;
    private String priorOrCurrentCounty;
    private String priorOrCurrentStateCode;
    private String priorOrCurrentState;
    private String priorOrCurrentZipCode;
    private int yearBuilt;
    private String squareFeet;
    private String generalShapeAndStyleQualityGrade;
    private String exteriorShapeAndStyleQualityGrade;
    private String interiorShapeAndStyleQualityGrade;
    private String cabinetsAndCounterTopsQualityGrade;
    private boolean keep360Prefill;
    private String numberOfStories;
    private String bathrooms;
    private String foundationType;
    private String finishedPercentOfBasement;
    private String exteriorWallFinish;
    private String roofCover;
    private String floorCoverings;
    private String heatingSystem;
    private String fireplace;
    private String garageCarport;
    private String garageStyle;
    private boolean mailingAddressDifferent;
    private String emailAddress;
    private String phoneNumber;
    private String occupation;
    private boolean centralBurglarAlarm;
    private boolean centralFireAlarm;
    private boolean localBurglarAlarm;
    private boolean localFireAlarm;
    private String burglarAlarm;
    private String fireAlarm;
    private String alarmSystem;
    private String sprinklerSystem;
    private String smokeAlarm;
    private String waterLeakProtection;
    private String fortifiedHome;
    private String ulRoof;
    private boolean nonSmoker;
    private boolean temporaryRentals;
    private String swimmingPool;
    private boolean solarPanels;
    private String trampoline;
    private String roofReplaced;
    private boolean mineSubsidence;
    private boolean newlyOwned;
    private boolean inEscrow;
    private boolean fireHydrant;
    private boolean homeVisible;
    private String secondaryHeatingSource;
    private boolean wroughtIronBars;
    private String previousInsurance;
    private String wildFireRisk;
    private String electricalUpdated;
    private String plumbingUpdated;
    private String hvacUpdated;
    private boolean stormShutters;
    private String earlyShoppingFactor;
    private String agentId;
    private boolean emailCheck;
    private String lenderBank;
    private String lenderBankName;
    private String lenderIncompleteSelection;
    private String impoundAccountSelection;
    private boolean plumbingOtherThanCopperPexPVC;
    private String primaryHeatingSource;
    private String updatedPrimaryHeatingSource;
    private boolean unrepairedStructures;
    private boolean businessOperatedOnPremises;
    private String dogsOnPremises;
    private String updatedDogsOnPremises;
    private boolean petWithBiteHistory;
    private String designationRdoBtn;
    private String programRdoBtn;
    private String roofCategoryRdoBtn;
    private String certExpDate;
    private String expectedFortifiedHomeDesignation;
    private String expectedCertExpDate;
    private String quoteNumber;
    private List<SqlDiscount> discounts;

    // In memory fields (not on the worksheet) with their defaults
    // Mobile home
    private boolean primaryResidence = true;
    private String reasonWhyNotPrimaryResidence = "RENT";
    private boolean inMobilePark = true;
    private String homeWidth = "Double";
    private String replacementCost = "100000";

    // Specialty dwelling
    private String typeOfHome = "Traditional site-built home";
    private boolean brickConstruction = false;
    private boolean openFoundation = false;
    private boolean woodburningDevice = false;
    private boolean woodburnerOutbuilding = false;
    private boolean rentedToStudents = false;
    private boolean deadbolts = false;

    /**
     * String Representation of Applicant class.
     */
    public String toString() {
        return String.format("%s %s %s %s %s %s %s %s", getId(), firstName, lastName, address, unit, city, state, zipCode );
    }
}