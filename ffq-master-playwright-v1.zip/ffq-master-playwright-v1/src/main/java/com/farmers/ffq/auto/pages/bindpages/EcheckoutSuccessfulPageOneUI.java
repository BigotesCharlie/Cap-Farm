package com.farmers.ffq.auto.pages.bindpages;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.auto.pages.bw.BwDocuSignPage;

public class EcheckoutSuccessfulPageOneUI extends AutoBasePage {

    private static final String PAYMENT_SUCCESSFUL = "Payment successful";
    @PWFindBy(xpath = "//div[contains(text()," + PAYMENT_SUCCESSFUL + ")]")
    private PWElement paymentSuccessfulMessage;

    private static final String WELCOME_TO_FARMERS = "Welcome to Farmers";
    private final String WELCOME_TO_FARMERS_XPATH = String.format("//h1[contains(.,'%s')]", WELCOME_TO_FARMERS);
    @PWFindBy(xpath = "//h1[contains(text()," + WELCOME_TO_FARMERS + ")]")
    private PWElement welcomeToFarmersMessage;

    private static final String SIGN_ELECTRONICALLY_XPATH = "//h1[contains(.,'Sign electronically')]";
    @PWFindBy(xpath = SIGN_ELECTRONICALLY_XPATH)
    private PWElement signElectronicallyMessage;

    private static final String JOINING_POLICY_HOLDER_MESSAGE = "Thank you for joining us as a policyholder!";
    @PWFindBy(xpath = "//h1[contains(text()," + JOINING_POLICY_HOLDER_MESSAGE + ")]")
    private PWElement joiningAsAPolicyHolderMessage;

    @PWFindBy (xpath = "//button[contains(@class, 'cta-sign')]")
    private PWElement startSigningButton;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public EcheckoutSuccessfulPageOneUI() throws Exception {
    }

    public boolean isPaymentSuccessfulMessageCorrect() {
        String PAYMENT_SUCCESSFUL_MESSAGE = "Payment successful";
        String PAYMENT_SUCCESSFUL_MESSAGE_BUNDLE = "Your  policy payments were successful!";
        try {
            waitForSpinnerToBeGone();
            wait.until(PWExpectedConditions.or(PWExpectedConditions.presenceOfElementLocated(PWBy.xpath("//div[contains(text(),'" + PAYMENT_SUCCESSFUL_MESSAGE + "')]")),
                    PWExpectedConditions.presenceOfElementLocated(PWBy.xpath("//p[contains(text(),'" + PAYMENT_SUCCESSFUL_MESSAGE_BUNDLE + "')]")),
                    		PWExpectedConditions.presenceOfElementLocated(PWBy.xpath("//h1[contains(text(),'Choose a Password')]"))));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isWelcomeToFarmersPresent() {
       return isElementPresent(PWBy.xpath(WELCOME_TO_FARMERS_XPATH), 15);
    }

    public boolean isSignElectronicallyPresent() {
       return isElementPresent(PWBy.xpath(SIGN_ELECTRONICALLY_XPATH) , 15);
    }

    public void signDocuments() throws Exception {
    	clickElement(startSigningButton);
    	waitElementBeInvisible(startSigningButton);
    	new BwDocuSignPage().signDocuments();
    }
}
