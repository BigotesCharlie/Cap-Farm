package com.farmers.ffq.auto.pages.bw;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.framework.report.Log;
import java.util.List;

public class BwDocuSignPage extends AutoBasePage {


    @PWFindBy(xpath = "//input[contains(@data-qa,'ersd-agree-checkbox')]")
    private PWElement disclosureCheckbox;

    @PWFindBy(xpath = "//button[@aria-describedby='continue-btn-a11y-desc']")
    private PWElement disclosurePopUpContinueButton;

    @PWFindBy(css = "button[class='btn btn-primary autoNav-relative']")
    private PWElement startButton;

    @PWFindBy(css = "button[data-qa='auto-nav-caret']")
    private PWElement startButtonAlternative;

    @PWFindBy(css = "button[data-qa='action-bar-btn-finish-mobile']")
    private PWElement nextButton;

    @PWFindBy(css = "button[class='btn btn-primary autoNav-relative btn-caret-right']")
    private PWElement initialButton;

    @PWFindBy(xpath = "//button[contains(@data-qa,'initials-tab-required') and @aria-invalid='true']")
    private List<PWElement> yellowInitials;

    @PWFindBy(xpath = "//div[contains(@class,'signature-tab-content')]")
    private List<PWElement> yellowSignature;

    @PWFindBy(xpath = "//input[contains(@name,'signature-style-radio-buttons')]")
    private PWElement signByRadioButton;

    @PWFindBy(css = "button[data-qa='adopt-submit']")
    private PWElement adoptAndInitial;

    @PWFindBy(css = "button[id='action-bar-btn-finish']")
    private PWElement finishButton;

    @PWFindBy(css = "button[id='action-bar-btn-finish-mobile']")
    private PWElement finishButtonMobile;

    @PWFindBy(xpath = "//div[@data-qa='butter-bar-countdown-content' and contains(.,'required field left')]")
    private PWElement requiredFieldLeft;


    /**
     * Constructor.
     *
     * @throws Exception
     */
    public BwDocuSignPage() throws Exception {
    }

    public boolean isOnDocuSignPage() {
        return isElementVisible(disclosureCheckbox, 100);
    }

    private void agreeDisclosurePopUpAndContinue() {
        if(isElementVisible(disclosureCheckbox,3)) {
            waitAndClickElement(disclosureCheckbox);
            waitAndClickElement(disclosurePopUpContinueButton);
        }
    }

    public void signDocuments() throws Exception {
        isOnDocuSignPage();
        agreeDisclosurePopUpAndContinue();
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(nextButton);
        } else {
            if(isElementVisible(startButtonAlternative, 2)) {
                waitAndClickElement(startButtonAlternative);
            } else {
                waitAndClickElement(startButton);
            }
        }
        sleep(1);
        fillOutInitials();
        fillOutSignatures();

        if(isElementVisible(requiredFieldLeft, 2)) {
            completeRemainingSignatures();
        }
        clickOnFinishButton();
        testStep("Docusign is signed", true);
    }

    private void fillOutInitials() throws Exception {
        sleep(1);
        List<PWElement> initials = driver().findElements(PWBy.xpath("//button[contains(@data-qa,'initials-tab-required') and @aria-invalid='true']"));
    	int numberOfElements = initials.size();
        for (int i =0; i< numberOfElements; i++){
            scrollElementToMiddle(initials.get(i));
            waitAndClickElement(initials.get(i));
            if(i == 0) {
                fillOutAdoptYourInitial();
            }
            sleep(1);
        }
        completeRemainingInitials();
    }

    private void completeRemainingInitials() throws Exception {
        //sign remaining initials
        List<PWElement> stillInvalidInitials = driver().findElements(PWBy.xpath("//div[contains(@class,'initials-tab owned signing-required has-tab-error')]//button"));
    	int numberOfElements = stillInvalidInitials.size();
        for (int i =0; i< numberOfElements; i++){
            waitAndClickElement(stillInvalidInitials.get(i));
        }
    }
    private void completeRemainingSignatures() throws Exception {
        //sign remaining signatures
        List<PWElement> stillInvalidSignatures = driver().findElements(PWBy.xpath("//div[contains(@class,'signing-required') and contains(@class,'signature') and not(contains(@class,'signed'))]"));
    	int numberOfElements = stillInvalidSignatures.size();
        for (int i =0; i< numberOfElements; i++){
            scrollElementToMiddle(stillInvalidSignatures.get(i));
            waitAndClickElement(stillInvalidSignatures.get(i));
        }
    }


    private void fillOutSignatures() throws Exception {
    	int numberOfElements = yellowSignature.size();
        for (int i =0; i < numberOfElements; i++){
            scrollElementToMiddle(yellowSignature.get(i));
            waitAndClickElement(yellowSignature.get(i));
        }
        if(isElementVisible(requiredFieldLeft, 2)) {
            completeRemainingSignatures();
        }
    }

    private void fillOutAdoptYourInitial() {
        if(!isElementVisible(adoptAndInitial,2)) {
            return;
        }
        if (isElementVisible(signByRadioButton,3)) {
            try {
                waitAndClickElement(signByRadioButton);
            } catch (PWElementClickInterceptedException interceptedException) {
                Log.info("Element click intercepted: " + interceptedException.getMessage());
                scrollAndClickOnElement(signByRadioButton);
            }
        }
        waitAndClickElement(adoptAndInitial);
    }

    public void clickOnFinishButton() {
        if(isUseMobileViewEnabled()) {
            scrollElementToMiddle(finishButtonMobile);
            waitAndClickElement(finishButtonMobile);
            wait.until(PWExpectedConditions.invisibilityOfElementLocated(PWBy.cssSelector("button[id='action-bar-btn-finish']")));
        } else {
            scrollElementToMiddle(finishButton);
            waitAndClickElement(finishButton);
            wait.until(PWExpectedConditions.invisibilityOfElementLocated(PWBy.cssSelector("button[id='action-bar-btn-finish']")));

        }
        Log.info("DocuSign Finish Button clicked");
    }

}
