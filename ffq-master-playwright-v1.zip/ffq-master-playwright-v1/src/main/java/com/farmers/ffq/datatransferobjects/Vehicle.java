package com.farmers.ffq.datatransferobjects;
import lombok.Data;

@Data
public class Vehicle implements Cloneable {
	private int vehicleId;
	private int applicantId;
	private int additionalDriverId;
	private String vehicleYear;
	private String vehicleMake;
	private String vehicleModel;
	private String vehicleType;
	private String vehicleVIN;
	private boolean useVIN;
	private String vehicleUsage;
	private boolean ridesharing;
	private String ownership;
	private String purchaseDate;
	private boolean parkInResidentAddress;
	private boolean alternativeFuels;
	private boolean antiTheftDevice;
	private boolean passiveRestraint;
	private boolean airBagSeatBelt;
	private boolean antiLockBrakes;
	private boolean stabilityControl;	
	private boolean daytimeLights;
	private boolean theftRecoverySystem;
	private boolean vinEtching;
	private String lessorStateName;
	private String lessor;
	private int currentOdometerReading;
	private String dateOfReading;
	private String vinDescription;


	@Override
	public Vehicle clone() {
		try {
			return (Vehicle) super.clone();
		} catch (CloneNotSupportedException e) {
			throw new AssertionError(); // Should never happen
		}
	}

}
