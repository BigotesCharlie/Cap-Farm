package com.farmers.ffq.datatransferobjects.hqm;

import java.util.*;
import java.util.stream.Collectors;

public class HomeQuoteHQM {
    public Date quoteInitTimeStamp;
    public boolean uwReviewNeeded;
    public List<Discount> discount;
    public PaymentDetails paymentDetails;
    public CreditDetails creditDetails;
    public String accountNumber;
    public String submissionNumber;
    public String policyNumber;
    public String alternateQuoteNumber;
    public String agentOfRecord;
    public String policytype;
    public String productType;
    public String policyStartDate;
    public String policyEndDate;
    public List<HoOffering> hoOffering;
    public List<OfferedQuote> offeredQuote;

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public String getAlternateQuoteNumber() {
        return alternateQuoteNumber;
    }

    public String getPolicyStartDate() {
        return policyStartDate;
    }

    public String getPolicyEndDate() {
        return policyEndDate;
    }

    public List<String> getDiscountNames () {
        return discount.stream().map(HomeQuoteHQM.Discount::getDiscountName)
                .collect(Collectors.toList());
    }

    public static class Discount{
        public String name;
        public String code;
        public String reference;

        public String getDiscountName() {
            return name;
        }
        public String getDiscountCode() {
            return code;
        }
        public String getDiscountReference() {
            return reference;
        }
    }

    public static class PaymentDetails{
        public String payPlan;
        public boolean isPayPlanChanged;
    }

    public static class CreditDetails{
        public boolean creditFreezeInd;
    }

    public static class TotalPremium{
        public double amount;
        public String currency;
    }

    public static class Deductible{
        public String code;
        public int value;
    }

    public static class CoverageAmount{
        public int amount;
        public String currency;
    }

    public static class PremiumAmount{
        public double amount;
        public String currency;
    }

    public static class BaseCoverage{
        public String coverageCode;
        public String sequenceNumber;
        public CoverageAmount coverageAmount;
        public PremiumAmount premiumAmount;
    }

    public static class Coverages{
        public List<BaseCoverage> baseCoverages;
    }

    public static class HoOffering{
        public String offeringName;
        public TotalPremium totalPremium;
        public List<Deductible> deductibles;
        public Coverages coverages;
    }

    public static class PolicyFee{
        public String amount;
        public String currency;
    }

    public static class Tax{
        public String amount;
        public String currency;
    }

    public static class AdditionalTax{
        public String type;
    }

    public static class Taxes{
        public String amount;
        public String currency;
    }

    public static class Premium{
        public Taxes taxes;
        public TotalPremium totalPremium;
    }

    public static class PayPlanPremium{
        public String payPlan;
        public Premium premium;
    }

    public static class OfferedQuote{
        public String offeringName;
        public PolicyFee policyFee;
        public Tax tax;
        public List<AdditionalTax> additionalTaxes;
        public List<Object> surcharges;
        public List<PayPlanPremium> payPlanPremium;
    }

}
