package com.farmers.ffq.ace.condo;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.ace.hrc.common.AceHRCDwellingCoverageBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoCustomCoveragePage extends AceHRCDwellingCoverageBasePage {

    private static final String COVERAGE_NEEDED_WITHIN_RANGE_ERROR_TEXT = "Coverage needed within range error text verification - condo custom coverage.";
    private static final String HOME_QUALITY_GRADE_QUESTION = "Why is my home's quality grade important?";
    private static final String HOME_QUALITY_GRADE_QUESTION_EXPLANATION_TEXT = "Your home's quality grade, along with other details you've provided about your home," +
            " are used to help estimate how much it might cost to replace the dwelling interior of your home in the event of a total loss.";
    private static final String LEARN_MORE_LINK_TEXT = "Learn more";

    private static final String HIGHER_BUILDING_INTERIOR_VALUE = "$300,000";
    private static final String COVERAGE_NEED_WITHIN_RANGE = "Coverage needs to be within the specified range.";
    private static final String EXPECTED_BUILDING_INTERIOR_HEADER = "Building interior";
    private static final String SEPARATING_STRING = Property.getDriver().equals(SAFARI)? EMPTY_STRING : SPACE;
    private static final String EXPECTED_PERSONAL_PROPERTY_SIDE_SHEET_DESC_NON_VA = "This coverage, also known as Coverage C, can help replace your possessions owned or used by an insured anywhere in the world subject to the policy provisions " +
            "and special limits for things like jewelry, watches, furs, firearms and computers. For a complete list, please check with your Farmers\u00ae representative." + SEPARATING_STRING +
	    "Actual cash value (ACV) - The amount we may pay for repair or replacement is reduced to account for depreciation." + SEPARATING_STRING +
            "Replacement cost value (RCV) - The amount we may pay for repair or replacement does not deduct for depreciation.";

    private static final String EXPECTED_PERSONAL_PROPERTY_SIDE_SHEET_DESC_VA = "This coverage can help replace possessions owned or used by an insured anywhere in the world, subject to the policy provisions and special limits for things like jewelry, " +
            "watches, furs, firearms and computers. For a complete list, please check with your Farmers\u00ae representative. Coverage for personal property is settled at Replacement Cost Value (RCV). Farmers also offers " +
            "settlement at Actual Cash Value, please contact your Farmers\u00ae representative for additional details on these options prior to purchase.";

    @PWFindBy(xpath = "//div[@class='condo-coverage__container']//h1")
    private PWElement customCoverageHeading;

    @PWFindBy(xpath = "//div[contains(@class,'coverage__main-image-section')]//div//img")
    protected PWElement customCoverageImage;
    @PWFindBy(xpath = "//div[contains(@class,'coverage__main-image-section')]//mat-icon")
    private PWElement whyHomeQualityGradeImportantInfoIcon;

    @PWFindBy(xpath = "//div[contains(@class,'coverage__main-image-section')]//p")
    private PWElement whyHomeQualityGradeImportantInfoTitle;
    @PWFindBy(xpath = "//div[contains(@class,'tui-info-box-content')]/span[1]")
    private PWElement whyHomeQualityGradeImportantInfoDescription;

    @PWFindBy(xpath = "//mat-dialog-container//h1")
    private PWElement sideSheetInfoTitleMobile;
    @PWFindBy(xpath = "//mat-dialog-container//p")
    private PWElement sideSheetInfoDescriptionMobile;

    @PWFindBy(xpath = "//div[contains(@class,'tui-info-box-content')]//span[contains(@class,'tui-link-button')]")
    private PWElement whyHomeQualityGradeImportantLearnMoreLink;

    @PWFindBy(xpath = "//mat-dialog-container//span[contains(@class,'tui-link-button')]")
    private PWElement whyHomeQualityGradeImportantLearnMoreLinkMobile;

    @PWFindBy(xpath = "//div[contains(@class,'coverage__main-content-subsection')]")
    private PWElement mainCoveragesTitle;
    @PWFindBy(xpath = "//div[contains(@class,'coverage__value-section')]//div[contains(@class,'tui-body-text-bold')][1]")
    private PWElement personalPropertyValueHeader;
    @PWFindBy(xpath = "//div[contains(@class,'coverage__value-section')]//div[contains(@class,'tui-body-text-bold')]//span[1]")
    private PWElement buildingInteriorValueHeader;
    @PWFindBy(xpath = "//div[contains(@class,'coverage__value-section')]//div[contains(text(),'Personal property value')]/following-sibling::div[contains(@class,'tui-h2')]")
    private PWElement personalPropertyValue;
    @PWFindBy(xpath = "//div[contains(@class,'coverage__value-subsection')]/following-sibling::div")
    private PWElement buildingInteriorValue;
    @PWFindBy(xpath = "//div[contains(@class,'coverage__value-section')]//div[contains(@class,'subtext')]")
    private List<PWElement> replacementCostValueANdHomeQualityGradeSubText;
    @PWFindBy(xpath = "//div[contains(@class,'coverage__value-subsection')]/following-sibling::div[2]")
    private PWElement homeQualityGrade;
//    @FindBy(xpath = "//div[contains(@class,'coverage__main-content-section')]//span[2]")
//    private WebElement homeQualityGradeText;
    @PWFindBy(xpath = "//div[contains(@class,'coverage__main-content-section')]/div/p")
    private PWElement mainCoverageSubText;
    @PWFindBy(xpath = "//div[contains(@class,'coverage__main-content-section')]/div[2]//mat-icon")
    private PWElement buildingInteriorInfoIcon;
    @PWFindBy(xpath = "//div[contains(@class,'coverage__main-content-section')]/div[2]//p[1]")
    private PWElement buildingInteriorInfoTitle;
    @PWFindBy(xpath = "//div[contains(@class,'coverage__main-content-section')]/div[2]//p[2]")
    private PWElement buildingInteriorInfoText;
    @PWFindBy(xpath = "//div[contains(@class,'editcoverage_link')]//button")
    private PWElement editCoveragesLink;
    @PWFindBy(xpath = "//mat-divider")
    private PWElement matDivider;
    @PWFindBy(xpath = "//app-edit-coverage-grade//h4")
    private PWElement coveragesAndGradeHeader;
    @PWFindBy(xpath = "//div[contains(@class,'sidesheet-close-hit-area')]//mat-icon")
    private PWElement closeIconInCoveragesAndGradeSheet;
    @PWFindBy(xpath = "//div[@id='personal-property-section-title']//p")
    private PWElement personalPropertyValueHeaderInSideSheet;
    @PWFindBy(xpath = "//div[contains(@class,'personal-property-input')]//p")
    private PWElement personalPropertyValueExplanation;
    @PWFindBy(xpath = "//div[contains(@class,'personal-property-input')]//input")
    private PWElement personalPropertyValueInputField;
    @PWFindBy(xpath = "//div[contains(@class,'personal-property-input')]//mat-label")
    private PWElement personalPropertyValueAriaLabel;
    @PWFindBy(xpath = "//div[contains(@class,'personal-property-input')]//mat-hint")
    private PWElement personalPropertyValueHint;
    @PWFindBy(xpath = "//mat-expansion-panel//a")
    private PWElement helpMeCalculateThisLink;
    @PWFindBy(xpath = "//button[contains(@class,'property-next-button')]")
    private PWElement nextButton;
    @PWFindBy(xpath = "//div[@id='interior-and-quality-section-title']//p")
    private PWElement buildingInteriorLabel;

    @PWFindBy(xpath = "//div[contains(@class,'circle')]")
    private List<PWElement> trackerCirclesOnSideSheet;
    @PWFindBy(xpath = "//div[contains(@class,'circle-active')]")
    private PWElement activeCircleOnOnSideSheet;
    @PWFindBy(id = "interior-and-quality-section-title")
    private PWElement buildingInteriorTitleOnSideSheet;
    @PWFindBy(xpath = "//div[contains(@class,'description-section')]//p")
    private PWElement buildingInteriorDescriptionInSideSheet;
    @PWFindBy(xpath = "//div[contains(@class,'text-box-section')]//input")
    private PWElement buildingInteriorInputBox;
    @PWFindBy(xpath = "//div[contains(@class,'text-box-section')]//mat-label")
    private PWElement buildingInteriorAriaLabel;
    @PWFindBy(xpath = "//div[contains(@class,'text-box-section')]//mat-hint")
    private PWElement buildingInteriorLimitHint;
    @PWFindBy(xpath = "//div[contains(@class,'building-interior-divider')]")
    private PWElement buildingInteriorDottedDivider;
    @PWFindBy(xpath = "//span[contains(@class,'quality-grade-title-section')]")
    private PWElement standardHomeQualityGradeTitleCondo;
    @PWFindBy(xpath = "//div[contains(@class,'home-quality-subheading')]//mat-icon")
    private PWElement standardHomeQualityGradeInfoIconCondo;
    @PWFindBy(xpath = "//div[contains(@class,'quality-grade-description-section')]//span[1]")
    private PWElement standardHomeQualityGradeSubTextCondo;
    @PWFindBy(xpath = "//div[contains(@class,'quality-grade-description-section')]//span[@class='tui-link-button']")
    private PWElement editYourQualityGradeLinkCondo;
    @PWFindBy(xpath = "//div[contains(@class,'page-submit-section')]//button")
    private PWElement doneButtonCondo;
    @PWFindBy(xpath = "//app-model-info-box//mat-icon[text() = 'close']")
    private PWElement closeIconWhyIsMyHomeQualityGradeImportantSideSheetCondo;
    @PWFindBy(xpath = "//app-edit-coverage-grade")
    private PWElement coveragesAndGradeSideSheetCondo;
    @PWFindBy(xpath = "//mat-error//span")
    private PWElement coverageNeededWithinRangeError;
    @PWFindBy(xpath = "//app-personal-property-calculator//h4")
    private PWElement personalPropertyCalculatorHeader;
    //app-personal-property-calculator//mat-icon[text() = 'close']
    @PWFindBy(xpath = "//app-personal-property-calculator//h4")
    private PWElement personalPropertyCalculatorCloseIcon;
    @PWFindBy(xpath = "//app-personal-property-calculator/div/div[2]/p")
    private PWElement personalPropertyCalculatorDescription;

    @PWFindBy(xpath = "//app-personal-property-calculator/div/div[2]/div")
    private List<PWElement> personalPropertyCategoriesWebElements;
    @PWFindBy(xpath = "//app-personal-property-calculator/div/div[2]//mat-slider//input")
    private List<PWElement> personalPropertySliders;
    @PWFindBy(xpath = "//app-personal-property-calculator/div/div[2]/div[6]//p[1]")
    private PWElement personalPropertyGrowthHeader;
    @PWFindBy(xpath = "//app-personal-property-calculator/div/div[2]/div[6]//p[2]")
    private PWElement personalPropertyGrowthAmount;
    @PWFindBy(xpath = "//app-personal-property-calculator/div/div[2]/div[6]//p[3]")
    private PWElement minimumAmountOfCoverageValue;
    @PWFindBy(xpath = "//app-personal-property-calculator//button")
    private PWElement useThisValueButton;

    @PWFindBy(xpath = "//div[contains(@class,'coverage__main-content-section')]//mat-icon[text()='info']")
    private PWElement mainContentInfoMobile;
    @PWFindBy(xpath = "//div[contains(@class,'coverage__value-section')]//mat-icon[text()='info']")
    private PWElement interiorValueInfoMobile;
    @PWFindBy(xpath = "//mat-icon[text()='close']")
    private PWElement closeSidesheetButtonMobile;


    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceCondoCustomCoveragePage() throws Exception {
    }

    public boolean isOnCustomCoveragePageAceCondo() {
        return isElementVisible(personalPropertyValueHeader, Property.PAGELOADTIMEOUT);
    }

    public void validateCustomCoverageHeaderAndImage(FarmersSoftAssert fsa) throws Exception {
        waitElementBeVisible(customCoverageImage);
        String expectedDwellingCoverageHeader = "Review your main coverages";
        fsa.assertEquals(getTextFromElement(customCoverageHeading), expectedDwellingCoverageHeader, "Custom coverage heading verification.");
        fsa.assertTrue(isElementInViewport(customCoverageHeading), "Custom coverage page - page title is in Viewport");
        fsa.assertTrue(customCoverageImage.isDisplayed(), "Custom coverage image displayed");
    }

    public void validateWhyHomeQualityGradeImportantSection(FarmersSoftAssert fsa) {
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(mainContentInfoMobile);
            waitElementBeVisible(closeSidesheetButtonMobile);
            fsa.assertEquals(getTextFromElement(sideSheetInfoTitleMobile), HOME_QUALITY_GRADE_QUESTION, "Dwelling coverage info question text verification (mobile).");
            fsa.assertEquals(getTextFromElement(sideSheetInfoDescriptionMobile), HOME_QUALITY_GRADE_QUESTION_EXPLANATION_TEXT + " " + LEARN_MORE_LINK_TEXT,
                    "Why home quality grade important info question text verification - condo custom coverage (mobile).");
            fsa.assertEquals(getTextFromElement(whyHomeQualityGradeImportantLearnMoreLinkMobile), LEARN_MORE_LINK_TEXT, "Learn more link text verification - condo custom coverage (mobile).");
            waitAndClickElement(closeSidesheetButtonMobile);
        } else {
            waitElementBeVisible(whyHomeQualityGradeImportantInfoIcon);
            fsa.assertEquals(getTextFromElement(whyHomeQualityGradeImportantInfoTitle), HOME_QUALITY_GRADE_QUESTION, "Dwelling coverage info question text verification.");
            fsa.assertEquals(getTextFromElement(whyHomeQualityGradeImportantInfoDescription), HOME_QUALITY_GRADE_QUESTION_EXPLANATION_TEXT,
                    "Why home quality grade important info question text verification - condo custom coverage.");
            fsa.assertEquals(getTextFromElement(whyHomeQualityGradeImportantLearnMoreLink), LEARN_MORE_LINK_TEXT, "Learn more link text verification - condo custom coverage.");
        }
    }

    public void validateBuildingInteriorInfoSection(FarmersSoftAssert fsa) {
        String expectedBuildingInteriorInfoText = "As a condo owner, you decide the coverage to rebuild the interior of your condo. This is also known as your \"Unit owner's building property\" coverage.";
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(interiorValueInfoMobile);
            waitElementBeVisible(closeSidesheetButtonMobile);
            fsa.assertEquals(getTextFromElement(sideSheetInfoTitleMobile), EXPECTED_BUILDING_INTERIOR_HEADER, "Building interior info title verification (mobile).");
            fsa.assertEquals(getTextFromElement(sideSheetInfoDescriptionMobile), expectedBuildingInteriorInfoText,
                    "Building interior info question text verification - condo custom coverage (mobile).");
            waitAndClickElement(closeSidesheetButtonMobile);
        } else {
            waitElementBeVisible(buildingInteriorInfoIcon);
            fsa.assertEquals(getTextFromElement(buildingInteriorInfoTitle), EXPECTED_BUILDING_INTERIOR_HEADER, "Building interior info title verification - condo custom coverage.");
            fsa.assertEquals(getTextFromElement(buildingInteriorInfoText), expectedBuildingInteriorInfoText, "Building interior info question text verification - condo custom coverage.");
        }
    }

    public void validateMainCoverageTextSection(FarmersSoftAssert fsa) throws Exception {
        String expectedMainCoveragesTitle = isUseMobileViewEnabled() || isSafariBrowser() ? "Main coverages info" : "Main coverages";
        fsa.assertEquals(getTextFromElement(mainCoveragesTitle), expectedMainCoveragesTitle, "Main coverages title text verification - condo custom coverage.");

        String expectedHomeQualityGrade = getTheQualityGradeFromAppStore();
        String expectedHomeQualityGradeText = expectedHomeQualityGrade +  " home quality grade";
        fsa.assertEquals(getTextFromElement(homeQualityGrade), expectedHomeQualityGradeText, "Home quality grade with text verification - condo custom coverage.");

        String expectedMainCoverageSubText = "The initial estimate to replace your personal property and to rebuild the interior of your condo (called \"Building property unit owners\") in the event of a covered loss is based on the information you provided. You ultimately decide your coverage limits.";
        fsa.assertEquals(getTextFromElement(mainCoverageSubText), expectedMainCoverageSubText, "Main coverage sub text verification - condo custom coverage.");
    }

    public String getPersonalPropertyValue() {
        return getValueFromWebElement(personalPropertyValue);
    }

    public String getBuildingInteriorValue() {
        return getValueFromWebElement(buildingInteriorValue);
    }

    public void validateMainCoveragesValuesSection(FarmersSoftAssert fsa, AppStore appStore) throws Exception {

        // validate personal property value amount, header validation and replacement cost value subtext
        String expectedPersonalPropertyValue = getPersonalPropertyValueFromAppStoreInCurrencyFormat(appStore);
        if (expectedPersonalPropertyValue != null) {
            fsa.assertEquals(getTextFromElement(personalPropertyValue), expectedPersonalPropertyValue, "Personal property value verification - condo custom coverage.");
        } else {
            fsa.assertEquals(getTextFromElement(personalPropertyValue), getOneLakhsInCurrencyFormat(), "Personal property value on initial load verification.");
        }
        String expectedPersonalPropertyValueHeader = "Personal property value";
        fsa.assertEquals(getTextFromElement(personalPropertyValueHeader) , expectedPersonalPropertyValueHeader, "Personal property value header verification - main coverages section - condo custom coverage.");

        String expectedReplacementCostValueSubtext = "Replacement cost value";
        fsa.assertEquals(getTextFromElement(replacementCostValueANdHomeQualityGradeSubText.get(0)) , expectedReplacementCostValueSubtext, "Replacement cost value subtext verification - main coverages section - condo custom coverage.");

        // validate building interior value amount, building interior header, home quality grade
        String expectedBuildingInteriorAmount = getDwellingCoverageCostFromAppStoreInCurrencyFormat(getSessionStorageAppStore());
        fsa.assertEquals(getTextFromElement(buildingInteriorValue), expectedBuildingInteriorAmount, "Building interior amount verification - condo custom coverage.");

        fsa.assertEquals(getTextFromElement(buildingInteriorValueHeader) , EXPECTED_BUILDING_INTERIOR_HEADER, "Home quality grade verification - main coverages section - condo custom coverage.");

        String expectedHomeQualityGradeValue = getTheQualityGradeFromAppStore() + " home quality grade";
        fsa.assertEquals(getTextFromElement(replacementCostValueANdHomeQualityGradeSubText.get(1)) , expectedHomeQualityGradeValue, "Home quality grade subtext verification - main coverages section - condo custom coverage.");
    }

    public void validateCustomCoverageEditCoverageAndQualityGradeLinkSection(FarmersSoftAssert fsa) {
        String expectedEditCoverageButtonLinkText = "Edit coverages";
        fsa.assertEquals(getTextFromElement(editCoveragesLink), expectedEditCoverageButtonLinkText, "Edit coverage link text verification - condo custom coverage.");
        fsa.assertTrue(editCoveragesLink.isEnabled(), "Edit coverage link enabled - condo custom coverage.");
        scrollToElement(matDivider);
        waitElementBeVisible(matDivider);
        fsa.assertTrue(matDivider.isDisplayed(), "Mat divider displayed - condo custom coverage.");
    }

    public String getPersonalPropertyValueFromAppStoreInCurrencyFormat(AppStore appStore) {
        String expectedPersonalPropertyValue = appStore.getHome().getPersonalPropertyValue();
        if (expectedPersonalPropertyValue != null) {
            expectedPersonalPropertyValue = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(expectedPersonalPropertyValue);
        }
        return expectedPersonalPropertyValue;
    }

    public String getOneLakhsInCurrencyFormat() {
        return CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal("100000");
    }

    public void clickOnLearnMoreLinkOnCustomCoveragePage() {
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(mainContentInfoMobile);
            waitAndClickElement(whyHomeQualityGradeImportantLearnMoreLinkMobile);
        } else {
            waitAndClickElement(whyHomeQualityGradeImportantLearnMoreLink);
        }
    }

    public void clickOnNextButton() {
        waitAndClickElement(nextButton);
    }

    public void clickOnEditCoveragesAndQualityGradeLink() {
        waitAndClickElement(editCoveragesLink);
    }

    public void clickOnEditYourQualityGradeLinkCondo() {
        waitAndClickElement(editYourQualityGradeLinkCondo);
    }

    public void clickOnDoneOrSaveButton() {
        waitAndClickElement(doneButtonCondo);
    }

    public void clickOnCloseIconInCoveragesAndGradeSideSheet() {
        waitAndClickElement(closeIconInCoveragesAndGradeSheet);
    }

    public void clickOnHelpMeCalculateThisLinkCondo() {
        waitAndClickElement(helpMeCalculateThisLink);
    }

    public void validateContentOfCoveragesAndGradeInCondo(FarmersSoftAssert fsa, AppStore appStore, boolean initialLoad, String applicantStateCode) throws Exception {
        String expectedCoveragesHeader = "Coverages";
        fsa.assertEquals(getTextFromElement(coveragesAndGradeHeader), expectedCoveragesHeader, "Coverages header verification - condo custom coverage.");

        fsa.assertEquals(trackerCirclesOnSideSheet.size(), 2, "Tracker circles count - condo custom coverage.");
        fsa.assertTrue(activeCircleOnOnSideSheet.isDisplayed(), "Active tracker circle displayed - condo custom coverage.");
        waitElementBeVisible(closeIconInCoveragesAndGradeSheet);
        fsa.assertTrue(closeIconInCoveragesAndGradeSheet.isDisplayed(), "Close icon displayed on coverage and grade side sheet- condo custom coverage.");

        String expectedPersonalPropertyValueHeader = "Personal property value";
        fsa.assertEquals(getTextFromElement(personalPropertyValueHeader), expectedPersonalPropertyValueHeader, "Personal property value header verification - condo custom coverage.");

        String expectedPersonalPropertyExplanation = applicantStateCode.equals(VA) ? EXPECTED_PERSONAL_PROPERTY_SIDE_SHEET_DESC_VA : EXPECTED_PERSONAL_PROPERTY_SIDE_SHEET_DESC_NON_VA;
        fsa.assertEquals(getTextFromElement(personalPropertyValueExplanation), removeSpecialCharFromString(expectedPersonalPropertyExplanation), "Personal property explanation text verification - condo custom coverage.");

        fsa.assertTrue(personalPropertyValueInputField.isDisplayed(), "Personal property value input field displayed - condo custom coverage.");
        fsa.assertEquals(getTextFromElement(personalPropertyValueAriaLabel), expectedPersonalPropertyValueHeader, "Personal property value aria label verification - condo custom coverage.");

        String expectedPersonalPropertyValue = initialLoad ? "$100,000" : appStore.getHome().getPersonalPropertyValue();
        fsa.assertEquals(getAttributeData(personalPropertyValueInputField, VALUE).trim(), expectedPersonalPropertyValue, "Personal property value inside input box - condo custom coverage.");

        String expectedPersonalPropertyValueRangeHint = applicantStateCode.equals(VA)? "$5,000 - $300,000" : "$4,000 - $300,000";
        fsa.assertEquals(getTextFromElement(personalPropertyValueHint), expectedPersonalPropertyValueRangeHint, "Personal property value range hint verification - condo custom coverage.");

        String expectedHelpMeCalculateLinkText = "Help me calculate this";
        fsa.assertEquals(getTextFromElement(helpMeCalculateThisLink), expectedHelpMeCalculateLinkText, "Help me calculate this link text verification - condo custom coverage.");

        String nextButtonText = "Next";
        fsa.assertTrue(nextButton.isDisplayed(), "Next button displayed - condo custom coverage.");
        fsa.assertEquals(getTextFromElement(nextButton), nextButtonText, "Next button text verification - condo custom coverage.");

        fsa.assertEquals(getTextFromElement(buildingInteriorLabel), EXPECTED_BUILDING_INTERIOR_HEADER, "Building interior label verification.");

        clickOnNextButton();
        fsa.assertEquals(trackerCirclesOnSideSheet.size(), 2, "Tracker circles count - condo custom coverage.");
        fsa.assertTrue(activeCircleOnOnSideSheet.isDisplayed(), "Active tracker circle displayed - condo custom coverage.");

        fsa.assertEquals(getTextFromElement(buildingInteriorTitleOnSideSheet), EXPECTED_BUILDING_INTERIOR_HEADER, "Building interior header verification - condo custom coverage.");

        String expectedBuildingInteriorDescription = "This coverage, referred to as Unit Owner's Building Property, can repair or replace the portion of your condominium owned by you from a covered loss, subject to your policy provisions, " +
                "which include, but are not limited to, common exclusions such as, wear and tear, earth movement, earthquake, mold, flood and nuclear hazard.";
        fsa.assertEquals(getTextFromElement(buildingInteriorDescriptionInSideSheet), expectedBuildingInteriorDescription, "Building interior description verification - condo custom coverage.");

        fsa.assertTrue(buildingInteriorInputBox.isDisplayed(), "Building interior input box displayed - condo custom coverage.");

        fsa.assertEquals(getTextFromElement(buildingInteriorAriaLabel), EXPECTED_BUILDING_INTERIOR_HEADER, "Building interior aria label check - condo custom coverage.");

        validateBuildingInteriorValueRange(fsa);

        fsa.assertTrue(buildingInteriorDottedDivider.isDisplayed(), "Building interior dotted divider displayed - condo custom coverage.");

        validateUnSavedChangesInCoveragesAndGradeSideSheet(fsa);

        clickOnEditCoveragesAndQualityGradeLink();
        sleep(1);
        clickOnHelpMeCalculateThisLinkCondo();

        // validate content of personal property calculator, save the updated value, validate the updated value
        validateContentPersonalPropertyCalculator(fsa, 10000, CONDO);
        clickOnNextButton();
        clickOnDoneOrSaveButton();
        validateMainCoveragesValuesSection(fsa, getSessionStorageAppStore());
    }

    public void validateUnSavedChangesInCoveragesAndGradeSideSheet(FarmersSoftAssert fsa) {
        closeSideSheetByEscKey(fsa);
        clickOnEditCoveragesAndQualityGradeLink();
        sleep(2);
        clearOutFieldUsingBackSpace(personalPropertyValueInputField);
        fsa.assertEquals(getTextFromElement(coverageNeededWithinRangeError), COVERAGE_NEED_WITHIN_RANGE, COVERAGE_NEEDED_WITHIN_RANGE_ERROR_TEXT);
        clickOnCloseIconInCoveragesAndGradeSideSheet();
        validateContentOfExitWithoutSavingPopUp(fsa);
        clickOnContinueEditingLink();

        sendKeysOneByOne(personalPropertyValueInputField, "3000");
        fsa.assertEquals(getTextFromElement(coverageNeededWithinRangeError), COVERAGE_NEED_WITHIN_RANGE, COVERAGE_NEEDED_WITHIN_RANGE_ERROR_TEXT);

        sendKeysOneByOne(personalPropertyValueInputField, "4000000");
        fsa.assertEquals(getTextFromElement(coverageNeededWithinRangeError), COVERAGE_NEED_WITHIN_RANGE, COVERAGE_NEEDED_WITHIN_RANGE_ERROR_TEXT);
        clickOnCloseIconInCoveragesAndGradeSideSheet();
        clickOnExitWithoutSavingButton();
        clickOnEditCoveragesAndQualityGradeLink();

        clickOnNextButton();
        if (!isElementVisible(buildingInteriorInputBox, 3)) {
            waitAndClickElement(personalPropertyValueHeaderInSideSheet);
            clickOnNextButton();
        }
        clearOutFieldUsingBackSpace(buildingInteriorInputBox);
        clickOnCloseIconInCoveragesAndGradeSideSheet();
        validateContentOfExitWithoutSavingPopUp(fsa);
        clickOnContinueEditingLink();

        sendKeysOneByOne(buildingInteriorInputBox, "3000");
        fsa.assertEquals(getTextFromElement(coverageNeededWithinRangeError), COVERAGE_NEED_WITHIN_RANGE, COVERAGE_NEEDED_WITHIN_RANGE_ERROR_TEXT);

        sendKeysOneByOne(buildingInteriorInputBox, "4000000");
        fsa.assertEquals(getTextFromElement(coverageNeededWithinRangeError), COVERAGE_NEED_WITHIN_RANGE, COVERAGE_NEEDED_WITHIN_RANGE_ERROR_TEXT);

        clickOnCloseIconInCoveragesAndGradeSideSheet();
        clickOnContinueEditingLink();
        clickOnCloseIconInCoveragesAndGradeSideSheet();
        clickOnExitWithoutSavingButton();
    }

    public void checkIfCoverageAndGradeSideSheetDisplayedCondo(FarmersSoftAssert fsa) {
        waitElementBeVisible(coveragesAndGradeHeader);
        fsa.assertTrue(coveragesAndGradeSideSheetCondo.isDisplayed(), "Coverages & grade side sheet displayed - custom coverage condo.");
    }

    public void validateBuildingInteriorValueRange(FarmersSoftAssert fsa) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        String buildingInteriorLowerLimit = getDwellingCoverageCostFromAppStoreInCurrencyFormat(appStore);
        String expectedBuildingInteriorLimitRange = buildingInteriorLowerLimit + " - " + HIGHER_BUILDING_INTERIOR_VALUE;
        fsa.assertEquals(getTextFromElement(buildingInteriorLimitHint), expectedBuildingInteriorLimitRange, "Building interior value range is not valid - condo custom coverage.");
        fsa.assertEquals(getAttributeData(buildingInteriorInputBox, VALUE).trim(), buildingInteriorLowerLimit, "Building interior value verification in building interior input box - condo custom coverage.");
    }

    public void validateContentPersonalPropertyCalculator(FarmersSoftAssert fsa, int multiplier, String lobType) {
        waitElementBeVisible(personalPropertyCalculatorHeader);
        String expectedPersonalPropertyCalculatorHeader = "Personal property calculator";
        fsa.assertEquals(getTextFromElement(personalPropertyCalculatorHeader), expectedPersonalPropertyCalculatorHeader,
                "Personal property calculator header verification - condo custom coverage.");

        fsa.assertTrue(personalPropertyCalculatorCloseIcon.isDisplayed(), "Personal property calculator close icon displayed - condo custom coverage.");

        String expectedPersonalPropertyCalculatorDescription = "Use the sliders to help calculate an estimate for your personal property. Please note, " +
                "the amounts you select will help determine your overall coverage, they won't limit your coverage in each category.";
        fsa.assertEquals(getTextFromElement(personalPropertyCalculatorDescription), expectedPersonalPropertyCalculatorDescription,
                "Personal property calculator description text verification - condo custom coverage.");


        List<String> personalPropertyCategories = personalPropertyCategoriesWebElements.stream().limit(5).map(i -> getTextFromElement(i)).collect(Collectors.toList());
        List<String> expectedPersonalPropertyCategories = isSafariBrowser()?
        	Arrays.asList("Electronics$0MinMax", "Furniture$0MinMax", "Wardrobe$0MinMax", "Hobbies$0MinMax", "Appliances$0MinMax"):
        	Arrays.asList("Electronics $0 Min Max", "Furniture $0 Min Max", "Wardrobe $0 Min Max", "Hobbies $0 Min Max", "Appliances $0 Min Max");

        fsa.assertEquals(personalPropertyCategories, expectedPersonalPropertyCategories, "Personal property categories verification - condo custom coverage.");

        fsa.assertEquals(personalPropertySliders.size(), 5, "Personal property slider size verification - condo custom coverage.");

        String expectedPersonalPropertyGrowthText = "My personal property is worth";
        fsa.assertEquals(getTextFromElement(personalPropertyGrowthHeader), expectedPersonalPropertyGrowthText, "Personal property growth header text verification - condo custom coverage.");

        String expectedPersonalPropertyGrowthValue = "$0";
        fsa.assertEquals(getTextFromElement(personalPropertyGrowthAmount), expectedPersonalPropertyGrowthValue, "Personal property growth value text verification - condo custom coverage.");

        String expectedRequiredMinimumCoverageText = "The minimum amount of coverage required is $4,000.";
        fsa.assertEquals(getTextFromElement(minimumAmountOfCoverageValue), expectedRequiredMinimumCoverageText, "Minimum required coverage line text verification - condo custom coverage.");

        String expectedUseThisValueButtonText = "Use this value";
        fsa.assertEquals(getTextFromElement(useThisValueButton), expectedUseThisValueButtonText, "Use this value button text verification - condo custom coverage.");

        int totalMove = 0;
        for (PWElement personalPropertySlider : personalPropertySliders) {
            int randomMove = ThreadLocalRandom.current().nextInt(0, 6);
            for (int j = 0; j < randomMove; j++) {
                sendKeysToElement(personalPropertySlider, PWKeys.ARROW_RIGHT);
                sleep(2);
            }
            totalMove = totalMove + randomMove;
        }

        int totalPersonalPropertyValue = totalMove * multiplier;
        String expectedPersonalPropertyGrowthValueFromSliders = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(totalPersonalPropertyValue));
        int sleepSeconds = Property.getTestProperty("driver").equalsIgnoreCase(FIREFOX) ? 5 : 3; // added extra wait for firefox as slider movement and value update is taking more time in firefox compared to other browsers
        sleep(sleepSeconds);
        String countedPersonalPropertyGrowthValue = getTextFromElement(personalPropertyGrowthAmount);

        fsa.assertEquals(countedPersonalPropertyGrowthValue, expectedPersonalPropertyGrowthValueFromSliders, "Counted personal property growth value verification - condo custom coverage.");

        waitAndClickElement(useThisValueButton);
        if (lobType.equals(CONDO)) {
            fsa.assertEquals(getAttributeData(personalPropertyValueInputField, VALUE), countedPersonalPropertyGrowthValue,
                    "Personal property value verification in personal property input field - condo custom coverage.");
        }
    }

    public void fillOutCustomCoveragePageCondo(ApplicantAceHome applicantAceHome) throws Exception {
        waitElementBeVisible(customCoverageImage);
        AppStore appStore = getSessionStorageAppStore();
        String reconstructionCost = appStore.getHome().getReconstructionCost();
        if (reconstructionCost != null && Integer.parseInt(reconstructionCost) <= THREELAKH) {
            if (!applicantAceHome.isKeep360Prefill()) {
                clickOnEditCoveragesAndQualityGradeLink();
                waitElementBeVisible(coveragesAndGradeHeader);
                int randomPersonalPropertyValue = roundToThousand(randomNumberBetweenTwoNumbers(4000, 300000));
                waitElementBeVisibleClickable(personalPropertyValueInputField);
                sendKeysOneByOne(personalPropertyValueInputField, String.valueOf(randomPersonalPropertyValue));
                Log.info("Selecting Personal property value: " + randomPersonalPropertyValue);
                clickOnNextButton();

                int randomBuildingInteriorValue = roundToThousand(randomNumberBetweenTwoNumbers(Integer.parseInt(appStore.getHome().getDwellingCoverage()), 300000));
                waitElementBeVisibleClickable(buildingInteriorInputBox);
                sendKeysOneByOne(buildingInteriorInputBox, String.valueOf(randomBuildingInteriorValue));
                Log.info("Selecting Building interior value: " + randomBuildingInteriorValue);

                clickOnDoneOrSaveButton();
            }
        }
    }

    public void clickOnContinueButton() throws Exception {
        scrollElementToMiddle(buttonContinue);
        waitAndClickElement(buttonContinue);
        testStep("Clicked on Continue button at " + driver().getCurrentUrl(), false);
    }

    public void changeCustomCoverage() throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        String dwellingCoverage = appStore.getHome().getDwellingCoverage();
        clickOnEditCoveragesAndQualityGradeLink();
        waitElementBeVisible(coveragesAndGradeHeader);
        int randomPersonalPropertyValue = roundToThousand(randomNumberBetweenTwoNumbers(4000, 300000));
        waitElementBeVisibleClickable(personalPropertyValueInputField);
        sendKeysOneByOne(personalPropertyValueInputField, String.valueOf(randomPersonalPropertyValue));
        Log.info("Selecting Personal property value: " + randomPersonalPropertyValue);

        clickOnNextButton();

        int randomBuildingInteriorValue = roundToThousand(randomNumberBetweenTwoNumbers(Integer.parseInt(dwellingCoverage), 300000));
        waitElementBeVisibleClickable(buildingInteriorInputBox);
        sendKeysOneByOne(buildingInteriorInputBox, String.valueOf(randomBuildingInteriorValue));
        Log.info("Selecting Building interior value: " + randomBuildingInteriorValue);

        clickOnDoneOrSaveButton();
        clickContinueButton();
    }

    public void validateADA() throws InterruptedException {
        clickOnEditCoveragesAndQualityGradeLink();
        performADATesting(this.getClass().getSimpleName(),MARKETING_IT,FFQ_ACE_CONDO);
        clickOnCloseIconInCoveragesAndGradeSideSheet();
    }
}
