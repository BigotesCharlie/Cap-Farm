package com.farmers.ffq.utils;

import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.framework.report.Log;
import com.manybrain.mailinator.client.MailinatorClient;
import com.manybrain.mailinator.client.message.GetInboxRequest;
import com.manybrain.mailinator.client.message.GetLinksRequest;
import com.manybrain.mailinator.client.message.GetMessageRequest;
import com.manybrain.mailinator.client.message.Links;
import com.manybrain.mailinator.client.message.Message;
import com.manybrain.mailinator.client.message.Sort;
import org.apache.commons.lang3.RandomUtils;
import org.testng.Assert;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.awaitility.Awaitility.with;

public class Mailinator extends AutoBasePage {

    public static String MAILINATOR_FARMERS_PRIVATE_DOMAIN = "farminsqa.testinator.com";

    private static final String START_TEXT = "A Farmers agent will be in touch with you soon.";
    private static final String START_TEXT_EE = "A Farmers<sup>&reg;</sup> representative will be in touch with you soon.";

    private static final String DISCLAIMER_1 = "Advertisement produced on behalf of the following specific insurers and seeking to obtain business " +
            "for insurance underwritten by Farmers Insurance Exchange, Fire Insurance Exchange, Truck Insurance Exchange, Mid-Century Insurance Company, &nbsp;" +
            "Farmers Insurance Company of Washington (Bellevue, WA) or affiliates. In TX: insurance is underwritten by Farmers Insurance Exchange, Fire " +
            "Insurance Exchange, Truck Insurance Exchange, Mid-Century Insurance Company, Farmers Texas County Mutual Insurance Company, Mid-Century Insurance " +
            "Company of Texas or Texas Farmers Insurance Company. In NY: insurance is underwritten by Farmers Insurance Exchange, Truck Insurance Exchange,";

    private static final String DISCLAIMER_EE_1A = "Advertisement produced on behalf of the following specific insurers and seeking to obtain business for " +
            "insurance underwritten by Farmers Insurance Exchange, Fire Insurance Exchange, Truck Insurance Exchange, Mid-Century Insurance Company, &nbsp;" +
            "Farmers Insurance Company of Washington (Bellevue, WA) or affiliates. In TX: insurance is underwritten by Farmers Insurance Exchange, Fire Insurance " +
            "Exchange, Truck Insurance Exchange, Mid-Century Insurance Company, Farmers Texas County Mutual Insurance Company, Mid-Century Insurance Company " +
            "of Texas or Texas Farmers Insurance Company. In NY: insurance is underwritten by Farmers Insurance Exchange, Truck Insurance Exchange, Mid-Century";
    private static final String DISCLAIMER_EE_1B = "Insurance Company or Farmers New Century Insurance Company. Home office, Los Angeles, CA.";

    private static final String DISCLAIMER_2A = "Each insurer has sole financial responsibility for its own insurance. List of all insurers and states where licensed at";
    private static final String DISCLAIMER_2B = "Not all insurers are authorized in all states. Not all products, coverages, and discounts " +
            "are available in every state and may vary by state. Restrictions, exclusions, limits, and conditions apply. See agent for details.";

    public static final String DISCLAIMER_QUICKEN_1 = "Advertisement produced on behalf of the following specific insurers and seeking to obtain " +
            "business for insurance underwritten by Farmers Insurance Exchange, Fire Insurance Exchange, Truck Insurance Exchange, Mid-Century " +
            "Insurance Company, Civic Property and Casualty Company, Exact Property and Casualty Company, Neighborhood Spirit Property and Casualty " +
            "Company, Farmers Insurance Company of Washington (Bellevue, WA) & affiliates. In TX: insurance is underwritten by Farmers Insurance " +
            "Exchange, Fire Insurance Exchange, Truck Insurance Exchange, Mid-Century Insurance Company, Farmers Texas County Mutual Insurance Company, " +
            "Mid-Century Insurance Company of Texas, and Texas Farmers";
    public static final String DISCLAIMER_QUICKEN_2 = "Insurance Company. In NY: insurance is underwritten by Farmers Insurance Exchange, Truck Insurance " +
            "Exchange, Mid-Century Insurance Company and Farmers New Century Insurance Company. Home office, Los Angeles, CA.";

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public Mailinator() throws Exception {
    }

    public static void validateHqmThankYouEmail(ApplicantHQM applicantHQM, boolean eeState, List<Message> messages) {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        // Check if Thank you email is received
        int counter = 0;
        for (Message message : messages) {
            if (message.getSubject()
                    .contains(applicantHQM.firstName + ", here are your Farmers Insurance\u00ae Home quote details")) {
                fsa.assertEquals(message.getFromfull(), "email@em.farmers.com", "Email 'From' is verified.");
                String msgBody = message.getParts().get(0).getBody();
//                System.out.println("**********");
//                System.out.println(msgBody);
//                System.out.println("**********");
                fsa.assertTrue(msgBody.contains("YOUR PERSONALIZED COVERAGE AWAITS"), "Personalized Coverage text is available.");
                fsa.assertTrue(msgBody.contains("Quote " + applicantHQM.quoteNumber), "Quote number is available.");
                fsa.assertTrue(msgBody.contains("Hi " + applicantHQM.firstName + ","), "Hi firstName is available.");
                fsa.assertTrue(msgBody.contains("Thank you for choosing Farmers Insurance"), "Thank you text is available.");
                fsa.assertTrue(msgBody.contains("for your Home quote."), "for your Home quote text is available.");
                fsa.assertTrue(msgBody.contains("To retrieve your online quote, click below:"), "Text to retrieve quote is available.");
                fsa.assertTrue(msgBody.contains("RETRIEVE QUOTE"), "RETRIEVE QUOTE button text is available.");
                String startText = eeState ? START_TEXT_EE : START_TEXT;
                startText += " If you have any questions in the meantime, give us a call at";
                fsa.assertTrue(msgBody.contains(startText), "Text to 1-800-FARMERS number is available.");
                fsa.assertTrue(msgBody.contains("1-800-FARMERS"), "1-800-FARMERS text is available.");
                if (!eeState) {
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_1), "Disclaimer text 1 is available.");
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_2A), "Disclaimer text 2 (part 1) is available.");
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_2B), "Disclaimer text 2 (part 2) is available.");
                } else {
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_EE_1A), "Disclaimer 1 (EE states, part 1) text is available.");
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_EE_1B), "Disclaimer 1 (EE states, part 2) text is available.");
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_2A), "Disclaimer 2 (EE states, part 1) text is available.");
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_2B), "Disclaimer 2 (EE states, part 2) text is available.");
                }
                counter++;
            }
        }
        fsa.assertEquals(counter, 1, "Found exactly 1 Thank you email.");
        fsa.assertAll("Thank You email verified.");
    }

    public static void validateHqmEmailToCustomer(ApplicantHQM applicantHQM, boolean eeState,
                                                  List<Message> messages, @Nullable List<String> quotes) {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        // Check if Email To Customer email is received
        List<String> quotePremiums = new ArrayList<>(Collections.singleton(applicantHQM.quoteRate));
        if (quotes != null) {
            quotePremiums.addAll(quotes);
        }
        Log.info("Expected quotes monthly premiums:: " + quotePremiums);
        for (Message message : messages) {
            if (message.getSubject()
                    .contains("Your Farmers Insurance\u00ae Home quote")) {
                fsa.assertEquals(message.getFromfull(), "email@em.farmers.com", "Email 'From' is verified.");
                String msgBody = message.getParts().get(0).getBody();
                fsa.assertTrue(msgBody.contains("YOUR PERSONALIZED COVERAGE AWAITS"), "Personalized Coverage text is available.");
                fsa.assertTrue(msgBody.contains("Quote " + applicantHQM.quoteNumber), "Quote number is available.");
                fsa.assertTrue(msgBody.contains("Hi " + applicantHQM.firstName + ","), "Hi firstName is available.");
                fsa.assertTrue(msgBody.contains("Thank you for quoting with Farmers Insurance"), "Thank you text is available.");
                fsa.assertTrue(msgBody.contains("Below is the summary of your online Home quote."), "Below is the summary text is available.");
                fsa.assertTrue(msgBody.contains("Please refer to your Quote Number to purchase your policy with one of our friendly Farmers"),
                        "Please refer to your Quote Number to purchase your policy text is available.");
                fsa.assertTrue(msgBody.contains("Quote: " + applicantHQM.quoteNumber), "Quote number text is available.");
                fsa.assertTrue(msgBody.toUpperCase().contains("ADDRESS: " + applicantHQM.addressApt), "Address text is available.");
                for (String quoteVal : quotePremiums) {
                    if (msgBody.contains("Monthly Premium : " + quoteVal)) {
                        Log.info("Found Email To Customer with Monthly Premium: " + quoteVal);
                        quotePremiums.remove(quoteVal);
                        break;
                    }
                }
                fsa.assertTrue(msgBody.contains("RETRIEVE QUOTE"), "RETRIEVE QUOTE button text is available.");
                String startText = eeState ? START_TEXT_EE.replace("representative", "representatives")
                        : START_TEXT;
                startText += " If you have any questions in the meantime, give us a call at";
                fsa.assertTrue(msgBody.contains(startText), "Text to 1-800-FARMERS number is available.");
                fsa.assertTrue(msgBody.contains("1-800-FARMERS"), "1-800-FARMERS text is available.");
                if (!eeState) {
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_1), "Disclaimer text 1 is available.");
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_2A), "Disclaimer text 2 (part 1) is available.");
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_2B), "Disclaimer text 2 (part 2) is available.");

                } else {
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_EE_1A), "Disclaimer 1 (EE states, part 1) text is available.");
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_EE_1B), "Disclaimer 1 (EE states, part 2) text is available.");
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_2A), "Disclaimer 2 (EE states, part 1) text is available.");
                    fsa.assertTrue(msgBody.contains(DISCLAIMER_2B), "Disclaimer 2 (EE states, part 2) text is available.");
                }
            }
        }
        fsa.assertEquals(quotePremiums.size(), 0, "Found All Email to Customer.");
        fsa.assertAll("Email to Customer is verified.");
    }

    public static void validateHqmQuickenWelcomeEmail(ApplicantHQM applicantHQM, List<Message> messages) {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        // Check if Thank you for choosing Farmers email for Quicken customer is received
        int counter = 0;
        for (Message message : messages) {
            if (message.getSubject()
                    .contains("Thank You For Choosing Farmers\u00ae")) {
                fsa.assertEquals(message.getFromfull(), "email@em.farmers.com", "Email 'From' is verified.");
                String msgBody = message.getParts().get(0).getBody();
                fsa.assertTrue(msgBody.contains("WE\u2019RE HERE TO HELP"), "We're Here To Help text is available.");
                fsa.assertTrue(msgBody.contains("Hi " + applicantHQM.firstName + ","), "Hi firstName is available.");
                fsa.assertTrue(msgBody.contains("We know you have options for homeowners insurance and we are happy you chose Farmers"),
                        "We know you have options text is available.");
                fsa.assertTrue(msgBody.contains("A Farmers representative will be in contact with you shortly."),
                        "A Farmers representative will be in contact text is available.");
                fsa.assertTrue(msgBody.contains("If you have questions along the way, please call <b>(800) 491-9927</b> " +
                        "to speak with a live representative."), "Phone number to call Farmers, regarding Quicken quote is available.");
                fsa.assertTrue(msgBody.contains(DISCLAIMER_QUICKEN_1), "Disclaimer text 1 (Quicken) is available.");
                fsa.assertTrue(msgBody.contains(DISCLAIMER_QUICKEN_2), "Disclaimer text 2 (Quicken) is available.");
                counter++;
            }
        }
        fsa.assertEquals(counter, 1, "Found exactly 1 Quicken Welcome email.");
        fsa.assertAll("Quicken Welcome email verified.");
    }

    public static void validateHqmAlertAgentEmail(ApplicantHQM applicantHQM, Boolean eeState, List<Message> messages) {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        // Check if Alert Agent email is received
        int counter = 0;
        for (Message message : messages) {
            if (message.getSubject().contains("Alert: New online Home quote " + applicantHQM.quoteNumber + " is available")) {
                String emailFrom = eeState ? "email@em.farmers.com" : "email@mail.farmers.com";
                fsa.assertEquals(message.getFromfull(), emailFrom, "Email 'From' is verified.");
                String msgBody = message.getParts().get(0).getBody();
                String emailStartText = eeState ?
                        "A new online Home quote request " + applicantHQM.quoteNumber + " from " +
                                applicantHQM.firstName + "  " + applicantHQM.lastName +
                                " is available." :
                        "A new online Home quote request is available in your queue";
                fsa.assertTrue(msgBody.contains(emailStartText), "New online Home quote text is available.");
                if (!eeState) {
                    fsa.assertTrue(msgBody.contains("ACCESS THE LEAD"), "Access the lead text is available.");
                    fsa.assertTrue(msgBody.contains("To access online quotes manually:"), "To access quotes manually text is available.");
                    fsa.assertTrue(msgBody.contains("Log on to Agency Dashboard."), "Logon to Agency Dashboard text is available.");
                    fsa.assertTrue(msgBody.contains("Proceed to APEX."), "Proceed to APEX text is available.");
                    fsa.assertTrue(msgBody.contains("Select the \u201cLead Depot\u201d tab."), "Select the Lead Depot text is available.");
                    fsa.assertTrue(msgBody.contains("You will land on the \u201cAssigned FFQ\u201d tab."), "You will land on text is available.");
                } else {
                    fsa.assertTrue(msgBody.contains("Online prospects have a much better chance of converting if you respond to their inquiry promptly."),
                            "Respond to the inquiry promptly text is available.");
                    fsa.assertTrue(msgBody.contains("Quote Number: " + applicantHQM.quoteNumber), "Quote Number text is available.");
                    fsa.assertTrue(msgBody.contains("Customer Name: " + applicantHQM.firstName + "&nbsp;" + applicantHQM.lastName), "Customer Name text is available.");
                    fsa.assertTrue(msgBody.contains("Customer Zip: " + applicantHQM.zipCode), "Customer Zip text is available.");
                }
                counter++;
            }
        }
        fsa.assertEquals(counter, 1, "Found exactly 1 Alert Agent email.");
        fsa.assertAll("Alert Agent email verified.");
    }

    public static void validateHqmEmails(ApplicantHQM applicantHQM, @Nullable List<String> quotePremiums, boolean bQuicken) throws Exception {
        int secondsAgo = 400;
        String userEmail = applicantHQM.emailAddress.split("@")[0];
        Log.info("Email Address User Name => " + userEmail);

        BasePage basePage = new BasePage();
        Boolean stateEE = basePage.isEasternExpansionState(applicantHQM.stateCode);

        if (!bQuicken) {
            // 'Thank You' email validation
            String subject = applicantHQM.firstName + ", here are your Farmers Insurance\u00ae Home quote details";
            List<Message> messages = retrieveEmail(userEmail, subject, secondsAgo);
            validateHqmThankYouEmail(applicantHQM, stateEE, messages);
        } else {
            // 'Quicken Welcome' email validation
            String subject = "Thank You For Choosing Farmers\u00ae";
            secondsAgo = 600;
            List<Message> messages = retrieveEmail(userEmail, subject, secondsAgo);
            validateHqmQuickenWelcomeEmail(applicantHQM, messages);
        }

        // 'Email To Customer' validation
        String subject = "Your Farmers Insurance\u00ae Home quote";
        List<Message> messages = retrieveEmail(userEmail, subject, secondsAgo);
        validateHqmEmailToCustomer(applicantHQM, stateEE, messages, quotePremiums);

        // US465457: Suppress assigned agent emails for Home (Legacy and HQM)
        /*
        if ((!applicantHQM.agentId.isEmpty() || stateEE) && !bQuicken) {
            // If this is AWS agent or EE state quote, validate 'Alert Agent' email. (not Quicken (Rocket Mortgage)
            subject = "Alert: New online Home quote " + quoteNumber + " is available";
            messages = retrieveEmail(userEmail, subject, secondsAgo);
            validateHqmAlertAgentEmail(applicantHQM, quoteNumber, stateEE, messages);
        }
        */
    }

    public void validateAceRatedEmail(AutoApplicant applicant, FarmersSoftAssert fsa, String quoteNumber, String expectedPremiumAmount) throws Exception {
        int secondsAgo = 400;
        String userEmail = applicant.getEmail().split("@")[0];
        Log.info("Email Address User Name => " + userEmail);
        String expectedSubject = applicant.getFirstName() + ", here are your Farmers Insurance\u00ae auto quotes";
        String expectedContentHeader1 = applicant.getFirstName() + ", your auto insurance quote is ready for purchase!";
        String expectedContentHeader2 = "Your auto insurance quote is ready for purchase!";
        List<Message> messages = retrieveEmail(userEmail, expectedSubject, secondsAgo);
        for (Message message : messages) {
            fsa.assertTrue(message.getFromfull().contains("farmers.com"));
            fsa.assertEquals(message.getSubject().strip(), expectedSubject, "Email subject line check");
            String body = message.getParts().stream().findFirst().get().getBody();
            fsa.assertTrue(body.contains(expectedContentHeader1) || body.contains(expectedContentHeader2), "Email body header check");
            fsa.assertTrue(body.contains(quoteNumber), "Email contains quote number check. Quote number: " + quoteNumber);
            fsa.assertTrue(body.contains(expectedPremiumAmount.replace(",", EMPTY_STRING)), "Email contains the expected premium amount: " + expectedPremiumAmount);

            Map<String, String> clickableLinks = retrieveClickableLinksFromMessage(userEmail, expectedSubject, secondsAgo);
            Log.info("Clickable links found in email: " + clickableLinks);
//TODO: Currently the email does not contain the link
//            String finalizeMyCoverageLink = clickableLinks.get("Finalize my coverage");
//            Assert.assertNotNull(finalizeMyCoverageLink, "'Finalize my coverage' link was not found in the email");
//            Log.info("Navigating to 'Finalize my coverage' link: " + finalizeMyCoverageLink);
//            driver().get(finalizeMyCoverageLink);
//            QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
//            SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
//            if (quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
//                quoteSummaryAutoPage.isSnackBarMessageDisplayed(String.format("Welcome back %s", applicant.getFirstName()));
//            } else if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
//                selectAQuoteToReviewPage.clickContinueMyQuote();
//                quoteSummaryAutoPage.isSnackBarMessageDisplayed(String.format("Welcome back %s", applicant.getFirstName()));
//            }
        }
    }

    public void validateAceNotRatedEmail(AutoApplicant applicant, FarmersSoftAssert fsa, String quoteNumber) throws Exception {
        int secondsAgo = 400;
        String userEmail = applicant.getEmail().split("@")[0];
        Log.info("Email Address User Name => " + userEmail);
        String expectedSubject = "You're almost done with your quote";
        String yourQuoteNumber = "Your quote number is";
        List<Message> messages = retrieveEmail(userEmail, expectedSubject, secondsAgo);
        Message message = messages.stream().findFirst().get();
        fsa.assertEquals(message.getSubject().strip(), expectedSubject, "Email subject line check");
        fsa.assertTrue(message.getFromfull().contains("farmers.com"), "Email message contains farmers.com in from address");
        String body = message.getParts().stream().findFirst().get().getBody();
        fsa.assertTrue(body.contains(yourQuoteNumber) && body.contains(quoteNumber), "Email contains the expected body header");
        fsa.assertTrue(body.contains(quoteNumber), "Email contains the quote number");

        Map<String, String> clickableLinks = retrieveClickableLinksFromMessage(userEmail, expectedSubject, secondsAgo);
        Log.info("Clickable links found in email: " + clickableLinks);

        //TODO: Finish my quote link is not present in the email, so commenting out the below code for now. Once the link is added to the email, we can uncomment this code and validate the link.
        /*String finishMyQuoteLink = clickableLinks.get("Finish my quote");
        Assert.assertNotNull(finishMyQuoteLink, "'Finish my quote' link was not found in the email");
        Log.info("Navigating to 'Finish my quote' link: " + finishMyQuoteLink);
        driver().get(finishMyQuoteLink);*/

        // Instead of above, retrieving the code from landing page
        new LandingPage().retrieveQuoteFromLandingPage(applicant, quoteNumber);

        waitForSpinnerToBeGone();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        fsa.assertTrue(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User expected to land on Who Should We Insure page");
        fsa.assertEquals(whoShouldWeInsurePage.getTitle(), "Welcome back " + applicant.getFirstName() + "!", "Email link should navigate user to Who Should We Insure page with correct title");
        boolean isStreamlineState = isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        if (!isStreamlineState) {
            fsa.assertEquals(whoShouldWeInsurePage.getSubTitle(), "Please review your information so we can get you that quote", "Email link should navigate user to Who Should We Insure page with correct subtitle");
            whoShouldWeInsurePage.clickOnContinueButton();
        } else {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.validatePageDescription(fsa);
            vehiclesDriversInfoPage.clickContinueButton();
        }
        if (!isStreamlineState) {
            VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
            vehicleReviewPage.isOnVehiclesReviewPage();
            vehicleReviewPage.clickContinueButton();
            DriverReviewPage driverReviewPage = new DriverReviewPage();
            driverReviewPage.isOnDriverReviewPage();
            driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
            driverReviewPage.clickContinueButton();
        }

        if (!isSignalDiscountDisabledState(applicant.getStateCode())) {
            SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
            signalPageOneUI.isOnSignalPage();
            signalPageOneUI.processSignalPage(RandomUtils.nextBoolean());
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.enterPhoneNumber(applicant.getPhoneNumber());
        contactInfoAutoPage.fillOutPrimaryResidenceInsuranceSection(applicant.getStateCode().equals(MA));
        fsa.assertTrue(getAttributeData(contactInfoAutoPage.getEmailAddressInput(), "aria-invalid").equals(LOWERCASE_FALSE), "Email should be prefilled");
        contactInfoAutoPage.clickContactInfoPageCTAButton();
        waitForSpinnerToBeGone();
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        if (!quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
            if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
                if (applicant.getStateCode().equals(VA)) {
                    vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
                } else {
                    vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
                }
            }
            if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
                continueWithBristolWestPage.continueWithBwPopUp();
                BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
                if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                    bristolWestAdditionalDiscountsPage.clickContinue();
                }
            }
            SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
            if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
                selectAQuoteToReviewPage.clickContinueMyQuote();
            }

        } else {
            fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User expected to reach the quote summary page");

        }

    }

    private static List<Message> retrieveEmail(String userEmail, String subject, @Nullable Integer secondsAgo) {

        MailinatorClient mailinatorClient = new MailinatorClient("b997e325d1fe47bc97fc017771e1a4d3");

        // Let's check that the email is received by polling inbox of the account holder
        long timeToWait = 300;
        // secondsAgo must account for the full polling window (timeToWait) plus the original threshold,
        // otherwise emails that arrived early in the poll cycle get filtered out by the time the final
        // check runs (secondsAgo grows every second the message sits in the inbox).
        Integer finalSecondsAgo = (secondsAgo == null) ? 400 : secondsAgo + (int) timeToWait;

        with().pollInterval(10, SECONDS).then().await().atMost(timeToWait, SECONDS).untilAsserted(() -> {

            List<Message> messages = mailinatorClient.request(GetInboxRequest.builder()
                    .domain(MAILINATOR_FARMERS_PRIVATE_DOMAIN)
                    .inbox(userEmail)
                    .sort(Sort.DESC)
                    .limit(10)   // increased from 5 to avoid missing the target email in busy inboxes
                    .build()).getMsgs();

            Log.info("Subject => " + subject);
            Log.info("Messages count => " + messages.size());

            Assert.assertTrue(messages.stream()
                            .filter(seconds -> (seconds.getSecondsAgo() < finalSecondsAgo))
                            .anyMatch(i -> i.getSubject().contains(subject)),
                    "FFQ email with subject: [" + subject + "] was not found within <" + timeToWait + "> seconds.");
        });

        List<Message> messages = mailinatorClient.request(GetInboxRequest.builder()
                .domain(MAILINATOR_FARMERS_PRIVATE_DOMAIN)
                .inbox(userEmail)
                .sort(Sort.DESC)
                .limit(10)   // increased from 5 to avoid missing the target email in busy inboxes
                .build()).getMsgs();

        List<String> messageIds = messages.stream()
                .filter(i -> i.getSubject().contains(subject))
                .filter(seconds -> (seconds.getSecondsAgo() < finalSecondsAgo))
                .map(Message::getId)
                .collect(Collectors.toList());
        Log.info("inboxMessageIds => " + messageIds);

        List<Message> messageBodyList = messageIds.stream()
                .map(msgId -> mailinatorClient.request(new GetMessageRequest(
                        MAILINATOR_FARMERS_PRIVATE_DOMAIN, userEmail, msgId)))
                .collect(Collectors.toList());

        Log.info("inboxMessageBody => " + messageBodyList.size());
        return messageBodyList;
    }

    /**
     * Parses all hyperlinks with their display text from a matched email's HTML body.
     * Returns a map of { display text → URL } preserving insertion order.
     * Links with empty text are stored under an auto-generated key "link_1", "link_2", etc.
     *
     * @param userEmail  the inbox name (part before '@')
     * @param subject    the subject to match
     * @param secondsAgo only consider messages received within this many seconds ago
     * @return ordered map of link text → URL
     */
    public static Map<String, String> retrieveClickableLinksFromMessage(String userEmail, String subject, int secondsAgo) {
        List<Message> messages = retrieveEmail(userEmail, subject, secondsAgo);
        Map<String, String> linksMap = new LinkedHashMap<>();

        if (messages.isEmpty() || messages.get(0).getParts() == null || messages.get(0).getParts().isEmpty()) {
            Log.info("No message or parts found for subject: [" + subject + "]");
            return linksMap;
        }

        String body = messages.get(0).getParts().get(0).getBody();

        // Match: <a ... href="URL" ...>TEXT</a>  (handles multi-attribute tags)
        Pattern pattern = Pattern.compile(
                "<a[^>]+href=\"([^\"]+)\"[^>]*>\\s*([^<]*?)\\s*</a>",
                Pattern.CASE_INSENSITIVE | Pattern.DOTALL
        );
        Matcher matcher = pattern.matcher(body);
        int unnamedCount = 0;
        while (matcher.find()) {
            String url = matcher.group(1).trim();
            String text = matcher.group(2).trim();
            if (text.isEmpty()) {
                unnamedCount++;
                text = "link_" + unnamedCount;
            }
            linksMap.put(text, url);
            Log.info("Found clickable link: [" + text + "] -> " + url);
        }
        return linksMap;
    }

    /**
     * Fetches all hyperlinks (URL only) from a specific message in a Mailinator inbox.
     *
     * @param userEmail  the inbox name (part before '@' in the email address)
     * @param subject    the subject to match when locating the message
     * @param secondsAgo only consider messages received within this many seconds ago
     * @return list of URLs extracted from the matched message, or empty list if none found
     */
    public static List<String> retrieveLinksFromMessage(String userEmail, String subject, int secondsAgo) {
        MailinatorClient mailinatorClient = new MailinatorClient("b997e325d1fe47bc97fc017771e1a4d3");

        List<Message> messages = mailinatorClient.request(GetInboxRequest.builder()
                .domain(MAILINATOR_FARMERS_PRIVATE_DOMAIN)
                .inbox(userEmail)
                .sort(Sort.DESC)
                .limit(10)
                .build()).getMsgs();

        Optional<Message> targetMessage = messages.stream()
                .filter(m -> m.getSubject().contains(subject))
                .filter(m -> m.getSecondsAgo() < secondsAgo)
                .findFirst();

        if (!targetMessage.isPresent()) {
            Log.info("No message found matching subject: [" + subject + "] within " + secondsAgo + " secondsAgo");
            return new ArrayList<>();
        }

        String messageId = targetMessage.get().getId();
        Log.info("Fetching links for messageId: " + messageId);

        Links links = mailinatorClient.request(new GetLinksRequest(MAILINATOR_FARMERS_PRIVATE_DOMAIN, userEmail, messageId));
        List<String> linkList = links.getLinks();
        Log.info("Links found in message: " + linkList);
        return linkList != null ? linkList : new ArrayList<>();
    }

}
