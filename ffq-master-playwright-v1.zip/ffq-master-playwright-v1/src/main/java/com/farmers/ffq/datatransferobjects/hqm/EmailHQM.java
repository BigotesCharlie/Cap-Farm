package com.farmers.ffq.datatransferobjects.hqm;

import java.util.ArrayList;
import java.util.List;

public class EmailHQM {
    private String templateName;
    private String isSynchronousRequest;
    private String uniqueId;
    private String recipientContactPoint;
    private final List<DynamicProperties> dynamicProperties = new ArrayList<>();

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getIsSynchronousRequest() {
        return isSynchronousRequest;
    }

    public void setIsSynchronousRequest(String isSynchronousRequest) {
        this.isSynchronousRequest = isSynchronousRequest;
    }

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getRecipientContactPoint() {
        return recipientContactPoint;
    }

    public void setRecipientContactPoint(String recipientContactPoint) {
        this.recipientContactPoint = recipientContactPoint;
    }

    public List<EmailHQM.DynamicProperties> getDynamicProperties() {
        return dynamicProperties;
    }

    public String getDynamicPropertyByName(String name) {
        String propValue = null;
        for (DynamicProperties prop: dynamicProperties) {
            if (prop.getName().equals(name)) {
                propValue = prop.getValue();
                break;
            }
        }
        return propValue;
    }

    public static class DynamicProperties {
        private String name;
        private String value;

        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }
        public String getValue() {
            return value;
        }
        public void setValue(String value) {
            this.value = value;
        }
    }

}
