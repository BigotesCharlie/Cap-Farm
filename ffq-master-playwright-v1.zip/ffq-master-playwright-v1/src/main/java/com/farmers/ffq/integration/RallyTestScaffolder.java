package com.farmers.ffq.integration;

import java.util.List;
import java.util.Locale;

/**
 * Standalone utility that queries Rally for a test case by ID and prints a
 * fully-structured Java test method skeleton — ready to paste into any test class.
 *
 * <h3>Run via Gradle</h3>
 * <pre>
 *   ./gradlew scaffoldTest -DtcId=TC2176453
 * </pre>
 *
 * <h3>Run directly (main method)</h3>
 * <pre>
 *   RallyTestScaffolder.main(new String[]{"TC2176453"});
 * </pre>
 *
 * <p>Requires {@code rally.enabled=true} and a valid {@code rally.apiKey}
 * in {@code properties.json} (or passed via {@code -Drally.*} system properties).
 *
 * <h3>Example output for TC2176453</h3>
 * <pre>
 *   &#64;RallyTestCase(ids = {"TC2176453"}, description = "Verify that error messages…")
 *   &#64;Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
 *         testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
 *         dataProviderClass = AutoDataProviders.class,
 *         groups = { /* TODO: add groups *&#47; })
 *   public void testVerifyThatErrorMessagesAreDisplayed(AutoApplicant applicant) throws Exception {
 *       // TC2176453 – Verify that error messages are displayed …
 *       //
 *       // Step 1: &lt;input&gt;
 *       //   Expected: &lt;expectedResult&gt;
 *       //
 *       // TODO: implement test body
 *       FarmersSoftAssert fsa = new FarmersSoftAssert();
 *       // fsa.assertTrue( … );
 *       fsa.assertAll();
 *   }
 * </pre>
 */
public final class RallyTestScaffolder {

    private RallyTestScaffolder() {}

    // ── Entry point ───────────────────────────────────────────────────────────

    /**
     * Main entry point.  Pass one or more TC IDs as arguments, e.g.:
     * <pre>TC2176453 TC2176454</pre>
     */
    public static void main(String[] args) {
        // Support -DtcId=... (used by the Gradle scaffoldTest task)
        String sysTcId = System.getProperty("tcId", "").trim();
        if (!sysTcId.isEmpty() && args.length == 0) {
            args = sysTcId.split("[,\\s]+");
        }

        if (args.length == 0) {
            System.err.println("Usage: RallyTestScaffolder <TC_ID> [TC_ID ...]");
            System.err.println("  or:  ./gradlew scaffoldTest -DtcId=TC2176453");
            System.exit(1);
        }

        RallyService rally = RallyService.getInstance();

        for (String tcId : args) {
            tcId = tcId.trim();
            if (tcId.isEmpty()) continue;

            System.out.println("\n" + "=".repeat(70));
            System.out.println(" Scaffolding test for " + tcId);
            System.out.println("=".repeat(70));

            RallyTestCaseInfo info = rally.getTestCaseDetails(tcId);
            if (info == null) {
                System.err.println("[ERROR] Could not retrieve TC '" + tcId
                        + "' from Rally. Check rally.enabled / rally.apiKey.");
                continue;
            }

            System.out.println(generate(info));
        }
    }

    // ── Code generator ────────────────────────────────────────────────────────

    /**
     * Generates a Java test method skeleton from {@code info} and returns it
     * as a formatted {@code String} ready to paste into a test class.
     */
    public static String generate(RallyTestCaseInfo info) {
        StringBuilder sb = new StringBuilder();

        String methodName = toMethodName(info.getName());
        String desc       = sanitiseInlineString(info.getDescription());

        // ── Javadoc ──────────────────────────────────────────────────────────
        sb.append("    /**\n");
        sb.append("     * ").append(wrap(info.getName(), 70, "     * ")).append("\n");
        if (!info.getDescription().isEmpty()) {
            sb.append("     *\n");
            sb.append("     * <p>").append(wrap(info.getDescription(), 66, "     * ")).append("\n");
        }
        sb.append("     *\n");
        sb.append("     * <p>Rally: ").append(info.getFormattedId());
        if (!info.getMethod().isEmpty())  sb.append(" | Method: ").append(info.getMethod());
        if (!info.getPriority().isEmpty()) sb.append(" | Priority: ").append(info.getPriority());
        sb.append("\n     */\n");

        // ── @RallyTestCase ───────────────────────────────────────────────────
        sb.append("    @RallyTestCase(ids = {\"").append(info.getFormattedId()).append("\"}, ");
        sb.append("description = \"").append(desc).append("\")\n");

        // ── @Test ────────────────────────────────────────────────────────────
        sb.append("    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,\n");
        sb.append("            testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,\n");
        sb.append("            dataProviderClass = AutoDataProviders.class,\n");
        sb.append("            groups = { /* TODO: add groups e.g. NAME_AND_DOB_ONEUI, FFQ_ONEUI */ },\n");
        sb.append("            attributes = {@CustomAttribute(name = FILTER, values = \"applicantId=1\")})\n");

        // ── Method signature ─────────────────────────────────────────────────
        sb.append("    public void ").append(methodName).append("(AutoApplicant applicant) throws Exception {\n");

        // ── TC header comment ────────────────────────────────────────────────
        sb.append("        // ── ").append(info.getFormattedId()).append(": ")
          .append(info.getName()).append(" ──\n");

        // ── Test steps ───────────────────────────────────────────────────────
        List<RallyTestCaseInfo.TestStep> steps = info.getSteps();
        if (!steps.isEmpty()) {
            sb.append("        //\n");
            for (RallyTestCaseInfo.TestStep step : steps) {
                sb.append("        // Step ").append(step.getIndex()).append(": ");
                if (!step.getInput().isEmpty()) {
                    sb.append(wrap(stripHtml(step.getInput()), 60, "        //   ")).append("\n");
                } else {
                    sb.append("(no input)\n");
                }
                if (!step.getExpectedResult().isEmpty()) {
                    sb.append("        //   Expected: ");
                    sb.append(wrap(stripHtml(step.getExpectedResult()), 57, "        //             ")).append("\n");
                }
                sb.append("        //\n");
            }
        }

        // ── Navigation placeholder ────────────────────────────────────────────
        sb.append("\n");
        sb.append("        // TODO: navigate to the page under test\n");
        sb.append("        // Example: NameAndDobPage page = new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);\n");
        sb.append("\n");

        // ── Assertions ────────────────────────────────────────────────────────
        sb.append("        FarmersSoftAssert fsa = new FarmersSoftAssert();\n");
        sb.append("        // TODO: add assertions\n");
        sb.append("        // fsa.assertTrue( /* your condition */ , \"assertion description\");\n");
        sb.append("        fsa.assertAll();\n");
        sb.append("    }");

        return sb.toString();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * Converts a Rally TC name to a valid Java method name.
     *
     * <p>Example: {@code "Verify error messages for char limits"} →
     * {@code "testVerifyErrorMessagesForCharLimits"}
     */
    static String toMethodName(String name) {
        if (name == null || name.isBlank()) return "testTodoImplement";

        // Strip HTML tags, special chars, keep only alphanumeric + spaces
        String clean = stripHtml(name).replaceAll("[^a-zA-Z0-9 ]", " ").trim();

        String[] words = clean.split("\\s+");
        StringBuilder sb = new StringBuilder("test");
        for (String w : words) {
            if (w.isEmpty()) continue;
            sb.append(Character.toUpperCase(w.charAt(0)));
            if (w.length() > 1) sb.append(w.substring(1).toLowerCase(Locale.ROOT));
        }
        // Truncate at 60 chars to stay readable
        return sb.length() > 60 ? sb.substring(0, 60) : sb.toString();
    }

    /** Strips HTML tags from a string. */
    private static String stripHtml(String s) {
        if (s == null) return "";
        return s.replaceAll("<[^>]+>", " ").replaceAll("\\s+", " ").trim();
    }

    /** Sanitises a string for use inside a Java string literal (escapes quotes, removes newlines). */
    private static String sanitiseInlineString(String s) {
        if (s == null) return "";
        return stripHtml(s)
                .replace("\\", "\\\\")
                .replace("\"", "'")
                .replaceAll("[\\r\\n]+", " ")
                .trim();
    }

    /** Soft-wraps {@code text} at {@code width} characters, indenting continuation lines. */
    private static String wrap(String text, int width, String indent) {
        text = stripHtml(text);
        if (text.length() <= width) return text;
        StringBuilder out = new StringBuilder();
        while (text.length() > width) {
            int cut = text.lastIndexOf(' ', width);
            if (cut <= 0) cut = width;
            if (out.length() > 0) out.append("\n").append(indent);
            out.append(text, 0, cut).append("\n").append(indent);
            text = text.substring(cut).trim();
        }
        if (!text.isEmpty()) {
            if (out.length() > 0) out.append(text);
            else out.append(text);
        }
        return out.toString();
    }
}

