package com.farmers.ffq.datatransferobjects;

import lombok.Data;
import net.datafaker.Faker;

import static com.farmers.ffq.utils.GlobalVariables.EMPTY_STRING;
import static com.farmers.ffq.utils.GlobalVariables.SPACE;

import java.util.Random;

import static com.farmers.ffq.utils.GlobalVariables.NEWLINE;

@Data
public class ApplicantAllLOB {
	private SqlApplicant autoApplicant;
	private ApplicantCondo condoApplicant;
	private ApplicantRenters rentersApplicant;
	private ApplicantLife lifeApplicant;
	private ApplicantBusiness businessApplicant;
	private static final Random randomNumberGenerator = new Random();

	/**
	 * String Representation of class.
	 */
	public String toString() {
		StringBuilder applicantInfo = new StringBuilder("Cross sell applicant: ");
		if (autoApplicant != null) {
			applicantInfo.append(autoApplicant.getFirstName() + SPACE + autoApplicant.getLastName() + SPACE + autoApplicant.getResidentAddress1() + SPACE + autoApplicant.getCity() + SPACE + autoApplicant.getStateName() + SPACE + autoApplicant.getZipCode()) ;			
		}		
		return applicantInfo.toString();
	}
	
	public String applicantInfo() {
		StringBuilder applicantInfo = new StringBuilder();
		if (autoApplicant != null) {
			applicantInfo.append("Auto applicant Info: " +
					autoApplicant.getFirstName() + SPACE + autoApplicant.getLastName() + SPACE + autoApplicant.getResidentAddress1() + SPACE + autoApplicant.getCity() + SPACE + autoApplicant.getStateName() + SPACE + autoApplicant.getZipCode()) ;
		}
		if (condoApplicant != null) {
			applicantInfo.append("Condo applicant Info: " + condoApplicant + NEWLINE);
		}
		if (rentersApplicant != null) {
			applicantInfo.append("Renters applicant Info: " + rentersApplicant + NEWLINE);
		}
		if (lifeApplicant != null) {
			applicantInfo.append("Life applicant Info: " + lifeApplicant + NEWLINE);
		}
		if (businessApplicant != null) {
			applicantInfo.append("Business applicant Info: " + businessApplicant + NEWLINE);
		}
		return applicantInfo.toString();
	}

	public void normalizeData() {
		// Determine which address to use
		int useAddressFromLOB = randomNumberGenerator.nextInt(5);
		switch (useAddressFromLOB) {
		case 1 :
			if (condoApplicant != null) {
				autoApplicant.setResidentAddress1(condoApplicant.getAddressApt());
				autoApplicant.setCity(condoApplicant.getCity());
				autoApplicant.setZipCode(condoApplicant.getZipCode());
			}		
			break;
		case 2: 
			if (rentersApplicant != null) {
				autoApplicant.setResidentAddress1(rentersApplicant.getAddressApt());
				autoApplicant.setCity(rentersApplicant.getCity());
				autoApplicant.setZipCode(rentersApplicant.getZipCode());
			}		
			break;
		case 3:
			if (lifeApplicant != null) {
				autoApplicant.setResidentAddress1(lifeApplicant.getAddress());
				autoApplicant.setCity(lifeApplicant.getCity());
				autoApplicant.setZipCode(lifeApplicant.getZipCode());
			}		
			break;
		case 4:
			if (businessApplicant != null) {
				autoApplicant.setResidentAddress1(businessApplicant.getAddress1());
				autoApplicant.setCity(businessApplicant.getCity());
				autoApplicant.setZipCode(businessApplicant.getZipCode());
			}		
			break;
		case 0: default: // Use Auto, nothing to do
			break;
		}
		// Use data in Auto as primary
	        Faker faker = new Faker();
		autoApplicant.setFirstName(faker.name().firstName());
		autoApplicant.setLastName(faker.name().lastName());
		String spouseFirstName = EMPTY_STRING;
		String spouseLastName = EMPTY_STRING;
		String spouseGender = EMPTY_STRING;
		int spouseAge = 0;
		if (!autoApplicant.getAdditionalDrivers().isEmpty()) {
			spouseFirstName = autoApplicant.getAdditionalDrivers().get(0).getFirstName();
			spouseLastName = autoApplicant.getAdditionalDrivers().get(0).getLastName();
			spouseGender = autoApplicant.getAdditionalDrivers().get(0).getGender();
			spouseAge = autoApplicant.getAdditionalDrivers().get(0).getAge();
		}
		// Condo data
		if (condoApplicant != null) {
			condoApplicant.setFirstName(autoApplicant.getFirstName());
			condoApplicant.setLastName(autoApplicant.getLastName());
			condoApplicant.setAge(autoApplicant.getAge());
			condoApplicant.setMaritalStatus(autoApplicant.getMaritalStatus());
			condoApplicant.setGender(autoApplicant.getGender());
			condoApplicant.setSpouseFirstName(spouseFirstName);
			condoApplicant.setSpouseLastName(spouseLastName);
			condoApplicant.setSpouseAge(spouseAge);
			condoApplicant.setSpouseGender(spouseGender);
			condoApplicant.setAddressApt(autoApplicant.getResidentAddress1()) ;
			condoApplicant.setCity(autoApplicant.getCity());
			condoApplicant.setStateCode(autoApplicant.getStateCode());
			condoApplicant.setState(autoApplicant.getStateName());
			condoApplicant.setZipCode(autoApplicant.getZipCode());
			condoApplicant.setPhoneNumber(autoApplicant.getPhoneNumber());
			condoApplicant.setEmailAddress(autoApplicant.getEmail());
			setCondoApplicant(condoApplicant);
		}

		// Renters data
		if (rentersApplicant != null) {
			rentersApplicant.setFirstName(autoApplicant.getFirstName());
			rentersApplicant.setLastName(autoApplicant.getLastName());
			rentersApplicant.setAge(autoApplicant.getAge());
			rentersApplicant.setMaritalStatus(autoApplicant.getMaritalStatus());
			rentersApplicant.setGender(autoApplicant.getGender());
			rentersApplicant.setSpouseFirstName(spouseFirstName);
			rentersApplicant.setSpouseLastName(spouseLastName);
			rentersApplicant.setSpouseAge(spouseAge);
			rentersApplicant.setSpouseGender(spouseGender);
			rentersApplicant.setAddressApt(autoApplicant.getResidentAddress1()) ;
			rentersApplicant.setCity(autoApplicant.getCity());
			rentersApplicant.setStateCode(autoApplicant.getStateCode());
			rentersApplicant.setState(autoApplicant.getStateName());
			rentersApplicant.setZipCode(autoApplicant.getZipCode());
			rentersApplicant.setPhoneNumber(autoApplicant.getPhoneNumber());
			rentersApplicant.setEmailAddress(autoApplicant.getEmail());
			rentersApplicant.setScenario(autoApplicant.getTestScenario());
			setRentersApplicant(rentersApplicant);
		}

		// Life data
		if (lifeApplicant != null) {
			lifeApplicant.setFirstName(autoApplicant.getFirstName());
			lifeApplicant.setLastName(autoApplicant.getLastName());
			lifeApplicant.setAge(autoApplicant.getAge());
			lifeApplicant.setGender(autoApplicant.getGender());
			lifeApplicant.setAddress(autoApplicant.getResidentAddress1()) ;
			lifeApplicant.setCity(autoApplicant.getCity());
			lifeApplicant.setStateCode(autoApplicant.getStateCode());
			lifeApplicant.setState(autoApplicant.getStateName());
			lifeApplicant.setZipCode(autoApplicant.getZipCode());
			lifeApplicant.setPhoneNumber(autoApplicant.getPhoneNumber());
			lifeApplicant.setEmailAddress(autoApplicant.getEmail());
			lifeApplicant.setPremiumYears("10");
			setLifeApplicant(lifeApplicant); 
		}

		// Business data
		if (businessApplicant != null) {
			businessApplicant.setFirstName(autoApplicant.getFirstName());
			businessApplicant.setLastName(autoApplicant.getLastName());
			businessApplicant.setAge(autoApplicant.getAge());
			businessApplicant.setPhoneNumber(autoApplicant.getPhoneNumber());
			businessApplicant.setEmail(autoApplicant.getEmail());
			setBusinessApplicant(businessApplicant) ;
		}

	}

}
