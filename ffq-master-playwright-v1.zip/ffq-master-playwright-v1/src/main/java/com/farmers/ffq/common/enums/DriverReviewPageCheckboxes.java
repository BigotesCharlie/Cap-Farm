package com.farmers.ffq.common.enums;

import com.farmers.ffq.datatransferobjects.AutoApplicant;
import lombok.Getter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter
public enum DriverReviewPageCheckboxes {

    COMMUTES_TO_DC("Commutes to DC"),
    MARITAL("Married, in a domestic partnership, or in a civil union"),
    FINANCIAL_RESPONSIBILITY("Requires financial responsibility filing (SR-22/FR-44) in "),
//    EMPLOYED("I want to check if my occupation is eligible for a discount"),
    INCIDENT("Had an accident or violation in last 5 years"),
    SAFETY_COURSE("Has completed a driver safety course in the last 3 years"),
    SAFETY_COURSE_2_YEARS("Has completed a driver safety course in the last 2 years"),
    HAD_DRIVER_LICENCE("Has had driver's license for less than 3 years"),
    STUDENT("Full time student"),
    HIGH_GPA("GPA over 3.0"),
    DISTANT_STUDENT("Attends school more than 100 miles away from home without custody of a car"),
    NOT_LIVE_IN_HOUSEHOLD("Does not live in my household"),
    NOT_RELATED("Not related to me (i.e roommate, friend)");

    private String checkBoxText;

    DriverReviewPageCheckboxes(String checkBoxText) {
        this.checkBoxText = checkBoxText;
    }

    public static List<String> getMiddleAgePniOrSniCheckboxes(String state) {
        List<String> middleAgePniOrSniCheckboxes = new ArrayList<>();
        middleAgePniOrSniCheckboxes.addAll(Arrays.asList(MARITAL.getCheckBoxText(), INCIDENT.getCheckBoxText()));
        if(!Arrays.asList(CALIFORNIA, MASSACHUSETTS, NEW_MEXICO).contains(state)) {
            middleAgePniOrSniCheckboxes.add(FINANCIAL_RESPONSIBILITY.getCheckBoxText() + state);
        }
        if(state.equals(KANSAS)) {
            middleAgePniOrSniCheckboxes.add(SAFETY_COURSE.getCheckBoxText());
        }
        if(state.equals(MARYLAND)) {
            middleAgePniOrSniCheckboxes.add(COMMUTES_TO_DC.checkBoxText);
        }
        return middleAgePniOrSniCheckboxes;
    }

    public static List<String> getOldAgePniOrSniCheckboxes(String state) {
        List<String> oldAgePniOrSniCheckboxes = new ArrayList<>();
        oldAgePniOrSniCheckboxes.addAll(Arrays.asList(MARITAL.getCheckBoxText(),SAFETY_COURSE.getCheckBoxText(), INCIDENT.getCheckBoxText()));
        if(!isStateRequiresSafetyCourse(state)) {
            oldAgePniOrSniCheckboxes.remove(SAFETY_COURSE.getCheckBoxText());
        }
        //NM state does not ask about financial filing
        if(!Arrays.asList(CALIFORNIA, MASSACHUSETTS, NEW_MEXICO).contains(state)) {
            oldAgePniOrSniCheckboxes.add(FINANCIAL_RESPONSIBILITY.getCheckBoxText() + state);
        }
        if(state.equals(MARYLAND)) {
            oldAgePniOrSniCheckboxes.add(COMMUTES_TO_DC.checkBoxText);
        }
        return oldAgePniOrSniCheckboxes;
    }

    public static List<String> getYoungAgePniOrSniCheckboxes(String state) {

        List<String> youngAgePniOrSniCheckboxes = new ArrayList<>(Arrays.asList(MARITAL.getCheckBoxText(), INCIDENT.getCheckBoxText(), HAD_DRIVER_LICENCE.getCheckBoxText(), STUDENT.getCheckBoxText()));

        if(!Arrays.asList(CALIFORNIA, MASSACHUSETTS, NEW_MEXICO).contains(state)) {
            youngAgePniOrSniCheckboxes.add(FINANCIAL_RESPONSIBILITY.getCheckBoxText() + state);
        }

        if(state.equals(KANSAS)) {
            youngAgePniOrSniCheckboxes.add(SAFETY_COURSE.getCheckBoxText());
        }
        if(state.equals(MARYLAND)) {
            youngAgePniOrSniCheckboxes.add(COMMUTES_TO_DC.checkBoxText);
        }

        if(Arrays.asList(CALIFORNIA, MASSACHUSETTS, LOUISIANA).contains(state)) {
            youngAgePniOrSniCheckboxes.remove(HAD_DRIVER_LICENCE.getCheckBoxText());
        }
        return youngAgePniOrSniCheckboxes;
    }

    public static List<String> getMiddleAgeAdditionalDriverCheckboxes(String state) {
        List<String> middleAgeAdditionalDriverCheckbox = new ArrayList<>();
        middleAgeAdditionalDriverCheckbox.addAll(Arrays.asList(MARITAL.getCheckBoxText(), INCIDENT.getCheckBoxText()));

        if(!Arrays.asList(CALIFORNIA, MASSACHUSETTS, NEW_MEXICO).contains(state)) {
            middleAgeAdditionalDriverCheckbox.add(FINANCIAL_RESPONSIBILITY.getCheckBoxText() + state);
        }
        if(state.equals(MICHIGAN)) {
            middleAgeAdditionalDriverCheckbox.addAll(Arrays.asList(NOT_RELATED.getCheckBoxText(), NOT_LIVE_IN_HOUSEHOLD.getCheckBoxText()));
        }
        if(state.equals(KANSAS)) {
            middleAgeAdditionalDriverCheckbox.add(SAFETY_COURSE.getCheckBoxText());
        }
        if(state.equals(MARYLAND)) {
            middleAgeAdditionalDriverCheckbox.add(COMMUTES_TO_DC.checkBoxText);
        }

        return middleAgeAdditionalDriverCheckbox;
    }

    public static List<String> getOldAgeAdditionalDriverCheckboxes(String state) {
        List<String> oldAgeAdditionalDriverCheckboxes = new ArrayList<>();
        oldAgeAdditionalDriverCheckboxes.addAll( Arrays.asList(MARITAL.getCheckBoxText(), INCIDENT.getCheckBoxText()));

        if(isStateRequiresSafetyCourse(state)) {
            oldAgeAdditionalDriverCheckboxes.add(SAFETY_COURSE.getCheckBoxText());
        }

        if(!Arrays.asList(CALIFORNIA, MASSACHUSETTS, NEW_MEXICO).contains(state)) {
            oldAgeAdditionalDriverCheckboxes.add(FINANCIAL_RESPONSIBILITY.getCheckBoxText() + state);
        }

        if(state.equals(MICHIGAN)) {
            oldAgeAdditionalDriverCheckboxes.addAll(Arrays.asList(NOT_RELATED.getCheckBoxText(), NOT_LIVE_IN_HOUSEHOLD.getCheckBoxText()));
        }
        if(state.equals(MARYLAND)) {
            oldAgeAdditionalDriverCheckboxes.add(COMMUTES_TO_DC.checkBoxText);
        }

        return oldAgeAdditionalDriverCheckboxes;
    }

    public static List<String> getYoungAgeAdditionalDriverCheckboxes(String state) {
        List<String> youngAgeAdditionalDriverCheckboxes = new ArrayList<>();
        youngAgeAdditionalDriverCheckboxes.addAll(Arrays.asList(MARITAL.getCheckBoxText(), INCIDENT.getCheckBoxText(), HAD_DRIVER_LICENCE.getCheckBoxText()));
        if(!Arrays.asList(CALIFORNIA, MASSACHUSETTS, NEW_MEXICO).contains(state)) {
            youngAgeAdditionalDriverCheckboxes.add(FINANCIAL_RESPONSIBILITY.getCheckBoxText() + state);
        }
        if(state.equals(MICHIGAN)) {
            youngAgeAdditionalDriverCheckboxes.addAll(Arrays.asList(NOT_RELATED.getCheckBoxText(), NOT_LIVE_IN_HOUSEHOLD.getCheckBoxText()));
        }

        //KS state asks for this question regardless of the age
        if(state.equals(KANSAS)) {
            youngAgeAdditionalDriverCheckboxes.add(SAFETY_COURSE.getCheckBoxText());
        }
        if(state.equals(MARYLAND)) {
            youngAgeAdditionalDriverCheckboxes.add(COMMUTES_TO_DC.checkBoxText);
        }

        if(Arrays.asList(CALIFORNIA, MASSACHUSETTS, LOUISIANA).contains(state)) {
            youngAgeAdditionalDriverCheckboxes.remove(HAD_DRIVER_LICENCE.getCheckBoxText());
        }
        return youngAgeAdditionalDriverCheckboxes;
    }

    public static List<String> getStudentAdditionalDriverCheckboxes(String state) {

        List<String> studentAdditionalDriverCheckboxes = new ArrayList<>();
        studentAdditionalDriverCheckboxes.addAll(Arrays.asList(MARITAL.getCheckBoxText(), INCIDENT.getCheckBoxText(), HAD_DRIVER_LICENCE.getCheckBoxText(), STUDENT.getCheckBoxText()));
        if(!Arrays.asList(CALIFORNIA, MASSACHUSETTS, NEW_MEXICO).contains(state)) {
            studentAdditionalDriverCheckboxes.add(FINANCIAL_RESPONSIBILITY.getCheckBoxText() + state);
        }
        if(state.equals(MICHIGAN)) {
            studentAdditionalDriverCheckboxes.addAll(Arrays.asList(NOT_RELATED.getCheckBoxText(), NOT_LIVE_IN_HOUSEHOLD.getCheckBoxText()));
        }
        //KS state asks for this question regardless of the age
        if(state.equals(KANSAS)) {
            studentAdditionalDriverCheckboxes.add(SAFETY_COURSE.getCheckBoxText());
        }

        if(state.equals(MARYLAND)) {
            studentAdditionalDriverCheckboxes.add(COMMUTES_TO_DC.checkBoxText);
        }
        if(Arrays.asList(CALIFORNIA, MASSACHUSETTS, LOUISIANA).contains(state)) {
            studentAdditionalDriverCheckboxes.remove(HAD_DRIVER_LICENCE.getCheckBoxText());
        }
        return studentAdditionalDriverCheckboxes;
    }

    public static List<String> getStudentDiscountCheckboxes(AutoApplicant applicant, boolean isPniOrSniOver30) {
        List<String> studentDiscounts = new ArrayList<>();
        studentDiscounts.add(HIGH_GPA.getCheckBoxText());
         if(isPniOrSniOver30 && !applicant.getStateCode().equals(LA)) {
             studentDiscounts.add(DISTANT_STUDENT.getCheckBoxText());
         }
         return studentDiscounts;
    }

    private static boolean isStateRequiresSafetyCourse(String stateName) {
       return !Arrays.asList(LOUISIANA, NEBRASKA, SOUTH_DAKOTA, INDIANA, TEXAS).contains(stateName);
    }
}
