package com.farmers.ffq.datatransferobjects;
import lombok.Data;

@Data
public class SqlRepresentative {
	private String representativeId;
	private String fullName;
	private String aor;
	private String zipCode;
	private String stateCode;
	private String address;
}
