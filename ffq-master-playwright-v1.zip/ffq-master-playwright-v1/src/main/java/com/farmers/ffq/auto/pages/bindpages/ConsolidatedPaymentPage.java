package com.farmers.ffq.auto.pages.bindpages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.PolicyBankPayment;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.VerifyResponse;
import com.farmers.ffq.datatransferobjects.AppStore.VerifyResponse.PaymentSchedule;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.RandomStringUtils;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.common.pages.PolicyBankPayment.NO_SERVICE_CHARGE_WHEN_USING_BANK;
import static com.farmers.ffq.common.pages.PolicyDebitCreditPayment.NO_SERVICE_CHARGE_WHEN_PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class ConsolidatedPaymentPage extends AutoPolicyPaymentBasePage {

    //Constants
    protected final String SIX_MONTH_TERM_PRICE = "6-month term price";
    protected final String ONE_TIME_FEE = "One-time fee";
    protected final String FEES_LABEL = "Fees";
    protected final String SELECT_YOUR_PREFERRED_PAYMENT_METHOD = "Select your preferred payment method";
    private final String VIEW_BREAKDOWN = "View breakdown";
    private final String VIEW_LESS = "View less";
    protected final String NO_SERVICE_CHARGE_WHEN_PAYING_IN_FULL = "No service charges when paying in full";

    // Payment card content xpath:
    protected String PAYMENT_CARD__XPATH = "//div[contains(@class,'presentment-card-header')]//mat-card[contains(.,'%s')]";
    protected String PAYMENT_CARD_HEADER_XPATH = "//div[contains(@class,'tui-presentment-card-header-row-1')]//h2";
    protected String PAYMENT_CARD_SUB_HEADER_XPATH = "//div[contains(@class,'tui-presentment-card-header-row-1')]//p";
    protected String PAYMENT_CARD_PAYMENT_DESCRIPTION_XPATH = "//p[@class='tui-caption-text']";
    protected String PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_ONE_DOLLAR_SIGN_XPATH = "//div[@class='tui-payplan']/div[@class='tui-payplan-column-1']";
    protected String PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_TWO_DOLLAR_AMOUNT_XPATH = "//div[@class='tui-payplan']/div[@class='tui-payplan-column-2']";
    protected String PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_THREE_CENT_AMOUNT_XPATH = "//div[@class='tui-payplan']/div[@class='tui-payplan-column-3']";
    protected String PAYMENT_CARD_GREEN_MARK_XPATH = "//mat-icon[contains(@class,'payment-overview-green-mark')]";
    protected String PAYMENT_CARD_SAVINGS_TEXT_XPATH = "//p[contains(@class,'payment-overview-icon-padding')]";
    protected String CA_STATE_PAYMENT_METHOD_TEXT_XPATH = "//div[contains(@class,'ca-payment-method-text')]";
    protected String EXCLUDE_FEES_SURCHARGE_TAXES = "Excludes taxes, fees, and surcharges";
    protected String EXCLUDE_FEES_SURCHARGE_TAXES_XPATH = "//p[contains(text(),'" + EXCLUDE_FEES_SURCHARGE_TAXES +"')]";

    @PWFindAll({
            @PWFindBy(xpath = "//app-payment-consolidated//h1[@role='heading']"),
            @PWFindBy(xpath = "//app-payment-overview//h1")
    })
    protected PWElement pageHeader;
    @PWFindBy(xpath = "//div[contains(@class,'tui-input-text payment-overview-sub-para')]")
    private PWElement rateAdjustmentMessageInCaseOfDecrease;
    @PWFindBy(xpath = "//div[contains(@class,'tui-input-text payment-overview-sub-para')]")
    private PWElement rateAdjustmentMessage;
    @PWFindBy(css = "a[data-gtm='Auto_Bind_Payplan_CustomCoverage_link']")
    private PWElement changeYourCoverageLink;
    @PWFindBy(xpath = "//h2[@class='discount-title']")
    protected PWElement discountTitle;
    @PWFindBy(xpath = "//h2[@class='discount-title mt-4 mb-0']")
    protected PWElement discountTitleMobile;
    @PWFindBy(xpath = "//mat-radio-button[contains(.,'Pay in full')]")
    private PWElement payInFullRadioButton;
    @PWFindBy(xpath = "//mat-radio-button[contains(.,'Pay in full')]//label")
    private PWElement payInFullRadioButtonLabel;
    @PWFindBy(xpath = "//mat-radio-button[contains(.,'Monthly Autopay')]")
    private PWElement monthlyAutoPayRadioButton;
    @PWFindBy(xpath = "//mat-radio-button[contains(.,'Monthly Autopay')]//label")
    private PWElement monthlyAutoPayRadioButtonLabel;
    @PWFindAll({
        @PWFindBy(xpath = "//mat-radio-button//h2"),
        @PWFindBy(xpath = "//mat-tab-header//*[@role='tab']")
    })
    private List<PWElement> availablePaymentOptions;

    // locators for the fee help icon section
    @PWFindBy(xpath = "//p[@class='tui-info-box-header tui-field-label-text']")
    protected PWElement feeInfoBoxHeader;
    @PWFindBy(xpath = "//p[@class='tui-info-box-content']")
    protected PWElement feeInfoBoxDescription;
    @PWFindBy(xpath = "//mat-icon[contains(@class,'mat-icon notranslate tui-info-box-icon material-icons mat-ligature-font mat-icon-no-color')]")
    protected PWElement feeInfoIcon;
    @PWFindBy(xpath = "//mat-icon[contains(@class,'mat-icon notranslate tui-info-box-icon mobile-info-icon material-icons mat-icon-no-color')]")
    protected PWElement feeInfoIconMobileView;
    @PWFindBy(xpath = "//app-model-info-box-bind//h1[@aria-label='Fee info']")
    protected PWElement feeInfoBoxHeaderMobileView;
    @PWFindBy(xpath = "//app-model-info-box-bind//p")
    protected PWElement feeInfoBoxDescriptionMobileView;

    // Monthly auto pay payment details section
    @PWFindBy(xpath = "//app-monthly-auto-pay-consolidated//h2")
    protected PWElement monthlyAutoPaySectionHeader;
    @PWFindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row d-flex justify')][1]/p[1]")
    protected PWElement firstMonthlyPaymentText;
    @PWFindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row d-flex justify')][1]/p[2]")
    protected PWElement firstMonthlyPaymentAmount;
    @PWFindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')][2]/descendant::*[1]")
    protected PWElement monthlyPayOneTimeFeeText;
    @PWFindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')][2]/descendant::*[2]")
    protected PWElement monthlyPayFeeAmount;
    @PWFindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')][3]/descendant::*[1]")
    protected PWElement monthlyPaySurchargeText;
    @PWFindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')][3]/descendant::*[2]")
    protected PWElement monthlyPaySurchargeAmount;
    @PWFindBy(xpath = "//div[contains(@class,'monthly-autopay-fees-row')][2]//p")
    protected PWElement monthlyPayFeeAmountAuto;
    @PWFindBy(xpath = "//div[contains(@class,'details-bottom')]/span[1]")
    protected PWElement dueTodayLabel;
    @PWFindBy(xpath = "//div[contains(@class,'details-bottom')]/span[2]")
    protected PWElement dueTodayAmount;
    @PWFindBy(xpath = "//div[contains(@class,'monthly-autopay-details-header')]/span")
    protected PWElement monthlyAutoPayTotalHeader;
    @PWFindBy(id = "view-breakdown-link")
    private PWElement viewBreakDownLink;

    @PWFindBy(xpath = "//div[@class='show-breakdown ng-star-inserted']//div[@class='ng-star-inserted']//span[1]")
    private List<PWElement> monthByMonthInstallmentsTexts;

    @PWFindBy(xpath = "//div[@class='show-breakdown ng-star-inserted']//div[@class='ng-star-inserted']//span[2]")
    private List<PWElement> monthByMonthInstallmentsAmounts;
    @PWFindBy(xpath = "//div[contains(@class,'tui-body-text-bold monthly-autopay-details-bottom-row d-flex mb-2 justify-content-between')]//span[1]")
    private PWElement monthlyAutopayBottomTotalTermPriceText;
    @PWFindBy(xpath = "//div[contains(@class,'tui-body-text-bold monthly-autopay-details-bottom-row d-flex mb-2 justify-content-between')]//span[2]")
    private PWElement monthlyAutopayBottomTotalTermPriceAmount;


    // Pay in full payment section locators
    @PWFindBy(xpath = "//app-full-auto-pay-consolidated//h2")
    protected PWElement payInFullPaySectionHeader;
    @PWFindBy(xpath = "//div[contains(@class,'pif-autopay-fees-row d-flex justify-content-between w-100 tui-body')][1]/span[1]")
    protected PWElement payInFullSixMonthTermPriceText;
    @PWFindBy(xpath = "//div[contains(@class,'pif-autopay-fees-row d-flex justify-content-between w-100 tui-body')][1]/span[2]")
    protected PWElement payInFullSixMonthTermPriceAmount;
    @PWFindBy(xpath = "//div[contains(@class,'pif-autopay-fees-row')][2]/span[1]")
    protected PWElement payInFullOneTimeFeesText;
    @PWFindBy(xpath = "//div[contains(@class,'pif-autopay-fees-row')][2]/span[2]")
    protected PWElement payInFullOneTimeFeesAmount;
    @PWFindBy(xpath = "//div[contains(@class,'pif-autopay-surcharge-fees')]//span[1]")
    protected PWElement payInFullTaxesAndSurchargeText;
    @PWFindBy(xpath = "//div[contains(@class,'pif-autopay-surcharge-fees')]//span[2]")
    protected PWElement payInFullTaxesAndSurchargeAmount;
    @PWFindBy(xpath = "//div[contains(@class,'pif-autopay-details-bottom-row d-flex justify-content-between')][1]/span[1]")
    protected PWElement payInFullDueTodayText;
    @PWFindBy(xpath = "//div[contains(@class,'pif-autopay-details-bottom-row d-flex justify-content-between')][1]/span[2]")
    protected PWElement payInFullDueTodayAmount;
    @PWFindBy(xpath = "//div[contains(@class,'pif-autopay-details-header')]")
    protected PWElement payInFullBottomPaymentDetails;


    //payment method set up section
    @PWFindBy(css = "mat-radio-button[value='bank']")
    private PWElement bankPaymentRadioButton;
    @PWFindBy(xpath = "//mat-radio-button[@value='bank']//label")
    private PWElement bankPaymentRadioButtonLabel;
    @PWFindBy(css = "mat-radio-button[value='card']")
    private PWElement cardRadioButton;
    @PWFindBy(xpath = "//p[contains(@class,'selection-header')]")
    protected PWElement paymentMethodSelectionHeader;
    @PWFindBy(xpath = "//mat-radio-button[@value='bank']//label")
    protected PWElement paymentSelectionBankPaymentRadioButton;
    @PWFindBy(xpath = "//mat-radio-button[@value='card']//label")
    protected PWElement paymentSelectionCardRadioButton;
    @PWFindBy(xpath = "//div[contains(@class,'monthly-autopay-selection-option')]//div[contains(@class,'monthly-autopay-selection-sub-section')]")
    protected List<PWElement> bankCardPaymentServiceChargesText;
    @PWFindBy(xpath = "//mat-radio-button[contains(@class,'mat-radio-button ca-card-payment-radio-option mat-radio-disabled mat-accent')]")
    protected PWElement californiaCardPaymentRadioButton;
    @PWFindBy(xpath = "//span[contains(@class,'card-NA-text')]")
    protected PWElement californiaCardNotAvailableMonthlyPayMessage;
    @PWFindBy(xpath = "//span[contains(@class,'ca-card-payment-service-text')]")
    protected PWElement californiaCardPaymentServiceChargesText;
    @PWFindBy(xpath = "//section[@class='monthly-autopay-selection ng-star-inserted']/div/div")
    protected PWElement usingCardIncreaseMessage;
    @PWFindBy(xpath = "//div[contains(@class,'disclaimers-charge-info')]//*[contains(@class,'generic-payment')]")
    protected PWElement addedBankIcon;
    @PWFindBy(xpath = "//span[contains(@class,'account-numbers')]")
    protected PWElement maskedAddedPaymentDetails;
    @PWFindBy(xpath = "//span[contains(.,'Bank payment account added.')]")
    protected PWElement bankAccountAddedMessage;
    @PWFindAll({
            @PWFindBy(xpath = "//span[contains(.,'Debit card added.')]"),
            @PWFindBy(xpath = "//span[contains(.,' card added.')]")
    })
    protected PWElement debitCardAddedMessage;
    @PWFindBy(xpath = "//span[contains(.,'Credit card added.')]")
    protected PWElement creditCardAddedMessage;
    @PWFindBy(xpath = "//section[contains(@class,'payment-confirmation')]/div[1]//mat-icon")
    protected PWElement paymentAddedGreenCheck;
    @PWFindBy(xpath = "//div[contains(@class,'disclaimers-charge-info')]//i")
    protected PWElement addedPaymentMethodIconCard;
    @PWFindBy(xpath = "//div[contains(@class,'disclaimers-charge-info')]//i")
    protected PWElement addedPaymentMethodIconBank;
    @PWFindBy(xpath = "//*[contains(@class,'disclaimers-charge-text')]")
    protected PWElement chargeDisclaimerText;
    @PWFindBy(xpath = "//section[contains(@class,'payment-confirmation')]//div[3]/span[1]")
    protected PWElement paymentAddedDueMonthlyText;
    @PWFindBy(xpath = "//section[contains(@class,'payment-confirmation')]//div[3]/span[2]")
    protected PWElement paymentAddedDueMonthlyAmount;

    //added credit card service charge section
    @PWFindBy(xpath = "//*[contains(@class,'disclaimers-charge-text')]//mat-icon")
    protected PWElement infoIcon;
    @PWFindBy(xpath = "//*[contains(@class,'disclaimers-charge-text')]//p[@class='tui-info-box-content']/p[1]")
    protected PWElement serviceChargeTitle;
    @PWFindBy(xpath = "//*[contains(@class,'disclaimers-charge-text')]//p[@class='tui-info-box-content']/p[2]")
    protected PWElement serviceChargeMessage;
    @PWFindBy(xpath = "//*[contains(@class,'disclaimers-charge-text')]//p[@class='tui-info-box-content']/p[3]")
    protected PWElement changeSuggestionLink;


    // disclaimer section locators
    @PWFindBy(xpath = "//div[contains(@class,'disclaimers-text-header')]")
    private PWElement disclaimerHeaderText;
    @PWFindBy(xpath = "//section[contains(@class,'disclaimers-text')]//li[1]//p")
    private PWElement disclaimerContentBulletPointOne;
    @PWFindBy(partialLinkText = "Paperless Terms of Use")
    private PWElement paperlessTermsOfUseLink;
    @PWFindBy(xpath = "//section[contains(@class,'disclaimers-text')]//li[2]//p")
    private PWElement disclaimerContentBulletPointTwo;
    @PWFindBy(partialLinkText = "Information Storage Authorization")
    private PWElement informationStorageAuthorizationLink;
    @PWFindBy(partialLinkText = "Payment Authorization Terms & Conditions.")
    private PWElement paymentAuthorizationTermsAndConditionsLink;
    @PWFindBy(xpath = "//section[contains(@class,'disclaimers-text')]//li[3]//p")
    private PWElement disclaimerContentBulletPointThree;
    @PWFindBy(css = "mat-radio-button[value='one-time-payment']")
    private PWElement oneTimePaymentRadioButton;
    @PWFindBy(css = "mat-radio-button[value='automatic-recurring']")
    private PWElement recurringPaymentsRadioButton;

    @PWFindBy(xpath = "//section[contains(@class,'disclaimers-text')]//p[contains(@class, 'stacking')]")
    private PWElement termsAndConditionsDisclaimer;
    @PWFindBy(xpath= "//mat-progress-bar")
    private List<PWElement> progressbarInConsolidatedPaymentPageAceAuto;
    @PWFindBy(xpath = "//button[contains(@class,'ok-button')]")
    private PWElement rateChangeModalOkButton;
    /**
     * Constructor.
     *
     * @throws Exception
     */
    public ConsolidatedPaymentPage() throws Exception {
    }

    public boolean isOnConsolidatedPaymentPage() {
        // waiting long as there is PC call right before this page
        return isElementVisible(pageHeader, Property.PAGELOADTIMEOUT);
    }

    public boolean isPageHeaderCorrect(String expectedHeader) {
        return getTextFromElement(waitElementBeVisible(consolidatedPaymentPageHeader)).equals(expectedHeader);
    }

    /**
     * @param payInFullOrMonthlyPay: Accepts either "Pay in full" or "Monthly Autopay"
     * @param paymentMethods         - bank, credit, or debit selection
     */
    public void processConsolidatedPaymentPage(String payInFullOrMonthlyPay, PaymentMethods paymentMethods, Boolean continuePurchase) throws Exception {
        isOnConsolidatedPaymentPage();
        selectPaymentMethodFromPaymentCards(payInFullOrMonthlyPay);
        switch (paymentMethods) {
            case VISA_CREDIT_CARD_1:
            case VISA_DEBIT_CARD_1:
            case AMEX_CREDIT_CARD_1:
            case VISA_DEBIT_CARD_2:
            case MASTERCARD_CREDIT_CARD_1:
                clickCardRadioButton();
                addCardPaymentMethod(paymentMethods.getAccountNumber(), getSessionStorageAppStore().getData().getLandingZipCode());
                break;
            case BANK_ACCOUNT_1:
                clickBankPaymentRadioButton();
                String randomAccountNumber = RandomStringUtils.randomNumeric(6);
                addCheckingAccountPaymentMethod(paymentMethods.getAccountNumber(), randomAccountNumber);
                break;
			default:
				break;
        }
        waitElementBeVisibleClickable(completePurchaseButton);
        if (continuePurchase /* && !getSessionStorageAppStore().getData().getLandingStateCode().equals(CA) */) {
            clickCompletePurchaseButton();
            waitForSpinnerToBeGone();
            KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
            if(knockoutInconveniencePage.isOnInconveniencePage()) {
                testStep("User landed on the inconvenice page as bind was not success", true);
            } else {
                testStep("Test Ended", true);
            }

        }
    }

    public void validateConsolidatedPaymentPage(FarmersSoftAssert fsa) throws Exception {
        if (Arrays.asList(SD, WY).contains(getSessionStorageAppStore().getData().getLandingStateCode())) {
            fsa.assertTrue(isPayInFullDefault(), "Consolidated payment page Pay in full pay should be selected by default for SD and WY");
        } else {
            fsa.assertTrue(isMonthlyAutoPayDefault(), "Consolidated payment page Monthly auto pay should be selected by default");
        }
        validateContentOfPaymentCard(PAY_IN_FULL, fsa);
        validateContentOfPaymentCard(MONTHLY_AUTOPAY, fsa);
        comparePayInFullAndMonthlyAutoPayPremiumsAuto(fsa);
        validateDiscountSection(fsa);
        validateMonthlyAutopayPaymentSection(fsa);
        validatePayInFullPaymentSection(fsa);
        validateFeeInfoSection(fsa);
        validatePreferredPaymentMethodSection(PAY_IN_FULL, fsa);
        validatePreferredPaymentMethodSection(MONTHLY_AUTOPAY, fsa);
        validateConsolidatePageDisclaimers(fsa);
    }

    public boolean isMonthlyAutoPayDefault() throws Exception {
        if(isUseMobileViewEnabled()) {
            PWElement monthlyAutoPayTab = driver().findElement(PWBy.xpath(String.format("//div[contains(@class,'mat-mdc-tab-labels') and contains(.,'%s')]", MONTHLY_AUTOPAY)));
            return getAttributeData(monthlyAutoPayTab, ARIA_SELECTED).equals(LOWERCASE_TRUE);
        }
        PWElement monthlyAutopayMatRadioButton = driver().findElement(PWBy.xpath(getXPathForPaymentMethod(MONTHLY_AUTOPAY) + "//mat-radio-button"));
        return wait.until(PWExpectedConditions.attributeContains(monthlyAutopayMatRadioButton, CLASS, RADIO_BUTTON_CHECKED));
    }

    public boolean isPayInFullDefault() throws Exception {
        if(isUseMobileViewEnabled()) {
            PWElement monthlyAutoPayTab = driver().findElement(PWBy.xpath(String.format("//div[contains(@class,'mat-mdc-tab-labels') and contains(.,'%s')]", PAY_IN_FULL)));
            return getAttributeData(monthlyAutoPayTab, ARIA_SELECTED).equals(LOWERCASE_TRUE);
        }
        PWElement monthlyAutopayMatRadioButton = driver().findElement(PWBy.xpath(getXPathForPaymentMethod(PAY_IN_FULL) + "//mat-radio-button"));
        return wait.until(PWExpectedConditions.attributeContains(monthlyAutopayMatRadioButton, CLASS, RADIO_BUTTON_CHECKED));
    }

    public void validatePayments(FarmersSoftAssert fsa) throws Exception {
        validateBankAccountAddition(fsa, MONTHLY_AUTOPAY);
        isFarmersPhoneNumberCorrect(false, this.getClass().getSimpleName(), fsa);
        validateBankAccountAddition(fsa, PAY_IN_FULL);
        validateDebitCardPaymentAddition(fsa, MONTHLY_AUTOPAY);
        validateDebitCardPaymentAddition(fsa, PAY_IN_FULL);
        validateCreditCardPayment(fsa, MONTHLY_AUTOPAY);
        validateCreditCardPayment(fsa, PAY_IN_FULL);
    }

    public void validatePaymentMethodChanges(FarmersSoftAssert fsa) throws Exception {
        validateBankToCardPaymentChange(fsa, MONTHLY_AUTOPAY);
        validateBankToCardPaymentChange(fsa, PAY_IN_FULL);
        validateCardToBankPaymentChange(fsa, MONTHLY_AUTOPAY);
        validateCardToBankPaymentChange(fsa, PAY_IN_FULL);
    }

    public void validateDebitCardPaymentAddition(FarmersSoftAssert fsa, String paymentMethod) throws Exception {
        boolean isCAState = getSessionStorageAppStore().getData().getLandingStateCode().equals(CA);
        String commonMessage = paymentMethod + " Debit card addition";
        selectPaymentMethodFromPaymentCards(paymentMethod);
        if(isCAState && paymentMethod.equals(MONTHLY_AUTOPAY)) {
            Log.info("Card radio button is disabled for CA");
            fsa.assertTrue(isElementVisible(californiaCardPaymentRadioButton, 1), "Disabled radio button should be visible for CA");
            return;
        }
        clickCardRadioButton();
        boolean isPayInFull = paymentMethod.equals(PAY_IN_FULL);
        String debitCardNumber = isPayInFull ? VISA_DEBIT_CARD : VISA_DEBIT_CARD_2;
        addCardPaymentMethod(debitCardNumber, getSessionStorageAppStore().getData().getLandingZipCode());
        waitForSpinnerToBeGone();

        scrollToElement(debitCardAddedMessage);
        fsa.assertTrue(getTextFromElement(waitElementBeVisible(debitCardAddedMessage)).contains(" card added"), "Debit card added message for : " + commonMessage);
        fsa.assertTrue(isElementDisplayed(paymentAddedGreenCheck, 3), "Green check is displayed for : " + commonMessage);
        validateAddedPaymentMethodIconsForCards(debitCardNumber, fsa);
        String expectedMaskedPaymentMethod = String.format("%s | Exp %s", debitCardNumber.substring(12), EXP_DATE);
        fsa.assertEquals(getTextFromElement(maskedAddedPaymentDetails), expectedMaskedPaymentMethod, "Masked debit card details validaiton for : " + commonMessage);
        fsa.assertTrue(changePaymentMethodLink.isDisplayed() && changePaymentMethodLink.isEnabled(), "Change link should be displayed  and enabled for : " + commonMessage);

        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        if (paymentMethod.equals(MONTHLY_AUTOPAY)) {
            List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
            fsa.assertTrue(infoIcon.isDisplayed(), "Info icon for credit card service charge section : " + commonMessage);
            String expectedServiceChargeTitle = isFlexState(landingStateCode) && !Arrays.asList(LA).contains(landingStateCode) ? "Service charge" : "Service charge and total cost increase";
            fsa.assertEquals(getTextFromElement(serviceChargeTitle), expectedServiceChargeTitle, "Service charge section title validation for : " + commonMessage);
            int administrativeCharge = getAdministrativeFeeForGivenPayPlanDescription(paymentSchedules, MONTHLY_DEBIT_CREDIT_CARD); // before we used to pass 'MONTHLY_DEBIT_CARD_DESCRIPTION', but now paymentus is taking Debit as credit, thus this change is needed
            String expectedServiceChargeMessage = String.format("Your payment method added a $%s service charge.", administrativeCharge);
            if (Arrays.asList(LA, KS, KY, IN, IA, MA, MD, MN, MS, NV, OH, WA).contains(landingStateCode)) {
                String fullTermPremiumForBankPayment = paymentSchedules.stream().filter(payment -> payment.getPayPlanCode().equals("MTEF")).findFirst().get().getFullTermPremium();
                String fullTermPremiumForDebitCardPayment = paymentSchedules.stream().filter(payment -> payment.getPayPlanCode().equals("MTPD")).findFirst().get().getFullTermPremium();
                int premiumDifference = (int) (Double.parseDouble(fullTermPremiumForDebitCardPayment) - Double.parseDouble(fullTermPremiumForBankPayment));
                expectedServiceChargeMessage = String.format("Your payment method increased your total cost by $%s and added a $%s service charge.", premiumDifference, administrativeCharge);
            }
            fsa.assertEquals(getTextFromElement(serviceChargeMessage).replace("info_outline ", EMPTY_STRING), expectedServiceChargeMessage, "Service charge message validation for : " + commonMessage);

            //softAssert.assertEquals(getTextFromElement(changeSuggestionLink), "You can lower your cost by changing to a bank transfer.", "Change to bank transfer suggestion link validation for : " + commonMessage);
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyText), "Due monthly", "Due monthly text validation for: " + commonMessage);
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyAmount), String.format("$%.2f", Double.parseDouble(getInstallmentAmountFarmers(MONTHLY_DEBIT_CARD_DESCRIPTION))), "Due monthly amount validation for: " + commonMessage);
        } else {
            String expectedServiceChargeMessage = Arrays.asList(WY, SD).contains(landingStateCode) ? "No service charges or premium increases when using a debit card." : NO_SERVICE_CHARGE_WHEN_PAYING_IN_FULL;
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(chargeDisclaimerText)).replace("info_outline ", EMPTY_STRING), expectedServiceChargeMessage, "Service charge disclaimer should be as expected for : " + commonMessage);
            String dueTodayAmount = getDueTodayAmountForOnePay();
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyText), "Due today", "Due today text validation for: " + commonMessage);
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyAmount), String.format("$%s", getFormattedDecimal(Double.parseDouble(dueTodayAmount.replace(",", EMPTY_STRING)))), "Due today amount validation for: " + commonMessage);
        }

    }

    protected void validateCreditCardPayment(FarmersSoftAssert fsa, String paymentMethod) throws Exception {
        String commonMessage = paymentMethod + " Credit Card payment addition";
        selectPaymentMethodFromPaymentCards(paymentMethod);
        boolean caState = getSessionStorageAppStore().getData().getLandingStateCode().equals(CA);
        if(caState && !paymentMethod.equals(PAY_IN_FULL)) {
            return;
        }

        clickCardRadioButton();
        String creditCard = paymentMethod.equals(PAY_IN_FULL) ? AMERICAN_EXPRESS_CARD : new Random().nextBoolean() ? DISCOVER_CARD : MASTER_CARD;
        addCardPaymentMethod(creditCard, getSessionStorageAppStore().getData().getLandingZipCode());
        scrollToElement(waitElementBeVisible(creditCardAddedMessage));
        fsa.assertEquals(getTextFromElement(creditCardAddedMessage), "Credit card added.", "Credit card added message for : " + commonMessage);
        fsa.assertTrue(paymentAddedGreenCheck.isDisplayed(), "Green check is displayed for : " + commonMessage);
        validateAddedPaymentMethodIconsForCards(creditCard, fsa);
        //amex credit cards has 15 digits while other has 16 digits
        int startIndex = creditCard.equals(AMERICAN_EXPRESS_CARD) ? 11 : 12;
        String expectedMaskedPaymentMethod = String.format("%s | Exp %s", creditCard.substring(startIndex), EXP_DATE);
        fsa.assertEquals(getTextFromElement(maskedAddedPaymentDetails), expectedMaskedPaymentMethod, "Masked credit card details validation for : " + commonMessage);
        fsa.assertTrue(changePaymentMethodLink.isDisplayed() && changePaymentMethodLink.isEnabled(), "Change link should be displayed  and enabled for : " + commonMessage);

        boolean isPayInFull = paymentMethod.equals(PAY_IN_FULL);
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        if (!isPayInFull) {
            fsa.assertTrue(infoIcon.isDisplayed(), "Info icon for credit card service charge section : " + commonMessage);
            String serviceCharge = isFlexState(landingStateCode) && !Arrays.asList(LA).contains(landingStateCode)? "Service charge" : "Service charge and total cost increase";
            fsa.assertEquals(getTextFromElement(serviceChargeTitle), serviceCharge, "Service charge section title validation for : " + commonMessage);
            List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
            int administrativeCharge = getAdministrativeFeeForGivenPayPlanDescription(paymentSchedules, MONTHLY_DEBIT_CREDIT_CARD);
            String expectedServiceChargeMessage = String.format("Your payment method added a $%s service charge.", administrativeCharge);
            if (!isFlexState(landingStateCode)) {
                String fullTermPremiumForBankPayment = paymentSchedules.stream().filter(payment -> payment.getPayPlanCode().equals("MTEF")).findFirst().get().getFullTermPremium();
                String fullTermPremiumForDebitCardPayment = paymentSchedules.stream().filter(payment -> payment.getPayPlanCode().equals("MTPD")).findFirst().get().getFullTermPremium();
                int premiumDifference = (int) (Double.parseDouble(fullTermPremiumForDebitCardPayment) - Double.parseDouble(fullTermPremiumForBankPayment));
                expectedServiceChargeMessage = String.format("Your payment method increased your total cost by $%s and added a $%s service charge.", premiumDifference, administrativeCharge);

                if (landingStateCode.equals(WY)) {
                    expectedServiceChargeMessage = String.format("Your payment method added a $%s service charge.", administrativeCharge);
                }
            }
            fsa.assertEquals(getTextFromElement(serviceChargeMessage), expectedServiceChargeMessage, "Service charge message validation for : " + commonMessage);
//            String expectedChangeSuggestionText = Arrays.asList(KS,IN,IA,MN,OH).contains(getSessionStorageAppStore().getData().getLandingStateCode()) ? "You can lower your cost by changing to a bank transfer.": "You can lower your cost by changing to a bank or a debit card.";
//            softAssert.assertEquals(getTextFromElement(changeSuggestionLink), expectedChangeSuggestionText, "Change to debit or Credit card suggestion link validation for : " + commonMessage);
        } else {
            String expectedServiceCharge = Arrays.asList(WY, SD).contains(landingStateCode) ? "Total cost increase Your payment method increased your total cost. You can lower your cost by changing to a bank transfer or debit card." : NO_SERVICE_CHARGE_WHEN_PAYING_IN_FULL;
            fsa.assertEquals(getTextFromElement(chargeDisclaimerText).replace("info_outline ", EMPTY_STRING), expectedServiceCharge, "Service charerge text validation for " + commonMessage);
            String dueTodayAmount = getDueTodayAmountForOnePay();

            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyText), "Due today", "Due today text validation for: " + commonMessage);
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyAmount), String.format("$%s", getFormattedDecimal(Double.parseDouble(dueTodayAmount.replaceAll("[^0-9.]", EMPTY_STRING)))), "Due today amount validation for: " + commonMessage);
        }


    }

    public void validateProgressbar(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(progressbarInConsolidatedPaymentPageAceAuto.isEmpty(),"Progressbar shouldn't exist on consolidated payment page");
    }

    protected void validateBankAccountAddition(FarmersSoftAssert fsa, String paymentMethod) throws Exception {
        String commonMessage = paymentMethod + " Bank Account Addition";
        String dueTodayAmount = getDueTodayAmountForOnePay();
        //add bank account as payment
        selectPaymentMethodFromPaymentCards(paymentMethod);
        clickBankPaymentRadioButton();
        String accountNumber = RandomStringUtils.randomNumeric(6);
        addCheckingAccountPaymentMethod(BOFA_ROUTING_NUMBER, accountNumber);

        scrollToElement(waitElementBeVisible(bankAccountAddedMessage));
        //validations
        fsa.assertTrue(bankAccountAddedMessage.isDisplayed(), "Bank account is added message is displayed for " + commonMessage);
        fsa.assertTrue(paymentAddedGreenCheck.isDisplayed(), "Green check icon is displayed for  : " + commonMessage);
        fsa.assertTrue(addedPaymentMethodIconBank.isDisplayed(), "Bank icon should be displayed after bank payment addition : " + commonMessage);
        fsa.assertTrue(maskedAddedPaymentDetails.isDisplayed(), "Bank account number (masked) should be displayed after bank payment addition : " + commonMessage);
        isHiddenBankAccountMonthlyPayTextCorrect(fsa, accountNumber);
        fsa.assertTrue(changePaymentMethodLink.isDisplayed() && changePaymentMethodLink.isEnabled(), "Change should be displayed  and enabled after bank payment addition : " + commonMessage);
        boolean payInFull = paymentMethod.equals(PAY_IN_FULL);
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        /*int administrativeFeeForGivenPayPlanDescription = getAdministrativeFeeForGivenPayPlanDescription(paymentSchedules, MONTHLY_EFT);
        String expectedServiceChargeMessage = payInFull ? NO_SERVICE_CHARGE_WHEN_PAYING_IN_FULL : NO_SERVICE_CHARGE_WHEN_USING_BANK;
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        if (administrativeFeeForGivenPayPlanDescription > 0 && !payInFull) {
            expectedServiceChargeMessage = String.format("Service charge Your payment method added a $%s service charge.", administrativeFeeForGivenPayPlanDescription);
        } else if (Arrays.asList(KS, IN, IA, LA, MA, MD, MN, MS, OH, SD, WA, WY, NV).contains(landingStateCode)) {
            expectedServiceChargeMessage = payInFull || !Arrays.asList(SD, WY).contains(landingStateCode)
                    ? "No service charges or premium increases when using bank transfer."
                    : NO_SERVICE_CHARGE_WHEN_USING_BANK;
            expectedServiceChargeMessage = Arrays.asList(IN, IA, KS, MA, OH, MD, MN, NV, LA, WA, MS).contains(landingStateCode) && payInFull ? NO_SERVICE_CHARGE_WHEN_PAYING_IN_FULL : expectedServiceChargeMessage;
        }*/

        int fee = getAdministrativeFeeForGivenPayPlanDescription(paymentSchedules, MONTHLY_EFT);
        String state = getStateCodeFromAppStore();
        boolean isSpecialState = Arrays.asList(CA, KS, KY, IN, IA, LA, MA, MD, MN, MS, OH, SD, WA, WY, NV).contains(state);
        boolean isNoChargeState = Arrays.asList(IN, IA, KS, KY, MA, OH, MD, MN, NV, LA, WA, MS).contains(state);
        boolean isSDorWY = Arrays.asList(SD, WY).contains(state);

        String expectedServiceChargeMessage;

        if (fee > 0 && !payInFull) {
            expectedServiceChargeMessage = String.format(
                    "Service charge Your payment method added a $%s service charge.", fee);
        } else if (isSpecialState) {
            if (payInFull && isNoChargeState) {
                expectedServiceChargeMessage = NO_SERVICE_CHARGE_WHEN_PAYING_IN_FULL;
            } else if (payInFull || !isSDorWY) {
                expectedServiceChargeMessage = "No service charges or premium increases when using bank transfer.";
            } else {
                expectedServiceChargeMessage = NO_SERVICE_CHARGE_WHEN_USING_BANK;
            }
        } else {
            expectedServiceChargeMessage = payInFull
                    ? NO_SERVICE_CHARGE_WHEN_PAYING_IN_FULL
                    : NO_SERVICE_CHARGE_WHEN_USING_BANK;
        }

        fsa.assertEquals(getTextFromElement(waitElementBeVisible(chargeDisclaimerText)).replace("info_outline ", EMPTY_STRING), expectedServiceChargeMessage, "Service charge disclaimer text validation for " + commonMessage);
        if (paymentMethod.equals(MONTHLY_AUTOPAY)) {
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyText), "Due monthly", "Due monthly text validation for : " + commonMessage);
            String expectedDueMonthlyAmount = String.format("$%,.2f", Double.parseDouble(getInstallmentAmountFarmers(MONTHLY_EFT)));
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyAmount), expectedDueMonthlyAmount, "Due monthly amount validation for: " + commonMessage);
        } else {
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyText), "Due today", "Due today text validation for: " + commonMessage);
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyAmount), String.format("$%,.2f", Double.parseDouble(dueTodayAmount.replaceAll("[^0-9.]", EMPTY_STRING))), "Due today amount validation for: " + commonMessage);
        }


    }

    private void validateContentOfPaymentCard(String paymentMethod, FarmersSoftAssert fsa) throws Exception {
        VerifyResponse verifyResponse = getAutoVerifyRateResponse();
        String stateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        boolean isKYState = stateCode.equals(KY);
        double policyFee = getPolicyFeesFromAppStore(verifyResponse);
        double fullTermPremiumAmount = getFullTermPremiumPayInFull(verifyResponse);
        double monthlyPayInstallmentAmountForEFT = getMonthlyPayInstallmentAmountMonthlyEft(verifyResponse);
        String paymentCardXpath = getXPathForPaymentMethod(paymentMethod);
        PWElement paymentCardHeader;
        PWElement paymentCardHeaderDescription;
        PWElement paymentCardDescription;
        PWElement paymentCardDollarSign;
        PWElement paymentCardDollarAmount;
        PWElement paymentCardCentAmount;
        PWElement paymentCardGreenCheck;
        PWElement paymentCardSavingMessage;
//        WebElement excludeTaxesFeesSurchargesText;

        if(isUseMobileViewEnabled()){
            paymentCardHeader = driver().findElement(PWBy.xpath(paymentCardXpath));
            paymentCardHeaderDescription = driver().findElement(PWBy.xpath(paymentCardXpath));
            paymentCardDescription = driver().findElement(PWBy.xpath("//div[@class='amount-section']//p"));
            paymentCardDollarSign = driver().findElement(PWBy.xpath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_ONE_DOLLAR_SIGN_XPATH));
            paymentCardDollarAmount = driver().findElement(PWBy.xpath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_TWO_DOLLAR_AMOUNT_XPATH));
            paymentCardCentAmount = driver().findElement(PWBy.xpath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_THREE_CENT_AMOUNT_XPATH));
            paymentCardGreenCheck = driver().findElement(PWBy.xpath(PAYMENT_CARD_GREEN_MARK_XPATH));
            paymentCardSavingMessage = driver().findElement(PWBy.xpath(PAYMENT_CARD_SAVINGS_TEXT_XPATH));
        }else{
            paymentCardHeader = driver().findElement(PWBy.xpath(paymentCardXpath + PAYMENT_CARD_HEADER_XPATH));
            paymentCardHeaderDescription = driver().findElement(PWBy.xpath(paymentCardXpath + PAYMENT_CARD_SUB_HEADER_XPATH));
            paymentCardDescription = driver().findElement(PWBy.xpath(paymentCardXpath + PAYMENT_CARD_PAYMENT_DESCRIPTION_XPATH));
            paymentCardDollarSign = driver().findElement(PWBy.xpath(paymentCardXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_ONE_DOLLAR_SIGN_XPATH));
            paymentCardDollarAmount = driver().findElement(PWBy.xpath(paymentCardXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_TWO_DOLLAR_AMOUNT_XPATH));
            paymentCardCentAmount = driver().findElement(PWBy.xpath(paymentCardXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_THREE_CENT_AMOUNT_XPATH));
            paymentCardGreenCheck = driver().findElement(PWBy.xpath(paymentCardXpath + PAYMENT_CARD_GREEN_MARK_XPATH));
            paymentCardSavingMessage = driver().findElement(PWBy.xpath(paymentCardXpath + PAYMENT_CARD_SAVINGS_TEXT_XPATH));
        }

        boolean isOnePay = paymentMethod.equals(PAY_IN_FULL);
        fsa.assertTrue(getTextFromElement(paymentCardHeader).contains(paymentMethod), "Payment card header validation failed " + paymentMethod);

        String bestValueOrConvenientText = isOnePay ? "Best value" : "Convenient";
        fsa.assertTrue(getTextFromElement(paymentCardHeaderDescription).contains(bestValueOrConvenientText), "Payment card sub header validation failed " + paymentMethod);

        String oneTimePaymentOrTwelveMonthlyPayment = isOnePay ? "One-time payment" : "6 monthly payments";
        fsa.assertTrue(getTextFromElement(paymentCardDescription).contains(oneTimePaymentOrTwelveMonthlyPayment) , "Payment card description validation failed " + paymentMethod);
        String payAmount;
        if (isKYState) {
            PWElement excludeTaxesFeesSurchargesText = isUseMobileViewEnabled() ? driver().findElement(PWBy.xpath(EXCLUDE_FEES_SURCHARGE_TAXES_XPATH)) :
                    driver().findElement(PWBy.xpath(paymentCardXpath + EXCLUDE_FEES_SURCHARGE_TAXES_XPATH));

            payAmount = isOnePay ? getFormattedDecimal(fullTermPremiumAmount) : getFormattedDecimal(monthlyPayInstallmentAmountForEFT);
            fsa.assertTrue(excludeTaxesFeesSurchargesText.isDisplayed(), EXCLUDE_FEES_SURCHARGE_TAXES + " text is displayed for " + paymentMethod);
        }else{
            payAmount = isOnePay ? getFormattedDecimal(fullTermPremiumAmount + policyFee) : getFormattedDecimal(monthlyPayInstallmentAmountForEFT);
        }
        String expectedAmount = String.format("$%s", payAmount);
        String actualAmount = EMPTY_STRING + getTextFromElement(paymentCardDollarSign) + getTextFromElement(paymentCardDollarAmount) + getTextFromElement(paymentCardCentAmount);
        fsa.assertEquals(actualAmount, expectedAmount, "Displayed amount the in payment card is not matching for " + paymentMethod);

        fsa.assertTrue(paymentCardGreenCheck.isDisplayed(), "Green check is displayed " + paymentMethod);
        String expectedSavingMessage = isOnePay ? "Preferred payment plan savings" : "Autopay savings";
        fsa.assertEquals(getTextFromElement(paymentCardSavingMessage), expectedSavingMessage, "Saving message in the payment card for " + paymentMethod);

        if(stateCode.equals(CA)) {
            PWElement caPaymentMethodText = driver().findElement(PWBy.xpath(paymentCardXpath + CA_STATE_PAYMENT_METHOD_TEXT_XPATH));
            String expectedCAPaymentMethodText = isOnePay ? "monetization_on Bank, debit or credit card accepted" : "monetization_on Bank payment only";
            if(isSafariBrowser()) {
                // remove space for Safari
                expectedCAPaymentMethodText = expectedCAPaymentMethodText.replace("monetization_on ", "monetization_on");
            }
            fsa.assertEquals(getTextFromElement(caPaymentMethodText), expectedCAPaymentMethodText, "Saving method text for CA state in the payment card for " + paymentMethod);
        }
        testStep("Payment card content validation for : " + paymentMethod);

    }

    private void validateDiscountSection(FarmersSoftAssert fsa) throws Exception {

        String actualDiscountSectionTitle = isUseMobileViewEnabled() ? getTextFromElement(discountTitleMobile) : getTextFromElement(discountTitle);
        fsa.assertEquals(actualDiscountSectionTitle, "Discounts included", "Discount section title validation");

        List<String> expectedDiscounts = getAutoVerifyRateResponse().getDiscounts().stream()
                .filter(each -> !each.getName().contains("Autopay") && !each.getName().contains("Preferred") && !each.getName().contains("Vehicle History Factor"))
                .map(AppStore.VerifyResponse.Discount::getName)
                .map(each -> each.replaceAll("(?i)discount", EMPTY_STRING).trim())
                .collect(Collectors.toList());

        driver().findElements(PWBy.xpath("//div[contains(@class,'discount-item')]//mat-icon")).forEach(each -> {
            fsa.assertTrue(each.isDisplayed(), "Green checkbox is displayed for given discount: " + getTextFromElement(each));
        });
        fsa.assertEquals(getDiscountNames(), expectedDiscounts, "Discounts verification");

        testStep("Validate discounts against the appstore on the " + this.getClass().getSimpleName());
    }

    private void validateMonthlyAutopayPaymentSection(FarmersSoftAssert fsa) throws Exception {
        String landingStateCode = getStateCodeFromAppStore();
        String commonMessage = "Monthly autopay payment section : ";
        selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
        VerifyResponse verifyResponse = getAutoVerifyRateResponse();
        PaymentSchedule mtef = verifyResponse.getPaymentSchedules().stream().filter(each -> each.getPayPlanCode().equals("MTEF")).findFirst().get();
        double downPaymentMTEF = Double.parseDouble(mtef.getDownPayment().getAmount().getAmount());
        double policyFee = getPolicyFeesFromAppStore(verifyResponse);
        if(landingStateCode.equals(KY)) {
            policyFee += getTotalSpreadFeeAmount(verifyResponse, MONTHLY_EFT);
        }
        double expectedDueTodayAmount = downPaymentMTEF + policyFee;
        String expectedFirstMonthlyAmount = String.format("$%s", getFormattedDecimal(downPaymentMTEF));
        fsa.assertEquals(getTextFromElement(monthlyAutoPaySectionHeader), MONTHLY_AUTOPAY, commonMessage + "header validation");
        fsa.assertEquals(getTextFromElement(firstMonthlyPaymentText), "First monthly payment", commonMessage + "first monthly payment text validation");
        fsa.assertEquals(getTextFromElement(firstMonthlyPaymentAmount), expectedFirstMonthlyAmount, commonMessage + "first monthly payment amount validation");

        if (!landingStateCode.equals(KS)) {
            fsa.assertTrue(getTextFromElement(monthlyPayOneTimeFeeText).contains(ONE_TIME_FEE), commonMessage + "fee label validation. Actual text: " + getTextFromElement(monthlyPayOneTimeFeeText));
            fsa.assertEquals(getTextFromElement(monthlyPayFeeAmountAuto), String.format("$%s", getFormattedDecimal(policyFee)), commonMessage + "fee amount validation");
        }

        double totalInstallmentAmount = mtef.getInstallments().stream().mapToDouble(each -> Double.parseDouble(each.getCurrencyAmount())).sum();
        double totalSixTermPrice = totalInstallmentAmount + downPaymentMTEF;
        String expectedTotalText = String.format("$%s for 6-month term price", getFormattedDecimal(totalSixTermPrice));
        if (landingStateCode.equals(KY)) {
            Double surchargeTax = getSurchargeTaxes(mtef);
            fsa.assertTrue(getTextFromElement(monthlyPayOneTimeFeeText).contains(ONE_TIME_FEE), commonMessage + "fee label validation. Actual text: " + getTextFromElement(monthlyPayOneTimeFeeText));
            fsa.assertEquals(getTextFromElement(monthlyPayFeeAmountAuto), String.format("$%s", getFormattedDecimal(policyFee)), commonMessage + "fee amount validation");
            fsa.assertTrue(getTextFromElement(monthlyPaySurchargeText).contains("Taxes and surcharges"), commonMessage + " taxes and surcharges text validation");
            fsa.assertEquals(getTextFromElement(monthlyPaySurchargeAmount), String.format("$%s", getFormattedDecimal(surchargeTax)), commonMessage + " taxes and surcharges amount validation");
            expectedTotalText = String.format("$%s for 6-month term price (excludes taxes, fees, & surcharges)", getFormattedDecimal(totalSixTermPrice));
            expectedDueTodayAmount += surchargeTax;
        }
        fsa.assertEquals(getTextFromElement(dueTodayLabel), "Due today", commonMessage + "due today label validation");
        fsa.assertEquals(getTextFromElement(dueTodayAmount), String.format("$%s", getFormattedDecimal(expectedDueTodayAmount)), commonMessage + "due today amount validation");

        fsa.assertEquals(getTextFromElement(monthlyAutoPayTotalHeader), expectedTotalText, commonMessage + "6  month term price title validation");
        fsa.assertEquals(getTextFromElement(viewBreakDownLink), VIEW_BREAKDOWN, commonMessage + "View breakdown link label validation");
        waitAndClickElement(viewBreakDownLink);
        sleep(1);
        fsa.assertEquals(getTextFromElement(viewBreakDownLink), VIEW_LESS, commonMessage + "View less should be displayed after extension");

        List<String> expectedMonthByMonthInstallmentsText = Arrays.asList("Second monthly payment", "Third monthly payment", "Fourth monthly payment", "Fifth monthly payment", "Sixth monthly payment");
        List<String> actualMonthByMonthInstallmentsText = monthByMonthInstallmentsTexts.stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(actualMonthByMonthInstallmentsText, expectedMonthByMonthInstallmentsText, commonMessage + " view break down month by month installment texts");

        List<String> expectedMonthByMonthInstallmentsAmounts = mtef.getInstallments().stream().map(each -> String.format("$%s", getFormattedDecimal(Double.parseDouble(each.getCurrencyAmount())))).collect(Collectors.toList());

        List<String> actualMonthByMonthInstallmentsAmounts = monthByMonthInstallmentsAmounts.stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(actualMonthByMonthInstallmentsAmounts, expectedMonthByMonthInstallmentsAmounts, commonMessage + " view break down month by month installment amounts validation");

        fsa.assertEquals(getTextFromElement(monthlyAutopayBottomTotalTermPriceText), SIX_MONTH_TERM_PRICE, commonMessage + "Bottom total price text validation");
        fsa.assertEquals(getTextFromElement(monthlyAutopayBottomTotalTermPriceAmount), String.format("$%s", getFormattedDecimal(totalSixTermPrice)), commonMessage + "Bottom total price amount validation");
        //close breakdown section
        waitAndClickElement(viewBreakDownLink);
        sleep(1);
        fsa.assertTrue(monthByMonthInstallmentsAmounts.isEmpty(), commonMessage + "installment details should not be visible when View less clicked");
        fsa.assertEquals(getTextFromElement(viewBreakDownLink), VIEW_BREAKDOWN, commonMessage + "installment details should not be visible when View less clicked");
        testStep("Validate monthly payment section");
    }

    private void validatePayInFullPaymentSection(FarmersSoftAssert fsa) throws Exception {
        // Extracted common values
        String commonMessage = "Pay in full payment section : ";
        String landingStateCode = getStateCodeFromAppStore();
        VerifyResponse verifyResponse = getAutoVerifyRateResponse();
        PaymentSchedule pif = verifyResponse.getPaymentSchedules().stream().filter(each -> each.getPayPlan().equals("A1")).findFirst().get();
        double unformattedFullTermPremium = Double.parseDouble(pif.getFullTermPremium());
        double unformattedPolicyFeeAmount = getPolicyFeesFromAppStore(verifyResponse);
        String expectedSixMonthFullTermPremium = "$" + getFormattedDecimal(unformattedFullTermPremium);
        String expectedOneTimeFeeAmount = "$" + getFormattedDecimal(landingStateCode.equals(KY) ? unformattedPolicyFeeAmount + getTotalSpreadFeeAmount(verifyResponse, ONE_PAY) : unformattedPolicyFeeAmount);
        double dueTodayAmount = unformattedFullTermPremium + unformattedPolicyFeeAmount;
        if (landingStateCode.equals(KY)) {
            dueTodayAmount += getTotalSpreadFeeAmount(verifyResponse, ONE_PAY);
        }
        //make sure selecting one pay to validate one pay section
        selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
        fsa.assertEquals(getTextFromElement(payInFullPaySectionHeader), PAY_IN_FULL, commonMessage + "header text validation");
        fsa.assertEquals(getTextFromElement(payInFullSixMonthTermPriceText), SIX_MONTH_TERM_PRICE, commonMessage + "6 month term price text");
        fsa.assertEquals(getTextFromElement(payInFullSixMonthTermPriceAmount), expectedSixMonthFullTermPremium, commonMessage + "6 month term price amount");
        //Fee section is not applicaple for KS state
        if (!landingStateCode.equals(KS)) {
            fsa.assertTrue(getTextFromElement(payInFullOneTimeFeesText).contains(ONE_TIME_FEE), commonMessage + " one time fee text validation");
            fsa.assertEquals(getTextFromElement(payInFullOneTimeFeesAmount), expectedOneTimeFeeAmount, commonMessage + " one time fee amount validation");
        }

        String payInFullBottomPaymentDetailsText = String.format("$%s for 6-month term price", getFormattedDecimal(dueTodayAmount));
        // Handle state-specific logic for taxes and surcharges
        if(landingStateCode.equals(KY)) {
            double surchargeTaxes = getSurchargeTaxes(pif);
            fsa.assertTrue(getTextFromElement(payInFullTaxesAndSurchargeText).contains("Taxes and surcharges"), commonMessage + " taxes and surcharges text validation");
            fsa.assertEquals(getTextFromElement(payInFullTaxesAndSurchargeAmount), String.format("$%s", getFormattedDecimal(surchargeTaxes)), commonMessage + " taxes and surcharges amount validation");
            dueTodayAmount += surchargeTaxes;
            payInFullBottomPaymentDetailsText = String.format("$%s for 6-month term price (includes taxes, fees, & surcharges)", getFormattedDecimal(dueTodayAmount));
        }
        // Final validations for due today and bottom payment details
        fsa.assertEquals(getTextFromElement(payInFullDueTodayText), "Due today", commonMessage + " due today text/label validation");
        fsa.assertEquals(getTextFromElement(payInFullDueTodayAmount), String.format("$%s", getFormattedDecimal(dueTodayAmount)), commonMessage + " due today amount validation");
        fsa.assertEquals(getTextFromElement(payInFullBottomPaymentDetails), payInFullBottomPaymentDetailsText, commonMessage + " bottom total amount validation");
    }

    public void validateFeeInfoSection(FarmersSoftAssert fsa) throws Exception {
        if(isUseMobileViewEnabled()){
            feeInfoIcon = feeInfoIconMobileView;
            feeInfoBoxHeader = feeInfoBoxHeaderMobileView;
            feeInfoBoxDescription = feeInfoBoxDescriptionMobileView;
            clickFeesInfoIconMobileView();
        }
        String landingStateCode = getStateCodeFromAppStore();
        if (landingStateCode.equals(KS)) {
            fsa.assertFalse(isElementVisible(feeInfoBoxHeader, 1), "Fee section should not be visible for KS state");
            return;
        }
        String commonMessage = "Fee info section : ";
        fsa.assertEquals(getTextFromElement(feeInfoBoxHeader), ONE_TIME_FEE, commonMessage + "header validation");
        String expectedFeeDescription = null;
        if (isRequiredMembershipFees(landingStateCode)) {
            expectedFeeDescription = AUTO_MEMBERSHIP_FEE_MESSAGE;
        } else if (isRequiredVehicleFees(landingStateCode)) {
            if (!getAutoVerifyRateResponse().getPolicyFee().getAmount().equals("0.00")) {
                expectedFeeDescription = VEHICLE_FEE_MESSAGE;
            }
        } else {
            expectedFeeDescription = POLICY_POLICY_FEE_MESSAGE;
        }
        fsa.assertEquals(getTextFromElement(feeInfoBoxDescription), expectedFeeDescription, commonMessage + "description validation");
        if(isUseMobileViewEnabled()){
            waitAndClickElement(closeIcon);
        }
        fsa.assertTrue(feeInfoIcon.isDisplayed(), commonMessage + "info icon is displayed");
    }

    protected void validatePreferredPaymentMethodSection(String paymentMethod, FarmersSoftAssert fsa) throws Exception {
        selectPaymentMethodFromPaymentCards(paymentMethod);
        boolean isCAState = getSessionStorageAppStore().getData().getLandingStateCode().equals(CA);
        String commonMessage = paymentMethod + " Preferred payment method section ";
        fsa.assertEquals(getTextFromElement(paymentMethodSelectionHeader), SELECT_YOUR_PREFERRED_PAYMENT_METHOD, commonMessage + "header validation");
        fsa.assertEquals(getTextFromElement(paymentSelectionBankPaymentRadioButton), BANK_PAYMENT, commonMessage + "bank payment radio button label");
        fsa.assertEquals(getTextFromElement(paymentSelectionCardRadioButton), CARD, commonMessage + "card payment radio button label");
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        if (paymentMethod.equals(MONTHLY_AUTOPAY)) {
            PWElement cardPaymentServiceChargeElement = isCAState ? californiaCardPaymentServiceChargesText : bankCardPaymentServiceChargesText.get(1);
            int expectedMonthlyPayDebitCardAdministrativeFee;
            int expectedMonthlyPayCreditCardAdministrativeFee;
            String serviceCharges = "";
            if(!isCAState) {
                expectedMonthlyPayDebitCardAdministrativeFee = getAdministrativeFeeForGivenPayPlanDescription(paymentSchedules, MONTHLY_DEBIT_CREDIT_CARD); // before we used to pass 'MONTHLY_DEBIT_CARD_DESCRIPTION', but now paymentus is taking Debit as credit, thus this change is needed
                expectedMonthlyPayCreditCardAdministrativeFee = getAdministrativeFeeForGivenPayPlanDescription(paymentSchedules, MONTHLY_DEBIT_CREDIT_CARD);
                if ((expectedMonthlyPayDebitCardAdministrativeFee == 0) && (expectedMonthlyPayCreditCardAdministrativeFee == 0)) {
                    serviceCharges = "$0 in service charges";
                } else {
                    serviceCharges = String.format("$%s - $%s in service charges", expectedMonthlyPayDebitCardAdministrativeFee, expectedMonthlyPayCreditCardAdministrativeFee);
                    if (expectedMonthlyPayDebitCardAdministrativeFee == expectedMonthlyPayCreditCardAdministrativeFee) {
                        serviceCharges = String.format("$%s in service charges", expectedMonthlyPayDebitCardAdministrativeFee);
                    }
                }
                fsa.assertEquals(getTextFromElement(cardPaymentServiceChargeElement), serviceCharges, commonMessage + "card payment radio button label card service charges");
            } else {
                fsa.assertTrue(isElementVisible(californiaCardPaymentRadioButton, 1),"Card radio button for monthly auto pay in CA state");
                fsa.assertEquals(getTextFromElement(californiaCardNotAvailableMonthlyPayMessage),
                        "(Not available for monthly autopay)", commonMessage + "CA Card not available message");
                fsa.assertEquals(getTextFromElement(cardPaymentServiceChargeElement), "$2 - $5 in service charges", commonMessage + "card payment radio button label bank service charges");
            }

            if (getSessionStorageAppStore().getData().getLandingStateCode().equals(KS)) {
                fsa.assertEquals(getTextFromElement(usingCardIncreaseMessage), "Using a card? Your cost may increase.", "Card usage increase premium message for " + commonMessage);
            }
        }
    }

    private void validateConsolidatePageDisclaimers(FarmersSoftAssert fsa) throws Exception {
        String commonMessage = "Consolidated payment page disclaimer validation: ";
        fsa.assertEquals(getTextFromElement(disclaimerHeaderText), "By clicking \"Complete purchase\" below:", commonMessage + "header");
        fsa.assertEquals(getTextFromElement(disclaimerContentBulletPointOne), "I confirm that I have read and agree to the Paperless Terms of Use; and", commonMessage + "bullet one, paperless terms of use");
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        String expectedIConfirmText = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate One-Time and Automatic Payment processes.";
        if (isFlexState(landingStateCode)) {
            fsa.assertEquals(getTextFromElement(disclaimerContentBulletPointTwo), expectedIConfirmText, commonMessage + "bullet two, payment method discount");
        } else {
            selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
            if (Arrays.asList(CA, KS, KY, IA, IN, MA, MD, MN, MS, NV, OH, WA).contains(landingStateCode)) {
                fsa.assertEquals(getTextFromElement(disclaimerContentBulletPointTwo), expectedIConfirmText, commonMessage + "bullet two, payment method discount");
            } else {
                fsa.assertEquals(getTextFromElement(disclaimerContentBulletPointTwo), "I understand that I may be eligible for a lower premium by agreeing to use a payment method other than a credit card, and that if I want to use a credit card at a later time my policy will be re-rated, which may result in a higher premium; and", commonMessage + "bullet two, payment method discount");
                fsa.assertEquals(getTextFromElement(disclaimerContentBulletPointThree), expectedIConfirmText, commonMessage + "bullet three, information storage and payment authorization text");
            }
            selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
            scrollElementToMiddle(recurringPaymentsRadioButton);
            fsa.assertEquals(getTextFromElement(recurringPaymentsRadioButton), "A one-time payment and automatic recurring payments.", "Recurring payment text validation for " + commonMessage);

            fsa.assertEquals(getTextFromElement(oneTimePaymentRadioButton), "A one-time payment only.", "One time payment only text validation for " + commonMessage);

            fsa.assertTrue(getAttributeData(recurringPaymentsRadioButton, CLASS).contains(CHECKED), "Recurring payment option should be selected by default for " + commonMessage);
        }
        scrollElementToMiddle(termsAndConditionsDisclaimer);
        fsa.assertEquals(getTextFromElement(termsAndConditionsDisclaimer), IF_DO_NOT_AGREE_WITH_TERMS, "termsAndConditionsDisclaimer verification" );
        fsa.assertTrue(completePurchaseButton.getLocation().getY() < termsAndConditionsDisclaimer.getLocation().getY() , "Complete purchase button placed higher than final disclaimer");
    }

    private void validateBankToCardPaymentChange(FarmersSoftAssert fsa, String paymentMethod) throws Exception {
        boolean isCAState = getSessionStorageAppStore().getData().getLandingStateCode().equals(CA);
        boolean isUTState = getSessionStorageAppStore().getData().getLandingStateCode().equals(UT);
        if(isUTState && paymentMethod.equals(MONTHLY_AUTOPAY) && !availablePaymentOptions.stream().map(this::getTextFromElement).collect(Collectors.toList()).contains(paymentMethod)) {
            Log.info("Monthly auto pay is not available for UT state");
            return;
        }
        String commonMessage = " validation of Bank to Card payment change with " + paymentMethod;
        selectPaymentMethodFromPaymentCards(paymentMethod);
        if(isElementVisible(bankPaymentRadioButtonLabel, 1)) {
            clickBankPaymentRadioButton();
        } else {
            clickChangeLink();
        }

        // add bank account details validate validate afterwards
        List<String> bankAccounts = new ArrayList<>(Arrays.asList(PaymentMethods.BANK_ACCOUNT_1.getAccountNumber(), PaymentMethods.BANK_ACCOUNT_2.getAccountNumber(), PaymentMethods.BANK_ACCOUNT_3.getAccountNumber(), PaymentMethods.BANK_ACCOUNT_4.getAccountNumber(), PaymentMethods.BANK_ACCOUNT_5.getAccountNumber()));
        Collections.shuffle(bankAccounts);
        switchToBankPaymentToggleInPaymentSideSheet();
        String bankAccountRoutingNumber = bankAccounts.get(0);
        String accountNumber = RandomStringUtils.randomNumeric(6);
        addCheckingAccountPaymentMethod(bankAccountRoutingNumber, accountNumber);
        //validations
        scrollToElement(waitElementBeVisible(bankAccountAddedMessage));
        fsa.assertTrue(bankAccountAddedMessage.isDisplayed(), "Bank account is added message is displayed for " + commonMessage);
        fsa.assertTrue(paymentAddedGreenCheck.isDisplayed(), "Green check icon is displayed for  : " + commonMessage);
        fsa.assertTrue(addedPaymentMethodIconCard.isDisplayed(), "Bank icon should be displayed after bank payment addition : " + commonMessage);
        fsa.assertTrue(maskedAddedPaymentDetails.isDisplayed(), "Bank account number (masked) should be displayed after bank payment addition : " + commonMessage);
        isHiddenBankAccountMonthlyPayTextCorrect(fsa, accountNumber);
        fsa.assertTrue(isElementDisplayed(addedBankIcon, 4), "Bank icon should be visible for " + commonMessage);

        if(isCAState && paymentMethod.equals(MONTHLY_AUTOPAY)) {
            Log.info("Card radio button is not enabled for Monthly auto pay");
            return;
        }
        // change payment method to a card
        clickChangeLink();
        fsa.assertTrue(isEditPaymentMethodLabelCorrect(), "Edit payment message is correct for " + commonMessage);
        if (isElementVisible(debitCreditCardButton, 2)) {
            clickDebitCreditCardButton();
        } else {
            clickCardButton();
        }
        List<String> cardNumbers = new ArrayList<>(Arrays.asList(PaymentMethods.VISA_DEBIT_CARD_1.getAccountNumber(), PaymentMethods.AMEX_CREDIT_CARD_1.getAccountNumber(), PaymentMethods.DISCOVER_CREDIT_CARD_1.getAccountNumber(), PaymentMethods.MASTERCARD_CREDIT_CARD_1.getAccountNumber(), PaymentMethods.VISA_CREDIT_CARD_2.getAccountNumber()));
        Collections.shuffle(cardNumbers);
        String cardNumber = cardNumbers.get(0);
        addCardPaymentMethod(cardNumber, ZIP_CODE);
        scrollToElement(waitElementBeVisible(paymentAddedGreenCheck));
        if (cardNumber.equals(PaymentMethods.VISA_DEBIT_CARD_1.getAccountNumber())) {
            fsa.assertTrue(getTextFromElement(waitElementBeVisible(debitCardAddedMessage)).contains(" card added"), "Debit card added message for : " + commonMessage);
        } else {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(creditCardAddedMessage)), "Credit card added.", "Credit card added message for : " + commonMessage);
        }
        validateAddedPaymentMethodIconsForCards(cardNumber, fsa);
        fsa.assertTrue(paymentAddedGreenCheck.isDisplayed(), "Green check is displayed for : " + commonMessage);
        //amex credit cards has 15 digits while other has 16 digits
        int startIndex = cardNumber.equals(AMERICAN_EXPRESS_CARD) ? 11 : 12;
        String expectedMaskedPaymentMethod = String.format("%s | Exp %s", cardNumber.substring(startIndex), EXP_DATE);
        fsa.assertEquals(getTextFromElement(maskedAddedPaymentDetails), expectedMaskedPaymentMethod, "Masked credit card details validation for : " + commonMessage);

    }

    private void validateCardToBankPaymentChange(FarmersSoftAssert fsa, String paymentMethod) throws Exception {
        String commonMessage = " payment method change from card to bank";
        driver().navigate().refresh();

        boolean isUTState = getSessionStorageAppStore().getData().getLandingStateCode().equals(UT);
        if(isUTState && paymentMethod.equals(MONTHLY_AUTOPAY)) {
            Log.info("Monthly auto pay is not available for UT state");
            return;
        }
        selectPaymentMethodFromPaymentCards(paymentMethod);
        boolean is_CA_State = getSessionStorageAppStore().getData().getLandingStateCode().equals(CA);
        if(is_CA_State && paymentMethod.equals(MONTHLY_AUTOPAY)) {
            Log.info("Card radio button is not enabled for Monthly auto pay");
            return;
        }
        if (isElementVisible(changeLink, 1)) {
            clickChangeLink();
            if (isElementVisible(debitCreditCardButton, 2)) {
                clickDebitCreditCardButton();
            } else {
                clickCardButton();
            }
        } else {
            clickCardRadioButton();
        }

        // add card number and validations
        List<String> cardNumbers = new ArrayList<>(Arrays.asList(PaymentMethods.VISA_DEBIT_CARD_1.getAccountNumber(), PaymentMethods.AMEX_CREDIT_CARD_1.getAccountNumber(), PaymentMethods.DISCOVER_CREDIT_CARD_1.getAccountNumber(), PaymentMethods.MASTERCARD_CREDIT_CARD_1.getAccountNumber()));
        Collections.shuffle(cardNumbers);
        String cardNumber = cardNumbers.get(0);
        addCardPaymentMethod(cardNumber, ZIP_CODE);
        scrollToElement(waitElementBeVisible(paymentAddedGreenCheck));
        if (cardNumber.equals(PaymentMethods.VISA_DEBIT_CARD_1.getAccountNumber())) {
            fsa.assertTrue(getTextFromElement(debitCardAddedMessage).contains(" card added."), "Debit card added message for : " + commonMessage);
        } else {
            fsa.assertEquals(getTextFromElement(creditCardAddedMessage), "Credit card added.", "Credit card added message for : " + commonMessage);
        }
        validateAddedPaymentMethodIconsForCards(cardNumber, fsa);
        fsa.assertTrue(paymentAddedGreenCheck.isDisplayed(), "Green check is displayed for : " + commonMessage);
        //amex credit cards has 15 digits while other has 16 digits
        int startIndex = cardNumber.equals(AMERICAN_EXPRESS_CARD) ? 11 : 12;
        String expectedMaskedPaymentMethod = String.format("%s | Exp %s", cardNumber.substring(startIndex), EXP_DATE);
        fsa.assertEquals(getTextFromElement(maskedAddedPaymentDetails), expectedMaskedPaymentMethod, "Masked credit card details validation for : " + commonMessage);

        // change to bank
        clickChangeLink();
        fsa.assertTrue(isEditPaymentMethodLabelCorrect(), "Edit payment message is correct for " + commonMessage);
        switchToBankPaymentToggleInPaymentSideSheet();
        // add bank account details validate validate afterwards
        List<String> bankAccounts = new ArrayList<>(Arrays.asList(PaymentMethods.BANK_ACCOUNT_1.getAccountNumber(), PaymentMethods.BANK_ACCOUNT_2.getAccountNumber(), PaymentMethods.BANK_ACCOUNT_3.getAccountNumber(), PaymentMethods.BANK_ACCOUNT_4.getAccountNumber(), PaymentMethods.BANK_ACCOUNT_5.getAccountNumber()));
        Collections.shuffle(bankAccounts);
        String bankAccountRoutingNumber = bankAccounts.get(0);
        String accountNumber = RandomStringUtils.randomNumeric(6);
        addCheckingAccountPaymentMethod(bankAccountRoutingNumber, accountNumber);
        //validations
        scrollToElement(waitElementBeVisible(bankAccountAddedMessage));
        fsa.assertTrue(bankAccountAddedMessage.isDisplayed(), "Bank account is added message is displayed for " + commonMessage);
        fsa.assertTrue(paymentAddedGreenCheck.isDisplayed(), "Green check icon is displayed for  : " + commonMessage);
        fsa.assertTrue(addedPaymentMethodIconCard.isDisplayed(), "Bank icon should be displayed after bank payment addition : " + commonMessage);
        fsa.assertTrue(maskedAddedPaymentDetails.isDisplayed(), "Bank account number (masked) should be displayed after bank payment addition : " + commonMessage);
        isHiddenBankAccountMonthlyPayTextCorrect(fsa, accountNumber);
        fsa.assertTrue(isElementDisplayed(addedBankIcon, 4), "Bank icon should be visible for " + commonMessage);

    }

    public void validateAddedPaymentMethodIconsForCards(String cardNumber, FarmersSoftAssert fsa) throws Exception {

        String locatorAdjuster = null;

        switch (cardNumber) {
            case "4444424444444440":
            case "4444444444444448":
            case "4111111111111111":
            case "4400000000000008":
            case "4852464911331840":
                locatorAdjuster = "visa";
                break;
            case "371449635398431":
                locatorAdjuster = "amex";
                break;
            case "6011000000000012":
            case "6011000995500000":
            case "6011111111111117":
                locatorAdjuster = "discover";
                break;
            case "5454545454545454":
            case "5555555555554444":
                locatorAdjuster = "mastercard";
                break;

            default:
                Log.error("Please provide a valid card number to this method");

        }
        scrollElementToTop(waitElementBeVisible(paymentAddedGreenCheck));
        PWElement icon = driver().findElement(PWBy.xpath(String.format("//*[contains(@src,'%s')]", locatorAdjuster)));

        fsa.assertTrue(icon.isDisplayed(), "Icon is displayed for " + locatorAdjuster + " card type");

    }

    private String getDueTodayAmountForOnePay() throws Exception {
        VerifyResponse verifyResponse = getAutoVerifyRateResponse();
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        AppStore.VerifyResponse.PaymentSchedule onePay = verifyResponse.getPaymentSchedules().stream().filter(each -> each.getPayPlan().equals("A1")).findFirst().get();
        double polFee = getPolicyFeesFromAppStore(verifyResponse);
        double fullTermPremium = Double.parseDouble(onePay.getFullTermPremium());
        double stateTax = Double.parseDouble(onePay.getStateTax() != null ? onePay.getStateTax() : "0.00");
        double dueToday = polFee + fullTermPremium + stateTax;
        if(landingStateCode.equals(KY)) {
            // add County and Fee Surcharge for KY state
            dueToday += getTotalSpreadFeeAmount(verifyResponse, ONE_PAY);
        }
        return getFormattedDecimal(dueToday);
    }

    public List<String> getDiscountNames() throws Exception {
        // locator help based on the browser resolution size
        // strip the word "discount" (case-insensitive) from each name and trim any leftover whitespace
        return driver().findElements(PWBy.xpath("//div[contains(@class,'discount-item')]//span")).stream()
                .map(this::getTextFromElement)
                .map(name -> name.replaceAll("(?i)discount", "").trim()) // remove the discount word from the discount name and trim the whitespace
                .collect(Collectors.toList());
    }

    public void checkDefensiveOrMatureDriverDiscountOnConsolidatedPaymentPage(FarmersSoftAssert fsa, boolean isDefensiveDriverDiscountEnabled) throws Exception {
        String expectedDiscountName = isDefensiveDriverDiscountEnabled ? DEFENSIVE_DRIVER : MATURE_DRIVER;
        List<String> displayedDiscountNames = getDiscountNames();
        fsa.assertTrue(displayedDiscountNames.contains(expectedDiscountName), expectedDiscountName + " discount is present on the consolidated payment page");
    }

    public void checkDriverImprovementDiscountOnConsolidatedPaymentPage(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(getDiscountNames().contains(DRIVER_IMPROVEMENT), DRIVER_IMPROVEMENT + " discount is present on the consolidated payment page");
    }
    /**
     * @param paymentMethod - Please provide accepted payment method
     * @return
     * @throws Exception
     */
    protected String getXPathForPaymentMethod(String paymentMethod) throws Exception {
        if (isUseMobileViewEnabled()) {
            String mobileTabXpath = String.format("//mat-tab-header//*[@role='tab' and contains(.,'%s')]", paymentMethod);
            PWElement mobileTabElement = driver().findElement(PWBy.xpath(mobileTabXpath));
            if (!getAttributeData(mobileTabElement, CLASS).contains("mdc-tab--active")) {
                scrollAndClickOnElement(mobileTabElement);
            }
            return mobileTabXpath;
        } else {
            return String.format(PAYMENT_CARD__XPATH, paymentMethod);
        }
    }

    public void selectPaymentMethodFromPaymentCards(String paymentMethod) throws Exception {
        isOnConsolidatedPaymentPage();
        List<String> availablePaymentOptions = this.availablePaymentOptions.stream().map(this::getTextFromElement).collect(Collectors.toList());
        // Example: availablePaymentOptions = [Pay in full $108.00, Monthly Autopay Convenient]
        String finalPaymentMethod = paymentMethod;
        boolean hasPaymentMethod = availablePaymentOptions.stream().anyMatch(option -> option.startsWith(finalPaymentMethod));
        if(!hasPaymentMethod) {
            paymentMethod = availablePaymentOptions.get(0);
            Log.info(String.format("Provided payment method (%s) is not available, hence selecting the first available payment method : %s", paymentMethod, availablePaymentOptions.get(0)));
            paymentMethod = availablePaymentOptions.get(0);
        }
        if (isUseMobileViewEnabled()) {
            getXPathForPaymentMethod(paymentMethod);
        } else {
            if (paymentMethod.equals(PAY_IN_FULL)) {
            	scrollAndClickOnElement(payInFullRadioButtonLabel);
                sleep(1);
                waitForSpinnerToBeGone();
                if(!doesAttributeContainText(payInFullRadioButton, CLASS, MAT_MDC_RADIO_CHECKED)) {
                    Log.info("Pay in full radio button is not selected, clicking again");
                    waitAndClickElement(payInFullRadioButtonLabel);
                }
            } else {
                waitAndClickElement(monthlyAutoPayRadioButtonLabel);
                sleep(1);
                waitForSpinnerToBeGone();
                if(!doesAttributeContainText(monthlyAutoPayRadioButton, CLASS, MAT_MDC_RADIO_CHECKED)) {
                    Log.info("Monthly autopay radio button is not selected, clicking again");
                    waitAndClickElement(monthlyAutoPayRadioButtonLabel);
                }
            }
        }
    }

    public void validatePremiumChangeMessage(FarmersSoftAssert fsa) throws Exception {
        AppStore sessionStorageAppStore = getSessionStorageAppStore();
        String stateCode = sessionStorageAppStore.getData().getLandingStateCode();
        // NV state has only one pay plan and message is different

        if (!isElementVisible(changeYourCoverageLink, 1)) {
            return;
        }

        String commonRateDecreaseMessage = "Great news! Your rate decreased based on third-party information and information you provided.";
        String commonRateDecreaseMessage2 = "Great news! Your rate decreased based on third-party information and information you provided. If you'd like, you can change your coverage options.";
        String commonRateMayHaveChangedMessage = "Based on third-party information and information you provided, your rate may have changed from our initial quote.";
        String commonRateMayHaveChangedMessage2 = "Based on third-party information and information you provided, your rate may have changed from our initial quote. If you'd like, you can change your coverage options.";

        if(stateCode.equals(NV)) {
            double pifAmountOnTheQuoteSummaryPage = Double.parseDouble(sessionStorageAppStore.getAuto().getQuote().getPif().getTotalPremiumAmount());
            double pifAmountOnThePaymentPage = Double.parseDouble(getAutoVerifyRateResponse().getPaymentSchedules().stream().filter(paymentSchedule -> paymentSchedule.getPayPlan().equals("A1")).findFirst().get().getFullTermPremium());
            if (pifAmountOnTheQuoteSummaryPage > pifAmountOnThePaymentPage) {
                fsa.assertEquals(getTextFromElement(rateAdjustmentMessage), commonRateDecreaseMessage, "Rate adjustment message message validation for increase - " + stateCode);
            } else {
                fsa.assertEquals(getTextFromElement(rateAdjustmentMessage), commonRateMayHaveChangedMessage,
                        "Rate adjustment message message validation for increase - " + stateCode);
            }
        } else {
            double monthlyPaymentAmountInTheQuoteSummaryPage = Double.parseDouble(sessionStorageAppStore.getAuto().getQuote().getEft().getTotalPremiumAmount()) / 6.00;
            double monthlyInstallmentAmountInPaymentPage = Double.parseDouble(getAutoVerifyRateResponse().getPaymentSchedules().stream().filter(paymentSchedule -> paymentSchedule.getPayPlanCode().equals("MTEF")).findFirst().get().getDownPayment().getAmount().getAmount());

            if (monthlyInstallmentAmountInPaymentPage > monthlyPaymentAmountInTheQuoteSummaryPage) {

                fsa.assertTrue(List.of(commonRateMayHaveChangedMessage, commonRateMayHaveChangedMessage2).contains(getTextFromElement(rateAdjustmentMessage)),
                        "Rate adjustment message message validation for increase. Actual message: " + getTextFromElement(rateAdjustmentMessage));

                clickChangeYourCoverageLink();
                QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
                fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the Quote summary page after clicking change your coverage options link");
                quoteSummaryAutoPage.clickOnStartCheckoutButton();
                AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
                additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();
                waitForSpinnerToBeGone();

                fsa.assertTrue(isOnConsolidatedPaymentPage(), "User is on the " + this.getClass().getSimpleName() + ", second time after going back to the Quote summary page");

            } else if (monthlyPaymentAmountInTheQuoteSummaryPage > monthlyInstallmentAmountInPaymentPage) {
                fsa.assertTrue(List.of(commonRateDecreaseMessage, commonRateDecreaseMessage2).contains(getTextFromElement(rateAdjustmentMessageInCaseOfDecrease)),
                        "Rate adjustment message message validation for decrease. Actual message: " + getTextFromElement(rateAdjustmentMessageInCaseOfDecrease));
            }
        }
    }

    public void clickBankPaymentRadioButton() {
        waitForSpinnerToBeGone();
        scrollElementToMiddle(bankPaymentRadioButtonLabel);
        clickElement(bankPaymentRadioButtonLabel);
    }

    public void clickCardRadioButton() {
        scrollAndClickOnElement(paymentSelectionCardRadioButton);
    }

    public boolean isGreenCheckIsDisplayed() {
        return isElementVisible(paymentAddedGreenCheck, 15);
    }

    public void isHiddenBankAccountMonthlyPayTextCorrect(FarmersSoftAssert fsa, String accountNumber) {
        String expectedMaskedAccountNumber = String.format("%s %s", accountNumber.substring(2, 4), accountNumber.substring(accountNumber.length() - 2));
        fsa.assertEquals(getTextFromElement(maskedAddedPaymentDetails), expectedMaskedAccountNumber, "Bank account number (masked) should be masked and in certain format");
    }

    public void clickChangeYourCoverageLink() {
        waitAndClickElement(changeYourCoverageLink);
    }

    public void validateIframes(FarmersSoftAssert fsa) throws Exception {
        validateIframeForBank(PAY_IN_FULL, fsa);
        validateIframeForBank(MONTHLY_AUTOPAY, fsa);
        validateIframeForCard(PAY_IN_FULL, fsa);
        validateIframeForCard(MONTHLY_AUTOPAY, fsa);
    }

    private void validateIframeForBank(String paymentMethod, FarmersSoftAssert fsa) throws Exception {
        driver().navigate().refresh();
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        if(landingStateCode.equals(UT)) {
            Log.info(String.format("Bank payment method is not available for %s state", landingStateCode));
            return;
        }
        selectPaymentMethodFromPaymentCards(paymentMethod);
        if (isElementVisible(changeLink, 1)) {
            clickChangeLink();
            clickBankTransferButton();
        } else {
            clickBankPaymentRadioButton();
        }

        PolicyBankPayment policyBankPayment = new PolicyBankPayment();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        String accountNumber = RandomStringUtils.randomNumeric(10);
        AppStore sessionStorage = getSessionStorageAppStore();
        // Checking payment setup validation
        switchToPaymentUsIframe();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER + PWKeys.TAB);
        sleep(1);
        fsa.assertTrue(policyBankPayment.isBOFABankNameLabelCorrect(), errorMessage("BOFA bank label"));

        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        clickAddButton();
        fsa.assertTrue(policyBankPayment.isBankPaymentAccountAddedMsgCorrect(), errorMessage("Bank account added"));

        String disclaimerText = getTextFromElement(disclaimerChargeText);
        Log.info(String.format("Found disclaimer text with payment method %s: %s", paymentMethod, disclaimerText));

        fsa.assertTrue(isValidDisclaimer(disclaimerText),
                "No service charge with PIF/Bank Transfer message");

        // fsa.assertTrue(disclaimerText.equals(NO_SERVICE_CHARGE_WHEN_PAYING_IN_FULL) || disclaimerText.equals(NO_SERVICE_CHARGE_WHEN_PAY_IN_FULL) || disclaimerText.contains("No service charges when using bank transfer.") || disclaimerText.contains("No service charges or premium increases when using bank transfer."), "No service change with PIF/Bank Transfer message");
        fsa.assertTrue(policyBankPayment.isBankIconDisplayed(), "Bank icon is not displayed");
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountPayInFullTextCorrect(accountNumber), errorMessage("Hidden account number pay in full"));

        policyBankPayment.clickChangeLink();

        // Payment method already added error validation
        switchToPaymentUsIframe();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        clickAddButton();
        fsa.assertTrue(isPaymentMethodAlreadyAddedMsgCorrect(), errorMessage("Payment method already added"));
        switchToParentWindow();
        closeAddPaymentMethodContainer(true);

        // Savings payment setup
        policyBankPayment.clickChangeLink();
        switchToPaymentUsIframe();
        policyBankPayment.clickSavingsRadioButton();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        clickAddButton();
        switchToParentWindow();
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountPayInFullTextCorrect(accountNumber), errorMessage("Hidden account number pay in full"));

        // Business checking payment setup
        policyBankPayment.clickChangeLink();
        switchToPaymentUsIframe();
        policyBankPayment.clickBusinessCheckingRadioButton();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        clickAddButton();
        switchToParentWindow();
        waitForSpinnerToBeGone();
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountPayInFullTextCorrect(accountNumber), errorMessage("Hidden account number pay in full"));


        if (Property.getTestProperty("driver").equals("firefox")) {
            fsa.assertTrue(validateClickableLinksPaymentPage(), "One or more links is not enabled or displayed");
        } else {
            fsa.assertTrue(validateOpeningLinksInNewTab(), "Title is not matching for one or more opened tab");
        }

        fsa.assertTrue(policyDebitCreditPayment.isOneTimePaymentTextCorrect(), "One time payment");
        fsa.assertTrue(isCompletePurchaseButtonTextMatching(), errorMessage("Complete purchase button"));
        logInfoMessage(sessionStorage.getData().getQuoteNumber());

    }

    private boolean isValidDisclaimer(String disclaimerText) {
        if (disclaimerText == null || disclaimerText.isBlank()) {
            return false;
        }

        Log.info(String.format("Found disclaimer text with payment method: %s", disclaimerText));

        String normalized = disclaimerText.trim().toLowerCase();

        return normalized.contains("no service charge")
                && (normalized.contains("paying in full")
                || normalized.contains("pay in full")
                || normalized.contains("bank transfer"));
    }

    private void validateIframeForCard(String paymentMethod, FarmersSoftAssert fsa) throws Exception {
        driver().navigate().refresh();
        AppStore sessionStorage = getSessionStorageAppStore();
        selectPaymentMethodFromPaymentCards(paymentMethod);
        if (isElementVisible(changeLink, 1)) {
            clickChangeLink();
            if (isElementVisible(debitCreditCardButton, 2)) {
                clickDebitCreditCardButton();
            } else {
                clickCardButton();
            }
        } else {
            clickCardRadioButton();
        }

        switchToPaymentUsIframe();

        // validate VISA, MASTER, AMEX, DISCOVER card symbol
        enterCardNumber(VISA_CREDIT_CARD);
        fsa.assertTrue(isVisaCardIconDisplayed(), "Visa card symbol is not displayed");
        clearOutCardNumberInputField();

        enterCardNumber(MASTER_CARD);
        fsa.assertTrue(isMasterCardIconDisplayed(), "Master card symbol is not displayed");
        clearOutCardNumberInputField();

        enterCardNumber(DISCOVER_CARD);
        fsa.assertTrue(isDiscoverCardIconDisplayed(), "Discover card symbol is not displayed");
        clearOutCardNumberInputField();

        enterCardNumber(AMERICAN_EXPRESS_CARD);
        fsa.assertTrue(isAmexCardIconDisplayed(), "American express card symbol is not displayed");
        clearOutCardNumberInputField();

        // Validate AMEX credit card details and validate success messages
        enterCardNumber(AMERICAN_EXPRESS_CARD);
        enterExpDate(EXP_DATE);
        enterCVVNumber(0 + CVV_NUMBER);
        enterBillingZipCode(ZIP_CODE);
        clickAddButton();
        waitForSpinnerToBeGone();
        driver().navigate().refresh(); // Refreshing the page to avoid browser 'Save card' pop up

        // Validate duplicate card added
        if (isElementPresent(PWBy.xpath("//a[contains(text(), '" + CHANGE_LINK + "')]"), 6)) {
            scrollToElement(changeLink);
            clickOnHiddenElement(changeLink);
            if (isElementVisible(debitCreditCardButton, 2)) {
                clickDebitCreditCardButton();
            } else {
                clickCardButton();
            }
        } else {
            clickCardRadioButton();
        }
        switchToPaymentUsIframe();
        enterCardNumber(AMERICAN_EXPRESS_CARD);
        enterExpDate(EXP_DATE);
        enterCVVNumber(0 + CVV_NUMBER);
        enterBillingZipCode(ZIP_CODE);
        clickAddButton();

        fsa.assertTrue(isPaymentMethodAlreadyAddedMsgCorrect(), errorMessage("Payment method already added"));
        switchToParentWindow();
        closeAddPaymentMethodContainer(true);

        // Validate adding DISCOVER card details
        clickChangeLink();
        if (isElementVisible(debitCreditCardButton, 2)) {
            clickDebitCreditCardButton();
        } else {
            clickCardButton();
        }
        switchToPaymentUsIframe();
        enterCardNumber(DISCOVER_CARD);
        enterExpDate(EXP_DATE);
        enterCVVNumber(CVV_NUMBER);
        enterBillingZipCode(ZIP_CODE);
        clickAddButton();

        logInfoMessage(sessionStorage.getData().getQuoteNumber());
        addSauceLabsLinkInLog();

    }

    public void validateIframeContents(FarmersSoftAssert fsa) throws Exception {
        AppStore sessionStorageAppStore = getSessionStorageAppStore();
        if(isOnBristolWest()) {
            Log.info("Customer landed on the BW payment page. This test requires farmers payment page, hence skipping the iframe content validation");
            return;
        }
        validateIframeContentForCard(PAY_IN_FULL, fsa);
        validateIframeContentForCard(MONTHLY_AUTOPAY, fsa);
        validateIframeContentForBank(MONTHLY_AUTOPAY, fsa);
        validateIframeContentForBank(PAY_IN_FULL, fsa);
        logInfoMessage(sessionStorageAppStore.getData().getQuoteNumber());
        addSauceLabsLinkInLog();
    }

    private void validateIframeContentForCard(String paymentMethod, FarmersSoftAssert fsa) throws Exception {
        driver().navigate().refresh();
        selectPaymentMethodFromPaymentCards(paymentMethod);
        boolean isCaState = getSessionStorageAppStore().getData().getLandingStateCode().equals(CA);
        if(isCaState) {
            Log.info("CA state is not accepting Card payment for Monthly Autopay");
            return;
        }
        AppStore sessionStorageAppStore = getSessionStorageAppStore();
        clickCardRadioButton();
        if(isCaState) {
            fsa.assertTrue(isAddBankHeaderCorrect(), errorMessage("Add payment method label"));
        } else {
            fsa.assertTrue(isAddPaymentMethodLabelCorrect(), errorMessage("Add payment method label"));
        }
        fsa.assertTrue(isBankPaymentButtonTextCorrect() || isBankButtonTextCorrect(), errorMessage("Bank transfer button"));
        fsa.assertTrue(isDebitCreditCardButtonTextCorrect() || isCardButtonTextCorrect(), errorMessage("Debit credit card (or Card) button"));
        String fullName = fullNameFromCustomerData(sessionStorageAppStore.getData().getCustomerData());
        if (isElementVisible(debitCreditCardButton, 2)) {
            clickDebitCreditCardButton();
        } else {
            clickCardButton();
        }
        switchToPaymentUsIframe();
        fsa.assertTrue(isNameOnCardLabelCorrect(), errorMessage("Name on card label"));
        fsa.assertEquals(getValueForFullNamePaymentusFrame(), fullName);
        fsa.assertTrue(isCardNumberLabelCorrect(), errorMessage("Card number label"));
        fsa.assertTrue(isExpirationDateCorrect(), errorMessage("Exp date label"));
        fsa.assertTrue(isCardSecurityCodeLabelCorrect(), errorMessage("Card security label"));
        fsa.assertTrue(isBillingZipCodeLabelCorrect(), errorMessage("Billing zip code label"));
        fsa.assertTrue(isVisaCardIconInRowDisplayed(), "Visa card icon in row is not displayed");
        fsa.assertTrue(isMasterCardIconInRowDisplayed(), "Master card icon in row is not displayed");
        fsa.assertTrue(isDiscoverCardIconInRowDisplayed(), "Discover card icon in row is not displayed");
        fsa.assertTrue(isAmexCardIconInRowDisplayed(), "Amex card icon in row is not displayed");
        fsa.assertTrue(isAddButtonTextCorrect(), errorMessage("Add button"));
    }

    private void validateIframeContentForBank(String paymentMethod, FarmersSoftAssert fsa) throws Exception {
        driver().navigate().refresh();
        selectPaymentMethodFromPaymentCards(paymentMethod);
        AppStore sessionStorageAppStore = getSessionStorageAppStore();
        clickBankPaymentRadioButton();

        PolicyBankPayment policyBankPayment = new PolicyBankPayment();
        fsa.assertTrue(policyBankPayment.isAddPaymentMethodLabelCorrect(), errorMessage("Add bank label for " + paymentMethod));
        switchToPaymentUsIframe();
        fsa.assertTrue(policyBankPayment.isBankAccountTypeHeaderCorrect(), errorMessage("Bank account type header"));
        fsa.assertTrue(policyBankPayment.isCheckingRadioButtonSelected(), "Checking radio button is selected");
        fsa.assertTrue(policyBankPayment.isCheckingLabelCorrect(), errorMessage("Checking label"));
        fsa.assertTrue(policyBankPayment.isSavingsRadioButtonEnabled(), "Savings radio button is displayed");
        fsa.assertTrue(policyBankPayment.isSavingsLabelCorrect(), errorMessage("Savings label"));
        fsa.assertTrue(policyBankPayment.isBusinessCheckingRadioButtonEnabled(), "Business checking radio button is displayed");
        fsa.assertTrue(policyBankPayment.isBusinessCheckingLabelCorrect(), errorMessage("Business checking label"));
        fsa.assertTrue(policyBankPayment.isAccountHolderNameLabelCorrect(), errorMessage("Account holder name"));
        fsa.assertTrue(policyBankPayment.isAccountHolderNameMatching(fullNameFromCustomerData(sessionStorageAppStore.getData().getCustomerData())), "Account holder name is not matching");
        fsa.assertTrue(policyBankPayment.isBankRoutingNumberLabelCorrect(), errorMessage("Bank routing number label"));
        fsa.assertTrue(policyBankPayment.isAccountNumberLabelCorrect(), errorMessage("Account number label"));
        fsa.assertTrue(policyBankPayment.isConfirmAccountNumberLabelCorrect(), errorMessage("Confirm account number label"));
        fsa.assertTrue(isAddButtonTextCorrect(), errorMessage("Add button"));
        switchToParentWindow();
        waitAndClickElement(closeIcon);
    }

    public void validateIframeErrors(FarmersSoftAssert fsa) throws Exception {
        String quoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
        validateIframeErrorForCard(PAY_IN_FULL, fsa);
        validateIframeErrorForBank(PAY_IN_FULL, fsa);
        validateIframeErrorForCard(MONTHLY_AUTOPAY, fsa);
        validateIframeErrorForBank(MONTHLY_AUTOPAY, fsa);
        logInfoMessage(quoteNumber);
        addSauceLabsLinkInLog();
    }

    private void validateIframeErrorForCard(String paymentMethod, FarmersSoftAssert fsa) throws Exception {
        driver().navigate().refresh();
        boolean isCAState = getSessionStorageAppStore().getData().getLandingStateCode().equals(CA);

        if(isCAState && !paymentMethod.equals(PAY_IN_FULL)) {
            Log.info("CA state card radio button will be disabled for Monthly Autopay");
            return;
        }
        selectPaymentMethodFromPaymentCards(paymentMethod);

        clickCardRadioButton();
        if (isElementVisible(debitCreditCardButton, 2)) {
            clickDebitCreditCardButton();
        } else {
            clickCardButton();
        }
        switchToPaymentUsIframe();
        clearOutCardHolderNameInputField();
        clickAddButton();

        fsa.assertTrue(isEnterYourNameErrorCorrect(), errorMessage("Enter your name error"));
        fsa.assertTrue(isEnterCardNumberErrorCorrect(), errorMessage("Enter Card number error"));
        fsa.assertTrue(isEnterEXPDateNumberErrorCorrect(), errorMessage("Enter exp date error"));
        fsa.assertTrue(isEnterCVVNumberErrorCorrect(), errorMessage("Enter CVV number error"));
        fsa.assertTrue(isEnterBillingZipCodeErrorCorrect(), errorMessage("Enter billing zip error"));

        enterCardNumber(DIGITS);
        fsa.assertTrue(isEnterCardNumberErrorCorrect(), errorMessage("Enter Card number error"));

        enterExpDate("12/12");
        fsa.assertTrue(isEnterEXPDateNumberErrorCorrect(), errorMessage("Enter exp date error"));

        enterCVVNumber("@@@");
        fsa.assertTrue(isEnterCVVNumberErrorCorrect(), errorMessage("Enter CVV number error"));

        enterBillingZipCode("1111!");
        fsa.assertTrue(isEnterBillingZipCodeErrorCorrect(), errorMessage("Enter billing zip error"));

    }

    private void validateIframeErrorForBank(String paymentMethod, FarmersSoftAssert fsa) throws Exception {
        driver().navigate().refresh();
        selectPaymentMethodFromPaymentCards(paymentMethod);
        clickBankPaymentRadioButton();
        clickBankTransferButton();
        switchToPaymentUsIframe();
        clearOutAccountHolderInputField();
        clickAddButton();
        fsa.assertTrue(isEnterValidAccountHolderNameErrorCorrect(), errorMessage("Enter valid account holder name error"));
        fsa.assertTrue(isEnterValidRoutingNumberErrorCorrect(), errorMessage("Enter valid routing number error"));
        fsa.assertTrue(isEnterValidBankAccountNumberErrorCorrect(), errorMessage("Enter valid account number error"));
        fsa.assertTrue(isBankAccountNumbersNotMatchingErrorCorrect(), errorMessage("Bank account numbers are not matching error"));

        enterRoutingNumber(DIGITS);
        fsa.assertTrue(isEnterValidRoutingNumberErrorCorrect(), errorMessage("Enter valid routing number error"));

        enterAccountNumber(DIGITS.substring(5));
        fsa.assertTrue(isEnterValidBankAccountNumberErrorCorrect(), errorMessage("Enter valid account number error"));

        // enterConfirmAccountNumber(DIGITS.substring(4));
        fsa.assertTrue(isBankAccountNumbersNotMatchingErrorCorrect(), errorMessage("Bank account numbers are not matching error"));
    }

    private void comparePayInFullAndMonthlyAutoPayPremiumsAuto(FarmersSoftAssert fsa) throws Exception {
        PWElement paymentCardPayInFullDollars;
        PWElement paymentCardPayInFullCents;
        PWElement paymentCardMonthlyAutopayDollars;
        PWElement paymentCardMonthlyAutopayCents;
        String payInFullAmount;
        String monthlyAutopayAmount;
        if (isUseMobileViewEnabled()) {
            getXPathForPaymentMethod(PAY_IN_FULL);
            paymentCardPayInFullDollars = driver().findElement(PWBy.xpath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_TWO_DOLLAR_AMOUNT_XPATH));
            paymentCardPayInFullCents = driver().findElement(PWBy.xpath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_THREE_CENT_AMOUNT_XPATH));
            payInFullAmount = getTextFromElement(paymentCardPayInFullDollars) + getTextFromElement(paymentCardPayInFullCents);
            getXPathForPaymentMethod(MONTHLY_AUTOPAY);
            paymentCardMonthlyAutopayDollars = driver().findElement(PWBy.xpath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_TWO_DOLLAR_AMOUNT_XPATH));
            paymentCardMonthlyAutopayCents = driver().findElement(PWBy.xpath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_THREE_CENT_AMOUNT_XPATH));
        } else {
            String payInFullXpath = getXPathForPaymentMethod(PAY_IN_FULL);
            paymentCardPayInFullDollars = driver().findElement(PWBy.xpath(payInFullXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_TWO_DOLLAR_AMOUNT_XPATH));
            paymentCardPayInFullCents = driver().findElement(PWBy.xpath(payInFullXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_THREE_CENT_AMOUNT_XPATH));
            payInFullAmount = getTextFromElement(paymentCardPayInFullDollars) + getTextFromElement(paymentCardPayInFullCents);
            String monthlyAutopayXpath = getXPathForPaymentMethod(MONTHLY_AUTOPAY);
            paymentCardMonthlyAutopayDollars = driver().findElement(PWBy.xpath(monthlyAutopayXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_TWO_DOLLAR_AMOUNT_XPATH));
            paymentCardMonthlyAutopayCents = driver().findElement(PWBy.xpath(monthlyAutopayXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_THREE_CENT_AMOUNT_XPATH));
        }
        monthlyAutopayAmount = getTextFromElement(paymentCardMonthlyAutopayDollars) + getTextFromElement(paymentCardMonthlyAutopayCents);

        double dPayInFull = Double.parseDouble(payInFullAmount.replace(COMMA,EMPTY_STRING));
        double dMonthlyAutopay = Double.parseDouble(monthlyAutopayAmount.replace(COMMA,EMPTY_STRING));
        double dDueTodayAmount = Double.parseDouble(getTextFromElement(dueTodayAmount).replaceAll("[,$]",EMPTY_STRING));

        fsa.assertTrue(dPayInFull <= Math.ceil(dMonthlyAutopay*11 + dDueTodayAmount), "Pay in full premium is less or equal to Monthly Autopay.");
    }

    private double getPolicyFeesFromAppStore(VerifyResponse verifyResponse){
        return Double.parseDouble(verifyResponse.getPolicyFee().getAmount());
    }

    private double getTotalSpreadFeeAmount(VerifyResponse verifyResponse, String payPlanDescription){
        List<PaymentSchedule> paymentSchedules = filterListOfPaymentScheduleByPayPlan(
                verifyResponse.getPaymentSchedules(), payPlanDescription);

        if (paymentSchedules.isEmpty()) {
            Log.warn("No payment schedules found for payPlanDescription: " + payPlanDescription);
            return 0.0;
        }

        PaymentSchedule schedule = paymentSchedules.get(0);
        List<PaymentSchedule.DownPayment.SpreadFeeAmount> spreadFeeAmount = schedule.getDownPayment().getSpreadFeeAmount();

        if (spreadFeeAmount == null || spreadFeeAmount.isEmpty()) {
            Log.warn("No spread fees found in payment schedule");
            return 0.0;
        }

        double total = spreadFeeAmount.stream()
                .mapToDouble(each -> {
                    String amount = each.getCurrencyAmount();
                    if (amount == null) {
                        return 0.0;
                    }
                    String trimmed = amount.trim();
                    if (trimmed.isEmpty()) {
                        return 0.0;
                    }
                    try {
                        double parsed = Double.parseDouble(trimmed);
                        Log.info("Parsed fee - Type: " + each.getFeeType() + ", Amount: " + parsed);
                        return parsed;
                    } catch (NumberFormatException e) {
                        Log.error("Failed to parse currency amount: '" + amount + "' for fee type: " + each.getFeeType());
                        return 0.0;
                    }
                })
                .sum();
        Log.info("Total spread fee amount: " + total);
        return total;
    }

    private double getFullTermPremiumPayInFull(VerifyResponse verifyResponse){
        return Double.parseDouble(verifyResponse.getPaymentSchedules().stream().filter(each -> each.getPayPlanCode().equals("A1")).findAny().get().getFullTermPremium());
    }

    private double getMonthlyPayInstallmentAmountMonthlyEft(VerifyResponse verifyResponse){
        return Double.parseDouble(verifyResponse.getPaymentSchedules().stream().filter(each -> each.getPayPlanCode().equals("MTEF")).findAny().get().getDownPayment().getAmount().getAmount());
    }

     void clickFeesInfoIconMobileView(){
        clickElement(feeInfoIconMobileView);
    }

    private double getSurchargeTaxes(PaymentSchedule paymentSchedule){
        return Double.parseDouble(paymentSchedule.getCountyTax()) + Double.parseDouble(paymentSchedule.getStateTax());
    }

    public void closeRateChangedModal(){
        if(isElementVisible(rateChangeModalOkButton, 2)){
            clickElement(rateChangeModalOkButton);
        }
    }
}
