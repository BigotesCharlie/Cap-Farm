package com.farmers.ffq.ace.condo;

import com.farmers.ffq.ace.hrc.common.AceHRCContactInfoBasePage;


public class AceCondoContactInfoPage extends AceHRCContactInfoBasePage {
    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceCondoContactInfoPage() throws Exception {
        super();
    }

/*
    @Override
    public void validateContactInfoSelections(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        validateContactInfoSelections(applicant, true, fsa);
    }

    public void validateContactInfoSelections(ApplicantAceHome applicant, boolean beforeRate, FarmersSoftAssert fsa) throws Exception {
        // Policy start date
        String policyStartDate = applicant.getEarlyShoppingFactor().trim();
        if (policyStartDate.equalsIgnoreCase(TRUE)) {
            policyStartDate = getFormattedForPolicyStartDate(getTodayDate().plusDays(7));
        } else if (policyStartDate.isBlank() || policyStartDate.equalsIgnoreCase(FALSE)) {
            policyStartDate = getFormattedForPolicyStartDate(getTodayDate().plusDays(1));
        }
        fsa.assertEquals(getPolicyStartDate(), policyStartDate, "Contact Info page - Policy start date value.");
        // Fire hydrant question
        if (isElementDisplayed(By.xpath(FIRE_HYDRANT_SECTION_XPATH))) {
            fsa.assertEquals(getFireHydrantYesNo(), applicant.isFireHydrant(), "Contact Info page - Fire hydrant question value.");
        }
        // Discount bundles
        List<SqlDiscount> discounts = applicant.getDiscounts();
        SqlDiscount discount = discounts.stream().findFirst().orElse(null);
        assert discount != null;
        fsa.assertEquals(isBundleCheckboxSelected(AUTO), discount.isAutoInsurance(), "Contact Info page - bundle Auto insurance");
        if (!isNoLifeBundleState(applicant.getStateCode()) && beforeRate) {
            fsa.assertEquals(isBundleCheckboxSelected(LIFE), discount.isLifeInsurance(), "Contact Info page - bundle Life insurance");
        }
        if (!isNoEligibleOccupationState(applicant.getStateCode())) {
            fsa.assertEquals(isBundleCheckboxSelected("Umbrella"), discount.isUmbrellaInsurance(), "Contact Info page - bundle Umbrella insurance");
        }
        fsa.assertEquals(isBundleCheckboxSelected("Business"), discount.isBusinessInsurance(), "Contact Info page - bundle Business insurance");
        if (isElementVisible(viewAdditionProductsLink,2)) {
            waitAndClickElement(viewAdditionProductsLink);
        }
        fsa.assertEquals(isBundleCheckboxSelected("Recreational Boat/Watercraft"), discount.isRecreationalBoatWatercraftInsurance(), "Contact Info page - bundle Recreational Boat/Watercraft");
        fsa.assertEquals(isBundleCheckboxSelected("Off-road vehicle"), discount.isMotorcycleInsurance(), "Contact Info page - bundle Off-Road Vehicle");
        fsa.assertEquals(isBundleCheckboxSelected("Motorhome, Travel Trailer or 5th Wheel"), discount.isMotorHome(), "Contact Info page - bundle Motorhome, Travel Trailer or 5th Wheel");

       if(!getLobTypeFromAppStore().equalsIgnoreCase(RENTERS)){
           // Mailing address
           Address address = getSessionStorageAppStore().getData().getCustomerData().getAddress();
           fsa.assertEquals(getAttributeData(defaultMailingAddressRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED), true,
                   "Contact Info page - Default mailing address radio-button is selected.");
           fsa.assertEquals(getTextFromElement(defaultMailingAddressRadioButtonLabel).toUpperCase(), address.getNew_address().toUpperCase(),
                   "Contact Info page - Default mailing address");
           fsa.assertEquals(getAttributeData(otherMailingAddressRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED), false,
                   "Contact Info page - Other mailing address radio-button is selected.");
           // Contact info
           fsa.assertTrue(isEmailAddressReadOnly(), "Contact Info page - e-mail address is ready-only.");
           fsa.assertTrue(isPhoneNumberReadOnly(), "Contact Info page - phone is ready-only.");
           fsa.assertEquals(getValueFromWebElement(emailAddressInput), applicant.getEmailAddress(), "Contact Info page - e-mail address.");
           fsa.assertEquals(getValueFromWebElement(phoneNumberInput), getFormattedPhoneNumber(applicant.getPhoneNumber()),
                   "Contact Info page - phone number.");
       }
    }

    public void fillOutContactInfoPageCondo(ApplicantAceHome applicant) throws Exception {
        enterPolicyStartDate(applicant);
        enterFireHydrantData(applicant);
        fillOutBundleAndSave(applicant, CONDO);
        enterEmailIdAndPhoneNumberInContactInfoPage(applicant);
        clickOnAgreeAndSubmitButton();
    }
*/
}
