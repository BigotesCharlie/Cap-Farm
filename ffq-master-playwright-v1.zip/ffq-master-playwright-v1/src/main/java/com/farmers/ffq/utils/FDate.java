package com.farmers.ffq.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class FDate {

	private static final int TENTH = 10;
	private String day;
	private String month;
	private String year;

	public FDate(String day, String month, String year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}

	public FDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		day = Integer.toString(calendar.get(Calendar.DAY_OF_MONTH));
		if (calendar.get(Calendar.DAY_OF_MONTH) < TENTH) {
			day = "0" + day;
		}
		month = calendar.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault());
		year = Integer.toString(calendar.get(Calendar.YEAR));
	}
	
	public FDate(String date) throws Exception {		
		this(new SimpleDateFormat("MMddyyy").parse(date));
	}

	public String getDay() {
		return day;
	}

	public String getMonth() {
		return month;
	}

	public String getYear() {
		return year;
	}
	
	public String toString() {
		return getMonth()+"/"+getDay()+"/"+getYear();
	}
}
