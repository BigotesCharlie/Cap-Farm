package com.farmers.ffq.datatransferobjects.hqm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.farmers.ffq.utils.GlobalVariables.NONE;
import static com.farmers.ffq.utils.GlobalVariables.SPACE;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "quoteNumber",
        "valuationId",
        "valuationForms"
})

public class PrefillResponseHQM {

    @JsonProperty("quoteNumber")
    private String quoteNumber;
    @JsonProperty("valuationId")
    private String valuationId;
    @JsonProperty("valuationForms")
    private final List<ValuationForm> valuationForms = new ArrayList<>();
    @JsonProperty("countyNameList")
    private final List<String> countyNameList = new ArrayList<>();

    public PrefillResponseHQM() {
    }

    @JsonProperty("quoteNumber")
    public String getQuoteNumber() {
        return quoteNumber;
    }

    @JsonProperty("valuationId")
    public String getValuationId() {
        return valuationId;
    }

    @JsonProperty("valuationForms")
    public List<ValuationForm> getValuationForms() {
        return valuationForms;
    }

    public String getStreet() {
        return Objects.requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("addressForm"))
                .findFirst().orElse(null)).getFields().get(0).getAddress();
    }

    public String getCity() {
        return Objects.requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("addressForm"))
                .findFirst().orElse(null)).getFields().get(0).getCity();
    }

    public String getZipCode() {
        return Objects.requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("addressForm"))
                .findFirst().orElse(null)).getFields().get(0).getZipCode();
    }

    public String getStateCode() {
        return Objects.requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("addressForm"))
                .findFirst().orElse(null)).getFields().get(0).getState();
    }

    public String getCounty() {
        String county = null;
        try {
            county = Objects.requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("addressForm"))
                    .findFirst().orElse(null)).getFields().get(0).getCounty();
        } catch (NullPointerException ignored) {}
        return county;
    }

    public List<String> getCountyNameList() {
        return countyNameList;
    }

    public String getYearBuilt() {
        String yearBuilt = null;
        try {
            yearBuilt = Objects.requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyForm"))
                    .findFirst().orElse(null)).getFields().get(0).getYearBuilt();
        } catch (NullPointerException ignored) {}
        return yearBuilt;
    }

    public String getSquareFeet() {
        String squareFeet = null;
        try {
            squareFeet = Objects.requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyForm"))
                    .findFirst().orElse(null)).getFields().get(0).getSqFeet();
        } catch (NullPointerException ignored) {}
        return squareFeet;
    }

    public String getQualityGrade() {
        String qualityGrade = null;
        try {
            qualityGrade = Objects.requireNonNull(Objects
                    .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("qualityGradeForm"))
                    .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("qualityGrade"))
                    .findFirst().orElse(null)).getValues().get(0).getWebDesc();
        } catch (NullPointerException ignored) {}
        return qualityGrade;
    }

    public boolean isPropertyDetailsForm() {
        long numOfForms = getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm")).count();
        return numOfForms > 0;
    }

    public boolean isQualityGradeForm() {
        long numOfForms = getValuationForms().stream().filter((va) -> va.getFormName().equals("qualityGradeForm")).count();
        return numOfForms > 0;
    }

    public String getNumberOfStories() {
        return Objects.requireNonNull(Objects
                .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("numberOfStories"))
                .findFirst().orElse(null)).getValues().get(0).getWebDesc();
    }

    public String getFoundationType() {
        return Objects.requireNonNull(Objects
                .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("foundationType"))
                .findFirst().orElse(null)).getValues().get(0).getWebDesc();
    }

    public String getFinishedPercentOfLowestLevel() {
        String finishedPercent;
        try {
            finishedPercent = Objects.requireNonNull(Objects
                    .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                    .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("finishedPercentOfLowestLevel"))
                    .findFirst().orElse(null)).getValues().get(0).getValue();
        } catch (NullPointerException e) {
            finishedPercent = null;
        }
        return finishedPercent;
    }

    public String getExteriorWallFinish() {
        return Objects.requireNonNull(Objects
                .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("exteriorWallFinish"))
                .findFirst().orElse(null)).getValues().get(0).getWebDesc();
    }

    public String getExteriorWallConstruction() {
        String extWallConstruction;
        try {
            extWallConstruction = Objects.requireNonNull(Objects
                    .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                    .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("exteriorWallConstruction"))
                    .findFirst().orElse(null)).getValues().get(0).getValue();
        } catch (NullPointerException e) {
            extWallConstruction = "";
        }
        return extWallConstruction;
    }

    public String getRoofCover() {
        return Objects.requireNonNull(Objects
                .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("roofCover"))
                .findFirst().orElse(null)).getValues().get(0).getWebDesc();
    }

    public String getFloorCoverings() {
        return Objects.requireNonNull(Objects
                .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("floorCoverings"))
                .findFirst().orElse(null)).getValues().get(0).getWebDesc();
    }

    public String getHeatingSystem() {
        return Objects.requireNonNull(Objects
                .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("heatingSystem"))
                .findFirst().orElse(null)).getValues().get(0).getWebDesc();
    }

    public String getFireplaces() {
        String fireplaces;
        try {
            fireplaces = Objects.requireNonNull(Objects
                    .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                    .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("firePlaces"))
                    .findFirst().orElse(null)).getValues().get(0).getWebDesc();
        } catch (NullPointerException e) {
            fireplaces = NONE;
        }
        return fireplaces;
    }

    public String getGarageCarport() {
        String garageCarport;
        try {
            garageCarport = Objects.requireNonNull(Objects
                    .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                    .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("garageCarport"))
                    .findFirst().orElse(null)).getValues().get(0).getWebDesc().replaceFirst("\u00a0", SPACE);
        } catch (NullPointerException e) {
            garageCarport = null;
        }
        return garageCarport;
    }

    public String getGarageStyle() {
        String garageStyle = null;
        try {
            garageStyle = Objects.requireNonNull(Objects
                    .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                            .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("garageStyle"))
                    .findFirst().orElse(null)).getValues().get(0).getWebDesc();
        } catch (NullPointerException ignored) {
        }
        return garageStyle;
    }

    public String getPoolHotTubOnPremises() {
        String poolOnPrem = null;
        try {
            poolOnPrem = Objects.requireNonNull(Objects
                    .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                            .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("poolQuestion"))
                    .findFirst().orElse(null)).getValues().get(0).getWebDesc();
        } catch (NullPointerException ignored) {
        }
        return poolOnPrem;
    }

    public String getUnitsAttached() {
        String unitsAttachedTo = null;
        try {
            unitsAttachedTo = Objects.requireNonNull(Objects
                    .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                            .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("unitsQuestion"))
                    .findFirst().orElse(null)).getValues().get(0).getWebDesc();
        } catch (NullPointerException ignored) {
        }
        return unitsAttachedTo;
    }

    public String getOilTankOnPremises() {
        String oilTankOnPrem = null;
        try {
            oilTankOnPrem = Objects.requireNonNull(Objects
                    .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                            .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("oilTank"))
                    .findFirst().orElse(null)).getValues().get(0).getWebDesc();
        } catch (NullPointerException ignored) {
        }
        return oilTankOnPrem;
    }

    public String getPoolOnPremises() {
        String poolOnPrem = null;
        try {
            poolOnPrem = Objects.requireNonNull(Objects
                    .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                            .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("onlyPoolQuestion"))
                    .findFirst().orElse(null)).getValues().get(0).getWebDesc();
        } catch (NullPointerException ignored) {
        }
        return poolOnPrem;
    }

    public String getSolarPanelsOnPremises() {
        String solarPanelsOnPrem = null;
        try {
            solarPanelsOnPrem = Objects.requireNonNull(Objects
                    .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                            .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("solarPanelQuestion"))
                    .findFirst().orElse(null)).getValues().get(0).getWebDesc();
        } catch (NullPointerException ignored) {
        }
        return solarPanelsOnPrem;
    }

    public String getTrampolineOnPremises() {
        String trampolineOnPrem = null;
        try {
            trampolineOnPrem = Objects.requireNonNull(Objects
                    .requireNonNull(getValuationForms().stream().filter((va) -> va.getFormName().equals("propertyDetailsForm"))
                            .findFirst().orElse(null)).getFields().stream().filter(fa -> fa.getFieldName().equals("trampolineQuestion"))
                    .findFirst().orElse(null)).getValues().get(0).getWebDesc();
        } catch (NullPointerException ignored) {
        }
        return trampolineOnPrem;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonPropertyOrder({
            "country",
            "city",
            "zipCode",
            "address",
            "addressLine2",
            "state",
            "county",
            "sqFeet",
            "yearBuilt",
            "fieldName",
            "values"
    })

    public static class Field {

        @JsonProperty("country")
        private String country;
        @JsonProperty("city")
        private String city;
        @JsonProperty("zipCode")
        private String zipCode;
        @JsonProperty("address")
        private String address;
        @JsonProperty("addressLine2")
        private String addressLine2;
        @JsonProperty("state")
        private String state;
        @JsonProperty("county")
        private String county;
        @JsonProperty("sqFeet")
        private String sqFeet;
        @JsonProperty("yearBuilt")
        private String yearBuilt;
        @JsonProperty("fieldName")
        private String fieldName;
        @JsonProperty("values")
        private final List<Value> values = new ArrayList<>();

        @JsonProperty("country")
        public String getCountry() {
            return country;
        }

        @JsonProperty("city")
        public String getCity() {
            return city;
        }

        @JsonProperty("zipCode")
        public String getZipCode() {
            return zipCode;
        }

        @JsonProperty("address")
        public String getAddress() {
            return address;
        }

        @JsonProperty("addressLine2")
        public String getAddressLine2() {
            return addressLine2;
        }

        @JsonProperty("state")
        public String getState() {
            return state;
        }

        @JsonProperty("county")
        public String getCounty() {
            return county;
        }

        @JsonProperty("sqFeet")
        public String getSqFeet() {
            return sqFeet;
        }

        @JsonProperty("yearBuilt")
        public String getYearBuilt() {
            return yearBuilt;
        }

        @JsonProperty("fieldName")
        public String getFieldName() {
            return fieldName;
        }

        @JsonProperty("values")
        public List<Value> getValues() {
            return values;
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonPropertyOrder({
            "formName",
            "fields"
    })
    public static class ValuationForm {

        @JsonProperty("formName")
        private String formName;
        @JsonProperty("fields")
        private final List<Field> fields = new ArrayList<>();

        @JsonProperty("formName")
        public String getFormName() {
            return formName;
        }

        @JsonProperty("fields")
        public List<Field> getFields() {
            return fields;
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonPropertyOrder({
            "webDesc",
            "value"
    })
    public static class Value {

        @JsonProperty("webDesc")
        private String webDesc;
        @JsonProperty("value")
        private String value;

        @JsonProperty("webDesc")
        public String getWebDesc() {
            return webDesc;
        }

        @JsonProperty("value")
        public String getValue() {
            return value;
        }
    }
}
