package com.farmers.ffq.ace.hrc.common;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.home.AceHomeReviewQuotePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.testng.Assert;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.farmers.ffq.ace.hrc.common.AceHRCAdditionalInfoBasePage.I_AM_NOT_SURE;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCJustAFewMoreThingsBasePage extends AceHRCBasePage {

    private static final String JFMT_INFO_HEADER_TITLE = "Let\u2019s complete your quote";
    private static final String JFMT_INFO_HEADER_TITLE2 = "Just a few more things";
    private static final String JFMT_INFO_HEADER_XPATH = "//h1[contains(text(), '" + JFMT_INFO_HEADER_TITLE + "') or contains(text(), '" + JFMT_INFO_HEADER_TITLE2 + "')]";
    private static final String LENDER_INFO_HEADER_LABEL = "Lender info";
    private static final String LENDER_INFO_SUBHEADER_LABEL = "Do you have a mortgage on this property?";
    private static final String WHY_DO_YOU_NEED_MY_LENDER_INFO_LABEL = "Why do you need my lender's info?";
    private static final String WHY_DO_YOU_NEED_MY_LENDER_INFO_CONTENT = "Lending companies require %s to list them on your policy, so they know you have the insurance they require.";
    private static final String MORTGAGE_TEXT = "We can also bill you through your mortgage company.";
    private static final String MORTGAGE_ON_PROPERTY_BUTTON_XPATH = "//label[text()='Do you have a mortgage on this property?']/following::mat-button-toggle";
    private static final String FORTIFIED_CERTIFICATE_BUTTON_XPATH = "//div[contains(@class,'certification-date-form')]";
    private static final String FORTIFIED_CERTIFICATION_HEADER_LABEL = "FORTIFIED certification";
    private static final String FORTIFIED_CERTIFICATION_SUBHEADER_LABEL = "Does your home have valid or active FORTIFIED certification, and does the certification expire after your policy start date?";
    private static final String SPECIFY_ONE_PER_SECTION_LABEL = "Please specify one per section:";
    private static final String DESIGNATION_HEADER = "Designation";
    private static final String PROGRAM_HEADER = "Program";
    private static final String ROOF_CATEGORY_HEADER = "Roof category";
    private static final String DESIGNATION_RDO_BTN1 = "Roof";
    private static final String DESIGNATION_RDO_BTN2 = "Silver";
    private static final String DESIGNATION_RDO_BTN3 = "Gold";
    private static final String PROGRAM_RDO_BTN1 = "High wind";
    private static final String PROGRAM_RDO_BTN2 = "High wind & Hail";
    private static final String PROGRAM_RDO_BTN3 = "Hurricane";
    private static final String PROGRAM_RDO_BTN4 = "Hurricane & Hail";
    private static final String ROOF_RDO_BTN1 = "Existing roof";
    private static final String ROOF_RDO_BTN2 = "New roof";

    private static final String LENDER_SEARCH_TIPS = "Lender search tips";

    private static final String LENDER_SEARCH_TIPS_ONE = "Double-check spelling and remove punctuation.";
    private static final String LENDER_SEARCH_TIPS_TWO = "Search using the full name or an abbreviation, like 'Bank of America' or 'BofA'.";
    private static final String LENDER_SEARCH_TIPS_THREE = "Check for your lender details on your lender's website, billing statement, or by contacting them.";
    private static final String I_CANT_FIND_MY_LENDER = "I can't find my lender";
    private static final String I_CANT_FIND_MY_LENDER_DESCRIPTION_TITLE = "No worries!";
    private static final String JFMT_INFO_SUBHEADER_LABEL = "Please fill out these last few details so we can complete your purchase.";
    private static final String LENDER_NOT_FOUND = "Lender not found";
    final String LOAN_NUMBERVAL = "68980989";
    final String INVALID_LOAN_NUMBERVAL = "9899867868686798066986889798889";
    private static final String PLUMBING_COPPER_CONTENT = "Penny in color. It starts out shiny, then transitions to dark brown after a few years. It has been used in water supply piping since the mid-1930s.";
    private static final String PLUMBING_PVC_CONTENT = "A white- or cream-colored plastic pipe that may turn light tan as it ages. It is usually stamped with the letters \"PVC\" or \"CPVC.\" It has been used in water supply piping since the 1960s.";
    private static final String PLUMBING_PEX_CONTENT = "A flexible plastic pipe that is white, red or blue. It is usually stamped with the letters \"PEX,\" but can be difficult to see. It has been used in water supply piping since the 1960s, but more widely used since 2000.";
    private static final String PLUMBING_GALVANIZED_CONTENT = "It is gray metal color and, when tapped with a screwdriver, makes a metallic sound. It was used in water supply piping from 1900 to mid-1970s, is still available, but rarely used for new construction.";
    private static final String PLUMBING_POLYBUTYLENE_CONTENT = "A flexible plastic pipe that is usually gray, but can also be blue or black, with copper crimped rings securing pipe connections. It is usually stamped with the marking \"PB2110.\" It was used in water supply piping from mid-1970s to mid-1990s.";
    private static final String PRIMARYHEATINGSOURCE_SUBHEADER_CONTENT = "Select the type of heating system for your home's primary heat source.";
    private static final String DOGSONPREMISES_SUBHEADER_CONTENT = "Select the breeds below that live on your property. Also, if you have mixed-breed dogs, please select all the different breeds of your dog(s).";
    private static final String PLUMBING_CHECKBOX_CONTENT = "Plumbing other than Copper, PEX, or PVC";
    private static final String PRIMARY_HEATING_CHECKBOX_CONTENT = "Primary heating source other than central forced-air (with thermostat)";
    private static final String UNREPAIRED_STRUCTURE_CHECKBOX_CONTENT = "Unrepaired structures on property";
    private static final String UNREPAIRED_STRUCTURE_CHECKBOX_SUBHEADER_CONTENT = "One (or more) separate structures may require repairs, is not properly maintained, or is being built.";
    private static final String BUSINESS_OPERATED_CHECKBOX_CONTENT = "Business operated on premises";
    private static final String BUSINESS_OPERATED_CHECKBOX_SUBHEADER_CONTENT = "Excludes home offices if working remotely for an employer.";
    private static final String DOGS_ONPREMISES_CHECKBOX_CONTENT = "Dog(s) on premises";
    private static final String PET_BITE_HISORY_CHECKBOX_CONTENT = "Pet with bite history";
    private static final String PET_BITE_HISORY_CHECKBOX_SUBHEADER_CONTENT = "A pet, such as a dog, cat, bird, or reptile who has bitten and injured a person or animal.";
    private static final String IMPOUND_RDO_BTN1 = "For this new policy, and for renewals";
    private static final String IMPOUND_RDO_BTN2 = "For renewals, but I'll pay for this new policy";
    private static final String IMPOUND_RDO_BTN3 = "No";

    private static final String POLICY_START_DATE_LABEL = "Policy start date";
    private static final String POLICY_TO_BEGIN_LABEL = "When would you like your policy to begin?";
    private static final String EXPECTED_ESCROW_CLOSING_DATE_HEADER = "Policy start and escrow closing date";
    private static final String EXPECTED_ESCROW_TO_CLOSE_QUESTION = "When is escrow expected to close?";
    private static final String EXPECTED_ESCROW_TO_CLOSE_LABEL = "Estimated closing date";
    private static final String EXPECTED_NOT_SURE_WHEN_ESCROW_CLOSING = "Not sure when escrow is closing?";
    private static final String EXPECTED_ESCROW_IS_CLOSING_DESC_TEXT = "Don't worry, you can change the date if you need to.";
    private static final String EXPECTED_INFO_BAR_DESC = "For now, provide an estimated date for when you expect escrow to close. If needed, you can change the date by calling customer service at 1-8";
    private static final String EXPECTED_INFO_BAR_NOTE = "Please note: Rates do fluctuate, so your rate may change if you need to update your closing date.";
    private static final String FINALIZING_YOUR_QUOTE = "Finalizing your quote ...";
    private static final String RC3_PAGE_SUBTITLE1 = "Based on third-party information and what you've provided, your rate may change from our initial quote.";
    private static final String RC3_PAGE_SUBTITLE2 = "Right now, we're ...";

    @PWFindBy(xpath = JFMT_INFO_HEADER_XPATH)
    private PWElement justFewMoreThingsTitle;
    private static final String BUNDLE_JFMT_TITLE_XPATH = "//div[contains(@class,'additional-info-main')]//h1";
    @PWFindBy(xpath = BUNDLE_JFMT_TITLE_XPATH)
    private PWElement bundlePropertyJustFewMoreThingsTitle;
    @PWFindBy(xpath = "//p[contains(text(), 'Please fill out these last few details so we can complete your purchase.')]")
    private PWElement justFewMoreThingsLabelInfoSubHeader;
    @PWFindBy(xpath = "//h2[contains(text(), 'Lender info')]")
    private PWElement lenderInfoLabel;
    @PWFindBy(xpath = "//label[contains(text(), 'Do you have a mortgage on this property?')]")
    private PWElement lenderInfoSubLabel;
    @PWFindBy(xpath = "//mat-icon[starts-with(@aria-label,'Lender')]")
    private PWElement whyDoYouNeedMyLenderInfoIcon;
    @PWFindBy(xpath = "//mat-icon[starts-with(@aria-label,'Lender')]/following-sibling::p[contains(@class,'tui-field-label-text')]")
    private PWElement whyDoYouNeedMyLenderInfoLabel;
    @PWFindBy(xpath = "//mat-icon[starts-with(@aria-label,'Lender')]/following-sibling::p[contains(@class,'tui-info-box-content')]")
    private PWElement whyDoYouNeedMyLenderInfoContent;
    @PWFindBy(xpath = "//app-model-info-box//h1")
    private PWElement whyDoYouNeedMyLenderInfoLabelMobile;
    @PWFindBy(xpath = "//app-model-info-box//p[contains(@class,'model-caption-text')]")
    private PWElement whyDoYouNeedMyLenderInfoContentMobile;

    @PWFindBy(xpath = "//div[@class='lender-info-header']//h2")
    private PWElement lenderInfoHeaderSideSheet;
    @PWFindBy(xpath = "//div[@id='lender-address-section-title']//p")
    private PWElement lenderAddressSubHeader;
    @PWFindBy(xpath = "//mat-label[contains(text(),'Certificate expiration date')]")
    private PWElement formFieldCertificateExpDate;
    @PWFindBy(xpath = "//mat-hint[contains(text(),'mm/dd/yyyy')]")
    private PWElement formFieldCertificateExpDateFormat;
    @PWFindBy(xpath = "//input[contains(@aria-label,'Certification')]")
    private PWElement certExpDateInputField;
    @PWFindBy(xpath = "//input[contains(@aria-label,'Certification')]")
    private List<PWElement> certExpDateInputFieldList;
    @PWFindBy(xpath = "//mat-error[contains(text(),'Please provide your certification date.')]")
    private PWElement certificationErrorLabel;
    @PWFindBy(xpath = "//app-date-picker[@id='certificationDateDiv_certificationDate']//mat-datepicker-toggle//button")
    private PWElement certificateExpDatePickerButtonFMTPHome;
    @PWFindBy(xpath = "//div[contains(@class,'lender-zipcode')]//div[1]//mat-label")
    private PWElement formFieldLenderZipOrState;
    @PWFindBy(xpath = "//mat-label[contains(text(),'Lender name')]")
    private PWElement formFieldLenderName;
    @PWFindBy(xpath = "//div[contains(@class,'lender-info-header')]")
    private PWElement lenderInfoPopUpHeader;
    @PWFindBy(xpath = "//div[contains(@id,'lender-address-section-title')]")
    private PWElement lenderAddressSideSheetHeader;
    @PWFindBy(xpath = "//div[contains(text(),'proof of insurance.')]")
    private PWElement lenderAddressSideSheetSubHeader;
    @PWFindBy(xpath = "//div[contains(@class,'heating-system')]//a[contains(text(),'Edit')]")
    private PWElement editButtonPrimaryHeatingSource;
    @PWFindBy(xpath = "//div[contains(@class,'dog-breed')]//a[contains(text(),'Edit')]")
    private PWElement editButtonDogsOnPremises;
    @PWFindBy(xpath = "//button[contains(text(),'Next')]")
    private List<PWElement> nextButton;
    @PWFindBy(xpath = "//div[contains(@class,'lender-zipcode-state-field')]//input")
    private PWElement lenderZipOrStateTextBox;
    @PWFindBy(xpath = "//div[contains(@class,'lender-name-section')]//input")
    private PWElement lenderName;
    @PWFindBy(xpath = "//mat-option")
    private PWElement lenderDropdownOptions;
    @PWFindBy(xpath = "//mat-option//p[1]")
    private PWElement lenderNameSuggestedVal;
    @PWFindBy(linkText = "//a[contains(text(),'Edit')]")
    private List<PWElement> editHyperLink;
    @PWFindBy(linkText = "//h2[text()='Lender info' and @class='tui-subtitle']/following::a[contains(text(),'Edit') and @tabindex='0']")
    private PWElement editLenderInfoSideSheet;
    @PWFindBy(xpath = "//div[contains(@class,'tui-field-label')]/span")
    private PWElement lenderSearchTipsText;
    @PWFindBy(xpath = "//li[@class='tui-input-text'][1]")
    private PWElement lenderSearchTipsTextOne;
    @PWFindBy(xpath = "//li[@class='tui-input-text'][2]")
    private PWElement lenderSearchTipsTextTwo;
    @PWFindBy(xpath = "//li[@class='tui-input-text'][3]")
    private PWElement lenderSearchTipsTextThree;
    @PWFindBy(xpath = "//li[@class='tui-input-text'][4]")
    private PWElement lenderSearchTipsTextFour;
    @PWFindBy(xpath = "//li[@class='tui-input-text'][5]")
    private PWElement lenderSearchTipsTextFive;
    @PWFindBy(xpath = "//div[contains(@class,'lender-not-found-section')]/mat-checkbox")
    private PWElement iCantFindMyLenderCheckBox;
    @PWFindBy(xpath = "//div[@class='lender-not-found-section']/mat-checkbox//label")
    private PWElement iCantFindMyLenderLabel;
    @PWFindBy(xpath = "//div[@class='lender-not-found-section']/p")
    private PWElement iCantFindMyLenderDescriptionTitle;
    @PWFindBy(xpath = "//div[@class='lender-not-found-section']/p/following-sibling::ul")
    private PWElement iCantFindMyLenderDescription;
    @PWFindBy(xpath = "//a[contains(text(),'Edit')]")
    private PWElement lenderNotFoundEditButton;
    @PWFindBy(xpath = "//div[contains(@class,'lendername-selected')]/div[2]/div[1]/span[1]")
    private PWElement selectedLenderName;
    @PWFindBy(xpath = "//div[contains(@class,'lender-selected-section')]//div//span[4]/span")
    private PWElement selectedLenderSectionForLoanNum;
    @PWFindBy(xpath = "//div[contains(@class,'lender-selected-section')]//div/span[1]")
    private PWElement selectedLenderNameUnderMortgageSection;
    @PWFindBy(xpath = "//div[contains(@class,'lender-selected-section')]")
    private List<PWElement> selectedLenderSectionList;
    @PWFindBy(xpath = "//span[contains(text(),'Lender incomplete')]")
    private PWElement lenderIncompleteTitle;
    @PWFindBy(xpath = "//button[@aria-label='close']")
    private PWElement lenderInfoSideSheetCloseBtn;
    @PWFindBy(xpath = "//span[@id='lenderNotFoundLabel']")
    private PWElement lenderNotFoundLabel;
    @PWFindBy(xpath = "//span[contains(text(),'No lender on this property')]")
    private PWElement lenderIncompleteNoLenderOnThisProperty;
    @PWFindBy(xpath = "//span[contains(text(),'I will retry finding my lender')]")
    private PWElement lenderIncompleteRetryFindingLender;
    @PWFindBy(xpath = "//mat-dialog-actions//button")
    private PWElement lenderIncompleteContinueBtn;
    protected static final String ERROR_MESSAGE_XPATH = "//mat-error[not(@hidden)]";
    @PWFindBy(xpath = ERROR_MESSAGE_XPATH)
    protected PWElement errorMessage;
    @PWFindBy(xpath = "//div[contains(@class,'loan-info-field')]//mat-label[contains(text(),'Loan #')]")
    private PWElement formFieldLenderLoanNumber;
    @PWFindBy(xpath = "//div[contains(@class,'loan-info-field')]//input")
    private PWElement lenderLoanNumber;
    @PWFindBy(xpath = "//mat-error[contains(text(),'Maximum of 25 characters for loan #.')]")
    private PWElement loanErrorMessageForMaxChar;
    @PWFindBy(xpath = "//div[contains(@id,'loan-number-section-title')]")
    private PWElement loanNumberHeaderInSideSheet;
    @PWFindBy(xpath = "//div[contains(text(),'Including this helps your lender match the insurance policy')]")
    private PWElement loanNumberSubHeaderInSideSheet;
    @PWFindBy(xpath = "//mat-hint[contains(text(),'Optional')]")
    private PWElement loanNumberHintText;
    @PWFindBy(xpath = "//div[@id='impound-account-section-title']/p")
    private PWElement impoundAccountTitle;
    @PWFindBy(xpath = "//div[@class='impound-details-section tui-caption']")
    private PWElement impoundAccountSubTitle;
    @PWFindBy(xpath = "//*[@id='RADIO_BUTTON_FOR_IMPOUND_Mortgagee']//label")
    private PWElement impoundAccountNewPolicyAndRenewalRdoBtn;
    @PWFindBy(xpath = "//*[@id='RADIO_BUTTON_FOR_IMPOUND_mortagageePayRenewal']//label")
    private PWElement impoundAccountRenewalRdoBtn;
    @PWFindBy(xpath = "//*[@id='RADIO_BUTTON_FOR_IMPOUND_Insured']//label")
    private PWElement impoundAccountNoRdoBtn;
    @PWFindBy(xpath = "//button[contains(text(),'Done')]")
    private PWElement impoundAccountDoneBtn;
    @PWFindBy(xpath = "//mat-divider[contains(@class, 'emergency_mortgage_divider')]")
    private PWElement emergencyMortgageAssistanceDivider;
    private static final String EMERGENCY_MORTGAGE_CARD_XPATH = "//mat-card[contains(@class,'emergency_mortgage_card')]";
    @PWFindBy(xpath = EMERGENCY_MORTGAGE_CARD_XPATH + "//mat-slide-toggle")
    private PWElement emergencyMortgageAssistanceToggle;
    @PWFindBy(xpath = "//mat-card[contains(@class,'emergency_mortgage_card')]//mat-slide-toggle//label")
    private PWElement emergencyMortgageAssistanceLabel;
    @PWFindBy(xpath = EMERGENCY_MORTGAGE_CARD_XPATH + "//div[contains(@class, 'tui-caption-text')]")
    private PWElement emergencyMortgageAssistanceDescription;
    @PWFindBy(xpath = EMERGENCY_MORTGAGE_CARD_XPATH + "//div[contains(@class, 'tui-subtitle-text-2')]")
    private PWElement emergencyMortgageAssistanceSubHeader;
    @PWFindBy(xpath = "//div[contains(@class,'policy-start-date-section')]//h2")
    private PWElement policyStartDateHeader;
    @PWFindBy(xpath = "//app-date-picker[@id='policyStartDiv_policyStartDate']/preceding-sibling::p")
    private PWElement whenWouldYouLikeYourPolicyToBeginQuestion;
    @PWFindBy(xpath = "//input[contains(@aria-label,'Policy start date in the format of mmddyyyy.')]")
    private PWElement policyStartDateInputFieldFMTPHome;
    @PWFindBy(xpath = "//app-date-picker[@id='policyStartDiv_policyStartDate']//mat-label[contains(text(),'date')]")
    private PWElement policyStartDatePlaceHolderTextFMTPHome;
    @PWFindBy(xpath = "//app-date-picker[@id='policyStartDiv_policyStartDate']//mat-datepicker-toggle//button")
    private PWElement policyStartDatePickerButtonFMTPHome;
    @PWFindBy(xpath = "//app-date-picker[@id='certificationDateDiv_certificationDate']//mat-datepicker-toggle//button")
    private PWElement certExpirationDatePickerButtonFMTPHome;
    @PWFindBy(xpath = "//div[contains(@class,'tui-info-box')]//mat-icon[@aria-label='Early shopping discount information icon']/following-sibling::p[contains(@class,'tui-field-label-text')]")
    private PWElement earlyShoppingDiscountInfoTitleFMTPHome;
    @PWFindBy(xpath = "//div[contains(@class,'tui-info-box')]//mat-icon[@aria-label='Early shopping discount information icon']/following-sibling::p[contains(@class,'tui-info-box-content')]")
    private PWElement earlyShoppingDiscountDescriptionFMTPHome;
    @PWFindBy(xpath = "//div[contains(@class,'mat-calendar-controls')]//button[contains(@class,'mat-calendar-period-button')]")
    private PWElement monthYearLabelInCalenderPopUpFMTPHome;
    @PWFindBy(xpath = "//div[contains(@class,'mat-calendar-controls')]//button[contains(@class,'mat-calendar-previous-button')]")
    private PWElement previousMonthButtonInCalenderPopUpFMTPHome;
    @PWFindBy(xpath = "//div[contains(@class,'mat-calendar-controls')]//button[contains(@class,'mat-calendar-next-button')]")
    private PWElement nextMonthButtonInCalenderPopUpFMTPHome;
    @PWFindBy(xpath = "//button[descendant::*[contains(@class,'selected')]]")
    private PWElement selectedDateInDatePickerPopUp;
    @PWFindBy(xpath = "//button[contains(.,'Close calendar')]")
    private PWElement closeCalendarButton;
    private static final String EARLY_SHOPPING_INFO_TITLE = "Early shopping discount";
    private static final String EARLY_SHOPPING_DISCOUNT_DESCRIPTION_DESKTOP = "If your policy start date is 7 or more days from today, you may get an early shopping discount. You can start your policy up to 60 days in the future.";
    private static final String EARLY_SHOPPING_DISCOUNT_DESCRIPTION_MOBILE = "If your policy start date is 7 or more days from today, you may get an early shopping discount. You can start your policy up to 60 days in the future.";
    @PWFindBy(xpath = "//h2[contains(text(),'Policy start')]/following-sibling::div/mat-icon[text()='info']")
    private PWElement earlyShoppingInfoIconMobile;
    @PWFindBy(xpath = "//app-model-info-box//h1")
    private PWElement earlyShoppingInfoTitleMobile;
    @PWFindBy(xpath = "//app-model-info-box//h1/following-sibling::p")
    private PWElement earlyShoppingInfoDescriptionMobile;
    @PWFindBy(xpath = "//app-model-info-box//mat-icon[text()='close']")
    private PWElement earlyShoppingInfoButtonCloseMobile;
    @PWFindBy(xpath = "//mat-label[contains(text(),'Plumbing other than Copper, PEX, or PVC')]")
    private PWElement plumbingOtherThanCopperCheckBox;
    @PWFindBy(xpath = "//mat-card[contains(@class,'plumbing-card')]//mat-radio-button//label[contains(.,'Galvanized')]")
    private PWElement plumbingGalvanizedRadioButtonLabel;
    @PWFindBy(xpath = "//mat-label[contains(text(),'Primary heating')]")
    private PWElement primaryHeatingSourceCheckBox;
    @PWFindBy(xpath = "//mat-label[contains(text(),'Unrepaired structures')]")
    private PWElement unrepairedStructuresCheckBox;
    @PWFindBy(xpath = "//p[contains(text(),'One (or more) separate structures may require repairs, is not properly maintained, or is being built.')]")
    private PWElement unrepairedStructuresCheckBoxSubHeader;
    @PWFindBy(xpath = "//mat-label[contains(text(),'Business operated')]")
    private PWElement businessOperatedOnPremisesCheckBox;
    @PWFindBy(xpath = "//p[contains(text(),'Excludes home offices if working remotely for an employer.')]")
    private PWElement businessOperatedOnPremisesCheckBoxSubHeader;
    @PWFindBy(xpath = "//mat-label[contains(text(),'Dog(s) on premises')]")
    private PWElement dogsOnPremisesCheckBox;
    @PWFindBy(xpath = "//mat-label[contains(text(),'Pet with bite')]")
    private PWElement petWithBiteHistoryCheckBox;
    @PWFindBy(xpath = "//p[contains(text(),'A pet, such as a dog, cat, bird, or reptile who has bitten and injured a person or animal.')]")
    private PWElement petWithBiteHistoryCheckBoxSubHeader;
    @PWFindBy(xpath = "//div[contains(@class,'row tui-stacking-top-md')]//mat-radio-button//input")
    private List<PWElement> primaryHeatingSourceSideSheetRadioButtons;
    @PWFindBy(xpath = "//app-dog-breed-selection//mat-checkbox")
    private List<PWElement> dogsOnPremisesCheckBoxes;
    @PWFindBy(xpath = "//app-dog-breed-selection//mat-checkbox//label")
    private List<PWElement> dogsOnPremisesCheckBoxesLabels;
    @PWFindBy(xpath = "//div[contains(@class,'heating-system-update-section')]/button[contains(text(),'Save')]")
    private PWElement saveButtonPrimaryHeatSideSheet;
    @PWFindBy(xpath = "//div[contains(@class,'heating-system-update-section')]/a[contains(text(),'Cancel')]")
    private PWElement cancelButtonPrimaryHeatSideSheet;
    @PWFindBy(xpath = "//mat-icon[@aria-label='Close']")
    private PWElement crossButtonPrimaryHeatSideSheet;
    @PWFindBy(xpath = "//div[contains(@class,'save-cta-section')]/button[contains(text(),'Save')]")
    private PWElement saveButtonDogsOnPremisesSideSheet;
    @PWFindBy(xpath = "//div[contains(@class,'save-cta-section')]/a[contains(text(),'Cancel')]")
    private PWElement cancelButtonDogsOnPremisesSideSheet;
    @PWFindBy(xpath = "//div[contains(@class,'heating-system-added-value')]")
    private PWElement primaryHeatingSourceSelectedValue;
    @PWFindBy(xpath = "//div[contains(@class,'dog-breed-section')]/span")
    private PWElement dogsOnPremisesSelectedValue;
    @PWFindBy(xpath = "//h2[contains(text(), 'FORTIFIED certification')]")
    private PWElement fortifiedCertificationLabel;
    @PWFindBy(xpath = "//h2[contains(text(), 'FORTIFIED certification')]")
    private List<PWElement> fortifiedCertificationLabelList;
    @PWFindBy(xpath = "//p[contains(text(), 'Does your home have valid or active FORTIFIED certification, and does the certification expire after your policy start date?')]")
    private PWElement fortifiedCertificationSubLabel;
    @PWFindBy(xpath = "//p[contains(text(), 'Does your home have valid or active FORTIFIED certification, and does the certification expire after your policy start date?')]")
    private List<PWElement> fortifiedCertificationSubLabelList;
    @PWFindBy(xpath = "//div[contains(@class,'tui-stacking-md ng-star-inserted')]")
    private PWElement fortifiedNoSelectionDiscountRemovalMessage;
    @PWFindBy(xpath = "//div[contains(@class,'tui-stacking-md ng-star-inserted')]")
    private List<PWElement> fortifiedNoSelectionDiscountRemovalMessageList;
    @PWFindBy(xpath = "//p[contains(text(),'Plumbing systems help')]")
    private PWElement plumbingSystemsHelpLink;
    @PWFindBy(xpath = "//h1[contains(text(),'Plumbing systems')]")
    private PWElement plumbingSideSheetHeader;
    @PWFindBy(xpath = "//h2[contains(text(),'Heating systems')]")
    private PWElement primaryHeatingSourceSideSheetHeader;
    @PWFindBy(xpath = "//h2[contains(text(),'Dog(s) on premises')]")
    private PWElement dogsOnPremisesSideSheetHeader;
    @PWFindBy(xpath = "//p[contains(@class,'tui-input')]")
    private PWElement heatingSystemsSubHeaderSideSheet;
    @PWFindBy(xpath = "//div[contains(text(),'" + DOGSONPREMISES_SUBHEADER_CONTENT + "')]")
    private PWElement dogsOnPremisesSubHeaderSideSheet;
    @PWFindBy(xpath = "//p[contains(text(),'With thermostat')]")
    private PWElement thermostatSubHeader;
    @PWFindBy(xpath = "//p[contains(text(),'Without thermostat')]")
    private PWElement withOutThermostatSubHeader;
    @PWFindBy(xpath = "//p[contains(text(),'No heating system')]")
    private PWElement noHeatingSystemSubHeader;
    @PWFindBy(xpath = "//mat-radio-group//div[1]//mat-radio-button//label")
    private List<PWElement> withThermoStatHeatingSystemOptions;
    @PWFindBy(xpath = "//mat-radio-group//div[2]//mat-radio-button//label")
    private List<PWElement> withoutThermoStatHeatingSystemOptions;
    @PWFindBy(xpath = "//mat-radio-group//div[3]//mat-radio-button//label")
    private PWElement noHeatingSystemOption;
    @PWFindBy(xpath = "//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'Copper')]")
    private PWElement copperSubHeaderSideSheet;
    @PWFindBy(xpath = "//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'PVC')]")
    private PWElement pvcSubHeaderSideSheet;
    @PWFindBy(xpath = "//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'PEX')]")
    private PWElement pexSubHeaderSideSheet;
    @PWFindBy(xpath = "//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'Galvanized')]")
    private PWElement galvanizedSubHeaderSideSheet;
    @PWFindBy(xpath = "//p[contains(@class,'tui-subtitle-text-2') and contains(text(),'Polybutylene')]")
    private PWElement polybutyleneSubHeaderSideSheet;
    @PWFindBy(xpath = "//p[contains(@class,'tui-input-text') and contains(text(),'" + PLUMBING_COPPER_CONTENT + "')]")
    private PWElement copperSubHeaderContentSideSheet;
    @PWFindBy(xpath = "//p[contains(@class,'tui-input-text') and contains(text(),'A white- or cream-colored plastic')]")
    private PWElement pvcSubHeaderContentSideSheet;
    @PWFindBy(xpath = "//p[contains(@class,'tui-input-text') and contains(text(),'A flexible plastic pipe that is white')]")
    private PWElement pexSubHeaderContentSideSheet;
    @PWFindBy(xpath = "//p[contains(@class,'tui-input-text') and contains(text(),'" + PLUMBING_GALVANIZED_CONTENT + "')]")
    private PWElement galvanizedSubHeaderContentSideSheet;
    @PWFindBy(xpath = "//p[contains(@class,'tui-input-text') and contains(text(),'A flexible plastic pipe that is usually gray,')]")
    private PWElement polybutyleneSubHeaderContentSideSheet;
    @PWFindBy(xpath = "//mat-icon[@aria-label='Close']")
    private PWElement otherQuestionsSideSheetCloseBtn;
    @PWFindBy(xpath = "//span[@class='mat-radio-label-content']")
    private List<PWElement> listOfFortifiedCertification_Impound_RdoBtnLabels;
    @PWFindBy(xpath = "//mat-radio-group[@aria-label='Does your lender include your property insurance costs in your monthly mortgage payments? (common)']//mat-radio-button")
    private List<PWElement> escrowAccountRadioButtonOptionsLabels;
    @PWFindBy(xpath = "//span[@class='mat-radio-label-content']")
    private List<PWElement> listOfFortifiedCertification_Impound;
    @PWFindBy(xpath = "//label[contains(text(),'Designation')]")
    private PWElement designationGroupRdbBtnHeader;
    @PWFindBy(xpath = "//label[contains(text(),'Program')]")
    private PWElement programGroupRdbBtnHeader;
    @PWFindBy(xpath = "//label[contains(text(),'Roof category')]")
    private PWElement roofCategoryGroupRdbBtnHeader;
    @PWFindBy(xpath = "//label[contains(text(),'Designation')]")
    private List<PWElement> designationGroupRdbBtnHeaderList;
    @PWFindBy(xpath = "//label[contains(text(),'Program')]")
    private List<PWElement> programGroupRdbBtnHeaderList;
    @PWFindBy(xpath = "//label[contains(text(),'Roof category')]")
    private List<PWElement> roofCategoryGroupRdbBtnHeaderList;
    @PWFindBy(xpath = "//mat-radio-group//mat-radio-button[contains(@id,'DESIGNATION')]")
    private List<PWElement> designationRadioButtons;
    @PWFindBy(xpath = "//mat-radio-group//mat-radio-button[contains(@id,'PROGRAM')]")
    private List<PWElement> programRadioButtons;
    @PWFindBy(xpath = "//mat-radio-group//mat-radio-button[contains(@id,'ROOF')]")
    private List<PWElement> roofCategoryRadioButtons;
    @PWFindBy(xpath = "//mat-radio-button[contains(@id,'DESIGNATION')]")
    private List<PWElement> designationRadioButtonsLabels;
    @PWFindBy(xpath = "//mat-radio-button[contains(@id,'PROGRAM')]")
    private List<PWElement> programRadioButtonsLabels;
    @PWFindBy(xpath = "//mat-radio-button[contains(@id,'ROOF')]")
    private List<PWElement> roofCategoryRadioButtonsLabels;
    @PWFindBy(xpath = "//p[contains(text(),'Please specify one per section:')]")
    private PWElement specifyOnePerSectionLabel;
    @PWFindBy(xpath = "//p[contains(text(),'Please specify one per section:')]")
    private List<PWElement> specifyOnePerSectionLabelList;
    private static final String EARLY_SHOPPER_DISCOUNT_CONGRATULATIONS_MSG_XPATH = "//div[contains(@class,'shopper_discount')]//p";
    @PWFindBy(xpath = EARLY_SHOPPER_DISCOUNT_CONGRATULATIONS_MSG_XPATH)
    private PWElement earlyShopperDiscountCongratulationsMessage;
    private static final String EARLY_SHOPPER_DISCOUNT_CONGRATULATIONS_GREEN_CHECKMARK_XPATH = "//div[contains(@class,'shopper_discount')]//mat-icon";
    @PWFindBy(xpath = EARLY_SHOPPER_DISCOUNT_CONGRATULATIONS_GREEN_CHECKMARK_XPATH)
    private PWElement earlyShopperDiscountMessageGreenCheckMark;
    private static final String POLICY_START_DATE_RANGE_MSG_XPATH = "//mat-error[contains(text(), 'Please select a date between')]";
    @PWFindBy(xpath = POLICY_START_DATE_RANGE_MSG_XPATH)
    private PWElement policyStartDateRangeError;
    private static final String PLEASE_PROVIDE_POLICY_START_DATE_ERROR = "Please provide your policy start date.";
    @PWFindBy(xpath = "//app-date-picker[@id='policyStartDiv_policyStartDate']//mat-error")
    private PWElement pleaseProvidePolicyStartDateError;
    @PWFindBy(xpath = "//div[contains(@class,'home-purchase-date-section')]//h2")
    private PWElement homePurchaseDateHeader;
    @PWFindBy(xpath = "//div[contains(@class,'home-purchase-date-section')]//p")
    private PWElement whenDidYouPurchaseThisHomeQuestion;
    @PWFindBy(xpath = "//input[contains(@aria-label,'Home purchase date')]")
    private PWElement homePurchaseDateInputField;
    @PWFindBy(xpath = "//app-date-picker[@id='homePurchaseDiv_homePurchaseDate']//mat-label")
    private PWElement homePurchaseDatePlaceHolderText;
    @PWFindBy(xpath = "//app-date-picker[@id='homePurchaseDiv_homePurchaseDate']//mat-datepicker-toggle//button")
    private PWElement homePurchaseDatePickerButton;
    private static final String EXPECTED_PURCHASE_DATE_CANNOT_BE_IN_FUTURE_ERROR = "Purchase date cannot be future date.";
    private static final String HOME_PURCHASE_DATE_ERROR_CANT_BE_IN_FUTURE_XPATH = "//mat-error[contains(text(),'" + EXPECTED_PURCHASE_DATE_CANNOT_BE_IN_FUTURE_ERROR + "')]";
    @PWFindBy(xpath = HOME_PURCHASE_DATE_ERROR_CANT_BE_IN_FUTURE_XPATH)
    private PWElement homePurchaseDateCantBeInFutureError;
    private static final String EXPECTED_INVALID_HOME_PURCHASE_DATE_ERROR = "Invalid Home purchase date";
    private static final String INVALID_HOME_PURCHASE_DATE_ERROR_XPATH = "//mat-error[contains(text(),'" + EXPECTED_INVALID_HOME_PURCHASE_DATE_ERROR + "')]";
    @PWFindBy(xpath = INVALID_HOME_PURCHASE_DATE_ERROR_XPATH)
    private PWElement invalidHomePurchaseDateError;
    private static final String HALF_DATE = "04/19/";
    @PWFindBy(xpath = "//mat-button-toggle-group/following-sibling::div")
    private PWElement discountRemovalMessageFortifiedSection;
    private static final String DISCOUNT_MESSAGE_FORTIFIED_CERTIFICATION = "Note: This previously-applied discount will be removed from the final quote.";
    private static final String EXPECTED_SNACK_BAR_MESSSAGE = "We've updated your response to \"No\" mortgage on property.";
    @PWFindBy(xpath = "//img[@alt='Farmers Logo']")
    private PWElement farmersLogoThankYouScreen;

    @PWFindBy(xpath = "//h1[contains(text(),'Thank you')]")
    private PWElement thankYouScreenTitle;
    @PWFindBy(xpath = "//p[contains(text(),'Because your home')]")
    private PWElement thankYouScreenSubTitle;
    @PWFindBy(id = "emailLink")
    private PWElement emailLink;
    @PWFindBy(linkText = "Done")
    private PWElement linkCloseEmailSnackBar;
    @PWFindBy(xpath = "//div[contains(@class,'save-in-progress')]/p")
    private PWElement saveInProgressFooter;
    @PWFindBy(xpath = "//div[contains(@class,'save-quote')]")
    private PWElement quoteNumberText;
    @PWFindBy(xpath = "//tui-oneui-footer//div[contains(@class,'tui-oneui-footer-logo-container')]/img")
    private PWElement farmersLogoFooter;
    @PWFindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_personal-information-use']")
    private PWElement footerPersonalInfoUseLink;
    @PWFindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_digital-accessibility']")
    private PWElement footerDigitalAccessibilityLink;
    @PWFindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_terms-of-use']")
    private PWElement footerTermsOfUseLink;
    @PWFindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_privacy-center']")
    private PWElement footerPrivacyCenterLink;
    @PWFindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_notice-of-information-practices']")
    private PWElement footerNoticeOfInformationPracticesLink;
    @PWFindBy(xpath = "//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_do-not-sell']")
    private PWElement footerDoNotSellLink;
    @PWFindBy(xpath = "//button[contains(text(),'Continue') and @tabindex=0]")
    private PWElement escrowAccountPopupContinueBtn;
    @PWFindBy(xpath = "//span[contains(text(),'Lender info incomplete')]")
    private PWElement escrowAccountPopupHeader;
    @PWFindBy(xpath = "//span[contains(text(),'We need more information about your loan to complete your policy.')]")
    private PWElement escrowAccountPopupSubHeader;
    @PWFindBy(xpath = "//a[contains(text(),'This property has no mortgage')]")
    private PWElement escrowAccountPopupContentLink;
    private static final String TERRITORY_SELECT_XPATH = "//div[contains(@class,'territory-option')]";
    @PWFindBy(xpath = TERRITORY_SELECT_XPATH + "//mat-select")
    private PWElement selectTerritory;
    @PWFindBy(xpath = "//mat-option")
    private PWElement optionTerritory;
    @PWFindBy(xpath = "//div[@role='listbox']")
    private PWElement territoryList;
    @PWFindBy(xpath = TERRITORY_SELECT_XPATH + "//label")
    private PWElement territoryPlaceHoldertext;
    @PWFindBy(xpath = "//form[@id='additional-info-main-form']//div[1]/label")
    private PWElement selectTerritoryQuestion;
    @PWFindBy(xpath = "//mat-label[contains(text(),'Estimated closing date')]")
    private PWElement whenIsEscrowExpectedToCloseLabel;
    @PWFindBy(xpath = "//mat-icon[contains(@class,'lightbulb-icon')]")
    private PWElement lightBulbIcon;
    @PWFindBy(xpath = "//p[text()='Not sure when escrow is closing?']")
    private PWElement notSureWhenEscrowIsClosingTitle;
    @PWFindBy(xpath = "//p[contains(text(),\"Don't worry, you can change the date\")]")
    private PWElement notSureWhenEscrowIsClosingDescText;
    @PWFindBy(xpath = "(//div[@class='tui-info-box']/p)[1]")
    private PWElement escrowInfoBoxTitle;
    @PWFindBy(xpath = "(//div[@class='tui-info-box']/p)[2]")
    private PWElement escrowInfoBoxDescText;
    @PWFindBy(xpath = "(//div[@class='tui-info-box']/p)[3]")
    private PWElement escrowInfoBoxNoteText;
    @PWFindBy(xpath = "//td[contains(@class,'mat-calendar-body-cell-container')]/button")
    private List<PWElement> calenderDateCells;
    @PWFindBy(xpath = "//div[@class='mat-calendar-header']//span[@id='mat-calendar-button-0']")
    private PWElement calendarMonthYearHeader;
    private static final String RC3_SCREEN_XPATH = "//app-just-afew-more-things/child::*[contains(name(), 'rc3')]";
    @PWFindBy(xpath = RC3_SCREEN_XPATH)
    private PWElement rc3Screen;
    @PWFindBy(xpath = "//app-rc3-loading-hrc//h1")
    private PWElement rc3MainHeading;
    @PWFindBy(xpath = "//app-rc3-loading-hrc//div[@class='tui-input-text']")
    private PWElement rc3SubHeading1;
    @PWFindBy(xpath = "//app-rc3-loading-hrc//div[@class='tui-field-label']")
    private PWElement rc3SubHeading2;

    private final String RACE_TOGGLE_GROUP_XPATH = "//mat-button-toggle-group[@aria-label='Homeowner info']";
    @PWFindBy(xpath = RACE_TOGGLE_GROUP_XPATH + "//mat-button-toggle[contains(.,'Yes')]")
    private List<PWElement> rnogToggleYesButtons;
    @PWFindBy(xpath = RACE_TOGGLE_GROUP_XPATH + "//mat-button-toggle[contains(.,'No')]")
    private List<PWElement> rnogToggleNoButtons;

    //mat-button-toggle-group[contains(@class,'waterShutOffToggle')]
    private final String WATER_SHUTOFF_TOGGLE_GROUP_XPATH = "//mat-button-toggle-group[contains(@class,'waterShutOffToggle')]";
    @PWFindBy(xpath = WATER_SHUTOFF_TOGGLE_GROUP_XPATH + "//mat-button-toggle[contains(.,'Yes')]/button")
    private PWElement waterShutoffToggleYesButton;
    @PWFindBy(xpath = WATER_SHUTOFF_TOGGLE_GROUP_XPATH + "//mat-button-toggle[contains(.,'No')]/button")
    private PWElement waterShutoffToggleNoButton;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceHRCJustAFewMoreThingsBasePage() throws Exception {
    }

    public boolean isOnJFMTPage(boolean longWait) {
        int timer = longWait? Property.PAGELOADTIMEOUT : 5;
        return isElementVisible(justFewMoreThingsTitle, timer);
    }

    public boolean isOnBundleJMFTPage() {
        return isOnBundleJMFTPage(5);
    }

    public boolean isOnBundleJMFTPage(int timer) {
        waitForSpinnerToBeGone();
        return isElementVisible(policyStartDateHeader, timer);
    }

    public void verifyJustAFewMoreThingsHeader(FarmersSoftAssert fsa) throws Exception {
        waitElementBeVisible(justFewMoreThingsTitle);
        String pageTitle = getTextFromElement(justFewMoreThingsTitle);
        fsa.assertTrue(pageTitle.equals(JFMT_INFO_HEADER_TITLE) || pageTitle.equals(JFMT_INFO_HEADER_TITLE2), "JFMT Page title: <" + pageTitle + "> check.");
        if (!Property.getDriver().matches(FIREFOX + "|" + SAFARI)) { /* manually the page title is visible, but when run by automation it is not visible in Firefox and Safari */
            fsa.assertTrue(isElementInViewport(justFewMoreThingsTitle), "JAFMT Page - page title is in Viewport.");
        }
        fsa.assertEquals(getTextFromElement(justFewMoreThingsLabelInfoSubHeader), JFMT_INFO_SUBHEADER_LABEL, "JFMT Page Sub-title check");
    }

    public void verifyLenderInfoHeaderAndSubHeader(FarmersSoftAssert fsa, String lobType) throws Exception {
        waitElementBeVisible(lenderInfoLabel);
        fsa.assertEquals(getTextFromElement(lenderInfoLabel), LENDER_INFO_HEADER_LABEL, "Lender Info header Content check");
        fsa.assertEquals(getTextFromElement(lenderInfoSubLabel), LENDER_INFO_SUBHEADER_LABEL, "Lender Info sub header Content check");
        String LENDER_TOOLTIP_TEXT = lobType.equals(HOME) ? String.format(WHY_DO_YOU_NEED_MY_LENDER_INFO_CONTENT, "us") + SPACE + MORTGAGE_TEXT : String.format(WHY_DO_YOU_NEED_MY_LENDER_INFO_CONTENT, "you");
        if (isUseMobileViewEnabled()) {
            clickOnHiddenElement(whyDoYouNeedMyLenderInfoIcon);
            fsa.assertEquals(getTextFromElement(whyDoYouNeedMyLenderInfoLabelMobile), WHY_DO_YOU_NEED_MY_LENDER_INFO_LABEL, "Lender Info box label - mobile.");
            fsa.assertEquals(getTextFromElement(whyDoYouNeedMyLenderInfoContentMobile), LENDER_TOOLTIP_TEXT, "Lender Info box content - mobile.");
            closeSideSheetByEscKey(fsa);
        } else {
            fsa.assertEquals(getTextFromElement(whyDoYouNeedMyLenderInfoLabel), WHY_DO_YOU_NEED_MY_LENDER_INFO_LABEL, "Lender Info box label - desktop.");
            fsa.assertEquals(getTextFromElement(whyDoYouNeedMyLenderInfoContent), LENDER_TOOLTIP_TEXT, "Lender Info box content - desktop.");
        }
    }

    public void verifyFortifiedCertificationHeaderAndSubHeader(FarmersSoftAssert fsa) {
        waitElementBeVisible(fortifiedCertificationLabel);
        fsa.assertEquals(getTextFromElement(fortifiedCertificationLabel), FORTIFIED_CERTIFICATION_HEADER_LABEL, "Fortified cert header Content check");
        fsa.assertEquals(getTextFromElement(fortifiedCertificationSubLabel), FORTIFIED_CERTIFICATION_SUBHEADER_LABEL, "Fortified cert sub header Content check");
    }


    public void selectMortgageOnThisProperty(boolean mortgageSelectionValue) throws Exception {
        waitForPageToBeReady();
        if (isElementPresent(PWBy.xpath(MORTGAGE_ON_PROPERTY_BUTTON_XPATH))) {
        	String buttonXpath = mortgageSelectionValue ? "//button[@aria-label='Yes']" : "//button[@aria-label='No']";
        	PWElement we = driver().findElement(PWBy.xpath(MORTGAGE_ON_PROPERTY_BUTTON_XPATH + buttonXpath));
        	waitAndClickElement(we);
        }
    }

    public void selectFortifiedCertification(boolean fortifiedCertSelectionValue) throws Exception {
        waitForPageToBeReady();
        String buttonXpath = fortifiedCertSelectionValue ? "//button[@aria-label='Yes']" : "//button[@aria-label='No']";
        PWElement we = driver().findElement(PWBy.xpath(FORTIFIED_CERTIFICATE_BUTTON_XPATH + buttonXpath));
        waitAndClickElement(we);
    }

    public void validateFortifiedCertificationToggleButtonsAndInputField(FarmersSoftAssert fsa) throws Exception {
        String buttonYes = "//button[@aria-label='Yes']";
        String buttonNo = "//button[@aria-label='No']";
        PWElement xpathForButtonYes = driver().findElement(PWBy.xpath(FORTIFIED_CERTIFICATE_BUTTON_XPATH + buttonYes));
        PWElement xpathForButtonNo = driver().findElement(PWBy.xpath(FORTIFIED_CERTIFICATE_BUTTON_XPATH + buttonNo));
        fsa.assertEquals(getTextFromElement(xpathForButtonYes), YES, "Expected button check under fortified certification section - YES");
        fsa.assertEquals(getTextFromElement(xpathForButtonNo), NO, "Expected button check under fortified certification section - NO");
        fsa.assertTrue(isButtonSelected(xpathForButtonYes),  "Cert Exp is selected as YES by default when landed on JFMT page");
        fsa.assertEquals(getValueFromWebElement(certExpDateInputField), EMPTY_STRING, "Cert Exp date is empty by default when landed on JFMT");
    }

    public void validateCertificateExpFormFields(FarmersSoftAssert fsa) {
        final String CERTIFICATE_EXP_DATE = "Certificate expiration date";
        final String CERTIFICATE_EXP_DATE_FORMAT = "mm/dd/yyyy";
        waitForPageToBeReady();
        fsa.assertEquals(getTextFromElement(formFieldCertificateExpDate), CERTIFICATE_EXP_DATE, "Certificate exp date field form field message check");
        fsa.assertEquals(getTextFromElement(formFieldCertificateExpDateFormat), CERTIFICATE_EXP_DATE_FORMAT, "Certificate exp date field form field message mm/dd/yyyy check");
    }

    public void validateCertificateExpDateErrors(FarmersSoftAssert fsa) throws Exception {
        final String SELECT_ONE_OPTION_PER_SECTION_ERROR = "Please select one option per section.";
        final String PROVIDE_YOUR_CERTIFICATION_ERROR = "Please provide your certification date.";
        final String CERTIFICATION_EXP_DATE_ERROR = "Certification date must be after policy start date.";
        driver().navigate().refresh();
        clickContinueButton();
        waitForPageToBeReady();
        sleep(2);
        fsa.assertTrue(getPageErrors().contains(PROVIDE_YOUR_CERTIFICATION_ERROR), PROVIDE_YOUR_CERTIFICATION_ERROR + ERROR_FOUND);
        fsa.assertTrue(getPageErrors().contains(SELECT_ONE_OPTION_PER_SECTION_ERROR), SELECT_ONE_OPTION_PER_SECTION_ERROR + ERROR_FOUND);
        AppStore appStore = getSessionStorageAppStore();
        String expectedPolicyStartDate = appStore.getHome().getContactInfo().getPolicyStartDate();
        validateContentOfCertificateExpirationDatePickerPopUp(fsa, expectedPolicyStartDate);
        sendKeysToElement(certExpDateInputField, "04/24/2024"); //hard coded as policy start date when entered is not giving error.
        certExpirationDatePickerButtonFMTPHome.sendKeys(PWKeys.TAB);
        //enter effective Date into cert exp date field and validate error message
        waitForPageToBeReady();
        waitForSpinnerToBeGone();
        fsa.assertTrue(getPageErrors().contains(CERTIFICATION_EXP_DATE_ERROR), CERTIFICATION_EXP_DATE_ERROR + ERROR_FOUND);
    }

    public void validateManuallyEnteredCertificationDate(String certExpDateVal, FarmersSoftAssert fsa) throws Exception {
        int dateVal = Integer.parseInt(certExpDateVal);
        AppStore appStore = getSessionStorageAppStore();
        String expectedPolicyStartDate = appStore.getHome().getContactInfo().getPolicyStartDate();
        LocalDate formattedExpectedDate = getFormattedDateFromStringDate(expectedPolicyStartDate).plusDays(dateVal);
        String dateToEnter = getFormattedForPolicyStartDate(formattedExpectedDate);
        //Adding days to the policy start date - no of days come from data sheet.
        sendKeysToElement(certExpDateInputField, dateToEnter);
        fsa.assertEquals(getAttributeData(certExpDateInputField, VALUE), dateToEnter, "Manually entered date check");
    }

    public void validateAllRdoBtnUnderFortifiedCertification(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(specifyOnePerSectionLabel), SPECIFY_ONE_PER_SECTION_LABEL, "specify one per section label check");

        // validate content of designation radio button section
        List<String> expectedFortifiedCertificationDesignationRdoBtnLabels = Arrays.asList(DESIGNATION_RDO_BTN1, DESIGNATION_RDO_BTN2, DESIGNATION_RDO_BTN3);
        List<String> foundFortifiedCertificationDesignationRdoBtnLabels = designationRadioButtonsLabels.stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(getTextFromElement(designationGroupRdbBtnHeader), DESIGNATION_HEADER, "Header for Designation radio button group check");
        fsa.assertEquals(designationRadioButtons.size(), 3, "Designation radio buttons size check");
        fsa.assertEquals(foundFortifiedCertificationDesignationRdoBtnLabels, expectedFortifiedCertificationDesignationRdoBtnLabels, "Designation radio buttons labels check");

        // validate content of program radio button section
        List<String> expectedFortifiedCertificationProgramRdoBtnLabels = Arrays.asList(PROGRAM_RDO_BTN1, PROGRAM_RDO_BTN2, PROGRAM_RDO_BTN3, PROGRAM_RDO_BTN4);
        List<String> foundFortifiedCertificationProgramRdoBtnLabels = programRadioButtonsLabels.stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(getTextFromElement(programGroupRdbBtnHeader), PROGRAM_HEADER, "Header for program radio button group check");
        fsa.assertEquals(programRadioButtons.size(), 4, "Program radio buttons size check");
        fsa.assertEquals(foundFortifiedCertificationProgramRdoBtnLabels, expectedFortifiedCertificationProgramRdoBtnLabels, "Program radio buttons labels check");

        checkNoRadioButtonSelected(fsa);

        // validate content of roof category radio button section
        List<String> expectedFortifiedCertificationRoofCategoryRdoBtnLabels = Arrays.asList(ROOF_RDO_BTN1, ROOF_RDO_BTN2);
        List<String> foundFortifiedCertificationRoofRdoBtnLabels = roofCategoryRadioButtonsLabels.stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(getTextFromElement(roofCategoryGroupRdbBtnHeader), ROOF_CATEGORY_HEADER, "Header for roof category radio button group check");
        fsa.assertEquals(roofCategoryRadioButtons.size(), 2, "Roof radio buttons size check");
        fsa.assertEquals(foundFortifiedCertificationRoofRdoBtnLabels, expectedFortifiedCertificationRoofCategoryRdoBtnLabels, "Roof radio buttons labels check");

    }

    public void validateLenderAddressFormFields(FarmersSoftAssert fsa) {
        final String LENDER_ZIPCODE_OR_STATE = "Lender's ZIP Code or state";
        final String LENDER_NAME = "Lender name";
        final String LENDER_INFO_POPUP_HEADER = "Lender info";
        final String LENDER_ADDRESS_SIDE_SHEET_HEADER = "Lender address";
        final String LENDER_ADDRESS_SIDE_SHEET_SUB_HEADER = "Let's find your lender so we can send them proof of insurance.";
        waitForPageToBeReady();
        fsa.assertTrue(isExpectedTextContainedInElement(lenderInfoPopUpHeader, LENDER_INFO_POPUP_HEADER), "Lender info header in side sheet check");
        fsa.assertEquals(getTextFromElement(lenderAddressSideSheetHeader), LENDER_ADDRESS_SIDE_SHEET_HEADER, "Lender address header in side sheet check");
        waitForPageToBeReady();
        fsa.assertEquals(getTextFromElement(lenderAddressSideSheetSubHeader), LENDER_ADDRESS_SIDE_SHEET_SUB_HEADER, "Lender address sub header in side sheet check");
        fsa.assertEquals(getTextFromElement(formFieldLenderZipOrState), LENDER_ZIPCODE_OR_STATE, "Lender Address, state or zip code form field error check");
        fsa.assertEquals(getTextFromElement(formFieldLenderName), LENDER_NAME, "Lender Address,lender name form field error check");
    }

    public void validateLenderAddressErrors(FarmersSoftAssert fsa) throws Exception {
        final String ADDRESS_FIELD_ENTER_YOUR_ZIP_OR_ADDRESS_ERROR = "You must first enter a ZIP Code or state.";
        final String LENDER_NAME_ERROR = "No matches found. Please review and retry per the tips below, or select the checkbox if you're not having any luck finding a match.";
        final String LENDER_SIDE_SHEET_ERRORS_XPATH = "//app-lender-info//mat-error";
        waitAndClickElement(nextButton.get(0));
        waitForPageToBeReady();
        sleep(2);
        List<String> listOfErrorsFoundInPage = driver().findElements(PWBy.xpath(LENDER_SIDE_SHEET_ERRORS_XPATH)).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(listOfErrorsFoundInPage, List.of(ADDRESS_FIELD_ENTER_YOUR_ZIP_OR_ADDRESS_ERROR, LENDER_NAME_ERROR), "Verify errors in lender info sidesheet.");
    }

    public void validateLenderAddressSectionDefaultValues(FarmersSoftAssert fsa) {
        waitAndClickElement(nextButton.get(0));
        waitForPageToBeReady();
        fsa.assertTrue(isElementDisplayed(lenderZipOrStateTextBox, 3), "Lender Zip code or State field is displayed");
        fsa.assertEquals(getValueFromWebElement(lenderZipOrStateTextBox).strip(), EMPTY_STRING, "Lender Zip code or State field is blank");
        fsa.assertTrue(isElementDisplayed(lenderName, 3), "Lender name field is displayed");
        fsa.assertEquals(getValueFromWebElement(lenderName).strip(), EMPTY_STRING, "Lender name field is blank");
        fsa.assertFalse(getAttributeData(iCantFindMyLenderCheckBox, CLASS).contains(CHECKBOX_CHECKED), "I can't find my lender checkbox is unchecked");
    }

    public void validateEnterLenderZipcodeOrState(FarmersSoftAssert fsa, ApplicantAceHome applicant) {
        //Click on yes
        sendKeysToElement(lenderZipOrStateTextBox, applicant.getZipCode());
        lenderName.sendKeys(PWKeys.TAB);
        waitForPageToBeReady();

        fsa.assertEquals(getValueFromWebElement(lenderZipOrStateTextBox), applicant.getZipCode(), "Zip code entered retained");
        clearOutFieldUsingBackSpace(lenderZipOrStateTextBox);
        waitAndClickElement(lenderZipOrStateTextBox);
        sendKeysToElement(lenderZipOrStateTextBox, applicant.getStateCode());
        waitElementBeVisible(lenderDropdownOptions);
        fsa.assertEquals(getTextFromElement(lenderDropdownOptions), applicant.getStateCode(), "Suggested state check");
        waitAndClickElement(lenderDropdownOptions);

    }

    public void enterLenderZipcodeOrState(ApplicantAceHome applicant) {
        sendKeysToElement(lenderZipOrStateTextBox, applicant.getStateCode());
        waitElementBeVisible(lenderDropdownOptions);
        waitAndClickElement(lenderDropdownOptions);
    }

    public void enterLenderName(String lenderBankVal) {
        sendKeysToElement(lenderName, lenderBankVal);
        if (!isElementDisplayed(lenderDropdownOptions, 5)) {
            sendKeysToElement(lenderName, "BANK");
        }
        waitElementBeVisible(lenderDropdownOptions);
        waitAndClickElement(lenderDropdownOptions);
        waitAndClickElement(nextButton.get(0));
    }

    public void enterLoanNumber() {
        sendKeysToElement(lenderLoanNumber, LOAN_NUMBERVAL);
        waitAndClickElement(nextButton.get(1));
        testStep("Loan Number Entered", true, false, false);
    }


    public void validateEnterLenderName(FarmersSoftAssert fsa, String lenderBankVal) {
        sendKeysToElement(lenderName, lenderBankVal);
        waitElementBeVisible(lenderDropdownOptions);
        sleep(2);
        fsa.assertEquals(getTextFromElement(lenderNameSuggestedVal), lenderBankVal, "Suggested lender name check");
        waitAndClickElement(lenderDropdownOptions);
        sleep(2);
        fsa.assertEquals(getTextFromElement(selectedLenderName), lenderBankVal, "Selected lender name check");
    }


    public void lenderSearchTips(FarmersSoftAssert fsa) {
        waitAndClickElement(nextButton.get(0));
        fsa.assertEquals(getTextFromElement(lenderSearchTipsText), LENDER_SEARCH_TIPS, "Lender search tips Message");
        fsa.assertEquals(getTextFromElement(lenderSearchTipsTextOne), LENDER_SEARCH_TIPS_ONE, "Lender search tip1 Message");
        fsa.assertEquals(getTextFromElement(lenderSearchTipsTextTwo), LENDER_SEARCH_TIPS_TWO, "Lender search tip2 Message");
        fsa.assertEquals(getTextFromElement(lenderSearchTipsTextThree), LENDER_SEARCH_TIPS_THREE, "Lender search tip3 Message");
    }

    public void iCantFindMyLenderCheckbox(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception { //Lender Incomplete option 1 validation

        //waitAndClickElement(nextButton.get(0));
        String separator = isSafariBrowser() ? EMPTY_STRING : SPACE;
        final String I_CANT_FIND_MY_LENDER_DESCRIPTION = "You can still proceed to purchase your policy directly." + separator +
                "In this case, we cannot bill the lender for the cost of this policy." + separator + "We can help you add and bill your lender for future renewals (if applicable).";

        fsa.assertEquals(getTextFromElement(iCantFindMyLenderLabel), I_CANT_FIND_MY_LENDER, "Cant find lender checkbox label check");
        fsa.assertEquals(getTextFromElement(iCantFindMyLenderDescriptionTitle), I_CANT_FIND_MY_LENDER_DESCRIPTION_TITLE, "Cant find lender checkbox label description title");
        fsa.assertEquals(getTextFromElement(iCantFindMyLenderDescription), I_CANT_FIND_MY_LENDER_DESCRIPTION, "Cant find lender checkbox label description");

        waitAndClickElement(iCantFindMyLenderLabel);
        waitAndClickElement(nextButton.get(0));
        waitForPageToBeReady();
        sleep(2);
        fsa.assertEquals(getTextFromElement(lenderNotFoundLabel), LENDER_NOT_FOUND, "Lender not found - label updated on UI under mortgage section");
        waitAndClickElement(lenderNotFoundEditButton);
        noLenderFoundOnMyProperty(fsa, applicant);

    }

    public void noLenderFoundOnMyProperty(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {  //Lender Incomplete option 2
        validateLenderIncompleteSection(fsa, applicant.getLenderIncompleteSelection());
        validateMortgageSelectionToggledToNo(fsa);
        if (applicant.getLenderIncompleteSelection().contains("CantFindLender")) {
            waitForPageToBeReady();
            sleep(2);
            fsa.assertEquals(getTextFromElement(lenderNotFoundLabel), LENDER_NOT_FOUND, "Lender Not Found - label updated on UI under mortgage section");
            waitAndClickElement(lenderNotFoundEditButton);
        }
    }

    public void validateLenderIncompleteSection(FarmersSoftAssert fsa, String lenderIncompleteSelectionVal) {
        waitAndClickElement(lenderInfoSideSheetCloseBtn);
        switch (lenderIncompleteSelectionVal) {
            case "CantFindLender":
                waitAndClickElement(lenderNotFoundLabel);
                scrollAndClickOnElement(lenderIncompleteContinueBtn);
                //code for lender not found
                fsa.assertEquals(getTextFromElement(lenderNotFoundLabel), LENDER_NOT_FOUND, "Lender Not Found - label updated on UI under mortgage section");
                break;
            case "NoLender":
                waitForPageToBeReady();
                scrollAndClickOnElement(lenderIncompleteContinueBtn);
                break;
            case "RetryFindingLender":
                scrollAndClickOnElement(lenderIncompleteContinueBtn);
                break;
            default:
                testStep("Incorrect Selection", false, false, false);
        }

    }

    public void validateLoanNumber(FarmersSoftAssert fsa) {
        final String LOAN_NUMBER_FORM_FIELD = "Loan #";
        final String LOAN_NUMBER_OPTIONAL_HINT = "Optional";
        final String LOAN_NUMBER_SIDE_SHEET_HEADER = "Loan number";
        final String LOAN_NUMBER_SIDE_SHEET_SUB_HEADER = "Including this helps your lender match the insurance policy to your loan records.";
        final String MAX_CHAR_ERROR = "Maximum of 25 characters for loan #.";

        waitAndClickElement(nextButton.get(0));
        fsa.assertEquals(getTextFromElement(loanNumberHeaderInSideSheet), LOAN_NUMBER_SIDE_SHEET_HEADER, "Loan Number Header in side sheet check");
        fsa.assertEquals(getTextFromElement(loanNumberSubHeaderInSideSheet), LOAN_NUMBER_SIDE_SHEET_SUB_HEADER, "Loan Number Sub Header in side sheet check");
        fsa.assertEquals(getTextFromElement(formFieldLenderLoanNumber), LOAN_NUMBER_FORM_FIELD, "Loan Number form field message check");
        fsa.assertEquals(getTextFromElement(loanNumberHintText), LOAN_NUMBER_OPTIONAL_HINT, "Optional Hint in side sheet check");
        sendKeysToElement(lenderLoanNumber, INVALID_LOAN_NUMBERVAL);
        sleep(1);
        nextButton.get(1).sendKeys(PWKeys.TAB);
        sleep(1);
        fsa.assertEquals(getTextFromElement(loanErrorMessageForMaxChar), MAX_CHAR_ERROR, "loan number error check");
        clearOutFieldUsingBackSpace(lenderLoanNumber);
        sendKeysToElement(lenderLoanNumber, LOAN_NUMBERVAL);
        waitAndClickElement(nextButton.get(1));
        testStep("Loan Number Entered", true, false, false);
    }


    public void selectEscrowAccount(String impoundAccountSelectionVal) {
        switch (impoundAccountSelectionVal) {
            case NEW_POLICY_AND_RENEWAL:
                waitAndClickElement(impoundAccountNewPolicyAndRenewalRdoBtn);
                waitAndClickElement(impoundAccountDoneBtn);
                break;
            case RENEWAL:
                waitAndClickElement(impoundAccountRenewalRdoBtn);
                waitAndClickElement(impoundAccountDoneBtn);
                break;
            case NO:
                waitAndClickElement(impoundAccountNoRdoBtn);
                waitAndClickElement(impoundAccountDoneBtn);
                break;
            default:
                testStep("Incorrect Selection", false, false, false);
        }
    }

    public void validateEscrowAccount(FarmersSoftAssert fsa) {
        final String IMPOUND_HEADER = "Escrow account";
        final String IMPOUND_SUB_HEADER = "Does your lender include your property insurance costs in your monthly mortgage payments? (common)";
        fsa.assertEquals(getTextFromElement(impoundAccountTitle), IMPOUND_HEADER, "Escrow account title check");
        fsa.assertEquals(getTextFromElement(impoundAccountSubTitle), IMPOUND_SUB_HEADER, "Escrow account Sub title check");
        validateAllRdoBtnLabelsUnderImpoundAccountSection(fsa);
    }

    public void validateEscrowAccountPopup(FarmersSoftAssert fsa) throws Exception {
        final String ESCROW_ACCOUNT_POPUP_HEADER = "Lender info incomplete";
        final String ESCROW_ACCOUNT_POPUP_SUB_HEADER = "We need more information about your loan to complete your policy.";

        waitAndClickElement(lenderInfoSideSheetCloseBtn);
        fsa.assertEquals(getTextFromElement(escrowAccountPopupHeader), ESCROW_ACCOUNT_POPUP_HEADER, "Escrow account popup header check");
        fsa.assertEquals(getTextFromElement(escrowAccountPopupSubHeader), ESCROW_ACCOUNT_POPUP_SUB_HEADER, "Escrow account popup Sub header check");
        waitAndClickElement(escrowAccountPopupContinueBtn);
        waitAndClickElement(lenderInfoSideSheetCloseBtn);
        waitAndClickElement(escrowAccountPopupContentLink);
        fsa.assertTrue(isSnackBarMessageDisplayed(EXPECTED_SNACK_BAR_MESSSAGE), "Snack Bar message for Mortgage No selection when No Lender Selected");
        validateMortgageSelectionToggledToNo(fsa);
        selectMortgageOnThisProperty(true);
    }

    public void validateMortgageSelectionToggledToNo(FarmersSoftAssert fsa) throws Exception {
    	PWElement we = driver().findElement(PWBy.xpath(MORTGAGE_ON_PROPERTY_BUTTON_XPATH + "//button[@aria-label='No']"));
    	waitForPageToBeReady();
    	sleep(2);
        fsa.assertTrue(isButtonSelected(we), "Mortgage selection updated to No");
    }


    public void validatePopulatedLenderInfoUnderMortgageSection(FarmersSoftAssert fsa, String lenderBankVal) {
        waitElementBeVisible(selectedLenderSectionForLoanNum);
        fsa.assertTrue(getTextFromElement(selectedLenderSectionForLoanNum).contains(LOAN_NUMBERVAL), "Loan Number is displayed, as expected");
        fsa.assertTrue(getTextFromElement(selectedLenderNameUnderMortgageSection).contains(lenderBankVal), "Selected lender name is displayed, as expected");
        waitAndClickElement(lenderNotFoundEditButton);
        waitAndClickElement(lenderInfoSideSheetCloseBtn);
    }

    public void validateEmergencyMortgageAssistanceSection(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {
        String EMERGENCY_MORTGAGE_ASSISTANCE_TITLE = "Emergency mortgage assistance";
        fsa.assertTrue(isElementDisplayed(emergencyMortgageAssistanceDivider,3), "Emergency mortgage assistance divider id displayed");
        fsa.assertTrue(isElementDisplayed(emergencyMortgageAssistanceToggle,3), "Emergency mortgage assistance toggle is displayed");

        fsa.assertFalse(getAttributeData(emergencyMortgageAssistanceToggle, CLASS).contains(TOGGLE_CHECKED), "Emergency mortgage assistance toggle button" +
                " is disabled by default");
        clickEmergencyAssistanceMortgageToggle();
        fsa.assertTrue(getAttributeData(emergencyMortgageAssistanceToggle, CLASS).contains(TOGGLE_CHECKED), "Emergency mortgage assistance toggle button" +
                " is enabled");

        fsa.assertEquals(getTextFromElement(emergencyMortgageAssistanceLabel), EMERGENCY_MORTGAGE_ASSISTANCE_TITLE, "Emergency mortgage assistance header is displayed");

        final String expectedEmergencyMortgageAssistanceDescription = "If a covered loss or damage to the dwelling makes the dwelling uninhabitable, this coverage provides" +
                " the lesser of up to $10,000 or three consecutive months of your mortgage payment.";
        fsa.assertEquals(getTextFromElement(emergencyMortgageAssistanceDescription), expectedEmergencyMortgageAssistanceDescription, "Emergency mortgage assistance description match");

        fsa.assertTrue(isElementDisplayed(emergencyMortgageAssistanceSubHeader,3), "Emergency mortgage assistance sub header check");
        final String expectedEmergencyMortgageAssistanceSubHeader = "$15.00/yr";
        fsa.assertEquals(getTextFromElement(emergencyMortgageAssistanceSubHeader), expectedEmergencyMortgageAssistanceSubHeader, "Emergency mortgage assistance sub-header text match");

        validateEmergencyMortgageAssistancePremiumOnReviewQuote(fsa, applicant);
    }

    public void validateEmergencyMortgageAssistancePremiumOnReviewQuote(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {
        selectStepper("Review quote");
        AceHomeNavigationHelper navigationHelper = new AceHomeNavigationHelper();
        AceHomeReviewQuotePage reviewQuotePage = navigationHelper.goToAceHomeReviewQuotePage(applicant);

        String EMA_PREMIUM = reviewQuotePage.getQuotePriceOnCard().endsWith("/mo") ? "$1.25" : "$15";
        fsa.assertEquals(reviewQuotePage.getOptionalCoveragesPriceOnCard(), EMA_PREMIUM, "Review quote page - Emergency Mortgage Assistance premium is correct.");
        navigationHelper.setResumeFromPage(REVIEW_QUOTE);
        navigationHelper.navigateToAceHomeJustAFewMoreThingsPage(applicant, LOB_HOME, HOME);
    }

    public void validateAddedMortgageAddressIsRemovedWhenNoMortgageSelected(FarmersSoftAssert fsa) throws Exception {
        selectMortgageOnThisProperty(false);
        fsa.assertTrue(selectedLenderSectionList.isEmpty(), "Selected address removed after selecting mortgage as No");
    }

    public void clickEmergencyAssistanceMortgageToggle() {
        waitAndClickElement(emergencyMortgageAssistanceLabel);
    }

    public void fillOutLenderInformationWithLenderSelected(ApplicantAceHome applicantAceHome) throws Exception {
        selectMortgageOnThisProperty(true);
        enterLenderZipcodeOrState(applicantAceHome);
        enterLenderName(applicantAceHome.getLenderBank());
        enterLoanNumber();
        selectEscrowAccount(applicantAceHome.getImpoundAccountSelection());
    }

    public void validateAllRdoBtnLabelsUnderImpoundAccountSection(FarmersSoftAssert fsa) {
        List<String> expectedImpoundAccountRdoBtnLabels = Arrays.asList(IMPOUND_RDO_BTN1, IMPOUND_RDO_BTN2, IMPOUND_RDO_BTN3);
        List<String> actualImpoundAccountRdoBtnLabels = escrowAccountRadioButtonOptionsLabels.stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(actualImpoundAccountRdoBtnLabels, expectedImpoundAccountRdoBtnLabels, "JFMT Page - Escrow account radio button labels match");
    }

    public void validateOtherQuestionsSection(ApplicantAceHome applicant, FarmersSoftAssert fsa, String lobType) throws Exception {
        if (lobType.equals(HOME)) {
            validatePlumbingOtherThanCopperPexPVC(fsa);
            validatePrimaryHeatingSource(applicant, fsa);
            validateUnrepairedStructures(fsa);
        }
        validateSelectTerritory(applicant, fsa);
        validateBusinessOperatedOnPremises(fsa);
        validateDogsOnPremises(applicant.getDogsOnPremises(), applicant.getUpdatedDogsOnPremises(), fsa);
        validatePetWithBiteHistory(fsa);
    }

    public void validatePlumbingSideSheet(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(plumbingSideSheetHeader), "Plumbing systems", "Expected side sheet check for Plumbing selection");
        fsa.assertEquals(getTextFromElement(copperSubHeaderSideSheet), "Copper", "Expected side sheet sub header for copper check");
        fsa.assertEquals(getTextFromElement(copperSubHeaderContentSideSheet), PLUMBING_COPPER_CONTENT, "Expected side sheet content for sub header copper check");
        fsa.assertEquals(getTextFromElement(pvcSubHeaderSideSheet), "PVC", "Expected side sheet sub header for PVC check");
        fsa.assertEquals(getTextFromElement(pvcSubHeaderContentSideSheet), PLUMBING_PVC_CONTENT, "Expected side sheet content for sub header PVC check");
        fsa.assertEquals(getTextFromElement(pexSubHeaderSideSheet), "PEX", "Expected side sheet sub header for PEX check");
        fsa.assertEquals(getTextFromElement(pexSubHeaderContentSideSheet), PLUMBING_PEX_CONTENT, "Expected side sheet content for sub header PEX check");
        fsa.assertEquals(getTextFromElement(galvanizedSubHeaderSideSheet), "Galvanized", "Expected side sheet sub header for Galvanized check");
        fsa.assertEquals(getTextFromElement(galvanizedSubHeaderContentSideSheet), PLUMBING_GALVANIZED_CONTENT, "Expected side sheet content for sub header Galvanized check");
        fsa.assertEquals(getTextFromElement(polybutyleneSubHeaderSideSheet), "Polybutylene", "Expected side sheet sub header for Polybutylene check");
        fsa.assertEquals(getTextFromElement(polybutyleneSubHeaderContentSideSheet), PLUMBING_POLYBUTYLENE_CONTENT, "Expected side sheet content for sub header Polybutylene check");
        closeSideSheetByEscKey(fsa);
    }

    public void validatePrimaryHeatingSourceSideSheet(ApplicantAceHome applicant, FarmersSoftAssert fsa) {
        waitElementBeVisible(primaryHeatingSourceSideSheetHeader);
        fsa.assertTrue(primaryHeatingSourceSideSheetRadioButtons.size() == 13, "Radio button size check for Primary heat source section.");
        fsa.assertEquals(getTextFromElement(primaryHeatingSourceSideSheetHeader), "Heating systems", "Expected side sheet check for Primary Heating Source selection");
        String expectedSubheaderContent = applicant.isInEscrow() ?  EXPECTED_ESCROW_IS_CLOSING_DESC_TEXT : PRIMARYHEATINGSOURCE_SUBHEADER_CONTENT;
        fsa.assertEquals(getTextFromElement(heatingSystemsSubHeaderSideSheet), expectedSubheaderContent, "Expected side sheet sub header for copper check");
        fsa.assertEquals(getTextFromElement(thermostatSubHeader), "With thermostat", "Expected side sheet content for sub header copper check");
        List<String> expectedWithThermoStatOptions = Arrays.asList("Pellet stove", "Solar heating", "Space heater", "Wood burning stove", "Other heating system");
        List<String> foundWithThermoStatOptions = withThermoStatHeatingSystemOptions.stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(foundWithThermoStatOptions, expectedWithThermoStatOptions, "With thermostat heating options are not matching");

        fsa.assertEquals(getTextFromElement(withOutThermostatSubHeader), "Without thermostat", "Expected side sheet sub header for PVC check");
        List<String> expectedWithoutThermoStatOptions = Arrays.asList("Central forced-air", "Fireplace", "Pellet stove", "Solar heating",
                "Space heater", "Wood burning stove", "Other heating system");
        List<String> foundWithoutThermoStatOptions = withoutThermoStatHeatingSystemOptions.stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(foundWithoutThermoStatOptions, expectedWithoutThermoStatOptions, "Without thermostat heating options are not matching");

        fsa.assertEquals(getTextFromElement(noHeatingSystemSubHeader), "No heating system", "Expected side sheet content for sub header PVC check");
        fsa.assertEquals(getTextFromElement(noHeatingSystemOption), "None", "No heating option check");
    }

    private void validateDogsOnPremisesSideSheet(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(dogsOnPremisesSideSheetHeader), "Dog(s) on premises", "Expected side sheet check for Dogs On Premises selection");
        fsa.assertEquals(getTextFromElement(dogsOnPremisesSubHeaderSideSheet), DOGSONPREMISES_SUBHEADER_CONTENT, "Expected side sheet sub header for copper check");
        fsa.assertTrue(dogsOnPremisesCheckBoxes.size() == 19, "Checkbox size check for dogs on premises side sheet section.");

        List<String> expectedDogsBreedOptions = Arrays.asList("Akita", "American Staffordshire Terrier", "Belgian Malinois", "Boerboels", "Boxer", "Chow Chow", "Dalmatian", "Doberman Pinscher",
                "Fila Brasileiro", "German Shepherd", "Huskies", "Malamute", "Mastiff, or Bullmastiff", "Pit Bull", "Presa Canario", "Rottweiler", "Tosa Inu", "Wolf hybrids", "Other breed(s)");
        List<String> foundDogsBreedOptions = dogsOnPremisesCheckBoxesLabels.stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());
        fsa.assertEquals(foundDogsBreedOptions, expectedDogsBreedOptions, "Dogs breed options are not matching in dogs premises side sheet.");
    }


    public void validatePlumbingOtherThanCopperPexPVC(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(plumbingOtherThanCopperCheckBox), PLUMBING_CHECKBOX_CONTENT, "Expected side sheet check for Primary heating selection");
        clickOnPlumbingOtherThanCopperCheckBox();
        clickOnPlumbingSystemsHelpLink();
        waitForPageToBeReady();
        validatePlumbingSideSheet(fsa);
    }

    public void validatePrimaryHeatingSource(ApplicantAceHome applicant, FarmersSoftAssert fsa) {
        String primaryHeatingSourceVal = applicant.getPrimaryHeatingSource();
        if (!applicant.getPrimaryHeatingSource().equals(EMPTY_STRING)) {
            fsa.assertEquals(getTextFromElement(primaryHeatingSourceCheckBox), PRIMARY_HEATING_CHECKBOX_CONTENT, "Expected checkbox for Primary heating selection check");
            clickOnPrimaryHeatingSourceCheckBox();
            validatePrimaryHeatingSourceSideSheet(applicant, fsa);
            selectPrimaryHeatingRadioButton(primaryHeatingSourceVal);
            waitForPageToBeReady();
            waitAndClickElement(crossButtonPrimaryHeatSideSheet);
            fsa.assertTrue(!primaryHeatingSourceCheckBox.isSelected(), "Primary Heating Source is still showing Selected");
            clickOnPrimaryHeatingSourceCheckBox();
            selectPrimaryHeatingRadioButton(primaryHeatingSourceVal);
            clickOnSaveButtonOnPrimaryHeatingSystemSideSheet();
            waitForPageToBeReady();
            sleep(2);
            clickOnEditButtonPrimaryHeatingSource();
            selectPrimaryHeatingRadioButton(applicant.getUpdatedPrimaryHeatingSource());
            clickOnSaveButtonOnPrimaryHeatingSystemSideSheet();
        }
    }

    public void validateUnrepairedStructures(FarmersSoftAssert fsa) {
        scrollToElement(unrepairedStructuresCheckBox);
        fsa.assertEquals(getTextFromElement(unrepairedStructuresCheckBox), UNREPAIRED_STRUCTURE_CHECKBOX_CONTENT, "Unrepaired structures selection checkbox header check");
        fsa.assertEquals(getTextFromElement(unrepairedStructuresCheckBoxSubHeader), UNREPAIRED_STRUCTURE_CHECKBOX_SUBHEADER_CONTENT, "Unrepaired structures checkbox sub header check");
        clickOnUnrepairedStructureCheckbox();
    }

    public void validateBusinessOperatedOnPremises(FarmersSoftAssert fsa) {
        clickOnBusinessOperatedOnPremisesCheckBox();
        fsa.assertEquals(getTextFromElement(businessOperatedOnPremisesCheckBox), BUSINESS_OPERATED_CHECKBOX_CONTENT, "Business Operated selection checkbox header check");
        fsa.assertEquals(getTextFromElement(businessOperatedOnPremisesCheckBoxSubHeader), BUSINESS_OPERATED_CHECKBOX_SUBHEADER_CONTENT, "Business Operated selection checkbox sub header check");
    }

    public void validateDogsOnPremises(String dogsOnPremisesVal, String updatedDogsOnPremisesVal, FarmersSoftAssert fsa) {
        if (!dogsOnPremisesVal.isBlank()) {
            fsa.assertEquals(getTextFromElement(dogsOnPremisesCheckBox), DOGS_ONPREMISES_CHECKBOX_CONTENT, "DOGS ON PREMISES selection checkbox header check");
            clickOnDogsOnPremisesCheckBox();
            waitAndClickElement(crossButtonPrimaryHeatSideSheet);
            waitForPageToBeReady();
            fsa.assertTrue(isElementDisplayed(dogsOnPremisesCheckBox,2), "Dogs on premises check box is displayed");
            waitElementBeVisible(dogsOnPremisesCheckBox);
            fsa.assertTrue(!dogsOnPremisesCheckBox.isSelected(), "Dogs On Premises checkbox is selected which it should as side sheet close is clicked");
            clickOnDogsOnPremisesCheckBox();
            selectDogsBreedFromSideSheet(dogsOnPremisesVal);
            clickOnCancelButtonDogsOnPremisesSideSheet();
            waitForPageToBeReady();
            sleep(2);
            fsa.assertTrue(!dogsOnPremisesCheckBox.isSelected(), "Dogs On Premises checkbox is UnSelected");
            clickOnDogsOnPremisesCheckBox();
            validateDogsOnPremisesSideSheet(fsa);
            selectDogsBreedFromSideSheet(dogsOnPremisesVal);
            clickOnSaveButtonDogsOnPremisesSideSheet();
            waitForPageToBeReady();
            sleep(2);
            fsa.assertTrue(getTextFromElement(dogsOnPremisesSelectedValue).contains(dogsOnPremisesVal), "Dog's On Premises selection is displayed");
            waitForPageToBeReady();
            clickOnEditLinkInDogsOnPremises();
            unselectDogsBreedFromSideSheet(dogsOnPremisesVal);
            List<String> listDogs = Stream.of(updatedDogsOnPremisesVal.split(SEMI_COLON)).collect(Collectors.toList());
            for (String s : listDogs) {
                selectDogsBreedFromSideSheet(s);
            }
            clickOnSaveButtonDogsOnPremisesSideSheet();
            waitForPageToBeReady();
            sleep(2);
            int len = listDogs.size();
            if (len > 2) {
                fsa.assertEquals(getTextFromElement(dogsOnPremisesSelectedValue), listDogs.get(0) + "; " + listDogs.get(1) + "; more", "Updated Multiple Dog's On Premises selection is displayed.");
            } else if (len == 2) {
                fsa.assertEquals(getTextFromElement(dogsOnPremisesSelectedValue), listDogs.get(0) + "; " + listDogs.get(1), "Updated 2 Dog's On Premises selection is displayed.");
            } else {
                fsa.assertEquals(getTextFromElement(dogsOnPremisesSelectedValue), listDogs.get(0), "Updated 1 Dog's On Premises selection is displayed.");
            }
        }
    }

    public void validatePetWithBiteHistory(FarmersSoftAssert fsa) {
        clickOnPetWithBiteHistoryCheckBox();
        fsa.assertEquals(getTextFromElement(petWithBiteHistoryCheckBox), PET_BITE_HISORY_CHECKBOX_CONTENT, "Pet with bite history checkbox header check");
        fsa.assertEquals(getTextFromElement(petWithBiteHistoryCheckBoxSubHeader), PET_BITE_HISORY_CHECKBOX_SUBHEADER_CONTENT, "Pet with bite history checkbox sub header check");
    }

    public void validatePolicyStartDateSection(FarmersSoftAssert fsa, ApplicantAceHome applicant, String lobType) throws Exception {
        String expectedPolicyStartDate = getSessionStorageAppStore().getHome().getContactInfo().getPolicyStartDate();
        validateContentOfPolicyStartDateHeaderAndInputField(fsa, applicant, expectedPolicyStartDate, lobType);
        validateContentOfEarlyShopperDiscountInfo(fsa, applicant, lobType);
        validateContentOfPolicyStartDatePickerPopUp(fsa, expectedPolicyStartDate, lobType);
        validateManuallyEnteredPolicyStartDateAndErrorValidationHomeLob(fsa, expectedPolicyStartDate, lobType);
    }

    public void clickDatePickerIconPolicyStartDate() {
        waitAndClickElement(policyStartDatePickerButtonFMTPHome);
    }

    // Validate content of policy start date field, headers, questions
    public void validateContentOfPolicyStartDateHeaderAndInputField(FarmersSoftAssert fsa, ApplicantAceHome applicant, String expectedPolicyStartDate, String lobType) {
        String expectedPolicyStartDateHeader = (applicant.isInEscrow() && !lobType.equals(RENTERS)) ? EXPECTED_ESCROW_CLOSING_DATE_HEADER : POLICY_START_DATE_LABEL;
        fsa.assertEquals(getTextFromElement(policyStartDateHeader), expectedPolicyStartDateHeader, "Policy start date header check - " + lobType);

        String expectedPolicyToBeginQuestion = (applicant.isInEscrow() && !lobType.equals(RENTERS)) ? EXPECTED_ESCROW_TO_CLOSE_QUESTION : POLICY_TO_BEGIN_LABEL;
        fsa.assertEquals(getTextFromElement(whenWouldYouLikeYourPolicyToBeginQuestion), expectedPolicyToBeginQuestion, expectedPolicyToBeginQuestion + " question text check - " + lobType);

        fsa.assertEquals(policyStartDateInputFieldFMTPHome.isDisplayed(), true, "Policy start date input field visible - " + lobType);
        String expectedStartDatePlaceHolder = (applicant.isInEscrow() && !lobType.equals(RENTERS)) ? EXPECTED_ESCROW_TO_CLOSE_LABEL : POLICY_START_DATE_LABEL;
        fsa.assertEquals(getTextFromElement(policyStartDatePlaceHolderTextFMTPHome), expectedStartDatePlaceHolder, "Policy start date input place holder visible - " + lobType);

        fsa.assertEquals(getValueFromWebElement(policyStartDateInputFieldFMTPHome), expectedPolicyStartDate, "Policy start date check - " + lobType);
    }

    // Validate content of early shopper discount side information
    public void validateContentOfEarlyShopperDiscountInfo(FarmersSoftAssert fsa, ApplicantAceHome applicant, String lobType) {
        String expectedEarlyShoppingInfoIconLabel;
        String expectedEarlyShoppingInfoDiscountDescription;
        if (applicant.isInEscrow() && !lobType.equals(RENTERS)) {
            expectedEarlyShoppingInfoIconLabel = EXPECTED_ESCROW_CLOSING_DATE_HEADER;
            expectedEarlyShoppingInfoDiscountDescription = EXPECTED_INFO_BAR_DESC;
        } else {
            expectedEarlyShoppingInfoIconLabel = EARLY_SHOPPING_INFO_TITLE;
            expectedEarlyShoppingInfoDiscountDescription = isUseMobileViewEnabled() ? EARLY_SHOPPING_DISCOUNT_DESCRIPTION_MOBILE : EARLY_SHOPPING_DISCOUNT_DESCRIPTION_DESKTOP;
        }
        if (!lobType.equals(RENTERS)) {
            if (isUseMobileViewEnabled()) {
                waitAndClickElement(earlyShoppingInfoIconMobile);
                fsa.assertEquals(getTextFromElement(earlyShoppingInfoTitleMobile), expectedEarlyShoppingInfoIconLabel, "Early shopper discount info title (mobile) is displayed - " + lobType);
                fsa.assertEquals(getTextFromElement(earlyShoppingInfoDescriptionMobile), expectedEarlyShoppingInfoDiscountDescription, "Early shopper discount info description (mobile) is displayed - " + lobType);
                waitAndClickElement(earlyShoppingInfoButtonCloseMobile);
            } else {
                fsa.assertEquals(getTextFromElement(earlyShoppingDiscountInfoTitleFMTPHome), expectedEarlyShoppingInfoIconLabel, "Early shopping discount info title (desktop) is displayed - " + lobType);
                fsa.assertEquals(getTextFromElement(earlyShoppingDiscountDescriptionFMTPHome), expectedEarlyShoppingInfoDiscountDescription, "Early shopper discount description (desktop) is displayed - " + lobType);
            }
        }
    }

    // Validate content of policy start date picker content
    public void validateContentOfPolicyStartDatePickerPopUp(FarmersSoftAssert fsa, String expectedPolicyStartDate, String lobType) {
        clickDatePickerIconPolicyStartDate();
        LocalDate formattedExpectedDate = getFormattedDateFromStringDate(expectedPolicyStartDate);
        String expectedMonthYearLabel = formattedExpectedDate.getMonth() + SPACE + formattedExpectedDate.getYear();
        waitElementBeVisible(monthYearLabelInCalenderPopUpFMTPHome);
        fsa.assertEquals(monthYearLabelInCalenderPopUpFMTPHome.isDisplayed(), true, "Month year label check in calendar pop up - " + lobType);
        fsa.assertEquals(getTextFromElement(monthYearLabelInCalenderPopUpFMTPHome), expectedMonthYearLabel, "Month year label value check in calendar pop up - " + lobType);

        fsa.assertEquals(previousMonthButtonInCalenderPopUpFMTPHome.isDisplayed(), true, "Previous month button check in calendar pop up - " + lobType);
        fsa.assertEquals(nextMonthButtonInCalenderPopUpFMTPHome.isDisplayed(), true, "Next month button check in calendar pop up - " + lobType);
        waitElementBeVisible(selectedDateInDatePickerPopUp);
        fsa.assertEquals(getTextFromElement(selectedDateInDatePickerPopUp), String.valueOf(formattedExpectedDate.getDayOfMonth()), "Selected date in date picker pop up check - " + lobType);
        clickElement(closeCalendarButton);
    }

    // Validate manually entered policy start date and error/discount message validation
    public void validateManuallyEnteredPolicyStartDateAndErrorValidationHomeLob(FarmersSoftAssert fsa, String expectedPolicyStartDate, String lobType) throws Exception {
        waitAndClickElement(policyStartDateInputFieldFMTPHome);
        clearOutFieldUsingBackSpace(policyStartDateInputFieldFMTPHome);
        clickAway();
        fsa.assertEquals(getTextFromElement(pleaseProvidePolicyStartDateError), PLEASE_PROVIDE_POLICY_START_DATE_ERROR, "Provide your policy start date error check - " + lobType);

        sendKeysOneByOne(policyStartDateInputFieldFMTPHome, expectedPolicyStartDate.substring(1, 4));
        clickAway();
        validatePolicyStartDateRangeError(fsa, true, lobType);
        validateEarlyShopperDiscount(fsa, false, lobType);

        sendKeysOneByOne(policyStartDateInputFieldFMTPHome, "04/19/1993");
        clickAway();
        validatePolicyStartDateRangeError(fsa, true, lobType);
        validateEarlyShopperDiscount(fsa, false, lobType);

        sendKeysOneByOne(policyStartDateInputFieldFMTPHome, HALF_DATE);
        clickAway();
        validatePolicyStartDateRangeError(fsa, true, lobType);
        validateEarlyShopperDiscount(fsa, false, lobType);


        sendKeysOneByOne(policyStartDateInputFieldFMTPHome, getFormattedTodayDate());
        clickAway();
        validatePolicyStartDateRangeError(fsa, true, lobType);
        validateEarlyShopperDiscount(fsa, false, lobType);

        sendKeysOneByOne(policyStartDateInputFieldFMTPHome, getFormattedTomorrowDate());
        clickAway();
        validatePolicyStartDateRangeError(fsa, false, lobType);
        validateEarlyShopperDiscount(fsa, false, lobType);

        sendKeysOneByOne(policyStartDateInputFieldFMTPHome, getFormattedDateAfter8days());
        clickAway();
        validatePolicyStartDateRangeError(fsa, false, lobType);
        validateEarlyShopperDiscount(fsa, true, lobType);
        clickDatePickerIconPolicyStartDate();
        String expectedDateInPolicyStartDateField = getTextFromElement(selectedDateInDatePickerPopUp);
        String foundDayInPolicyStartDateField = String.valueOf(getFormattedDateFromStringDate(getFormattedDateAfter8days()).getDayOfMonth());
        fsa.assertEquals(expectedDateInPolicyStartDateField, foundDayInPolicyStartDateField, "Selected date in date picker pop up check for " + expectedDateInPolicyStartDateField + " - " + lobType);
        waitAndClickElement(closeCalendarButton);

        sendKeysOneByOne(policyStartDateInputFieldFMTPHome, getFormattedForPolicyStartDate(todayPlus60Days()));
        clickAway();
        validatePolicyStartDateRangeError(fsa, true, lobType);
        validateEarlyShopperDiscount(fsa, false, lobType);
        sendKeysOneByOne(policyStartDateInputFieldFMTPHome, getFormattedForPolicyStartDate(todayPlus6Days()));

    }

    public void validateEarlyShopperDiscount(FarmersSoftAssert fsa, Boolean isEarlyShopperDiscountVisible, String lobType) throws Exception {
        if (!lobType.equals(RENTERS)) {
            if (isEarlyShopperDiscountVisible) {
                fsa.assertEquals(isElementPresent(PWBy.xpath(EARLY_SHOPPER_DISCOUNT_CONGRATULATIONS_MSG_XPATH)), true, "Green check mark in congratulations message is displayed - " + lobType);
                fsa.assertEquals(isElementPresent(PWBy.xpath(EARLY_SHOPPER_DISCOUNT_CONGRATULATIONS_GREEN_CHECKMARK_XPATH)), true, "Early shopper discount message is displayed - " + lobType);
            } else {
                List<PWElement> discountCongratulationMessageElement = driver().findElements(PWBy.xpath(EARLY_SHOPPER_DISCOUNT_CONGRATULATIONS_MSG_XPATH));
                fsa.assertTrue(discountCongratulationMessageElement.isEmpty(), "Early shopper discount message check - " + lobType);
            }
        }
    }

    public void validatePolicyStartDateRangeError(FarmersSoftAssert fsa, Boolean isVisible, String lobType) throws Exception {
        if (isVisible) {
            waitElementBeVisible(policyStartDateRangeError);
            fsa.assertEquals(policyStartDateRangeError.isDisplayed(), true, "Policy start Date range error displayed - " + lobType);
            EXPECTED_POLICY_START_DATE_ERROR = "Please select a date between " + getFormattedForPolicyStartDate(today.plusDays(1)) + " and " + getFormattedForPolicyStartDate(lobType.equals(MOBILE_HOME)? today.plusDays(29) : today.plusDays(59)) + ".";
            fsa.assertEquals(getTextFromElement(policyStartDateRangeError), EXPECTED_POLICY_START_DATE_ERROR, "Policy Start Date Error check");
        } else {
            List<PWElement> policyStartDateRangeErrorMessage = driver().findElements(PWBy.xpath(POLICY_START_DATE_RANGE_MSG_XPATH));
            fsa.assertTrue(policyStartDateRangeErrorMessage.isEmpty(), "No Policy start Date range errors - " + lobType);
        }
    }

    public void validateHomePurchaseDateSection(FarmersSoftAssert fsa, String lobType) throws Exception {
        validateContentOfHomePurchaseDateHeaderAndInputField(fsa, lobType);
        validateManuallyEnteredHomePurchaseDateAndErrorValidation(fsa, lobType);
        validateContentOfHomePurchaseDatePickerPopUp(fsa, lobType);
    }

    // Validate content of home purchase date field, headers, questions
    public void validateContentOfHomePurchaseDateHeaderAndInputField(FarmersSoftAssert fsa, String lobType) {
        String expectedHomePurchaseDateHeader = "Home purchase date";
        fsa.assertEquals(getTextFromElement(homePurchaseDateHeader), expectedHomePurchaseDateHeader, "Home purchase date header is matching - " + lobType);

        String expectedWhenDidYouPurchaseYourHomeQuestion = "When did you purchase this home?";
        fsa.assertEquals(getTextFromElement(whenDidYouPurchaseThisHomeQuestion), expectedWhenDidYouPurchaseYourHomeQuestion, expectedWhenDidYouPurchaseYourHomeQuestion + " question text as expected - " + lobType);

        fsa.assertEquals(homePurchaseDateInputField.isDisplayed(), true, "Home purchase date input field is not visible - " + lobType);
        fsa.assertEquals(getTextFromElement(homePurchaseDatePlaceHolderText), expectedHomePurchaseDateHeader, "Home purchase date input place holder is visible - " + lobType);

        fsa.assertEquals(getValueFromWebElement(homePurchaseDateInputField), EMPTY_STRING, "Home purchase date is empty on initial load - " + lobType);
    }

    // Validate content of home purchase date picker content
    public void validateContentOfHomePurchaseDatePickerPopUp(FarmersSoftAssert fsa, String lobType) {
        String homePurchaseDate = getFormattedYesterdayDate();
        fillOutHomePurchaseDate(homePurchaseDate);
        LocalDate formattedExpectedDate = getFormattedDateFromStringDate(homePurchaseDate);
        String expectedMonthYearLabel = formattedExpectedDate.getMonth() + " " + formattedExpectedDate.getYear();
        clickDatePickerIconHomePurchaseDate();
        fsa.assertEquals(monthYearLabelInCalenderPopUpFMTPHome.isDisplayed(), true, "Month year label check in home purchase date calendar pop up - " + lobType);
        fsa.assertEquals(getTextFromElement(monthYearLabelInCalenderPopUpFMTPHome), expectedMonthYearLabel, "Month year label value check in home purchase date calendar pop up - " + lobType);

        fsa.assertEquals(previousMonthButtonInCalenderPopUpFMTPHome.isDisplayed(), true, "Previous month button check in home purchase date calendar pop up - " + lobType);
        fsa.assertEquals(nextMonthButtonInCalenderPopUpFMTPHome.isDisplayed(), true, "Next month button check in home purchase date calendar pop up - " + lobType);
        waitElementBeVisible(selectedDateInDatePickerPopUp);
        fsa.assertEquals(getTextFromElement(selectedDateInDatePickerPopUp), String.valueOf(formattedExpectedDate.getDayOfMonth()), "Selected date in date picker pop up home purchase date - " + lobType);
        clickElement(selectedDateInDatePickerPopUp);
    }

    public String getHomePurchaseDate() {
        return getValueFromWebElement(homePurchaseDateInputField);
    }

    public void fillOutHomePurchaseDate(String homePurchaseDate) {
        waitAndClickElement(homePurchaseDateInputField);
        sendKeysToElement(homePurchaseDateInputField, homePurchaseDate + PWKeys.TAB);
        sleep(2);
    }

    public void clickDatePickerIconHomePurchaseDate() {
        waitAndClickElement(homePurchaseDatePickerButton);
    }

    public void validateInvalidHomePurchaseDateError(FarmersSoftAssert fsa, boolean isErrorVisible, String lobType) throws Exception {
        List<PWElement> invalidHomePurchaseDateErrorMessage = driver().findElements(PWBy.xpath(INVALID_HOME_PURCHASE_DATE_ERROR_XPATH));
        fsa.assertEquals(!invalidHomePurchaseDateErrorMessage.isEmpty(), isErrorVisible, EXPECTED_INVALID_HOME_PURCHASE_DATE_ERROR + " display check for " + lobType);
    }

    //Purchase date cannot be a future date.
    public void validateHomePurchaseDateError(FarmersSoftAssert fsa, boolean isErrorVisible, String lobType) throws Exception {
        List<PWElement> homePurchaseDateErrorMessage = driver().findElements(PWBy.xpath(HOME_PURCHASE_DATE_ERROR_CANT_BE_IN_FUTURE_XPATH));
        fsa.assertEquals(!homePurchaseDateErrorMessage.isEmpty(), isErrorVisible, EXPECTED_PURCHASE_DATE_CANNOT_BE_IN_FUTURE_ERROR + " display check for " + lobType);
    }

    // Validate manually entered home purchase date and error validations
    public void validateManuallyEnteredHomePurchaseDateAndErrorValidation(FarmersSoftAssert fsa, String lobType) throws Exception {
        fillOutHomePurchaseDate(getFormattedTomorrowDate());
        validateHomePurchaseDateError(fsa, true, lobType);
        validateInvalidHomePurchaseDateError(fsa, false, lobType);

        fillOutHomePurchaseDate(getFormattedTodayDate());
        validateHomePurchaseDateError(fsa, true, lobType);
        validateInvalidHomePurchaseDateError(fsa, false, lobType);

        fillOutHomePurchaseDate(HALF_DATE);
        validateHomePurchaseDateError(fsa, false, lobType);
        validateInvalidHomePurchaseDateError(fsa, true, lobType);

        fillOutHomePurchaseDate("01/01/1899");
        validateHomePurchaseDateError(fsa, false, lobType);
        validateInvalidHomePurchaseDateError(fsa, true, lobType);

        fillOutHomePurchaseDate("01/01/1900");
        validateHomePurchaseDateError(fsa, false, lobType);
        validateInvalidHomePurchaseDateError(fsa, true, lobType);
    }

    public void validateDiscountRemovalMessageFortifiedCertSection(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(discountRemovalMessageFortifiedSection), DISCOUNT_MESSAGE_FORTIFIED_CERTIFICATION, "Expected discount removal message check under fortified certification section when checked No");
    }

    public void validateContentOfCertificateExpirationDatePickerPopUp(FarmersSoftAssert fsa, String expectedPolicyStartDate) {

        LocalDate formattedExpectedDate = getFormattedDateFromStringDate(expectedPolicyStartDate).plusDays(7);
        String dateToEnter = getFormattedForPolicyStartDate(formattedExpectedDate);
        //Adding days to the policy start date - no of days come from data sheet.
        waitElementBeVisibleClickable(certExpDateInputField);
        sendKeysToElement(certExpDateInputField, dateToEnter);
        waitAndClickElement(certExpirationDatePickerButtonFMTPHome);
        String expectedMonthYearLabel = formattedExpectedDate.getMonth() + SPACE + formattedExpectedDate.getYear();
        fsa.assertEquals(monthYearLabelInCalenderPopUpFMTPHome.isDisplayed(), true, "Month year label check in calendar pop up - ");
        fsa.assertEquals(getTextFromElement(monthYearLabelInCalenderPopUpFMTPHome), expectedMonthYearLabel, "Month year label value check in calendar pop up - ");

        fsa.assertEquals(previousMonthButtonInCalenderPopUpFMTPHome.isDisplayed(), true, "Previous month button check in calendar pop up - ");
        fsa.assertEquals(nextMonthButtonInCalenderPopUpFMTPHome.isDisplayed(), true, "Next month button check in calendar pop up - ");
        waitElementBeVisible(selectedDateInDatePickerPopUp);
        fsa.assertEquals(getTextFromElement(selectedDateInDatePickerPopUp), String.valueOf(formattedExpectedDate.getDayOfMonth()), "Selected date in date picker pop up check - ");
    }

    public void clickOnPrimaryHeatingSourceCheckBox() {
        waitAndClickElement(primaryHeatingSourceCheckBox);
    }

    public void selectPrimaryHeatingRadioButton(String primaryHeatingSourceVal) {
        try {
            waitForPageToBeReady();
            PWElement primaryHeatingRadioElement = driver().findElement(PWBy.xpath("//input[contains(@id,'RADIO_BUTTON_FOR_" + primaryHeatingSourceVal + "')]"));
            clickElement(primaryHeatingRadioElement);
        } catch (Exception e) {
            Log.error("Element not found for primary heating source selection in side sheet by XPath: //input[contains(@id,'RADIO_BUTTON_FOR_" + primaryHeatingSourceVal + "')]");
        }
    }

    public void clickOnSaveButtonOnPrimaryHeatingSystemSideSheet() {
        waitElementBeVisible(saveButtonPrimaryHeatSideSheet);
        scrollAndClickOnElement(saveButtonPrimaryHeatSideSheet);
    }

    public void clickOnEditButtonPrimaryHeatingSource() {
        waitAndClickElement(editButtonPrimaryHeatingSource);
    }

    public void clickOnDogsOnPremisesCheckBox() {
        scrollToElement(dogsOnPremisesCheckBox);
        waitAndClickElement(dogsOnPremisesCheckBox);
    }

    public void selectDogsBreedFromSideSheet(String dogsOnPremisesVal) {
        try {
            PWElement checkBox = driver().findElement(PWBy.xpath("//span[contains(text(),'" + dogsOnPremisesVal + "')]"));
            PWElement matCheckbox = checkBox.findElement(PWBy.xpath("ancestor::mat-checkbox[contains(@class,'breed-checkbox')]"));
            if (!getAttributeData(matCheckbox, CLASS).contains(CHECKBOX_CHECKED)) {
                scrollAndClickOnElement(checkBox);
            }
        } catch (Exception e) {
            Log.error("Element not found for dogs not found selection: " + dogsOnPremisesVal);
        }
    }

    public void unselectDogsBreedFromSideSheet(String dogsOnPremisesVal) {
        try {
            PWElement checkBox = driver().findElement(PWBy.xpath("//span[contains(text(),'" + dogsOnPremisesVal + "')]"));
            PWElement matCheckbox = checkBox.findElement(PWBy.xpath("ancestor::mat-checkbox[contains(@class,'breed-checkbox')]"));
            if (getAttributeData(matCheckbox, CLASS).contains(CHECKBOX_CHECKED)) {
                scrollAndClickOnElement(checkBox);
            }
        } catch (Exception e) {
            Log.error("Element not found for dogs not found selection: " + dogsOnPremisesVal);
        }
    }

    public void clickOnCancelButtonDogsOnPremisesSideSheet() {
        waitAndClickElement(cancelButtonDogsOnPremisesSideSheet);
    }

    public void clickOnSaveButtonDogsOnPremisesSideSheet() {
        if (isElementDisplayed(saveButtonDogsOnPremisesSideSheet, 3)) {
            waitAndClickElement(saveButtonDogsOnPremisesSideSheet);
        }
    }

    public void clickOnEditLinkInDogsOnPremises() {
        waitAndClickElement(editButtonDogsOnPremises);
    }

    public void clickOnPlumbingOtherThanCopperCheckBox() {
        waitAndClickElement(plumbingOtherThanCopperCheckBox);
        waitAndClickElement(plumbingGalvanizedRadioButtonLabel);
    }

    public void clickOnPlumbingSystemsHelpLink() {
        waitAndClickElement(plumbingSystemsHelpLink);
    }

    public void selectPlumbingOtherThanCopperPexPVC(boolean isPlumbingOtherThanCopperPexPVC) {
        if (isPlumbingOtherThanCopperPexPVC) {
            clickOnPlumbingOtherThanCopperCheckBox();
        }
    }

    public void selectPrimaryHeatingSource(String primaryHeatingSourceVal) {
        if (!primaryHeatingSourceVal.equals(EMPTY_STRING)) {
            clickOnPrimaryHeatingSourceCheckBox();
            selectPrimaryHeatingRadioButton(primaryHeatingSourceVal);
            clickOnSaveButtonOnPrimaryHeatingSystemSideSheet();
        }
    }

    public void selectUnrepairedStructure(boolean isUnrepairedStructures) {
        if (isUnrepairedStructures) {
            clickOnUnrepairedStructureCheckbox();
        }
    }

    public void selectBusinessOperatedOnPremisesCheckBox(boolean isBusinessOperatedOnPremises) {
        if (isBusinessOperatedOnPremises) {
            clickOnBusinessOperatedOnPremisesCheckBox();
        }
    }

    public void selectDogsOnPremisesCheckbox(String dogsOnPremisesVal) {
        if (dogsOnPremisesVal != null && !dogsOnPremisesVal.isBlank()) {
            PWElement matCheckbox = dogsOnPremisesCheckBox.findElement(PWBy.xpath("ancestor::mat-checkbox"));
            if (!getAttributeData(matCheckbox, CLASS).contains(CHECKBOX_CHECKED)) {
                clickOnDogsOnPremisesCheckBox();
                selectDogsBreedFromSideSheet(dogsOnPremisesVal);
                clickOnSaveButtonDogsOnPremisesSideSheet();
            }
        }
    }

    public void selectPetWithBiteHistoryCheckBox(boolean isPetWithBiteHistory) {
        if (isPetWithBiteHistory) {
            clickOnPetWithBiteHistoryCheckBox();
        }
    }

    public void clickOnUnrepairedStructureCheckbox() {
        waitAndClickElement(unrepairedStructuresCheckBox);
    }

    public void clickOnBusinessOperatedOnPremisesCheckBox() {
        waitAndClickElement(businessOperatedOnPremisesCheckBox);
    }

    public void clickOnPetWithBiteHistoryCheckBox() {
        waitAndClickElement(petWithBiteHistoryCheckBox);
    }

    public void fillFortifiedPurchaseDate(String fortifiedPurchaseDate) {
        sendKeysOneByOne(certExpDateInputField, fortifiedPurchaseDate);
        sleep(2);
        //clickAway();
        certificateExpDatePickerButtonFMTPHome.sendKeys(PWKeys.TAB);
    }

    public void selectDesignationRdoBtn(String designationSelectionVal) throws Exception {
            PWElement radioBtn = driver().findElement(PWBy.xpath("//mat-radio-button//label[contains(text(),'" + designationSelectionVal + "')]"));
            clickElement(radioBtn);
    }

    public void selectProgramRdoBtn(String programSelectionVal) throws Exception {
        PWElement radioBtn = driver().findElement(PWBy.xpath("//*[contains(@id,'RADIO_BUTTON_FOR_PROGRAM_" + programSelectionVal + "-input')]"));
        clickElement(radioBtn);
    }

    public void selectRoofCategoryRdoBtn(String roofCategorySelectionVal) throws Exception {
        PWElement radioBtn = driver().findElement(PWBy.xpath("//label[contains(text(),'" + roofCategorySelectionVal + "')]"));
        clickElement(radioBtn);
    }

    public void fillFortifiedHomeSection(ApplicantAceHome applicant) throws Exception {
        if (!applicant.getFortifiedHome().isEmpty() && isElementVisible(fortifiedCertificationLabel, 2)) {
            selectFortifiedCertification(true);
            fillFortifiedPurchaseDate(getFortifiedCertificateDateValue());
            selectDesignationRdoBtn(applicant.getDesignationRdoBtn());
            selectProgramRdoBtn(applicant.getProgramRdoBtn());
            selectRoofCategoryRdoBtn(applicant.getRoofCategoryRdoBtn());
        }
    }

    public void fillOutTerritory(ApplicantAceHome applicant) throws Exception {
        if (isTerritoryQuestionAvailable(applicant)) {
            boolean selected = false;
            for (int i = 0; i < 3; i++) {
                waitAndClickElement(selectTerritory);
                if (isElementDisplayed(territoryList, 2)) {
                    waitAndClickElement(optionTerritory);
                    selected = true;
                    break;
                }
                sleep(1);
            }
            if (!selected) {
                throw new IllegalStateException("Territory dropdown did not open; unable to select a territory.");
            }
        }
    }

    public void validateSelectTerritory(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        if (isTerritoryQuestionAvailable(applicant)) {
            final String expectedSelectTerritoryQuestionText = "Select the territory for your address?";
            fsa.assertEquals(getTextFromElement(selectTerritoryQuestion), expectedSelectTerritoryQuestionText, expectedSelectTerritoryQuestionText + " text validation");
            fsa.assertEquals(getTextFromElement(territoryPlaceHoldertext), "Territory", expectedSelectTerritoryQuestionText + " text validation");
            fsa.assertTrue(selectTerritory.isDisplayed(), "Select territory dropdown validation");
            fillOutTerritory(applicant);
        }
    }

    public boolean isTerritoryQuestionAvailable(ApplicantAceHome applicant) throws Exception {
        return applicant.getStateCode().contains(MN) && (isElementDisplayed(PWBy.xpath(TERRITORY_SELECT_XPATH)));
    }

    public void fillOutRNOGSectionNo() throws Exception {
        if (isElementPresent(PWBy.xpath(RACE_TOGGLE_GROUP_XPATH))) {
            for (PWElement buttonNoWe : rnogToggleNoButtons) {
                clickElement(buttonNoWe);
            }
        }
    }

    public void fillOutFlowOfWaterShutoffYes() throws Exception {
        if (isElementPresent(PWBy.xpath(WATER_SHUTOFF_TOGGLE_GROUP_XPATH))) {
            waitAndClickElement(waterShutoffToggleYesButton);
        }
    }

    public void fillOutFMTPWithUnrepairedStructureSelected(ApplicantAceHome applicant) throws Exception {
        if (applicant.isNewlyOwned()) {
            fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }

        fillFortifiedHomeSection(applicant);
        fillOutTerritory(applicant);

        selectMortgageOnThisProperty(false);
        selectUnrepairedStructure(applicant.isUnrepairedStructures());

        clickContinueButton();
    }

    public void fillOutFMTPWithBusinessOperatedOnPremisesSelected(ApplicantAceHome applicant) throws Exception {

        if (applicant.isNewlyOwned()) {
            fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }

        fillFortifiedHomeSection(applicant);
        fillOutTerritory(applicant);

        selectMortgageOnThisProperty(false);
        selectBusinessOperatedOnPremisesCheckBox(applicant.isBusinessOperatedOnPremises());
        clickContinueButton();
    }

    public void fillOutFMTPWithPetWithBiteHistorySelected(ApplicantAceHome applicant) throws Exception {
        if (applicant.isNewlyOwned()) {
            fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }

        fillFortifiedHomeSection(applicant);
        fillOutTerritory(applicant);

        selectMortgageOnThisProperty(false);
        selectPetWithBiteHistoryCheckBox(applicant.isPetWithBiteHistory());
        clickContinueButton();
    }

    public void fillOutFMTPWithPlumbingOtherThanCopperPEXPVCSelected(ApplicantAceHome applicant) throws Exception {
        if (applicant.isNewlyOwned()) {
            fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }

        fillFortifiedHomeSection(applicant);
        fillOutTerritory(applicant);

        selectMortgageOnThisProperty(false);
        selectPlumbingOtherThanCopperPexPVC(applicant.isPlumbingOtherThanCopperPexPVC());
        clickContinueButton();
    }

    public void fillOutFMTPWithPrimaryHeatingSourceSelected(ApplicantAceHome applicant) throws Exception {
        if (applicant.isNewlyOwned()) {
            fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }

        fillFortifiedHomeSection(applicant);
        fillOutTerritory(applicant);

        selectMortgageOnThisProperty(false);
        selectPrimaryHeatingSource(applicant.getPrimaryHeatingSource());
        clickContinueButton();
    }


    public void fillOutFMTPWithDogsOnPremisesSelected(ApplicantAceHome applicant) throws Exception {
        if (applicant.isNewlyOwned()) {
            fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }

        fillFortifiedHomeSection(applicant);
        fillOutTerritory(applicant);

        selectMortgageOnThisProperty(false);
        selectDogsOnPremisesCheckbox(applicant.getDogsOnPremises());
        clickContinueButton();
    }

    public void fillOutFMTPWithAllOtherQuestionsSelected(ApplicantAceHome applicant) throws Exception {
        if (applicant.isNewlyOwned()) {
            fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }

        fillOutTerritory(applicant);
        fillFortifiedHomeSection(applicant);
        selectMortgageOnThisProperty(false);

        selectPlumbingOtherThanCopperPexPVC(applicant.isPlumbingOtherThanCopperPexPVC());
        selectPrimaryHeatingSource(applicant.getPrimaryHeatingSource());
        selectUnrepairedStructure(applicant.isUnrepairedStructures());
        selectBusinessOperatedOnPremisesCheckBox(applicant.isBusinessOperatedOnPremises());
        selectDogsOnPremisesCheckbox(applicant.getDogsOnPremises());
        selectPetWithBiteHistoryCheckBox(applicant.isPetWithBiteHistory());
        clickContinueButton();
    }


    public String getFortifiedCertificateDateValue() {
        return getFormattedDateFromStringDate(getAttributeData(policyStartDateInputFieldFMTPHome, VALUE)).plusDays(2).format(dateTimeFormatter);
    }

    public void fillOutJustFewMoreThingsPage(ApplicantAceHome applicant, boolean continueButton) throws Exception {
        if (applicant.isNewlyOwned() && !applicant.isInEscrow()) {
            fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }
        fillFortifiedHomeSection(applicant);
        selectMortgageOnThisProperty(false);
        fillOutTerritory(applicant);
        fillOutRNOGSectionNo();
        selectDogsOnPremisesCheckbox(applicant.getDogsOnPremises());
        if (continueButton) {
            clickContinueButton();
        }
    }

    public void fillOutBundleJFMTPageAndContinue(ApplicantAceHome hrcApplicant, String propertyType) throws Exception {
        fillOutTerritory(hrcApplicant);
        // Making these false by default, could change to use applicant data in future
        selectBusinessOperatedOnPremisesCheckBox(false);
        selectDogsOnPremisesCheckbox(EMPTY_STRING);
        selectPetWithBiteHistoryCheckBox(false);
        if (!propertyType.equals(RENTERS)) {
            if (hrcApplicant.isNewlyOwned() && !hrcApplicant.isInEscrow()) {
                fillOutHomePurchaseDate(getFormattedYesterdayDate());
            }
            if (propertyType.equals(HOME)) {
            	fillFortifiedHomeSection(hrcApplicant);
            }
            selectMortgageOnThisProperty(false);
        }
        fillOutRNOGSectionNo();
        clickContinueButton();
        waitForSpinnerToBeGone();
        waitForRC3ToBeGone();
        longWaitForElementToBeGoneByXpath(BUNDLE_JFMT_TITLE_XPATH);
    }

    //Possibly externalize in future
    public void waitForRC3ToBeGone() {
    	longWaitForElementToBeGoneByXpath(RC3_SCREEN_XPATH);
    	waitForSpinnerToBeGone();
    }

    public String getSelectedDesignationRdBtn() {
        return designationRadioButtons.stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).findFirst().map(this::getTextFromElement).orElse(null);
    }

    public String getSelectedProgramRdBtn() {
        return programRadioButtons.stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).findFirst().map(this::getTextFromElement).orElse(null);
    }

    public String getSelectedRoofRdBtn() {
        return roofCategoryRadioButtons.stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).findFirst().map(this::getTextFromElement).orElse(null);
    }

    public void validateJFMTPageSelections(String dogsOnPremisesVal, ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        String expectedPolicyStartDate = appStore.getHome().getContactInfo().getPolicyStartDate();

        if (applicant.isNewlyOwned() && !applicant.isInEscrow()) {
            fsa.assertEquals(getAttributeData(homePurchaseDateInputField, VALUE), getFormattedYesterdayDate(), "Newly Owned data");
        }
        if (!applicant.getFortifiedHome().isBlank() && !applicant.getStateCode().equals(IN) && isElementVisible(fortifiedCertificationLabel, 2)) {
            fsa.assertEquals(getAttributeData(certExpDateInputField, VALUE), getFortifiedCertificateDateValue(), "Fortified certification date is entered");
            fsa.assertEquals(getSelectedDesignationRdBtn(), applicant.getDesignationRdoBtn(), "Designation Details are retained");
            fsa.assertTrue(getSelectedProgramRdBtn().replace(SPACE, EMPTY_STRING).replace("&", "And").equalsIgnoreCase(applicant.getProgramRdoBtn()),
                    "Program details are not retained");
            fsa.assertEquals(getSelectedRoofRdBtn(), applicant.getRoofCategoryRdoBtn(), "Roof category Details are retained");
        }
        if (!dogsOnPremisesVal.isBlank()) {
            fsa.assertTrue(!dogsOnPremisesCheckBox.isSelected(), "Dogs On Premises checkbox is selected");
            fsa.assertTrue(getTextFromElement(dogsOnPremisesSelectedValue).contains(dogsOnPremisesVal), "Dog's On Premises selection is displayed");
        }
        fsa.assertEquals(getAttributeData(policyStartDateInputFieldFMTPHome, VALUE), expectedPolicyStartDate, "Policy Start date is Retained");
    }

    public void validateJFMTPageSelectionsRenters(String dogsOnPremisesVal, FarmersSoftAssert fsa) throws Exception {
        if (!dogsOnPremisesVal.isBlank()) {
            AppStore appStore = getSessionStorageAppStore();
            String expectedPolicyStartDate = appStore.getHome().getContactInfo().getPolicyStartDate();
            fsa.assertTrue(!dogsOnPremisesCheckBox.isSelected(), "Dogs On Premises checkbox is selected");
            fsa.assertTrue(getTextFromElement(dogsOnPremisesSelectedValue).contains(dogsOnPremisesVal), "Dog's On Premises selection is displayed");
            fsa.assertEquals(getAttributeData(policyStartDateInputFieldFMTPHome, VALUE), expectedPolicyStartDate, "Policy Start date is Retained");
        }
    }

    public void validateJFMTPageSelectionsCondo(String dogsOnPremisesVal, ApplicantAceHome applicant, FarmersSoftAssert fsa, boolean isMortagageSelected) throws Exception {
        if (applicant.isNewlyOwned() && !applicant.isInEscrow()) {
            fsa.assertEquals(getAttributeData(homePurchaseDateInputField, VALUE), getFormattedYesterdayDate(), "Newly Owned data");
        }
        String buttonXpath = isMortagageSelected ? "//mat-button-toggle[@value='Y']" : "//mat-button-toggle[@value='N']";
        PWElement we = driver().findElement(PWBy.xpath(buttonXpath));
        fsa.assertTrue(getAttributeData(we, CLASS).contains(TOGGLE_CHECKED), "Mortgage selection is retained");
        if (!dogsOnPremisesVal.isBlank()) {
            fsa.assertTrue(!dogsOnPremisesCheckBox.isSelected(), "Dogs On Premises checkbox is unselected");
            fsa.assertTrue(getTextFromElement(dogsOnPremisesSelectedValue).contains(dogsOnPremisesVal), "Dog's On Premises selection is displayed");
        }
        AppStore appStore = getSessionStorageAppStore();
        String expectedPolicyStartDate = appStore.getHome().getContactInfo().getPolicyStartDate();
        fsa.assertEquals(getAttributeData(policyStartDateInputFieldFMTPHome, VALUE), expectedPolicyStartDate, "Policy Start date is Retained");
    }

    public void fillOutFMTPWithCantFindLenderSelected(FarmersSoftAssert fsa, ApplicantAceHome applicant, String lobType) throws Exception {
        if (applicant.isNewlyOwned()) {
            fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }
        fillFortifiedHomeSection(applicant);
        fillOutTerritory(applicant);

        selectMortgageOnThisProperty(true);
        waitAndClickElement(iCantFindMyLenderLabel);
        waitAndClickElement(nextButton.get(0));
        fsa.assertTrue(isElementDisplayed(lenderNotFoundLabel, 3), "JFMT page - Lender not found label.");
        clickContinueButton();
        validateRC3LoadingScreen(fsa);
        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
        Assert.assertTrue(aceHRCPaymentSelectionPage.isOnPaymentPage(), "Did not reach payment page");
        String stateCode = applicant.getStateCode();
        aceHRCPaymentSelectionPage.validatePayInFullPaymentCard(fsa, stateCode, lobType);
        if (!List.of(MO, UT).contains(applicant.getStateCode())) {
            aceHRCPaymentSelectionPage.validateMonthlyAutoPayPaymentBank(fsa, stateCode, lobType);
            aceHRCPaymentSelectionPage.validateMonthlyAutoPayPaymentCard(fsa, stateCode, lobType);
        }
    }


    public void validateLenderInfoSection(FarmersSoftAssert fsa, ApplicantAceHome applicant, String lobType) throws Exception {
        verifyLenderInfoHeaderAndSubHeader(fsa, lobType);
        selectMortgageOnThisProperty(true);
        validateLenderAddressFormFields(fsa);
        validateLenderAddressErrors(fsa);
        lenderSearchTips(fsa);
        iCantFindMyLenderCheckbox(fsa, applicant);
        validateMortgageSelectionToggledToNo(fsa);
        selectMortgageOnThisProperty(true);
        validateLenderAddressSectionDefaultValues(fsa); // Validate after selecting No, previously selected values should be cleared
        fsa.assertTrue(lenderZipOrStateTextBox.isDisplayed(), "Retry finding lender selection did not keep lender info side sheet open");
        validateEnterLenderZipcodeOrState(fsa, applicant);
        validateEnterLenderName(fsa, applicant.getLenderBank());
        validateLoanNumber(fsa);
        validateEscrowAccount(fsa);
        validateEscrowAccountPopup(fsa);
        enterLenderZipcodeOrState(applicant);
        enterLenderName(applicant.getLenderBank());
        sleep(1);
        enterLoanNumber();
        selectEscrowAccount(applicant.getImpoundAccountSelection());
        validatePopulatedLenderInfoUnderMortgageSection(fsa, applicant.getLenderBank());
        if (isEmergencyMortgageAssistanceState(applicant.getStateCode()) && lobType.equals(HOME)) {
            validateEmergencyMortgageAssistanceSection(fsa, applicant);
        }
        validateAddedMortgageAddressIsRemovedWhenNoMortgageSelected(fsa);
    }

    public void validateFortifiedCertificationSection(ApplicantAceHome applicantAceHome, FarmersSoftAssert fsa) throws Exception {
        if (isElementVisible(fortifiedCertificationLabel, 2)) {
            verifyFortifiedCertificationHeaderAndSubHeader(fsa);
            validateFortifiedCertificationToggleButtonsAndInputField(fsa);
            validateCertificateExpFormFields(fsa);
            validateCertificateExpDateErrors(fsa);
            validateAllRdoBtnUnderFortifiedCertification(fsa);
            validateManuallyEnteredCertificationDate(applicantAceHome.getCertExpDate(), fsa);
            selectFortifiedCertification(false);
            validateDiscountRemovalMessageFortifiedCertSection(fsa);
        }
    }

    public void validateFortifiedCertificateSectionVisibility(FarmersSoftAssert fsa) {
        // if Fortified Certification is validated/pre-filled and selected on Additional info page then it should not be displayed on JFMT page
        // F64082: Fortified Home - Move API call to Quote flow
        // DE201269: Was closed as Working as designed.
        fsa.assertFalse(isElementDisplayed(fortifiedCertificationLabel, 3), "Fortified Cert Section Header Label check");
        fsa.assertFalse(isElementDisplayed(fortifiedCertificationSubLabel, 1), "Fortified Cert Section Sub Header Label check");
        fsa.assertFalse(isElementDisplayed(certExpDateInputField, 1), "Fortified Cert Date Picker check");
        fsa.assertFalse(isElementDisplayed(specifyOnePerSectionLabel, 1), "Specify one per section label Message check");
        fsa.assertFalse(isElementDisplayed(designationGroupRdbBtnHeader, 1), "Designation Group header check");
        fsa.assertFalse(isElementDisplayed(programGroupRdbBtnHeader, 1), "Program Group header check");
        fsa.assertFalse(isElementDisplayed(roofCategoryGroupRdbBtnHeader, 1), "Roof Group header check");
        fsa.assertEquals(designationRadioButtons.size(), 0, "Designation radio buttons check");
        fsa.assertEquals(programRadioButtons.size(), 0, "Program radio buttons check");
        fsa.assertEquals(roofCategoryRadioButtons.size(), 0, "Roof category radio buttons check");
    }


    public void fillOutFMTPWithLenderCompanySelected(ApplicantAceHome applicant, String lobType) throws Exception {
        if (!lobType.equals(RENTERS) && applicant.isNewlyOwned()) {
        	fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }
        if (lobType.equals(HOME)) {
            fillFortifiedHomeSection(applicant);
        }
        fillOutLenderInformationWithLenderSelected(applicant);
        fillOutTerritory(applicant);
        clickContinueButton();
    }

    public void checkNoRadioButtonSelected(FarmersSoftAssert fsa) throws Exception {
        for (int j = 1; j <= 6; j++) {
            PWElement we = driver().findElement(PWBy.xpath("//label[text()='Program']//following::mat-radio-button[" + j + "]"));
            fsa.assertTrue(!we.isSelected(), "Radio button/buttons is selected for element " + j);
        }
    }

    public void validateEscrowDetailsOnJFMTPage(FarmersSoftAssert fsa, String lobType) throws Exception {
        fsa.assertEquals(getTextFromElement(policyStartDateHeader), EXPECTED_ESCROW_CLOSING_DATE_HEADER, EXPECTED_ESCROW_CLOSING_DATE_HEADER + " header text check - " + lobType);
        fsa.assertEquals(getTextFromElement(whenWouldYouLikeYourPolicyToBeginQuestion), EXPECTED_ESCROW_TO_CLOSE_QUESTION, EXPECTED_ESCROW_TO_CLOSE_QUESTION + " question text check - " + lobType);
        fsa.assertEquals(policyStartDateInputFieldFMTPHome.isDisplayed(), true, EXPECTED_ESCROW_TO_CLOSE_QUESTION + " input field is not visible - " + lobType);
        fsa.assertEquals(getTextFromElement(whenIsEscrowExpectedToCloseLabel), EXPECTED_ESCROW_TO_CLOSE_LABEL, EXPECTED_ESCROW_TO_CLOSE_LABEL + " input place holder is not visible - " + lobType);
        AppStore appStore = getSessionStorageAppStore();
        String expectedPolicyStartDate = appStore.getHome().getContactInfo().getPolicyStartDate();
        fsa.assertEquals(getValueFromWebElement(policyStartDateInputFieldFMTPHome), expectedPolicyStartDate, "Escrow closing date is not as per the expectation - " + lobType);
        fsa.assertTrue(lightBulbIcon.isDisplayed(), "Light bulb icon check on JFMT Page (Escrow) - " + lobType);
        fsa.assertEquals(getTextFromElement(notSureWhenEscrowIsClosingTitle), EXPECTED_NOT_SURE_WHEN_ESCROW_CLOSING, EXPECTED_NOT_SURE_WHEN_ESCROW_CLOSING + " text check - " + lobType);
        fsa.assertEquals(getTextFromElement(notSureWhenEscrowIsClosingDescText), EXPECTED_ESCROW_IS_CLOSING_DESC_TEXT, EXPECTED_NOT_SURE_WHEN_ESCROW_CLOSING + " description text check - " + lobType);
        fsa.assertEquals(getTextFromElement(escrowInfoBoxTitle), EXPECTED_ESCROW_CLOSING_DATE_HEADER, EXPECTED_ESCROW_CLOSING_DATE_HEADER + " - info bar header text check - " + lobType);
        fsa.assertTrue(getTextFromElement(escrowInfoBoxDescText).startsWith(EXPECTED_INFO_BAR_DESC), "Info bar text check - " + lobType);
        fsa.assertEquals(getTextFromElement(escrowInfoBoxNoteText), EXPECTED_INFO_BAR_NOTE, "Please note text check in Info bar - " + lobType);
    }

    public void validatePastFutureDateOfHomePurchaseDatePicker(FarmersSoftAssert sa, String lobType) {
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.US);
        String formattedFutureDate = getTodayDate().plusDays(1).format(outputFormatter);
        String currentYear = String.valueOf(getTodayDate().getYear());
        String previousYear = String.valueOf(getTodayDate().getYear() - 1);
        String currentMonth = String.valueOf(LocalDate.now().getMonth());
        String expectedDatePast365Days = getTodayDate().minusDays(366).format(outputFormatter);
        try {
            clickDatePickerIconHomePurchaseDate();
            String currentCalendarMonthYear = getTextFromElement(calendarMonthYearHeader);
            log.info("Current month year on calendar is displayed as : " + currentCalendarMonthYear);

            // validating the future date, It should be disabled.
            int i = 0;
            if(!(currentCalendarMonthYear.contains(currentMonth) && currentCalendarMonthYear.contains(currentYear))){
                sa.assertEquals(getAttributeData(nextMonthButtonInCalenderPopUpFMTPHome, DISABLED), LOWERCASE_TRUE, "Future month arrow is enabled on calendar");
            }
            else {
                for (PWElement date : calenderDateCells) {
                    String futureDateAriaLabel = getAttributeData(date, ARIA_LABEL);
                    if (futureDateAriaLabel.contains(formattedFutureDate) || (i > 31)) {
                        sa.assertEquals(getAttributeData(date, ARIA_DISABLED), LOWERCASE_TRUE, "Future date is enabled on home purchase date picker - " + lobType);
                        break;
                    }
                    i++;
                }
            }
            // traversing backward to the last year and month
            waitAndClickElement(monthYearLabelInCalenderPopUpFMTPHome);
            boolean yearFound = false;
            i = 0;
            while (!yearFound && (i < 12)) {
                for (PWElement year : calenderDateCells) {
                    if (getAttributeData(year, ARIA_LABEL).equals(previousYear)) {
                        waitAndClickElement(year);
                        yearFound = true;
                        break;
                    }
                }
                if (!yearFound) {
                    waitAndClickElement(previousMonthButtonInCalenderPopUpFMTPHome);
                }
                i++;
            }
            i = 0;
            for (PWElement month : calenderDateCells) {
                if (getAttributeData(month, ARIA_LABEL).toUpperCase().contains(currentMonth) || (i > 12)) {
                    waitAndClickElement(month);
                    break;
                }
                i++;
            }
            // Validating date older than 365 days
            i = 0;
            boolean isPast365DayLabelFound = false;
            while (!isPast365DayLabelFound && (i < 31)) {
                for (PWElement date : calenderDateCells) {
                    if (getAttributeData(date, ARIA_LABEL).contains(expectedDatePast365Days)) {
                        sa.assertTrue(getAttributeData(date, ARIA_DISABLED).equals(LOWERCASE_TRUE), "Date older than 365 days is enabled on home purchase date picker - " + lobType);
                        isPast365DayLabelFound = true;
                        break;
                    }
                }
                if (!isPast365DayLabelFound) {
                    sa.assertTrue(getAttributeData(previousMonthButtonInCalenderPopUpFMTPHome, DISABLED).equals(LOWERCASE_TRUE), "We can't see the date in last year current month calender, but the date picker backword arrow is enabled which is incorrect - ");
                    isPast365DayLabelFound = true;
                }
                i++;
            }
        } catch (Exception e) {
            throw new IllegalStateException("Home Purchase date picker should be present and clickable but it is either not available or clickable - " + lobType);
        }
    }

    public void verifyBundlePropertyJustAFewMoreThingsPageContent(String propertyType, FarmersSoftAssert fsa) {
    	fsa.assertEquals(getTextFromElement(bundlePropertyJustFewMoreThingsTitle), "Review and complete " + propertyType.toLowerCase(), propertyType + " JFMT Page title verification");
    	fsa.assertEquals(getTextFromElement(policyStartDateHeader), "Property policy start date", "Policy start date header verification");
    	fsa.assertEquals(getTextFromElement(buttonContinue), "Continue to final review", "Continue button text verification");
    }
    public String getHomePolicyStartDateInHRCFewMoreThingsPage(){
        return getElementValue(policyStartDateInputFieldFMTPHome, "HRC policy start date:").trim();
    }

    public boolean isOnRC3LoadingPage() {
        return isElementVisible(rc3MainHeading, 10);
    }

    public void validateRC3LoadingScreen(FarmersSoftAssert fsa) throws Exception {
        String verifyingYourQuote = "Verifying your quote";
        String settingUpSomeBillingOptions  = "Setting up some billing options";
        String finishingUp = "Finishing up";

        Assert.assertTrue(isOnRC3LoadingPage(), "User is on the RC3 Loading page.");

        //validating Page content
        fsa.assertEquals(getTextFromElement(rc3MainHeading), FINALIZING_YOUR_QUOTE, "RC3 Loading page main heading check");
        fsa.assertEquals(getTextFromElement(rc3SubHeading1), RC3_PAGE_SUBTITLE1, "RC3 Loading page sub heading check");
        fsa.assertEquals(getTextFromElement(rc3SubHeading2), RC3_PAGE_SUBTITLE2, "RC3 Loading page sub heading check");
        fsa.assertTrue(isElementDisplayed(PWBy.xpath(String.format("//span[@class='rc3_loading_screen_label_text' and contains(.,'%s')]", verifyingYourQuote))), verifyingYourQuote + " text is present");
        fsa.assertTrue(isElementDisplayed(PWBy.xpath(String.format("//span[@class='rc3_loading_screen_label_text' and contains(.,'%s')]", settingUpSomeBillingOptions))), settingUpSomeBillingOptions + " text is present");
        fsa.assertTrue(isElementDisplayed(PWBy.xpath(String.format("//span[@class='rc3_loading_screen_label_text' and contains(.,'%s')]", finishingUp))), finishingUp + " text is present");
        testStep("RC3 Loading page content validation");
    }

    public List<String> prebindContingencyKOCode(ApplicantAceHome applicantAceHome) {
        List<String> expectedKOCode = new ArrayList<>();
        if (applicantAceHome.getPlumbingUpdated().equals(I_AM_NOT_SURE)) {
            expectedKOCode.add("PAU");
        }
        if (applicantAceHome.getElectricalUpdated().equals(I_AM_NOT_SURE)) {
            expectedKOCode.add("EAU");
        }
        if (applicantAceHome.getHvacUpdated().equals(I_AM_NOT_SURE)) {
            expectedKOCode.add("HAU");
        }
        return getSortedList(expectedKOCode);
    }
}

