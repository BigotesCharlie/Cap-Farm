package com.farmers.ffq.auto.pages.legacy;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.datatransferobjects.SqlPayment;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PaymentPage extends AutoBasePage  {
	private static final String PAYMENT_PAGE_HEADER = "//div[@id='PaymentContent']/div[@id='Intro']";
	@PWFindBy(xpath = PAYMENT_PAGE_HEADER + "/p[@title='PAYMENT DETAILS']")
	private PWElement paymentPageTitle;

	@PWFindBy(xpath = PAYMENT_PAGE_HEADER + "/p[@class='subTitleAlign']")
	private PWElement paymentPageDescription;

	@PWFindBy(xpath = PAYMENT_PAGE_HEADER + "/p[@id='termPremiumSecText']")
	private PWElement termPremium;

	@PWFindBy(xpath = "//span[contains(@id,'payment:paymentHeaderText')]")
	private PWElement paymentPlanHeader;

	@PWFindBy(id = "MoreOptions")
	private PWElement changePaymentPlanLink;
	
	@PWFindBy(id = "payment:doInitiateESignature")
	private PWElement continueToSignButton;

	@PWFindBy(id = "disclosureAccepted")
	private PWElement agreeToUseESign;
	
	@PWFindBy(id = "action-bar-btn-continue")
	private PWElement continueFromESign;
	
	@PWFindBy (id = "action-bar-btn-finish")
	private PWElement bwFinishDocReviewButton;
	  
	//Select Payment Dialog
	@PWFindBy(xpath = "//div[contains(@class, 'selectPaymentOptionHeading')]")
	private PWElement selectPaymentDialogTitle;

	private static final String RADIO_BUTTON_SECTION = "//div[contains(@class, 'radioAlign')]";
	private static final String DUE_TODAY_SECTION = "//div[contains(@class, 'dueToday')]";
	private static final String NEXT_PAYMENT_SECTION = "//div[contains(@class, 'nextPaymentDueClass')]";
	private static final String PAYMENT_SCHEDULE_SECTION = "//div[contains(@class, 'paymentScheduleClass')]";

	//Payment plans
	//Pay in Full
	private static final String PAY_IN_FULL_SECTION = "//div[contains(@class, 'A1DivClass')]";
	@PWFindBy(xpath = PAY_IN_FULL_SECTION)
	private PWElement payInFullOption;

	@PWFindBy(xpath = PAY_IN_FULL_SECTION + RADIO_BUTTON_SECTION)
	private PWElement payInFullRadioButtonSection;

	@PWFindBy(xpath = PAY_IN_FULL_SECTION + DUE_TODAY_SECTION)
	private PWElement payInFullDueTodaySection;

	@PWFindBy(xpath = PAY_IN_FULL_SECTION + NEXT_PAYMENT_SECTION)
	private PWElement payInFullNextPaymentSection;

	@PWFindBy(xpath = PAY_IN_FULL_SECTION + PAYMENT_SCHEDULE_SECTION)
	private PWElement payInFullPaymentScheduleSection;

	// Monthly Auto Pay - Bank Account
	private static final String MONTHLY_BANK_ACCOUNT_SECTION = "//div[contains(@class, 'MTEFDivClass')]";
	@PWFindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION)
	private PWElement monthlyBankAccountOption;

	@PWFindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION + RADIO_BUTTON_SECTION)
	private PWElement monthlyBankAccountRadioButtonSection;

	@PWFindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION + DUE_TODAY_SECTION)
	private PWElement monthlyBankAccountDueTodaySection;

	@PWFindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION + NEXT_PAYMENT_SECTION)
	private PWElement monthlyBankAccountNextPaymentSection;

	@PWFindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION + PAYMENT_SCHEDULE_SECTION)
	private PWElement monthlyBankAccountPaymentScheduleSection;

	// Monthly Auto Pay - Credit Card
	private static final String MONTHLY_CREDIT_CARD_SECTION = "//div[contains(@class, 'MTPCDivClass')]";
	@PWFindBy(xpath = MONTHLY_CREDIT_CARD_SECTION)
	private PWElement monthlyCreditCardOption;

	@PWFindBy(xpath = MONTHLY_CREDIT_CARD_SECTION + RADIO_BUTTON_SECTION)
	private PWElement monthlyCreditCardRadioButtonSection;

	@PWFindBy(xpath = MONTHLY_CREDIT_CARD_SECTION + DUE_TODAY_SECTION)
	private PWElement monthlyCreditCardDueTodaySection;

	@PWFindBy(xpath = MONTHLY_CREDIT_CARD_SECTION + NEXT_PAYMENT_SECTION)
	private PWElement monthlyCreditCardNextPaymentSection;

	@PWFindBy(xpath = MONTHLY_CREDIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION)
	private PWElement monthlyCreditCardPaymentScheduleSection;

	// Monthly Auto Pay - Debit Card
	private static final String MONTHLY_DEBIT_CARD_SECTION = "//div[contains(@class, 'MTPDDivClass')]";
	@PWFindBy(xpath = MONTHLY_DEBIT_CARD_SECTION)
	private PWElement monthlyDebitCardOption;

	@PWFindBy(xpath = MONTHLY_DEBIT_CARD_SECTION + RADIO_BUTTON_SECTION)
	private PWElement monthlyDebitCardRadioButtonSection;

	@PWFindBy(xpath = MONTHLY_DEBIT_CARD_SECTION + DUE_TODAY_SECTION)
	private PWElement monthlyDebitCardDueTodaySection;

	@PWFindBy(xpath = MONTHLY_DEBIT_CARD_SECTION + NEXT_PAYMENT_SECTION)
	private PWElement monthlyDebitCardNextPaymentSection;

	@PWFindBy(xpath = MONTHLY_DEBIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION)
	private PWElement monthlyDebitCardPaymentScheduleSection;

	//Monthly Billing
	private static final String MONTHLY_BILLING_SECTION = "//div[contains(@class, 'MTDivClass')]";
	@PWFindBy(xpath = MONTHLY_BILLING_SECTION)
	private PWElement monthlyBillingOption;

	@PWFindBy(xpath = MONTHLY_BILLING_SECTION + RADIO_BUTTON_SECTION)
	private PWElement monthlyBillingRadioButtonSection;

	@PWFindBy(xpath = MONTHLY_BILLING_SECTION + DUE_TODAY_SECTION)
	private PWElement monthlyBillingDueTodaySection;

	@PWFindBy(xpath = MONTHLY_BILLING_SECTION + NEXT_PAYMENT_SECTION)
	private PWElement monthlyBillingNextPaymentSection;

	@PWFindBy(xpath = MONTHLY_BILLING_SECTION + PAYMENT_SCHEDULE_SECTION)
	private PWElement monthlyBillingPaymentScheduleSection;

	// Bristol West Payment plans
	// Pay in Full
	private static final String BW_PAY_IN_FULL_SECTION = "//div[contains(@class, 'PIFDivClass')]";
	@PWFindBy(xpath = BW_PAY_IN_FULL_SECTION)
	private PWElement bwPayInFullOption;

	@PWFindBy(xpath = BW_PAY_IN_FULL_SECTION + RADIO_BUTTON_SECTION)
	private PWElement bwPayInFullRadioButtonSection;

	@PWFindBy(xpath = BW_PAY_IN_FULL_SECTION + DUE_TODAY_SECTION)
	private PWElement bwPayInFullDueTodaySection;

	@PWFindBy(xpath = BW_PAY_IN_FULL_SECTION + NEXT_PAYMENT_SECTION)
	private PWElement bwPayInFullNextPaymentSection;

	@PWFindBy(xpath = BW_PAY_IN_FULL_SECTION + PAYMENT_SCHEDULE_SECTION)
	private PWElement bwPayInFullPaymentScheduleSection;

	// Monthly Auto Pay - Bank Account
	private static final String BW_MONTHLY_BANK_ACCOUNT_SECTION = "//div[contains(@class, 'EFTBDivClass')]";
	@PWFindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION)
	private PWElement bwMonthlyBankAccountOption;

	@PWFindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION + RADIO_BUTTON_SECTION)
	private PWElement bwMonthlyBankAccountRadioButtonSection;

	@PWFindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION + DUE_TODAY_SECTION)
	private PWElement bwMonthlyBankAccountDueTodaySection;

	@PWFindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION + NEXT_PAYMENT_SECTION)
	private PWElement bwMonthlyBankAccountNextPaymentSection;

	@PWFindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION + PAYMENT_SCHEDULE_SECTION)
	private PWElement bwMonthlyBankAccountPaymentScheduleSection;

	// Monthly Auto Pay - Credit Card
	private static final String BW_MONTHLY_CREDIT_CARD_SECTION = "//div[contains(@class, 'EFTCDivClass')]";
	@PWFindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION)
	private PWElement bwMonthlyCreditCardOption;

	@PWFindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION + RADIO_BUTTON_SECTION)
	private PWElement bwMonthlyCreditCardRadioButtonSection;

	@PWFindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION + DUE_TODAY_SECTION)
	private PWElement bwMonthlyCreditCardDueTodaySection;

	@PWFindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION + NEXT_PAYMENT_SECTION)
	private PWElement bwMonthlyCreditCardNextPaymentSection;

	@PWFindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION)
	private PWElement bwMonthlyCreditCardPaymentScheduleSection;

	// Monthly Auto Pay - Debit Card
	private static final String BW_MONTHLY_DEBIT_CARD_SECTION = "//div[contains(@class, 'EFTDDivClass')]";
	@PWFindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION)
	private PWElement bwMonthlyDebitCardOption;

	@PWFindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION + RADIO_BUTTON_SECTION)
	private PWElement bwMonthlyDebitCardRadioButtonSection;

	@PWFindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION + DUE_TODAY_SECTION)
	private PWElement bwMonthlyDebitCardDueTodaySection;

	@PWFindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION + NEXT_PAYMENT_SECTION)
	private PWElement bwMonthlyDebitCardNextPaymentSection;

	@PWFindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION)
	private PWElement bwMonthlyDebitCardPaymentScheduleSection;

	//Monthly Billing
	private static final String BW_MONTHLY_BILLING_SECTION = "//div[contains(@class, 'NONDivClass')]";
	@PWFindBy(xpath = BW_MONTHLY_BILLING_SECTION)
	private PWElement bwMonthlyBillingOption;

	@PWFindBy(xpath = BW_MONTHLY_BILLING_SECTION + RADIO_BUTTON_SECTION)
	private PWElement bwMonthlyBillingRadioButtonSection;

	@PWFindBy(xpath = BW_MONTHLY_BILLING_SECTION + DUE_TODAY_SECTION)
	private PWElement bwMonthlyBillingDueTodaySection;

	@PWFindBy(xpath = BW_MONTHLY_BILLING_SECTION + NEXT_PAYMENT_SECTION)
	private PWElement bwMonthlyBillingNextPaymentSection;

	@PWFindBy(xpath = BW_MONTHLY_BILLING_SECTION + PAYMENT_SCHEDULE_SECTION)
	private PWElement bwMonthlyBillingPaymentScheduleSection;

	@PWFindBy(xpath = "//input[@value='Continue']")
	private PWElement continueButton;

	/**
	 * Constructor.
	 *
	 * @throws Exception 
	 */
	public PaymentPage() throws Exception {
		super();
		checkForKnockout("PaymentPage constructor");
		if (!isElementPresentByClass(errorMessageElement)) {
			waitElementBeVisible(selectPaymentDialogTitle);
		}
	}

	public void processPaymentPage(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		if (!isElementPresentByClass(errorMessageElement)) {
			boolean isBristolWestQuote = isBristolWestQuote();
			if (isElementPresentByID(continueToSignButton)) {
				clickElement(continueToSignButton);
				waitForPageToBeReady();
				waitForSpinnerToBeGone();
				waitAndClickElement(agreeToUseESign);
				waitAndClickElement(continueFromESign);			
				waitForPageToBeReady();
				waitForSpinnerToBeGone();
				waitAndClickElement(bwFinishDocReviewButton);
			} else {
				Log.warn("Got to payment page with payment plan: " + applicant.getPayment().getPaymentPlan(), true);
				verifyPaymentPlans(applicant.getStateCode(), isBristolWestQuote, fsa);
				selectPaymentPlan(applicant.getPayment(), isBristolWestQuote);
			}
		}
	}

	private void selectPaymentPlan(SqlPayment paymentObject, boolean isBristolWestQuote) {
		Log.warn("Select payment plan", true);
		if (isBristolWestQuote) {
			switch (paymentObject.getPaymentPlan()) {
			case "Pay in Full" :
				scrollAndClickOnElement(bwPayInFullRadioButtonSection);
				break;
			case "Monthly Automatic - Bank Account" :
				clickElement(bwMonthlyBankAccountRadioButtonSection);
				break;
			case "Monthly Automatic - Credit/Debit Card" :
				if (paymentObject.getPaymentMethod().equals("Credit Card")) {
					clickElement(bwMonthlyCreditCardRadioButtonSection);
				} else {
					clickElement(bwMonthlyDebitCardRadioButtonSection);
				}
				break;
			case "Monthly":
				clickElement(bwMonthlyBillingRadioButtonSection);
				break;
			default:
				throw new IllegalArgumentException("Invalid Payment Plan: <" + paymentObject.getPaymentPlan() + ">");				
			}
		} else {
			switch (paymentObject.getPaymentPlan()) {
			case "Pay in Full" :
				scrollAndClickOnElement(payInFullRadioButtonSection);
				break;
			case "Monthly Automatic - Bank Account" :
				clickElement(monthlyBankAccountRadioButtonSection);
				break;
			case "Monthly Automatic - Credit/Debit Card" :
				clickElement(monthlyCreditCardRadioButtonSection);				
				break;
			case "Monthly":
				clickElement(monthlyBillingRadioButtonSection);
				break;
			default:
				throw new IllegalArgumentException("Invalid Payment Plan: <" + paymentObject.getPaymentPlan() + ">");				
			}
		}
		scrollToElementBottom(continueButton);
		clickElement(continueButton);
	}

	private void verifyPaymentPlans(String stateCode, boolean isBristolWestQuote, FarmersSoftAssert fsa) {
		if (isBristolWestQuote) {
			fsa.assertTrue(getTextFromElement(selectPaymentDialogTitle).contains("How would you like to pay?"), "selectPaymentDialogTitle");	
			fsa.assertTrue(bwPayInFullRadioButtonSection.isDisplayed(), "PayInFull radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwPayInFullRadioButtonSection).contains("Payment in full"), "bwPayInFullRadioButtonSection");
			fsa.assertTrue(bwMonthlyBankAccountRadioButtonSection.isDisplayed(), "MonthlyAutoBankAcnt radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwMonthlyBankAccountRadioButtonSection).contains("Monthly payment (AutoPay) bank account"), "bwMonthlyBankAccountRadioButtonSection");
			fsa.assertTrue(bwMonthlyCreditCardRadioButtonSection.isDisplayed(), "MonthlyAutoCredit radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwMonthlyCreditCardRadioButtonSection).contains("Monthly payment (AutoPay) credit card"), "bwMonthlyCreditCardRadioButtonSection");
			fsa.assertTrue(bwMonthlyDebitCardRadioButtonSection.isDisplayed(), "MonthlyAutoDebit radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwMonthlyDebitCardRadioButtonSection).contains("Monthly payment (AutoPay) debit card"), "bwMonthlyBillingRadioButtonSection");
			fsa.assertTrue(bwMonthlyBillingRadioButtonSection.isDisplayed(), "Monthly radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwMonthlyBillingRadioButtonSection).contains("Monthly billing"), "bwMonthlyBillingRadioButtonSection");
		} else {		
			fsa.assertTrue(getTextFromElement(selectPaymentDialogTitle).contains("SELECT A PAYMENT PLAN"), "selectPaymentDialogTitle");	
			if (isEasternExpansionState(stateCode)) { // LA
				fsa.assertTrue(monthlyBankAccountRadioButtonSection.isDisplayed(), "MonthlyAutoBankAcnt radio button in pop-up window visible!");
				fsa.assertTrue(getTextFromElement(monthlyBankAccountRadioButtonSection).contains("Monthly automatic with bank account"), "monthlyBankAccountRadioButtonSection");
				fsa.assertTrue(monthlyDebitCardRadioButtonSection.isDisplayed(), "MonthlyAutoDebit radio button in pop-up window visible!");
				fsa.assertTrue(getTextFromElement(monthlyDebitCardRadioButtonSection).contains("Monthly automatic with debit card"), "bwMonthlyBillingRadioButtonSection");
				fsa.assertTrue(monthlyCreditCardRadioButtonSection.isDisplayed(), "MonthlyAutoCreditDebit radio button in pop-up window visible!");
				fsa.assertTrue(getTextFromElement(monthlyCreditCardRadioButtonSection).contains("Monthly automatic with credit card"), "monthlyCreditCardRadioButtonSection");
				fsa.assertTrue(payInFullRadioButtonSection.isDisplayed(), "PayInFull radio button in pop-up window visible!");
				fsa.assertTrue(getTextFromElement(payInFullRadioButtonSection).contains("Pay in full"), "payInFullRadioButtonSection");
			} else {
				if (!stateCode.equals(NJ)) {
					fsa.assertTrue(monthlyBankAccountRadioButtonSection.isDisplayed(), "MonthlyAutoBankAcnt radio button in pop-up window visible!");
					fsa.assertTrue(getTextFromElement(monthlyBankAccountRadioButtonSection).contains("Monthly payment (AutoPay) bank account"), "monthlyBankAccountRadioButtonSection");
				}
				fsa.assertTrue(monthlyCreditCardRadioButtonSection.isDisplayed(), "MonthlyAutoCreditDebit radio button in pop-up window visible!");
				if (isDebitListedFirstStates(stateCode)) {
					fsa.assertTrue(getTextFromElement(monthlyCreditCardRadioButtonSection).contains("Monthly payment (AutoPay) debit/credit card"), "monthlyCreditCardRadioButtonSection");
				} else {
					fsa.assertTrue(getTextFromElement(monthlyCreditCardRadioButtonSection).contains("Monthly payment (AutoPay) credit/debit card"), "monthlyCreditCardRadioButtonSection");				
				}
				if (!stateCode.equals(TN)) {
					fsa.assertTrue(payInFullRadioButtonSection.isDisplayed(), "PayInFull radio button in pop-up window visible!");
					fsa.assertTrue(getTextFromElement(payInFullRadioButtonSection).contains("Payment in full"), "payInFullRadioButtonSection");
				}
			}
		}
	}

	private boolean isDebitListedFirstStates(String stateCode) {
		List<String> debitListedFirstStates = new ArrayList<>(Arrays.asList(AL, CT, MT, ND, OR, SD, VA));
		return debitListedFirstStates.contains(stateCode);
	}
}
