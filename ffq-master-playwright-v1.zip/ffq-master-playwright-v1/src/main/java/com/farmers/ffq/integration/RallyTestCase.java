package com.farmers.ffq.integration;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to link a TestNG test method (or class) to one or more Rally test case IDs.
 *
 * <p>Usage:
 * <pre>
 *   {@literal @}Test(groups = {REGRESSION})
 *   {@literal @}RallyTestCase(ids = {"TC12345", "TC67890"})
 *   public void myTest() { ... }
 * </pre>
 *
 * <p>After each test run the {@link com.farmers.ffq.integration.RallyListener} will automatically report Pass / Fail
 * results to Rally for every ID listed in {@code ids}.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
public @interface RallyTestCase {

    /**
     * One or more Rally test-case formatted IDs, e.g. {@code "TC12345"}.
     */
    String[] ids();

    /**
     * Optional human-readable description that is appended to the Rally result note.
     */
    String description() default "";
}

