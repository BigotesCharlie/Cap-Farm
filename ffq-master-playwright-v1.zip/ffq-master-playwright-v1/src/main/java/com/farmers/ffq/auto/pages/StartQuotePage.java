package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
public class StartQuotePage extends BasePage {


    @PWFindBy(css = "div.mat-select-arrow-wrapper")
    private PWElement dropdownArrow;

    @PWFindBy(xpath = "//mat-option[./span[text() = 'Auto']]")
    private PWElement autoDropDownOption;

    @PWFindBy(css = "input[formcontrolname]")
    private PWElement zipCodeInput;

    @PWFindBy(xpath = "//button[text()='START QUOTE']")
    private PWElement startQuoteButton;



    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public StartQuotePage() throws Exception {
        String url = Property.getUri();
        driver().manage().deleteAllCookies();
        Log.info("\n\t\tNavigating to " + url);
        try {
            driver().navigate().to(url);
        } catch (PWTimeoutException te) {
            driver().navigate().refresh();
            driver().navigate().to(url);
        }
        PWDriver driver = driver();
        PWPageFactory.initElements(driver, this);
    }

    public void startQuote(AutoApplicant autoApplicant) {
        startQuote(autoApplicant.getZipCode());
    }

    public void startQuote(String zipCode) {
        waitAndClickElement(dropdownArrow);
        waitAndClickElement(autoDropDownOption);
        enterValueInField(zipCode, zipCodeInput, "Entering ZipCode: ");
        startQuoteButton.click();
    }
}
