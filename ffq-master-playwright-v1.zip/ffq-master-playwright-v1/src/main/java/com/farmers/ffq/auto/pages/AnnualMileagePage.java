package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import java.util.List;

/**
 * Page Object for the Annual Mileage page.
 * Shown when the system cannot confirm the annual mileage for one or more vehicles.
 */
public class AnnualMileagePage extends AutoBasePage {

    // ─── Page-level elements ────────────────────────────────────────────────

    /** H1 "Annual mileage" heading. */
    @PWFindBy(css = "app-annual-mileage h1.tui-h1")
    private PWElement pageTitle;

    /** Subtitle: "We need your help. We weren't able to confirm annual mileage for the following:" */
    @PWFindBy(css = "p.annual-mileage__subtitle")
    private PWElement pageSubtitle;

    // ─── Per-vehicle elements ────────────────────────────────────────────────

    /**
     * One label per vehicle, e.g. "2007 CHEVROLET TRUCK TRAILBLAZER 4DOOR 4X2".
     * Use {@code get(index)} to target a specific vehicle section.
     */
    @PWFindBy(css = "p.annual-mileage__vehicle-label")
    private List<PWElement> vehicleLabels;

    /**
     * Annual mileage input field for each vehicle (ordered, same index as {@link #vehicleLabels}).
     * Each field has {@code formcontrolname="annualMileage"}, maxlength 6, and inputmode="numeric".
     */
    @PWFindBy(css = "input[formcontrolname='annualMileage']")
    private List<PWElement> annualMileageInputFields;

    /**
     * Inline validation error messages ("Annual mileage is required." / invalid value messages).
     * Indexed in the same order as {@link #vehicleLabels}.
     */
    @PWFindBy(css = "mat-error.annual-mileage__error")
    private List<PWElement> annualMileageErrorMessages;

    // ─── CTA ─────────────────────────────────────────────────────────────────

    /** Primary "Continue" button at the bottom of the form. */
    @PWFindBy(id = "ANNUAL_MILEAGE_CONTINUE_CTA")
    private PWElement continueButton;

    // ─── Expected text constants ──────────────────────────────────────────────

    public static final String EXPECTED_PAGE_TITLE   = "Annual mileage";
    public static final String EXPECTED_PAGE_SUBTITLE =
            "We need your help. We weren't able to confirm annual mileage for the following:";
    public static final String ANNUAL_MILEAGE_REQUIRED_ERROR = "Annual mileage is required.";

    // ─── Constructor ──────────────────────────────────────────────────────────

    /**
     * Constructor.
     *
     * @throws Exception if the underlying driver() call fails
     */
    public AnnualMileagePage() throws Exception {
        super();
    }

    // ─── Navigation / state ───────────────────────────────────────────────────

    /**
     * Returns {@code true} once the Annual Mileage page heading is visible.
     *
     * @return {@code true} if the page title is displayed within 40 s
     */
    public boolean isOnAnnualMilagePage() {
        waitForSpinnerToBeGone();
        return isElementVisible(pageTitle, 10); // we have to wait for verify rate response to find out if user on the annual mileage page or not, hence the 10s wait for the page title to be visible
    }

    // ─── Getters / text helpers ───────────────────────────────────────────────

    /**
     * Returns the trimmed text of the H1 heading.
     *
     * @return page title text
     */
    public String getPageTitleText() {
        return getTextFromElement(pageTitle).trim();
    }

    /**
     * Returns the trimmed subtitle text.
     *
     * @return subtitle text
     */
    public String getPageSubtitleText() {
        return getTextFromElement(pageSubtitle).trim();
    }

    /**
     * Returns all vehicle label texts shown on the page (e.g. "2007 CHEVROLET TRUCK TRAILBLAZER 4DOOR 4X2").
     *
     * @return ordered list of vehicle description strings
     */
    public List<String> getVehicleLabelTexts() {
        return vehicleLabels.stream()
                .map(this::getTextFromElement)
                .map(String::trim)
                .collect(java.util.stream.Collectors.toList());
    }

    /**
     * Returns the number of vehicles displayed on this page.
     *
     * @return count of vehicle sections
     */
    public int getVehicleCount() {
        return vehicleLabels.size();
    }

    // ─── Input actions ────────────────────────────────────────────────────────

    /**
     * Enters the given mileage value into the input field for the vehicle at {@code index}.
     * Index is 0-based, matching the order in which vehicles appear on the page.
     *
     * @param index   0-based vehicle index
     * @param mileage annual mileage value (numeric string, max 6 characters)
     */
    public void enterAnnualMileageForVehicle(int index, String mileage) {
        PWElement inputField = annualMileageInputFields.get(index);
        scrollElementToMiddle(inputField);
        enterValueInField(mileage, inputField, "Entering annual mileage for vehicle " + index + ": ");
        Log.info(String.format("Annual mileage '%s' entered for vehicle at index %d", mileage, index));
    }

    /**
     * Enters mileage values for every vehicle currently displayed on the page.
     * <ul>
     *   <li>One value supplied → that value is used for all vehicles.</li>
     *   <li>Fewer values than vehicles → the last value is recycled for the remaining vehicles.</li>
     *   <li>More values than vehicles → extras are ignored.</li>
     * </ul>
     *
     * @param mileageValues one or more mileage strings; the last value is recycled for any
     *                      additional vehicles found on the page at runtime
     */
    public void enterAnnualMileageForAllVehicles(String... mileageValues) {
        if (mileageValues == null || mileageValues.length == 0) {
            Log.warn("enterAnnualMileageForAllVehicles called with no values — skipping.");
            return;
        }
        int vehicleCount = annualMileageInputFields.size();
        Log.info(String.format("Filling annual mileage for %d vehicle(s) on the page", vehicleCount));
        for (int i = 0; i < vehicleCount; i++) {
            String mileage = mileageValues[Math.min(i, mileageValues.length - 1)];
            enterAnnualMileageForVehicle(i, mileage);
        }
    }

    /**
     * Clears the annual mileage input field for the vehicle at {@code index} and
     * immediately re-enters a new value.
     *
     * @param index      0-based vehicle index
     * @param newMileage replacement mileage value
     */
    public void updateAnnualMileageForVehicle(int index, String newMileage) {
        PWElement inputField = annualMileageInputFields.get(index);
        scrollElementToMiddle(inputField);
        inputField.clear();
        enterValueInField(newMileage, inputField, "Updating annual mileage for vehicle " + index + ": ");
        Log.info(String.format("Annual mileage updated to '%s' for vehicle at index %d", newMileage, index));
    }

    // ─── CTA ─────────────────────────────────────────────────────────────────

    /**
     * Clicks the primary "Continue" button and waits for any spinner to disappear.
     */
    public void clickContinue() {
        scrollElementToMiddle(continueButton);
        waitAndClickElement(continueButton);
        waitForSpinnerToBeGone();
        Log.info("Clicked 'Continue' on Annual Mileage page");
    }

    // ─── Validation helpers ───────────────────────────────────────────────────

    /**
     * Returns the inline error message text for the vehicle at {@code index}, or an empty string
     * if no error is currently shown.
     *
     * @param index 0-based vehicle index
     * @return error message text (trimmed)
     */
    public String getAnnualMileageErrorMessageForVehicle(int index) {
        if (index < annualMileageErrorMessages.size()) {
            return getTextFromElement(annualMileageErrorMessages.get(index)).trim();
        }
        return "";
    }

    /**
     * Asserts that the page title, subtitle and the "required" error messages for all vehicles
     * are shown as expected.
     *
     * @param fsa      a {@link FarmersSoftAssert} instance to collect failures
     */
    public void validatePageContent(FarmersSoftAssert fsa) {
        fsa.assertEquals(getPageTitleText(), EXPECTED_PAGE_TITLE,
                "Annual Mileage page title");
        fsa.assertEquals(getPageSubtitleText(), EXPECTED_PAGE_SUBTITLE,
                "Annual Mileage page subtitle");
    }

    /**
     * Asserts that all visible annual-mileage error messages read "Annual mileage is required."
     *
     * @param fsa a {@link FarmersSoftAssert} instance to collect failures
     */
    public void validateRequiredErrorMessagesForAllVehicles(FarmersSoftAssert fsa) {
        for (int i = 0; i < annualMileageErrorMessages.size(); i++) {
            fsa.assertEquals(getAnnualMileageErrorMessageForVehicle(i),
                    ANNUAL_MILEAGE_REQUIRED_ERROR,
                    "Annual mileage required error for vehicle index " + i);
        }
    }

    /**
     * Asserts that a specific vehicle label is present on the page.
     *
     * @param fsa              soft-assert instance
     * @param vehicleLabel     expected label text (e.g. "2007 CHEVROLET TRUCK TRAILBLAZER 4DOOR 4X2")
     */
    public void validateVehicleLabelIsPresent(FarmersSoftAssert fsa, String vehicleLabel) {
        List<String> labels = getVehicleLabelTexts();
        fsa.assertTrue(labels.contains(vehicleLabel),
                "Vehicle label '" + vehicleLabel + "' should be present on Annual Mileage page. Found: " + labels);
    }

    /**
     * Full page interaction: enters the supplied mileage values for all vehicles and clicks Continue.
     * <p>
     * Because the number of vehicles on the page is not always known ahead of time, the last
     * supplied value is reused for every vehicle beyond the provided list.  To apply the same
     * value to every vehicle simply pass a single argument, e.g.:
     * <pre>
     *   fillAnnualMileageAndContinue("12000");          // same value for all vehicles
     *   fillAnnualMileageAndContinue("10000", "15000"); // per-vehicle, last recycled if more exist
     * </pre>
     *
     * @param mileageValues one or more mileage strings; the last value is recycled for any
     *                      additional vehicles found on the page at runtime
     */
    public void fillAnnualMileageAndContinue(String... mileageValues) {
        enterAnnualMileageForAllVehicles(mileageValues);
        clickContinue();
    }

}
