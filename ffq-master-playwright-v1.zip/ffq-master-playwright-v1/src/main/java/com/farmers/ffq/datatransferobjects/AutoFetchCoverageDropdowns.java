package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class AutoFetchCoverageDropdowns {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Array {
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class DropDownValue {

            @JsonProperty("webDesc")
            public String webDesc;
            @JsonProperty("value")
            public String value;

        }

        @JsonProperty("type")
        public String type;
        @JsonProperty("coverageCode")
        public String coverageCode;
        @JsonProperty("dropDownValues")
        public List<DropDownValue> dropDownValues;
    }

    @JsonProperty("ArrayList")
    public List<Array> arrayList;

}
