package com.farmers.ffq.ace.renters;

import com.farmers.ffq.ace.hrc.common.AceHRCPropertyTypeBasePage;
import com.farmers.ffq.utils.FarmersSoftAssert;

import java.util.Arrays;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersPropertyTypePage extends AceHRCPropertyTypeBasePage {

    private static final List<String> PROPERTY_TYPES = Arrays.asList(HOME, APARTMENT_CONDO, DUPLEX_TRIPLEX, OTHER);

    private static final List<String> PROPERTY_TYPE_DESCRIPTIONS = Arrays.asList("Single-family home that you rent.",
            "Multi-unit building in which you rent an individual unit.",
            "A house which has been split into separate units for different families or groups of people.",
            "Any other home type that does not fit in the above categories.");

    /**
     * Default Constructor
     */
    public AceRentersPropertyTypePage() throws Exception {
        super();
    }

    public void validatePageCards(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getPropertyTypeCards(), PROPERTY_TYPES, "Renters Property Type page - Expected Property Type Cards are displayed.");
        fsa.assertEquals(getPropertyTypeCardImageAltDescriptions(), PROPERTY_TYPES, "Renters Property Type page - Property Type Card Image Alt attributes match.");
        fsa.assertEquals(getPropertyTypeCardDescriptions(), PROPERTY_TYPE_DESCRIPTIONS, "Renters Property Type page - Expected Property Type Card Descriptions are displayed.");
    }

}
