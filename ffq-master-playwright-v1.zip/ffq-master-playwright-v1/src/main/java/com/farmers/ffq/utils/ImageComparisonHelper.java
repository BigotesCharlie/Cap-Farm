package com.farmers.ffq.utils;

import com.farmers.framework.playwright.compat.PWElement;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.framework.report.Log;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import static com.farmers.ffq.utils.GlobalVariables.*;
import static com.farmers.framework.AutomationFramework.driver;

/** Playwright-native screenshot and pixel-comparison helper. */
public class ImageComparisonHelper {
    public void takeAndSaveWholePageScreenShot(Class<? extends BasePage> page, String lob) throws Exception {
        BufferedImage image = takeWholePageScreenShot();
        File out = new File(getImageLocation(page.getSimpleName(), lob));
        if (out.getParentFile() != null) out.getParentFile().mkdirs();
        ImageIO.write(image, "png", out);
    }
    public void takeAndSaveWebElementScreenShot(PWElement element, String lob, String imageName) throws Exception {
        BufferedImage image = takeWebElementScreenShot(element);
        File out = new File(getImageLocation(imageName, lob));
        if (out.getParentFile() != null) out.getParentFile().mkdirs();
        ImageIO.write(image, "png", out);
    }
    public BufferedImage takeWholePageScreenShot() throws Exception { return decode(driver().screenshot()); }
    public BufferedImage takeWebElementScreenShot(PWElement element) throws Exception { return decode(element.screenshot()); }
    private BufferedImage decode(byte[] png) throws IOException { return ImageIO.read(new ByteArrayInputStream(png)); }

    public boolean compareImages(BufferedImage expected, BufferedImage actual, String expectedImageName) throws IOException {
        if (expected == null || actual == null) return false;
        int width = Math.max(expected.getWidth(), actual.getWidth());
        int height = Math.max(expected.getHeight(), actual.getHeight());
        BufferedImage marked = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        boolean different = expected.getWidth()!=actual.getWidth() || expected.getHeight()!=actual.getHeight();
        for (int y=0;y<height;y++) for(int x=0;x<width;x++) {
            int e = x<expected.getWidth()&&y<expected.getHeight()?expected.getRGB(x,y):0;
            int a = x<actual.getWidth()&&y<actual.getHeight()?actual.getRGB(x,y):0;
            if (e!=a) { different=true; marked.setRGB(x,y,0xFFFF0000); }
            else marked.setRGB(x,y,a);
        }
        if (different) {
            File out = new File("src/test/resources/screenshots/auto/difference/" + expectedImageName + ".png");
            if (out.getParentFile()!=null) out.getParentFile().mkdirs();
            ImageIO.write(marked,"png",out);
            Log.error(expectedImageName + " image differs from actual image");
        } else Log.info(expectedImageName + " image matches actual image");
        return !different;
    }
    public BufferedImage getExpectedImage(String image,String lob)throws IOException{return ImageIO.read(new File(getImageLocation(image,lob)));}
    public BufferedImage getExpectedWholePageImage(Class<? extends BasePage> page,String lob)throws IOException{return ImageIO.read(new File(getImageLocation(page.getSimpleName(),lob)));}
    private String getImageLocation(String image,String lob){
        if(AUTO.equals(lob))return "src/test/resources/screenshots/auto/"+image+".png";
        if(HOME.equals(lob))return "src/test/resources/screenshots/home/"+image+".png";
        if(CONDO.equals(lob))return "src/test/resources/screenshots/condo/"+image+".png";
        if(RENTERS.equals(lob))return "src/test/resources/screenshots/renters/"+image+".png";
        if(LIFE.equals(lob))return "src/test/resources/screenshots/life/"+image+".png";
        return "src/test/resources/screenshots/"+image+".png";
    }
}
