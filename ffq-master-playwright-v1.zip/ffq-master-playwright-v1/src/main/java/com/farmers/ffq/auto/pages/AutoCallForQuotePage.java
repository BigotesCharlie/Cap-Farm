package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AutoCallForQuotePage extends AutoBasePage {


    @PWFindAll({
            @PWFindBy(xpath = "//span[@class='h1-alt1']"),
            @PWFindBy(xpath = "//span[@class='h1-alt2']"),
            @PWFindBy(css = "h1[id='main-content1']")
    })
    private PWElement callForAQuotePageTitle;
    @PWFindBy(xpath = "//span[contains(.,'get started')]")
    private PWElement letsGetStartedText;
    @PWFindAll({
            @PWFindBy(css = "span[class='p-style']"),
            @PWFindBy(xpath = "//div[@class='productgrid__heading rich-text']//p"),
            @PWFindBy(css = "p[class='pb-3']")
    })
    private PWElement pageDescription;
    @PWFindBy(xpath = "//a[@data-gtm='Check_ call_colp' and contains(@class,'mobile mobile button-cta')]")
    private PWElement mobileCallNowButton;
    @PWFindBy(xpath = "//a[@data-gtm='Check_ call_colp' and contains(@class,'desktop desktop button-cta')]")
    private PWElement desktopCallNowButton;
    @PWFindBy(xpath = "//span[@class='font-blue']//span[@class='h4-alt1']")
    private PWElement quickAndEasy;
    @PWFindBy(xpath = "//img[contains(@src,'auto-landing')]")
    private PWElement farmersImage;
    @PWFindBy(xpath = "//div[contains(@class,'tile tile--one-col col-12 mt-3 mb-1')]//img")
    private List<PWElement> tileSectionImages;
    @PWFindBy(xpath = "//div[contains(@class,'tile tile--one-col col-12 mt-3 mb-1')]//section")
    private List<PWElement> tileSectionTexts;
    @PWFindBy(xpath = "//p[contains(.,'NOTE')]")
    private PWElement noteSectionText;
    @PWFindBy(xpath = "//span[contains(.,'*')]")
    private PWElement savingPercentageNote;
    @PWFindBy(xpath = "//div[@class='footernav__notes-section row pt-3 pb-5']")
    private PWElement disclaimers;

    public AutoCallForQuotePage() throws Exception {
    }

    public boolean isOnCallForQuotePage() {
        return isElementVisible(callForAQuotePageTitle, 10);
    }

    public void validateCallForAQuotePage(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(callForAQuotePageTitle)), "Call for your quote", "FWS page title validated");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageDescription)), "Let's get started! If you'd like to continue your quote and see how much you could save, please give us a call.", "Page description text validated");
        fsa.assertTrue(getTextFromElement(isUseMobileViewEnabled() ? mobileCallNowButton : desktopCallNowButton).contains("Call Now"), "Call now button text validated");
    }
}
