package com.farmers.ffq.hqm.pages;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import java.util.List;
import java.util.stream.Collectors;

public class FarmersInsuranceAgencyPage extends HqmBasePage {

    @PWFindBy(xpath = "//header//div[contains(@class,'call-in')]")
    private PWElement speakWithAgent;

    @PWFindBy(xpath = "//header//div[contains(@class,'logo')]/a[contains(@class,'partner-logo')]")
    private PWElement farmersLogo;

    private static final String CITY_STATE_ZIP_XPATH = "//section//input[@name='address_city']/../p[@class='address']";
    @PWFindBy(xpath = CITY_STATE_ZIP_XPATH)
    private PWElement cityStateZip;

    private static final String MULTI_CITY_STATE_ZIP_XPATH = "//section//p[@class='multi-city-address']";
    @PWFindBy(xpath = MULTI_CITY_STATE_ZIP_XPATH)
    private PWElement multiCityStateZip;

    private static final String CITY_SELECT_XPATH = "//section//select[@id='address_city']";
    @PWFindBy(xpath = CITY_SELECT_XPATH)
    private PWElement citySelect;


    /**
     * Constructor.
     *
     * @throws Exception
     */
    public FarmersInsuranceAgencyPage() throws Exception {
        super();
        wait.until(PWExpectedConditions.urlContains("farmersgeneralinsuranceagency.com/quote?zipcode="));
    }

    public String getCityStateZip() throws Exception {
        String stateZip = "";
        if (isElementDisplayed(PWBy.xpath(CITY_STATE_ZIP_XPATH))) {
            stateZip = getTextFromElement(cityStateZip).stripLeading().stripTrailing();
        } else if (isElementDisplayed(PWBy.xpath(CITY_SELECT_XPATH))) {
            stateZip = getTextFromElement(multiCityStateZip).stripLeading().stripTrailing();
        }
        return stateZip;
    }

    public boolean isCitySelectDisplayed() throws Exception {
        return isElementDisplayed(PWBy.xpath(CITY_SELECT_XPATH));
    }

    public List<String> getCitySelectOptions () {
        PWSelect selCity = new PWSelect(citySelect);
        return selCity.getOptions().stream().map(this::getTextFromElement)
                .map(String::toUpperCase).collect(Collectors.toList());
    }

}
