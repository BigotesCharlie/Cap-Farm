package com.farmers.ffq.datatransferobjects;

import com.farmers.ffq.dataproviderframework.DataObjectBase;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ApplicantRenters extends DataObjectBase {

    private String lob;
    private String scenario;
    private String firstName;
    private String lastName;
    private int age;
    private String maritalStatus;
    private String gender;
    private String spouseFirstName;
    private String spouseLastName;
    private int spouseAge;
    private String spouseGender;
    private String addressApt;
    private String city;
    private String stateCode;
    private String state;
    private String zipCode;
    /*Rental Info*/
    private String propertyType;
    private String numberOfUnits;
    private String roommates;
    private String firstRoommateName;
    private String firstRoommateLastName;
    private String secondRoommateName;
    private String secondRoommateLastName;
    private String numberOfPropertyLosses;
    /*Property Variables*/
    private boolean fireSprinklerPresent; 
    private boolean centralFireBurglarAlarmService;
    private boolean localFireSmokeAlarmPresent;
    private boolean homeSecurityPresent;
    private boolean nonSmokingOccupants;
    private boolean localBurglarAlarmPresent;
    private String hazards;
    private boolean dogHasBittenOnProperty;
    private String dogBreed;
    private boolean businessFromHome;
    private String policyStartDate;
    private int personalPropertyWorth;
    private String phoneNumber;
    private String emailAddress;
    /* Multiple Policies*/
    private boolean hasAutoPolicy;
    private String autoPolicyNumber;
    private boolean crossSellAutoInsurance;
    private boolean crossSellLifeInsurance;
    /* Payment Variables */
    private String paymentPlan;
    private String bankAccountType;
    private String accountHolderName;
    private String routingNumber;
    private String bankAccountNumber;
    private String confirmBankNumber;
    private String bankName;
    private String chargeType;
    private String cardType;
    private String nameOnCard;
    private String cardNumber;
    private String cardMonth;
    private String cardYear;
    private String billingZipCode;
    private String paymentMethod;
    
	private boolean saveAndRetrievePropertyPage;
	private boolean saveAndRetrieveQuotePage;
	private boolean saveAndRetrieveCompletedQuote;
    private ApplicantRetQuote applicantRetQuote;

    /*String representation of ApplicantRenters class */
    public String toString() {
        return String.format("#%s: %s %s %s %s %s %s", getId(), firstName, lastName, addressApt, city, state, zipCode);
    }
}
