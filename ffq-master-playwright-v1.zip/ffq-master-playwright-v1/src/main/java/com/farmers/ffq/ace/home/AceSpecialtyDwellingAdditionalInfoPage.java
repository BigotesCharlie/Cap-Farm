package com.farmers.ffq.ace.home;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.ffq.utils.GlobalVariables.DROPDOWN_OPTIONS_XPATH;
import static com.farmers.ffq.utils.GlobalVariables.RENT;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.farmers.ffq.ace.hrc.common.AceHRCAdditionalInfoBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;

public class AceSpecialtyDwellingAdditionalInfoPage extends AceHRCAdditionalInfoBasePage {

    @PWFindBy (xpath = MAT_CHECKBOX_XPATH)
    private List<PWElement> listOfCheckboxes;

    @PWFindBy (id = "doAnyApplyHeading")
    private PWElement anyApplySectionHeader;

    @PWFindBy (xpath = "//*[@id='brickConstruction']//input")
    private PWElement constructedOfBrickCheckbox;

    @PWFindBy (xpath = "//*[@id='openFoundation']//input")
    private PWElement openFoundationCheckbox;

    @PWFindBy (xpath = "//*[@id='woodBurningDeviceOtherThanFireplace']//input")
    private PWElement woodburningDeviceCheckbox;

    @PWFindBy (xpath = "//*[@id='woodBurnerInOutbuilding']//input")
    private PWElement woodburnerOutbuildingCheckbox;

    @PWFindBy (xpath = "//*[@id='trampolineOnPremises']//input")
    private PWElement trampolineCheckbox;

    @PWFindBy (xpath = "//*[@id='businessActivityOnPremises']//input")
    private PWElement businessOnPremisesCheckbox;

    @PWFindBy (xpath = "//*[@id='rentedToStudents']//input")
    private PWElement rentedTostudentsCheckbox;

    @PWFindBy (id = "safetyDevices")
    private PWElement safetyDevicesSectionHeader;

    @PWFindBy (xpath = "//*[@id='deadboltLocksOnExteriorDoors']//input")
    private PWElement deadboltsCheckbox;

    @PWFindBy (xpath = "//*[@id='burglarAlarm']//input")
    private PWElement burglarAlarmCheckbox;

    @PWFindBy (xpath = "//*[@id='smokeDetector']//input")
    private PWElement smokeDetectorsCheckbox;

    @PWFindBy (xpath = "//*[@id='centralFireAlarm']//input")
    private PWElement centralFireAlarmCheckbox;

    @PWFindBy (xpath = "//div[contains(@class, 'dwelling-smoke-detector-popup-buttons')]")
    private PWElement smokeDetectorConfirmationDialog;

    @PWFindBy (id = "sameButton")
    private PWElement yesHomeHasSmokeDetectorsButton;

    @PWFindBy (id = "differentButton")
    private PWElement noHomeDoesNotHaveSmokeDetectorsButton;

    public AceSpecialtyDwellingAdditionalInfoPage() throws Exception {
		super();
	}

    public void fillOutSpecialtyDwellingAdditionalInfoPage(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
    	fillOutRoofInfo(specialtyDwellingApplicant);
    	selectValueInDropDown(roofMaterialDropdown, specialtyDwellingApplicant.getRoofCover());
    	setCheckbox(constructedOfBrickCheckbox, specialtyDwellingApplicant.isBrickConstruction());
    	setCheckbox(openFoundationCheckbox, specialtyDwellingApplicant.isOpenFoundation());
    	setCheckbox(woodburningDeviceCheckbox, specialtyDwellingApplicant.isWoodburningDevice());
    	setCheckbox(woodburnerOutbuildingCheckbox, specialtyDwellingApplicant.isWoodburnerOutbuilding());
    	setCheckbox(trampolineCheckbox, !specialtyDwellingApplicant.getTrampoline().isBlank());
    	setCheckbox(businessOnPremisesCheckbox, specialtyDwellingApplicant.isBusinessOperatedOnPremises());
    	setCheckbox(rentedTostudentsCheckbox, specialtyDwellingApplicant.isRentedToStudents());
    	setCheckbox(deadboltsCheckbox, specialtyDwellingApplicant.isDeadbolts());
    	setCheckbox(burglarAlarmCheckbox, specialtyDwellingApplicant.isCentralBurglarAlarm());
    	setCheckbox(smokeDetectorsCheckbox, !specialtyDwellingApplicant.getSmokeAlarm().isBlank());
    	setCheckbox(centralFireAlarmCheckbox, specialtyDwellingApplicant.isCentralFireAlarm());
    	sleep(3); //let gui catch up with the checkbox selections before clicking continue
    	scrollAndClickOnContinueButton();
    	if (isElementDisplayed(smokeDetectorConfirmationDialog, 2)) {
    		clickElement(specialtyDwellingApplicant.getSmokeAlarm().isBlank()? noHomeDoesNotHaveSmokeDetectorsButton: yesHomeHasSmokeDetectorsButton);
    		waitForSpinnerToBeGone();
    	}
    }

    private void setCheckbox(PWElement checkbox, boolean checkboxShouldBeSelected) {
    	if (((checkboxShouldBeSelected && isCheckboxNotSelected(checkbox)) ||
    		 (!checkboxShouldBeSelected && isCheckboxSelected(checkbox)))) {
    		scrollAndClickOnElement(checkbox);
    	}
    }

	public void verifySpecialtyDwellingAdditionalInformationPageContent(FarmersSoftAssert fsa, ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		String testCategory = specialtyDwellingApplicant.getTestCategory();
		String activeStep = getActiveStep(testCategory);
		verifySpecialtyDwellingCommonHeader(fsa);
		validateTheHeaderOfAdditionalInfoPage(fsa);
		validateRoofSection(fsa, specialtyDwellingApplicant.getReasonWhyNotPrimaryResidence().equals(RENT));
		validatePageLinksText(fsa, activeStep);
		validatePageLinksNavigationTitles(fsa);
		validateAgentSectionContent(fsa, false, testCategory);
	}

	private void validateRoofSection(FarmersSoftAssert fsa, boolean isRentalProperty) throws Exception {
        fsa.assertEquals(getTextFromElement(roofCompletelyReplacedQuestion), "Roof", "Roof section header.");
        fsa.assertEquals(getTextFromElement(roofCompletelyReplacedQuestionAlternate), "Has the roof been completely replaced since the house was built?",
                "Roof completely replaced question verification.");
        fsa.assertEquals(getNumberOfRoofReplacedToggleButtons(), 2, "Yes and No roof replaced toggle buttons displayed.");
        clickOnYesToggleButtonForRoofYearSection();
        fsa.assertEquals(getTextFromElement(whenWasTheLastTimeRoofWasReplacedQuestion), "When was it last replaced?", "Last time replaced label text verification.");
        fsa.assertTrue(roofYearInputField.isDisplayed(), "Roof year input box displayed.");
        fsa.assertEquals(getTextFromElement(yearPlaceHolderText), "Year", "Year place holder text verification.");
        sendKeysToElement(roofYearInputField, LocalDate.now().getYear());
        clickOnNoToggleButtonForRoofYearSection();
        fsa.assertEquals(getTextFromElement(roofMaterialSectionLabel), "What is the roof material?", "Roof material section label");
		clickElement(roofMaterialDropdown);
		List<PWElement> listOfDropdownOptionElements = driver().findElements(PWBy.xpath(DROPDOWN_OPTIONS_XPATH));
		List<String> listOfDropdownOptions = listOfDropdownOptionElements.stream().map(this::getTextFromElement).collect(Collectors.toList());
		List<String> listOfRoofMaterials = List.of("Asphalt shingle", "Metal", "Slate", "Tile", "Wood shake", "Wood shingle", "Other");
		fsa.assertEquals(listOfDropdownOptions, listOfRoofMaterials, "Roof materials dropdown content");
		clickElement(roofMaterialDropdown);
		List<String> listOfCheckboxLabels = new ArrayList<>(Arrays.asList("It is constructed of brick.", "It has an open foundation.", "There is a wood-burning device (other than a fireplace).",
				"There is a wood-burner in an outbuilding.", "There is a trampoline on the premises.", "There is a business activity on the premises.", "It is rented to students.",
				"Deadbolt locks on exterior doors", "Burglar alarm", "Smoke detectors", "Central fire alarm"));
		if (!isRentalProperty ) {
			listOfCheckboxLabels.remove("It is rented to students.");
		}
		fsa.assertEquals(getTextFromElement(anyApplySectionHeader), "Do any of the following apply to your home?", "Applicable to dwelling section header verification");
		fsa.assertEquals(getTextFromElement(safetyDevicesSectionHeader), "Safety devices", "Safety devices section header verification");
		fsa.assertEquals(getTextFromListOfWebElementsAndDescendents(listOfCheckboxes), listOfCheckboxLabels, "Checkbox label verification");
		fsa.assertEquals(getTextFromElement(buttonContinue), "Continue", "CTA button label verification");
	}
}
