package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.framework.report.Log;

public class SaveAndFinishLaterPopup extends AutoBasePage {
	
	@PWFindBy(id = "FFQAuto_Modal_saveFinishForm")
	private PWElement saveAndFinishLaterForm;
	
	@PWFindBy(id = "FFQAuto_Modal_saveFinishHeader")
	private PWElement saveAndFinishLaterFormHeader;
		
	@PWFindBy(id = "FFQAuto_Modal_saveFinishEmailAddress")
	private PWElement emailTextbox;
	
	@PWFindBy(id = "FFQAuto_Modal_saveFinishOk")
	private PWElement saveAndExitButton;
	
	@PWFindBy(id = "FFQAuto_Modal_saveFinishClose")
	private PWElement continueWithQuoteButton;
	
	/**
	 * Constructor.
	 * 
	 * @throws Exception
	 */
	public SaveAndFinishLaterPopup() throws Exception {
		super();		
	}
	
	public void enterEmailId() {
		Log.info("Entering EmailId for Retrieving the quote.");
		waitElementBeVisible(emailTextbox);		
	}
	
	public void saveAndExit() {
		Log.info("Selecting SaveAndExit button.");
		waitElementBeVisibleClickable(saveAndExitButton);
		clickElement(saveAndExitButton);
	}
	
	public void continueWithTheQuote() {
		Log.info("Selecting ContinueWithTheQuote button.");
		waitElementBeVisibleClickable(continueWithQuoteButton);
		clickElement(continueWithQuoteButton);
	}
}
