package com.farmers.ffq.datatransferobjects;
import lombok.Data;

@Data

public class SqlAdditionalDriver {
	private int additionalDriverId;
	private int applicantId;
	private int incidentId;
	private String firstName;
	private String lastName;
	private int age;
	private String dateOfBirth;
	private String relationshipToApplicant;
	private String maritalStatus;
	private String gender;
	private String occupation;
	private String otherOccupation;
	private String licenseToDriveInUSA;
	private int firstAgeUnitedStatesDriverLicense;
	private int firstAgeForeignDriverLicense;
	private boolean fullTimeStudentWithHighGPA;
	private boolean attendsDistantSchool;
	private boolean completedDriversSafetyCourse;
	private String financialFiling;
	private boolean anyIncident;
	private String driversLicense;
	private String licenseIssueStateName;
	private boolean mediaAlphaCurrentlyInsured;
	private String signalMobilePhone;
}
