package com.farmers.ffq.ace.business;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.auto.pages.ThankYouPageAce;
import com.farmers.ffq.datatransferobjects.ApplicantBusiness;
import com.farmers.ffq.utils.FarmersSoftAssert;

public class AceBusinessThankYouPage extends ThankYouPageAce {

	@PWFindBy(xpath = "//div[contains(@class, 'thank-you__quote-number')]/span[1]")
	private PWElement quoteNumberLabel;

	@PWFindBy(xpath = "//div[contains(@class, 'leadForm__toll-free-section')]")
	private PWElement needMoreHelpSection;

	public AceBusinessThankYouPage() throws Exception {
		super();
	}

	public void verifyPageContent(FarmersSoftAssert fsa, ApplicantBusiness businessApplicant, String expectedLeadNumber) throws Exception {
		fsa.assertEquals(getThankYouPageTitle(), "Thank you for choosing Farmers Insurance\u00ae", "Thank you page title");
		fsa.assertEquals(getThankYouPageSubtitle(), "We'll have someone review your request. You may also contact the number provided below. " +
				"Until then, take a look at our range of products and remember you can save more when you bundle.", "Thank you page subtitle");
		fsa.assertEquals(getTextFromElement(quoteNumberLabel), "Quote number", "Quote number label");
		fsa.assertEquals(getThankYouPageQuoteNumber(), expectedLeadNumber, "Quote number shown");
		if (isElementVisible(needMoreHelpSection, 3)) {
			fsa.assertEquals(getTextFromElement(needMoreHelpSection), "Need more help? You can call customer service at 1-888-422-1618", "Need more help section verification");
		}
	}
}
