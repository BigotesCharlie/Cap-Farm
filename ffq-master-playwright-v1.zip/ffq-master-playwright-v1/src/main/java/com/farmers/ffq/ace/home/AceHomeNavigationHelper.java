package com.farmers.ffq.ace.home;

import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.auto.pages.WhoShouldWeInsurePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeNavigationHelper extends AceHRCNavigationHelperBasePage {

    public AceHomeNavigationHelper() throws Exception {
        super();
    }

    public AceHRCNameAndDobBasePage navigateToAceHomeNameAndDobPage(ApplicantAceHome applicant) throws Exception {
        return navigateToAceHRCNameAndDobBasePage(applicant, LOB_HOME);
    }

    public AceHRCPropertyTypeBasePage navigateToAceHomePropertyTypePage(ApplicantAceHome applicant) throws Exception {
        return navigateToHRCPropertyTypePage(applicant, LOB_HOME);
    }

    public AceHRCPropertyInfoBasePage navigateToAceHomePropertyInfoPage(ApplicantAceHome applicant) throws Exception {
        return navigateToAceHRCPropertyInfoBasePage(applicant, LOB_HOME, HOME);
    }

    public AceHRCAddressContactBasePage navigateToAceHomeAddressContactBasePage(ApplicantAceHome applicant) throws Exception {
        return navigateToAceHRCAddressContactBasePage(applicant, LOB_HOME);
    }

    public AceHRCAddressBasePage navigateToAceHomeAddressPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        return navigateToHRCAddressPage(applicant, lob, propertyType);
    }

    public AceHRCPropertyDetailsBasePage navigateToAceHomePropertyDetailsPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        return  navigateToHRCPropertyDetailsPage(applicant, lob, propertyType);
    }

    public AceHRCAdditionalInfoBasePage navigateToAceHomeAdditionalInfoPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        return navigateToHRCAdditionalInfoPage(applicant, lob, propertyType);
    }

    public AceHRCAboutYouBasePage navigateToAceHomeAboutYouPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        return navigateToHRCAboutYouPage(applicant, lob, propertyType);
    }

    public AceHRCContactInfoBasePage navigateToAceHomeContactInfoPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        return navigateToAceHRCContactInfoPage(applicant, lob, propertyType);
    }

/*
    public AceHomeContactInfoPage navigateToAceHomeContactInfoPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        AceHomeContactInfoPage contactInfoPage = new AceHomeContactInfoPage();
        if (getResumeFromPage().equals(CONTACT_INFO)) {
            return contactInfoPage;
        }
        if (!isNewFlowEnabledState(applicant.getStateCode())) {
            AceHRCAboutYouBasePage aboutYouPage = navigateToAceHomeAboutYouPage(applicant, lob, propertyType);
            aboutYouPage.fillOutTheDataInAboutYouPage(applicant, true);
            waitForSpinnerToBeGone();
        }
        if (contactInfoPage.isOnContactInfoPage(true)) {
            if (isADATestingEnabled()) {
                contactInfoPage.validateADA(FFQ_ACE_HOME);
            }
            Reporter.pass("Navigated to AceHomeContactInfoPage");
            return contactInfoPage;
        } else {
            int retries = 3;
            while (isTryAgainPagePresent() && wasTryAgainSuccessful() && retries>0) {
                if (applicant.isNewlyOwned()) {
                    enterCurrentOrPriorAddress(applicant);
                }
                retries--;
                clickContinueButton();
            }
            if (contactInfoPage.isOnContactInfoPage(false)) {
                Reporter.pass("Navigated to AceHomeContactInfoPage");
                return contactInfoPage;
            }
            reportKnockout();
            throw new IllegalStateException(DID_NOT_REACH + "ContactInfoPage");
        }
    }

 */

    public AceHRCDwellingCoverageBasePage navigateToAceHomeDwellingCoveragePage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceHRCDwellingCoverageBasePage();
        if (getResumeFromPage().equals(DWELLING_COVERAGE)) {
            return dwellingCoveragePage;
        }
        AceHRCContactInfoBasePage contactInfoPage = navigateToAceHRCContactInfoPage(applicant, lob, propertyType);
        contactInfoPage.fillOutContactInfoPage(applicant, HOME);
        if (dwellingCoveragePage.isOnDwellingCoveragePage()) {
            if (isADATestingEnabled()) {
                dwellingCoveragePage.validateADA();
            }
            Reporter.pass("Navigated to AceHomeDwellingCoveragePage");
            return dwellingCoveragePage;
        } else {
            reportKnockout();
            throw new IllegalStateException(DID_NOT_REACH + "DwellingCoveragePage");
        }
    }

    public AceHomeReviewQuotePage navigateToAceHomeReviewQuotePage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeReviewQuotePage();
        if (List.of(FAILED_RC2, FAILED_RC3, REVIEW_QUOTE).contains(getResumeFromPage())) {
            if(reviewQuotePage.isBundleDiscountStateV1(applicant.getStateCode())) {
                reviewQuotePage.clickContinueWithHomeOnly();
            }
            return reviewQuotePage;
        }
        AceHRCDwellingCoverageBasePage dwellingCoveragePage = navigateToAceHomeDwellingCoveragePage(applicant, lob, propertyType);
        dwellingCoveragePage.fillOutDwellingCoveragePage(applicant);
        return goToAceHomeReviewQuotePage(applicant);
    }

    public AceHomeReviewQuotePage goToAceHomeReviewQuotePage(ApplicantAceHome applicant) throws Exception {
        waitForSpinnerToBeGone();
        waitForSkeletonToBeGone();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeReviewQuotePage();
        if (reviewQuotePage.isOnReviewQuotePageHome(true)) {
            if (reviewQuotePage.isBundleDiscountStateV1(applicant.getStateCode())) {
                reviewQuotePage.clickContinueWithHomeOnly();
            }
            Reporter.pass("Navigated to AceHomeReviewQuotePage");
            logReviewQuotePage(applicant, reviewQuotePage);
            return reviewQuotePage;
        } else {
            if (isTryAgainPagePresent() && !wasTryAgainSuccessful()) {
                throw new IllegalStateException("ReviewQuotePage: " + TRY_AGAIN_ATTEMPTS_LIMIT_EXCEEDED);
            } else {
                if (reviewQuotePage.isOnReviewQuotePageHome(false)) {
                    Reporter.pass("Navigated to AceHomeReviewQuotePage");
                    return reviewQuotePage;
                }
                reportKnockout();
                throw new IllegalStateException(DID_NOT_REACH + "ReviewQuotePage");
            }
        }
    }

    private void logReviewQuotePage(ApplicantAceHome applicant, AceHomeReviewQuotePage reviewQuotePage) throws Exception {
        String quoteNumber = applicant.getQuoteNumber();
        Log.info("Ace Home - Review Quote page. Quote number: " + quoteNumber + ". Number of packages: " + reviewQuotePage.getNumberOfPackageTabs(), true);
        logQuoteNumber(applicant, HOME, quoteNumber);
        if (isADATestingEnabled()){
            reviewQuotePage.validateADA();
        }
    }

    public AceHRCAdditionalCoveragesBasePage navigateToAceHomeAdditionalCoveragesPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        AceHRCAdditionalCoveragesBasePage additionalCoveragesPage = new AceHRCAdditionalCoveragesBasePage();
        if (getResumeFromPage().equals(ADDITIONAL_COVERAGES)) {
            return additionalCoveragesPage;
        }
        AceHomeReviewQuotePage reviewQuotePage = navigateToAceHomeReviewQuotePage(applicant, lob, propertyType);
        if (!reviewQuotePage.clickContinueWithHomeOnly()) {
            reviewQuotePage = goToAceHomeReviewQuotePage(applicant);
            reviewQuotePage.clickOnContinueButton();
        }
        if (reviewQuotePage.isOnReviewQuotePageHome(false)) {
            reviewQuotePage.clickOnContinueButton();
        }
        if (additionalCoveragesPage.isOnAdditionalCoveragesPage()) {
            if (isADATestingEnabled()){
                additionalCoveragesPage.validateADA(applicant, false);
            }
            Reporter.pass("Navigated to AceHomeAdditionalCoveragesPage");
            return additionalCoveragesPage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + "AdditionalCoveragesPage");
        }
    }

    public AceHRCJustAFewMoreThingsBasePage navigateToAceHomeJustAFewMoreThingsPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jFMTPage = new AceHRCJustAFewMoreThingsBasePage();
        if (getResumeFromPage().equals(JFMT_PAGE)) {
            return jFMTPage;
        }
        AceHRCAdditionalCoveragesBasePage additionalCoveragesPage = navigateToAceHomeAdditionalCoveragesPage(applicant, lob, propertyType);
        if (additionalCoveragesPage.isContinueButtonPresent()) {
            additionalCoveragesPage.clickOnContinueButton();
            waitForSpinnerToBeGone();
            if (jFMTPage.isOnJFMTPage(true)) {
                Reporter.pass("Navigated to AceHomeJustAFewMoreThingsPage");
                return jFMTPage;
            } else {
                throw new IllegalStateException(DID_NOT_REACH + "AceHomeJustAFewMoreThingsPage - " + getTextFromElement(quoteNumber));
            }
        } else {
            throw new IllegalStateException("Quote is not bind-able, cannot reach AceHomeJustAFewMoreThingsPage");
        }
    }

    public AceHRCThankYouBasePage navigateToAceHomeThankYouPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        AceHRCThankYouBasePage aceHomeThankYouPage = new AceHRCThankYouBasePage();
        if (getResumeFromPage().equals(THANK_YOU_PAGE)) {
            return aceHomeThankYouPage;
        }
        AceHRCAdditionalCoveragesBasePage additionalCoveragesPage = navigateToAceHomeAdditionalCoveragesPage(applicant, lob, propertyType);
        additionalCoveragesPage.clickOnContinueButton();
        if (aceHomeThankYouPage.isOnThankYouPage()) {
            Reporter.pass("Navigated to AceHomeThankYouPage");
            return aceHomeThankYouPage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + "AceHomeThankYouPage");
        }
    }

    public AceHRCPaymentSelectionPage navigateToAceHomePaymentSelectionPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
        if (getResumeFromPage().equals(SELECT_PAYMENT)) {
            return aceHRCPaymentSelectionPage;
        }
        AceHRCJustAFewMoreThingsBasePage jFMTPage = navigateToAceHomeJustAFewMoreThingsPage(applicant, lob, propertyType);
        waitForSpinnerToBeGone();
        if (!List.of(FAILED_RC2, FAILED_RC3).contains(getResumeFromPage())) {
            jFMTPage.fillOutJustFewMoreThingsPage(applicant, true);
        } else {
            jFMTPage.fillFortifiedHomeSection(applicant);
            jFMTPage.clickContinueButton();
        }
        if (aceHRCPaymentSelectionPage.isOnPaymentPage()) {
            Reporter.pass("Navigated to AceHomePaymentPage");
            Log.info("Ace Home - Payment page. Quote number: " + applicant.getQuoteNumber(), true);
            aceHRCPaymentSelectionPage.addSauceLabsLinkInLog();
            return aceHRCPaymentSelectionPage;
        } else {
            if (isTryAgainPagePresent()) {
                boolean success = wasTryAgainSuccessful();
                if (success && aceHRCPaymentSelectionPage.isOnPaymentPage()) {
                    Reporter.pass("Navigated to AceHomePaymentPage");
                    Log.info("Ace Home - Payment page. Quote number: " + applicant.getQuoteNumber(), true);
                    return aceHRCPaymentSelectionPage;
                } else {
                    throw new IllegalStateException(TRY_AGAIN_ATTEMPTS_LIMIT_EXCEEDED + " but " + DID_NOT_REACH + "Ace Home Payment Page");
                }
            } else {
                if (!getResumeFromPage().equals(FAILED_RC2)) {
                    Log.info(DID_NOT_REACH + "Ace Home - Payment Selection page. Quote number: " + applicant.getQuoteNumber());
                    retrieveQuoteByQuoteNumber(applicant);
                    setResumeFromPage(FAILED_RC2);
                    aceHRCPaymentSelectionPage = navigateToAceHomePaymentSelectionPage(applicant, LOB_HOME, HOME);
                    if (aceHRCPaymentSelectionPage.isOnPaymentPage()) {
                        return aceHRCPaymentSelectionPage;
                    }
                }
                throw new IllegalStateException(DID_NOT_REACH + "Ace Home - Payment Selection Page");
            }
        }
    }

    public AceHRCPaymentBasePage navigateToPayInFullPaymentPageAceHome(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        if (getResumeFromPage().equals(PAYMENT_PAGE)) {
            return aceHRCPaymentBasePage;
        }
        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = navigateToAceHomePaymentSelectionPage(applicant, lob, propertyType);
        aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentPayInFullCard(lob);
        if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage()) {
            Reporter.pass("Navigated to AceHomePayInFullPage");
            Log.info("Ace Home - Pay in full payment page. Quote number: " + applicant.getQuoteNumber(), true);
            return aceHRCPaymentBasePage;
        } else {
            if (!getResumeFromPage().equals(FAILED_RC3)) {
                Log.info(DID_NOT_REACH + "Ace Home - Payment page. Quote number: " + applicant.getQuoteNumber());
                retrieveQuoteByQuoteNumber(applicant);
                setResumeFromPage(FAILED_RC3);
                aceHRCPaymentBasePage = navigateToPayInFullPaymentPageAceHome(applicant, LOB_HOME, HOME);
                if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage()) {
                    Reporter.pass("Navigated to AceHomePayInFullPage");
                    return aceHRCPaymentBasePage;
                }
            }
            throw new IllegalStateException(DID_NOT_REACH + "aceHRCPaymentBasePage PIF");
        }
    }

    public AceHRCPaymentBasePage navigateToMonthlyAutoPayBankPaymentPageAceHome(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        if (getResumeFromPage().equals(PAYMENT_PAGE)) {
            return aceHRCPaymentBasePage;
        }
        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = navigateToAceHomePaymentSelectionPage(applicant, lob, propertyType);
        aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayBank();
        if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage()) {
            Reporter.pass("Navigated to AceHomeMonthlyBankPayPage");
            Log.info("Ace Home - monthly pay bank payment page. Quote number: " + applicant.getQuoteNumber(), true);
            return aceHRCPaymentBasePage;
        } else {
            if (!getResumeFromPage().equals(FAILED_RC3)) {
                Log.info(DID_NOT_REACH + "Ace Home - Payment page. Quote number: " + applicant.getQuoteNumber());
                retrieveQuoteByQuoteNumber(applicant);
                setResumeFromPage(FAILED_RC3);
                aceHRCPaymentBasePage = navigateToMonthlyAutoPayBankPaymentPageAceHome(applicant, LOB_HOME, HOME);
                if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage()) {
                    Reporter.pass("Navigated to AceHomeMonthlyBankPayPage");
                    return aceHRCPaymentBasePage;
                }
            }
            throw new IllegalStateException(DID_NOT_REACH + "aceHRCPaymentBasePage Monthly bank.");
        }
    }

    public AceHRCPaymentBasePage navigateToMonthlyAutoPayCardPaymentPageAceHome(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        if (getResumeFromPage().equals(PAYMENT_PAGE)) {
            return aceHRCPaymentBasePage;
        }
        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = navigateToAceHomePaymentSelectionPage(applicant, lob, propertyType);
        aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayCard();
        if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage()) {
            Reporter.pass("Navigated to AceHomeMonthlyCardPayPage");
            Log.info("Ace Home - monthly pay card payment page. Quote number: " + applicant.getQuoteNumber(), true);
            return aceHRCPaymentBasePage;
        } else {
            if (!getResumeFromPage().equals(FAILED_RC3)) {
                Log.info(DID_NOT_REACH + "Ace Home - Payment page. Quote number: " + applicant.getQuoteNumber());
                retrieveQuoteByQuoteNumber(applicant);
                setResumeFromPage(FAILED_RC3);
                aceHRCPaymentBasePage = navigateToMonthlyAutoPayCardPaymentPageAceHome(applicant, LOB_HOME, HOME);
                if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage()) {
                    Reporter.pass("Navigated to AceHomeMonthlyCardPayPage");
                    return aceHRCPaymentBasePage;
                }
            }
            throw new IllegalStateException(DID_NOT_REACH + "aceHRCPaymentBasePage Monthly card.");
        }
    }

    public void navigateToAceHomeAutoWhoShouldWeInsurePageVariant1(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceHRCDwellingCoverageBasePage();
        if (!getResumeFromPage().equals(DWELLING_COVERAGE)) {
            dwellingCoveragePage = navigateToAceHomeDwellingCoveragePage(applicant, lob, propertyType);
        }
        dwellingCoveragePage.fillOutDwellingCoveragePage(applicant);
        AceHomeReviewQuotePage aceHomeReviewQuotePage = new AceHomeReviewQuotePage();
        waitForSpinnerToBeGone();
        if (aceHomeReviewQuotePage.isOnReviewQuotePageHome(true) &&
                aceHomeReviewQuotePage.isBundleDiscountStateV1(applicant.getStateCode())) {
            aceHomeReviewQuotePage.clickContinueWithBundle();
        }
        waitForSpinnerToBeGone();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        if (whoShouldWeInsurePage.isAddVehiclesDriversButtonPresent()) {
            Reporter.pass("Navigated to WhoShouldWeInsurePage");
        } else {
            throw new IllegalStateException(DID_NOT_REACH + "WhoShouldWeInsurePage");
        }
    }

    public void navigateToAceHomeAutoWhoShouldWeInsurePageVariant2(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
        AceHomeReviewQuotePage aceHomeReviewQuotePage = new AceHomeReviewQuotePage();
        if (!getResumeFromPage().equals(REVIEW_QUOTE)) {
            aceHomeReviewQuotePage = navigateToAceHomeReviewQuotePage(applicant, lob, propertyType);
        }
        if (aceHomeReviewQuotePage.isOnReviewQuotePageHome(true) &&
                aceHomeReviewQuotePage.isBundleDiscountStateV2(applicant.getStateCode())) {
                aceHomeReviewQuotePage.clickApplyBundleDiscountButtonIfPresent();
        }
        waitForSkeletonToBeGone();
        if (aceHomeReviewQuotePage.isOnReviewQuotePageHome(true)) {
            aceHomeReviewQuotePage.clickContinueWithAutoBundleButton();
        }
        waitForSpinnerToBeGone();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        if (whoShouldWeInsurePage.isAddVehiclesDriversButtonPresent()) {
            Reporter.pass("Navigated to WhoShouldWeInsurePage");
        } else {
            throw new IllegalStateException(DID_NOT_REACH + "WhoShouldWeInsurePage");
        }
    }
}
