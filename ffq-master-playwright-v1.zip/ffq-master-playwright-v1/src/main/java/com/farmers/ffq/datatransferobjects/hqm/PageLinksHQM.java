package com.farmers.ffq.datatransferobjects.hqm;

import com.farmers.ffq.hqm.pages.HqmBasePage;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class PageLinksHQM {
	public final String pageName;
	public final String stateCode;
	public Integer checkAgentInfo;
	public String quoteType;
	public Integer iconSummary;
	public Integer stepperAddress;
	public Integer stepperProperty;
	public Integer stepperPersonalInfo;
	public Integer stepperQuote;
	public Integer linkPersonalInfoUse;
	public Integer linkSaveQuote;
	public Integer linkCallFarmers;
	public Integer needHelpText;
	public String  phoneToCall;
	public Integer linkContactUs;
	public Integer linkTermsOfUse;
	public Integer linkPrivacyPolicy;
	public Integer linkPrivacyPolicyNext;
	public Integer linkNoticeOfInformationPractices;
	public Integer linkDigiCert;
	public Integer linkCallUs;
	public Integer buttonBack;
	public Integer buttonNext;

	// null - no validation
	// 0 - validate link/button not available (not displayed)
	// 1 - validate link/button available (displayed)
	// 2 - validate link/button disabled
	// 3 - validate link/button enabled

	public PageLinksHQM(String pageToCheck, String stateCode) {
		this.pageName = pageToCheck;
		this.stateCode = stateCode;
		this.quoteType = FC;
		checkAgentInfo = 1;
		iconSummary = 1;
		linkCallFarmers = 1;
		linkContactUs = 1;
		linkCallUs = 1;
		linkTermsOfUse = 1;
		linkPrivacyPolicy = 1;
		linkPrivacyPolicyNext = 0;
		linkPersonalInfoUse = 1;
		linkNoticeOfInformationPractices = 1;
		linkDigiCert = 1;
		needHelpText = 1;
		phoneToCall = CALL_FARMERS;
		switch (pageToCheck) {
			case "addressPage":
				stepperAddress = 3;
				stepperProperty = 2;
				stepperPersonalInfo = 2;
				stepperQuote = 2;
				linkSaveQuote = 0;
				linkPrivacyPolicyNext = 1;
				buttonBack = 0;
				buttonNext = 3;
				break;
			case "propertyPage":
			case "qualityPage":
			case "propertyDetailsPage":
				stepperAddress = 2;
				stepperProperty = 3;
				stepperPersonalInfo = 2;
				stepperQuote = 2;
				linkSaveQuote = 0;
				buttonBack = 3;
				buttonNext = 2;
				break;
			case "customerInfoPage":
				stepperAddress = 2;
				stepperProperty = 2;
				stepperPersonalInfo = 3;
				stepperQuote = 2;
				linkSaveQuote = 0;
				buttonBack = 3;
				buttonNext = 2;
				break;
			case "contactInfoPage":
				stepperAddress = 2;
				stepperProperty = 2;
				stepperPersonalInfo = 3;
				stepperQuote = 2;
				linkSaveQuote = 1;
				buttonBack = 3;
				buttonNext = 2;
				break;
			case "discountsPage":
				stepperAddress = 2;
				stepperProperty = 2;
				stepperPersonalInfo = 3;
				stepperQuote = 2;
				linkSaveQuote = 1;
				buttonBack = 3;
				buttonNext = 3;
				break;
			case "quotePage":
				stepperAddress = 2;
				stepperProperty = 2;
				stepperPersonalInfo = 2;
				stepperQuote = 3;
				linkSaveQuote = 1;
				buttonBack = 3;
				buttonNext = 3;
				break;
			case "thankYouPage":
				checkAgentInfo = 0;
				iconSummary = 0;
				stepperAddress = 0;
				stepperProperty = 0;
				stepperPersonalInfo = 0;
				stepperQuote = 0;
				linkPersonalInfoUse = 0;
				linkCallFarmers = 0;
				linkContactUs = 0;
				linkCallUs = 0;
				linkTermsOfUse = 0;
				linkPrivacyPolicy = 0;
				linkSaveQuote = 0;
				linkNoticeOfInformationPractices = 0;
				linkDigiCert = 0;
				needHelpText = 0;
				buttonBack = 0;
				buttonNext = 0;
				break;
			default:
				throw new IllegalArgumentException("\nUnknown Page Name passed: " + pageToCheck + "\n");
		}
		if (!pageToCheck.equals("thankYouPage")) {
			switch (stateCode) {
				case VA:
				case MT:
				case CT:
				case AZ:
				case ID:
				case OR:
				case NM:
				case WI:
				case NE:
				case TN:
				case WY:
				case GA:
				case CA:
					linkNoticeOfInformationPractices = 1;
					break;
				case MO:
				case CO:
				case IN:
				case KS:
				case MD:
				case OH:
				case OK:
				case PA:
					phoneToCall = CALL_FARMERS;
					linkNoticeOfInformationPractices = 0;
					break;
				case MN:
				case NV:
				case TX:
				case WA:
				case IL:
				case UT:
				case IA:
					phoneToCall = CALL_FARMERS;
					linkNoticeOfInformationPractices = 1;
					break;
				case MI:
				case AR:
				case SD:
				case ND:
				case AL:
					linkNoticeOfInformationPractices = 0;
					break;
				case KY:
				case MS:
				case MA:
				case LA:
				case NC:
					phoneToCall = CALL_FARMERS_EE;
					linkNoticeOfInformationPractices = 0;
				break;
				default:
					throw new IllegalArgumentException("\nUnknown State Code passed: " + stateCode + "\n");
			}
		}
	}

	public PageLinksHQM(String pageToCheck, ApplicantHQM applicant, String quoteType, boolean afterQuote) throws Exception {
		this(pageToCheck, applicant.stateCode);
		this.phoneToCall = (new HqmBasePage()).getContactUsPhoneNumber(applicant, quoteType, afterQuote);
		if (quoteType.equals(QQ)) {
			this.quoteType = quoteType;
			this.linkContactUs = 0;
		}
	}

}
