package com.farmers.ffq.datatransferobjects;

import com.farmers.ffq.dataproviderframework.DataObjectBase;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ApplicantHome extends DataObjectBase {

    private String firstName;
    private String lastName;
    private int age;
    private String gender;
    private String maritalStatus;
    private String spouseFirstName;
    private String spouseLastName;
    private int spouseAge;
    private String spouseGender;
    private String addressApt;
    private String city;
    private String stateCode;
    private String state;
    private String sameStateZipCode;
    private String diffOfferingZipCode;
    private String zipCode;
    private boolean mailingAddressDifferent;
    private String mailingAddress;
    private String mailingCity;
    private String mailingState;
    private String mailingZipCode;
    private String propertyType;
    private boolean agreeHomeownersNotif;
    private boolean shareConsumeReport;
    private String propertyIsYour;
    private String numberOfAdultsInTheHousehold;
    private String lineOfBusiness;
    private boolean hasMailingAddressCheckbox;
    private String howLongAgoWasYourLastPropertyClaim;
    private boolean numberOfAdultsInTheHouseholdQuestionAsked;
    private boolean howLongAgoWasYourLastPropertyClaimQuestionAsked;
    private boolean propertyLossesInTheLastFiveYearsQuestionAsked;
    private int whenYourHomeWasOriginallyBuilt;
    private String squareFootage;
    private String numberOfSeparateLivingUnits;
    private String propertyLossesInTheLastFiveYears;
    private String typeOfRoof;
    private String homeExteriorWallType;
    private String dwellingStyle;
    private String numberOfStories;
    private String numberOfFullBathsRooms;
    private String numberOfHalfBathsRooms;
    private String howOldIsYourRoof;
    private String typeOfGarage;
    private boolean yourHomeHaveAnyDecks;
    private boolean yourHomeHavePool;
    private boolean yourHomeConnected;
    private boolean yourHomeHaveBasement;
    private boolean permanentStormShutters;
    private boolean permanentStormShuttersQuestionAsked;
    private boolean plumbingSystemBeenReplaced;
    private boolean plumbingSystemBeenReplacedQuestionAsked;
    private String heatingSystemIsBeingUsed;
    private String emailAddress;
    private String phoneNumber;
    private String occupation;
    private String spouseOccupation;
    private boolean anySmokersInYourHouse;
    private boolean fireSprinklerSystem;
	private boolean centralBurglarAlarm;
    private boolean centralFireAlarm;
    private String homeSafety;
    private boolean ironBars;
    private boolean localBurglarAlarm;
    private int policyStartDay;
    private String yourPackage;
    private String estimatedReconstructionCost;
    private boolean crossSellOptionAuto;
    private boolean errorScenario;
    private boolean knockOutScenario;
    private boolean verifyEmail;
    private boolean sendEmail;
    private String diffOfferingState;
    private boolean saveAndRetrievePropPage;
    private boolean saveAndRetrieveCoveragePage;
    private boolean saveAndRetrieveQuotePage;
    private boolean backSaveInPropPage;
    private boolean backSaveInCoveragePage;
    private ApplicantRetQuote applicantRetQuote;
    private String url;
    private boolean getRetrieveScenario;
    private boolean existingCustomerScenario;
    private boolean hasAutoPolicy;
    private boolean politicalFlowScenario;
	private boolean awsFlowScenario;
    private boolean keep360Prefill;
    private boolean customRateScenario;
    private String windAndHail;
    private String allPeril;
    private String personalLiability;
    private boolean customRateAndResetScenario;
    private String dwelling;
    private String lossOfUse;
    private String personalProperty;
    private String extendedReplacementCost;
    private boolean backNavFlow;
    private boolean didNavBack;
    private boolean changeBrowserDimensionScenario;

    /**
     * String Representation of Applicant class.
     */
    public String toString() {
        return String.format("%s: %s %s %s %s %s %s", getId(), firstName, lastName, addressApt, city, state, zipCode );
    }

}
