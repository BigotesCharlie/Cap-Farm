package com.farmers.ffq.ace.hrc.common;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCDwellingCoverageBasePage extends AceHRCBasePage {

    private static final String EXPECTED_HOME_QUALITY_GRADE_IMP_QUESTION = "Why is my home's quality grade important?";
    private static final String EXPECTED_WHY_HOME_QUALITY_GRADE_EXPLANATION_TEXT_DESKTOP = "Your home's quality grade, along with other details you've provided about your home, are used to help estimate how much it might cost to replace your home in the event of a total loss.";
    private static final String EXPECTED_WHY_HOME_QUALITY_GRADE_EXPLANATION_TEXT_MOBILE = "Your home's quality grade, along with other details you've provided about your home, are used to help estimate how much it might cost to replace the dwelling interior of your home in the event of a total loss. Learn more";
    private static final String EXPECTED_LEARN_MORE_LINK = "Learn more";
    protected static final String EXPECTED_EDIT_CVG_LINK_TEXT = "Edit dwelling coverage";

    private static final String ECONOMY_QUALITY_GRADE = "Economy";
    private static final String STANDARD_QUALITY_GRADE = "Standard";
    private static final String ABOVE_AVG_QUALITY_GRADE = "Above average";
    private static final String CUSTOM_QUALITY_GRADE = "Custom";
    private static final String PREMIUM_QUALITY_GRADE = "Premium";
    private static final String ECONOMY_GRADE_DESCRIPTION = "Basic home features and design. Simple construction layout and floor plan. Inexpensive fixtures and features. Lower grade, but functional, construction materials.";
    private static final String STANDARD_GRADE_DESCRIPTION = "Common tract style home construction. Features come as part of the packaged construction design. Some upgraded features and may include slightly higher ceilings or vaulted ceilings.";
    private static final String ABOVE_AVG_GRADE_DESCRIPTION = "Tract style home construction with upgraded features in many of the rooms. Features are of higher quality materials, including wall and floor coverings, lighting fixtures and kitchen and master bath countertops.";
    private static final String CUSTOM_GRADE_DESCRIPTION = "Homes are distinguished by unique style and shape. High quality/premium finishes for kitchen and bath countertops, floor and wall coverings, and features like built-in bookshelves, and wet bars.";
    private static final String PREMIUM_GRADE_DESCRIPTION = "Unique style and/or shape which vary from other homes in the area. Very large homes with the highest grade materials and unique features such as wall safes, built-in movie theaters, etc.";
    private static final List<String> EXPECTED_QUALITY_GRADE_DESCRIPTION_ECONOMY = Arrays.asList(ECONOMY_GRADE_DESCRIPTION, STANDARD_GRADE_DESCRIPTION, ABOVE_AVG_GRADE_DESCRIPTION, CUSTOM_GRADE_DESCRIPTION, PREMIUM_GRADE_DESCRIPTION);
    private static final List<String> EXPECTED_QUALITY_GRADE_DESCRIPTION_STANDARD = Arrays.asList(STANDARD_GRADE_DESCRIPTION, ABOVE_AVG_GRADE_DESCRIPTION, CUSTOM_GRADE_DESCRIPTION, PREMIUM_GRADE_DESCRIPTION);
    private static final List<String> EXPECTED_QUALITY_GRADE_DESCRIPTION_ABOVE_AVG = Arrays.asList(ABOVE_AVG_GRADE_DESCRIPTION, CUSTOM_GRADE_DESCRIPTION, PREMIUM_GRADE_DESCRIPTION);
    private static final List<String> EXPECTED_QUALITY_GRADE_DESCRIPTION_CUSTOM = Arrays.asList(CUSTOM_GRADE_DESCRIPTION, PREMIUM_GRADE_DESCRIPTION);
    private static final List<String> EXPECTED_QUALITY_GRADE_DESCRIPTION_PREMIUM = Arrays.asList(PREMIUM_GRADE_DESCRIPTION);

    private static final List<String> EXPECTED_QUALITY_GRADE_LABELS_ECONOMY = Arrays.asList(ECONOMY_QUALITY_GRADE, STANDARD_QUALITY_GRADE, ABOVE_AVG_QUALITY_GRADE, CUSTOM_QUALITY_GRADE, PREMIUM_QUALITY_GRADE);
    private static final List<String> EXPECTED_QUALITY_GRADE_LABELS_STANDARD = Arrays.asList(STANDARD_QUALITY_GRADE, ABOVE_AVG_QUALITY_GRADE, CUSTOM_QUALITY_GRADE, PREMIUM_QUALITY_GRADE);
    private static final List<String> EXPECTED_QUALITY_GRADE_LABELS_ABOVE_AVG = Arrays.asList(ABOVE_AVG_QUALITY_GRADE, CUSTOM_QUALITY_GRADE, PREMIUM_QUALITY_GRADE);
    private static final List<String> EXPECTED_QUALITY_GRADE_LABELS_CUSTOM = Arrays.asList(CUSTOM_QUALITY_GRADE, PREMIUM_QUALITY_GRADE);
    private static final List<String> EXPECTED_QUALITY_GRADE_LABELS_PREMIUM = Arrays.asList(PREMIUM_QUALITY_GRADE);

    private static final String UPDATE_HOME_QUALITY_GRADE_ACTION_DESCRIPTION = "You are about to update your home quality grade. This will also change your Dwelling reconstruction coverage options. Are you sure you want to continue?";

    private static final String ONE_MOMENT_PLEASE = "One moment, please";
    private static final String RC2_PAGE_SUBTITLE = "Based on the information you provided and your current coverage, we're ...";

    @PWFindBy(xpath = "//div[contains(@class,'-coverage__container')]//h1")
    private PWElement dwellingCoverageHeading;

    @PWFindBy(xpath = "//div[@class='dwelling-coverage-image']//img")
    private PWElement dwellingCoverageImage;
    @PWFindBy(xpath = "//div[contains(@class,'dwelling-coverage-info')]//mat-icon")
    private PWElement dwellingCoverageInfoIconDesktop;
    @PWFindBy(xpath = "//div[contains(@class,'dwelling-coverage-main')]//mat-icon[contains(@class,'mobile-info-icon')]")
    private PWElement dwellingCoverageInfoIconMobile;
    @PWFindBy(xpath = "//div[contains(@class,'dwelling-coverage-info')]//p")
    private PWElement dwellingCoverageInfoQuestionDesktop;
    @PWFindBy(xpath = "//mat-dialog-container//h1")
    private PWElement dwellingCoverageInfoQuestionMobile;
    @PWFindBy(xpath = "//div[contains(@class,'dwelling-coverage-info')]//div//span[1]")
    private PWElement dwellingCoverageInfoTextDesktop;
    @PWFindBy(xpath = "//mat-dialog-container//h1/following-sibling::p")
    private PWElement dwellingCoverageInfoTextMobile;
    @PWFindBy(xpath = "//div[contains(@class,'dwelling-coverage-info')]//div//span[contains(@class,'tui-link-button')]")
    private PWElement dwellingCoverageLearnMoreLinkDesktop;
    @PWFindBy(xpath = "//mat-dialog-container//h1/following-sibling::p/span")
    private PWElement dwellingCoverageLearnMoreLinkMobile;

    @PWFindBy(xpath = "//p[contains(@class,'dwelling-coverage-title')]")
    private PWElement dwellingCoverageTitle;
    @PWFindBy(xpath = "//p[contains(@class,'dwelling-coverage-amount')]")
    private PWElement dwellingCoverageAmount;
    @PWFindBy(xpath = "//div[@id='propertyGradeDiv']")
    private PWElement dwellingCoverageQualityGrade;
    @PWFindBy(xpath = "//div[contains(@class,'dwelling-coverage-disclaimer')]//p[1]")
    private PWElement dwellingCoverageDisclaimerPart1;
    @PWFindBy(xpath = "//div[contains(@class,'dwelling-coverage-disclaimer')]//p[2]")
    private PWElement dwellingCoverageDisclaimerPart2;
    @PWFindBy(xpath = "//button[@id='editDetailsLink']/span/span")
    private PWElement editCoverageAndQualityGraderButtonLinkHomeLob;
    @PWFindBy(xpath = "//button[@id='editDetailsLink']")
    private PWElement editCoverageAndQualityGraderButtonLink;
    @PWFindBy(xpath = "//mat-divider")
    private PWElement matDivider;
    @PWFindBy(xpath = "//div[@class='model-info-section']//h1")
    private PWElement dwellingCoverageInfoHeaderQuestionSideSheet;
    @PWFindBy(xpath = "//div[@class='model-info-section']//p[1]")
    private PWElement dwellingCoverageInfoHeaderSubtextSideSheet;
    @PWFindBy(xpath = "//div[@class='model-info-section']//p[2]")
    private PWElement fiveQualityGradeHeaderSideSheet;
    @PWFindBy(xpath = "//ul[contains(@class,'dwelling-types')]//li")
    private List<PWElement> qualityGradeTypesDiv;
    @PWFindBy(xpath = "//ul[contains(@class,'dwelling-types')]//span[contains(@class,'tui-field-label-text')]")
    private List<PWElement> qualityGradeTypesHeaders;
    @PWFindBy(xpath = "//ul[contains(@class,'dwelling-types')]//p")
    private List<PWElement> qualityGradeTypesDescriptions;
    @PWFindBy(xpath = "//app-model-info-box//mat-icon[contains(text(),'close')]")
    private PWElement closeIconOnLearnMoreSideSheet;
    @PWFindBy(xpath = "//mat-icon[contains(@class,'dwelling-list-heading-close')]")
    private PWElement dwellingListCloseIcon;
    @PWFindBy(xpath = "//app-dwelling-coverage-list//h4")
    private PWElement dwellingCoverageAndGradeHeaderSideSheet;
    @PWFindBy(xpath = "//app-dwelling-coverage-list//div[contains(@class,'coverage-subtitle')]")
    private PWElement dwellingReconstructionSubHeaderSideSheet;
    @PWFindBy(xpath = "//app-dwelling-coverage-list//p[@id='increased-coverage-info']")
    private PWElement dwellingReconstructionDescriptionSideSheet;
    @PWFindBy(xpath = "//app-dwelling-coverage-list//mat-divider")
    private PWElement matDividerDwellingCoverageSideSheet;

    @PWFindBy(xpath = "//app-dwelling-coverages//button[contains(@class,'tui-link-button')]")
    private PWElement editCoveragesAndQualityGrade;

    @PWFindBy(xpath = "//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button")
    private List<PWElement> reconstructionCoverageAmountMatRadioButtons;

    @PWFindBy(xpath = "//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button//label")
    private PWElement reconstructionCoverageAmountLabel;
    @PWFindBy(xpath = "//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button//input")
    private List<PWElement> reconstructionCoverageAmountInputRadioButtons;
    @PWFindBy(xpath = "//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button//label//p[contains(@class,'tui-body-text-bold')]")
    private List<PWElement> reconstructionCoverageAmountLabels;
    @PWFindBy(xpath = "//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button//label//p[2]")
    private List<PWElement> reconstructionCoverageAmountLabelsSubText;
    @PWFindBy(xpath = "//hr")
    private PWElement dottedHorizontalDivider;
    @PWFindBy(xpath = "//div[@class='subsection-heading']//div")
    private PWElement standardHomeQualityGradeTitle;
    @PWFindBy(xpath = "//div[@class='subsection-heading']//mat-icon")
    private PWElement standardHomeQualityGradeHintIcon;
    @PWFindBy(xpath = "//div[@class='coverage-body']//span[1]")
    private PWElement standardHomeQualityGradeSubText;
    @PWFindBy(xpath = "//span[@class='edit-link']")
    private PWElement editYourQualityGradeLink;
    @PWFindBy(xpath = "//div[contains(@class,'dwelling-disclaimer-text')]//p")
    private PWElement agentContainerText;
    @PWFindBy(xpath = "//div[contains(@class,'dwelling-submit-section')]//button[contains(text(),'Save')]")
    private PWElement saveButtonOnDwellingCovSideSheet;
    @PWFindBy(xpath = "//div[contains(@class,'dwelling-submit-section')]//button[contains(text(),'Cancel')]")
    private PWElement cancelButtonOnDwellingCovSideSheet;
    @PWFindBy(xpath = "//mat-icon[contains(@class,'edit-quality-grade-back__button')]")
    protected PWElement backIconOnEditQualityGradeSideSheet;
    @PWFindBy(xpath = "//div[contains(@class,'edit-grade-heading-section')]//h4")
    private PWElement editHomeQualityGradeHeader;

    @PWFindBy(xpath = "//div[contains(@class,'edit-grade-heading-section')]//mat-divider")
    private PWElement editHomeQualityGradeSolidDivider;

    @PWFindBy(xpath = "//div[contains(text(),'Home quality grade')]")
    private PWElement editHomeQualityGradeSubHeader;
    @PWFindBy(xpath = "//p[contains(@class,'tui-field-label')]")
    private PWElement editHomeQualityGradeSubHeaderDescription;
    private static final String COVERAGE_RADIO_BUTTON_XPATH = "//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button";
    @PWFindBy(xpath = COVERAGE_RADIO_BUTTON_XPATH)
    protected List<PWElement> homeQualityGradeMatRadioButtons;
    @PWFindBy(xpath = COVERAGE_RADIO_BUTTON_XPATH + "//input")
    protected List<PWElement> homeQualityGradeInputRadioButtons;
    @PWFindBy(xpath = COVERAGE_RADIO_BUTTON_XPATH + "[not(contains(@class,'radio-checked'))]//label")
    protected PWElement coverageUncheckedRadioButtonLabel;
    @PWFindBy(xpath = "//span[contains(@class,'grade-option-subtext')]")
    private List<PWElement> homeQualityGradeRadioButtonDescriptions;
    @PWFindBy(xpath = COVERAGE_RADIO_BUTTON_XPATH + "//span[contains(@class,'mat-radio-label-content')]")
    private List<PWElement> homeQualityGradeRadioButtonLabels;
    @PWFindBy(xpath = "//mat-divider[contains(@class,'quality-grade-note-divider')]")
    private PWElement homeQualityGradeDottedDivider;
    @PWFindBy(xpath = "//p[contains(@class,'quality-grade-note')]")
    private PWElement homeQualityGradeNote;
    @PWFindBy(xpath = "//div[contains(@class,'edit-grade-update-section')]//button")
    protected PWElement upgradeGradeButton;
    @PWFindBy(xpath = "//div[contains(@class,'edit-grade-update-section')]//a")
    protected PWElement cancelGradeButton;
    @PWFindBy(xpath = "//app-dwelling-coverage-list")
    private PWElement dwellingCoverageSideSheet;
    @PWFindBy(xpath = "//mat-dialog-container")
    private PWElement updateHomeQualityGradeModalDialog;
    @PWFindBy(xpath = "//span[contains(@class,'quality-grade-pop-up-title')]")
    private PWElement updateHomeQualityGradeTitle;
    @PWFindBy(xpath = "//mat-dialog-content//span")
    private PWElement updateHomeQualityGradeActionDescription;
    @PWFindBy(xpath = "//mat-dialog-container//mat-dialog-actions//button[2]")
    private PWElement keepPreviousGradeLink;
    @PWFindBy(xpath = "//mat-dialog-container//mat-dialog-actions//button[1]")
    private PWElement updateGradeButtonInPopup;
    @PWFindBy(xpath = "//mat-dialog-container[@aria-labelledby='unsavedChanges']")
    private PWElement unsavedChangesModalDialogue;
    @PWFindBy(xpath = "//span[contains(@class,'unsaved-changes-modal-title')]")
    private PWElement unsavedChangesModalTitle;
    @PWFindBy(xpath = "//span[contains(text(),'Changes that you made have not been saved yet.')]")
    private PWElement changesHaveNotBeenSavedText;
    @PWFindBy(xpath = "//button[@data-test-id='UNSAVED_CHANGES_EXIT_WITHOUT_SAVING_BUTTON']")
    private PWElement exitWithoutSavingButton;
    @PWFindBy(xpath = "//button[@data-test-id='UNSAVED_CHANGES_NO_CONTINUE_EDITING_BUTTON']")
    private PWElement continueEditingLink;
    @PWFindBy(xpath = "//mat-icon[contains(@class,'edit-quality-grade-heading-close')]")
    private PWElement editHomeQualityGradeCloseIcon;

    @PWFindBy(xpath = "//button[@id='continueButton']")
    private PWElement continueButton;

    @PWFindBy(xpath = "//app-home-condo-renter-rc2-loader/h1")
    private PWElement rc2Screen_MainHeading;

    @PWFindBy(xpath = "//app-home-condo-renter-rc2-loader//div[@class='tui-input-text']")
    private PWElement rc2SubHeading;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceHRCDwellingCoverageBasePage() throws Exception {
        super();
    }

    public boolean isOnDwellingCoveragePage() {
        waitForSpinnerToBeGone();
        return isElementVisible(dwellingCoverageHeading, Property.PAGELOADTIMEOUT);
    }

    public boolean quickIsOnDwellingCoveragePage() {
        return isElementPresent(PWBy.xpath("//div[contains(@class,'-coverage__container')]//h1"), 5);
    }

    public void validateDwellingCoverageHeaderAndImage(FarmersSoftAssert sa) throws Exception {
        waitElementBeVisible(dwellingCoverageImage);
        String expectedDwellingCoverageHeader = "Review your dwelling coverage";
        sa.assertEquals(getTextFromElement(dwellingCoverageHeading), expectedDwellingCoverageHeader, "Dwelling coverage heading check");
        sa.assertTrue(isElementInViewport(dwellingCoverageHeading), "Dwelling coverage page - page title is in Viewport");
        sa.assertTrue(dwellingCoverageImage.isDisplayed(), "Dwelling coverage image displayed.");
    }

    public void validateDwellingCoverageInfoSection(FarmersSoftAssert sa) {
        if (!isUseMobileViewEnabled()) {
            waitElementBeVisible(dwellingCoverageInfoIconDesktop);
            sa.assertTrue(dwellingCoverageInfoIconDesktop.isDisplayed(), "Dwelling coverage info icon (desktop) is not displayed.");
            sa.assertEquals(getTextFromElement(dwellingCoverageInfoQuestionDesktop), EXPECTED_HOME_QUALITY_GRADE_IMP_QUESTION, "Dwelling coverage info question text (desktop) check");
            sa.assertEquals(getTextFromElement(dwellingCoverageInfoTextDesktop), EXPECTED_WHY_HOME_QUALITY_GRADE_EXPLANATION_TEXT_DESKTOP, "Dwelling coverage info question content text (desktop) check");
            sa.assertEquals(getTextFromElement(dwellingCoverageLearnMoreLinkDesktop), EXPECTED_LEARN_MORE_LINK, "Dwelling coverage info question learn more link text (desktop) check");
        } else {
            sa.assertTrue(isElementDisplayed(dwellingCoverageInfoIconMobile, 2), "Dwelling coverage info icon (mobile) is not displayed.");
            waitAndClickElement(dwellingCoverageInfoIconMobile);
            sa.assertEquals(getTextFromElement(dwellingCoverageInfoQuestionMobile), EXPECTED_HOME_QUALITY_GRADE_IMP_QUESTION, "Dwelling coverage info question text (mobile) check");
            sa.assertEquals(getTextFromElement(dwellingCoverageInfoTextMobile), EXPECTED_WHY_HOME_QUALITY_GRADE_EXPLANATION_TEXT_MOBILE, "Dwelling coverage info question content text (mobile) check");
            sa.assertEquals(getTextFromElement(dwellingCoverageLearnMoreLinkMobile), EXPECTED_LEARN_MORE_LINK, "Dwelling coverage info question learn more link text (mobile) check");
            clickOnCloseIconOnLearnMoreSideSheet();
        }
    }

    public void validateContentOfLearnMoreSideSheet(FarmersSoftAssert sa) {

        waitElementBeVisible(dwellingCoverageInfoHeaderQuestionSideSheet);
        sa.assertEquals(getTextFromElement(dwellingCoverageInfoHeaderQuestionSideSheet), EXPECTED_HOME_QUALITY_GRADE_IMP_QUESTION,
                "Why is home's quality grade important question in side sheet text check");
        if (!isUseMobileViewEnabled()) {
            sa.assertEquals(getTextFromElement(dwellingCoverageInfoHeaderSubtextSideSheet), EXPECTED_WHY_HOME_QUALITY_GRADE_EXPLANATION_TEXT_DESKTOP,
                    "Dwelling coverage info subtext in side sheet (desktop) check");
        } else {
            sa.assertEquals(getTextFromElement(dwellingCoverageInfoHeaderSubtextSideSheet), EXPECTED_WHY_HOME_QUALITY_GRADE_EXPLANATION_TEXT_MOBILE,
                    "Dwelling coverage info subtext in side sheet (mobile) check");
        }

        String expectedFiveQualityGraderHeaderText = "There are five quality grades:";
        sa.assertEquals(getTextFromElement(fiveQualityGradeHeaderSideSheet), expectedFiveQualityGraderHeaderText,
                "Five quality grades header text in side sheet check");

        sa.assertEquals(qualityGradeTypesDiv.size(), 5, "Quality grade type count check");
        sa.assertEquals(qualityGradeTypesHeaders.size(), 5, "Quality grade type header count check");
        sa.assertEquals(qualityGradeTypesDescriptions.size(), 5, "Quality grade type description count check");

        List<String> foundQualityTypeHeaders = qualityGradeTypesHeaders.stream().map(this::getTextFromElement).collect(Collectors.toList());
        sa.assertTrue(EXPECTED_QUALITY_GRADE_LABELS_ECONOMY.equals(foundQualityTypeHeaders), "Quality Types headers check.");

        List<String> foundQualityGradeTypeDescriptions = qualityGradeTypesDescriptions.stream().map(this::getTextFromElement).collect(Collectors.toList());
        sa.assertTrue(EXPECTED_QUALITY_GRADE_DESCRIPTION_ECONOMY.equals(foundQualityGradeTypeDescriptions), "Quality grade descriptions check.");

        sa.assertTrue(closeIconOnLearnMoreSideSheet.isDisplayed(), "Close icon displayed");

        closeSideSheetByEscKey(sa);
    }

    public void validateDwellingCoverageDetailsSection(FarmersSoftAssert sa, AppStore appStore) throws Exception {
        String expectedDwellingCoverageTitle = "Dwelling coverage";
        sa.assertEquals(getTextFromElement(dwellingCoverageTitle), expectedDwellingCoverageTitle, "Dwelling coverage title text check");

        String expectedDwellingCoverageAmount = getDwellingCoverageCostFromAppStoreInCurrencyFormat(appStore);
        String updatedReconstructionAmount = getSessionStorageAppStore().getHome().getUpdatedReconstructionCost();
        if (updatedReconstructionAmount != null) {
            String updatedReconstructionCostCostFromAppStoreInCurrencyFormat = getUpdatedReconstructionCostCostFromAppStoreInCurrencyFormat(updatedReconstructionAmount);
            sa.assertEquals(getTextFromElement(dwellingCoverageAmount), updatedReconstructionCostCostFromAppStoreInCurrencyFormat, "Dwelling coverage amount set to reconstruction value.");
        } else {
            sa.assertEquals(getTextFromElement(dwellingCoverageAmount), expectedDwellingCoverageAmount, "Dwelling coverage amount check");
        }
        String qualityGrade = getTheQualityGradeFromAppStore();

        String expectedDwellingCoverageQualityGrade = qualityGrade + " home quality grade";
        if (isUseMobileViewEnabled()) {
            expectedDwellingCoverageQualityGrade = expectedDwellingCoverageQualityGrade + (isSafariBrowser() ? "info" : " info");
        }
        sa.assertEquals(getTextFromElement(dwellingCoverageQualityGrade), expectedDwellingCoverageQualityGrade,
                "Dwelling coverage quality grade text " + expectedDwellingCoverageQualityGrade + " on page check");

        String expectedDwellingCoverageDisclaimerPart1 = "This is the amount of coverage you may want to repair or rebuild your home in the event of a loss, including a total loss. Your personal belongings aren't included.";
        sa.assertEquals(getTextFromElement(dwellingCoverageDisclaimerPart1), expectedDwellingCoverageDisclaimerPart1, "Dwelling coverage disclaimer part 1 text check");

        String expectedDwellingCoverageDisclaimerPart2 = "This initial coverage amount is based on the reconstruction cost estimate we calculated based on the information you've provided, but ultimately you are responsible for selecting the amount of coverage you want.";
        sa.assertEquals(getTextFromElement(dwellingCoverageDisclaimerPart2), expectedDwellingCoverageDisclaimerPart2, "Dwelling coverage disclaimer part 2 text check");
    }

    public void validateEditCoverageAndQualityGradeLinkSectionHomeLob(FarmersSoftAssert sa) {
        sa.assertEquals(getTextFromElement(editCoverageAndQualityGraderButtonLinkHomeLob), EXPECTED_EDIT_CVG_LINK_TEXT, "Edit coverage link text check");
        sa.assertTrue(editCoverageAndQualityGraderButtonLinkHomeLob.isEnabled(), "Edit coverage and quality grade link enabled.");
        scrollToElement(matDivider);
        waitElementBeVisible(matDivider);
        sa.assertTrue(matDivider.isDisplayed(), "Mat divider is not displayed - dwelling coverage main page.");
    }
    public void validateContentOfDwellingCoverageAndGradeSideSheet(FarmersSoftAssert sa) throws Exception {
        String expectedDwellingCoverageAndQualityGradeSideSheetHeader = "Dwelling coverage";
        sa.assertEquals(getTextFromElement(dwellingCoverageAndGradeHeaderSideSheet), expectedDwellingCoverageAndQualityGradeSideSheetHeader, "Dwelling coverage & grade header text check.");

        sa.assertTrue(matDividerDwellingCoverageSideSheet.isDisplayed(), "Mat divide displayed");

        String expectedReconstructionCoverageSubHeaderText = "Dwelling reconstruction coverage";
        sa.assertEquals(getTextFromElement(dwellingReconstructionSubHeaderSideSheet), expectedReconstructionCoverageSubHeaderText, "Dwelling reconstruction coverage sub header text check.");

        String expectedReconstructionDescriptionText = "You may want to increase your coverage to allow for extra protection against changing labor and material costs to rebuild in case of a loss.";
        sa.assertEquals(getTextFromElement(dwellingReconstructionDescriptionSideSheet), expectedReconstructionDescriptionText, "Dwelling reconstruction description text check.");

        validateContentOfReconstructionCostAndSubtext(sa);

        sa.assertTrue(dottedHorizontalDivider.isDisplayed(), "Dotted horizontal line displayed.");

        String expectedAgentContainerText = "Looking for a different coverage level? Get in touch with a Farmers\u00ae representative to get the coverage you want.";
        sa.assertEquals(getTextFromElement(agentContainerText), expectedAgentContainerText, "Agent level question text check.");
    }

    public void validateContentOfReconstructionCostAndSubtext(FarmersSoftAssert sa) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        String reconstructionCost = appStore.getHome().getReconstructionCost();
        if (reconstructionCost != null) {
            if ((Integer.parseInt(reconstructionCost) <= ONEMILLION)) {
                waitElementBeVisibleClickable(reconstructionCoverageAmountMatRadioButtons.get(0));

                List<String> foundReconstructionCoverageAmount = getListOfReconstructionCoverageAmountLabels();
                List<String> expectedReconstructionCoverageAmount = getTheExpectedReconstructionCoverageInInteger(getTheReconstructionCostFromAppStore());
                sa.assertEquals(foundReconstructionCoverageAmount, expectedReconstructionCoverageAmount, "Reconstruction coverage amount cost check");

                List<String> foundReconstructionCoverageSubText = getListOfReconstructionCoverageAmountLabelsSubText();
                List<String> expectedReconstructionCoverageSubText = new ArrayList<>();
                if (expectedReconstructionCoverageAmount.size() == 3) {
                    sa.assertEquals(reconstructionCoverageAmountMatRadioButtons.size(),3, "Reconstruction coverage amount radio button count check");
                    expectedReconstructionCoverageSubText = Arrays.asList("Our estimated coverage amount", "About 10% more coverage", "About 20% more coverage");
                } else {
                    sa.assertEquals(reconstructionCoverageAmountMatRadioButtons.size(), 2, "Reconstruction coverage amount radio button count check");
                    expectedReconstructionCoverageSubText = Arrays.asList("Our estimated coverage amount", "Maximum coverage available");
                }
                PWElement selectedReconstructionRadioButton = driver().findElement(PWBy.xpath("//div[contains(@class,'dwelling-cost-radio')]//mat-radio-button//label//p[contains(text(),'"
                        + getReconstructionCostFromAppStoreInCurrencyFormat() + "')]/./../../.."));

                sa.assertTrue(getAttributeData(selectedReconstructionRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED), "Expected reconstruction radio button is checked");

                // in case the last coverage amount is 1M, the radio button subtext should reflect that
                if (foundReconstructionCoverageAmount.get(foundReconstructionCoverageAmount.size()-1).equals(_1M)) {
                    int lastIndex = expectedReconstructionCoverageSubText.size() - 1;
                    expectedReconstructionCoverageSubText.set(lastIndex, "Maximum coverage available");
                }
                sa.assertEquals(foundReconstructionCoverageSubText, expectedReconstructionCoverageSubText, "Reconstruction coverage amount subtext check");
            } else {
                KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
                knockoutInconveniencePage.validateHRCKnockOuts(sa);
            }
        }
    }

    public String  getTheQualityGradeFromAppStore() throws Exception {
        List<AppStore.Home.Field> qualityGradeField = getSessionStorageAppStore().getHome().getQualityGradeForm().getFields().stream().filter(i -> i.getFieldName().equals("qualityGrade")).collect(Collectors.toList());
        return qualityGradeField.get(0).getValues().get(0).getWebDesc();
    }

    public void clickOnEditCoverageLink() {
        waitAndClickElement(editCoverageAndQualityGraderButtonLink);
        if (!isElementDisplayed(updateHomeQualityGradeModalDialog, 2)) {
            waitAndClickElement(editCoverageAndQualityGraderButtonLink);
        }
        waitElementBeVisibleClickable(reconstructionCoverageAmountLabel);
    }

    public void clickOnLearnMoreLink() {
        if (!isUseMobileViewEnabled()) {
            waitAndClickElement(dwellingCoverageLearnMoreLinkDesktop, 5);
        } else {
            waitAndClickElement(dwellingCoverageInfoIconMobile, 5);
            waitAndClickElement(dwellingCoverageLearnMoreLinkMobile, 5);
        }
    }

    public void clickOnStandardQualityGradeHintIcon() {
        waitAndClickElement(standardHomeQualityGradeHintIcon);
    }

    public void clickOnEditYourQualityGradeLink() {
        waitElementBeVisibleClickable(editYourQualityGradeLink);
        waitAndClickElement(editYourQualityGradeLink);
    }

    public void clickOnUpgradeButton() {
        waitAndClickElement(upgradeGradeButton);
    }

    public void clickOnCancelGradeLink() {
        waitAndClickElement(cancelGradeButton);
    }

    public void clickOnCloseIconOnLearnMoreSideSheet() {
        waitAndClickElement(closeIconOnLearnMoreSideSheet);
    }

    public void clickOnCloseIconDwellingCoverageSideSheet() {
        waitAndClickElement(dwellingListCloseIcon);
    }

    public void clickOnCloseIconEditHomeQualityGradeSideSheet() {
        waitAndClickElement(editHomeQualityGradeCloseIcon);
    }

    List<String> getTheExpectedReconstructionCoverageInInteger(String reconstructionCostString) {
        List<Double> reconstructionCostLessThanMillion = new ArrayList<>();
        List<String> reconstructionCostInCurrencyFormat = new ArrayList<>();
        double reconstructionCost = Integer.parseInt(reconstructionCostString);
        addIntoReconstructionCostArrayIfEligible(reconstructionCost, reconstructionCostLessThanMillion);

        double tenPercentReconstructionCoverageAmount = Math.round(Math.ceil(reconstructionCost + reconstructionCost * 0.1) / 1000) * 1000;
        addIntoReconstructionCostArrayIfEligible(tenPercentReconstructionCoverageAmount, reconstructionCostLessThanMillion);
        double twentyPercentReconstructionCoverageAmount = Math.round(Math.ceil(reconstructionCost + reconstructionCost * 0.2) / 1000) * 1000;
        addIntoReconstructionCostArrayIfEligible(twentyPercentReconstructionCoverageAmount, reconstructionCostLessThanMillion);
        if (!reconstructionCostLessThanMillion.isEmpty()) {
            reconstructionCostInCurrencyFormat = reconstructionCostLessThanMillion.stream().map(i -> getCurrencyFormatWithoutDecimal(String.valueOf(i))).collect(Collectors.toList());
        }
        return reconstructionCostInCurrencyFormat;
    }

    void addIntoReconstructionCostArrayIfEligible(double reconstructionCost, List<Double> reconstructionCostLessThanMillion) {
        if (reconstructionCostLessThanMillion.stream().noneMatch(i -> i.equals(ONEMILLION))) {
            reconstructionCostLessThanMillion.add(reconstructionCost);
        }
    }

    String getCurrencyFormatWithoutDecimal(String currency) {
        return CurrencyFormat.convertStringIntoCurrencyFormat(currency).replace(".00", "");
    }

    public String getTheReconstructionCostFromAppStore() throws Exception {
        return getSessionStorageAppStore().getHome().getReconstructionCost();
    }

    public String getDwellingCoverageCostFromAppStoreInCurrencyFormat(AppStore appStore) {
        return CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(appStore.getHome().getDwellingCoverage());
    }
    public String getUpdatedReconstructionCostCostFromAppStoreInCurrencyFormat(String updatedReconstructionAmount) {
        return CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(updatedReconstructionAmount);
    }
    public List<String> getListOfReconstructionCoverageAmountLabels(){
        return reconstructionCoverageAmountLabels.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }
    public List<String> getListOfReconstructionCoverageAmountLabelsSubText(){
        return reconstructionCoverageAmountLabelsSubText.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public String getReconstructionCostFromAppStoreInCurrencyFormat() throws Exception {
        return CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(getSessionStorageAppStore().getHome().getReconstructionCost());
    }

    public void updateReconstructionRadioButtonAndValidateUpdatedCost(FarmersSoftAssert sa) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        int count = reconstructionCoverageAmountInputRadioButtons.size();
        for (int i = 1; i < count; i++) {
            // Edit the reconstruction cost and click on cancel
            scrollAndClickOnHiddenElement(reconstructionCoverageAmountInputRadioButtons.get(i));
            clickOnCancelLinkDwellingCovAndGradeSideSheet();
//            clickOnExitWithoutSavingButton();
            validateDwellingCoverageDetailsSection(sa, appStore);

            // Edit the reconstruction cost and click on close icon, validate content of exit without saving pop up
            clickOnEditCoverageLink();
            scrollAndClickOnHiddenElement(reconstructionCoverageAmountInputRadioButtons.get(i));
            clickOnCloseIconDwellingCoverageSideSheet();
            validateContentOfExitWithoutSavingPopUp(sa);
            clickOnExitWithoutSavingButton();
            validateDwellingCoverageDetailsSection(sa, appStore);
            clickOnEditCoverageLink();
            scrollAndClickOnHiddenElement(reconstructionCoverageAmountInputRadioButtons.get(i));
            clickOnCloseIconDwellingCoverageSideSheet();
            clickOnContinueEditingLink();
            clickOnCancelLinkDwellingCovAndGradeSideSheet();
           // clickOnExitWithoutSavingButton();

            // Edit the reconstruction cost and click on save button, validate content of main dwelling coverage page
            clickOnEditCoverageLink();
            scrollAndClickOnHiddenElement(reconstructionCoverageAmountInputRadioButtons.get(i));
            clickOnSaveButtonDwellingCovAndGradeSideSheet();
            validateDwellingCoverageDetailsSection(sa, appStore);
            clickOnEditCoverageLink();
        }
        scrollAndClickOnHiddenElement(reconstructionCoverageAmountInputRadioButtons.get(0));
        clickOnSaveButtonDwellingCovAndGradeSideSheet();
    }
    public void validateBrowserForwardButtonIsDisableAfterUpdatingCustomCoveragePage(FarmersSoftAssert sa, String lobType) throws Exception {
        driver().navigate().forward();
        sa.assertTrue(driver().getCurrentUrl().contains("custom-coverage"), "Browser forward button is disable - " + lobType);
    }
    public void clickOnSaveButtonDwellingCovAndGradeSideSheet() {
        waitAndClickElement(saveButtonOnDwellingCovSideSheet);
    }

    public void clickOnCancelLinkDwellingCovAndGradeSideSheet() {
        waitAndClickElement(cancelButtonOnDwellingCovSideSheet);
    }

    public void clickOnKeepPreviousSelectionLink() {
        waitAndClickElement(keepPreviousGradeLink);
    }

    public void clickOnUpdateGradeButtonInPopUp() {
        waitAndClickElement(updateGradeButtonInPopup);
    }

    public void clickOnExitWithoutSavingButton() {
        waitAndClickElement(exitWithoutSavingButton);
    }

    public void clickOnContinueEditingLink() {
        waitAndClickElement(continueEditingLink);
    }

    public void clickOnBackIconButtonFromSideSheet() {
        waitAndClickElement(backIconOnEditQualityGradeSideSheet);
    }

    public void validateContentOfEditHomeQualityGradeSideSheet(FarmersSoftAssert sa) throws Exception {
        AppStore appStore = getSessionStorageAppStore();

        validateHeadersSubtextFooterTextInEditHomeQualityGradeSideSheet(sa);

        validateHomeQualityGradeRadioButtonsAndSubtext(sa);

        if (homeQualityGradeMatRadioButtons.size() > 1) {
            scrollAndClickOnHiddenElement(homeQualityGradeInputRadioButtons.get(1));
            sa.assertTrue(upgradeGradeButton.isDisplayed(), "Upgrade grade button is not displayed on edit home grade side sheet.");
            sa.assertTrue(cancelGradeButton.isDisplayed(), "Cancel link is not displayed on edit home grade side sheet.");

            waitAndClickElement(backIconOnEditQualityGradeSideSheet);
            checkIfDwellingCoverageAndGradeSideSheetDisplayed(sa);

            clickOnEditYourQualityGradeLink();
            scrollAndClickOnHiddenElement(homeQualityGradeInputRadioButtons.get(1));
            clickOnCloseIconEditHomeQualityGradeSideSheet();
            validateContentOfExitWithoutSavingPopUp(sa);
            clickOnExitWithoutSavingButton();
            checkIfDwellingCoverageAndGradeSideSheetDisplayed(sa);

            clickOnEditYourQualityGradeLink();
            scrollAndClickOnHiddenElement(homeQualityGradeInputRadioButtons.get(1));
            clickOnCloseIconEditHomeQualityGradeSideSheet();
            clickOnContinueEditingLink();

            clickOnCancelGradeLink();
            checkIfDwellingCoverageAndGradeSideSheetDisplayed(sa);
            clickOnEditYourQualityGradeLink();
            scrollAndClickOnHiddenElement(homeQualityGradeInputRadioButtons.get(1));
            clickOnUpgradeButton();
            validateUpdateHomeQualityGradePopUpContent(sa, UPDATE_HOME_QUALITY_GRADE_ACTION_DESCRIPTION);

            clickOnKeepPreviousSelectionLink();
            checkIfDwellingCoverageAndGradeSideSheetDisplayed(sa);
            clickOnEditYourQualityGradeLink();
            scrollAndClickOnHiddenElement(homeQualityGradeInputRadioButtons.get(1));
            clickOnUpgradeButton();
            clickOnUpdateGradeButtonInPopUp();
            waitForSpinnerToBeGone();
            validateContentOfReconstructionCostAndSubtext(sa);
        }

    }

    public void checkIfDwellingCoverageAndGradeSideSheetDisplayed(FarmersSoftAssert sa) {
        waitElementBeVisible(dwellingCoverageSideSheet);
        sa.assertTrue(dwellingCoverageSideSheet.isDisplayed(), "Dwelling coverage side sheet open on clicking cancel button on edit home quality grade side sheet.");
    }

    public void validateUpdateHomeQualityGradePopUpContent(FarmersSoftAssert sa, String expectedUpdateHomeQualityGradeActionDescription) {

        String expectedUpdateHomeQualityGradeTitle = "Update home quality grade";
        sa.assertEquals(getTextFromElement(updateHomeQualityGradeTitle), expectedUpdateHomeQualityGradeTitle, "Update home quality grade title check");

        sa.assertEquals(getTextFromElement(updateHomeQualityGradeActionDescription), expectedUpdateHomeQualityGradeActionDescription, "Update home quality grade action description check");

        sa.assertTrue(keepPreviousGradeLink.isDisplayed(), "Keep previous grade link displayed");
        sa.assertTrue(updateGradeButtonInPopup.isDisplayed(), "Keep previous grade link displayed");
    }

    public void validateContentOfExitWithoutSavingPopUp(FarmersSoftAssert sa) {
        waitElementBeVisible(unsavedChangesModalDialogue);
        sa.assertTrue(unsavedChangesModalDialogue.isDisplayed(), "Unsaved changes dialogue box displayed.");

        String expectedExitWithoutSavingText = "Exit without saving?";
        sa.assertEquals(getTextFromElement(unsavedChangesModalTitle), expectedExitWithoutSavingText, "Exit without savings title check");

        String expectedChangesNotSavedText = "Changes that you made have not been saved yet.";
        sa.assertEquals(getTextFromElement(changesHaveNotBeenSavedText), expectedChangesNotSavedText, "Changes have not been saved text check");

        String expectedExitWithoutSavingButtonText = "Yes, exit without saving";
        sa.assertTrue(exitWithoutSavingButton.isDisplayed(), "Exit without saving button is not displayed.");
        sa.assertEquals(getTextFromElement(exitWithoutSavingButton), expectedExitWithoutSavingButtonText, "Exit without saving button text check");

        String expectedContinueEditingButtonText = "No, continue editing";
        sa.assertTrue(continueEditingLink.isDisplayed(), "Continue editing button is not displayed.");
        sa.assertEquals(getTextFromElement(continueEditingLink), expectedContinueEditingButtonText, "Continue editing button text check.");
    }

    public void validateHeadersSubtextFooterTextInEditHomeQualityGradeSideSheet(FarmersSoftAssert sa) {
        sa.assertTrue(backIconOnEditQualityGradeSideSheet.isDisplayed(), "Back icon displayed on edit home quality grade side sheet.");
        sa.assertTrue(editHomeQualityGradeCloseIcon.isDisplayed(), "Close icon displayed");
        sa.assertTrue(homeQualityGradeDottedDivider.isDisplayed(), "Dotted line displayed in quality grade home side sheet");

        String expectedHomeQualityGradeHeader = "Edit home quality grade";
        sa.assertEquals(getTextFromElement(editHomeQualityGradeHeader), expectedHomeQualityGradeHeader, "Expected edit home quality grade header check");

        String expectedHomeQualityGradeSubHeader = "Home quality grade";
        sa.assertEquals(getTextFromElement(editHomeQualityGradeSubHeader), expectedHomeQualityGradeSubHeader, "Home quality grade header check");

        String expectedHomeQualityGradeText = "Note: Changing your quality grade will impact your dwelling coverage options.";
        sa.assertEquals(getTextFromElement(homeQualityGradeNote), expectedHomeQualityGradeText, "Home quality grade check");
    }

    public void validateHomeQualityGradeRadioButtonsAndSubtext(FarmersSoftAssert fsa) throws Exception {
        String qualityGradeFromAppStore = getTheQualityGradeFromAppStore();

        String matRadioButtonCountForQualityGradeNotMatchingMsg = "Home quality grade radio button size check for " + qualityGradeFromAppStore + ".";
        String matRadioButtonLabelTextForQualityGradeNotMatchingMsg = "Home quality grade radio button label text check for " + qualityGradeFromAppStore + ".";
        String matRadioButtonDescriptionTextForQualityGradeNotMatchingMsg = "Home quality grade radio button description text check for " + qualityGradeFromAppStore + ".";

        List<String> homeQualityGradeRadioLabelText = homeQualityGradeRadioButtonLabels.stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());
        List<String> homeQualityGradeRadioDescriptionText = homeQualityGradeRadioButtonDescriptions.stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());

        switch (qualityGradeFromAppStore) {
            case ECONOMY_QUALITY_GRADE:
                fsa.assertTrue(homeQualityGradeMatRadioButtons.size() == 5, matRadioButtonCountForQualityGradeNotMatchingMsg);
                fsa.assertTrue(homeQualityGradeRadioLabelText.equals(EXPECTED_QUALITY_GRADE_LABELS_ECONOMY), matRadioButtonLabelTextForQualityGradeNotMatchingMsg);
                fsa.assertTrue(homeQualityGradeRadioDescriptionText.equals(EXPECTED_QUALITY_GRADE_DESCRIPTION_ECONOMY), matRadioButtonDescriptionTextForQualityGradeNotMatchingMsg);
                break;

            case STANDARD_QUALITY_GRADE:
                fsa.assertTrue(homeQualityGradeMatRadioButtons.size() == 4, matRadioButtonCountForQualityGradeNotMatchingMsg);
                fsa.assertTrue(homeQualityGradeRadioLabelText.equals(EXPECTED_QUALITY_GRADE_LABELS_STANDARD), matRadioButtonLabelTextForQualityGradeNotMatchingMsg);
                fsa.assertTrue(homeQualityGradeRadioDescriptionText.equals(EXPECTED_QUALITY_GRADE_DESCRIPTION_STANDARD), matRadioButtonDescriptionTextForQualityGradeNotMatchingMsg);
                break;

            case ABOVE_AVG_QUALITY_GRADE:
                fsa.assertTrue(homeQualityGradeMatRadioButtons.size() == 3, matRadioButtonCountForQualityGradeNotMatchingMsg);
                fsa.assertTrue(homeQualityGradeRadioLabelText.equals(EXPECTED_QUALITY_GRADE_LABELS_ABOVE_AVG), matRadioButtonLabelTextForQualityGradeNotMatchingMsg);
                fsa.assertTrue(homeQualityGradeRadioDescriptionText.equals(EXPECTED_QUALITY_GRADE_DESCRIPTION_ABOVE_AVG), matRadioButtonDescriptionTextForQualityGradeNotMatchingMsg);
                break;

            case CUSTOM_QUALITY_GRADE:
                fsa.assertTrue(homeQualityGradeMatRadioButtons.size() == 2, matRadioButtonCountForQualityGradeNotMatchingMsg);
                fsa.assertTrue(homeQualityGradeRadioLabelText.equals(EXPECTED_QUALITY_GRADE_LABELS_CUSTOM), matRadioButtonLabelTextForQualityGradeNotMatchingMsg);
                fsa.assertTrue(homeQualityGradeRadioDescriptionText.equals(EXPECTED_QUALITY_GRADE_DESCRIPTION_CUSTOM), matRadioButtonDescriptionTextForQualityGradeNotMatchingMsg);
                break;

            case PREMIUM_QUALITY_GRADE:
                fsa.assertTrue(homeQualityGradeMatRadioButtons.size() == 1, matRadioButtonCountForQualityGradeNotMatchingMsg);
                fsa.assertTrue(homeQualityGradeRadioLabelText.equals(EXPECTED_QUALITY_GRADE_LABELS_PREMIUM), matRadioButtonLabelTextForQualityGradeNotMatchingMsg);
                fsa.assertTrue(homeQualityGradeRadioDescriptionText.equals(EXPECTED_QUALITY_GRADE_DESCRIPTION_PREMIUM), matRadioButtonDescriptionTextForQualityGradeNotMatchingMsg);
                break;

            default:
                Log.warn("Unexpected quality grade: " + qualityGradeFromAppStore);
                break;
        }
    }

    public void fillOutDwellingCoveragePage(ApplicantAceHome applicantAceHome) throws Exception {
        if (!applicantAceHome.isKeep360Prefill()) {
            clickOnEditCoverageLink();
            if (homeQualityGradeMatRadioButtons.size() > 1) {
                scrollAndClickOnHiddenElement(homeQualityGradeInputRadioButtons.get(1));
                clickOnSaveButtonDwellingCovAndGradeSideSheet();
            }
        }
        clickContinueButton();
    }

    public void changeDwellingCoverage() {
        clickOnEditCoverageLink();
        waitAndClickElement(coverageUncheckedRadioButtonLabel);
        clickOnSaveButtonDwellingCovAndGradeSideSheet();
        scrollAndClickOnElement(continueButton);
    }

    public String getDwellingCoverageAmount() {
        return getTextFromElement(dwellingCoverageAmount);
    }

    public String getDwellingCoverageQualityGrade() {
        return getTextFromElement(dwellingCoverageQualityGrade);
    }

    public void validateADA() throws InterruptedException {
        clickOnEditCoverageLink();
        performADATesting(this.getClass().getSimpleName(),MARKETING_IT,FFQ_ACE_HOME);
        clickOnCloseIconDwellingCoverageSideSheet();
    }

    public boolean isOnRC2LoadingPage(int timeoutInSeconds) {
        return isElementVisible(rc2Screen_MainHeading, timeoutInSeconds);
    }

    public void validateRC2LoadingScreen(FarmersSoftAssert fsa) throws Exception {
        String checkingEligibility = "Checking eligibility";
        String calculatingYourRate = "Calculating your rate";
        String finishingUp = "Finishing up";

        fsa.assertTrue(isOnRC2LoadingPage(10), "User is on the RC2 Loading page.");

        //validating Page content
        fsa.assertEquals(getTextFromElement(rc2Screen_MainHeading), ONE_MOMENT_PLEASE, "RC2 Loading page main heading check");
        fsa.assertEquals(getTextFromElement(rc2SubHeading), RC2_PAGE_SUBTITLE, "RC2 Loading page sub heading check");
        fsa.assertTrue(isElementDisplayed(PWBy.xpath(String.format("//span[@class='rc2_loading_screen_label_text' and contains(.,'%s')]", checkingEligibility))), checkingEligibility + " text is present");
        fsa.assertTrue(isElementDisplayed(PWBy.xpath(String.format("//span[@class='rc2_loading_screen_label_text' and contains(.,'%s')]", calculatingYourRate))), calculatingYourRate + " text is present");
        fsa.assertTrue(isElementDisplayed(PWBy.xpath(String.format("//span[@class='rc2_loading_screen_label_text' and contains(.,'%s')]", finishingUp))), finishingUp + " text is present");
        testStep("RC2 Loading page content validation");
    }
}