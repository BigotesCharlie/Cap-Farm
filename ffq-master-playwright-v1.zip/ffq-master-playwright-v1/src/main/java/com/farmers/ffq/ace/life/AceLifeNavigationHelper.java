package com.farmers.ffq.ace.life;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.datatransferobjects.ApplicantLife;
import com.farmers.framework.report.Reporter;

import lombok.Getter;
import lombok.Setter;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Setter
@Getter
public class AceLifeNavigationHelper extends BasePage {
	private static final String ACE_LIFE = "Ace Life - ";
	private static final String DID_NOT_REACH = "Did not reach ";
	private static final String FOR_QUOTE = " for quote ";

	@PWFindBy(xpath = "//tui-oneui-footer")
	private PWElement footer;

	private String pageToResumeFrom;
	private String lifeQuoteNumber = EMPTY_STRING;

	public AceLifeNavigationHelper() throws Exception {
		super();
		pageToResumeFrom = EMPTY_STRING;
	}

	public AceLifeReviewQuotePage navigateToAceLifeReviewQuotePage(ApplicantLife applicant) throws Exception {
		AceLifeReviewQuotePage reviewQuotePage = new AceLifeReviewQuotePage();
		if (getPageToResumeFrom().equals(reviewQuotePage.getClass().getSimpleName())) {
			return reviewQuotePage;
		}
		AceLifePersonalInfoPage personalInfoPage = navigateToAceLifePersonalInfoPage(applicant);
		personalInfoPage.enterDataAndContinueToReviewQuotePage(applicant);
		waitForSpinnerToBeGone();
		reviewQuotePage.waitForSkeletonToBeGone();
		if (reviewQuotePage.isOnReviewQuotePage()) {
			Reporter.pass("Navigated to Review Quote page");
			writeRatedQuoteInformationToFile(ACE_LIFE + getLifeQuoteNumber() + SPACE + applicant.toString() + " Age: " + applicant.getAge());
			if (isADATestingEnabled()) {
				performADATesting(reviewQuotePage.getClass().getSimpleName(), MARKETING_IT, FFQ_ACE_LIFE);
				screenCapture(footer, reviewQuotePage.getClass().getSimpleName(), LARGE, false);
			}
			return reviewQuotePage;
		} else {
			writeDataToKnockoutLogFile(ACE_LIFE + getLifeQuoteNumber() + SPACE + applicant.toString());
			throw new IllegalStateException(DID_NOT_REACH + reviewQuotePage.getClass().getSimpleName() + FOR_QUOTE + getLifeQuoteNumber() + NEWLINE);
		}
	}

	public AceLifePersonalInfoPage navigateToAceLifePersonalInfoPage(ApplicantLife applicant) throws Exception {
		AceLifePersonalInfoPage personalInfoPage = new AceLifePersonalInfoPage();
		if (getPageToResumeFrom().equals(personalInfoPage.getClass().getSimpleName())) {
			return personalInfoPage;
		}
		AceLifeNameAndDOBPage nameAndDOBPage = navigateToAceLifeNameAndDOBPage(applicant);
		nameAndDOBPage.enterDataAndContinueToPersonalInfoPage(applicant);
		waitForSpinnerToBeGone();
		if (personalInfoPage.isOnPersonalInfoPage()) {
			Reporter.pass("Navigated to Personal Information page");
			if (isADATestingEnabled()) {
				personalInfoPage.clickOnAgreeAndSubmitButton();
				performADATesting(personalInfoPage.getClass().getSimpleName(), MARKETING_IT, FFQ_ACE_LIFE);
			}
			screenCapture(footer, "AceLife_PersonalInfoPage", LARGE, true);
			return personalInfoPage;
		} else {
			writeDataToKnockoutLogFile(ACE_LIFE + getLifeQuoteNumber() + SPACE + applicant.toString());
			throw new IllegalStateException(DID_NOT_REACH + personalInfoPage.getClass().getSimpleName() + FOR_QUOTE + getLifeQuoteNumber() + NEWLINE);
		}
	}

	public AceLifeNameAndDOBPage navigateToAceLifeNameAndDOBPage(ApplicantLife applicant) throws Exception {
		AceLifeNameAndDOBPage nameAndDOBPage = new AceLifeNameAndDOBPage();
		if (getPageToResumeFrom().equals(nameAndDOBPage.getClass().getSimpleName())) {
			return nameAndDOBPage;
		}
		processLandingPage(applicant);
		if (!nameAndDOBPage.isOnNameAndDOBPage() && isElementPresent(PWBy.className("preload-resources-container"), 3)) {
			// Page did not render let's refresh and hope that fixes it...
			driver().navigate().refresh();
			Reporter.pass("Name and DOB page did not render, refreshing page");
			waitForSpinnerToBeGone();
		}
		setLifeQuoteNumber(getQuoteNumberFromStorage());
		if (nameAndDOBPage.isOnNameAndDOBPage()) {
			writeCreatedQuoteInformationToFile(ACE_LIFE + getLifeQuoteNumber() + SPACE + applicant.toString());
			Reporter.pass("Navigated to Name and DOB page for quote " + getLifeQuoteNumber());
			if (isADATestingEnabled()) {
				nameAndDOBPage.clickOnContinueButton();
				performADATesting(nameAndDOBPage.getClass().getSimpleName(), MARKETING_IT, FFQ_ACE_LIFE);
				screenCapture(footer, nameAndDOBPage.getClass().getSimpleName(), MEDIUM, false);
			}
			return nameAndDOBPage;
		} else {
			writeDataToKnockoutLogFile(ACE_LIFE + getLifeQuoteNumber() + SPACE + applicant.toString());
			throw new IllegalStateException(DID_NOT_REACH + nameAndDOBPage.getClass().getSimpleName() + FOR_QUOTE + getLifeQuoteNumber() + NEWLINE);
		}
	}

	private void processLandingPage(ApplicantLife applicant) throws Exception {
		if (applicant.getId().equals(AWS_SCENARIOS)) {
			new LandingPage(applicant);
			Reporter.pass("Application launched in AWS mode");
		} else {
			new LandingPage(isUseMobileViewEnabled(), true).enterLandingPageData(LOB_LIFE, applicant.getZipCode());
		}
		waitForSpinnerToBeGone();
	}

	private String getQuoteNumberFromStorage() throws Exception {
		if (getItemFromSessionStorage("appStore")!= null) {
			return getSessionStorageAppStore().getData().getQuoteNumber();
		} else {
			return EMPTY_STRING;
		}
	}
}
