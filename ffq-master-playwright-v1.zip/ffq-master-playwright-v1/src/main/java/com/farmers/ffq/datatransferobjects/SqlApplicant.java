/**
=============================================
* Author:	Zhabiz Sonee
* Create date:	05/01/2017
=============================================
*/
package com.farmers.ffq.datatransferobjects;

import com.farmers.framework.report.Log;

import java.util.List;
import lombok.Data;

@Data
public class SqlApplicant {
	private int applicantId;
	private String testCategory;
	private String testScenario;
	private String gender;	
	private String residentAddress1;
	private String residentAddress2;
	private String city;
	private String zipCode;
	private String stateCode;
	private String stateName;
	private String maritalStatus;
	private String occupation;
	private String currentlyInsuredStatus;
	private String currentInsuranceCompany;
	private String continuosInsurancePeriod;
	private String currentBodilyInjuryLimit;
	private String financialFiling;	
	private String firstName;
	private String lastName;
	private int age;
	private String otherOccupation;
	private String dateOfBirth;
	private boolean mailingAddressDifferent;
	private boolean currentlyHaveAutoInsurance;
	private String principalPIP;
	private int firstAgeUnitedStatesDriverLicense;	
	private int firstAgeForeignDriverLicense;	
	private boolean fullTimeStudentWithHighGPA;
	private String email;
	private String phoneNumber;
	private String phoneExtentionNumber;
	private boolean knockoutExpected;
	private boolean completedDriversSafetyCourse;
	private boolean havePersonalInjuryLoss;
	private boolean haveAccidentOrViolations;
	private String currentInsuranceExpirationDate;
	private String driversLicense;
	private String licenseIssueStateName;
	private boolean attemptToBind;
	private String garagingAddress;
	private String sameStateZip;
	private boolean saveAndRetrieveVehiclesPage;
	private boolean saveAndRetrieveDriversPage;
	private boolean saveAndRetrieveDiscountsPage;
	private boolean saveAndRetrieveQuotePage;
    private ApplicantRetQuote applicantRetQuote;
    
    // Links to other data sheets
	private List<SqlAdditionalDriver> additionalDrivers;
	private List<SqlIncident> incidents;
	private List<SqlVehicle> vehicles;
	private SqlDiscount discounts;
	private SqlPayment payment;
	private SqlRepresentative representative;
	
	/**
	 * String Representation of Applicant class.
	 */
	public String toString() {
		return String.format("#%d - %s in %s: %s", applicantId, testCategory, stateCode, testScenario);
	}

	public String logInformationString() {
        return String.format("#%d: %s %s %s %s %s %s", applicantId, firstName, lastName, residentAddress1, city, stateCode, zipCode);
	}

	public void dump() {
		Log.warn("\nAPPLICANT: " +
				applicantId + "," + 
				testCategory + "," + 
				testScenario + "," + 
				gender + "," + 	
				residentAddress1 + "," + 
				residentAddress2 + "," + 
				city + "," + 
				zipCode + "," + 
				stateCode + "," + 
				stateName + "," + 
				maritalStatus + "," + 
				occupation + "," + 
				currentlyInsuredStatus + "," + 
				currentInsuranceCompany + "," + 
				continuosInsurancePeriod + "," + 
				currentBodilyInjuryLimit + "," + 
				financialFiling + "," + 	
				firstName + "," + 
				lastName + "," + 
				age + "," + 
				otherOccupation + "," + 
				dateOfBirth + "," + 
				mailingAddressDifferent + "," + 
				currentlyHaveAutoInsurance + "," + 
				principalPIP + "," + 
				firstAgeUnitedStatesDriverLicense + "," + 	
				firstAgeForeignDriverLicense + "," + 	
				fullTimeStudentWithHighGPA + "," + 
				email + "," + 
				phoneNumber + "," + 
				phoneExtentionNumber + "," +
				completedDriversSafetyCourse + "," + 
				havePersonalInjuryLoss + "," + 
				haveAccidentOrViolations + "," + 
				currentInsuranceExpirationDate + "," + 
				driversLicense + "," + 
				licenseIssueStateName + "," + 
				attemptToBind + "," + 
				garagingAddress);
		int moreDrivers = additionalDrivers.size();
			for (int i=0; i < moreDrivers; i++) {
				Log.warn("ADDITIONAL DRIVER " + i + ": " +
						additionalDrivers.get(i).getAdditionalDriverId() + "," + 
						additionalDrivers.get(i).getIncidentId() + "," + 
						additionalDrivers.get(i).getFirstName() + "," + 
						additionalDrivers.get(i).getLastName() + "," + 
						additionalDrivers.get(i).getAge() + "," + 
						additionalDrivers.get(i).getDateOfBirth() + "," + 
						additionalDrivers.get(i).getRelationshipToApplicant() + "," + 
						additionalDrivers.get(i).getMaritalStatus() + "," + 
						additionalDrivers.get(i).getGender() + "," + 
						additionalDrivers.get(i).getOccupation() + "," + 
						additionalDrivers.get(i).getOtherOccupation() + "," + 
						additionalDrivers.get(i).getLicenseToDriveInUSA() + "," + 
						additionalDrivers.get(i).getFirstAgeUnitedStatesDriverLicense() + "," + 
						additionalDrivers.get(i).getFirstAgeForeignDriverLicense() + "," + 
						additionalDrivers.get(i).isFullTimeStudentWithHighGPA() + "," + 
						additionalDrivers.get(i).isCompletedDriversSafetyCourse() + "," + 
						additionalDrivers.get(i).getFinancialFiling() + "," + 
						additionalDrivers.get(i).isAnyIncident() + "," + 
						additionalDrivers.get(i).getDriversLicense() + "," + 
						additionalDrivers.get(i).getLicenseIssueStateName());
			}
		int vehicleCount = vehicles.size();
			for (int i=0; i < vehicleCount; i++) {
				Log.warn("VEHICLE " + i + ": " +
						vehicles.get(i).getVehicleId() + "," + 
						vehicles.get(i).getVehicleStateCode() + "," + 
						vehicles.get(i).getVehicleYear() + "," + 
						vehicles.get(i).getVehicleMake() + "," + 
						vehicles.get(i).getVehicleModel() + "," + 
						vehicles.get(i).getVehicleVIN() + "," + 
						vehicles.get(i).getVehicleType() + "," + 
						vehicles.get(i).getOwnership() + "," + 
						vehicles.get(i).getPurchaseDate() + "," + 
						vehicles.get(i).getVehicleUsage() + "," + 
						vehicles.get(i).getOneWayMiles() + "," + 
						vehicles.get(i).getCommute() + "," + 
						vehicles.get(i).getAnnualMiles() + "," + 
						vehicles.get(i).isParkInresidentAddress() + "," + 
						vehicles.get(i).isRideSharing() + "," + 
						vehicles.get(i).isAlternativeFuels() + "," + 
						vehicles.get(i).isPassiveRestraint() + "," + 
						vehicles.get(i).isAntiLockBrakes() + "," + 
						vehicles.get(i).isTheftRecoverySystem() + "," + 
						vehicles.get(i).getLessorStateName() + "," + 
						vehicles.get(i).getLessor() + "," + 
						vehicles.get(i).getCurrentOdometerReading() + "," + 
						vehicles.get(i).getDateOfReading());	
			}
		int incidentCount = incidents.size();
			for (int i=0; i < incidentCount; i++) {
				Log.warn("INCIDENT " + i + ": " +
						incidents.get(i).getIncidentId() + "," + 
						incidents.get(i).getAdditionalDriverId() + "," + 
						incidents.get(i).getIncidentType() + "," + 
						incidents.get(i).getDescription() + "," + 
						incidents.get(i).getDateOccuredOffsetInDays() + "," + 
						incidents.get(i).getDateOccured() + "," + 
						incidents.get(i).isAnyInjuries());
		}
			if (discounts != null) {
				Log.warn("DISCOUNTS: " +
						discounts.getDiscountId() + "," + 
						discounts.getPaymentMethod() + "," + 
						discounts.getStartDateOfNewPolicy() + "," + 
						discounts.isHomeInsurance() + "," + 
						discounts.isRentersInsurance() + "," + 
						discounts.isCondoInsurance() + "," + 
						discounts.isValueTermLifeInsurance() + "," + 
						discounts.isUmbrellaInsurance() + "," + 
						discounts.isBusinessInsurance() + "," + 
						discounts.getOwnOrRentHome() + "," + 
						discounts.getPaymentMethodForDiscount()); 
			}		
		if (payment != null) {
				Log.warn("PAYMENT: " +
						payment.getPaymentId() + "," + 
						payment.getPaymentPlan() + "," + 
						payment.getPaymentMethod() + "," + 
						payment.getAccountHolderName() + "," + 
						payment.getRoutingNumber() + "," + 
						payment.getBankAccountNumber() + "," + 
						payment.getBankName() + "," + 
						payment.getCreditCardType() + "," + 
						payment.getDebitCardType() + "," + 
						payment.getNameOnCard() + "," + 
						payment.getCardNumber() + "," + 
						payment.getExpirationDate() + "," + 
						payment.getBillingZipCode()); 

		}
		if (payment != null) {
				Log.warn("AGENT: " +
						representative.getRepresentativeId() + "," + 
						representative.getFullName() + "," + 
						representative.getAor() + "," + 
						representative.getZipCode()+ "," + 
						representative.getStateCode() + "," + 
						representative.getAddress());
		}
	}
}
