package com.farmers.ffq.datatransferobjects;


import nl.flotsam.xeger.Xeger;

public enum LicenseFormatByState {

    AL("([1-9]{7})"),

    AK("([1-9]{7})"),

    AZ("([A-Z]{1}[1-9]{8})"),

    AR("([1-9]{8})"),

    CA("([A-Z]{1}[1-9]{7})"),

    CO("([1-9]{9})"),

    CT("([1-9]{9})"),

    DC("([A-Z]{2}[1-9]{8})"),

    DE("([1-9]{7})"),

    FL("([A-Z]{1}[0-9]{11})"),

    GA("([1-9]{9})"),

    HI("([1-9]{9})"),

    ID("([A-Z]{2}[0-9]{6}[A-Z]{1})"),

    IL("([A-Z]{1}[1-9]{11})"),

    IN("(S[1-9]{9})"),

    IA("([1-9]{3}[A-Z]{2}[0-9]{4})"),

    KS("(K[0-9]{8})"),

    KY("([A-Z]{1}[0-9]{8})"),

    LA("([1-9]{9})"),

    ME("([1-9]{7})"),

    MD("([A-Z]{1}[0-9]{12})"),

    MA("(S[0-9]{8})"),

    MI("([A-Z]{1}[0-9]{12})"),

    MN("([A-Z]{1}[0-9]{12})"),

    MS("([1-9]{9})"),

    MO("([A-Z]{1}[0-9]{16})"),

    MT("([A-Z]{3}[0-9]{10})"),

    NE("([A-Z]{1}[0-9]{3})"),

    NV("([1-9]{10})"),

    NH("(NHL[0-9]{8})"),

    NJ("([A-Z]{1}[0-9]{14})"),

    NM("([1-9]{8})"),

    NY("([1-9]{9})"),

    NC("([1-9]{12})"),

    ND("([A-Z]{3}[0-9]{6})"),

    OH("([A-Z]{2}[0-9]{6})"),

    OK("([A-Z]{1}[0-9]{9})"),

    OR("(00[1-9]{7})"),

    PA("([1-9]{8})"),

    RI("(V[0-9]{6})"),

    SC("([1-9]{7})"),

    SD("([1-9]{9})"),

    TN("([1-9]{8})"),

    TX("([1-9]{8})"),

    UT("([1-9]{4})"),

    VT("([1-9]{8})"),

    VA("([1-9]{12})"),

    WA("([A-Z]{7}[1-9]{5})"),

    WV("([1-9]{7})"),

    WI("([A-Z]{1}[1-9]{13})"),

    WY("([1-9]{9})");

    // get the PNI license number by state
    static public String getLicenseNumberByState(String stateCode) {
        Xeger generator = new Xeger(LicenseFormatByState.valueOf(stateCode).licenseNumberFormat);
        return generator.generate();
    }


    public final String licenseNumberFormat;
    LicenseFormatByState(String licenseNumberFormat) {
        this.licenseNumberFormat = licenseNumberFormat;

    }
}

