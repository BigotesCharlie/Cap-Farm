package com.farmers.ffq.datatransferobjects;

import com.farmers.ffq.dataproviderframework.DataObjectBase;
import static com.farmers.ffq.utils.GlobalVariables.EMPTY_STRING;
import static com.farmers.ffq.utils.GlobalVariables.LOWERCASE_NULL;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ApplicantLife extends DataObjectBase {

    private String firstName;
    private String lastName;
    private int age;
    private String gender;
    private String address;
    private String apartment;
    private String city;
    private String stateCode;
    private String state;
    private String zipCode;
    private String mailingAddress;
    private String mailingApartment;
    private String mailingCity;
    private String mailingState;
    private String mailingZipCode;
    private String useTobacco;
    private String insuranceAmount;
    private String premiumYears;
    private String quoteWaiver;
    private String criticalIllnessAmount;
    private String emailAddress;
    private String phoneNumber;
    private String occupation;
    private boolean saveAndRetrieveMoreInfoPage;
    private boolean saveAndRetrieveQuotePage;
    private boolean saveAndRetrieveThankYouPage;
    private ApplicantRetQuote applicantRetQuote;

    /**
     * String Representation of Applicant class.
     */
    public String toString() {
    	String apt = (apartment.equals(LOWERCASE_NULL)? EMPTY_STRING : apartment);
        return String.format("%s %s %s %s %s %s %s", firstName,lastName, address, apt, city, state, zipCode );
    }

}

