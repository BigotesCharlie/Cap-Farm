package com.farmers.ffq.datatransferobjects.hqm;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

import static com.farmers.ffq.utils.GlobalVariables.SPACE;

public class StaticContentHQM {

    @JsonProperty("quoteNumber")
    private String quoteNumber;
    @JsonProperty("quote")
    private Quote quote;
    @JsonProperty("address")
    private Address address;
    @JsonProperty("discounts")
    private Discounts discounts;
    @JsonProperty("property")
    private Property property;
    @JsonProperty("quality")
    private Quality quality;
    @JsonProperty("ratesummary")
    private RateSummary rateSummary;
    @JsonProperty("property-details")
    private PropertyDetails propertyDetails;
    @JsonProperty("customer-info")
    private CustomerInfo customerInfo;
    @JsonProperty("contact-info")
    private ContactInfo contactInfo;
    @JsonProperty("coverages")
    private Coverages coverages;
    @JsonProperty("thankyou")
    private Thankyou thankyou;
    @JsonProperty("knockout")
    private Knockout knockout;
    @JsonProperty("error")
    private Error error;
    @JsonProperty("inconvenience")
    private Inconvenience inconvenience;
    @JsonProperty("maintenance")
    private Maintenance maintenance;
    @JsonProperty("exsisting-customer")
    private ExistingCustomer existingCustomer;


    public String getAddressTitle() {
        return !address.summary.headerTitles.isEmpty() ?
                address.summary.headerTitles.get(0).value.replace("<br/>","\n") : null;
    }

    public String getAddressCaption() {
        return address.summary.headerTitles.size() > 1 ?
                address.summary.headerTitles.get(1).value.replace("<br/>","\n") : null;
    }

    public String getAddressDisclaimer() {
        String disclaimer = null;
        if (!address.summary.disclaimerText.isEmpty()) {
            disclaimer = Objects.requireNonNull(address.summary.disclaimerText.stream()
                            .filter((va) -> va.name.equals("ADDRESS_DISCLAIMER")).findFirst().orElse(null)).value
                            .replace("<br> ", "\n").replace("<br>", "\n")
                            .replace("<br/><br/> ", "\n\n").replace(" <br/><br/>", "\n\n")
                            .replace("<br/> ", "\n\n").replace("<br/>", "\n").replace("</br/>", "");
            Pattern pattern = Pattern.compile("( )*(\\[privacy.+policy])+( )*", Pattern.CASE_INSENSITIVE);
            Pattern pattern2 = Pattern.compile("( )*(\\[privacy.+policies])+( )*", Pattern.CASE_INSENSITIVE);
            if (pattern.matcher(disclaimer).find()) {
                disclaimer = pattern.matcher(disclaimer).replaceFirst("\nPrivacy Policy\n");
            } else {
                disclaimer = pattern2.matcher(disclaimer).replaceFirst("\nPrivacy Policies\n");
            }
            disclaimer = disclaimer.replace("\u00a0", SPACE).trim();
        }
        return disclaimer;
    }

    public String getPropertyTitle() {
        return (!property.summary.headerTitles.isEmpty()) ?
                property.summary.headerTitles.get(0).value.replace("<br/>","\n") : null;
    }

    public String getPropertyCaption() {
        return (property.summary.headerTitles.size() > 1) ?
                property.summary.headerTitles.get(1).value.replace("<br/>","\n") : null;
    }

    public String getPropertyDisclaimer() {
        return property.summary.disclaimerText.get(0).value;
    }

    public List<String> getPropertyInfoContent() {
        List<String> infoTextList = new ArrayList<>();
        for (InfoContent infoText : property.summary.infoContent) {
            infoTextList.add(infoText.value.replace("<br/>", "\n"));
        }
        return infoTextList;
    }

    public String getQualityTitle() {
        return quality.summary.headerTitles.get(0).value.replace("<br/>","\n");
    }

    public String getQualityCaption() {
        return (quality.summary.headerTitles.size() > 1) ?
                quality.summary.headerTitles.get(1).value.replace("\u00a0[QUALITY_STAR]"," *") : null;
    }

    public String getQualityDisclaimer() {
        return (!quality.summary.disclaimerText.isEmpty()) ?
                quality.summary.disclaimerText.get(0).value.replace("[QUALITY_STAR_DISCLAIMER]","*") : null;
    }

    public String getPropertyDetailsTitle() {
        String pageTitle = null;
        if (!propertyDetails.summary.headerTitles.isEmpty()) {
            pageTitle = Objects.requireNonNull(propertyDetails.summary.headerTitles.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_H1")).findFirst().orElse(null)).value.replace("<br/>","\n").trim();
        }
        return pageTitle;
    }

    public String getPropertyDetailsCaption() {
        String pageCaption = null;
        if (!propertyDetails.summary.headerTitles.isEmpty()) {
            pageCaption = Objects.requireNonNull(propertyDetails.summary.headerTitles.stream()
                    .filter((va) -> va.name.equals("ROPERTY_DETAILS_H1_CAPTION")).findFirst().orElse(null)).value.trim();
        }
        return pageCaption;
    }

    public String getPropertyDetailsSubHeading() {
        String pageSubHeading = null;
        if (!propertyDetails.summary.headerTitles.isEmpty()) {
            pageSubHeading = Objects.requireNonNull(propertyDetails.summary.headerTitles.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_SUB_HEADING")).findFirst().orElse(null)).value.trim();
        }
        return pageSubHeading;
    }

    public List<InfoContent> getPropertyDetailsInfoContent() {
        return propertyDetails.summary.infoContent;
    }

    public String getPropertyDetailsHelpStories() {
        String helpStories = null;
        if (!propertyDetails.summary.infoContent.isEmpty()) {
            helpStories = Objects.requireNonNull(propertyDetails.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_STORIES")).findFirst().orElse(null)).value.trim();
        }
        return helpStories;
    }

    public String getPropertyDetailsHelpFoundationType() {
        String helpFoundation = null;
        if (!propertyDetails.summary.infoContent.isEmpty()) {
            helpFoundation = Objects.requireNonNull(propertyDetails.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_FT")).findFirst().orElse(null)).value;
        }
        return helpFoundation;
    }

    public String getPropertyDetailsHelpFinishedLevel() {
        String helpFinishedLevel = null;
        if (!propertyDetails.summary.infoContent.isEmpty()) {
            helpFinishedLevel = Objects.requireNonNull(propertyDetails.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_LEVEL")).findFirst().orElse(null)).value.trim();
        }
        return helpFinishedLevel;
    }

    public String getPropertyDetailsHelpExteriorWall() {
        String helpEWC = null;
        if (!propertyDetails.summary.infoContent.isEmpty()) {
            helpEWC = Objects.requireNonNull(propertyDetails.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_EWF")).findFirst().orElse(null)).value;
        }
        return helpEWC;
    }

    public String getPropertyDetailsHelpRoof() {
        String helpRoof = null;
        if (!propertyDetails.summary.infoContent.isEmpty()) {
            helpRoof = Objects.requireNonNull(propertyDetails.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_ROOF_COVER")).findFirst().orElse(null)).value.trim();
        }
        return helpRoof;
    }

    public String getPropertyDetailsHelpFloor() {
        String helpFloor = null;
        if (!propertyDetails.summary.infoContent.isEmpty()) {
            helpFloor = Objects.requireNonNull(propertyDetails.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_FC")).findFirst().orElse(null)).value;
        }
        return helpFloor;
    }

    public String getPropertyDetailsHelpHeating() {
        String helpHeating = null;
        if (!propertyDetails.summary.infoContent.isEmpty()) {
            helpHeating = Objects.requireNonNull(propertyDetails.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_HS")).findFirst().orElse(null))
                    .value.replace(SPACE + SPACE, SPACE);
        }
        return helpHeating;
    }

    public String getPropertyDetailsHelpFireplace() {
        String helpFireplace = null;
        if (!propertyDetails.summary.infoContent.isEmpty()) {
            helpFireplace = Objects.requireNonNull(propertyDetails.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_FIREPLACE")).findFirst().orElse(null)).value;
        }
        return helpFireplace;
    }

    public String getPropertyDetailsHelpGarage() {
        String helpGarage = null;
        if (!propertyDetails.summary.infoContent.isEmpty()) {
            helpGarage = Objects.requireNonNull(propertyDetails.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_GARAGE")).findFirst().orElse(null)).value;
        }
        return helpGarage;
    }

    public String getPropertyDetailsHelpGarageStyle() {
        String helpGarageStyle = null;
        if (!propertyDetails.summary.infoContent.isEmpty()) {
            helpGarageStyle = Objects.requireNonNull(propertyDetails.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_GS")).findFirst().orElse(null)).value.trim();
        }
        return helpGarageStyle;
    }

    public String getPropertyDetailsHelpUndergroundOilTank() {
        String helpOilTank = null;
        if (!propertyDetails.summary.infoContent.isEmpty()) {
            helpOilTank = Objects.requireNonNull(propertyDetails.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_TANK_OP")).findFirst().orElse(null)).value.trim();
        }
        return helpOilTank;
    }

    public String getPropertyDetailsHelpNumberOfUnitsAttached() {
        String helpNumberOfUnits = null;
        if (!propertyDetails.summary.infoContent.isEmpty()) {
            helpNumberOfUnits = Objects.requireNonNull(propertyDetails.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("PROPERTY_DETAILS_UNITS")).findFirst().orElse(null)).value.trim();
        }
        return helpNumberOfUnits;
    }

    public String getCustomerInfoTitle() {
        return (!customerInfo.summary.headerTitles.isEmpty()) ?
                customerInfo.summary.headerTitles.get(0).value.replace("<br/>","\n") : null;
    }

    public String getCustomerInfoCaption() {
        return (customerInfo.summary.headerTitles.size() > 1) ?
                customerInfo.summary.headerTitles.get(1).value : null;
    }

    public String getContactInfoTitle() {
        return contactInfo.summary.headerTitles.get(0).value.replace("<br/>","\n");
    }

    public String getContactInfoCaption() {
        return contactInfo.summary.headerTitles.get(1).value.replace("<br/> ","\n").replace("<br/>","\n");
    }

    public List<String> getContactInfoDisclaimer() {
        List<String> infoTextList = new ArrayList<>();
        for (DisclaimerText infoText : contactInfo.summary.disclaimerText) {
            infoText.value = infoText.value.contains("\"Next,\"") ? infoText.value.replace("\"Next,\"", "\"Next\",") : infoText.value;
            infoTextList.add(infoText.value.replace("\u00a0", SPACE));
        }
        return infoTextList;
    }

    public String getDiscountsTitle() {
        return (!discounts.summary.headerTitles.isEmpty()) ?
                discounts.summary.headerTitles.get(0).value.replace("<br/>","\n") : null;
    }

    public String getDiscountsCaption() {
        return (discounts.summary.headerTitles.size() > 1) ?
                discounts.summary.headerTitles.get(1).value : null;
    }

    public List<InfoContent> getDiscountsInfoContent() {
        return discounts.summary.infoContent;
    }

    public String getDiscountsInfoContentPD() {
        String helpDiscounts = null;
        if (discounts.summary.infoContent.size() > 1) {
            helpDiscounts = Objects.requireNonNull(discounts.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("DISCOUNTS_INFO_PD")).findFirst().orElse(null)).value;
        }
        return helpDiscounts;
    }

    public String getDiscountsInfoContentFIP() {
        String helpDiscounts = null;
        if (discounts.summary.infoContent.size() > 1) {
            helpDiscounts = Objects.requireNonNull(discounts.summary.infoContent.stream()
                    .filter((va) -> va.name.equals("DISCOUNTS_INFO_FIP")).findFirst().orElse(null)).value;
        }
        return helpDiscounts;
    }

    public String getQuoteTitle() {
        return quote.summary.headerTitles.get(0).value.replace("<br/>","\n");
    }

    public String getQuoteCaption() {
        return quote.summary.headerTitles.get(1).value;
    }

    public List<InfoContent> getQuoteContent() {
        return quote.summary.infoContent;
    }

    public String getQuoteDisclaimer() {
        String disclaimer = null;
        if (!quote.summary.disclaimerText.isEmpty()) {
            disclaimer = Objects.requireNonNull(quote.summary.disclaimerText.stream()
                    .filter((va) -> va.name.equals("QUOTE_DISCLAIMER")).findFirst().orElse(null)).value
                    .replace("[QUOTE_STAR] ", "* ").replace("[QUOTE_STAR]", "* ")
                    .replace("<br/><br/> ","\n\n").replace("<br/><br/>","\n\n")
                    .replace("</br></br>","\n\n").replace("<br/>","").replace("\u00a0",SPACE).trim();
        }
        return disclaimer;
    }

    public String getQuoteDisclaimerPolicyPerks() {
        String disclaimer = null;
        if (!quote.summary.disclaimerText.isEmpty()) {
            disclaimer = Objects.requireNonNull(quote.summary.disclaimerText.stream()
                    .filter((va) -> va.name.equals("QUOTE_DISCLAIMER_POLICYPERKS")).findFirst().orElse(null))
                    .value.replace("<br/><br/>","\n\n");
        }
        return disclaimer;
    }

    public String getQuoteDisclaimerDecliningDeductibles() {
        String disclaimer = null;
        if (!quote.summary.disclaimerText.isEmpty()) {
            disclaimer = Objects.requireNonNull(quote.summary.disclaimerText.stream()
                    .filter((va) -> va.name.equals("QUOTE_DISCLAIMER_DECLINING_DEDUCTIBLES")).findFirst().orElse(null))
                    .value.replace("<br/><br/>","\n\n");
        }
        return disclaimer;
    }

    public String getQuoteDisclaimerClaimForgiveness() {
        String disclaimer = null;
        if (!quote.summary.disclaimerText.isEmpty()) {
            disclaimer = Objects.requireNonNull(quote.summary.disclaimerText.stream()
                    .filter((va) -> va.name.equals("QUOTE_DISCLAIMER_CLAIM_FORGIVENESS")).findFirst().orElse(null))
                    .value.replace("<br/><br/>","\n\n");
        }
        return disclaimer;
    }

    public String getQuoteDisclaimerClaimFree() {
        String disclaimer = null;
        if (!quote.summary.disclaimerText.isEmpty()) {
            disclaimer = Objects.requireNonNull(quote.summary.disclaimerText.stream()
                    .filter((va) -> va.name.equals("QUOTE_DISCLAIMER_CLAIM_FREE_DISCOUNT")).findFirst().orElse(null))
                    .value.replace("<br/><br/>","\n\n");
        }
        return disclaimer;
    }

    public String getRateSummaryDisclaimerClaimFree() {
        String disclaimer = null;
        if (!rateSummary.summary.disclaimerText.isEmpty()) {
            disclaimer = Objects.requireNonNull(rateSummary.summary.disclaimerText.stream()
                    .filter((va) -> va.name.equals("RATESUMMARY_CLAIM_FREE_DISCOUNT")).findFirst().orElse(null))
                    .value.replace(" <br/><br/> ","\n\n").replace(" <br/><br/>","\n\n").replace("<br/><br/>","\n\n");
        }
        return disclaimer;
    }

    public String getThankYouTitle() {
        String title = null;
        if (!thankyou.summary.headerTitles.isEmpty()) {
            title = Objects.requireNonNull(thankyou.summary.headerTitles.stream()
                    .filter((va) -> va.name.equals("THANKYOU_H1")).findFirst().orElse(null))
                    .value.replace("<br/>","\n");
        }
        return title;
    }

    public String getThankYouCaption() {
        String caption = null;
        if (!thankyou.summary.headerTitles.isEmpty()) {
            caption = Objects.requireNonNull(thankyou.summary.headerTitles.stream()
                            .filter((va) -> va.name.equals("THANKYOU_CAPTION")).findFirst().orElse(null))
                    .value.replace("<br/>","\n");
        }
        return caption;
    }

    public String getCoverageValuesDisclaimer() {
        String disclaimer = null;
        if (!coverages.summary.disclaimerText.isEmpty()) {
            disclaimer = Objects.requireNonNull(coverages.summary.disclaimerText.stream()
                    .filter((va) -> va.name.equals("DISCLAIMER")).findFirst().orElse(null)).value
                    .replace("[COVERAGE_STAR_DISCLAIMER]", "* ");
        }
        return disclaimer;
    }

    public String getCoverageValuesPersonalLiability() {
        String personalLiability = null;
        if (!coverages.summary.coverageValues.isEmpty()) {
            personalLiability = Objects.requireNonNull(coverages.summary.coverageValues.stream()
                    .filter((va) -> va.name.equals("PERSONAL_LIABILITY")).findFirst().orElse(null)).value.replace("  ", SPACE);
        }
        return personalLiability;
    }

    public String getCoverageValuesSeparateStructures() {
        String separateStructures = null;
        if (!coverages.summary.coverageValues.isEmpty()) {
            separateStructures = Objects.requireNonNull(coverages.summary.coverageValues.stream()
                    .filter((va) -> va.name.equals("SEPARATE_STRUCTURES")).findFirst().orElse(null)).value;
        }
        return separateStructures;
    }

    public String getCoverageValuesExtendedReplacementCost() {
        String extendedReplacementCost = null;
        if (!coverages.summary.coverageValues.isEmpty()) {
            extendedReplacementCost = Objects.requireNonNull(coverages.summary.coverageValues.stream()
                    .filter((va) -> va.name.equals("EXTENDED_REPLACEMENT_COST")).findFirst().orElse(null)).value;
        }
        return extendedReplacementCost;
    }

    public String getCoverageValuesMedicalPayments() {
        String medicalPayments = null;
        if (!coverages.summary.coverageValues.isEmpty()) {
            medicalPayments = Objects.requireNonNull(coverages.summary.coverageValues.stream()
                    .filter((va) -> va.name.equals("MEDICAL_PAYMENTS_TO_OTHERS")).findFirst().orElse(null)).value;
        }
        return medicalPayments;
    }

    public String getCoverageValuesPersonalProperty() {
        String personalProperty = null;
        if (!coverages.summary.coverageValues.isEmpty()) {
            personalProperty = Objects.requireNonNull(coverages.summary.coverageValues.stream()
                    .filter((va) -> va.name.equals("PERSONAL_PROPERTY")).findFirst().orElse(null)).value;
        }
        return personalProperty;
    }

    public String getCoverageValuesDwelling() {
        String dwelling = null;
        if (!coverages.summary.coverageValues.isEmpty()) {
            dwelling = Objects.requireNonNull(coverages.summary.coverageValues.stream()
                    .filter((va) -> va.name.equals("DWELLING")).findFirst().orElse(null)).value;
        }
        return dwelling;
    }

    public String getCoverageValuesMineSubsidence() {
        String mineSubsidence = null;
        if (coverages.summary.coverageValues.stream().anyMatch((va) -> va.name.equals("MINE_SUBSIDENCE"))) {
            mineSubsidence = coverages.summary.coverageValues.stream()
                    .filter((va) -> va.name.equals("MINE_SUBSIDENCE")).findFirst().get().value;
        }
        return mineSubsidence;
    }

    public String getCoverageValuesBOL() {
        String buildingOrdinanceAndLaw = null;
        if (coverages.summary.coverageValues.stream().anyMatch((va) -> va.name.equals("BOL"))) {
            buildingOrdinanceAndLaw = coverages.summary.coverageValues.stream()
                    .filter((va) -> va.name.equals("BOL")).findFirst().get().value;
        }
        return buildingOrdinanceAndLaw;
    }

    public String getDeductibleAllPeril() {
        String allPeril = null;
        if (!coverages.summary.deductible.isEmpty()) {
            try {
                allPeril = Objects.requireNonNull(coverages.summary.deductible.stream()
                        .filter((va) -> va.name.equals("ALL_PERIL_LOSSES")).findFirst().orElse(null)).value;
            } catch (NullPointerException e) {
                allPeril = Objects.requireNonNull(coverages.summary.deductible.stream()
                        .filter((va) -> va.name.equals("ALL_OTHER_PERIL_LOSSES")).findFirst().orElse(null)).value;
            }
        }
        return allPeril;
    }

    public String getDeductibleWindHail() {
        String windHail = null;
        if (coverages.summary.deductible.stream().anyMatch((va) -> va.name.equals("WIND_HAIL_LOSSES"))) {
            windHail = coverages.summary.deductible.stream()
                    .filter((va) -> va.name.equals("WIND_HAIL_LOSSES")).findFirst().get().value;
        }
        return windHail;
    }

    public String getDeductibleHurricane() {
        String hurricane = null;
        if (coverages.summary.deductible.stream().anyMatch((va) -> va.name.equals("HURRICANE_LOSSES"))) {
            hurricane = coverages.summary.deductible.stream()
                    .filter((va) -> va.name.equals("HURRICANE_LOSSES")).findFirst().get().value;
        }
        return hurricane;
    }

    public String getDeductibleWater() {
        String water = null;
        if (coverages.summary.deductible.stream().anyMatch((va) -> va.name.equals("WATER_LOSSES"))) {
            water = coverages.summary.deductible.stream()
                    .filter((va) -> va.name.equals("WATER_LOSSES")).findFirst().get().value.replace("\u00a0",SPACE);
        }
        return water;
    }

    public String getKnockoutTitle() {
        String koTitle = null;
        if (knockout.summary.headerTitles.stream().anyMatch((va) -> va.name.equals("KNOCKOUT_H1"))) {
            koTitle = knockout.summary.headerTitles.stream()
                    .filter((va) -> va.name.equals("KNOCKOUT_H1")).findFirst().get().value;
        }
        return koTitle;
    }

    public String getKnockoutCaption() {
        String koCaption = null;
        if (knockout.summary.headerTitles.stream().anyMatch((va) -> va.name.equals("KNOCKOUT_CAPTION"))) {
            koCaption = knockout.summary.headerTitles.stream()
                    .filter((va) -> va.name.equals("KNOCKOUT_CAPTION")).findFirst().get().value
                    .replace("<br/><br/>","\n\n")
                    .replace("\u00a0", SPACE);
        }
        return koCaption;
    }

    public String getKnockoutCaptionCA() {
        String koCaption = null;
        if (knockout.summary.headerTitles.stream().anyMatch((va) -> va.name.equals("KNOCKOUT_CAPTIONCA_FAIR_PLAN_ACT"))) {
            koCaption = knockout.summary.headerTitles.stream()
                    .filter((va) -> va.name.equals("KNOCKOUT_CAPTIONCA_FAIR_PLAN_ACT")).findFirst().get()
                    .value.replace("  <br/> <br/>"," \n \n");
        }
        return koCaption;
    }

    public String getMaxCoverageExceededTitle() {
        String koCaption = null;
        if (knockout.summary.headerTitles.stream().anyMatch((va) -> va.name.equals("KNOCKOUT_MAX_COV_AMT_EXCED_H1"))) {
            koCaption = knockout.summary.headerTitles.stream()
                    .filter((va) -> va.name.equals("KNOCKOUT_MAX_COV_AMT_EXCED_H1")).findFirst().get().value;
        }
        return koCaption;
    }

    public String getMaxCoverageExceededTitleKOCaption() {
        String koCaption = null;
        if (knockout.summary.headerTitles.stream().anyMatch((va) -> va.name.equals("KNOCKOUT_MAX_COV_AMT_EXCED_CAPTION"))) {
            koCaption = knockout.summary.headerTitles.stream()
                    .filter((va) -> va.name.equals("KNOCKOUT_MAX_COV_AMT_EXCED_CAPTION")).findFirst().get().value;
        }
        return koCaption;
    }

    public String getErrorTitle() {
        return error.summary.headerTitles.get(0).value.replace("<br/>","\n");
    }

    public String getErrorCaption() {
        return error.summary.headerTitles.get(1).value.replace("<br/>","\n");
    }

    public String getInconvenienceTitle() {
        return inconvenience.summary.headerTitles.get(1).value;
    }

    public String getInconvenienceCaption() {
        return inconvenience.summary.headerTitles.get(0).value;
    }

    public String getMaintenanceTitle() {
        return maintenance.summary.headerTitles.get(1).value;
    }

    public String getMaintenanceCaption() {
        return maintenance.summary.headerTitles.get(0).value;
    }

    public String getExistingCustomerTitle() {
        return existingCustomer.summary.headerTitles.get(1).value;
    }

    public String getExistingCustomerCaption() {
        return existingCustomer.summary.headerTitles.get(0).value;
    }

    public static class DisclaimerText{
        public String name;
        public String value;
    }

    public static class HeaderTitle{
        public String name;
        public String value;
    }

    public static class Summary{
        public List<DisclaimerText> disclaimerText;
        public List<HeaderTitle> headerTitles;
        public List<InfoContent> infoContent;
        public List<CoverageValues> coverageValues;
        public List<Deductible> deductible;
    }

    public static class Quote{
        public Summary summary;
    }

    public static class Address{
        public Summary summary;
    }

    public static class InfoContent{
        public String name;
        public String value;
    }

    public static class Discounts{
        public Summary summary;
    }

    public static class Property{
        public Summary summary;
    }

    public static class Quality{
        public Summary summary;
    }

    public static class RateSummary{
        public Summary summary;
    }

    public static class PropertyDetails{
        public Summary summary;
    }

    public static class CustomerInfo{
        public Summary summary;
    }

    public static class ContactInfo{
        public Summary summary;
    }

    public static class Thankyou{
        public Summary summary;
    }

    public static class CoverageValues{
        public String name;
        public String value;
    }

    public static class Deductible{
        public String name;
        public String value;
    }

    public static class Coverages{
        public Summary summary;
    }

    public static class Knockout{
        public Summary summary;
    }

    public static class Error{
        public Summary summary;
    }

    public static class Inconvenience{
        public Summary summary;
    }

    public static class Maintenance{
        public Summary summary;
    }

    public static class ExistingCustomer{
        public Summary summary;
    }

}
