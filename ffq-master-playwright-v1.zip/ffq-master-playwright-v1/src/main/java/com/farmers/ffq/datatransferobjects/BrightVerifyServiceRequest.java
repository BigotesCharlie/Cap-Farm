package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
public class BrightVerifyServiceRequest {
    @JsonProperty("ValidateEmailRequestBean")
    private ValidateEmailRequestBean validateEmailRequestBean;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties
    @Data
    public static class ValidateEmailRequestBean {
        private String emailVerify;
    }

}
