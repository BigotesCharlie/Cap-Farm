package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
public class ThankForRetreivingQuotePage extends AutoBasePage {

	@PWFindBy(className = "auto-module__retrieve-confirmation-header-text")
	private PWElement thankYouForRetreivingYourQuoteText;

	@PWFindBy(xpath = "//mat-dialog-actions/button")
	private PWElement continueButton;
		
	public ThankForRetreivingQuotePage() throws Exception {
		super();
		PWDriver browserDriver = driver();
		PWPageFactory.initElements(browserDriver, this);
		waitForSpinnerToBeGone();
		continueToBristolWest(true);
		waitElementBeVisible(thankYouForRetreivingYourQuoteText);
	}
	
	public void clickContinueButton() {
		waitElementBeVisibleClickable(continueButton);
		continueButton.click();
		waitForSpinnerToBeGone();
	}

}
