package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.GlobalVariables;
import com.farmers.framework.report.Log;
import lombok.Getter;
import lombok.SneakyThrows;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter
public class NameAndDobPage extends AutoBasePage {

    private static final String DATE_OF_BIRTH = "Date of birth";
    private static final String FIRST_NAME = "First name";
    private static final String LAST_NAME = "Last name";
    private static final String LOG_MESSAGE_TEMPLATE = "Entering ";
    private static final String NOT_ALLOWED_NUMERIC_CHARACTERS = "1234567890";
    private static final String NOT_ALLOWED_SPECIAL_AND_ALPHABETIC_CHARACTERS = "!@#$%^&()_+=~`[]{}|:;'<>,/?abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String NOT_ALLOWED_SPECIAL_CHARACTERS = "!@#$%^&()_+=~`[]{}|:;<>/?";
    private final PWBy enterprisePrivacyStatementPageHeader = PWBy.xpath("//span[text()='Enterprise Privacy Statement' or text()='Privacy Policy']");
    @PWFindBy(xpath = "//button[@data-tui-tracking-id='personal-info__continue-button-cta' or contains(@class, 'partner-premium-details__cta')]")
    private List<PWElement> continueButtons;
    @PWFindBy(xpath = "//button[@class='tui-btn tui-btn-primary address-form__continue-cta']")
    private PWElement agreeButton;
    @PWFindBy(xpath = "//input[contains(@aria-label, '"+ FIRST_NAME + "')]")
    private PWElement firstNameInputField;
    @PWFindAll({
            @PWFindBy(xpath = "//app-personal-info//h1[@class='tui-h1 ng-star-inserted']"),
            @PWFindBy(xpath = "//*[contains(@class, 'personal-info_name_dob_h1')]/h1")
    })
    private PWElement nameAndDobTitle;
    @PWFindBy(id = "personal-info_name_dob-subheading")
    private PWElement nameAndDobSubtitle;

    @PWFindBy (xpath = "//*[contains(@class, 'disclaimer__credit-report')]")
    private PWElement creditCheckDisclaimerTextElement;
    @PWFindBy (xpath = "//*[starts-with(@class, 'disclaimer__color')]")
    private PWElement privacyPolicyDisclaimerTextElement;

    @PWFindBy(xpath = "//div[contains(@class,'disclaimer__credit')]//p[1]")
    private PWElement disclaimerCredit;
    @PWFindBy(xpath = "//div[contains(@class,'disclaimer__credit')]//p[2]")
    private PWElement drivingScore;
    @PWFindBy(xpath = "//div[contains(@class,'auto-disclaimer__color d-grid gap-4')]")
    private PWElement drivingScoreExtended;
    @PWFindBy(id = "showMoreButton")
    private PWElement showMoreButton;
    @PWFindBy(xpath = "//div[starts-with(@class,'disclaimer__color')]")
    private PWElement ctaDisclaimer;
    @PWFindBy(linkText = "Personal information use")
    private PWElement personalInfoUseLink;
    @PWFindBy(xpath = "//a[contains(@data-tui-tracking-id, 'privacy-policy-hyperlink')]")
    private PWElement privacyPolicy;
    @PWFindBy(xpath = "//span[contains(text(),'Privacy Center') or contains(text(),'Privacy Policy') or contains(text(),'Enterprise Privacy Statement')]")
    PWElement privacyCenterPageHeader;

    //Media Alpha
    private static final String MEDIA_ALPHA_COMMON_XPATH = "//div[contains(@class, 'personal-info-aggregator-actions') or contains(@class, 'partner-premium-details__legal')]";

    @PWFindAll({
            @PWFindBy(xpath = "//div[contains(@class,'tui-stacking-top-md disclaimer__credit-report')]/p[1]"),
            @PWFindBy (xpath = MEDIA_ALPHA_COMMON_XPATH + "//p[1]")
    })
    private PWElement mediaAlphaCreditCheckDisclaimerTextElement;

    @PWFindAll({
            @PWFindBy(xpath = "//div[contains(@class,'tui-stacking-top-md disclaimer__credit-report')]/p[3]"),
            @PWFindBy (xpath = MEDIA_ALPHA_COMMON_XPATH + "//p[2]")
    })
    private PWElement mediaAlphaConsumerReportDisclaimerTextElement;
    @PWFindBy (xpath = MEDIA_ALPHA_COMMON_XPATH + "//p[3]")
    private PWElement mediaAlphaExtraordinaryCircumstancesTextElement;

    @PWFindAll({
            @PWFindBy (xpath = MEDIA_ALPHA_COMMON_XPATH + "//p[4]"),
            @PWFindBy (xpath = "//div[contains(@class,'disclaimer__color mt-3 ng-star-inserted')]//p")
    })
    private PWElement mediaAlphaPrivacyPolicyDisclaimerTextElement;
    @PWFindBy (xpath = MEDIA_ALPHA_COMMON_XPATH + "//p[5]")
    private PWElement mediaAlphaConsumerReportDisclaimerTextAlternateElement;
    @PWFindBy (xpath = MEDIA_ALPHA_COMMON_XPATH + "//p[6]")
    private PWElement mediaAlphaConsumerReportEntititesTextAlternateElement;
    @PWFindBy (xpath = MEDIA_ALPHA_COMMON_XPATH + "/p[1]")
    private PWElement mediaAlphaPrivacyPolicyDisclaimerTextAlternateElement;
    @PWFindBy (xpath = MEDIA_ALPHA_COMMON_XPATH + "//p")
    private List<PWElement> listOfDisclaimerTextElements;

    // Highlighted tooltip rebrand card (BW "new look" notice)
    @PWFindBy(css = "div.highlighted-tooltip-rebrand")
    private PWElement highlightedTooltipRebrandContainer;
    @PWFindBy(css = "div.highlighted-tooltip img.lightbulbblue-icon")
    private PWElement highlightedTooltipBulbIcon;
    @PWFindBy(css = "div.label-text span.tui-body-text-bold")
    private PWElement highlightedTooltipTitle;
    @PWFindBy(css = "div.label-text span.tui-body-text-1")
    private PWElement highlightedTooltipContent;

    private static final String HIGHLIGHTED_TOOLTIP_TITLE_TEXT = "We've got a new look!";
    private static final String HIGHLIGHTED_TOOLTIP_CONTENT_TEXT = "Bristol West is part of the Farmers family and together we've refreshed our apperance while bringing you the same great coverage.";
    private static final String HIGHLIGHTED_TOOLTIP_BULB_ICON_ALT = "Attention";



    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public NameAndDobPage() throws Exception {
        super();
    }

    public boolean areNotAllowedNumericCharactersNotAcceptedOnDOBField() throws Exception {
        return areNotAllowedCharactersNotAccepted(DATE_OF_BIRTH, NOT_ALLOWED_SPECIAL_AND_ALPHABETIC_CHARACTERS);
    }

    public boolean areNotAllowedNumericCharactersNotAcceptedOnFirstNameField() throws Exception {
        return areNotAllowedCharactersNotAccepted(FIRST_NAME, NOT_ALLOWED_NUMERIC_CHARACTERS);
    }

    public boolean areNotAllowedNumericCharactersNotAcceptedOnLastNameField() throws Exception {
        return areNotAllowedCharactersNotAccepted(LAST_NAME, NOT_ALLOWED_NUMERIC_CHARACTERS);
    }

    public boolean areNotAllowedSpecialCharactersNotAcceptedOnFirstNameField() throws Exception {
        return areNotAllowedCharactersNotAccepted(FIRST_NAME, NOT_ALLOWED_SPECIAL_CHARACTERS);
    }

    public boolean areNotAllowedSpecialCharactersNotAcceptedOnLastNameField() throws Exception {
        return areNotAllowedCharactersNotAccepted(LAST_NAME, NOT_ALLOWED_SPECIAL_CHARACTERS);
    }

    @SneakyThrows
    public boolean isNameAndDOBDataSaved(AutoApplicant applicant) {

        String firstNameFieldValue = getInputFieldValue(findFormFieldWebElement(FIRST_NAME));
        String lastNameFieldValue = getInputFieldValue(findFormFieldWebElement(LAST_NAME));
        String dateOfBirthFieldValue = getInputFieldValue(findFormFieldWebElement(DATE_OF_BIRTH));

        return areTwoListEqual(new ArrayList<>(Arrays.asList(firstNameFieldValue, lastNameFieldValue, dateOfBirthFieldValue.replace("/", GlobalVariables.EMPTY_STRING))), new ArrayList<>(Arrays.asList(applicant.getFirstName(), applicant.getLastName(), applicant.getDateOfBirth())));
    }

    public boolean areInvalidDatesTriggerErrorMessage(AutoApplicant applicant) {

        String date = generateRandomDateOfBirth();
        AtomicBoolean flag = new AtomicBoolean(true);

        filloutApplicantFormWithValues(applicant.getFirstName(), applicant.getLastName(), date);
        if (getListOfActualErrorMessages().stream().noneMatch(msg -> msg.contains("Age should be between 15 and 99 years."))) {
            flag.set(false);
            Log.error("Error message did not trigger for this date: " + date);
        }

        return flag.get();
    }

    public void clickOnPersonalInformationUseLink() throws Exception {
        waitUntilAngular5Ready();
        clickOnHiddenElement(personalInfoUseLink);
    }

    public void filloutApplicantForm(AutoApplicant autoApplicant) throws Exception {
        if(autoApplicant.getTestScenario().contains(BW_CLICK_TO_BUY_FULL_FLOW)) {
            clickContinueButton();
            AppStore.Data.CustomerData customerData = getSessionStorageAppStore().getData().getCustomerData();
            autoApplicant.setFirstName(customerData.getFirstName());
            autoApplicant.setLastName(customerData.getLastName());
            Log.info("Applicant last name : " + autoApplicant.getLastName());
            String dateOfBirth = customerData.getDateOfBirth();
            String year = dateOfBirth.substring(0,4);
            String month = dateOfBirth.substring(5,7);
            String day = dateOfBirth.substring(8);
            autoApplicant.setDateOfBirth(month + day + year);
            autoApplicant.setZipCode(customerData.getAddress().getZip());
            autoApplicant.setAge(LocalDate.now().getYear() - Integer.parseInt(dateOfBirth.substring(0,4)));
        } else {
            filloutApplicantFormWithValues(autoApplicant.getFirstName(), autoApplicant.getLastName(), autoApplicant.getDateOfBirth());
        }
        testStep("StateCode: " + autoApplicant.getStateCode() + ". ZipCode: " + autoApplicant.getZipCode(), false);

    }

    public void filloutApplicantFormWithIncorrectInput() {
        String wrongInput = "--";
        String wrongDate = "05/05";
        filloutApplicantFormWithValues(wrongInput, wrongInput, wrongDate);
    }

    public void filloutApplicantFormWithNoInput() {
        //skipping form field entering
        waitForNameAndDobPageToRender();
        clickContinueButton();
    }

    public void clickContinueButton() {
    	scrollToBottomOfPage();
        clickElement(continueButtons.stream().filter(each -> isElementVisible(each, 1)).collect(Collectors.toList()).stream().findFirst().get());
    }

    @SneakyThrows
    public void filloutApplicantFormWithValues(String firstName, String lastName, String dateOfBirth) {
        waitForNameAndDobPageToRender();
        enterFirstNameLastNameDOB(firstName, lastName, dateOfBirth);
        clickContinueButton();
        testStep("LastName: " + lastName + ". DoB: " + dateOfBirth);
    }

    public void enterFirstNameLastNameDOB(String firstName, String lastName, String dateOfBirth) throws Exception {
        enterValueInField(firstName, waitElementBeVisible(findFormFieldWebElement(FIRST_NAME)), LOG_MESSAGE_TEMPLATE + FIRST_NAME + COLON + SPACE);
        enterValueInField(lastName, findFormFieldWebElement(LAST_NAME), LOG_MESSAGE_TEMPLATE + FIRST_NAME + COLON + SPACE);
        enterValueInField(dateOfBirth, findFormFieldWebElement(DATE_OF_BIRTH), LOG_MESSAGE_TEMPLATE + DATE_OF_BIRTH + COLON + SPACE);
        Log.info(String.format("User personal info details entered: First name: %s, Last Name: %s, Dob: %s", firstName, lastName, dateOfBirth));
    }

    // invalidate condition is age<=15 and age>=99
    public String generateRandomDateOfBirth() {
        LocalDate currentDate = LocalDate.now();
        Random random = new Random();
        boolean isYounger = true;
        int year;

        if (isYounger) {
            // Generate a random age between 1 to 14 (exclusive of age 15 boundary)
            int startYoungYear = currentDate.minusYears(14).getYear();
            int endYoungYear = currentDate.minusYears(1).getYear();
            year = random.nextInt(endYoungYear - startYoungYear + 1) + startYoungYear;
        } else {
            // Generate a random age between 99 to 200 (inclusive)
            int startOldYear = currentDate.minusYears(200).getYear();
            int endOldYear = currentDate.minusYears(99).getYear();
            year = random.nextInt(endOldYear - startOldYear + 1) + startOldYear;
        }

        int month = random.nextInt(12) + 1;
        int day = random.nextInt(28) + 1; // We assume February 28 as the maximum date for simplicity.

        return String.format("%02d/%02d/%04d", month, day, year);
    }

    public String getFormFieldWebElementValue(String fieldName) throws Exception {
        return getElementValue(driver().findElement(PWBy.cssSelector(String.format("input[aria-label*='%s']", fieldName))), fieldName);
    }

    public boolean isFirstNameCharLimitCorrect() throws Exception {
        int maxFirstNameCharLimit = 15;
        String inputValue = getInputFieldValue(findFormFieldWebElement(FIRST_NAME));
        return inputValue.length() == maxFirstNameCharLimit;
    }

    public boolean isLastNameCharLimitCorrect() throws Exception {
        int maxLastNameCharLimit = 20;
        String inputValue = getInputFieldValue(findFormFieldWebElement(LAST_NAME));
        return inputValue.length() == maxLastNameCharLimit;
    }

    public boolean isOnNameAndDobPage() {
        return isElementVisible(nameAndDobTitle, 60);
    }

    public boolean quickIsOnNameAndDobPage() {
        return isElementVisible(nameAndDobTitle, 10);
    }

    public boolean isPrivacyStatementPageHeaderExist() throws Exception {
        return isElementPresent(enterprisePrivacyStatementPageHeader, 5);
    }

    public boolean isPrivacyStatementTabTitleCorrect() throws Exception {
        wait.until(PWExpectedConditions.numberOfWindowsToBe(2));
        // Get the window handles
        Set<String> windowHandles = driver().getWindowHandles();

        // Switch to the next tab (second tab)
        String currentWindowHandle = driver().getWindowHandle();
        for (String handle : windowHandles) {
            if (!handle.equals(currentWindowHandle)) {
                driver().switchTo().window(handle);
                break;
            }
        }

        return wait.until(driver -> {
            String title = driver.getTitle();
            return title.contains("Privacy Statement") || title.contains("Privacy Policy");
        });
    }

    // TODO: enable image comparison
//    public boolean validatePageContent() throws Exception {
//        String pageScreenShot = this.getClass().getSimpleName();
//        return imageComparisonHelper.compareImages(imageComparisonHelper.takeWholePageScreenShot(), imageComparisonHelper.getExpectedImage(pageScreenShot, GlobalVariables.AUTO), pageScreenShot);
//    }

    @SneakyThrows
    public void refreshPage() {
        driver().navigate().refresh();
        waitUntilAngular5Ready();
    }

    public void validateErrorMessageForIncorrectInput() {
        waitForNameAndDobPageToRender();
        assertErrorMessages(getListOfExpectedErrorMessages("Invalid %s"), getListOfActualErrorMessages());
    }

    public void validateErrorMessageForNoInput() {
        waitForNameAndDobPageToRender();
        assertErrorMessages(getListOfExpectedErrorMessages("Please provide your %s."), getListOfActualErrorMessages());
    }

    public void waitForNameAndDobPageToRender() {
        waitElementBeVisible(firstNameInputField, 20);
    }

    private boolean areNotAllowedCharactersNotAccepted(String fieldName, String notAllowedChars) throws Exception {

        // Test special characters
        for (char character : notAllowedChars.toCharArray()) {

            PWElement firstNameField = findFormFieldWebElement(fieldName);
            firstNameField.sendKeys(Character.toString(character));
            String inputFieldValue = getInputFieldValue(firstNameField);
            if (!GlobalVariables.EMPTY_STRING.equals(inputFieldValue)) {
                return false;
            }
            firstNameField.clear();
        }
        return true;
    }

    private void assertErrorMessages(List<String> listOfExpectedErrorMessages, List<String> listOfActualErrorMessages) {
        waitForNameAndDobPageToRender();
        // validate error messages
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(new HashSet<>(listOfExpectedErrorMessages).containsAll(listOfActualErrorMessages), listOfExpectedErrorMessages + " to contain " + listOfActualErrorMessages);
        fsa.assertAll();
    }

    private PWElement findFormFieldWebElement(String fieldName) throws Exception {
        return driver().findElement(PWBy.cssSelector(String.format("input[aria-label*='%s']", fieldName)));
    }

    @SneakyThrows
    private List<String> getListOfActualErrorMessages() {
        sleep(1);
        return driver().findElements(PWBy.xpath("//mat-error")).stream()
                .filter(PWElement::isDisplayed).map(this::getTextFromElement).map(String::strip)
                .collect(Collectors.toList());
    }

    private List<String> getListOfExpectedErrorMessages(String errorMessageTemplate) {
        waitForNameAndDobPageToRender();
        return Stream.of(FIRST_NAME, LAST_NAME, "date of birth (mm/dd/yyyy)")
                .map(String::toLowerCase)
                .map(field -> {
                    // Error message for date is different for invalid input so below is an itinerary operation to meet error message constructions.
                    if (field.contains(DATE_OF_BIRTH.toLowerCase()) && errorMessageTemplate.contains("Invalid")) {
                        return "Date of Birth is not a valid entry.";
                    }
                    return String.format(errorMessageTemplate, field);
                }).collect(Collectors.toList());
    }

    public void validateADA_NameAndDobPage() {
        if (!isADATestingEnabled()) return;
        isOnNameAndDobPage();
        clickContinueButton();
        waitForPageToBeReady();
        performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
    }

    public void validateLinks() throws Exception {
        validateColorOfTheLinks();
        String mainPage = driver().getWindowHandle();
        clickOnPersonalInformationUseLink();
        testStepAssert(isPrivacyStatementTabTitleCorrect(), "Privacy statement link tab title validated");
        testStepAssert(isPrivacyStatementPageHeaderExist(), "Private Statement page header exist validation");
        driver().close();
        driver().switchTo().window(mainPage);
        isOnNameAndDobPage();
    }

    public void verifyLetsBeginPageContent(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
    	fsa.assertEquals(getTextFromElement(nameAndDobTitle), "Let's begin...", "Let's begin page title");
    	fsa.assertEquals(getTextFromElement(nameAndDobSubtitle), "Get started with just a few details.", "Let's begin page subtitle");
    	new AutoEnterAddressPage().verifyBundleDisclaimerSection(fsa);
    	validateDisclaimers(fsa, false);
    }

    public void verifyPageTitle(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(nameAndDobTitle), "Let's begin...", "Let's begin page title");
    }

    public void verifyPageTitleWithInfo(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(nameAndDobTitle), "Let's get you started with a quote", "Let's begin page title");
    }

    public void validateDisclaimers(FarmersSoftAssert fsa, boolean isAutoLOB) throws Exception {
        String applicantStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        String expectedCreditDisclaimerText = EMPTY_STRING;
        String expectedBrowserDataInfoAuto = "IMPORTANT If using a public computer: To protect your privacy, you must clear your browsing data and sign out of all accounts before leaving. You are solely responsible for any information left on public devices. ";
        String yourCreditReportString = "In connection with this application for insurance, Farmers may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. ";
        String youAndYourSpouseCreditReportString = "In connection with this application for insurance, Farmers may review your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. ";
        String nctueString = "We may use third parties in connection with the development of your insurance scores based on data from traditional credit bureaus and the National Consumer Telecom & Utilities Exchange database. ";
        String creditBureauString = "We may use third parties in connection with the development of your insurance scores based on data from traditional credit bureaus. ";
        String requestSepareteQuoteString = "You may request a separate premium quotation that separately identifies the portion of the premium attributable to your credit history by contacting Farmers at (800) 909-7777. ";
        String extraordinaryLifeCircumstancesString = "If you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, in writing, that we provide reasonable exceptions to our underwriting and/or rating practices. ";
        String extraordinaryLifeCircumstancesWithThisQuoteOrOtherPolicyString = "If you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, in writing, that we provide reasonable exceptions to our underwriting" +
                " and/or rating practices for this quote or any policy issued. ";

        String contactFarmersString = "Please contact a Farmers\u00ae representative for details on qualifying circumstances and how to request an exception. ";
        String farmersEntitiesString = "Farmers entities may use any consumer report information their affiliates might currently have for you for your quote request. Our Privacy Notice gives you the choice to opt out of allowing Farmers affiliates to share your consumer report information among Farmers entities. You can still opt out of future sharing.";
        String expectedCreditDisclaimerTextForCAandIL = farmersEntitiesString + SPACE +
                "Any estimate provided will reflect rates in effect as of the date of that estimate and is subject to revision, including revision based on verification of information and inspection if needed. " +
                "Premium may vary based on additional information, coverages, and deductibles that you select, underwriting criteria, and any changes to assumptions. " +
                "Farmers reserves the right to accept, reject, or modify this quote after review of an application and other underwriting information. " +
                "Applications are subject to underwriting approval. Farmers online auto quotes are available for new auto customers.";

        if (List.of(AZ, CO, IL, MI, PA).contains(applicantStateCode)) {
            youAndYourSpouseCreditReportString = "In connection with this application for insurance, Farmers and/or its affiliates may review your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. ";
        }

        if (List.of(CT, KS, KY, NV, OK).contains(applicantStateCode)) {
            youAndYourSpouseCreditReportString = "In connection with this application for insurance, Farmers and/or affiliates may review your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. ";
        }

        switch (applicantStateCode) {
            case GA: case VA:
                expectedCreditDisclaimerText = (isAutoLOB? expectedBrowserDataInfoAuto: EMPTY_STRING)  + youAndYourSpouseCreditReportString + nctueString + farmersEntitiesString;
                break;
            case AL: case AR: case AZ: case CO:  case ID: case MO: case ND: case NM:
            case NE: case OH: case OR: case PA: case SD: case TN: case UT:  case WY: case WI:
                expectedCreditDisclaimerText = youAndYourSpouseCreditReportString + nctueString + farmersEntitiesString;
                break;
            case CA:
                expectedCreditDisclaimerText = expectedCreditDisclaimerTextForCAandIL;
                break;
            case CT:
                expectedCreditDisclaimerText = youAndYourSpouseCreditReportString + creditBureauString + extraordinaryLifeCircumstancesWithThisQuoteOrOtherPolicyString + contactFarmersString + farmersEntitiesString;
                break;
            case FL: case IN:
                expectedCreditDisclaimerText = youAndYourSpouseCreditReportString + creditBureauString + farmersEntitiesString;
                break;
            case IA: case KY: case MI: case NV: case OK:
            	expectedCreditDisclaimerText = youAndYourSpouseCreditReportString + nctueString + extraordinaryLifeCircumstancesString + contactFarmersString + farmersEntitiesString;
            	break;
            case IL:
            	expectedCreditDisclaimerText = (isAutoLOB? expectedBrowserDataInfoAuto: EMPTY_STRING) + youAndYourSpouseCreditReportString + nctueString + expectedCreditDisclaimerTextForCAandIL;
            	break;
            case KS:
            	extraordinaryLifeCircumstancesString = "Also, if you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, in writing, that we provide reasonable exceptions to our underwriting and/or rating practices. ";
            	expectedCreditDisclaimerText = youAndYourSpouseCreditReportString + nctueString +
            			"We provide an internal appeal process whereby you may review an adverse action based on your credit information. " + extraordinaryLifeCircumstancesString + contactFarmersString + farmersEntitiesString;
            	break;
            case LA:
                expectedCreditDisclaimerText = youAndYourSpouseCreditReportString + creditBureauString + extraordinaryLifeCircumstancesString + contactFarmersString + farmersEntitiesString;
                break;
            case MA:
            	expectedCreditDisclaimerText = farmersEntitiesString;
            	break;
            case MD:
            	expectedCreditDisclaimerText = yourCreditReportString + creditBureauString + requestSepareteQuoteString + farmersEntitiesString;
            	break;
            case MN:
            	expectedCreditDisclaimerText = yourCreditReportString + creditBureauString + extraordinaryLifeCircumstancesString + contactFarmersString +
            	"The insurer may elect to cancel coverage at any time during the first 59 days following issuance of the coverage for any reason which is not specifically prohibited by statute. " +
            	"Your state also requires us to tell you that we may obtain consumer reports or personal or privileged information from third parties. " +
            	"This information as well as other personal or privileged information subsequently collected by us or your representative may be used for underwriting or rating and in certain circumstances may be disclosed to third parties without authorization, as permitted by law. " +
            	"You have the right of access and correction with respect to all personal information collected. At your request, we will provide you with more detailed information regarding our collection, use and disclosure of personal information, and your rights to access and correct such information. " +
            	"By continuing, you authorize us and your representative to collect and disclose your personal and privileged information. This authorization will remain valid for as long as you are continually insured with us. " +
            	farmersEntitiesString;
            	break;
            case MS:
                expectedCreditDisclaimerText = yourCreditReportString + creditBureauString + extraordinaryLifeCircumstancesString + contactFarmersString + farmersEntitiesString;
                break;
            case MT:
            	expectedCreditDisclaimerText = youAndYourSpouseCreditReportString + nctueString + extraordinaryLifeCircumstancesString + contactFarmersString + farmersEntitiesString;
            	break;
            case NC:
                expectedCreditDisclaimerText = yourCreditReportString + creditBureauString +
                        "This insurance is offered through Truck Insurance Exchange. An Exchange is an insurance organization, which operates in most ways like any other insurance company. " +
                        "The Exchange is owned by its policyholders and appoints an \"attorney-in-fact\" to issue policies, collect premiums, and perform other duties on their behalf for a fee. " +
                        "That appointment is made through a document called a \"Subscription Agreement.\" To become a member of the Exchange, you need to review and sign the Subscription Agreement, which is an agreement with the Exchange's attorney-in-fact to provide services. " +
                        "In addition to a $3 installment fee, we also may charge a $15 late fee, a $20 returned payment charge, or a $25 reinstatement fee. This policy is also subject to a policy fee of $30. " +
                        farmersEntitiesString;
                break;
            case TX:
                expectedCreditDisclaimerText = (isAutoLOB? expectedBrowserDataInfoAuto: EMPTY_STRING) + "We will obtain and use credit information, from traditional credit bureaus and the National Consumer Telecom & Utilities Exchange database, on you and your spouse as a part of the insurance credit scoring process. " + farmersEntitiesString;
                break;
            case WA:
                expectedCreditDisclaimerText = yourCreditReportString + creditBureauString + farmersEntitiesString;
                break;
        }
        fsa.assertEquals(getTextFromElement(creditCheckDisclaimerTextElement), expectedCreditDisclaimerText, "Correct creditCheckDisclaimerTextElement content");
        String ctaButtonText = getTextFromElement(continueButtons.stream().filter(each -> isElementVisible(each, 1)).collect(Collectors.toList()).stream().findFirst().get());
        String connectingText = applicantStateCode.equals(NC) ? " Subscription agreement, and agree to " : SPACE;
        if (isAutoLOB) {
        	fsa.assertEquals(getTextFromElement(privacyPolicyDisclaimerTextElement), "By clicking \"" + ctaButtonText + "\", you acknowledge that you've read and agree to the Privacy Policy and" + connectingText + "the above consumer report information provisions. " +
        			"Otherwise contact a Farmers\u00ae representative to discuss options.", "Correct privacyPolicyDisclaimerTextElement content");
        } else {
        	fsa.assertEquals(getTextFromElement(privacyPolicyDisclaimerTextElement), "You also acknowledge that you've read and agree to the Privacy Policy and the above consumer report information provisions. " +
        			"Otherwise contact a Farmers\u00ae representative to discuss options.", "Correct privacyPolicyDisclaimerTextElement content");
        }
    }

    public void validateDisclaimersOnMediaAlphaFlow(FarmersSoftAssert fsa) throws Exception {
        String applicantStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        String thirdPartiesText = "We may use third parties in connection with the development of your insurance scores based on data from traditional credit bureaus and the National Consumer Telecom & Utilities Exchange database.";
        String expectedCreditDisclaimerText = "In connection with this application for insurance, Farmers and/or its affiliates may review your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. " +
        		thirdPartiesText;
        String youAndYourSpouseCreditReportText = "In connection with this application for insurance, Farmers may review your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. " +
        		thirdPartiesText;
        String farmersEntitiesString = "Farmers entities may use any consumer report information their affiliates might currently have for you for your quote request. " +
        		"Our Privacy Notice gives you the choice to opt out of allowing Farmers affiliates to share your consumer report information among Farmers entities. You can still opt out of future sharing.";
        String ctaButtonText = getTextFromElement(continueButtons.stream().filter(each -> isElementVisible(each, 1)).collect(Collectors.toList()).stream().findFirst().get());
        String acknowledgeAndAgreeText = "By clicking \"" + ctaButtonText + "\", you acknowledge that you've read and agree to the Privacy Policy and the above consumer report information provisions. " +
                "Otherwise contact a Farmers\u00ae representative to discuss options.";
        String publicComputerText = "IMPORTANT If using a public computer: To protect your privacy, you must clear your browsing data and sign out of all accounts before leaving. " +
                "You are solely responsible for any information left on public devices. ";
        String esignText = "By clicking \"" + ctaButtonText + "\", you agree to these ESIGN terms and conditions and to receive marketing calls and texts as detailed below.";
        String marketingText = "We call and/or text consumers with information about products and services. " +
        		"By clicking \"" + ctaButtonText + "\", you consent to receive marketing calls and texts on behalf of Farmers\u00ae, Foremost\u00ae, Bristol West\u00ae, and Farmers Life\u00ae associated entities and their representatives using an automated telephone dialing system, AI-generated and artificial or pre-recorded voice, even for numbers listed on national, state, or business do-not-call registries. " +
        		"Consent is not a condition of purchase. Go to Farmers.com for alternative contact options. Message and data rates may apply.";
        String estimateText = "Any estimate provided will reflect rates in effect as of the date of that estimate and is subject to revision, including revision based on verification of information and inspection if needed. " +
				"Premium may vary based on additional information, coverages, and deductibles that you select, underwriting criteria, and any changes to assumptions. " +
				"Farmers reserves the right to accept, reject, or modify this quote after review of an application and other underwriting information. " +
				"Applications are subject to underwriting approval. Farmers online auto quotes are available for new auto customers.";
        if (List.of(AZ, ID, IL, MO).contains(applicantStateCode)) {
        	fsa.assertEquals(getTextFromElement(mediaAlphaCreditCheckDisclaimerTextElement), esignText, "Correct mediaAlphaESIGNDisclaimer content");
    		fsa.assertEquals(getTextFromElement(mediaAlphaConsumerReportDisclaimerTextElement), marketingText, "Correct mediaAlphaMarketingDisclaimer content");
    		fsa.assertEquals(getTextFromElement(mediaAlphaExtraordinaryCircumstancesTextElement), List.of(AZ,IL).contains(applicantStateCode)? expectedCreditDisclaimerText : youAndYourSpouseCreditReportText,
    				"Correct mediaAlphaCreditCheckDisclaimer content");
    		fsa.assertEquals(getTextFromElement(mediaAlphaConsumerReportDisclaimerTextAlternateElement), applicantStateCode.equals(IL)? farmersEntitiesString + SPACE + estimateText : farmersEntitiesString,
    				"Correct mediaAlphaConsumerReportDisclaimer content");
    		fsa.assertEquals(getTextFromElement(mediaAlphaPrivacyPolicyDisclaimerTextAlternateElement), acknowledgeAndAgreeText, "Correct mediaAlphaPrivacyPolicyDisclaimer content");
        } else if (applicantStateCode.equals(MN)) {
        	String accidentSurchageText = "Minnesota Accident and Violation Surcharge - Your policy premium can be affected by chargeable accidents and chargeable traffic violations such as moving violations. " +
        			"Insurers are required to file a surcharge plan explaining conditions under which a surcharge may be applied to a policy. MN law permits an insurer to notify applicants that its surcharge disclosure plan is available for review on its website. " +
        			"A copy of our written Surcharge Disclosure Statement, including examples of how premium can be affected, is available on our website.";
        	String extraordinaryLifeCircumstancesText = "In connection with this application for insurance, Farmers may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. " +
        			"We may use third parties in connection with the development of your insurance scores based on data from traditional credit bureaus. " +
        			"If you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, in writing, that we provide reasonable exceptions to our underwriting and/or rating practices. Please contact a Farmers® representative for details on qualifying circumstances and how to request an exception. " +
        			"The insurer may elect to cancel coverage at any time during the first 59 days following issuance of the coverage for any reason which is not specifically prohibited by statute.";
        	String yourStateConsumerReportText ="Your state also requires us to tell you that we may obtain consumer reports or personal or privileged information from third parties. " +
        			"This information as well as other personal or privileged information subsequently collected by us or your representative may be used for underwriting or rating and in certain circumstances may be disclosed to third parties without authorization, as permitted by law. " +
        			"You have the right of access and correction with respect to all personal information collected. At your request, we will provide you with more detailed information regarding our collection, use and disclosure of personal information, and your rights to access and correct such information. " +
        			"By continuing, you authorize us and your representative to collect and disclose your personal and privileged information. This authorization will remain valid for as long as you are continually insured with us.";
        	fsa.assertEquals(getTextFromElement(mediaAlphaCreditCheckDisclaimerTextElement), esignText, "Correct mediaAlphaESIGNDisclaimer content");
        	fsa.assertEquals(getTextFromElement(mediaAlphaConsumerReportDisclaimerTextElement), marketingText, "Correct mediaAlphaMarketingDisclaimer content");
        	fsa.assertEquals(getTextFromElement(mediaAlphaExtraordinaryCircumstancesTextElement), accidentSurchageText, "Correct mediaAlphaAccidentSurchargeDisclaimer content");
    		fsa.assertEquals(getTextFromElement(mediaAlphaPrivacyPolicyDisclaimerTextElement), extraordinaryLifeCircumstancesText, "Correct mediaAlphaCreditReportDisclaimer content");
    		fsa.assertEquals(getTextFromElement(mediaAlphaConsumerReportDisclaimerTextAlternateElement), yourStateConsumerReportText, "Correct mediaAlphaConsumerReportDisclaimer content");
    		fsa.assertEquals(getTextFromElement(mediaAlphaConsumerReportEntititesTextAlternateElement), farmersEntitiesString, "Correct mediaAlphaSharingDisclaimer content");
    		fsa.assertEquals(getTextFromElement(mediaAlphaPrivacyPolicyDisclaimerTextAlternateElement), acknowledgeAndAgreeText, "Correct mediaAlphaPrivacyPolicyDisclaimer content");
        } else if (List.of(TX, VA).contains(applicantStateCode)) {
        	String nctueText = "We will obtain and use credit information, from traditional credit bureaus and the National Consumer Telecom & Utilities Exchange database, on you and your spouse as a part of the insurance credit scoring process.";
        	int count = listOfDisclaimerTextElements.size();
        	for (int index = 0; index < count; index++) {
        		switch (index) {
					case 0:
						fsa.assertEquals(getTextFromElement(listOfDisclaimerTextElements.get(index)), esignText + SPACE + marketingText, "Correct mediaAlphaESIGNMarkertingDisclaimer content");
						break;
					case 1:
						fsa.assertEquals(getTextFromElement(listOfDisclaimerTextElements.get(index)), applicantStateCode.equals(TX)? nctueText : youAndYourSpouseCreditReportText, "Correct mediaAlphaCreditDisclaimer content");
						break;
					case 2:
						fsa.assertEquals(getTextFromElement(listOfDisclaimerTextElements.get(index)), farmersEntitiesString, "Correct mediaAlphaConsumerReportDisclaimer content");
						break;
					case 3:
						fsa.assertEquals(getTextFromElement(listOfDisclaimerTextElements.get(index)), acknowledgeAndAgreeText, "Correct mediaAlphaPrivacyPolicyDisclaimer content");
						break;
				}
        	}
        } else {
        	fsa.assertEquals(getTextFromElement(mediaAlphaCreditCheckDisclaimerTextElement), applicantStateCode.equals(GA) ? publicComputerText + expectedCreditDisclaimerText : expectedCreditDisclaimerText,
        			"Correct mediaAlphaCreditCheckDisclaimer content");
        	fsa.assertEquals(getTextFromElement(mediaAlphaConsumerReportDisclaimerTextElement), farmersEntitiesString, "Correct mediaAlphaConsumerReportDisclaimer content");
        	fsa.assertEquals(getTextFromElement(mediaAlphaPrivacyPolicyDisclaimerTextElement), acknowledgeAndAgreeText, "Correct mediaAlphaPrivacyPolicyDisclaimer content");
        }
    }

    public void capturePEWC() throws Exception {
        screenCapture(creditCheckDisclaimerTextElement, "AceAuto_NameAndDOBPage", MEDIUM, true);
    }

    public void validateBDQSpecificRules(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        fsa.assertTrue(isOnNameAndDobPage(), "User is on the Personal Info page");
        fsa.assertFalse(isDiscountSectionDisplayed(), "Discount section should NOT be available on " + this.getClass().getSimpleName());
        if(isElementVisible(creditCheckDisclaimerTextElement,1)) {
        	String creditCheckDisclaimer = getTextFromElement(creditCheckDisclaimerTextElement);
        	String privacyPolicyDisclaimer = getTextFromElement(privacyPolicyDisclaimerTextElement);
            fsa.assertTrue(isExpectedTextContainedInElement(creditCheckDisclaimerTextElement, "The Bristol West") && !creditCheckDisclaimer.contains("Farmers"), "Correct credit check disclaimer for Bristol West and not Farmers on " + this.getClass().getSimpleName());
            fsa.assertTrue(isExpectedTextContainedInElement(privacyPolicyDisclaimerTextElement, "Bristol West\u00ae") && !privacyPolicyDisclaimer.contains("Farmers"), "Correct privacy policy disclaimer for Bristolwest on " + this.getClass().getSimpleName());
            fsa.assertTrue(isExpectedTextContainedInElement(privacyPolicyDisclaimerTextElement, "\"Agree\""), privacyPolicyDisclaimer + " should containing 'Agree' cta text");
            fsa.assertEquals(getTextFromElement(agreeButton), "Agree", "CTA button text is 'Agree' on " + this.getClass().getSimpleName());
        }
        validateValidateAndFooterForBDQ(fsa, applicant, this);
    }

    public void updateTheApplicantFromClickToBuyFlow(AutoApplicant applicant) throws Exception {
        if(!applicant.getTestScenario().contains(BW_CLICK_TO_BUY_FULL_FLOW)) {
            return;
        }
        String firstName = getElementValue(firstNameInputField, "First name input");
        String lastName = getElementValue(findFormFieldWebElement(LAST_NAME), "Last name input");
        String dateOfBirth = getElementValue(findFormFieldWebElement(DATE_OF_BIRTH), "Date of Birth input");
        // Only update if data is present
        if (!firstName.isBlank()) {
        	firstName = String.valueOf(firstName.charAt(0)).toUpperCase() + firstName.substring(1);
        	applicant.setFirstName(firstName);
        }
        if (!lastName.isBlank()) {
        	lastName = String.valueOf(lastName.charAt(0)).toUpperCase() + lastName.substring(1);
        	applicant.setLastName(lastName);
        }
        if (!dateOfBirth.isBlank() ) {
        	applicant.setDateOfBirth(dateOfBirth);
        }
    }

    public void clickOnPrivacyPolicyLink() throws Exception {
        waitUntilAngular5Ready();
        clickOnHiddenElement(privacyPolicy);
    }

    public boolean isPrivacyCenterTabTitleCorrect() throws Exception {
        waitUntilAngular5Ready();

        // Get the window handles
        Set<String> windowHandles = driver().getWindowHandles();

        // Switch to the next tab (second tab)
        String currentWindowHandle = driver().getWindowHandle();
        for (String handle : windowHandles) {
            if (!handle.equals(currentWindowHandle)) {
                driver().switchTo().window(handle);
                break;
            }
        }
        sleep(2);


        String privacyCenter = "Privacy Center : Farmers Insurance";
        String privacyPolicyTitle = "Privacy Policy | Farmers Insurance";
        String privacyStatement = "Privacy Statement : Farmers Insurance";
        String title = driver().getTitle();
        return title.contains(privacyCenter) || title.contains(privacyPolicyTitle) || title.contains(privacyStatement);
    }

    public boolean isPrivacyCenterPageHeaderExist() {
        return isElementVisible(privacyCenterPageHeader, 3);
    }

    public void validatePrivacyPolicyLink() throws Exception {
        String mainWindow = driver().getWindowHandle();
        clickOnPrivacyPolicyLink();
        testStepAssert(isPrivacyCenterTabTitleCorrect(), "Privacy Policy link tab title validation");
        testStepAssert(isPrivacyCenterPageHeaderExist(), "Privacy Policy link tab header validation");
        driver().close();
        driver().switchTo().window(mainWindow);
        isOnNameAndDobPage();
    }

    public void arePrefilledValuesMatching(AutoApplicant applicant, FarmersSoftAssert softAssert) throws Exception {
        softAssert.assertEquals(getElementValue(firstNameInputField, "First name"), applicant.getFirstName(), "Applicant first name is prefilled correclty");
        softAssert.assertEquals(getElementValue(findFormFieldWebElement(LAST_NAME), "Last name input"), applicant.getLastName(), "Applicant last name is prefilled correclty");
        softAssert.assertEquals(getElementValue(findFormFieldWebElement(DATE_OF_BIRTH), "Date of Birth input").replaceAll("\\D", EMPTY_STRING ), applicant.getDateOfBirth().replaceAll("\\D", EMPTY_STRING ), "Applicant DoB is prefilled correclty");

        // make sure input fields are enabled so user can edit
        softAssert.assertTrue(firstNameInputField.isEnabled(), "First name input field is enabled");
        softAssert.assertTrue(findFormFieldWebElement(LAST_NAME).isEnabled(), "Last name input field is enabled");
        softAssert.assertTrue(findFormFieldWebElement(DATE_OF_BIRTH).isEnabled(), "Dob input field is enabled");
    }

    public void validateBundleFieldsAreDisabledOnRetrieve(AutoApplicant autoApplicant, FarmersSoftAssert fsa) throws Exception {
    	PWElement lastNameInputField = findFormFieldWebElement(LAST_NAME);
    	PWElement dateOfBirthField = findFormFieldWebElement(DATE_OF_BIRTH);
		fsa.assertEquals(getAttributeData(firstNameInputField, DISABLED), LOWERCASE_TRUE, "First Name field disabled");
		fsa.assertEquals(getInputFieldValue(firstNameInputField), autoApplicant.getFirstName(), "First Name content is correct");
		fsa.assertEquals(getAttributeData(lastNameInputField, DISABLED), LOWERCASE_TRUE, "Last Name field disabled");
		fsa.assertEquals(getInputFieldValue(lastNameInputField), autoApplicant.getLastName(), "First Name content is correct");
		fsa.assertEquals(getAttributeData(dateOfBirthField, DISABLED), LOWERCASE_TRUE, "DOB field disabled");
		PWElement yourAddressText = driver().findElement(PWBy.id("formField_address"));
		fsa.assertEquals(getTextFromElement(yourAddressText), "Your address " + autoApplicant.getResidentAddress() + SPACE +  autoApplicant.getCity() + ", " + autoApplicant.getStateCode() + SPACE + autoApplicant.getZipCode(),
				"Listed address is correct");
   }

    /**
     * Validates the Bristol West rebrand highlighted tooltip card on the Name & DOB page.
     * Covers: container visibility, lightbulb icon, bold title, and content text.
     *
     * @param fsa FarmersSoftAssert instance for soft assertions
     */
    public void validateHighlightedTooltipRebrand(FarmersSoftAssert fsa) {
        fsa.assertTrue(isElementVisible(highlightedTooltipRebrandContainer, 1),
                "Highlighted rebrand tooltip container should be visible on the Name & DOB page");

        fsa.assertTrue(isElementVisible(highlightedTooltipBulbIcon, 1),
                "Lightbulb icon should be visible in the rebrand tooltip");
        fsa.assertEquals(getAttributeData(highlightedTooltipBulbIcon, "alt"), HIGHLIGHTED_TOOLTIP_BULB_ICON_ALT,
                "Lightbulb icon alt text should be: " + HIGHLIGHTED_TOOLTIP_BULB_ICON_ALT);

        fsa.assertEquals(getTextFromElement(highlightedTooltipTitle), HIGHLIGHTED_TOOLTIP_TITLE_TEXT,
                "Rebrand tooltip title should be: " + HIGHLIGHTED_TOOLTIP_TITLE_TEXT);

        fsa.assertTrue(getTextFromElement(highlightedTooltipContent).contains(HIGHLIGHTED_TOOLTIP_CONTENT_TEXT),
                "Rebrand tooltip content should contain: " + HIGHLIGHTED_TOOLTIP_CONTENT_TEXT);
    }

}
