package com.farmers.ffq.ace.hrc.common;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.common.pages.PaymentSelectionBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Home.VerifyResponse;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;


public class AceHRCPaymentSelectionPage extends PaymentSelectionBasePage {
    private static final String SELECT_AND_SET_UP_PAYMENT_TEXT = "Select & set up payment";
    private static final String TWELVE_MONTHLY_PAYMENT = "12 monthly payments";
    private static final String TWELVE_MONTH_TERM_TOTAL_COST = "12-month term total cost";


    @PWFindBy(xpath = "//div[contains(@class,'payment-overview')]//h1")
    protected PWElement howWouldYouLikeToPay;

    @PWFindBy(xpath = "//div[contains(@class,'payment-overview')]//a")
    private PWElement changeYourCoverageLink;

    @PWFindBy(xpath = "//div[contains(@class,'payment-overview-sub-para')]")
    private PWElement baseOnThirdPartyInfoSubText;
    @PWFindBy(xpath = "//button[@aria-label='Pay in full, Select and setup payment']")
    private List<PWElement> selectAndSetUpPaymentButtonPayInFull;
    @PWFindBy(xpath = "//button[@aria-label='Monthly autopay bank, Select and setup payment']")
    private PWElement selectAndSetUpPaymentButtonMonthlyBank;
    @PWFindBy(xpath = "//input[@value='MTEF']")
    private PWElement selectAndSetUpPaymentButtonMonthlyBankRenters;
    @PWFindBy(xpath = "//button[@aria-label='Monthly autopay card, Select and setup payment']")
    private PWElement selectAndSetUpPaymentButtonMonthlyCard;
    @PWFindBy(xpath = "//mat-radio-button[@value='card']//label")
    private PWElement selectAndSetUpPaymentButtonMonthlyCardLabel;
    @PWFindBy(xpath = "//mat-radio-button[@value='bank']//label")
    private PWElement selectAndSetUpPaymentButtonMonthlyBankPaymentLabel;
    @PWFindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_CARD_HEADER + "')]")
    private List<PWElement> payInMonthlyPayCardHeader;

    @PWFindBy(xpath = "//mat-tab-group//div[@role='tab']//*[contains(text(),'" + PAY_IN_FULL + "')]")
    private PWElement payInFullTabMobile;
    @PWFindBy(xpath = "//mat-tab-group//div[@role='tab']//*[contains(text(),'" + MONTHLY_PAY_BANK_HEADER + "')]")
    private PWElement monthlyPayBankTabMobile;
    @PWFindBy(xpath = "//mat-tab-group//div[@role='tab']//*[contains(text(),'" + MONTHLY_PAY_CARD_HEADER + "')]")
    private PWElement monthlyPayCardTabMobile;
    private final String PAYMENT_OVERVIEW_HEADER_XPATH = "//h1[contains(@class,'payment-overview-header-text')]";
    @PWFindBy(xpath = PAYMENT_OVERVIEW_HEADER_XPATH)
    private PWElement payForPropertyTitle;
    @PWFindBy(xpath = PAYMENT_OVERVIEW_HEADER_XPATH + "/following-sibling::div[1]")
    private PWElement autoPaymentSuccessMessage;
    AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();

    @PWFindBy(xpath = "//mat-card//span[contains(@class,'payment-bank-downpayment')]")
    private List<PWElement> cardPaymentAmounts;


    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceHRCPaymentSelectionPage() throws Exception {
    }

    public boolean isOnPaymentPage() {
        return isElementVisible(howWouldYouLikeToPay, Property.PAGELOADTIMEOUT);
    }

    public boolean quickIsOnPaymentPage() {
        return isElementVisible(howWouldYouLikeToPay, 5);
    }

    public void validateHeadersAndTextPaymentSelection(FarmersSoftAssert sa, String lobType) throws Exception {
        wait.until(PWExpectedConditions.elementToBeClickable(howWouldYouLikeToPay));

        String expectedHowWouldYouLikeToPayText = "How would you like to pay?";
        sa.assertEquals(getTextFromElement(howWouldYouLikeToPay), expectedHowWouldYouLikeToPayText,"How would you like to pay question is not matching - " + lobType);
        sa.assertTrue(isElementInViewport(howWouldYouLikeToPay), "Payment selection page - page title is in Viewport - " + lobType);

        if(lobType.equals(HOME)){
            String expectedChangeYourOptionsLinkText = "change your coverage options";
            String expectedBaseOnThirdPartySubText = "Based on third-party information and information you provided";

            sa.assertTrue(getTextFromElement(baseOnThirdPartyInfoSubText).contains(expectedBaseOnThirdPartySubText), expectedBaseOnThirdPartySubText + " message is not included in subtext - " + lobType);
            sa.assertTrue(getTextFromElement(baseOnThirdPartyInfoSubText).contains(expectedChangeYourOptionsLinkText), expectedBaseOnThirdPartySubText + " message does not contain change your coverage options link - " + lobType);
        }
    }

    public void validatePayInFullPaymentCard(FarmersSoftAssert fsa, String stateCode, String lobType) throws Exception {
        //validate pay in full section
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(payInFullTabMobile);
        }
        aceHRCValidatePayInFullCardHeaderTextValidation(fsa, stateCode, lobType);
        aceHRCValidatePayInFullAmountSection(fsa, stateCode, lobType);
    }


    public void validateMonthlyAutoPayPaymentBank(FarmersSoftAssert fsa, String stateCode, String lobType) throws Exception {
        //validate monthly auto pay bank section
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(monthlyPayBankTabMobile);
        }
        aceHRCValidateMonthlyAutoPayBankHeadersTextValidation(fsa, stateCode, lobType);
        aceHRCValidateAmountsInMonthlyAutoPayBank(fsa, stateCode, lobType);
    }

    public void validateMonthlyAutoPayPaymentCard(FarmersSoftAssert fsa, String stateCode, String lobType) throws Exception {
        //validate monthly auto pay card section
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(monthlyPayCardTabMobile);
        }
        aceHRCValidateMonthlyAutoPayCardTextsSection(fsa, stateCode, lobType);
        aceHRCValidateAmountsInMonthlyAutoPayCard(fsa, stateCode, lobType);
    }


    public void aceHRCValidatePayInFullCardHeaderTextValidation(FarmersSoftAssert fsa, String stateCode, String lobType) {
        boolean isDisplayed = false;
        int numberOfHeaders = payInFullHeader.size();
        for (int i=0; i < numberOfHeaders; i++) {
            if (payInFullHeader.get(i).isDisplayed()) {
                waitForPageToBeReady();
                isDisplayed = true;
                fsa.assertTrue(isDisplayed, "Pay in full header is displayed - " + lobType);
                fsa.assertTrue((bestValueSubHeader.get(i).isDisplayed()), "Best value sub text is displayed - " + lobType);
                fsa.assertTrue(oneTimePaymentSubHeader.get(i).isDisplayed(), "One time payment sub header is displayed - " + lobType);
                fsa.assertTrue(preferredPayPlanSavings.get(i).isDisplayed(), "Preferred pay plan savings is displayed - " + lobType);
                fsa.assertTrue(noServiceChargeWhenPayInFull.get(i).isDisplayed(), "No service charge is displayed - " + lobType + " i=" + i);
                // F91172 - FFQ Payment Screen Enhancement for Fees and Surcharges - KY state changes
                List<PWElement> includeFeesSurchargePayInFullElement = aceHRCPaymentBasePage.isExcludedFeeState(stateCode) ? excludeFeesSurchargePayInFull : includeAllFeesPayInFull;
                fsa.assertTrue(isElementDisplayed(includeFeesSurchargePayInFullElement.get(i), 3), "Include/Exclude Fees label is displayed - " + lobType);
                fsa.assertTrue(bankDebitCreditCardPayment.get(i).isDisplayed(), "Bank debit credit card payment is displayed - " + lobType);
                fsa.assertTrue(selectAndSetUpPaymentButtonPayInFull.get(i).isEnabled(), "Select and set up payment button for pay in full card is enabled - " + lobType);
                fsa.assertEquals(getTextFromElement(selectAndSetUpPaymentButtonPayInFull.get(i)), SELECT_AND_SET_UP_PAYMENT_TEXT,
                        "Select and set up payment button text is matching - " + lobType);
            }
        }
        fsa.assertTrue(isDisplayed, "Payment Selection page - displayed payInFullHeader element");
    }

    public void aceHRCValidatePayInFullAmountSection(FarmersSoftAssert fsa, String stateCode, String lobType) throws Exception {
        String downPayment = aceHRCPaymentBasePage.getDownPaymentHRC(ONE_PAY);
        Double doublePolicyFees = doublePolicyFeeAmount(aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC().getPolicyFee().getAmount());
        // F91172, F98974/US1101544 - FFQ Payment Screen Enhancement for Fees and Surcharges - KY, MN state changes
        Double payInFullAmountAbovePart = aceHRCPaymentBasePage.isExcludedFeeState(stateCode) ? Double.parseDouble(downPayment) : doublePolicyFees + Double.parseDouble(downPayment);
        if (aceHRCPaymentBasePage.isFairPlanFeeState(stateCode)) {
            payInFullAmountAbovePart += new AceHRCConsolidatedPaymentPage().getFeeSurchargeAmountFromAppStore(aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC());
        }
        List<String> splitAmountByDecimalPoint = splitAmountByDecimalPoint(payInFullAmountAbovePart.toString());

        // Pay In Full One Time Payment Validation above part
        List<PWElement> listOfFullAmountWebElementsByDiv =  listOfFullAmountWebElements(splitAmountByDecimalPoint.get(0), "div", false);
        isElementListSizeGreaterThanZero(listOfFullAmountWebElementsByDiv, "Pay in full one time payment is not matching - " + lobType, fsa);

        // Pay In Full One Time Payment Validation below part
        List<PWElement> listOfFullAmountWebElementsBySpan =  listOfFullAmountWebElements(splitAmountByDecimalPoint.get(0), "span", false);
        isElementListSizeGreaterThanZero(listOfFullAmountWebElementsBySpan, "Pay in full 12 month term total cost amount is not matching - " + lobType, fsa);

        if(splitAmountByDecimalPoint.size() == 2){
            List<PWElement> listOfDecimalOnePayWebElementByDiv = listOfFullAmountWebElements(splitAmountByDecimalPoint.get(1), "span",false);
            isElementListSizeGreaterThanZero(listOfDecimalOnePayWebElementByDiv, "One Pay Decimal Amount Is Not Displayed.", fsa);

            List<PWElement> listOfDecimalOnePayWebElementBySpan =  listOfFullAmountWebElements(splitAmountByDecimalPoint.get(1), "span", false);
            isElementListSizeGreaterThanZero(listOfDecimalOnePayWebElementBySpan, "One Pay Decimal Amount Below Is Not Displayed.", fsa);
        }
        // Validate Pay in full amount is the lesser amount of all payment options
        List<String> paymentAmounts = cardPaymentAmounts.stream().map(this::getTextFromElement).collect(Collectors.toList());
        if (paymentAmounts.size() > 2) {
            List<Double> dPaymentAmounts = paymentAmounts.stream().map(s -> s.replaceAll("\\D",EMPTY_STRING)).map(Double::parseDouble).collect(Collectors.toList());
            fsa.assertTrue(dPaymentAmounts.get(1) <= dPaymentAmounts.get(2),
                    "Pay in full amount: " + dPaymentAmounts.get(1) + " is less than Monthly pay option 1: " + dPaymentAmounts.get(2));
            if (paymentAmounts.size() > 3) {
                fsa.assertTrue(dPaymentAmounts.get(1) <= dPaymentAmounts.get(3),
                        "Pay in full amount: " + dPaymentAmounts.get(1) + " is less than Monthly pay option 2: " + dPaymentAmounts.get(3));
            }
        }

    }

    public void aceHRCValidateMonthlyAutoPayBankHeadersTextValidation(FarmersSoftAssert sa, String stateCode, String lobType) throws Exception {
        sa.assertEquals(getTextFromElement(payInMonthlyPayBankHeader.get(0)), MONTHLY_AUTO_PAY_BANK_HEADER, "Monthly pay bank card header validation - " + lobType);
        sa.assertEquals(getTextFromElement(getPaymentCardSubHeaderByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER)), CONVENIENT, "Monthly pay bank card header subtitle validation - " + lobType);
        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + "//p[contains(text(),'"+ TWELVE_MONTHLY_PAYMENT +"')]")), TWELVE_MONTHLY_PAYMENT + " text should be available in monthly bank pay section - " + lobType);

        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + AUTO_PAY_SAVINGS_XPATH_GREEN_CHECKMARK)), AUTO_PAY_SAVINGS_TEXT + " green check should be available in monthly bank pay section - " + lobType);
        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + AUTO_PAY_SAVINGS_XPATH)), AUTO_PAY_SAVINGS_TEXT + " text should be available in monthly bank pay section - " + lobType);
        PWElement autoPaySavingsWebElement = driver().findElement(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + AUTO_PAY_SAVINGS_XPATH));
        sa.assertTrue(getTextFromElement(autoPaySavingsWebElement).equals(AUTO_PAY_SAVINGS_TEXT), AUTO_PAY_SAVINGS_TEXT + " text is not matching in monthly bank pay section - " + lobType);

        // Getting the expected administrative fee amounts from performHomeVerify response
        int administrativeFeeForGivenPayPlanDescription = aceHRCPaymentBasePage.getAdministrativeFeeForGivenPayPlanDescriptionHRC(
                aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC().getPaymentSchedules(), MONTHLY_EFT);
        if(administrativeFeeForGivenPayPlanDescription == 0) {
            sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + "//p[contains(.,'" + NO_SERVICE_CHARGE + "')]")), NO_SERVICE_CHARGE + " text should be present for Monthly pay bank section - " + lobType);
        } else {
            String expectedFeeForBankPayment = String.format("$%d  monthly service charge", administrativeFeeForGivenPayPlanDescription);
            sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + "//p[contains(.,'" + expectedFeeForBankPayment + "')]")), expectedFeeForBankPayment + " text should be present for Monthly pay bank section - " + lobType);
        }

        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + "//p[contains(text(), '" + TWELVE_MONTH_TERM_TOTAL_COST + "')]")), TWELVE_MONTH_TERM_TOTAL_COST + " text should be present in monthly pay bank section - " + lobType);
        // F91172, F98974/US1101544,US1104962 - FFQ Payment Screen Enhancement for Fees and Surcharges - KY, MN state changes
        String includeExcludeFeesTitle = aceHRCPaymentBasePage.isExcludedFeeState(stateCode) ? EXCLUDE_TAXES_TEXT : INCLUDES_ALL_FEES;
        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + "//p[contains(text(), '" + includeExcludeFeesTitle + "')]")), includeExcludeFeesTitle + " text should be present in monthly pay bank section - " + lobType);
        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + "//p[contains(text(),'"+ BANK_PAYMENT+"')]")), "Bank payment text should be available in monthly bank pay section - "+ lobType);
    }

    public void aceHRCValidateAmountsInMonthlyAutoPayBank(FarmersSoftAssert sa, String stateCode, String lobType) throws Exception {
        VerifyResponse verifyResponse = aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC();
        Double doublePolicyFees = doublePolicyFeeAmount(verifyResponse.getPolicyFee().getAmount());
        String monthlyBankDownPayment = String.format("$%,.2f", Double.parseDouble(aceHRCPaymentBasePage.getDownPaymentHRC(MONTHLY_EFT)));
        List<VerifyResponse.PaymentSchedule> paymentSchedules = verifyResponse.getPaymentSchedules();
        String fullTermPremium = paymentSchedules.stream().filter(paymentSchedule -> paymentSchedule.getPayPlanDescription().equals(MONTHLY_EFT)).collect(Collectors.toList()).stream().findFirst().get().getFullTermPremium();
        int administrativeFeeForGivenPayPlanDescription = aceHRCPaymentBasePage.getAdministrativeFeeForGivenPayPlanDescriptionHRC(paymentSchedules, MONTHLY_EFT);
        Double totalMonthlyBankPaymentAmountD = aceHRCPaymentBasePage.isExcludedFeeState(stateCode) ? Double.parseDouble(fullTermPremium) : Double.parseDouble(fullTermPremium) + doublePolicyFees + (administrativeFeeForGivenPayPlanDescription * 11);
        if (aceHRCPaymentBasePage.isFairPlanFeeState(stateCode)) {
           totalMonthlyBankPaymentAmountD += new AceHRCConsolidatedPaymentPage().getFeeSurchargeAmountFromAppStore(verifyResponse);
        }
        String totalMonthlyBankPaymentAmount = String.format("$%,.2f", totalMonthlyBankPaymentAmountD).replace(SPACE, EMPTY_STRING);
        PWElement monthlyBankDownPaymentElement = driver().findElement(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + DOWN_PAYMENT_XPATH));
        sa.assertEquals(getTextFromElement(monthlyBankDownPaymentElement).replace(SPACE, EMPTY_STRING), monthlyBankDownPayment, MONTHLY_AUTO_PAY_BANK_HEADER + " down payment amount validation - " + lobType);

        PWElement monthlyBankTotalAmountElement = driver().findElement(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + TOTAL_PAYMENT_OVERVIEW_CARD_PREMIUM_XPATH));
        sa.assertEquals(getTextFromElement(monthlyBankTotalAmountElement).replace(SPACE, EMPTY_STRING), totalMonthlyBankPaymentAmount, MONTHLY_AUTO_PAY_BANK_HEADER + " total amount validation - " + lobType);
    }


    public void aceHRCValidateMonthlyAutoPayCardTextsSection(FarmersSoftAssert sa, String stateCode, String lobType) throws Exception {
        sa.assertEquals(getTextFromElement(payInMonthlyPayCardHeader.get(0)), MONTHLY_AUTO_PAY_CARD_HEADER, "Monthly pay card card header validation - " + lobType);
        sa.assertEquals(getTextFromElement(getPaymentCardSubHeaderByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER)), CONVENIENT, "Monthly pay card card header subtitle validation - " + lobType);
        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + "//p[contains(text(), '" + TWELVE_MONTHLY_PAYMENT + "')]")), TWELVE_MONTHLY_PAYMENT + " text should be present in monthly pay card section");

        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + AUTO_PAY_SAVINGS_XPATH_GREEN_CHECKMARK)), AUTO_PAY_SAVINGS_TEXT + " green check should be available in monthly bank pay section - " + lobType);
        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + AUTO_PAY_SAVINGS_XPATH)), AUTO_PAY_SAVINGS_TEXT + " text should be available in monthly bank pay section - " + lobType);
        PWElement autoPaySavingsWebElement = driver().findElement(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + AUTO_PAY_SAVINGS_XPATH));
        sa.assertTrue(getTextFromElement(autoPaySavingsWebElement).equals(AUTO_PAY_SAVINGS_TEXT), AUTO_PAY_SAVINGS_TEXT + " text is not matching in monthly bank pay section - " + lobType);

        // Getting the expected administrative fee amounts from performAutoVerify response
        List<AppStore.Home.VerifyResponse.PaymentSchedule> paymentSchedules = aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC().getPaymentSchedules();

        int expectedMonthlyPayDebitCardAdministrativeFee = aceHRCPaymentBasePage.getAdministrativeFeeForGivenPayPlanDescriptionHRC(paymentSchedules, MONTHLY_DEBIT_CARD_DESCRIPTION);
        int expectedMonthlyPayCreditCardAdministrativeFee = aceHRCPaymentBasePage.getAdministrativeFeeForGivenPayPlanDescriptionHRC(paymentSchedules, MONTHLY_DEBIT_CREDIT_CARD);
        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + "//p[contains(.,'" + MONTHLY_SERVICE_CHARGE + "')]")), MONTHLY_SERVICE_CHARGE + " text should be available in monthly auto pay card section - " + lobType);
        String expectedMonthlyPayDebitCardAdministrativeFeeLabel = String.format("$%d:  Debit card", expectedMonthlyPayDebitCardAdministrativeFee);
        String expectedMonthlyPayCreditCardAdministrativeFeeLabel = String.format("$%d:  Credit card", expectedMonthlyPayCreditCardAdministrativeFee);

        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + "//p[contains(.,'"+ expectedMonthlyPayDebitCardAdministrativeFeeLabel +"')]")), "Monthly Debit Card Administrative/Service Fee amount is not matching in monthly pay card section- " + lobType);
        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + "//p[contains(.,'"+ expectedMonthlyPayCreditCardAdministrativeFeeLabel +"')]")), "Monthly Credit Card Administrative/Service Fee amount is not matching in monthly pay card section- " + lobType);
        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + "//p[contains(text(), '" + TWELVE_MONTH_TERM_TOTAL_COST + "')]")), TWELVE_MONTH_TERM_TOTAL_COST + " text should be present in monthly pay card section - " + lobType);
        // F91172, F98974/US1101544,US1104962 - FFQ Payment Screen Enhancement for Fees and Surcharges - KY, MN state changes
        String includeExcludeFeesTitle = aceHRCPaymentBasePage.isExcludedFeeState(stateCode) ? EXCLUDE_TAXES_TEXT : INCLUDES_ALL_FEES;
        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + "//p[contains(text(), '" + includeExcludeFeesTitle + "')]")), includeExcludeFeesTitle + " text should be present in monthly pay card section - " + lobType);
        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + "//p[contains(.,'Debit card ')]")), "Debit card text - at the bottom of the page - should be available in monthly card pay section - " + lobType);
        sa.assertTrue(isElementPresent(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + "//p[contains(text(), 'Credit card:')]")), "Credit card text - at the bottom of the page - should be available in monthly card pay section - " + lobType);
    }


    public void aceHRCValidateAmountsInMonthlyAutoPayCard(FarmersSoftAssert sa, String stateCode, String lobType) throws Exception {
        VerifyResponse verifyResponse = aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC();
        Double doublePolicyFees = doublePolicyFeeAmount(verifyResponse.getPolicyFee().getAmount());
        String monthlyCardDownPayment = String.format("$%,.2f", Double.parseDouble(aceHRCPaymentBasePage.getDownPaymentHRC(MONTHLY_DEBIT_CARD_DESCRIPTION)));
        VerifyResponse.PaymentSchedule debitCardPaymentSchedule = verifyResponse.getPaymentSchedules().stream().filter(paymentSchedule -> paymentSchedule.getPayPlanDescription().equals(MONTHLY_DEBIT_CARD_DESCRIPTION)).collect(Collectors.toList()).stream().findFirst().get();
        VerifyResponse.PaymentSchedule creditCardPaymentSchedule = verifyResponse.getPaymentSchedules().stream().filter(paymentSchedule -> paymentSchedule.getPayPlanDescription().equals(MONTHLY_DEBIT_CREDIT_CARD)).collect(Collectors.toList()).stream().findFirst().get();
        String fullTermPremiumForDebitCard = debitCardPaymentSchedule.getFullTermPremium();
        String fullTermPremiumForCreditCard = creditCardPaymentSchedule.getFullTermPremium();
        // F91172, F98974/US1101544,US1104962 - FFQ Payment Screen Enhancement for Fees and Surcharges - KY, MN state changes
        Double totalMonthlyBankPaymentAmountForDebitCardDouble = aceHRCPaymentBasePage.isExcludedFeeState(stateCode) ? Double.parseDouble(fullTermPremiumForDebitCard) : Double.parseDouble(fullTermPremiumForDebitCard) + doublePolicyFees + ( 11 * Double.parseDouble(debitCardPaymentSchedule.getAdministrativeCharges().getCurrencyAmount()));
        Double totalMonthlyBankPaymentAmountForCreditCardDouble = aceHRCPaymentBasePage.isExcludedFeeState(stateCode) ? Double.parseDouble(fullTermPremiumForCreditCard) : Double.parseDouble(fullTermPremiumForCreditCard) + doublePolicyFees + ( 11 * Double.parseDouble(creditCardPaymentSchedule.getAdministrativeCharges().getCurrencyAmount()));
        if (aceHRCPaymentBasePage.isFairPlanFeeState(stateCode)) {
            totalMonthlyBankPaymentAmountForDebitCardDouble += new AceHRCConsolidatedPaymentPage().getFeeSurchargeAmountFromAppStore(verifyResponse);
            totalMonthlyBankPaymentAmountForCreditCardDouble += new AceHRCConsolidatedPaymentPage().getFeeSurchargeAmountFromAppStore(verifyResponse);
        }
        String totalMonthlyBankPaymentAmountForDebitCard = String.format("$%,.2f", totalMonthlyBankPaymentAmountForDebitCardDouble);
        String totalMonthlyBankPaymentAmountForCreditCard = String.format("$%,.2f", totalMonthlyBankPaymentAmountForCreditCardDouble);
        PWElement monthlyBankDownPaymentElement = driver().findElement(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + DOWN_PAYMENT_XPATH));
        sa.assertEquals(getTextFromElement(monthlyBankDownPaymentElement).replace(SPACE, EMPTY_STRING), monthlyCardDownPayment, MONTHLY_AUTO_PAY_CARD_HEADER + " down payment amount validation - " + lobType);
        PWElement monthlyCardTotalAmountElement = driver().findElement(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + TOTAL_PAYMENT_OVERVIEW_CARD_PREMIUM_XPATH));
        sa.assertEquals(getTextFromElement(monthlyCardTotalAmountElement).replace(SPACE, EMPTY_STRING), totalMonthlyBankPaymentAmountForDebitCard, MONTHLY_AUTO_PAY_CARD_HEADER + " debit total amount validation - " + lobType);
        PWElement creditCardTotalElement = driver().findElement(PWBy.xpath("//p[contains(@class,'tui-caption-text payment-overview-payment-debit-tex')]"));
        sa.assertEquals(getTextFromElement(creditCardTotalElement).replace(SPACE, EMPTY_STRING).replace("Creditcard:", "Credit card: "), String.format("Credit card: %s", totalMonthlyBankPaymentAmountForCreditCard),
                MONTHLY_AUTO_PAY_CARD_HEADER + "credit total amount validation - " + lobType);

    }
    public void clickSelectAndSetUpPaymentPayInFullCard(String lob) {
    	if (!selectAndSetUpPaymentButtonPayInFull.isEmpty()) {
    		if (isUseMobileViewEnabled()) {
    			clickElement(payInFullTabMobile);
    		}
    		int indexCount = !lob.contains(RENTERS) ? 0 : 1;
    		clickElement(selectAndSetUpPaymentButtonPayInFull.get(indexCount));
    	}
    }

    public void clickSelectAndSetUpPaymentMonthlyPayBank(){
        clickElement(selectAndSetUpPaymentButtonMonthlyBank);
    }

    public void clickSelectAndSetUpPaymentMonthlyPayBankRenters(){
        clickElement(selectAndSetUpPaymentButtonMonthlyBankRenters);
    }

    public void clickSelectAndSetUpPaymentMonthlyPayCard(){
        clickElement(selectAndSetUpPaymentButtonMonthlyCard);
    }

    public void clickSelectAndSetUpPaymentMonthlyPayCardLabelRenters() throws Exception {
        scrollAndClickOnElement(waitElementBeVisible(selectAndSetUpPaymentButtonMonthlyCardLabel, 5));
    }

    public void clickSelectAndSetUpPaymentMonthlyPayBankPaymentLabelRenters() throws Exception {
        scrollAndClickOnElement(selectAndSetUpPaymentButtonMonthlyBankPaymentLabel);
    }
    public void clickPayInFullTabMobile(){
        clickElement(payInFullTabMobile);
    }
    public void clickMonthlyPayBankTabMobile(){
        clickElement(monthlyPayBankTabMobile);
    }
    public void clickMonthlyPayCardTabMobile(){
        clickElement(monthlyPayCardTabMobile);
    }

    public void verifyAceBundleHRCPaymentPageContent(FarmersSoftAssert fsa) throws Exception {
        waitElementBeVisible(payForPropertyTitle);
        fsa.assertTrue(getListOfSteps().isEmpty(), "Stepper is not available on HRC payment page");
        fsa.assertEquals(getTextFromElement(payForPropertyTitle), "Next: Pay for property", "Ace Bundle pay for property title verification");
        String expectedAutoPaymentSuccessMessage = "Success! You've paid for your auto policy. You can now choose payment options for your property policy.";
        fsa.assertEquals(getTextFromElement(autoPaymentSuccessMessage), expectedAutoPaymentSuccessMessage, "Auto payment success message verification");
    }
}
