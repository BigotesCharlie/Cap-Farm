package com.farmers.ffq.dataproviders;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.dataproviderframework.DataObjectBase;
import com.farmers.ffq.dataproviderframework.DataProviderBase;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.datatransferobjects.hqm.ApexHQM;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.framework.Property;
import com.farmers.framework.data.ExcelDataProvider;
import com.farmers.framework.report.Log;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.datafaker.Faker;

import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class DataProviders extends DataProviderBase {
	protected static final String SELECTED_DATA_PROVIDER_ROWS = "Selected data provider row(s)=";
	protected static final String HAS_ROWS_OF_DATA = " has rows of data: ";
	private static final String STATE_CODE_EQUALS = "stateCode=";
	public static final String ONE_APPLICANT_PER_STATE = "OneApplicantPerState";

	public static final String APPLICANT_HOME_DATA_PROVIDER = "ApplicantHomeDataProvider";
	public static final String APPLICANT_HOME_ERROR_DATA_PROVIDER = "ApplicantHomeErrorDataProvider";
	public static final String APPLICANT_HOME_SMOKE_DATA_PROVIDER = "ApplicantHomeSmokeDataProvider";
	public static final String GET_RETRIEVE_QUOTE_APPLICANT_HOME = "GetRetrieveQuoteApplicantHome";
	public static final String MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER = "MonetizedLegacyHomeApplicantDataProvider";
	public static final String APPLICANT_HQM_DATA_PROVIDER = "ApplicantHQMDataProvider";
	public static final String APPLICANT_HQM_MONETIZATION_DP = "ApplicantHQMMonetizationDataProvider";
	public static final String APEX_HQM_DATA_PROVIDER = "ApexHQMDataProvider";
	public static final String APPLICANT_HQM_PROD_DATA_PROVIDER = "ApplicantHQMProdDataProvider";
	public static final String ACE_LIFE_APPLICANTS_DATA_PROVIDER = "AceLifeApplicantsDataProvider";
	public static final String ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER = "OneAceLifeApplicantDataProvider";
	public static final String ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES = "AceLifeApplicantsFromAFewStatesDataProvider";
	public static final String PRODUCTION_TEST_LIFE_APPLICANT_DATA_PROVIDER = "ProductionTestLifeApplicantDataProvider";
	public static final String BUSINESS_APPLICANT_DATA_PROVIDER = "BusinessApplicantDataProvider";
	public static final String ONE_BUSINESS_APPLICANT_DATA_PROVIDER = "OneBusinessApplicantDataProvider";
	public static final String PRODUCTION_TEST_BUSINESS_APPLICANT_DATA_PROVIDER = "productionValidationBuisinessDataProvider";
	public static final String ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER = "AllAceMobileHomeApplicantsDataProvider";
	public static final String RANDOM_MOBILEHOME_APPLICANT = "RandomAceMobileHomeApplicantDataProvider";
	public static final String ONE_MOBILEHOME_APPLICANT_PER_STATE = "OneAceMobileHomeApplicantPerStateDataProvider";
	public static final String ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES = "OneAceMobileHomeApplicantPerRandomStatesDataProvider";
	private static final String HOME_CONDO_RENTERS_FILE_NAME = "src/test/resources/HomeTestData.xlsx";
	private static final String BUSINESS_FILE_NAME = "src/test/resources/BusinessTestData.xlsx";
	private static final String LIFE_FILE_NAME = "src/test/resources/LifeTestData.xlsx";
	private static final String HQM_FILE_NAME = "src/test/resources/HQMTestData.xlsx";
	private static final String HQM_APEX_FILE_NAME = "src/test/resources/HQMApexTestData.xlsx";
	protected static final String ACE_HOME_FILE_NAME = "src/test/resources/AceHomeTestData.xlsx";
	private static final String JSON_LOG_INFO = "Data provider row %s%n %s%n";
	protected static final String HOMEDP_JSON = "applicantHome " + JSON_LOG_INFO;
	private static final String LIFEDP_JSON = "applicantLife " + JSON_LOG_INFO;
	protected static final String DP_LOG_ENTRY = "=== %s has %d rows of data ===";
	private static final String HQM_DP_JSON = "applicantHQM - DataProvider %s%n%s%n";

	private static final String BUSINESS_APPLICANT_PAGE = "businessApplicant";
	protected static final String HOME_APPLICANT_PAGE = "ApplicantHome";
	private static final String HQM_APEX_APPLICANT_PAGE = "ApexHQM";
	private static final String LIFE_APPLICANT_PAGE = "ApplicantLife";
	protected static final Random randomNumberGenerator = new Random();

	@DataProvider(name = APPLICANT_HOME_DATA_PROVIDER, parallel = true)
	public Iterator<ApplicantHome> applicantHome(Method m) throws Exception {
		List<ApplicantHome> entries = new ArrayList<>();
		List<String> listOfApplicableStates = updateListOfStatesWithTestAttributeAndStateListProperty(m, getListOfLegacyHomeStates(Property.getUri()));
		if (!listOfApplicableStates.isEmpty()) {
			entries = listOfHomeApplicants(HOME_APPLICANT_PAGE, NO_FILTER);
			entries.removeIf(homeApplicant -> !listOfApplicableStates.contains(homeApplicant.getStateCode()));
		}
		Log.warn(String.format(DP_LOG_ENTRY, APPLICANT_HOME_DATA_PROVIDER, entries.size()));
		return entries.iterator();
	}

	@DataProvider(name = APPLICANT_HOME_SMOKE_DATA_PROVIDER, parallel = true)
	public Iterator<ApplicantHome> applicantHomeSmoke(Method m) throws Exception {
		List<ApplicantHome> entries = new ArrayList<>();
		List<String> listOfApplicableStates = updateListOfStatesWithTestAttributeAndStateListProperty(m, getListOfLegacyHomeStates(Property.getUri()));
		if (!listOfApplicableStates.isEmpty()) {
			entries = listOfHomeApplicants(HOME_APPLICANT_PAGE, "lastName=Barnert");
			Collections.shuffle(listOfApplicableStates);
			entries.removeIf(homeApplicant -> !homeApplicant.getStateCode().equals(listOfApplicableStates.get(FIRST_AVAILABLE_OPTION)));
		}
		Log.warn(String.format(DP_LOG_ENTRY, APPLICANT_HOME_SMOKE_DATA_PROVIDER, entries.size()));
		return entries.iterator();
	}

	@DataProvider(name = APPLICANT_HOME_ERROR_DATA_PROVIDER, parallel = true)
	public Iterator<ApplicantHome> applicantHomeErrorValidation() throws Exception {
		List<ApplicantHome> entries = listOfHomeApplicants(HOME_APPLICANT_PAGE, "errorScenario=DISABLED");
		Log.warn(String.format(DP_LOG_ENTRY, APPLICANT_HOME_ERROR_DATA_PROVIDER, entries.size()));
		return entries.iterator();
	}

	@DataProvider(name = MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER, parallel = true)
	public Iterator<ApplicantHome> aorHomeApplicant(Method m) throws Exception {
		List<ApplicantHome> entries = new ArrayList<>();
		List<String> listOfApplicableStates = updateListOfStatesWithTestAttributeAndStateListProperty(m, getListOfLegacyHomeMonetizedStates(Property.getUri()));
		if (!listOfApplicableStates.isEmpty()) {
			entries = listOfHomeApplicants(HOME_APPLICANT_PAGE, NO_FILTER);
			entries.removeIf(homeApplicant -> !listOfApplicableStates.contains(homeApplicant.getStateCode()));
			entries = homeDataProviderScenarios(m, entries, listOfApplicableStates);
		}
		Log.warn(String.format(DP_LOG_ENTRY, MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER, entries.size()));
		return entries.iterator();
	}

	private List<ApplicantHome> homeDataProviderScenarios(Method m, List<ApplicantHome> entries, List<String> listOfApplicableStates) {
		Test annotation = m.getAnnotation(Test.class);
		if (annotation != null) {
			String dataProviderScenario = annotation.testName();
			if (dataProviderScenario != null && dataProviderScenario.equals(ONE_APPLICANT_PER_STATE)) {
				List<ApplicantHome> listOfRandomEntries = new ArrayList<>();
				for (String stateCode : listOfApplicableStates) {
					if (entries.stream().anyMatch(homeApplicant -> (homeApplicant.getStateCode().equals(stateCode)))) {
						List<ApplicantHome> tempEntries = entries.stream().filter(applicant -> applicant.getStateCode().equals(stateCode)).collect(Collectors.toList());
						listOfRandomEntries.add(tempEntries.get(randomNumberGenerator.nextInt(tempEntries.size())));
					}
				}
				entries = listOfRandomEntries;
			}
		}
		return entries;
	}

	@DataProvider(name = GET_RETRIEVE_QUOTE_APPLICANT_HOME, parallel = true)
	public Iterator<ApplicantHome> getRetrieveQuoteHome(Method m) throws Exception {
		List<ApplicantHome> entries = new ArrayList<>();
		List<String> listOfApplicableStates = updateListOfStatesWithTestAttributeAndStateListProperty(m, getListOfLegacyHomeStates(Property.getUri()));
		if (!listOfApplicableStates.isEmpty()) {
			List<String> workingStateList = partialListOfStates(listOfApplicableStates, 5);
			entries = listOfHomeApplicants("GetRetrieveQuoteHome", NO_FILTER);
			entries.removeIf(homeApplicant -> !workingStateList.contains(homeApplicant.getStateCode()));
		}
		Log.warn(String.format(DP_LOG_ENTRY, GET_RETRIEVE_QUOTE_APPLICANT_HOME, entries.size()));
		return entries.iterator();
	}

	private static final List<String> listOfMonetizedLegacyHomeStates_RA11 = new ArrayList<>(Arrays.asList(NJ, NY));
	private static final List<String> listOfMonetizedLegacyHomeStates_RA61 = new ArrayList<>(Arrays.asList(NJ, NY));
	public static List<String> getListOfLegacyHomeMonetizedStates(String environmentURI) {
		List<String> listOfMonetizedStates = new ArrayList<>();
		if (environmentURI.contains(RA11_ENVIRONMENT) || environmentURI.contains(MA11_ENVIRONMENT)) {
			listOfMonetizedStates.addAll(listOfMonetizedLegacyHomeStates_RA11);
		} else if (environmentURI.contains(RA61_ENVIRONMENT)) {
			listOfMonetizedStates.addAll(listOfMonetizedLegacyHomeStates_RA61);
		}
		return listOfMonetizedStates;
	}


	@DataProvider(name = APPLICANT_HQM_DATA_PROVIDER, parallel = true)
	public static synchronized Iterator<ApplicantHQM> applicantHQM(Method m) throws Exception {
		ExcelDataProvider excel = new ExcelDataProvider();
		String filter = Property.FILTER;
		JSONArray json = filter.equals(ALL) ? excel.getDataJson(HQM_FILE_NAME, HOME_APPLICANT_PAGE, true) :
			excel.filterJsonData(filter, excel.getDataJson(HQM_FILE_NAME, HOME_APPLICANT_PAGE, true));
		List<ApplicantHQM> entries = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		for (int i = 0; i < json.length(); i++) {
			String js = json.getJSONObject(i).toString();
			js = js.replaceAll(TRUE, LOWERCASE_TRUE);
			js = js.replaceAll(FALSE, LOWERCASE_FALSE);
			Log.debug(String.format(HQM_DP_JSON, i, js));
			entries.add(mapper.readValue(js, ApplicantHQM.class));
		}
		//randomize first/last names
		entries = entries.stream().peek(appl -> {
			Faker faker = new Faker();
			String firstName = faker.name().firstName();
			String lastName = faker.name().lastName().replaceAll("[^a-zA-Z]+", "").toLowerCase();
			lastName = StringUtils.capitalize(lastName);
			appl.firstName = firstName;
			appl.lastName = lastName;
			if (appl.maritalStatus.equals(MARRIED)) {
				appl.spouseFirstName = faker.name().firstName();
				appl.spouseLastName = lastName;
			}
		}).filter(ap -> !ap.isNonOffering()).collect(Collectors.toList());
		CustomAttribute[] customAttrs = m.getAnnotation(Test.class).attributes();
		if (customAttrs.length > 0) {
			ArrayList<String> states = new ArrayList<>(Arrays.asList(customAttrs[0].values()));
			if (customAttrs[0].name().equals(EXCLUDED_STATES)) {
				entries = entries.stream().filter(appl -> !states.contains(appl.stateCode)).collect(Collectors.toList());
			} else if (customAttrs[0].name().equals(INCLUDED_STATES)) {
				entries = entries.stream().filter(appl -> states.contains(appl.stateCode)).collect(Collectors.toList());
			}
		}
		if (!entries.isEmpty() && !m.getAnnotation(Test.class).testName().isEmpty()) {
			int row;
			List<ApplicantHQM> applicants = new ArrayList<>();
			String testType = m.getAnnotation(Test.class).testName();
			switch (testType) {
				case RANDOM_ROW:
					// return random data row
					row = randomNumberGenerator.nextInt(entries.size());
					Log.info("Randomly selected data provider row=" + (row + 1));
					entries = entries.subList(row, row + 1);
					break;
				case "randomStates":
					// return 2 data rows for random states
					String randomState1 = listOfHQMStates().get(randomNumberGenerator.nextInt(listOfHQMStates().size()));
					String randomState2 = listOfHQMStates().get(randomNumberGenerator.nextInt(listOfHQMStates().size()));
					List<ApplicantHQM> apList1 = entries.stream().filter(r -> r.stateCode.equals(randomState1)).collect(Collectors.toList());
					List<ApplicantHQM> apList2 = entries.stream().filter(r -> r.stateCode.equals(randomState2)).collect(Collectors.toList());
					applicants.add(apList1.get(randomNumberGenerator.nextInt(apList1.size())));
					applicants.add(apList2.get(randomNumberGenerator.nextInt(apList2.size())));
					Log.info("Selected data provider row1 => " + applicants.get(0));
					Log.info("Selected data provider row2 => " + applicants.get(1));
					entries.clear();
					entries.addAll(applicants);
					break;
				case "randomStatesByGroup":
					// return one random data row for states in each of the 4 groups PLA, GWPC, EE, Flex
					List<String> plaStates = new ArrayList<>(listOfHQMStatesPLA());
					Collections.shuffle(plaStates, new Random());
					String randomStatePLA = plaStates.get(0);
					List<String> gwpcStates = new ArrayList<>(listOfHQMStatesGWPC());
					Collections.shuffle(gwpcStates, new Random());
					String randomStateGWPC = gwpcStates.get(0);

					List<ApplicantHQM> apListPLA = entries.stream().filter(r -> r.stateCode.equals(randomStatePLA)).collect(Collectors.toList());
					List<ApplicantHQM> apListGWPC = entries.stream().filter(r -> r.stateCode.equals(randomStateGWPC)).collect(Collectors.toList());

					applicants.add(apListPLA.get(randomNumberGenerator.nextInt(apListPLA.size())));
					applicants.add(apListGWPC.get(randomNumberGenerator.nextInt(apListGWPC.size())));
					for (int i = 0; i < applicants.size(); i++) {
						Log.info("Selected data provider row #" + (i + 1) + " => " + applicants.get(i));
					}
					entries.clear();
					entries.addAll(applicants);
					break;
				default:
					if (testType.startsWith("row=")) {
						// return only data from the given rows
						String rowsString = m.getAnnotation(Test.class).testName().substring(4);
						List<String> rows = new ArrayList<>(Arrays.asList(rowsString.split(COMMA)));
						Log.info(SELECTED_DATA_PROVIDER_ROWS + rowsString);
						entries = entries.stream().filter(r -> rows.contains(r.getId())).collect(Collectors.toList());
					}
			}
		}
		Log.warn(APPLICANT_HQM_DATA_PROVIDER + HAS_ROWS_OF_DATA + entries.size());
		return entries.iterator();
	}

	@DataProvider(name = APPLICANT_HQM_MONETIZATION_DP, parallel = true)
	public static synchronized Iterator<ApplicantHQM> applicantMonetizationHQM(Method m) throws Exception {
		ExcelDataProvider excel = new ExcelDataProvider();
		String filter = Property.FILTER;
		JSONArray json = filter.equals(ALL) ? excel.getDataJson(HQM_FILE_NAME, HOME_APPLICANT_PAGE, true) :
			excel.filterJsonData(filter, excel.getDataJson(HQM_FILE_NAME, HOME_APPLICANT_PAGE, true));
		List<ApplicantHQM> entries = new ArrayList<>();
		List<ApplicantHQM> entriesFinal = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		for (int i = 0; i < json.length(); i++) {
			String js = json.getJSONObject(i).toString();
			js = js.replaceAll(TRUE, LOWERCASE_TRUE);
			js = js.replaceAll(FALSE, LOWERCASE_FALSE);
			Log.debug(String.format(HQM_DP_JSON, i, js));
			entries.add(mapper.readValue(js, ApplicantHQM.class));
		}
		ArrayList<String> hqmStates = new ArrayList<>(listOfHQMStates());
		CustomAttribute[] customAttrs = m.getAnnotation(Test.class).attributes();
		if (customAttrs.length > 0) {
			hqmStates.clear();
			hqmStates.addAll(Arrays.asList(customAttrs[0].values()));
			if (customAttrs[0].name().equals(EXCLUDED_STATES)) {
				entries = entries.stream().filter(appl -> !hqmStates.contains(appl.stateCode)).collect(Collectors.toList());
			} else if (customAttrs[0].name().equals(INCLUDED_STATES)) {
				entries = entries.stream().filter(appl -> hqmStates.contains(appl.stateCode)).collect(Collectors.toList());
			}
		}
		// get one PA agent row and one EA agent row per state
		for (String stateCode : hqmStates) {
			if (entries.stream().anyMatch(appl -> (appl.stateCode.equals(stateCode) && appl.agentId.isEmpty()))) {
				entriesFinal.add(entries.stream().filter(appl -> (appl.stateCode.equals(stateCode) && appl.agentId.isEmpty()))
						.collect(Collectors.toList()).get(0));
			}
			if (entries.stream().anyMatch(appl -> (appl.stateCode.equals(stateCode) && !appl.agentId.isEmpty()))) {
				entriesFinal.add(entries.stream().filter(appl -> (appl.stateCode.equals(stateCode) && !appl.agentId.isEmpty()))
						.collect(Collectors.toList()).get(0));
			}
		}
		Log.warn(APPLICANT_HQM_DATA_PROVIDER + HAS_ROWS_OF_DATA + entriesFinal.size());
		return entriesFinal.iterator();
	}

	@DataProvider(name = APEX_HQM_DATA_PROVIDER, parallel = true)
	public Iterator<ApexHQM> apexApplicantHQM(Method m) throws Exception {
		ExcelDataProvider excel = new ExcelDataProvider();
		String filter = Property.FILTER;
		JSONArray json = filter.equals(ALL) ? excel.getDataJson(HQM_APEX_FILE_NAME, HQM_APEX_APPLICANT_PAGE, true) :
			excel.filterJsonData(filter, excel.getDataJson(HQM_APEX_FILE_NAME, HQM_APEX_APPLICANT_PAGE, true));
		List<ApexHQM> entries = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		for (int i = 0; i < json.length(); i++) {
			String js = json.getJSONObject(i).toString();
			js = js.replaceAll(TRUE, LOWERCASE_TRUE);
			js = js.replaceAll(FALSE, LOWERCASE_FALSE);
			Log.debug(String.format(HQM_DP_JSON, i, js));
			entries.add(mapper.readValue(js, ApexHQM.class));
		}
		CustomAttribute[] customAttrs = m.getAnnotation(Test.class).attributes();
		if (customAttrs.length > 0) {
			ArrayList<String> states = new ArrayList<>(Arrays.asList(customAttrs[0].values()));
			if (customAttrs[0].name().equals(EXCLUDED_STATES)) {
				entries = entries.stream().filter(appl -> !states.contains(appl.stateCode)).collect(Collectors.toList());
			} else if (customAttrs[0].name().equals(INCLUDED_STATES)) {
				entries = entries.stream().filter(appl -> states.contains(appl.stateCode)).collect(Collectors.toList());
			}
		}
		if (!m.getAnnotation(Test.class).testName().isEmpty()) {
			int row;
			if (m.getAnnotation(Test.class).testName().equals("randomRow")) {
				// return a random data row
				row = randomNumberGenerator.nextInt(entries.size());
				Log.info("Randomly selected data provider row id=" + (row + 1));
				ApexHQM applicant = entries.get(row);
				Log.debug(applicant.toString());
				entries.clear();
				entries.add(applicant);
			} else if (m.getAnnotation(Test.class).testName().startsWith("row=")) {
				// return only data from the given rows
				String rowsString = m.getAnnotation(Test.class).testName().substring(4);
				List<String> rows = new ArrayList<>(Arrays.asList(rowsString.split(COMMA)));
				Log.info(SELECTED_DATA_PROVIDER_ROWS + rowsString);
				entries.clear();
				for (String i : rows) {
					row = Integer.parseInt(i) - 1;
					String js = json.getJSONObject(row).toString();
					js = js.replaceAll(TRUE, LOWERCASE_TRUE);
					js = js.replaceAll(FALSE, LOWERCASE_FALSE);
					Log.debug(String.format(HQM_DP_JSON, row, js));
					entries.add(mapper.readValue(js, ApexHQM.class));
				}
			}
		}
		Log.warn(APEX_HQM_DATA_PROVIDER + HAS_ROWS_OF_DATA + entries.size());
		return entries.iterator();
	}

	@DataProvider(name = APPLICANT_HQM_PROD_DATA_PROVIDER, parallel = true)
	public static synchronized Iterator<ApplicantHQM> applicantProdHQM(Method m) throws Exception {
		ExcelDataProvider excel = new ExcelDataProvider();
		String filter = Property.FILTER;
		JSONArray json = filter.equals(ALL) ? excel.getDataJson(HQM_FILE_NAME, HOME_APPLICANT_PAGE, true) :
			excel.filterJsonData(filter, excel.getDataJson(HQM_FILE_NAME, HOME_APPLICANT_PAGE, true));
		List<ApplicantHQM> entries = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		for (int i = 0; i < json.length(); i++) {
			String js = json.getJSONObject(i).toString();
			js = js.replaceAll(TRUE, LOWERCASE_TRUE);
			js = js.replaceAll(FALSE, LOWERCASE_FALSE);
			Log.debug(String.format(HQM_DP_JSON, i, js));
			entries.add(mapper.readValue(js, ApplicantHQM.class));
		}
		// update first/last names and email for Prod
		entries = entries.stream().peek(appl -> {
			appl.setFirstName(PRODUCTION_APPLICANT_FIRST_NAME);
			appl.setLastName(PRODUCTION_APPLICANT_LAST_NAME);
			appl.setEmailAddress(PRODUCTION_APPLICANT_EMAIL);
		}).filter(ap -> !ap.isNonOffering()).collect(Collectors.toList());
		List<ApplicantHQM> applicants = new ArrayList<>();
		CustomAttribute[] customAttrs = m.getAnnotation(Test.class).attributes();
		if (customAttrs.length > 0) { // pick one random row per state
			ArrayList<String> states = new ArrayList<>(Arrays.asList(customAttrs[0].values()));
			if (customAttrs[0].name().equals(INCLUDED_STATES)) {
				for (String state : states) {
					List<ApplicantHQM> appls = entries.stream().filter(appl -> appl.getStateCode().equals(state)).collect(Collectors.toList());
					applicants.add(appls.get(randomNumberGenerator.nextInt(appls.size())));
				}
			}
		}
		Log.info(APPLICANT_HQM_PROD_DATA_PROVIDER + HAS_ROWS_OF_DATA + applicants.size());
		return applicants.iterator();
	}

	protected static synchronized List<ApplicantAceHome> listOfAceHomeApplicants(String xlDataSheetName, String filter) throws Exception {
		ExcelDataProvider excel = new ExcelDataProvider();
		JSONArray json = filter.equals(NO_FILTER) ? excel.getDataJson(ACE_HOME_FILE_NAME, xlDataSheetName, false) :
			excel.filterJsonData(filter, excel.getDataJson(ACE_HOME_FILE_NAME, xlDataSheetName, true));
		List<ApplicantAceHome> entries = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		for (int i = 0; i < json.length(); i++) {
			String js = json.getJSONObject(i).toString();
			js = js.replace(TRUE, LOWERCASE_TRUE);
			js = js.replace(FALSE, LOWERCASE_FALSE);
			js = js.replace(LOWERCASE_NULL, EMPTY_STRING);
			Log.debug(String.format(HOMEDP_JSON, i, js));
			entries.add(mapper.readValue(js, ApplicantAceHome.class));
		}
		Iterator<ApplicantAceHome> applicantListIterator = entries.iterator();
		List<SqlDiscount> listOfDiscounts = getAllDiscounts();
		while (applicantListIterator.hasNext()) {
			ApplicantAceHome applicant = applicantListIterator.next();
			Iterator<SqlDiscount> discountsIterator = listOfDiscounts.iterator();
			List<SqlDiscount> applicantDiscounts = new ArrayList<>();
			while(discountsIterator.hasNext()) {
				SqlDiscount discount = discountsIterator.next();
				if (discount.getApplicantId() == Integer.parseInt(applicant.getId())) {
					applicantDiscounts.add(discount);
				}
			}
			if (applicantDiscounts.isEmpty()) {
				Log.warn("Did not find any discount rows for applicant id: " + applicant.getId());
			}
			applicant.setDiscounts(applicantDiscounts);
		}
		return entries;
	}

	protected static List<SqlDiscount> getAllDiscounts() throws Exception {
		ExcelDataProvider excelDP = new ExcelDataProvider();
		JSONArray json = excelDP.getDataJson(ACE_HOME_FILE_NAME, "discounts", false);
		List<SqlDiscount> allDiscounts = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
		for (int j = 0; j < json.length(); j++) {
			String jsObject = json.getJSONObject(j).toString();
			jsObject = jsObject.replace(TRUE, LOWERCASE_TRUE);
			jsObject = jsObject.replace(FALSE, LOWERCASE_FALSE);
			jsObject = jsObject.replace(LOWERCASE_NULL, EMPTY_STRING);
			allDiscounts.add(mapper.readValue(jsObject, SqlDiscount.class));
		}
		return allDiscounts;
	}

	@DataProvider(name = ACE_LIFE_APPLICANTS_DATA_PROVIDER, parallel = true)
	public Iterator<ApplicantLife> allAceLifeApplicants(Method m) throws Exception {
		List<String> listOfAceLifeSupportingStates = updateListOfStatesWithTestAttributeAndStateListProperty(m, getListOfAceLifeStates(Property.getUri()));
		if (listOfAceLifeSupportingStates.isEmpty()) {
			throw new SkipException("No supported states found for Ace Life in this environment");
		} else {
			List<ApplicantLife> listOfLifeApplicants = filteredListOfLifeApplicants(LIFE_APPLICANT_PAGE, NO_FILTER);
			listOfLifeApplicants.removeIf(applicant -> !listOfAceLifeSupportingStates.contains(applicant.getStateCode()));
			return listOfLifeApplicants.iterator();
		}
	}

	@DataProvider(name = ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, parallel = true)
	public Iterator<ApplicantLife> oneAceLifeApplicant(Method m) throws Exception {
		List<String> listOfAceLifeSupportingStates = updateListOfStatesWithTestAttributeAndStateListProperty(m, getListOfAceLifeStates(Property.getUri()));
		if (listOfAceLifeSupportingStates.isEmpty()) {
			throw new SkipException("No supported states found for Ace Life in this environment");
		} else {
			Collections.shuffle(listOfAceLifeSupportingStates);
			return filteredListOfLifeApplicants(LIFE_APPLICANT_PAGE, STATE_CODE_EQUALS + listOfAceLifeSupportingStates.get(FIRST_AVAILABLE_OPTION)).iterator();
		}
	}

	@DataProvider(name = ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES, parallel = true)
	public Iterator<ApplicantLife> lifeApplicantsFromAListOfStates(Method m) throws Exception {
		List<String> listOfAceLifeSupportingStates = updateListOfStatesWithTestAttributeAndStateListProperty(m, getListOfAceLifeStates(Property.getUri()));
		if (listOfAceLifeSupportingStates.isEmpty()) {
			throw new SkipException("No supported states found for Ace Life in this environment");
		} else {
			int maxNumberOfStates = 5;
			List<ApplicantLife> listOfLifeApplicants = filteredListOfLifeApplicants(LIFE_APPLICANT_PAGE, NO_FILTER);
			if (listOfAceLifeSupportingStates.size() > maxNumberOfStates) {
				Collections.shuffle(listOfAceLifeSupportingStates);
				listOfAceLifeSupportingStates.subList(maxNumberOfStates, listOfAceLifeSupportingStates.size()).clear();
			}
			listOfLifeApplicants.removeIf(applicant -> !listOfAceLifeSupportingStates.contains(applicant.getStateCode()));
			return listOfLifeApplicants.iterator();
		}
	}

	@DataProvider(name = PRODUCTION_TEST_LIFE_APPLICANT_DATA_PROVIDER, parallel = true)
	public Iterator<ApplicantLife> productionValidationLifeApplicants(Method m) throws Exception {
		Iterator<ApplicantLife> allAceLifeApplicantsIterator = allAceLifeApplicants(m);
		List<ApplicantLife> listOfLifeApplicants = new ArrayList<>();
		while (allAceLifeApplicantsIterator.hasNext()) {
			listOfLifeApplicants.add(allAceLifeApplicantsIterator.next());
		}
		String stateListProperty = Property.getTestProperty(STATE_LIST);
		if (stateListProperty != null && stateListProperty.equals(ALL)) {
			// If no specific stateList value is provided, randomly pick one
			ApplicantLife randomLifeApplicant = listOfLifeApplicants.get(randomNumberGenerator.nextInt(listOfLifeApplicants.size()));
			listOfLifeApplicants.clear();
			listOfLifeApplicants.add(randomLifeApplicant);
		}
		listOfLifeApplicants.forEach(lifeApplicant -> {
			lifeApplicant.setFirstName(PRODUCTION_APPLICANT_FIRST_NAME);
			lifeApplicant.setLastName(PRODUCTION_APPLICANT_LAST_NAME);
			lifeApplicant.setEmailAddress(PRODUCTION_APPLICANT_EMAIL);
		});
		return listOfLifeApplicants.iterator();
	}

	@SuppressWarnings("unchecked")
	private <T extends DataObjectBase> T updateAddressData(Object applicantObject) throws Exception {
		SqlDataProviders dProvider = new SqlDataProviders();
		if (applicantObject.getClass().getSimpleName().equals(LIFE_APPLICANT)) {
			ApplicantLife lifeApplicant = (ApplicantLife) applicantObject;
			SqlApplicant autoApplicant = dProvider.getRandomAutoApplicantFromState(lifeApplicant.getStateCode());
			lifeApplicant.setAddress(autoApplicant.getResidentAddress1());
			lifeApplicant.setCity(autoApplicant.getCity());
			lifeApplicant.setZipCode(autoApplicant.getZipCode());
			return (T) lifeApplicant;
		} else if (applicantObject.getClass().getSimpleName().equals(BUSINESS_APPLICANT)) {
			ApplicantBusiness businessApplicant = (ApplicantBusiness) applicantObject;
			SqlApplicant autoApplicant = dProvider.getRandomAutoApplicantFromState(businessApplicant.getStateCode());
			businessApplicant.setAddress1(autoApplicant.getResidentAddress1());
			businessApplicant.setCity(autoApplicant.getCity());
			businessApplicant.setZipCode(autoApplicant.getZipCode());
			return (T) businessApplicant;
		} else {
			ApplicantAceHome mobileHomeApplicant = (ApplicantAceHome) applicantObject;
			SqlApplicant autoApplicant = dProvider.getRandomAutoApplicantFromState(mobileHomeApplicant.getStateCode());
			mobileHomeApplicant.setAddress(autoApplicant.getResidentAddress1());
			mobileHomeApplicant.setCity(autoApplicant.getCity());
			mobileHomeApplicant.setZipCode(autoApplicant.getZipCode());
			return (T) mobileHomeApplicant;
		}
	}

	@DataProvider(name = BUSINESS_APPLICANT_DATA_PROVIDER, parallel = true)
	public Iterator<ApplicantBusiness> allBusinessApplicants(Method m) throws Exception {
		return filteredBusinessApplicantsIterator(BUSINESS_APPLICANT_PAGE, updateListOfStatesWithTestAttributeAndStateListProperty(m, getListOfAceBusinessStates()));
	}

	@DataProvider(name = ONE_BUSINESS_APPLICANT_DATA_PROVIDER, parallel = true)
	public Iterator<ApplicantBusiness> oneBusinessApplicant(Method m) throws Exception {
		List<String> supportedStates = updateListOfStatesWithTestAttributeAndStateListProperty(m, getListOfAceBusinessStates());
		if (supportedStates.isEmpty()) {
			throw new SkipException("No supported states found for business in this environment");
		} else {
			return filteredBusinessApplicantsIterator(BUSINESS_APPLICANT_PAGE, List.of(supportedStates.get(randomNumberGenerator.nextInt(supportedStates.size()))));
		}
	}

	@DataProvider(name = PRODUCTION_TEST_BUSINESS_APPLICANT_DATA_PROVIDER, parallel = true)
	public Iterator<ApplicantBusiness> productionValidationBusinessApplicants(Method m) throws Exception {
		List<String> listOfStates = updateListOfStatesWithTestAttributeAndStateListProperty(m, getListOfAceBusinessStates());
		String stateListProperty = Property.getTestProperty(STATE_LIST);
		if (stateListProperty != null && stateListProperty.equals(ALL) && !listOfStates.isEmpty()) {
			Collections.shuffle(listOfStates);
			String state = listOfStates.get(FIRST_AVAILABLE_OPTION);
			listOfStates.clear();
			listOfStates.add(state);
		}
		Iterator<ApplicantBusiness> filteredBusinessApplicantIterator = filteredBusinessApplicantsIterator(BUSINESS_APPLICANT_PAGE, listOfStates);
		List<ApplicantBusiness> entries = new ArrayList<>();
		while (filteredBusinessApplicantIterator.hasNext()) {
			ApplicantBusiness businessApplicant = filteredBusinessApplicantIterator.next();
			businessApplicant.setFirstName(PRODUCTION_APPLICANT_FIRST_NAME);
			businessApplicant.setLastName(PRODUCTION_APPLICANT_LAST_NAME);
			businessApplicant.setEmail(PRODUCTION_APPLICANT_EMAIL);
			entries.add(businessApplicant);
		}
		return entries.iterator();
	}

	@DataProvider(name = ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, parallel = true)
	public Iterator<ApplicantAceHome> aceMobileHomeApplicants(Method method) throws Exception {
		List<String> listOfAceMobileHomeSupportingStates = updateListOfStatesWithTestAttributeAndStateListProperty(method, getListOfAceMobileHomeStates(Property.getUri()));
		if (listOfAceMobileHomeSupportingStates.isEmpty()) {
			throw new SkipException("No supported states found for Ace Mobile Home in this environment");
		} else {
			List<ApplicantAceHome> listOfMobileHomeApplicants = listOfAceHomeApplicants(HOME_APPLICANT_PAGE, NO_FILTER);
			listOfMobileHomeApplicants.removeIf(applicant -> !listOfAceMobileHomeSupportingStates.contains(applicant.getStateCode()));
			//With no test name annotation we return all applicants
			String dataProviderDescriptionString = ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER;
			Test annotation = method.getAnnotation(Test.class);
			if (!listOfMobileHomeApplicants.isEmpty() && annotation != null) {
				String dataProviderScenario = annotation.testName();
				if (dataProviderScenario != null) {
					dataProviderDescriptionString = dataProviderScenario;
					switch (dataProviderScenario) {
						case RANDOM_MOBILEHOME_APPLICANT:
							ApplicantAceHome randomApplicant = listOfMobileHomeApplicants.get(randomNumberGenerator.nextInt(listOfMobileHomeApplicants.size()));
							listOfMobileHomeApplicants.clear();
							listOfMobileHomeApplicants.add(randomApplicant);
							break;
						case ONE_MOBILEHOME_APPLICANT_PER_STATE:
							List<ApplicantAceHome> listOfRandomEntries = new ArrayList<>();
							getOneMobilehomeApplicantPerState(listOfAceMobileHomeSupportingStates, listOfMobileHomeApplicants, listOfRandomEntries);
							listOfMobileHomeApplicants = listOfRandomEntries;
							break;
						case ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES:
							int MAXIMUM_NUMBER_OF_STATES = 8;
							listOfRandomEntries = new ArrayList<>();
							Collections.shuffle(listOfAceMobileHomeSupportingStates);
							int numberOfStatesToSelect = listOfAceMobileHomeSupportingStates.size() > MAXIMUM_NUMBER_OF_STATES ? MAXIMUM_NUMBER_OF_STATES : listOfAceMobileHomeSupportingStates.size();
							if (numberOfStatesToSelect == MAXIMUM_NUMBER_OF_STATES) {
								listOfAceMobileHomeSupportingStates.subList(numberOfStatesToSelect, listOfAceMobileHomeSupportingStates.size()).clear();
							}
							getOneMobilehomeApplicantPerState(listOfAceMobileHomeSupportingStates, listOfMobileHomeApplicants, listOfRandomEntries);
							listOfMobileHomeApplicants = listOfRandomEntries;
							break;
					}
				}
			}
			Faker faker = new Faker();
			listOfMobileHomeApplicants.forEach(mobileHomeApplicant -> {
				mobileHomeApplicant.setFirstName(faker.name().firstName());
				mobileHomeApplicant.setLastName(faker.name().lastName());
				mobileHomeApplicant.setPhoneNumber(faker.phoneNumber().phoneNumber());
				mobileHomeApplicant.setPrimaryHeatingSource("Heat pump");
				mobileHomeApplicant.setPreviousInsurance(YES);
				mobileHomeApplicant.setTestCategory(EMPTY_STRING);
				mobileHomeApplicant.setYearBuilt(LocalDate.now().minusYears(10+randomNumberGenerator.nextInt(10)).getYear());
				mobileHomeApplicant.setMailingAddressDifferent(false);
				List<SqlDiscount> listOfDiscounts = mobileHomeApplicant.getDiscounts();
				listOfDiscounts.forEach(bundleGroup-> {
					bundleGroup.setAutoInsurance(false);
					bundleGroup.setLifeInsurance(false);
					bundleGroup.setUmbrellaInsurance(false);
				});
				mobileHomeApplicant.setDiscounts(listOfDiscounts);
				try {
					updateAddressData(mobileHomeApplicant);
				} catch (Exception e) {
					Log.info("Unable to update address data");
				}
			});
			Log.warn(String.format(DP_LOG_ENTRY, dataProviderDescriptionString, listOfMobileHomeApplicants.size()));
			return listOfMobileHomeApplicants.iterator();
		}
	}

	private void getOneMobilehomeApplicantPerState(List<String> listOfAceMobileHomeSupportingStates, List<ApplicantAceHome> listOfMobileHomeApplicants, List<ApplicantAceHome> listOfRandomEntries) {
		for (String stateCode : listOfAceMobileHomeSupportingStates) {
			if (listOfMobileHomeApplicants.stream().anyMatch(applicant -> (applicant.getStateCode().equals(stateCode)))) {
				List<ApplicantAceHome> tempEntries = listOfMobileHomeApplicants.stream().filter(applicant -> applicant.getStateCode().equals(stateCode)).collect(Collectors.toList());
				listOfRandomEntries.add(tempEntries.get(randomNumberGenerator.nextInt(tempEntries.size())));
			}
		}
	}

	private List<ApplicantHome> listOfHomeApplicants(String xlDataSheetName, String filter) throws Exception {
		JSONArray json = getDataInJsonFormat(HOME_CONDO_RENTERS_FILE_NAME, xlDataSheetName, filter);
		List<ApplicantHome> entries = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		for (int i = 0; i < json.length(); i++) {
			String js = json.getJSONObject(i).toString();
			js = js.replace(TRUE, LOWERCASE_TRUE);
			js = js.replace(FALSE, LOWERCASE_FALSE);
			Log.debug(String.format(HOMEDP_JSON, i, js));
			entries.add(mapper.readValue(js, ApplicantHome.class));
		}
		return entries;
	}

	private List<ApplicantLife> filteredListOfLifeApplicants(String xlDataSheetName, String filter) throws Exception {
		JSONArray json = getDataInJsonFormat(LIFE_FILE_NAME, xlDataSheetName, filter);
		List<ApplicantLife> entries = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		for (int i = 0; i < json.length(); i++) {
			String js = json.getJSONObject(i).toString();
			js = js.replace(TRUE, LOWERCASE_TRUE);
			js = js.replace(FALSE, LOWERCASE_FALSE);
			Log.debug(String.format(LIFEDP_JSON, i, js));
			entries.add(mapper.readValue(js, ApplicantLife.class));
		}
		Faker faker = new Faker();
		entries.forEach(lifeApplicant -> {
			lifeApplicant.setFirstName(faker.name().firstName());
			lifeApplicant.setLastName(faker.name().lastName());
			try {
				updateAddressData(lifeApplicant);
			} catch (Exception e) {
				Log.info("Unable to update address data");
			}
		});
		return entries;
	}

	private List<ApplicantBusiness> getListOfAllBusinessApplicants(String xlDataSheetName) throws Exception {
		JSONArray json = getDataInJsonFormat(BUSINESS_FILE_NAME, xlDataSheetName, NO_FILTER);
		List<ApplicantBusiness> businessList = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
		for (int i = 0; i < json.length(); i++) {
			String js = json.getJSONObject(i).toString();
			js = js.replace(TRUE, LOWERCASE_TRUE);
			js = js.replace(FALSE, LOWERCASE_FALSE);
			js = js.replace(LOWERCASE_NULL, EMPTY_STRING);
			businessList.add(mapper.readValue(js, ApplicantBusiness.class));
		}
		Faker faker = new Faker();
		businessList.forEach(applicant -> {
			applicant.setFirstName(faker.name().firstName());
			applicant.setLastName(faker.name().lastName());
			applicant.setEmail(BasePage.generateEmailAddress());
			try {
				updateAddressData(applicant);
			} catch (Exception e) {
				Log.info("Unable to update address data");
			}
		});
		return businessList;
	}

	private Iterator<ApplicantBusiness> filteredBusinessApplicantsIterator(String xlDataSheetName, List<String> listOfStates) throws Exception {
		List<ApplicantBusiness> businessList = getListOfAllBusinessApplicants(xlDataSheetName);
		if (!listOfStates.contains(ALL)) {
			businessList.removeIf(businessApplicant -> !listOfStates.contains(businessApplicant.getStateCode()));
		}
		return businessList.iterator();
	}

	private JSONArray getDataInJsonFormat(String fileName, String worksheetName, String filter) throws Exception {
		ExcelDataProvider excel = new ExcelDataProvider();
		if (filter.equals(NO_FILTER)) {
			return excel.getDataJson(fileName, worksheetName, true);
		} else {
			return excel.filterJsonData(filter, excel.getDataJson(fileName, worksheetName, true));
		}
	}

	protected static List<String> updateListWithValueOfStateListProperty(List<String> incomingStateList) {
		List<String> returnList = new ArrayList<>(incomingStateList);
		String stateListPropertyValue = Property.getTestProperty(STATE_LIST);
		if (stateListPropertyValue != null && !stateListPropertyValue.equals(EMPTY_STRING) && !stateListPropertyValue.equals(ALL)) {
			String[] arrayOfStates = stateListPropertyValue.split(COMMA);
			returnList.retainAll(Arrays.asList(arrayOfStates));
		}
		return returnList;
	}

	protected static List<String> updateListOfStatesWithTestAttributeAndStateListProperty(Method m, List<String> listOfStates) {
		// Keep all states that are valid and listed in stateList property
		List<String> listOfSupportedStates = new ArrayList<>(listOfStates);
		listOfSupportedStates.retainAll(updateListWithValueOfStateListProperty(listOfStates));
		CustomAttribute[] customAttrs = m.getAnnotation(Test.class).attributes();
		for (CustomAttribute testAttribute : customAttrs) {
			List<String> listOfValuesFromTestcase = Arrays.asList(testAttribute.values());
			switch (testAttribute.name()) {
				case INCLUDED_STATES:
					listOfSupportedStates.retainAll(listOfValuesFromTestcase);
					break;
				case EXCLUDED_STATES:
					listOfSupportedStates.removeIf(listOfValuesFromTestcase::contains);
					break;
				case DISABLED_STATES:
					//Expectation is that these states are not enabled for the application, or they are not Farmers states (like NH or AK)
					listOfSupportedStates.clear();
					listOfSupportedStates.addAll(listOfValuesFromTestcase);
					break;
				case EXCLUDE_NONMONOLINE_HOME_STATES:
					//Here is where you would add those states that no longer start with monoline behavior
					List<String> listOfHomeNonMonolineStates = new ArrayList<>();
					listOfSupportedStates.removeIf(listOfHomeNonMonolineStates::contains);
					break;
				case EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES:
					//States that don't have MA or don't lead to FFQ
					listOfSupportedStates.removeIf(List.of(ME, MS, NH, NJ, NV, NY, RI, SC, VT, WV)::contains);
					break;
				case SPECIALTY_DWELLING:
					List<String> listOfStatesEnabledForFeaure = new ArrayList<>(Arrays.asList(AL, AR, AZ, CA, CO, CT, GA, IA, ID, IN, KS,
							KY, LA, MA, MD, MI, MN, MO, MS, MT, NC, ND, NE, NM, NV, IL, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY));
					listOfSupportedStates.retainAll(listOfStatesEnabledForFeaure);
					break;
				case REMOVE_AUTO_REDSTATES:
					// They've changed the behavior again, now it navigates to BW, no need to remove -- keeping code for when they change their mind.
					// listOfSupportedStates.removeIf(List.of(CO, MI, MO, NE, NM, PA, TN, VA)::contains);
					break;
				case REMOVE_SPECIALTY_REDSTATES:
					 listOfSupportedStates.removeIf(List.of(AK, CT, FL, GA, KY, MA, NC, NV, SC)::contains);
					break;
				default:
					//this is for when "name = stateCode" is used
					listOfSupportedStates.removeIf(state -> !state.equals(testAttribute.name()));
					break;
			}
		}
		return listOfSupportedStates;
	}

	// List of all HQM states
	// As of October 2024
	public static List<String> listOfHQMStates() {
		return List.of(CA, MT, NV);
	}

	// As of October 2024
	public static List<String> listOfHQMStatesPLA() {
		return List.of(MT);
	}

	// As of October 2024
	public static List<String> listOfHQMStatesGWPC() {
		return List.of(CA, NV);
	}


	private List<String> partialListOfStates(List<String> listOfApplicableStates, int i) {
		List<String> partialList = new ArrayList<>();
		List<String> mutableList = new ArrayList<>(listOfApplicableStates);
		Collections.shuffle(mutableList);
		for (int index = 0; (index < i) && (index < mutableList.size()); index++) {
			partialList.add(mutableList.get(index));
		}
		return partialList;
	}

	public static List<String> getListOfLegacyHomeStates(String environmentURI) {
		List<String> listOfValidStates = new ArrayList<>();
		return listOfValidStates;
	}

}