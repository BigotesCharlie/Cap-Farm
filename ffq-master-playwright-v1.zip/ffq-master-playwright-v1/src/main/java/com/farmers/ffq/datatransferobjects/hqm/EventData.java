package com.farmers.ffq.datatransferobjects.hqm;

public class EventData {
    private String event;
    private Properties properties;

    public String getEvent() {
        return event;
    }

    public Properties getProperties() {
        return properties;
    }

    public static class Properties {
        private String time;
        private String distinct_id;
        private String $browser;
        private String $browser_version;
        private String $city;
        private String $current_url;
        private String $insert_id;
        private String $mp_api_endpoint;
        private String $mp_api_timestamp_ms;
        private String $os;
        private String $region;
        private String action;
        private String app_name;
        private String company_code;
        private String existing_lobs;
        private String flow_param;
        private String lead_id;
        private String lob;
        private String mp_country_code;
        private String mp_lib;
        private String mp_processing_time_ms;
        private String quote_number;
        private String source_id;
        private String source_indicator;
        private String state;
        private String step;
        private String variable_name;
        private Object variable_value;
        private String zip;

        static class Occupation {
            public String value;
            public String webDesc;
        }

        public String getTime() {
            return time;
        }

        public String getDistinct_id() {
            return distinct_id;
        }

        public String get$browser() {
            return $browser;
        }

        public String get$browser_version() {
            return $browser_version;
        }

        public String get$city() {
            return $city;
        }

        public String get$current_url() {
            return $current_url;
        }

        public String get$insert_id() {
            return $insert_id;
        }

        public String get$mp_api_endpoint() {
            return $mp_api_endpoint;
        }

        public String get$mp_api_timestamp_ms() {
            return $mp_api_timestamp_ms;
        }

        public String get$os() {
            return $os;
        }

        public String get$region() {
            return $region;
        }

        public String getAction() {
            return action;
        }

        public String getApp_name() {
            return app_name;
        }

        public String getCompany_code() {
            return company_code;
        }

        public String getExisting_lobs() {
            return existing_lobs;
        }

        public String getFlow_param() {
            return flow_param;
        }

        public String getLead_id() {
            return lead_id;
        }

        public String getLob() {
            return lob;
        }

        public String getMp_country_code() {
            return mp_country_code;
        }

        public String getMp_lib() {
            return mp_lib;
        }

        public String getMp_processing_time_ms() {
            return mp_processing_time_ms;
        }

        public String getQuote_number() {
            return quote_number;
        }

        public String getSource_id() {
            return source_id;
        }

        public String getSource_indicator() {
            return source_indicator;
        }

        public String getState() {
            return state;
        }

        public String getStep() {
            return step;
        }

        public String getVariable_name() {
            return variable_name;
        }

        public Object getVariable_value() {
            return variable_value;
        }

        public String getZip() {
            return zip;
        }

    }

}
