package com.farmers.ffq.common.enums;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.datatransferobjects.SqlDiscount;
import com.farmers.ffq.datatransferobjects.Vehicle;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

@AllArgsConstructor
@Getter
public enum AutoDiscounts {

    ANTI_THEFT_DEVICE("Anti-theft Device"),
    AUTOPAY("Auto Pay"),
    AUTO_HOME("Auto & Home"),
    AUTO_CONDO("Auto & Condo"),
    AUTO_LIFE("Auto & Life"),
    AUTO_RENT("Auto & Renters"),
    AUTO_UMBRELLA("Auto & Umbrella"),
    AUTO_BUSINESS("Auto & Business"),
    AUTO_WATERCRAFT("Auto & Watercraft"),
    AUTO_MOTORCYCLE("Auto & Motorcycle"),
    BOAT_WATERCRAFT("Recreational Boat/Watercraft Insurance"),
    DEFENSIVE_DRIVER("Defensive driver"),
    DISTANT_STUDENT("Distant Student"),
    EARLY_SHOPPING("Early Shopping"),
    E_POLICY("ePolicy Discount"),
    ELECTRONIC_FUND_TRANSFER("Electronic Funds Transfer"),
    EMPLOYMENT("Profession group"),
    FIVE_YEAR_ACCIDENT_FREE("Five Year Accident Free"),
    GOOD_PAYER("Good Payer"),
    GOOD_STUDENT("Good student"),
    HOMEOWNER("Homeowner"),
    MATURE_DRIVER("Mature driver"),
    MOTORCYCLE("Motorcycle Insurance"),
    MULTIPLE_CAR("Multiple Car"),
    NEW_BUSINESS_FIVE_YEAR_ACCIDENT_FREE("New Business Five Year Accident Free Discount"),
    PAID_IN_FULL("Paid In Full Discount"),
    PREFERRED_PAYMENT_PLAN("Preferred payment plan"),
    SIGNAL("Signal"),
    WELCOME("Welcome"),
    YOUTHFUL("Youthful Driver Discount");

    private final String name;

    public static List<String> getExpectedDiscountsForGivenApplicant(AutoApplicant applicant, boolean monhtlyPay, boolean isEarlyShopper, boolean isEmploymentEligible) throws Exception {

        String stateCode = applicant.getStateCode();
        List<String> expectedDiscounts = new ArrayList<>();
        List<SqlDiscount> discounts = applicant.getDiscounts();
        SqlDiscount discount = discounts.stream().findFirst().get();
        boolean homeInsurance = discount.isHomeInsurance();
        boolean condeInsurance = discount.isCondoInsurance();
        boolean rentersInsurance = discount.isRentersInsurance();
        boolean umbrellaInsurance = discount.isUmbrellaInsurance();
        boolean lifeInsurance = discount.isValueTermLifeInsurance();
        boolean motorcycleInsurance = discount.isMotorcycleInsurance();
        boolean boatWatercraftInsurance = discount.isRecreationalBoatWatercraftInsurance();
        boolean signalEnrolled = discount.isSignalSignup();

        expectedDiscounts.add(GOOD_PAYER.name);
        expectedDiscounts.add(WELCOME.name);

        if (homeInsurance || condeInsurance) {
            expectedDiscounts.add(AUTO_HOME.name);
        }
        if (rentersInsurance) {
            expectedDiscounts.add(AUTO_RENT.name);
        }

        if (umbrellaInsurance) {
            expectedDiscounts.add(AUTO_UMBRELLA.name);
        }

        if (lifeInsurance) {
            expectedDiscounts.add(AUTO_LIFE.name);
        }

        if (new AutoBasePage().isHomeowner(applicant)) {
            expectedDiscounts.add(HOMEOWNER.name);
        }

        if (monhtlyPay) {
            switch (stateCode) {
                case IA:
                    expectedDiscounts.add(ELECTRONIC_FUND_TRANSFER.name);
                    break;
                default:
                    expectedDiscounts.add(AUTOPAY.name);
            }

        } else {
            switch (stateCode) {
                case IA:
                    expectedDiscounts.add(PAID_IN_FULL.name);
                    break;
                default:
                    expectedDiscounts.add(PREFERRED_PAYMENT_PLAN.name);
            }
        }

        if (motorcycleInsurance) {
            expectedDiscounts.add(MOTORCYCLE.name);
        }
        if (boatWatercraftInsurance) {
            expectedDiscounts.add(BOAT_WATERCRAFT.name);
        }

        if (isEarlyShopper) {
            expectedDiscounts.add(EARLY_SHOPPING.name);
        }
        if (signalEnrolled) {
            expectedDiscounts.add(SIGNAL.name);
        }

        if (isHighGpaInvolved(applicant)) {
            expectedDiscounts.add(GOOD_STUDENT.name);
        }

        if (isDistantStudentEligible(applicant)) {
            expectedDiscounts.add(DISTANT_STUDENT.name);
        }

        if (accidentFree(applicant)) {
            expectedDiscounts.add(FIVE_YEAR_ACCIDENT_FREE.name);
        }

        if (isEmploymentEligible) {
            expectedDiscounts.add(EMPLOYMENT.name);
        }

        if (applicant.getVehicles().size() > 1) {
            expectedDiscounts.add(MULTIPLE_CAR.name);
        }

        if (isMatureDriver(applicant)) {
            expectedDiscounts.add(MATURE_DRIVER.name);
        }
        if(isAntiTheftDeviceEligible(applicant)) {
            expectedDiscounts.add(ANTI_THEFT_DEVICE.name);
        }
        return expectedDiscounts;
    }

    private static boolean isMatureDriver(AutoApplicant applicant) {
        boolean isMatureDriverDiscountEligible = false;
        if (applicant.getAge() >= MIN_OLD_AGE && applicant.isCompletedDriversSafetyCourse()) {
            isMatureDriverDiscountEligible = true;
        }

        for (SqlAdditionalDriver additionalDriver : applicant.getAdditionalDrivers()) {

            if (additionalDriver.getAge() >= MIN_OLD_AGE && additionalDriver.isCompletedDriversSafetyCourse()) {
                isMatureDriverDiscountEligible = true;
            }
        }
        return isMatureDriverDiscountEligible;
    }

    private static boolean accidentFree(AutoApplicant applicant) {
        return applicant.getIncidents().stream().filter(each -> each.getIncidentType().equals(ACCIDENT)).count() == 0;
    }

    private static boolean isHighGpaInvolved(AutoApplicant applicant) {
        boolean isGoodStudentDiscountEligible = false;
        if (applicant.getAge() <= 25 && !applicant.getMaritalStatus().equals(MARRIED) && applicant.isFullTimeStudentWithHighGPA()) {
            isGoodStudentDiscountEligible = true;
        }
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();

        for (SqlAdditionalDriver additionalDriver : additionalDrivers) {
            if (additionalDriver.getAge() <= MAX_YOUNG_AGE && additionalDriver.isFullTimeStudentWithHighGPA()) {
                isGoodStudentDiscountEligible = true;
            }
        }

        return isGoodStudentDiscountEligible;
    }

    private static boolean isDistantStudentEligible(AutoApplicant applicant) {
        boolean isDistantStudentEligible = false;

        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();

        for (SqlAdditionalDriver additionalDriver : additionalDrivers) {
            if (applicant.getAge() >= MIN_DISTANT_STUDENT_PARENT_AGE && additionalDriver.getAge() <= MAX_YOUNG_AGE && additionalDriver.isAttendsDistantSchool()) {
                isDistantStudentEligible = true;
            }
        }
        return isDistantStudentEligible;
    }

    private static boolean isAntiTheftDeviceEligible(AutoApplicant applicant) {
        boolean antiTheftEligible = false;
        String stateCode = applicant.getStateCode();
        for (Vehicle vehicle : applicant.getVehicles()) {
            if (vehicle.isAntiTheftDevice()) {
                switch (stateCode) {
                    case IL:
                    case NM:
                        antiTheftEligible = true;
                        break;
                    default:
                        antiTheftEligible = false;
                }
            }
        }
        return antiTheftEligible;
    }

}
