package com.farmers.ffq.ace.hrc.common;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
public class AceHRCFarmersChoicePage extends AceHRCBasePage {

    @PWFindBy(xpath = "//div//nav[@data-topbar]//a[contains(@class,'logo')]")
    private PWElement pageTitle;
    private static final String PAGE_TITLE_TEXT = "Farmers Insurance Choice";

    @PWFindBy(xpath = "//div//nav[@data-topbar]//a[contains(@class,'partner-logo')]")
    private PWElement partnerLogo;

    private static final String XPATH_HERO = "//section[@id='hero']//h1";
    @PWFindBy(xpath = XPATH_HERO)
    private PWElement farmersHeroTitle;
    private static final String TITLE_HERO_TEXT = "MORE CHOICE, MORE SAVINGS";

    private static final String XPATH_PRODUCTS = "//section[@class='products']//h3";
    @PWFindBy(xpath = XPATH_PRODUCTS)
    private PWElement farmersProducts;
    private static final String PRODUCTS_SUBTITLE_TEXT = "Farmers Insurance Choice lets you compare and save on insurance";
    private static final String PRODUCTS_SUBTITLE_TEXT_URBN = "It's easy for URBN employees to compare and save on insurance with Farmers Insurance Choice.";

    private static final String XPATH_ZIP = "//section[@id='hero']//form[@id='quote-form']//input[@id='zipcode']";
    @PWFindBy(xpath = XPATH_ZIP)
    private PWElement inputZip;

    private static final String XPATH_START_QUOTE = "//section[@id='hero']//button[@id='start-quote']";
    @PWFindBy(xpath = XPATH_START_QUOTE)
    private PWElement buttonToStartQuote;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public AceHRCFarmersChoicePage() throws Exception {
        super();
        waitForSpinnerToBeGone();
        wait.until(PWExpectedConditions.urlContains("/uat.farmersinsurancechoice.com/"));
    }

    public void verifyPageElements(String partnerText, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getAttributeData(pageTitle, "text").trim(), PAGE_TITLE_TEXT, "Farmers Insurance Choice page - Page Title");
        fsa.assertTrue(getAttributeData(partnerLogo, "style").contains(partnerText.toLowerCase()), "Farmers Insurance Choice page - Partner Logo");
        fsa.assertEquals(getTextFromElement(farmersHeroTitle), TITLE_HERO_TEXT, "Farmers Insurance Choice page - Hero section title");
        fsa.assertTrue(isElementDisplayed(PWBy.xpath(XPATH_ZIP)), "Farmers Insurance Choice page - Input Zip Code field");
        fsa.assertTrue(isElementDisplayed(PWBy.xpath(XPATH_START_QUOTE)), "Farmers Insurance Choice page - Button to start a quote");
        String subtitle = partnerText.contains("urbn") ? PRODUCTS_SUBTITLE_TEXT_URBN : PRODUCTS_SUBTITLE_TEXT;
        fsa.assertEquals(getTextFromElement(farmersProducts), subtitle, "Farmers Insurance Choice page - Farmers Insurance Subtitle is displayed");
    }
}
