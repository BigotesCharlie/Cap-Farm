package com.farmers.ffq.ace.life;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.datatransferobjects.ApplicantLife;
import com.farmers.ffq.utils.FarmersSoftAssert;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceLifePersonalInfoPage extends BasePage {

	@PWFindBy(xpath = "//div[contains(@class,'personal-info_address_h1')]//h1")
	private PWElement personalInfoPageTitle;

	@PWFindBy(id = "auto-personal-info_address-subheading")
	private PWElement personalInfoPageSubtitle;

	@PWFindBy(linkText = "Go back")
	private PWElement goBackLink;

	@PWFindBy(xpath = "//mat-dialog-container//button[text()='Yes, enter manually']")
	private PWElement yesEnterManuallyButton;

	@PWFindBy(xpath = "//*[@class='manual-addr-heading']/a")
	private PWElement enterAddressManuallyLink;

	@PWFindBy(xpath = "//div[contains(@class, 'address__input')]//input")
	private PWElement addressInputField;

	@PWFindBy(xpath = "//div[contains(@class, 'address__input')]//mat-error")
	private PWElement addressInputFieldErrorLabel;

	@PWFindBy(xpath = "//div[@id='formField_apartment']//input")
	private PWElement apartmentInputField;

	@PWFindBy(xpath = "//div[@id='formField_apartment']//mat-hint")
	private PWElement apartmentInputFieldLabel;

	@PWFindBy(id = "auto-manual-street__input-section")
	private PWElement manualEntryAddressInputField;

	@PWFindBy(id = "auto-manual-apartment__input-section")
	private PWElement manualEntryApartmentInputField;

	@PWFindBy(xpath = "//div[@id='formField_city']//input")
	private PWElement manualEntryCityInputField;

	@PWFindBy(xpath = "//div[@id='formField_city']//mat-error")
	private PWElement manualEntryCityInputFieldErrorLabel;

	@PWFindBy(xpath = "//div[@id='formField_zipCode']//input")
	private PWElement manualEntryZipCodeInputField;

	@PWFindBy(xpath = "//div[@id='formField_zipCode']//mat-error")
	private PWElement manualEntryZipCodeInputFieldErrorLabel;

	@PWFindBy(id = "formField_label_gender")
	private PWElement genderSelectionLabel;

	@PWFindBy(xpath = "//button[*[normalize-space(text())='Male']]")
	private PWElement maleButton;

	@PWFindBy(xpath = "//button[*[normalize-space(text())='Female']]")
	private PWElement femaleButton;

	@PWFindBy(xpath = "//div[@id='formField_gender']//mat-error")
	private PWElement genderSelectionErrorLabel;

	@PWFindBy(xpath = "//div[@id='formField_nicotine']/label")
	private PWElement nicotineUseSelectionLabel;

	@PWFindBy(xpath = "//button[*[normalize-space(text())='No']]")
	private PWElement notUsedNicotineButton;

	@PWFindBy(xpath = "//button[*[normalize-space(text())='Yes']]")
	private PWElement haveUsedNicotineButton;

	@PWFindBy(xpath = "//div[@id='formField_nicotine']//mat-error")
	private PWElement nicotineUseSelectionErrorLabel;

	@PWFindBy(xpath = "//p[contains(@class, 'tui-field-label-text')]")
	private PWElement emailAndPhoneSectionLabel;

	@PWFindBy(id = "flex-field-emailAddress-input_personalInfo_life")
	private PWElement emailInputField;

	@PWFindBy(xpath = "//div[@class='email-address']//mat-error")
	private PWElement emailInputFieldErrorLabel;

	@PWFindBy(id = "flex-field-phoneNumber-input_personalInfo_life")
	private PWElement phoneNumberInputField;

	@PWFindBy(xpath = "//div[@class='phone-number']//mat-error")
	private PWElement phoneNumberInputFieldErrorLabel;

	@PWFindBy(id = "personal-info-phone-consent")
	private PWElement pewcDisclaimerText;

	@PWFindBy(xpath = "//*[@class='icc24_container']/parent::div")
	private PWElement legalDisclaimerText;

	@PWFindBy(xpath = "//*[contains(@class,'disclaimer__color')][not(@hidden)]")
	private PWElement privacyDisclaimer;

	@PWFindBy(xpath = "//p[@role='alert']")
	private PWElement personalInfoPageErrorLabel;

	@PWFindBy(xpath = "//button[contains(@class, 'address-form__continue-cta')]")
	private PWElement agreeAndSubmitButton;

	@PWFindBy(xpath = "//div[contains(@class, 'home-group-image-container')]/img")
	private PWElement personalInfoPageImage;

	public AceLifePersonalInfoPage() throws Exception {
		super();
	}

	public boolean isOnPersonalInfoPage() {
		return isElementVisible(maleButton, 3);
	}

	public void saveQuoteForLater(ApplicantLife applicant) throws Exception {
		saveLifeApplicantInHashMap(applicant, getClass().getSimpleName(), getSessionStorageAppStore().getData().getQuoteNumber());
	}

	public void contentValidation(ApplicantLife applicant, FarmersSoftAssert fsa) throws Exception {
		String connectingCharacter = isSafariBrowser()? EMPTY_STRING : SPACE;
		String connectingCharacter2 = isSafariBrowser() && !List.of(IN, MI).contains(applicant.getStateCode())? EMPTY_STRING : SPACE;
		String connectingCharacter3 = isSafariBrowser() && applicant.getStateCode().equals(AZ)? EMPTY_STRING : SPACE;
		fsa.assertEquals(getTextFromElement(personalInfoPageTitle), "Hi, " + applicant.getFirstName(), "Personal Info page title");
		//A/B testing may cause some variation in the subtitle text, so we will accept either version of the message.
		fsa.assertTrue(List.of("Let's find your " + applicant.getState() + " address in ZIP Code " + applicant.getZipCode() + ", or enter your address manually.",
				"Please enter your " + applicant.getState() + " address.").contains(getTextFromElement(personalInfoPageSubtitle)),  "Personal Info page subtitle");
		fsa.assertEquals(getTextFromElement(apartmentInputFieldLabel), "Optional", "Apartment input field label");
		fsa.assertEquals(getTextFromElement(genderSelectionLabel), "Please select your gender (as assigned at birth)", "Gender section title");
		fsa.assertEquals(getTextFromElement(nicotineUseSelectionLabel), "Have you ever used any nicotine products in the past?", "Nicotine use section title");
		fsa.assertEquals(getTextFromElement(emailAndPhoneSectionLabel), "Contact information (required)", "email/phone section title");
		fsa.assertTrue(isButtonNotSelected(maleButton), "Male button not pressed by default");
		fsa.assertTrue(isButtonNotSelected(femaleButton), "Female button not pressed by default");
		fsa.assertTrue(isButtonNotSelected(haveUsedNicotineButton), "Used nicotine button not pressed by default");
		fsa.assertTrue(isButtonNotSelected(notUsedNicotineButton), "Never used nicotine button not pressed by default");
		clickElement(enterAddressManuallyLink);
		fsa.assertEquals(getTextFromElement(personalInfoPageSubtitle), "Please enter your " + applicant.getState() + " address.", "Manual Address entry text label");
		fsa.assertEquals(getTextFromElement(pewcDisclaimerText), "By clicking \"Agree and submit\", you agree to these ESIGN terms and conditions and to receive marketing calls and texts as detailed below." + connectingCharacter +
				"We call and/or text consumers with information about products and services. " +
				"By clicking \"Agree and submit\", you consent to receive marketing calls and texts on behalf of Farmers\u00ae, Foremost\u00ae, Bristol West\u00ae, and Farmers Life\u00ae associated entities and their representatives using an automated telephone dialing system, AI-generated and artificial or pre-recorded voice, even for numbers listed on national, state, or business do-not-call registries. " +
				"Consent is not a condition of purchase. Go to Farmers.com for alternative contact options. Message and data rates may apply.", "PEWC disclaimer text");
		fsa.assertEquals(getTextFromElement(privacyDisclaimer), "Farmers entities may use any consumer report information their affiliates might currently have for you for your quote request. Our Privacy Notice gives you the choice to opt out of allowing Farmers affiliates to share your consumer report information among Farmers entities. " +
				"You can still opt out of future sharing." + connectingCharacter +"You also acknowledge that you have read the Privacy Policy.", "Privacy policy disclaimer text");
		fsa.assertEquals(getTextFromElement(agreeAndSubmitButton), "Agree and submit", "Agree and submit button label");
		String imageSourceValue = getAttributeData(personalInfoPageImage, SRC);
		fsa.assertTrue(imageSourceValue!= null && imageSourceValue.contains("life-rebrand.png"), "life-rebrand.png image used in page");
		fsa.assertEquals(getTextFromElement(legalDisclaimerText), "ICC25-FTL or applicable state variation" + connectingCharacter +
				"Life insurance issued by Farmers New World Life Insurance Company, 12822 SE 32nd St, Suite 2 Bellevue, WA 98005. " +
				"Products and features, including same-day coverage, may not be available to all applicants or in all states and may vary by state. " +
				"Restrictions, exclusions, limits, and conditions apply."+ connectingCharacter2 +
				"Any product guarantees are subject to the financial strength and claims-paying ability of Farmers New World Life Insurance Company, which is solely responsible for the obligations under its own policies. " +
				"Farmers New World Life Insurance Company is not licensed and does not solicit or sell in the state of New York." + connectingCharacter3 +
				"6952619.2 5/26", "Legal disclaimer text");
	}

	public void retrievedQuoteContentValidation(ApplicantLife applicant, FarmersSoftAssert fsa) throws Exception {
		fsa.assertEquals(getTextFromElement(personalInfoPageTitle), "Hi, " + applicant.getFirstName(), "Personal Info page title");
		fsa.assertEquals(getTextFromElement(personalInfoPageSubtitle), "Your address " + toPascalCase(applicant.getAddress())+ SPACE + toPascalCase(applicant.getCity()) + COMMA + SPACE + applicant.getStateCode() + SPACE + applicant.getZipCode(), "Applicant retrieved address");
		fsa.assertEquals(getTextFromElement(genderSelectionLabel), "Please select your gender (as assigned at birth)", "Gender section title");
		fsa.assertEquals(getTextFromElement(nicotineUseSelectionLabel), "Have you ever used any nicotine products in the past?", "Nicotine use section title");
		fsa.assertEquals(getTextFromElement(emailAndPhoneSectionLabel), "Contact information (required)", "email/phone section title");
		if (applicant.getGender().equalsIgnoreCase(MALE)) {
			fsa.assertTrue(isButtonSelected(maleButton), "Male button pressed");
			fsa.assertTrue(isButtonNotSelected(femaleButton), "Female button not pressed");
		} else {
			fsa.assertTrue(isButtonSelected(femaleButton), "Female button pressed");
			fsa.assertTrue(isButtonNotSelected(maleButton), "Male button not pressed");
		}
		fsa.assertEquals(getAttributeData(emailInputField, READONLY), LOWERCASE_TRUE, "Email field read only");
		fsa.assertEquals(getAttributeData(phoneNumberInputField, READONLY), LOWERCASE_TRUE, "Phone number field read only");
		fsa.assertEquals(getValueFromWebElement(emailInputField), applicant.getEmailAddress(), "Retrieved email data matches");
		fsa.assertEquals(getValueFromWebElement(phoneNumberInputField), getFormattedPhoneNumber(applicant.getPhoneNumber()), "Retrieved phone number matches");
	}

	public void clickOnAgreeAndSubmitButton() {
		scrollToBottomOfPage();
		clickElement(agreeAndSubmitButton);
	}

	public void errorMessageValidation(FarmersSoftAssert fsa) {
		//Assumption is we have a clean page already loaded
		clickOnAgreeAndSubmitButton();
		scrollToTopOfPage();
		//Default no entry messages - A/B testing may cause some variation in verbiage so we will accept either version of the message if both are present.
		fsa.assertTrue(List.of("Please enter your home address.", "Please enter street number and name.").contains(getTextFromElement(addressInputFieldErrorLabel)), "addressInputFieldErrorLabel no entry check");
		fsa.assertEquals(getTextFromElement(genderSelectionErrorLabel), "This is required.", "genderSelectionErrorLabel no entry check");
		fsa.assertEquals(getTextFromElement(nicotineUseSelectionErrorLabel), "This is required.", "nicotineUseSelectionErrorLabel no entry check");
		fsa.assertEquals(getTextFromElement(personalInfoPageErrorLabel), "One or more required fields are incomplete or incorrect. Please review.", "personalInfoPageErrorLabel no entry check");
		//Check for invalid data on fields - Not with A/B testing going on
//		enterValueInField(ALPHA, addressInputField, "Invalid address");
//		scrollAndClickOnElement(apartmentInputField);
//		waitElementBeVisible(goBackLink);
//		fsa.assertEquals(getTextFromElement(addressInputFieldErrorLabel), "Please select an address from the list.", "addressInputFieldErrorLabel select address check");
//		clickElement(goBackLink);
		enterValueInField(ALPHA, emailInputField, "Invalid email address");
		enterValueInField(INVALID_PHONE, phoneNumberInputField, "Invalid phone number");
		clickOnAgreeAndSubmitButton();
		scrollElementToMiddle(phoneNumberInputField);
		fsa.assertEquals(getTextFromElement(emailInputFieldErrorLabel), "Email address entered is invalid.", "emailInputFieldErrorLabel invalid data check");
		fsa.assertEquals(getTextFromElement(phoneNumberInputFieldErrorLabel), getValueFromWebElement(phoneNumberInputField) + " is not a valid entry.", "phoneNumberInputFieldErrorLabel invalid data check");
		scrollAndClickOnElement(enterAddressManuallyLink);
		clickOnAgreeAndSubmitButton();
		scrollToTopOfPage();
		fsa.assertTrue(List.of("Please enter your home address.", "Please enter street number and name.").contains(getTextFromElement(addressInputFieldErrorLabel)), "addressInputFieldErrorLabel manual entry check");
		fsa.assertEquals(getTextFromElement(manualEntryCityInputFieldErrorLabel), "Please enter your city.", "manualEntryCityInputFieldErrorLabel no entry check");
		enterValueInField(ALPHA, manualEntryAddressInputField, "Reset address field");
		enterValueInField(DIGITS, manualEntryCityInputField, "Invalid city");
		enterValueInField(SPACE, manualEntryZipCodeInputField, "Invalid zip code");
		enterValueInField(DIGITS, manualEntryAddressInputField, "Invalid address");
		scrollAndClickOnElement(manualEntryZipCodeInputField);
		clickOnAgreeAndSubmitButton();
		fsa.assertTrue(List.of("Please enter your home address.", "Please enter street number and name.").contains(getTextFromElement(addressInputFieldErrorLabel)), "addressInputFieldErrorLabel manual entry invalid data check");
		fsa.assertEquals(getTextFromElement(manualEntryCityInputFieldErrorLabel), DIGITS + " is not a valid city.", "manualEntryCityInputFieldErrorLabel invalid data check");
		enterValueInField("9", manualEntryZipCodeInputField, "Incomplete ZIP code");
		clickOnAgreeAndSubmitButton();
		scrollToTopOfPage();
		if (! isSafariBrowser()) {
			fsa.assertEquals(getTextFromElement(manualEntryZipCodeInputFieldErrorLabel), "Please enter a 5 digit ZIP Code.", "manualEntryZipCodeInputFieldErrorLabel incomplete zipcode check");
		}
	}

	public void enterDataAndContinueToReviewQuotePage(ApplicantLife applicant) {
		if (enterGoogleAddress(addressInputField, applicant.getAddress(), applicant.getCity())) {
			if (!applicant.getApartment().isEmpty()) {
				enterValueInField(applicant.getApartment(), apartmentInputField, "Unit info");
			}
		} else {
			// Manually enter address
			if (isElementDisplayed(yesEnterManuallyButton, 5)) {
				sleep(3);
				clickElement(yesEnterManuallyButton);
			} else {
				clickElement(enterAddressManuallyLink);
			}
			waitAndClickElement(manualEntryAddressInputField);
			scrollElementToMiddle(manualEntryAddressInputField);
			enterValueInField(applicant.getAddress(), manualEntryAddressInputField, "Manually enter address");
			enterValueInField(applicant.getApartment(), manualEntryApartmentInputField, "Manually enter unit number");
			enterValueInField(applicant.getCity(), manualEntryCityInputField, "Manually enter city");
		}
		if (applicant.getGender().equalsIgnoreCase(MALE)) {
			clickElement(maleButton);
		} else {
			clickElement(femaleButton);
		}
		if (applicant.getUseTobacco().equalsIgnoreCase(YES)) {
			clickElement(haveUsedNicotineButton);
		} else {
			clickElement(notUsedNicotineButton);
		}
		enterValueInField(applicant.getEmailAddress(), emailInputField, "email address");
		enterValueInField(applicant.getPhoneNumber(), phoneNumberInputField, "phone number");
		scrollElementToMiddle(emailInputField);
		scrollToElement(phoneNumberInputField);
		clickOnAgreeAndSubmitButton();
	}

	public void testQuoteRetrieval(ApplicantLife applicant, boolean completedPersonalInfoPage, FarmersSoftAssert fsa) throws Exception {
		if (!completedPersonalInfoPage) {
			//For now retrieval only works for completed quotes, if that changes then enter the data
			fsa.assertTrue(new KnockoutInconveniencePage().isUnableToCompleteOnlineQuoteKnockOutPage(), "Unable to complete online quote page displayed");
			//enterDataAndContinueToReviewQuotePage(applicant);
		} else {
			fsa.assertTrue(isOnPersonalInfoPage(), "Returned to Personal Info page");
			retrievedQuoteContentValidation(applicant, fsa);
			clickOnAgreeAndSubmitButton();
		}
	}

	private static String toPascalCase(String stringToConvert) {
		StringBuilder result = new StringBuilder();
		String[] words = stringToConvert.split("\\s+"); // Split by whitespace
		for (String word : words) {
			result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1).toLowerCase()).append(SPACE);
		}
		result.deleteCharAt(result.length()-1);
		return result.toString();
	}
}
