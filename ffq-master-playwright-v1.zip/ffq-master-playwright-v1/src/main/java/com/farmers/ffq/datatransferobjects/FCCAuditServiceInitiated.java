package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@JsonIgnoreProperties
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class FCCAuditServiceInitiated {

    private CustomerConsentDataRequest customerConsentDataRequest;

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class CustomerConsentDataRequest {
        private RequestHeader requestHeader;
        private String fcc_disclaimerMsg;
        private String applicationId;
        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class RequestHeader {

        }
    }
}
