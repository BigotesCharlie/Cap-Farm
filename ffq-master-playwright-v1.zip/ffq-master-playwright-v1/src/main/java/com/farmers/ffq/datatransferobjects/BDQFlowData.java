package com.farmers.ffq.datatransferobjects;

import lombok.Data;

@Data
public class BDQFlowData {
    private String stateAbb;
    private String stateCode;
    private String bdqFullUrl;
}
