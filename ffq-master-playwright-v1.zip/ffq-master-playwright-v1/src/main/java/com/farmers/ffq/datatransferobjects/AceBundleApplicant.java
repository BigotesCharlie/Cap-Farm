package com.farmers.ffq.datatransferobjects;

import com.farmers.ffq.common.pages.BasePage;
import lombok.Data;
import net.datafaker.Faker;
import org.apache.commons.lang3.RandomStringUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static com.farmers.ffq.common.pages.BasePage.generateEmailAddress;
import static com.farmers.ffq.utils.GlobalVariables.*;

@Data
public class AceBundleApplicant {
	private AutoApplicant autoApplicant;
	private ApplicantAceHome hrcApplicant;

	/**
	 * String Representation of class.
	 */
	public String toString() {
		StringBuilder applicantInfo = new StringBuilder("Bundle applicant #");
		if (autoApplicant != null) {
			applicantInfo.append(autoApplicant.getApplicantId() + COLON + SPACE + autoApplicant.getFirstName() + SPACE + autoApplicant.getLastName() + SPACE + autoApplicant.getResidentAddress() + SPACE + autoApplicant.getCity() + SPACE + autoApplicant.getStateName() + SPACE + autoApplicant.getZipCode()) ;
		}
		return applicantInfo.toString();
	}

	public String applicantInfo() {
		StringBuilder applicantInfo = new StringBuilder();
		if (autoApplicant != null) {
			applicantInfo.append("Auto applicant row used: " +
					autoApplicant.getApplicantId() + SPACE + autoApplicant.getFirstName() + SPACE + autoApplicant.getLastName() + SPACE + autoApplicant.getResidentAddress() + SPACE + autoApplicant.getCity() + SPACE + autoApplicant.getStateName() + SPACE + autoApplicant.getZipCode() + NEWLINE) ;
		}
		if (hrcApplicant != null) {
			applicantInfo.append("Ace HRC row used: " + hrcApplicant.toString() + NEWLINE);
		}
		return applicantInfo.toString();
	}

	public void normalizeData() {
		// Use data in Auto as PNI
		Faker faker = new Faker();
		autoApplicant.setFirstName(faker.name().firstName());
		autoApplicant.setLastName(faker.name().lastName()+ RandomStringUtils.randomAlphabetic(3).toLowerCase());
		autoApplicant.setEmail(generateEmailAddress("farminsqa.testinator.com"));
		String spouseFirstName = EMPTY_STRING;
		String spouseLastName = EMPTY_STRING;
		String spouseGender = EMPTY_STRING;
		int spouseAge = 0;
		List<SqlAdditionalDriver> listOfAdditionalDrivers = autoApplicant.getAdditionalDrivers();
		if (!listOfAdditionalDrivers.isEmpty()) {
			SqlAdditionalDriver additionalDriver = autoApplicant.getAdditionalDrivers().get(0);
			spouseFirstName = additionalDriver.getFirstName();
			spouseLastName = additionalDriver.getLastName();
			spouseGender = additionalDriver.getGender();
			spouseAge = additionalDriver.getAge();
			//Limit to two additional drivers
			for (int count = listOfAdditionalDrivers.size(); count>2; count--) {
				listOfAdditionalDrivers.remove(count-1);
			}
			autoApplicant.setAdditionalDrivers(listOfAdditionalDrivers);
		}
		//Limit to three vehicles
		List<Vehicle> listOfVehicles = autoApplicant.getVehicles();
		for (int count = listOfVehicles.size(); count>3; count--) {
			listOfVehicles.remove(count-1);
		}
		autoApplicant.setVehicles(listOfVehicles);
		hrcApplicant.setAddress(autoApplicant.getResidentAddress());
		hrcApplicant.setCity(autoApplicant.getCity());
		hrcApplicant.setZipCode(autoApplicant.getZipCode());
		// HRC data update
		hrcApplicant.setFirstName(autoApplicant.getFirstName());
		hrcApplicant.setLastName(autoApplicant.getLastName());
		hrcApplicant.setDateOfBirth(autoApplicant.getDateOfBirth());
		hrcApplicant.setMaritalStatus(autoApplicant.getMaritalStatus());
		hrcApplicant.setGender(autoApplicant.getGender());
		hrcApplicant.setSpouseFirstName(spouseFirstName);
		hrcApplicant.setSpouseLastName(spouseLastName);
		hrcApplicant.setSpouseDateOfBirth(BasePage.calculateDateOfBirthFromAge(spouseAge));
		hrcApplicant.setSpouseGender(spouseGender);
		hrcApplicant.setPhoneNumber(autoApplicant.getPhoneNumber());
		hrcApplicant.setEmailAddress(autoApplicant.getEmail());
		hrcApplicant.setKeep360Prefill(false);
		hrcApplicant.setYearBuilt(2017);
		hrcApplicant.setFortifiedHome(EMPTY_STRING);
		hrcApplicant.setWildFireRisk(EMPTY_STRING);
		hrcApplicant.setSquareFeet("1700");
		hrcApplicant.setGeneralShapeAndStyleQualityGrade(STANDARD);
		hrcApplicant.setExteriorShapeAndStyleQualityGrade(STANDARD);
		hrcApplicant.setInteriorShapeAndStyleQualityGrade(STANDARD);
		hrcApplicant.setCabinetsAndCounterTopsQualityGrade(STANDARD);
		hrcApplicant.setTemporaryRentals(false);
		hrcApplicant.setTrampoline(EMPTY_STRING);
		hrcApplicant.setSwimmingPool(EMPTY_STRING);
		hrcApplicant.setSolarPanels(false);
		hrcApplicant.setRoofReplaced(EMPTY_STRING);
		hrcApplicant.setNewlyOwned(false);
		hrcApplicant.setInEscrow(false);
        if (hrcApplicant.getEarlyShoppingFactor().equalsIgnoreCase(TRUE)) {
            hrcApplicant.setEarlyShoppingFactor(LocalDate.now().plusDays(7).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)));
        } else {
            if (hrcApplicant.getEarlyShoppingFactor().equalsIgnoreCase(FALSE) || hrcApplicant.getEarlyShoppingFactor().isBlank()) {
                hrcApplicant.setEarlyShoppingFactor(LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)));
            }
        }
		setHrcApplicant(hrcApplicant);
		setAutoApplicant(autoApplicant);
	}
}
