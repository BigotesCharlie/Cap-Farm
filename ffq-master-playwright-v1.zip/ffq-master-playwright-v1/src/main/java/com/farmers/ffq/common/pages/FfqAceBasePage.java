package com.farmers.ffq.common.pages;

import com.farmers.framework.AutomationFramework;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class FfqAceBasePage extends AutomationFramework {
    public static String AGE_LIMIT_ERROR = "Age should be between 15 and 99 years.";
    public static String DOB_IS_NOT_VALID_ENTRY_ERROR = "Date of Birth is not a valid entry.";
    public static String INVALID_FORMAT_DATE = "11/11/199";
    public static final String NOT_ALLOWED_SPECIAL_CHARACTERS = "!@#$%^&*()_+=~`[]{}|:;<>/?";
    public static final String NOT_ALLOWED_NUMERIC_CHARACTERS = "1234567890";
    public static final String NOT_ALLOWED_SPECIAL_AND_ALPHABETIC_CHARACTERS = "!@#$%^&*()_+=~`[]{}|:;'<>,/?abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final String ABOUT_YOU_HEADER = "About you";
    public static final String LOG_MESSAGE_TEMPLATE = "Entering ";

    public static String generateDateOfBirthYoungerThan15OrOlderThan99() {
        LocalDate currentDate = LocalDate.now();
        Random random = new Random();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        int month = random.nextInt(12) + 1;
        int day = random.nextInt(28) + 1; // We assume February 28 as the maximum date for simplicity.
        int year;
        boolean isYounger = random.nextBoolean();
        if (isYounger) {
            // Generate a random age between 1 to 14 (inclusive)
            int startYoungYear = currentDate.minusYears(14).getYear();
            year = random.nextInt(14) + startYoungYear;
        } else {
            // Generate a random age between 99 to 200 (inclusive)
            int startOldYear = currentDate.minusYears(200).getYear();
            year = random.nextInt(101) + startOldYear;
        }
        return LocalDate.of(year, month, day).format(dateFormatter);
    }
}
