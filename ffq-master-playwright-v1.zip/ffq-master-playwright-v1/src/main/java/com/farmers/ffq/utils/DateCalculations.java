package com.farmers.ffq.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.ThreadLocalRandom;

public class DateCalculations {

	public static Long ageFromDob(String dob) {
		return ChronoUnit.YEARS.between(LocalDate.parse(dob, DateTimeFormatter.ofPattern("MM/dd/yyyy")), LocalDate.now());
	}

	public static Long ageFromYear(String year) {
		return ChronoUnit.YEARS.between(LocalDate.parse("01/01/"+year, DateTimeFormatter.ofPattern("MM/dd/yyyy")), LocalDate.now());
	}

	public static String generateDateBetweenRange(){

		LocalDate startDate = LocalDate.of(1980, 1, 1); //start date
		long start = startDate.toEpochDay();

		LocalDate endDate = LocalDate.of(2004, 1, 1); //end date
		long end = endDate.toEpochDay();

		long randomEpochDay = ThreadLocalRandom.current().longs(start, end).findAny().getAsLong();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		return formatter.format(LocalDate.ofEpochDay(randomEpochDay)).toString();
	}
}
