package com.farmers.ffq.common.pages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.framework.report.Log;
public class BristolWestLandingPage extends AutoBasePage {

    @PWFindBy(id = "bw-main-content")
    private PWElement pageHeader;

    @PWFindBy(xpath = "//div[@class='hero-split__input-field']//input")
    private PWElement zipCodeInput;
    @PWFindBy(xpath = "//div[@class='hero-split__mobile-input-inner']//input")
    private PWElement zipCodeInputMobileView;
    @PWFindBy(xpath = "//button[@class='hero-split__button start-quote-btn']")
    private PWElement startQuoteButton;

    @PWFindBy(xpath = "//button[@class='hero-split__mobile-button start-quote-btn']")
    private PWElement startQuoteButtonMobileView;
    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public BristolWestLandingPage() throws Exception {
    }


    private boolean isOnBristolWestLandingPage() {
        return isElementVisible(pageHeader, 5);
    }

    public void launchBristolWestLandingPage(String url, String zipCode) throws Exception {
        if (isUseMobileViewEnabled()) {
            setBrowserDimensionToMobileBreakPoint();
        }

        driver().get(url);
        isOnBristolWestLandingPage();
        Log.info("User is on the Landing Page for BW");
        fillOutZipCodeInputField(zipCode);
        clickStartQuoteButton();
    }

    private void fillOutZipCodeInputField(String zipCode) throws Exception {
        if(isUseMobileViewEnabled()) {
            sendKeysToElement(zipCodeInputMobileView, zipCode);
        }else{
            sendKeysToElement(zipCodeInput, zipCode);
        }
    }

    private void clickStartQuoteButton() {
        if(isUseMobileViewEnabled()) {
            clickElement(startQuoteButtonMobileView);
        }else{
            clickElement(startQuoteButton);
        }
    }
}
