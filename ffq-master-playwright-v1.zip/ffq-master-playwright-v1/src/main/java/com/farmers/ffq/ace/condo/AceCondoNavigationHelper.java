package com.farmers.ffq.ace.condo;

import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;


public class AceCondoNavigationHelper extends AceHRCNavigationHelperBasePage {
	/**
	 * Constructor.
	 *
	 * @throws Exception if driver() call fails
	 */
	public AceCondoNavigationHelper() throws Exception {
	}

	public AceHRCPropertyInfoBasePage navigateToAceCondoPropertyInfoPage(ApplicantAceHome applicant) throws Exception {
		return navigateToAceHRCPropertyInfoBasePage(applicant, LOB_HOME, CONDO);
	}

	public AceHRCAddressBasePage navigateToAceCondoAddressPage(ApplicantAceHome applicant) throws Exception {
		if (isNewFlowEnabledState(applicant.getStateCode())) {
			navigateToAceHRCAddressContactBasePage(applicant, LOB_CONDO);
		} else {
			navigateToHRCAddressPage(applicant, LOB_CONDO, CONDO);
		}
		AceHRCAddressBasePage addressPage = new AceHRCAddressBasePage();
		if (addressPage.isOnAddressPage(true)) {
			Reporter.pass("Navigated to AceCondoAddressPage");
			return addressPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AceCondoAddressPage");
		}
	}

	public AceCondoPropertyDetailsPage navigateToAceCondoPropertyDetailsPage(ApplicantAceHome applicant) throws Exception {
		AceCondoPropertyDetailsPage propertyDetailsPage = new AceCondoPropertyDetailsPage();
		if(getResumeFromPage().equals(PROPERTY_DETAILS)) {
			return propertyDetailsPage;
		}
		AceHRCQualityGradeBasePage aceHRCQualityGradeBasePage = navigateToHRCQualityGradePage(applicant, LOB_CONDO, CONDO);
		aceHRCQualityGradeBasePage.fillOutQualityGradePage(applicant, getSessionStorageAppStore().getHome().getHomeQualityGradeForm());
		waitForSpinnerToBeGone();
		if (propertyDetailsPage.isOnPropertyDetailsPage()) {
			if (isADATestingEnabled()){
				propertyDetailsPage.validateADA(FFQ_ACE_CONDO);
			}
			Reporter.pass("Navigated to AceCondoPropertyDetailsPage");
			return propertyDetailsPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AceCondoPropertyDetailsPage");
		}
	}

	public AceCondoAdditionalInfoPage navigateToAceCondoAdditionalInfoPage(ApplicantAceHome applicant) throws Exception {
		AceCondoAdditionalInfoPage additionalInfoPage = new AceCondoAdditionalInfoPage();
		if(getResumeFromPage().equals(ADDITIONAL_INFO)) {
			return additionalInfoPage;
		}
		AceHRCQualityGradeBasePage aceHRCQualityGradeBasePage = navigateToHRCPropertyDetailsQualityGradePage(applicant, LOB_CONDO, CONDO);
		aceHRCQualityGradeBasePage.fillOutQualityGradePage(applicant, getSessionStorageAppStore().getHome().getHomeQualityGradeForm());
		AceCondoPropertyDetailsPage propertyDetailsPage = new AceCondoPropertyDetailsPage();
		propertyDetailsPage.enterPropertyDetails(applicant);
		propertyDetailsPage.clickContinueButton();
		waitForSpinnerToBeGone();
		if (additionalInfoPage.isOnAdditionalInfoPage()) {
			if (isADATestingEnabled()){
				additionalInfoPage.validateADA(FFQ_ACE_CONDO);
			}
			Reporter.pass("Navigated to AceCondoAdditionalInfoPage");
			return additionalInfoPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AceCondoAdditionalInfoPage");
		}
	}

	public AceHRCAboutYouBasePage navigateToAceCondoAboutYouPage(ApplicantAceHome applicant) throws Exception {
		AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
		if(getResumeFromPage().equals(ABOUT_YOU)) {
			return aboutYouPage;
		}
		AceCondoAdditionalInfoPage additionalInfoPage = navigateToAceCondoAdditionalInfoPage(applicant);
		additionalInfoPage.fillOutAdditionalInfoPageCondo(applicant,true);
		waitForSpinnerToBeGone();
		if (aboutYouPage.isOnAboutYouPage(true)) {
			if (isADATestingEnabled()){
				aboutYouPage.validateADA(FFQ_ACE_CONDO);
			}
			Reporter.pass("Navigated to AceCondoAboutYouPage");
			return aboutYouPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AceCondoAboutYouPage");
		}
	}

    public AceCondoContactInfoPage navigateToAceCondoContactInfoPage(ApplicantAceHome applicant) throws Exception {
		AceCondoContactInfoPage contactInfoPage = new AceCondoContactInfoPage();
		if(getResumeFromPage().equals(CONTACT_INFO)) {
			return contactInfoPage;
		}
        if (isNewFlowEnabledState(applicant.getStateCode())) {
			AceCondoAdditionalInfoPage additionalInfoBasePage = navigateToAceCondoAdditionalInfoPage(applicant);
			additionalInfoBasePage.fillOutAdditionalInfoPageCondo(applicant, true);
		} else {
			AceHRCAboutYouBasePage aboutYouPage = navigateToAceCondoAboutYouPage(applicant);
			aboutYouPage.fillOutTheDataInAboutYouPage(applicant, true);
		}
		waitForSpinnerToBeGone();
		if (contactInfoPage.isOnContactInfoPage(true)) {
			if (isADATestingEnabled()){
				contactInfoPage.validateADA(FFQ_ACE_CONDO);
			}
			Reporter.pass("Navigated to AceCondoContactInfoPage");
			return contactInfoPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AceCondoContactInfoPage");
		}

	}

	public AceCondoCustomCoveragePage navigateToAceCondoCustomCoveragePage(ApplicantAceHome applicant) throws Exception {
		AceCondoCustomCoveragePage customCoveragePageAceCondo = new AceCondoCustomCoveragePage();
		if(getResumeFromPage().equals(CUSTOM_COVERAGE)) {
			return customCoveragePageAceCondo;
		}
		AceHRCContactInfoBasePage contactInfoPage = navigateToAceCondoContactInfoPage(applicant);
		contactInfoPage.fillOutContactInfoPage(applicant, CONDO);
		waitForSpinnerToBeGone();
		if (customCoveragePageAceCondo.isOnCustomCoveragePageAceCondo()) {
			if (isADATestingEnabled()){
				customCoveragePageAceCondo.validateADA();
			}
			Reporter.pass("Navigated to AceCondoCustomCoveragePage");
			return customCoveragePageAceCondo;
		} else {
			reportKnockout();
			throw new IllegalStateException(DID_NOT_REACH + "AceCondoCustomCoveragePage");
		}
	}

	public AceCondoReviewQuotePage navigateToAceCondoReviewQuotePage(ApplicantAceHome applicant) throws Exception {
		AceCondoReviewQuotePage reviewQuotePage = new AceCondoReviewQuotePage();
		if (List.of(FAILED_RC2, FAILED_RC3, REVIEW_QUOTE).contains(getResumeFromPage())) {
			return reviewQuotePage;
		}
		AceCondoCustomCoveragePage customCoveragePage = navigateToAceCondoCustomCoveragePage(applicant);
		customCoveragePage.fillOutCustomCoveragePageCondo(applicant);
		customCoveragePage.clickOnContinueButton();
		return goToAceCondoReviewQuotePage(applicant);
	}

	public AceCondoReviewQuotePage goToAceCondoReviewQuotePage(ApplicantAceHome applicant) throws Exception {
		AceCondoReviewQuotePage reviewQuotePage = new AceCondoReviewQuotePage();
		waitForSpinnerToBeGone();
		if (reviewQuotePage.isOnReviewQuotePage(true)) {
			Log.info("Ace Condo - Review Quote page. Quote number: " + applicant.getQuoteNumber(), true);
			logQuoteNumber(applicant, CONDO, applicant.getQuoteNumber());
			if (isADATestingEnabled()){
				reviewQuotePage.validateADA(FFQ_ACE_CONDO);
			}
			Reporter.pass("Navigated to AceCondoReviewQuotePage");
			return reviewQuotePage;
		} else {
			if (isTryAgainPagePresent() && !wasTryAgainSuccessful()) {
				throw new IllegalStateException("AceCondoReviewQuotePage: " + TRY_AGAIN_ATTEMPTS_LIMIT_EXCEEDED);
			} else {
				if (reviewQuotePage.isOnReviewQuotePage(false)) {
					Reporter.pass("Navigated to AceCondoReviewQuotePage");
					return reviewQuotePage;
				}
				reportKnockout();
				throw new IllegalStateException(DID_NOT_REACH + "AceCondoReviewQuotePage");
			}
		}
	}

	public AceCondoAdditionalCoveragesPage navigateToAceCondoAdditionalCoveragesPage(ApplicantAceHome applicant) throws Exception {
		AceCondoAdditionalCoveragesPage additionalCoveragesPage = new AceCondoAdditionalCoveragesPage();
		if(getResumeFromPage().equals(ADDITIONAL_COVERAGES)) {
			return additionalCoveragesPage;
		}
		navigateToAceCondoReviewQuotePage(applicant).clickOnContinueButton();
		if (additionalCoveragesPage.isOnAdditionalCoveragesPageAceCondo()) {
			if (isADATestingEnabled()){
				additionalCoveragesPage.validateADA(applicant);
			}
			Reporter.pass("Navigated to AdditionalCoveragesPageAceCondo");
			return additionalCoveragesPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AdditionalCoveragesPageAceCondo");
		}
	}

	public AceHRCJustAFewMoreThingsBasePage navigateToAceCondoJustAFewMoreThingsPage(ApplicantAceHome applicant) throws Exception {
		AceHRCJustAFewMoreThingsBasePage jFMTPage = new AceHRCJustAFewMoreThingsBasePage();
		if(getResumeFromPage().equals(JFMT_PAGE)) {
			return jFMTPage;
		}
		navigateToAceCondoAdditionalCoveragesPage(applicant).clickOnContinueButton();
		waitForSpinnerToBeGone();
		if (jFMTPage.isOnJFMTPage(true)) {
			Reporter.pass("Navigated to AceCondoJustAFewMoreThingsPage");
			return jFMTPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AceCondoJustAFewMoreThingsPage");
		}
	}

	public AceHRCThankYouBasePage navigateToAceCondoThankYouPage(ApplicantAceHome applicant) throws Exception {
		AceHRCThankYouBasePage aceHRCThankYouPage = new AceHRCThankYouBasePage();
		if(getResumeFromPage().equals(THANK_YOU_PAGE)) {
			return aceHRCThankYouPage;
		}
		navigateToAceCondoAdditionalCoveragesPage(applicant).clickOnContinueButton();
		if (aceHRCThankYouPage.isOnThankYouPage()) {
			Reporter.pass("Navigated to AceCondoThankYouPage");
			return aceHRCThankYouPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AceCondoThankYouPage");
		}
	}

	public AceHRCPaymentSelectionPage navigateToAceCondoPaymentSelectionPage(ApplicantAceHome applicant) throws Exception {
		AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
		if(getResumeFromPage().equals(SELECT_PAYMENT)) {
			return aceHRCPaymentSelectionPage;
		}
		navigateToAceCondoJustAFewMoreThingsPage(applicant);
		AceCondoJustAFewMoreThingsPage jFMTPageCondoLob = new AceCondoJustAFewMoreThingsPage();
		if (!List.of(FAILED_RC2, FAILED_RC3).contains(getResumeFromPage())) {
			jFMTPageCondoLob.fillOutJustFewMoreThingsPageCondo(applicant, true);
		} else {
			jFMTPageCondoLob.selectDogsOnPremisesCheckbox(applicant.getDogsOnPremises());
			jFMTPageCondoLob.clickContinueButton();
		}
		if (aceHRCPaymentSelectionPage.isOnPaymentPage()) {
			Reporter.pass("Navigated to AceCondoPaymentSelectionPage");
			Log.info("Ace Condo - Payment page. Quote number: " + applicant.getQuoteNumber(), true);
			return aceHRCPaymentSelectionPage;
		} else {
			if (!getResumeFromPage().equals(FAILED_RC2)) {
				Log.info(DID_NOT_REACH + "Ace Condo - Payment Selection page. Quote number: " + applicant.getQuoteNumber());
				retrieveQuoteByQuoteNumber(applicant);
				setResumeFromPage(FAILED_RC2);
				aceHRCPaymentSelectionPage = navigateToAceCondoPaymentSelectionPage(applicant);
				if (aceHRCPaymentSelectionPage.isOnPaymentPage()) {
					return aceHRCPaymentSelectionPage;
				}
			}
			throw new IllegalStateException(DID_NOT_REACH + "Ace Condo - Payment Selection Page");
		}
	}

	public AceHRCPaymentBasePage navigateToPayInFullPaymentPageAceCondo(ApplicantAceHome applicant) throws Exception {
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		if (getResumeFromPage().equals(PAYMENT_PAGE)) {
			return aceHRCPaymentBasePage;
		}
		AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = navigateToAceCondoPaymentSelectionPage(applicant);
		if(isUseMobileViewEnabled()){
			aceHRCPaymentSelectionPage.clickPayInFullTabMobile();
		}
		aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentPayInFullCard(LOB_CONDO);
		if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage()) {
			Reporter.pass("Navigated to AceCondoPayInFullPage");
			Log.info("Ace Condo - Pay in full payment page. Quote number: " + applicant.getQuoteNumber(), true);
			return aceHRCPaymentBasePage;
		} else {
			if (!getResumeFromPage().equals(FAILED_RC3)) {
				Log.info(DID_NOT_REACH + "Ace Condo - Payment PIF page. Quote number: " + applicant.getQuoteNumber());
				retrieveQuoteByQuoteNumber(applicant);
				setResumeFromPage(FAILED_RC3);
				aceHRCPaymentBasePage = navigateToPayInFullPaymentPageAceCondo(applicant);
				if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage()) {
					return aceHRCPaymentBasePage;
				}
			}
			throw new IllegalStateException(DID_NOT_REACH + "aceHRCPaymentBasePage PIF Condo.");
		}

	}

	public AceHRCPaymentBasePage navigateToMonthlyAutoPayCardPaymentPageAceCondo(ApplicantAceHome applicant) throws Exception {
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		if (getResumeFromPage().equals(PAYMENT_PAGE)) {
			return aceHRCPaymentBasePage;
		}
		AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = navigateToAceCondoPaymentSelectionPage(applicant);
		if(isUseMobileViewEnabled()){
			aceHRCPaymentSelectionPage.clickMonthlyPayCardTabMobile();
		}
		aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayCard();
		if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage()) {
			Reporter.pass("Navigated to AceCondoMonthlyCardPaymentPage");
			Log.info("Ace Condo - Monthly pay card payment page. Quote number: " + applicant.getQuoteNumber(), true);
			return aceHRCPaymentBasePage;
		} else {
			if (!getResumeFromPage().equals(FAILED_RC3)) {
				Log.info(DID_NOT_REACH + "Ace Condo - Monthly Payment page. Quote number: " + applicant.getQuoteNumber());
				retrieveQuoteByQuoteNumber(applicant);
				setResumeFromPage(FAILED_RC3);
				aceHRCPaymentBasePage = navigateToMonthlyAutoPayCardPaymentPageAceCondo(applicant);
				if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage()) {
					return aceHRCPaymentBasePage;
				}
			}
			throw new IllegalStateException(DID_NOT_REACH + "aceHRCPaymentBasePage Condo Monthly card.");
		}
	}

	public AceHRCPaymentBasePage navigateToMonthlyAutoPayBankPaymentPageAceCondo(ApplicantAceHome applicant) throws Exception {
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		if (getResumeFromPage().equals(PAYMENT_PAGE)) {
			return aceHRCPaymentBasePage;
		}
		AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = navigateToAceCondoPaymentSelectionPage(applicant);
		if(isUseMobileViewEnabled()){
			aceHRCPaymentSelectionPage.clickMonthlyPayBankTabMobile();
		}
		aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayBank();
		if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage()) {
			Reporter.pass("Navigated to AceCondoMonthlyBankPayPage");
			Log.info("Ace Condo - Monthly pay bank payment page. Quote number: " + applicant.getQuoteNumber(), true);
			return aceHRCPaymentBasePage;
		} else {
			if (!getResumeFromPage().equals(FAILED_RC3)) {
				Log.info(DID_NOT_REACH + "Ace Condo - Payment page. Quote number: " + applicant.getQuoteNumber());
				retrieveQuoteByQuoteNumber(applicant);
				setResumeFromPage(FAILED_RC3);
				aceHRCPaymentBasePage = navigateToMonthlyAutoPayBankPaymentPageAceCondo(applicant);
				if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage()) {
					return aceHRCPaymentBasePage;
				}
			}
			throw new IllegalStateException(DID_NOT_REACH + "aceHRCPaymentBasePage Condo Monthly bank.");
		}
	}

}
