package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
public class OneMomentPage extends AutoBasePage {

    @PWFindBy(xpath = "//p[contains(@class, 'auto-spinner__subheading')]")
    private PWElement pageContent;
    @PWFindBy(xpath = "//app-one-moment//h1")
    private PWElement pageTitle;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public OneMomentPage() throws Exception {
    }

    public boolean isOnOneMomentPage() {
        return isElementVisible(pageTitle, 5);
    }

    public String getOneMomentPageContent() {
	return getTextFromElement(pageContent);
    }

    public String getOneMomentPageTitle() {
        return getTextFromElement(pageTitle);
    }

    public void waitPageTitleAppear() {
        waitElementBeVisible(pageTitle);
    }

}
