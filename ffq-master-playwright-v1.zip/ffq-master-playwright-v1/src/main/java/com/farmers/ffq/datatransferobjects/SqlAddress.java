/**
=============================================
* Author:	Zhabiz Sonee
* Create date:	05/01/2017
=============================================
*/
package com.farmers.ffq.datatransferobjects;
import lombok.Data;

@Data
public class SqlAddress {

	private String testCategory;
	private String testScenario;
	private String firstName;
	private String lastName;
	private String dateOfBirth;
	private String gender;
	private String maritalStatus;
	private String occupation;
	private String propertyType;
	private String address1;
	private String address2;
	private String city;
	private String stateCode;
	private String stateName;
	private String zipCode;
	private String standardizedAddress1;
	private String standardizedAddress2;
	private String standardizedCity;	
	private boolean mailingAddressDifferent;	
	private String mailingAddress1;
	private String mailingAddress2;
	private String mailingCity;
	private String mailingStateName;
	private String mailingZipCode;
	private String standardizedMailingAddress1;
	private String standardizedMailingAddress2;
	private String standardizedMailingCity;
		
	/**
	 * String Representation of AddressStandardization class.
	 */
	public String toString() {
		return String.format("%s - %s %s: %s %s to %s %s, %s to %s", testScenario, stateCode, zipCode, address1, address2, standardizedAddress1, standardizedAddress2, city, standardizedCity);
	}
}
