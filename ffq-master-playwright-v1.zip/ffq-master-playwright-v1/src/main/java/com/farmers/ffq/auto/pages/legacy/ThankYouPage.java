package com.farmers.ffq.auto.pages.legacy;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.framework.report.Log;
import org.testng.Assert;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Farmers Fast Quote (FFQ) - Thank You Page - Home Quote Modernization (HQM).
 */

public class ThankYouPage extends AutoBasePage {
	
	@PWFindBy(xpath = "//div[@id='thank-you-page-container']//div/h2[contains(text(),'QUOTE NUMBER')]/../p")
	private PWElement textQuoteNumber;
	
	@PWFindBy(xpath = "//div[@id='thank-you-page-container']//div/h2[contains(text(), 'ESTIMATED')]/../span")
	private PWElement textEstimatedPremium;

    @PWFindBy(xpath = "//farmers-home-quote-thank-you//h1")
    private PWElement pageTitle;

    @PWFindBy(xpath = "//div[@id='thank-you-footer']//mat-select")
    private PWElement selectCrossSellType;

    private static final String START_SAVING_BUTTON_XPATH = "//div[@id='thank-you-footer']//button[@data-gtm='FFQ_Auto_ThankYou_startsaving_button']";
    @PWFindBy(xpath = START_SAVING_BUTTON_XPATH)
    private PWElement buttonStartSaving;

    private final PWBy selectListOptions = PWBy.xpath("//div[contains(@class,'mat-select-panel-wrap')]//mat-option");

    private static final String SELECT_OPTIONS_XPATH = "//div[contains(@class,'mat-select-panel')]//mat-option[.='%s']";

	@PWFindBy(xpath = "//a[@data-gtm='FFQ_Auto_Signal_Discount_Learn_More_Link']")
	private PWElement learnMoreLink;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public ThankYouPage() throws Exception {
        super();
		if (isLegacyQuoteKnockout()) {
			Assert.fail("Quote knocked out");
		} else {
			waitElementBeVisible(textQuoteNumber);
		}
    }
    
    public String getQuoteNumberTY() {
    	return getTextFromElement(waitElementBeVisible(textQuoteNumber));
    }
    
    public String getEstimatedPremium() {
    	return getTextFromElement(waitElementBeVisible(textEstimatedPremium));
    }

    public String getSelectedCrossSellType() {
        return getTextFromElement(waitElementBeVisible(selectCrossSellType));
    }

    public List<String> getAvailableCrossSellTypes() throws Exception {
        waitAndClickElement(selectCrossSellType);
        List<String> listAvailableCrossSellTypes = driver().findElements(selectListOptions).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        listAvailableCrossSellTypes.remove("Select");
        selectCrossSellType.sendKeys(PWKeys.ESCAPE);
        Log.info(">> Available Cross Sell Types: " + listAvailableCrossSellTypes);
        return listAvailableCrossSellTypes;
    }

    public void selectCrossSellType(String crossSellType) throws Exception {
        waitAndClickElement(selectCrossSellType);
        PWElement optionWe = driver().findElement(PWBy.xpath(String.format(SELECT_OPTIONS_XPATH, crossSellType)));
        waitAndClickElement(optionWe);
    }

    public void clickStartSaving() {
        waitAndClickElement(buttonStartSaving);
    }

	public final boolean onThankYouPage() {
		return isElementPresentByXPath(START_SAVING_BUTTON_XPATH);
	}

	public void testSignalLink() throws Exception {
		LinkedHashMap<String, String> urlsAndTitles = new LinkedHashMap<>();
		urlsAndTitles.put("www.farmers.com/signal", "Farmers\u00ae Signal\u00ae with CrashAssist | Farmers Insurance\u00ae");
		verifyListOfLinks(Arrays.asList(learnMoreLink), urlsAndTitles);
	}
}
