package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
public class ThankYouPageAce extends AutoBasePage {

    @PWFindBy(xpath = "//div[@class='thank-you__title']//h1")
    private PWElement pageTitle;

    @PWFindBy(xpath = "//div[@class='tui-body thank-you__subtitle']//p")
    private PWElement pageSubTitle;

    @PWFindBy(xpath = "//div[@class='thank-you__quote-number ng-star-inserted']//span[2]")
    private PWElement thankYouPageQuoteNumber;

    @PWFindBy (xpath = "//img[@alt='Bristol West logo']")
    private PWElement bristolWestIcon;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public ThankYouPageAce() throws Exception {
    }

    public boolean isOnThankYouPage() {
        return isElementVisible(pageTitle, 15);
    }

    public boolean quickIsOnThankYouPage() {
        return isElementVisible(pageTitle, 3);
    }

    public boolean showsBristolWestIcon() {
        return isElementVisible(bristolWestIcon, 3);
    }

    public String getThankYouPageQuoteNumber() {
        scrollToElement(thankYouPageQuoteNumber);
        return getTextFromElement(thankYouPageQuoteNumber);
    }

    public String getThankYouPageTitle() {
    	return getTextFromElement(pageTitle);
    }

    public String getThankYouPageSubtitle() {
    	return getTextFromElement(pageSubTitle);
    }
}
