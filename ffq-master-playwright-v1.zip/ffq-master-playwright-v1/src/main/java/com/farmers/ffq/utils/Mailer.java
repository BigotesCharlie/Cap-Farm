package com.farmers.ffq.utils;

import javax.mail.*;

import com.farmers.ffq.common.pages.BasePage;

import java.util.*;

public class Mailer extends BasePage{

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public Mailer() throws Exception {
    }

    private static final String MAIL_POP_HOST = "pop.gmail.com";
    private static final String MAIL_STORE_TYPE = "pop3s";
    private static final String POP_PORT = "995";
    private static final String POP_USER = "farmerstest2017@gmail.com";
    private static final String POP_PASSWORD = "farmers2017";


    public static String getEmailContent() {
        try {

            Properties properties = new Properties();
            properties.put("mail.pop3.host", MAIL_POP_HOST);
            properties.put("mail.pop3.port", POP_PORT);
            properties.put("mail.pop3.starttls.enable", "true");

            Session emailSession = Session.getDefaultInstance(properties);
            Store store = emailSession.getStore(MAIL_STORE_TYPE);

            store.connect(MAIL_POP_HOST, POP_USER, POP_PASSWORD);

            Folder emailFolder = store.getFolder("INBOX");
            emailFolder.open(Folder.READ_ONLY);

            Message[] messages = emailFolder.getMessages();
            for(int i = messages.length -1; i >= 0; i--){
                Message message = messages[i];
                System.out.println("---------------------------------");
                System.out.println("Email Number " + (messages.length + 1));
                System.out.println("Subject: " + message.getSubject());
                System.out.println("From: " + message.getFrom()[0]);
                System.out.println("Body: " + message.getContent().toString());
                System.out.println("Date " + message.getSentDate());
                System.out.println("Inbox " + message.getFolder());

                if (message.getSubject().equals("Farmers FastQuote Confirmation")) {
                    String s = (String) getContentText(message);
                    return s != null ? s.substring(s.indexOf("H"), s.indexOf("</h1>")) : null;
                }
            }

            emailFolder.close(false);
            store.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static String getContentText(Message message) {
        try {
            Object content = message.getContent();

            StringBuilder result = new StringBuilder();
            if (content instanceof String) {
                result.append(content);
            } else if (content instanceof Multipart) {
                Multipart parts = (Multipart) content;
                for (int i = 0; i < parts.getCount(); i++) {
                    BodyPart part = parts.getBodyPart(i);
                    if (part.getContent() instanceof String) {
                        result.append(part.getContent());
                    }
                }
            }
            return result.toString();

        } catch (Exception e) {
            e.printStackTrace();

        }
        return null;
    }
}
