package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.Data;
import org.apache.commons.lang3.StringEscapeUtils;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

@Data
public class BristolWestRateQuoteInitiated {

    @JacksonXmlProperty(localName = "ACORD")
    private Acord acord;

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JacksonXmlRootElement(localName = "ACORD")
    public static class Acord {
        @JacksonXmlProperty(localName = "SignonRq")
        public SignonRq signonRq;

        @JacksonXmlProperty(localName = "InsuranceSvcRq")
        public InsuranceSvcRq insuranceSvcRq;

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class SignonRq {
            @JacksonXmlProperty(localName = "SignonPswd")
            public SignonPswd signonPswd;

            @JacksonXmlProperty(localName = "ClientDt")
            public String clientDt;

            @JacksonXmlProperty(localName = "CustLangPref")
            public String custLangPref;

            @JacksonXmlProperty(localName = "ClientApp")
            public ClientApp clientApp;

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class SignonPswd {
                @JacksonXmlProperty(localName = "SignonRoleCd")
                public String signonRoleCd;

                @JacksonXmlProperty(localName = "CustId")
                public CustId custId;

                @JacksonXmlProperty(localName = "CustPswd")
                public CustPswd custPswd;

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class CustId {
                    @JacksonXmlProperty(localName = "SPName")
                    public String spName;
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class CustPswd {
                    @JacksonXmlProperty(localName = "EncryptionTypeCd")
                    public String encryptionTypeCd;
                }
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class ClientApp {
                @JacksonXmlProperty(localName = "Org")
                public String org;
                @JacksonXmlProperty(localName = "Name")
                public String name;
                @JacksonXmlProperty(localName = "Version")
                public String version;
            }
        }

        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class InsuranceSvcRq {
            @JacksonXmlProperty(localName = "PersAutoPolicyQuoteInqRq")
            public PersAutoPolicyQuoteInqRq persAutoPolicyQuoteInqRq;

            @Data
            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class PersAutoPolicyQuoteInqRq {
                @JacksonXmlProperty(localName = "RqUID")
                public String rqUID;

                @JacksonXmlProperty(localName = "TransactionRequestDt")
                public String transactionRequestDt;

                @JacksonXmlProperty(localName = "CurCd")
                public String curCd;

                @JacksonXmlProperty(localName = "Producer")
                public Producer producer;

                @JacksonXmlProperty(localName = "InsuredOrPrincipal")
                public InsuredOrPrincipal insuredOrPrincipal;

                @JacksonXmlProperty(localName = "PersPolicy")
                public PersPolicy persPolicy;

                @JacksonXmlProperty(localName = "PersAutoLineBusiness")
                public PersAutoLineBusiness persAutoLineBusiness;

                @JacksonXmlProperty(localName = "Location")
                public Location location;

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class Producer {
                    @JacksonXmlProperty(localName = "GeneralPartyInfo")
                    public Common.GeneralPartyInfo generalPartyInfo;

                    @JacksonXmlProperty(localName = "ProducerInfo")
                    public ProducerInfo producerInfo;

                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class ProducerInfo {
                        @JacksonXmlProperty(localName = "ContractNumber")
                        public String contractNumber;
                    }
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class InsuredOrPrincipal {
                    @JacksonXmlProperty(localName = "GeneralPartyInfo")
                    public Common.GeneralPartyInfo generalPartyInfo;

                    @JacksonXmlProperty(localName = "InsuredOrPrincipalInfo")
                    public InsuredOrPrincipalInfo insuredOrPrincipalInfo;

                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class InsuredOrPrincipalInfo {
                        @JacksonXmlProperty(localName = "PersonInfo")
                        public Common.PersonInfo personInfo;
                    }
                }

                @Data
                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class PersPolicy {
                    @JacksonXmlProperty(localName = "LOBCd")
                    public String lobCd;

                    @JacksonXmlProperty(localName = "LOBSubCd")
                    public String lobSubCd;

                    @JacksonXmlProperty(localName = "FinalCall")
                    public String finalCall;

                    @JacksonXmlProperty(localName = "ControllingStateProvCd")
                    public String controllingStateProvCd;

                    @JacksonXmlProperty(localName = "ContractTerm")
                    public ContractTerm contractTerm;

                    @JacksonXmlProperty(localName = "PaymentOption")
                    public PaymentOption paymentOption;

                    @JacksonXmlProperty(localName = "QuoteInfo")
                    public QuoteInfo quoteInfo;

                    @JacksonXmlProperty(localName = "PersApplicationInfo")
                    public PersApplicationInfo persApplicationInfo;

                    @JacksonXmlProperty(localName = "DriverVeh")
                    public DriverVeh driverVeh;

                    @JacksonXmlProperty(localName = "PipHealtCare")
                    public String pipHealtCare; // empty in your sample

                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class ContractTerm {
                        @JacksonXmlProperty(localName = "EffectiveDt")
                        public String effectiveDt;

                        @JacksonXmlProperty(localName = "DurationPeriod")
                        public DurationPeriod durationPeriod;

                        @JsonIgnoreProperties(ignoreUnknown = true)
                        public static class DurationPeriod {
                            @JacksonXmlProperty(localName = "NumUnits")
                            public Integer numUnits;
                            @JacksonXmlProperty(localName = "UnitMeasurementCd")
                            public String unitMeasurementCd;
                        }
                    }

                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class PaymentOption {
                        @JacksonXmlProperty(localName = "Description")
                        public String description;
                        @JacksonXmlProperty(localName = "MethodPaymentCd")
                        public String methodPaymentCd;
                        @JacksonXmlProperty(localName = "Package")
                        public String pkg;
                    }

                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class QuoteInfo {
                        @JacksonXmlProperty(localName = "CompanysQuoteNumber")
                        public String companysQuoteNumber;
                    }

                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class PersApplicationInfo {
                        @JacksonXmlProperty(localName = "ResidenceOwnedRentedCd")
                        public String residenceOwnedRentedCd;
                        @JacksonXmlProperty(localName = "NumVehsInHousehold")
                        public Integer numVehsInHousehold;
                    }

                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class DriverVeh {
                        @JacksonXmlProperty(isAttribute = true, localName = "DriverRef")
                        public String driverRef;

                        @JacksonXmlProperty(isAttribute = true, localName = "VehRef")
                        public String vehRef;
                    }
                }

                @Data
                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class PersAutoLineBusiness {
                    @JacksonXmlElementWrapper(useWrapping = false)
                    @JacksonXmlProperty(localName = "PersDriver")
                    public List<PersDriver> persDrivers;

                    @Data
                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class PersDriver {
                        @JacksonXmlProperty(isAttribute = true, localName = "id")
                        public String id;

                        @JacksonXmlProperty(localName = "GeneralPartyInfo")
                        public Common.GeneralPartyInfo generalPartyInfo;

                        @JacksonXmlProperty(localName = "DriverInfo")
                        public DriverInfo driverInfo;

                        @JacksonXmlProperty(localName = "PersDriverInfo")
                        public PersDriverInfo persDriverInfo;

                        @Data
                        @JsonIgnoreProperties(ignoreUnknown = true)
                        public static class DriverInfo {
                            @JacksonXmlProperty(localName = "PersonInfo")
                            public Common.PersonInfo personInfo;
                            @JacksonXmlProperty(localName = "License")
                            public License license;

                            @JsonIgnoreProperties(ignoreUnknown = true)
                            public static class License {
                                @JacksonXmlProperty(localName = "LicenseTypeCd") public String licenseTypeCd;
                                @JacksonXmlProperty(localName = "LicensedAge") public Integer licensedAge;
                                @JacksonXmlProperty(localName = "LicenseStatusCd") public String licenseStatusCd;
                                @JacksonXmlProperty(localName = "LicenseClassCd") public String licenseClassCd;
                            }
                        }

                        @Data
                        @JsonIgnoreProperties(ignoreUnknown = true)
                        public static class PersDriverInfo {
                            @JacksonXmlProperty(localName = "DriverRelationshipToApplicantCd")
                            public String driverRelationshipToApplicantCd;
                            @JacksonXmlProperty(localName = "SpouseLicense")
                            public String spouseLicense;
                            @JacksonXmlProperty(localName = "DriverTypeCd")
                            public String driverTypeCd;
                        }
                    }
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class Location {
                    @JacksonXmlProperty(isAttribute = true, localName = "id")
                    public String id;

                    @JacksonXmlProperty(localName = "Addr")
                    public Common.Addr addr;
                }
            }
        }

        // ===== Common reusable nodes =====
        public static class Common {
            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class GeneralPartyInfo {
                @JacksonXmlProperty(localName = "NameInfo")
                public NameInfo nameInfo;

                @JacksonXmlProperty(localName = "Addr")
                public Addr addr;

                @JacksonXmlProperty(localName = "Communications")
                public Communications communications;
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class NameInfo {
                @JacksonXmlProperty(localName = "PersonName")
                public PersonName personName;

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class PersonName {
                    @JacksonXmlProperty(localName = "Surname")
                    public String surname;
                    @JacksonXmlProperty(localName = "GivenName")
                    public String givenName;
                }
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class Addr {
                @JacksonXmlProperty(localName = "AddrTypeCd") public String addrTypeCd;
                @JacksonXmlProperty(localName = "Addr1") public String addr1;
                @JacksonXmlProperty(localName = "City") public String city;
                @JacksonXmlProperty(localName = "StateProvCd") public String stateProvCd;
                @JacksonXmlProperty(localName = "PostalCode") public String postalCode;
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class Communications {
                @JacksonXmlProperty(localName = "PhoneInfo")
                public PhoneInfo phoneInfo;
                @JacksonXmlProperty(localName = "EmailInfo")
                public EmailInfo emailInfo;

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class PhoneInfo {
                    @JacksonXmlProperty(localName = "PhoneTypeCd") public String phoneTypeCd;
                    @JacksonXmlProperty(localName = "CommunicationUseCd") public String communicationUseCd;
                    @JacksonXmlProperty(localName = "PhoneNumber") public String phoneNumber;
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class EmailInfo {
                    @JacksonXmlProperty(localName = "EmailAddr") public String emailAddr;
                }
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class PersonInfo {
                @JacksonXmlProperty(localName = "GenderCd") public String genderCd;
                @JacksonXmlProperty(localName = "BirthDt") public String birthDt;
                @JacksonXmlProperty(localName = "MaritalStatusCd") public String maritalStatusCd;
            }
        }
    }
}

