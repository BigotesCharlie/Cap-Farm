package com.farmers.ffq.dataproviders;

import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.SqlDiscount;
import com.farmers.framework.Property;
import com.farmers.framework.data.ExcelDataProvider;
import com.farmers.framework.report.Log;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.datafaker.Faker;
import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONArray;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeDataProviders extends DataProviders {
	public static final String APPLICANT_ACE_HOME_DATA_PROVIDER = "ApplicantAceHomeDataProvider";
	public static final String APPLICANT_ACE_HOME_CATEGORY_PROVIDER = "ApplicantAceHomeCategoryDataProvider";
	public static final String ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME = "ApplicantAceHomeWithUnmodifiedNameCategoryDataProvider";
	public static final String ENVIRONMENT_STABILITY_DATA_PROVIDER = "ENVIRONMENT_STABILITY_DATA_PROVIDER";
	protected static final String ACE_HOME_PAGE_VALIDATION = "PageValidationApplicantAceHome";
	public static final String CATEGORY_RECONSTRUCTION_COST_KO = "Reconstruction cost KO";
	public static final String CATEGORY_FIRELINE_KO = "Fireline Score more than allowed";
	public static final String CATEGORY_UNFENCED_POOL_TRAMPOLINE = "Unfenced pool trampoline";
	public static final String CATEGORY_JFMTP_KO = "JFMTP KO Validation";
	public static final String CATEGORY_FORTIFIED_HOME_SECTION = "Fortified Home Section Validation";
	public static final String CATEGORY_BIND_VALIDATION = "Bind validation";
	public static final String CATEGORY_THANK_YOU_SCREEN_VALIDATION = "Thank You Screen Validation";
	public static final String CATEGORY_FOUNDATIONTYPE_KO = "Foundation Type KO";
	public static final String CATEGORY_PPC_ZIP_MISMATCH_KO = "PPC Zip Mismatch KO";
	public static final String CATEGORY_PPC_FIRE_HYDRANT_KO = "PPC Fire Hydrant KO";
	public static final String CATEGORY_DIGITAL_MONETIZATION_AWS = "Digital Monetization AWS";
	public static final String CATEGORY_DIGITAL_MONETIZATION_NON_AWS = "Digital Monetization Non AWS";
	public static final String CATEGORY_POLICY_EXCLUSION = "Policy Exclusion";
	public static final String CATEGORY_RECONSTRUCTION_COST_1_TO_1N_HALF = "Reconstruction cost 1-1.5M";
	public static final String CATEGORY_UNACCEPTABLE_ROOF_KO = "Unacceptable Roof KO";
	public static final String CATEGORY_FWS_INTERSTITIAL_BINDABLE_CHOICE = "FWS Interstitial Bindable Choice";
	public static final String CATEGORY_FWS_INTERSTITIAL_COLP = "FWS Interstitial COLP";
	public static final String CATEGORY_FWS_INTERSTITIAL_QNB = "FWS Interstitial QnB";
	public static final String CATEGORY_PRE_BIND_CONTINGENCY_KO = "Pre-Bind Contingency KO";
	public static final String CATEGORY_PAYROLL_DEDUCTION = "Payroll Deduction";

	@DataProvider(name = APPLICANT_ACE_HOME_CATEGORY_PROVIDER, parallel = true)
	public static synchronized Iterator<ApplicantAceHome> additionalInfoPageApplicant(Method m) throws Exception {
		List<ApplicantAceHome> filteredListOfHomeApplicants;
		String testCategory = m.getAnnotation(Test.class).suiteName();
		if (m.getAnnotation(Test.class).testName().equals(ONE_APPLICANT_PER_STATE)) {
			filteredListOfHomeApplicants = randomOnePerStateAceHomeApplicant(listOfAceHomeApplicants(ACE_HOME_PAGE_VALIDATION, "testCategory=" + testCategory, m));
		} else {
			filteredListOfHomeApplicants = randomlySelectedAceHomeApplicant(listOfAceHomeApplicants(ACE_HOME_PAGE_VALIDATION, "testCategory=" + testCategory, m));
		}
		Log.info(String.format(DP_LOG_ENTRY, APPLICANT_ACE_HOME_CATEGORY_PROVIDER + SPACE + COLON + testCategory, filteredListOfHomeApplicants.size()));
		return filteredListOfHomeApplicants.iterator();
	}

    @DataProvider(name = ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, parallel = true)
    public static synchronized Iterator<ApplicantAceHome> randomApplicantAsFoundInDatafile(Method m) throws Exception {
        List<ApplicantAceHome> filteredListOfHomeApplicants;
        String testCategory = m.getAnnotation(Test.class).suiteName();
        filteredListOfHomeApplicants = randomlySelectedAceHomeApplicantWithUnmodifiedName(listOfAceHomeApplicants(ACE_HOME_PAGE_VALIDATION, "testCategory=" + testCategory, m));
        Log.info(String.format(DP_LOG_ENTRY, ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME + SPACE + COLON + testCategory, filteredListOfHomeApplicants.size()));
        return filteredListOfHomeApplicants.iterator();
    }

	@DataProvider(name = ENVIRONMENT_STABILITY_DATA_PROVIDER, parallel = true)
	public static synchronized Iterator<ApplicantAceHome> environmentStabilityTestApplicants(Method m) throws Exception {
		String testCategory = m.getAnnotation(Test.class).suiteName();
		List<ApplicantAceHome> filteredListOfHomeApplicants = listOfAceHomeApplicants(ACE_HOME_PAGE_VALIDATION, "testCategory=" + testCategory, m);
		List<ApplicantAceHome> listOfRandomEntries = new ArrayList<>();
		List<String> listOfValidStateCodes = updateListOfStatesWithTestAttributeAndStateListProperty(m, getListOfAceHCRStates(Property.getUri()));
		Log.warn(filteredListOfHomeApplicants.toString());
		for (String stateCode : listOfValidStateCodes) {
			if (filteredListOfHomeApplicants.stream().anyMatch(applicant -> (applicant.getStateCode().equals(stateCode)))) {
				List<ApplicantAceHome> tempEntries = filteredListOfHomeApplicants.stream().filter(appl -> appl.getStateCode().equals(stateCode)).collect(Collectors.toList());
				ApplicantAceHome applicant = tempEntries.get(randomNumberGenerator.nextInt(tempEntries.size()));
				Faker faker = new Faker();
				applicant.setFirstName(faker.name().firstName() + RandomStringUtils.randomAlphabetic(3));
				applicant.setLastName(faker.name().lastName() + RandomStringUtils.randomAlphabetic(3));
				listOfRandomEntries.add(applicant);
			}
		}
		filteredListOfHomeApplicants = listOfRandomEntries;
		Log.info(String.format(DP_LOG_ENTRY, ENVIRONMENT_STABILITY_DATA_PROVIDER + SPACE + COLON + testCategory, filteredListOfHomeApplicants.size()));
		return filteredListOfHomeApplicants.iterator();
	}

	@DataProvider(name = APPLICANT_ACE_HOME_DATA_PROVIDER, parallel = true)
	public Iterator<ApplicantAceHome> applicantAceHome(Method m) throws Exception {
		ExcelDataProvider excel = new ExcelDataProvider();
		JSONArray json = excel.getDataJson(ACE_HOME_FILE_NAME, HOME_APPLICANT_PAGE);
		List<ApplicantAceHome> entries = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		for (int i = 0; i < json.length(); i++) {
			String js = json.getJSONObject(i).toString();
			js = js.replaceAll(TRUE, LOWERCASE_TRUE);
			js = js.replaceAll(FALSE, LOWERCASE_FALSE);
			js = js.replace(LOWERCASE_NULL, EMPTY_STRING);
			Log.debug(String.format("Ace HRC DataProvider %s%n%s%n", i, js));
			entries.add(mapper.readValue(js, ApplicantAceHome.class));
		}
		List<String> listOfValidStateCodes = updateListOfStatesWithTestAttributeAndStateListProperty(m, getListOfAceHCRStates(Property.getUri()));
		entries.removeIf(aceApplicant -> !listOfValidStateCodes.contains(aceApplicant.getStateCode()));

		if (!m.getAnnotation(Test.class).testName().isEmpty() && !entries.isEmpty()) {
			int row;
			if (m.getAnnotation(Test.class).testName().equals(RANDOM_ROW)) {
				// return a random data row
				row = randomNumberGenerator.nextInt(entries.size());
				Log.info("Randomly selected data provider row id=" + (row + 1));
				ApplicantAceHome applicant = entries.get(row);
				Log.debug(applicant.toString());
				entries.clear();
				entries.add(applicant);
			} else if (m.getAnnotation(Test.class).testName().startsWith("row=")) {
				// return only data from the given rows
				String rowsString = m.getAnnotation(Test.class).testName().substring(4);
				List<String> rows = new ArrayList<>(Arrays.asList(rowsString.split(COMMA)));
				Log.info(SELECTED_DATA_PROVIDER_ROWS + rowsString);
				entries = entries.stream().filter(rowId -> rows.contains(rowId.getId())).collect(Collectors.toList());
			} else if (m.getAnnotation(Test.class).testName().equals("allFromState")) {
				List<ApplicantAceHome> listOfApplicants = new ArrayList<>();
				for (String stateCode : listOfValidStateCodes) {
					if (entries.stream().anyMatch(applicant -> (applicant.getStateCode().equals(stateCode)))) {
						List<ApplicantAceHome> tempEntries = entries.stream().filter(appl -> appl.getStateCode().equals(stateCode)).collect(Collectors.toList());
						listOfApplicants.addAll(tempEntries);
					}
				}
				entries = listOfApplicants;
			} else if (m.getAnnotation(Test.class).testName().equals(ONE_APPLICANT_PER_STATE)) {
				List<ApplicantAceHome> listOfRandomEntries = new ArrayList<>();
				for (String stateCode : listOfValidStateCodes) {
					if (entries.stream().anyMatch(applicant -> (applicant.getStateCode().equals(stateCode)))) {
						List<ApplicantAceHome> tempEntries = entries.stream().filter(appl -> appl.getStateCode().equals(stateCode)).collect(Collectors.toList());
						listOfRandomEntries.add(tempEntries.get(randomNumberGenerator.nextInt(tempEntries.size())));
					}
				}
				entries = listOfRandomEntries;
			}
		}

		Iterator<ApplicantAceHome> applicantListIterator = entries.iterator();
		List<SqlDiscount> listOfDiscounts = getAllDiscounts();
		while (applicantListIterator.hasNext()) {
			ApplicantAceHome applicant = applicantListIterator.next();
			Iterator<SqlDiscount> discountsIterator = listOfDiscounts.iterator();
			List<SqlDiscount> applicantDiscounts = new ArrayList<>();
			while (discountsIterator.hasNext()) {
				SqlDiscount discount = discountsIterator.next();
				if (discount.getApplicantId() == Integer.parseInt(applicant.getId())) {
					applicantDiscounts.add(discount);
				}
			}
			applicant.setDiscounts(applicantDiscounts);
		}
		//randomize first/last names
		Faker faker = new Faker();
		entries = entries.stream().peek(applicant -> {
			applicant.setFirstName(faker.name().firstName());
			applicant.setLastName(faker.name().lastName());
			if (applicant.getMaritalStatus().equals(MARRIED)) {
				applicant.setSpouseFirstName(faker.name().firstName());
				applicant.setSpouseLastName(faker.name().lastName());
			}
		}).collect(Collectors.toList());
		Log.info(String.format(DP_LOG_ENTRY, APPLICANT_ACE_HOME_DATA_PROVIDER, entries.size()));
		return entries.iterator();
	}

	private static synchronized List<ApplicantAceHome> listOfAceHomeApplicants(String xlDataSheetName, String filter, Method m) throws Exception {
		ExcelDataProvider excel = new ExcelDataProvider();
		JSONArray json = filter.equals(NO_FILTER) ? excel.getDataJson(ACE_HOME_FILE_NAME, xlDataSheetName, true) :
			excel.filterJsonData(filter, excel.getDataJson(ACE_HOME_FILE_NAME, xlDataSheetName, true));
		List<ApplicantAceHome> entries = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		for (int i = 0; i < json.length(); i++) {
			String js = json.getJSONObject(i).toString();
			js = js.replace(TRUE, LOWERCASE_TRUE);
			js = js.replace(FALSE, LOWERCASE_FALSE);
			js = js.replace(LOWERCASE_NULL, EMPTY_STRING);
			Log.debug(String.format(HOMEDP_JSON, i, js));
			entries.add(mapper.readValue(js, ApplicantAceHome.class));
		}
		List<String> listOfValidStateCodes = updateListOfStatesWithTestAttributeAndStateListProperty(m, getListOfAceHCRStates(Property.getUri()));
		entries.removeIf(aceApplicant -> !listOfValidStateCodes.contains(aceApplicant.getStateCode()));
		Iterator<ApplicantAceHome> applicantListIterator = entries.iterator();
		List<SqlDiscount> listOfDiscounts = getAllDiscounts();
		while (applicantListIterator.hasNext()) {
			ApplicantAceHome applicant = applicantListIterator.next();
			Iterator<SqlDiscount> discountsIterator = listOfDiscounts.iterator();
			List<SqlDiscount> applicantDiscounts = new ArrayList<>();
			while(discountsIterator.hasNext()) {
				SqlDiscount discount = discountsIterator.next();
				if (discount.getApplicantId() == Integer.parseInt(applicant.getId())) {
					applicantDiscounts.add(discount);
				}
			}
			if (applicantDiscounts.isEmpty()) {
				Log.warn("Did not find any discount rows for applicant id: " + applicant.getId());
			}
			applicant.setDiscounts(applicantDiscounts);
		}

		Log.info(String.format(DP_LOG_ENTRY, APPLICANT_ACE_HOME_DATA_PROVIDER, entries.size()));
		return entries;

	}

	public static List<ApplicantAceHome> randomlySelectedAceHomeApplicant(List<ApplicantAceHome> listOfAceHomeApplicant){
		Collections.shuffle(listOfAceHomeApplicant);
		ApplicantAceHome applicant = listOfAceHomeApplicant.get(FIRST_AVAILABLE_OPTION);
		Faker faker = new Faker();
		applicant.setFirstName(faker.name().firstName() + RandomStringUtils.randomAlphabetic(3));
		applicant.setLastName(faker.name().lastName() + RandomStringUtils.randomAlphabetic(3));
		List<ApplicantAceHome> randomlySelectedApplicant = new ArrayList<>();
		randomlySelectedApplicant.add(applicant);
		return randomlySelectedApplicant;
	}

    public static List<ApplicantAceHome> randomlySelectedAceHomeApplicantWithUnmodifiedName(List<ApplicantAceHome> listOfAceHomeApplicant){
        if (listOfAceHomeApplicant == null || listOfAceHomeApplicant.isEmpty()) {
            throw new SkipException("No test data available for the requested test suite/state filter combination");
        }
        Collections.shuffle(listOfAceHomeApplicant);
        ApplicantAceHome applicant = listOfAceHomeApplicant.get(FIRST_AVAILABLE_OPTION);
        List<ApplicantAceHome> randomlySelectedApplicant = new ArrayList<>();
        randomlySelectedApplicant.add(applicant);
        return randomlySelectedApplicant;
    }

	public static List<ApplicantAceHome> randomOnePerStateAceHomeApplicant(List<ApplicantAceHome> listOfAceHomeApplicant){
		if (listOfAceHomeApplicant == null || listOfAceHomeApplicant.isEmpty()) {
			throw new SkipException("No test data available for the requested test suite/state filter combination");
		}

		Collections.shuffle(listOfAceHomeApplicant);
		Map<String, List<ApplicantAceHome>> applicantsByState = listOfAceHomeApplicant.stream()
			.collect(Collectors.groupingBy(ApplicantAceHome::getStateCode));

		Faker faker = new Faker();
		List<ApplicantAceHome> randomlySelectedApplicants = new ArrayList<>();
		for (List<ApplicantAceHome> stateApplicants : applicantsByState.values()) {
			ApplicantAceHome applicant = stateApplicants.get(randomNumberGenerator.nextInt(stateApplicants.size()));
			applicant.setFirstName(faker.name().firstName() + RandomStringUtils.randomAlphabetic(3));
			applicant.setLastName(faker.name().lastName() + RandomStringUtils.randomAlphabetic(3));
			randomlySelectedApplicants.add(applicant);
		}

		return randomlySelectedApplicants;
	}
}
