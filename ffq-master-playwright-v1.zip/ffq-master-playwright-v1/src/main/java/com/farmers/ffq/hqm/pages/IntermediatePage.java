package com.farmers.ffq.hqm.pages;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
public class IntermediatePage extends HqmBasePage {

    @PWFindBy(xpath = "//*[@id='quote_unavailable-content']//h2")
    private PWElement pageTitle;

    @PWFindBy(xpath = "//button[contains(text(),'Start my quote')]")
    private PWElement buttonStartMyQuote;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public IntermediatePage() throws Exception {
        super();
        wait.until(PWExpectedConditions.urlContains("/fastquote/intermediatepage"));
    }

    public boolean isUnableToProvideQuoteTextExists() throws Exception {
        return driver().getPageSource().contains("We're sorry, but we are unable to provide an online quote at this time.");
    }

    public boolean isButtonStartMyQuoteExists() throws Exception {
        driverWait(10).until(PWExpectedConditions.elementToBeClickable(buttonStartMyQuote));
		return buttonStartMyQuote.isDisplayed();
    }
}
