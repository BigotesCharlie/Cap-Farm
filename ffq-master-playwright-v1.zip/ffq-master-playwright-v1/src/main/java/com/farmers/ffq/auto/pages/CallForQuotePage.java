package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.utils.FarmersSoftAssert;

public class CallForQuotePage extends AutoBasePage {

    /**
     * Constructor.
     */
    public CallForQuotePage() throws Exception {
    }

    @PWFindBy(xpath = "*//span[contains(text(),'Thanks for starting')]")
    private PWElement pageHeader;

    @PWFindBy(xpath = "//div/p[contains(text(),'Speaking with one')]")
    private PWElement subHeaderText;

    @PWFindBy(xpath = "//p[@class='landing-text']//a")
    private PWElement phoneNumber;

    @PWFindBy(xpath = "*//img[@class='lozad FarmersTestImage']")
    private PWElement imageContainer;

    @PWFindBy(xpath = "//div[contains(@class,'container-flex farmerscolorsection  with-bgcolor ')]//span[@class='small-text']")
    private PWElement disclaimerContent;

    private static final String PAGE_HEADER = "Thanks for starting your quote online with Farmers GroupSelectSM";
    private static final String SUB_HEADER_TEXT = "Speaking with one of our knowledgeable representatives is the best way to ensure you're getting all the auto and home insurance savings and discounts you're eligible for. Just call";
    private static final String DISCLAIMER_CONTENT = "*Savings based on the average nationwide annual savings in 2022 reported by new customers who called the Farmers GroupSelect employee and affinity member call center, switched their auto insurance to Farmers\u00ae branded auto insurance policies issued the Farmers GroupSelect employee or affinity member program, and realized savings. Potential savings vary by customer and may vary by state and product. Statistics do not reflect sales of products sold on Agent360SM.";

    public void validateCallForQuotePage(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageHeader)), PAGE_HEADER, "Call for Quote page header validation ");
        fsa.assertTrue(getTextFromElement(subHeaderText).contains(SUB_HEADER_TEXT), " Call for Quote page SubHeader text validation ");
        fsa.assertTrue(isElementDisplayed(phoneNumber, 10), "PhoneNumber validation ");
        fsa.assertTrue(isElementDisplayed(imageContainer, 10), "Call for Quote Page Content Image is displayed");
        String callNowButtonXpath = isUseMobileViewEnabled() ? "//a[contains(@class,' button-cta button-cta--mobile mobile button-cta')]" : "//a[contains(@class,' button-cta button-cta--desktop desktop button-cta')]";
        PWElement callNowButton = driver().findElement(PWBy.xpath(callNowButtonXpath));
        fsa.assertTrue(isElementDisplayed(callNowButton, 10), "CALL NOW button validation ");
        fsa.assertEquals(getTextFromElement(disclaimerContent), DISCLAIMER_CONTENT, this.getClass().getSimpleName() + " Disclaimer Content validation");
    }
}



