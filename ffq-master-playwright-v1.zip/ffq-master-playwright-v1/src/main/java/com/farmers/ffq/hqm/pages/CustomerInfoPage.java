package com.farmers.ffq.hqm.pages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.StaticContentHQM;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.apache.commons.lang.RandomStringUtils;
import org.testng.Assert;

import javax.annotation.Nullable;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Home Quote Modernization (HQM) - Personal Info Page 1.
 */

public class CustomerInfoPage extends HqmBasePage {

	private static final String LOWERCASE_MARRIED = "married";
	private static final String CUSTOMER_INFO_PAGE_TITLE = "WE'D LIKE TO\nMEET YOU";
	private static final String CUSTOMER_INFO_PAGE_SUBTITLE = "Telling us about your job is optional \u2014 we only ask because " +
			"it may help you qualify for a discount.";
	@PWFindBy(xpath = "//ui-farmers-input[@fieldlabel='First name']//input")
	private PWElement inputFirstName;

	@PWFindBy(xpath = "//ui-farmers-input[@fieldlabel='First name']//mat-label")
	private PWElement labelFirstName;

	@PWFindBy(xpath = "//ui-farmers-input[@fieldlabel='Last name']//input")
	private PWElement inputLastName;

	@PWFindBy(xpath = "//ui-farmers-input[@fieldlabel='Last name']//mat-label")
	private PWElement labelLastName;

	@PWFindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Date of birth']//input[@matinput]")
	private PWElement inputDob;

	@PWFindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Date of birth']//mat-label")
	private PWElement labelDob;

	@PWFindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='gender']/mat-radio-button[@value='M']")
	private PWElement radioBtnMale;

	@PWFindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='gender']/mat-radio-button[@value='M']//input")
	private PWElement radioBtnMaleInternal;

	@PWFindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='gender']/mat-radio-button[@value='F']")
	private PWElement radioBtnFemale;

	@PWFindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='gender']/mat-radio-button[@value='F']//input")
	private PWElement radioBtnFemaleInternal;

	private static final String SELECT_OCCUPATION_XPATH = "//ui-farmers-auto-complete[@fieldlabel='Occupation (optional)']//input";
	@PWFindBy(xpath = SELECT_OCCUPATION_XPATH)
	private PWElement selectOccupation;

	private static final String OCCUPATION_OPTION_XPATH = "//div[contains(@class,'mat-autocomplete-panel')]//mat-option[.='%s']";
	@PWFindBy(xpath = "//ui-farmers-checkbox[@id='maritualStatus-input']//mat-checkbox//input")
	private PWElement checkMarried;

	@PWFindBy(xpath = "//input[@id='maritualStatus-input-input']")
	private PWElement checkMarriedInternal;

	@PWFindBy(xpath = "//ui-farmers-input[@fieldlabel='Spouse first name']//input")
	private PWElement inputSpouseFirstName;

	@PWFindBy(xpath = "//ui-farmers-input[@fieldlabel='Spouse first name']//mat-label")
	private PWElement labelSpouseFirstName;

	@PWFindBy(xpath = "//ui-farmers-input[@fieldlabel='Spouse last name']//input")
	private PWElement inputSpouseLastName;

	@PWFindBy(xpath = "//ui-farmers-input[@fieldlabel='Spouse last name']//mat-label")
	private PWElement labelSpouseLastName;

	@PWFindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Spouse date of birth']//input[@matinput]")
	private PWElement inputSpouseDob;

	@PWFindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Spouse date of birth']//mat-label")
	private PWElement labelSpouseDob;

	@PWFindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='spouseGender']/mat-radio-button[@value='M']")
	private PWElement radioBtnSpouseMale;

	@PWFindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='spouseGender']/mat-radio-button[@value='M']//input")
	private PWElement radioBtnSpouseMaleInternal;

	@PWFindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='spouseGender']/mat-radio-button[@value='F']")
	private PWElement radioBtnSpouseFemale;

	@PWFindBy(xpath = "//farmers-home-quote-customer-info//mat-radio-group[@id='spouseGender']/mat-radio-button[@value='F']//input")
	private PWElement radioBtnSpouseFemaleInternal;

	@PWFindBy(xpath = "//farmers-home-quote-customer-info//h1[@aria-label=\"WE'D LIKE TO MEET YOU\"]")
	private PWElement textPageTitle;

	@PWFindBy(xpath = "//farmers-home-quote-customer-info//div[@id='customer-info']//span[contains(@class,'sub-title-one')]")
	private PWElement textPageSubTitle1;

	@PWFindBy(xpath = "//farmers-home-quote-customer-info//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__image')]/../p")
	private PWElement discountSubTitleLock;

	private static final String DISCOUNT_LOCK_TEXT = "We will never sell your information.";

	@PWFindBy(xpath = "//farmers-home-quote-customer-info//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__potential')]/../p")
	private PWElement discountSubTitlePiggy;

	private static final String DISCOUNT_PIGGY_TEXT = "otential savings/discounts. Let's find some more.";

	@PWFindBy(xpath ="//farmers-home-quote-customer-info//div[@class='discount-journey-card']//mat-icon[text()='info']")
	private PWElement discountHelpButtonPiggy;

	@PWFindBy(xpath = "//farmers-home-quote-discount-journey-dialog//h4")
	private PWElement discountHelpDialogTitle;

	private static final String DISCOUNT_HELP_DIALOG_TITLE = "Potential savings/discounts ($)";

	private static final String DISCOUNT_HELP_DIALOG_CONTENT_XPATH = "//farmers-home-quote-discount-journey-dialog//li";
	@PWFindBy(xpath = DISCOUNT_HELP_DIALOG_CONTENT_XPATH)
	private PWElement discountHelpDialogContent;

	@PWFindBy(xpath = "//farmers-home-quote-customer-info//mat-card//div[@class='djm-discount-check']/../p")
	private PWElement discountCheck;

	private static final String DISCOUNT_CHECK_TEXT = "Great! You may be eligible for our Affinity Discount.";

	@PWFindBy(xpath = "//mat-dialog-actions//button[.='CLOSE']")
	private PWElement buttonCloseDialog;

	private static final String SUBTITLE_XPATH = "//farmers-home-quote-customer-info//div[contains(@class,'bottom-text')]/span[@class='tui-subtitle-text-1']";
	@PWFindBy(xpath = SUBTITLE_XPATH)
	private PWElement textPageSubTitle2;

	private static final String FIRST_NAME_ERROR_TEXT = "Please enter your first name";
	private static final String LAST_NAME_ERROR_TEXT = "Please enter your last name";
	private static final String DOB_ERROR_TEXT = "Please enter your date of birth";
	private static final String SPOUSE_FIRST_NAME_ERROR_TEXT = "Please enter spouse first name";
	private static final String SPOUSE_LAST_NAME_ERROR_TEXT = "Please enter spouse last name";
	private static final String SPOUSE_DOB_ERROR_TEXT = "Please enter your spouse date of birth";
	private static final String FIRST_NAME_ERROR_TEXT_TWO = "Please enter valid first name";
	private static final String LAST_NAME_ERROR_TEXT_TWO = "Please enter valid last name";
	private static final String DOB_ERROR_TEXT_TWO = "Online home quotes are only available for applicants between the age of 18 and 99";
	private static final String SPOUSE_FIRST_NAME_ERROR_TEXT_TWO = "Please enter valid spouse first name";
	private static final String SPOUSE_LAST_NAME_ERROR_TEXT_TWO = "Please enter valid spouse last name";
	private static final String SPOUSE_DOB_ERROR_TEXT_TWO = "Entered date of birth is not a valid entry";
	private static final String SPOUSE_DOB_ERROR_TEXT_THREE = "Entered spouse date of birth is not a valid entry";

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public CustomerInfoPage() throws Exception {
		super();
		waitElementBeVisibleClickable(inputFirstName);
	}

	public void setRequiredFields(ApplicantHQM applicant) throws Exception {
		setFirstName(applicant.firstName);
		setLastName(applicant.lastName);
		setDateOfBirth(applicant.dateOfBirth);
		if (!isEasternExpansionState(applicant.stateCode) && !Arrays.asList(MN,TN).contains(applicant.stateCode)) {
			selectOccupation(applicant.occupation);
		}
		if (applicant.maritalStatus.equalsIgnoreCase(LOWERCASE_MARRIED)) {
			checkMarried(true);
			setSpouseFirstName(applicant.spouseFirstName);
			setSpouseLastName(applicant.spouseLastName);
			setSpouseDateOfBirth(applicant.spouseDateOfBirth);
		}
	}

	public String setRequiredFieldsRandom(ApplicantHQM applicant) throws Exception {
		String firstNameRand = applicant.firstName + "-" + RandomStringUtils.randomAlphabetic(3);
		String lastNameRand = applicant.lastName + "-" + RandomStringUtils.randomAlphabetic(3);
		Log.info("Randomized First and Last Name: " + firstNameRand + " " + lastNameRand);
		setFirstName(firstNameRand);
		setLastName(lastNameRand);
		setDateOfBirth(applicant.dateOfBirth);
		if (!isEasternExpansionState(applicant.stateCode) && !Arrays.asList(MN,TN).contains(applicant.stateCode)) {
			selectOccupation(applicant.occupation);
		}
		String spouseFirstNameRand = applicant.spouseFirstName + "-" + RandomStringUtils.randomAlphabetic(3);
		String spouseLastNameRand = applicant.spouseLastName + "-" + RandomStringUtils.randomAlphabetic(3);
		Log.info("Randomized Spouse First and Spouse Last Name: " + spouseFirstNameRand + " " + spouseLastNameRand);
		if (applicant.maritalStatus.equalsIgnoreCase(MARRIED)) {
			checkMarried(true);
			setSpouseFirstName(spouseFirstNameRand);
			setSpouseLastName(spouseLastNameRand);
			setSpouseDateOfBirth(applicant.spouseDateOfBirth);
			return firstNameRand + ":" + lastNameRand + ":" + spouseFirstNameRand + ":" + spouseLastNameRand;
		} else {
			return firstNameRand + ":" + lastNameRand;
		}
	}

	public void setRequiredFieldsQuicken(ApplicantHQM applicant, @Nullable String blankField) throws Exception {
		if (blankField != null && blankField.equalsIgnoreCase("lastName")) {
			Assert.assertEquals(getLastName(), "", "CustomerInfo Page - Expected No Customer Last name.");
			setLastName(applicant.lastName);
		}
		if (!isEasternExpansionState(applicant.stateCode) && !Arrays.asList(MN,TN).contains(applicant.stateCode)) {
			selectOccupation(applicant.occupation);
		}
		if (applicant.maritalStatus.equalsIgnoreCase(LOWERCASE_MARRIED)) {
			setSpouseFirstName(applicant.spouseFirstName);
			setSpouseLastName(applicant.spouseLastName);
			setSpouseDateOfBirth(applicant.spouseDateOfBirth);
		}
	}

	public void setRequiredFieldsCrossSell(ApplicantHQM applicant) throws Exception {
		if (!isEasternExpansionState(applicant.stateCode) && !Arrays.asList(MN,TN).contains(applicant.stateCode)) {
			selectOccupation(applicant.occupation);
		}
		if (applicant.maritalStatus.equalsIgnoreCase(LOWERCASE_MARRIED)) {
			checkMarried(true);
			setSpouseFirstName(applicant.spouseFirstName);
			setSpouseLastName(applicant.spouseLastName);
			setSpouseDateOfBirth(applicant.spouseDateOfBirth);
		}
	}

	public void setFirstName(String firstName) {
		waitAndClickElement(inputFirstName);
		sendKeysToElement(inputFirstName, firstName);
	}

	public String getFirstName() {
		return getAttributeData(inputFirstName, VALUE);
	}

	public String getFirstNameLabel() {
		return getTextFromElement(labelFirstName);
	}

	public void setLastName(String lastName) {
		waitAndClickElement(inputLastName);
		sendKeysToElement(inputLastName, lastName);
	}

	public String getLastName() {
		return getAttributeData(inputLastName, VALUE);
	}

	public String getLastNameLabel() {
		return getTextFromElement(labelLastName);
	}

	public void setDateOfBirth(String dateOfBirth) {
		waitAndClickElement(inputDob);
		sendKeysToElement(inputDob, dateOfBirth);
	}

	public String getDateOfBirth() {
		return getAttributeData(inputDob, VALUE);
	}

	public String getDateOfBirthLabel() {
		return getTextFromElement(labelDob);
	}

	public boolean isSelectedMale() {
		return radioBtnMaleInternal.isSelected();
	}

	public boolean isSelectedFemale() {
		return radioBtnFemaleInternal.isSelected();
	}

	public void selectGender(String gender) {
		if (gender.equalsIgnoreCase("male")) {
			waitAndClickElement(radioBtnMale);
		} else if (gender.equalsIgnoreCase("female")) {
			waitAndClickElement(radioBtnFemale);
		}
	}

	public void selectOccupation(String occupation) throws Exception {
		if ((occupation == null) || occupation.trim().isEmpty()) {
			return;
		}
		if (occupation.equals("21st Century Employees")) {
			occupation = "21st  Century Employees";
		}
		try {
			waitAndClickElement(selectOccupation);
			PWElement optionWe = driver().findElement(PWBy.xpath(String.format(OCCUPATION_OPTION_XPATH, occupation)));
			scrollAndClickOnElement(optionWe);
		} catch (Exception e) {
			Log.warn("Occupation selection was not successful");
		}
	}

	public String getSelectedOccupation() {
		return getElementValue(selectOccupation, "Selected Occupation: ");
	}

	public List<String> getAvailableOccupations() throws Exception {
		waitAndClickElement(selectOccupation);
		List<String> occupation = driver().findElements(PWBy.xpath(OCCUPATION_OPTION_XPATH.substring(0, OCCUPATION_OPTION_XPATH.length() - 8)))
				.stream().map(we -> getAttributeData(we, "textContent")).map(String::trim).collect(Collectors.toList());
		sendKeysToElement(selectOccupation, PWKeys.ESCAPE);
		return occupation;
	}

	public void checkMarried(boolean check) {
		waitElementBeVisible(checkMarried);
		setCheckboxTo(checkMarried, check);
	}

	public boolean isCheckedMarried() {
		return checkMarriedInternal.isSelected();
	}

	public void setSpouseFirstName(String firstName) {
		waitAndClickElement(inputSpouseFirstName);
		sendKeysToElement(inputSpouseFirstName, firstName);
	}

	public String getSpouseFirstName() {
		return getAttributeData(inputSpouseFirstName, VALUE);
	}

	public String getSpouseFirstNameLabel() {
		return getTextFromElement(labelSpouseFirstName);
	}

	public void setSpouseLastName(String lastName) {
		waitAndClickElement(inputSpouseLastName);
		sendKeysToElement(inputSpouseLastName, lastName);
	}

	public String getSpouseLastName() {
		return getAttributeData(inputSpouseLastName, VALUE);
	}

	public String getSpouseLastNameLabel() {
		return getTextFromElement(labelSpouseLastName);
	}

	public void setSpouseDateOfBirth(String dateOfBirth) {
		waitAndClickElement(inputSpouseDob);
		sendKeysToElement(inputSpouseDob, dateOfBirth);
	}

	public String getSpouseDateOfBirth() {
		return getAttributeData(inputSpouseDob, VALUE);
	}

	public String getSpouseDateOfBirthLabel() {
		return getTextFromElement(labelSpouseDob);
	}

	public boolean isSelectedSpouseMale() {
		return radioBtnSpouseMaleInternal.isSelected();
	}

	public boolean isSelectedSpouseFemale() {
		return radioBtnSpouseFemaleInternal.isSelected();
	}

	public void selectSpouseGender(String gender) {
		if (gender.equalsIgnoreCase("male")) {
			waitAndClickElement(radioBtnSpouseMale);
		} else if (gender.equalsIgnoreCase("female")) {
			waitAndClickElement(radioBtnSpouseFemale);
		}
	}

	public void validatePageFieldContents(ApplicantHQM applicant, boolean bNew, FarmersSoftAssert fsa) throws Exception {
		if (bNew) {
			fsa.assertTrue(this.getFirstName().isEmpty(), "First name is empty");
			fsa.assertEquals(this.getFirstNameLabel(), "First name", "First name is requested");
			fsa.assertTrue(this.getLastName().isEmpty(), "Last name is empty");
			fsa.assertEquals(this.getLastNameLabel(), "Last name", "Last name is requested");
			fsa.assertTrue(this.getDateOfBirth().isEmpty(), "Date of birth is empty");
			fsa.assertEquals(this.getDateOfBirthLabel(), "Date of birth", "Date of birth is requested");
			fsa.assertFalse(this.isCheckedMarried(), "Married is unchecked");
			if (isNotGuideWireOrEasternExpansionState(applicant.stateCode) && !Arrays.asList(MN,TN).contains(applicant.stateCode)) {
				List<String> availableOccupations = getAvailableOccupations();
				List<String> dbOccupations = new ApiHelper().getOccupations(applicant.stateCode);
				Collections.sort(availableOccupations);
				Collections.sort(dbOccupations);
				Log.info("Available occupations: " + availableOccupations);
				Log.info("Occupations from Postgres: " + dbOccupations);
				fsa.assertEquals(availableOccupations, dbOccupations, "Customer Info page - " +
						"Occupations match between UI drop-down and DB.");
			}
			clickElement(checkMarried);
			fsa.assertTrue(this.getSpouseFirstName().isEmpty(), "Spouse first name is empty");
			fsa.assertEquals(this.getSpouseFirstNameLabel(), "Spouse first name", "First name is requested");
			fsa.assertTrue(this.getSpouseLastName().isEmpty(), "Spouse fast name is empty");
			fsa.assertEquals(this.getSpouseLastNameLabel(), "Spouse last name", "Last name is requested");
			fsa.assertTrue(this.getSpouseDateOfBirth().isEmpty(), "Spouse date of birth is empty");
			fsa.assertEquals(this.getSpouseDateOfBirthLabel(), "Spouse date of birth", "Date of birth is requested");
			clickElement(checkMarried);
		} else {
			fsa.assertEquals(this.getFirstName(), applicant.firstName, "First name validation");
			fsa.assertEquals(this.getLastName(), applicant.lastName, "Last name validation");
			fsa.assertEquals(this.getDateOfBirth(), applicant.dateOfBirth, "Date of birth validation");
			fsa.assertEquals(this.isCheckedMarried(), applicant.maritalStatus.equalsIgnoreCase("Married"), "Married checkbox validation");
			if (isNotGuideWireOrEasternExpansionState(applicant.stateCode) && !Arrays.asList(MN,TN).contains(applicant.stateCode) &&
					!this.getSelectedOccupation().equals(applicant.occupation)) {
				fsa.assertFalse(this.getAvailableOccupations().contains(applicant.occupation), "Occupation does not match to expected, but it exists in the list.");
			}
			if (this.isCheckedMarried()) {
				fsa.assertEquals(this.getSpouseFirstName(), applicant.spouseFirstName, "Spouse First name validation");
				fsa.assertEquals(this.getSpouseLastName(), applicant.spouseLastName, "Spouse Last name validation");
				fsa.assertEquals(this.getSpouseDateOfBirth(), applicant.spouseDateOfBirth, "Spouse date of birth validation");
			}
		}
	}

	public void validatePageErrors(FarmersSoftAssert fsa) throws Exception {
		sendKeysToElement(inputFirstName, PWKeys.TAB);
		List<String> pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS  + pageErrors);
		List<String> expectedErrors1 = new ArrayList<>(Collections.singletonList(FIRST_NAME_ERROR_TEXT));
		fsa.assertEquals(pageErrors, expectedErrors1, "Customer Info page - Found first expected error.");

		sendKeysToElement(inputLastName, PWKeys.TAB);
		pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		expectedErrors1.add(LAST_NAME_ERROR_TEXT);
		fsa.assertEquals(pageErrors, expectedErrors1, "Contact Info page - Found 2 expected errors.");

		sendKeysToElement(inputDob, PWKeys.TAB);
		pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		expectedErrors1.add(DOB_ERROR_TEXT);
		fsa.assertEquals(pageErrors, expectedErrors1, "Contact Info page - Found 3 expected errors.");

		clickElement(checkMarried);

		sendKeysToElement(inputSpouseFirstName, PWKeys.TAB);
		pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		expectedErrors1.add(SPOUSE_FIRST_NAME_ERROR_TEXT);
		fsa.assertEquals(pageErrors, expectedErrors1, "Customer Info page - Found 4 expected errors.");

		sendKeysToElement(inputSpouseLastName, PWKeys.TAB);
		pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		expectedErrors1.add(SPOUSE_LAST_NAME_ERROR_TEXT);
		fsa.assertEquals(pageErrors, expectedErrors1, "Contact Info page - Found 5 expected errors.");

		sendKeysToElement(inputSpouseDob, PWKeys.TAB);
		pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		expectedErrors1.add(SPOUSE_DOB_ERROR_TEXT);
		fsa.assertEquals(pageErrors, expectedErrors1, "Contact Info page - Found all expected errors.");

		clickElement(checkMarried);

		// Invalid primary field data input
		String invalidName = "abc1";
		String invalidDob1 = "20/20/2020";
		String invalidDob2 = "02/20/2015";
		this.setFirstName(invalidName);
		this.setLastName(invalidName);
		this.setDateOfBirth(invalidDob1);
		sendKeysToElement(inputDob, PWKeys.TAB);
		pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		List<String> expectedErrors2 = new ArrayList<>(Arrays.asList(FIRST_NAME_ERROR_TEXT_TWO, LAST_NAME_ERROR_TEXT_TWO, SPOUSE_DOB_ERROR_TEXT_TWO));

		fsa.assertEquals(pageErrors, expectedErrors2, "Contact Info page - Found invalid data input errors, primary w/DoB1.");
		this.setDateOfBirth(invalidDob2);
		sendKeysToElement(inputDob, PWKeys.TAB);
		pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		expectedErrors2 = new ArrayList<>(Arrays.asList(FIRST_NAME_ERROR_TEXT_TWO, LAST_NAME_ERROR_TEXT_TWO, DOB_ERROR_TEXT_TWO));

		fsa.assertEquals(pageErrors, expectedErrors2, "Contact Info page - Found invalid data input errors, primary w/DoB2.");

		// Invalid spouse field data input
		clickElement(checkMarried);
		this.setSpouseFirstName(invalidName);
		this.setSpouseLastName(invalidName);
		this.setSpouseDateOfBirth(invalidDob1);
		sendKeysToElement(inputSpouseDob, PWKeys.TAB);
		pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		expectedErrors2.add(SPOUSE_FIRST_NAME_ERROR_TEXT_TWO);
		expectedErrors2.add(SPOUSE_LAST_NAME_ERROR_TEXT_TWO);
		expectedErrors2.add(SPOUSE_DOB_ERROR_TEXT_THREE);
		List<String> expectedErrors3 = new ArrayList<>(expectedErrors2);
		fsa.assertEquals(pageErrors, expectedErrors3, "Contact Info page - Found invalid data input errors, spouse w/DoB1.");
		this.setSpouseDateOfBirth(invalidDob2);
		sendKeysToElement(inputSpouseDob, PWKeys.TAB);
		expectedErrors3.remove(expectedErrors2.size() - 1);
		expectedErrors3.add(DOB_ERROR_TEXT_TWO);
		pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		fsa.assertEquals(pageErrors, expectedErrors3, "Contact Info page - Found invalid data input errors, spouse w/DoB2.");

		clickElement(checkMarried);
	}

	public void validatePageTitles(ApplicantHQM applicant, FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) throws Exception {
		fsa.assertEquals(getTextFromElement(textPageTitle), CUSTOMER_INFO_PAGE_TITLE, "Customer Info page - page Title");
		if (isEasternExpansionState(applicant.stateCode) || applicant.stateCode.equals(MN)) {
			fsa.assertFalse(isElementDisplayed(PWBy.xpath(SUBTITLE_XPATH)), "Customer Info page - page Subtitle 2 should not be displayed.");
		} else {
			fsa.assertEquals(getTextFromElement(textPageSubTitle2), CUSTOMER_INFO_PAGE_SUBTITLE, "Customer Info page - page Sub-Title 2");
		}
		if (staticContent != null) {
			fsa.assertEquals(staticContent.getCustomerInfoTitle(), CUSTOMER_INFO_PAGE_TITLE, "Customer Info page - page Title (AEM).");
			if (isEasternExpansionState(applicant.stateCode)) {
				fsa.assertNull(staticContent.getCustomerInfoCaption(), "Customer Info page - page Sub-Title 2 should be null (AEM).");
			} else {
				fsa.assertEquals(staticContent.getCustomerInfoCaption(), CUSTOMER_INFO_PAGE_SUBTITLE, "Customer Info page - page Sub-Title 2 (AEM).");
			}
		}
	}

	public List<String> validateSubtitlesDiscountJourney(List<String> discounts, FarmersSoftAssert fsa) throws Exception {
		fsa.assertEquals(getTextFromElement(discountSubTitleLock), DISCOUNT_LOCK_TEXT, "Customer Info page - Discount Journey Subtitle Clock image.");
		int discountCount = discounts.size();
		List<String> discountsAvailable = new ArrayList<>(discounts);
		if (isElementPresentByXPath(SELECT_OCCUPATION_XPATH) && !getSelectedOccupation().isEmpty() && !getSelectedOccupation().equals(OTHER)
				&& !discounts.contains("affinity(occupation)") && !discounts.contains("Affinity(occupation)")) {
			discountsAvailable.add("affinity(occupation)");
			discountCount++;
			Log.info("Customer Info page - Occupation is selected, so expecting Affinity discount.");
		}
		String textDiscount = discountCount > 0? discountCount + " p" : "P";
		fsa.assertEquals(getTextFromElement(discountSubTitlePiggy), textDiscount + DISCOUNT_PIGGY_TEXT, "Customer Info page - Discount Journey Subtitle Lock image.");
		List<String> listDiscounts = new ArrayList<>();
		if (discountCount > 0) {
			waitAndClickElement(discountHelpButtonPiggy);
			waitElementBeVisible(discountHelpDialogTitle);
			fsa.assertEquals(getTextFromElement(discountHelpDialogTitle), DISCOUNT_HELP_DIALOG_TITLE.replace("($)", "(" + discountCount + ")"),
					"Customer Info page - Discount Journey Help Dialog Title.");
			listDiscounts = driver().findElements(PWBy.xpath(DISCOUNT_HELP_DIALOG_CONTENT_XPATH)).stream().map(this::getTextFromElement)
					.map(String::toLowerCase).sorted(Comparator.naturalOrder()).collect(Collectors.toList());
			discountsAvailable = discountsAvailable.stream().map(String::toLowerCase)
					.sorted(Comparator.naturalOrder()).collect(Collectors.toList());
			fsa.assertEquals(listDiscounts, discountsAvailable, "Customer Info page - Discount Journey Help Dialog Content.");
			waitAndClickElement(buttonCloseDialog);
			//
			if (listDiscounts.contains("Affinity(occupation)")) {
				fsa.assertEquals(getTextFromElement(discountCheck), DISCOUNT_CHECK_TEXT, "Customer Info page - Discount Journey, Discount Check.");
			}
		}
		return listDiscounts;
	}

	public void validatePageFieldsLength(FarmersSoftAssert fsa) {
		String firstName = "abcdefghijklmnop";
		String lastName = "abcdefghijklmnoprstuf";
		sendKeysToElement(inputFirstName, firstName);
		sendKeysToElement(inputLastName, lastName);
		clickElement(checkMarried);
		sendKeysToElement(inputSpouseFirstName, firstName);
		sendKeysToElement(inputSpouseLastName, lastName);
		fsa.assertEquals(getFirstName(), firstName.substring(0, 15), "First name field accepted only 15 chars");
		fsa.assertEquals(getLastName(), lastName.substring(0, 20), "Last name field accepted only 20 chars");
		fsa.assertEquals(getSpouseFirstName(), firstName.substring(0, 15), "Spouse First name field accepted only 15 chars");
		fsa.assertEquals(getSpouseLastName(), lastName.substring(0, 20), "Spouse Last name field accepted only 20 chars");
		clickElement(checkMarried);
	}

	public void verifyPageFieldsReadonly(ApplicantHQM applicant, boolean bPrimary, FarmersSoftAssert fsa) throws Exception {
		fsa.assertEquals(getAttributeData(inputFirstName, READONLY), LOWERCASE_TRUE, "Customer Info page - First name field is read-only");
		fsa.assertEquals(getAttributeData(inputLastName, READONLY), LOWERCASE_TRUE, "Customer Info page - Last name field is read-only");
		fsa.assertEquals(getAttributeData(inputDob, READONLY), LOWERCASE_TRUE, "Customer Info page - Date of birth field is read-only");
		if (!bPrimary) {
			if (isNotGuideWireOrEasternExpansionState(applicant.stateCode)) {
				fsa.assertEquals(getAttributeData(selectOccupation, READONLY), LOWERCASE_TRUE, "Customer Info page - Occupation field is read-only");
			}
			fsa.assertEquals(getAttributeData(checkMarriedInternal, DISABLED), LOWERCASE_TRUE, "Customer Info page - Married checkbox is disabled");
			if (checkIfElementIsDisplayed(inputSpouseFirstName, 3)) {
				fsa.assertEquals(getAttributeData(inputSpouseFirstName, READONLY), LOWERCASE_TRUE, "Customer Info page - Spouse First name field is read-only");
				fsa.assertEquals(getAttributeData(inputSpouseLastName, READONLY), LOWERCASE_TRUE, "Customer Info page - Spouse Last name field is read-only");
				fsa.assertEquals(getAttributeData(inputSpouseDob, READONLY), LOWERCASE_TRUE, "Customer Info page - Spouse Date of birth field is read-only");
			}
		}
	}
}