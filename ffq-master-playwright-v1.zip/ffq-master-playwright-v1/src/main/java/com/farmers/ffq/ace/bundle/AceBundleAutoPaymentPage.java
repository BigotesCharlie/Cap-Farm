package com.farmers.ffq.ace.bundle;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import static com.farmers.ffq.utils.GlobalVariables.MASTER_CARD;
import static com.farmers.ffq.utils.GlobalVariables.SRC;

import java.util.List;

public class AceBundleAutoPaymentPage extends BasePage {

    //Common elements

    @PWFindBy (xpath = "//h1[contains(@class, 'payment-overview-header-text')]")
    private PWElement autoPaymentPageTitle;

    //Farmers Elements
    @PWFindBy (xpath = "//input[@value='bank']")
    private PWElement bankPreferedPaymentRadioButton;
    @PWFindBy (xpath = "//input[@value='card']")
    private PWElement cardPreferedPaymentRadioButton;
    @PWFindBy (xpath = "//button[contains(@class, '-purchase-btn-bundle')]")
    private PWElement completeAutoPurchaseButton;

    //BW Elements
    @PWFindBy (xpath = "//div[contains(@class, 'bristol-west-bundle-icon')]//img")
    private PWElement autoPaymentPageBWIcon;
    @PWFindBy (xpath = "//div[contains(@class, 'bristol-west-bundle-body')]")
    private PWElement autoPaymentPageBWLabel;
    @PWFindBy (xpath = "//div[contains(@class, 'mat-tab-label')][@role='tab']")
    private List<PWElement> listOfTabsForAvailablePaymentPlans;
    @PWFindBy (xpath = "//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Pay in full')]")
    private PWElement selectAndSignDocumentsPayInFullButton;
    @PWFindBy (xpath = "//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly autopay bank')]")
    private PWElement selectAndSignDocumentsMonthlyBankButton;
    @PWFindBy (xpath = "//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly autopay card')]")
    private PWElement selectAndSignDocumentsMonthlyCardButton;
    @PWFindBy (xpath = "//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly direct')]")
    private PWElement selectAndSignDocumentsMonthlyDirectButton;
    @PWFindBy (xpath = "//mat-tab-body//button")
    private PWElement activeSelectAndSignDocumentsButton;
    @PWFindBy (xpath = "//button[contains(@class, 'tui-btn')]")
    private PWElement bwSetupPaymentButton;

    //ERSD Consent Dialog
    @PWFindBy (xpath = "//div[@data-qa='ersd-modal-content']")
    private PWElement ersdDialog;
    @PWFindBy (xpath = "//input[@data-qa='ersd-agree-checkbox']")
    private PWElement agreeToUseERSDCheckbox;
    @PWFindBy (xpath = "//button[@data-qa='ersd-modal-agree']")
    private PWElement ersdDialogContinueButton;

    //Docusign elements
    @PWFindBy (id = "oneds-title")
    private PWElement docusignDocument;
    @PWFindBy (xpath = "//button[contains(@data-qa,'initials-tab-required') and @aria-invalid='true']")
    private List<PWElement> listOfInitialHereLocations;
    @PWFindBy (xpath = "//button[contains(@data-qa,'signature-tab-required') and @aria-invalid='true']")
    private List<PWElement> listOfSignHereLocations;
    @PWFindBy (xpath = "//div[@data-qa='adopt-signature-modal-content']")
    private PWElement adoptSignatureDialog;
    @PWFindBy (xpath = "//button[@data-qa='adopt-submit']")
    private PWElement adoptAndInitialButton;
    @PWFindBy (xpath = "//button[contains(@data-qa,'action-bar-btn-finish')]")
    private PWElement finishDocusignButton;

    public AceBundleAutoPaymentPage() throws Exception {
    }

    public boolean isOnAceBundleAutoPaymentPage() {
	return isElementDisplayed(autoPaymentPageTitle, 4);
    }

    public void verifyAceBundleAutoPaymentPageContent(FarmersSoftAssert fsa) throws Exception {
	fsa.assertTrue(getListOfSteps().isEmpty(), "Stepper is not available on auto payment page");
	fsa.assertEquals(getTextFromElement(autoPaymentPageTitle), "First up: Pay for auto", "AceBundleAutoPaymentPage title verification");
	if (isElementDisplayed(autoPaymentPageBWIcon, 1)) {
	    fsa.assertTrue(getAttributeData(autoPaymentPageBWIcon, SRC).contains("bristol-west"), "AceBundleAutoPaymentPage using BW logo");
	    fsa.assertEquals(getTextFromElement(autoPaymentPageBWLabel), "Auto policy insured and serviced by Bristol West, a Farmers company", "AceBundleAutoPaymentPage BW label verification");
	}
    }

    public void fillOutAutoPaymentPageAndContinue(AutoApplicant autoApplicant) throws Exception {
	boolean isBristolWest = isElementDisplayed(autoPaymentPageBWIcon, 1);
	if (isBristolWest) {
	    clickElement(activeSelectAndSignDocumentsButton);
	    waitElementBeVisible(ersdDialog);
	    waitAndClickElement(agreeToUseERSDCheckbox);
	    waitAndClickElement(ersdDialogContinueButton);
	    waitElementBeInvisible(ersdDialog);
	    waitElementBeVisible(finishDocusignButton);
	    boolean firstTime = true;
	    for (PWElement initialHere : listOfInitialHereLocations) {
		scrollToElement(initialHere);
		waitAndClickElement(initialHere);
		if (firstTime) {
		    waitElementBeVisible(adoptSignatureDialog);
		    waitAndClickElement(adoptAndInitialButton);
		    waitElementBeInvisible(adoptSignatureDialog);
		    firstTime = false;
		}
	    }
	    for (PWElement signHere : listOfSignHereLocations) {
		scrollToElement(signHere);
		waitAndClickElement(signHere);
	    }
	    // Sometimes some of the clicks fail :(
	    for (PWElement initialHere : listOfInitialHereLocations) {
		scrollToElement(initialHere);
		waitAndClickElement(initialHere);
	    }
	    waitAndClickElement(finishDocusignButton);
	    waitElementBeInvisible(finishDocusignButton);
	    waitAndClickElement(bwSetupPaymentButton);
	} else {
	    scrollAndClickOnElement(cardPreferedPaymentRadioButton);
	}
	AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
	aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
	scrollAndClickOnElement(completeAutoPurchaseButton);
	waitForSpinnerToBeGone();
	if (isElementDisplayed(completeAutoPurchaseButton, 1)) {
	    scrollAndClickOnElement(completeAutoPurchaseButton);
	    waitForSpinnerToBeGone();
	}
    }
}
