package com.farmers.ffq.integration;

import java.util.List;

/**
 * Immutable data transfer object that holds the details of a Rally test case
 * as returned by {@link RallyService#getTestCaseDetails(String)}.
 */
public final class RallyTestCaseInfo {

    private final String formattedId;
    private final String name;
    private final String description;
    private final String method;        // "Automated" | "Manual" | ""
    private final String priority;
    private final List<TestStep> steps;

    public RallyTestCaseInfo(String formattedId, String name, String description,
                             String method, String priority, List<TestStep> steps) {
        this.formattedId = formattedId;
        this.name        = name;
        this.description = description;
        this.method      = method;
        this.priority    = priority;
        this.steps       = steps;
    }

    public String            getFormattedId()  { return formattedId; }
    public String            getName()         { return name; }
    public String            getDescription()  { return description; }
    public String            getMethod()       { return method; }
    public String            getPriority()     { return priority; }
    public List<TestStep>    getSteps()        { return steps; }

    // ── Nested step DTO ──────────────────────────────────────────────────────

    public static final class TestStep {
        private final int    index;
        private final String input;
        private final String expectedResult;

        public TestStep(int index, String input, String expectedResult) {
            this.index          = index;
            this.input          = input;
            this.expectedResult = expectedResult;
        }

        public int    getIndex()          { return index; }
        public String getInput()          { return input; }
        public String getExpectedResult() { return expectedResult; }
    }
}

