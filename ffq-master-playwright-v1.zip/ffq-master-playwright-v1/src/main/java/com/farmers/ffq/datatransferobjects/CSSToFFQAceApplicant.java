package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter @Setter
public class CSSToFFQAceApplicant {
    @JsonProperty("First_Name")
    private String firstName;
    @JsonProperty("Last_Name")
    private String lastName;
    @JsonProperty("DOB")
    private String dob;
    @JsonProperty("Street")
    private String street;
    @JsonProperty("City")
    private String city;
    @JsonProperty("Zip_Code")
    private String zipCode;
    @JsonProperty("LOB")
    private String lob;
    @JsonProperty("Gender")
    private String gender;
    @JsonProperty("MaritalStatus")
    private String maritalStatus;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("Phone")
    private String phone;
    @JsonProperty("Source_Indicator")
    private String sourceIndicator;
    @JsonProperty("SRC")
    private String SRC;

// {"First_Name":"Kinder","Last_Name":"Joy","DOB":"1995-01-01","Email":"k5pla@farmers.testinator.com","Phone":"971-266-3534","Gender":"M","MaritalStatus":"Single","Street":"5632 Fairview Ln","City":"Florence","Zip_Code":"59833","LOB":"home","Source_Indicator":"MV","SRC":"MV000000001"}
// {"First_Name":"vYihNq","Last_Name":"AhRuqDArt","DOB":"1989-10-11","Email":"qaautomation@farmers.testinator.com","Phone":"818-245-7832","Gender":"M","MaritalStatus":"Single","Street":"3244 W Maldonado Rd","City":"Phoenix","Zip_Code":"85041","LOB":"home","Source_Indicator":"MV","SRC":"MV000000001"}

    public CSSToFFQAceApplicant(ApplicantAceHome applicant, String lob) {
        this.setFirstName(applicant.getFirstName());
        this.setLastName(applicant.getLastName());
        this.setDob(formattedDob(applicant.getDateOfBirth()));
        this.setStreet(applicant.getAddress());
        this.setCity(applicant.getCity());
        this.setZipCode(applicant.getZipCode());
        this.setLob(lob.toLowerCase());
        this.setGender(applicant.getGender().substring(0,1).toUpperCase());
        this.setMaritalStatus(SINGLE);
        this.setEmail(applicant.getEmailAddress());
        this.setPhone(applicant.getPhoneNumber());
        this.setSourceIndicator("MV");
        this.setSRC("MV000000001");
    }

    private String formattedDob(String dob) {
        LocalDate localDate = LocalDate.parse(dob, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        LocalDateTime localDateTime = localDate.atStartOfDay();
        return localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    }
}
