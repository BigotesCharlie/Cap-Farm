package com.farmers.ffq.ace.renters;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.ace.hrc.common.AceHRCJustAFewMoreThingsBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersJustAFewMoreThingsPage extends AceHRCJustAFewMoreThingsBasePage {
    //// Mailing address elements for renters are moved here....We can create common class in future if Hone/Condo get the same changes
    static final String MAILING_ADDRESS = "Mailing Address";
    @PWFindBy(css = "#mailingAddressDiv>div>label")
    private PWElement mailingAddressLabel;
    @PWFindBy(xpath = "//mat-radio-button[@id='mailingAddressDiv_1']")
    protected PWElement defaultMailingAddressRadioButton;
    @PWFindBy(xpath = "//div[@id='mailingAddressDiv']//mat-radio-button[1]")
    protected PWElement defaultMailingAddressRadioButtonLabel;
    @PWFindBy(xpath = "//input[@id='mailingAddressDiv_2-input']")
    protected PWElement otherMailingAddressRadioButton;
    @PWFindBy(xpath = "//mat-radio-button[contains(.,'Other mailing address')]")
    protected PWElement otherMailingAddressRadioButtonLabel;

    @PWFindBy(xpath = "//div[@id='formField_address']//mat-label")
    private PWElement mailingAddressInputLabel;

    @PWFindBy(xpath = "//div[@id='formField_address']//mat-error")
    private PWElement mailingAddressError;

    @PWFindBy(css = "input[aria-label='Apartment number (optional)']")
    private PWElement apartmentNumberInputField;

    @PWFindBy(xpath = "//div[@id='mailingAddressDiv_apartment']//mat-label")
    private PWElement apartmentInputLabel;

    @PWFindBy(xpath = "//mat-form-field[@id='auto-contact-info-apartment__input-field']//mat-error")
    private PWElement invalidAptError;
    @PWFindBy(css = "input[aria-label='City']")
    private PWElement cityInputField;

    @PWFindBy(xpath = "//div[@id='mailingAddressDiv_city']//mat-label")
    private PWElement cityInputLabel;

    @PWFindBy(xpath = "//div[@id='mailingAddressDiv_city']//mat-error")
    private PWElement cityError;

    @PWFindBy(css = "mat-select[aria-label='State']")
    private PWElement stateDropDown;

    @PWFindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-label")
    private PWElement stateDropDownLabel;

    @PWFindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-error/div")
    private PWElement stateError;

    @PWFindBy(css = "input[aria-label='Zip code']")
    private PWElement zipCodeInputField;

    @PWFindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//mat-label")
    private PWElement zipCodeInputLabel;

    @PWFindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//mat-error/div")
    private PWElement zipCodeError;
    @PWFindBy(xpath = "//address-autocomplete-input//input")
    private PWElement otherMailingAddressInputField;
    @PWFindBy(xpath = "//div[@id='mailingAddressDiv_apartment']//input")
    private PWElement otherMailingAddressUnitInputField;
    @PWFindBy(xpath = "//div[@id='mailingAddressDiv_city']//input")
    private PWElement otherMailingAddressCityInputField;
    @PWFindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-select")
    private PWElement otherMailingAddressStateDropdownField;
    @PWFindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//input")
    private PWElement otherMailingAddressZipCodeInputField;
    @PWFindBy(xpath = "//span[@class='mat-option-text']")
    private List<PWElement> listOfAllTheStatesInOtherMailingAddressStateDropDown;

    @PWFindBy(xpath = "//div[@id='flex-field-emailAddress_contactInfo']/p")
    private PWElement personalInfoLabel;

    @PWFindBy(xpath = "//div[@class='email-address']//label")
    private PWElement emailAddressFieldLabel;

    @PWFindBy(xpath = "//div[@id='flex-field-emailAddress_contactInfo']//mat-error")
    private PWElement emailAddressError;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceRentersJustAFewMoreThingsPage() throws Exception {
    }

    public void fillOutFMTPWithAllOtherQuestionsSelectedRentersLob(ApplicantAceHome applicantAceHome) throws Exception {
        fillOutTerritory(applicantAceHome);
        clickOnBusinessOperatedOnPremisesCheckBox();
        clickOnDogsOnPremisesCheckBox();
        selectDogsBreedFromSideSheet(applicantAceHome.getDogsOnPremises());
        clickOnSaveButtonDogsOnPremisesSideSheet();
        clickOnPetWithBiteHistoryCheckBox();
        clickContinueButton();
    }
    public void fillOutFMTPWithBusinessOperatedOnPremisesSelectedRentersLob(ApplicantAceHome applicantAceHome) throws Exception {
        selectBusinessOperatedOnPremisesCheckBox(applicantAceHome.isBusinessOperatedOnPremises());
        clickContinueButton();
    }
    public void fillOutFMTPWithPetWithBiteHistorySelectedRentersLob(ApplicantAceHome applicantAceHome) throws Exception {
        selectPetWithBiteHistoryCheckBox(applicantAceHome.isPetWithBiteHistory());
        clickContinueButton();
    }

    public void fillOutFMTPWithDogsOnPremisesSelectedRentersLob(ApplicantAceHome applicantAceHome, FarmersSoftAssert fsa, boolean validateRC3Page) throws Exception {
        fillOutTerritory(applicantAceHome);
        selectDogsOnPremisesCheckbox(applicantAceHome.getDogsOnPremises());
        clickContinueButton();
        if(validateRC3Page) {
            validateRC3LoadingScreen(fsa);
        }
    }

    public void fillOutJustFewMoreThingsPageRentersLob(ApplicantAceHome applicantAceHome) throws Exception {
        fillOutTerritory(applicantAceHome);
        fillOutRNOGSectionNo();
        clickContinueButton();
    }

    public void validateContentOfMailingAndOtherMailingAddress(FarmersSoftAssert fsa) throws Exception {
        String defaultMailingAddress = getSessionStorageAppStore().getData().getCustomerData().getAddress().getStreet();
        //validate mailing address input field content
        final String EXPECTED_MAILING_ADDRESS_LABEL = "Mailing address";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(mailingAddressLabel)), EXPECTED_MAILING_ADDRESS_LABEL, errorMessage(EXPECTED_MAILING_ADDRESS_LABEL));

        fsa.assertTrue(defaultMailingAddressRadioButton.isEnabled(), "Default mailing address radio button enabled");
        String defaultMailAddressLabel = getTextFromElement(defaultMailingAddressRadioButtonLabel);
        fsa.assertTrue(defaultMailAddressLabel.contains(defaultMailingAddress.toUpperCase()), "Default mailing address verification");

        // Validate other mailing address content
        final String EXPECTED_OTHER_MAILING_ADDRESS_LABEL = "Other mailing address";
        clickElement(otherMailingAddressRadioButton);
        fsa.assertTrue(otherMailingAddressRadioButton.isEnabled(), "Other mailing address radio button is not enabled");
        fsa.assertEquals(getAttributeData(waitElementBeVisible(otherMailingAddressRadioButtonLabel), "innerText").strip(), EXPECTED_OTHER_MAILING_ADDRESS_LABEL, errorMessage(EXPECTED_OTHER_MAILING_ADDRESS_LABEL));

        fsa.assertEquals(getTextFromElement(waitElementBeVisible(mailingAddressInputLabel)), MAILING_ADDRESS, errorMessage(MAILING_ADDRESS));

        final String EXPECTED_APARTMENT_LABEL = "Unit #";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(apartmentInputLabel)), EXPECTED_APARTMENT_LABEL, errorMessage(EXPECTED_APARTMENT_LABEL));

        final String EXPECTED_CITY_LABEL = "City";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(cityInputLabel)), EXPECTED_CITY_LABEL, errorMessage(EXPECTED_CITY_LABEL));

        final String EXPECTED_STATE_LABEL = "State";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(stateDropDownLabel)), EXPECTED_STATE_LABEL, errorMessage(EXPECTED_STATE_LABEL));

        final String EXPECTED_ZIP_LABEL = "ZIP";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(zipCodeInputLabel)), EXPECTED_ZIP_LABEL, errorMessage(EXPECTED_ZIP_LABEL));

        final String EXPECTED_STREET_ADDRESS = "10528 Sea Palms Ave";
        final String EXPECTED_CITY = "Las Vegas";
        final String EXPECTED_STATE = "NV";
        final String EXPECTED_ZIP_CODE = "89134";
        scrollToElement(otherMailingAddressInputField);
        enterGoogleAddress(otherMailingAddressInputField, EXPECTED_STREET_ADDRESS, EXPECTED_CITY);
//        sleep(5);
//        Actions builder = new Actions(driver());
        waitAndClickElement(otherMailingAddressCityInputField);
//        builder.moveToElement(otherMailingAddressStateDropdownField, 100, 100).click().build().perform();
        fsa.assertEquals(getAttributeData(otherMailingAddressInputField, VALUE), EXPECTED_STREET_ADDRESS, "Other mailing address street verification.");
        fsa.assertEquals(getAttributeData(otherMailingAddressCityInputField, VALUE), EXPECTED_CITY, "Other mailing address city verification.");

        waitAndClickElement(stateDropDownLabel);
        List<String> foundListOfStates = stateDropDownOptions.stream().map(this::getTextFromElement).sorted().collect(Collectors.toList());
        fsa.assertEquals(foundListOfStates.size(), listOfAllStates().size(), "Other mailing address list of states verification.");
        fsa.assertEquals(getTextFromElement(otherMailingAddressStateDropdownField), EXPECTED_STATE, "Other mailing address state verification in the state drop down.");
        fsa.assertEquals(getAttributeData(otherMailingAddressZipCodeInputField, VALUE), EXPECTED_ZIP_CODE, "Other mailing address zip code verification.");
        fsa.assertEquals(getAttributeData(otherMailingAddressUnitInputField, VALUE), EMPTY_STRING, "Other mailing address unit is empty.");
    }

}
