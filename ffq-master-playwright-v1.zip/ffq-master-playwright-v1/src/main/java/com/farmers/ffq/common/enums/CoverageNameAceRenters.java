package com.farmers.ffq.common.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.List;

@Getter
public enum CoverageNameAceRenters {
    RENTERS_COVERAGE(Arrays.asList("Personal property","Loss settlement", "Loss of use (Additional living expense term)", "Building additions & alterations", "Personal liability", "Medical payments to others"));

    private final List<String> coverages;
    CoverageNameAceRenters(List<String> coverages) {
        this.coverages = coverages;
    }
}
