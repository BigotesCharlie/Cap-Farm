package com.farmers.ffq.datatransferobjects.hqm;

import java.util.ArrayList;
import java.util.List;

public class CrossSellInfoHQM {
    private String quoteNumber;
    private final List<CSOption> crossSellOptions = new ArrayList<>();

    public String getQuoteNumber() { 
    	return quoteNumber; 
    }

    public List<CrossSellInfoHQM.CSOption> getCrossSellOptions() {
        return crossSellOptions;
    }

    public static class CSOption {
        private String url;
        private String label;

        public String getUrl() {
            return url;
        }

        public String getLabel() {
            return label;
        }
    }

}
