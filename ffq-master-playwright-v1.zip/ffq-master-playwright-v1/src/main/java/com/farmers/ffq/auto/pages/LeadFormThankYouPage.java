package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.utils.FarmersSoftAssert;

public class LeadFormThankYouPage extends AutoBasePage {

    @PWFindBy(css = "div[class='thank-you__title']>h1")
    private PWElement pageTitle;

    @PWFindBy(css = "div[class='tui-body thank-you__subtitle']>p")
    private PWElement pageSubtitle;

    @PWFindBy(css = "div[class='thank-you__quote-number ng-star-inserted']>span[class='tui-body-bold']")
    private PWElement quoteNumberText;

    @PWFindBy(css = "div[class='thank-you__quote-number ng-star-inserted']>span[class='tui-body']")
    private PWElement quoteNumberElement;

    @PWFindBy(xpath = "//div[contains(text(),'Need more help?')]")
    private PWElement needMoreHelp;

    @PWFindBy(xpath = "//div[contains(text(),'You can call customer service at')]")
    private PWElement youCanCallCustomerService;

    @PWFindBy(xpath = "//div[contains(@class,'toll-free-number')]")
    private PWElement tollNumber;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public LeadFormThankYouPage() throws Exception {
    }

    public void validateLeadFormThankYouPageContent(FarmersSoftAssert fsa, boolean isMobile) throws Exception {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageTitle)), "Thank you for choosing Farmers Insurance\u00ae", "Thank you page title check");
        fsa.assertEquals(getTextFromElement(pageSubtitle), "Your request has been submitted.", "Thank you page subtitle check");
        fsa.assertTrue(needMoreHelp.isDisplayed(), "Need more help link displayed");
        fsa.assertTrue(youCanCallCustomerService.isDisplayed(), "Call Customer service link displayed");
        String expectedPhoneNumber = isUseMobileViewEnabled() || isMobile? "1-888-587-2121" : "1-888-422-1618";
        fsa.assertEquals(getTextFromElement(tollNumber), expectedPhoneNumber, "Displayed phone number check");

        // Ace Auto and Bind - Validate that Quote Number is removed from lead thank you page for Auto LOBValidate
        fsa.assertFalse(getTextFromElement(driver().findElement(PWBy.tagName("app-thank-you"))).contains("quote number:"), "Quote number should not be displayed in the content");

    }
}
