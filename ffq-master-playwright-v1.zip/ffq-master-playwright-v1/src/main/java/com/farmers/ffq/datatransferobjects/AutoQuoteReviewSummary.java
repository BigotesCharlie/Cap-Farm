package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@JsonIgnoreProperties
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class AutoQuoteReviewSummary {

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class ReviewQuote {
        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Summary {
            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class Disclaimer {
                private String name;
                private String value;
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class Header {
                private String name;
                private String value;
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class InfoContent {
                private String name;
                private String value;
            }

            private List<Header> headers;
            private List<InfoContent> infoContents;
            private List<Disclaimer> disclaimers;

           public List<Header> getHeaders(){
                return headers;
            }
        }

        public Summary summary;
    }

    private ReviewQuote reviewQuote;

// public ReviewQuote getReviewQuote(){
//    return reviewQuote;
// }

}






