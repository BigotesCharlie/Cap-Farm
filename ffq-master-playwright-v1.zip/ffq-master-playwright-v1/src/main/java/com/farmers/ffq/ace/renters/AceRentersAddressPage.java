package com.farmers.ffq.ace.renters;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.ace.hrc.common.AceHRCAddressBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import static com.farmers.ffq.utils.GlobalVariables.*;
public class AceRentersAddressPage extends AceHRCAddressBasePage {

    private static final String ADDRESS_INPUT_FIELD_XPATH = "//app-personal-info//input[@id='auto-manual-street__input-section']";
    @PWFindBy(xpath = ADDRESS_INPUT_FIELD_XPATH)
    protected PWElement formFieldAddressInput;
    @PWFindBy(xpath = "//app-personal-info//div[@id='formField_apartment']//input")
    protected PWElement unitNumberInput;
    @PWFindBy(xpath = "//app-personal-info//div[@id='formField_apartment']//mat-label")
    protected PWElement unitNumberInputLabel;
    @PWFindBy(xpath = "//app-personal-info//div[@id='formField_apartment']//mat-hint")
    protected PWElement optionalHintText;
    public AceRentersAddressPage() throws Exception {
        super();
    }

    public boolean isOnAddressPageRenters(boolean longWait) {
        int timeout = longWait ? Property.PAGELOADTIMEOUT : 5;
        return isElementDisplayed(formFieldAddressInput, timeout);
    }

    public void validateRentersPageFormFields(FarmersSoftAssert fsa, ApplicantAceHome applicant) {
        final String ADDRESS_FIELD_TEXT = "Home Address (No Post Office Boxes)";
        fsa.assertEquals(getAttributeData(formFieldAddressInput, ARIA_LABEL), ADDRESS_FIELD_TEXT, "Address page - Address placeholder text.");
        fsa.assertEquals(getTextFromElement(formFieldAddressInput), EMPTY_STRING, "Address page - Address field is blank.");

        fsa.assertEquals(unitNumberInput.isDisplayed(), true, "Unit number input field");
        fsa.assertEquals(getTextFromElement(unitNumberInputLabel), "Unit #", "Address page - unit field place holder text.");

        fsa.assertEquals(optionalHintText.isDisplayed(), true, "Optional hint validation");
        fsa.assertEquals(getTextFromElement(optionalHintText), "Optional", "Optional hint validation");
    }

    public void validateAddressPageErrorsRenters(FarmersSoftAssert sa, ApplicantAceHome applicant) throws Exception {
        final String ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR = "Please enter street number and name.";
        final String PAGE_ALERT = "One or more required fields are incomplete or incorrect. Please review.";
        clickContinueButton();
        waitForSpinnerToBeGone();
        sa.assertTrue(getPageErrors().contains(ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR), ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR + ERROR_FOUND);
        sa.assertTrue(getPageAlerts().contains(PAGE_ALERT), "Expected page alert(s) found.");
        waitAndClickElement(formFieldAddressInput);
        sendKeysToElement(formFieldAddressInput, SPECIALCHARS);
        clickContinueButton();
        sa.assertTrue(getPageErrors().contains(ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR), ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR + ERROR_FOUND);
        sa.assertTrue(getPageAlerts().contains(PAGE_ALERT), "Expected page alert(s) found.");
        driver().navigate().refresh();
        enterGoogleAddress(formFieldAddressInput, applicant.getAddress(), applicant.getCity());
        wait.until(invisibilityOfElementLocated(PWBy.xpath("//mat-error")));
        sa.assertTrue(getPageErrors().isEmpty(), "Page error(s) should not be found.");
        sa.assertTrue(getPageAlerts().isEmpty(), "Page alert(s) should not be found.");
    }

}
