package com.farmers.ffq.ace.bundle;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import com.farmers.ffq.ace.hrc.common.AceHRCAdditionalCoveragesBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCJustAFewMoreThingsBasePage;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Auto;
import com.farmers.ffq.datatransferobjects.AppStore.Home;
import com.farmers.ffq.utils.CurrencyFormat;

import com.farmers.framework.report.Reporter;
import org.apache.commons.math3.util.Precision;
import com.farmers.ffq.ace.home.AceHomeContactInfoPage;
import com.farmers.ffq.ace.hrc.common.AceHRCQualityGradeBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCReviewQuoteBasePage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.AceBundleApplicant;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;

public class AceBundleReviewQuotesPage extends BasePage {

	private static final String NON_DIGITS_AND_PERIOD = "[^0-9.]";

	@PWFindBy (xpath = "//div[@class='bundle-quote-review']//h1")
	private PWElement bundleReviewQuotesPageTitle;

	@PWFindBy (xpath = "//div[contains(@class,'bundle-quote-header')]//p[@class='tui-input-text']")
	private PWElement bundleReviewQuotesPageSubtitle;

	@PWFindBy (xpath = "//div[contains(@class,'bundle-quote-review')]//div[contains(@class, 'box ')]/span")
	private PWElement bundleReviewQuotePageSummaryHeader;

	@PWFindBy (xpath = "//thead//th[contains(@class, 'monthlyAutopay')]")
	private PWElement monthlyAutopayColumnTitle;

	@PWFindBy (xpath = "//thead//th[contains(@class, 'payInFull')]")
	private PWElement payInFullColumnTitle;

	@PWFindBy (xpath = "//tbody//td[contains(@class, 'column-lob')]")
	private List<PWElement> listOfBundleLOBs;

	@PWFindBy (xpath = "//tbody//td[contains(@class, 'column-monthly')]")
	private List<PWElement> listOfBundleMonthlyCost;

	@PWFindBy (xpath = "//tbody//td[contains(@class, 'column-pay')]")
	private List<PWElement> listOfBundlePayInFullCost;

	@PWFindBy (xpath = "//div[contains(@class, 'bundle-savings')]")
	private PWElement upToSavingsLabel;

	@PWFindBy (className = "bundle-lob-summary")
	private List<PWElement> listOfBundleSummarySectionTitles;

	private static final String USING_BW_AUTO_XPATH = "//div[contains(@class, 'bundle-lob-bw')]";
	@PWFindBy (xpath = USING_BW_AUTO_XPATH + "/span")
	private List<PWElement> listOfProviderDescriptionLabels;
	@PWFindBy (xpath = USING_BW_AUTO_XPATH + "/img")
	private List<PWElement> listOfProviderLogos;

	@PWFindBy (xpath = "//div[@class='tui-stacking-bottom-xs']")
	private List<PWElement> listOfBundleSummaryTermLabels;

	@PWFindBy (xpath = "//div[@class='tui-stacking-bottom-sm']")
	private List<PWElement> listOfBundleSummaryDescriptionLabels;

	@PWFindBy (xpath = "//div[contains(@class, 'lob-discounts')]/a")
	private List<PWElement> listOfLOBDiscountsLinks;

	@PWFindBy (xpath = "//div[contains(@class, 'cta-container')]/button")
	private List<PWElement> listOfQuoteReviewEditUpdateButtons;

	@PWFindBy (className = "payment-flexibility-info")
	protected PWElement paymentFlexibilityLabel;

	@PWFindBy (xpath = "//button[contains(@class, 'bundle-quote-button') and (contains(text(), 'auto coverages') or contains(text(), 'final wrap'))]")
	private PWElement continueToNextPageButton;

	@PWFindBy (xpath = "//*[@role='heading']")
	private PWElement changePoliciesDialogTitle;

	@PWFindBy (id = "onePolicyContent")
	private PWElement changePolicyDialogSubtitle;

	private static final String AUTO_MONOLINE_XPATH = "//mat-radio-button[@value='Auto']";
	private static final String PROPERTY_MONOLINE_XPATH = "//mat-radio-button[not(@value)]";
	private static final String KEEP_BUNDLE_XPATH = "//mat-radio-button[@value='Bundle']";

	@PWFindBy (xpath = AUTO_MONOLINE_XPATH)
	private PWElement autoPolicyMonolineLabel;
	@PWFindBy (xpath = PROPERTY_MONOLINE_XPATH)
	private PWElement propertyPolicyMonolineLabel;
	@PWFindBy (xpath = KEEP_BUNDLE_XPATH)
	private PWElement keepBundleLabel;
	@PWFindBy (xpath = "//app-one-policy-popup//button")
	private PWElement changePoliciesDialogContinueButton;
	@PWFindBy(xpath = "//div[@id='appliedDiscounts']")
	private PWElement discountsSideSheetAppliedText;
	@PWFindBy(xpath = "//div/span[contains(@class,'discount-name')]")
	private List<PWElement> discountsNameInSideSheet;
	@PWFindBy(xpath = "//app-auto-discount-sidesheet//mat-icon[text()='close']")
	private PWElement closeIconDiscountsSideSheet;
	@PWFindBy(xpath = "//div[contains(@class, 'bundle-savings')]")
	private PWElement savingsAppliedWhenBundleText;
	@PWFindBy(xpath = "//a[contains(@class,'email_Quote_CTA')]")
	private PWElement emailLink;
	@PWFindBy(linkText = "Done")
	private PWElement linkCloseEmailSnackBar;
	@PWFindBy(xpath = "//a[contains(@class, 'bundle-one-popup-link')]")
	private PWElement wantOneOfThePoliciesLink;
	@PWFindBy(id = "onePolicyHeading")
	private PWElement changePoliciesHeaderInCPPopUpModal;
	@PWFindBy(xpath = "//div[contains(@class, 'onePolicy-popup-content')]")
	private PWElement changePoliciesContentInCPPopUpModal;
	@PWFindBy(xpath = "//div[contains(text(), 'Please select one:')]")
	private PWElement pleaseSelectOneHeaderInCPPopUpModal;
	@PWFindBy(xpath = "//mat-radio-group[contains(@class, 'bundle-radio-group')]//mat-radio-button")
	private List<PWElement> policyOptionsRadioButtonsInCPPopUpModal;
	@PWFindBy(xpath = "//mat-radio-group[contains(@class, 'bundle-radio-group')]//mat-radio-button//label")
	private List<PWElement> policyOptionsLabelsInCPPopUpModal;
	@PWFindBy(xpath = "//mat-radio-group[contains(@class, 'bundle-radio-group')]//p")
	private List<PWElement> discountAmountInCPPopUpModal;
	@PWFindBy(xpath = "//app-one-policy-popup//button")
	private PWElement continueButtonInCPPopUpModal;
	@PWFindBy(xpath = "//*[@appbristolwestbundle]")
	private PWElement bWLogoAndDescriptionSectionOnAutoPage;
	@PWFindBy(xpath = "//*[@appbristolwestbundle]//img[contains(@class, 'bristol-west-bundle-icon-auto')]")
	private PWElement bWLogoOnAutoPage;
	@PWFindBy(xpath = "//*[@appbristolwestbundle]//div[contains(@class, 'bristol-west-bundle-icon bristol-west-bundle-body')]//p")
	private PWElement bWDescriptionOnAutoPage;
	@PWFindBy(xpath = "//div[contains(@class, 'thank-you__title')]//h1")
	private PWElement thankYouTitleForBindDisabledBundle;
	@PWFindBy(xpath = "//div[contains(@class, 'thank-you__subtitle')]//p")
	private PWElement thankYouSubTitleForBindDisabledBundle;
	@PWFindBy(css = "button[class='bundle-quote-button tui-btn tui-btn-primary']")
	private PWElement nextReviewAutoCoveragesButton;

	public AceBundleReviewQuotesPage() throws Exception {
	}

	public void verifyBundleReviewQuotePageContent(String propertyBundle, AceBundleApplicant bundleApplicant, FarmersSoftAssert fsa) throws Exception {
		// Checking element visibility condition as Thank you page for bind disabled quotes have some common components same as bundle page
		if (isElementVisible(continueToNextPageButton,2)) {
			fsa.assertEquals(getTextFromElement(bundleReviewQuotesPageTitle), "Here are your quotes", "Bundle quote review page title verification");
			fsa.assertEquals(getTextFromElement(bundleReviewQuotesPageSubtitle), "On the following pages, you can review your coverage details and choose what's right for you.", "Bundle quote review page subtitle verification");

			// verify savings when bundle
			String expectedTotalSavingsWhenBundleText = "Up to " + getTotalBundleSavingsAmountPerMonth() + " in savings when you bundle";
			fsa.assertTrue(getTextFromElement(savingsAppliedWhenBundleText).contains(expectedTotalSavingsWhenBundleText), expectedTotalSavingsWhenBundleText + " text validation");

			// We defined this as a condition to trigger BW flow
			if (bundleApplicant.getAutoApplicant().getContinuosInsurancePeriod().equals(NEVER_INSURED)) {
				verifyBWRelatedItems(fsa);
			}
			verifyBundleDiscounts(propertyBundle, fsa);
			String separator = isSafariBrowser()? EMPTY_STRING : SPACE;
			fsa.assertEquals(getTextFromElement(paymentFlexibilityLabel), "Payment flexibility"+ separator + "You can mix or match your policy payplans.", "Payment flexibility label verification");
			verifyWantOneOfThePoliciesPopUpModal(propertyBundle, fsa);
			validateAssignedAgentSection(this, fsa);
		} else {
			String expectedThankYouTitleTextForBindDisabled = "Thank you for choosing Farmers Insurance\u00ae";
			String expectedThankYouSubTitleTextForBindDisabled = "You've completed your quote! If you'd like to purchase, please give us a call." +
					" We can keep your current discounts, and check for additional savings.";
			fsa.assertEquals(getTextFromElement(thankYouTitleForBindDisabledBundle), expectedThankYouTitleTextForBindDisabled, "Thank you screen title validation for the bind disabled quote");
			fsa.assertEquals(getTextFromElement(thankYouSubTitleForBindDisabledBundle), expectedThankYouSubTitleTextForBindDisabled, "Thank you screen sub title validation for the bind disabled quote");
		}
		fsa.assertEquals(getTextFromElement(bundleReviewQuotePageSummaryHeader), "Bundled quote summary", "Bundle quote review page summary title verification");
		fsa.assertEquals(getTextFromElement(monthlyAutopayColumnTitle), "Monthly autopay", "Bundle summary monthly autopay column title verification");
		fsa.assertEquals(getTextFromElement(payInFullColumnTitle), "Pay in full", "Bundle summary pay in full column title verification");
		List<String> expectedBundleLOBs = List.of(AUTO, propertyBundle, "Total");
		if (propertyBundle.equals(HOME_TO_AUTO)) {
			expectedBundleLOBs = List.of(AUTO, HOME, "Total");
		}
		fsa.assertEquals(getTextFromListOfWebElementsAndDescendents(listOfBundleLOBs), expectedBundleLOBs, "Listed bundles column content verification");		validateEmailThisQuoteLinkOnBundleReviewQuotePage(bundleApplicant.getAutoApplicant().getEmail(), fsa);
		verifyTermLabels(bundleApplicant, fsa);
		verifySummaryDescriptionLabels(bundleApplicant.getAutoApplicant(), fsa);
		if (isShortcutToPurchaseState(bundleApplicant.getAutoApplicant().getStateCode())) {
			verifyIndividualQuoteEditLabels(fsa);
		}
		if (!bundleApplicant.getAutoApplicant().getStateCode().equals(CA)) {
			if (propertyBundle.equals(HOME_TO_AUTO)) {
				validateStepperFunctionsHomeToAutoBundle(propertyBundle, fsa);
			} else {
				validateStepperFunctions(propertyBundle, fsa);
			}
		}
	}

	public String getTotalBundleSavingsAmountPerMonth() throws Exception {
		AppStore appStore = getSessionStorageAppStore();
		Double autoBundleSavings = Double.parseDouble(appStore.getAuto().getQuote().getAutoBundleSavings());
		Double homeBundleSavings = Double.parseDouble(appStore.getHome().getQuote().getHomeBundleSavings());
		Double totalBundleSavings = autoBundleSavings + homeBundleSavings;
		String totalBundleSavingsInCurrencyByMonthly = CurrencyFormat.convertDoubleToCurrencyString(totalBundleSavings) + "/mo";
		return totalBundleSavingsInCurrencyByMonthly;
	}

	public void clickNextButton() {
		scrollAndClickOnElement(continueToNextPageButton);
		waitForSpinnerToBeGone();
	}

	public boolean isOnBundleReviewQuotesPage() {
		waitForSkeletonToBeGone();
		return isElementDisplayed(bundleReviewQuotePageSummaryHeader, 5);
	}

	protected void verifyBWRelatedItems(FarmersSoftAssert fsa) throws Exception {
		fsa.assertTrue(listOfProviderDescriptionLabels.size()==2, "Provider labels for each LOB found");
		fsa.assertTrue(listOfProviderLogos.size()==2, "Provider logos for each LOB found");
		fsa.assertEquals(getTextFromElement(listOfProviderDescriptionLabels.get(0)), "Auto policy insured and serviced by Bristol West, a Farmers company", "Auto policy provided by BW verification");
		fsa.assertTrue(getAttributeData(listOfProviderLogos.get(0), SRC).contains("bristol"), "BW logo verification");
		fsa.assertEquals(getTextFromElement(listOfProviderDescriptionLabels.get(1)), "Property policy insured and serviced by Farmers", "Property policy provided by Farmers verification");
		fsa.assertTrue(getAttributeData(listOfProviderLogos.get(1), SRC).contains("farmers"), "Farmers logo verification");
	}

	private void verifyTermLabels(AceBundleApplicant bundleApplicant, FarmersSoftAssert fsa) {
		fsa.assertTrue(listOfBundleSummaryTermLabels.size()==2, "Term labels for each LOB found");
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("LLL d, yyyy");
		// CA Auto policies are always 15 days from today...
		LocalDate autoPolicyStartDate = bundleApplicant.getAutoApplicant().getStateCode().equals(CA)? LocalDate.now().plusDays(15) :
			LocalDate.parse(bundleApplicant.getAutoApplicant().getCurrentInsuranceExpirationDate(), DateTimeFormatter.ofPattern("MMddyyyy"));
		String autoTermLabel = "6-month term: " + autoPolicyStartDate.format(dateFormatter) + " - " + autoPolicyStartDate.plusMonths(6).format(dateFormatter);
		fsa.assertEquals(getTextFromElement(listOfBundleSummaryTermLabels.get(0)), autoTermLabel, "Auto Term label verification");

		LocalDate propertyPolicyStartDate = LocalDate.parse(bundleApplicant.getHrcApplicant().getEarlyShoppingFactor(), DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		String propertyTermLabel = "12-month term: " + propertyPolicyStartDate.format(dateFormatter) + " - " + propertyPolicyStartDate.plusYears(1).format(dateFormatter);
		fsa.assertEquals(getTextFromElement(listOfBundleSummaryTermLabels.get(1)), propertyTermLabel, "Property Term label verification");
	}

	protected void verifySummaryDescriptionLabels(AutoApplicant autoApplicant, FarmersSoftAssert fsa) {
		fsa.assertTrue(listOfBundleSummaryDescriptionLabels.size()==2, "Description labels for each LOB found");
		// Because of ADPF data we can't assert vehicle + driver count with confidence, so only verifying address
		fsa.assertEquals(getTextFromElement(listOfBundleSummaryDescriptionLabels.get(1)).toUpperCase(), autoApplicant.getResidentAddress().toUpperCase() + ", " + autoApplicant.getCity().toUpperCase() + ", " + autoApplicant.getStateCode() + SPACE + autoApplicant.getZipCode(), "Property description label verification");
	}

	private void verifyIndividualQuoteEditLabels(FarmersSoftAssert fsa) {
		fsa.assertTrue(listOfQuoteReviewEditUpdateButtons.size()==2, "Edit/Update buttons for each LOB found");
		fsa.assertEquals(getTextFromElement(listOfQuoteReviewEditUpdateButtons.get(0)), "Review & Edit", "Review/Edit auto policy button label verification");
		fsa.assertEquals(getTextFromElement(listOfQuoteReviewEditUpdateButtons.get(1)), "Review & Edit", "Review/Edit property policy button label verification");
	}

	protected void verifyBundleDiscounts(String propertyBundle, FarmersSoftAssert fsa) throws Exception {
		String expectedBundleDiscountName = (propertyBundle.equals(HOME_TO_AUTO) || !listOfProviderLogos.isEmpty()) ?
				                                                             "Auto & Home" : "Auto & " + propertyBundle;
		fsa.assertTrue(listOfLOBDiscountsLinks.size()==2, "Discount links for each LOB found");
		AppStore appStore = getSessionStorageAppStore();
		int totalAppliedAutoDiscountCont;
		int totalAppliedHomeDiscountCount;
		if(isOnBundleReviewQuotesPage()){
			totalAppliedAutoDiscountCont = appStore.getAuto().getQuote().getEft().getRateQuoteResponse().getPersAutoPolicy().getDiscount().size();
			totalAppliedHomeDiscountCount = appStore.getHome().getQuote().getRateQuoteResponses().get(0).getPersHomePolicy().getDiscount().size();
		}else{
			totalAppliedAutoDiscountCont = filterOutAppStoreDiscounts(appStore).size();
			totalAppliedHomeDiscountCount = appStore.getHome().getVerifyResponse().getDiscounts().size();
		}

		fsa.assertEquals(getTextFromElement(listOfLOBDiscountsLinks.get(0)), totalAppliedAutoDiscountCont + " auto discounts applied", "Auto discounts label found");
		clickElement(listOfLOBDiscountsLinks.get(0));
		fsa.assertEquals(getTextFromElement(discountsSideSheetAppliedText), String.format("Applied (%s)", totalAppliedAutoDiscountCont), "Auto applied discounts validation in discount side sheet");
		List<String> appliedAutoDiscountNames = discountsNameInSideSheet.stream().map(this::getTextFromElement).map(String::strip).collect(Collectors.toList());
		fsa.assertTrue(appliedAutoDiscountNames.contains(expectedBundleDiscountName), expectedBundleDiscountName + " bundle discount listed - Auto");
		clickElement(closeIconDiscountsSideSheet);
		String lobText = propertyBundle.equals(HOME_TO_AUTO)? "home" : propertyBundle.toLowerCase();
		fsa.assertEquals(getTextFromElement(listOfLOBDiscountsLinks.get(1)), totalAppliedHomeDiscountCount + " " + lobText + " discounts applied", propertyBundle + " discounts label found");
		clickElement(listOfLOBDiscountsLinks.get(1));
		fsa.assertEquals(getTextFromElement(discountsSideSheetAppliedText), String.format("Applied (%s)", totalAppliedHomeDiscountCount), "Auto & " + propertyBundle + " applied discounts validation in discount side sheet");
		List<String> appliedHomeDiscountNames = discountsNameInSideSheet.stream().map(this::getTextFromElement).map(String::strip).collect(Collectors.toList());
		fsa.assertTrue(appliedHomeDiscountNames.contains("Auto & Home"),  "Auto & Home bundle discount name validation - " + propertyBundle);
		clickElement(closeIconDiscountsSideSheet);
		waitElementBeInvisible(discountsSideSheetAppliedText);
	}

	private List<String> filterOutAppStoreDiscounts(AppStore appStore){
		List<String> notApplicableDiscounts = Arrays.asList("Comp Without Call Factor", "Motorcycle  Surcharge", "Permissive User Factor", "SR22 Surcharge",
				"Vehicle History Factor - Damage Type 1", "Vehicle History Factor - Damage Type 2", "Vehicle History Factor - Junk Title",
				"Vehicle History Factor - Theft", "Vehicle History Factor - Title Issue");

		List<String> listOfAppStoreDiscount = appStore.getAuto().getVerifyResponse().getDiscounts().stream().map(i -> i.getName()).collect(Collectors.toList());
		listOfAppStoreDiscount.removeAll(notApplicableDiscounts);
		return listOfAppStoreDiscount;
	}

	private void verifyWantOneOfThePoliciesPopUpModal(String propertyBundle, FarmersSoftAssert fsa) throws Exception {
		String expectedWantOneOfThePoliciesLinkText = "I only want one of the policies";
		fsa.assertEquals(getTextFromElement(wantOneOfThePoliciesLink), expectedWantOneOfThePoliciesLinkText, expectedWantOneOfThePoliciesLinkText + " link text validation");
		verifyContentOfChangePoliciesPopUp(propertyBundle, fsa);
	}

	private void verifyContentOfChangePoliciesPopUp(String propertyBundle, FarmersSoftAssert fsa) throws Exception {
		clickWantOneOfThePoliciesLink();
		waitElementBeVisible(changePoliciesContentInCPPopUpModal);
		String expectedChangePoliciesHeader = "Change policies";
		fsa.assertEquals(getTextFromElement(changePoliciesHeaderInCPPopUpModal), expectedChangePoliciesHeader, expectedChangePoliciesHeader + " header text validation");
		String expectedChangePoliciesPopUpContent = "Don't want to purchase a bundle just yet? Select the policy you want to purchase now:";
		fsa.assertEquals(getTextFromElement(changePoliciesContentInCPPopUpModal), expectedChangePoliciesPopUpContent, "Change policies pop up modal content validation");
		fsa.assertTrue(pleaseSelectOneHeaderInCPPopUpModal.isDisplayed(), "Please select one header validation");
		fsa.assertEquals(policyOptionsRadioButtonsInCPPopUpModal.size(), 3, "Available policies options in change policies pop up modal");

		try {
			AppStore appStore = getSessionStorageAppStore();
			AppStore.Auto auto = appStore.getAuto();
			double monthlyAutoBundlePremium = getMonthlyAutoBundlePremium(auto);
			double monthlyAutoMonoLinePremium = getMonthlyAutoMonoLinePremium(auto);
			double monoLineVsBundleMonthlyAutoPremiumDifference = Precision.round((monthlyAutoMonoLinePremium - monthlyAutoBundlePremium), 2);

			AppStore.Home home = appStore.getHome();
			double monthlyHomeBundlePremium = getMonthlyHomeBundlePremium(home, propertyBundle);
			double monthlyHomeMonoLinePremium = getMonthlyHomeMonoLinePremium(home, propertyBundle);
			double monoLineVsBundleMonthlyHomePremiumDifference = Precision.round((monthlyHomeMonoLinePremium - monthlyHomeBundlePremium), 2);

			double totalMonthlyAutoHomeBundlePremium = Precision.round((monthlyAutoBundlePremium + monthlyHomeBundlePremium), 2);
			double totalPremiumSavingsWithBundle = Precision.round((monoLineVsBundleMonthlyAutoPremiumDifference + monoLineVsBundleMonthlyHomePremiumDifference), 2);

			List<String> foundPolicyOptionsLabelsInCPPopUpModal = policyOptionsLabelsInCPPopUpModal.stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());
			double observedMonthlyAutoMonoLinePremium = Double.parseDouble(foundPolicyOptionsLabelsInCPPopUpModal.get(0).replaceAll(NON_DIGITS_AND_PERIOD, EMPTY_STRING));
			double observedMonthlyHomeMonoLinePremium = Double.parseDouble(foundPolicyOptionsLabelsInCPPopUpModal.get(1).replaceAll(NON_DIGITS_AND_PERIOD, EMPTY_STRING));
			double observedTotalMonthlyAutoHomeBundlePremium = Double.parseDouble(foundPolicyOptionsLabelsInCPPopUpModal.get(2).replaceAll(NON_DIGITS_AND_PERIOD, EMPTY_STRING));

			fsa.assertTrue(amountsAreEqual(observedMonthlyAutoMonoLinePremium, monthlyAutoMonoLinePremium), "Monthly auto policy premium is correct");
			fsa.assertTrue(amountsAreEqual(observedMonthlyHomeMonoLinePremium, monthlyHomeMonoLinePremium), "Monthly property policy premium is correct");
			fsa.assertTrue(amountsAreEqual(observedTotalMonthlyAutoHomeBundlePremium, totalMonthlyAutoHomeBundlePremium), "Monthly bundle premium is correct");

			String changePoliciesAutoAmountString = "Auto policy (" + CurrencyFormat.convertDoubleToCurrencyString(observedMonthlyAutoMonoLinePremium) + "/mo)";
			String changePoliciesHomeAmountString = propertyBundle + " policy (" + CurrencyFormat.convertDoubleToCurrencyString(observedMonthlyHomeMonoLinePremium) + "/mo)";
			String changePoliciesBundleAmountString = "Let's keep bundle (" + CurrencyFormat.convertDoubleToCurrencyString(observedTotalMonthlyAutoHomeBundlePremium) + "/mo)";

			List<String> expectedPolicyOptionsLabelsInCPPopUpModal = Arrays.asList(changePoliciesAutoAmountString, changePoliciesHomeAmountString, changePoliciesBundleAmountString);
			fsa.assertEquals(foundPolicyOptionsLabelsInCPPopUpModal, expectedPolicyOptionsLabelsInCPPopUpModal, "Change policies radio button label validation in change policies modal pop up");

			List<String> foundPremiumComparisonDescriptionsInCPPopUpModal = discountAmountInCPPopUpModal.stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());
			// DE251981 If auto or property lob savings is less than or equal to zero, then both auto and property lob savings will be hidden.
			// Only conduct this verification when all 3 comparisons are present
			if (foundPremiumComparisonDescriptionsInCPPopUpModal.size() == 3) {
				double observedAutoBundleVsMonoLineComparisonPremium = Double.parseDouble(foundPremiumComparisonDescriptionsInCPPopUpModal.get(0).replaceAll(NON_DIGITS_AND_PERIOD, EMPTY_STRING));
				double observedHomeBundleVsMonoLineComparisonPremium = Double.parseDouble(foundPremiumComparisonDescriptionsInCPPopUpModal.get(1).replaceAll(NON_DIGITS_AND_PERIOD, EMPTY_STRING));
				double observedTotalPremiumSavingsWithBundle = Double.parseDouble(foundPremiumComparisonDescriptionsInCPPopUpModal.get(2).replaceAll(NON_DIGITS_AND_PERIOD, EMPTY_STRING));

				fsa.assertTrue(amountsAreEqual(observedAutoBundleVsMonoLineComparisonPremium, monoLineVsBundleMonthlyAutoPremiumDifference), "Monthly auto policy premium with no discount is correct");
				fsa.assertTrue(amountsAreEqual(observedHomeBundleVsMonoLineComparisonPremium, monoLineVsBundleMonthlyHomePremiumDifference), "Monthly property policy premium with no discount is correct");
				fsa.assertTrue(amountsAreEqual(observedTotalPremiumSavingsWithBundle, totalPremiumSavingsWithBundle), "Monthly bundle savings is correct");

				String autoPremiumHigherWithoutBundleDiscount = CurrencyFormat.convertDoubleToCurrencyString(observedAutoBundleVsMonoLineComparisonPremium) + "/mo higher without a bundle discount";
				String homePremiumHigherWithoutBundleDiscount = CurrencyFormat.convertDoubleToCurrencyString(observedHomeBundleVsMonoLineComparisonPremium) + "/mo higher without a bundle discount";
				String totalPremiumSavingsWithBundleDiscount = CurrencyFormat.convertDoubleToCurrencyString(observedTotalPremiumSavingsWithBundle) + "/mo in savings with a bundle discount";
				List<String> expectedPremiumComparisonDescriptionsInCPPopUpModal = Arrays.asList(autoPremiumHigherWithoutBundleDiscount, homePremiumHigherWithoutBundleDiscount, totalPremiumSavingsWithBundleDiscount);
				fsa.assertEquals(foundPremiumComparisonDescriptionsInCPPopUpModal, expectedPremiumComparisonDescriptionsInCPPopUpModal, "Premium difference description validation in change policies modal pop up");
			}
			PWElement defaultSelectedRadioButtonOptionInCPPopUpModal = policyOptionsRadioButtonsInCPPopUpModal.stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).collect(Collectors.toList()).get(0);
			fsa.assertEquals(getTextFromElement(defaultSelectedRadioButtonOptionInCPPopUpModal), changePoliciesBundleAmountString, "Let's keep bundle radio button selected by default in change policies modal pop up");

			fsa.assertTrue(continueButtonInCPPopUpModal.isDisplayed(), "Continue button displayed in change policies pop up");
			fsa.assertEquals(getTextFromElement(continueButtonInCPPopUpModal), "Continue", "Continue button text validation in change policies pop up");
		} catch (Exception e) {
			fsa.assertTrue(true, "Skipping popup modal amount verification due to " + e.getCause());
		}
		clickContinueButtonInCPPopUpModal();
		fsa.assertTrue(isOnBundleReviewQuotesPage(), "Landed on bundle review quote page validation");
	}

	private boolean amountsAreEqual(double observed, double expected) {
		// Due to the calculations involved, amounts observed and expected may be offset by one cent and still be considered equal.
		boolean amountsAreEqual = Math.abs(Precision.round(observed - expected, 2)) <= 0.01;
		if (!amountsAreEqual) {
			Log.warn("Observed: " + observed + " , Expected: " + expected);
		}
		return amountsAreEqual;
	}

	public double getMonthlyAutoBundlePremium(Auto auto){
		double autoBundleTotalPremium = Double.parseDouble(auto.getQuote().getEft().getTotalPremiumAmount());
		return (double)Math.round(autoBundleTotalPremium/6 * 100.0) / 100.0;
	}

	public double getMonthlyAutoMonoLinePremium(Auto auto) throws Exception {
		double autoMonoLineTotalPremium = Double.parseDouble(auto.getQuote().getMonolineResponse().getTotalPremiumAmount());
		return (double)Math.round(autoMonoLineTotalPremium/6 * 100.0) / 100.0;
	}

	public double getMonthlyHomeMonoLinePremium(Home home, String propertyBundle) throws Exception {
		double homeMonoLineTotalPremium = propertyBundle.equals(HOME) ?
				Double.parseDouble(getTotalPremiumBasedOnSelectedPackage(home.getQuote().getMonolineResponses().get(0).getPersHomePolicy().getPersHomeCoverage(), home)):
					Double.parseDouble(home.getQuote().getMonolineResponses().get(0).getPersHomePolicy().getPersHomeCoverage().getCustomCoverages().getTotalPremium());
		return (double)Math.round(homeMonoLineTotalPremium/12 * 100.0) / 100.0;
	}

	public String getTotalPremiumBasedOnSelectedPackage(Home.PersHomeCoverage persHomeCoverage, Home home) {
		String selectedPackage = home.getQuote().getSelectedPackageCode();
		if(selectedPackage.equals("S")){
			return persHomeCoverage.getStandardCoverages().getTotalPremium();
		}else if(selectedPackage.equals("E")){
			return persHomeCoverage.getEnhancedCoverages().getTotalPremium();
		}else {
			return persHomeCoverage.getPremierCoverages().getTotalPremium();
		}
	}
	public double getMonthlyHomeBundlePremium(Home home, String propertyBundle){
		Home.Quote quote = home.getQuote();
		String selectedPackageCode = quote.getSelectedPackageCode();
		String selectedPaymentMode = quote.getSelectedPaymentMode();
		AppStore.Home.RateQuoteResponse selectedPackageRateQuoteResponse = quote.getRateQuoteResponses().stream().filter(i -> i.getRatePackage().equals(selectedPackageCode) && i.getPaymentMode().equals(selectedPaymentMode)).collect(Collectors.toList()).get(0);
		double homeBundleTotalPremium = propertyBundle.equals(HOME) ?
				Double.parseDouble(getTotalPremiumBasedOnSelectedPackage(selectedPackageRateQuoteResponse.getPersHomePolicy().getPersHomeCoverage(), home)):
					Double.parseDouble(selectedPackageRateQuoteResponse.getPersHomePolicy().getPersHomeCoverage().getCustomCoverages().getTotalPremium());
		return (double)Math.round(homeBundleTotalPremium/12 * 100.0) / 100.0;
	}

	public void validateEmailThisQuoteLinkOnBundleReviewQuotePage(String emailAddress, FarmersSoftAssert fsa) throws Exception {
		clickElement(emailLink);
		scrollToBottomOfPage();
		fsa.assertTrue(isSnackBarMessageDisplayed("A copy of your quote number has been emailed to " + emailAddress),
				this.getClass().getSimpleName() + " - Email sent snack bar message displayed.");
		waitAndClickElement(linkCloseEmailSnackBar);
	}

	public void selectOptionInCPPopup(String option) {
		wait.until(PWExpectedConditions.visibilityOfAllElements(policyOptionsRadioButtonsInCPPopUpModal));
		switch (option) {
			case AUTO:
				clickElement(policyOptionsRadioButtonsInCPPopUpModal.get(0));
				break;
			case HOME:
			case RENTERS:
				clickElement(policyOptionsRadioButtonsInCPPopUpModal.get(1));
				break;
			case BUNDLE:
				clickElement(policyOptionsRadioButtonsInCPPopUpModal.get(2));
				break;
		}
	}

	private void validateStepperFunctions(String bundleType, FarmersSoftAssert fsa) throws Exception {
		if (isElementVisible(continueToNextPageButton,1)) {
			String stepperCheck = " step check";
			List<String> listOfExpectedStepsStrings = List.of(AUTO_INFO, PROPERTY_INFO, REVIEW_QUOTE, PURCHASE);
			fsa.assertEquals(getListOfSteps(), listOfExpectedStepsStrings, "Stepper content");
			fsa.assertEquals(getStepState(AUTO_INFO), ENABLED, AUTO_INFO + stepperCheck);
			fsa.assertEquals(getStepState(PROPERTY_INFO), ENABLED, PROPERTY_INFO + stepperCheck);
			fsa.assertEquals(getStepState(REVIEW_QUOTE), ENABLED, REVIEW_QUOTE + stepperCheck);
			fsa.assertEquals(getStepState(PURCHASE), DISABLED, PURCHASE + stepperCheck);
			selectStepper(PROPERTY_INFO);
			// DE246418 - TSK1 - Ace Auto/home Auto/Renters - User is landing on quality grade page on clicking property info in the stepper.
			if (bundleType.equals(RENTERS)) {
				fsa.assertTrue(new AceHomeContactInfoPage().isOnBundlePolicyStartDatePage(), "Stepper navigated to Renters policy start date page");
			} else {
				fsa.assertTrue(new AceHRCQualityGradeBasePage().isOnQualityGradePage(), "Stepper navigated to Home quality grade page");
			}
			// DE248873 - Have to traverse the quote again to generate a re-rate in case customer changes anything, so we can only go back.
			fsa.assertEquals(getStepState(AUTO_INFO), ENABLED, AUTO_INFO + stepperCheck);
			fsa.assertEquals(getStepState(PROPERTY_INFO), ENABLED, PROPERTY_INFO + stepperCheck);
			fsa.assertEquals(getStepState(REVIEW_QUOTE), DISABLED, REVIEW_QUOTE + stepperCheck);
			fsa.assertEquals(getStepState(PURCHASE), DISABLED, PURCHASE + stepperCheck);
			selectStepper(AUTO_INFO);
			fsa.assertTrue(new WhoShouldWeInsurePage().quickIsOnWhoShouldWeInsurePage() || new HeresWhatWeFoundPage().isOnHeresWhatWeFoundPageShort(), "Stepper navigated to Auto info section");
			fsa.assertEquals(getStepState(AUTO_INFO), ENABLED, AUTO_INFO + stepperCheck);
			fsa.assertEquals(getStepState(PROPERTY_INFO), DISABLED, PROPERTY_INFO + stepperCheck);
			fsa.assertEquals(getStepState(REVIEW_QUOTE), DISABLED, REVIEW_QUOTE + stepperCheck);
			fsa.assertEquals(getStepState(PURCHASE), DISABLED, PURCHASE + stepperCheck);
		}
	}

	private void validateStepperFunctionsHomeToAutoBundle(String bundleType, FarmersSoftAssert fsa) throws Exception {
		if (isElementVisible(continueToNextPageButton,1)) {
			String stepperCheck = " step check";
			List<String> listOfExpectedStepsStrings = List.of(PROPERTY_INFO, AUTO_INFO, REVIEW_QUOTE, PURCHASE);
			fsa.assertEquals(getListOfSteps(), listOfExpectedStepsStrings, "Stepper content (Home to Auto bundle)");
			fsa.assertEquals(getStepState(PROPERTY_INFO), ENABLED, PROPERTY_INFO + stepperCheck);
			fsa.assertEquals(getStepState(AUTO_INFO), ENABLED, AUTO_INFO + stepperCheck);
			fsa.assertEquals(getStepState(REVIEW_QUOTE), ENABLED, REVIEW_QUOTE + stepperCheck);
			fsa.assertEquals(getStepState(PURCHASE), DISABLED, PURCHASE + stepperCheck);
			selectStepper(PROPERTY_INFO);
			if (bundleType.startsWith(RENTERS)) {
				fsa.assertTrue(new AceHomeContactInfoPage().isOnBundlePolicyStartDatePage(), "Stepper navigated to Renters policy start date page");
			} else {
				AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
				fsa.assertTrue(qualityGradePage.isOnPropertyDetailsQualityGradePage(false) || qualityGradePage.isOnQualityGradePage(), "Stepper navigated to Home quality grade page");
			}
			fsa.assertEquals(getStepState(PROPERTY_INFO), ENABLED, PROPERTY_INFO + stepperCheck);
			fsa.assertEquals(getStepState(AUTO_INFO), DISABLED, AUTO_INFO + stepperCheck);
			fsa.assertEquals(getStepState(REVIEW_QUOTE), DISABLED, REVIEW_QUOTE + stepperCheck);
			fsa.assertEquals(getStepState(PURCHASE), DISABLED, PURCHASE + stepperCheck);
		}
	}

	public void clickContinueButtonInCPPopUpModal(){
		clickElement(continueButtonInCPPopUpModal);
	}

	public void clickWantOneOfThePoliciesLink(){
		scrollAndClickOnElement(wantOneOfThePoliciesLink);
	}

	public void selectSingleQuoteOptionInCPPopUp(String lob) {
		clickWantOneOfThePoliciesLink();
		selectOptionInCPPopup(lob);
		clickContinueButtonInCPPopUpModal();
	}

	public void clickReviewUpdateAutoQuote() {
		scrollAndClickOnElement(listOfQuoteReviewEditUpdateButtons.get(0));
		waitForSpinnerToBeGone();
	}

	public void clickReviewUpdatePropertyQuote() {
		scrollAndClickOnElement(listOfQuoteReviewEditUpdateButtons.get(1));
		waitForSpinnerToBeGone();
	}

	public void validateBWLogoOnAutoPagesBWBundleFlow(FarmersSoftAssert fsa) throws Exception {
		String autoInfoOption = "Auto info";
		selectStepper(autoInfoOption);
		DriverReviewPage driverReviewPage = new DriverReviewPage();
		VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
		while (driver().getCurrentUrl().contains("/auto")){
			validateBWLogoAndTextOnBundleAutoPage(fsa, driver().getCurrentUrl());
			if (driverReviewPage.isOnDriverReviewPageQuickCheck()){
				driverReviewPage.clickContinueButton();
			} else if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
				vehicleDriverAssignmentPage.saveAndCheckForNoErrors();
			} else {
				clickContinueButton();
			}
			waitForSpinnerToBeGone();
		}
	}

    public List<String> getAutoDiscounts() {
        scrollAndClickOnElement(listOfLOBDiscountsLinks.get(0));
        return getDiscountsListedInSidesheet();
    }

    public List<String> getPropertyDiscounts() {
        scrollAndClickOnElement(listOfLOBDiscountsLinks.get(1));
        return getDiscountsListedInSidesheet();
    }

	private List<String> getDiscountsListedInSidesheet() {
		waitElementBeVisible(discountsSidesheetTitle);
        List<String> displayedDiscounts = discounts.stream().map(this::getTextFromElement).collect(Collectors.toList());
        Collections.sort(displayedDiscounts);
        waitAndClickElement(closeIcon);
        return displayedDiscounts;
	}

    public void validateBWLogoAndTextOnBundleAutoPage(FarmersSoftAssert fsa, String pageTested){
		fsa.assertTrue(bWLogoAndDescriptionSectionOnAutoPage.isDisplayed(), "BW logo with description displayed in " + pageTested);
		fsa.assertTrue(bWLogoOnAutoPage.isDisplayed(), "BW logo displayed in " + pageTested);
		String expectedBWDescription = "Auto policy insured and serviced by Bristol West, a Farmers company";
		fsa.assertEquals(getTextFromElement(bWDescriptionOnAutoPage), expectedBWDescription, "BW description validation in " + pageTested);
	}

	public void goToDriverMismatchPageFromBundleReviewPageAndValidateBWLogoOnAutoPages(FarmersSoftAssert fsa, AceBundleApplicant aceBundleApplicant) throws Exception {
		AceBundleReviewQuotesPage aceBundleReviewQuotesPage = new AceBundleReviewQuotesPage();
		aceBundleReviewQuotesPage.clickNextButton();
		QuoteSummaryAutoPage autoQuoteSummaryPage = new QuoteSummaryAutoPage();

		if (autoQuoteSummaryPage.isOnQuoteSummaryAutoPage()) {
			validateBWLogoAndTextOnBundleAutoPage(fsa, autoQuoteSummaryPage.getClass().getSimpleName());
			autoQuoteSummaryPage.clickNextToReviewPropertyCoveragePage();
			AceHRCReviewQuoteBasePage propertySummaryQuotePage = new AceHRCReviewQuoteBasePage();
			if (propertySummaryQuotePage.isOnBundlePropertyReviewQuotePage()) {
				propertySummaryQuotePage.clickContinueToMoreCoveragesButton();
				AceHRCAdditionalCoveragesBasePage propertyOptionalCoveragesPage = new AceHRCAdditionalCoveragesBasePage();
				if (propertyOptionalCoveragesPage.isOnBundlePropertyOptionalCoveragesPage()) {
					propertyOptionalCoveragesPage.clickContinueToFinalWrapupButton(true);

					ThankYouPageAce thankYouPage = new ThankYouPageAce();
					if (thankYouPage.quickIsOnThankYouPage()) {
						fsa.assertTrue(thankYouPage.showsBristolWestIcon(), "Bristol West icon displayed in Thank You page");
					} else {
						AdditionalInfoPolicyStartDateOneUI bundleAutoJustAFewMoreThingsPage = new AdditionalInfoPolicyStartDateOneUI();
						if (bundleAutoJustAFewMoreThingsPage.isOnAdditionalInfoPage()) {
							validateBWLogoAndTextOnBundleAutoPage(fsa, bundleAutoJustAFewMoreThingsPage.getClass().getSimpleName());
							bundleAutoJustAFewMoreThingsPage.fillOutAdditionalInfoPage(true);
							DriverMismatchPage driverMismatchPage = new DriverMismatchPage();
							if (driverMismatchPage.isOnDriverMismatchPage()) {
								validateBWLogoAndTextOnBundleAutoPage(fsa, driverMismatchPage.getClass().getSimpleName());
							} else {
								fsa.fail("Did not reach driver mismatch page" + NEWLINE);
							}
						} else {
							fsa.fail("Did not reach additional info page" + NEWLINE);
						}
					}
				} else {
					fsa.fail("Did not reach property optional coverage page" + NEWLINE);
				}
			} else {
				fsa.fail("Did not reach property quote summary page" + NEWLINE);
			}
		} else {
			fsa.fail("Did not reach Auto quote summary page" + NEWLINE);
		}
	}

	public void validatePolicyStartDateAutoHomeFewMoreThingsPage(FarmersSoftAssert fsa, AceBundleApplicant bundleApplicant) throws Exception {
		String hostName = new URL(Property.getUri()).getHost();
		driver().navigate().to("https://" + hostName + "/quote/auto/contact-info");
		String autoPolicyStartDateInContactInfoPage = new ContactInfoAutoPage().getAutoPolicyStartDateValue();
		driver().navigate().to("https://" + hostName + "/quote/home/contact-info");
		String homePolicyStartDateInContactInfoPage = new AceHomeContactInfoPage().getPropertyPolicyStartDateOrEstimatedClosingDateValue();
		selectStepper("Review quote");
		waitForSpinnerToBeGone();
		AceBundleReviewQuotesPage aceBundleReviewQuotesPage = new AceBundleReviewQuotesPage();
		if (aceBundleReviewQuotesPage.isOnBundleReviewQuotesPage()) {
			aceBundleReviewQuotesPage.clickNextButton();
			QuoteSummaryAutoPage autoQuoteSummaryPage = new QuoteSummaryAutoPage();
			if (autoQuoteSummaryPage.isOnQuoteSummaryAutoPage()) {
				autoQuoteSummaryPage.clickNextToReviewPropertyCoveragePage();
				AceHRCReviewQuoteBasePage propertySummaryQuotePage = new AceHRCReviewQuoteBasePage();
				if (propertySummaryQuotePage.isOnBundlePropertyReviewQuotePage()) {
					propertySummaryQuotePage.clickContinueToMoreCoveragesButton();

					AceHRCAdditionalCoveragesBasePage propertyOptionalCoveragesPage = new AceHRCAdditionalCoveragesBasePage();
					if (propertyOptionalCoveragesPage.isOnBundlePropertyOptionalCoveragesPage()) {
						propertyOptionalCoveragesPage.clickContinueToFinalWrapupButton(true);

						AdditionalInfoPolicyStartDateOneUI bundleAutoJustAFewMoreThingsPage = new AdditionalInfoPolicyStartDateOneUI();
						if (bundleAutoJustAFewMoreThingsPage.isOnAdditionalInfoPage()) {
							fsa.assertTrue(autoPolicyStartDateInContactInfoPage.equals(bundleAutoJustAFewMoreThingsPage.getAutoPolicyStartDateInAutoFewMoreThingsPage()),
									"Policy start date validation on auto few more things page");
							bundleAutoJustAFewMoreThingsPage.fillOutAdditionalInfoPage(true);
							AceHRCJustAFewMoreThingsBasePage aceHRCJustAFewMoreThingsBasePage = new AceHRCJustAFewMoreThingsBasePage();
							new ContactInfoAutoPage().waitForRC2ScreenToFinish();
							ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
							if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
								continueWithBristolWestPage.continueWithBwPopUp();
								ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
								contactInfoAutoPage.waitForRC2ScreenToFinish();
								Reporter.pass("Navigated to Bristol West");
								if (continueWithBristolWestPage.isOnThanksForChoosingBristolWestDialog()) {
									continueWithBristolWestPage.closeThanksForChoosingBristolWestDialog();
								}
								if (new KnockoutInconveniencePage().isQuoteKnockedOut()) {
									//Reset page in an attempt to clear issue
									Log.warn("BWAuto quote portion possibly knocked out, attempt to correct issue");
									hostName = new URL(Property.getUri()).getHost();
									driver().navigate().to("https://" + hostName + "/quote/auto/contact-info");
									waitForSpinnerToBeGone();
								}
								driver().navigate().to("https://" + hostName + "/quote/home/additional-info-main");
							}
							fsa.assertTrue(homePolicyStartDateInContactInfoPage.equals(aceHRCJustAFewMoreThingsBasePage.getHomePolicyStartDateInHRCFewMoreThingsPage()),
									"Policy start date validation on HRC few more things page");
						} else {
							fsa.fail("Did not reach auto additional info page" + NEWLINE);
						}
					} else {
						fsa.fail("Did not reach optional coverage page for HRC quote" + NEWLINE);
					}
				} else {
					fsa.fail("Did not reach HRC review quote summary page" + NEWLINE);
				}
			} else {
				fsa.fail("Did not reach Auto quote summary page" + NEWLINE);
			}
		} else {
			fsa.fail("Did not reach bundle quote summary page");
		}
	}
}
