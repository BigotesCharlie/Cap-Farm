package com.farmers.ffq.ace.bundle;


import com.farmers.framework.playwright.compat.*;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.farmers.ffq.ace.home.AceHomeReviewQuotePage;
import com.farmers.ffq.ace.renters.AceRentersReviewQuotePage;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import com.farmers.ffq.datatransferobjects.AceBundleApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceBundleFinalReviewPage extends AceBundleReviewQuotesPage {

    @PWFindBy(xpath = "//div[contains(@class,'final-bundle-header')]//h1")
    private PWElement finalReviewPageTitleElement;

    @PWFindBy(xpath = "//div[contains(@class,'final-bundle-header')]/p")
    private PWElement finalReviewPageSubtitleElement;

    @PWFindBy(xpath = "//app-final-bundle-page//div[contains(@class, 'box ')]/span")
    private PWElement finalReviewPageSummaryTitleElement;

    @PWFindBy(xpath = "//div[@class='tui-stacking-bottom-xs'][2]")
    private List<PWElement> listOfBundleSummaryTermLabels;
    @PWFindBy(xpath = "//button//span[contains(text(), 'Edit auto coverages')]")
    private PWElement editAutoCoveragesLink;
    @PWFindBy(xpath = "//button//span[contains(text(), 'Edit auto coverages')]//mat-icon")
    private PWElement editAutoCoveragesPencilIcon;
    @PWFindBy(xpath = "//button//span[contains(text(), 'Edit home coverages')]")
    private PWElement editHomeCoveragesLink;
    @PWFindBy(xpath = "//button//span[contains(text(), 'Edit home coverages')]//mat-icon")
    private PWElement editHomeCoveragesPencilIcon;

    @PWFindBy(xpath = "//button//span[contains(text(), 'Edit renters coverages')]")
    private PWElement editRentersCoveragesLink;
    @PWFindBy(xpath = "//button//span[contains(text(), 'Edit renters coverages')]//mat-icon")
    private PWElement editRentersCoveragesPencilIcon;

    @PWFindBy(xpath = "//app-final-bundle-page//div[contains(@class,'final-bundle-continue')]//button")
    private PWElement continueToPaymentButton;

    @PWFindBy(xpath = "//img[contains(@alt, 'Bristol West')]")
    PWElement bristolWestLogo;

    public AceBundleFinalReviewPage() throws Exception {
        super();
    }

    public boolean isOnFinalReviewPage() {
        return isElementDisplayed(finalReviewPageTitleElement, 15);
    }

    public void verifyBundleFinalReviewQuotePageContent(AceBundleApplicant bundleApplicant, String propertyBundle, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(finalReviewPageTitleElement), "Ready to buy?", "Final review page title verification");
        fsa.assertEquals(getTextFromElement(finalReviewPageSubtitleElement), "Based on third-party information and information you provided, your rate may have changed from our initial quote. If you'd like, you can change your coverage options below.", "Final review page subtitle verification");
        fsa.assertEquals(getTextFromElement(finalReviewPageSummaryTitleElement), "Bundled quote summary", "Final review page summary title verification");
        // We defined this as a condition to trigger BW flow
        if (bundleApplicant.getAutoApplicant().getContinuosInsurancePeriod().equals(NEVER_INSURED)) {
            verifyBWRelatedItems(fsa);
        }
        verifyTermLabels(bundleApplicant, fsa);
        verifySummaryDescriptionLabels(bundleApplicant.getAutoApplicant(), fsa);
        //BW discounts are not matching appstore, removing check
        if (!isElementDisplayed(bristolWestLogo, 2)) {
            verifyBundleDiscounts(propertyBundle, fsa);
        }
        String separator = isSafariBrowser() ? EMPTY_STRING : SPACE;
        fsa.assertEquals(getTextFromElement(paymentFlexibilityLabel), "Payment flexibility" + separator + "You can mix or match your policy payplans.", "Payment flexibility label verification");
        fsa.assertEquals(getTextFromElement(buttonContinue), "Continue to payment", "Continue button label verification");
        verifyEditCoveragesLink(propertyBundle, fsa);
    }

    private void verifyTermLabels(AceBundleApplicant bundleApplicant, FarmersSoftAssert fsa) throws Exception {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("LLL d, yyyy");
        LocalDate autoPolicyStartDate = LocalDate.parse(bundleApplicant.getAutoApplicant().getCurrentInsuranceExpirationDate(), DateTimeFormatter.ofPattern("MMddyyyy"));
        LocalDate propertyPolicyStartDate = getFormattedDateFromStringDate(getSessionStorageAppStore().getHome().getContactInfo().getPolicyStartDate());
        String autoTermLabel = "6-month term: " + autoPolicyStartDate.format(dateFormatter) + " - " + autoPolicyStartDate.plusMonths(6).format(dateFormatter);
        String propertyTermLabel = "12-month term: " + propertyPolicyStartDate.format(dateFormatter) + " - " + propertyPolicyStartDate.plusYears(1).format(dateFormatter);
        fsa.assertTrue(listOfBundleSummaryTermLabels.size() == 2, "Term labels for each LOB found");
        fsa.assertEquals(getTextFromElement(listOfBundleSummaryTermLabels.get(0)), autoTermLabel, "Auto Term label verification");
        fsa.assertEquals(getTextFromElement(listOfBundleSummaryTermLabels.get(1)), propertyTermLabel, "Property Term label verification");
    }

    private void verifyEditCoveragesLink(String propertyBundle, FarmersSoftAssert fsa) throws Exception {
        PWElement linkToCheck = editHomeCoveragesLink;
        PWElement iconToCheck = editHomeCoveragesPencilIcon;
        if (propertyBundle.equals(RENTERS)) {
            linkToCheck = editRentersCoveragesLink;
            iconToCheck = editRentersCoveragesPencilIcon;
        }
        fsa.assertTrue(editAutoCoveragesLink.isDisplayed(), "Edit auto coverages link verification");
        fsa.assertTrue(editAutoCoveragesPencilIcon.isDisplayed(), "Edit auto coverage pencil icon verification");
        fsa.assertTrue(linkToCheck.isDisplayed(), "Edit " + propertyBundle + " coverages link verification");
        fsa.assertTrue(iconToCheck.isDisplayed(), "Edit " + propertyBundle + " coverages icon verification");
        QuoteSummaryAutoPage autoQuoteSummaryPage = new QuoteSummaryAutoPage();
        clickElement(editAutoCoveragesLink);
        waitForSpinnerToBeGone();
        if (autoQuoteSummaryPage.quickIsOnQuoteSummaryAutoPage()) {
            autoQuoteSummaryPage.verifyAutoEditLiabilityCoverageInBundleFlow(fsa);
            autoQuoteSummaryPage.verifyAutoEditVehicleCoverageInBundleFlow(fsa);
            loadFinalBundleReviewPage();
            verifyLandedOnPropertyReviewCovPageOnClickingEditAutoCovLink(propertyBundle, fsa);
        } else {
            fsa.fail("Did not reach edit auto coverages page");
        }
    }

    private void verifyLandedOnPropertyReviewCovPageOnClickingEditAutoCovLink(String propertyBundle, FarmersSoftAssert fsa) throws Exception {
        PWElement linkToClick = propertyBundle.equals(RENTERS) ? editRentersCoveragesLink : editHomeCoveragesLink;
        clickElement(linkToClick);
        waitForSpinnerToBeGone();
        waitForSkeletonToBeGone();
        fsa.assertTrue(propertyBundle.equals(RENTERS) ? new AceRentersReviewQuotePage().isOnReviewQuotePageAceRenters() : new AceHomeReviewQuotePage().isOnBundlePropertyReviewQuotePage()
                , "Navigated to " + propertyBundle + " review quote page");
        loadFinalBundleReviewPage();
    }

    private void loadFinalBundleReviewPage() throws Exception {
        String hostName = new URL(Property.getUri()).getHost();
        driver().navigate().to("https://" + hostName + "/quote/final-bundle-review");
        waitForSpinnerToBeGone();
    }

    public void clickContinueToPaymentButton() throws Exception {
        clickElement(continueToPaymentButton);
    }
}
