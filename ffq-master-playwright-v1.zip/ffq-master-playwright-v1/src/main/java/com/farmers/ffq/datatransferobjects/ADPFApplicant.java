package com.farmers.ffq.datatransferobjects;
import java.util.List;

import lombok.Data;

@Data
public class ADPFApplicant {
	private int householdNumber;
	private int numberOfDrivers;
	private int numberOfVehicles;
	private int numberOfIncompleteVehicles;
	private int numberOfIncompleteDrivers;
	private String firstName;
	private String lastName;
	private String dateOfBirth;
	private String gender;
	private String address;
	private String city;
	private String stateCode;
	private String zipCode;
	private String currentInsuranceExpirationDate;
	private List<ADPFApplicant> listOfAdditionalApplicants;
	private List<Vehicle> listOfApplicantVehicles;

	@Override
	public String toString() {
		return String.format("%s %s %s %s %s %s", firstName, lastName, address, city, stateCode, zipCode);
	}

	public String dump() {
		StringBuilder dataString = new StringBuilder("APPLICANT: " +
				firstName + "," +
				lastName + "," +
				dateOfBirth + "," +
				gender + "," +
				address + "," +
				city + "," +
				stateCode + "," +
				zipCode + "," +
				householdNumber + "," +
				numberOfDrivers + "," +
				numberOfVehicles + "," +
				numberOfIncompleteVehicles + "," +
				numberOfIncompleteDrivers + "," +
				currentInsuranceExpirationDate + " ");
		if(listOfAdditionalApplicants!= null && !listOfAdditionalApplicants.isEmpty()) {
			for (int i=0; i < listOfAdditionalApplicants.size(); i++) {
				dataString.append("ADDITIONAL DRIVER " + i + ": " +
						listOfAdditionalApplicants.get(i).firstName + "," +
						listOfAdditionalApplicants.get(i).lastName + "," +
						listOfAdditionalApplicants.get(i).dateOfBirth + "," +
						listOfAdditionalApplicants.get(i).gender + " ");
			}
		}
		if(listOfApplicantVehicles != null && !listOfApplicantVehicles.isEmpty()) {
			for (int i=0; i < listOfApplicantVehicles.size(); i++) {
				dataString.append("VEHICLE " + i + ": " +
						listOfApplicantVehicles.get(i).getVehicleId() + "," +
						listOfApplicantVehicles.get(i).getAdditionalDriverId() + "," +
						listOfApplicantVehicles.get(i).getVehicleYear() + "," +
						listOfApplicantVehicles.get(i).getVehicleMake() + "," +
						listOfApplicantVehicles.get(i).getVehicleModel() + "," +
						listOfApplicantVehicles.get(i).getVehicleVIN() + "," +
						listOfApplicantVehicles.get(i).getVehicleType() + "," +
						listOfApplicantVehicles.get(i).getOwnership() + "," +
						listOfApplicantVehicles.get(i).getPurchaseDate() + "," +
						listOfApplicantVehicles.get(i).getVehicleUsage() + "," +
						listOfApplicantVehicles.get(i).isRidesharing() + "," +
						listOfApplicantVehicles.get(i).isParkInResidentAddress() + "," +
						listOfApplicantVehicles.get(i).isAlternativeFuels() + "," +
						listOfApplicantVehicles.get(i).isPassiveRestraint() + "," +
						listOfApplicantVehicles.get(i).isAntiLockBrakes() + "," +
						listOfApplicantVehicles.get(i).isTheftRecoverySystem() + "," +
						listOfApplicantVehicles.get(i).getLessorStateName() + "," +
						listOfApplicantVehicles.get(i).getLessor() + "," +
						listOfApplicantVehicles.get(i).getCurrentOdometerReading() + "," +
						listOfApplicantVehicles.get(i).getDateOfReading() + " ");
			}
		}
		return dataString.toString();
	}

}
