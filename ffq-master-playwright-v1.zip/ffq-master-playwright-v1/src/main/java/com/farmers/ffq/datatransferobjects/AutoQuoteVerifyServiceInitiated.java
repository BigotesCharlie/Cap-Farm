package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class AutoQuoteVerifyServiceInitiated {
    private List<AutoQuote> autoQuote;
    private RequestHeader requestHeader;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class AutoQuote {
        private PersonalAuto personalAuto;
        private List<Reports> reports;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class PersonalAuto {
            private List<Vehicle> vehicles;
            private List<Driver> drivers;

            @JsonInclude(JsonInclude.Include.NON_NULL)
            @Data
            public static class Vehicle {
                private String odometerReading;
                private String odometerReadingDate;
            }

            @JsonInclude(JsonInclude.Include.NON_NULL)
            @Data
            public static class Driver {
                private String rideSharingIndicator;
                private String relationshipToInsured;
                private String maritalStatus;
                private String nonDriverReason;
                private Boolean customerRNOGConsentInd;
                private Name name;
                private String signal;

                @JsonInclude(JsonInclude.Include.NON_NULL)
                @Data
                public static class Name {
                    private String firstName;
                    private String lastName;
                }
            }
        }

        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class Reports {
            private String code;
            private String value;
        }

    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class RequestHeader {

    }

}
