package com.farmers.ffq.dataproviders;

import com.farmers.ffq.dataproviderframework.DataProviderBase;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.framework.Property;
import com.farmers.framework.data.ExcelDataProvider;
import com.farmers.framework.report.Log;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Synchronized;
import net.datafaker.Faker;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.farmers.ffq.dataproviders.DataProviders.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AutoDataProviders extends DataProviderBase {

    public static final String AUTO_APPLICANT_DATA_PROVIDER = "autoApplicants";

    public static final String RANDOM_AUTO_APPLICANT = "RandomAutoApplicant";
    public static final String AUTO_APPLICANT_FROM_EACH_STATE = "RandomAutoApplicantFromEachState";
    public static final String AUTO_APPLICANTS_FROM_A_FEW_STATES = "AutoApplicantsFromAFewStates";
    public static final String AUTO_APPLICANT_WITH_ONE_VEHICLE = "RandomAutoApplicantWithOneVehicle";
    public static final String SERVICE_VIRTUALIZATION_APPLICANT = "ServiceVirtualizationApplicants";
    public static final String ALL_APPLICANTS = "AllApplicants";
    public static final String AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER = "AutoApplicantTestCategoryDataProvider";
    public static final String RANDOM_ADPF_APPLICANT_DATA_PROVIDER = "RandomADPFApplicantDataProvider";
    public static final String ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER = "ADPFApplicantWithDriverAndVehicleNumberDataProvider";
    public static final String BIND_ADPF_APPLICANT_DATA_PROVIDER = "bindApplicantDataProvider";
    public static final String FINANCIAL_RESPONSIBILITY_APPLICANT = "financialResponsibility";

    private static final String ONEUI_AUTO_APPLICANT_FILE_NAME = "src/test/resources/OneUIAutoTestData.xlsx";
    private static final String AUTO_APPLICANT_DATA = "applicant";
    private static final String ADPF_APPLICANT_DATA = "ADPFApplicant";
    private static final String ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA = "ADPFApplicantVehicleDriverNum";
    private static final String BIND_ONE_UI_APPLICANT_DATA = "bindOneUIApplicant";
    private static final String PAGE_VALIDATION_DATA = "pageValidationApplicant";
    private static final String NO_FILTER = "NO_FILTER";
    private static final String DP_LOG_ENTRY = "=== %s has %d rows of data ===";
    private static final String ASSAULT_WITH_MOTOR_VEHICLE = "Assault";

    static String stateList = Property.getTestProperty("stateList").replaceAll("\\s+", "");
    // List of one UI supported states

    private static final List<String> listOfApplicantStates = !stateList.equals(ALL) ? Arrays.asList(stateList.split(COMMA)) : Property.getTestProperty("isBDQFlow").equals(LOWERCASE_TRUE) ? getBDQEnabledStates() : getListOfAceAutoStates(Property.getUri());

    @Synchronized
    @DataProvider(name = AUTO_APPLICANT_DATA_PROVIDER, parallel = true)
    public static Iterator<AutoApplicant> autoApplicantsIterator(Method m) throws Exception {
    	List<String> listOfApplicableStates = new ArrayList<>(listOfApplicantStates);
    	String filter = setFilterAndListOfValidStates(m, NO_FILTER, listOfApplicableStates);
    	if (listOfApplicableStates.isEmpty()) {
    		throw new SkipException("No applicable states found that match the requested conditions" + NEWLINE);
    	}
    	List<AutoApplicant> listOfAutoApplicants = listOfAutoApplicants(AUTO_APPLICANT_DATA, filter);
    	listOfAutoApplicants.removeIf(autoApplicant -> !listOfApplicableStates.contains(autoApplicant.getStateCode()));
    	List<String> testScenariosFromConfig = new ArrayList<>(getTestScenariosFromConfig());
    	testScenariosFromConfig.removeIf(each -> each.equals(ASSAULT_WITH_MOTOR_VEHICLE));
    	if (!testScenariosFromConfig.isEmpty()) {
    		listOfAutoApplicants.removeIf(each -> !testScenariosFromConfig.contains(each.getTestScenario()));
    		return listOfAutoApplicants.iterator();
    	}

        if (!stateList.equals("all")) {
            listOfAutoApplicants.removeIf(each -> !stateList.contains(each.getStateCode()));
            return listOfAutoApplicants.iterator();
        }

    	//Process testName parameter for post fetch filtering
    	String testCategory = m.getAnnotation(Test.class).testName();
    	if (!testCategory.equals(EMPTY_STRING)) {
    		switch (testCategory) {
    		case RANDOM_AUTO_APPLICANT:
    			setListToRandomApplicant(listOfAutoApplicants);
    			break;
    		case AUTO_APPLICANT_FROM_EACH_STATE:
    			List<AutoApplicant> listOfAnApplicantPerState = new ArrayList<>();
    			// add random applicant for each state
    			for (String stateCode : listOfApplicableStates) {
    				List<AutoApplicant> allApplicantsFromGivenState = new ArrayList<>();
    				allApplicantsFromGivenState.addAll(listOfAutoApplicants);
    				allApplicantsFromGivenState.removeIf((applicant -> !applicant.getStateCode().equals(stateCode)));
    				allApplicantsFromGivenState = allApplicantsFromGivenState.stream().filter(each -> each.getApplicantId() == 1).collect(Collectors.toList());
    				if (allApplicantsFromGivenState.isEmpty()) {
    					// So that we not restrict this to applicant id = 1
        				allApplicantsFromGivenState.addAll(listOfAutoApplicants);
        				allApplicantsFromGivenState.removeIf((applicant -> !applicant.getStateCode().equals(stateCode)));
        				setListToRandomApplicant(allApplicantsFromGivenState);
    				}
    				listOfAnApplicantPerState.addAll(allApplicantsFromGivenState);
    			}
    			listOfAutoApplicants.clear();
    			listOfAutoApplicants.addAll(listOfAnApplicantPerState);
    			break;
    		case AUTO_APPLICANTS_FROM_A_FEW_STATES:
    			Collections.shuffle(listOfApplicableStates);
    			List<AutoApplicant> listOfApplicantsFromAFewStates = new ArrayList<>();
    			for (int index = 0; index < 4 && index < listOfApplicableStates.size(); index++) {
    				String stateCode = listOfApplicableStates.get(index);
    				List<AutoApplicant> allApplicantsFromGivenState = new ArrayList<>();
    				allApplicantsFromGivenState.addAll(listOfAutoApplicants);
    				allApplicantsFromGivenState.removeIf((applicant -> !applicant.getStateCode().equals(stateCode)));
       				setListToRandomApplicant(allApplicantsFromGivenState);
    				listOfApplicantsFromAFewStates.addAll(allApplicantsFromGivenState);
    			}
    			listOfAutoApplicants.clear();
    			listOfAutoApplicants.addAll(listOfApplicantsFromAFewStates);
    			break;
    		case AUTO_APPLICANT_WITH_ONE_VEHICLE:
    			listOfAutoApplicants.removeIf(applicant -> applicant.getSingleVehicle().equals(NO));
    			listOfAutoApplicants.removeIf(applicant -> applicant.getVehicles().size() != 1);
    			setListToRandomApplicant(listOfAutoApplicants);
    			break;
    		case FINANCIAL_RESPONSIBILITY_APPLICANT:
    			listOfAutoApplicants.removeIf(applicant -> !List.of(SR_22, SR_22_ANOTHER_STATE).contains(applicant.getFinancialFiling()));
    			setListToRandomApplicant(listOfAutoApplicants);
    			updateApplicantsForBind(listOfAutoApplicants);
    			break;
    		case SERVICE_VIRTUALIZATION_APPLICANT:
    			List<Integer> listOfServiceVirtualizationApplicantIds = new ArrayList<>(Arrays.asList(1, 2, 6));
    			listOfAutoApplicants.removeIf(applicant -> !listOfServiceVirtualizationApplicantIds.contains(applicant.getApplicantId()));
    			setListToRandomApplicant(listOfAutoApplicants);
    			updateApplicantsForBind(listOfAutoApplicants);
    			break;
    		case ALL_APPLICANTS:
    			updateApplicantsForBind(listOfAutoApplicants);
    		default:
    			break;
    		}
    	}
    	if (listOfAutoApplicants.isEmpty()) {
    		throw new SkipException(NEWLINE + "No applicants found that match the requested conditions" + NEWLINE);
    	}
    	Log.info(String.format("=== AUTO_APPLICANT_DATA_PROVIDER has %d rows of data ===", listOfAutoApplicants.size()));
    	return listOfAutoApplicants.iterator();
    }

    private static void setListToRandomApplicant(List<AutoApplicant> listOfApplicants) {
    	if (!listOfApplicants.isEmpty()) {
    		Collections.shuffle(listOfApplicants);
    		AutoApplicant randomApplicant = listOfApplicants.get(FIRST_AVAILABLE_OPTION);
    		listOfApplicants.clear();
    		listOfApplicants.add(randomApplicant);
    	}
    }

    @DataProvider(name = AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, parallel = true)
    public static synchronized Iterator<AutoApplicant> testCategoryDataProvider(Method method) throws Exception {
        String testCategory = method.getAnnotation(Test.class).suiteName();
        List<AutoApplicant> filteredListOfAutoApplicants = listOfAutoApplicants(PAGE_VALIDATION_DATA, "testCategory=" + testCategory);
        List<String> testScenarios = getTestScenariosFromConfig();
        if (!testCategory.equals("existing customer knockout")) {
        	if (testScenarios.get(FIRST_AVAILABLE_OPTION).contains(ASSAULT_WITH_MOTOR_VEHICLE)) {
        		filteredListOfAutoApplicants = randomlySelectedAutoApplicant(filteredListOfAutoApplicants);
        	} else {
        		filteredListOfAutoApplicants = getTestScenariosFromMultipleStateBind();
        	}
        }
        filteredListOfAutoApplicants.forEach(applicant -> {
            Faker faker = new Faker();
            //applicant.setFirstName(faker.name().firstName());
            applicant.setEmail("testesign_" + RandomStringUtils.randomAlphanumeric(4) + applicant.getLastName().replace(SPACE, EMPTY_STRING) + "@farmers.testinator.com");
            applicant.setPhoneNumber(faker.phoneNumber().phoneNumber().replaceAll("\\D", EMPTY_STRING).strip());
        });
        Log.info(String.format(DP_LOG_ENTRY, AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, filteredListOfAutoApplicants.size()));
        return filteredListOfAutoApplicants.iterator();
    }

    @DataProvider(name = RANDOM_ADPF_APPLICANT_DATA_PROVIDER, parallel = true)
    public static synchronized Object[][] randomADPFApplicant(Method m) throws Exception {
        List<ADPFApplicant> adpfApplicantsList = listOfADPFApplicants(NO_FILTER);
        CustomAttribute[] customAttrs = m.getAnnotation(Test.class).attributes();
        if (customAttrs.length > 0) {
            if (customAttrs[0].name().equals(HOUSEHOLD_NUMBER)) {
                ArrayList<String> validHouseholds = new ArrayList<>(Arrays.asList(customAttrs[0].values()));
                adpfApplicantsList = adpfApplicantsList.stream().filter(applicant -> validHouseholds.contains(Integer.toString(applicant.getHouseholdNumber()))).collect(Collectors.toList());
            }
        }
        int randomRow = randomNumberGenerator.nextInt(adpfApplicantsList.size());
        ADPFApplicant singleADPFAutoApplicant = adpfApplicantsList.get(randomRow);
        List<ADPFApplicant> householdADPFApplicantList = new ArrayList<>();
        for (ADPFApplicant adpfApplicant : adpfApplicantsList) {
            if ((adpfApplicant.getHouseholdNumber() == singleADPFAutoApplicant.getHouseholdNumber()) && (!adpfApplicant.getFirstName().equals(singleADPFAutoApplicant.getFirstName()))) {
                householdADPFApplicantList.add(adpfApplicant);
            }
        }
        singleADPFAutoApplicant.setListOfAdditionalApplicants(householdADPFApplicantList);
        singleADPFAutoApplicant.setListOfApplicantVehicles(getListOfADPFVehicles(singleADPFAutoApplicant.getHouseholdNumber()));
        Object[][] applicant = new Object[1][1];
        applicant[0][0] = singleADPFAutoApplicant;
        return applicant;
    }

    @DataProvider(name = BIND_ADPF_APPLICANT_DATA_PROVIDER, parallel = true)
    public static synchronized Iterator<ADPFApplicant> randomBindADPFApplicant(Method m) throws Exception {
        List<ADPFApplicant> adpfApplicantsList = listOfBindADPFApplicants(NO_FILTER);
        CustomAttribute[] customAttrs = m.getAnnotation(Test.class).attributes();
        if (customAttrs.length > 0) {
            if (customAttrs[0].name().equals(HOUSEHOLD_NUMBER)) {
                ArrayList<String> validHouseholds = new ArrayList<>(Arrays.asList(customAttrs[0].values()));
                adpfApplicantsList = adpfApplicantsList.stream().filter(applicant -> validHouseholds.contains(Integer.toString(applicant.getHouseholdNumber()))).collect(Collectors.toList());
            }
        }
        List<ADPFApplicant> filterAdpfApplicantByState = new ArrayList<>();
        for (String stateCode : listOfApplicantStates) {
            filterAdpfApplicantByState.addAll(adpfApplicantsList.stream().filter(i -> i.getStateCode().equals(stateCode)).collect(Collectors.toList()));
        }
        return filterAdpfApplicantByState.iterator();
    }

    //ADPF filtering options
    public static final String TWELVE_DRIVERS_AND_VEHICLES = "twelveDriversTwelveVehicles";
    public static final String DRIVERS_GT_0 = "driversGT0";
    public static final String DRIVERS_AND_VEHICLES = "driversAndVehicles";
    public static final String DRIVERS_AND_NO_VEHICLES = "driversAndNoVehicles";
    public static final String VEHICLES_AND_DRIVERS_AND_INCOMPLETE_DRIVERS = "vehiclesAndDriversAndIncompleteDrivers";
    public static final String VEHICLES_GT_1 = "vehiclesGT1";
    public static final String DRIVERS_GT_5 = "driversGT5";
    public static final String ONE_TO_FIVE_VEHICLES = "oneToFiveVehicles";
    public static final String NO_INCOMPLETE_DRIVERS_AND_VEHICLES = "noIncompleteDriversVehicles";
    public static final String INCOMPLETE_DRIVERS_AND_VEHICLES = "incompleteDriversVehicles";
    public static final String INCOMPLETE_DRIVERS = "incompleteDrivers";
    public static final String ONE_INCOMPLETE_VEHICLE = "oneIncompleteVehicle";
    public static final String INCOMPLETE_DRIVERS_AND_NO_DRIVERS = "incompleteDriversAndNoDrivers";
    public static final String NO_INCOMPLETE_VEHICLES_AND_LT_FIVE_VEHICLES = "noIncompleteVehiclesAndVehiclesLTFive";

    @DataProvider(name = ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, parallel = true)
    public static synchronized Iterator<ADPFApplicant> adpfApplicantsWithDriverAndVehicleNumber(Method m) throws Exception {
        CustomAttribute[] customAttrs = m.getAnnotation(Test.class).attributes();
        List<ADPFApplicant> listOfADPFApplicants = listOfADPFApplicantsWithDriverAndVehicleNumbers(NO_FILTER);
        // CA is monetized, at least on RA11
        listOfADPFApplicants.removeIf(applicant -> applicant.getStateCode().equals(CA));
        if (customAttrs.length > 0) {
            String attributeName = customAttrs[0].name();
            //AZ and IL data rows are not working for now..
            if (!attributeName.equals(DRIVERS_GT_5)) {
                listOfADPFApplicants.removeIf(applicant -> Arrays.asList(AZ, IL, CA).contains(applicant.getStateCode()));
            }
            switch (attributeName) {
                case TWELVE_DRIVERS_AND_VEHICLES:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfIncompleteVehicles() == 12 && applicant.getNumberOfIncompleteDrivers() == 12).collect(Collectors.toList());
                    break;
                case DRIVERS_GT_0:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfDrivers() > 0).collect(Collectors.toList());
                    break;
                case DRIVERS_GT_5:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfDrivers() > 5).collect(Collectors.toList());
                    break;
                case DRIVERS_AND_VEHICLES:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfDrivers() > 0 && applicant.getNumberOfVehicles() > 0).collect(Collectors.toList());
                    break;
                case DRIVERS_AND_NO_VEHICLES:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfDrivers() > 0 && applicant.getNumberOfVehicles() == 0).collect(Collectors.toList());
                    break;
                case VEHICLES_AND_DRIVERS_AND_INCOMPLETE_DRIVERS:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfVehicles() > 0 && applicant.getNumberOfDrivers() > 1 && applicant.getNumberOfIncompleteDrivers() > 0).collect(Collectors.toList());
                    break;
                case VEHICLES_GT_1:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfVehicles() > 1).collect(Collectors.toList());
                    break;
                case ONE_TO_FIVE_VEHICLES:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfVehicles() >= 1 && applicant.getNumberOfVehicles() <= 5).collect(Collectors.toList());
                    break;
                case INCOMPLETE_DRIVERS:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfIncompleteDrivers() > 0).collect(Collectors.toList());
                    break;
                case NO_INCOMPLETE_DRIVERS_AND_VEHICLES:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfIncompleteDrivers() == 0 && applicant.getNumberOfIncompleteVehicles() == 0).collect(Collectors.toList());
                    break;
                case INCOMPLETE_DRIVERS_AND_VEHICLES:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfIncompleteDrivers() > 0 && applicant.getNumberOfIncompleteVehicles() > 0).collect(Collectors.toList());
                    break;
                case INCOMPLETE_DRIVERS_AND_NO_DRIVERS:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfIncompleteDrivers() > 0 && applicant.getNumberOfDrivers() == 0).collect(Collectors.toList());
                    break;
                case ONE_INCOMPLETE_VEHICLE:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfIncompleteVehicles() == 1).collect(Collectors.toList());
                    break;
                case NO_INCOMPLETE_VEHICLES_AND_LT_FIVE_VEHICLES:
                    listOfADPFApplicants = listOfADPFApplicants.stream().filter(applicant -> applicant.getNumberOfVehicles() > 0 && applicant.getNumberOfVehicles() <= 5 && applicant.getNumberOfIncompleteVehicles() == 0).collect(Collectors.toList());
                    break;
                default:
                    //Randomly pick from entire list of applicants
            }
        }
        if (listOfADPFApplicants.isEmpty()) {
            throw new SkipException("No applicants found that match the requested scenario");
        }
        List<ADPFApplicant> returnedApplicant = new ArrayList<>();
        returnedApplicant.add(listOfADPFApplicants.get(randomNumberGenerator.nextInt(listOfADPFApplicants.size())));
        return returnedApplicant.iterator();
    }

    private static List<Vehicle> getListOfADPFVehicles(int adpfAutoApplicantID) throws Exception {
        List<Vehicle> listOfApplicantVehicles = new ArrayList<>();
        for (Vehicle vehicle : getAllVehicles("ADPFVehicles")) {
            if (vehicle.getApplicantId() == adpfAutoApplicantID) {
                listOfApplicantVehicles.add(vehicle);
            }
        }
        return listOfApplicantVehicles;
    }

    private static List<ADPFApplicant> listOfADPFApplicants(String filter) throws Exception {
        ExcelDataProvider excel = new ExcelDataProvider();
        JSONArray json = filter.equals(NO_FILTER) ? excel.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, ADPF_APPLICANT_DATA, true) : excel.filterJsonData(filter, excel.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, ADPF_APPLICANT_DATA, true));
        return mapJSONToADPFApplicant(json);
    }

    private static List<ADPFApplicant> mapJSONToADPFApplicant(JSONArray json) throws JsonProcessingException {
        List<ADPFApplicant> adpfApplicantsList = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
        for (int i = 0; i < json.length(); i++) {
            String js = json.getJSONObject(i).toString();
            js = js.replace(TRUE, LOWERCASE_TRUE);
            js = js.replace(FALSE, LOWERCASE_FALSE);
            js = js.replace(LOWERCASE_NULL, EMPTY_STRING);
            ADPFApplicant jsonToMappedADPFApplicant = mapper.readValue(js, ADPFApplicant.class);
            adpfApplicantsList.add(jsonToMappedADPFApplicant);
        }
        return adpfApplicantsList;
    }

    private static List<ADPFApplicant> listOfBindADPFApplicants(String filter) throws Exception {
        ExcelDataProvider excel = new ExcelDataProvider();
        JSONArray json = filter.equals(NO_FILTER) ? excel.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, BIND_ONE_UI_APPLICANT_DATA, true) : excel.filterJsonData(filter, excel.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, BIND_ONE_UI_APPLICANT_DATA, true));
        return mapJSONToADPFApplicant(json);
    }

    private static List<ADPFApplicant> listOfADPFApplicantsWithDriverAndVehicleNumbers(String filter) throws Exception {
        ExcelDataProvider excel = new ExcelDataProvider();
        JSONArray json = filter.equals(NO_FILTER) ? excel.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA, true) : excel.filterJsonData(filter, excel.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA, true));
        return mapJSONToADPFApplicant(json);
    }

    private static synchronized List<AutoApplicant> getTestScenariosFromMultipleStateBind() throws Exception {
        List<String> stateCodes = getStateFromConfig();
        List<String> testScenarios = getTestScenariosFromConfig();
        List<AutoApplicant> autoApplicants = new ArrayList<>();
        for (String stateCode : stateCodes) {
            autoApplicants.addAll(listOfAutoApplicants(PAGE_VALIDATION_DATA, "stateCode=" + stateCode));
        }
        return autoApplicants.stream().filter(each -> testScenarios.contains(each.getTestScenario().trim())).collect(Collectors.toList());
    }

    private static List<String> getTestScenariosFromConfig() {
        return Arrays.asList(Property.getTestProperty("testScenario").split(","));
    }

    private static List<String> getStateFromConfig() {
        return Arrays.asList(Property.getTestProperty("stateList").split(","));
    }

    public static synchronized List<AutoApplicant> listOfAutoApplicants(String xlDataSheetName, String filter) throws Exception {
        ExcelDataProvider excel = new ExcelDataProvider();
        JSONArray json = filter.equals(NO_FILTER) ? excel.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, xlDataSheetName, true) : filter.contains("#") ? excel.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, xlDataSheetName, filter.split("#")[1]) : excel.filterJsonData(filter, excel.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, xlDataSheetName, true));
        List<AutoApplicant> applicantList = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
        for (int i = 0; i < json.length(); i++) {
            String js = json.getJSONObject(i).toString();
            js = js.replace(TRUE, LOWERCASE_TRUE);
            js = js.replace(FALSE, LOWERCASE_FALSE);
            js = js.replace(LOWERCASE_NULL, EMPTY_STRING);
            AutoApplicant applicant = mapper.readValue(js, AutoApplicant.class);
            applicantList.add(applicant);
        }
        Iterator<AutoApplicant> applicantListIterator = applicantList.iterator();
        List<Vehicle> listOfVehicles = getAllVehicles("vehicles");
        List<SqlAdditionalDriver> listOfAdditionalDrivers = getAllAdditionalDrivers();
        List<SqlIncident> listOfIncidents = getAllIncidents();
        List<SqlDiscount> listOfDiscounts = getAllDiscounts();
        List<AutoApplicant> autoApplicantList = new ArrayList<>();
        while (applicantListIterator.hasNext()) {
            AutoApplicant applicant = applicantListIterator.next();
            // Set all iterators.
            Iterator<Vehicle> vehicleIterator = listOfVehicles.iterator();
            Iterator<SqlAdditionalDriver> additionalDriversIterator = listOfAdditionalDrivers.iterator();
            Iterator<SqlIncident> incidentsIterator = listOfIncidents.iterator();
            Iterator<SqlDiscount> discountsIterator = listOfDiscounts.iterator();

            // Set all lists.
            List<Vehicle> applicantVehicles = new ArrayList<>();
            List<SqlAdditionalDriver> applicantAdditionalDrivers = new ArrayList<>();
            List<SqlIncident> applicantIncidents = new ArrayList<>();
            List<SqlDiscount> applicantDiscounts = new ArrayList<>();
            // Traverse each list for appropriate data
            while (vehicleIterator.hasNext()) {
                Vehicle vehicle = vehicleIterator.next();
                if (vehicle.getApplicantId() == applicant.getApplicantId()) {
                    applicantVehicles.add(vehicle);
                }
            }
            while (additionalDriversIterator.hasNext()) {
                SqlAdditionalDriver additionalDriver = additionalDriversIterator.next();
                if (additionalDriver.getApplicantId() == applicant.getApplicantId()) {
                    applicantAdditionalDrivers.add(additionalDriver);
                }
            }
            while (incidentsIterator.hasNext()) {
                SqlIncident incident = incidentsIterator.next();
                if (incident.getApplicantId() == applicant.getApplicantId()) {
                    applicantIncidents.add(incident);
                }
            }
            while (discountsIterator.hasNext()) {
                SqlDiscount discount = discountsIterator.next();
                if (discount.getApplicantId() == applicant.getApplicantId()) {
                    applicantDiscounts.add(discount);
                }
            }
            applicant.setVehicles(applicantVehicles);
            // if MA state, disable garaging address due to a defect
            if(applicant.getStateCode().equals(MA)) {
                applicant.getVehicles().forEach(each -> each.setParkInResidentAddress(true));
            }
            applicant.setAdditionalDrivers(applicantAdditionalDrivers);
            applicant.setIncidents(applicantIncidents);
            applicant.setDiscounts(applicantDiscounts);
            //applicant.setFirstName(new Faker().name().firstName());
            String updatedEmail = applicant.getApplicantId() + RandomStringUtils.randomAlphanumeric(15) + "@farmers.testinator.com";
            applicant.setEmail(updatedEmail);
            autoApplicantList.add(applicant);

        }
        List<String> listOfApplicableStates = new ArrayList<>(listOfApplicantStates);
        autoApplicantList.removeIf(applicant -> !listOfApplicableStates.contains(applicant.getStateCode()));
        Log.info(String.format("=== %s worksheet has %d rows of data ===", xlDataSheetName, autoApplicantList.size()));
        return autoApplicantList;
    }

    private static List<Vehicle> getAllVehicles(String vehicleDataSheet) throws Exception {
        ExcelDataProvider excelDP = new ExcelDataProvider();
        JSONArray json = excelDP.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, vehicleDataSheet, true);
        List<Vehicle> allVehicles = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
        for (int j = 0; j < json.length(); j++) {
            String jsObject = json.getJSONObject(j).toString();
            jsObject = jsObject.replace(TRUE, LOWERCASE_TRUE);
            jsObject = jsObject.replace(FALSE, LOWERCASE_FALSE);
            jsObject = jsObject.replace(LOWERCASE_NULL, EMPTY_STRING);
            allVehicles.add(mapper.readValue(jsObject, Vehicle.class));
        }
        return allVehicles;
    }

    private static List<SqlAdditionalDriver> getAllAdditionalDrivers() throws Exception {
        ExcelDataProvider excelDP = new ExcelDataProvider();
        JSONArray json = excelDP.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, "additionalDriver", true);
        List<SqlAdditionalDriver> allAdditionalDriver = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
        for (int j = 0; j < json.length(); j++) {
            String jsObject = json.getJSONObject(j).toString();
            jsObject = jsObject.replace(TRUE, LOWERCASE_TRUE);
            jsObject = jsObject.replace(FALSE, LOWERCASE_FALSE);
            jsObject = jsObject.replace(LOWERCASE_NULL, EMPTY_STRING);
            allAdditionalDriver.add(mapper.readValue(jsObject, SqlAdditionalDriver.class));
        }
        Faker faker = new Faker();
        for (SqlAdditionalDriver additionalDriver : allAdditionalDriver) {
            String firstName = faker.name().firstName();
            additionalDriver.setFirstName(firstName);
            String lastName = faker.name().lastName().replaceAll("[^a-zA-Z]+", "").toLowerCase();
            lastName = StringUtils.capitalize(lastName);
            additionalDriver.setLastName(lastName);
        }
        return allAdditionalDriver;
    }

    private static List<SqlIncident> getAllIncidents() throws Exception {
        ExcelDataProvider excelDP = new ExcelDataProvider();
        JSONArray json = excelDP.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, "incidents", true);
        List<SqlIncident> allIncidents = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
        for (int j = 0; j < json.length(); j++) {
            String jsObject = json.getJSONObject(j).toString();
            jsObject = jsObject.replace(TRUE, LOWERCASE_TRUE);
            jsObject = jsObject.replace(FALSE, LOWERCASE_FALSE);
            jsObject = jsObject.replace(LOWERCASE_NULL, EMPTY_STRING);
            allIncidents.add(mapper.readValue(jsObject, SqlIncident.class));
        }
        return allIncidents;
    }

    private static List<SqlDiscount> getAllDiscounts() throws Exception {
        ExcelDataProvider excelDP = new ExcelDataProvider();
        JSONArray json = excelDP.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, "discounts", true);
        List<SqlDiscount> allDiscounts = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
        for (int j = 0; j < json.length(); j++) {
            String jsObject = json.getJSONObject(j).toString();
            jsObject = jsObject.replace(TRUE, LOWERCASE_TRUE);
            jsObject = jsObject.replace(FALSE, LOWERCASE_FALSE);
            jsObject = jsObject.replace(LOWERCASE_NULL, EMPTY_STRING);
            allDiscounts.add(mapper.readValue(jsObject, SqlDiscount.class));
        }
        return allDiscounts;
    }

    public List<DefaultCoverages> listOfCoveragesAndLiabilities(String sheetName, String coverageAmountFilter) {
        ExcelDataProvider excel = new ExcelDataProvider();
        try {
            JSONArray json = excel.filterJsonData(coverageAmountFilter, excel.getDataJson("src/test/resources/AutoDefaultCoveragesData.xlsx", sheetName, true));
            ObjectMapper mapper = new ObjectMapper();
            mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
            return IntStream.range(0, json.length()).mapToObj(j -> json.getJSONObject(j).toString().replace(LOWERCASE_NULL, EMPTY_STRING)).map(jsObject -> {
                try {
                    return mapper.readValue(jsObject, DefaultCoverages.class);
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                    return null;
                }
            }).filter(Objects::nonNull).collect(Collectors.toList());
        } catch (Exception e) {
            throw new SkipException(e.getMessage());
        }
    }

    public List<AgentFlowData> listOfAgentFlowData() throws Exception {
        ExcelDataProvider excelDP = new ExcelDataProvider();
        JSONArray json = excelDP.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, "agentFlow", true);
        List<AgentFlowData> allAgentFlowDataData = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
        for (int j = 0; j < json.length(); j++) {
            String jsObject = json.getJSONObject(j).toString();
            allAgentFlowDataData.add(mapper.readValue(jsObject, AgentFlowData.class));
        }
        return allAgentFlowDataData;
    }

    public List<BDQFlowData> getBdqData() throws Exception {
        ExcelDataProvider excelDP = new ExcelDataProvider();
        JSONArray json = excelDP.getDataJson(ONEUI_AUTO_APPLICANT_FILE_NAME, "BDQ_Data", true);
        List<BDQFlowData> bdqFlowData = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
        for (int j = 0; j < json.length(); j++) {
            String jsObject = json.getJSONObject(j).toString();
            bdqFlowData.add(mapper.readValue(jsObject, BDQFlowData.class));
        }
        return bdqFlowData;
    }

    public ApplicantWithUmbrellaPolicy randomApplicantWithUmbrellaPolicy(String stateCode) throws Exception {
        List<ApplicantWithUmbrellaPolicy> listOfApplicantsWithUmbrellaPolicy = new ArrayList<>();
        //default is ma11
        String sheetName = "ApplicantsUmbrellaPolicy_MA11";
        if (Property.getUri().contains(RA11_ENVIRONMENT)) {
            sheetName = "ApplicantsUmbrellaPolicy_RA11";
        } else if (Property.getUri().contains(MA61_ENVIRONMENT)) {
            sheetName = "ApplicantsUmbrellaPolicy_MA61";
        } else if (Property.getUri().contains(RA61_ENVIRONMENT)) {
            sheetName = "ApplicantsUmbrellaPolicy_RA61";
        }

        ExcelDataProvider excel = new ExcelDataProvider();
        JSONArray json = excel.filterJsonData("stateCode=" + stateCode, excel.getDataJson("src/test/resources/AutoDefaultCoveragesData.xlsx", sheetName, true));
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
        for (int j = 0; j < json.length(); j++) {
            String jsObject = json.getJSONObject(j).toString();
            jsObject = jsObject.replace(LOWERCASE_NULL, EMPTY_STRING);
            listOfApplicantsWithUmbrellaPolicy.add(mapper.readValue(jsObject, ApplicantWithUmbrellaPolicy.class));
        }
        if (listOfApplicantsWithUmbrellaPolicy.isEmpty()) {
            throw new SkipException("Can't execute test, no umbrella policy holders found for " + stateCode + " in src/test/resources/AutoDefaultCoveragesData.xlsx");
        }
        return listOfApplicantsWithUmbrellaPolicy.get(randomNumberGenerator.nextInt(listOfApplicantsWithUmbrellaPolicy.size()));
    }

    public static List<AutoApplicant> randomlySelectedAutoApplicant(List<AutoApplicant> listOfAutoApplicant) {
        List<AutoApplicant> applicantList = listOfAutoApplicant.stream().filter(applicant -> listOfApplicantStates.contains(applicant.getStateCode())).collect(Collectors.toList());
        if (applicantList.isEmpty()) {
            Log.info("There is no applicant data for any of the following states: " + listOfApplicantStates);
            // re- assign to random
            applicantList = listOfAutoApplicant;
        }
        Collections.shuffle(applicantList);
        AutoApplicant applicant = applicantList.get(FIRST_AVAILABLE_OPTION);
        List<AutoApplicant> randomlySelectedAutoApplicant = new ArrayList<>();
        randomlySelectedAutoApplicant.add(applicant);
        return randomlySelectedAutoApplicant;
    }

    public static List<AutoApplicant> updateApplicantsForBind(List<AutoApplicant> applicants) throws Exception {
        for (AutoApplicant applicant : applicants) {
            Faker faker = new Faker();
            applicant.setFirstName(faker.name().firstName());
            applicant.setLastName("Brown"); //SV data last name
            applicant.setEmail("testesign_" + RandomStringUtils.randomAlphanumeric(4) + applicant.getFirstName() + "@farmers.testinator.com");
            applicant.setPhoneNumber(faker.phoneNumber().phoneNumber().replaceAll("\\D", EMPTY_STRING));

            // update the address for bind data to avoid same household failure
            List<AutoApplicant> applicantsFromTheSameState = listOfAutoApplicants(AUTO_APPLICANT_DATA, "stateCode=" + applicant.getStateCode());
            Collections.shuffle(applicantsFromTheSameState);
            AutoApplicant randomApplicant = applicantsFromTheSameState.get(FIRST_AVAILABLE_OPTION);
            applicant.setZipCode(randomApplicant.getZipCode());
            applicant.setCity(randomApplicant.getCity());
            applicant.setResidentAddress(randomApplicant.getResidentAddress());
            applicant.setApartmentNumber(randomApplicant.getApartmentNumber());
            applicant.setGaragingAddress(randomApplicant.getGaragingAddress());
            applicant.getAdditionalDrivers().forEach(each -> each.setLastName("Brown"));
        }
        return applicants;
    }

    public static Object[][] convertListToObjectArray(List<AutoApplicant> list) {
        // Determine the dimensions of the Object[][]
        int rows = list.size();
        int cols = 1; // Assuming each List<Object> element goes into a separate row

        // Initialize the Object[][] array
        Object[][] array = new Object[rows][cols];

        // Populate the Object[][] array
        for (int i = 0; i < list.size(); i++) {
            array[i][0] = list.get(i);
        }
        return array;
    }

    private static List<String> getListOfBWOnlyStates(String environmentURI) {
    	// Leaving groundwork in case environments differ on list
    	return new ArrayList<>(Arrays.asList(CT, FL, MA, NJ, NV));
    }

    private static List<String> getListOfAutoDisabledStates(String environmentURI) {
    	// Leaving groundwork in case environments differ on list
    	return new ArrayList<>(Arrays.asList(NC));
    }

    private static String setFilterAndListOfValidStates(Method m, String filter, List<String> listOfApplicableStates) {
		//First filter the list based on the contents of the stateList property
    	String stateList = Property.getTestProperty(STATE_LIST);
    	if (stateList != null && !stateList.equals(EMPTY_STRING) && !stateList.equals(ALL)) {
    		String[] arrayOfStates = stateList.split(COMMA);
    		listOfApplicableStates.retainAll(Arrays.asList(arrayOfStates));
    	}
    	//Now let's process any custom attribute
		CustomAttribute[] customAttrs = m.getAnnotation(Test.class).attributes();
    	for (CustomAttribute testAttribute : customAttrs) {
    		List<String> listOfValuesFromTestcase = Arrays.asList(testAttribute.values());
    		switch (testAttribute.name()) {
    		case FILTER:
    			// filter Property overrides any custom attribute filtering, so only use value if property is not set
    	    	String filterByProperty = Property.getTestProperty(FILTER);
    	    	if (filterByProperty == null || filterByProperty.equals(EMPTY_STRING) || filterByProperty.equals(ALL)) {
    	    		filter = listOfValuesFromTestcase.get(FIRST_AVAILABLE_OPTION);
    	    	}
    			break;
    		case INCLUDED_STATES:
    			listOfApplicableStates.retainAll(listOfValuesFromTestcase);
    			break;
    		case EXCLUDED_STATES:
    			listOfApplicableStates.removeIf(listOfValuesFromTestcase::contains);
    			break;
    		case DISABLED_STATES:
    			//Expectation is that these states are not enabled for the application, or they are not Farmers states (like NH or AK)
    			listOfApplicableStates.clear();
    			listOfApplicableStates.addAll(listOfValuesFromTestcase);
    			break;
    		case FARMERS_STATES:
    			//States that render the appropriate FFQ application after the landing page
        		listOfApplicableStates.removeAll(getListOfBWOnlyStates(Property.getUri()));
        		listOfApplicableStates.removeAll(getListOfAutoDisabledStates(Property.getUri()));
    			break;
    		case BW_STATES:
    			//States that render the BW version of the FFQ application after the landing page
    			listOfApplicableStates.retainAll(getListOfBWOnlyStates(Property.getUri()));
    			break;
    		default:
    			//this is for when "name = stateCode" is used
    			listOfApplicableStates.removeIf(state -> !state.equals(testAttribute.name()));
    			break;
    		}
    	}
    	return filter;
	}
}