/**
=============================================
* Author:	Zhabiz Sonee
* Create date:	05/01/2017
=============================================
*/
package com.farmers.ffq.datatransferobjects;

import lombok.Data;

@Data
public class SqlPayment {
	private int paymentId;
	private int applicantId;
	private String paymentPlan;
	private String paymentMethod;
	private String accountHolderName;
	String routingNumber;
	private String bankAccountNumber;
	private String bankName;
	private String creditCardType;
	private String debitCardType;
	private String nameOnCard;
	private String cardNumber;
	private String expirationDate;
	private String billingZipCode;
}
