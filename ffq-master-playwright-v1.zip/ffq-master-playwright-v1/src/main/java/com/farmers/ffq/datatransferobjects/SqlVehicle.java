/**
=============================================
* Author:	Zhabiz Sonee
* Create date:	05/01/2017
=============================================
*/
package com.farmers.ffq.datatransferobjects;
import lombok.Data;

@Data
public class SqlVehicle {
	private int vehicleId;
	private int applicantId;
	private String vehicleStateCode;
	private String vehicleYear;
	private String vehicleMake;
	private String vehicleModel;
	private String vehicleVIN;
	private String vehicleType;
	private String ownership;
	private String purchaseDate;
	private String vehicleUsage;
	private int oneWayMiles;
	private String commute;
	private int annualMiles;
	private boolean parkInresidentAddress;
	private boolean rideSharing;
	private boolean alternativeFuels;
	private boolean antiTheftDevice;
	private boolean passiveRestraint;
	private boolean airBagSeatBelt;
	private boolean antiLockBrakes;
	private boolean stabilityControl;	
	private boolean daytimeLights;
	private boolean theftRecoverySystem;
	private boolean vinEtching;
	private String lessorStateName;
	private String lessor;
	private int currentOdometerReading;
	private String dateOfReading;
	private boolean useVIN;
	private String garagingAddress;
	private String garagingApt;
	private String garagingCity;
	private String garagingZip;
	private String mediaAlphaModel;
	private String submodel;
	private String mediaAlphaAnnualMiles;
	private String collisionDeductible;
	private String comprehensiveDeductible;

	public String toString() {
		return String.format("%d, %d, %d, %s, %s, %s, %s, %s, %s, %s, %s, %s, %d, %s, %d, %b, %b, %b, %b, %b, %b, %b, %b, %b, %b, %b, %b, %b, %s, %s, %s, %s, %b, %s, %s, %s, %s",
						vehicleId, applicantId, vehicleStateCode, vehicleYear, vehicleMake, vehicleModel, vehicleVIN, vehicleType, ownership, purchaseDate, vehicleUsage,
						oneWayMiles, commute, annualMiles, parkInresidentAddress, rideSharing, alternativeFuels, antiTheftDevice, passiveRestraint, airBagSeatBelt, antiLockBrakes, stabilityControl, 
						daytimeLights, theftRecoverySystem, vinEtching, lessorStateName, lessor, currentOdometerReading, dateOfReading, useVIN,
						garagingAddress, garagingApt, garagingCity, garagingZip);
		

	}

}
