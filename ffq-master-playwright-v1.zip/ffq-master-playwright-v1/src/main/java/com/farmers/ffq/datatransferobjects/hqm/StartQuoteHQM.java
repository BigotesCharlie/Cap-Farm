package com.farmers.ffq.datatransferobjects.hqm;

import java.util.List;

public class StartQuoteHQM {

    private String quoteNumber;
    private String landingStateCode;
    private String landingStateDescription;
    private boolean isRedirectionRequired;
    private String quoteWindowId;
    private String tokenInfo;
    private String ssnKey;
    private String quoteType;
    private String isValidAgent;
    private AgentInfoHQM.Agent agent;
    private String landingZipCode;
    private List<String> cityList;

    public String getQuoteNumber() {
        return quoteNumber;
    }

    public String getLandingStateCode() {
        return landingStateCode;
    }

    public String getLandingStateDescription() {
        return landingStateDescription;
    }

    public boolean getIsRedirectionRequired() {
        return isRedirectionRequired;
    }

    public String getQuoteWindowId() {
        return quoteWindowId;
    }

    public String getTokenInfo() {
        return tokenInfo;
    }

    public String getSsnKey() {
        return ssnKey;
    }

    public String getQuoteType() {
        return quoteType;
    }

    public String getIsValidAgent() {
        return isValidAgent;
    }

    public AgentInfoHQM.Agent getAgent() {
        return agent;
    }

    public String getLandingZipCode() {
        return landingZipCode;
    }

    public List<String> getCityList() {
        return cityList;
    }

}
