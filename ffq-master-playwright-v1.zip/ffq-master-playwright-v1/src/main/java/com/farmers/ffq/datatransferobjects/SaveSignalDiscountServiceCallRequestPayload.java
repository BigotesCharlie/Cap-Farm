package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonIgnoreProperties
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class SaveSignalDiscountServiceCallRequestPayload {

    @JsonProperty("SaveSignalDiscountRequestBean")
    private SaveSignalDiscountRequestBean saveSignalDiscountRequestBean;

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class SaveSignalDiscountRequestBean {
        private String quoteNumber;
        private String landingStateCode;
        private String signalDiscountEnrolled;
        private String pgLastVisitedPage;
        private String lastVisitedPage;
    }


}
