package com.farmers.ffq.datatransferobjects;

import java.util.List;
import lombok.Data;

@Data
public class AdditionalDiscountsPageDiscounts{
	private List<String> extraDiscounts;
	private List<Object> alreadyIncludedDiscounts;
}