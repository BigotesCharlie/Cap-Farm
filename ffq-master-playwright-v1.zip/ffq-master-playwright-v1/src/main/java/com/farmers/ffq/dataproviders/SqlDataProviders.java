package com.farmers.ffq.dataproviders;

import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

import com.farmers.ffq.datatransferobjects.*;
import org.json.JSONArray;
import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviderframework.DataProviderBase;
import com.farmers.framework.Property;
import com.farmers.framework.data.ExcelDataProvider;
import com.farmers.framework.report.Log;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.datafaker.Faker;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class SqlDataProviders extends DataProviderBase {

	private static final String STATE_CODE_EQ = "stateCode=";
	public static final String STATES_DATA_PROVIDER_NAME = "StatesDataProvider";
	public static final String AUTO_APPLICANT_DATA_PROVIDER = "AutoApplicantDataProvider";
	public static final String AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER = "AutoPageValidationDataProvider";
	public static final String AUTO_APPLICANT_COMMON_DATA_PROVIDER = "AutoCommonUserDataProvider";
	public static final String BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER = "BWAutoApplicantDataProvider";
	public static final String ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER = "AllAutoBVTApplicantsDataProvider";
	public static final String BVT_AUTO_APPLICANT_DATA_PROVIDER = "AutoBVTDataProvider";
	public static final String AUTO_APPLICANT_SAVE_AND_RETRIEVE_DATA_PROVIDER = "SaveAndRetrieveAutoApplicantDataProvider";
	public static final String HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER = "HighValueStatesAutoApplicantDataProvider";
	public static final String TEST_AUTO_APPLICANT_DATA_PROVIDER = "testAutoDataProvider";

	public static final String JENKINS_AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER = "JenkinsPageValidationDataProvider";
	public static final String JENKINS_AUTO_APPLICANT_SMOKE_TEST_DATA_PROVIDER = "JenkinsSmokeTestDataProvider";
	public static final String JENKINS_AUTO_APPLICANT_QUOTE_SCENARIOS_DATA_PROVIDER = "JenkinsQuoteScenariosDataProvider";

	private static final String DP_LOG_ENTRY = "=== %s has %d rows of data ===";

	// Excel information
	private static final String AUTO_APPLICANT_FILE_NAME = "src/test/resources/AutoTestData.xlsx";
	private static final String AUTO_APPLICANT_DATA = "applicant";
	private static final String AUTO_COMMON_DATA = "applicantTest";
	private static final String AUTO_BVT_DATA = "applicantBVT";
	private static final String AUTO_BRISTOL_WEST_DATA = "applicantBW";
	private static final String PAGE_VALIDATION_DATA = "pageValidationApplicant";
	private static final String RETRIEVE_APPLICANT_DATA = "retrieveQuoteApplicant";
	private static final String TEST_AUTO_APPLICANT_DATA = "testApplicant";


	//These states always complete the quote creation without knock-out
	private static final List<String> listOfAutoBVTStates = List.of(AL, AR, CA, CO, CT, GA, IA, ID, IN, KS, KY, LA, MA, MD, MI, MN,
			MS, MT, ND, NE, NJ, NM, NV, OK, OR, SD, TN, VA, WI, WY);
	private static final List<String> listOfAutoStates = List.of(AL, AR, AZ, CA, CO, CT, FL, GA, IA, ID, IN, IL, KS, KY, LA, MA, MD, MI, MN,
			MO, MS, MT, NC, ND, NE, NJ, NM, NV, NY, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);

	// High value states will be comprised of alwaysRun + one random of each of the other groups
	// states in multiple lists are assigned one group and removed from other lists they belong to.
	private static final List<String> listOfAlwaysRunStates = List.of();
	private static final List<String> listOfEEStates = List.of(KY, LA, MA, MS, NC);
	private static final List<String> listOfFlexStates = List.of(AL, AR, ID, MI, NE, NM, OK, OR, PA, TN, WI, WY);
	private static final List<String> listOfPLAStates = List.of(CT, GA, MT, ND, SD, VA);
	private static final List<String> listOfGWPCStates = List.of(CO, FL, IA, IN, KS, MD, MN, MO, NV, OH, UT, WA);

	protected static final Random randomNumberGenerator = new Random();

	public static List<String> getlistOfAutoStates() {
		return listOfAutoStates;
	}

	public static List<String> getListOfLegacyAutoStates() {
		return 	composeListOfStates(listOfAutoStates);
	}

	@DataProvider(name = STATES_DATA_PROVIDER_NAME, parallel = true)
	public Iterator<State> state(Method m) throws Exception {
		ExcelDataProvider excel = new ExcelDataProvider();
		JSONArray json = excel.getDataJson(AUTO_APPLICANT_FILE_NAME, "stateValidation", true);
		List<State> stateList = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
		for (int i = 0; i < json.length(); i++) {
			String js = json.getJSONObject(i).toString();
			js = js.replace(TRUE, LOWERCASE_TRUE);
			js = js.replace(FALSE, LOWERCASE_FALSE);
			js = js.replace(LOWERCASE_NULL, EMPTY_STRING);
			stateList.add(mapper.readValue(js, State.class));
		}
		List<String> listOfRetrievedStates =  stateList.stream().map(each -> each.getStateCode()).collect(Collectors.toList());
		List<String> listOfApplicableStates = updateListOfStatesWithTestAttribute(m, listOfRetrievedStates);
		stateList.removeIf(state -> !listOfApplicableStates.contains(state.getStateCode()));
		//Randomize zip codes to use
		stateList.forEach(state -> state.setZipCode(new Faker(Locale.US).address().zipCodeByState(state.getStateCode())));
		Log.warn(String.format(DP_LOG_ENTRY, STATES_DATA_PROVIDER_NAME, stateList.size()));
		return stateList.iterator();
	}

	@DataProvider(name = AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER, parallel = true)
	public Iterator<SqlApplicant> autoPageValidationApplicants(Method m) throws Exception {
		List<SqlApplicant> allAutoApplicants = listOfAutoApplicants(PAGE_VALIDATION_DATA, NO_FILTER);
		allAutoApplicants = filterApplicantsFromValidStates(m, allAutoApplicants, AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER);
		return allAutoApplicants.iterator();
	}

	@DataProvider(name = AUTO_APPLICANT_DATA_PROVIDER, parallel = true)
	public Iterator<SqlApplicant> autoQuoteScenariosApplicants(Method m) throws Exception {
		List<SqlApplicant> allAutoApplicants = listOfAutoApplicants(AUTO_APPLICANT_DATA, NO_FILTER);
		allAutoApplicants = filterApplicantsFromValidStates(m, allAutoApplicants, AUTO_APPLICANT_DATA_PROVIDER);
		return allAutoApplicants.iterator();
	}

	@DataProvider(name = AUTO_APPLICANT_SAVE_AND_RETRIEVE_DATA_PROVIDER, parallel = true)
	public Iterator<SqlApplicant> autoQuoteSaveAndRetrieveApplicant(Method m) throws Exception {
		List<SqlApplicant> allAutoApplicants = listOfAutoApplicants(RETRIEVE_APPLICANT_DATA, NO_FILTER);
		allAutoApplicants = filterApplicantsFromValidStates(m, allAutoApplicants, AUTO_APPLICANT_SAVE_AND_RETRIEVE_DATA_PROVIDER);
		return allAutoApplicants.iterator();
	}

	@DataProvider(name = AUTO_APPLICANT_COMMON_DATA_PROVIDER, parallel = true)
	public Iterator<SqlApplicant> autoTestApplicants(Method m) throws Exception {
		List<SqlApplicant> allAutoApplicants = listOfAutoApplicants(AUTO_COMMON_DATA, NO_FILTER);
		allAutoApplicants = filterApplicantsFromValidStates(m, allAutoApplicants, AUTO_APPLICANT_COMMON_DATA_PROVIDER);
		return allAutoApplicants.iterator();
	}

	@DataProvider(name = TEST_AUTO_APPLICANT_DATA_PROVIDER, parallel = true)
	public Iterator<SqlApplicant> testAutoApplicant(Method m) throws Exception {
		List<SqlApplicant> allAutoApplicants = listOfAutoApplicants(TEST_AUTO_APPLICANT_DATA, NO_FILTER);
		allAutoApplicants = filterApplicantsFromValidStates(m, allAutoApplicants, TEST_AUTO_APPLICANT_DATA_PROVIDER);
		return allAutoApplicants.iterator();
	}

	@DataProvider(name = ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER, parallel = true)
	public Iterator<SqlApplicant> allAutoBVTApplicants(Method m) throws Exception {
		List<SqlApplicant> allBVTApplicants = listOfAutoApplicants(AUTO_BVT_DATA, NO_FILTER);
		allBVTApplicants = filterApplicantsFromValidStates(m, allBVTApplicants, ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER);
		return allBVTApplicants.iterator();
	}

	private List<SqlApplicant> filterApplicantsFromValidStates(Method m, List<SqlApplicant> allAutoApplicants, String dataProviderType) {
		List<String> listOfApplicableStates = updateListOfStatesWithTestAttribute(m, composeListOfStates(listOfAutoStates));
		allAutoApplicants.removeIf(applicant -> !listOfApplicableStates.contains(applicant.getStateCode()));
		Log.warn(String.format(DP_LOG_ENTRY, dataProviderType, allAutoApplicants.size()));
		return allAutoApplicants;
	}

	@DataProvider(name = BVT_AUTO_APPLICANT_DATA_PROVIDER, parallel = true)
	public Iterator<SqlApplicant> autoBVTApplicant(Method m) throws Exception {
		CustomAttribute[] customAttrs = m.getAnnotation(Test.class).attributes();
		if (customAttrs.length > 0  && customAttrs[0].name().equals(INCLUDED_STATES)) {
			List<String> listOfStates = new ArrayList<>(Arrays.asList(customAttrs[0].values()));
			listOfStates = composeListOfStates(listOfStates);
			if (listOfStates.isEmpty()) {
				throw new SkipException("No supported states found for Auto in this environment");
			}
			Collections.shuffle(listOfStates);
			return getApplicantsFromSingleState(AUTO_BVT_DATA, listOfStates.get(FIRST_AVAILABLE_OPTION));
		} else {
			return getApplicantsFromSingleState(AUTO_BVT_DATA, RANDOM_ROW);
		}
	}

	@DataProvider(name = BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, parallel = true)
	public Iterator<SqlApplicant> autoRedesignBWApplicant(Method m) throws Exception {
		CustomAttribute[] customAttrs = m.getAnnotation(Test.class).attributes();
		if (customAttrs.length > 0) {
			String filter = NO_FILTER;
			for (int index = 0; index < customAttrs.length; index++) {
				String attributeName = customAttrs[index].name();
				if (attributeName.equals(FILTER)) {
					List<String> filterList = new ArrayList<>(Arrays.asList(customAttrs[index].values()));
					filter = filterList.get(0);
				}
			}
			List<SqlApplicant> bwAutoApplicants = listOfAutoApplicants(AUTO_BRISTOL_WEST_DATA, filter);
			List<String> listOfStates = updateListOfStatesWithTestAttribute(m, composeListOfStates(listOfAutoBVTStates));
			String stateListPropertyValue = Property.getTestProperty(STATE_LIST);
			if (stateListPropertyValue != null && !stateListPropertyValue.equals(EMPTY_STRING) && !stateListPropertyValue.equals("all")) {
				bwAutoApplicants.removeIf(applicant -> !listOfStates.contains(applicant.getStateCode()));
				Log.warn(String.format(DP_LOG_ENTRY, BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, bwAutoApplicants.size()));
				return bwAutoApplicants.iterator();
			} else {
				List<SqlApplicant> filteredListOfApplicantsFromFiveRandomStates = getApplicantEntries(bwAutoApplicants, listOfStates);
				Log.warn(String.format(DP_LOG_ENTRY, BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, filteredListOfApplicantsFromFiveRandomStates.size()));
				return filteredListOfApplicantsFromFiveRandomStates.iterator();
			}
		} else {
			List<SqlApplicant> allBWAutoApplicants = listOfAutoApplicants(AUTO_BRISTOL_WEST_DATA, NO_FILTER);
			List<SqlApplicant> listOfBWApplicantsFromFiveRandomStates = getApplicantEntries(allBWAutoApplicants, composeListOfStates(listOfAutoStates));
			Log.warn(String.format(DP_LOG_ENTRY, BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, listOfBWApplicantsFromFiveRandomStates.size()));
			return listOfBWApplicantsFromFiveRandomStates.iterator();
		}
	}

	//Data providers for Jenkins self-service automation
	@DataProvider(name = JENKINS_AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER, parallel = true)
	public Iterator<SqlApplicant> jenkinsAutoPageValidationApplicants(Method m) throws Exception {
		List<SqlApplicant> applicantList = getApplicants(PAGE_VALIDATION_DATA, m);
		Log.warn(String.format(DP_LOG_ENTRY, JENKINS_AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER, applicantList.size()));
		return applicantList.iterator();
	}

	@DataProvider(name = JENKINS_AUTO_APPLICANT_SMOKE_TEST_DATA_PROVIDER, parallel = true)
	public Iterator<SqlApplicant> jenkinsAutoSmokeTestApplicants(Method m) throws Exception {
		List<SqlApplicant> applicantList = getApplicants(AUTO_BVT_DATA, m);
		Log.warn(String.format(DP_LOG_ENTRY, JENKINS_AUTO_APPLICANT_SMOKE_TEST_DATA_PROVIDER, applicantList.size()));
		return applicantList.iterator();
	}

	@DataProvider(name = JENKINS_AUTO_APPLICANT_QUOTE_SCENARIOS_DATA_PROVIDER, parallel = true)
	public Iterator<SqlApplicant> jenkinsAutoQuoteScenarioApplicants(Method m) throws Exception {
		List<SqlApplicant> completeApplicantList = getApplicants(AUTO_APPLICANT_DATA, m);
		List<SqlApplicant> applicantList = getCriticalScenarios(completeApplicantList);
		Log.warn(String.format(DP_LOG_ENTRY, JENKINS_AUTO_APPLICANT_QUOTE_SCENARIOS_DATA_PROVIDER, applicantList.size()));
		return applicantList.iterator();
	}

	public SqlApplicant getRandomAutoApplicantFromState(String stateCode) throws Exception {
		List<SqlApplicant> listOfApplicantsFromAState = getApplicants(AUTO_APPLICANT_DATA, STATE_CODE_EQ + stateCode);
		return listOfApplicantsFromAState.get(randomNumberGenerator.nextInt(listOfApplicantsFromAState.size()));
	}

	private List<SqlApplicant> getApplicants(String excelSheet, Method m) throws Exception {
		List<SqlApplicant> allAutoApplicants = listOfAutoApplicants(excelSheet, NO_FILTER);
		List<String> listOfApplicableStates = updateListOfStatesWithTestAttribute(m, composeListOfStates(listOfAutoBVTStates));
		allAutoApplicants.removeIf(applicant -> !listOfApplicableStates.contains(applicant.getStateCode()));
		return allAutoApplicants;
	}

	private List<SqlApplicant> getCriticalScenarios(List<SqlApplicant> applicantList) {
		List<SqlApplicant> returnList = new ArrayList<>();
		Iterator<SqlApplicant> allAutoApplicants = applicantList.iterator();
		while (allAutoApplicants.hasNext()) {
			SqlApplicant autoApplicant = allAutoApplicants.next();
			int scenarioNumber = autoApplicant.getApplicantId();
			String applicantStateCode = autoApplicant.getStateCode();
			// This is the list of tests scenarios considered critical that don't go to BW per QA request.
			if (!Arrays.asList(IN, KY, MA, MS, ND, OK, PA, SD, TX, TN).contains(applicantStateCode) && Arrays.asList(1, 5, 8).contains(scenarioNumber) &&
					(!(scenarioNumber == 8 && Arrays.asList(CO, ID).contains(applicantStateCode)))) {
				returnList.add(autoApplicant);
			}
		}
		return returnList;
	}

	@DataProvider(name = HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER, parallel = true)
	public Iterator<SqlApplicant> highValueAutoApplicant() throws Exception {
		List<SqlApplicant> allAutoApplicants = listOfAutoApplicants(AUTO_APPLICANT_DATA, NO_FILTER);
		List<String> highValueStateList = createHighValueStateList();
		allAutoApplicants.removeIf(applicant-> !highValueStateList.contains(applicant.getStateCode()));
		Log.info(String.format(DP_LOG_ENTRY, HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER, allAutoApplicants.size()));
		return allAutoApplicants.iterator();
	}

	private static List<String> createHighValueStateList() {
		List<String> highValueStateList = composeListOfStates(listOfAlwaysRunStates);
		List<String> tempList = composeListOfStates(listOfEEStates);
		HashSet<Integer> randomListOfIndices = randomIntegerSet(1, 0, tempList.size());
		highValueStateList.addAll(partialList(tempList, randomListOfIndices));
		tempList = composeListOfStates(listOfFlexStates);
		randomListOfIndices = randomIntegerSet(1, 0, tempList.size());
		highValueStateList.addAll(partialList(tempList, randomListOfIndices));
		tempList = composeListOfStates(listOfPLAStates);
		randomListOfIndices = randomIntegerSet(1, 0, tempList.size());
		highValueStateList.addAll(partialList(tempList, randomListOfIndices));
		tempList = composeListOfStates(listOfGWPCStates);
		randomListOfIndices = randomIntegerSet(1, 0, tempList.size());
		highValueStateList.addAll(partialList(tempList, randomListOfIndices));
		return highValueStateList;
	}

	private Iterator<SqlApplicant> getApplicantsFromSingleState(String xlDataSheetName, String randomState) throws Exception {
		if (randomState.equals(RANDOM_ROW)) {
			List<String> listOfStates = composeListOfStates(listOfAutoBVTStates);
			if (listOfStates.isEmpty()) {
				throw new SkipException("No supported states found for Auto in this environment");
			}
			Collections.shuffle(listOfStates);
			randomState = listOfStates.get(FIRST_AVAILABLE_OPTION);
		}
		return listOfAutoApplicants(xlDataSheetName, STATE_CODE_EQ + randomState).iterator();
	}

	private List<SqlApplicant> getApplicantEntries(List<SqlApplicant> allAutoApplicants, List<String> listOfStatesForApplicants) {
		HashSet<Integer> randomListOfIndices = randomIntegerSet(5, 0, listOfStatesForApplicants.size());
		List<String> workingStateList = partialList(listOfStatesForApplicants, randomListOfIndices);
		allAutoApplicants.removeIf(applicant -> !workingStateList.contains(applicant.getStateCode()));
		return allAutoApplicants;
	}

	private synchronized List<SqlApplicant> listOfAutoApplicants(String xlDataSheetName, String filter) throws Exception {
		Iterator<SqlApplicant> applicantListIterator = getApplicants(xlDataSheetName, filter).iterator();
		List<SqlVehicle> vehicles = getAllVehicles();
		List<SqlAdditionalDriver> additionalDrivers = getAllAdditionalDrivers();
		List<SqlIncident> incidents = getAllIncidents();
		List<SqlDiscount> discounts = getAllDiscounts();
		List<SqlPayment> payments = getAllPayments();
		List<SqlRepresentative> representatives = getAllRepresentatives();
		List<SqlApplicant> autoApplicantList = new ArrayList<>();
		while (applicantListIterator.hasNext()) {
			SqlApplicant applicant = applicantListIterator.next();
			// Set all iterators.
			Iterator<SqlVehicle> vehicleIterator = vehicles.iterator();
			Iterator<SqlAdditionalDriver> additionalDriversIterator = additionalDrivers.iterator();
			Iterator<SqlIncident> incidentsIterator = incidents.iterator();
			Iterator<SqlDiscount> discountsIterator = discounts.iterator();
			Iterator<SqlPayment> paymentsIterator = payments.iterator();
			Iterator<SqlRepresentative> representativesIterator = representatives.iterator();
			// Set all lists.
			List<SqlVehicle> applicantVehicles = new ArrayList<>();
			List<SqlAdditionalDriver> applicantAdditionalDrivers = new ArrayList<>();
			List<SqlIncident> applicantIncidents = new ArrayList<>();
			// Traverse each list for appropriate data
			while (vehicleIterator.hasNext()) {
				SqlVehicle vehicle = vehicleIterator.next();
				if (vehicle.getApplicantId() == applicant.getApplicantId()) {
					//Garaging address has to come from applicant since vehicles are not state specific
					vehicle.setGaragingAddress(applicant.getGaragingAddress());
					vehicle.setGaragingCity(applicant.getCity());
					vehicle.setGaragingZip(applicant.getZipCode());
					// NC correction for rideshare
					if (applicant.getStateCode().equals(NC) && !applicant.isKnockoutExpected()) {
						vehicle.setRideSharing(false);
					}
					applicantVehicles.add(vehicle);
				}
			}
			while (additionalDriversIterator.hasNext()) {
				SqlAdditionalDriver additionalDriver = additionalDriversIterator.next();
				if (additionalDriver.getApplicantId() == applicant.getApplicantId()) {
					applicantAdditionalDrivers.add(additionalDriver);
				}
			}
			while (incidentsIterator.hasNext()) {
				SqlIncident incident = incidentsIterator.next();
				if (incident.getApplicantId() == applicant.getApplicantId()) {
					applicantIncidents.add(incident);
				}
			}
			while (discountsIterator.hasNext()) {
				SqlDiscount discount = discountsIterator.next();
				if (discount.getApplicantId() == applicant.getApplicantId()) {
					applicant.setDiscounts(discount);
					break;
				}
			}
			while (paymentsIterator.hasNext()) {
				SqlPayment payment = paymentsIterator.next();
				if (payment.getApplicantId() == applicant.getApplicantId()) {
					applicant.setPayment(payment);
				}
			}
			while (representativesIterator.hasNext()) {
				SqlRepresentative representative = representativesIterator.next();
				//Overload sameStateZip field with AOR number or Enterprise Agent
				if (applicant.getSameStateZip().equals(representative.getRepresentativeId())) {
					applicant.setRepresentative(representative);
					break;
				}
			}
			applicant.setVehicles(applicantVehicles);
			applicant.setAdditionalDrivers(applicantAdditionalDrivers);
			applicant.setIncidents(applicantIncidents);
			autoApplicantList.add(applicant);
		}
		Faker faker = new Faker();
		autoApplicantList.forEach(autoApplicant -> autoApplicant.setFirstName(faker.name().firstName()));
		autoApplicantList.forEach(autoApplicant -> autoApplicant.setLastName(faker.name().lastName()));
		Log.info(String.format(DP_LOG_ENTRY, xlDataSheetName, autoApplicantList.size()));
		return autoApplicantList;
	}

	private List<SqlApplicant> getApplicants(String xlDataSheetName, String filter) throws Exception {
		ExcelDataProvider excel = new ExcelDataProvider();
		JSONArray json = filter.equals(NO_FILTER) ? excel.getDataJson(AUTO_APPLICANT_FILE_NAME, xlDataSheetName, true) :
			excel.filterJsonData(filter, excel.getDataJson(AUTO_APPLICANT_FILE_NAME, xlDataSheetName, true));
		List<SqlApplicant> applicantList = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
		for (int i = 0; i < json.length(); i++) {
			String js = json.getJSONObject(i).toString();
			js = js.replace(TRUE, LOWERCASE_TRUE);
			js = js.replace(FALSE, LOWERCASE_FALSE);
			js = js.replace(LOWERCASE_NULL, EMPTY_STRING);
			SqlApplicant applicant = mapper.readValue(js, SqlApplicant.class);
			applicantList.add(applicant);
		}
		return applicantList;
	}

	private List<SqlVehicle> getAllVehicles() throws Exception {
		ExcelDataProvider excelDP = new ExcelDataProvider();
		JSONArray json = excelDP.getDataJson(AUTO_APPLICANT_FILE_NAME, "vehicles", true);
		List<SqlVehicle> allVehicles = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
		for (int j = 0; j < json.length(); j++) {
			String jsObject = json.getJSONObject(j).toString();
			jsObject = jsObject.replace(TRUE, LOWERCASE_TRUE);
			jsObject = jsObject.replace(FALSE, LOWERCASE_FALSE);
			jsObject = jsObject.replace(LOWERCASE_NULL, EMPTY_STRING);
			allVehicles.add(mapper.readValue(jsObject, SqlVehicle.class));
		}
		return allVehicles;
	}

	private List<SqlAdditionalDriver> getAllAdditionalDrivers() throws Exception {
		ExcelDataProvider excelDP = new ExcelDataProvider();
		JSONArray json = excelDP.getDataJson(AUTO_APPLICANT_FILE_NAME, "additionalDriver", true);
		List<SqlAdditionalDriver> allAdditionalDriver = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
		for (int j = 0; j < json.length(); j++) {
			String jsObject = json.getJSONObject(j).toString();
			jsObject = jsObject.replace(TRUE, LOWERCASE_TRUE);
			jsObject = jsObject.replace(FALSE, LOWERCASE_FALSE);
			jsObject = jsObject.replace(LOWERCASE_NULL, EMPTY_STRING);
			allAdditionalDriver.add(mapper.readValue(jsObject, SqlAdditionalDriver.class));
		}
		return allAdditionalDriver;
	}

	private List<SqlDiscount> getAllDiscounts() throws Exception {
		ExcelDataProvider excelDP = new ExcelDataProvider();
		JSONArray json = excelDP.getDataJson(AUTO_APPLICANT_FILE_NAME, "discounts", true);
		List<SqlDiscount> allDiscounts = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
		for (int j = 0; j < json.length(); j++) {
			String jsObject = json.getJSONObject(j).toString();
			jsObject = jsObject.replace(TRUE, LOWERCASE_TRUE);
			jsObject = jsObject.replace(FALSE, LOWERCASE_FALSE);
			jsObject = jsObject.replace(LOWERCASE_NULL, EMPTY_STRING);
			allDiscounts.add(mapper.readValue(jsObject, SqlDiscount.class));
		}
		return allDiscounts;
	}

	private List<SqlIncident> getAllIncidents() throws Exception {
		ExcelDataProvider excelDP = new ExcelDataProvider();
		JSONArray json = excelDP.getDataJson(AUTO_APPLICANT_FILE_NAME, "incidents", true);
		List<SqlIncident> allIncidents = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
		for (int j = 0; j < json.length(); j++) {
			String jsObject = json.getJSONObject(j).toString();
			jsObject = jsObject.replace(TRUE, LOWERCASE_TRUE);
			jsObject = jsObject.replace(FALSE, LOWERCASE_FALSE);
			jsObject = jsObject.replace(LOWERCASE_NULL, EMPTY_STRING);
			allIncidents.add(mapper.readValue(jsObject, SqlIncident.class));
		}
		return allIncidents;
	}

	private List<SqlPayment> getAllPayments() throws Exception {
		ExcelDataProvider excelDP = new ExcelDataProvider();
		JSONArray json = excelDP.getDataJson(AUTO_APPLICANT_FILE_NAME, "payments", true);
		List<SqlPayment> allPayments = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
		for (int j = 0; j < json.length(); j++) {
			String jsObject = json.getJSONObject(j).toString();
			jsObject = jsObject.replace(TRUE, LOWERCASE_TRUE);
			jsObject = jsObject.replace(FALSE, LOWERCASE_FALSE);
			jsObject = jsObject.replace(LOWERCASE_NULL, EMPTY_STRING);
			allPayments.add(mapper.readValue(jsObject, SqlPayment.class));
		}
		return allPayments;
	}

	private List<SqlRepresentative> getAllRepresentatives() throws Exception {
		ExcelDataProvider excelDP = new ExcelDataProvider();
		JSONArray json = excelDP.getDataJson(AUTO_APPLICANT_FILE_NAME, "representative", true);
		List<SqlRepresentative> allRepresentatives = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
		for (int j = 0; j < json.length(); j++) {
			String jsObject = json.getJSONObject(j).toString();
			jsObject = jsObject.replace(TRUE, LOWERCASE_TRUE);
			jsObject = jsObject.replace(FALSE, LOWERCASE_FALSE);
			jsObject = jsObject.replace(LOWERCASE_NULL, EMPTY_STRING);
			allRepresentatives.add(mapper.readValue(jsObject, SqlRepresentative.class));
		}
		return allRepresentatives;
	}

	private static List<String> composeListOfStates(List<String> listOfStates) {
		List<String> tempList = new ArrayList<>(listOfStates);
		String environmentURI = Property.getUri();
		tempList.removeAll(getListOfAceAutoStates(environmentURI));
		tempList.removeAll(getListOfLegacyAutoMonetizedStates(environmentURI));
		return tempList;
	}

	public static List<String> getListOfLegacyAutoMonetizedStates(String environmentURI) {
		return new ArrayList<>();
	}

	private static List<String> updateListOfStatesWithTestAttribute(Method m, List<String> listOfApplicableStates) {
		List<String> updatedList = new ArrayList<>(listOfApplicableStates);
		String stateList = Property.getTestProperty(STATE_LIST);
		if (stateList != null && !stateList.equals(EMPTY_STRING) && !stateList.equals(ALL)) {
			String[] arrayOfStates = stateList.split(COMMA);
			updatedList.retainAll(Arrays.asList(arrayOfStates));
		}
		CustomAttribute[] customAttrs = m.getAnnotation(Test.class).attributes();
		for (CustomAttribute testAttribute : customAttrs) {
			List<String> listOfValuesFromTestcase = Arrays.asList(testAttribute.values());
			switch (testAttribute.name()) {
			case INCLUDED_STATES:
				updatedList.removeIf(state -> !listOfValuesFromTestcase.contains(state));
				break;
			case EXCLUDED_STATES:
				updatedList.removeIf(listOfValuesFromTestcase::contains);
				break;
			case DISABLED_STATES:
				if (listOfValuesFromTestcase.contains("HCR")) {
					updatedList = DataProviderBase.getListOfHCRMonetizedStates(Property.getUri());
				} else {
					updatedList.clear();
					updatedList.addAll(listOfValuesFromTestcase);
				}
				break;
			case HIGH_VALUE_STATES:
				updatedList = createHighValueStateList();
				break;
			case MONETIZED_STATES:
				if (listOfValuesFromTestcase.isEmpty()) {
					updatedList.addAll(getListOfLegacyAutoMonetizedStates(Property.getUri()));
				} else {
					updatedList.clear();
					updatedList.addAll(listOfValuesFromTestcase);
					updatedList.retainAll(getListOfLegacyAutoMonetizedStates(Property.getUri()));
				}
				break;
			case RANDOM_STATE:
				if (!updatedList.isEmpty()) {
					Collections.shuffle(updatedList);
					String randomState = updatedList.get(FIRST_AVAILABLE_OPTION);
					updatedList.clear();
					updatedList.add(randomState);
				}
				break;
			default:
				//this is for when "name = stateCode" is used
				updatedList.removeIf(state -> !state.equals(testAttribute.name()));
				break;
			}
		}
		return updatedList;
	}

}

