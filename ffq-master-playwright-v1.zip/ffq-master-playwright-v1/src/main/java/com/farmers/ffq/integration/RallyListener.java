package com.farmers.ffq.integration;


import com.farmers.framework.playwright.compat.*;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.framework.report.Log;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * TestNG listener that posts test results and a self-contained HTML report
 * (page source + embedded screenshot) to Rally after every test run.
 *
 * <p>Annotate a test with {@link RallyTestCase} to link it:
 * <pre>
 *   {@literal @}RallyTestCase(ids = {"TC2175178"})
 *   public void myTest() { ... }
 * </pre>
 *
 * <p>Implements {@link IInvokedMethodListener} so the screenshot and page source
 * are captured <em>right after the test method body</em>, before {@code @AfterMethod}
 * can navigate away or reset the browser.  The screenshot is embedded inline
 * as a base-64 {@code <img>} inside the HTML so the attachment is fully
 * self-contained when opened from Rally.
 */
public class RallyListener implements ITestListener, IInvokedMethodListener {

    private final RallyService rally = RallyService.getInstance();

    @Override
    public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {}

    /**
     * Fires right after the test method body returns, before {@code @AfterMethod}.
     * Captures the screenshot and full page source while the browser still shows
     * the last action of the test.
     */
    @Override
    public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
        if (!method.isTestMethod()) return;
        if (!rally.isEnabled()) return;
        if (getRallyIds(testResult).isEmpty()) return;

        try {
            Object driver = getDriver(testResult);

            // Screenshot – stored for embedding in the HTML report
            if (RallyContext.getScreenshotBytes() == null && driver instanceof PWTakesScreenshot) {
                RallyContext.setScreenshotBytes(
                        ((PWTakesScreenshot) driver).getScreenshotAs(PWOutputType.BYTES));
                Log.debug("RallyListener: screenshot captured after test method");
            }

            // Page source – inject <base> tag so relative URLs resolve from the app origin
            if (RallyContext.getPageSourceHtml() == null && driver instanceof PWDriver) {
                String currentUrl = ((PWDriver) driver).getCurrentUrl();
                String source     = ((PWDriver) driver).getPageSource();
                if (source != null && !source.isEmpty()) {
                    RallyContext.setPageSourceHtml(injectBaseTag(source, currentUrl));
                    Log.debug("RallyListener: page source captured after test method, url=" + currentUrl);
                }
            }
        } catch (Exception e) {
            Log.debug("RallyListener: post-test capture failed – " + e.getMessage());
        }
    }

    @Override
    public void onTestStart(ITestResult result) {
        RallyContext.clear();
    }

    @Override public void onTestSuccess(ITestResult result) { postToRally(result, RallyService.VERDICT_PASS);    }
    @Override public void onTestFailure(ITestResult result) { postToRally(result, RallyService.VERDICT_FAIL);    }
    @Override public void onTestSkipped(ITestResult result) { postToRally(result, RallyService.VERDICT_BLOCKED); }

    @Override public void onStart(ITestContext context) {}
    @Override public void onFinish(ITestContext context) {}
    @Override public void onTestFailedButWithinSuccessPercentage(ITestResult result) {}


    private void postToRally(ITestResult result, String verdict) {
        if (!rally.isEnabled()) return;

        List<String> ids = getRallyIds(result);
        if (ids.isEmpty()) return;

        // ── Snapshot all ThreadLocal context immediately ───────────────────────
        // Reading from RallyContext here (on the test's own thread) is safe because
        // onTestSuccess/Failure/Skipped is always called on the same thread as the
        // test method — BUT we snapshot eagerly to ensure nothing is mutated if
        // the TestNG framework hands off to a reporting thread before we finish.
        byte[] screenshot  = RallyContext.getScreenshotBytes();
        String quoteNumber = RallyContext.getQuoteNumber();
        if (quoteNumber == null) {
            quoteNumber = readQuoteNumberFromSessionStorage(result);
        }

        // ── Build a compact, per-test HTML report ─────────────────────────────
        // This is constructed entirely from the ThreadLocal snapshot above plus
        // the ITestResult — it is fully isolated to THIS test and cannot contain
        // data from a different test or a previous run.
        byte[] htmlReport = buildCompactHtmlReport(result, verdict, quoteNumber);

        String notes      = buildNotes(result, verdict, quoteNumber);
        String buildLabel = result.getMethod().getMethodName();

        rally.postResults(ids, verdict, notes, screenshot, htmlReport, buildLabel);
    }

    /**
     * Builds a compact, self-contained HTML report suitable for attaching to Rally.
     *
     * <p>Contains only:
     * <ul>
     *   <li>Test name, verdict badge, environment, timestamp, quote number</li>
     *   <li>Screenshot embedded as an inline base-64 {@code <img>}</li>
     *   <li>Error message (if the test failed)</li>
     * </ul>
     *
     * <p>The full page source is already persisted to {@code build/source/} by the
     * automation framework, so it is intentionally excluded here to keep the
     * attachment small (typically 200 KB – 1 MB vs 4–11 MB for the enriched version).
     */
    private static byte[] buildCompactHtmlReport(ITestResult result, String verdict,
                                                  String quoteNumber) {
        String methodName  = result.getMethod().getMethodName();
        String environment = RallyService.getInstance().getEnvironment();
        String timestamp   = java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC)
                .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss 'UTC'"));

        String badgeColor = RallyService.VERDICT_PASS.equals(verdict)    ? "#28a745"
                          : RallyService.VERDICT_FAIL.equals(verdict)    ? "#dc3545"
                          : RallyService.VERDICT_BLOCKED.equals(verdict) ? "#fd7e14"
                          : "#6c757d";

        byte[] screenshotBytes = RallyContext.getScreenshotBytes();

        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html><html><head>")
            .append("<meta charset=\"UTF-8\">")
            .append("<title>").append(escapeHtml(methodName)).append("</title>")
            .append("<style>")
            .append("body{margin:0;font-family:Arial,Helvetica,sans-serif;background:#f5f5f5;}")
            .append(".header{background:#1B365D;color:#fff;padding:16px 20px;}")
            .append(".header h2{margin:0 0 6px;font-size:17px;}")
            .append(".badge{display:inline-block;background:").append(badgeColor)
            .append(";color:#fff;padding:2px 12px;border-radius:3px;font-weight:bold;font-size:13px;}")
            .append(".meta{background:#fff;border:1px solid #dee2e6;border-radius:6px;")
            .append("margin:14px;padding:14px 18px;font-size:13px;}")
            .append(".meta table{border-collapse:collapse;width:100%;}")
            .append(".meta td{padding:5px 10px;border-bottom:1px solid #f0f0f0;}")
            .append(".meta td:first-child{font-weight:bold;color:#495057;width:130px;}")
            .append(".screenshot{margin:0 14px 14px;}")
            .append(".screenshot img{max-width:100%;border:1px solid #ccc;border-radius:4px;display:block;}")
            .append(".error{background:#f8d7da;border-left:4px solid #dc3545;margin:0 14px 14px;")
            .append("padding:12px 16px;font-size:13px;border-radius:4px;word-break:break-word;}")
            .append("</style></head><body>");

        // Header
        html.append("<div class=\"header\">")
            .append("<h2>").append(escapeHtml(methodName)).append("</h2>")
            .append("<span class=\"badge\">").append(escapeHtml(verdict)).append("</span>")
            .append("</div>");

        // Metadata table
        html.append("<div class=\"meta\"><table>");
        html.append(metaRow("Timestamp", timestamp));
        if (environment != null && !environment.isEmpty())
            html.append(metaRow("Environment", environment));
        if (quoteNumber != null && !quoteNumber.isEmpty())
            html.append(metaRow("Quote",       quoteNumber));
        html.append(metaRow("Class",
                result.getMethod().getTestClass().getName()
                      .replaceAll(".*\\.", "")));   // simple class name only
        html.append("</table></div>");

        // Error message (failures only)
        if (result.getThrowable() != null) {
            String msg = result.getThrowable().getMessage();
            if (msg != null && !msg.isEmpty()) {
                String truncated = msg.length() > 800 ? msg.substring(0, 800) + "…" : msg;
                html.append("<div class=\"error\"><strong>Failure reason:</strong><br>")
                    .append(escapeHtml(truncated)).append("</div>");
            }
        }

        // Screenshot
        if (screenshotBytes != null && screenshotBytes.length > 0) {
            html.append("<div class=\"screenshot\">")
                .append("<img src=\"data:image/png;base64,")
                .append(Base64.getEncoder().encodeToString(screenshotBytes))
                .append("\" alt=\"Test screenshot\"/>")
                .append("</div>");
        }

        html.append("</body></html>");
        return html.toString().getBytes(StandardCharsets.UTF_8);
    }

    private static String metaRow(String label, String value) {
        return "<tr><td>" + escapeHtml(label) + "</td><td>" + escapeHtml(value) + "</td></tr>";
    }

    /**
     * Builds a styled HTML banner fragment (info bar + embedded screenshot).
     * All styles are inline so the fragment is self-contained.
     */
    private static String buildReportBanner(ITestResult result, String verdict,
                                            String quoteNumber, byte[] screenshotBytes) {
        String badgeColor = RallyService.VERDICT_PASS.equals(verdict)    ? "#28a745"
                          : RallyService.VERDICT_FAIL.equals(verdict)    ? "#dc3545"
                          : RallyService.VERDICT_BLOCKED.equals(verdict) ? "#fd7e14"
                          : "#6c757d";

        StringBuilder sb = new StringBuilder();

        // Info bar
        sb.append("<div id=\"rally-info-bar\" style=\"font-family:Arial,Helvetica,sans-serif;"
                + "background:#1B365D;color:#fff;padding:14px 20px;margin:0;\">\n");
        sb.append("  <h2 style=\"margin:0 0 6px 0;font-size:17px;font-weight:bold;\">")
          .append(escapeHtml(result.getMethod().getMethodName())).append("</h2>\n");
        sb.append("  <p style=\"margin:0;font-size:13px;\">")
          .append("Status:&nbsp;<span style=\"background:").append(badgeColor)
          .append(";padding:2px 10px;border-radius:3px;font-weight:bold;\">")
          .append(escapeHtml(verdict)).append("</span>");
        if (quoteNumber != null && !quoteNumber.isEmpty()) {
            sb.append("&nbsp;&nbsp;|&nbsp;&nbsp;Quote:&nbsp;<strong>")
              .append(escapeHtml(quoteNumber)).append("</strong>");
        }
        sb.append("</p>\n</div>\n");

        // Embedded screenshot
        if (screenshotBytes != null && screenshotBytes.length > 0) {
            sb.append("<div id=\"rally-screenshot\" style=\"background:#f8f9fa;"
                    + "border-bottom:2px solid #dee2e6;padding:10px 20px;\">\n");
            sb.append("  <p style=\"margin:0 0 8px 0;font-family:Arial,Helvetica,sans-serif;"
                    + "font-size:13px;font-weight:bold;\">Screenshot &mdash; final state after test</p>\n");
            sb.append("  <img src=\"data:image/png;base64,")
              .append(Base64.getEncoder().encodeToString(screenshotBytes))
              .append("\" style=\"max-width:100%;border:1px solid #ccc;display:block;\""
                    + " alt=\"Test screenshot\"/>\n");
            sb.append("</div>\n");
        }

        return sb.toString();
    }

    private static String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    /**
     * Injects {@code <base href="origin/">} so that all relative resource paths
     * (CSS, JS, images) resolve from the app's origin when the HTML is opened
     * from Rally without a local server.
     */
    private static String injectBaseTag(String html, String currentUrl) {
        if (html == null || html.isEmpty() || html.contains("<base ")) return html;
        String origin = currentUrl;
        try {
            URL url = new URL(currentUrl);
            origin = url.getProtocol() + "://" + url.getHost()
                   + (url.getPort() != -1 ? ":" + url.getPort() : "");
        } catch (Exception ignored) {}
        String baseTag  = "<base href=\"" + origin + "/\">";
        String injected = html.replaceFirst("(?i)(<head[^>]*>)", "$1" + baseTag);
        return injected.contains(baseTag) ? injected : baseTag + html;
    }

    private static File findPageSourceFile(String testMethodName) {
        try {
            File sourceDir = new File(System.getProperty("user.dir"), "build/source");
            if (!sourceDir.exists()) return null;
            String suffix = "-" + testMethodName + ".html";
            File[] matches = sourceDir.listFiles(f -> f.getName().endsWith(suffix));
            if (matches == null || matches.length == 0) return null;
            return Arrays.stream(matches)
                    .max(Comparator.comparingLong(File::lastModified))
                    .orElse(null);
        } catch (Exception e) {
            Log.debug("RallyListener: page-source file lookup failed – " + e.getMessage());
            return null;
        }
    }

    private static byte[] readFileQuietly(File file) {
        try {
            return Files.readAllBytes(file.toPath());
        } catch (Exception e) {
            Log.debug("RallyListener: could not read file " + file + " – " + e.getMessage());
            return null;
        }
    }

    // ------------------------------------------------------------------
    // Annotation helpers
    // ------------------------------------------------------------------

    private List<String> getRallyIds(ITestResult result) {
        try {
            Method method = result.getMethod().getConstructorOrMethod().getMethod();
            RallyTestCase annotation = method.getAnnotation(RallyTestCase.class);
            if (annotation == null) annotation = method.getDeclaringClass().getAnnotation(RallyTestCase.class);
            if (annotation != null && annotation.ids().length > 0) return Arrays.asList(annotation.ids());
        } catch (Exception e) {
            Log.error("RallyListener: could not read @RallyTestCase – " + e.getMessage(), false);
        }
        return Collections.emptyList();
    }

    // ------------------------------------------------------------------
    // Quote number from session storage
    // ------------------------------------------------------------------

    private static String readQuoteNumberFromSessionStorage(ITestResult result) {
        try {
            Object driver = getDriver(result);
            if (!(driver instanceof PWJavascriptExecutor)) return null;

            String json = (String) ((PWJavascriptExecutor) driver)
                    .executeScript("return sessionStorage.getItem('appStore')");
            if (json == null || json.isEmpty()) {
                Log.debug("RallyListener: sessionStorage.appStore empty – no quote number");
                return null;
            }

            ObjectMapper mapper = new ObjectMapper()
                    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            AppStore appStore = mapper.readValue(json, AppStore.class);

            if (appStore.getData() != null && appStore.getData().getQuoteNumber() != null) {
                return appStore.getData().getQuoteNumber();
            }
            if (appStore.getHome() != null
                    && appStore.getHome().getQuote() != null
                    && appStore.getHome().getQuote().getQuoteNumber() != null) {
                return appStore.getHome().getQuote().getQuoteNumber();
            }
        } catch (Exception e) {
            Log.debug("RallyListener: could not read quote number – " + e.getMessage());
        }
        return null;
    }


    private static Object getDriver(ITestResult result) throws Exception {
        Object instance = result.getInstance();
        Class<?> clazz  = instance.getClass();
        while (clazz != null) {
            try {
                Method m = clazz.getDeclaredMethod("driver");
                m.setAccessible(true);
                return m.invoke(instance);
            } catch (NoSuchMethodException e) {
                clazz = clazz.getSuperclass();
            }
        }
        return null;
    }


    private String buildNotes(ITestResult result, String verdict, String quoteNumber) {
        StringBuilder sb = new StringBuilder();
        sb.append("Test: ").append(result.getMethod().getMethodName());
        sb.append(" | Status: ").append(verdict);

        String env = rally.getEnvironment();
        if (env != null && !env.isEmpty()) sb.append(" | Env: ").append(env);

        if (quoteNumber != null && !quoteNumber.isEmpty()) sb.append(" | Quote: ").append(quoteNumber);

        try {
            Method method = result.getMethod().getConstructorOrMethod().getMethod();
            RallyTestCase ann = method.getAnnotation(RallyTestCase.class);
            if (ann == null) ann = method.getDeclaringClass().getAnnotation(RallyTestCase.class);
            if (ann != null && !ann.description().isEmpty()) sb.append(" | ").append(ann.description());
        } catch (Exception ignored) {}

        if (result.getThrowable() != null) {
            String msg = result.getThrowable().getMessage();
            if (msg != null && !msg.isEmpty())
                sb.append(" | Error: ").append(msg.length() > 500 ? msg.substring(0, 500) + "..." : msg);
        }
        return sb.toString();
    }
}
