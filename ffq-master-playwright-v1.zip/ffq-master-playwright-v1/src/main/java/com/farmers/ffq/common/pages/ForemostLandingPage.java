package com.farmers.ffq.common.pages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.ace.hrc.common.AceHRCAddressBasePage;
import com.farmers.ffq.utils.FarmersSoftAssert;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class ForemostLandingPage extends AceHRCAddressBasePage {

    @PWFindBy(xpath = "//h1[@id='foremost_title']")
    PWElement foremostTitle;
    @PWFindBy(xpath = "(//div[contains(@class, 'content-rebrand')])[1]")
    PWElement foremostSubtitle;
    @PWFindBy(xpath = "//app-foremost-interstitial//mat-card//img")
    PWElement foremostLogo;
    @PWFindBy(xpath = "//div[contains(@class,'foremost_description')]")
    PWElement foremostDescription;
    @PWFindBy(xpath = "//div[@aria-labelledby='Request a quote']")
    PWElement requestAQuoteLabel;
    @PWFindBy(xpath = "//button[contains(@class,'foremost_continue_button')]")
    PWElement foremostContinueButton;
    @PWFindBy(xpath = "//div[@aria-labelledby='prefer to call?']")
    PWElement preferToCallLabel;
    @PWFindBy(xpath = "//button[contains(@class,'foremost-rebrand-call-btn')]")
    PWElement foremostContactButton;
    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public ForemostLandingPage() throws Exception {
    }

    public void clickContinueWithForeMostButton(){
        clickElement(foremostContinueButton);
    }

    public void validateContentOfContinueWithForeMostScreen(FarmersSoftAssert fsa, String lobType){
        waitForPageToBeReady();
        final String expectedForeMostTitle = "It's not you. It's us.";
        fsa.assertEquals(getTextFromElement(foremostTitle), expectedForeMostTitle, "Foremost title validation - " + lobType);

        String separator = isSafariBrowser() ? EMPTY_STRING : SPACE;
        final String expectedForeMostSubTitle = "We think you're great. We just can't offer you a Farmers quote right now." + separator +
                "Why? It could be your location. It could be risk related. It could be something out of our hands." + separator +
                "The good news is that we can still help you find coverage today." + separator + "Foremost® — part of the Farmers family — thinks you're a catch. " +
                "We can connect you in a click so you can explore more coverage options." + separator + "Sound good?" + separator + "Tap below now to continue.";
        fsa.assertEquals(getTextFromElement(foremostSubtitle), expectedForeMostSubTitle, "Foremost sub-title text validation - " + lobType);

        fsa.assertTrue(foremostLogo.isDisplayed(), "Foremost logo validation - " + lobType);

        final String expectedForemostDescription = "Foremost® - A Farmers Insurance® Company -- is focused on providing A Better Insurance Experience® to all customers." +
                (isSafariBrowser() ? EMPTY_STRING : SPACE) +
                "Foremost® offers flexible payment plans, numerous discounts, and every policy includes claim service with 24/7 access and award-winning, distinctive service.";
        fsa.assertEquals(getTextFromElement(foremostDescription), expectedForemostDescription, "Foremost description validation - " + lobType);

        final String expectedRequestAQuoteLabel = "Request a quote";
        fsa.assertEquals(getTextFromElement(requestAQuoteLabel), expectedRequestAQuoteLabel, "Request a quote label - " + lobType);

        final String expectedContinueWithFarmersButtonText = "Continue";
        fsa.assertTrue(foremostContinueButton.isDisplayed(), "Continue button displayed - " + lobType);
        fsa.assertEquals(getTextFromElement(foremostContinueButton), expectedContinueWithFarmersButtonText, "Continue button text validation - " + lobType);        final String expectedPreferToCallLabel = "Prefer to call?";
        fsa.assertEquals(getTextFromElement(preferToCallLabel), expectedPreferToCallLabel, "Prefer to call label validation - " + lobType);

        final String expectedForeMostContactButtonText = "888-846-6077";
        fsa.assertTrue(foremostContactButton.isDisplayed(), "Foremost contact button displayed - " + lobType);
        fsa.assertEquals(getTextFromElement(foremostContactButton), expectedForeMostContactButtonText, "Foremost contact button text validation - " + lobType);
    }

    public void validateURLAfterClickingOnContinueWithForeMostButton(FarmersSoftAssert fsa, String selectedOption, String lobType) throws Exception {
        clickContinueWithForeMostButton();
        String landingUrlPartialLinkText = "";
        if(selectedOption.equals(MOBILE_MANUFACTURED_HOME)){
            landingUrlPartialLinkText = "get-mobile-home-estimate";
        }  else if(List.of(RENT, PART_TIME, OTHER).contains(selectedOption)){
            landingUrlPartialLinkText = "get-landlord-rental-property-estimate-request";
        }

        fsa.assertTrue(driver().getCurrentUrl().contains(landingUrlPartialLinkText),
                "Foremost landing page landed on expected landing page for selected reason/property - " + selectedOption + " - " + lobType);
    }
}
