package com.farmers.ffq.datatransferobjects;

import com.farmers.ffq.dataproviderframework.DataObjectBase;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ApplicantCondo extends DataObjectBase {

    private String firstName;
    private String lastName;
    private int age;
    private String gender;
    private String scenario;
    private String zipCode;
    private String maritalStatus;
    private String spouseFirstName;
    private String spouseLastName;
    private int spouseAge;
    private String spouseGender;
    private String addressApt;
    private String aptNumber;
    private String city;
    private String stateCode;
    private boolean mailingAddressDifferent;
    private String mailingAddress;
    private String mailingAddressApt;
    private String mailingCity;
    private String mailingState;
    private String mailingZipCode;
    private String state;
    private int propertyValue;
    private String numberOfUnits;
    private String numberOfPropertyLosses;
    private String phoneNumber;
    private String emailAddress;
    // Discount Variables
    private String occupation;
    private String spouseOccupation;
    private boolean nonSmokingOccupants;
    private boolean fireSprinklerInUnit;
    private boolean centralBurglarAlarmService;
    private boolean centralFireAlarmService;
    private boolean ironBarsPresent;
    private boolean localBurglarAlarm;
    private String packageName;
    private String currentHomeCarrier;
    private int yearBuilt;
    private boolean hurricaneShutters;
    private String typeOfConstruction;
    private String policyStartDate;
    // Redesign datapoints
    private boolean ownedLessThanAYear;
    private boolean inEscrow;
    private boolean primaryResidence;
    private String usage;
    private boolean hoaCovered;

    // Save and retrieve return page
    private boolean saveAndRetrievePropPage;
    private boolean saveAndRetrieveDiscountPage;
    private boolean saveAndRetrieveQuotePage;
    private ApplicantRetQuote applicantRetQuote;
    private boolean getRetrieveScenario;
    
    // Cross sell variables (not in spreadsheet)
    private boolean bundleAutoInsurance;
    private boolean bundleValueTermLifeInsurance;
    
    /* String Representation of Applicant class.
     */
    public String toString() {
        return String.format("#%s: %s %s %s %s %s %s", getId(), firstName, lastName, addressApt, city, state, zipCode);
   }
}
