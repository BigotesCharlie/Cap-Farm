/**
=============================================
* Author:	Zhabiz Sonee
* Create date:	02/01/2017
=============================================
*/
package com.farmers.ffq.datatransferobjects;
import lombok.Data;

@Data
public class State {
	
	private String testCategory;
	private String testScenario;	
	private String zipCode;
	private String stateCode;
	private String stateName;

	/**
	 * String Representation of State class.
	 */
	public String toString() {
		return String.format("%s - %s %s", testScenario, stateName, zipCode);
	}
}
