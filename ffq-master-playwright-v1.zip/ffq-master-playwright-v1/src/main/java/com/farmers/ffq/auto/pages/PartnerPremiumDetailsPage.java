package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
public class PartnerPremiumDetailsPage extends AutoBasePage {

	@PWFindBy(xpath = "//app-partner-premium-details//h1")
    private PWElement partnerDetailsPageTitle;

    public PartnerPremiumDetailsPage() throws Exception {
    }

    public boolean isOnPartnerPremiumDetailsPage() {
        return isElementVisible(partnerDetailsPageTitle, 10);
    }

}
