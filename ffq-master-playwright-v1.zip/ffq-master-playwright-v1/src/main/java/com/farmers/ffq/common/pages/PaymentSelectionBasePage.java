package com.farmers.ffq.common.pages;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import java.text.DecimalFormat;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class PaymentSelectionBasePage extends AutoBasePage {
    protected static final String BANK_PAYMENT = "Bank payment";
    public static final String CARD = "Card";
    public static final String PAY_IN_FULL = "Pay in full";
    public static final String MONTHLY_AUTOPAY = "Monthly Autopay";
    public static final String PAY_IN_FULL_BANK_DEBIT = "Pay in full – bank or debit card";
    public static final String PAY_IN_FULL_CREDIT_CARD = "Pay in full – credit card";
    protected static final String VIEW_CREDIT_CARD_PRICE = "View credit card price";
    protected static final String TOTAL_PRICE_UPDATED = "Total price updated";
    protected static final String CREDIT_CARD = "Credit card";
    protected static final String DEBIT_CARD = "Debit card";
    protected static final String PAYMENT_METHOD = "Payment method";
    protected static final String ADD_YOUR_PREFERRED_PAYMENT_METHOD = "Add your preferred payment method.";
    protected static final String CHANGE_TO_NEW_PAYMENT_METHOD = "Change to a new payment method";
    protected static final String EDIT_PAYMENT_METHOD = "Edit payment method";
    protected static final String EXCLUDE_TAXES_TEXT= "Excludes taxes, fees, and surcharges";

    @PWFindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL + "')]")
    protected List<PWElement> payInFullHeader;
    protected static final String HOW_WOULD_YOU_LIKE_TO_PAY = "How would you like to pay?";
    @PWFindBy(xpath = "//h1[contains(text(), '" + HOW_WOULD_YOU_LIKE_TO_PAY + "')]")
    protected PWElement howWouldYouLikeToPay;
    @PWFindBy(xpath = "//app-payment-consolidated//h1")
    protected PWElement consolidatedPaymentPageHeader;
    @PWFindBy(xpath = "//app-payment-overview//h1")
    protected PWElement consolidatedPaymentPageHeaderBw;
    protected static final String BEST_VALUE_SUBHEADER = "Best value";
    @PWFindBy(xpath = "//p[contains(text(), '" + BEST_VALUE_SUBHEADER + "')]")
    protected List<PWElement> bestValueSubHeader;
    protected static final String ONE_TIME_PAYMENT = "One-time payment";
    @PWFindBy(xpath = "//p[contains(text(), '" + ONE_TIME_PAYMENT + "')]")
    protected List<PWElement> oneTimePaymentSubHeader;

    protected static final String SELECT_SETUP_PAYMENT = "Select & set up payment";
    @PWFindBy(xpath = "//mat-tab-group//button[contains(text(), '" + SELECT_SETUP_PAYMENT + "')]")
    protected PWElement selectAndSetUpPayment;

    @PWFindBy(xpath = "//*[contains(@class,'disclaimers-charge-text')]")
    protected PWElement disclaimerChargeText;

    // Preferred payment plan savings
    protected static final String PREFERRED_PAYMENT_PLAN_SAVINGS = "Preferred payment plan savings";
    @PWFindBy(xpath = "//p[contains(text(), '" + PREFERRED_PAYMENT_PLAN_SAVINGS + "')]")
    protected List<PWElement> preferredPayPlanSavings;


    private static final String PAYMENTUS_MANAGE_PAYMENT = "Paymentus Manage Payments";
    @PWFindBy(xpath = "//iframe[@title = '" + PAYMENTUS_MANAGE_PAYMENT + "']")
    private PWElement paymentUsIframe;

    //No service charge
    protected static final String NO_SERVICE_CHARGE = "No service charge";
    @PWFindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL +"')]/ancestor::mat-card//p[contains(text(),'" + NO_SERVICE_CHARGE + "')]")
    protected List<PWElement> noServiceChargeWhenPayInFull;

    @PWFindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL +"')]/ancestor::mat-card//p[contains(text(),'" + EXCLUDE_TAXES_TEXT + "')]")
    protected List<PWElement> excludeFeesSurchargePayInFull;

    @PWFindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL +"')]/ancestor::mat-card//p[contains(text(),'" + INCLUDES_ALL_FEES + "')]")
    protected List<PWElement> includeAllFeesPayInFull;

    protected static final String BANK_DEBIT_CREDIT_PAYMENT = "Bank payment, debit card, or credit card";
    @PWFindBy(xpath = "//p[contains(text(), '" + BANK_DEBIT_CREDIT_PAYMENT + "')]")
    protected List<PWElement> bankDebitCreditCardPayment;

    protected static final String MONTHLY_AUTO_PAY_BANK_HEADER = "Monthly autopay - bank";
    protected static final String MONTHLY_AUTO_PAY_CARD_HEADER = "Monthly autopay - card";
    public static final String MONTHLY_DIRECT_BILL = "Monthly - direct bill";
    public static final String MONTHLY_DIRECT_BILL_PARENTHESIS = "Monthly (direct bill)";

    protected static final String MONTHLY_PAY_BANK_HEADER = "Monthly - bank";
    protected static final String MONTHLY_PAY_CARD_HEADER = "Monthly - card";

    @PWFindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_BANK_HEADER + "')]")
    protected List<PWElement> payInMonthlyPayBankHeader;

    protected static final String CONVENIENT = "Convenient";
    @PWFindBy(xpath = "//p[contains(text(), '" + CONVENIENT + "')]")
    protected PWElement convenientHeader;

    protected static final String AUTO_PAY_SAVINGS_TEXT = "Autopay savings";
    protected String AUTO_PAY_SAVINGS_XPATH = "//p[contains(@class,'payment-overview-icon-padding')]";
    protected String AUTO_PAY_SAVINGS_XPATH_GREEN_CHECKMARK = "//mat-icon[contains(@class,'payment-overview-green-mark')]";
    protected static final String DOWN_PAYMENT_XPATH = "//div[@class='tui-payplan']";
    protected static final String TOTAL_PAYMENT_OVERVIEW_CARD_PREMIUM_XPATH = "//div[contains(@class,'payment-overview-card-premium-font')]";

    protected static final String MONTHLY_SERVICE_CHARGE = "Monthly service charge:";
    protected static final String INCLUDES_ALL_FEES = "(includes all fees)";
    @PWFindBy(xpath = "//p[contains(text(), '" + INCLUDES_ALL_FEES + "')]")
    protected PWElement includedAllFeesLabel;

    protected static final String CHANGE_LINK = "Change";
    @PWFindBy(xpath = "//a[contains(text(), '" + CHANGE_LINK + "')]")
    protected PWElement changeLink;
    private static final String BANK_OF_AMERICA = "BANK OF AMERICA, N.A. SFNB";
    @PWFindBy(xpath = "//span[@class='pm-display-bank-name bank-found']")
    private PWElement bankNameLabel;
    private static final String BANK_PAYMENT_ACCOUNT_ADDED = "Bank payment account added.";
    @PWFindBy(xpath = "//span[text() = '" + BANK_PAYMENT_ACCOUNT_ADDED + "']")
    private PWElement bankPaymentAddedMessage;

    @PWFindBy(xpath = "//i[@class='tui-icon tui-icon-generic-payment ng-star-inserted']")
    private PWElement bankIcon;

    private static final String SAVING_LABEL = "Savings";
    @PWFindBy(xpath = "//label[text() = '" + SAVING_LABEL + "']")
    private PWElement savingsLabel;

    private static final String BUSINESS_CHECKING_LABEL = "Business Checking";
    @PWFindBy(xpath = "//label[text() = '" + BUSINESS_CHECKING_LABEL + "']")
    private PWElement businessCheckingLabel;

    // paymentus iframe locators
    @PWFindBy(xpath = "//*[@aria-label='Edit payment method' and not(@role='dialog')]")
    protected PWElement paymentusIframeHeader;
    protected static final String BANK_PAYMENT_TOGGLE_BUTTON_TITLE = "Bank payment";
    @PWFindBy(xpath = "//div[@role='tab'][contains(.,'" + BANK_PAYMENT_TOGGLE_BUTTON_TITLE + "')]")
    protected PWElement paymentusBankPaymentToggle;
    @PWFindBy(xpath = "//div[@role='tab'][contains(.,'" + BANK_PAYMENT_TOGGLE_BUTTON_TITLE + "')]/span")
    protected PWElement paymentusBankPaymentToggleButton;
    protected static final String DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE = "Debit / Credit card";
    @PWFindBy(xpath = "//div[@role='tab'][contains(.,'" + DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE + "')]")
    protected PWElement paymentusDebitCreditCardToggle;
    @PWFindBy(xpath = "//div[@role='tab'][contains(.,'" + DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE + "')]/div")
    protected PWElement paymentusDebitCreditCardToggleButton;
    @PWFindBy(xpath = "//legend")
    protected PWElement paymentusBankAccountTypeHeader;
    @PWFindBy(xpath = "//fieldset//input[@id='checking']")
    protected PWElement paymentusCheckingAccountRadioButton;
    @PWFindBy(xpath = "//fieldset//input[@id='savings']")
    protected PWElement paymentusSavingsAccountRadioButton;
    @PWFindBy(xpath = "//fieldset//input[@id='busChecking']")
    protected PWElement paymentusBusinessCheckingAccountRadioButton;
    @PWFindBy(xpath = "//fieldset//label[@for='busChecking']")
    protected PWElement paymentusCheckingAccountLabel;
    @PWFindBy(xpath = "//fieldset//label[@for='savings']")
    protected PWElement paymentusSavingsAccountLabel;
    @PWFindBy(xpath = "//fieldset//label[@for='busChecking']")
    protected PWElement paymentusBusinessCheckingAccountLabel;
    @PWFindBy(xpath = "//input[@id='accountHolderField']")  // @id='cardHolderField'
    protected PWElement paymentusAccountHolderInput;
    @PWFindBy(xpath = "//span[contains(@class,'pm-display-logo-visa')]")
    private PWElement visaCardIcon;
    @PWFindBy(xpath = "//input[@id='cardNumberField']")
    private PWElement cardNumberInputField;
    @PWFindBy(xpath = "//span[contains(@class,'pm-display-logo-mc')]")
    private PWElement masterCardIcon;
    @PWFindBy(xpath = "//span[contains(@class,'pm-display-logo-disc')]")
    private PWElement discoverCardIcon;
    @PWFindBy(xpath = "//span[contains(@class,'pm-display-logo-amex')]")
    private PWElement amexCardIcon;

    @PWFindBy(xpath = "//label[@for='accountHolderField']")
    protected PWElement paymentusAccountHolderLabel;
    @PWFindBy(xpath = "//input[@id='cardHolderField']")
    protected PWElement paymentusCardHolderInput;
    @PWFindBy(xpath = "//label[@for='cardHolderField']")
    protected PWElement paymentusCardHolderLabel;
    @PWFindBy(xpath = "//input[@id='routingNumberField']")
    protected PWElement paymentusRoutingNumberInput;
    @PWFindBy(xpath = "//label[@for='routingNumberField']")
    protected PWElement paymentusRoutingNumberLabel;
    @PWFindBy(xpath = "//input[@id='cardNumberField']")
    protected PWElement paymentusCardNumberInput;
    @PWFindBy(xpath = "//label[@for='cardNumberField']")
    protected PWElement paymentusCardNumberLabel;
    @PWFindBy(xpath = "//div[contains(@class,'methodVisa')]")
    protected PWElement paymentusVisaCardIcon;
    @PWFindBy(xpath = "//div[contains(@class,'methodMastercard')]")
    protected PWElement paymentusMasterCardIcon;
    @PWFindBy(xpath = "//div[contains(@class,'methodDiscover')]")
    protected PWElement paymentusDiscoverCardIcon;
    @PWFindBy(xpath = "//div[contains(@class,'methodAmex')]")
    protected PWElement paymentusAmexCardIcon;
    @PWFindBy(xpath = "//input[@id='bankAccountField']")
    protected PWElement paymentusAccountNumberInput;
    @PWFindBy(xpath = "//label[@for='bankAccountField']")
    protected PWElement paymentusAccountNumberLabel;
    @PWFindBy(xpath = "//input[@id='ccExpirationDate']")
    protected PWElement paymentusCardExpirationDateInput;
    @PWFindBy(xpath = "//label[@for='ccExpirationDate']")
    protected PWElement paymentusCardExpirationDateLabel;
    @PWFindBy(xpath = "//input[@id='cardCVVField']")
    protected PWElement paymentusCardCVVFieldInput;
    @PWFindBy(xpath = "//label[@for='cardCVVField']")
    protected PWElement paymentusCardCVVFieldLabel;
    @PWFindBy(xpath = "//input[@id='zipCode']")
    protected PWElement paymentusZipCodeInput;
    @PWFindBy(xpath = "//label[@for='zipCode']")
    protected PWElement paymentusZipCodeLabel;
    @PWFindBy(xpath = "//input[@id='confirmBankAccountField']")
    protected PWElement paymentusConfirmAccountNumberInput;
    @PWFindBy(xpath = "//label[@for='confirmBankAccountField']")
    protected PWElement paymentusConfirmAccountNumberLabel;
    @PWFindBy(xpath = "//button[@name='submitBtn']")
    protected PWElement paymentusAddButton;
    @PWFindBy(xpath = "//a[contains(.,'Change')]")
    protected PWElement changePaymentMethodLink;

    private static final String ENTER_VALID_ACCOUNT_HOLDER_NAME_ERROR = "Please enter a valid account holder name.";
    @PWFindBy(xpath = "//span[text() = '" + ENTER_VALID_ACCOUNT_HOLDER_NAME_ERROR + "']")
    private PWElement enterValidAccountHolderNameError;

    private static final String ENTER_VALID_ROUTING_NUMBER_ERROR = "Please enter a valid routing number.";
    @PWFindBy(xpath = "//span[text() = '" + ENTER_VALID_ROUTING_NUMBER_ERROR + "']")
    private PWElement enterValidRoutingNumberError;

    private static final String ENTER_VALID_ACCOUNT_NUMBER_ERROR = "Please enter a valid bank account number.";
    @PWFindBy(xpath = "//span[text() = '" + ENTER_VALID_ACCOUNT_NUMBER_ERROR + "']")
    private PWElement enterValidAccountNumberError;

    private static final String BANK_ACCOUNT_NUMBERS_DO_NOT_MATCH_ERROR = "The bank account numbers do not match. Please re-enter your bank account number.";
    @PWFindBy(xpath = "//span[text() = '" + BANK_ACCOUNT_NUMBERS_DO_NOT_MATCH_ERROR + "']")
    private PWElement bankAccountNumbersDoNotMatchError;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public PaymentSelectionBasePage() throws Exception {
    }

    public String getDownPayment(AppStore appStore, String payPlanDescription) throws Exception {
        List<AppStore.VerifyResponse.PaymentSchedule> monthlyEffectivePayPlan = filterListOfPaymentScheduleByPayPlan(appStore.getVerifyResponse().getPaymentSchedules(), payPlanDescription);
        return monthlyEffectivePayPlan.get(0).getDownPayment().getAmount().getAmount();
    }

    protected String getInstallmentAmountFarmers(String paymentMethod) throws Exception {
        if (paymentMethod.equals(PAY_IN_FULL)) {
            return getFullTermPremiumAmountFarmers(paymentMethod);
        }
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPayPlanCode().equals(convertPaymentMethodToPayPlanCodeFarmers(paymentMethod))).findFirst().get().getInstallments().get(0).getCurrencyAmount();
    }

    protected String getInstallmentAmountBw(String paymentMethod) throws Exception {
        if (paymentMethod.equals(PAY_IN_FULL)) {
            return getFullTermPremiumAmountBW(paymentMethod);
        }
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPaymentMethod().equals(convertPaymentMethodToPayPlanCodeBW(paymentMethod))).findFirst().get().getInstallmentAmount();
    }

    protected String getFullTermPremiumAmountFarmers(String paymentMethod) throws Exception {
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPaymentMethod().equals(convertPaymentMethodToPayPlanCodeFarmers(paymentMethod))).findFirst().get().getFullTermPremium();
    }

    protected String getFullTermPremiumAmountBW(String paymentMethod) throws Exception {
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPaymentMethod().equals(convertPaymentMethodToPayPlanCodeBW(paymentMethod))).findFirst().get().getFullTermPremium();
    }

    public String convertPaymentMethodToPayPlanCodeBW(String paymentMethod) {
        switch (paymentMethod) {
            case PAY_IN_FULL:
                return "PIF";
            case MONTHLY_AUTO_PAY_BANK_HEADER:
                return "EFTB";
            case MONTHLY_AUTO_PAY_CARD_HEADER:
                return "EFTC";
            case MONTHLY_DIRECT_BILL:
                return "NON";
            case MONTHLY_AUTOPAY:
                return "MTEF";
            default:
                Log.error("Please provide acceptable payment method");
                return null;
        }
    }

    public String convertPaymentMethodToPayPlanCodeFarmers(String paymentMethod) {
        switch (paymentMethod) {
            case PAY_IN_FULL:
                return "A1";
            case MONTHLY_AUTO_PAY_BANK_HEADER:
            case MONTHLY_EFT:
                return "MTEF";
            case MONTHLY_AUTO_PAY_CARD_HEADER:
                return "MTPC";
            case MONTHLY_AUTOPAY:
            case MONTHLY_DEBIT_CARD_DESCRIPTION:
                return "MTPD";
            default:
                Log.error("Please provide acceptable payment method");
                return null;
        }
    }

    public List<AppStore.VerifyResponse.PaymentSchedule> filterListOfPaymentScheduleByPayPlan(List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules, String payPlanDescription){
        System.out.println("Payment schedules " + paymentSchedules);
        return  paymentSchedules.stream().filter(c -> c.getPayPlanDescription().equals(payPlanDescription)).collect(Collectors.toList());
    }

    public Double doublePolicyFeeAmount(String policyFee){
        Double doublePolicyFees = 0.0;
        if(!policyFee.equals("")){
            doublePolicyFees = Double.parseDouble(policyFee);
        }
        return doublePolicyFees;
    }

    public List<String> splitAmountByDecimalPoint(String fullAmount){
        String[] splitAmountByDecimalPoint = fullAmount.split("\\.");

        List<String> splittedAmountList = null;
        if(splitAmountByDecimalPoint.length == 2){
            splittedAmountList = Arrays.asList(splitAmountByDecimalPoint[0], splitAmountByDecimalPoint[1]);
        }else{
            splittedAmountList = Arrays.asList(splitAmountByDecimalPoint[0]);
        }
        return splittedAmountList;
    }
    public List<PWElement> listOfFullAmountWebElements(String amount, String htmlElement, boolean isCurrencyFormat) throws Exception {
        String currencyFormatAmount = CurrencyFormat.convertStringIntoCurrencyFormat(amount);
        String amountOnePayXpath = "";
        if(isCurrencyFormat){
            amountOnePayXpath  = "//" + htmlElement + "[contains(text(), '" + currencyFormatAmount + "')]";
        }else{
            amountOnePayXpath  = "//" + htmlElement + "[contains(text(), '" + String.format("%,d", Integer.parseInt(amount)) + "')]";
        }

        return driver().findElements(PWBy.xpath(amountOnePayXpath));
    }

    public void isElementListSizeGreaterThanZero(List<PWElement> elementList, String message, FarmersSoftAssert fsa){
        fsa.assertTrue(!elementList.isEmpty(), message);
    }

    protected PWElement getPaymentCardSubHeaderByGivenPayMethod(String payMethod) throws Exception {
        return driver().findElement(PWBy.xpath(getPaymentCardXPathByGivenPayMethod(payMethod) + "//div[contains(@class,'tui-presentment-card-header-row-1')]//p"));
    }

    protected String getPaymentCardXPathByGivenPayMethod(String payMethod) {
        return String.format("//mat-card[contains(.,'%s')]", payMethod);
    }

    public int getAdministrativeFeeForGivenPayPlanDescription(List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules, String payPlanDescription) {
        AppStore.VerifyResponse.PaymentSchedule paymentSchedule = filterListOfPaymentScheduleByPayPlan(paymentSchedules, payPlanDescription).stream().findFirst().get();
        String currencyAmount = paymentSchedule.getAdministrativeCharges().getCurrencyAmount();
        return (int) Double.parseDouble(currencyAmount);
    }

    public String getFormattedDecimal(double number) {
        DecimalFormat decimalFormat = new DecimalFormat("#,###.00");
        return decimalFormat.format(number);
    }


    public void addCardPaymentMethod(String cardNumber, String zipCode) throws Exception {
        clickPaymentusIframeCardToggle();
        switchToPaymentUsIframe();
        String cvv = cardNumber.equals(AMERICAN_EXPRESS_CARD) ? "1234" : CVV_NUMBER;
        enterCardNumber(cardNumber);
        Log.info("Card number has been entered: " + cardNumber);

        if (isSafariBrowser()) {
            PWJavascriptExecutor js = driver();
            js.executeScript(String.format("arguments[0].value='%s';", EXP_DATE), paymentusCardExpirationDateInput);
        } else {
            enterExpDate(EXP_DATE);
        }

        Log.info("Exp date has been entered: " + EXP_DATE);
        sendKeysToElement(waitElementBeVisible(paymentusCardCVVFieldInput), cvv);
        Log.info("Cvv has been entered: " + cvv);
        sendKeysToElement(waitElementBeVisible(paymentusZipCodeInput), zipCode);
        Log.info("Zipcode has been entered: " + zipCode);
        waitAndClickElement(paymentusAddButton);
        switchToParentWindow();
        waitForSpinnerToBeGone();
    }

    private void clickPaymentusIframeCardToggle() {
        if (isElementDisplayed(paymentusDebitCreditCardToggle, 5)) {
            int retry = 3;
            while (!getAttributeData(paymentusDebitCreditCardToggle, ARIA_SELECTED).equals(LOWERCASE_TRUE) && retry > 0) {
                waitAndClickElement(paymentusDebitCreditCardToggleButton);
                retry--;
                sleep(1);
            }
        }
    }

    public void addCheckingAccountPaymentMethod(String routingNumber, String accountNumber) throws Exception {
        switchToPaymentUsIframe();
        enterRoutingNumber(routingNumber);
        Log.info("Routing Number has been entered: " + routingNumber);
        enterAccountNumber(accountNumber);
        Log.info("Account Number has been entered: " + accountNumber);
        sendKeysToElement(waitElementBeVisible(paymentusConfirmAccountNumberInput), accountNumber);
        waitAndClickElement(paymentusAddButton);
        switchToParentWindow();
        waitForSpinnerToBeGone();
    }

    public void switchToPaymentUsIframe() throws Exception {
        waitElementBeVisible(paymentUsIframe);
        driver().switchTo().frame(paymentUsIframe);
        wait.until(PWExpectedConditions.elementToBeClickable(paymentusAddButton));
    }

    public void isDisclaimerChargeTextCorrect(FarmersSoftAssert fsa, String expectedChargeMessage) {
        fsa.assertEquals(getTextFromElement(disclaimerChargeText), expectedChargeMessage, "Payment method charge disclaimer text validation");
    }

    public void enterCardNumber(String cardNumber){
        sendKeysToElement(waitElementBeVisible(paymentusCardNumberInput), cardNumber);
    }

    public void enterExpDate(String expDate){
        sendKeysToElement(waitElementBeVisible(paymentusCardExpirationDateInput), expDate);
    }

    public void enterRoutingNumber(String routingNumber){
        sendKeysToElement(waitElementBeVisible(paymentusRoutingNumberInput), routingNumber);
    }

    public void enterAccountNumber(String accountNumber){
        sendKeysToElement(waitElementBeVisible(paymentusAccountNumberInput), accountNumber);
    }

    public boolean isEditPaymentMethodLabelCorrect(){
        wait.until(PWExpectedConditions.visibilityOf(paymentusIframeHeader));
        return isExpectedTextDisplayed(paymentusIframeHeader, EDIT_PAYMENT_METHOD);
    }

    public void clickChangeLink(){
        waitAndClickElement(changeLink);
    }

    public boolean isBOFABankNameLabelCorrect(){
        wait.until(PWExpectedConditions.visibilityOf(bankNameLabel));
        return isExpectedTextDisplayed(bankNameLabel, BANK_OF_AMERICA);
    }

    public boolean isBankPaymentAccountAddedMsgCorrect() throws Exception {
        driver().switchTo().defaultContent();
        wait.until(PWExpectedConditions.visibilityOf(bankPaymentAddedMessage));
        sleep(3);
        return isExpectedTextDisplayed(bankPaymentAddedMessage, BANK_PAYMENT_ACCOUNT_ADDED);
    }

    public boolean isBankIconDisplayed(){
        wait.until(PWExpectedConditions.visibilityOf(bankIcon));
        return bankIcon.isDisplayed();
    }

    public void clickSavingsRadioButton(){
        waitAndClickElement(savingsLabel);
    }


    public void clickBusinessCheckingRadioButton(){
        waitAndClickElement(businessCheckingLabel);
    }

    public boolean isSavingsLabelCorrect(){
        return isExpectedTextDisplayed(savingsLabel, SAVING_LABEL);
    }

    public boolean isBusinessCheckingLabelCorrect(){
        return isExpectedTextDisplayed(businessCheckingLabel, BUSINESS_CHECKING_LABEL);
    }

    public void clearOutAccountHolderInputField(){
        paymentusAccountHolderInput.clear();
    }
    public boolean isEnterValidAccountHolderNameErrorCorrect(){
        wait.until(PWExpectedConditions.visibilityOf(enterValidAccountHolderNameError));
        return isExpectedTextDisplayed(enterValidAccountHolderNameError, ENTER_VALID_ACCOUNT_HOLDER_NAME_ERROR);
    }

    public boolean isEnterValidRoutingNumberErrorCorrect(){
        wait.until(PWExpectedConditions.visibilityOf(enterValidRoutingNumberError));
        return isExpectedTextDisplayed(enterValidRoutingNumberError, ENTER_VALID_ROUTING_NUMBER_ERROR);
    }

    public boolean isEnterValidBankAccountNumberErrorCorrect(){
        return isExpectedTextDisplayed(enterValidAccountNumberError, ENTER_VALID_ACCOUNT_NUMBER_ERROR);
    }

    public boolean isBankAccountNumbersNotMatchingErrorCorrect(){
        return isExpectedTextDisplayed(bankAccountNumbersDoNotMatchError, BANK_ACCOUNT_NUMBERS_DO_NOT_MATCH_ERROR);
    }

    public boolean isAccountHolderNameMatching(String fullName){
        String accountHolderNameFromInputField = getAttributeData(paymentusAccountHolderInput, VALUE);
        boolean isAccountHolderNameMatching = fullName.equals(accountHolderNameFromInputField);
        return isAccountHolderNameMatching;
    }

    public boolean isVisaCardIconDisplayed(){
        return visaCardIcon.isDisplayed();
    }

    public void clearOutCardNumberInputField(){
        waitAndClickElement(cardNumberInputField);
        cardNumberInputField.clear();
    }

    public boolean isMasterCardIconDisplayed(){
        return masterCardIcon.isDisplayed();
    }

    public boolean isDiscoverCardIconDisplayed(){
        return discoverCardIcon.isDisplayed();
    }

    public boolean isAmexCardIconDisplayed(){
        return amexCardIcon.isDisplayed();
    }

    // Reusable helper for Save Card popup
    protected void dismissSaveCardPopupIfPresent() throws Exception {
        PWBy saveCardModal = PWBy.xpath("//div[contains(.,'Save card?')]");
        PWBy noThanksBtn = PWBy.xpath("//button[normalize-space()='No thanks']");
        PWBy closeBtn = PWBy.xpath("//div[contains(.,'Save card?')]//button[normalize-space()='×' or normalize-space()='x' or @aria-label='Close']");

        try {
            // Short wait so we don't slow tests when popup is not displayed
            PWWait shortWait = new PWWait(driver(), Duration.ofSeconds(3));
            shortWait.until(PWExpectedConditions.visibilityOfElementLocated(saveCardModal));

            // Prefer "No thanks"; fallback to close icon
            List<PWElement> noThanks = driver().findElements(noThanksBtn);
            if (!noThanks.isEmpty() && noThanks.get(0).isDisplayed()) {
                noThanks.get(0).click();
            } else {
                List<PWElement> close = driver().findElements(closeBtn);
                if (!close.isEmpty() && close.get(0).isDisplayed()) {
                    close.get(0).click();
                }
            }

            // Optional: wait for modal to disappear
            shortWait.until(PWExpectedConditions.invisibilityOfElementLocated(saveCardModal));
        } catch (PWTimeoutException ignored) {
            // Popup did not appear; continue test
        }
    }

    public AppStore.VerifyResponse getAutoVerifyRateResponse() throws Exception {
        return getSessionStorageAppStore().getAuto().getVerifyResponse();
    }

}
