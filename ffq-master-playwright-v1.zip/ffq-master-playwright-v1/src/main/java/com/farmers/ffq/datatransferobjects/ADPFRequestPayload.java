package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonIgnoreProperties
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ADPFRequestPayload {

    @JsonProperty("ADPFRequestBean")
    private ADPFRequestBean ADPFRequestBean;

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class ADPFRequestBean {
        private String quoteNumber;
        private String lob;
        private boolean iidImpl;
        private boolean adpfRetrieval;
        @JsonProperty("skipADPF")
        private boolean skipADPF;
        private boolean prefillRequiredFromBind;
        private boolean skipADPFDueToStateShutOff;
    }
}
