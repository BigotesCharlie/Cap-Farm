package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
public class CaptchaResponseBean {
    private ValidateCaptchaResponseBean validateCaptchaResponseBean;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties
    @Data
    public static class ValidateCaptchaResponseBean {
        private String status;
    }
}
