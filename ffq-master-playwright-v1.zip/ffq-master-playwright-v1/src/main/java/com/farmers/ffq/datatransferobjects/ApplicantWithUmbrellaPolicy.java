package com.farmers.ffq.datatransferobjects;
import lombok.Data;

@Data
public class ApplicantWithUmbrellaPolicy {	
    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private String residentAddress;
    private String city;
    private String zipCode;
    private String stateCode;
}
