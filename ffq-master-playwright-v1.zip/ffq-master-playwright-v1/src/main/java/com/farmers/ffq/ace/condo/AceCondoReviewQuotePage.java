package com.farmers.ffq.ace.condo;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.ace.hrc.common.AceHRCReviewQuoteBasePage;
import com.farmers.ffq.common.enums.CoverageNameAceCondo;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import java.text.NumberFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoReviewQuotePage extends AceHRCReviewQuoteBasePage {

    protected static final String EXPECTED_TYPE_OF_LOSS_HEADER_TEXT = "Type of loss";

    @PWFindBy(xpath = "//app-condo-renters-quote-review//h1[text()='Here is your quote']")
    private PWElement quoteSummaryHeading;

    protected static final String PAGE_TITLE = "Here is your quote";
    private static final String PAGE_SUBTITLE = "Coverages are based on your selected personal property coverage of %s.";

    @PWFindBy(xpath = "//app-condo-renters-quote-review//div/a[text()='Change coverage']/preceding-sibling::span")
    protected PWElement quoteSummarySubheading;

    protected static final String CHANGE_COVERAGE_XPATH = "//app-condo-renters-quote-review//a[text()='Change coverage']";
    @PWFindBy(xpath = CHANGE_COVERAGE_XPATH)
    protected PWElement linkChangeCoverage;

    private static final String QUOTE_PRESENTMENT_DESKTOP_XPATH = "//app-condo-renters-quote-review//mat-card[contains(@class,'tui-quote-presentment-desktop')]";
    private static final String QUOTE_PRESENTMENT_MOBILE_XPATH = "//app-condo-renters-quote-review//mat-card[contains(@class,'tui-quote-presentment-mobile')]";

    @PWFindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tui-price")
    private PWElement quotePriceOnCard;

    private static final String PRESENTMENT_CARD_PRICE_HEADER = "12-month plan starting at";

    private static final String PRESENTMENT_CARD_PRICE_HEADER_XPATH = "//app-condo-renters-quote-review//mat-card//div[contains(@class,'price-description')]";
    @PWFindBy(xpath = PRESENTMENT_CARD_PRICE_HEADER_XPATH)
    private PWElement presentmentCardPriceHeader;

    private static final String VIEW_MONTHLY_PRICING_LINK_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//*[text()='View monthly pricing']";
    @PWFindBy(xpath = VIEW_MONTHLY_PRICING_LINK_XPATH)
    private PWElement linkViewMonthlyPricing;

    private static final String VIEW_PAY_IN_FULL_PRICING_LINK_XPATH = "//div[starts-with(text(),'View pay-in-full pricing')]";

    @PWFindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + VIEW_PAY_IN_FULL_PRICING_LINK_XPATH)
    private PWElement linkViewPayInFullPricing;

    @PWFindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[starts-with(text(),'Primary coverages')]/following-sibling::td")
    private PWElement quotePrimaryCoverageOnCard;

    @PWFindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[text()='All other coverages']/following-sibling::td")
    private PWElement quoteAllOtherCoveragesPriceOnCard;

    private static final String PRIMARY_COVERAGES_XPATH = "//tr/td[starts-with(text(),'Primary coverages')]/following-sibling::td";
    @PWFindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + PRIMARY_COVERAGES_XPATH)
    private PWElement primaryCoveragesPriceOnCardDesktop;
    @PWFindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + PRIMARY_COVERAGES_XPATH)
    private PWElement primaryCoveragesPriceOnCardMobile;

    private static final String ALL_OTHER_COVERAGES_XPATH = "//tr/td[starts-with(text(),'All other coverages')]/following-sibling::td";
    @PWFindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + ALL_OTHER_COVERAGES_XPATH)
    private PWElement getQuoteAllOtherCoveragesPriceOnCardDesktop;
    @PWFindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + ALL_OTHER_COVERAGES_XPATH)
    private PWElement getGetQuoteAllOtherCoveragesPriceOnCardMobile;

    @PWFindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div")
    private PWElement quoteDiscountsOnCard;
    @PWFindBy(xpath = "//app-condo-renters-quote-review//h2[contains(.,'Deductibles')]")
    private PWElement deductiblesHeader;
    @PWFindBy(xpath = "//app-condo-renters-quote-review//h2")
    private List<PWElement> deductiblesHeaders;
    @PWFindBy(xpath = "//div[contains(@class,'deductible-label')]")
    private List<PWElement> deductibleLabels;
    @PWFindBy(xpath = "//div[contains(@class,'deductible-amount')]")
    private List<PWElement> deductibleAmount;
    @PWFindBy(xpath = "//div[@id='editCoverageDialogHeading']")
    private PWElement coveragesHeader;
    @PWFindBy(xpath = "//app-condo-renters-quote-review//h2/following-sibling::div[1]")
    private PWElement outOfPocketCostHeader;
    Random random = new Random();


    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceCondoReviewQuotePage() throws Exception {
    }

    public String getPersonalPropertyCoverageFromHeading() {
        final String subheadingVerbiage = "Coverages are based on your selected personal property coverage of ";
        return getTextFromElement(quoteSummarySubheading).replace(subheadingVerbiage, EMPTY_STRING);
    }

    public boolean isPageTitleDisplayed() {
        return getTextFromElement(quoteSummaryHeading).equals(PAGE_TITLE);
    }

    public String getPageTitle() {
        return getTextFromElement(quoteSummaryHeading);
    }

    public String getPageSubtitle() {
        return getTextFromElement(quoteSummarySubheading);
    }

    public boolean isPageTitleInViewport() throws Exception {
        return isElementInViewport(quoteSummaryHeading);
    }

    public String getPageSubtitle(String coverage) {
        return String.format(PAGE_SUBTITLE, coverage);
    }

    public void validateContentOfDeductiblesSection(FarmersSoftAssert fsa, String lobType) throws Exception {
        waitElementBeVisible(deductiblesHeader);
        fsa.assertEquals(getTextFromElement(deductiblesHeader), DEDUCTIBLES, "Deductibles header verification - " + lobType);
        fsa.assertEquals(getTextFromElement(outOfPocketCostHeader), EXPECTED_OUT_OF_POCKET_COST_FOR_COVERED_LOSS, "Out of pocket covered loss text verification - condo lob.");

        fsa.assertEquals(getTextFromElement(deductibleLabels.get(0)), EXPECTED_TYPE_OF_LOSS_HEADER_TEXT, "Type of loss label text verification - condo lob.");
        fsa.assertEquals(getTextFromElement(deductibleLabels.get(1)), EXPECTED_ALL_PERILS_HEADER_TEXT, "Deductibles sub header label text verification - condo lob.");
        fsa.assertEquals(getTextFromElement(deductibleAmount.get(0)), DEDUCTIBLES, "All peril loss label text verification - condo lob.");
        fsa.assertEquals(getDeductibleAmountFromWebElement(), getDeductibleAmountInCurrencyFormat(), "Type of loss label text verification - condo lob.");
        testStep("Validated deductible section headers, table headers and deductible table content for " + lobType);

        fsa.assertTrue(editDeductibleButton.isDisplayed(), "Edit deductible button verification.");
        fsa.assertTrue(editDeductibleIcon.isDisplayed(), "Edit deductible info icon verification.");
        fsa.assertEquals(getTextFromElement(editDeductibleText), EXPECTED_EDIT_DEDUCTIBLES_LINK_TEXT, "Edit deductible text verification.");
        testStep("Validated edit deductible button, icons and deductible button text for " + lobType);
    }

    public String getDeductibleAmountFromWebElement(){
        return getTextFromElement(deductibleAmount.get(1));
    }
    public String getPrimaryCoveragesOnCard() {
        try {
            if (isUseMobileViewEnabled()) {
                if (isElementDisplayed(expandQuoteCard, 2)) {
                    waitAndClickElement(expandQuoteCard);
                }
                waitElementBeVisible(primaryCoveragesPriceOnCardMobile);
            } else {
                waitElementBeVisible(primaryCoveragesPriceOnCardDesktop);
            }
        } catch (PWStaleElementReferenceException e) {
            sleep(3);
        }
        if (isUseMobileViewEnabled()) {
            return getTextFromElement(primaryCoveragesPriceOnCardMobile);
        } else {
            return getTextFromElement(primaryCoveragesPriceOnCardDesktop);
        }
    }

    public String getAllOtherCoveragesPriceOnCard() {
        try {
            if (isUseMobileViewEnabled()) {
                if (isElementDisplayed(expandQuoteCard, 2)) {
                    waitAndClickElement(expandQuoteCard);
                }
                waitElementBeVisible(getGetQuoteAllOtherCoveragesPriceOnCardMobile);
            } else {
                waitElementBeVisible(getQuoteAllOtherCoveragesPriceOnCardDesktop);
            }
        } catch (PWStaleElementReferenceException e) {
            sleep(2);
        }
        if (isUseMobileViewEnabled()) {
            return getTextFromElement(getGetQuoteAllOtherCoveragesPriceOnCardMobile);
        } else {
            return getTextFromElement(getQuoteAllOtherCoveragesPriceOnCardDesktop);
        }
    }

    public void verifyQuotePresentmentCard(FarmersSoftAssert fsa) throws Exception {

        fsa.assertTrue(isPresentmentCardPriceHeader(), "Review Quote page - Quote Presentment card - quote price header.");
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
        AppStore appStore = getSessionStorageAppStore();
        AppStore.Home.Quote quote = appStore.getHome().getQuote();
        String selectedPackageCode = quote.getSelectedPackageCode();
        String selectedPaymentMode = quote.getSelectedPaymentMode();
        double totalPremium = Double.parseDouble(appStore.getHome().getCoverageForPackage(selectedPackageCode, selectedPaymentMode).getTotalPremium());
        double monthlyPremium = Math.round((totalPremium / 12) * 100) / 100.00;
        List<AppStore.Home.Discount> discounts = appStore.getHome().getDiscountsForPackage(selectedPackageCode, selectedPaymentMode);

        fsa.assertTrue(isPresentmentCardPriceHeader(), "Review Quote page - Quote Presentment card - quote price header.");
        double premiumAmount = selectedPaymentMode.equals("PIF")? totalPremium: monthlyPremium;
        fsa.assertEquals(currencyFormat.parse(getQuotePriceOnCard()).doubleValue(), premiumAmount,
                    "Review Quote page - Quote Presentment card - quote price.");
        fsa.assertEquals(currencyFormat.parse(getPrimaryCoveragesOnCard()).doubleValue(), premiumAmount,
                    "Review Quote page - Quote Presentment card - Primary coverages price.");
        fsa.assertEquals(getAllOtherCoveragesPriceOnCard(), "$0", "Review Quote page - Quote Presentment card - All other coverages price.");
        fsa.assertEquals(getDiscountsOnCard(), String.format("%s discounts included", discounts.size()),
                "Review Quote page - Quote Presentment card - number of discounts included.");

        clickPriceAlternative();
        sleep(2);
        appStore = getSessionStorageAppStore();
        quote = appStore.getHome().getQuote();
        selectedPackageCode = quote.getSelectedPackageCode();
        selectedPaymentMode = quote.getSelectedPaymentMode();
        totalPremium = Double.parseDouble(appStore.getHome().getCoverageForPackage(selectedPackageCode, selectedPaymentMode).getTotalPremium());
        monthlyPremium = Math.round((totalPremium / 12) * 100) / 100.00;
        premiumAmount = selectedPaymentMode.equals("EFT")? monthlyPremium : totalPremium;
        fsa.assertEquals(currencyFormat.parse(getQuotePriceOnCard()).doubleValue(), premiumAmount,
                "Review Quote page - Quote Presentment card - quote price.");
        fsa.assertEquals(currencyFormat.parse(getPrimaryCoveragesOnCard()).doubleValue(), premiumAmount,
                "Review Quote page - Quote Presentment card - Primary coverages price.");
        fsa.assertEquals(getAllOtherCoveragesPriceOnCard(), "$0", "Review Quote page - Quote Presentment card - All other coverages price.");
        fsa.assertEquals(getDiscountsOnCard(), String.format("%s discounts included", discounts.size()),
                "Review Quote page - Quote Presentment card - number of discounts included.");
    }

    public void validateContentOfCoverageSectionCondoLob(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome, String lobType) throws Exception {
        List<String> foundPrimaryCoverageName = getCondoRentersCoveragesNamesOnReviewQuotePage(lobType);
        List<String> foundPrimaryCoverageAmount = getSortedList(getCondoRentersCoveragesAmountOnReviewQuotePage());

        Map<String, String> coverageAmountKeyValuePair = getExpectedCoverageAndCoverageAmountFromAppStoreCondoLob(applicantAceHome);
        List<String> coverageAmountFromCoverageAmountKeyValuePair = getSortedList(new ArrayList<String>(coverageAmountKeyValuePair.values()));
        List<String> coverageNameFromCoverageNameKeyValuePair = getSortedList(new ArrayList<>(coverageAmountKeyValuePair.keySet()));
        fsa.assertEquals(foundPrimaryCoverageName, coverageNameFromCoverageNameKeyValuePair, lobType + " coverage names verification - " + lobType);
        fsa.assertEquals(foundPrimaryCoverageAmount, coverageAmountFromCoverageAmountKeyValuePair, lobType + " coverage amount values verification - " + lobType);
    }


    public void validateEditCoverageSideSheetCondoLob(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome, String lobType) throws Exception {
        String stateCode = applicantAceHome.getStateCode();
        clickOnAddEditCoverageLinkButton();

        // validate common content of cond edit coverage side sheet
        validateCommonContentFromEditCoverageSideSheetCondoRentersLob(fsa, lobType, "Condo coverages");

        Map<String, String> coverageAmountKeyValuePair = getExpectedCoverageAndCoverageAmountFromAppStoreCondoLob(applicantAceHome);

        // validate personal property section
        validatePersonalPropertySectionCondo(fsa, coverageAmountKeyValuePair, lobType, stateCode);

        // validate unit owner building property section
        validateUnitOwnerBuildingPropertySection(fsa, coverageAmountKeyValuePair, lobType);

        // validate unit owner building property section
        validateLossOfUseSection(fsa, coverageAmountKeyValuePair, stateCode, lobType);

        // validate personal liability section
        validatePersonalLiabilitySection(fsa, coverageAmountKeyValuePair, lobType);

        // validate medical payment to others section
        validateMedicalPaymentToOthersSection(fsa, coverageAmountKeyValuePair, lobType);

       //  validate Mine subsidence section
        if(applicantAceHome.isMineSubsidence()){
            validateMineSubsidenceSection(fsa, coverageAmountKeyValuePair, lobType);
        }

       //  Validate loss of assessment section
        validateIncreaseLossOfAssessmentSection(fsa, coverageAmountKeyValuePair, lobType);

        // Validate home sharing section
        boolean hasTemporaryRentalSection = !hasTemporaryRentalSectionOption(stateCode);
        if(hasTemporaryRentalSection){
            if(applicantAceHome.isTemporaryRentals()){
                validateHomeSharingSection(fsa, coverageAmountKeyValuePair, lobType);
            }
        }
        // Validate building ordinance section
        validateBuildingOrdinanceSection(fsa, coverageAmountKeyValuePair, applicantAceHome, lobType);


        // Validate content of reset value pop up and reset coverage value in side sheet
        validateRecalculateResetButtonTextInSideSheet(fsa, lobType);
        clickResetChangesButtonCondoRentersInSideSheet();
        validateContentOfResetChangesPopUp(fsa);
        clickKeepEditingButton();
        clickResetChangesButtonCondoRentersInSideSheet();
        clickResetValueButton();

        // validate if the value is reset properly on click of reset button
        validateIfCoverageIsResetInCoverageSideSheetCondoLob(fsa, coverageAmountKeyValuePair, lobType);

        // randomly update the coverage value from condo side sheet
        editTheCondoCoveragesAndValidateContentOnMainPage(coverageAmountKeyValuePair);

        // validate randomly edited coverage values are updated on main screen
        waitForSpinnerToBeGone();
        validateEditedCoverageValueUpdatedOnMainScreen(fsa, coverageAmountKeyValuePair, lobType);

    }

    // validate if the value is reset properly on click of reset button
    public void validateIfCoverageIsResetInCoverageSideSheetCondoLob(FarmersSoftAssert fsa, Map<String, String> coverageAmountKeyValuePair, String lobType) {
        String originalSelectedLossOfUseOption = getTextFromElement(lossOfUseDropDownWebElement);
        String originalSelectedPersonalLiabilityValue = getTextFromElement(selectedPersonalLiabilityRadioButtonElement);
        String originalSelectedMedicalPaymentToOthersValue = getTextFromElement(selectedMedicalPaymentToOthersRadioButtonElement);
        fsa.assertEquals(originalSelectedLossOfUseOption.replace("/ ", ""), coverageAmountKeyValuePair.get(LOSS_OF_USE).replaceAll("[()]", ""),
                LOSS_OF_USE + " drop down selected values are not matching - " + lobType);
        fsa.assertEquals(originalSelectedPersonalLiabilityValue, coverageAmountKeyValuePair.get(PERSONAL_LIABILITY),
                PERSONAL_LIABILITY + " selected radio button value verification - " + lobType);
        fsa.assertEquals(originalSelectedMedicalPaymentToOthersValue, coverageAmountKeyValuePair.get(MEDICAL_PAYMENT_TO_OTHERS),
                MEDICAL_PAYMENT_TO_OTHERS + " selected radio button value verification - " + lobType);
        fsa.assertTrue(!getAttributeData(increaseLossAssessmentToggleButtonInEditCoverageSideSheet, CLASS).contains(TOGGLE_CHECKED), INCREASE_LOSS_ASSESSMENT + " mat-toggle-button is not checked.");
        fsa.assertTrue(!getAttributeData(buildingOrdinanceToggleButtonInEditCoverageSideSheet, CLASS).contains(TOGGLE_CHECKED), BUILDING_ORDINANCE + " mat-toggle-button is not checked.");

    }

    public Map<String, String> getExpectedCoverageAndCoverageAmountFromAppStoreCondoLob(ApplicantAceHome applicantAceHome) throws Exception {
        String stateCode = applicantAceHome.getStateCode();
        AppStore appStore = getSessionStorageAppStore();
        String selectedPaymentMode = appStore.getHome().getQuote().getSelectedPaymentMode();
        AppStore.Home.RateQuoteResponse rateQuoteResponse = appStore.getHome().getQuote().getRateQuoteResponses().stream().filter(i -> i.getPaymentMode().equals(selectedPaymentMode)).collect(Collectors.toList()).get(0);
        List<AppStore.Home.CvgInfo> cvgInfo = rateQuoteResponse.getPersHomePolicy().getPersHomeCoverage().getCustomCoverages().getCvgInfo();
        List<AppStore.Home.CvgInfo> listOfPrimaryCoverageFromAppStore = cvgInfo.stream().filter(i -> i.getCvgSection().equals("Primary")).collect(Collectors.toList());

        List<String> expectedPrimaryCoverageAmountFromAppStore = listOfPrimaryCoverageFromAppStore.stream().map(i -> i.getCvgAmt()).collect(Collectors.toList());

        // setting the coverage amount where we get values in terms of %
        int personalPropertyValueInt = getIntCurrencyValueFromStringCurrencyValue(getPersonalPropertyValue());
        String valueToSet = "";
        int numberOfCoverageAmountsFromAppStore = expectedPrimaryCoverageAmountFromAppStore.size();
        for (int i = 0; i < numberOfCoverageAmountsFromAppStore; i++){
            if(expectedPrimaryCoverageAmountFromAppStore.get(i).contains("%")){
                int multiplier = Integer.parseInt(expectedPrimaryCoverageAmountFromAppStore.get(i).replace("%", ""));
                valueToSet = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf((multiplier*personalPropertyValueInt)/100));
                expectedPrimaryCoverageAmountFromAppStore.set(i, valueToSet);
            }
        }

        // setting the expected coverage based on home sharing and mine subsidence
        List<String> expectedPrimaryCoverageNameFromAppStore;
        if (applicantAceHome.isTemporaryRentals() && applicantAceHome.isMineSubsidence()){
            expectedPrimaryCoverageNameFromAppStore = CoverageNameAceCondo.CONDO_COVERAGE_WITHOUT_HOME_SHARING_MINE_SUBSIDENCE.getCoverages();
        } else if (!hasTemporaryRentalSectionOption(stateCode)){
            if (applicantAceHome.isTemporaryRentals()){
                expectedPrimaryCoverageNameFromAppStore = CoverageNameAceCondo.CONDO_COVERAGE_WITH_HOME_SHARING.getCoverages();
            } else {
                expectedPrimaryCoverageNameFromAppStore = CoverageNameAceCondo.CONDO_COVERAGE_WITHOUT_HOME_SHARING_MINE_SUBSIDENCE.getCoverages();
            }
        } else if (applicantAceHome.isMineSubsidence()){
            expectedPrimaryCoverageNameFromAppStore = CoverageNameAceCondo.CONDO_COVERAGE_WITH_MINE_SUBSIDENCE.getCoverages();
        } else {
            expectedPrimaryCoverageNameFromAppStore = CoverageNameAceCondo.CONDO_COVERAGE_WITHOUT_HOME_SHARING_MINE_SUBSIDENCE.getCoverages();
        }

        if (!stateCode.equals(VA)){
            expectedPrimaryCoverageAmountFromAppStore.set(2, expectedPrimaryCoverageAmountFromAppStore.get(2).concat(" (24 months)"));
            expectedPrimaryCoverageAmountFromAppStore.remove(3);
        }
        if (stateCode.equals(CT)) {
            expectedPrimaryCoverageNameFromAppStore.replaceAll(
                    coverageName -> coverageName.equals(LOSS_OF_USE) ? LOSS_OF_USE_TEXT : coverageName);
        }

        Map<String, String> coverageAmountKeyValuePair = new HashMap<String, String>();
        int numberOfCoverageNamesFromAppStore = expectedPrimaryCoverageNameFromAppStore.size();
        for (int i = 0; i < numberOfCoverageNamesFromAppStore; i++) {
            coverageAmountKeyValuePair.put(expectedPrimaryCoverageNameFromAppStore.get(i), expectedPrimaryCoverageAmountFromAppStore.get(i));
        }

        // Setting the coverage amount for some of the coverage as we don't get the direct values from app store
        coverageAmountKeyValuePair.put(INCREASE_LOSS_ASSESSMENT, "$1,500");

        setExpectedBuildingOrdinanceAmount(listOfPrimaryCoverageFromAppStore, coverageAmountKeyValuePair);

        if (!hasTemporaryRentalSectionOption(stateCode)){
            if (applicantAceHome.isTemporaryRentals()){
                coverageAmountKeyValuePair.put(HOME_SHARING, "Covered");
            }
        } else if (applicantAceHome.isMineSubsidence()) {
            coverageAmountKeyValuePair.put(MINE_SUBSIDENCE, "Covered");
        }
//        if(!List.of(VA).contains(stateCode)){
//            String personalPropertyKey = getPersonalPropertyKey();
//            String personalPropertyValue = coverageAmountKeyValuePair.remove(PERSONAL_PROPERTY);
//            coverageAmountKeyValuePair.put(personalPropertyKey, personalPropertyValue);
//        }
        return coverageAmountKeyValuePair;
    }


    public void setExpectedBuildingOrdinanceAmount(List<AppStore.Home.CvgInfo> listOfPrimaryCoverageFromAppStore, Map<String, String> coverageAmountKeyValuePair){
        AppStore.Home.CvgInfo buildingOrdinanceCovInfo = listOfPrimaryCoverageFromAppStore.stream().filter(i -> i.getCvgDesc().equals(BUILDING_ORDINANCE)).collect(Collectors.toList()).get(0);
        if(buildingOrdinanceCovInfo.getCvgCode().equals("24205")){
            coverageAmountKeyValuePair.put(BUILDING_ORDINANCE, "Covered");
        }else{
            if(buildingOrdinanceCovInfo.getCvgAmt().equals("Off")){
                coverageAmountKeyValuePair.put(BUILDING_ORDINANCE, "Not Covered");
            }else{
                coverageAmountKeyValuePair.put(BUILDING_ORDINANCE, buildingOrdinanceCovInfo.getCvgAmt());
            }
        }
    }
    public void validateUnitOwnerBuildingPropertySection(FarmersSoftAssert fsa, Map<String, String> coverageAmountKeyValuePair, String lobType) throws Exception {
        fsa.assertTrue(unitOwnerBuildingPropertyLabelInEditCoverageSideSheet.isDisplayed(), UNIT_OWNER_BUILDING_PROPERTY + " label verification in edit coverage side sheet - " + lobType );
        String unitOwnerBuildingPropertyDescription = "This coverage, also known as Coverage A, can repair or replace the the portion of your condominium owned by you from a covered loss," +
                " subject to your policy provisions, which include, but are not limited to, common exclusions such as, wear and tear, earth movement, earthquake, mold, flood and nuclear hazard.";
        fsa.assertEquals(getTextFromElement(unitOwnerBuildingPropertyDescriptionWebElement), unitOwnerBuildingPropertyDescription, UNIT_OWNER_BUILDING_PROPERTY + " description verification - " + lobType);
        String unitOwnerBuildingPropertyCoverageValue = coverageAmountKeyValuePair.get(UNIT_OWNER_BUILDING_PROPERTY);
        PWElement personalPropertyValueOnScreen = driver().findElement(PWBy.xpath(UNIT_OWNER_BUILDING_PROPERTY_XPATH + "/ancestor::coverage-data-card//div[contains(text(),'" + unitOwnerBuildingPropertyCoverageValue +"')]"));
        fsa.assertEquals(getTextFromElement(personalPropertyValueOnScreen), unitOwnerBuildingPropertyCoverageValue, UNIT_OWNER_BUILDING_PROPERTY + " coverage amount verification - " + lobType);
        testStep("Validating " + UNIT_OWNER_BUILDING_PROPERTY + " coverage header/description and coverage value on coverages side sheet.");
    }

    private void validateLimitedMoldSection(FarmersSoftAssert fsa, String lobType) throws Exception {
        clickOnLimitedMoldToggleButton();
        fsa.assertTrue(limitedMoldToggleButtonInEditCoverageSideSheet.isDisplayed(), LIMITED_MOLD + " mat-toggle-button displayed.");
        fsa.assertTrue(getAttributeData(limitedMoldToggleButtonInEditCoverageSideSheet, CLASS).contains(TOGGLE_CHECKED), LIMITED_MOLD + " mat-toggle-button is checked.");

        fsa.assertTrue(limitedMoldLabelInEditCoverageSideSheet.isDisplayed(), LIMITED_MOLD + " label verification in edit coverage side sheet - " + lobType );
        String limitedMoldDescription = "This coverage can pay for expenses required to remediate any mold which results from the repair or replacement of a covered loss.";
        fsa.assertEquals(getTextFromElement(limitedMoldDescriptionWebElement), limitedMoldDescription, LIMITED_MOLD + " description verification - " + lobType);

        List<String> foundLimitedMoldRadioOptions = limitedMoldRadioButtonElements.stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());

        List<String> limitedMoldCoverageValueAmountFromAppStore = getCoverageValuesByCoverageDescription(LIMITED_MOLD);

        fsa.assertEquals(foundLimitedMoldRadioOptions, limitedMoldCoverageValueAmountFromAppStore, LIMITED_MOLD + " coverage amount options verification - " + lobType);
        fsa.assertEquals(getTextFromElement(selectedLimitedMoldRadioButtonElement), foundLimitedMoldRadioOptions.get(0), LIMITED_MOLD + " selected coverage amount radio button label - " + lobType);
    }

    private void validateMineSubsidenceSection(FarmersSoftAssert fsa, Map<String, String> coverageAmountKeyValuePair, String lobType) throws Exception {
        scrollToElement(mineSubsidenceLabelInEditCoverageSideSheet);
        fsa.assertTrue(mineSubsidenceLabelInEditCoverageSideSheet.isDisplayed(), MINE_SUBSIDENCE + " displayed in edit coverage side sheet - " + lobType );
        String mineSubsidenceDescription = "Covers loss to the residence or living unit caused by Mine subsidence.";
        fsa.assertEquals(getTextFromElement(mineSubsidenceDescriptionWebElement), mineSubsidenceDescription, MINE_SUBSIDENCE + " description verification - " + lobType);
        String mineSubsidenceCoverageValue = coverageAmountKeyValuePair.get(MINE_SUBSIDENCE);
        fsa.assertEquals(getTextFromElement(mineSubsidenceCoveredValueWebElement), mineSubsidenceCoverageValue, MINE_SUBSIDENCE + " selected coverage amount radio button label - " + lobType);
    }

    private void validateIncreaseLossOfAssessmentSection(FarmersSoftAssert fsa, Map<String, String> coverageAmountKeyValuePair, String lobType) throws Exception {
        clickOnIncreaseLossAssessmentToggleButton();
        fsa.assertTrue(increaseLossAssessmentToggleButtonInEditCoverageSideSheet.isDisplayed(), INCREASE_LOSS_ASSESSMENT + " mat-toggle-button displayed.");
        fsa.assertTrue(getAttributeData(increaseLossAssessmentToggleButtonInEditCoverageSideSheet, CLASS).contains(TOGGLE_CHECKED), INCREASE_LOSS_ASSESSMENT + " checked.");

        fsa.assertTrue(increaseLossAssessmentLabelInEditCoverageSideSheet.isDisplayed(), INCREASE_LOSS_ASSESSMENT + " is displayed in edit coverage side sheet - " + lobType );
        String increaseLossAssessmentDescription = "This coverage can help cover the cost of an assessment by your association in the event of a covered loss.";
        fsa.assertEquals(getTextFromElement(increaseLossAssessmentDescriptionWebElement), increaseLossAssessmentDescription, INCREASE_LOSS_ASSESSMENT + " description verification - " + lobType);

        String increaseLossAssessmentCoverageLimitDescription = "$1,500 limit is included";
        fsa.assertEquals(getTextFromElement(increaseLossAssessmentCoverageLimitWebElement), increaseLossAssessmentCoverageLimitDescription, INCREASE_LOSS_ASSESSMENT + " coverage limit text verification - " + lobType);

        List<String> increaseLossAssessmentRadioOptions = increaseLossAssessmentRadioButtonElements.stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());

        List<String> increaseLossAssessmentCoverageValueAmountFromAppStore = getCoverageValuesByCoverageDescription(INCREASE_LOSS_ASSESSMENT);

        int numberOfLossAssessmentsFromAppStore = increaseLossAssessmentCoverageValueAmountFromAppStore.size();
        for(int i = 0; i < numberOfLossAssessmentsFromAppStore; i++){
            String totalCombinedLimitIncreaseLossAssessment = increaseLossAssessmentCoverageValueAmountFromAppStore.get(i) + " Total combined limit: " +
                    add1500InSelectedIncreaseLossAssessmentValueFromEditCoverageSideSheet(increaseLossAssessmentCoverageValueAmountFromAppStore.get(i));
            increaseLossAssessmentCoverageValueAmountFromAppStore.set(i, totalCombinedLimitIncreaseLossAssessment);
        }
        fsa.assertEquals(increaseLossAssessmentRadioOptions, increaseLossAssessmentCoverageValueAmountFromAppStore, INCREASE_LOSS_ASSESSMENT + " coverage amount options verification" + lobType);
        fsa.assertEquals(getTextFromElement(selectedIncreaseLossAssessmentRadioButtonElement), increaseLossAssessmentCoverageValueAmountFromAppStore.get(0), INCREASE_LOSS_ASSESSMENT + " selected coverage amount radio button label - " + lobType);
    }
    private void validateHomeSharingSection(FarmersSoftAssert fsa, Map<String, String> coverageAmountKeyValuePair, String lobType) throws Exception {
        scrollToElement(homeSharingLabelInEditCoverageSideSheet);
        fsa.assertTrue(homeSharingLabelInEditCoverageSideSheet.isDisplayed(), HOME_SHARING + " is displayed in edit coverage side sheet - " + lobType );
        String homeSharingDescription = "Home share business is excluded in the base coverage for Farmers Smart Plan Condominium policies. Home sharing involves renting the primary residence, or part of it, for a home-sharing occupant either through the use of a" +
                " home-sharing network platform such as Airbnb or Vrbo\u00ae platforms, or through a rental agency. Homeshare coverage is mandatory when a residence is being used for home sharing.";
        fsa.assertEquals(getTextFromElement(homeSharingDescriptionWebElement), homeSharingDescription, HOME_SHARING + " description verification - " + lobType);
        String homeSharingCoverageValue = coverageAmountKeyValuePair.get(HOME_SHARING);
        fsa.assertEquals(getTextFromElement(homeShariongCoveredValueWebElement), homeSharingCoverageValue, HOME_SHARING + " selected coverage amount radio button label - " + lobType);
    }

    private void validateBuildingOrdinanceSection(FarmersSoftAssert fsa, Map<String, String> coverageAmountKeyValuePair, ApplicantAceHome applicantAceHome, String lobType) throws Exception {
        fsa.assertTrue(buildingOrdinanceToggleButtonInEditCoverageSideSheet.isDisplayed(), BUILDING_ORDINANCE + " is displayed with toggle option.");
        fsa.assertTrue(!getAttributeData(buildingOrdinanceToggleButtonInEditCoverageSideSheet, CLASS).contains(TOGGLE_CHECKED), BUILDING_ORDINANCE + " toggle is off by default.");
        String buildingOrdinanceValue = coverageAmountKeyValuePair.get(BUILDING_ORDINANCE);
        if(buildingOrdinanceValue.equals("Covered")){
            String expectedBuildingOrdinanceDescription = "This coverage can pay for the increased costs that you actually incur as a result of building" +
                    " law enforcement when you repair or replace the portion of the condominium that you own due to a covered loss.";
            fsa.assertEquals(getTextFromElement(buildingOrdinanceDescriptionWebElement), expectedBuildingOrdinanceDescription, BUILDING_ORDINANCE + " description verification - " + lobType);
        }else{
            clickOnBuildingOrdinanceToggleButton();
            fsa.assertTrue(buildingOrdinanceToggleButtonInEditCoverageSideSheet.isDisplayed(), BUILDING_ORDINANCE + " is displayed.");
            fsa.assertTrue(getAttributeData(buildingOrdinanceToggleButtonInEditCoverageSideSheet, CLASS).contains(TOGGLE_CHECKED), BUILDING_ORDINANCE + " is checked.");

            fsa.assertTrue(buildingOrdinanceLabelInEditCoverageSideSheet.isDisplayed(), BUILDING_ORDINANCE + " is displayed in edit coverage side sheet - " + lobType );
            String buildingOrdinanceDescription = "This coverage can pay for the increased costs that you actually incur as a result of building law enforcement when" +
                    " you repair or replace the portion of the condominium that you own due to a covered loss.";
            fsa.assertEquals(getTextFromElement(buildingOrdinanceDescriptionWebElement), buildingOrdinanceDescription, BUILDING_ORDINANCE + " description verification - " + lobType);
            List<String> buildingOrdinanceRadioOptions = buildingOrdinanceRadioButtonElements.stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());

            List<String> buildingOrdinanceCoverageValueAmountFromAppStore = getFormattedRadioButtonTextForBuildingOrdinance(coverageAmountKeyValuePair, applicantAceHome);
            fsa.assertEquals(buildingOrdinanceRadioOptions, buildingOrdinanceCoverageValueAmountFromAppStore, BUILDING_ORDINANCE + " coverage amount options verification - " + lobType);
            fsa.assertEquals(getTextFromElement(selectedBuildingOrdinanceRadioButtonElement), buildingOrdinanceCoverageValueAmountFromAppStore.get(0), BUILDING_ORDINANCE + " selected coverage amount radio button label - " + lobType);
        }
    }

    private List<String> getFormattedRadioButtonTextForBuildingOrdinance(Map<String, String> coverageAmountKeyValuePair, ApplicantAceHome applicantAceHome) throws Exception {
        List<String> buildingOrdinanceAmountWithoutNoCoverageAmount = getCoverageValuesByCoverageDescription(BUILDING_ORDINANCE);
        List<String> buildingOrdinanceAmountWithoutDollarSign = buildingOrdinanceAmountWithoutNoCoverageAmount.stream().map(i -> i.replace("$", "")).collect(Collectors.toList());
        List<Integer> buildingOrdinanceAmountInNumericForm = buildingOrdinanceAmountWithoutDollarSign.stream().map(i -> Integer.parseInt(i)).collect(Collectors.toList());

        int unitOwnerBuildingPropertyValue = Integer.parseInt(coverageAmountKeyValuePair.get(UNIT_OWNER_BUILDING_PROPERTY).replaceAll("[$,]",""));
        List<String> buildingOrdinanceRadioButtonOptionsWithCurrencyFormat = new ArrayList<>();

        List<String> buildingOrdinancePercentageText = new ArrayList<>();
        if(applicantAceHome.getStateCode().equals(VA)){
            buildingOrdinancePercentageText = Arrays.asList("10%", "25%", "50%", "100%");
        }else{
            buildingOrdinancePercentageText = Arrays.asList("10%", "25%");
        }
        int numberOfBuildingOrdinanceAmounts = buildingOrdinanceAmountInNumericForm.size();
        for(int i = 0; i < numberOfBuildingOrdinanceAmounts; i++){
            String buildingOrdinanceAmount = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(unitOwnerBuildingPropertyValue*buildingOrdinanceAmountInNumericForm.get(i)/100));
            buildingOrdinanceRadioButtonOptionsWithCurrencyFormat.add(buildingOrdinanceAmount +  " About " + buildingOrdinancePercentageText.get(i) + " of Cov A");
        }
        return buildingOrdinanceRadioButtonOptionsWithCurrencyFormat;
    }

    private void editTheCondoCoveragesAndValidateContentOnMainPage(Map<String, String> coverageAmountKeyValuePair) throws Exception {
        String newlySelectedLossOfUseValue = randomlySelectLossOfUseFromDropDown();
        coverageAmountKeyValuePair.put(LOSS_OF_USE, newlySelectedLossOfUseValue);

        String newlySelectedPersonalLiabilityValue = randomlySelectPersonalLiabilityRadioButton();
        coverageAmountKeyValuePair.put(PERSONAL_LIABILITY, newlySelectedPersonalLiabilityValue);

        String newlySelectedMedicalPaymentValue = randomlySelectMedicalPaymentRadioButton();
        coverageAmountKeyValuePair.put(MEDICAL_PAYMENT_TO_OTHERS, newlySelectedMedicalPaymentValue);

        String newlySelectedIncreaseLossOfAssessmentValue = randomlySelectIncreaseLossOfAssessmentRadioButton();
        coverageAmountKeyValuePair.put(INCREASE_LOSS_ASSESSMENT, newlySelectedIncreaseLossOfAssessmentValue);

        if(!coverageAmountKeyValuePair.get(BUILDING_ORDINANCE).equals("Covered")){
            String newlySelectedBuildingOrdinanceValue = randomlySelectBuildingOrdinanceRadioButton();
            coverageAmountKeyValuePair.put(BUILDING_ORDINANCE, newlySelectedBuildingOrdinanceValue);
        }

        clickRecalculateButtonCondoRentersInSideSheet();

    }

    private String randomlySelectIncreaseLossOfAssessmentRadioButton(){
        if(!getAttributeData(increaseLossAssessmentToggleButtonInEditCoverageSideSheet, CLASS).contains(TOGGLE_CHECKED)){
            clickOnIncreaseLossAssessmentToggleButton();
        }
        if(areElementsDisplayed(increaseLossAssessmentRadioButtonElements, 3)) {
            int index = random.nextInt(increaseLossAssessmentRadioButtonElements.size());
            waitAndClickElement(increaseLossAssessmentRadioButtonElements.get(index));
        }
        String newlySelectedValue = getTextFromElement(selectedDollarIncreaseLossAssessmentValue);
        return add1500InSelectedIncreaseLossAssessmentValueFromEditCoverageSideSheet(newlySelectedValue);
    }

    private String randomlySelectBuildingOrdinanceRadioButton(){
        if(!getAttributeData(buildingOrdinanceToggleButtonInEditCoverageSideSheet, CLASS).contains(TOGGLE_CHECKED)){
            clickOnBuildingOrdinanceToggleButton();
        }

        int index = random.nextInt(buildingOrdinanceRadioButtonElements.size());
        waitAndClickElement(buildingOrdinanceRadioButtonElements.get(index));
        return getTextFromElement(selectedDollarBuildingOrdinanceValue);
    }

    private String add1500InSelectedIncreaseLossAssessmentValueFromEditCoverageSideSheet(String selectedIncreaseLossAssessmentValue){
        int increaseLossAssessmentValueAmount = Integer.parseInt(selectedIncreaseLossAssessmentValue.replaceAll("[$,]",""));
        int increaseLossAssessmentValueAmountWith1500 = increaseLossAssessmentValueAmount + 1500;
        return CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(increaseLossAssessmentValueAmountWith1500));
    }


    public void fillOutEditCoverageCondoLob(){
        clickOnAddEditCoverageLinkButton();
        randomlySelectLossOfUseFromDropDown();
        randomlySelectPersonalLiabilityRadioButton();
        randomlySelectMedicalPaymentRadioButton();
        randomlySelectIncreaseLossOfAssessmentRadioButton();
        randomlySelectBuildingOrdinanceRadioButton();
        clickRecalculateButtonCondoRentersInSideSheet();
    }

    public void validateADA(String lobType) {
        performADATesting(this.getClass().getSimpleName(),MARKETING_IT,lobType);

        clickOnAddEditCoverageLinkButton();
        performADATesting(this.getClass().getSimpleName()+"_AddEditCoverages",MARKETING_IT,lobType);
        clickCloseIconOnCoveragesSideSheet();

        clickEditDeductiblesLink();
        performADATesting(this.getClass().getSimpleName()+"_EditDeductibles",MARKETING_IT,lobType);
        clickCloseIconOnCoveragesSideSheet();
    }

    public void clickChangeCoverage() {
        waitAndClickElement(linkChangeCoverage);
    }

    public void validatePersonalPropertySectionCondo(FarmersSoftAssert fsa, Map<String, String> coverageAmountKeyValuePair, String lobType, String stateCode) throws Exception {
        fsa.assertTrue(personalPropertyLabelInEditCoverageSideSheet.isDisplayed(), PERSONAL_PROPERTY + " label is not displayed in edit coverage side sheet - " + lobType );
        if(List.of(VA).contains(stateCode)){
            fsa.assertEquals(getTextFromElement(personalPropertyDescriptionWebElement), EXPECTED_PERSONAL_PROPERTY_DESCRIPTION_VA, PERSONAL_PROPERTY + " description check - " + lobType);
        }else{
            fsa.assertEquals(getTextFromElement(personalPropertyDescriptionWebElement), EXPECTED_PERSONAL_PROPERTY_DESCRIPTION, PERSONAL_PROPERTY + " description check - " + lobType);
            fsa.assertTrue(acvToggleButtonUnderPersonalProperty.isDisplayed(), PERSONAL_PROPERTY + " - Actual cash value toggle button is displayed under personal property in edit coverage side sheet - " + lobType);
            fsa.assertTrue(rcvToggleButtonUnderPersonalProperty.isDisplayed(), PERSONAL_PROPERTY + " - Replacement cost value toggle button is displayed under personal property in edit coverage side sheet - " + lobType);
            boolean personalPropertyContainsRCV = getCondoRentersCoverageNamesFromCovNameWebElements().contains(PERSONAL_PROPERTY_KEY_WITH_RCV);
            if(personalPropertyContainsRCV){
                fsa.assertTrue(isButtonSelected(rcvToggleButtonUnderPersonalProperty), PERSONAL_PROPERTY + " - RCV button selected - " + lobType);
            }else{
                fsa.assertTrue(isButtonSelected(acvToggleButtonUnderPersonalProperty), PERSONAL_PROPERTY + " - ACV button selected - " + lobType);
            }
        }
        String personalPropertyCoverageValue = coverageAmountKeyValuePair.get(PERSONAL_PROPERTY);

        PWElement personalPropertyValueOnScreen = driver().findElement(PWBy.xpath(PERSONAL_PROPERTY_LABEL_XPATH + "/ancestor::coverage-data-card" + "//div[contains(text(),'" + personalPropertyCoverageValue +"')]"));
        fsa.assertEquals(getTextFromElement(personalPropertyValueOnScreen), personalPropertyCoverageValue, PERSONAL_PROPERTY + " coverage amount check - " + lobType);
        Log.info("Validating " + PERSONAL_PROPERTY + " coverage header/description and coverage value on coverages side sheet.");
    }

    public String getDeductibleAmountInCurrencyFormat() throws Exception {
        String deductibleAmountOnInitialLoad = getSessionStorageAppStore().getHome().getQuote().getRateQuoteResponses().get(0).getPersHomePolicy()
                .getPersHomeCoverage().getCustomCoverages().getDedInfo().get(0).getAmt();
        return CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(deductibleAmountOnInitialLoad);
    }
}
