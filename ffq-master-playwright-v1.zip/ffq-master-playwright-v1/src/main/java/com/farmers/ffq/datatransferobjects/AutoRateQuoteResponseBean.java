package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AutoRateQuoteResponseBean {
    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class AutoRateQuoteResponseBean__1 {

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class RateQuoteResponse {
            @Data
            @JsonInclude(JsonInclude.Include.NON_NULL)
            private static class PersAutoPolicy {

                @JsonInclude(JsonInclude.Include.NON_NULL)
                public static class LiabilityCoverage {

                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    public static class CustomCoverages__1 {

                        @JsonInclude(JsonInclude.Include.NON_NULL)
                        public static class CvgInfo__1 {

                            @JsonProperty("cvgCode")
                            public String cvgCode;
                            @JsonProperty("cvgDesc")
                            public String cvgDesc;
                            @JsonProperty("premiumAmt")
                            public String premiumAmt;
                            @JsonProperty("displayCode")
                            public String displayCode;

                        }

                        @JsonProperty("totalPremium")
                        public String totalPremium;
                        @JsonProperty("netPremium")
                        public String netPremium;
                        @JsonProperty("cvgInfo")
                        public List<CvgInfo__1> cvgInfo;

                    }

                    @JsonProperty("customCoverages")
                    public CustomCoverages__1 customCoverages;

                }

                @JsonInclude(JsonInclude.Include.NON_NULL)
                public static class Vehicle {
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    public static class PersAutoCoverage {
                        public static class CustomCoverages {

                            @JsonInclude(JsonInclude.Include.NON_NULL)
                            public static class CvgInfo {

                                @JsonProperty("cvgCode")
                                public String cvgCode;
                                @JsonProperty("cvgDesc")
                                public String cvgDesc;
                                @JsonProperty("premiumAmt")
                                public String premiumAmt;
                                @JsonProperty("displayCode")
                                public String displayCode;

                            }


                            @JsonProperty("totalPremium")
                            public String totalPremium;
                            @JsonProperty("netPremium")
                            public String netPremium;
                            @JsonProperty("cvgInfo")
                            public List<CvgInfo> cvgInfo;

                        }


                        @JsonProperty("packageSelected")
                        public String packageSelected;
                        @JsonProperty("customCoverages")
                        public CustomCoverages customCoverages;

                    }

                    @JsonProperty("reference")
                    public String reference;
                    @JsonProperty("year")
                    public String year;
                    @JsonProperty("make")
                    public String make;
                    @JsonProperty("model")
                    public String model;
                    @JsonProperty("makeDesc")
                    public String makeDesc;
                    @JsonProperty("modelDesc")
                    public String modelDesc;
                    @JsonProperty("persAutoCoverage")
                    public PersAutoCoverage persAutoCoverage;
                    @JsonIgnore
                    @JsonProperty("persInsAutoCoveragebean")
                    public List<Object> persInsAutoCoveragebean;

                }

                @JsonInclude(JsonInclude.Include.NON_NULL)
                public static class Discount {

                    @JsonProperty("name")
                    public String name;
                    @JsonProperty("type")
                    public String type;
                    @JsonProperty("code")
                    public String code;

                }

                @JsonProperty("vehicle")
                public List<Vehicle> vehicle;
                @JsonProperty("discount")
                public List<Discount> discount;
                @JsonProperty("liabilityCoverage")
                public LiabilityCoverage liabilityCoverage;

            }


            @JsonProperty("quoteNumber")
            private String quoteNumber;

            @JsonProperty("paymentMode")
            private String paymentMode;
            @JsonProperty("persAutoPolicy")
            private PersAutoPolicy persAutoPolicy;
            @JsonProperty("knockOutInd")
            private Boolean knockOutInd;
            @JsonProperty("brightlinedIndicator")
            private Boolean brightlinedIndicator;
            @JsonProperty("buyEnableInd")
            private String buyEnableInd;

            @JsonIgnore
            @JsonProperty("knockOutBeanList")
            private List<Object> knockOutBeanList;
            @JsonIgnore
            @JsonProperty("infoMessages")
            private List<Object> infoMessages;
            @JsonProperty("payPlanChanged")
            private Boolean payPlanChanged;
            @JsonProperty("flHouseAccount")
            private Boolean flHouseAccount;
            @JsonProperty("isHouseAccount")
            private Boolean isHouseAccount;
            @JsonProperty("coverageAdjustedIndicator")
            private String coverageAdjustedIndicator;

            @JsonProperty("umbrellaPolicyIndicator")
            private String umbrellaPolicyIndicator;
            private String isFastTrackInd;
            @JsonProperty("eligibleForAutoRentersBundle")
            private Boolean eligibleForAutoRentersBundle;
            @JsonProperty("validCityZipForMN")
            private Boolean validCityZipForMN;
            @JsonProperty("eligibleForChat")
            private Boolean eligibleForChat;

        }

        @JsonProperty("quoteNumber")
        private String quoteNumber;
        @JsonProperty("rateQuoteResponses")
        private List<RateQuoteResponse> rateQuoteResponses;
        @JsonProperty("invokePerformRateService")
        private Boolean invokePerformRateService;

    }

    @JsonProperty("AutoRateQuoteResponseBean")
    private AutoRateQuoteResponseBean__1 autoRateQuoteResponseBean;

}










