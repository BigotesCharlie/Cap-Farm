package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;


import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
public class IidResponseBean {
    private RiskReports riskReports;
    private TransactionNotification transactionNotification;

    @Data
    public static class RiskReports {
        private boolean cachedRiskReportIndicator;
        private boolean adpfOrderedIndicator;
        private List<Driver> drivers;
        private boolean iidHitIndicator;
        private IidReport iidReport;
        private String auditReportID;

        @Data
        public static class IidReport {
            private List<RiskIndicator> riskIndicators;

            @Data
            public static class RiskIndicator {
                private String code;
                private String description;
                private boolean dobVerifiedIndicator;

            }

        }

        @Data
        public static class Driver {
            private List<Address> addresses;
            private String dateOfBirth;
            private DriverLicense driversLicense;
            private String externalReference;
            private Name name;

            @Data
            public static class DriverLicense {

            }

            @Data
            public static class Name {
                private String firstName;
                private String lastName;
            }

            @Data
            public static class Address {
                private Location location;
                private Street street;
                private List<String> unparsedAddress;

                @Data
                public static class Location {
                    private String city;
                    private String state;
                    private String zipCode;
                    private String zipCodeExtn;
                }
                @Data
                public static class Street {
                    private String name;
                    private String number;
                }
            }

        }
    }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class TransactionNotification {
        private String transactionCode;
        private String transactionStatus;
        private List<Remark> remark;

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class Remark {
            private String messageCode;
            private String messageText;
        }
    }
}
