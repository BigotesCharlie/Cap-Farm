package com.farmers.ffq.datatransferobjects.hqm;

import com.farmers.framework.Property;
import com.farmers.framework.report.Log;

import java.text.NumberFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.KY;

public class QuoteRateHQM {
    private String quoteNumber;
    private final List<Discount> discounts = new ArrayList<>();
    private String reconstructionCost;
    private final List<PackageType> packageType = new ArrayList<>();
    private final List<Deductible> deductibles = new ArrayList<>();
    private final List<Knockout> knockouts = new ArrayList<>();
    private String totalDiscAmt;

    public String getQuoteNumber() {
        return quoteNumber;
    }

    public List<Discount> getDiscounts() {
        return discounts;
    }

    public String getReconstructionCost() {
        return reconstructionCost;
    }

    public List<PackageType> getPackageType() {
        return packageType;
    }

    public List<Deductible> getDeductibles() {
        return deductibles;
    }

    public List<Knockout> getKnockouts() {
        return knockouts;
    }

    public String getMonthlyPremium() {
        return packageType.get(0).getMonthlyPremium();
    }

    public String getYearlyPremium() {
        return packageType.get(0).getAnnualPremium();
    }

    public String getQuoteType() {
        return packageType.get(0).getPackageTypeDescription();
    }

    public String getTotalDiscAmt() {
        return totalDiscAmt;
    }

    public List<String> getAppliedDiscounts() {
        return discounts.stream().map(Discount::getWebDesc)
                .filter(Objects::nonNull).map(String::toLowerCase)
                .sorted(Comparator.naturalOrder()).collect(Collectors.toList());
    }

    public List<String> getDeductibleDescriptions() {
        List<String> deductibleDesc = deductibles.stream().map(QuoteRateHQM.Deductible::getCode)
                .collect(Collectors.toList());
        List<String> descriptions = new ArrayList<>();
        for (String item : deductibleDesc) {
            switch (item) {
                case "A":
                    descriptions.add("All peril");
                    break;
                case "W":
                    descriptions.add("Wind & Hail");
                    break;
                case "H":
                    descriptions.add("Hurricane");
                    break;
                case "R":
                    descriptions.add("Water");
                    break;
                default:
                    Log.error("Unknown Deductible Code: " + item);
                    return null;
            }
        }
        return descriptions;
    }

    public String getDeductibleValue(String deductibleDesc, String stateCode) {
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
        currencyFormat.setGroupingUsed(false);
        currencyFormat.setMaximumFractionDigits(0);
        NumberFormat percentFormat = NumberFormat.getPercentInstance(Locale.US);
        percentFormat.setMaximumFractionDigits(1);
        String value = null;
        for (Deductible item : deductibles) {
            switch (item.getCode()) {
                case "A":
                    if (deductibleDesc.equals("All Peril")) {
                        value = item.getValue();
                    }
                    break;
                case "W":
                    if (deductibleDesc.equals("Wind & Hail")) {
                        value = item.getValue();
                    }
                    break;
                case "H":
                    if (deductibleDesc.equals("Hurricane")) {
                        value = item.getValue();
                    }
                    break;
                case "R":
                    if (deductibleDesc.equals("Water")) {
                        value = item.getValue();
                    }
                    break;
                default:
                    Log.error("Unknown Deductible Description: " + item);
                    return null;
            }
            if (value != null) {
                break;
            }
        }
        if (value != null) {
            double dSliderValue = Double.parseDouble(value);
            if (dSliderValue > 100) {
                value = currencyFormat.format(dSliderValue);
            } else {
                if (stateCode.equals(KY) && Property.ENVIRONMENT.equals("hqm_qa_qa1")) {
                    value = percentFormat.format(dSliderValue / 1000);
                } else {
                    value = dSliderValue / 10 + "%";
                }
            }
        }
        return value;
    }

    public String getCoverageAmount(String coverageDesc) {
        String amount = null;
        for (CoverageValue coverageValue : packageType.get(0).getCoverageValues()) {
            if (coverageValue.getCoverageDescription().equals(coverageDesc)) {
                amount = coverageValue.getValues().get(0).getAmount();
                break;
            }
        }
        return amount;
    }

    public String getKnockoutCode() {
        if (!knockouts.isEmpty()) {
            return knockouts.get(0).getKnockoutCode();
        } else {
            return null;
        }
    }

    public static class PackageType {
        private String packageTypeDescription;
        private final List<CoverageValue> coverageValues = new ArrayList<>();
        private String annualPremium;
        private String packageTypeCode;
        private String monthlyPremium;

        public String getPackageTypeDescription() {
            return packageTypeDescription;
        }

        public List<CoverageValue> getCoverageValues() {
            return coverageValues;
        }

        public String getAnnualPremium() {
            return annualPremium;
        }

        public String getPackageTypeCode() {
            return packageTypeCode;
        }

        public String getMonthlyPremium() {
            return monthlyPremium;
        }
    }

    public static class Discount {
        private String discountCode;
        private String webDesc;

        public String getDiscountCode() {
            return discountCode;
        }

        public String getWebDesc() {
            return webDesc;
        }
    }

    public static class CoverageValue {
        private final List<Coverage> values = new ArrayList<>();
        private String coverageDescription;
        private String coverageCode;

        public List<Coverage> getValues() {
            return values;
        }

        public String getCoverageDescription() {
            return coverageDescription;
        }

        public String getCoverageCode() {
            return coverageCode;
        }
    }

    public static class Coverage {
        private String amount;
        private String sequenceNo;
        private String coveragePremium;

        public String getAmount() {
            return amount;
        }

        public String getSequenceNo() {
            return sequenceNo;
        }

        public String getCoveragePremium() {
            return coveragePremium;
        }
    }

    public static class Deductible {
        private String code;
        private String value;
        private String minValue;
        private String sequenceNumber;

        public String getCode() {
            return code;
        }

        public String getValue() {
            return value;
        }

        public String getMinValue() {
            return minValue;
        }

        public String getSequenceNumber() {
            return sequenceNumber;
        }
    }

    public static class Knockout {
        private String knockoutCode;
        private String knockoutMessage;

        public String getKnockoutCode() {
            return knockoutCode;
        }

        public String getKnockoutMessage() {
            return knockoutMessage;
        }

    }

}
