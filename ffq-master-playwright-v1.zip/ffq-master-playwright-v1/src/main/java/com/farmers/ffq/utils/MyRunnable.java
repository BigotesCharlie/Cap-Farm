package com.farmers.ffq.utils;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.ffq.common.pages.BasePage.sendGetRequest;

public class MyRunnable implements Runnable {

    private final PWElement hrefElement;

    public MyRunnable(PWElement element) {
        this.hrefElement = element;
    }

    @Override
    public void run() {
        sendGetRequest(hrefElement);
    }
}
