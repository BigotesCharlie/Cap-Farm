package com.farmers.ffq.utils;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.auto.pages.AutoBasePage;


import com.farmers.ffq.datatransferobjects.AutoApplicant;

import javax.annotation.Nullable;

public class MailinatorHelper extends AutoBasePage {

    @PWFindBy(css = "#menu-item-7937")
    private PWElement logInButton;

    @PWFindBy(id = "many_login_email")
    private PWElement emailIdLoginInputField;

    @PWFindBy(id = "many_login_password")
    private PWElement passwordInputField;

    @PWFindBy(css = "a[class='btn btn-default submit']")
    private PWElement logInSubmit;

    @PWFindBy(css = "input[id='inbox_field']")
    private PWElement emailUserNameInputField;

    @PWFindBy(xpath = "//div[@class='wrapper-title d-flex align-items-center']//div[2]")
    private PWElement emailSubject;

    @PWFindBy(css = "img[title='Farmers Insurance']")
    private PWElement farmersInsuranceLink;

    @PWFindBy(css = "span[style='font-size: 28px']>b")
    private PWElement premiumAmount;

    @PWFindBy(partialLinkText = "Finish my quote")
    private PWElement finishMyQuote;

    @PWFindBy(partialLinkText = "Finalize my coverage")
    private PWElement finalizeMyCoverage;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public MailinatorHelper() throws Exception {
    }

    private final String MAILINATOR_URL = "https://www.mailinator.com/";

    private void logIntoMailinator() throws Exception {
        driver().navigate().refresh();
        driver().get(MAILINATOR_URL);
        String emailId = "ali.ak@farmersinsurance.com";
        String password = "Farmers123!";
        waitAndClickElement(logInButton);
        sendKeysToElement(waitElementBeVisible(emailIdLoginInputField), emailId);
        sendKeysToElement(waitElementBeVisible(passwordInputField), password);
        waitAndClickElement(logInSubmit);
    }

    private void openEmail(String emailUserName) throws Exception{

        logIntoMailinator();
        sendKeysToElement(waitElementBeVisible(emailUserNameInputField), emailUserName);
        sleep(1);
        PWElement lastRecievedEmail = waitElementBeVisible(driver().findElement(PWBy.xpath(String.format("//tr[contains(@id,'row_%s')][1]", emailUserName))));

        waitAndClickElement(lastRecievedEmail);

    }

    public boolean validateEmailContent(AutoApplicant applicant, String emailUserName, String expectedSubject, String expectedEmailContentHeader, String quoteNumber, @Nullable String expectedPremiumAmount) throws Exception {

        boolean validated = true;
        // wait for the email to drop in the inbox
        sleep(5);
        openEmail(emailUserName.split("@")[0]);

        //validate subject of the email
        validated &= validateEmailSubject(applicant, expectedSubject);

        // validate email body
        validated &= validateEmailBody(applicant, expectedEmailContentHeader, quoteNumber);

        if(expectedPremiumAmount != null) {
            String actualPremiumAmount = getPremiumAmount();
            System.out.println("Actual Premium Amount => " + actualPremiumAmount);
            System.out.println("Expected Premium Amount => " + expectedPremiumAmount);
            validated &= actualPremiumAmount.contains(expectedPremiumAmount);
        }

        return validated;

    }

    private boolean validateEmailBody(AutoApplicant applicant, String expectedEmailContentHeader, String quoteNumber) throws Exception {
        boolean validated = true;
        driver().switchTo().frame("html_msg_body");
        //validate the title of the email body
        validated &= getTextFromElement(waitElementBeVisible(driver().findElement(PWBy.xpath(String.format("//p[contains(.,'%s')]", expectedEmailContentHeader))))).contains(applicant.getFirstName());
        // validate quote number correctly displayed
        validated &= waitElementBeVisible(driver().findElement(PWBy.xpath(String.format("//b[contains(.,'%s')]", quoteNumber)))).isDisplayed();
        return validated;
    }

    private boolean validateEmailSubject(AutoApplicant applicant, String expectedSubject) {
        boolean validated = true;
        String expectedSubjectText = applicant.getFirstName() + expectedSubject;
        // validate subjectLine
        validated &= testExpectedTextContentForElement(waitElementBeVisible(emailSubject), expectedSubjectText);
        return validated;
    }

    public String getPremiumAmount() throws Exception {
       return getTextFromElement(driver().findElement(PWBy.cssSelector("span[style='font-size: 28px']>b")));
    }

    public void clickOnFinishMyQuote() {
       waitAndClickElement(finishMyQuote);
    }

    public void clickOnFinalizeMyQuote() {
       waitAndClickElement(finalizeMyCoverage);
    }

}
