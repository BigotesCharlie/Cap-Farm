package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class BWAutoVerifyServiceStarted {
    private AutoQuoteVerifyServiceInitiated.AutoQuote autoQuote;
}
