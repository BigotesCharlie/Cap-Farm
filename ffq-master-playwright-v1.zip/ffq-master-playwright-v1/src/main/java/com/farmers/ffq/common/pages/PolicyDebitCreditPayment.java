package com.farmers.ffq.common.pages;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.auto.pages.bindpages.AutoPolicyPaymentBasePage;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class PolicyDebitCreditPayment extends AutoPolicyPaymentBasePage {

    protected static final String MONTHLY_AUTO_PAY_CARD_HEADER = "Monthly autopay - card";

    @PWFindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_CARD_HEADER + "')]")
    private PWElement monthlyAutoPayCardHeader;

    @PWFindBy(xpath = "//input[@id='ccExpirationDate']")
    private PWElement expirationDateInputField;
    private static final String CREDIT_CARD_ADDED_MSG = "Credit card added.";
    @PWFindBy(xpath = "//span[contains(text(),'" +  CREDIT_CARD_ADDED_MSG + "')]")
    private PWElement creditCardAddedMsg;

    private static final String DEBIT_CARD_ADDED_MSG = "Debit card added.";
    @PWFindBy(xpath = "//span[contains(text(),'" +  DEBIT_CARD_ADDED_MSG + "')]")
    private PWElement debitCardAddedMsg;
    public static final String NO_SERVICE_CHARGE_WHEN_PAY_IN_FULL = "No service charges when you pay in full";
    @PWFindBy(xpath = "//p[contains(text(),'" +  NO_SERVICE_CHARGE_WHEN_PAY_IN_FULL + "')]")
    private PWElement noServiceChargeWhenPayInFullMsg;

    @PWFindBy(xpath = "//*[contains(@src,'cc_amex')]")
    private PWElement amexIconOnAutoPolicyPaymentScreen;

    @PWFindBy(xpath = "//*[contains(@src,'cc_mastercard')]")
    private PWElement masterCardIconOnAutoPolicyPaymentScreen;

    @PWFindBy(xpath = "//*[contains(@src,'cc_discover')]")
    private PWElement discoverCardIconOnAutoPolicyPaymentScreen;

    @PWFindBy(xpath = "//*[contains(@src,'cc_visa')]")
    private PWElement visaCardIconOnAutoPolicyPaymentScreen;
    @PWFindBy(xpath = "//span[contains(@class,'pif-autopay-disclaimers-account-numbers')]//span")
    private PWElement hiddenCardNumberAndExpDatePayInFull;

    @PWFindBy(xpath = "//span[contains(@class,'monthly-autopay-disclaimers-account-numbers')]//small")
    private PWElement hiddenCardNumberAndExpDateMonthlyPay;
    private static final String CHANGE_LINK = "Change";
    @PWFindBy(xpath = "//a[contains(text(), '" + CHANGE_LINK + "')]")
    private PWElement changeLink;
    private static final String AUTOMATIC_RECURRING_PAYMENT_TEXT = "A one-time payment and automatic recurring payments.";
    @PWFindBy(xpath = "//p[contains(text(),'" +  AUTOMATIC_RECURRING_PAYMENT_TEXT + "')]")
    private PWElement automaticRecurringPaymentText;
    private static final String ONE_TIME_PAYMENT_TEXT = "A one-time payment only.";
    @PWFindBy(xpath = "//p[contains(text(),'" +  ONE_TIME_PAYMENT_TEXT + "')]")
    private PWElement oneTimePaymentText;
    @PWFindBy(xpath = "//input[@value='one-time-payment']")
    private PWElement oneTimePaymentRadioButton;
    @PWFindBy(xpath = "//input[@value='automatic-recurring']")
    private PWElement automaticRecurringPaymentRadioButton;
    private static final String FUTURE_MONTHLY_PAYMENT_INCLUDE_$5 = "Future monthly payments will include a $5 service charge.";
    @PWFindBy(xpath = "//span[contains(text(), '$5')]/parent::span")
    private PWElement futureMonthlyPaymentInclude$5;

    private static final String FUTURE_MONTHLY_PAYMENT_INCLUDE_$3 = "Future monthly payments will include a $3 service charge.";
    @PWFindBy(xpath = "//span[contains(text(), '$3')]/parent::span")
    private PWElement futureMonthlyPaymentInclude$3;

    public static final String FUTURE_MONTHLY_SERVICE_CHARGE_CARD = "Future monthly payments will include a $5 service charge.";
    @PWFindBy(xpath = "//div[contains(@class,'monthly-autopay-disclaimers-details')]//p")
    private PWElement futureMonthlyPaymentsServiceChargeCard;


    private static final String COMPLETE_PURCHASE_BUTTON = "Complete purchase";
    @PWFindBy(xpath = "//button[contains(text(), '" + COMPLETE_PURCHASE_BUTTON + "')]")
    private PWElement completerPurchaseButton;


    public PolicyDebitCreditPayment() throws Exception {
    }

    public boolean isNameOnCardMatching(String fullName){
        String accountHolderNameFromInputField = getValueForFullNamePaymentusFrame();
        boolean isNameOnCardMatching= fullName.equals(accountHolderNameFromInputField);
        return isNameOnCardMatching;
    }

    public boolean isCreditCardAddedMsgCorrect(){
       // wait.until(ExpectedConditions.visibilityOf(creditCardAddedMsg));
        return isExpectedTextDisplayed(creditCardAddedMsg, CREDIT_CARD_ADDED_MSG);
    }

    public boolean isDebitCardAddedMsgCorrect(){
        return isExpectedTextDisplayed(debitCardAddedMsg, DEBIT_CARD_ADDED_MSG);
    }

    public boolean isNoServiceChargeWhenPayInFullMsgCorrect(String lobType){
        String noServiceChargeMessage = !lobType.equals(AUTO)? NO_SERVICE_CHARGE_WHEN_PAY_IN_FULL+ "." : NO_SERVICE_CHARGE_WHEN_PAY_IN_FULL;
        return isExpectedTextDisplayed(noServiceChargeWhenPayInFullMsg, noServiceChargeMessage);
    }

    public boolean isHiddenCardNumberAndExpDatePayInfFullCorrect(String cardNumber, String expDate, String cardName){
        String lastFourDigitOfCardNumber = getLastFourDigitOfCard(cardNumber);
        boolean cardSymbolDisplayed = waitUntilCardSymbolIsDisplayed(cardName);
        boolean isHiddenCardNumberCorrect = getTextFromElement(hiddenCardNumberAndExpDatePayInFull).contains(lastFourDigitOfCardNumber);
        boolean isExpDateCorrect = getTextFromElement(hiddenCardNumberAndExpDatePayInFull).contains(expDate);
        return isHiddenCardNumberCorrect && isExpDateCorrect && cardSymbolDisplayed;
    }

    public boolean waitUntilCardSymbolIsDisplayed(String cardName){
        boolean cardSymbolDisplayed = false;
        if(cardName.equals(CARD_NAME_VISA)){
            cardSymbolDisplayed = isElementVisible(visaCardIconOnAutoPolicyPaymentScreen, 5);
        } else if(cardName.equals(CARD_NAME_AMEX)){
            cardSymbolDisplayed = isElementVisible(amexIconOnAutoPolicyPaymentScreen, 5);
        } else if(cardName.equals(CARD_NAME_MASTER)){
            cardSymbolDisplayed = isElementVisible(masterCardIconOnAutoPolicyPaymentScreen, 5);
        } else if(cardName.equals(CARD_NAME_DISCOVER)){
            cardSymbolDisplayed = isElementVisible(discoverCardIconOnAutoPolicyPaymentScreen, 5);
        }
        return cardSymbolDisplayed;
    }

    public boolean isHiddenCardNumberAndExpDateMonthlyPayCorrect(String cardNumber, String expDate, String cardName){
        String lastFourDigitOfCardNumber =getLastFourDigitOfCard(cardNumber);
        sleep(5);
        wait.until(PWExpectedConditions.elementToBeClickable(changeLink));
        wait.until(PWExpectedConditions.visibilityOf(hiddenCardNumberAndExpDateMonthlyPay));
        boolean isHiddenCardNumberCorrect = testExpectedTextContentContainsForElement(hiddenCardNumberAndExpDateMonthlyPay, lastFourDigitOfCardNumber);
        boolean isExpDateCorrect = testExpectedTextContentContainsForElement(hiddenCardNumberAndExpDateMonthlyPay, expDate);
        boolean cardSymbolDisplayed = waitUntilCardSymbolIsDisplayed(cardName);
        return isHiddenCardNumberCorrect && isExpDateCorrect && cardSymbolDisplayed;
    }

    public void clickChangeLink(){
        scrollAndClickOnElement(changeLink);
    }

    public void waitForCompletePurchaseButtonToBeClickable() throws Exception {
        driver().switchTo().defaultContent();
        waitElementBeVisibleClickable(completerPurchaseButton);
    }

    public boolean isAutomaticRecurringTextCorrect(){
        return isExpectedTextDisplayed(automaticRecurringPaymentText, AUTOMATIC_RECURRING_PAYMENT_TEXT);
    }

    public boolean isOneTimePaymentTextCorrect(){
        return isExpectedTextDisplayed(oneTimePaymentText, ONE_TIME_PAYMENT_TEXT);
    }

    public void selectAutomaticRecurringRadioButton(){
        waitAndClickElement(automaticRecurringPaymentRadioButton);
    }

    public void selectOneTimePaymentRadioButton(){
        waitAndClickElement(oneTimePaymentRadioButton);
    }

    public boolean isFutureCreditCardServiceChargesTextMatching(){
        return isExpectedTextDisplayed(futureMonthlyPaymentInclude$5, FUTURE_MONTHLY_PAYMENT_INCLUDE_$5);
    }

    public boolean isFutureDebitCardServiceChargesTextMatching(){
        return isExpectedTextDisplayed(futureMonthlyPaymentInclude$3, FUTURE_MONTHLY_PAYMENT_INCLUDE_$3);
    }

    public boolean isFutureCardServiceChargesTextMatching(){
        return isExpectedTextDisplayed(futureMonthlyPaymentsServiceChargeCard, FUTURE_MONTHLY_SERVICE_CHARGE_CARD);
    }

    public boolean isOnAutoPolicyAutoPayCardPage() {
        return isElementVisible(monthlyAutoPayCardHeader, 25);
    }

    public void validateADA_AutoPolicyPaymentAutoPayCard() {
        isOnAutoPolicyAutoPayCardPage();
        if(isADATestingEnabled()) {
            performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
        }
    }

    public String getLastFourDigitOfCard(String cardNumber){
        return cardNumber.substring(cardNumber.length()-4);
    }
}

