package com.farmers.ffq.utils;

import com.farmers.framework.Property;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class AESHelper {

	static SecretKeySpec spec = null;

	private AESHelper() {
		throw new IllegalStateException("Utility class");
	}

	public static SecretKeySpec getKeySpec() throws IOException {

		if (spec == null) {
			String keyFile = "adb_aes_test.key";
			InputStream fis;
			fis = Property.class.getClassLoader().getResourceAsStream(keyFile);
			byte[] rawkey = new byte[16];
			fis.read(rawkey);
			fis.close();
			spec = new SecretKeySpec(rawkey, "AES");
		}
		return spec;
	}

	public static SecretKeySpec getKeySpecToggle() throws IOException {

		if (spec == null) {
			String keyFile = "tg_aes_test.key";
			InputStream fis;
			fis = Property.class.getClassLoader().getResourceAsStream(keyFile);
			byte[] rawkey = new byte[16];
			fis.read(rawkey);
			fis.close();
			spec = new SecretKeySpec(rawkey, "AES");
		}
		return spec;
	}

	public static String encryptWithOutIV(String text) throws IOException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		SecretKeySpec spec = getKeySpec();
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, spec);
		return new String(Base64.getEncoder().encode(cipher.doFinal(text.getBytes())));
	}

	public static String decryptWithOutIV(String text) throws IOException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		SecretKeySpec spec = getKeySpec();
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, spec);
		return new String(cipher.doFinal(Base64.getDecoder().decode(text.getBytes())));
	}

	public static String encryptToggle(String text) throws IOException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		SecretKeySpec spec = getKeySpecToggle();
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, spec);
		return new String(Base64.getEncoder().encode(cipher.doFinal(text.getBytes())));
	}

	public static String decryptToggle(String text) throws IOException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		SecretKeySpec spec = getKeySpecToggle();
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, spec);
		return new String(cipher.doFinal(Base64.getDecoder().decode(text.getBytes())));
	}
}
