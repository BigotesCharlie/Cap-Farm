package com.farmers.ffq.datatransferobjects;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.utils.DateCalculations;
import lombok.Data;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Data
public class AutoApplicant {
	private int applicantId;
	private String testCategory;
	private String testScenario;
	private String firstName;
	private String lastName;
	private String residentAddress;
	private String apartmentNumber;
	private String city;
	private String zipCode;
	private String stateCode;
	private String stateName;
	private int age;
	private String dateOfBirth;
	private String gender;
	private String maritalStatus;
	private String occupation;

	private String singleVehicle;
	private String otherOccupation;
	private String currentlyInsuredStatus;
	private String currentInsuranceCompany;
	private String continuosInsurancePeriod;
	private String currentInsuranceExpirationDate;
	private String currentBodilyInjuryLimit;
	private String financialFiling;
	private int firstAgeUnitedStatesDriverLicense;
	private int firstAgeForeignDriverLicense;
	private boolean fullTimeStudentWithHighGPA;
	private boolean mailingAddressDifferent;
	private String email;
	private String phoneNumber;
	private boolean completedDriversSafetyCourse;
	private boolean havePersonalInjuryLoss;
	private boolean haveAccidentOrViolations;
	private String driversLicense;
	private String licenseIssueStateName;
	private String garagingAddress;

	// Links to other data sheets
	private List<Vehicle> vehicles;
	private List<SqlAdditionalDriver> additionalDrivers;
	private List<SqlIncident> incidents;
	private List<SqlDiscount> discounts;

	public AutoApplicant(ApplicantHQM applicantHQM, boolean homeOwner) {
		applicantId = 99;
		testScenario = applicantHQM.umbrellaInsurance ? LOB_UMBRELLA : "";
		firstName = applicantHQM.firstName;
		lastName = applicantHQM.lastName;
		gender = applicantHQM.gender.isBlank() ? "Male" : applicantHQM.gender;
		dateOfBirth = applicantHQM.dateOfBirth;
		age = Math.toIntExact(DateCalculations.ageFromDob(applicantHQM.dateOfBirth));
		maritalStatus = applicantHQM.maritalStatus;
		if (!Arrays.asList(KY, LA, MA, MS, NC, MN).contains(applicantHQM.stateCode)) {
			occupation = applicantHQM.occupation;
		} else {
			occupation = OTHER;
		}
		firstAgeUnitedStatesDriverLicense = 18;
		completedDriversSafetyCourse = true;
		haveAccidentOrViolations = false;
		currentlyInsuredStatus = "Insured";
		currentInsuranceCompany = "AAA";
		currentBodilyInjuryLimit = "$50,000/$100,000";
		currentInsuranceExpirationDate = LocalDate.now().plusMonths(1).format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		continuosInsurancePeriod = "12 - 23 Months";
		residentAddress = applicantHQM.addressApt;
		city = applicantHQM.city;
		stateCode = applicantHQM.stateCode;
		zipCode = applicantHQM.zipCode;
		phoneNumber = applicantHQM.phoneNumber;
		email = applicantHQM.emailAddress;

		additionalDrivers = new ArrayList<>();
		if (maritalStatus.equalsIgnoreCase("Married")) {
			SqlAdditionalDriver additionalDriver = new SqlAdditionalDriver();
			additionalDriver.setFirstName(applicantHQM.spouseFirstName);
			additionalDriver.setLastName(applicantHQM.spouseLastName);
			additionalDriver.setDateOfBirth(applicantHQM.spouseDateOfBirth);
			additionalDriver.setAge(Math.toIntExact(DateCalculations.ageFromDob(applicantHQM.spouseDateOfBirth)));
			additionalDriver.setMaritalStatus(applicantHQM.maritalStatus);
			additionalDriver.setRelationshipToApplicant("spouse");
			additionalDriver.setGender(applicantHQM.getSpouseGender().isBlank() ? "Female" : applicantHQM.getSpouseGender());
			additionalDriver.setLicenseToDriveInUSA(YES);
			additionalDriver.setFirstAgeUnitedStatesDriverLicense(18);
			additionalDriver.setCompletedDriversSafetyCourse(true);
			additionalDriver.setAnyIncident(false);
			additionalDrivers.add(additionalDriver);
		}

		vehicles = new ArrayList<>();
		Vehicle vehicle1 = new Vehicle();
		vehicle1.setVehicleYear("2020");
		vehicle1.setVehicleMake("ACURA");
		vehicle1.setVehicleModel("ILX 4D");
		vehicle1.setVehicleType("2WD SUV");
		vehicle1.setVehicleUsage("Personal");
		vehicle1.setOwnership("Financed");
		vehicle1.setPurchaseDate("062020");
		vehicle1.setParkInResidentAddress(true);
		vehicles.add(vehicle1);
		Vehicle vehicle2 = new Vehicle();
		vehicle2.setVehicleYear("2018");
		vehicle2.setVehicleMake("TOYOTA");
		vehicle2.setVehicleModel("CAMRY 4D 2WD XSE");
		vehicle2.setVehicleType("Sedan");
		vehicle2.setVehicleUsage("Personal");
		vehicle2.setOwnership("Owned");
		vehicle2.setPurchaseDate("062018");
		vehicle2.setParkInResidentAddress(true);
		vehicles.add(vehicle2);

        discounts = new ArrayList<>();
		SqlDiscount discount = new SqlDiscount();
		discount.setHomeInsurance(homeOwner);
		discount.setOwnOrRentHome(homeOwner ? "Own" : "Rent");
		discount.setStartDateOfNewPolicy(DateTimeFormatter.ofPattern("MM/dd/yyyy").format(LocalDate.now().plusDays(14)));
		discounts.add(discount);

	}

	public AutoApplicant() {
	}

	public AutoApplicant(ApplicantCondo condoApplicant) {
		applicantId = 100;
		testCategory = "Cross Sell";
		firstName = condoApplicant.getFirstName();
		lastName = condoApplicant.getLastName();
		age = condoApplicant.getAge();
		residentAddress = condoApplicant.getAddressApt();
		city = condoApplicant.getCity();
		apartmentNumber = condoApplicant.getAptNumber();
		dateOfBirth = BasePage.calculateDateOfBirthFromAge(condoApplicant.getAge());
		testScenario = "Cross Sell from Condo to Ace Auto";
		maritalStatus = condoApplicant.getMaritalStatus();
		zipCode = condoApplicant.getZipCode();
		stateCode = condoApplicant.getStateCode();
		stateName = condoApplicant.getState();
		gender = condoApplicant.getGender();
		occupation =  condoApplicant.getOccupation();
		singleVehicle = "Yes";
		otherOccupation = EMPTY_STRING;
		currentlyInsuredStatus = "Insured";
		currentInsuranceCompany = "AAA";

		continuosInsurancePeriod = "60+ Months";
		currentInsuranceExpirationDate = DateTimeFormatter.ofPattern("MM/dd/yyyy").format(LocalDate.now().plusDays(14));
		currentBodilyInjuryLimit = "$50,000/$100,000";
		financialFiling = NO;
		firstAgeUnitedStatesDriverLicense = 16;
		firstAgeForeignDriverLicense = 0;
		fullTimeStudentWithHighGPA = false;
		mailingAddressDifferent = condoApplicant.isMailingAddressDifferent();
		email = condoApplicant.getEmailAddress();
		phoneNumber = condoApplicant.getPhoneNumber();

		completedDriversSafetyCourse = false;
		havePersonalInjuryLoss = false;
		haveAccidentOrViolations = false;
		driversLicense = EMPTY_STRING;
		licenseIssueStateName = stateName;
		garagingAddress = EMPTY_STRING;

		// additional drivers
		additionalDrivers = new ArrayList<>();
		if(condoApplicant.getMaritalStatus().equals(MARRIED)) {
			SqlAdditionalDriver additionalDriver = new SqlAdditionalDriver();
			additionalDriver.setFirstName(condoApplicant.getSpouseFirstName());
			additionalDriver.setLastName(condoApplicant.getSpouseLastName());
			additionalDriver.setGender(condoApplicant.getSpouseGender());
			additionalDriver.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(condoApplicant.getAge()));
			additionalDriver.setOccupation(condoApplicant.getSpouseOccupation());
			additionalDriver.setAge(condoApplicant.getSpouseAge());
			additionalDriver.setMaritalStatus(condoApplicant.getMaritalStatus());
			additionalDriver.setRelationshipToApplicant(SPOUSE);
			additionalDriver.setLicenseToDriveInUSA(YES);
			additionalDriver.setFirstAgeUnitedStatesDriverLicense(18);
			additionalDriver.setCompletedDriversSafetyCourse(false);
			additionalDriver.setAnyIncident(false);
			additionalDriver.setFullTimeStudentWithHighGPA(false);
			additionalDrivers.add(additionalDriver);
		}

		vehicles = new ArrayList<>();
		Vehicle vehicle1 = new Vehicle();
		vehicle1.setUseVIN(true);
		vehicle1.setVehicleUsage("Personal");
		vehicle1.setOwnership("Financed");
		vehicle1.setPurchaseDate("06" + (LocalDate.now().getYear() - 2));
		vehicle1.setParkInResidentAddress(true);
		vehicle1.setVehicleYear("2020");
		vehicle1.setVehicleMake("ACURA");
		vehicle1.setVehicleModel("ILX 4D");
		vehicle1.setVehicleType("2WD SUV");
		vehicles.add(vehicle1);

		discounts = new ArrayList<>();
		SqlDiscount discount = new SqlDiscount();
		discount.setHomeInsurance(true);
		discount.setOwnOrRentHome("Own");
		discount.setStartDateOfNewPolicy(DateTimeFormatter.ofPattern("MM/dd/yyyy").format(LocalDate.now().plusDays(14)));
		discounts.add(discount);
	}

	public AutoApplicant(ApplicantLife lifeApplicant) {
		applicantId = 100;
		testCategory = "Cross Sell";
		firstName = lifeApplicant.getFirstName();
		lastName = lifeApplicant.getLastName();
		age = lifeApplicant.getAge();
		residentAddress = lifeApplicant.getAddress();
		city = lifeApplicant.getCity();
		apartmentNumber = lifeApplicant.getApartment();
		dateOfBirth = BasePage.calculateDateOfBirthFromAge(lifeApplicant.getAge());
		testScenario = "Cross Sell from Condo to Ace Auto";
		maritalStatus = "Single";
		zipCode = lifeApplicant.getZipCode();
		stateCode = lifeApplicant.getStateCode();
		stateName = lifeApplicant.getState();
		gender = lifeApplicant.getGender();
		occupation =  lifeApplicant.getOccupation();
		singleVehicle = "Yes";
		otherOccupation = EMPTY_STRING;
		currentlyInsuredStatus = "Insured";
		currentInsuranceCompany = "AAA";

		continuosInsurancePeriod = "60+ Months";
		currentInsuranceExpirationDate = DateTimeFormatter.ofPattern("MM/dd/yyyy").format(LocalDate.now().plusDays(14));
		currentBodilyInjuryLimit = "$50,000/$100,000";
		financialFiling = NO;
		firstAgeUnitedStatesDriverLicense = 16;
		firstAgeForeignDriverLicense = 0;
		fullTimeStudentWithHighGPA = false;
		mailingAddressDifferent = false;
		email = lifeApplicant.getEmailAddress();
		phoneNumber = lifeApplicant.getPhoneNumber();

		completedDriversSafetyCourse = false;
		havePersonalInjuryLoss = false;
		haveAccidentOrViolations = false;
		driversLicense = EMPTY_STRING;
		licenseIssueStateName = stateName;
		garagingAddress = EMPTY_STRING;

		vehicles = new ArrayList<>();
		Vehicle vehicle1 = new Vehicle();
		vehicle1.setUseVIN(true);
		vehicle1.setVehicleUsage("Personal");
		vehicle1.setOwnership("Financed");
		vehicle1.setPurchaseDate("06" + (LocalDate.now().getYear() - 2));
		vehicle1.setParkInResidentAddress(true);
		vehicle1.setVehicleYear("2020");
		vehicle1.setVehicleMake("ACURA");
		vehicle1.setVehicleModel("ILX 4D");
		vehicle1.setVehicleType("2WD SUV");
		vehicles.add(vehicle1);

		discounts = new ArrayList<>();
		SqlDiscount discount = new SqlDiscount();
		discount.setHomeInsurance(true);
		discount.setOwnOrRentHome("Own");
		discount.setStartDateOfNewPolicy(DateTimeFormatter.ofPattern("MM/dd/yyyy").format(LocalDate.now().plusDays(14)));
		discounts.add(discount);
	}

	public AutoApplicant(ApplicantRenters applicantRenters) {
		applicantId = 100;
		testCategory = "Cross Sell";
		firstName = applicantRenters.getFirstName();
		lastName = applicantRenters.getLastName();
		age = applicantRenters.getAge();
		residentAddress = applicantRenters.getAddressApt();
		city = applicantRenters.getCity();
		dateOfBirth = BasePage.calculateDateOfBirthFromAge(applicantRenters.getAge());
		testScenario = "Cross Sell from Condo to Ace Auto";
		maritalStatus = applicantRenters.getMaritalStatus();
		zipCode = applicantRenters.getZipCode();
		stateCode = applicantRenters.getStateCode();
		stateName = applicantRenters.getState();
		gender = applicantRenters.getGender();
		occupation =  "Accountant";
		singleVehicle = "Yes";
		otherOccupation = EMPTY_STRING;
		currentlyInsuredStatus = "Insured";
		currentInsuranceCompany = "AAA";

		continuosInsurancePeriod = "60+ Months";
		currentInsuranceExpirationDate = DateTimeFormatter.ofPattern("MM/dd/yyyy").format(LocalDate.now().plusDays(14));
		currentBodilyInjuryLimit = "$50,000/$100,000";
		financialFiling = NO;
		firstAgeUnitedStatesDriverLicense = 16;
		firstAgeForeignDriverLicense = 0;
		fullTimeStudentWithHighGPA = false;
		mailingAddressDifferent = false;
		email = applicantRenters.getEmailAddress();
		phoneNumber = applicantRenters.getPhoneNumber();

		completedDriversSafetyCourse = false;
		havePersonalInjuryLoss = false;
		haveAccidentOrViolations = false;
		driversLicense = EMPTY_STRING;
		licenseIssueStateName = stateName;
		garagingAddress = EMPTY_STRING;

		// additional drivers
		additionalDrivers = new ArrayList<>();
		if(applicantRenters.getMaritalStatus().equals(MARRIED)) {
			SqlAdditionalDriver additionalDriver = new SqlAdditionalDriver();
			additionalDriver.setFirstName(applicantRenters.getSpouseFirstName());
			additionalDriver.setLastName(applicantRenters.getSpouseLastName());
			additionalDriver.setGender(applicantRenters.getSpouseGender());
			additionalDriver.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(applicantRenters.getAge()));
			additionalDriver.setOccupation("Engineer");
			additionalDriver.setAge(applicantRenters.getSpouseAge());
			additionalDriver.setMaritalStatus(applicantRenters.getMaritalStatus());
			additionalDriver.setRelationshipToApplicant(SPOUSE);
			additionalDriver.setLicenseToDriveInUSA(YES);
			additionalDriver.setFirstAgeUnitedStatesDriverLicense(18);
			additionalDriver.setCompletedDriversSafetyCourse(false);
			additionalDriver.setAnyIncident(false);
			additionalDriver.setFullTimeStudentWithHighGPA(false);
			additionalDrivers.add(additionalDriver);
		}

		vehicles = new ArrayList<>();
		Vehicle vehicle1 = new Vehicle();
		vehicle1.setUseVIN(true);
		vehicle1.setVehicleUsage("Personal");
		vehicle1.setOwnership("Financed");
		vehicle1.setPurchaseDate("06" + (LocalDate.now().getYear() - 2));
		vehicle1.setParkInResidentAddress(true);
		vehicle1.setVehicleYear("2020");
		vehicle1.setVehicleMake("ACURA");
		vehicle1.setVehicleModel("ILX 4D");
		vehicle1.setVehicleType("2WD SUV");
		vehicles.add(vehicle1);

		discounts = new ArrayList<>();
		SqlDiscount discount = new SqlDiscount();
		discount.setHomeInsurance(true);
		discount.setOwnOrRentHome("Own");
		discount.setStartDateOfNewPolicy(DateTimeFormatter.ofPattern("MM/dd/yyyy").format(LocalDate.now().plusDays(14)));
		discounts.add(discount);
	}

    @Override
	public String toString() {
		return String.format("#%d - %s in %s: %s", applicantId, testCategory, stateCode, testScenario);
	}

	public String getDetails() {
		return String.format("%s %s %s %s %s %s", firstName, lastName, residentAddress, city, stateCode, zipCode);
	}

	public String dump() {
		StringBuilder dataString = new StringBuilder("APPLICANT: " +
				applicantId + "," +
				testCategory + "," +
				testScenario + "," +
				firstName + "," +
				lastName + "," +
				residentAddress + "," +
				apartmentNumber + "," +
				city + "," +
				zipCode + "," +
				stateCode + "," +
				stateName + "," +
				age + "," +
				dateOfBirth + "," +
				gender + "," +
				maritalStatus + "," +
				occupation + "," +
				otherOccupation + "," +
				currentlyInsuredStatus + "," +
				currentInsuranceCompany + "," +
				continuosInsurancePeriod + "," +
				currentInsuranceExpirationDate + "," +
				currentBodilyInjuryLimit + "," +
				financialFiling + "," +
				firstAgeUnitedStatesDriverLicense + "," +
				firstAgeForeignDriverLicense + "," +
				fullTimeStudentWithHighGPA + "," +
				mailingAddressDifferent + "," +
				email + "," +
				phoneNumber + "," +
				completedDriversSafetyCourse + "," +
				havePersonalInjuryLoss + "," +
				haveAccidentOrViolations + "," +
				driversLicense + "," +
				licenseIssueStateName + "," +
				garagingAddress + " ");
		int moreDrivers = additionalDrivers.size();
		for (int i=0; i < moreDrivers; i++) {
			dataString.append("ADDITIONAL DRIVER " + (i+1) + ": " +
					additionalDrivers.get(i).getAdditionalDriverId() + "," +
					additionalDrivers.get(i).getIncidentId() + "," +
					additionalDrivers.get(i).getFirstName() + "," +
					additionalDrivers.get(i).getLastName() + "," +
					additionalDrivers.get(i).getAge() + "," +
					additionalDrivers.get(i).getDateOfBirth() + "," +
					additionalDrivers.get(i).getRelationshipToApplicant() + "," +
					additionalDrivers.get(i).getMaritalStatus() + "," +
					additionalDrivers.get(i).getGender() + "," +
					additionalDrivers.get(i).getOccupation() + "," +
					additionalDrivers.get(i).getOtherOccupation() + "," +
					additionalDrivers.get(i).getLicenseToDriveInUSA() + "," +
					additionalDrivers.get(i).getFirstAgeUnitedStatesDriverLicense() + "," +
					additionalDrivers.get(i).getFirstAgeForeignDriverLicense() + "," +
					additionalDrivers.get(i).isFullTimeStudentWithHighGPA() + "," +
					additionalDrivers.get(i).isCompletedDriversSafetyCourse() + "," +
					additionalDrivers.get(i).getFinancialFiling() + "," +
					additionalDrivers.get(i).isAnyIncident() + "," +
					additionalDrivers.get(i).getDriversLicense() + "," +
					additionalDrivers.get(i).getLicenseIssueStateName() + " ");
		}
		int vehicleCount = vehicles.size();
		for (int i=0; i < vehicleCount; i++) {
			dataString.append("VEHICLE " + (i+1) + ": " +
					vehicles.get(i).getVehicleId() + "," +
					vehicles.get(i).getAdditionalDriverId() + "," +
					vehicles.get(i).getVehicleYear() + "," +
					vehicles.get(i).getVehicleMake() + "," +
					vehicles.get(i).getVehicleModel() + "," +
					vehicles.get(i).getVehicleVIN() + "," +
					vehicles.get(i).getVehicleType() + "," +
					vehicles.get(i).getOwnership() + "," +
					vehicles.get(i).getPurchaseDate() + "," +
					vehicles.get(i).getVehicleUsage() + "," +
					vehicles.get(i).isRidesharing() + "," +
					vehicles.get(i).isParkInResidentAddress() + "," +
					vehicles.get(i).isAlternativeFuels() + "," +
					vehicles.get(i).isPassiveRestraint() + "," +
					vehicles.get(i).isAntiLockBrakes() + "," +
					vehicles.get(i).isTheftRecoverySystem() + "," +
					vehicles.get(i).getLessorStateName() + "," +
					vehicles.get(i).getLessor() + "," +
					vehicles.get(i).getCurrentOdometerReading() + "," +
					vehicles.get(i).getDateOfReading() + " ");
		}
		int incidentCount = incidents.size();
		for (int i=0; i < incidentCount; i++) {
			dataString.append("INCIDENT " + (i+1) + ": " +
					incidents.get(i).getIncidentId() + "," +
					incidents.get(i).getAdditionalDriverId() + "," +
					incidents.get(i).getIncidentType() + "," +
					incidents.get(i).getDescription() + "," +
					incidents.get(i).getDateOccuredOffsetInDays() + "," +
					incidents.get(i).getDateOccured() + "," +
					incidents.get(i).isAnyInjuries() + " ");
		}
		int discountCount = discounts.size();
		for (int i=0; i < discountCount; i++) {
			dataString.append("DISCOUNT " + (i+1) + ": " +
					discounts.get(i).getDiscountId() + "," +
					discounts.get(i).getPaymentMethod() + "," +
					discounts.get(i).getStartDateOfNewPolicy() + "," +
					discounts.get(i).isHomeInsurance() + "," +
					discounts.get(i).isRentersInsurance() + "," +
					discounts.get(i).isCondoInsurance() + "," +
					discounts.get(i).isValueTermLifeInsurance() + "," +
					discounts.get(i).isUmbrellaInsurance() + "," +
					discounts.get(i).isBusinessInsurance() + "," +
					discounts.get(i).getOwnOrRentHome() + "," +
					discounts.get(i).getPaymentMethodForDiscount() + " ");
		}
		return dataString.toString();
	}
}
