package com.farmers.ffq.integration;

import com.farmers.framework.report.Log;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ISuiteResult;
import org.testng.ITestContext;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

/**
 * TestNG {@link ISuiteListener} that posts a <strong>job-level summary</strong>
 * to Rally when a Jenkins-scheduled (or any automated) suite finishes.
 *
 * <h3>What it does</h3>
 * <ol>
 *   <li>Counts total Passed / Failed / Skipped tests across the whole suite.</li>
 *   <li>Builds a self-contained HTML report that includes the counts, the
 *       Jenkins build URL, branch, commit, and environment.</li>
 *   <li>Attaches that HTML as an artifact to the Rally User Story whose ref is
 *       configured via {@code rally.userStoryRef} in {@code properties.json}
 *       (or overridden at runtime with {@code -Drally.userStoryRef=...}).</li>
 *   <li>Optionally updates the User Story's {@code Notes} field with a
 *       one-line build summary.</li>
 * </ol>
 *
 * <h3>Registration – add to test.gradle listeners block</h3>
 * <pre>
 *   listeners &lt;&lt; 'com.farmers.ffq.integration.RallyJobReporter'
 * </pre>
 *
 * <h3>Jenkins pipeline – pass build context</h3>
 * <pre>
 *   ./gradlew test \
 *     -Dsuite=smoke \
 *     -Drally.build="${env.BUILD_NUMBER}" \
 *     -Drally.buildUrl="${env.BUILD_URL}" \
 *     -Drally.jobName="${env.JOB_NAME}" \
 *     -Drally.branch="${env.GIT_BRANCH}" \
 *     -Drally.commit="${env.GIT_COMMIT}" \
 *     -Drally.userStoryRef="https://rally1.rallydev.com/slm/webservice/v2.0/hierarchicalrequirement/YOUR_US_ID"
 * </pre>
 *
 * <p>If {@code rally.userStoryRef} is empty or Rally is disabled, the listener
 * silently skips without affecting the test run.
 */
public class RallyJobReporter implements ISuiteListener {

    private final RallyService rally = RallyService.getInstance();

    @Override
    public void onStart(ISuite suite) {
        // nothing to do before the suite
    }

    @Override
    public void onFinish(ISuite suite) {
        if (!rally.isEnabled()) {
            Log.debug("RallyJobReporter: Rally disabled – skipping job summary.");
            return;
        }

        String userStoryRef = resolveUserStoryRef();
        if (userStoryRef == null) {
            Log.debug("RallyJobReporter: no valid rally.userStoryRef / rally.userStoryId – skipping job summary.");
            return;
        }

        // ── Collect counts ────────────────────────────────────────────────────
        int passed = 0, failed = 0, skipped = 0;
        Map<String, ISuiteResult> results = suite.getResults();
        for (ISuiteResult sr : results.values()) {
            ITestContext ctx = sr.getTestContext();
            passed  += ctx.getPassedTests().size();
            failed  += ctx.getFailedTests().size();
            skipped += ctx.getSkippedTests().size();
        }
        int total = passed + failed + skipped;

        // ── Jenkins context ───────────────────────────────────────────────────
        String buildNumber = sysProp("rally.build",    sysProp("BUILD_NUMBER", ""));
        String buildUrl    = sysProp("rally.buildUrl", sysProp("BUILD_URL",    ""));
        String jobName     = sysProp("rally.jobName",  sysProp("JOB_NAME",     suite.getName()));
        String branch      = sysProp("rally.branch",   sysProp("GIT_BRANCH",   ""));
        String commit      = sysProp("rally.commit",   sysProp("GIT_COMMIT",   ""));
        String environment = rally.getEnvironment();

        String timestamp = ZonedDateTime.now(ZoneOffset.UTC)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss 'UTC'"));

        String verdict     = (failed == 0) ? RallyService.VERDICT_PASS : RallyService.VERDICT_FAIL;
        String noteSummary = buildNoteSummary(jobName, buildNumber, buildUrl, branch,
                                              environment, passed, failed, skipped, total, timestamp);

        byte[] htmlReport  = buildHtmlReport(jobName, buildNumber, buildUrl, branch, commit,
                                             environment, passed, failed, skipped, total,
                                             timestamp, verdict);

        Log.info(String.format("RallyJobReporter: posting job summary to Rally US – "
                + "Pass=%d Fail=%d Skip=%d  US=%s", passed, failed, skipped, userStoryRef));

        rally.postJobSummaryToUserStory(userStoryRef, verdict, noteSummary, htmlReport,
                                        buildNumber, jobName);
    }

    /** Rally SaaS REST API base – same for all standard tenants. */
    private static final String RALLY_API_BASE =
            "https://rally1.rallydev.com/slm/webservice/v2.0";

    /**
     * Resolves the Rally User Story REST URL from the available parameters,
     * in priority order:
     * <ol>
     *   <li>{@code rally.userStoryRef} in properties.json or {@code -Drally.userStoryRef=<full_url>}</li>
     *   <li>{@code -Drally.userStoryId=<id>} – numeric ObjectID or FormattedID (e.g. US1089892)</li>
     *   <li>Jenkins {@code JOB_NAME} looked up in the {@code rally.jobs} map in properties.json.
     *       Values can be a numeric ObjectID (e.g. {@code "123456789"}) or a Rally
     *       FormattedID (e.g. {@code "US1089892"}) — both are resolved automatically.</li>
     * </ol>
     *
     * @return the validated full REST URL, or {@code null} if nothing valid was found.
     */
    private String resolveUserStoryRef() {
        // ── Option 1: full URL (from properties.json or -Drally.userStoryRef=...) ─
        String ref = rally.getUserStoryRef();
        if (ref != null && !ref.trim().isEmpty()) {
            if (isValidUserStoryRef(ref.trim())) return ref.trim();
            Log.debug("RallyJobReporter: rally.userStoryRef has no numeric US ID at the end ("
                    + ref.trim() + ") – treating as not set.");
        }

        // ── Option 2: ID passed via -Drally.userStoryId= ─────────────────────────
        String usId = sysProp("rally.userStoryId", "");
        if (!usId.isEmpty()) {
            return resolveIdToRef(usId, "rally.userStoryId");
        }

        // ── Option 3: auto-lookup Jenkins JOB_NAME in properties.json rally.jobs ─
        // Values can be a numeric ObjectID or a FormattedID (US1089892) — both work.
        String jobName = sysProp("JOB_NAME", "");
        if (!jobName.isEmpty()) {
            String lookedUpValue = lookupJobEntry(jobName);
            if (lookedUpValue != null) {
                String resolved = resolveIdToRef(lookedUpValue, "rally.jobs[" + jobName + "]");
                if (resolved != null) return resolved;
            }
            Log.debug("RallyJobReporter: no valid rally.jobs entry for JOB_NAME='"
                    + jobName + "' – skipping.");
        }

        return null;
    }

    /**
     * Resolves a raw value from the config (either a numeric ObjectID or a
     * Rally FormattedID like {@code "US1089892"}) to a full REST {@code _ref} URL.
     *
     * <ul>
     *   <li>Numeric only (e.g. {@code "123456789"}) → URL built directly.</li>
     *   <li>FormattedID (e.g. {@code "US1089892"}) → queried via Rally API.</li>
     * </ul>
     */
    private String resolveIdToRef(String value, String sourceLabel) {
        String v = value.trim();
        if (v.isEmpty()) return null;

        if (v.matches("\\d+")) {
            // Plain numeric ObjectID — build URL directly
            Log.info("RallyJobReporter: using numeric ObjectID " + v
                    + " from " + sourceLabel);
            return RALLY_API_BASE + "/hierarchicalrequirement/" + v;
        }

        if (v.matches("(?i)US\\d+")) {
            // Rally FormattedID — look up the ObjectID via the API
            Log.info("RallyJobReporter: resolving FormattedID " + v
                    + " from " + sourceLabel + " via Rally API...");
            String usRef = rally.findUserStoryRef(v);
            if (usRef != null) {
                Log.info("RallyJobReporter: " + v + " → " + usRef);
                return usRef;
            }
            Log.error("RallyJobReporter: could not resolve FormattedID " + v
                    + " (check workspace config and Rally access)", false);
            return null;
        }

        Log.debug("RallyJobReporter: value '" + v + "' from " + sourceLabel
                + " is neither a numeric ObjectID nor a US FormattedID – skipping.");
        return null;
    }

    /**
     * Looks up the raw value for a Jenkins job name from the
     * {@code rally.jobs} map in {@code properties.json}.
     *
     * <p>Matching is tried in two passes:
     * <ol>
     *   <li><b>Exact</b> – {@code "FFQ-QA/AceAuto-AutomatedTesting_General_Regression"}</li>
     *   <li><b>Short-name</b> – segment after the last {@code /}</li>
     * </ol>
     *
     * @return the raw string value (ObjectID or FormattedID), or {@code null} if not found.
     */
    private static String lookupJobEntry(String jobName) {
        try {
            File propsFile = new File(System.getProperty("user.dir"), "properties.json");
            if (!propsFile.exists()) return null;

            JsonNode jobs = new ObjectMapper().readTree(propsFile)
                    .path("rally").path("jobs");
            if (jobs.isMissingNode() || !jobs.isObject()) return null;

            String shortName = jobName.contains("/")
                    ? jobName.substring(jobName.lastIndexOf('/') + 1)
                    : jobName;

            // Pass 1 – exact match, Pass 2 – short-name match
            JsonNode node = jobs.get(jobName);
            if (node == null || node.asText("").trim().isEmpty()) node = jobs.get(shortName);

            if (node != null) {
                String val = node.asText("").trim();
                if (!val.isEmpty() && !val.startsWith("_comment")) return val;
            }
        } catch (Exception e) {
            Log.debug("RallyJobReporter: job→US lookup failed – " + e.getMessage());
        }
        return null;
    }

    /**
     * Returns {@code true} when {@code ref} is a non-empty URL whose last path
     * segment is a numeric Rally ObjectID.
     * Rejects URLs that end with {@code /} or have a non-numeric trailing segment,
     * which would happen when a Jenkins parameter is left blank, e.g.:
     * <pre>
     *   https://rally1.rallydev.com/slm/webservice/v2.0/hierarchicalrequirement/
     * </pre>
     */
    private static boolean isValidUserStoryRef(String ref) {
        if (ref == null || ref.isEmpty()) return false;
        // Strip optional trailing slash then grab the last path segment
        String trimmed    = ref.endsWith("/") ? ref.substring(0, ref.length() - 1) : ref;
        int    lastSlash  = trimmed.lastIndexOf('/');
        String lastSegment = (lastSlash >= 0) ? trimmed.substring(lastSlash + 1) : trimmed;
        return lastSegment.matches("\\d+");
    }

    private static String sysProp(String key, String fallback) {
        String v = System.getProperty(key);
        return (v != null && !v.trim().isEmpty()) ? v.trim() : fallback;
    }

    /** One-liner that goes into the Rally US Notes field. */
    private static String buildNoteSummary(String jobName, String buildNumber, String buildUrl,
                                            String branch, String environment,
                                            int passed, int failed, int skipped, int total,
                                            String timestamp) {
        StringBuilder sb = new StringBuilder();
        sb.append("[").append(timestamp).append("] ");
        sb.append("Automated run: ").append(jobName);
        if (!buildNumber.isEmpty()) sb.append(" #").append(buildNumber);
        if (!branch.isEmpty())      sb.append(" | Branch: ").append(branch);
        if (!environment.isEmpty()) sb.append(" | Env: ").append(environment);
        sb.append(" | Results: ").append(passed).append("/").append(total).append(" passed");
        if (failed  > 0) sb.append(", ").append(failed).append(" failed");
        if (skipped > 0) sb.append(", ").append(skipped).append(" skipped");
        if (!buildUrl.isEmpty()) sb.append(" | Build: ").append(buildUrl);
        return sb.toString();
    }

    /** Full self-contained HTML for Rally attachment. */
    private static byte[] buildHtmlReport(String jobName, String buildNumber, String buildUrl,
                                           String branch, String commit, String environment,
                                           int passed, int failed, int skipped, int total,
                                           String timestamp, String verdict) {
        boolean isPass = RallyService.VERDICT_PASS.equals(verdict);
        String badgeColor = isPass ? "#28a745" : "#dc3545";
        String bgColor    = isPass ? "#d4edda"  : "#f8d7da";

        String buildLabel = buildNumber.isEmpty() ? "N/A"
                : (buildUrl.isEmpty() ? "#" + buildNumber
                        : "<a href=\"" + esc(buildUrl) + "\" target=\"_blank\">#" + esc(buildNumber) + "</a>");

        double pct = total > 0 ? (passed * 100.0 / total) : 0;

        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html><html><head><meta charset=\"UTF-8\">")
          .append("<title>Jenkins Automated Run – ").append(esc(jobName)).append("</title>")
          .append("<style>")
          .append("body{font-family:Arial,Helvetica,sans-serif;margin:0;background:#f5f5f5;}")
          .append(".header{background:#1B365D;color:#fff;padding:18px 24px;}")
          .append(".header h1{margin:0;font-size:20px;}")
          .append(".header p{margin:4px 0 0;font-size:13px;opacity:.85;}")
          .append(".badge{display:inline-block;padding:3px 12px;border-radius:4px;")
          .append("font-weight:bold;font-size:14px;background:").append(badgeColor).append(";color:#fff;}")
          .append(".summary{background:").append(bgColor)
          .append(";border-left:5px solid ").append(badgeColor)
          .append(";padding:16px 24px;margin:16px;border-radius:4px;}")
          .append(".grid{display:flex;gap:24px;margin:16px;flex-wrap:wrap;}")
          .append(".card{background:#fff;border:1px solid #dee2e6;border-radius:6px;")
          .append("padding:16px 20px;min-width:130px;text-align:center;}")
          .append(".card .val{font-size:32px;font-weight:bold;margin:4px 0;}")
          .append(".card .lbl{font-size:12px;color:#6c757d;text-transform:uppercase;}")
          .append(".pass .val{color:#28a745;}.fail .val{color:#dc3545;}.skip .val{color:#fd7e14;}.total .val{color:#1B365D;}")
          .append(".meta{background:#fff;border:1px solid #dee2e6;border-radius:6px;")
          .append("margin:0 16px 16px;padding:16px 20px;}")
          .append(".meta table{border-collapse:collapse;width:100%;}")
          .append(".meta td{padding:6px 12px;border-bottom:1px solid #f0f0f0;font-size:13px;}")
          .append(".meta td:first-child{font-weight:bold;color:#495057;width:160px;}")
          .append(".bar-bg{background:#dee2e6;border-radius:4px;height:14px;margin:12px 0;}")
          .append(".bar-fill{background:").append(badgeColor)
          .append(";height:14px;border-radius:4px;transition:width .3s;}")
          .append("</style></head><body>")

          // Header
          .append("<div class=\"header\">")
          .append("<h1>").append(esc(jobName)).append(" &nbsp;<span class=\"badge\">").append(esc(verdict)).append("</span></h1>")
          .append("<p>Automated scheduled run &mdash; ").append(esc(timestamp)).append("</p>")
          .append("</div>")

          // Summary bar
          .append("<div class=\"summary\">")
          .append("<strong>").append(passed).append("/").append(total).append(" tests passed</strong>")
          .append(failed > 0 ? " &nbsp;&bull;&nbsp; <strong style=\"color:#dc3545;\">"+failed+" failed</strong>" : "")
          .append(skipped > 0 ? " &nbsp;&bull;&nbsp; "+skipped+" skipped" : "")
          .append(String.format(" &nbsp;&bull;&nbsp; %.1f%%", pct))
          .append("<div class=\"bar-bg\"><div class=\"bar-fill\" style=\"width:").append(String.format("%.1f", pct)).append("%\"></div></div>")
          .append("</div>")

          // Count cards
          .append("<div class=\"grid\">")
          .append("<div class=\"card total\"><div class=\"lbl\">Total</div><div class=\"val\">").append(total).append("</div></div>")
          .append("<div class=\"card pass\"><div class=\"lbl\">Passed</div><div class=\"val\">").append(passed).append("</div></div>")
          .append("<div class=\"card fail\"><div class=\"lbl\">Failed</div><div class=\"val\">").append(failed).append("</div></div>")
          .append("<div class=\"card skip\"><div class=\"lbl\">Skipped</div><div class=\"val\">").append(skipped).append("</div></div>")
          .append("</div>")

          // Metadata table
          .append("<div class=\"meta\"><table>")
          .append(row("Build",       buildLabel))
          .append(row("Job",         esc(jobName)))
          .append(row("Branch",      esc(branch.isEmpty() ? "N/A" : branch)))
          .append(row("Commit",      esc(commit.isEmpty() ? "N/A" : (commit.length() > 10 ? commit.substring(0, 10) + "..." : commit))))
          .append(row("Environment", esc(environment.isEmpty() ? "N/A" : environment)))
          .append(row("Timestamp",   esc(timestamp)))
          .append("</table></div>")

          .append("</body></html>");

        return sb.toString().getBytes(StandardCharsets.UTF_8);
    }

    private static String row(String label, String value) {
        return "<tr><td>" + label + "</td><td>" + value + "</td></tr>";
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}

