package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
public class BrightVerifyServiceResponse {
    @JsonProperty("ValidateEmailResponseBean")
    private ValidateEmailResponseBean validateEmailResponseBean;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties
    @Data
    public static class ValidateEmailResponseBean {
        private String address;
        private String account;
        private String domain;
        private String status;
    }

}
