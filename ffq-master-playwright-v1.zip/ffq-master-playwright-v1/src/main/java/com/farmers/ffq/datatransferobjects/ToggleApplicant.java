package com.farmers.ffq.datatransferobjects;

import com.farmers.ffq.utils.DateCalculations;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter @Setter
public class ToggleApplicant {
    @JsonProperty("First_Name")
    private String firstName;
    @JsonProperty("Last_Name")
    private String lastName;
    @JsonProperty("DOB")
    private String dob;
    @JsonProperty("Street")
    private String street;
    @JsonProperty("City")
    private String city;
    @JsonProperty("Zip_Code")
    private String zipCode;
    @JsonProperty("LOB")
    private String lob;
    @JsonProperty("Source_Indicator")
    private String sourceIndicator;
    @JsonProperty("SourceID")
    private String sourceId;

//    String value = "{\"City\":\"Tolleson\",\"DOB\":\"1969-12-08 00:00:00.000\",\"First_Name\":\"JOHNATHAN\",\"LOB\":\"AUTO\",\"Last_Name\":\"VEAL\",\"SourceID\":\"TOGREABZFQ\",\"Source_Indicator\":\"TO\",\"Street\":\"3010 South 105th Drive\",\"Zip_Code\":\"85353\"}";

    public ToggleApplicant(ApplicantAceHome applicantAceHome, String lob, boolean newApplicant) {
        this.setFirstName(applicantAceHome.getFirstName());
        this.setLastName(applicantAceHome.getLastName());
        this.setDob(formattedDob(applicantAceHome.getDateOfBirth()));
        this.setStreet(applicantAceHome.getAddress());
        this.setCity(applicantAceHome.getCity());
        this.setZipCode(applicantAceHome.getZipCode());
        if (lob.equals(LOB_HOME)) {
            this.setLob("HOME");
        } else {
            this.setLob("RENT");
        }
        this.setSourceId("TOGREHBZFQ");
        if (newApplicant)
            this.setSourceIndicator("TN");
        else
            this.setSourceIndicator("TO");
    }

    public ToggleApplicant(AutoApplicant applicantAuto, boolean newApplicant) {
        this.setFirstName(applicantAuto.getFirstName());
        this.setLastName(applicantAuto.getLastName());
        this.setDob(formattedDob(applicantAuto.getDateOfBirth()));
        this.setStreet(applicantAuto.getResidentAddress());
        this.setCity(applicantAuto.getCity());
        this.setZipCode(applicantAuto.getZipCode());
        this.setSourceId("TOGREABZFQ");
        this.setLob("AUTO");
        if (newApplicant)
            this.setSourceIndicator("TN");
        else
            this.setSourceIndicator("TO");
    }

    private String formattedDob(String dob) {
        LocalDate localDate = LocalDate.parse(dob, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        LocalDateTime localDateTime = localDate.atStartOfDay();
        return localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
    }
}
