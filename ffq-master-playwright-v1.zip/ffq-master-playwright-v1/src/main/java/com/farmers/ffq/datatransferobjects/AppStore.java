package com.farmers.ffq.datatransferobjects;

import com.farmers.framework.report.Log;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.farmers.ffq.utils.GlobalVariables.COMMA;
import static com.farmers.ffq.utils.GlobalVariables.EMPTY_STRING;

@JsonIgnoreProperties
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class AppStore {

    private Auto auto;
    private VerifyResponse verifyResponse;
    private ControlData controlData;
    private ServiceControlData serviceControlData;
    private Data data;
    @JsonIgnore
    private Discounts discounts;
    private Home home;
    private List<KnockOut> knockouts;
    @JsonIgnore
    private LienHolderData lienHolderData;
    @JsonIgnore
    private List<PaymentUsUrls> paymentUsUrls;
    private PaymentusIframeData paymentusIframeData;
    @JsonIgnore
    private RetrieveDataStatus retrieveDataStatus;

    private StaticContent staticContent;
    private Error error;
    @JsonIgnore
    private String sourceIndicatorFromUrl;
    @JsonIgnore
    private boolean isCS;
    @JsonIgnore
    private int currentStep;
    private UrlParameterObject urlParameterObject;

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class Error {
        private ErrorInfo errorInfo;
        private String message;
        private String serviceName;
        private String status;
        private URLParams urlParams;

    }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class ErrorInfo {
        private String errorCode;
        private String errorMessage;
        private String quoteNumber;
		public String state;
    }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class URLParams {

    }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class Auto{
        private ArrayList<Driver> drivers;
        private List<AppStoreVehicle> vehicles;
        private DriverReview driverReview;
        private VinLookUpResp vinLookUpResp;
        private Dropdowns dropdowns;
        private Quote quote;
        private VerifyResponse verifyResponse;
        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Dropdowns {
            private Quote quote;
            private Driver driver;

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class Quote {

                private List<DropDownResponseBean> dropDownResponseBeans;

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class DropDownResponseBean {

                    private List<DropDownValue> dropDownValues;
                    private String coverageCode;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class DropDownValue {
                        private String value;
                        private String webDesc;
                    }

                }
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class Driver {

                private List<DropDownResponseBean> dropDownResponseBeans;

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class DropDownResponseBean {

                    private List<DropDownValue> dropDownValues;
                    private String fieldName;
                    private String formName;
                    private String status;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class DropDownValue {
                        private String value;
                        private String retiredValue;
                        private String webDesc;
                        private String parentValue;
                    }

                }
            }

        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Driver{

            private ArrayList<Object> incidents;
            private String accidentHistory;

            private int age;
            private String adpfLicenseSequenceNumber;
            private String ageFirstLicencedInUS;
            private String bodilyInjuryLimitCd;
            private String bodilyInjuryLimitName;
            private String carrierCode;
            private String carrierExpDate;
            private String commuteToNYNJ;
            private String currentCarrier;
            private String dateOfBirth;
            private String distantStudent;
            private String drivingExpInMonths;
            private String emailAddress;
            private String ffqOccupationCode;
            private String ffqOccupationDescription;
            private String finFiling;
            private String firstName;
            private String fullTimeStudent;
            private String gender;
            private String lapseInCovdesc;
            private String lapseInCoverage;
            private String lastName;
            private String licNumber;
            private String licStateCd;
            private String licenseFromAdpf;
            private String licenseIssueState;
            private String licenseNumber;
            private String maritalStatus;
            private String maritalStatusDesc;
            private String militaryDeployment;
            private String mostUsedVehicleRef;
            private String nopriorIns;
            private String personalInjury;
            private String phoneNumber;
            private String pni;
            private String principalPIP;
            private String reference;
            private String safetyCourseCompleted;
            private String signalEnrolled;
            private String spouseLicencedToDrive;
            private String spouseLicensed;
            private String spouseRef;
            private String ssn;
            private boolean anySixMonthsContLiabilityInPast;
            private boolean ssnUpdated;
            private boolean isLicenseIssuedInUS;
            private boolean hasDriverLicense;

        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class DriverReview {

            private FetchIncidentCategoryList fetchIncidentCategoryList;

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class FetchIncidentCategoryList {
                private IncidentType incidentTypeACC;
                private IncidentType incidentTypeUCC;

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class IncidentType {
                    private List<Dropdowns.Quote.DropDownResponseBean.DropDownValue> dropDownValues;
                }
            }

        }

        @JsonIgnoreProperties
       // @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class AppStoreVehicle {

            private ArrayList<Object> persInsAutoCoveragebean;
            private LnLrAddr lnLrAddr;
            private PersAutoCoverage persAutoCoverage;
            private String absCdDrv;
            private String absProtected;
            private String absUpdated;
            private String altFuelProtected;
            private String altFuelupdated;
            private String alternativeFuel;
            private String annualMiles;
            private String antiLockBreaks;
            private String antiTheftDevice;
            private String cashValueAmt;
            private String daytimeRunningLamps;
            private String diffGrgInd;
            private String escdValdtnCdDrv;
            private GrgingAddr grgingAddr;
            private String homingDevice;
            private String isVinEntrInQuote;
            private String lnLrCompany;
            private String make;
            private String makeAndModel;
            private String makeDesc;
            private String minHorsePower;
            private String model;
            private String modelDesc;
            private String modelTrimDesc;
            private String noOfDaysUsed;
            private String odometerMileage;
            private String oneWayMiles;
            private String pasiveRstUpdated;
            private String passiveRestrCdDrv;
            private String passiveRestraint;
            private String passiveRstProtected;
            private String primaryDriver;
            private String purchaseDate;
            private String rideShare;
            private String rideShareVeh;
            private boolean showVehicle;
            private String statedValue;
            private String surchargePD;
            private String theftRecovery;
            private String truckGUWCdDrv;
            private String vehcielFuelType;
            private String vehicleIsOn;
            private String vehicleSelected;
            private String vehicleType;
            private String vehicleUsage;
            private String vehicleUsageDesc;
            private String vin = EMPTY_STRING;
            private String year;

            @JsonIgnoreProperties
          //  @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class LnLrAddr{
                private String city;
                private String street;
                private String zipCode;
            }

            @JsonIgnoreProperties
            @lombok.Data
            public static class GrgingAddr{
                private String apartment;
                private String city;
                private String state;
                private String street;
                private String zip;
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class PersAutoCoverage{

                private CustomCoverages customCoverages;
                private String packageSelected;


                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class CustomCoverages{
                    private List<CvgInfo> cvgInfoList;
                    private String netPremium;
                    private String totalPremium;


                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class CvgInfo{
                        private String coverageValue;
                        private String cvgCode;
                        private String cvgDesc;
                        private String displayCode;
                        private String premiumAmt;
                        private String sequenceNo;

                    }
                }

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class EnhancedCoverages{
                    private ArrayList<CvgInfo> cvgInfo;
                    private String netPremium;
                    private String totalPremium;



                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data

                    public static class CvgInfo{
                        private String coverageValue;
                        private String cvgCode;
                        private String cvgDesc;
                        private String displayCode;
                        private String premiumAmt;
                        private String sequenceNo;
                    }

                }

            }
        }

        @JsonIgnoreProperties
        @lombok.Data
        public static class VinLookUpResp{
            private String year;
            private String make;
            private String model;
            private String makeDesc;
            private String modelDesc;
            private String vehicleType;
            private String vin;
            private String vehcielFuelType;
            private String absCdDrv;
            private String passiveRestrCdDrv;
            private String escdValdtnCdDrv;
            private String truckGUWCdDrv;
            private String antiLockBreaks;
            private String absProtected;
            private String passiveRestraint;
            private String alternativeFuel;
            private String altFuelProtected;
            private String passiveRstProtected;
            private String cashValueAmt;
            private String minHorsePower;
            private List<Object> persInsAutoCoveragebeanList;
            private String daytimeRunningLamps;
            private String vehClassCd;
            private String reference;
        }

        @JsonIgnoreProperties
        @lombok.Data
        public static class Quote {
            private String autoBundleSavings;
            private int rateQuoteResponseLength;
            private String paymentMode;
            private MonolineResponse monolineResponse;
            @JsonProperty("EFT")
            private Eft eft;
            @JsonProperty("PIF")
            private Pif pif;
            private boolean isSecondaryRateUpdate;
            private boolean isQuoteCustomized;
            private String totalYearlySaving;
            private boolean showPriceAlternativeLink;
            private List<DnqReason> dnqReasons;

            @JsonIgnoreProperties
            @lombok.Data
            public static class Eft {
                private RateQuoteResponseData rateQuoteResponse;
                private String totalPremiumAmount;
            }
            @JsonIgnoreProperties
            @lombok.Data
            public static class MonolineResponse {
                private RateQuoteResponseData rateQuoteResponse;
                private String totalPremiumAmount;
            }

            @JsonIgnoreProperties
            @lombok.Data
            public static class DnqReason {
                private String code;
                private String description;
            }

            @JsonIgnoreProperties
            @lombok.Data
            public static class Pif {
                private RateQuoteResponseData rateQuoteResponse;
                private String totalPremiumAmount;
            }

            @JsonIgnoreProperties
            @lombok.Data
            public static class RateQuoteResponseData {
                private String quoteNumber;
                private String paymentMode;
                private PersAutoPolicy persAutoPolicy;
                private boolean knockOutInd;
                private boolean brightlinedIndicator;
                private String buyEnableInd;
                private List<Object> knockOutBeanList;
                private List<Object> dnqMessages;
                private List<Object> infoMessages;
                private boolean payPlanChanged;
                private boolean flHouseAccount;
                private boolean isHouseAccount;
                private String coverageAdjustedIndicator;
                private String umbrellaPolicyIndicator;
                private boolean eligibleForChat;
                private boolean validCityZipForMN;
                private boolean eligibleForAutoRentersBundle;
            }

            @JsonIgnoreProperties
            @lombok.Data
            public static class PersAutoPolicy {
                private List<AppStoreVehicle> vehicle;
                private List<Discount> discount;
                private Data.LiabilityCoverage liabilityCoverage;
            }

            @JsonIgnoreProperties
            @lombok.Data
            public static class Discount {
                private String name;
                private String type;
                private String code;
            }
        }

    }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class Home{
        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Field{
                private String address;
                private String addressLine2;
                private String city;
                private String country;
                private String fieldName;
                private Object hoaCoversWallsIn;
                private String inEscrow;
                private String isNewHome;
                private String isPrimaryResidence;
                private String noOfPropertyLosses;
                private String state;
                private boolean status;
                private String zipCode;
                private String yearBuilt;
                private String sqFeet;
                private List<Value> values;
            }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Value {
            private String description;
            private String webDesc;
            private String value;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class FieldValues {
            private String fieldName;
            private List<Value> values;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class GetLocation {
            private String hydrantWithin1000FtInd;
            private String newSplitPpc;
            private String publicProtectionClassification;
            private String quoteNumber;
            private String splitPPCInd;
            private String status;
            private String waterSupplyType;
            private String zipMatchorAddressMatch;
        }

        private AdditionalHome additionalHome;
        private AdditionalInfoHomeDetails additionalInfoHomeDetails;
        private AddlCustomerDetails addlCustomerDetails;
        private AddressForm addressForm;
        private Dropdowns dropdowns;
        private List<Discounts> discounts;
        private String valuationId;
        private String dwellingCoverage;
        private String personalPropertyValue;
        private String reconstructionCost;
        private String updatedReconstructionCost;
        private int personalCalculatorValue;
        private PropertyForm propertyForm;
        private HomeQualityGradeForm homeQualityGradeForm;
        private QualityGradeForm qualityGradeForm;
        private PropertyDetailsForm propertyDetailsForm;
        private GetLocation getLocation;
        private Quote quote;
        private ContactInfo ContactInfo;
        private VerifyResponse verifyResponse;

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class AdditionalHome {
            private String lenderName;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class AddlCustomerDetails{
            private String address;
            private Data.CustomerData.Address addressStoreObject;
            private String addressType;
            private String homeUnit;
            private String occupationCode;
            private String occupationDescription;
            private boolean retiredOccupation;
//            private SpouseData spouseData;
            private Data.CustomerData.Address priorOrCurrentAddress;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class AdditionalInfoHomeDetails{
            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class FortifiedHome{
                private boolean checkboxChecked;
                private boolean radioSelected;
                private String radioValue;
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class BurglarAlarm{
                private boolean checkboxChecked;
                private boolean radioSelected;
                private String radioValue;
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class FireAlarm{
                private boolean checkboxChecked;
                private boolean radioSelected;
                private String radioValue;
            }
            private FortifiedHome fortifiedHome;
            private BurglarAlarm burglarAlarm;
            private FireAlarm fireAlarm;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class AddressForm{
            private List<Field> fields;
            private String formName;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Discounts{
            private String name;
            private String orderNo;
            private boolean showSnackbar;
            private String step;

            @Override
            public boolean equals(Object o) {
                if (this == o) return true;
                if (o == null || getClass() != o.getClass()) return false;
                Discounts d = (Discounts) o;
                return name.contains("&") && d.name.contains("&");
            }

            @Override
            public int hashCode() {
                return 1;
            }
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Dropdowns{
            private Quote quote;

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class Quote {
                private List<CoverageValue> coverageValues;

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class CoverageValue{
                    private String coverageCode;
                    private String coverageDescription;
                    private List<Value> values;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Value{
                        private String sequenceNo;
                        private String amount;
                    }
                }
            }
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class PropertyForm{
            private String formName;
            private List<Field> fields;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        // this form correspond to Quality Grade page
        public static class HomeQualityGradeForm{
            private String formName;
            private List<Field> fields;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        // this form correspond to Dwelling/Custom coverage page
        public static class QualityGradeForm{
            private String formName;
            private List<Field> fields;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class PropertyDetailsForm {
            private static final String COMMA_SPACE = ", ";
            private String formName;
            private List<FieldValues> fields;

            public String getFieldValueByName(String fieldName) {
                String fieldValue = null;
                List<String> bathrooms = new ArrayList<>(List.of("0", "0", "0", "0"));
                for (FieldValues fieldVal : fields) {
                    if (fieldVal.getFieldName().equals(fieldName)) {
                        for (Value fieldVals : fieldVal.getValues()) {
                            if (fieldName.equals("numberOfBathroom")) {
                                switch (fieldVals.getWebDesc()) {
                                    case "Full baths":
                                        bathrooms.set(0, fieldVals.getValue());
                                        break;
                                    case "1/2 baths":
                                        bathrooms.set(1, fieldVals.getValue());
                                        break;
                                    case "3/4 baths":
                                        bathrooms.set(2, fieldVals.getValue());
                                        break;
                                    case "1-1/2 baths":
                                        bathrooms.set(3, fieldVals.getValue());
                                        break;
                                }
                                fieldValue = String.join(COMMA, bathrooms);
                            } else if (fieldName.equals("numberOfStories")) {
                                String noOfStoriesWebDescription = fieldVals.getWebDesc();
                                if (noOfStoriesWebDescription.contains("Attic") || noOfStoriesWebDescription.contains("stories") || noOfStoriesWebDescription.contains("story")) {
                                    int noOfStories = (int) Math.ceil(Double.parseDouble(fieldVals.value));
                                    String noOfStoriesInNumericStringFormat = String.valueOf(noOfStories);
                                    fieldValue = noOfStories > 1 ? noOfStoriesInNumericStringFormat + " stories" : noOfStoriesInNumericStringFormat + " story";
                                } else if (noOfStoriesWebDescription.contains("Split") || noOfStoriesWebDescription.contains("Bi-level")) {
                                    fieldValue = noOfStoriesWebDescription;
                                } else {
                                    fieldValue = fieldVals.value;
                                }

                            } else if (fieldVals.getWebDesc().isBlank() && !fieldName.equals("exteriorWallFinish")) {
                                if (fieldValue == null) {
                                    fieldValue = fieldVals.getValue() + COMMA_SPACE;
                                } else {
                                    fieldValue += fieldVals.getValue() + COMMA_SPACE;
                                }
                            } else if (fieldName.equals("roofReplacedYear")) {
                                List<Value> roofValues = fieldVal.getValues();
                                if (roofValues != null && !roofValues.isEmpty()) {
                                    fieldValue = roofValues.get(0).getValue();
                                } else {
                                    Log.warn("No roofReplacedYear values available for field: " + fieldName);
                                }
                            } else {
                                if (fieldValue == null) {
                                    fieldValue = fieldVals.getWebDesc() + COMMA_SPACE;
                                } else {
                                    fieldValue += fieldVals.getWebDesc() + COMMA_SPACE;
                                }
                            }
                        }
                        if ((fieldValue != null) && (fieldValue.endsWith(COMMA_SPACE))) {
                            fieldValue = fieldValue.substring(0, fieldValue.length() - 2);
                        }
                        break;
                    }
                }
                if (fieldName.equals("floorCoverings")) {
                    switch (Objects.requireNonNull(fieldValue)) {
                        case "CPT":
                            fieldValue = "Carpet";
                            break;
                        case "HW":
                        case "WU":
                            fieldValue = "Hardwood";
                            break;
                    }
                    // remove duplicates, if any
                    List<String> floors = Stream.of(fieldValue.split(COMMA_SPACE)).distinct().collect(Collectors.toList());
                    fieldValue = String.join(COMMA_SPACE, floors);
                }
                return fieldValue;
            }

            public String getNumberOfStoriesValueRounded() {
                String FIELD_NAME = "numberOfStories";
                String fieldValue = null;
                for (FieldValues fieldVal : fields) {
                    if (fieldVal.getFieldName().equals(FIELD_NAME)) {
                        fieldValue = fieldVal.getValues().get(0).getValue();
                        break;
                    }
                }
                String numberOfStories;
                if (fieldValue != null) {
                    numberOfStories = String.valueOf((int) Math.floor(Double.parseDouble(fieldValue)));
                    numberOfStories = Integer.parseInt(numberOfStories) > 1 ? numberOfStories + " stories" : numberOfStories + " story";
                } else {
                    numberOfStories = "0";
                }
                return numberOfStories;
            }
        }

        public GetLocation getLocation() {
            return getLocation;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Quote {
            private String homeBundleSavings;
            private boolean isQuoteCustomized;
            private String quoteNumber;
            private String selectedPackageCode;
            private String selectedPaymentMode;
            private List<RateQuoteResponse> rateQuoteResponses;
            private List<RateQuoteResponse> monolineResponses;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class RateQuoteResponse {
            private String buyEnableInd;
            private List<Object> knockOutBeanList;
            private boolean knockOutInd;
            private String lob;
            private boolean payPlanChanged;
            private String paymentMode;
            private PersHomePolicy persHomePolicy;
            private String quoteNumber;
            private String ratePackage;
            private List<ValidationMessage> validationMessage;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class PersHomePolicy {
            private List<Discount> discount;
            private PersHomeCoverage persHomeCoverage;
            private String quoteNumber;
            private String ratePackage;
            private String validationMessage;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Discount {
            private String code;
            private String name;
            private String type;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class ValidationMessage {
            private String code;
            private String leadDisposition;
            private String message;
            private String sysRule;
            private String targetPage;
            private String title;
            private String uiDesc;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class PersHomeCoverage {
            private String packageSelected;
            private Coverage customCoverages;
            private Coverage standardCoverages;
            private Coverage enhancedCoverages;
            private Coverage premierCoverages;
        }

        public Coverage getCoverageForPackage(String packageCode, String paymentMode) {
            Coverage coverage = null;
            for (int i = 0; i < getQuote().getRateQuoteResponses().size(); i++) {
                RateQuoteResponse rateResponse = getQuote().getRateQuoteResponses().get(i);
                if (rateResponse.getRatePackage().equals(packageCode) && (rateResponse.getPaymentMode() == null || rateResponse.getPaymentMode().equals(paymentMode))){
                    switch (packageCode) {
                        case "S": case "STANDARD":
                            coverage = rateResponse.getPersHomePolicy().getPersHomeCoverage().getStandardCoverages();
                            break;
                        case "E":
                            coverage = rateResponse.getPersHomePolicy().getPersHomeCoverage().getEnhancedCoverages();
                            break;
                        case "P":
                            coverage = rateResponse.getPersHomePolicy().getPersHomeCoverage().getPremierCoverages();
                            break;
                        case "C":
                            coverage = rateResponse.getPersHomePolicy().getPersHomeCoverage().getCustomCoverages();
                            break;
                        default:
                            Log.error("Unknown package code: " + packageCode);
                            break;
                    }
                }
                if (coverage != null) {
                    break;
                }
            }
            return coverage;
        }

        public List<Discount> getDiscountsForPackage(String packageCode, String paymentMode) {
            List<Discount> discounts = new ArrayList<>();
            for (int i = 0; i < getQuote().getRateQuoteResponses().size(); i++) {
                RateQuoteResponse rateResponse = getQuote().getRateQuoteResponses().get(i);
                if (rateResponse.getRatePackage().equals(packageCode) && rateResponse.getPaymentMode().equals(paymentMode)) {
                    discounts = rateResponse.getPersHomePolicy().getDiscount();
                    break;
                }
            }
            return discounts;
        }

        public String getTotalSavingForPackage(String packageCode, String paymentMode) {
            String totalSaving = EMPTY_STRING;
            Coverage coverage = getCoverageForPackage(packageCode, paymentMode);
            if (coverage != null && coverage.getTotalDiscountSavingAmount() != null) {
                totalSaving = coverage.getTotalDiscountSavingAmount();
            }
            return totalSaving;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Coverage {
            private List<CvgInfo> cvgInfo;
            private List<DedInfo> dedInfo;
            private String dwellingCoverage;
            private String reconstructionCost;
            private String totalDiscountSavingAmount;
            private String totalPremium;
            private String yearBuilt;

            public CvgInfo getCvgInfoForCvgDesc(String cvgDesc) {
                CvgInfo cvgInfo = null;
                for (int i = 0; i < this.cvgInfo.size(); i++) {
                    CvgInfo cvgInfo1 = this.getCvgInfo().get(i);
                    if (cvgInfo1.getCvgDesc().equalsIgnoreCase(cvgDesc) && !cvgInfo1.getCvgAmt().equals("N")) {
                        cvgInfo = cvgInfo1;
                        Log.info("Found CvgInfo for cvgDesc: " + cvgDesc);
                        break;
                    }
                }
                // try cvgGroup, if cvgDesc was not found
                if (cvgInfo == null) {
                    for (int i = 0; i < this.cvgInfo.size(); i++) {
                        CvgInfo cvgInfo1 = this.getCvgInfo().get(i);
                        if (cvgInfo1.getCvgGroup().equals(cvgDesc)) {
                            cvgInfo = cvgInfo1;
                            Log.info("Found CvgInfo (CvgGroup) for cvgDesc: " + cvgDesc);
                            break;
                        }
                    }
                }
                return cvgInfo;
            }
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class CvgInfo {
            private Boolean additionalCvg;
            private String cvgAmt;
            private String cvgCode;
            private String cvgDesc;
            private String cvgGroup;
            private String cvgSection;
            private String cvgType;
            private String displayPremium;
            private int orderNo;
            private String premiumAmt;
            private String sequenceNo;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class DedInfo {
            private String amt;
            private String code;
            private String desc;
            private String premiumAmt;
            private String sequenceNo;
            private String type;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class ContactInfo{
            private String policyStartDate;
            private List<String> wildFireOptions;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class VerifyResponse {
            private boolean premiumIncrease;
            private String status;
            private String selectedPayPlan;
            private PolicyFee policyFee;
            private Tax tax;
            private List<ExcludedDriver> additionalDrivers;
            private List<AdditionalTax> additionalTaxes;
            private List<Discount> discounts;
            private List<PaymentSchedule> paymentSchedules;

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class PolicyFee{
                private String amount;
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class Tax{
                private String amount;
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class AdditionalTax{
                private String amount;
                private String type;
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class ExcludedDriver {

                private String age;
                private String firstName;
                private String gender;
                private String lastName;
                private String sequenceNumber;

            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class Discount{
                private String code;
                private String referenceCode;
                private String name;
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class PaymentSchedule{
                private String payPlan;
                private String installmentAmount;
                private boolean isDefault;
                private String numberOfInstallments;
                private AppStore.VerifyResponse.PaymentSchedule.DownPayment downPayment;
                private AppStore.VerifyResponse.PaymentSchedule.AdministrativeCharges administrativeCharges;
                private List<AppStore.VerifyResponse.PaymentSchedule.Installments> installments;
                private String paymentMethod;
                private String payPlanDescription;
                private String payPlanCode;
                private String fullTermPremium;
                private String countyTax;
                private String serviceCharge;
                private String stateTax;
                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class DownPayment{

                    private AppStore.VerifyResponse.PaymentSchedule.DownPayment.Amount amount;
                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Amount{
                        private String amount;
                        private String currency;
                    }
                }

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class AdministrativeCharges{
                    private String currencyAmount;
                    private String currencyCode;
                }

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Installments {
                    private String currencyAmount;
                    private String currencyCode;
                    private String dueDate;
                }
            }

        }

    }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class Data{
        private int age;
        private AgentData agentData;
        private CustomerData customerData;
        private LiabilityCoverage liabilityCoverage;
        private ProjectCodeData projectCodeData;
        private String landingStateCode;
        private String landingStateDescription;
        private String landingZipCode;
        private String lob;
        private String employerName;
        private String quoteNumber;
        private String quoteType;
        private boolean reBrandToBW;
        private String safetyCourseCompleted;
        private String safetyCourseDate;
        private String safetyCourseDateIDoNotKnow;
        private String sourceIndicator;
        private String src;
        private String ssnKey;
        private String tokenInfo;
        private String bundleLob;
        private SubmitCustomerResponse submitCustomerResponse;
        private boolean caAutoHomeBundleIndicator;
        @JsonProperty("isBundleQuote")
        private boolean bundleQuote;
        @JsonProperty("isHomeBundleEligible")
        private boolean homeBundleEligible;

        private List<Auto.Dropdowns.Quote.DropDownResponseBean.DropDownValue> zipTownList;

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class SubmitCustomerResponse {
            private String employerName;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class ProjectCodeData{
            private ProjectCodeDataAuto auto;
            private ProjectCodeDataHome home;

            @lombok.Data
            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            public static class ProjectCodeDataAuto {
                private String effectiveDate;
                private boolean isBWImplemented;
                @JsonProperty("isEGImpl")
                private boolean egImpl;
                @JsonProperty("isLineTypeIntelligencePhoneNumbersImpl")
                private boolean lineTypeIntelligenceImpl;
            }

            @lombok.Data
            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            public static class ProjectCodeDataHome {
                private String effectiveDate;
                @JsonProperty("isHomeBundleImpl")
                private boolean homeBundleImpl;
                @JsonProperty("isBundleVariantOneImpl")
                private boolean homeBundleImplVariantOneImpl;
                @JsonProperty("isBundleVariantTwoImpl")
                private boolean homeBundleImplVariantTwoImpl;
                @JsonProperty("isHomePewcRedirection")
                private boolean homePewcRedirection;
                @JsonProperty("isWildfireMitigationImpl")
                private boolean wildfireMitigationImpl;
                @JsonProperty("isEmergencyMortgageAssistanceImpl")
                private boolean emergencyMortgageAssistanceImpl;
                @JsonProperty("isSuppressQualityGradeImpl")
                private boolean suppressQualityGradePage;
            }
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class AgentData{
                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Address{
                    private String city;
                    private String state;
                    private String street;
                    private String zip;
                }

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Communication{
                    private EmailId emailId;
                    private PhoneNumber phoneNumber;
                    private String agentId;
                    private String assign;
                    private String isBuyEnabled;
                    private String reference;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class PhoneNumber{
                        private String phoneNumber;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class EmailId{
                        private String emailAddress;
                    }
                }
            private String agentType;
            private String agencyType;
            private String firstName;
            private String lastName;
            private Address address;
            private Communication communication;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class CustomerData{
            private Address address;
            private Communication communication;
            private String dateOfBirth;
            private String firstName;
            private String gender;
            private String lastName;

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class Communication{
                private EmailId emailId;
                private PhoneNumber phoneNumber;

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class PhoneNumber{
                    private String areaCode;
                    private String phoneNumber;
                }

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class EmailId{
                    private String emailAddress;
                }

            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class Address{
                private String city;
                private String houseNumber;
                private String new_address;
                private String isStandardized;
                private String state;
                private String userStrtAdd;
                private String street;
                private String streetName;
                private String streetPreDirection;
                private String streetType;
                private String type;
                private String zip;
            }

        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class LiabilityCoverage{
            private CustomCoverages customCoverages;

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class CustomCoverages{
                private List<CvgInfo> cvgInfo;
                private String netPremium;
                private String totalDiscount;
                private String totalPremium;

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class CvgInfo{
                    private String coverageValue;
                    private String cvgCode;
                    private String cvgDesc;
                    private String displayCode;
                    private String premiumAmt;
                    private String sequenceNo;
                }
            }

        }

    }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class ControlData{
        private Boolean bristolWestAccepted;
        private ArrayList<Boolean> lienLesserFlags;
        private ArrayList<Boolean> vinFlags;
        private String assignAgent;
        private String fetchPaymentUsIframeUrls;
        private String iidBehaviorCode;
        private String lastVisitedPage;
        private String packageSelected;
        private String quoteSourceIndicator;
        private String retrieveQuote;
        private String signalDiscountSelected;
        private boolean eaiBrightlineInd;
        private boolean isPrefillCallRequired;
        private boolean primaryDriverBrightLined;
        private int maxAllowedVehicle;
        private boolean fairPlanIndicator;
        private boolean windHailExclusionSelected;
        private String employerName;
        }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class ServiceControlData {

        @JsonProperty("PerformRate")
        private String performRate;

        private String saveAdditionalInfo;

        private String mismatchedDrivers;

        @JsonProperty("PerformVerifyStatus")
        private String performAutoVerify;

        @JsonProperty("performHomeVerifyRate")
        private String performHomeVerify;
    }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class Discounts{
        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class VehiclesPageDiscounts{

            private AlreadyIncludedDiscounts alreadyIncludedDiscounts;
            private ExtraDiscounts extraDiscounts;

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class AlreadyIncludedDiscounts{

            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class ExtraDiscounts{

            }

        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class DriversPageDiscounts{

            private AlreadyIncludedDiscounts alreadyIncludedDiscounts;
            private ExtraDiscounts extraDiscounts;

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class ExtraDiscounts{

            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class AlreadyIncludedDiscounts{

            }

        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class ReviewPageDiscounts{

            private AlreadyIncludedDiscounts alreadyIncludedDiscounts;
            private ExtraDiscounts extraDiscounts;

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class ExtraDiscounts{

            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class AlreadyIncludedDiscounts{

            }

        }
    }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class KnockOut{
        private boolean brightlined;
        private String errorCode;
        private boolean knockOut;
        private String knockOutMsg;

        private String knockoutLeadDisp;
        private String knockoutSysRule;
        private String knockoutCode;
        private String knockoutTitle;
        private String knockoutUIDesc;
    }


    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class LienHolderData{

        private List<String> lnList;
        private List<String> lrList;

    }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class RetrieveDataStatus{
        private boolean isAppStateDataExists;
        private boolean isDriversDataExists;
        private boolean isQuoteDataExists;
        private boolean isVehiclesDataExists;
    }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class StaticContent{
        private Auto auto;
        private Home home;

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Auto{
            private AdditionalDetails additionalDetails;
            private CardPayment cardPayment;
            private ContactInfo contactInfo;
            private DriversReview driversReview;
            private PaymentPage paymentPage;
            private PersonalInfo personalInfo;
            private QuoteCustomization quoteCustomization;
            private QuotePresentment quotePresentment;
            private VehiclesDriversReview vehiclesDriversReview;
            private VehiclesReview vehiclesReview;


            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class PersonalInfo{
                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Summary{

                    private List<Disclaimers> disclaimers;
                    private List<Headers> headers;
                    private List<InfoContents> infoContents;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Headers{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class InfoContents{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Disclaimers{
                        private String name;
                        private String value;
                    }
                }
            }


            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class VehiclesDriversReview{
                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Summary{

                        private List<Disclaimers> disclaimers;
                        private List<Headers> headers;
                        private List<InfoContents> infoContents;

                        @JsonIgnoreProperties
                        @JsonInclude(JsonInclude.Include.NON_NULL)
                        @lombok.Data
                        public static class Headers{
                            private String name;
                            private String value;
                        }

                        @JsonIgnoreProperties
                        @JsonInclude(JsonInclude.Include.NON_NULL)
                        @lombok.Data
                        public static class InfoContents{
                            private String name;
                            private String value;
                        }

                        @JsonIgnoreProperties
                        @JsonInclude(JsonInclude.Include.NON_NULL)
                        @lombok.Data
                        public static class Disclaimers{
                            private String name;
                            private String value;
                        }
                    }

                }


            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class VehiclesReview{
                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Summary{

                    private List<Disclaimers> disclaimers;
                    private List<Headers> headers;
                    private List<InfoContents> infoContents;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Headers{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class InfoContents{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Disclaimers{
                        private String name;
                        private String value;
                    }
                }
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class DriversReview{
                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Summary{

                    private List<Disclaimers> disclaimers;
                    private List<Headers> headers;
                    private List<InfoContents> infoContents;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Headers{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class InfoContents{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Disclaimers{
                        private String name;
                        private String value;
                    }
                }
            }


            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class ContactInfo{
                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Summary{

                    private List<Disclaimers> disclaimers;
                    private List<Headers> headers;
                    private List<InfoContents> infoContents;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Headers{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class InfoContents{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Disclaimers{
                        private String name;
                        private String value;
                    }
                }
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class QuotePresentment{
                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Summary{

                    private List<Disclaimers> disclaimers;
                    private List<Headers> headers;
                    private List<InfoContents> infoContents;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Headers{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class InfoContents{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Disclaimers{
                        private String name;
                        private String value;
                    }
                }
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class QuoteCustomization{

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Summary{

                    private List<Disclaimers> disclaimers;
                    private List<Headers> headers;
                    private List<InfoContents> infoContents;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Headers{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class InfoContents{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Disclaimers{
                        private String name;
                        private String value;
                    }
                }
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class AdditionalDetails{

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Summary{

                    private List<DisclaimerText> disclaimerText;
                    private List<HeaderTitles> disclaimers;
                    private List<InfoContents> infoContents;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class DisclaimerText{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class InfoContents{
                        private String coverage;
                        private String name;
                        private String title;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class HeaderTitles{
                        private String name;
                        private String value;
                    }
                }

            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class PaymentPage{

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Summary{

                    private List<DisclaimerText> disclaimerText;
                    private List<HeaderTitles> disclaimers;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class DisclaimerText{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class HeaderTitles{
                        private String name;
                        private String value;
                    }
                }

            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class CardPayment{
                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Summary{

                    private List<Disclaimers> disclaimers;
                    private List<Headers> headers;
                    private List<InfoContents> infoContents;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Headers{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class InfoContents{
                        private String name;
                        private String value;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Disclaimers{
                        private String name;
                        private String value;
                    }
                }
            }

        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Home{
            private ReviewQuote reviewQuote;

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class ReviewQuote{

                private SpecialLimits specialLimits;
                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class SpecialLimits{
                    private List<Enhanced> enhanced;
                    private List<Premier> premier;
                    private List<Standard> standard;
                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Enhanced{
                        private String name;
                        private String value;
                    }
                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Premier{
                        private String name;
                        private String value;
                    }
                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class Standard{
                        private String name;
                        private String value;
                    }

                }
            }
        }

    }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class VerifyResponse {
        private boolean premiumIncrease;
        private boolean premiumDecrease;
        private String status;
        private String selectedPayPlan;
        private PolicyFee policyFee;
        private Tax tax;
        private List<ExcludedDriver> additionalDrivers;
        private List<AdditionalTax> additionalTaxes;
        private List<Discount> discounts;
        private List<PaymentSchedule> paymentSchedules;

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class PolicyFee{
            private String amount;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Tax{
            private String amount;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class AdditionalTax{
            private String amount;
            private String type;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class ExcludedDriver {

            private String age;
            private String firstName;
            private String gender;
            private String lastName;
            private String sequenceNumber;

        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class Discount{
            private String code;
            private String referenceCode;
            private String name;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class PaymentSchedule{
            private String payPlan;
            private String installmentAmount;
            private boolean isDefault;
            private String numberOfInstallments;
            private DownPayment downPayment;
            private AdministrativeCharges administrativeCharges;
            private List<Installments> installments;
            private String paymentMethod;
            private String payPlanDescription;
            private String payPlanCode;
            private String fullTermPremium;
            private String countyTax;
            private String serviceCharge;
            private String stateTax;

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class DownPayment{

                private Amount amount;
                private List<SpreadFeeAmount> spreadFeeAmount;

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class SpreadFeeAmount {
                    private String currencyAmount;
                    private String currencyCode;
                    private String feeType;
                }
                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Amount{
                    private String amount;
                    private String currency;
                }
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class AdministrativeCharges{
                private String currencyAmount;
                private String currencyCode;
            }

            @JsonIgnoreProperties
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @lombok.Data
            public static class Installments {
                private String currencyAmount;
                private String currencyCode;
                private String dueDate;
            }
        }

    }

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class PaymentUsUrls{
        private String iFrameUrl;
        private String selectPayMethodCode;
        private String selectPayMethodId;
        private String selectPayMethodName;
    }


    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class PaymentusIframeData{
        private String maskedAccountNumber;
    }
    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class UrlParameterObject {
        @JsonProperty("Source_Indicator")
        private String sourceIndicator; // this is source indicator
        private String SRC; // this is source id
        private String DsplayPhn; // phone number
        private String Agent_Name; // agent name
    }
}