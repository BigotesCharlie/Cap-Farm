package com.farmers.ffq.datatransferobjects.hqm;

import static com.farmers.ffq.utils.GlobalVariables.SPACE;

public class AgentInfoHQM {
    private String quoteNumber;
    private Agent agent;

    public String getQuoteNumber() {
        return quoteNumber;
    }

    public AgentInfoHQM() {
    }

    public AgentInfoHQM(Agent agent) {
        this.agent = agent;
    }

    public String getAgentPhoneNumber () {
        String phone =  getAgent().getCommunication().getPhoneNumber().getPhoneNumber();
        return phone.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "$1-$2-$3");
    }

    public String getAgentEmailAddress () {
        if (getAgent().getCommunication().getEmailId() != null) {
            return getAgent().getCommunication().getEmailId().getEmailAddress();
        } else {
            return null;
        }
    }

    public String getAgentFullAddress() {
        return getAgent().getAddress().getStreet() + "\n" + getAgent().getAddress().getCity() + ", "
                + getAgent().getAddress().getState() + SPACE + getAgent().getAddress().getZip();
    }

    public Agent getAgent() {
        return agent;
    }

    public static class Agent {
        private String firstName;
        private String lastName;
        private Address address;
        private Communication communication;
        private String agentId;
        private String agentImageUrl;
        private String reference;
        private String assign;
        private String agentTier;
        private String isBuyEnabled;
        private String leadId;

        public String getFirstName() {
            return firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public Address getAddress() {
            return address;
        }

        public Communication getCommunication() {
            return communication;
        }

        public String getAgentId() {
            return agentId;
        }

        public String getAgentImageUrl() {
            return agentImageUrl;
        }

        public String getReference() {
            return reference;
        }

        public String getAssign() {
            return assign;
        }

        public String getAgentTier() {
            return agentTier;
        }

        public String getIsBuyEnabled() {
            return isBuyEnabled;
        }

        public String getLeadId() {
            return leadId;
        }
    }

    public static class Address {
        private String city;
        private String state;
        private String zip;
        private String street;

        public String getCity() {
            return city;
        }

        public String getState() {
            return state;
        }

        public String getZip() {
            return zip;
        }

        public String getStreet() {
            return street;
        }
    }

    public static class Communication {
        private PhoneNumber phoneNumber;
        private EmailId emailId;

        public PhoneNumber getPhoneNumber() {
            return phoneNumber;
        }

        public EmailId getEmailId() {
            return emailId;
        }
    }

    public static class PhoneNumber {
        private String phoneNumber;

        public String getPhoneNumber() {
            return phoneNumber;
        }
    }

    public static class EmailId {
        private String emailAddress;

        public String getEmailAddress() {
            return emailAddress;
        }
    }

}
