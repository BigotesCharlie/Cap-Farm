package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@JsonIgnoreProperties
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ADPFServiceEnd {
    private DriverPrefillDetails driverPrefillDetails;

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class DriverPrefillDetails {
        private CurrentCarrier currentCarrier;

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class CurrentCarrier {
           private String carrierCompanyName;
           private String carrierCompanyStatus;
           private String policyInceptionDate;
           private String policyExpirationDate;
           private String carrierRatingtNumber;
           private String bILimitPerPerson;
           private String bILimitPerOccurance;
        }
    }
}
