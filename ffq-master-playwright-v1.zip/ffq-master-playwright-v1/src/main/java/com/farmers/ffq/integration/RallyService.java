package com.farmers.ffq.integration;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.farmers.framework.report.Log;
import okhttp3.*;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.File;
import java.io.IOException;
import java.security.cert.X509Certificate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class RallyService {

    public static final String VERDICT_PASS    = "Pass";
    public static final String VERDICT_FAIL    = "Fail";
    public static final String VERDICT_BLOCKED = "Blocked";

    private static final String RALLY_API_BASE = "https://rally1.rallydev.com/slm/webservice/v2.0";
    private static final String DATE_FMT       = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    /**
     * Millisecond timestamp recorded when this class is first loaded.
     * Used as a session boundary in {@link #readLatestAutomationResultsReport()}
     * to guarantee that only reports generated <em>during the current test run</em>
     * are ever attached to a Rally result — preventing stale data from a previous
     * run being posted to the wrong test case.
     */
    private static final long SESSION_START_MS = System.currentTimeMillis();

    private static volatile RallyService instance;

    private final Config       config;
    private final OkHttpClient httpClient;
    private final ObjectMapper mapper;

    private RallyService() {
        this.config     = new Config();
        this.httpClient = buildHttpClient();
        this.mapper     = new ObjectMapper()
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    /** Returns the process-wide singleton, creating it on first call. */
    public static RallyService getInstance() {
        if (instance == null) {
            synchronized (RallyService.class) {
                if (instance == null) instance = new RallyService();
            }
        }
        return instance;
    }

    // ── Public accessors ──────────────────────────────────────────────────────

    public boolean isEnabled()       { return config.isEnabled(); }
    public String  getEnvironment()  { return config.getEnvironment(); }
    public String  getUserStoryRef() { return config.getUserStoryRef(); }
    public String  getWorkspaceRef() { return config.getWorkspaceRef(); }
    public String  getBuild()        { return config.getBuild(); }

    // ── Test-case result posting ──────────────────────────────────────────────

    /**
     * Convenience overload — posts results with no attachments.
     * Called from {@code BasePage.writeTestcaseState()}.
     */
    public void postResults(List<String> ids, String verdict, String notes) {
        postResults(ids, verdict, notes, null, null, null);
    }

    /**
     * Posts Pass / Fail / Blocked results to every Rally test case ID in {@code ids}.
     *
     * @param ids        Rally formatted IDs, e.g. {@code ["TC12345"]}
     * @param verdict    {@link #VERDICT_PASS}, {@link #VERDICT_FAIL}, or {@link #VERDICT_BLOCKED}
     * @param notes      text for the Rally result note
     * @param screenshot PNG bytes to attach (may be {@code null})
     * @param htmlReport self-contained HTML report bytes (may be {@code null})
     */
    public void postResults(List<String> ids, String verdict, String notes,
                            byte[] screenshot, byte[] htmlReport) {
        postResults(ids, verdict, notes, screenshot, htmlReport, null);
    }

    /**
     * Posts Pass / Fail / Blocked results to every Rally test case ID in {@code ids},
     * with an explicit {@code buildLabel} shown in the Rally Build field.
     *
     * @param buildLabel text for the Rally Build field (e.g. the test method name);
     *                   falls back to {@code rally.build} from properties.json when {@code null}
     */
    public void postResults(List<String> ids, String verdict, String notes,
                            byte[] screenshot, byte[] htmlReport, String buildLabel) {
        for (String id : ids) {
            postResult(id, verdict, notes, screenshot, htmlReport, buildLabel);
        }
    }

    /** Posts a result for a single test case formatted ID (no build label override). */
    public void postResult(String testCaseId, String verdict, String notes,
                           byte[] screenshot, byte[] htmlReport) {
        postResult(testCaseId, verdict, notes, screenshot, htmlReport, null);
    }

    /**
     * Posts a result for a single test case formatted ID.
     *
     * <p><b>Attachment strategy (no-mix guarantee):</b>
     * <ol>
     *   <li>If {@code htmlReport} is non-null it is a <em>per-test</em> compact HTML
     *       built from ThreadLocal data — use it directly (test-specific, no race).</li>
     *   <li>Otherwise fall back to the shared ExtentReports {@code index.html}, but
     *       only if that file was written during <em>this JVM session</em>
     *       ({@link #SESSION_START_MS} guard) so a previous run's report is never
     *       accidentally attached.</li>
     * </ol>
     *
     * <p><b>Attachment note:</b> the HTML report is attached to the
     * <em>TestCase</em> (an Artifact), not the TestCaseResult.  Rally's
     * Attachment API only accepts Artifacts as the parent object; attaching
     * to a TestCaseResult is silently rejected by the API.
     *
     * @param buildLabel overrides {@code rally.build}; pass the test method name
     *                   to show it in the Rally Build field instead of "N/A"
     */
    public void postResult(String testCaseId, String verdict, String notes,
                           byte[] screenshot, byte[] htmlReport, String buildLabel) {
        if (!isEnabled()) return;
        try {
            String tcRef = findTestCaseRef(testCaseId);
            if (tcRef == null) {
                Log.error("RallyService: test case not found in Rally – " + testCaseId, false);
                return;
            }
            // Build the TestCaseResult with Notes = environment/quote text + screenshot inline
            String resultRef = createTestCaseResult(tcRef, verdict, notes, buildLabel, screenshot);
            if (resultRef == null) {
                Log.error("RallyService: failed to create TestCaseResult for " + testCaseId, false);
                return;
            }

            // ── Attach the HTML report ────────────────────────────────────────
            // Priority 1: per-test compact HTML passed by the caller (ThreadLocal,
            //             fully test-specific, immune to parallel-run mixing).
            // Priority 2: full ExtentReports suite HTML — only used as a fallback
            //             when no per-test HTML is available AND the file was
            //             produced during this JVM session (SESSION_START_MS guard).
            byte[]  reportBytes    = null;
            String  attachmentName = null;

            if (htmlReport != null && htmlReport.length > 0) {
                reportBytes    = htmlReport;
                attachmentName = testCaseId + "_result.html";
                Log.info("RallyService: using per-test compact HTML ("
                        + reportBytes.length + " bytes) for " + testCaseId);
            } else {
                byte[] extentReport = readLatestAutomationResultsReport();
                if (extentReport != null) {
                    reportBytes    = extentReport;
                    attachmentName = testCaseId + "_full_report.html";
                    Log.info("RallyService: using current-session ExtentReports HTML ("
                            + reportBytes.length + " bytes) for " + testCaseId);
                }
            }

            if (reportBytes != null) {
                boolean ok = attachToTestCaseResult(resultRef, reportBytes, attachmentName);
                if (!ok) {
                    Log.info("RallyService: TestCaseResult attachment rejected – "
                            + "falling back to TestCase for " + testCaseId);
                    attachBytesTo(tcRef, reportBytes, attachmentName);
                }
            } else {
                Log.info("RallyService: no HTML report available to attach for " + testCaseId);
            }
        } catch (Exception e) {
            Log.error("RallyService: postResult failed for " + testCaseId
                    + " – " + e.getMessage(), false);
        }
    }

    /**
     * Posts a job-level summary to the Rally <strong>User Story</strong>
     * referenced by {@code userStoryRef}.
     *
     * <ol>
     *   <li>Prepends {@code noteSummary} to the US {@code Notes} field.</li>
     *   <li>Attaches {@code htmlReport} as a self-contained HTML artifact.</li>
     * </ol>
     *
     * <p>Called from {@link RallyJobReporter#onFinish} after the suite completes.
     */
    public void postJobSummaryToUserStory(String userStoryRef, String verdict,
                                          String noteSummary, byte[] htmlReport,
                                          String buildNumber, String jobName) {
        if (!isEnabled()) return;
        if (userStoryRef == null || userStoryRef.trim().isEmpty()) return;

        // Guard: last path segment must be a numeric Rally ObjectID
        String trimmedRef  = userStoryRef.trim().replaceAll("/$", "");
        String lastSegment = trimmedRef.substring(trimmedRef.lastIndexOf('/') + 1);
        if (!lastSegment.matches("\\d+")) {
            Log.error("RallyService: userStoryRef has no numeric ID at the end – skipping. ref="
                    + userStoryRef, false);
            return;
        }

        try {
            appendUserStoryNotes(trimmedRef, noteSummary);
        } catch (Exception e) {
            Log.error("RallyService: failed to update US notes – " + e.getMessage(), false);
        }

        // ── Attach HTML report to the User Story ─────────────────────────────
        // Prefer the full ExtentReports HTML from tmp/automation-results/.
        // Falls back to the custom job-summary HTML when ExtentReports is not
        // available or its attachment fails, so the US always receives a file.
        try {
            String safe      = (jobName == null || jobName.isEmpty()) ? "job"
                    : jobName.replaceAll("[^a-zA-Z0-9_\\-]", "_");
            String buildSufx = (buildNumber == null || buildNumber.isEmpty()) ? ""
                    : "_build-" + buildNumber;
            String fileName  = safe + buildSufx + ".html";

            boolean attached = false;

            // Try ExtentReports first (single check – no sleep to avoid JVM shutdown race)
            byte[] extentReport = readLatestAutomationResultsReport();
            if (extentReport != null) {
                Log.info("RallyService: attaching ExtentReports HTML ("
                        + extentReport.length + " bytes) to US as '" + fileName + "'");
                attached = attachBytesTo(trimmedRef, extentReport, fileName);
                if (!attached) {
                    Log.info("RallyService: ExtentReports attachment failed"
                            + " – falling back to job-summary HTML");
                }
            }

            // Fallback: always-available custom job-summary HTML
            if (!attached && htmlReport != null && htmlReport.length > 0) {
                Log.info("RallyService: attaching job-summary HTML ("
                        + htmlReport.length + " bytes) to US as '" + fileName + "'");
                attached = attachBytesTo(trimmedRef, htmlReport, fileName);
            }

            if (!attached) {
                Log.error("RallyService: all attachment attempts failed for US "
                        + trimmedRef, false);
            }
        } catch (Exception e) {
            Log.error("RallyService: failed to attach HTML report to US – "
                    + e.getMessage(), false);
        }
    }


    /**
     * Looks up a User Story by FormattedID (e.g. {@code "US1089892"}) and returns
     * its full REST {@code _ref} URL, or {@code null} if not found.
     *
     * <p>Use this when {@code rally.jobs} entries are stored as FormattedIDs rather
     * than numeric ObjectIDs — both formats are now supported.
     */
    public String findUserStoryRef(String formattedId) {
        try {
            String url = RALLY_API_BASE + "/hierarchicalrequirement"
                    + "?query=(FormattedID%20%3D%20%22" + formattedId + "%22)"
                    + "&fetch=_ref,FormattedID"
                    + "&workspace=" + config.getWorkspaceRef();
            Request req = new Request.Builder()
                    .url(url)
                    .header("ZSESSIONID", config.getApiKey())
                    .header("Accept", "application/json")
                    .get().build();
            try (Response resp = httpClient.newCall(req).execute()) {
                if (!resp.isSuccessful() || resp.body() == null) return null;
                JsonNode items = mapper.readTree(resp.body().string())
                        .path("QueryResult").path("Results");
                if (items.isEmpty()) {
                    Log.debug("RallyService: User Story not found for FormattedID – " + formattedId);
                    return null;
                }
                String ref = items.get(0).path("_ref").asText(null);
                Log.debug("RallyService: resolved " + formattedId + " → " + ref);
                return ref;
            }
        } catch (Exception e) {
            Log.error("RallyService: findUserStoryRef failed for " + formattedId
                    + " – " + e.getMessage(), false);
            return null;
        }
    }

    /**
     * Fetches the full details of a Rally test case (name, description, method,
     * priority, and all test steps) by its formatted ID (e.g. {@code "TC2176453"}).
     *
     * <p>Used by {@link RallyTestScaffolder} to generate test method skeletons.
     *
     * @param formattedId Rally formatted ID, e.g. {@code "TC2176453"}
     * @return populated {@link RallyTestCaseInfo}, or {@code null} if not found
     */
    public RallyTestCaseInfo getTestCaseDetails(String formattedId) {
        try {
            String url = RALLY_API_BASE + "/testcase"
                    + "?query=(FormattedID%20%3D%20%22" + formattedId + "%22)"
                    + "&fetch=FormattedID,Name,Description,Method,Priority"
                    + "&workspace=" + config.getWorkspaceRef();
            Request req = new Request.Builder()
                    .url(url)
                    .header("ZSESSIONID", config.getApiKey())
                    .header("Accept", "application/json")
                    .get().build();
            try (Response resp = httpClient.newCall(req).execute()) {
                if (!resp.isSuccessful() || resp.body() == null) return null;
                JsonNode results = mapper.readTree(resp.body().string())
                        .path("QueryResult").path("Results");
                if (results.isEmpty()) return null;

                JsonNode tc    = results.get(0);
                String name    = tc.path("Name").asText("");
                String desc    = tc.path("Description").asText("");
                String method  = tc.path("Method").asText("");
                String priority= tc.path("Priority").asText("");

                java.util.List<RallyTestCaseInfo.TestStep> steps = fetchTestSteps(formattedId);
                return new RallyTestCaseInfo(formattedId, name, desc, method, priority, steps);
            }
        } catch (Exception e) {
            Log.error("RallyService: getTestCaseDetails failed for " + formattedId
                    + " – " + e.getMessage(), false);
            return null;
        }
    }

    /** Fetches ordered test steps for a given TC formatted ID. */
    private java.util.List<RallyTestCaseInfo.TestStep> fetchTestSteps(String formattedId) {
        java.util.List<RallyTestCaseInfo.TestStep> steps = new java.util.ArrayList<>();
        try {
            String url = RALLY_API_BASE + "/testcasestep"
                    + "?query=(TestCase.FormattedID%20%3D%20%22" + formattedId + "%22)"
                    + "&fetch=StepIndex,Input,ExpectedResult"
                    + "&order=StepIndex"
                    + "&workspace=" + config.getWorkspaceRef();
            Request req = new Request.Builder()
                    .url(url)
                    .header("ZSESSIONID", config.getApiKey())
                    .header("Accept", "application/json")
                    .get().build();
            try (Response resp = httpClient.newCall(req).execute()) {
                if (!resp.isSuccessful() || resp.body() == null) return steps;
                JsonNode items = mapper.readTree(resp.body().string())
                        .path("QueryResult").path("Results");
                for (JsonNode step : items) {
                    int    idx      = step.path("StepIndex").asInt(steps.size() + 1);
                    String input    = step.path("Input").asText("");
                    String expected = step.path("ExpectedResult").asText("");
                    steps.add(new RallyTestCaseInfo.TestStep(idx, input, expected));
                }
            }
        } catch (Exception e) {
            Log.debug("RallyService: fetchTestSteps failed for " + formattedId
                    + " – " + e.getMessage());
        }
        return steps;
    }

    /** Queries Rally for a test case by formatted ID and returns its {@code _ref} URL. */
    private String findTestCaseRef(String formattedId) throws IOException {
        String url = RALLY_API_BASE + "/testcase"
                + "?query=(FormattedID%20%3D%20%22" + formattedId + "%22)"
                + "&fetch=_ref,FormattedID"
                + "&workspace=" + config.getWorkspaceRef();
        Request req = new Request.Builder()
                .url(url)
                .header("ZSESSIONID", config.getApiKey())
                .header("Accept", "application/json")
                .get().build();
        try (Response resp = httpClient.newCall(req).execute()) {
            if (!resp.isSuccessful() || resp.body() == null) return null;
            JsonNode items = mapper.readTree(resp.body().string())
                    .path("QueryResult").path("Results");
            return (items.size() == 0) ? null : items.get(0).path("_ref").asText(null);
        }
    }

    /** Creates a {@code TestCaseResult} in Rally and returns its {@code _ref}.
     *
     * <p>The {@code Notes} field contains plain text showing Environment and
     * Quote Number prominently, followed by the full notes string.
     * The screenshot is NOT embedded here — it is included in the HTML report
     * attachment instead.
     */
    private String createTestCaseResult(String tcRef, String verdict, String notes,
                                        String buildLabel, byte[] screenshot) throws IOException {
        String date = ZonedDateTime.now(ZoneOffset.UTC)
                .format(DateTimeFormatter.ofPattern(DATE_FMT));

        String build = (buildLabel != null && !buildLabel.isEmpty()) ? buildLabel
                : (config.getBuild().isEmpty() ? "N/A" : config.getBuild());

        // ── Build text Notes with Environment and Quote Number highlighted ────
        String badgeColor = VERDICT_PASS.equals(verdict)    ? "#28a745"
                          : VERDICT_FAIL.equals(verdict)    ? "#dc3545"
                          : VERDICT_BLOCKED.equals(verdict) ? "#fd7e14"
                          : "#6c757d";

        StringBuilder notesHtml = new StringBuilder();
        notesHtml.append("<div style='font-family:Arial,Helvetica,sans-serif;")
                 .append("font-size:12px;padding:8px 10px;background:#f8f9fa;")
                 .append("border-left:4px solid ").append(badgeColor).append(";")
                 .append("margin-bottom:6px;border-radius:2px;'>");

        // Highlight Env and Quote as labelled fields on the first line
        if (notes != null && !notes.isEmpty()) {
            for (String part : notes.split("\\|")) {
                String trimmed = part.trim();
                if (trimmed.startsWith("Env:") || trimmed.startsWith("Quote:")) {
                    notesHtml.append("<span style='font-weight:bold;'>")
                             .append(escapeHtml(trimmed.split(":")[0].trim()))
                             .append(":</span>&nbsp;")
                             .append(escapeHtml(trimmed.substring(trimmed.indexOf(':') + 1).trim()))
                             .append("&nbsp;&nbsp;&nbsp;");
                }
            }
        }
        // Build detail line: strip Env: and Quote: segments already shown in the header above
        String detailNotes = "";
        if (notes != null && !notes.isEmpty()) {
            StringBuilder detail = new StringBuilder();
            for (String part : notes.split("\\|")) {
                String trimmed = part.trim();
                if (!trimmed.startsWith("Env:") && !trimmed.startsWith("Quote:")) {
                    if (detail.length() > 0) detail.append(" | ");
                    detail.append(trimmed);
                }
            }
            detailNotes = detail.toString();
        }
        notesHtml.append("<br/><span style='color:#555;font-size:11px;'>")
                 .append(escapeHtml(detailNotes))
                 .append("</span></div>");


        ObjectNode tcResult = mapper.createObjectNode();
        tcResult.put("Verdict", verdict);
        tcResult.put("Date",    date);
        tcResult.put("Build",   build);
        tcResult.put("Notes",   notesHtml.toString());
        tcResult.putObject("TestCase").put("_ref", tcRef);
        if (!config.getWorkspaceRef().isEmpty())
            tcResult.putObject("Workspace").put("_ref", config.getWorkspaceRef());

        ObjectNode payload = mapper.createObjectNode();
        payload.set("TestCaseResult", tcResult);

        RequestBody body = RequestBody.create(
                mapper.writeValueAsString(payload),
                MediaType.parse("application/json; charset=utf-8"));
        Request req = new Request.Builder()
                .url(RALLY_API_BASE + "/testcaseresult/create")
                .header("ZSESSIONID", config.getApiKey())
                .header("Accept", "application/json")
                .post(body).build();
        try (Response resp = httpClient.newCall(req).execute()) {
            String respBody = resp.body() != null ? resp.body().string() : "<empty>";
            if (!resp.isSuccessful()) {
                Log.error("RallyService: createTestCaseResult HTTP "
                        + resp.code() + " | " + respBody, false);
                return null;
            }
            JsonNode ref = mapper.readTree(respBody)
                    .path("CreateResult").path("Object").path("_ref");
            return ref.isMissingNode() ? null : ref.asText(null);
        }
    }

    /**
     * Prepends {@code note} to the current {@code Notes} field of a Rally
     * User Story via a REST update call.
     */
    private void appendUserStoryNotes(String userStoryRef, String note) throws IOException {
        String currentNotes = "";
        try {
            Request getReq = new Request.Builder()
                    .url(userStoryRef + "?fetch=Notes")
                    .header("ZSESSIONID", config.getApiKey())
                    .header("Accept", "application/json")
                    .get().build();
            try (Response getResp = httpClient.newCall(getReq).execute()) {
                if (getResp.isSuccessful() && getResp.body() != null) {
                    JsonNode notesNode = mapper.readTree(getResp.body().string())
                            .path("HierarchicalRequirement").path("Notes");
                    if (!notesNode.isMissingNode()) currentNotes = notesNode.asText("");
                }
            }
        } catch (Exception e) {
            Log.debug("RallyService: could not fetch existing US Notes – " + e.getMessage());
        }

        String updatedNotes = "<p>" + escapeHtml(note) + "</p>"
                + (currentNotes.isEmpty() ? "" : "\n" + currentNotes);

        ObjectNode us      = mapper.createObjectNode();
        ObjectNode payload = mapper.createObjectNode();
        us.put("Notes", updatedNotes);
        payload.set("HierarchicalRequirement", us);

        RequestBody body = RequestBody.create(
                mapper.writeValueAsString(payload),
                MediaType.parse("application/json; charset=utf-8"));
        Request req = new Request.Builder()
                .url(userStoryRef)
                .header("ZSESSIONID", config.getApiKey())
                .header("Accept", "application/json")
                .put(body).build();
        try (Response resp = httpClient.newCall(req).execute()) {
            if (resp.isSuccessful()) {
                Log.info("RallyService: US Notes updated successfully.");
            } else {
                Log.debug("RallyService: Notes update returned HTTP " + resp.code());
            }
        }
    }

    /**
     * Convenience overload — attaches to an Artifact parent (TestCase, UserStory, etc.)
     * using the standard {@code "Artifact"} field.
     */
    private boolean attachBytesTo(String artifactRef, byte[] data, String fileName)
            throws IOException {
        return attachBytesTo(artifactRef, "Artifact", data, fileName);
    }

    /**
     * Attaches {@code data} to a Rally TestCaseResult by using the
     * {@code "TestCaseResult"} parent field (TestCaseResult is not an Artifact
     * subtype, so the standard {@code "Artifact"} field is silently rejected).
     */
    private boolean attachToTestCaseResult(String resultRef, byte[] data, String fileName)
            throws IOException {
        return attachBytesTo(resultRef, "TestCaseResult", data, fileName);
    }

    /**
     * Two-step Rally attachment upload:
     * <ol>
     *   <li>POST {@code /attachmentcontent} with base64-encoded bytes.</li>
     *   <li>POST {@code /attachment} linking content to {@code parentRef} via
     *       {@code parentField} (e.g. {@code "Artifact"} or {@code "TestCaseResult"}).</li>
     * </ol>
     */
    private boolean attachBytesTo(String parentRef, String parentField, byte[] data, String fileName)
            throws IOException {
        if (data == null || data.length == 0) return false;
        String contentType = fileName.endsWith(".html") ? "text/html" : "image/png";
        Log.info("RallyService: uploading attachment '" + fileName
                + "' (" + data.length + " bytes) → " + parentField + " " + parentRef);

        // Step 1 – upload raw bytes
        ObjectNode contentObj = mapper.createObjectNode();
        contentObj.put("Content", Base64.getEncoder().encodeToString(data));
        ObjectNode contentPayload = mapper.createObjectNode();
        contentPayload.set("AttachmentContent", contentObj);

        RequestBody contentBody = RequestBody.create(
                mapper.writeValueAsString(contentPayload),
                MediaType.parse("application/json; charset=utf-8"));
        Request contentReq = new Request.Builder()
                .url(RALLY_API_BASE + "/attachmentcontent/create")
                .header("ZSESSIONID", config.getApiKey())
                .header("Accept", "application/json")
                .post(contentBody).build();

        String contentRef;
        try (Response contentResp = httpClient.newCall(contentReq).execute()) {
            String body1 = contentResp.body() != null ? contentResp.body().string() : "<empty>";
            if (!contentResp.isSuccessful()) {
                Log.error("RallyService: attachmentcontent/create failed HTTP "
                        + contentResp.code() + " | " + body1, false);
                return false;
            }
            JsonNode ref = mapper.readTree(body1)
                    .path("CreateResult").path("Object").path("_ref");
            if (ref.isMissingNode()) {
                Log.error("RallyService: attachmentcontent/create response missing _ref | "
                        + body1, false);
                return false;
            }
            contentRef = ref.asText();
            Log.info("RallyService: attachment content uploaded → " + contentRef);
        }

        // Step 2 – create the Attachment record
        ObjectNode attachObj = mapper.createObjectNode();
        attachObj.put("Name",        fileName);
        attachObj.put("ContentType", contentType);
        attachObj.put("Size",        data.length);
        attachObj.putObject("Content").put("_ref", contentRef);
        attachObj.putObject(parentField).put("_ref", parentRef);
        if (!config.getWorkspaceRef().isEmpty())
            attachObj.putObject("Workspace").put("_ref", config.getWorkspaceRef());

        ObjectNode attachPayload = mapper.createObjectNode();
        attachPayload.set("Attachment", attachObj);

        RequestBody attachBody = RequestBody.create(
                mapper.writeValueAsString(attachPayload),
                MediaType.parse("application/json; charset=utf-8"));
        Request attachReq = new Request.Builder()
                .url(RALLY_API_BASE + "/attachment/create")
                .header("ZSESSIONID", config.getApiKey())
                .header("Accept", "application/json")
                .post(attachBody).build();
        try (Response attachResp = httpClient.newCall(attachReq).execute()) {
            String body2 = attachResp.body() != null ? attachResp.body().string() : "<empty>";
            if (attachResp.isSuccessful()) {
                Log.info("RallyService: attached '" + fileName + "' to " + parentField + " " + parentRef);
                return true;
            } else {
                Log.error("RallyService: attachment/create failed HTTP "
                        + attachResp.code() + " | " + body2, false);
            }
        }
        return false;
    }

    /**
     * Looks for the most recently written {@code index.html} inside
     * {@code tmp/automation-results/<run-dir>/} and returns its bytes.
     *
     * <p><b>Session-isolation guarantee:</b> only subdirectories whose
     * {@code index.html} was last modified <em>at or after</em>
     * {@link #SESSION_START_MS} are considered.  This prevents a previous
     * run's report from being attached when the current run's ExtentReports
     * file has not been written yet (early tests in a suite).
     *
     * <p>Sorting is done on the {@code index.html} file's own
     * {@code lastModified} timestamp — not the parent directory's — because
     * most operating systems do <em>not</em> propagate a child file write
     * back to the parent directory's modification time.
     *
     * @return report bytes, or {@code null} if no current-session report is found
     */
    private byte[] readLatestAutomationResultsReport() {
        try {
            File archiveDir = new File(System.getProperty("user.dir"), "tmp/automation-results");
            if (!archiveDir.exists()) {
                Log.info("RallyService: tmp/automation-results not found at "
                        + archiveDir.getAbsolutePath());
                return null;
            }

            // Only accept index.html files written during this JVM session.
            File[] subdirs = archiveDir.listFiles(f -> {
                if (!f.isDirectory()) return false;
                File indexHtml = new File(f, "index.html");
                return indexHtml.exists() && indexHtml.lastModified() >= SESSION_START_MS;
            });

            if (subdirs == null || subdirs.length == 0) {
                Log.info("RallyService: no current-session automation-results found "
                        + "(SESSION_START_MS=" + SESSION_START_MS + ")");
                return null;
            }

            // Pick the directory whose index.html was most recently written.
            File latest = java.util.Arrays.stream(subdirs)
                    .max(java.util.Comparator.comparingLong(
                            f -> new File(f, "index.html").lastModified()))
                    .orElse(null);
            if (latest == null) return null;

            File report = new File(latest, "index.html");
            if (report.length() == 0) {
                Log.info("RallyService: index.html in " + latest.getName() + " is empty – skipping");
                return null;
            }
            Log.info("RallyService: found current-session ExtentReports → "
                    + report.getAbsolutePath() + " (" + report.length() + " bytes)");
            return java.nio.file.Files.readAllBytes(report.toPath());
        } catch (Exception e) {
            Log.debug("RallyService: could not read automation-results – " + e.getMessage());
            return null;
        }
    }

    private static String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    /** Builds an {@link OkHttpClient} with a permissive SSL trust manager. */
    private static OkHttpClient buildHttpClient() {
        try {
            X509TrustManager trustAll = new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] c, String a) {}
                public void checkServerTrusted(X509Certificate[] c, String a) {}
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
            };
            SSLContext sslCtx = SSLContext.getInstance("TLS");
            sslCtx.init(null, new TrustManager[]{trustAll}, null);
            return new OkHttpClient.Builder()
                    .sslSocketFactory(sslCtx.getSocketFactory(), trustAll)
                    .hostnameVerifier((h, s) -> true)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(60,  TimeUnit.SECONDS)
                    .writeTimeout(60, TimeUnit.SECONDS)
                    .build();
        } catch (Exception e) {
            Log.debug("RallyService: SSL setup failed, using default client – " + e.getMessage());
            return new OkHttpClient.Builder()
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(60,  TimeUnit.SECONDS)
                    .build();
        }
    }

    // ── Configuration ─────────────────────────────────────────────────────────

    /**
     * Reads the {@code rally} section of {@code properties.json} at startup.
     * Every field can be overridden via a matching {@code -Drally.fieldName=} system property.
     */
    private static final class Config {

        private final boolean enabled;
        private final String  apiKey;
        private final String  workspaceRef;
        private final String  projectRef;
        private final String  build;
        private final String  environment;
        private final String  userStoryRef;

        Config() {
            boolean en = false;
            String ak = "", ws = "", pr = "", bld = "", env = "", usr = "";
            try {
                File propsFile = new File(System.getProperty("user.dir"), "properties.json");
                if (propsFile.exists()) {
                    JsonNode rally = new ObjectMapper()
                            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                            .readTree(propsFile).path("rally");
                    en  = Boolean.parseBoolean(
                            sysProp("rally.enabled",    rally.path("enabled").asText("false")));
                    ak  = sysProp("rally.apiKey",       rally.path("apiKey").asText(""));
                    ws  = sysProp("rally.workspaceRef", rally.path("workspaceRef").asText(""));
                    pr  = sysProp("rally.projectRef",   rally.path("projectRef").asText(""));
                    bld = sysProp("rally.build",        rally.path("build").asText(""));
                    env = sysProp("rally.environment",
                            System.getProperty("environment",
                                    rally.path("environment").asText("")));
                    usr = sysProp("rally.userStoryRef", rally.path("userStoryRef").asText(""));
                }
            } catch (Exception e) {
                Log.debug("RallyService.Config: failed to read properties.json – "
                        + e.getMessage());
            }
            this.enabled      = en;
            this.apiKey       = ak;
            this.workspaceRef = ws;
            this.projectRef   = pr;
            this.build        = bld;
            this.environment  = env;
            this.userStoryRef = usr;
        }

        private static String sysProp(String key, String fallback) {
            String val = System.getProperty(key);
            return (val != null && !val.isEmpty()) ? val : fallback;
        }

        boolean isEnabled()       { return enabled; }
        String  getApiKey()       { return apiKey; }
        String  getWorkspaceRef() { return workspaceRef; }
        String  getProjectRef()   { return projectRef; }
        String  getBuild()        { return build; }
        String  getEnvironment()  { return environment; }
        String  getUserStoryRef() { return userStoryRef; }
    }
}
