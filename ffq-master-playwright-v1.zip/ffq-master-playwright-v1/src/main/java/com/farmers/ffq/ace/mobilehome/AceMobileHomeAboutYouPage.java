package com.farmers.ffq.ace.mobilehome;

import com.farmers.ffq.ace.hrc.common.AceHRCAboutYouBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import static com.farmers.ffq.utils.GlobalVariables.*;

import java.time.LocalDate;

public class AceMobileHomeAboutYouPage extends AceHRCAboutYouBasePage {

	public AceMobileHomeAboutYouPage() throws Exception {
		super();
	}

	public void verifyPageContent(FarmersSoftAssert fsa, ApplicantAceHome mobilehomeApplicant) throws Exception {
		String testCategory = mobilehomeApplicant.getTestCategory();
		boolean isForemostQuote = testCategory.equals(FOREMOST);
		boolean isOtherForemostQuote = testCategory.equals(USAA);
		boolean isAWSQuote = testCategory.equals(AWS_SCENARIOS);
		String activeStep = getActiveStep(testCategory);
		if (!isForemostQuote) {
			verifyMobileHomeCommonHeader(fsa, isOtherForemostQuote);
		}
		fsa.assertEquals(getTextFromElement(aboutYouHeader), ABOUT_YOU_HEADER, "About you page - Page title.");
		fsa.assertEquals(getTextFromElement(letsGetToKnowEachOtherSubHeader), "Let's get to know each other.", "About you page - Page subtitle.");
		fsa.assertEquals(getValueFromWebElement(firstNameInputBox), EMPTY_STRING, "About you page - First name field is blank.");
		fsa.assertEquals(getValueFromWebElement(lastNameInputBox), EMPTY_STRING, "About you page - Last name is blank.");
		fsa.assertEquals(getValueFromWebElement(dateOfBirthInputBox), EMPTY_STRING, "About you page - Date of birth is blank.");
		fsa.assertEquals(getTextFromElement(buttonContinue), "Continue", "Tell us more page - CTA button text label");
		validatePageLinksText(fsa, activeStep);
		if (!isOtherForemostQuote) {
			validatePageLinksNavigationTitles(fsa);
		}
		validateAgentSectionContent(fsa, isAWSQuote, testCategory);
	}

	public void validatePageErrors(FarmersSoftAssert fsa, ApplicantAceHome mobilehomeApplicant) throws Exception {
		//validate no data provided error messages
		fillOutApplicantFormWithNoInput();
		validateErrorMessageForNoInput(true, mobilehomeApplicant, fsa);
		validateRequiredIncompleteFieldErrorMessage(fsa);
		// validate incorrect input error messages
		fillOutApplicantFormWithIncorrectInput(true);
		validateErrorMessageForInvalidInput(true, mobilehomeApplicant, fsa);
		validateRequiredIncompleteFieldErrorMessage(fsa);
		// validate age<=15 and age>=99 & Date of Birth are invalid entries
		validateInvalidErrorMessagesForAgeLimitAndDob(fsa, mobilehomeApplicant, true);
		validateRequiredIncompleteFieldErrorMessage(fsa);
		driver().navigate().refresh();
		//validate First/Last name char limit - 15 char and 20 char max respectively
		fillOutApplicantFormWithValues("MoreThanFifteenChars", "MoreThanTwentyCharacters", "09/09/1600" );
		validateCharacterLimitForFirstNameLastName(fsa);
		driver().navigate().refresh();
		//Not allowed special chars and numeric chars in First name and last name field
		validateNotAllowedSpecialCharsInFirstLastName(fsa);
		driver().navigate().refresh();
		validateNotAllowedNumericInFirstLastName(fsa);
		//Not allowed special chars in DOB field
		validateNotAllowedSpecialCharInDOB(fsa);
	}

	public void validateSnackbarMessages(FarmersSoftAssert fsa) {
		enterValueInField("03/03/"+ LocalDate.now().minusYears(52).getYear(), dateOfBirthInputBox, "Adding over 50 yo applicant");
		fsa.assertTrue(isSnackBarMessageDisplayed("We added an age of insured discount!"), "About you page - Applicant age discount added snackbar message found.");
		sleep(5);
		enterValueInField("03/03/"+ LocalDate.now().minusYears(35).getYear(), dateOfBirthInputBox, "Adding under 50 yo applicant");
		sleep(3);
		fsa.assertTrue(isSnackBarMessageDisplayed("Age of insured discount removed"), "Tell us more page - Applicant age discount removed snackbar message found.");
	}

}
