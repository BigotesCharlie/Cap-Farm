package com.farmers.ffq.datatransferobjects.ffqace;

import lombok.Getter;

import java.util.Arrays;
import java.util.List;
@Getter
public enum AceHomeSupportedOccupationByState {
    AL(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Law Enforcement Officer", "Lawyer/Judge",
	    "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist")),

    AR(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Law Enforcement Officer", "Lawyer/Judge",
            "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Veterinarian")),

    AZ(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Law Enforcement Officer", "Lawyer/Judge",
            "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Veterinarian")),

    CA(Arrays.asList("Accountant", "Architect", "Bristol West Employees", "California-FIG FED CU Member", "Dentist", "Educator", "Engineer", "Farmers Agent",
            "Farmers District Manager", "Farmers Employee", "Firefighter", "Foremost Employee", "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Nurse",
            "Physical and Occupational Therapist", "Physician/Surgeon", "Professional Aviator", "Real Estate Agent and Brokers", "Scientist", "Speech Audiologist and Pathologist",
            "Veterinarian", "Workers Compensation Policyholders", "Zurich Employee")),

    CO(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter",
            "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist")),

    CT(Arrays.asList("Accountant", "Architect - State License-(NO DEGREE)", "Dentist", "Educator - Community College", "Engineer - College Degree", "Farmers Agent",
            "Farmers District Manager Employee", "Farmers Employee", "Firefighter", "Foremost Employee", "Law Enforcement Officer", "Lawyer/Judge", "Librarian",
            "Military Honorably Discharged", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Zurich Employee")),

    GA(Arrays.asList("Farmers/Zurich Employee", "Military Personnel 5 options")),

    IA(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter",
            "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist")),

    ID(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter",
            "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist")),

    IL(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter",
            "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Veterinarian")),

    IN(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter",
            "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist")),

    KS(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Law Enforcement Officer", "Lawyer/Judge",
            "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Veterinarian")),

    MD(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter",
            "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Veterinarian")),

    MI(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Honorably discharged", "Law Enforcement Officer", "Lawyer/Judge",
	    "Librarian", "Military Personnel", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Veterinarian")),

    MO(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter",
            "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist")),

    MT(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Military Personnel 6 options",
            "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Veterinarian")),

    ND(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Law Enforcement Officer", "Lawyer/Judge",
            "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist")),

    NE(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter",
            "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Veterinarian")),

    NM(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter",
            "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Veterinarian")),

    OH(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter",
	    "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist")),

    OK(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Law Enforcement Officer", "Lawyer/Judge",
            "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist")),

    OR(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Law Enforcement Officer", "Lawyer/Judge",
            "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Veterinarian")),

    PA(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Law Enforcement Officer", "Lawyer/Judge",
            "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Veterinarian")),

    SD(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter",
            "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist")),

    TN(List.of()),

    TX(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Law Enforcement Officer", "Lawyer/Judge",
            "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist")),

    UT(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Law Enforcement Officer", "Lawyer/Judge",
            "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist")),

    VA(Arrays.asList("21st Century Employees", "Accountant", "Architect - State License-(NO DEGREE)", "Bristol West Employee", "Dentist", "Educator - Community College",
            "Engineer - College Degree", "Farmers Agent", "Farmers District Manager", "Farmers Employee", "Firefighter", "Foremost Employee", "Law Enforcement Officer",
            "Lawyer/Judge", "Librarian", "Military Honorably Discharged", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Veterinarian",
            "Zurich Employee")),

    WA(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter",
            "Law Enforcement Officer", "Lawyer/Judge", "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist")),

    WI(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Law Enforcement Officer", "Lawyer/Judge",
            "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist", "Veterinarian")),

    WY(Arrays.asList("Accountant", "Architect", "Dentist", "Educator", "Engineer", "Farmers/Zurich Employee", "Firefighter", "Law Enforcement Officer", "Lawyer/Judge",
            "Librarian", "Military Personnel 6 options", "Nurse", "Physician/Surgeon", "Professional Aviator", "Scientist"));

    private final List<String> supportedOccupation;
    AceHomeSupportedOccupationByState(List<String> supportedOccupation) {
        this.supportedOccupation = supportedOccupation;
    }

}
