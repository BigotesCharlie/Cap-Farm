package com.farmers.ffq.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * Farmers Fast Quote (FFQ) - Global Variables.
 *
 */
public class GlobalVariables {
	private GlobalVariables() {
		// Nothing required
	}

	// Environments
	public static final String PROD_ENVIRONMENT = "esales";
	public static final String RA11_ENVIRONMENT = "ffqautouiuat.";
	public static final String RA61_ENVIRONMENT = "ffqautouiuat1.";
	public static final String MA11_ENVIRONMENT = "ffqautouiqa.";
	public static final String MA61_ENVIRONMENT = "ffqautouiqa1.";
	public static final String TSK1_ENVIRONMENT = "ffqautouiqa2.";
	public static final String PET_ENVIRONMENT = "ffqautouipet.";
	public static final String PERF_ENVIRONMENT = "ffqautouiperf.";
	public static final String DEV_ENVIRONMENT = "ffqautouidev.";

	//Browsers
	public static final String CHROME = "chrome";
	public static final String EDGE = "edge";
	public static final String FIREFOX = "firefox";
	public static final String SAFARI = "safari";

	// Screen resolution
	public static final String RESOLUTION_720_1100 = "720x1100";
	public static final String DEFAULT_RESOLUTION = "default";

	//LOB
	public static final String LOB_AUTO = "Auto Insurance";
	public static final String LOB_HOME = "Home Insurance";
	public static final String LOB_CONDO = "Condo Insurance";
	public static final String LOB_RENTERS = "Renters Insurance";
	public static final String LOB_BUSINESS = "Business Insurance";
	public static final String LOB_LIFE = "Life Insurance";
	public static final String LOB_MOBILE_HOME = "Mobile Home Insurance";
	public static final String AUTO_HOME_BUNDLE = "Auto & Home";
	public static final String AUTO_RENTERS_BUNDLE = "Auto & Renters";
	public static final String AUTO_CONDO_BUNDLE = "Auto & Condo";

	public static final String LOB_VTL = "Value Term Life Insurance";
	public static final String LOB_UMBRELLA = "Umbrella Insurance";
	public static final String CROSS_SELL_AUTO = "Cross Sell Auto";
	public static final String CROSS_SELL_LIFE = "Cross Sell Life";
	public static final String ALL_LOBS = "All LOBs";
	public static final String NO_BUNDLE = "noBundle";
	public static final String LOB_ACE_HCR = "Home/Condo/Renters Insurance";

	public static final String GET_A_QUOTE = "getAQuote";
	public static final String CHECK_MY_PRICE = "checkMyPrice";

	//Custom attribute names
	public static final String ACE_STATES = "aceStates";
	public static final String BW_STATES = "bwStates";
	public static final String DISABLED_STATES = "disabledStates";
	public static final String EXCLUDED_LEGACY_STATES = "excludedLegacyStates";
	public static final String EXCLUDED_STATES = "excludedStates";
	public static final String EXCLUDE_NONMONOLINE_HOME_STATES = "excludeNonmonolineHomeStates";
	public static final String EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES = "excludeUnconfiguredMAStates";
	public static final String REMOVE_AUTO_REDSTATES = "autoRedStates";
	public static final String REMOVE_SPECIALTY_REDSTATES = "specialtyRedStates";
	public static final String FARMERS_STATES = "farmersStates";
	public static final String HIGH_VALUE_STATES = "highValueStates";
	public static final String INCLUDED_STATES = "includedStates";
	public static final String MONETIZED_STATES = "monetizedStates";
	public static final String RANDOM_STATE = "randomState";

	// Specific test scenarios
	public static final String INFO_PAGE_VALIDATION = "info page";
	public static final String VEHICLE_PAGES_VALIDATION = "vehicle page";
	public static final String DRIVER_PAGES_VALIDATION = "driver page";
	public static final String QUOTE_PAGE_VALIDATION = "quote page";
	public static final String LEAD_GEN_TESTING = "leadGen";
	public static final String AWS_SCENARIOS ="AWS Scenarios";
	public static final String DIFFERENT_STATE_DL ="Different State Driver License";
	public static final String SUSPENDED_DL ="Suspended DL";
	public static final String NEW_YORK_COMMUTER ="New York Commutor";
	public static final String FOREMOST = "Foremost";
	public static final String USAA = "USAA";
	public static final String RETRIEVED = "retrieved";

	// Validation strings
	public static final String ALPHA = "Thequickbrownfoxjumpedoverthelazydog";
	public static final String ALPHA_NUMERIC = "The0quick1brown2fox3jumped4over5the6lazy7dog8";
	public static final String ALPHA_SPACE = "The quick brown fox jumped over the lazy dog";
	public static final String ALPHA_SPACE_HYPHEN = "The quick-brown fox jumped over the lazy-dog";
	public static final String ALPHA_SPACE_HYPHEN_NUMERIC = "The1 quick-brown2 fox3 jumped4 over5 the6 lazy-dog7";
	public static final String ALPHA_SPACE_NUMERIC = "0The1 quick2 brown3 fox4 jumped5 over6 the7 lazy8 dog9";
	public static final String DIGITS = "0123456789";
	public static final String SPECIALCHARS = "$ !#@%^&*()<>:;'\"?/~`[]{}|\\+=-_.,";
	public static final String SPECIALCHARS_ALPHA = "$ !#The@%^&*quick()<>:brown;'\"?/fox~`[]{}|\\+=-_.,";
	public static final String SPECIALCHARS_DIGITS = "$ !12#@%45^&*67()<>89:;'0\"?/~`[]{}|\\+=-_.,";
	public static final String VALID_DOB = "09091989";
	public static final String INVALID_DOB = "40132089";
	public static final String VALID_PHONE = "3105550000";
	public static final String INVALID_PHONE = "0000000000";

	//Auto
	public static final String MORNING = "Morning (9:00 AM - 12:00 PM)";
	public static final String AFTERNOON = "Afternoon (12:00 PM - 4:00 PM)";
	public static final String EVENING = "Evening (4:00 PM - 7:00 PM)";

	public static final int FIRST_AVAILABLE_OPTION = 0;
	public static final int SECOND_AVAILABLE_OPTION = 1;
	public static final int NOT_FOUND_IN_LIST = -1;
	public static final int LAST_AVAILABLE_OPTION = NOT_FOUND_IN_LIST;
	public static final int NEXT_TO_LAST_AVAILABLE_OPTION = -2;
	public static final int MAX_AGE = 98;
	public static final int MIN_AGE = 16;
	public static final int MIN_YOUNG_AGE = 16;
	public static final int MAX_YOUNG_AGE = 25;
	public static final int MIN_DISTANT_STUDENT_PARENT_AGE = 31;
	public static final int MIN_OLD_AGE = 56;
	public static final int MIN_OLD_AGE_ONE_UI = 55;
	public static final int MAX_OLD_AGE = 100;
	public static final int MAX_NUMBER_OF_ADDITIONALDRIVERS = 4;
	public static final int MAX_NUMBER_OF_VEHICLES = 5;
	public static final int MAX_NUMBER_OF_VEHICLES_FOUR = 4;
	public static final String HIGH_END_VEHICLE = "High End Vehicle";
	public static final String USE_VEHICLE_INFO = "Use Vehicle Info";
	public static final String NO_FAST_TRACK = "No Fast Track";
	public static final String YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION = "Your quote requires special attention";
	public static final String WE_APOLOGIZE_FOR_THE_INCONVENIENCE = "We apologize for the inconvenience";
	public static final String _0 = "$0";
	public static final String _40 = "$40";
	public static final String _50 = "$50";
	public static final String _80 = "$80";
	public static final String _100 = "$100";
	public static final String _120 = "$120";
	public static final String _140 = "$140";
	public static final String _150 = "$150";
	public static final String _200 = "$200";
	public static final String _250 = "$250";
	public static final String _300 = "$300";
	public static final String _500 = "$500";
	public static final String _750 = "$750";
	public static final String _1000 = "$1,000";
	public static final String _1500 = "$1,500";
	public static final String _2000 = "$2,000";
	public static final String _2500 = "$2,500";
	public static final String _3K = "$3,000";
	public static final String _4K = "$4,000";
	public static final String _5K = "$5,000";
	public static final String _8K = "$8,000";
	public static final String _10K = "$10,000";
	public static final String _15K = "$15,000";
	public static final String _20K = "$20,000";
	public static final String _25K = "$25,000";
	public static final String _30K = "$30,000";
	public static final String _35K = "$35,000";
	public static final String _40K = "$40,000";
	public static final String _45K = "$45,000";
	public static final String _50K = "$50,000";
	public static final String _60K = "$60,000";
	public static final String _70K = "$70,000";
	public static final String _75K = "$75,000";
	public static final String _85K = "$85,000";
	public static final String _100K = "$100,000";
	public static final String _110K = "$110,000";
	public static final String _250K = "$250,000";
	public static final String _200K = "$200,000";
	public static final String _300K = "$300,000";
	public static final String _500K = "$500,000";
	public static final String _1M = "$1,000,000";
	public static final double ONEMILLION = 1000000;
	public static final double ONE_POINT_FIVE_MILLION = 1500000;
	public static final double THREELAKH = 300000;
	public static final double ONE_FIFTY_LAKH = 150000;
	public static final String _0_AND_0 = "$0/$0";
	public static final String _1000_AND_5000 = "$1,000/$5,000";
	public static final String _1000_AND_15K = "$1,000/$15,000";
	public static final String _1500_AND_25K = "$1,500/$25,000";
	public static final String _2500_AND_50K = "$2,500/$50,000";
	public static final String _3500_AND_250 = "$3,500/$250";
	public static final String _4500_AND_900 = "$4,500/$900";
	public static final String _5K_AND_500 = "$5,000/$500";
	public static final String _10K_AND_0 = "$10,000/$0";
	public static final String _10K_AND_250 = "$10,000/$250";
	public static final String _10K_AND_500 = "$10,000/$500";
	public static final String _10K_AND_900 = "$10,000/$900";
	public static final String _10K_AND_1000 = "$10,000/$1,000";
	public static final String _10K_AND_20K = "$10,000/$20,000";
	public static final String _15K_AND_250 = "$15,000/$250";
	public static final String _15K_AND_500 = "$15,000/$500";
	public static final String _15K_AND_1000 = "$15,000/$1,000";
	public static final String _15K_AND_2000 = "$15,000/$2,000";
	public static final String _15K_AND_2500 = "$15,000/$2,500";
	public static final String _15K_AND_30K = "$15,000/$30,000";
	public static final String _20K_0_AND_0 = "$20,000/$0/$0";
	public static final String _20K_0_AND_200 = "$20,000/$0/$200";
	public static final String _20K_100_AND_0 = "$20,000/$100/$0";
	public static final String _20K_100_AND_200 = "$20,000/$100/$200";
	public static final String _20K_AND_250 = "$20,000/$250";
	public static final String _20K_AND_40K = "$20,000/$40,000";
	public static final String _25K_AND_200 = "$25,000/$200";
	public static final String _25K_AND_250 = "$25,000/$250";
	public static final String _25K_AND_500 = "$25,000/$500";
	public static final String _25K_AND_900 = "$25,000/$900";
	public static final String _25K_AND_1000 = "$25,000/$1,000";
	public static final String _25K_AND_50K = "$25,000/$50,000";
	public static final String _25K_AND_65K = "$25,000/$65,000";
	public static final String _30K_0_AND_0 = "$30,000/$0/$0";
	public static final String _30K_0_AND_200 = "$30,000/$0/$200";
	public static final String _30K_100_AND_0 = "$30,000/$100/$0";
	public static final String _30K_100_AND_200 = "$30,000/$100/$200";
	public static final String _30K_AND_60K = "$30,000/$60,000";
	public static final String _30K_AND_65K = "$30,000/$65,000";
	public static final String _35K_AND_70K = "$35,000/$70,000";
	public static final String _35K_AND_80K = "$35,000/$80,000";
	public static final String _40K_AND_250 = "$40,000/$250";
	public static final String _40K_0_AND_0 = "$40,000/$0/$0";
	public static final String _40K_0_AND_200 = "$40,000/$0/$200";
	public static final String _40K_100_AND_0 = "$40,000/$100/$0";
	public static final String _40K_100_AND_200 = "$40,000/$100/$200";
	public static final String _50K_AND_200 = "$50,000/$200";
	public static final String _50K_AND_250 = "$50,000/$250";
	public static final String _50K_AND_500 = "$50,000/$500";
	public static final String _50K_AND_1000 = "$50,000/$1,000";
	public static final String _50K_AND_2000 = "$50,000/$2,000";
	public static final String _50K_AND_2500 = "$50,000/$2,500";
	public static final String _50K_AND_50K = "$50,000/$50,000";
	public static final String _50K_AND_100K = "$50,000/$100,000";
	public static final String _75K_AND_250 = "$75,000/$250";
	public static final String _75K_AND_500 = "$75,000/$500";
	public static final String _75K_AND_1000 = "$75,000/$1,000";
	public static final String _75K_AND_2000 = "$75,000/$2,000";
	public static final String _75K_AND_2500 = "$75,000/$2,500";
	public static final String _100K_0_AND_0 = "$100,000/$0/$0";
	public static final String _100K_0_AND_200 = "$100,000/$0/$200";
	public static final String _100K_100_AND_0 = "$100,000/$100/$0";
	public static final String _100K_100_AND_200 = "$100,000/$100/$200";
	public static final String _100K_AND_200 = "$100,000/$200";
	public static final String _100K_AND_250 = "$100,000/$250";
	public static final String _100K_AND_500 = "$100,000/$500";
	public static final String _100K_AND_1000 = "$100,000/$1,000";
	public static final String _100K_AND_200K = "$100,000/$200,000";
	public static final String _100K_AND_300K = "$100,000/$300,000";
	public static final String _200K_AND_600K = "$200,000/$600,000";
	public static final String _150K_AND_250 = "$150,000/$250";
	public static final String _150K_AND_500 = "$150,000/$500";
	public static final String _150K_AND_1000 = "$150,000/$1,000";
	public static final String _150K_AND_2000 = "$150,000/$2,000";
	public static final String _150K_AND_2500 = "$150,000/$2,500";
	public static final String _150K_AND_300K = "$150,000/$300,000";
	public static final String _250K_AND_200 = "$250,000/$200";
	public static final String _250K_AND_250 = "$250,000/$250";
	public static final String _250K_AND_500 = "$250,000/$500";
	public static final String _250K_AND_1000 = "$250,000/$1,000";
	public static final String _250K_AND_2000 = "$250,000/$2,000";
	public static final String _250K_AND_2500 = "$250,000/$2,500";
	public static final String _250K_AND_500K = "$250,000/$500,000";
	public static final String _300K_AND_300K = "$300,000/$300,000";
	public static final String _500K_AND_200 = "$500,000/$200";
	public static final String _500K_AND_250 = "$500,000/$250";
	public static final String _500K_AND_500 = "$500,000/$500";
	public static final String _500K_AND_1000 = "$500,000/$1,000";
	public static final String _500K_AND_500K = "$500,000/$500,000";
	public static final String _500K_AND_1M = "$500,000/$1,000,000";
	public static final String _1M_AND_1M = "$1,000,000/$1,000,000";
	public static final String SPECIAL_BI_LIMIT_IS_NEEDED = "Special Bi Limit is Needed";

	// DOM element attributes
	public static final String ARIA_LABEL = "aria-label";
	public static final String ARIA_DISABLED = "aria-disabled";
	public static final String ARIA_OWNS = "aria-owns";
	public static final String ARIA_CHECKED = "aria-checked";
	public static final String ARIA_PRESSED = "aria-pressed";
	public static final String ARIA_REQUIRED = "aria-required";
	public static final String ARIA_SELECTED = "aria-selected";
	public static final String ARIA_INVALID = "aria-invalid";
	public static final String CLASS = "class";
	public static final String DATA_GTM = "data-gtm";
	public static final String LOWERCASE_ID = "id";
	public static final String DISABLED = "disabled";
	public static final String ENABLED = "enabled";
	public static final String HREF = "href";
	public static final String SRC = "src";
	public static final String VALUE = "value";
	public static final String COLOR = "color";
	public static final String DARK_RED_RGB = "rgb(179, 0, 50)";
	public static final String DARK_RED_RGBA = "rgba(179, 0, 50, 1)";
	public static final String RED_RGB = "rgb(255, 0, 0)";
	public static final String RED_RGBA = "rgba(255, 0, 0, 1)";
	public static final String RED_RGB_AUTO_REDESIGN = "rgb(224, 25, 51)";
	public static final String RED_RGBA_AUTO_REDESIGN = "rgba(224, 25, 51, 1)";
	public static final String MAXLENGTH = "maxlength";
	public static final String WAIT_SPINNER_XPATH = "//div[contains(@class, 'loader-spinner-mask-holder ng-star-inserted')]";
	public static final String LEGACY_WAIT_DIALOG_CLASSNAME = "summaryAddedMain";
	public static final String WAIT_QUOTE_READY_ID = "jsAlert99_background";
	public static final String XPATH = "xpath";
	public static final String DROPDOWN_OPTIONS_XPATH = "//mat-option//span";
	public static final String READONLY = "readonly";
	public static final String COMMA = ",";
	public static final String MAT_RADIO_CHECKED = "mat-radio-checked";
    public static final String RADIO_BUTTON_CHECKED = "radio-checked";
    public static final String MAT_MDC_RADIO_CHECKED = "mat-mdc-radio-checked";
    public static final String MDC_CHECKBOX_CHECKED = "mdc-checkbox-checked";
    public static final String MDC_CHECKBOX_SELECTED = "mdc-checkbox--selected";
	public static final String MAT_CHECKBOX_CHECKED = "mat-checkbox-checked";
	public static final String MAT_CHECKBOX_DISABLED = "mat-checkbox-disabled";
    public static final String CHECKBOX_CHECKED = "checkbox-checked";
    public static final String CHECKBOX_DISABLED = "checkbox-disabled";
	public static final String MAT_TOGGLE_CHECKED = "mat-checked";
	public static final String SLIDE_TOGGLE_CHECKED = "slide-toggle-checked";
	public static final String MDC_SWITCH_SELECTED = "mdc-switch--selected";
	public static final String MDC_SWITCH_UNSELECTED = "mdc-switch--unselected";
    public static final String TOGGLE_CHECKED = "toggle-checked";
	public static final String MAT_TOGGLE_BUTTON_CHECKED = "mat-button-toggle-checked";
	//Home
	public static final String SUCCESS = "S";
	public static final int MAX_AGE_HOME = 108;
	public static final int MIN_AGE_FOR_AGE_FIFTY_PLUS_DISCOUNT = 50;
	public static final String NO_MATCHES_FOUND = "No matches found";
	public static final String SR_22 = "SR-22";
	public static final String SR_22_ANOTHER_STATE = "SR-22-AnotherState";

	//Policies
	public static final String RENTERS = "Renters";
	public static final String CONDO = "Condo";
	public static final String LIFE = "Life";
	public static final String HOME = "Home";
	public static final String AUTO = "Auto";
	public static final String TOWNHOME = "Townhome";
	public static final String DUPLEX = "Duplex";
	public static final String APARTMENT_CONDO = "Apartment/Condo";
	public static final String DUPLEX_TRIPLEX = "Duplex/Triplex";
	public static final String MOBILE_MANUFACTURED_HOME = "Mobile/manufactured home";
	public static final String MOBILE_HOME = "mobilehome";
	public static final String WORKERS_COMPENSATION = "Workers";
	public static final String COMMERCIAL_AUTO = "Commercial";
	public static final String BUSINESSOWNER = "Businessowner";
    public static final String UMBRELLA = "Umbrella";
    public static final String HOME_TO_AUTO = "Home/Auto";

	//Groups
	public static final String ADDRESS_ONEUI = "addressOneUITest";
	public static final String ADDRESS_CHANGE_ZIP_ONEUI = "addressZipChangeOneUITest";
	public static final String ONE_MOMENT = "oneMoment";
	public static final String WHO_SHOULD_WE_INSURE = "whoShouldWeInsure";
	public static final String HERE_IS_WHAT_WE_HAVE_FOUND = "hereIsWhatWeFound";
	public static final String AGENT_DETAILS = "agentDetails";
	public static final String BINDONEUI = "bindOneUITest";
	public static final String NAME_AND_DOB_ONEUI = "nameAndDobOneUITest";
	public static final String QUOTEONEUI = "quoteOneUITest";
	public static final String QUOTE_SUMMARY = "quoteSummary";
	public static final String DRIVER_REVIEW = "driverReviewTests";
	public static final String CONTACT_INFO = "contactInfoTests";
	public static final String KNOCKOUT_LEAD_FORM = "knockoutLeadFormTests";
	public static final String KNOCKOUT_TESTS = "quoteKnockout";
	public static final String SAVE_AND_RETRIEVE = "saveAndRetrieveTests";
	public static final String BRISTOL_WEST_TESTS = "bristolWestTests";
	public static final String VEHICLES_REVIEW_TEST = "vehiclesReviewTests";
	public static final String HEADER_AND_FOOTER_TEST = "headerAndFooterTests";
	public static final String WHO_DRIVES_WHAT = "WhoDrivesWhatPage";
	public static final String SMOKE_ACE = "smoke"; // used for ACE smoke test case
	public static final String FFQ_ACE_SMOKE = "ffq_ace_smoke";
	public static final String ACE_STABILITY = "aceStability";
	public static final String FFQ_ACE_HOME_BIND = "ffqAceHomeBind";
	public static final String FFQ_ONEUI = "ffqOneui"; //meant to be the all encompassing group
	public static final String BDQ_TESTS = "bdqTests"; //meant to be the all encompassing group
	public static final String BDQ_TESTS_TESLA = "bdqTestsTeslaSupport";
	public static final String BW_ACE_TESTS = "bwAceAuto"; //meant to be the all encompassing group
	public static final String FFQ_ACE_CROSS_SELL = "ffqAceCrossSell"; //meant to be the all encompassing group
	public static final String FFQ_ONEUI_LANDINGPAGE = "ffqOneuiLandingPage";
	public static final String QUOTE_E2E = "QuoteE2E"; //meant to be the all encompassing group
	public static final String FFQ_BIND_JFMT_PAGE = "ffqJustFewMoreThingsPage";
	public static final String FFQ_BIND_PAYMENT_SUMMARY_PAGE = "ffqBindPaymentSummaryPage";
	public static final String FFQ_BIND_PAYINFULL_PAGE = "ffqBindPayInFullPage";
	public static final String FFQ_BIND_MONTHLYPAY_PAGE = "ffqBindMonthlyPayPage";
	public static final String FFQ_BIND_BANKPAYMENT_PAGE = "ffqBindBankPaymentPage";
	public static final String FFQ_BIND_DEBITCREDITPAYMENT_PAGE = "ffqBindDebitCreditPaymentPage";
	public static final String FFQ_BIND_BACKANDFORTH = "ffqBindBackAndForthValidation";
	public static final String FFQ_BIND_VEHICLE_KNOCKOUT = "ffqBindVehicleKnockOut";
	public static final String FFQ_BIND_LENDER_KNOCKOUT = "ffqBindLenderKnockOut";
	public static final String FFQ_ACE_AUTO_E2E = "ffqAceAutoE2E";
	public static final String FFQ_BIND_ENDTOEND = "ffqBindEndToEnd";
	public static final String BW_BIND_E2E = "bwBindE2E";
	public static final String FFQ_BIND_WITH_ADPFDATA_ENDTOEND = "ffqBindWithAdpfDataEndToEnd";
	public static final String FFQ_DRIVER_MISMATCH = "ffqDriverMismatch";
	public static final String FFQ_ACE_HOME = "Ace Home";
	public static final String FFQ_ACE_HOME_CRITICAL = "Ace Home Critical";
	public static final String FFQ_ACE_CONDO = "Ace Condo";
	public static final String FFQ_ACE_CONDO_CRITICAL = "Ace Condo Critical";
	public static final String FFQ_ACE_RENTERS = "Ace Renters";
	public static final String FFQ_ACE_RENTERS_CRITICAL = "Ace Renters Critical";
	public static final String FFQ_ACE_LIFE = "Ace Life";
	public static final String FFQ_MOBILE_HOME = "MobileHome";
	public static final String SPECIALTY_DWELLING = "dwelling";

	public static final String FFQ_ACE_HOME_ADDRESS_PAGE = "ffqAceHomeAddressPage";
	public static final String FFQ_ACE_RENTERS_ADDRESS_PAGE = "ffqAceRentersAddressPage";
	public static final String FFQ_ACE_CONDO_ADDRESS_PAGE = "ffqAceCondoAddressPage";
	public static final String FFQ_ACE_HOME_PROPERTY_TYPE_PAGE = "ffqAceHomePropertyTypePage";
	public static final String FFQ_ACE_RENTERS_PROPERTY_TYPE_PAGE = "ffqAceRentersPropertyTypePage";
	public static final String FFQ_ACE_HOME_QUALITY_GRADE_PAGE = "ffqAceHomeQualityGradePage";
	public static final String FFQ_ACE_CONDO_QUALITY_GRADE_PAGE = "ffqAceCondoQualityGradePage";
	public static final String FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE = "ffqAceHomePropertyDetailsPage";
	public static final String FFQ_ACE_CONDO_PROPERTY_DETAILS_PAGE = "ffqAceCondoPropertyDetailsPage";
	public static final String FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE = "ffqAceHomeAdditionalInfoPage";
	public static final String FFQ_ACE_CONDO_ADDITIONAL_INFO_PAGE = "ffqAceCondoAdditionalInfoPage";
	public static final String FFQ_ACE_HOME_ABOUT_YOU_PAGE = "ffqAceHomeAboutYouPage";
	public static final String FFQ_ACE_RENTERS_ABOUT_YOU_PAGE = "ffqAceRentersAboutYouPage";
	public static final String FFQ_ACE_CONDO_ABOUT_YOU_PAGE = "ffqAceCondoAboutYouPage";
	public static final String FFQ_ACE_HOME_CONTACT_INFO_PAGE = "ffqAceHomeContactInfoPage";
	public static final String FFQ_ACE_CONDO_CONTACT_INFO_PAGE = "ffqAceCondoContactInfoPage";
	public static final String FFQ_ACE_RENTERS_CONTACT_INFO_PAGE = "ffqAceRentersContactInfoPage";
	public static final String FFQ_ACE_HOME_DWELLING_COVERAGE_PAGE = "ffqAceHomeDwellingCoveragePage";
	public static final String FFQ_ACE_CONDO_CUSTOM_COVERAGE_PAGE = "ffqAceCondoCustomCoveragePage";
	public static final String FFQ_ACE_RENTERS_CUSTOM_COVERAGE_PAGE = "ffqAceRentersCustomCoveragePage";
	public static final String FFQ_ACE_HOME_REVIEW_QUOTE_PAGE = "ffqAceHomeReviewQuotePage";
	public static final String FFQ_ACE_CONDO_REVIEW_QUOTE_PAGE = "ffqAceCondoReviewQuotePage";
	public static final String FFQ_ACE_RENTERS_REVIEW_QUOTE_PAGE = "ffqAceRentersReviewQuotePage";
	public static final String FFQ_ACE_HOME_ADDITIONAL_COVERAGES_PAGE = "ffqAceHomeAdditionalCoveragesPage";
	public static final String FFQ_ACE_RENTERS_ADDITIONAL_COVERAGES_PAGE = "ffqAceRentersAdditionalCoveragesPage";
	public static final String FFQ_ACE_CONDO_ADDITIONAL_COVERAGES_PAGE = "ffqAceCondoAdditionalCoveragesPage";
	public static final String FFQ_ACE_HOME_THANK_YOU_PAGE = "ffqAceHomeThankYouPage";
	public static final String FFQ_ACE_CONDO_THANK_YOU_PAGE = "ffqAceCondoThankYouPage";
	public static final String FFQ_ACE_HOME_RETRIEVE_FLOW = "ffqAceHomeRetrieveFlow";
	public static final String FFQ_ACE_CONDO_RETRIEVE_FLOW = "ffqAceCondoRetrieveFlow";
	public static final String FFQ_ACE_RENTERS_RETRIEVE_FLOW = "ffqAceRentersRetrieveFlow";
	public static final String FFQ_ACE_HOME_JAFMT_PAGE = "ffqAceHomeJustAFewMoreThingsPage";
	public static final String FFQ_ACE_CONDO_JAFMT_PAGE = "ffqAceCondoJustAFewMoreThingsPage";
	public static final String FFQ_ACE_RENTERS_JAFMT_PAGE = "ffqAceRentersJustAFewMoreThingsPage";
	public static final String FFQ_ACE_HOME_PAYMENT_SELECTION_PAGE = "ffqAceHomePaymentSelectionPage";
	public static final String FFQ_ACE_CONDO_PAYMENT_SELECTION_PAGE = "ffqAceCondoPaymentSelectionPage";
	public static final String FFQ_ACE_RENTERS_PAYMENT_SELECTION_PAGE = "ffqAceRentersPaymentSelectionPage";
	public static final String FFQ_ACE_HOME_PAY_IN_FULL_PAGE = "ffqAceHomePayInFullPage";
	public static final String FFQ_ACE_CONDO_PAY_IN_FULL_PAGE = "ffqAceCondoPayInFullPage";
	public static final String FFQ_ACE_RENTERS_CONSOLIDATED_PAYMENT_PAGE = "ffqAceRentersConsolidatedPaymentPage";
	public static final String FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE = "ffqAceHomeMonthlyAutoPayBankPage";
	public static final String FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE = "ffqAceCondoMonthlyAutoPayBankPage";
	public static final String FFQ_ACE_RENTERS_MONTHLY_AUTOPAY_BANK_PAGE = "ffqAceRentersMonthlyAutoPayBankPage";
	public static final String FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE = "ffqAceHomeMonthlyAutoPayCardPage";
	public static final String FFQ_ACE_CONDO_MONTHLY_AUTOPAY_CARD_PAGE = "ffqAceCondoMonthlyAutoPayCardPage";
	public static final String FFQ_ACE_HOME_KNOCKOUT_FLOW = "ffqAceHomeKnockOutFlow";
	public static final String ACE_LIFE_NAME_DOB_PAGE = "AceLifeNameAndDOBPage";
	public static final String ACE_LIFE_PERSONAL_INFO_PAGE = "AceLifePersonalInfoPage";
	public static final String ACE_LIFE_REVIEW_QUOTE_PAGE = "AceLifeReviewQuotePage";
	public static final String FFQ_ACE_RENTERS_KNOCKOUT_FLOW = "ffqAceRentersKnockOutFlow";
	public static final String ADDITIONAL_INFO = "additionalinfo";
	public static final String HQM = "HQM";
	public static final String ACE_AUTO = "Ace Auto";
	public static final String ACE_AUTO_ADA_SUITE = "aceAutoAdaSuite";
	public static final String MARKETING_IT = "MarketingIT";
	public static final String BUNDLE = "bundle";
	public static final String SUITE = "suite";
	public static final String ADA_SUITE = "adaSuite";
	public static final String REGRESSION = "regSuite";
	public static final String MOBILE_REGRESSION = "mobileRegressionSuite";
	public static final String GUIDEWIRE = "guideWireSuite";
	public static final String AUTO_STABILITY = "autoQuote";
	public static final String AUTO_REDESIGN = "autoRedesign";
	public static final String AUTO_BVT = "autoBuildValidationTest";
	public static final String AUTO_COVERAGE_VALIDATION = "coverageTesting";
	public static final String DIGITAL_MONETIZATION = "digitalMonetization";
	public static final String STATE_SCENARIOS = "stateScenarios";
	public static final String GET_HOME = "get_home";
	public static final String CI_CD_SUITE = "cicdSuite";
	public static final String PRODUCTION_VALIDATION = "productionValidation";
	public static final String PAGE_VALIDATION_HOME = "page_validation_home";
	public static final String HOME_SMOKE = "home_smoke";
	public static final String GET_RETRIEVE_HOME = "get_retrieve_home";
	public static final String CONDO_GROUP = "condo";
	public static final String GET_RETRIEVE_CONDO = "get_retrieve_condo";
	public static final String RENTERS_GROUP = "renters";
	public static final String GET_RETRIEVE_RENTERS = "get_retrieve_renters";
	public static final String LIFE_REG = "life_reg";
	public static final String ACE_HOME_SMOKE = "ace_home_smoke";
	public static final String HQM_E2E_REGRESSION = "quoteTestHQM";
	public static final String HQM_PAGE_REGRESSION = "pageTestHQM";
	public static final String HQM_SMOKE = "smokeHQM";
	public static final String HQM_RETRIEVE = "quoteRetrieveHQM";
	public static final String HQM_QUICKEN = "quickenHQM";
	public static final String HQM_CROSS_SELL = "crossSellHQM";
	public static final String HQM_ALL = "allTestHQM";
	public static final String HQM_E2E_MOBILE = "mobileBrowserHQM";
	public static final String HQM_PAGE_MOBILE = "mobilePageHQM";
	public static final String HQM_APEX_TEST = "testingApexHQM";
	public static final String HQM_ADA_SUITE = "HqmAdaSuite";
	public static final String SPOT_TESTING = "requestedTests";
	public static final String RANDOM_ROW = "randomRow";
	public static final String HOUSEHOLD_NUMBER = "householdNumber";
	public static final String CROSS_SELL = "crossSellSuite";
	public static final String ENV_STABILITY = "envStabilityCheckSuite";
	public static final String EMV = "earlyMorningValidationSuite";
	public static final String FLEX = "flexTests";
	public static final String PEWC = "pewc";
	public static final String MEDIA_ALPHA = "mediaAlpha";
	public static final String APEX = "apex";
	public static final String NO_FILTER = "NO_FILTER" ;
	public static final String FILTER = "filter" ;
	public static final String CHECKED = "checked" ;
	public static final String UNCHECKED = "unchecked" ;
	public static final String AUTO_ADA_SUITE = "autoAdaSuite";
	public static final String BUSINESS_ADA_SUITE = "businessAdaSuite";
	public static final String CONDO_ADA_SUITE = "condoAdaSuite";
	public static final String RENTERS_ADA_SUITE = "rentersAdaSuite";
	public static final String LIFE_ADA_SUITE = "lifeAdaSuite";
	public static final String ACE_HOME_ADA_SUITE = "aceHomeAdaSuite";
	public static final String ACE_RENTERS_ADA_SUITE = "aceRentersAdaSuite";
	public static final String ACE_CONDO_ADA_SUITE = "aceCondoAdaSuite";


	//State
	public static final String ALABAMA = "Alabama";
	public static final String ARIZONA = "Arizona";
	public static final String ARKANSAS = "Arkansas";
	public static final String CALIFORNIA = "California";
	public static final String COLORADO = "Colorado";
	public static final String CONNECTICUT = "Connecticut";
	public static final String FLORIDA = "Florida";
	public static final String GEORGIA = "Georgia";
	public static final String HAWAII = "Hawaii";
	public static final String IDAHO = "Idaho";
	public static final String ILLINOIS = "Illinois";
	public static final String INDIANA = "Indiana";
	public static final String IOWA = "Iowa";
	public static final String KANSAS = "Kansas";
	public static final String KENTUCKY = "Kentucky";
	public static final String LOUISIANA = "Louisiana";
	public static final String MASSACHUSETTS = "Massachusetts";
	public static final String MARYLAND = "Maryland";
	public static final String MICHIGAN = "Michigan";
	public static final String MINNESOTA = "Minnesota";
	public static final String MISSOURI = "Missouri";
	public static final String MISSISSIPPI = "Mississippi";
	public static final String MONTANA = "Montana";
	public static final String NEBRASKA = "Nebraska";
	public static final String NEVADA = "Nevada";
	public static final String NEW_JERSEY = "New Jersey";
	public static final String NEW_MEXICO = "New Mexico";
	public static final String NEW_YORK = "New York";
	public static final String NORTH_CAROLINA = "North Carolina";
	public static final String NORTH_DAKOTA = "North Dakota";
	public static final String OHIO = "Ohio";
	public static final String OKLAHOMA = "Oklahoma";
	public static final String OREGON = "Oregon";
	public static final String PENNSYLVANIA = "Pennsylvania";
	public static final String SOUTH_DAKOTA = "South Dakota";
	public static final String TENNESSEE = "Tennessee";
	public static final String TEXAS = "Texas";
	public static final String UTAH = "Utah";
	public static final String VIRGINIA = "Virginia";
	public static final String WASHINGTON = "Washington";
	public static final String WISCONSIN = "Wisconsin";
	public static final String WYOMING = "Wyoming";
	public static final String UNITED_STATES = "United States";

	//State code
	public static final String AK = "AK";
	public static final String AL = "AL";
	public static final String AR = "AR";
	public static final String AZ = "AZ";
	public static final String CA = "CA";
	public static final String CO = "CO";
	public static final String CT = "CT";
	public static final String DC = "DC";
	public static final String DE = "DE";
	public static final String FL = "FL";
	public static final String GA = "GA";
	public static final String HI = "HI";
	public static final String ID = "ID";
	public static final String IL = "IL";
	public static final String IN = "IN";
	public static final String IA = "IA";
	public static final String KS = "KS";
	public static final String KY = "KY";
	public static final String LA = "LA";
	public static final String MA = "MA";
	public static final String ME = "ME";
	public static final String MD = "MD";
	public static final String MI = "MI";
	public static final String MN = "MN";
	public static final String MO = "MO";
	public static final String MS = "MS";
	public static final String MT = "MT";
	public static final String NC = "NC";
	public static final String ND = "ND";
	public static final String NE = "NE";
	public static final String NJ = "NJ";
	public static final String NH = "NH";
	public static final String NM = "NM";
	public static final String NV = "NV";
	public static final String NY = "NY";
	public static final String OH = "OH";
	public static final String OK = "OK";
	public static final String OR = "OR";
	public static final String PA = "PA";
	public static final String RI = "RI";
	public static final String SC = "SC";
	public static final String SD = "SD";
	public static final String TN = "TN";
	public static final String TX = "TX";
	public static final String UT = "UT";
	public static final String VA = "VA";
	public static final String VT = "VT";
	public static final String WA = "WA";
	public static final String WV = "WV";
	public static final String WI = "WI";
	public static final String WY = "WY";
	public static final String ALL_STATES = "ALL";
	// Territories
	public static final String GU = "GU";
	public static final String PR = "PR";
	public static final String TT = "TT";
	public static final String VI = "VI";

	// Nav Bar Items
	public static final String YOUR_INFO = "YOUR INFO";
	public static final String PROPERTY = "PROPERTY";
	public static final String COVERAGE = "COVERAGE";
	public static final String NO_COVERAGE = "No Coverage";
	public static final String QUOTE = "Quote";
	public static final String VEHICLES = "VEHICLES";
	public static final String DRIVERS = "DRIVERS";
	public static final String DISCOUNTS = "DISCOUNTS";
	public static final String SAVE_AUTO_QUOTE_FINISH_LATER_SIDE_LINK = "SAVE QUOTE & FINISH LATER";
	public static final String SAVE_AUTO_QUOTE_FINISH_LATER_PAGE_LINK = "SAVE QUOTE AND FINISH LATER";
	public static final String AUTO_INFO = "Auto info";
	public static final String PROPERTY_INFO = "Property info";
	public static final String ENTER_INFO = "Enter info";
	public static final String REVIEW_QUOTE = "Review quote";
	public static final String PURCHASE = "Purchase";

	public static final String TERMS_OF_USE_URL = "Terms-of-Use";
	public static final String CONTACT_US_URL =  "Contact-Us";
	public static final String PERSONAL_INFO_USE_URL = "Privacy-Statement";
	public static final String NOTICE_OF_INFORMATIONAL_PRACTICES_URL = "Information-Practices";

	//Pages
	public static final String YOUR_INFO_PAGE_AUTO = "YourInfoPageAuto";
	public static final String VEHICLES_PAGE_AUTO = "VehiclesPage";
	public static final String DRIVERS_PAGE_AUTO = "DriversPage";
	public static final String DISCOUNTS_PAGE_AUTO = "DiscountsPage";
	public static final String QUOTE_PAGE_AUTO = "QuotePageAuto";
	public static final String YOUR_INFO_PAGE_HOME = "YourInfoPageHome";
	public static final String PROPERTY_PAGE_HOME = "PropertyPage";
	public static final String QUOTE_PAGE_HOME = "QuotePageHome";
	public static final String YOUR_INFO_PAGE_CONDO = "YourInfoPageCondo";
	public static final String PROPERTY_PAGE_CONDO = "PropertyPageCondo";
	public static final String DISCOUNT_PAGE_CONDO = "DiscountPageCondo";
	public static final String QUOTE_PAGE_CONDO = "QuotePageCondo";
	public static final String CHOOSE_YOUR_COVERAGE_PAGE = "ChooseYourCoveragePage";
	public static final String THANK_YOU_PAGE = "ThankYouPage";
	public static final String SIGN_PAGE = "SignPage";
	public static final String YOUR_INFO_PAGE_RENTERS = "YourInfoPageRenters";
	public static final String PROPERTY_PAGE_RENTERS = "PropertyPageRenters";
	public static final String QUOTE_PAGE_RENTERS = "QuotePageRenters";
	public static final String THANK_YOU_PAGE_RENTERS = "ThankYouPageRenters";
	public static final String PAYMENT_PAGE_RENTERS = "PaymentPageRenters";
	public static final String OLD_PAYMENT_PAGE_RENTERS = "OldPaymentPageRenters";
	public static final String RENTERS_LEAD_PAGE = "RentersLeadPage";
	public static final String CUSTOMIZE_QUOTE_PAGE_GDB = "CustomizeQuoteGDBPage";
	public static final String THANK_YOU_PAGE_GDB = "ThankYouGDBPage";
	public static final String CUSTOMIZE_QUOTE_PAGE_STL = "CustomizeQuoteSTLPage";
	public static final String THANK_YOU_PAGE_STL = "ThankYouSTLPage";
	public static final String CUSTOMIZE_QUOTE_PAGE_SWL = "CustomizeQuoteSWLPage";
	public static final String THANK_YOU_PAGE_SWL = "ThankYouSWLPage";
	public static final String MORE_INFO_PAGE_VTL = "MoreInfoVTLPage";
	public static final String LIFE_QUOTE_PAGE_VTL = "LifeQuoteVTLPage";
	public static final String THANK_YOU_PAGE_VTL = "ThankYouVTLPage";
	public static final String ADDRESS_PAGE = "AddressPage";
	public static final String ABOUT_YOU_PAGE = "AboutYouPage";
	public static final String HERES_WHAT_WE_KNOW = "HeresWhatWeKnowPage";

	//Retrieve quote objects
	public static final String AUTO_APPLICANT = "SqlApplicant";
	public static final String ACE_AUTO_APPLICANT = "AutoApplicant";
	public static final String ACE_AUTO_ADPF_APPLICANT = "ADPFApplicant";
	public static final String ACE_BUNDLE_APPLICANT = "AceBundleApplicant";
	public static final String ACE_HOME_APPLICANT = "ApplicantAceHome";
	public static final String BUSINESS_APPLICANT = "ApplicantBusiness";
	public static final String HOME_APPLICANT = "ApplicantHome";
	public static final String LIFE_APPLICANT = "ApplicantLife";
	public static final String RENTERS_APPLICANT = "ApplicantRenters";
	public static final String HQM_APPLICANT = "ApplicantHQM";

	public static final String ZERO = "0";
	public static final String ONE = "1";
	public static final String TWO = "2";

	// payPlan Descriptions
	public static final String MONTHLY_EFT = "Monthly EFT";
	public static final String MONTHLY_DEBIT_CREDIT_CARD = "Monthly Credit/Debit Card";
	public static final String MONTHLY_DEBIT_CARD_DESCRIPTION = "Monthly Debit Card";
	public static final String ONE_PAY = "1-Pay";

	//Methods name
	public static final String SAVE_AUTO_QUOTE = "getAutoQuoteForRetrieval";
	public static final String SAVE_AND_RETRIEVE_HOME_QUOTE = "saveAndRetrieveHomeQuotes";
	public static final String SAVE_AND_RETRIEVE_CONDO_QUOTE = "saveAndRetrieveCondoQuotes";
	public static final String SAVE_AND_RETRIEVE_RENTERS_QUOTE = "saveAndRetrieveRentersQuotes";
	public static final String MEDIA_ALPHA_TESTS = "mediaAlphaTests";
	public static final String CREATE_CROSS_SELL_AUTO_QUOTE = "createCrossSellAutoQuote";

	//Gender
	public static final String MALE = "Male";
	public static final String FEMALE = "Female";
	public static final String NONBINARY = "Nonbinary";
	public static final String NOT_SPECIFIED = "Not Specified";
	public static final String INTERSEX = "Intersex";

	//Marital status
	public static final String MARITAL_STATUS = "Marital Status";
	public static final String MARRIED = "Married";
	public static final String SEPARATED = "Separated";
	public static final String CIVIL_UNION = "Civil Union";
	public static final String WIDOWED = "Widowed";
	public static final String SINGLE = "Single";
	public static final String CIVIL_UNION_PARTNER = "Civil Union Partner";
	public static final String NON_DRIVING_SPOUSE = "NonDrivingSpouse";

	//Relation to
	public static final String GRANDCHILD = "Grandchild";
	public static final String PARENT = "Parent";
	public static final String RELATIVE = "Relative";
	public static final String SON = "Son";
	public static final String DAUGHTER = "Daughter";

	//Property
	public static final String PRIMARY = "Primary";

	//Property type
	public static final String HOUSE = "House";
	public static final String TOWNHOUSE = "Townhouse";

	//Package
	public static final String STANDARD = "Standard";
	public static final String ENHANCED = "Enhanced";
	public static final String PREMIER = "Premier";
	public static final String BASIC = "Basic";
	public static final String FULL = "Full";
    public static final String FULL_PRICING = "full pricing";
	public static final String ADDITIONAL = "Additional";

	//Occupations
	public static final String ACCOUNTANT = "Accountant";
	public static final String AIR_FORCE = "Air Force";
	public static final String ARCHITECT = "Architect";
	public static final String ARMY = "Army";
	public static final String AVIATOR = "Aviator";
	public static final String COAST_GUARD = "Coast Guard";
	public static final String DENTIST = "Dentist";
	public static final String EDUCATOR = "Educator";
	public static final String ENGINEER = "Engineer";
	public static final String FARMERS_ZURICH_EMPLOYEE = "Farmers/Zurich Employee";
	public static final String FARMERS_ZURICH = "Farmers/Zurich";
	public static final String FARMERS_EMPLOYEE = "Farmers Employee";
	public static final String FIG_FICU = "FIG FCU Member";
	public static final String FIREFIGHTER = "Firefighter";
	public static final String HONORABLY_DISCHARGED = "Honorably discharged";
	public static final String LAWYER_JUDGE = "Lawyer/Judge";
	public static final String LAW_ENFORCEMENT_OFFICER = "Law Enforcement Officer";
	public static final String LIBRARIAN = "Librarian";
	public static final String MARINE = "Marine";
	public static final String MILITARY = "Military";
	public static final String MILITARY_DASH_HONORABLY_DISCHARGED = "Military - Honorably Discharged";
	public static final String MILITARY_HONORABLY_DISCHARGED = "Military Honorably Discharged";
	public static final String MILITARY_PERSONNEL = "Military Personnel";
	public static final String NAVY = "Navy";
	public static final String NURSE = "Nurse";
	public static final String OTHER = "Other";
	public static final String PHYSICAL_THERAPIST = "Physical And Occupational Therapist";
	public static final String PHYSICIAN_REG_NURSE = "Physician/Registered Nurse";
	public static final String PHYSICIAN_RN = "Physician/RN";
	public static final String PHYSICIAN_SURGEON = "Physician/Surgeon";
	public static final String PROFESSIONAL_AVIATOR = "Professional Aviator";
	public static final String REAL_ESTATE_AGENT = "Real Estate Agent";
	public static final String RETIRED_BRISTOL_WEST = "Retired Bristol West Employees";
	public static final String RETIRED_LAW_ENFORCEMENT = "Retired Law Enforcement Officer";
	public static final String RETIRED_SCIENTIST = "Retired Scientist";
	public static final String RETIRED_TWENTYFIRST_CENTURY = "Retired 21Century Employees";
	public static final String RETIRED_TWENTYFIRST_SPACE_CENTURY = "Retired 21 Century Employees";
	public static final String RETIRED_VETERINARIAN = "Retired Veterinarian";
	public static final String SCIENTIST = "Scientist";
	public static final String SMALL_BUSINESS_POLICYHOLDER = "Small Business PolicyHolder";
	public static final String SPEECH_PATHOLOGIST = "Speech Audiologist And Pathologist";
	public static final String TWENTYFIRST_CENTURY = "21st Century Employees";
	public static final String VETERINARIAN = "Veterinarian";
	public static final String VETERINARIANS = "Veterinarians";
	public static final String WORKERS_COMPENSATION_POLICYHOLDER= "Workers Compensation PolicyHolder";
	public static final String ZURICH_EMPLOYEE = "Zurich Employee";

	// Other common strings
	public static final String ACCIDENT = "Accident";
	public static final String CITATION = "Citation";
	public static final String SPOUSE = "Spouse";
	public static final String YES = "Yes";
	public static final String NO = "No";
	public static final String NA = "N/A";
	public static final String NEW_QUOTE_NUMBER = "[New Quote Number] ";
	public static final String NONE = "None";
	public static final String DEFAULT_COVERAGE_VALIDATION = "Default coverage validation";
	public static final String PARTTIME = "PARTTIME";
	public static final String UNOCCUPIED = "UNOCCUPIED";
	public static final String RENT = "RENT";
	public static final String SHORTRENT_DWELLING = "SHORTRENT  RENT";
	public static final String SECONDARY = "SECONDARY";
	public static final List<String> LIST_OF_NONPRIMARY_REASONS = List.of(RENT, SHORTRENT_DWELLING, PARTTIME, UNOCCUPIED);

	//Discounts
	public static final String BUSINESS_PROFESSIONAL_GROUP = "Business/Professional Group";
	public static final String HOME_PROTECTION_AND_LOSS_PREVENTION_DISCOUNT = "Home Protection and Loss Prevention Discount";
	public static final String CLAIM_FREE_DISCOUNT = "Claim Free Discount";
	public static final String PREFERRED_PAYMENT_PLAN = "Preferred payment plan";
	public static final String NEW_ROOF_CURRENT = "New Roof (Current)";
	public static final String NEW_ROOF = "New Roof";
	public static final String NEW_HOME = "New Home";
	public static final String RETIREMENT_COMMUNITY_DISCOUNT = "Retirement Community";
	public static final String GOOD_PAYER_DISCOUNT = "Good Payer Discount";
	public static final String NON_SMOKER = "Non-smoker";
	public static final String FULL_SPRINKLER_SYSTEM = "Full Sprinkler System";
	public static final String CENTRAL_BURGLAR_FIRE_ALARM = "Central Burglar/Fire Alarm";
	public static final String AGE_FIFTY_PLUS = "Age 50 Plus";
	public static final String AGE_FORTY_PLUS = "Age 40 Plus";
	public static final String IRON_BARS = "Iron Bars";
	public static final String LOCAL_BURGLAR_ALARM = "Local Burglar Alarm";
	public static final String LOCAL_FIRE_ALARM = "Local Fire Alarm";
	public static final String CENTRAL_FIRE_ALARM = "Central Fire Alarm";
	public static final String FIRE_PROTECTION_DEVICE = "Fire Protection Discount";
	public static final String CENTRAL_BURGLAR_ALARM = "Central Burglar Alarm";
	public static final String HOME_SAFETY_DISCOUNT = "Home Safety Discount";
	public static final String HOME_SECURITY = "Home Security";
	public static final String THEFT_PROTECTION_DEVICE = "Theft Protection Discount";
	public static final String WELCOME = "Welcome";
	public static final String PAPERLESS = "Paperless";
	public static final String MATURE_DRIVER = "Mature driver";
	public static final String DEFENSIVE_DRIVER = "Defensive driver";
	public static final String DRIVER_IMPROVEMENT = "Driver Improvement";
	// Incomplete quote scenarios
	public static final String KNOCKOUT = "knockout";
	public static final String PAYMENT_KNOCKOUT = "payment knockout";
	public static final String PROPERTY_KNOCKOUT = "property knockout";
	public static final String QUOTE_KNOCKOUT = "quote knockout";
	public static final String SPECIAL_ATTENTION = "special attention";
	public static final String INCONVENIENCE = "inconvenience";

	public static final String AWS_REST_ZIP = "AWS Restricted ZIPcode";

	//Static text
	public static final String COLON = ":";
	public static final String SEMI_COLON = ";";
	public static final String PERIOD = ".";
	public static final String SPACE = " ";
	public static final String DOUBLE_SPACE = "  ";
	public static final String UNDERSCORE = "_";
	public static final String EMPTY_STRING = "";
	public static final String SINGLE_CHAR = "a";
	public static final String BACKSPACE = "\b";
	public static final String NEWLINE = "\n";
	public static final String FALSE = "FALSE";
	public static final String TRUE = "TRUE";
	public static final String OFF = "Off";
	public static final String ON = "On";
	public static final String LOWERCASE_FALSE = "false";
	public static final String LOWERCASE_TRUE = "true";
	public static final String LOWERCASE_NULL = "null";
	public static final String INVALID_ENTRY_NO_PERIOD = " is not a valid entry";
	public static final String INVALID_ENTRY = INVALID_ENTRY_NO_PERIOD + PERIOD;
	public static final String MM_DD_YYYY = "MM/dd/yyyy";
	public static final String MEDIUM = "medium";
	public static final String LARGE = "large";
	public static final String EXTRA_LARGE = "extraLarge";
	public static final String RENT_IT = "rentIt";
	public static final String USE_IT = "useIt";
	public static final String THANK_YOU_FOR_RETRIEVING_YOUR_QUOTE = "Thank you for retrieving your quote";
	public static final String NOT = " not ";

	public static final String YOUR_QUOTE_MAY_HAVE_CHANGED = "Your quote may have changed since the last time you stopped by.";
	public static final String CONTACT_TEXT = "If you would like to speak to a Farmers agent immediately, call 1-800-206-9469 to locate an agent in your area.";
	public static final String QUOTE_DISCLAIMER_STATIC_TEXT = "A preliminary rate (\"quote\") is for insurance coverage you select. Certain assumptions may have been made that will influence the quote you receive. A quote is not an offer for insurance or an offer of an insurance contract, nor is it an insurance contract, binder or an application to purchase insurance."
			+ " The coverage descriptions provided are general descriptions of available coverage. If there is any conflict between the general coverage descriptions provided in this quote and the policy documents, the policy documents control. Rates quoted reflect the rates in effect as of the date of this quote and are subject to revision."
			+ " Your actual premium may vary based upon additional information you provide or we obtain, the coverages and deductibles that you select, any additional underwriting criteria, and removal of any assumptions. Farmers reserves the right to accept, reject, or modify this quote after review of the application and other underwriting information. All applications are subject to underwriting approval."
			+ " Farmers online quotes are for new customers only. Existing customers are requested to contact their local agent to make changes to their policy. Quoted rates do not include fees permitted by state law. Not all products, coverages and discounts are available in every state.";
	public static final String QUOTE_DISCLAIMER_STATIC_TEXT2 = "A preliminary rate (\"quote\") is for insurance coverage you select. Certain assumptions may have been made that will influence the quote you receive. A quote is not an offer for insurance, an offer of an insurance contract, nor is it an insurance contract, binder or an application to purchase insurance."
			+ " The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract. Rates quoted reflect the rates in effect as of the date of this quote and are subject to revision."
			+ " Your actual premium may vary based upon additional information you provide or we obtain, the coverages and deductibles that you select, any additional underwriting criteria, and removal of any assumptions. Farmers reserves the right to accept, reject, or modify this quote after review of the application and other underwriting information."
			+ " All applications are subject to underwriting approval. Farmers online quotes are for new customers only. Existing customers are requested to contact their local agent to make changes to their policy. Quoted rates do not include fees permitted by state law.";
	public static final String MONTHLY_AMOUNT_TEXT = "*The amount shown applies when premium is paid automatically on a monthly basis. Monthly payment amount may be different if payments are not made automatically. The amount shown does not include monthly service fees." +
			" Amounts charged for service fees also differ based on billing and pay plan selections. Please see your Farmers agent for details.";
	public static final String MONTHLY_AMOUNT_TEXT_PART2 = "A preliminary rate (\"quote\") is for insurance coverage you select. A quote is not an offer for insurance, an offer of an insurance contract, an insurance contract, or an application to purchase insurance. The coverage descriptions provided are general descriptions of available coverage." +
			" If there is any conflict between the general coverage descriptions and the policy documents, the policy documents control. Rates quoted reflect the rates in effect as of the quote date and are subject to revision. Your actual premium may vary based upon additional information you provide or we obtain, the coverages and deductibles that you select," +
			" and any additional underwriting criteria. Farmers reserves the right to accept, reject, or modify this quote after review of the application and other underwriting information. All applications are subject to underwriting approval. Quoted rates do not include fees permitted by state law. Not all products, coverages and discounts are available in every state.";
	public static final String AMOUNT_DISCLAIMER_STATIC_TEXT = MONTHLY_AMOUNT_TEXT + SPACE + MONTHLY_AMOUNT_TEXT_PART2;
	public static final String FOOTER_DISCLAIMER_STATIC_TEXT = MONTHLY_AMOUNT_TEXT + SPACE + QUOTE_DISCLAIMER_STATIC_TEXT2 + SPACE + CONTACT_TEXT;
	public static final String BRIEF_SUMMARY_STATIC_TEXT = "1This brief summary is not a policy document. Please read the actual policy documents for your state for important details on coverages, exclusions , limits, conditions, and terms. If there is any conflict between this summary and the policy documents, the policy doucments will control. Not all products, coverages and discounts are available in every state.";
	public static final String BRIEF_SUMMARY_STATIC_TEXT2 = "Less in a few states.";
	public static final String NEVER_INSURED = "Never Insured";
	public static final String EXPIRED = "Expired";
	public static final String NOT_REQUIRED = "Not Required";
	public static final String DEPLOYED = "Deployed";

	// Life insurance disclaimers
	public static final String MERELY_A_QUOTE_DISCLAIMER = "This is merely a quote and does not create a policy of insurance or offer to insure."
			+ " Premiums quoted reflect the premiums in effect as of the date of this quote and are subject to change."
			+ " Farmers New World Life reserves the right to accept, reject, or modify this quote after review of the application and other underwriting information."
			+ " Life insurance issued by Farmers New World Life Insurance Company, 3120 139th Avenue SE, Suite 300, Bellevue, WA 98005."
			+ " Products and features may not be available in all states and may vary by state. Restrictions, exclusions, limits, and conditions apply."
			+ " Issuance of a policy and premiums are subject to underwriting guidelines and approval.";
	public static final String PRODUCT_GUARANTEE_DISCLAIMER = "Any product guarantees are subject to the financial strength and claims-paying ability of Farmers New World Life Insurance Company, which is solely responsible for the obligations under its own policies.";
	public static final String QUOTED_PREMIUM_DISCLAIMER = "Your quoted premium is based on your age, gender, and EFT billing, as well as the Underwriting Class determined by your nicotine usage (Select Non-Nicotine - non-nicotine, Select Nicotine - nicotine, or Juvenile)."
			+ " Riders are available at additional charge. In Montana, gender does not impact your quoted premium: premiums are Unisex.";

	//Common URLs
	public static final String FARMERS_COM = "https://www.farmers.com/";
	public static final String FGIA_URL = "https://quote-uat.farmersgeneralinsuranceagency.com";
	// HQM Call Farmers numbers
	public static final String CALL_FARMERS = "1-800-206-9469";
	public static final String CALL_FARMERS_EE = "1-888-767-4030";
	public static final String CALL_FARMERS_HQM_MONETIZATION = "1-855-888-2936";
	public static final String CALL_FARMERS_QUICKEN = "1-800-491-9927";
	public static final String CALL_FARMERS_MOBILE = "1-800-420-9008";
	public static final String CALL_FARMERS_MOBILE_HQM_MONETIZATION = "1-888-327-6345";
	public static final String CALL_FARMERS_MOBILE_MANUFACTURED_HOME = "1-888-587-2121";

	// HQM quote source indicators
	public static final String FC = "FC"; // political agent
	public static final String AS = "AS"; // exclusive agent
    public static final String AP = "AP"; // exclusive agent
	public static final String RQ = "RQ"; // retrieve quote
	public static final String QQ = "QQ"; // QuickenLoans lead
	public static final String QQNPS = "QQNPS"; //QuickenLoans lead, no PpcSrc
	public static final String AEM = "AEM"; //AEM Campaign source
	public static final String CW = "CW"; //CSS to FFQ Cross-sell
	public static final String MB = "MB"; //Mobile to FFQ Cross-sell
	public static final String MOBILE_BROWSER = "mobile"; //Mobile browser emulator source
	public static final String DESKTOP_BROWSER = "desktop"; //Desktop browser emulator source

	//log related values
	public static final String USER_DIR_PROPERTY = "user.dir";
	public static final String CREATED_QUOTES_FILE = System.getProperty(USER_DIR_PROPERTY) + "/build/policies.log";
	public static final String QUOTE_DATA_LOG_FILE = System.getProperty(USER_DIR_PROPERTY) + "/build/quoteDetails.log";
	public static final String RATED_QUOTES_FILE = System.getProperty(USER_DIR_PROPERTY) + "/build/rated.log";
	public static final String KNOCKOUT_QUOTE_DATA_LOG_FILE = System.getProperty(USER_DIR_PROPERTY) + "/build/knockouts.log";

	//Atomic test case reporting
	public static final String FAILED = "failed";
	public static final String PASSED = "passed";
	public static final String TEST_PASSED = "test " + PASSED;
	public static final String TEST_COMPLETED = "Test completed.";

	// Bdq flows
	public static final String BW_ORGANIC_FLOW = "BW Organic Flow";
	public static final String BW_CLICK_TO_BUY_FULL_FLOW = "BW Click to buy full flow";
	public static final String BW_MARKETING_ID_FLOW = "BW Marketing Id flow";
	public static final String BW_CLICK_TO_BUY_LITE_FLOW = "BW Click to buy lite flow";

	public static List<String> listOfAllStates(){
		return new ArrayList<>(Arrays.asList(AK, AL, AR, AZ, CA, CO, CT, DC, DE, FL, GA, HI, IA, ID, IL,
				IN, KS, KY, LA, MA, MD, ME, MI, MN, MO, MS, MT, NC, ND, NE, NH, NJ, NM, NV, NY,
				OH, OK, OR, PA, RI, SC, SD, TN, TX, UT, VA, VT, WA, WI, WV, WY));
	}

	public static final String CARD_NAME_VISA = "VISA";
	public static final String CARD_NAME_AMEX = "AMEX";
	public static final String CARD_NAME_MASTER = "MASTER";
	public static final String CARD_NAME_DISCOVER = "DISCOVER";

	public static final String MASTER_CARD = "5454545454545454";
	public static final String VISA_CREDIT_CARD = "4111111111111111";
	public static final String VISA_DEBIT_CARD = "4444424444444440";
	public static final String VISA_DEBIT_CARD_2 = "4400000000000008";
	public static final String AMERICAN_EXPRESS_CARD = "371449635398431";
	public static final String DISCOVER_CARD = "6011000995500000";
	public static final String CVV_NUMBER = "123";
	public static final String EXP_DATE = "12/33";
	public static final String ZIP_CODE = "12205";

	public static final String BOFA_ROUTING_NUMBER = "125000024";

	public static final String PRODUCTION_APPLICANT_EMAIL = "autobindoptout@yahoo.com";
	public static final String PRODUCTION_APPLICANT_LAST_NAME = "Ffqtest";
	public static final String PRODUCTION_APPLICANT_FIRST_NAME = "Evan";
	public static final String NEW_POLICY_AND_RENEWAL = "NewPolicyAndRenewal";
	public static final String RENEWAL = "Renewal";
	public static final String YES_CONTINUE = "Yes, continue";
	public static final String NO_THANK_YOU = "No, thank you";

	public static final List<String> STATE_WITH_500_DEFAULT_DEDUCTIBLE = Arrays.asList(CO, MI, PA, TX);

}
