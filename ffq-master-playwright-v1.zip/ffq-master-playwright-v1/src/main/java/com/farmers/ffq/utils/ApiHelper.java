package com.farmers.ffq.utils;

import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.datatransferobjects.hqm.*;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONObject;

import javax.annotation.Nullable;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ApiHelper extends AutomationFramework {

    private String getEventLogQuery(String quoteNumber, String milestoneDesc) {
        String schema = Property.getEnvironmentProperty("postgres_schema");
        return String.format("select response from %s.quote_event_log qe " +
                        "join %s.quote_milestone qm on qm.milestone_id=qe.milestone_id where qe.quote_number='%s' " +
                        "and qe.event_status='success' and qm.milestone_description='%s' order by event_date desc",
                schema, schema, quoteNumber, milestoneDesc);
    }

    public String getEventLogResponseByMilestoneDescription(String quoteNumber, String milestoneDesc) throws SQLException, IOException {
        String sqlQuery = getEventLogQuery(quoteNumber, milestoneDesc);
        return DbHelper.queryPostgresGetFirstRow(sqlQuery);
    }

    public String getEventLogResponseCount(String quoteNumber, String milestoneDesc, int count) throws SQLException, IOException {
        String sqlQuery = getEventLogQuery(quoteNumber, milestoneDesc);
        List<String> rows = DbHelper.queryPostgresGetAllRows(sqlQuery);
        for (int i = 0; rows.size() < count; i++) {
            if (i < 10) {
                sleep(5);
            } else {
                break;
            }
            rows = DbHelper.queryPostgresGetAllRows(sqlQuery);
        }
        return rows.get(0);
    }

    public String getEventLogRequestByMilestoneDescription(String quoteNumber, String milestoneDesc) throws SQLException, IOException {
        String schema = Property.getEnvironmentProperty("postgres_schema");
        String sqlQuery = String.format("select request from %s.quote_event_log qe " +
                        "join %s.quote_milestone qm on qm.milestone_id=qe.milestone_id where qe.quote_number='%s' " +
                        "and qe.event_status='success' and qm.milestone_description='%s' order by event_date desc",
                schema, schema, quoteNumber, milestoneDesc);
        return DbHelper.queryPostgresGetFirstRow(sqlQuery);
    }

    public PrefillResponseHQM getPropertyDataFromJson(String quoteNumber) throws SQLException, IOException {
        final String prefillForm = "PrefillResponse";
        final String milestoneDesc = "propertyrisk API response completed";
        String textQuoteResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        PrefillResponseHQM propertyData = null;
        if (textQuoteResponse != null) {
            String prefillJson = (new JSONObject(textQuoteResponse)).getJSONObject(prefillForm).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            propertyData = mapper.readValue(prefillJson, PrefillResponseHQM.class);
        }
        return propertyData;
    }

    public AutoRateQuoteResponseBean getAutoRateQuote(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "Perform Rate Quote Rest Service Ended";
        String textQuoteResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        AutoRateQuoteResponseBean autoRateQuote = null;
        if (textQuoteResponse != null) {
            String json = (new JSONObject(textQuoteResponse)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            autoRateQuote = mapper.readValue(json, AutoRateQuoteResponseBean.class);
        }
        return autoRateQuote;
    }


    public TnediccaServiceRequest getTnediccaServiceRequest(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "TNEDICCA Service Inititated";
        String textQuoteRequest = getEventLogRequestByMilestoneDescription(quoteNumber, milestoneDesc);
        TnediccaServiceRequest tnediccaServiceRequest = null;
        if (textQuoteRequest != null) {
            String json = (new JSONObject(textQuoteRequest)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            tnediccaServiceRequest = mapper.readValue(json, TnediccaServiceRequest.class);
        }
        return tnediccaServiceRequest;
    }

    public ADPFRequestPayload getAdpfCallPayload(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "ADPFService REST Service call Initiated";
        String textQuoteResponse = getEventLogRequestByMilestoneDescription(quoteNumber, milestoneDesc);
        ADPFRequestPayload aDPFRequestPayload = null;
        if (textQuoteResponse != null) {
            String json = (new JSONObject(textQuoteResponse)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            aDPFRequestPayload = mapper.readValue(json, ADPFRequestPayload.class);
        }
        return aDPFRequestPayload;
    }

    public AdpfServiceServiceCallEnd getAdpfCallResponsePayload(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "ADPFService REST Service call End";
        String textQuoteResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        AdpfServiceServiceCallEnd adpfServiceServiceCallEnd = null;
        if (textQuoteResponse != null) {
            String json = (new JSONObject(textQuoteResponse)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            adpfServiceServiceCallEnd = mapper.readValue(json, AdpfServiceServiceCallEnd.class);
        }
        return adpfServiceServiceCallEnd;
    }

    public ADPFServiceEnd getADPFServiceEnd(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "ADPF Service End";
        String textQuoteResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        ADPFServiceEnd	 aDPFServiceEnd = null;
        if (textQuoteResponse != null) {
            String json = (new JSONObject(textQuoteResponse)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            aDPFServiceEnd = mapper.readValue(json, ADPFServiceEnd.class);
        }
        return aDPFServiceEnd;
    }

    public SaveSignalDiscountServiceCallRequestPayload getSaveSignalDiscountRequestPayload(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "Save Signal Discount REST Service call Initiated";
        String textQuoteResponse = getEventLogRequestByMilestoneDescription(quoteNumber, milestoneDesc);
        SaveSignalDiscountServiceCallRequestPayload saveSignalDiscountServiceCallRequestPayload = null;
        if (textQuoteResponse != null) {
            String json = (new JSONObject(textQuoteResponse)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            saveSignalDiscountServiceCallRequestPayload = mapper.readValue(json, SaveSignalDiscountServiceCallRequestPayload.class);
        }
        return saveSignalDiscountServiceCallRequestPayload;
    }

    public FCCAuditServiceInitiated getFccAuditServiceRequestPayload(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "FCC Audit Service Initiated";
        String textQuoteResponse = getEventLogRequestByMilestoneDescription(quoteNumber, milestoneDesc);
        FCCAuditServiceInitiated fCCAuditServiceInitiated = null;
        if (textQuoteResponse != null) {
            String json = (new JSONObject(textQuoteResponse)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            fCCAuditServiceInitiated = mapper.readValue(json, FCCAuditServiceInitiated.class);
        }
        return fCCAuditServiceInitiated;
    }

    public FCCAuditServiceEnded getFccAuditServiceResponsePayload(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "FCC Audit Service Ended";
        String textQuoteResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        FCCAuditServiceEnded fccAuditServiceEnded = null;
        if (textQuoteResponse != null) {
            String json = (new JSONObject(textQuoteResponse)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            fccAuditServiceEnded = mapper.readValue(json, FCCAuditServiceEnded.class);
        }
        return fccAuditServiceEnded;
    }

    public ProjectCodeStatusServiceCallEnd getProjectCodeStatusServiceCallResponse(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "ProjectCodeStatus REST Service call End";
        String textQuoteResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        ProjectCodeStatusServiceCallEnd projectCodeStatusServiceCallEnd = null;
        if (textQuoteResponse != null) {
            String json = (new JSONObject(textQuoteResponse)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            projectCodeStatusServiceCallEnd = mapper.readValue(json, ProjectCodeStatusServiceCallEnd.class);
        }
        return projectCodeStatusServiceCallEnd;
    }

    public RateQuoteServiceInitiated getRateQuoteServiceInitiated(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "Rate Quote Service Initiated";
        String textQuoteResponse = getEventLogRequestByMilestoneDescription(quoteNumber, milestoneDesc);
        RateQuoteServiceInitiated rateQuoteServiceInitiated = null;
        if (textQuoteResponse != null) {
            String json = (new JSONObject(textQuoteResponse)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            rateQuoteServiceInitiated = mapper.readValue(json, RateQuoteServiceInitiated.class);
        }
        return rateQuoteServiceInitiated;
    }


    public BristolWestRateQuoteInitiated getBristolWestRateQuoteInitiated(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "Bristol West Rate Quote Initiated";
        String xmlQuoteResponse = getEventLogRequestByMilestoneDescription(quoteNumber, milestoneDesc);
        BristolWestRateQuoteInitiated bristolWestRateQuoteInitiated = null;

        if (xmlQuoteResponse != null && !xmlQuoteResponse.isBlank()) {
            XmlMapper xmlMapper = new XmlMapper();
            xmlMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            // Optional: clean up XML if wrapped in SOAP or has BOM
            xmlQuoteResponse = xmlQuoteResponse.replaceFirst("^[\\uFEFF\\u200B]+", "").trim();

            bristolWestRateQuoteInitiated = xmlMapper.readValue(xmlQuoteResponse, BristolWestRateQuoteInitiated.class);
        }
        return bristolWestRateQuoteInitiated;
    }


    public AutoQuoteVerifyServiceInitiated getAutoQuoteVerifyServiceInitiated(String quoteNumber) throws SQLException, IOException {
        String schema = Property.getEnvironmentProperty("postgres_schema");
        String sqlQuery = String.format("select request from %s.bind_event_log qel where qel.quote_number = '%s' and event_status='success' and event_point ='Auto Quote Verify Service Started' order by event_date desc",
                schema, quoteNumber);

        String testQuoteRequest = DbHelper.queryPostgresGetFirstRow(sqlQuery);
        AutoQuoteVerifyServiceInitiated autoQuoteVerifyServiceInitiated = null;
        if (testQuoteRequest != null) {
            String json = (new JSONObject(testQuoteRequest)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            autoQuoteVerifyServiceInitiated = mapper.readValue(json, AutoQuoteVerifyServiceInitiated.class);
        }
        return autoQuoteVerifyServiceInitiated;
    }

    public BWAutoVerifyServiceStarted getBwAutoQuoteVerifyServiceInitiated(String quoteNumber) throws SQLException, IOException {
        String schema = Property.getEnvironmentProperty("postgres_schema");
        String sqlQuery = String.format("select request from %s.bind_event_log qel where qel.quote_number = '%s' and event_status='success' and event_point ='BW Auto Verify Service Started' order by event_date desc",
                schema, quoteNumber);

        String testQuoteRequest = DbHelper.queryPostgresGetFirstRow(sqlQuery);
        BWAutoVerifyServiceStarted bWAutoVerifyServiceStarted = null;
        if (testQuoteRequest != null) {
            String json = (new JSONObject(testQuoteRequest)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            bWAutoVerifyServiceStarted = mapper.readValue(json, BWAutoVerifyServiceStarted.class);
        }
        return bWAutoVerifyServiceStarted;
    }

    public BWCSSRegistrationEnded getBWCSSRegisterRestServiceEnded(String quoteNumber) throws SQLException, IOException {
        String schema = Property.getEnvironmentProperty("postgres_schema");
        String sqlQuery = String.format("select response from %s.bind_event_log qel where qel.quote_number = '%s' and event_status='success' and event_point ='BW CSS Registration Service Completed' order by event_date desc",
                schema, quoteNumber);

        String testQuoteRequest = DbHelper.queryPostgresGetFirstRow(sqlQuery);
        BWCSSRegistrationEnded bWCSSRegistrationEnded = null;
        if (testQuoteRequest != null) {
            String json = (new JSONObject(testQuoteRequest)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            bWCSSRegistrationEnded = mapper.readValue(json, BWCSSRegistrationEnded.class);
        }
        return bWCSSRegistrationEnded;
    }

    public IidResponseBean getIidResponse(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "IID Service End";
        String textQuoteResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        IidResponseBean iidResponseBean = null;
        if (textQuoteResponse != null) {
            String json = (new JSONObject(textQuoteResponse)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            iidResponseBean = mapper.readValue(json, IidResponseBean.class);
        }
        return iidResponseBean;
    }

    public CaptchaRequestBean getValidateandUpdateQuoteRequest(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "Validate HCaptcha Token REST Service call Initiated";
        String textQuoteRequest = getEventLogRequestByMilestoneDescription(quoteNumber, milestoneDesc);
        CaptchaRequestBean validateCaptchaBeanReq = null;

        if (textQuoteRequest != null) {
            String json = (new JSONObject(textQuoteRequest)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            validateCaptchaBeanReq = mapper.readValue(json, CaptchaRequestBean.class);
        }
        return validateCaptchaBeanReq;
    }

    public CaptchaResponseBean getValidateandUpdateQuoteResponse(String quoteNumber) throws SQLException, IOException {
        final String milestoneResponseDesc = "Validate HCaptcha Token REST Service call End";
        String textQuoteResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneResponseDesc);
        System.out.println(" ");
        System.out.println("textQuoteResponse: " + textQuoteResponse);
        CaptchaResponseBean validateCaptchaBeanRes = null;

        if (textQuoteResponse != null) {
            String json = (new JSONObject(textQuoteResponse)).toString();
            System.out.println("json: " + json);
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            System.out.println("mapper: " + mapper.readValue(json, CaptchaRequestBean.class));
            validateCaptchaBeanRes = mapper.readValue(json, CaptchaResponseBean.class);

        }
        System.out.println("validateCaptchaBeanRes : " + validateCaptchaBeanRes);

        return validateCaptchaBeanRes;
    }

    public BrightVerifyServiceRequest getAutoBrightVerifyRequest(String quoteNumber) throws SQLException, IOException {
        final String milestoneResponseDesc = "Bright Verify Service Inititated";
        String textQuoteRequest = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneResponseDesc);
        System.out.println(" ");
        System.out.println("textQuoteRequest: " + textQuoteRequest);
        BrightVerifyServiceRequest validateEmailRequestBean = null;
        if (textQuoteRequest != null) {
            String json = (new JSONObject(textQuoteRequest)).toString();
            System.out.println("json: " + json);
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            validateEmailRequestBean = mapper.readValue(json, BrightVerifyServiceRequest.class);

        }
        System.out.println("validateEmailRequestBean : " + validateEmailRequestBean);
        return validateEmailRequestBean;
    }


    public BrightVerifyServiceResponse getAutoBrightVerifyResponse(String quoteNumber) throws SQLException, IOException {
        final String milestoneResponseDesc = "Brite Verify Service Ended";
        Log.info("Getting " + milestoneResponseDesc + " for " + quoteNumber);
        String textQuoteResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneResponseDesc);
        System.out.println(" ");
        System.out.println("textQuoteResponse: " + textQuoteResponse);
        BrightVerifyServiceResponse validateEmailResponseBean = null;
        if (textQuoteResponse != null) {
            String json = (new JSONObject(textQuoteResponse)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            validateEmailResponseBean = mapper.readValue(json, BrightVerifyServiceResponse.class);
        }
        System.out.println("validateEmailResponseBean : " + validateEmailResponseBean);
        return validateEmailResponseBean;
    }

    public LineTypeIntelligenceRequest getLineTypeIntelligenceServiceInitiated(String quoteNumber) throws SQLException, IOException {
        final String milestoneResponseDesc = "Line Type Intelligence Service Initiated";
        Log.info("Getting " + milestoneResponseDesc + " for " + quoteNumber);
        String textQuoteResponse = getEventLogRequestByMilestoneDescription(quoteNumber, milestoneResponseDesc);
        LineTypeIntelligenceRequest lineTypeIntelligenceRequest = null;
        if (textQuoteResponse != null) {
            String json = (new JSONObject(textQuoteResponse)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            lineTypeIntelligenceRequest = mapper.readValue(json, LineTypeIntelligenceRequest.class);
        }
        return lineTypeIntelligenceRequest;
    }

    public AutoFetchCoverageDropdowns getAutoFetchCoverageDropdownsResponse(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "FetchCoverage Dropdown REST Service call End";
        String textFetchCoverageDropdownsResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        AutoFetchCoverageDropdowns autoFetchCoverageDropdowns = null;
        if (textFetchCoverageDropdownsResponse != null) {
            String json = (new JSONObject(textFetchCoverageDropdownsResponse)).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            autoFetchCoverageDropdowns = mapper.readValue(json, AutoFetchCoverageDropdowns.class);
        }
        return autoFetchCoverageDropdowns;
    }

    public AutoQuoteReviewSummary getStaticContentV2ResponseAuto() throws IOException {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(Property.getEnvironmentProperty("staticContentV2"))
                .get()
                .addHeader("Accept", "text/plain")
                .build();

        Response response = client.newCall(request).execute();
        String sResponse = Objects.requireNonNull(response.body()).string();


        String reviewQuoteJson = (new JSONObject(sResponse)).getJSONObject("auto").getJSONObject("reviewQuote").toString();
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        return mapper.readValue(reviewQuoteJson, AutoQuoteReviewSummary.class);
    }

    public PrefillResponseHQM getPropertyData(ApplicantHQM applicant, String quoteNumber,
                                              @Nullable PrefillResponseHQM propertyData) throws SQLException, IOException {
        if (applicant.keep360Prefill) {
            if ((propertyData == null) || !propertyData.isPropertyDetailsForm() || !propertyData.isQualityGradeForm()) {
                propertyData = this.getPropertyDataFromJson(quoteNumber);
            }
        }
        return propertyData;
    }

    public List<String> getDiscountsFromJsonBeforeRate(String quoteNumber) throws SQLException, IOException {
        final String milestoneDesc = "getDiscounts service end";
        String textQuoteResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        String responseName = "GetDiscountsResponse";
        List<String> discountsBeforeRate = new ArrayList<>();
        if (textQuoteResponse != null) {
            JSONObject quoteJson = new JSONObject(textQuoteResponse);
            for (int i = 0; i < quoteJson.getJSONObject(responseName).getJSONArray("discounts").length(); i++) {
                JSONObject formJson = quoteJson.getJSONObject(responseName).getJSONArray("discounts").getJSONObject(i);
                if (formJson.has("webDesc")) {
                    discountsBeforeRate.add(formJson.getString("webDesc").toLowerCase());
                }
            }
        }
        Log.info("\nDiscounts Before Rate: " + discountsBeforeRate + "\n");
        return discountsBeforeRate;
    }

    public QuoteRateHQM getQuoteRateFromJson(String quoteNumber, String quoteType) throws SQLException, IOException {
        String quoteRateForm;
        String milestoneDesc;
        if (quoteType.equalsIgnoreCase("basic")) {
            quoteRateForm = "BasicRateQuoteResponseBean";
            milestoneDesc = "Home: Rate Quote Service Ended";
        } else if (quoteType.equalsIgnoreCase("custom")) {
            milestoneDesc = "Custom Rate Quote Service Ended";
            quoteRateForm = "CustomRateQuoteResponseBean";
        } else {
            Log.error("Unrecognized quote type: " + quoteType);
            return null;
        }
        QuoteRateHQM quoteRateHQM = null;
        String textQuoteResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        if (textQuoteResponse != null) {
            String quoteJson = (new JSONObject(textQuoteResponse)).getJSONObject(quoteRateForm).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            quoteRateHQM = mapper.readValue(quoteJson, QuoteRateHQM.class);
        }
        return quoteRateHQM;
    }

    public String getQuoteRateFailedFromJson(String quoteNumber) throws SQLException, IOException {
        String milestoneDesc = "Home: Rate Quote REST Service call End";
        String schema = Property.getEnvironmentProperty("postgres_schema");
        String sqlQuery = String.format("select response from %s.quote_event_log qe " +
                        "join %s.quote_milestone qm on qm.milestone_id=qe.milestone_id where qe.quote_number='%s' " +
                        "and qe.event_status='failure' and qm.milestone_description='%s' order by event_date desc",
                schema, schema, quoteNumber, milestoneDesc);
        return DbHelper.queryPostgresGetFirstRow(sqlQuery);
    }

    public QuoteRateHQM getQuoteRateFromJson(String quoteNumber, String quoteType, int count) throws IOException, SQLException {
        String quoteRateForm;
        String milestoneDesc;
        if (quoteType.equalsIgnoreCase("basic")) {
            quoteRateForm = "BasicRateQuoteResponseBean";
            milestoneDesc = "Home: Rate Quote Service Ended";
        } else if (quoteType.equalsIgnoreCase("custom")) {
            milestoneDesc = "Custom Rate Quote Service Ended";
            quoteRateForm = "CustomRateQuoteResponseBean";
        } else {
            Log.error("Unrecognized quote type: " + quoteType);
            return null;
        }
        QuoteRateHQM quoteRateHQM = null;
        String textQuoteResponse = getEventLogResponseCount(quoteNumber, milestoneDesc, count);
        if (textQuoteResponse != null) {
            String quoteJson = (new JSONObject(textQuoteResponse)).getJSONObject(quoteRateForm).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            quoteRateHQM = mapper.readValue(quoteJson, QuoteRateHQM.class);
        }
        return quoteRateHQM;
    }

    public AgentInfoHQM getAgentInfoFromJson(String quoteNumber) throws SQLException, IOException {
        String agentInfoForm = "AgentAssignmentResponseBean";
        String milestoneDesc = "assignAgent API ended";
        String textAgentInfoResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        AgentInfoHQM agentInfoHQM = null;
        if (textAgentInfoResponse != null) {
            String infoJson = (new JSONObject(textAgentInfoResponse)).getJSONObject(agentInfoForm).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            agentInfoHQM = mapper.readValue(infoJson, AgentInfoHQM.class);
        }
        return agentInfoHQM;
    }

    public PrintInfoHQM getPrintInfoFromJson(String quoteNumber) throws SQLException, IOException {
        String printInfoForm = "PrintResponseBean";
        String milestoneDesc = "Print API Ended";
        String textPrintInfoResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        PrintInfoHQM printInfoHQM = null;
        if (textPrintInfoResponse != null) {
            String infoJson = (new JSONObject(textPrintInfoResponse)).getJSONObject(printInfoForm).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            printInfoHQM = mapper.readValue(infoJson, PrintInfoHQM.class);
        }
        return printInfoHQM;
    }

    public CrossSellInfoHQM getCrossSellFromJson(String quoteNumber) throws SQLException, IOException {
        String crossSellInfoForm = "CrossSellOptionsResponseBean";
        String milestoneDesc = "Get Cross Sell Options API Ended";
        String textCrossSellResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        CrossSellInfoHQM crossSellInfo = null;
        if (textCrossSellResponse != null) {
            String infoJson = (new JSONObject(textCrossSellResponse)).getJSONObject(crossSellInfoForm).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            crossSellInfo = mapper.readValue(infoJson, CrossSellInfoHQM.class);
        }
        return crossSellInfo;
    }

    public EmailHQM getEmailRequestFromJson(String quoteNumber) throws SQLException, IOException {
        String emailForm = "sendEmail";
        String milestoneDesc = "Email Send Serivce Initiated";
        String textEmailRequest = getEventLogRequestByMilestoneDescription(quoteNumber, milestoneDesc);
        EmailHQM emailHQM = null;
        if (textEmailRequest != null) {
            String infoJson = (new JSONObject(textEmailRequest)).getJSONObject(emailForm).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            emailHQM = mapper.readValue(infoJson, EmailHQM.class);
        }
        return emailHQM;
    }

    public NotificationHQM getNotificationRequestFromJson(String quoteNumber) throws SQLException, IOException {
        String notificationForm = "notification";
        String milestoneDesc = "Text Send Service Initiated";
        String textNotificationRequest = getEventLogRequestByMilestoneDescription(quoteNumber, milestoneDesc);
        NotificationHQM notificationHQM = null;
        if (textNotificationRequest != null) {
            String infoJson = (new JSONObject(textNotificationRequest)).getJSONObject(notificationForm).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            notificationHQM = mapper.readValue(infoJson, NotificationHQM.class);
        }
        return notificationHQM;
    }

    public List<String> getOccupations(String stateCode) throws SQLException, IOException {
        String sqlQuery = String.format("select trim(ffq_occupation_desc) from %s.tcustomer_occupation where state_group_cd='%s' " +
                "and (exp_dt is null or exp_dt > now()) order by ffq_occupation_desc", Property.getEnvironmentProperty("postgres_schema"), stateCode);
        return DbHelper.queryPostgresGetAllRows(sqlQuery);
    }

    public String getCampaignPhoneNumber(String quoteNumber, String campaignId) throws IOException, SQLException {
        String phoneNumbersInfoForm = "AEMPhoneNumberResponse";
        String phoneNumbersMapping = "sourcePhoneNumberMapping";
        String milestoneDesc = "Get AEM Phone number API Ended";
        String textResponse = null;
        for (int i = 0; i < 3; i++) {
            textResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
            if (textResponse != null) {
                break;
            } else {
                Log.info("Going to re-try Get AEM phone number Postgres SQL query: " + i);
                sleep(2);
            }
        }
        String phoneNumber = null;
        if (textResponse != null) {
            JSONObject quoteJson = new JSONObject(textResponse);
            for (int i = 0; i < quoteJson.getJSONObject(phoneNumbersInfoForm).getJSONArray(phoneNumbersMapping).length(); i++) {
                JSONObject formJson = quoteJson.getJSONObject(phoneNumbersInfoForm).getJSONArray(phoneNumbersMapping).getJSONObject(i);
                if (formJson.getString("src").equals(campaignId)) {
                    phoneNumber = formJson.getString("number");
                    break;
                }
            }
        }
        return phoneNumber;
    }

    public StaticContentHQM getStaticContentFromJson(String quoteNumber) throws SQLException, IOException {
        String staticContentForm = "StaticContentResponseBean";
        String milestoneDesc = "Get AEM Static content API Ended";
        StaticContentHQM staticContent = null;
        String textStaticContentResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        if (textStaticContentResponse != null) {
            textStaticContentResponse = textStaticContentResponse.replace("\\\\\\\\\\\\", "\\").replace("\\\\\\\"", "\\\"")
                    .replace("\\\\\"", "\\\"").replace("\\\\\\", "");
            String infoJson = (new JSONObject(textStaticContentResponse)).getJSONObject(staticContentForm).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            staticContent = mapper.readValue(infoJson, StaticContentHQM.class);
        }
        return staticContent;
    }

    public StartQuoteHQM getStartQuoteFromJson(String quoteNumber) throws SQLException, IOException {
        String startQuoteForm = "StartQuoteResponseBean";
        String milestoneDesc = "StartQuote REST Service call End";
        StartQuoteHQM startQuoteHQM = null;
        String textQuoteResponse = getEventLogResponseByMilestoneDescription(quoteNumber, milestoneDesc);
        if (textQuoteResponse != null) {
            String quoteJson = (new JSONObject(textQuoteResponse)).getJSONObject(startQuoteForm).toString();
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            startQuoteHQM = mapper.readValue(quoteJson, StartQuoteHQM.class);
        }
        return startQuoteHQM;
    }
}
