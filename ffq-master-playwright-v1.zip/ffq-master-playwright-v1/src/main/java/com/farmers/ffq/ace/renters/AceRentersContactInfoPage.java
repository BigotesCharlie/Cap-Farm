package com.farmers.ffq.ace.renters;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.ace.hrc.common.AceHRCContactInfoBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import java.util.ArrayList;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersContactInfoPage extends AceHRCContactInfoBasePage {

    @PWFindBy(xpath = "//button[contains(@class,'rentersContinueCta')]")
    protected PWElement continueToQuoteButton;
    private static final String STORM_SHUTTER_CHECKBOX_XPATH = "//div[@id='stormShutter']";
    @PWFindBy(xpath = STORM_SHUTTER_CHECKBOX_XPATH + "//mat-checkbox")
    private PWElement stormShutterCheckbox;
    @PWFindBy(xpath = STORM_SHUTTER_CHECKBOX_XPATH + "//mat-label")
    private PWElement stormShutterCheckboxLabel;
    @PWFindBy(xpath = "//div[@id='homeDiscountsDiv']//span[contains(text(), 'Does this apply to your home?')]")
    private PWElement doesThisApplyToYourHome;
    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceRentersContactInfoPage() throws Exception {
    }

    public void clickContinueToQuoteButton() {
        clickElement(continueToQuoteButton);
    }

    public void fillOutContactInfoPageRenters(ApplicantAceHome applicant) throws Exception {
        enterPolicyStartDate(applicant);
        enterFireHydrantData(applicant);
        fillOutBundleAndSave(applicant, RENTERS);
        clickContinueToQuoteButton();
    }

    public void validateContentOfStormShutterSection(FarmersSoftAssert fsa, String stateCode) throws Exception {
        if (stateCode.equals(MD)) {
            fsa.assertTrue(doesThisApplyToYourHome.isDisplayed(), "Does this apply to your home question validation");
            fsa.assertTrue(stormShutterCheckbox.isDisplayed(), "Storm shutter checkbox displayed");
            fsa.assertTrue(!getAttributeData(stormShutterCheckbox, CLASS).contains(MAT_CHECKBOX_CHECKED), "Storm shutter checkbox unchecked on initial load.");

            String expectedStormShutterCheckBoxCheckboxLabel = "It has permanently installed storm shutters on all windows in the dwelling.";
            fsa.assertEquals(getTextFromElement(stormShutterCheckboxLabel), expectedStormShutterCheckBoxCheckboxLabel, "Storm shutter checkbox label verification.");

            checkUncheckMatCheckbox(STORM_SHUTTER_CHECKBOX_XPATH, true);
            fsa.assertTrue(getAttributeData(stormShutterCheckbox, CLASS).contains(MAT_CHECKBOX_CHECKED), "Storm shutter checkbox checked.");
            checkUncheckMatCheckbox(STORM_SHUTTER_CHECKBOX_XPATH, false);
            fsa.assertTrue(!getAttributeData(stormShutterCheckbox, CLASS).contains(MAT_CHECKBOX_CHECKED), "Storm shutter checkbox unchecked.");
        }
    }

    public void validateContinueButtonText(FarmersSoftAssert fsa){
        fsa.assertEquals(getTextFromElement(continueToQuoteButton), "Continue to quote", "Continue to quote button validation");
    }

}
