package com.farmers.ffq.ace.mobilehome;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import static java.util.Map.entry;
import java.util.stream.Collectors;

import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.common.enums.CoveragesNameVsDescriptionInfoSideSheetAceHome.CoverageInfoDetails;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Home;
import com.farmers.ffq.datatransferobjects.AppStore.Home.Coverage;
import com.farmers.ffq.datatransferobjects.AppStore.Home.Discounts;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class AceMobileQuoteReviewPage extends AceHRCBasePage {

	private static final String WIND_AND_HAIL = "Wind and Hail";
	private static final String PERSONAL_EFFECTS = "Personal effects";
	private static final String MEDICAL_PAYMENTS_TO_OTHERS = "Medical payments to others";
	private static final String PERSONAL_LOWERCASEPROPERTY = "Personal property";
	private static final String PREMISES_LOWERCASELIABILITY = "Premises liability";
	private static final String FIRE_DEPARTMENT_SERVICE_CHARGE = "Fire department service charge";
	private static final String REPLACEMENT_COST = "Replacement cost";
	private static final String MEDICAL_PAYMENTS = "Medical payments";
	private static final String PERSONAL_LIABILITY = "Personal Liability";
	private static final String PERSONAL_LOWERCASELIABILITY = "Personal liability";
	private static final String ADDITIONAL_LIVING_EXPENSES = "Additional living expenses";
	private static final String PREMISES_LIABILITY = "Premises Liability";
	private static final String EXTENDED_REPLACEMENT_COST = "Extended replacement cost";
	private static final String PERSONAL_PROPERTY = PERSONAL_LOWERCASEPROPERTY;
	private static final String DWELLING = "Dwelling";
	private static final String MOBILE_HOME = "Mobile home";
	private static final String ADJACENT_STRUCTURES = "Adjacent structures";
	private static final String OTHER_STRUCTURES = "Other structures";
	private static final String PERSONAL_PROPERTY_ACV = "Personal property (Actual cash value)";
	private static final String PERSONAL_EFFECTS_ACV = "Personal effects (Actual cash value)";

	@PWFindBy(xpath = "//app-mobilehome-review-page//h1")
	private PWElement quoteReviewPageTitle;

	@PWFindBy (xpath = "//mat-card//div[contains(@class, 'call-agent-icon')]/img")
	private PWElement quoteReviewPageAgentIcon;
	@PWFindBy (xpath = "//mat-card/div[contains(@class, 'call-agent-content')]")
	private PWElement quoteReviewPageSubtitle;

	private static final String POLICY_DEDUCTIBLES_XPATH = "//app-mobilehome-coverage//h2[contains(@class, 'bold')]";
	@PWFindBy (xpath = POLICY_DEDUCTIBLES_XPATH)
	private PWElement policyDeductiblesSectionHeader;
	@PWFindBy (xpath = POLICY_DEDUCTIBLES_XPATH + "/following-sibling::p")
	private PWElement policyDeductiblesSectionDescription;
	@PWFindBy (xpath = "//div[contains (@class, 'deductible-item')]//div/span[not(contains(@class, 'bold'))]")
	private List<PWElement> listOfPolicyDeductibles;
	@PWFindBy (xpath = "//div[contains (@class, 'deductible-item')]//div/span[contains(@class, 'bold')]")
	private List<PWElement> listOfPolicyDeductibleAmounts;

	private static final String COVERAGES_XPATH = "//div[contains(@class, 'mobilehome-card-body')]";
	private static final String PRIMARY_COVERAGES_CARD_XPATH = COVERAGES_XPATH + "[1]";
	private static final String PRIMARY_COVERAGE_CONTENT_XPATH = PRIMARY_COVERAGES_CARD_XPATH + "//div[contains(@class, 'py-3')]";

	@PWFindBy (xpath = "//div[contains(@class, 'card-header mobilehome-header')]")
	private PWElement ratedAmountInCard;
	@PWFindBy (xpath = PRIMARY_COVERAGES_CARD_XPATH + "//div[contains(@class, 'py-2')]")
	private PWElement primaryCoveragesSectionHeader;
	@PWFindBy (xpath = PRIMARY_COVERAGE_CONTENT_XPATH + "//div[contains(@class, 'coverage-desktop')]")
	private List<PWElement> desktopListOfPrimaryCoverageLabels;
	@PWFindBy (xpath = PRIMARY_COVERAGE_CONTENT_XPATH + "//div[contains(@class, 'coverage-mobile')]")
	private List<PWElement> mobilelistOfPrimaryCoverageLabels;
	@PWFindBy (xpath = PRIMARY_COVERAGE_CONTENT_XPATH + "//span[contains(@class, 'bold')]")
	private List<PWElement> listOfPrimaryCoverageAmounts;
	@PWFindBy (xpath = "//button[contains(@class, 'mobilehome-info-icon-button')]")
	private List<PWElement> listOfCoverageHelpLinks;

	private static final String ADDITIONAL_COVERAGES_CARD_XPATH = COVERAGES_XPATH + "[2]";
	@PWFindBy (xpath = ADDITIONAL_COVERAGES_CARD_XPATH + "//div[contains(@class, 'tui-body')]")
	private List<PWElement> listOfAdditionalCoverageLabels;
	@PWFindBy (xpath = ADDITIONAL_COVERAGES_CARD_XPATH + "//div[contains(@class, 'py-3')]//span[contains(@class, 'bold')]")
	private List<PWElement> listOfAdditionalCoverageAmounts;

	@PWFindBy(xpath = "//div[@class='heading-area']//*[contains(@class, 'tui-subtitle-text')]")
	private PWElement infoSideSheetTitle;
	@PWFindBy(className = "intro-section")
	private PWElement infoSideSheetSubtitle;
	@PWFindBy(xpath = "//app-mobilehome-coverage-descriptions-dialog//button[@aria-label='Close']")
	private PWElement closeInfoSideSheetButton;
	@PWFindBy(xpath = "//mat-panel-title//div")
	private List<PWElement> listOfCoverageTitlesInSideSheet;
	@PWFindBy(xpath = "//mat-expansion-panel[contains(@class, 'mat-expanded')]//mat-panel-title")
	private List<PWElement> listOfCoverageTitlesWithExpandedHelpSections;
	@PWFindBy (xpath = "//mat-expansion-panel[contains(@class, 'mat-expanded')]//div[contains(@class,'mat-expansion-panel-body')]")
	private List<PWElement> listOfCoverageDescriptionsWithExpandedHelpSections;

	@PWFindBy (xpath = "//div[contains(@class, 'mobilehome-policy-banner')]//h2")
	private PWElement includedInPolicyHeader;
	@PWFindBy (xpath = "//div[@class='mobilehome-policy-banner_list-card']//*[self::mat-icon or self::i]")
	private List<PWElement> listOfCoverageIcons;
	@PWFindBy (className = "mobilehome-policy-banner_description")
	private List<PWElement> listOfCoverageDescriptions;

	private static final String DISCLAIMER_CARD_XPATH = "//div[contains(@class, 'disclaimer')]//mat-card";
	@PWFindBy (xpath = DISCLAIMER_CARD_XPATH + "//h2")
	private PWElement disclaimerCardHeader;
	@PWFindBy (xpath = DISCLAIMER_CARD_XPATH + "//p")
	private List<PWElement> listOfDisclaimerCardContent;

	private static final String DESKTOP_QUOTE_SUMMARY_CARD_XPATH = "//app-mobilehome-review-page//mat-card[contains(@class,'tui-quote-presentment-desktop')]";
	private static final String MOBILE_QUOTE_SUMMARY_CARD_XPATH = "//app-mobilehome-review-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]";
	private static final String TERM_LABEL_XPATH = "//div[contains(@class, 'price-description')]";
	private static final String CARD_QUOTE_AMOUNT_XPATH = "//tui-price";

	@PWFindBy (xpath = "//*[contains(@class,'discounts-included')]")
	private PWElement discountIncludedLabel;
	@PWFindBy (xpath = "//mat-list//mat-icon")
	private PWElement discountIncludedCheckmarkIcon;
	@PWFindBy (xpath = "//app-home-discount//p[contains(@class, 'subtitle')]")
	private PWElement discountsAppliedLabel;
	@PWFindBy (xpath = "//app-home-discount//p[contains(@class, 'link')]")
	private PWElement reviewDiscountsLink;
	@PWFindBy(xpath = "//app-home-discount-sidesheet//button[@aria-label='Close']")
	private PWElement closeDiscountsAppliedSidesheetButton;

	boolean isForemostQuote;
	boolean isForemostAffiliateQuote;
	boolean isAlternateLabelState;
	boolean isApplicantLandlord;
	boolean isMobilehomeVacant;
	boolean isSecondaryOrSeasonalResidence;
	boolean retrievedQuote = false;

	public AceMobileQuoteReviewPage(ApplicantAceHome mobilehomeApplicant) throws Exception {
		super();
		isForemostQuote = mobilehomeApplicant.getTestCategory().equals(FOREMOST);
		isForemostAffiliateQuote  = mobilehomeApplicant.getTestCategory().equals(USAA);
		isAlternateLabelState = List.of(NC, TX).contains(mobilehomeApplicant.getStateCode());
		isApplicantLandlord = !mobilehomeApplicant.isPrimaryResidence() && mobilehomeApplicant.getReasonWhyNotPrimaryResidence().equals("RENT");
		isMobilehomeVacant = !mobilehomeApplicant.isPrimaryResidence() && mobilehomeApplicant.getReasonWhyNotPrimaryResidence().equals(UNOCCUPIED);
		isSecondaryOrSeasonalResidence = !mobilehomeApplicant.isPrimaryResidence() && mobilehomeApplicant.getReasonWhyNotPrimaryResidence().equals(PARTTIME);
	}

	public boolean isOnMobileHomeQuotePage() {
		return isElementVisible(quoteReviewPageSubtitle, 5);
	}

	public void setRetrievedQuoteFlag() {
		retrievedQuote = true;
	}

	public void verifyPageContent(ApplicantAceHome mobilehomeApplicant, FarmersSoftAssert fsa) throws Exception {
		String testCategory = mobilehomeApplicant.getTestCategory();
		boolean isAWSQuote = testCategory.equals(AWS_SCENARIOS);
		String activeStep = getActiveStep(testCategory);
		String separator = isSafariBrowser()? EMPTY_STRING : SPACE;
    	String phoneNumber = isForemostQuote?"855-497-0352": isForemostAffiliateQuote? "800-315-1122": "888-902-1896";
    	String callUs = isForemostAffiliateQuote? "Call Foremost at " + phoneNumber + " to customize." : "Call " + phoneNumber + " to get started.";
		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.enable(SerializationFeature.INDENT_OUTPUT);
			String json = mapper.writeValueAsString(getSessionStorageAppStore());
			writeDataToQuoteLogFile("App store content: " + json);
		} catch (Exception e) {
			Log.warn("EXCEPTION while beautifying appstore");
			writeDataToQuoteLogFile("Exception - App store content: " + getSessionStorageAppStore());
		}
		if (!isForemostQuote) {
			verifyMobileHomeCommonHeader(fsa, isForemostAffiliateQuote);
		}
		fsa.assertEquals(getTextFromElement(quoteReviewPageTitle), "Initial estimate", "Quote Page title verification.");
		fsa.assertTrue(isElementDisplayed(quoteReviewPageAgentIcon, 2), "Customer service icon is present");
        String whoPutTogether = isForemostAffiliateQuote? "Foremost ": "We've ";
		fsa.assertEquals(getTextFromElement(quoteReviewPageSubtitle), "Thank you!" + separator + whoPutTogether +"put together a quote based on our most popular coverages. " +
				"Give us a call to discuss more coverage options, to see more ways to save, and to buy your policy! " +
				callUs, "Quote page subtitle verification.");
		fsa.assertEquals(getTextFromElement(policyDeductiblesSectionHeader), "Policy deductibles", "Policy deductibles section header verification.");
		fsa.assertEquals(getTextFromElement(policyDeductiblesSectionDescription), "Your out-of-pocket cost for a covered loss.", "Policy deductibles section description verification.");
		List<String> listOfObservedPolicyDeductibles = listOfPolicyDeductibles.stream().map(this::getTextFromElement).collect(Collectors.toList());
		List<String> listOfObservedPolicyDeductibleAmounts = listOfPolicyDeductibleAmounts.stream().map(this::getTextFromElement).collect(Collectors.toList());
		List<String> listOfAppstorePolicyDeductibles = getListOfPolicyDeductiblesFromAppstore();
		List<String> listOfExpectedPolicyDeductibles = getExpectedPolicyDeductiblesList(mobilehomeApplicant);
		List<String> listOfExpectedPolicyDeductibleAmounts = new ArrayList<>();
		listOfAppstorePolicyDeductibles.forEach(deductible -> {
			try {
				listOfExpectedPolicyDeductibleAmounts.add(getAmountForStringDeductibleFromAppstore(deductible) + " deductible");
			} catch (Exception e) {
				Log.warn("Unable to get expected policy amounts from appstore");
			}
		});
		fsa.assertEquals(listOfObservedPolicyDeductibles, listOfAppstorePolicyDeductibles, "Policy deductibles on screen match appstore");
		// Wind and Hail may be constrained to specific zip codes, so just flag if not found
		boolean foundExpected = listOfExpectedPolicyDeductibles.contains(WIND_AND_HAIL);
		boolean foundObserved = listOfObservedPolicyDeductibles.contains(WIND_AND_HAIL);
		if ((!foundExpected && foundObserved) || (foundExpected && !foundObserved)) {
			Log.warn(String.format("Wind and Hail deductible %s, removing it for deductible verification", (foundExpected? "expected but not observed" : "observed but not expected")));
			listOfExpectedPolicyDeductibles.remove(WIND_AND_HAIL);
			listOfObservedPolicyDeductibles.remove(WIND_AND_HAIL);
		}
		fsa.assertEquals(listOfObservedPolicyDeductibles, listOfExpectedPolicyDeductibles, "Policy deductibles on screen match expected list");
		fsa.assertEquals(listOfObservedPolicyDeductibleAmounts, listOfExpectedPolicyDeductibleAmounts, "Policy deductible amounts verification");
		fsa.assertEquals(getTextFromElement(ratedAmountInCard), CurrencyFormat.convertStringIntoCurrencyFormat(getCoverageObject().getTotalPremium()), "Rated amount verification");
		fsa.assertEquals(getTextFromElement(primaryCoveragesSectionHeader), "Primary coverages", "Coverages table section headers verification");
		List<PWElement> listOfDisplayedCoverageLabelElements = isUseMobileViewEnabled()? mobilelistOfPrimaryCoverageLabels: desktopListOfPrimaryCoverageLabels;
		List<String> listOfObservedCoverageLabels = listOfDisplayedCoverageLabelElements.stream().map(this::getTextFromElement).collect(Collectors.toList());
		listOfObservedCoverageLabels.addAll(listOfAdditionalCoverageLabels.stream().map(this::getTextFromElement).collect(Collectors.toList()));
		List<String> listOfAppstoreCoverageLabels = getListOfCoveragesFromAppstore();
		fsa.assertEquals(getSortedList(listOfObservedCoverageLabels), getSortedList(getExpectedCoveragesList(mobilehomeApplicant)), "Coverages labels on screen match expected list");
		fsa.assertEquals(listOfObservedCoverageLabels, listOfAppstoreCoverageLabels, "Coverages labels on screen match appstore");
		List<String> listOfObservedCoverageAmounts = listOfPrimaryCoverageAmounts.stream().map(this::getTextFromElement).collect(Collectors.toList());
		listOfObservedCoverageAmounts.addAll(listOfAdditionalCoverageAmounts.stream().map(this::getTextFromElement).collect(Collectors.toList()));
		List<String> listOfExpectedCoverageAmounts = getListOfCoverageAmountsFromAppstore(listOfAppstoreCoverageLabels);
		listOfExpectedCoverageAmounts.replaceAll(amount -> amount==null || amount.isBlank() || !amount.matches(".*\\d.*")? amount : CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(amount));
		fsa.assertEquals(listOfObservedCoverageAmounts, listOfExpectedCoverageAmounts, "Coverages amounts on screen match appstore");
		validateCoverageHelpLinks(mobilehomeApplicant, fsa);
		fsa.assertEquals(getTextFromElement(includedInPolicyHeader), "You get all this with your " + (isForemostAffiliateQuote? EMPTY_STRING : "mobile home ") + "policy", "Policy inclusion card header verification");
		List<String> listOfExpectedYouGetAllThisIcons = List.of("dollar", "security", "golfcart");
		List<String> listOfObservedYouGetAllThisIcons = new ArrayList<>();
		listOfCoverageIcons.forEach(iconElement -> {
			String iconClass = getAttributeData(iconElement, CLASS);
			if (iconClass.contains("mobilehome-policy")) {
				iconClass = getTextFromElement(iconElement);
			}
			listOfObservedYouGetAllThisIcons.add(iconClass);
		});
		for (int index = 0; index < listOfExpectedYouGetAllThisIcons.size() && index < listOfObservedYouGetAllThisIcons.size(); index++) {
			fsa.assertTrue(listOfObservedYouGetAllThisIcons.get(index).contains(listOfExpectedYouGetAllThisIcons.get(index)), "Verifying the " + listOfExpectedYouGetAllThisIcons.get(index) + " icon is present.");
		}
		List<String> listOfObservedCoverageDescriptions = listOfCoverageDescriptions.stream().map(this::getTextFromElement).collect(Collectors.toList());
		String liabilityCoverageConnector = isAlternateLabelState? "your" : "this";
		List<String> listOfExpectedCoverageDescriptions = new ArrayList<>(Arrays.asList("Comprehensive coverage" + separator + "Covers most direct, abrupt, and accidental physical losses (unless specifically excluded).",
				"Liability coverage" + separator + "Covers medical bills, lost wages, property damage, pain and suffering to others for accidents in " + liabilityCoverageConnector + " home for which you're liable."));
		if (!isApplicantLandlord && !isMobilehomeVacant) {
			listOfExpectedCoverageDescriptions.add("Vehicles" + separator + "Coverage included for up to $5,000 for vehicles such as a golf cart.");
		}
		fsa.assertEquals(listOfObservedCoverageDescriptions, listOfExpectedCoverageDescriptions, "Verifying You get all this coverage descriptions");
		fsa.assertEquals(getTextFromElement(disclaimerCardHeader), "Other options are available", "Other options card header verification");
		List<String> listOfObservedDisclaimerCardDescriptions = listOfDisclaimerCardContent.stream().map(this::getTextFromElement).collect(Collectors.toList());
		List<String> listOfExpectedDisclaimerCardDescriptions = new ArrayList<>();
		boolean prependAgreedLossSettlementSection = isForemostAffiliateQuote && !isApplicantLandlord && !isMobilehomeVacant;
		if (!isApplicantLandlord && !isMobilehomeVacant) {
			if (isAlternateLabelState) {
				listOfExpectedDisclaimerCardDescriptions.addAll(List.of("Personal effects replacement cost",
						"We won't deduct for depreciation when determining the amount we may pay to repair or replace your personal property. (The quote above currently pays on the Actual cash value basis, which does deduct for depreciation.)"));
			} else {
				listOfExpectedDisclaimerCardDescriptions.addAll(List.of("Dwelling replacement cost",
						"In most states, you could receive up to an additional 20% of the amount insured for the dwelling. Your settlement will reflect the cost to replace the damaged items with new property of comparable material and quality, without any deduction for depreciation.",
						"Personal property replacement cost",
						"We won't deduct for depreciation when determining the amount we may pay to repair or replace your personal property. (The quote above currently pays on the Actual cash value basis, which does deduct for depreciation.)"));
			}
		}
		List<String> agreedLostSettlementSectionStrings = new ArrayList<>(List.of("Agreed loss settlement with actual cash value",
				"Receive the full insured amount (minus applicable deductibles) if your home is destroyed by an insured loss. No hassles. (This is a lower-cost option.)"));
		if (prependAgreedLossSettlementSection) {
			if (listOfExpectedDisclaimerCardDescriptions.size() <= 2) {
				listOfExpectedDisclaimerCardDescriptions.addAll(0, agreedLostSettlementSectionStrings);
			} else {
				listOfExpectedDisclaimerCardDescriptions.addAll(2, agreedLostSettlementSectionStrings);
			}
		} else {
			listOfExpectedDisclaimerCardDescriptions.addAll(agreedLostSettlementSectionStrings);
		}
		listOfExpectedDisclaimerCardDescriptions.add("Get in touch with a " + (isForemostAffiliateQuote? "Foremost ": EMPTY_STRING) + "representative to get the coverage you want. Call us at");
		fsa.assertEquals(listOfObservedDisclaimerCardDescriptions, listOfExpectedDisclaimerCardDescriptions, "Verifying Other options card content");
		if (isElementDisplayed(discountsAppliedLabel, 3)) {
    		List<Discounts> listOfDiscountsForQuote = getListOfDiscountsFromAppstore();
    		int numberOfDiscounts = listOfDiscountsForQuote.size();
    		String discountNumberExpectedLabel = numberOfDiscounts == 1? "1 discount applied" : numberOfDiscounts + " discounts applied";
    		fsa.assertEquals(getTextFromElement(discountsAppliedLabel), discountNumberExpectedLabel, "Discounts applied verification.");
    		scrollAndClickOnElement(reviewDiscountsLink);
    		waitElementBeVisible(closeDiscountsAppliedSidesheetButton, 4);
    		List<String> listOfObservedDiscounts = driver().findElements(PWBy.xpath(DISCOUNT_NAMES_XPATH)).stream().map(this::getTextFromElement).sorted().collect(Collectors.toList());
    		List<String> listOfExpectedDiscounts = listOfDiscountsForQuote.stream().map(AppStore.Home.Discounts::getName).collect(Collectors.toList());
    		listOfExpectedDiscounts.replaceAll(discount -> discount.contains("&")? "Multi-policy" : discount);
    		fsa.assertEquals(listOfObservedDiscounts, getSortedList(listOfExpectedDiscounts), "Verifying discounts given");
    		clickElement(closeDiscountsAppliedSidesheetButton);
    		waitElementBeInvisible(closeDiscountsAppliedSidesheetButton);
    		fsa.assertTrue(getTextFromElement(discountIncludedCheckmarkIcon).equals("check_circle"), "Green checked circle icon displayed.");
    		discountNumberExpectedLabel = numberOfDiscounts == 1? "1 discount included" : numberOfDiscounts + " discounts included";
    		fsa.assertEquals(getTextFromElement(discountIncludedLabel), discountNumberExpectedLabel, "Summary card discounts included verification.");
		} else if (!isApplicantLandlord && !isMobilehomeVacant) {
			fsa.fail("Discounts included information is missing.");
		}
		String summaryCardXpath = isUseMobileViewEnabled()? MOBILE_QUOTE_SUMMARY_CARD_XPATH: DESKTOP_QUOTE_SUMMARY_CARD_XPATH;
		try {
			fsa.assertEquals(getTextFromElement(driver().findElement(PWBy.xpath(summaryCardXpath+TERM_LABEL_XPATH))), isForemostAffiliateQuote? "12-month quoted price" : "12-month term starting at", "Term label verification");
			fsa.assertEquals(getTextFromElement(driver().findElement(PWBy.xpath(summaryCardXpath+CARD_QUOTE_AMOUNT_XPATH))), getRateFromAppstore(), "Rated amount in summary card verification");
			fsa.assertEquals(getTextFromElement(driver().findElement(PWBy.xpath(summaryCardXpath+"//a[contains(@class, 'mobilehome-quote-start-checkout-button')]"))), isForemostAffiliateQuote? "Call to customize" : "Call to personalize", "Call label in summary card verification");
		} catch (Exception e) {
			Log.warn("Unable to completely verify summary card due to exception: " + e);
		}
		String expectedStepState = activeStep;
		if (retrievedQuote) {
			expectedStepState = expectedStepState + RETRIEVED;
		}
		validatePageLinksText(fsa, expectedStepState);
		if (!isForemostAffiliateQuote) {
			validatePageLinksNavigationTitles(fsa);
		}
		if (!isForemostQuote) {
			validateAgentSectionContent(fsa, isAWSQuote, testCategory);
		}
	}

	public void discountElementsPresentCheck(FarmersSoftAssert fsa, boolean elementsExpected) {
		String isIsnotExpected = elementsExpected? " displayed" : " is not displayed";
		fsa.assertEquals(isElementDisplayed(discountsAppliedLabel, 2), elementsExpected, "discountsAppliedLabel" + isIsnotExpected);
		fsa.assertEquals(isElementDisplayed(reviewDiscountsLink, 2), elementsExpected, "reviewDiscountsLink" + isIsnotExpected);
		fsa.assertEquals(isElementDisplayed(discountIncludedCheckmarkIcon, 2), elementsExpected, "discountIncludedCheckmarkIcon" + isIsnotExpected);
		fsa.assertEquals(isElementDisplayed(discountIncludedLabel,2), elementsExpected, "discountIncludedLabel" + isIsnotExpected);
	}

	public List<Discounts> getListOfDiscountsFromAppstore() throws Exception {
		return getSessionStorageAppStore().getHome().getDiscounts().stream().distinct().collect(Collectors.toList());
	}

	private List<String> getListOfCoveragesFromAppstore() throws Exception {
		List<String> listOfCoverages = new ArrayList<>(getCoverageObject().getCvgInfo().stream().map(AppStore.Home.CvgInfo::getCvgDesc).collect(Collectors.toList()));
		return listOfCoverages;
	}

	private List<String> getListOfCoverageAmountsFromAppstore(List<String> listOfCoverages) throws Exception {
		return getCoverageObject().getCvgInfo().stream().filter(i -> listOfCoverages.contains(i.getCvgDesc())).map(AppStore.Home.CvgInfo::getCvgAmt).collect(Collectors.toList());
	}

	private List<String> getListOfPolicyDeductiblesFromAppstore() throws Exception {
		return getCoverageObject().getDedInfo().stream().map(AppStore.Home.DedInfo::getDesc).collect(Collectors.toList());
	}

	private String getAmountForStringDeductibleFromAppstore(String deductible) throws Exception {
		return CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(getCoverageObject().getDedInfo().stream().filter(i -> deductible.equals(i.getDesc())).map(AppStore.Home.DedInfo::getAmt)
				.findFirst().orElse(EMPTY_STRING));
	}

	private Coverage getCoverageObject() throws Exception {
		Home home = getSessionStorageAppStore().getHome();
		AppStore.Home.Quote quote = home.getQuote();
		return home.getCoverageForPackage(quote.getSelectedPackageCode(), quote.getSelectedPaymentMode());
	}

	private String getRateFromAppstore() throws Exception {
		return CurrencyFormat.convertStringIntoCurrencyFormat(getCoverageObject().getTotalPremium());
	}

	private List<String> getExpectedCoveragesList(ApplicantAceHome mobilehomeApplicant) {
		boolean isReplacementCostState = isReplacementCostState(mobilehomeApplicant);
		String applicantStateCode = mobilehomeApplicant.getStateCode();
		String dwellingCoverage = DWELLING;
		String structuresCoverage = OTHER_STRUCTURES;
		String personalPropertyCoverage = PERSONAL_PROPERTY_ACV;
		if (isAlternateLabelState) {
			dwellingCoverage = MOBILE_HOME;
			structuresCoverage = ADJACENT_STRUCTURES;
			personalPropertyCoverage = PERSONAL_EFFECTS_ACV;
		}
		List<String> listofExpectedCoverages = new ArrayList<>();
		if (isApplicantLandlord) {
			listofExpectedCoverages.addAll(List.of(dwellingCoverage, personalPropertyCoverage, PREMISES_LIABILITY));
			if (List.of(CA, NV).contains(applicantStateCode)) {
				listofExpectedCoverages.add(EXTENDED_REPLACEMENT_COST);
			} else if (applicantStateCode.equals(MN)) {
				listofExpectedCoverages.remove(personalPropertyCoverage);
			} else if (applicantStateCode.equals(TX)) {
				listofExpectedCoverages.add(MEDICAL_PAYMENTS);
			}
			if (isReplacementCostState) {
				listofExpectedCoverages.add(REPLACEMENT_COST);
			}
		} else if (isMobilehomeVacant) {
			switch (applicantStateCode) {
				case DE: case KY: case TX:
					listofExpectedCoverages.addAll(List.of(dwellingCoverage, REPLACEMENT_COST));
					break;
				case NY: case VA:
					listofExpectedCoverages.addAll(List.of(dwellingCoverage));
					break;
				case WV:
					listofExpectedCoverages.addAll(List.of(dwellingCoverage, EXTENDED_REPLACEMENT_COST, MEDICAL_PAYMENTS, PREMISES_LIABILITY));
					break;
				default:
					listofExpectedCoverages.addAll(List.of(dwellingCoverage, MEDICAL_PAYMENTS, PREMISES_LIABILITY, REPLACEMENT_COST));
					break;
			}
		} else {
			listofExpectedCoverages.addAll(List.of(dwellingCoverage, EXTENDED_REPLACEMENT_COST, structuresCoverage, personalPropertyCoverage, ADDITIONAL_LIVING_EXPENSES, PERSONAL_LOWERCASELIABILITY, MEDICAL_PAYMENTS, FIRE_DEPARTMENT_SERVICE_CHARGE));
			if (!isExtendedReplacementCostState(mobilehomeApplicant)) {
				listofExpectedCoverages.remove(EXTENDED_REPLACEMENT_COST);
			}
			if (isNoFireDepartmentChargeState(mobilehomeApplicant) || isAlternateLabelState) {
				listofExpectedCoverages.remove(FIRE_DEPARTMENT_SERVICE_CHARGE);
			}
			// This is a discrepancy from the coverages sheet
			if (isAlternateLabelState || applicantStateCode.equals(NM)) {
				listofExpectedCoverages.add(REPLACEMENT_COST);
			}
			if (isSecondaryOrSeasonalResidence && !isAlternateLabelState) {
				listofExpectedCoverages.removeAll(List.of(PERSONAL_LOWERCASELIABILITY, MEDICAL_PAYMENTS));
			}
		}
		return listofExpectedCoverages;
	}

	private List<String> getExpectedPolicyDeductiblesList(ApplicantAceHome mobilehomeApplicant) {
		String dwellingDeductible = DWELLING;
		String structuresDeductible = OTHER_STRUCTURES;
		String personalPropertyDeductible = PERSONAL_PROPERTY_ACV;
		if (isAlternateLabelState) {
			dwellingDeductible = MOBILE_HOME;
			structuresDeductible = ADJACENT_STRUCTURES;
			personalPropertyDeductible = PERSONAL_EFFECTS_ACV;
		}
		List<String> listOfExpectedDeductibles = new ArrayList<>(Arrays.asList(dwellingDeductible, structuresDeductible, personalPropertyDeductible));
		if (isApplicantLandlord) {
			listOfExpectedDeductibles.remove(structuresDeductible);
			if (mobilehomeApplicant.getStateCode().equals(MN)) {
				listOfExpectedDeductibles.remove(personalPropertyDeductible);
			}
		} else if (isMobilehomeVacant) {
			listOfExpectedDeductibles.clear();
			listOfExpectedDeductibles.add(dwellingDeductible);
			if (List.of(KS, WY).contains(mobilehomeApplicant.getStateCode())) {
				listOfExpectedDeductibles.add(WIND_AND_HAIL);
			}
		} else if (isWindAndHailState(mobilehomeApplicant)) {
			listOfExpectedDeductibles.add(1, WIND_AND_HAIL);
		}
		return listOfExpectedDeductibles;
	}

	private void validateCoverageHelpLinks(ApplicantAceHome mobilehomeApplicant,  FarmersSoftAssert fsa) throws Exception {
		if (listOfCoverageHelpLinks.isEmpty()) {
			fsa.fail("No help links found in the Quote summary page");
		} else {
	    	String phoneNumber = isForemostQuote?"855-497-0352": isForemostAffiliateQuote? "800-315-1122": "888-902-1896";
			Map<String, String> helpTitleAndContentsMap = getHelpMap();
			int helpLinksOnPage = listOfCoverageHelpLinks.size();
			List<String> expectedCoverageHeadersInInfoSideSheet = getListOfHelpHeaders(mobilehomeApplicant);
			fsa.assertEquals(helpLinksOnPage, expectedCoverageHeadersInInfoSideSheet.size(), "Coverage help links found and expected match");
			waitAndClickElement(listOfCoverageHelpLinks.get(0));
			waitElementBeVisible(infoSideSheetTitle);
			fsa.assertEquals(getTextFromElement(infoSideSheetTitle), "Coverage descriptions", "Help sidesheet title verification.");
	        String whoCanHelp = isForemostAffiliateQuote? "Foremost ": "We ";
			fsa.assertEquals(getTextFromElement(infoSideSheetSubtitle), whoCanHelp +"can help you customize your coverage, and learn about other coverage options and more ways you could save. " +
					"Call us at " + phoneNumber + " so you can select the insurance you want.", "Help sidesheet subtitle verification.");
			List<String> foundCoverageHeadersInInfoSideSheet = listOfCoverageTitlesInSideSheet.stream().map(this::getTextFromElement).collect(Collectors.toList());
			fsa.assertEquals(getSortedList(foundCoverageHeadersInInfoSideSheet), getSortedList(expectedCoverageHeadersInInfoSideSheet), "Coverage descriptions found in info side sheet match available coverages");
			clickElement(closeInfoSideSheetButton);
			waitElementBeInvisible(closeInfoSideSheetButton);
			for (int i = 0; i < helpLinksOnPage; i++){
				scrollAndClickOnElement(listOfCoverageHelpLinks.get(i));
				String expectedHelpHeaderForItem = getExpectedHelpHeader(listOfCoverageHelpLinks.get(i));
				waitElementBeVisible(infoSideSheetTitle);
				List<String> listOfHelpTitlesWithExpandedSections = getTextFromListOfWebElementsAndDescendents(listOfCoverageTitlesWithExpandedHelpSections);
				if (listOfHelpTitlesWithExpandedSections.isEmpty()) {
					fsa.fail("No expanded help section found for " + expectedHelpHeaderForItem);
				} else {
					fsa.assertEquals(listOfHelpTitlesWithExpandedSections.size(), 1, "Verify only one expanded help section");
					fsa.assertEquals(listOfHelpTitlesWithExpandedSections.get(FIRST_AVAILABLE_OPTION), expectedHelpHeaderForItem, "Expanded section title verification for " + expectedHelpHeaderForItem);
					String expectedHelpContentForItem = expectedHelpHeaderForItem.equals(ADDITIONAL_LIVING_EXPENSES) && isAlternateLabelState? CoverageInfoDetails.LOSS_OF_USE_MOBILE_HOME_DESCRIPTION :
							helpTitleAndContentsMap.get(expectedHelpHeaderForItem);
					fsa.assertEquals(getTextFromElement(listOfCoverageDescriptionsWithExpandedHelpSections.get(FIRST_AVAILABLE_OPTION)), expectedHelpContentForItem, "Verify content of expanded help section for " + expectedHelpHeaderForItem);
				}
				clickElement(closeInfoSideSheetButton);
				waitElementBeInvisible(closeInfoSideSheetButton);
			}
		}
	}

	private String getExpectedHelpHeader(PWElement helpLink) {
		return headerTextCorrection(getAttributeData(helpLink, ARIA_LABEL).replace("Information about ", EMPTY_STRING));
	}

	private List<String> getListOfHelpHeaders(ApplicantAceHome mobilehomeApplicant) {
		List<String> listOfHelpHeaders = getExpectedCoveragesList(mobilehomeApplicant);
		//Corrections to match the headers in the info side sheet
		listOfHelpHeaders.replaceAll(header -> {
			return headerTextCorrection(header);
		});
		return listOfHelpHeaders;
	}

	private String headerTextCorrection(String header) {
		if (header.equals(PERSONAL_LIABILITY)) {
			return PERSONAL_LOWERCASELIABILITY;
		} else if (header.equals(PREMISES_LIABILITY)) {
			return PREMISES_LOWERCASELIABILITY;
		} else if (header.equals(PERSONAL_PROPERTY_ACV)) {
			return PERSONAL_LOWERCASEPROPERTY;
		} else if (header.equals(PERSONAL_EFFECTS_ACV)) {
			return PERSONAL_EFFECTS;
		} else if (header.equals(MEDICAL_PAYMENTS)) {
			return MEDICAL_PAYMENTS_TO_OTHERS;
		}
		return header;
	}

	private Map<String, String> getHelpMap() {
		String liabilityDescription = "This coverage can pay damages an insured becomes legally obligated to pay because of bodily injury or property damage to others.";
		Map<String, String> helpMap = Map.ofEntries(
			    entry(DWELLING, CoverageInfoDetails.DWELLING_COST_DESCRIPTION),
			    entry(MOBILE_HOME, CoverageInfoDetails.MOBILE_HOME_COVERAGE_DESCRIPTION),
			    entry(ADJACENT_STRUCTURES, CoverageInfoDetails.SEPARATE_STRUCTURES_DESCRIPTION),
			    entry(OTHER_STRUCTURES, CoverageInfoDetails.SEPARATE_STRUCTURES_DESCRIPTION),
			    entry(PERSONAL_EFFECTS, CoverageInfoDetails.PERSONAL_EFFECTS_MOBILE_HOME_DESCRIPTION),
			    entry(PERSONAL_PROPERTY, CoverageInfoDetails.PERSONAL_PROPERTY_MOBILE_HOME_DESCRIPTION),
			    entry(ADDITIONAL_LIVING_EXPENSES, CoverageInfoDetails.ADDITIONAL_LIVING_EXPENSES_MOBILE_HOME_DESCRIPTION),
			    entry(PREMISES_LOWERCASELIABILITY, liabilityDescription),
			    entry(PERSONAL_LOWERCASELIABILITY, liabilityDescription),
			    entry(EXTENDED_REPLACEMENT_COST, CoverageInfoDetails.EXTENDED_REPLACEMENT_COST),
			    entry(REPLACEMENT_COST, "Replacement cost coverage extends your Coverage A (Dwelling) limit if needed to repair or replace covered damage to your home by the percentage option you select."),
			    entry(MEDICAL_PAYMENTS_TO_OTHERS, "This coverage can pay medical costs, up to the limit selected by you, for guests who are injured at your residence, regardless of your legal liability."),
			    entry(FIRE_DEPARTMENT_SERVICE_CHARGE, "Provides coverage for fire department service charges incurred when the fire department is called to save or protect insured property from an Insured Peril. This coverage is automatically included at $500.00 but can be increased to $1,000 or $2,500. No deductible will apply to this coverage (not applicable in Arizona, New Jersey, and New Mexico)."));
		return helpMap;
	}

	private boolean isExtendedReplacementCostState(ApplicantAceHome mobilehomeApplicant) {
		return !List.of(NC, NM, TX).contains(mobilehomeApplicant.getStateCode());
	}

	private boolean isReplacementCostState(ApplicantAceHome mobilehomeApplicant) {
		return !List.of(AR, CA, NE, NH, NV, VA).contains(mobilehomeApplicant.getStateCode());
	}

	private boolean isNoFireDepartmentChargeState(ApplicantAceHome mobilehomeApplicant) {
		return List.of(AZ, NJ, NM).contains(mobilehomeApplicant.getStateCode());
	}

	private boolean isWindAndHailState(ApplicantAceHome mobilehomeApplicant) {
		return List.of(AR, AZ, CO, IA, ID, IL, IN, KS, KY, LA, MD, MI, MN, MO, MS, MT, ND, NE, NH, NM, NV, OH, OK, SC, SD, TN, WA, WI, WY).contains(mobilehomeApplicant.getStateCode());
	}
}
