package com.farmers.ffq.ace.hrc.common;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.home.AceHomeReviewQuotePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.DateCalculations;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.testng.Assert;

import java.text.NumberFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCReviewQuoteBasePage.*;
import static com.farmers.ffq.common.enums.CoveragesNameAceHome.Coverage.*;
import static com.farmers.ffq.utils.GlobalVariables.*;
public class AceHRCAdditionalCoveragesBasePage extends AceHRCBasePage {

    protected static final String PAGE_TITLE = "Optional coverages";
    protected static final String PAGE_SUBTITLE = "Pick and choose optional coverages you want for your property.";
    private static final String PAGE_TITLE_XPATH = "//app-additional-coverages-page//h1";
    private static final String A_COMP = "A_COMP";
    private static final String COMP = "COMP";
    private static final String I_COMP = "ICOMP";

    @PWFindBy(xpath = PAGE_TITLE_XPATH)
    protected PWElement additionalCoveragesHeading;
    @PWFindBy(xpath = "//app-additional-coverages-page//h1/following-sibling::div[contains(@class,'subheading-class')]")
    protected PWElement additionalCoveragesSubheading;

    protected static final String QUOTE_PRESENTMENT_DESKTOP_XPATH = "//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-desktop')]";
    protected static final String QUOTE_PRESENTMENT_MOBILE_XPATH = "//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]";

    @PWFindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tui-price")
    private PWElement quotePriceOnCardDesktop;
    @PWFindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//tui-price")
    private PWElement quotePriceOnCardMobile;

    private static final String PRESENTMENT_CARD_PRICE_HEADER = "12-month plan starting at";

    private static final String PRESENTMENT_CARD_PRICE_HEADER_XPATH = "//div[contains(@class,'price-description')]";
    @PWFindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + PRESENTMENT_CARD_PRICE_HEADER_XPATH)
    private PWElement presentmentCardPriceHeaderDesktop;
    @PWFindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + PRESENTMENT_CARD_PRICE_HEADER_XPATH)
    private PWElement presentmentCardPriceHeaderMobile;

    private static final String VIEW_MONTHLY_PRICING_LINK_DESKTOP_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[text()='View monthly pricing']";
    @PWFindBy(xpath = VIEW_MONTHLY_PRICING_LINK_DESKTOP_XPATH)
    private PWElement linkViewMonthlyPricingDesktop;
    private static final String VIEW_MONTHLY_PRICING_LINK_MOBILE_XPATH = QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[text()='View monthly pricing']";
    @PWFindBy(xpath = VIEW_MONTHLY_PRICING_LINK_MOBILE_XPATH)
    private PWElement linkViewMonthlyPricingMobile;

    private static final String VIEW_PAY_IN_FULL_PRICING_LINK_DESKTOP_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//div[starts-with(text(),'View pay-in-full pricing')]";
    @PWFindBy(xpath = VIEW_PAY_IN_FULL_PRICING_LINK_DESKTOP_XPATH)
    private PWElement linkViewPayInFullPricingDesktop;
    private static final String VIEW_PAY_IN_FULL_PRICING_LINK_MOBILE_XPATH = QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[starts-with(text(),'View pay-in-full pricing')]";
    @PWFindBy(xpath = VIEW_PAY_IN_FULL_PRICING_LINK_MOBILE_XPATH)
    private PWElement linkViewPayInFullPricingMobile;


    protected static final String PRIMARY_COVERAGE_PRICE_DESKTOP_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[starts-with(text(),'%s')]/following-sibling::td";
    protected static final String PRIMARY_COVERAGE_PRICE_MOBILE_XPATH = QUOTE_PRESENTMENT_MOBILE_XPATH + "//tr/td[starts-with(text(),'%s')]/following-sibling::td";

    private static final String OPTIONAL_COVERAGES_XPATH = "//tr/td[text()='Optional coverages']/following-sibling::td";
    @PWFindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + OPTIONAL_COVERAGES_XPATH)
    private PWElement quoteAllOtherCoveragesPriceOnCardDesktop;
    @PWFindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + OPTIONAL_COVERAGES_XPATH)
    private PWElement quoteAllOtherCoveragesPriceOnCardMobile;

    @PWFindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div")
    private PWElement quoteDiscountsOnCardDesktop;
    @PWFindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//mat-list-item//div")
    private PWElement quoteDiscountsOnCardMobile;

    private static final String CONTINUE_BUTTON_XPATH = "//button[contains(text(),'Continue')]";
    private static final String CALL_BUTTON_XPATH = "//button[contains(text(),'Call')]";
    @PWFindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + CONTINUE_BUTTON_XPATH)
    protected PWElement buttonContinueDesktop;
    @PWFindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + CONTINUE_BUTTON_XPATH)
    protected PWElement buttonContinueMobile;
    @PWFindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + CALL_BUTTON_XPATH)
    protected PWElement buttonCallDesktop;
    @PWFindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + CALL_BUTTON_XPATH)
    protected PWElement buttonCallMobile;
    @PWFindBy(xpath = "//app-additional-coverages-page" + CONTINUE_BUTTON_XPATH)
    private PWElement fallbackContinueButton;

    protected static final String RECALCULATE_BUTTON_DESKTOP_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[contains(text(),'Recalculate')]";
    @PWFindBy(xpath = RECALCULATE_BUTTON_DESKTOP_XPATH)
    protected PWElement recalculateButtonDesktop;
    protected static final String RECALCULATE_BUTTON_MOBILE_XPATH = QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[contains(text(),'Recalculate')]";
    @PWFindBy(xpath = RECALCULATE_BUTTON_MOBILE_XPATH)
    protected PWElement recalculateButtonMobile;
    @PWFindBy(xpath = "//div[contains(@class,'summary-box-mobile-button')]//button")
    private PWElement recalculateButtonBundleMobile;
    @PWFindBy(xpath = "//div[contains(@class,'summary-box-desktop-button')]//button")
    protected PWElement recalculateButtonBundleDesktop;
    @PWFindBy(id = "emailLink")
    private PWElement emailLink;
    @PWFindBy(linkText = "Done")
    private PWElement linkCloseEmailSnackBar;

    protected static final String INCREASED_COVERAGE_FOR_VALUABLES_TITLE = "Increased coverage for certain valuables";
    public static final String INCREASED_LIMITS_FOR_VALUABLES_TITLE = "Increased limits for certain valuables";
    public static final String INCREASED_LIMITS_FOR_LIMITED_MOLD = "Increased limits for Limited mold";
    public static final String EARTHQUAKE = "Earthquake";
    protected static final String HOA_LOSS_PAYMENT = "HOA loss payment";
    protected static final String UTILITY_LINE = "Utility line";
    protected static final String SERVICE_LINE = "Service line";
    protected static final String WATER_BACKUP_AND_SUMP_OVERFLOW = "Water backup and sump overflow";
    public static final String SEWER_AND_DRAIN = "Sewer and drain";
    protected static final String WATER_BACKUP_AND_SUMP_DISCHARGE = "Water backup and sump discharge";
    protected static final String LIMITED_LEAKAGE_AND_SEEPAGE = "Limited leakage & seepage";
    protected static final String LIMITED_ESCAPED_LIQUID_FUEL = "Limited escaped liquid fuel";
    protected static final String LIMITED_WATER_LEAKAGE = "Limited water leakage";
    protected static final String LIMITED_PLUMBING_SYSTEM_REPAIR = "Limited plumbing system repair";
    public static final String WATERCRAFT_LIABILITY_FAMILY_PROTECTION = "Watercraft liability - family protection";
    protected static final String EQUIPMENT_BREAKDOWN = "Equipment breakdown";
    protected static final String ZERO_DEDUCTIBLE_GLASS = "Zero-deductible glass";
    protected static final String PERSONAL_INJURY = "Personal injury";
    protected static final String SINKHOLE_LOSS = "Sinkhole loss";
    protected static final String CHILD_CARE_LIABILITY = "Child care liability";
    protected static final String ASSOCIATION_LOSS_ASSESSMENT = "Association loss assessment";
    protected static final String E_BIKES_AND_GOLF_CARTS = "E-bikes & golf carts";
    protected static final String RESIDENCE_GLASS_WAIVER_OF_DEDUCTIBLE = "Residence glass waiver of deductible";
    protected static final String IDENTITY_SHIELD = "Identity shield";

    protected static final String TOGGLE_BUTTON_XPATH = "//mat-slide-toggle[contains(.,'%s')]";

    private static final String TOGGLE_PRICE_XPATH = "//mat-slide-toggle[contains(.,'%s')]/following-sibling::div[contains(@class,'tui-subtitle-text')]";

    @PWFindBy(xpath = "//mat-slide-toggle")
    protected List<PWElement> toggleButtons;

    @PWFindBy(xpath = "//div[@id='HOAlosspayment']//label[contains(@class,'tui-input-text-2')]")
    private PWElement headerHoaLossPayment;
    @PWFindBy(xpath = "//div[@id='HOAlosspayment']//mat-radio-button")
    private List<PWElement> radioButtonsHoaLossPayment;
    @PWFindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//label[contains(@class,'tui-input-text-2')][1]")
    private PWElement headerWaterBackup;
    @PWFindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//label[contains(@class,'tui-input-text-2')][2]")
    private PWElement footerWaterBackup;

    @PWFindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-radio-button")
    private List<PWElement> radioButtonsWaterBackup;
    @PWFindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle[1]")
    private PWElement toggleButtonsWaterBackup1;
    @PWFindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle[2]")
    private PWElement toggleButtonsWaterBackup2;
    @PWFindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle-group/following-sibling::div")
    private PWElement toggleButtonsWaterBackupText;
    @PWFindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-card//input")
    private PWElement inputWaterBackup;
    @PWFindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle[.='remove']")
    private PWElement buttonWaterBackupMinus;
    @PWFindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-button-toggle[.='add']")
    private PWElement buttonWaterBackupPlus;
    @PWFindBy(xpath = "//div[@id='Waterbackupandsumpoverflow']//mat-hint")
    private PWElement subTextInputWaterBackup;

    @PWFindBy(xpath = "//div[@id='Limitedmold']//label[contains(@class,'tui-input-text-2')]")
    protected PWElement headerLimitedMold;
    @PWFindBy(xpath = "//div[@id='Limitedmold']//mat-radio-button")
    protected List<PWElement> radioButtonsLimitedMold;
    @PWFindBy(xpath = "//div[@id='Limitedmold']//mat-form-field//input")
    protected PWElement yearBuiltInputLimitedMold;
    @PWFindBy(xpath = "//div[@id='Earthquake']//mat-form-field//input")
    protected PWElement yearBuiltInputEarthquake;

    @PWFindBy(xpath = "//div[@id='IncreasedlimitsforLimitedmold']//label[contains(@class,'tui-input-text-2')]")
    protected PWElement headerIncreasedLimitsForLimitedMold;
    @PWFindBy(xpath = "//div[@id='IncreasedlimitsforLimitedmold']//mat-radio-button")
    protected PWElement radioButtonIncreasedLimitsForLimitedMold;

    @PWFindBy(xpath = "//div[@id='Limitedleakage&seepage']//label[contains(@class,'tui-input-text-2')]")
    private PWElement headerLimitedLeakage;
    @PWFindBy(xpath = "//div[@id='Limitedleakage&seepage']//mat-radio-button")
    private List<PWElement> radioButtonsLimitedLeakage;

    @PWFindBy(xpath = "//div[@id='increasedValuables']//label[contains(@class,'tui-input-text-2')]")
    private PWElement headerIncreasedValuables;
    @PWFindBy(xpath = "//div[@id='increasedValuables']//button[contains(@aria-label,'info icon')]")
    private PWElement headerIncreasedValuablesInfoIcon;
    @PWFindBy(xpath = "//div[@id='increasedValuables']//mat-checkbox")
    private List<PWElement> checkboxesIncreasedValuables;
    @PWFindBy(xpath = "//div[@id='increasedValuables']//mat-checkbox")
    private PWElement checkboxesIncreasedValuable;
    @PWFindBy(xpath = "//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]")
    private PWElement footerIncreasedValuables;
    @PWFindBy(xpath = "//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]/descendant::div[contains(.,'*')]")
    protected PWElement footerIncreasedValuablesStarText;
    @PWFindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[1]")
    private PWElement inputIncreasedCoverageJewelry;
    @PWFindBy(xpath = "//div[@id='increasedValuables']//mat-checkbox[following-sibling::div[contains(text(),'Jewelry')]]//label")
    private PWElement labelIncreasedCoverageJewelry;
    @PWFindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[1]")
    private PWElement increaseCoverageJewelry;
    @PWFindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[1]")
    private PWElement decreaseCoverageJewelry;
    @PWFindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[2]")
    private PWElement inputIncreasedCoverageOther;
    @PWFindBy(xpath = "//div[@id='increasedValuables']//mat-checkbox[following-sibling::div[contains(text(),'Other')]]//label")
    private PWElement labelIncreasedCoverageOther;
    @PWFindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[2]")
    private PWElement increaseCoverageOther;
    @PWFindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[2]")
    private PWElement decreaseCoverageOther;
    @PWFindBy(xpath = "//div[@id='increasedValuables']//button[contains(@aria-label,'Securities') and mat-icon[text()='add']]")
    private PWElement increaseCoverageSecurities;
    @PWFindBy(xpath = "//div[@id='increasedValuables']//button[contains(@aria-label,'Securities') and mat-icon[text()='remove']]")
    private PWElement decreaseCoverageSecurities;
    @PWFindBy(xpath = "//app-additional-coverage-card//mat-error")
    protected List<PWElement> errorsIncreasedCoverageSection;
    @PWFindBy(xpath = "(//div[@id='increasedValuables']//mat-checkbox//label)[1]")
    protected PWElement increaseCoverageJewelryCheckbox;
    @PWFindBy(xpath = "(//div[@id='increasedValuables']//mat-checkbox//label)[2]")
    protected PWElement increaseCoverageOtherCheckbox;
    @PWFindBy(xpath = "//app-increase-valuables-info-dialog//h1")
    protected PWElement increasedValuablesInfoDialogHeader;
    @PWFindBy(xpath = "//app-increase-valuables-info-dialog//button[@aria-label='Close']")
    protected PWElement increasedValuablesInfoDialogCloseButton;
    @PWFindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]/div")
    protected PWElement increasedValuablesInfoDialogMainContent;
    @PWFindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'package-name-label')]")
    private PWElement increasedValuablesInfoDialogPackageName;

    @PWFindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][1]")
    // Jewelry
    private PWElement increasedValuablesInfoDialogJewelry;
    @PWFindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][1]/following-sibling::div[1]")
    // Jewelry text content
    private PWElement increasedValuablesInfoDialogJewelryText;

    @PWFindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][2]")
    // Other articles
    private PWElement increasedValuablesInfoDialogOtherArticles;
    @PWFindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][2]/following-sibling::div[1]")
    // Firearms, Security, Silverware, Fine arts
    private PWElement increasedValuablesInfoDialogOtherArticlesTextFirearms;
    @PWFindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][2]/following-sibling::div[2]")
    private PWElement increasedValuablesInfoDialogOtherArticlesTextWatches;
    @PWFindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[1]")
    private PWElement increasedValuablesInfoDialogDivider1;
    @PWFindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[2]")
    private PWElement increasedValuablesInfoDialogDivider2;
    @PWFindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[3]")
    private PWElement increasedValuablesInfoDialogDivider3;

    @PWFindBy(xpath = "//div[@id='Limitedescapedliquidfuel']//div[contains(@class,'tui-input-text-2')]")
    private PWElement headerLimitedEscapedLiquidFuel;
    @PWFindBy(xpath = "//div[@id='Limitedescapedliquidfuel']//mat-radio-button")
    private List<PWElement> radioButtonsLimitedEscapedLiquidFuel;
    @PWFindBy(xpath = "//div[@id='Limitedescapedliquidfuel']//label[contains(@class,'tui-input-text-2')]")
    private List<PWElement> headersLimitedEscapedLiquidFuelSection;

    @PWFindBy(xpath = "//div[@id='Earthquake']//div[contains(@class,'tui-input-text-2')]")
    protected PWElement headerEarthquake;
    @PWFindBy(xpath = "//div[@id='Earthquake']//mat-radio-button")
    private List<PWElement> radioButtonsEarthquake;
    @PWFindBy(xpath = "//div[@id='Earthquake']//mat-radio-button//label")
    protected List<PWElement> radioButtonsEarthquakeLabels;
    @PWFindBy(xpath = "//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]")
    private List<PWElement> headersEarthquakeSection;
    @PWFindBy(xpath = "//div[@id='Earthquake']//mat-button-toggle/button")
    private List<PWElement> toggleButtonsEarthquake;
    @PWFindBy(xpath = "//div[@id='Earthquake']//button[contains(@aria-label,'info icon')]")
    private List<PWElement> earthquakeInfoIcons;
    @PWFindBy(xpath = "//app-earthquake-coverage-dialog//h4")
    protected PWElement earthquakeCoverageInfoDialogHeader;
    @PWFindBy(xpath = "//app-earthquake-coverage-dialog//div/span[contains(@class,'tui-subtitle-2')]")
    private List<PWElement> earthquakeInfoDialogSubheaders;
    @PWFindBy(xpath = "//app-earthquake-coverage-dialog//div[contains(@class,'tui-body')]")
    private List<PWElement> earthquakeInfoDialogParagraphs;

    @PWFindBy(xpath = "//div[@id='Specialwaterlosslimit']//label[contains(@class,'tui-input-text-2')]")
    private PWElement headerSpecialWaterLossLimit;
    @PWFindBy(xpath = "//div[@id='Specialwaterlosslimit']//mat-radio-button")
    private List<PWElement> radioButtonsSpecialWaterLossLimit;

    @PWFindBy(xpath = "//mat-dialog-container//span[contains(@class,'tui-subtitle')]")
    protected PWElement watercraftCoverageDialogTitle;
    @PWFindBy(xpath = "//mat-dialog-container//mat-dialog-content")
    protected PWElement watercraftCoverageDialogContent;
    @PWFindBy(xpath = "//mat-dialog-container//mat-dialog-actions//a")
    protected PWElement buttonRemoveCoverage;
    @PWFindBy(xpath = "//mat-dialog-container//mat-dialog-actions//button")
    protected PWElement buttonOk;

    @PWFindBy(xpath = "//a[contains(@class,'close')]//mat-icon")
    protected PWElement closeSidesheetButton;

    @PWFindBy(xpath = "//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]//mat-icon[@aria-label='expand quote card']")
    protected PWElement expandQuoteCard;
    @PWFindBy(xpath = "//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]//mat-icon[@aria-label='minimize quote card']")
    protected PWElement minimizeQuoteCard;

    @PWFindBy(xpath = "//mat-dialog-container//button[text()='OK']")
    private PWElement dialogButtonOk;

    @PWFindBy(xpath = "//div[contains(@class,'tui-stacking-top-sm')]//button[contains(text(),'Continue')]")
    protected PWElement buttonContinueMobileAtPageBottom;

    @PWFindBy(xpath = "//div[contains(@class,'tui-stacking-top-sm')]//button[contains(text(),'Recalculate')]")
    protected PWElement buttonRecalculateMobileAtPageBottom;

    @PWFindBy(xpath = "//mat-dialog-container[@aria-label='Special water loss limit dialog']//span[text()='Special water loss limit']")
    protected PWElement specialWaterLossLimitDialogTitle;

    @PWFindBy(xpath = "//mat-dialog-container//span[text()='Fortified Roof upgrade coverage']")
    protected PWElement fortifiedRoofUpgradeDialogTitle;

    @PWFindBy(xpath = "//mat-dialog-content//tui-simple-dialog-content")
    protected PWElement dialogContent;

    private static final String SPECIAL_WATER_LOSS_LIMIT_TITLE = "Special water loss limit";
    private static final String SPECIAL_WATER_LOSS_LIMIT_CONTENT = "Since you added this optional coverage, we must remove the Access through foundation and walls coverage from this quote.";
    private static final String ACCESS_THROUGH_FOUNDATIONS_AND_WALLS_COVERAGE = "Access through foundations and walls";

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceHRCAdditionalCoveragesBasePage() throws Exception {
    }

    public boolean isOnAdditionalCoveragesPage() {
    	if (isUseMobileViewEnabled()) {
    		wait.until(PWExpectedConditions.or(PWExpectedConditions.visibilityOf(buttonContinueMobile),
    				PWExpectedConditions.visibilityOf(tryAgainButton),
    				PWExpectedConditions.visibilityOf(fallbackContinueButton),
    				PWExpectedConditions.visibilityOf(buttonCallMobile)));
    		return isElementVisible(buttonContinueMobile, 3) || isElementVisible(buttonCallMobile, 3);
    	} else {
    		wait.until(PWExpectedConditions.or(PWExpectedConditions.visibilityOf(buttonContinueDesktop),
    				PWExpectedConditions.visibilityOf(tryAgainButton),
    				PWExpectedConditions.visibilityOf(fallbackContinueButton),
    				PWExpectedConditions.visibilityOf(buttonCallDesktop)));
    		return isElementVisible(buttonContinueDesktop, 3) || isElementVisible(buttonCallDesktop, 3);
    	}
    }

    public boolean isOnBundlePropertyOptionalCoveragesPage() {
        return isElementPresent(PWBy.xpath("//app-additional-coverage-card"), 2);
    }

    public boolean isOnOptionalCoveragesPageForRenters() {
        return isElementPresent(PWBy.xpath("//app-additional-coverages-page//h1[text()='Optional renters coverages']"), 10);
    }

    public void clickContinueToFinalWrapupButton(boolean retryIfStillInPage) {
        scrollToBottomOfPage();
        PWElement continueButtonElement = isUseMobileViewEnabled() ? buttonContinueMobile : buttonContinueDesktop;
        if (isElementVisibleAndClickable(continueButtonElement, 3)) {
            scrollAndClickOnElement(continueButtonElement);
        } else {
            scrollAndClickOnElement(fallbackContinueButton);
        }
        waitForSpinnerToBeGone();
        if (retryIfStillInPage) {
        	if (isOnBundlePropertyOptionalCoveragesPage()) {
        		clickContinueToFinalWrapupButton(false);
        	}
        }
    }

    public void validatePageTitleSubtitle(FarmersSoftAssert sa) throws Exception {
        sa.assertEquals(getTextFromElement(additionalCoveragesHeading), PAGE_TITLE, "Ace Home Additional coverages page - Title.");
        sa.assertTrue(isElementInViewport(additionalCoveragesHeading), "Ace Home Additional coverages page - page title is in Viewport.");
        sa.assertEquals(getTextFromElement(additionalCoveragesSubheading), PAGE_SUBTITLE, "Ace Home Additional coverages page - Subtitle.");
    }

    public String getQuotePriceOnCard() {
        String breakpoint = isUseMobileViewEnabled() || isMobileApplication() ? "mobile" : "desktop";
        String xpathToBundlePropertyMonthlyAmount = "//mat-card[contains(@class, '" + breakpoint + "')]//tr[2]/td/following-sibling::td[contains(@class, 'monthlyAutopay')]";
        if (isElementPresent(PWBy.xpath(xpathToBundlePropertyMonthlyAmount), 1)) {
            return getTextFromElement(bundleQuoteContainer.findElement(PWBy.xpath(xpathToBundlePropertyMonthlyAmount)));
        }
        if (isUseMobileViewEnabled()) {
            return getTextFromElement(waitElementBeVisible(quotePriceOnCardMobile));
        } else {
            return getTextFromElement(waitElementBeVisible(quotePriceOnCardDesktop));
        }
    }

    public void clickOnContinueButton() {
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(buttonContinueMobile);
        } else {
            waitAndClickElement(buttonContinueDesktop);
        }
    }

    public boolean isContinueButtonDisplayed() {
        return isElementVisible(isUseMobileViewEnabled() ? buttonContinueMobile : buttonContinueDesktop, 3);
    }

    public boolean isCallButtonDisplayed() {
        return isElementVisible(isUseMobileViewEnabled() ? buttonCallMobile : buttonCallDesktop, 3);
    }

    public boolean isQuotePriceStrikeThru() {
        String breakpoint = isUseMobileViewEnabled() || isMobileApplication() ? "mobile" : "desktop";
        String xpathToBundlePropertyRow = "//mat-card[contains(@class, '" + breakpoint + "')]//tr[2]/td/following-sibling::td[contains(@class, 'monthlyAutopay')]/ancestor::tr";
        if (isElementPresent(PWBy.xpath(xpathToBundlePropertyRow), 1)) {
            return getAttributeData(bundleQuoteContainer.findElement(PWBy.xpath(xpathToBundlePropertyRow)), CLASS).contains("strikeout");
        }
        if (isUseMobileViewEnabled()) {
            return getAttributeData(quotePriceOnCardMobile, CLASS).contains("recalculate-text-class");
        } else {
            return getAttributeData(quotePriceOnCardDesktop, CLASS).contains("recalculate-text-class");
        }
    }

    public String getPackagePriceOnCard(int numberOfPackages) throws Exception {
        String PRIMARY_PACKAGE_NAME = "Included coverages";
        String PRIMARY_PACKAGE_XPATH;
        if (isUseMobileViewEnabled()) {
            PRIMARY_PACKAGE_XPATH = String.format(PRIMARY_COVERAGE_PRICE_MOBILE_XPATH, PRIMARY_PACKAGE_NAME);
            if (isElementDisplayed(expandQuoteCard, 2)) {
                waitAndClickElement(expandQuoteCard);
            }
        } else {
            PRIMARY_PACKAGE_XPATH = String.format(PRIMARY_COVERAGE_PRICE_DESKTOP_XPATH, PRIMARY_PACKAGE_NAME);
        }
        PWElement primaryPackagePriceWe = driver().findElement(PWBy.xpath(PRIMARY_PACKAGE_XPATH));
        return getTextFromElement(primaryPackagePriceWe);
    }

    public String getAllOtherCoveragesPriceOnCard() {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard, 2)) {
                waitAndClickElement(expandQuoteCard);
            }
            return getTextFromElement(waitElementBeVisible(quoteAllOtherCoveragesPriceOnCardMobile));
        } else {
            return getTextFromElement(waitElementBeVisible(quoteAllOtherCoveragesPriceOnCardDesktop));
        }
    }

    public String getDiscountsOnCard() {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard, 2)) {
                waitAndClickElement(expandQuoteCard);
            }
            return getTextFromElement(waitElementBeVisible(quoteDiscountsOnCardMobile));
        } else {
            return getTextFromElement(waitElementBeVisible(quoteDiscountsOnCardDesktop));
        }
    }

    public void clickViewMonthlyPricing() {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard, 2)) {
                waitAndClickElement(expandQuoteCard);
            }
            waitAndClickElement(linkViewMonthlyPricingMobile);
        } else {
            waitAndClickElement(linkViewMonthlyPricingDesktop);
        }
    }

    public boolean isViewMonthlyPricingLink() throws Exception {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard, 2)) {
                waitAndClickElement(expandQuoteCard);
            }
            return isElementPresent(PWBy.xpath(VIEW_MONTHLY_PRICING_LINK_MOBILE_XPATH));
        } else {
            return isElementPresent(PWBy.xpath(VIEW_MONTHLY_PRICING_LINK_DESKTOP_XPATH));
        }
    }

    public boolean isViewPayInFullPricingLink() throws Exception {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard, 2)) {
                waitAndClickElement(expandQuoteCard);
            }
            return isElementPresent(PWBy.xpath(VIEW_PAY_IN_FULL_PRICING_LINK_MOBILE_XPATH));
        } else {
            return isElementPresent(PWBy.xpath(VIEW_PAY_IN_FULL_PRICING_LINK_DESKTOP_XPATH));
        }
    }

    public void clickViewPayInFullPricing() {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard, 2)) {
                waitAndClickElement(expandQuoteCard);
            }
            waitAndClickElement(linkViewPayInFullPricingMobile);
        } else {
            waitAndClickElement(linkViewPayInFullPricingDesktop);
        }
    }

    public boolean isPresentmentCardPriceHeader() {
        if (isUseMobileViewEnabled()) {
            return getTextFromElement(presentmentCardPriceHeaderMobile).equals(PRESENTMENT_CARD_PRICE_HEADER);
        } else {
            return getTextFromElement(presentmentCardPriceHeaderDesktop).equals(PRESENTMENT_CARD_PRICE_HEADER);
        }
    }

    public void waitContinueButtonVisibleClickable() {
        PWElement buttonToUse;
        if (isUseMobileViewEnabled()) {
            buttonToUse = isElementDisplayed(fallbackContinueButton, 2) ? fallbackContinueButton : buttonContinueMobile;
        } else {
            buttonToUse = isElementDisplayed(fallbackContinueButton, 2) ? fallbackContinueButton : buttonContinueDesktop;
        }
        waitElementBeVisible(buttonToUse);
    }

    public void toggleAdditionalCoverage(String coverage, boolean selectCoverage) throws Exception {
        String toggleXpath = String.format(TOGGLE_BUTTON_XPATH, coverage) + "//button";
        try {
            PWElement toggleWe = driver().findElement(PWBy.xpath(toggleXpath));
            if (selectCoverage != isAdditionalCoverageToggleSelected(coverage)) {
                waitAndClickElement(toggleWe);
                if (selectCoverage) {
                    wait.until(PWExpectedConditions.attributeContains(PWBy.xpath(String.format(TOGGLE_BUTTON_XPATH, coverage)), CLASS, TOGGLE_CHECKED));
                } else {
                    wait.until(not(PWExpectedConditions.attributeContains(PWBy.xpath(String.format(TOGGLE_BUTTON_XPATH, coverage)), CLASS, TOGGLE_CHECKED)));
                }
            }
        } catch (PWNoSuchElementException nsee) {
            Log.warn("Toggle button for <" + coverage + "> not found on page");
        }
    }

    public boolean isAdditionalCoverageToggleSelected(String coverage) throws Exception {
        return getAttributeData(driver().findElement(PWBy.xpath(String.format(TOGGLE_BUTTON_XPATH, coverage))), CLASS).contains(TOGGLE_CHECKED);
    }

    public boolean isAdditionalCoverageToggleDisplayed(String coverage) throws Exception {
        return isElementDisplayed(PWBy.xpath(String.format(TOGGLE_BUTTON_XPATH, coverage)));
    }

    public String getAdditionalCoverageText(String coverage) throws Exception {
        String toggleTextXpath = "//mat-slide-toggle[contains(.,'" + coverage + "')]/following-sibling::div[contains(@class,'tui-caption-text')]";
        PWElement toggleTextWe = driver().findElement(PWBy.xpath(toggleTextXpath));
        return getTextFromElement(toggleTextWe);
    }

    public String getAdditionalCoveragePrice(String coverage) throws Exception {
        String toggleTextXpath = String.format(TOGGLE_PRICE_XPATH, coverage);
        PWElement togglePriceWe = driver().findElement(PWBy.xpath(toggleTextXpath));
        return getTextFromElement(togglePriceWe);
    }

    public boolean isAdditionalCoveragePriceStrikeThru(String coverage) throws Exception {
        String toggleTextXpath = String.format(TOGGLE_PRICE_XPATH, coverage);
        PWElement togglePriceWe = driver().findElement(PWBy.xpath(toggleTextXpath));
        return getAttributeData(togglePriceWe, CLASS).contains("display-premium-out-of-date");
    }

    public void verifyQuotePresentmentCard(FarmersSoftAssert sa) throws Exception {
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);

        sa.assertTrue(isPresentmentCardPriceHeader(), "Additional coverages page - Quote Presentment card - quote price header.");

        for (int i = 0; i < 2; i++) {
            AppStore appStore = getSessionStorageAppStore();
            AppStore.Home.Quote quote = appStore.getHome().getQuote();
            String selectedPackageCode = quote.getSelectedPackageCode();
            String selectedPaymentMode = quote.getSelectedPaymentMode();
            double totalPremium = Double.parseDouble(appStore.getHome().getCoverageForPackage(selectedPackageCode, selectedPaymentMode).getTotalPremium());
            int numberOfPackages = quote.getRateQuoteResponses().size();
            List<AppStore.Home.Discount> discounts = appStore.getHome().getDiscountsForPackage(selectedPackageCode, selectedPaymentMode);
            if (selectedPaymentMode.equals("PIF")) {
                sa.assertEquals(currencyFormat.parse(getQuotePriceOnCard()).doubleValue(), totalPremium,
                        "Additional coverages page - Quote Presentment card - Quote PIF price.");
                sa.assertEquals(currencyFormat.parse(getPackagePriceOnCard(numberOfPackages)).doubleValue(), totalPremium,
                        "Additional coverages page - Quote Presentment card - Package PIF price.");
                sa.assertEquals(getAllOtherCoveragesPriceOnCard(), "$0", "Additional coverages - Quote Presentment card - All other coverages price.");
                sa.assertEquals(getDiscountsOnCard(), String.format("%s discounts included", discounts.size()),
                        "Additional coverages page - Quote Presentment card - number of discounts included.");
                if (isViewMonthlyPricingLink()) {
                    clickViewMonthlyPricing();
                } else {
                    break;
                }
            } else if (selectedPaymentMode.equals("EFT")) {
                Double monthlyPremium = Math.round((totalPremium / 12) * 100) / 100.00;
                sa.assertEquals(currencyFormat.parse(getQuotePriceOnCard()).doubleValue(), monthlyPremium,
                        "Additional coverages page - Quote Presentment card - Quote monthly price.");
                sa.assertEquals(currencyFormat.parse(getPackagePriceOnCard(numberOfPackages)).doubleValue(), monthlyPremium,
                        "Additional coverages page - Quote Presentment card - Package monthly price.");
                sa.assertEquals(getAllOtherCoveragesPriceOnCard(), "$0", "Review Quote page - Quote Presentment card - All other coverages price");
                sa.assertEquals(getDiscountsOnCard(), String.format("%s discounts included", discounts.size()),
                        "Additional coverages page - Quote Presentment card - number of discounts included");
                if (isViewPayInFullPricingLink()) {
                    clickViewPayInFullPricing();
                } else {
                    break;
                }
            }
            waitForPageToBeReady();
        }
    }

    public void validateToggleOnAdditionalCoveragesPage(FarmersSoftAssert fsa, String coverageName) {
        fsa.assertTrue(toggleButtons.stream().map(this::getTextFromElement).collect(Collectors.toList()).contains(coverageName), "Additional Coverages page - Verify presence of " + coverageName + " toggle.");
    }

    public void validateAdditionalCoveragesTogglesText(ApplicantAceHome applicant, FarmersSoftAssert sa, boolean isNonPrimaryApplicant) throws Exception {
        LinkedHashMap<String, String> additionalCoveragesDescriptionMap = new LinkedHashMap<>();
        String stateCode = applicant.getStateCode();
        additionalCoveragesDescriptionMap.put(WATER_BACKUP_AND_SUMP_OVERFLOW, "Covers sewer and drain back-up and sump-pump failure " +
                "losses except due to flood. This coverage will remain on the policy for the full-term.");
        additionalCoveragesDescriptionMap.put(WATER_BACKUP_AND_SUMP_DISCHARGE, "Covers sewer and drain back-up and sump-pump failure " +
                "losses except due to flood. This coverage will remain on the policy for the full-term.");
        additionalCoveragesDescriptionMap.put(SEWER_AND_DRAIN, "Covers sewer and drain back-up and sump-pump failure " +
                "losses except due to flood. This coverage will remain on the policy for the full-term.");
        additionalCoveragesDescriptionMap.put(UTILITY_LINE, "Covers damage to the sewer line on your property. This coverage will remain on the policy for the full-term.");
        additionalCoveragesDescriptionMap.put(SERVICE_LINE, "Covers damage to the sewer line on your property. This coverage will remain on the policy for the full-term.");
        if (!stateCode.equals(CA)) {
            additionalCoveragesDescriptionMap.put(EQUIPMENT_BREAKDOWN, "Dishwasher breaks and floods your kitchen? This covers both replacing " +
                    "the dishwasher and repairing the damage it caused with only a $500 deductible. This coverage will remain on the policy for the full-term.");
        } else {
            additionalCoveragesDescriptionMap.put(EQUIPMENT_BREAKDOWN, "Dishwasher breaks and floods your kitchen? This covers both replacing " +
                    "the dishwasher and repairing the damage it caused with only a $500 deductible.");
        }
        additionalCoveragesDescriptionMap.put(LIMITED_LEAKAGE_AND_SEEPAGE, "Covers damage from water when there is a hidden, accidental slow leak from pipes or an appliance.");
        additionalCoveragesDescriptionMap.put(LIMITED_WATER_LEAKAGE, "Covers damage from water when there is a hidden, accidental slow leak from pipes or an appliance.");
        additionalCoveragesDescriptionMap.put(LIMITED_PLUMBING_SYSTEM_REPAIR, "We may pay up to $1,000 to repair or replace loss or damage only to that specific part of the " +
                "plumbing system from which a covered water loss may have discharged, erupted, released, or overflowed.");
        additionalCoveragesDescriptionMap.put(PERSONAL_INJURY, "This coverage can pay for personal injury damages that you are legally obligated to pay as a result of a covered occurrence.");
        additionalCoveragesDescriptionMap.put(ZERO_DEDUCTIBLE_GLASS, "Covers replacing broken window glass with no deductible.");
        additionalCoveragesDescriptionMap.put(RESIDENCE_GLASS_WAIVER_OF_DEDUCTIBLE, "Covers replacing broken window glass with no deductible.");
        additionalCoveragesDescriptionMap.put(LIMITED_MOLD, "This coverage can pay for expenses required to remediate any mold which results from the repair or replacement of a covered loss.");
        additionalCoveragesDescriptionMap.put(INCREASED_LIMITS_FOR_LIMITED_MOLD, "This coverage can pay for expenses required to remediate any mold which results from the repair or replacement of a covered loss.");
        String lossAssessmentDescription = "This coverage increases the loss assessment limit from the already included $1,500 " +
                "to help cover the cost of an assessment by your association in the event of a covered loss.";
        if (stateCode.equals(CT)) {
            // US805335: [Continued] FFQ Ace home CT - State specific variations
            lossAssessmentDescription = lossAssessmentDescription.replace("$1,500", "$1,000");
        }
        additionalCoveragesDescriptionMap.put(HOA_LOSS_PAYMENT, lossAssessmentDescription);
        additionalCoveragesDescriptionMap.put(ASSOCIATION_LOSS_ASSESSMENT, "This coverage increases the loss assessment limit from the already included $1,500 " +
                "to help cover the cost of an assessment by your association in the event of a covered loss.");
        additionalCoveragesDescriptionMap.put("Association Loss Assessment", "This coverage increases the loss assessment limit from the already included $1,500 " +
                "to help cover the cost of an assessment by your association in the event of a covered loss.");
        if (!stateCode.equals(CA)) {
            additionalCoveragesDescriptionMap.put(INCREASED_COVERAGE_FOR_VALUABLES_TITLE, "Select your own limits for all covered perils if you need more " +
                    "coverage than the special limits for personal property included in this quote for items like your jewelry, furs(including articles for " +
                    "which fur represents the principal value), fine arts, imported or specialty rugs, stamp and coin collections, silverware, goldware, and pewterware," +
                    " and firearms. Maximum limit for any single article is the lesser of the limit you select or $2,500.");
        } else {
            additionalCoveragesDescriptionMap.put(INCREASED_COVERAGE_FOR_VALUABLES_TITLE, "Select your own limits for all covered perils if you need more " +
                    "coverage than the special limits for personal property included in this quote for items like your jewelry, furs, including articles for " +
                    "which fur represents the principal value, fine arts, imported or specialty rugs, stamp and coin collections, silverware, goldware, and pewterware, " +
                    "and firearms. Maximum limit for any single article is the lesser of the limit you select or $2,500.");
        }
        additionalCoveragesDescriptionMap.put(E_BIKES_AND_GOLF_CARTS, "Provides coverage for pedal assist class 1 e-bikes and motorized golf carts not subject to motor " +
                "vehicle registration while: 1) on the residence premises, 2) on the golf course and being used for golfing purposes, or 3) in a private residential " +
                "community where it can legally travel and that is subject to the authority of a property owners association and that contains the residence premises.");
        additionalCoveragesDescriptionMap.put(LIMITED_ESCAPED_LIQUID_FUEL, "Provides coverage for damage caused by abrupt and accidental liquid fuel escapes from a tank " +
                "located at the covered residence. This coverage includes costs and expenses to repair or replace damage to covered property, liquid fuel remediation, and " +
                "to stop any further escape or spread of the liquid fuel.");
        additionalCoveragesDescriptionMap.put(EARTHQUAKE, "Provides coverage for direct physical loss or damage caused by earthquake subject to the coverage provided in " +
                "the endorsement and the earthquake deductible selected. The underlying property policies exclude loss caused by all earth movements, including earthquakes.");
        additionalCoveragesDescriptionMap.put(SINKHOLE_LOSS, "Provides coverage for accidental, actual, and direct physical sinkhole loss.");
        additionalCoveragesDescriptionMap.put(IDENTITY_FRAUD, "Helps with the costs of repairing credit integrity that was compromised by identity theft.");
        additionalCoveragesDescriptionMap.put(SPECIAL_WATER_LOSS_LIMIT_TITLE, "Provides lower limits for non-weather water losses. The limit is a percentage of the Dwelling coverage (Coverage A). " +
                "When applied, Access through foundations and walls coverage will not be available.");
        additionalCoveragesDescriptionMap.put("Special water Loss limit", "Provides lower limits for non-weather water losses. The limit is a percentage of the Dwelling coverage (Coverage A). " +
                "When applied, Access through foundations and walls coverage will not be available.");
        additionalCoveragesDescriptionMap.put(WATERCRAFT_LIABILITY_FAMILY_PROTECTION, "This coverage is for bodily injury to family and household members other than " +
                "the Named Insured, that results from an occurrence involving watercraft. (Unselecting this option will deduct $2.00 from your Package price. If you " +
                "choose to decline this coverage, you must sign and return the Declination of Family Protection Liability Coverage form.)");
        if (isEligibleForFortifiedRoofUpgradeOption(stateCode)) {
            additionalCoveragesDescriptionMap.put(FORTIFIED_ROOF_UPGRADE, "With the FORTIFIED Roof\u2122 Upgrade endorsement, if the roof is damaged by a covered loss that requires a complete roof replacement, " +
                    "coverage is available for the added costs for labor and materials to rebuild the roof to FORTIFIED Roof standards. " +
                    "The coverage will also pay for the added expenses for the use of an IBHS certified evaluator to obtain certification.");
        }
        List<String> toggles = toggleButtons.stream().map(this::getTextFromElement).collect(Collectors.toList());
        Log.info("Displayed Additional coverages toggles: " + toggles);
        List<String> additionalCoverages = getAdditionalCoverageNames(applicant, isNonPrimaryApplicant);
        for (String coverageTitle : additionalCoverages) {
            Log.info(">> Validating Additional coverage: " + coverageTitle);
            sa.assertTrue(isElementDisplayed(PWBy.xpath(String.format(TOGGLE_BUTTON_XPATH, coverageTitle))),
                    "Ace Home Additional Coverage page - coverage toggle: " + coverageTitle + " is displayed.");
            sa.assertEquals(getAdditionalCoverageText(coverageTitle), additionalCoveragesDescriptionMap.get(coverageTitle),
                    "Ace Home Additional Coverage page - coverage description text: " + coverageTitle + " is displayed.");
            String coveragePrice = getCoveragePriceForCoverageTitle(coverageTitle);
            if (!coverageTitle.equals(INCREASED_COVERAGE_FOR_VALUABLES_TITLE)) {
                sa.assertEquals(getAdditionalCoveragePrice(coverageTitle), coveragePrice,
                        "Ace Home Additional Coverage page - coverage premium: " + coverageTitle + " is correctly displayed.");
            }
        }
    }

    public void validateAdditionalCoveragesTogglesPremium(ApplicantAceHome applicant, FarmersSoftAssert fsa, boolean isNonPrimaryApplicant) throws Exception {
        String separator = isSafariBrowser() ? EMPTY_STRING : SPACE;
        List<String> HOA_LOSS_PAYMENT_RADIO_TEXT;
        if (applicant.getStateCode().equals(CT)) {
            HOA_LOSS_PAYMENT_RADIO_TEXT = Arrays.asList("$10,000 Total combined limit: $11,000", "$25,000 Total combined limit: $26,000",
                    "$50,000 Total combined limit: $51,000");
        } else {
            HOA_LOSS_PAYMENT_RADIO_TEXT = Arrays.asList("$10,000 Total combined limit: $11,500", "$25,000 Total combined limit: $26,500",
                    "$50,000 Total combined limit: $51,500");
        }
        final List<String> WATER_BACKUP_RADIO_TEXT = Arrays.asList("$5,000", "$10,000", "$15,000", "$25,000", "$50,000");
        final String WATER_BACKUP_TOGGLE_BUTTON1_TEXT = "Provides coverage for loss or damage to all property covered under Personal Property on the policy.";
        final String WATER_BACKUP_TOGGLE_BUTTON2_TEXT = "Provides coverage for loss or damage to washing machines, clothes dryers, freezers and the food " +
                "therein, refrigerators and the food therein, ranges, portable dishwashers, portable water softeners, and dehumidifiers only.";
        final List<String> LIMITED_MOLD_RADIO_TEXT = Arrays.asList("$5,000", "$10,000");
        final String INCREASED_LIMITS_FOR_LIMITED_MOLD_RADIO_TEXT = "$25,000";
        final List<String> LIMITED_LEAKAGE_RADIO_TEXT = Arrays.asList("$5,000", "$10,000", "$25,000");
        final List<String> INCREASED_VALUABLES_CHECKBOXES_TEXT = Arrays.asList("Jewelry", "Other articles");
        final String INCREASED_COVERAGE_FOOTER_TEXT = "Total combined: %s *There is a max combined limit of %s.";
        final String INCREASED_COVERAGE_FOR_VALUABLES_TEXT = "Select your own limits for all covered perils if you need more coverage than the special limits " +
                "for personal property included in this quote for items like your jewelry, furs(including articles for which fur represents the principal value), " +
                "fine arts, imported or specialty rugs, stamp and coin collections, silverware, goldware, and pewterware, and firearms. Maximum limit for any " +
                "single article is the lesser of the limit you select or $2,500. Maximum combined coverage limit depends on your Personal Property coverage limit." + separator +
                "The special limits for personal property included in this quote depend on the coverage package you selected.";
        final String INCREASED_COVERAGE_FOR_VALUABLES_FIREARMS_TEXT = "Firearms - up to $2,500 per loss by theft." + separator +
                "Security, deeds, valuable papers and stamps - up to $1,000 per covered loss." + separator +
                "Silverware, gold ware, platinum ware and pewter ware - up to $2,500 per loss by theft." + separator +
                "Fine arts and imported or specialty rugs - up $5,000 per covered loss.";
        final String INCREASED_COVERAGE_FOR_VALUABLES_WATCHES_TEXT = "Watches, precious stones, semi-precious stones and furs - up to $1,000 for any one item " +
                "and up to $2,500 total limit per loss by theft.";
        final List<String> LIMITED_ESCAPED_LIQUID_FUEL_RADIO_TEXT = Arrays.asList("$50,000", "$100,000", "Above ground - indoors", "Above ground - outdoors",
                "Below ground");
        final List<String> EARTHQUAKE_RADIO_TEXT = Arrays.asList("10%", "15%", "20%", "25%");
        final List<String> EARTHQUAKE_INFO_DIALOG_PARAGRAPHS = List.of(
                //Coverage type: Full
                "Coverage for direct physical loss or damage caused by earthquake subject to the Coverage A (Dwelling) limit.",
                //Coverage type: Limited
                "Coverage for direct physical loss or damage caused by earthquake subject to the following: " +
                        "Coverage A (Dwelling) - We will pay up to the Coverage A limit. " +
                        "Coverage B and C are covered up to the sub-limits below only if the Coverage A loss exceeds the deductible amount selected. " +
                        "Coverage B (Separate structures) - $1,000 limit " +
                        "Coverage C (Personal property) - $2,000 limit " +
                        "Coverage D (Loss of use) - $2,500 limit including $1,500 limit for Additional living expense; $1,000 limit for HOA loss payment",
                // Deductible
                "All covered earthquake loss or damage under Coverage A is subject to this deductible. This deductible applies to each earthquake event.",
                // Masonry veneer
                "If more than one-third of the exterior of the home is masonry veneer construction, this material is excluded from coverage in the event of " +
                        "an Earthquake. Coverage for masonry veneer construction can be added for an additional charge.");
        final List<String> SPECIAL_WATER_LOSS_LIMIT_RADIO_TEXT = Arrays.asList(" (2.5% of Dwelling limit)", " (5% of Dwelling limit)",
                " (10% of Dwelling limit)", " (15% of Dwelling limit)", " (20% of Dwelling limit)", " (25% of Dwelling limit)");

        List<String> additionalCoverages = getAdditionalCoverageNames(applicant, isNonPrimaryApplicant);
        List<String> togglesDisplayed = toggleButtons.stream().map(this::getTextFromElement).sorted().collect(Collectors.toList());
        fsa.assertEquals(togglesDisplayed, additionalCoverages, "Additional coverages page - verify correct list of toggles.");
        String totalQuotePrice = getQuotePriceOnCard();
        Double dQuotePrice = CurrencyFormat.convertCurrencyStringToDouble(totalQuotePrice);
        for (String coverageTitle : togglesDisplayed) {
            Log.info(">> Validating Additional coverage: " + coverageTitle);
            String additionalCoveragePrice = getAdditionalCoveragePrice(coverageTitle);
            if (!coverageTitle.equals(WATERCRAFT_LIABILITY_FAMILY_PROTECTION)) {
                toggleAdditionalCoverage(coverageTitle, true);
            }
            if (isElementDisplayed(dialogButtonOk, 2)) {
                waitAndClickElement(dialogButtonOk);
            }
            // validating toggle price is reflected in the quote presentment card
            if (!additionalCoveragePrice.isBlank() && !coverageTitle.equals(INCREASED_COVERAGE_FOR_VALUABLES_TITLE)) {
                sleep(2);
                Double dAdditionalCoverage = CurrencyFormat.convertCurrencyStringToDouble(additionalCoveragePrice);
                fsa.assertEquals(CurrencyFormat.convertCurrencyStringToDouble(getQuotePriceOnCard().split("/")[0]), dQuotePrice + dAdditionalCoverage, 0.011d,
                        "Ace Home Additional coverage page - toggle: " + coverageTitle + " Total Quote price on Presentment card.");
                if (!isElementPresent(PWBy.xpath("//tr[2]/td/following-sibling::td[contains(@class, 'monthlyAutopay')]"), 2)) {
                    fsa.assertEquals(getAllOtherCoveragesPriceOnCard().replace(COMMA, EMPTY_STRING),
                            additionalCoveragePrice.split("/")[0].replace("Starting at ", EMPTY_STRING).replace(".00", EMPTY_STRING),
                            "Ace Home Additional coverage page - toggle: " + coverageTitle + " All other coverages price.");
                }
            }
            // Validating toggles with dependent sections, commented out some lines, as currently those coverage changes lead to Recalculate, which prevents any further toggles updates
            AppStore.Home home = getSessionStorageAppStore().getHome();
            String packageCode = home.getQuote().getSelectedPackageCode();
            String paymentMode = home.getQuote().getSelectedPaymentMode();
            String dwellingCoverage = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(home.getCoverageForPackage(packageCode, paymentMode).getDwellingCoverage());
            switch (coverageTitle) {
                case HOA_LOSS_PAYMENT:
                    fsa.assertEquals(getTextFromElement(headerHoaLossPayment), "Coverage limit", "HOA loss payment section header.");
                    fsa.assertEquals(radioButtonsHoaLossPayment.size(), 3, "HOA loss payment section number of radio-buttons.");
                    int i = 0;
                    for (PWElement matRadio : radioButtonsHoaLossPayment) {
                        fsa.assertEquals(getTextFromElement(matRadio), HOA_LOSS_PAYMENT_RADIO_TEXT.get(i),
                                "HOA loss payment section radio button: " + i + " text.");
                        if (i == 0) {
                            fsa.assertTrue(getAttributeData(matRadio, CLASS).contains(RADIO_BUTTON_CHECKED),
                                    "HOA loss payment section first radio button is selected.");
                        }
                        i++;
                    }
                    break;
                case WATER_BACKUP_AND_SUMP_OVERFLOW:
                    if (!applicant.getStateCode().equals(VA)) {
                        fsa.assertEquals(getTextFromElement(headerWaterBackup), "Coverage limit", "Water backup and sump overflow section header.");
                        fsa.assertEquals(getTextFromElement(footerWaterBackup), "Coverage applies to", "Water backup and sump overflow section footer.");
                        fsa.assertEquals(radioButtonsWaterBackup.size(), 5, "Water backup and sump overflow section number of radio-buttons.");
                        i = 0;
                        for (PWElement matRadio : radioButtonsWaterBackup) {
                            fsa.assertEquals(getTextFromElement(matRadio), WATER_BACKUP_RADIO_TEXT.get(i),
                                    "Water backup and sump overflow section radio button: " + (i + 1) + " text.");
                            if (i == 0) {
                                fsa.assertTrue(getAttributeData(matRadio, CLASS).contains(RADIO_BUTTON_CHECKED),
                                        "Water backup and sump overflow section first radio button is selected.");
                            }
                            i++;
                        }
                        fsa.assertEquals(getTextFromElement(toggleButtonsWaterBackup1), "Covered property", "Water backup and sump overflow section coverage toggle button1 name.");
                        fsa.assertEquals(getTextFromElement(toggleButtonsWaterBackupText), WATER_BACKUP_TOGGLE_BUTTON1_TEXT,
                                "Water backup and sump overflow section coverage toggle button1 text.");
                        fsa.assertTrue(getAttributeData(toggleButtonsWaterBackup1, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED),
                                "Water backup and sump overflow section toggle button1 is selected.");
                        waitAndClickElement(toggleButtonsWaterBackup2.findElement(PWBy.xpath("button")));
                        fsa.assertTrue(getAttributeData(toggleButtonsWaterBackup2, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED),
                                "Water backup and sump overflow section toggle button2 is selected.");
                        fsa.assertEquals(getTextFromElement(toggleButtonsWaterBackup2), "Specific appliances", "Water backup and sump overflow section coverage toggle button2 name.");
                        fsa.assertEquals(getTextFromElement(toggleButtonsWaterBackupText), WATER_BACKUP_TOGGLE_BUTTON2_TEXT,
                                "Water backup and sump overflow section coverage toggle button2 text.");
                        waitAndClickElement(toggleButtonsWaterBackup1.findElement(PWBy.xpath("button")));
                        fsa.assertTrue(isAdditionalCoveragePriceStrikeThru(WATER_BACKUP_AND_SUMP_OVERFLOW),
                                "Additional coverages page - coverage premium price strike-thru for Water backup and sump overflow.");
                    } else {
                        String minimalCoverage = home.getCoverageForPackage(packageCode, paymentMode).getCvgInfoForCvgDesc(WATER_BACKUP_AND_SUMP_OVERFLOW).getCvgAmt();
                        fsa.assertEquals(getValueFromWebElement(inputWaterBackup), minimalCoverage, "Water backup and sump overflow input field value.");
                        fsa.assertEquals(getTextFromElement(subTextInputWaterBackup), minimalCoverage + " - " + dwellingCoverage, "Water backup and sump overflow input field Sub-text.");
                        fsa.assertTrue(isElementVisible(buttonWaterBackupMinus, 2), "Water backup and sump overflow minus button is displayed.");
                        fsa.assertTrue(isElementVisible(buttonWaterBackupPlus, 2), "Water backup and sump overflow plus button is displayed.");
                        waitAndClickElement(buttonWaterBackupPlus);
                        fsa.assertEquals(getValueFromWebElement(inputWaterBackup), CurrencyFormat.convertDoubleToCurrencyString(CurrencyFormat.convertCurrencyStringToDouble(minimalCoverage) +
                                        CurrencyFormat.convertCurrencyStringToDouble("$1,000")).replace(".00", EMPTY_STRING),
                                "Increased coverage for Water backup and sump overflow form field.");
                        waitAndClickElement(buttonWaterBackupMinus);
                        fsa.assertEquals(getValueFromWebElement(inputWaterBackup), minimalCoverage, "Decreased coverage for Water backup and sump overflow form field.");
                    }
                    break;
                case LIMITED_MOLD:
                    fsa.assertEquals(getTextFromElement(headerLimitedMold), "Coverage limit", "Limited mold section header.");
                    fsa.assertEquals(radioButtonsLimitedMold.size(), 2, "Limited mold section number of radio-buttons.");
                    i = 0;
                    for (PWElement matRadio : radioButtonsLimitedMold) {
                        fsa.assertEquals(getTextFromElement(matRadio), LIMITED_MOLD_RADIO_TEXT.get(i),
                                "Limited mold section radio button: " + (i + 1) + " text.");
                        if (i == 0) {
                            fsa.assertTrue(getAttributeData(matRadio, CLASS).contains(RADIO_BUTTON_CHECKED),
                                    "Limited mold section first radio button is selected.");
                        }
                        i++;
                    }
                    break;
                case INCREASED_LIMITS_FOR_LIMITED_MOLD:
                    fsa.assertEquals(getTextFromElement(headerIncreasedLimitsForLimitedMold), "Coverage limit", "Increased limits for Limited mold section header.");
                    fsa.assertEquals(getTextFromElement(radioButtonIncreasedLimitsForLimitedMold), INCREASED_LIMITS_FOR_LIMITED_MOLD_RADIO_TEXT,
                            "Increased limits for Limited mold section radio button text.");
                    fsa.assertTrue(getAttributeData(radioButtonIncreasedLimitsForLimitedMold, CLASS).contains(RADIO_BUTTON_CHECKED),
                            "Increased limits for Limited mold section radio button is selected.");
                    break;
                case LIMITED_LEAKAGE_AND_SEEPAGE:
                    fsa.assertEquals(getTextFromElement(headerLimitedLeakage), "Coverage limit", "Limited mold section header.");
                    fsa.assertEquals(radioButtonsLimitedLeakage.size(), 3, "Limited leakage & seepage section number of radio-buttons.");
                    i = 0;
                    for (PWElement matRadio : radioButtonsLimitedLeakage) {
                        fsa.assertEquals(getTextFromElement(matRadio), LIMITED_LEAKAGE_RADIO_TEXT.get(i),
                                "Limited leakage & seepage section radio button: " + (i + 1) + " text.");
                        if (i == 0) {
                            fsa.assertTrue(getAttributeData(matRadio, CLASS).contains(RADIO_BUTTON_CHECKED),
                                    "Limited leakage & seepage section first radio button is selected.");
                        }
                        i++;
                    }
                    break;
                case INCREASED_COVERAGE_FOR_VALUABLES_TITLE:
                    fsa.assertEquals(getTextFromElement(headerIncreasedValuables), "Select the valuable types for increased coverage:*",
                            "Increased coverage for valuables section header.");
                    fsa.assertEquals(getAttributeData(headerIncreasedValuablesInfoIcon, ARIA_LABEL), "info icon for Select the valuable types for increased coverage:*",
                            "Increased coverage for valuables section header Info icon.");
                    // validating Info section side-sheet Content
                    waitAndClickElement(headerIncreasedValuablesInfoIcon);
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogHeader), INCREASED_COVERAGE_FOR_VALUABLES_TITLE, "Increased coverage for valuables info section title");
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogMainContent), INCREASED_COVERAGE_FOR_VALUABLES_TEXT, "Increased coverage for valuables info section text content");
                    fsa.assertTrue(isElementVisible(increasedValuablesInfoDialogDivider1, 1), "Increased coverage for valuables info section Divider 1");
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogPackageName), getSelectedPackageName() + " package",
                            "Increased coverage for valuables info section package name");
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogJewelry), "Jewelry", "Increased coverage for valuables info section Jewelry title");
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogJewelryText), "Jewelry - up to $1,000 for any one item and up to $2,500 total limit per loss by theft.",
                            "Increased coverage for valuables info section Jewelry section text");
                    fsa.assertTrue(isElementVisible(increasedValuablesInfoDialogDivider2, 1), "Increased coverage for valuables info section Divider 2");
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogOtherArticles), "Other articles", "Increased coverage for valuables info section Other articles title");
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogOtherArticlesTextFirearms), INCREASED_COVERAGE_FOR_VALUABLES_FIREARMS_TEXT,
                            "Increased coverage for valuables info section Other articles Firearms section text");
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogOtherArticlesTextWatches), INCREASED_COVERAGE_FOR_VALUABLES_WATCHES_TEXT,
                            "Increased coverage for valuables info section Other articles Watches section text");
                    fsa.assertTrue(isElementVisible(increasedValuablesInfoDialogDivider3, 1), "Increased coverage for valuables info section Divider 3");
                    waitAndClickElement(increasedValuablesInfoDialogCloseButton);
                    //
                    fsa.assertEquals(checkboxesIncreasedValuables.size(), 2, "Increased coverage for valuables section number of checkboxes.");
                    double maxLimitJewelry = Math.min(75000d, CurrencyFormat.convertCurrencyStringToDouble(dwellingCoverage) * 0.28);
                    String maxLimitJewelryStr = CurrencyFormat.convertDoubleToCurrencyStringNoDecimals(maxLimitJewelry);
                    fsa.assertEquals(getTextFromElement(footerIncreasedValuables), String.format(INCREASED_COVERAGE_FOOTER_TEXT, "$0", maxLimitJewelryStr),
                            "Increased coverage for valuables section footer text with no selected checkboxes.");
                    i = 0;
                    for (PWElement matCheckbox : checkboxesIncreasedValuables) {
                        fsa.assertEquals(getTextFromElement(matCheckbox.findElement(PWBy.xpath("../../div"))), INCREASED_VALUABLES_CHECKBOXES_TEXT.get(i),
                                "Increased coverage for valuables section checkboxes: " + (i + 1) + " text.");
                        if (i == 0) {
                            clickElement(labelIncreasedCoverageJewelry);
                            fsa.assertTrue(getAttributeData(matCheckbox, CLASS).contains(CHECKBOX_CHECKED),
                                    "Increased coverage for valuables section first checkbox (Jewelry) is selected.");
                            fsa.assertEquals(getValueFromWebElement(inputIncreasedCoverageJewelry), "$1,000", "Increased coverage for valuables section Jewelry form field.");
                            fsa.assertEquals(getTextFromElement(footerIncreasedValuables), String.format(INCREASED_COVERAGE_FOOTER_TEXT, "$1,000", maxLimitJewelryStr),
                                    "Increased coverage for valuables section footer text with Jewelry selected checkbox.");
                            waitElementBeVisibleClickable(increaseCoverageJewelry);
                            waitAndClickElement(increaseCoverageJewelry);
                            fsa.assertEquals(getValueFromWebElement(inputIncreasedCoverageJewelry), "$2,000",
                                    "Increased coverage for valuables section Jewelry form field.");
                            fsa.assertEquals(getTextFromElement(footerIncreasedValuables), String.format(INCREASED_COVERAGE_FOOTER_TEXT, "$2,000", maxLimitJewelryStr),
                                    "Increased coverage for valuables section footer text with $2,000 for Jewelry selected checkboxes.");

                            waitAndClickElement(decreaseCoverageJewelry);
                            fsa.assertEquals(getValueFromWebElement(inputIncreasedCoverageJewelry), "$1,000",
                                    "Decreased coverage for valuables section Jewelry form field to $1,000.");
                            fsa.assertEquals(getTextFromElement(footerIncreasedValuables), String.format(INCREASED_COVERAGE_FOOTER_TEXT, "$1,000", maxLimitJewelryStr),
                                    "Decreased coverage for valuables section footer text with $1,000 for Jewelry selected checkboxes.");
                        } else {
                            clickElement(labelIncreasedCoverageOther);
                            fsa.assertTrue(getAttributeData(matCheckbox, CLASS).contains(CHECKBOX_CHECKED),
                                    "Increased coverage for valuables section second checkbox (Other articles) is selected.");
                            fsa.assertEquals(getValueFromWebElement(inputIncreasedCoverageOther), "$5,000",
                                    "Increased coverage for valuables section Other form field.");
                            fsa.assertEquals(getTextFromElement(footerIncreasedValuables), String.format(INCREASED_COVERAGE_FOOTER_TEXT, "$6,000", maxLimitJewelryStr),
                                    "Increased coverage for valuables section footer text with Jewelry and Other selected checkboxes.");
                            waitAndClickElement(increaseCoverageOther);
                            fsa.assertEquals(getValueFromWebElement(inputIncreasedCoverageOther), "$6,000",
                                    "Increased coverage for valuables section Jewelry form field.");
                            fsa.assertEquals(getTextFromElement(footerIncreasedValuables), String.format(INCREASED_COVERAGE_FOOTER_TEXT, "$7,000", maxLimitJewelryStr),
                                    "Increased coverage for valuables section footer text with $1,000 for Jewelry and $6,000 for Other checkboxes.");

                            waitAndClickElement(decreaseCoverageOther);
                            fsa.assertEquals(getValueFromWebElement(inputIncreasedCoverageOther), "$5,000",
                                    "Decreased coverage for valuables section Jewelry form field to $5,000.");
                            fsa.assertEquals(getTextFromElement(footerIncreasedValuables), String.format(INCREASED_COVERAGE_FOOTER_TEXT, "$6,000", maxLimitJewelryStr),
                                    "Decreased coverage for valuables section footer text with $1,000 for Jewelry and $5,000 for Other checkboxes.");
                        }
                        i++;
                    }
                    fsa.assertTrue(isAdditionalCoveragePriceStrikeThru(INCREASED_COVERAGE_FOR_VALUABLES_TITLE),
                            "Additional coverages page - coverage premium  price strike-thru for Increased coverage for valuables.");
                    fsa.assertTrue(isQuotePriceStrikeThru(), "Additional coverages page - Quote price on card is strike-thru");
                    validateIncreasedCoverageLimits(applicant, HOME, fsa);
                    break;
                case LIMITED_ESCAPED_LIQUID_FUEL:
                    fsa.assertEquals(getTextFromElement(headersLimitedEscapedLiquidFuelSection.get(0)), "Coverage limit", "Limited escaped liquid fuel section header 1.");
                    fsa.assertEquals(getTextFromElement(headersLimitedEscapedLiquidFuelSection.get(1)), "Location of fuel tank", "Limited escaped liquid fuel section header 2.");
                    fsa.assertEquals(radioButtonsLimitedEscapedLiquidFuel.size(), 5, "Limited escaped liquid fuel section number of radio-buttons.");
                    i = 0;
                    for (PWElement matRadio : radioButtonsLimitedEscapedLiquidFuel) {
                        fsa.assertEquals(getTextFromElement(matRadio), LIMITED_ESCAPED_LIQUID_FUEL_RADIO_TEXT.get(i),
                                "Limited escaped liquid fuel section radio button: " + (i + 1) + " text.");
                        if (List.of(0, 3).contains(i)) {
                            fsa.assertTrue(getAttributeData(matRadio, CLASS).contains(RADIO_BUTTON_CHECKED),
                                    "Limited escaped liquid fuel section radio button " + LIMITED_ESCAPED_LIQUID_FUEL_RADIO_TEXT.get(i) + " is selected.");
                        }
                        i++;
                    }
                    break;
                case EARTHQUAKE:
                    List<String> sectionHeaders = List.of("Coverage type", "Deductible", "Is the structure attached to the foundation?",
                            "Would you like to add coverage for masonry veneer exterior construction?");
                    fsa.assertEquals(headersEarthquakeSection.stream().map(this::getTextFromElement).collect(Collectors.toList()), sectionHeaders,
                            "Earthquake section headers.");
                    fsa.assertEquals(radioButtonsEarthquake.size(), 4, "Earthquake section number of radio-buttons.");
                    List<String> sectionToggleButtons = List.of(FULL, "Limited", YES, NO, YES, NO);
                    fsa.assertEquals(toggleButtonsEarthquake.stream().map(this::getTextFromElement).collect(Collectors.toList()), sectionToggleButtons,
                            "Earthquake section toggle buttons.");
                    i = 0;
                    for (PWElement matRadio : radioButtonsEarthquake) {
                        fsa.assertEquals(getTextFromElement(matRadio), EARTHQUAKE_RADIO_TEXT.get(i),
                                "Earthquake section radio button: " + (i + 1) + " text.");
                        i++;
                    }
                    List<String> infoIconsText = List.of("info icon for Coverage type", "info icon for Deductible",
                            "info icon for Would you like to add coverage for masonry veneer exterior construction?");
                    fsa.assertEquals(earthquakeInfoIcons.stream().map(info -> getAttributeData(info, ARIA_LABEL)).collect(Collectors.toList()),
                            infoIconsText, "Earthquake section info icons.");

                    waitAndClickElement(earthquakeInfoIcons.get(0));
                    fsa.assertEquals(getTextFromElement(earthquakeCoverageInfoDialogHeader), "Earthquake coverage", "Earthquake info dialog header.");
                    List<String> infoDialogSubheaders = List.of("Coverage type: Full", "Coverage type: Limited", "Deductible", "Masonry veneer");
                    fsa.assertEquals(earthquakeInfoDialogSubheaders.stream().map(this::getTextFromElement).collect(Collectors.toList()), infoDialogSubheaders,
                            "Earthquake info dialog sub-headers.");
                    fsa.assertEquals(earthquakeInfoDialogParagraphs.stream().map(this::getTextFromElement).collect(Collectors.toList()),
                            EARTHQUAKE_INFO_DIALOG_PARAGRAPHS, "Earthquake info dialog paragraphs text content.");
                    waitAndClickElement(closeSidesheetButton);
                    break;
                case SPECIAL_WATER_LOSS_LIMIT_TITLE:
                    scrollToBottomOfPage();
                    fsa.assertEquals(getTextFromElement(headerSpecialWaterLossLimit), "Coverage limit", "Special water loss limit section header.");
                    fsa.assertEquals(radioButtonsSpecialWaterLossLimit.size(), 6, "Special water loss limit section number of radio-buttons.");
                    List<Double> percentages = List.of(0.025d, 0.05d, 0.10d, 0.15d, 0.20d, 0.25d);
                    i = 0;
                    for (PWElement matRadio : radioButtonsSpecialWaterLossLimit) {
                        double prefix = CurrencyFormat.convertCurrencyStringToDouble(dwellingCoverage);
                        prefix = prefix * percentages.get(i);
                        fsa.assertEquals(getTextFromElement(matRadio), CurrencyFormat.convertDoubleToCurrencyString(prefix).split("\\.")[0] +
                                SPECIAL_WATER_LOSS_LIMIT_RADIO_TEXT.get(i), "Special water loss limit section radio button: " + i + " text.");
                        if (i == 0) {
                            fsa.assertTrue(getAttributeData(matRadio, CLASS).contains(RADIO_BUTTON_CHECKED),
                                    "Special water loss limit section first radio button is selected.");
                        }
                        i++;
                    }
                    break;
                case WATERCRAFT_LIABILITY_FAMILY_PROTECTION:
                    String DIALOG_TITLE = "Watercraft liability - Family protection";
                    String DIALOG_CONTENT = "In your state, this coverage is automatically included in your quote. Unselecting this option " +
                            "will deduct $2.00 from your Package price. If you choose to decline this coverage, you must sign and return " +
                            "the Declination of Family Protection Liability Coverage form.";
                    fsa.assertTrue(isAdditionalCoverageToggleSelected(coverageTitle), "Additional coverage toggle (MN) has to be turned On by default.");

                    toggleAdditionalCoverage(coverageTitle, false);
                    fsa.assertEquals(getTextFromElement(watercraftCoverageDialogTitle), DIALOG_TITLE, "Additional coverage toggle (MN) confirmation dialog title");
                    fsa.assertEquals(getTextFromElement(watercraftCoverageDialogContent), DIALOG_CONTENT, "Additional coverage toggle (MN) confirmation dialog content");
                    waitAndClickElement(buttonOk);
                    tryRecalculateQuote();

                    toggleAdditionalCoverage(coverageTitle, false);
                    waitAndClickElement(buttonRemoveCoverage);
                    tryRecalculateQuote();
                    paymentMode = getSessionStorageAppStore().getHome().getQuote().getSelectedPaymentMode();
                    String coveragePrice = paymentMode.equals("PIF") ? "$-2/year" : "$-0.17/month";
                    fsa.assertEquals(getAdditionalCoveragePrice(coverageTitle), coveragePrice,
                            "Additional Coverage page - coverage premium: " + coverageTitle + " is correctly displayed.");
                    break;
            }
            toggleAdditionalCoverage(coverageTitle, false);
            if (isElementDisplayed(dialogButtonOk, 2)) {
                waitAndClickElement(dialogButtonOk);
            }
            tryRecalculateQuote();
        }

    }

    protected void validateIncreasedCoverageLimits(ApplicantAceHome applicant, String lob, FarmersSoftAssert sa) {
        sa.assertTrue(errorsIncreasedCoverageSection.isEmpty(), "Additional coverages page - Increased values section does not have any errors");
        for (int i = 0; i < 75; i++) {
            if (applicant.getStateCode().equals(NC)) {
                waitAndClickElement(increaseCoverageSecurities);
                if (lob.equals(RENTERS) && (i > 15)) {
                    break;
                }
            } else {
                if (isElementVisibleAndClickable(increaseCoverageJewelry, 3)) {
                    waitAndClickElement(increaseCoverageJewelry);
                }
            }
        }
        waitElementBeVisible(footerIncreasedValuablesStarText);
        sa.assertTrue(getAttributeData(footerIncreasedValuablesStarText, CLASS).contains("tui-error"),
                "Additional coverages page - Increased values star footnote displays an error");
        int numberOfErrorsInSection = errorsIncreasedCoverageSection.size();
        sa.assertTrue(numberOfErrorsInSection > 1, "Additional coverages page - Increased values section displays expected errors");
        for (int i = 0; i < numberOfErrorsInSection - 1; i++) {
            sa.assertEquals(getTextFromElement(errorsIncreasedCoverageSection.get(i)), "Combined max exceeded",
                    "Additional coverages page - Increased values section displays error: " + (i + 1));
        }
        if (lob.equals(RENTERS) && applicant.getStateCode().equals(NC)) {
            waitAndClickElement(decreaseCoverageSecurities);
        } else {
            waitAndClickElement(decreaseCoverageJewelry);
        }
        waitElementBeVisible(footerIncreasedValuablesStarText);
        sa.assertTrue(errorsIncreasedCoverageSection.isEmpty(), "Additional coverages page - Increased values section displays no errors");
        sa.assertFalse(getAttributeData(footerIncreasedValuablesStarText, CLASS).contains("tui-error"),
                "Additional coverages page - Increased values star footnote does not display an error");
    }

    public void tryRecalculateQuote() throws Exception {
        if (isRecalculateButtonDisplayed()) {
            clickRecalculateButton();
            for (int i = 0; i < 3; i++) {
                boolean recalculateSuccess = (new AceHRCAdditionalCoveragesBasePage()).isOnAdditionalCoveragesPage();
                if (!recalculateSuccess && isElementDisplayed(tryAgainButton, 2)) {
                    waitAndClickElement(tryAgainButton);
                } else {
                    break;
                }
            }
            waitContinueButtonVisibleClickable();
        }
    }

    public void clickRecalculateButtonAtBottom() {
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(buttonRecalculateMobileAtPageBottom);
            waitForSpinnerToBeGone();
        }
        if (isTryAgainPagePresent() && !wasTryAgainSuccessful()) {
            throw new IllegalStateException("Recalculate did not succeed on AceHRCAdditionalCoveragesPage");
        }
    }

    public void verifyTogglesOff(ApplicantAceHome applicant, FarmersSoftAssert sa) {
        int count = applicant.getStateCode().equals(MN) ? 1 : 0;
        sa.assertEquals((int) toggleButtons.stream().filter(we -> getAttributeData(we, CLASS).contains(TOGGLE_CHECKED)).count(), count, "Additional coverages page - Watercraft liability - family protection toggle is not selected by default");
    }

    public List<String> getSelectedToggles() {
        return toggleButtons.stream().filter(we -> getAttributeData(we, CLASS).contains(TOGGLE_CHECKED)).map(this::getTextFromElement).sorted().collect(Collectors.toList());
    }

    private List<String> getAdditionalCoverageNames(ApplicantAceHome applicant, boolean isNonPrimaryApplicant) throws Exception {
        String stateCode = applicant.getStateCode();
        final List<String> ADDITIONAL_COVERAGES_TITLES = List.of(UTILITY_LINE, EQUIPMENT_BREAKDOWN, LIMITED_LEAKAGE_AND_SEEPAGE,
                LIMITED_PLUMBING_SYSTEM_REPAIR, PERSONAL_INJURY, ZERO_DEDUCTIBLE_GLASS, LIMITED_MOLD, HOA_LOSS_PAYMENT,
                INCREASED_COVERAGE_FOR_VALUABLES_TITLE, E_BIKES_AND_GOLF_CARTS, WATER_BACKUP_AND_SUMP_OVERFLOW);
        List<String> additionalCoverages = new ArrayList<>(ADDITIONAL_COVERAGES_TITLES);
        if (getSelectedPackageName().equalsIgnoreCase(STANDARD)) {
            additionalCoverages.remove(INCREASED_COVERAGE_FOR_VALUABLES_TITLE);
        }
        if ((DateCalculations.ageFromYear(String.valueOf(applicant.getYearBuilt())) > 20) && !stateCode.equals(CA)) {
            additionalCoverages.remove(LIMITED_LEAKAGE_AND_SEEPAGE);
        }
        if (stateCode.equals(AZ)) {
            additionalCoverages.remove(EQUIPMENT_BREAKDOWN);
        }
        if (stateCode.equals(PA)) {
            additionalCoverages.add(SINKHOLE_LOSS);
            additionalCoverages.add(LIMITED_ESCAPED_LIQUID_FUEL);
        }
        if (stateCode.equals(AR)) {
            additionalCoverages.remove(LIMITED_MOLD);
            additionalCoverages.add(EARTHQUAKE);
        }
        if (stateCode.equals(VA)) {
            additionalCoverages.removeAll(List.of(ZERO_DEDUCTIBLE_GLASS, E_BIKES_AND_GOLF_CARTS, LIMITED_MOLD, UTILITY_LINE));
            additionalCoverages.add(SERVICE_LINE);
        }
        if (stateCode.equals(MI)) {
            additionalCoverages.remove(LIMITED_MOLD);
            if (getSelectedPackageName().equalsIgnoreCase(PREMIER) && isRoofTypeEligibleForFortifiedRoofUpgrade()) {
                additionalCoverages.add(FORTIFIED_ROOF_UPGRADE);
            }
        }
        if (stateCode.equals(TN)) {
            additionalCoverages.add(SINKHOLE_LOSS);
        }
        // R10 and R11 roll-out states specifics
        if (List.of(KS, KY, LA, MA, MS, NC, IA, IN, MD, MN, OH, WA).contains(stateCode)) {
            additionalCoverages.removeAll(List.of(WATER_BACKUP_AND_SUMP_OVERFLOW, UTILITY_LINE, LIMITED_LEAKAGE_AND_SEEPAGE, ZERO_DEDUCTIBLE_GLASS, HOA_LOSS_PAYMENT));
            if (!stateCode.equals(NC)) {
                if (List.of(KY, LA).contains(stateCode)) {
                    additionalCoverages.add(IDENTITY_FRAUD);
                }
                additionalCoverages.addAll(List.of(SEWER_AND_DRAIN, SERVICE_LINE, RESIDENCE_GLASS_WAIVER_OF_DEDUCTIBLE));
                if (List.of(IA, IN, MD, MN, OH, WA).contains(stateCode) && (DateCalculations.ageFromYear(String.valueOf(applicant.getYearBuilt())) < 40)) {
                    additionalCoverages.add(LIMITED_WATER_LEAKAGE);
                }
            } else {
                additionalCoverages.add(IDENTITY_FRAUD);
                additionalCoverages.add(WATER_BACKUP_AND_SUMP_DISCHARGE);
                additionalCoverages.remove(INCREASED_COVERAGE_FOR_VALUABLES_TITLE);
            }
            additionalCoverages.add(ASSOCIATION_LOSS_ASSESSMENT);
            if (List.of(KY, LA, MA, MS, NC, WA).contains(stateCode)) {
                additionalCoverages.remove(LIMITED_MOLD);
            }
            if (List.of(IA, IN, KS, KY, LA, MA, MD, MN, MS, NC, OH, WA).contains(stateCode)) {
                additionalCoverages.remove(E_BIKES_AND_GOLF_CARTS);
            }
            if (List.of(KY, LA, MA, MS, NC).contains(stateCode)) {
                additionalCoverages.remove(LIMITED_PLUMBING_SYSTEM_REPAIR);
            }
            if (Objects.equals(MS, stateCode)) {
                additionalCoverages.add(IDENTITY_FRAUD);
            }
        }
        if (stateCode.equals(GA)) {
            additionalCoverages.remove(LIMITED_MOLD);
            additionalCoverages.add(INCREASED_LIMITS_FOR_LIMITED_MOLD);
            if (getSelectedPackageName().equalsIgnoreCase(PREMIER) && isRoofTypeEligibleForFortifiedRoofUpgrade()) {
                additionalCoverages.add(FORTIFIED_ROOF_UPGRADE);
            }
        }
        if (stateCode.equals(CT)) {
            additionalCoverages.remove(LIMITED_MOLD);
        }
        if (stateCode.equals(MN)) {
            additionalCoverages.add(WATERCRAFT_LIABILITY_FAMILY_PROTECTION);
        }
        if (stateCode.equals(AL)) {
            additionalCoverages.add(SINKHOLE_LOSS);
        }
        if (stateCode.equals(MO)) {
            if (getSelectedPackageName().equalsIgnoreCase(PREMIER) && isRoofTypeEligibleForFortifiedRoofUpgrade()) {
                additionalCoverages.add(FORTIFIED_ROOF_UPGRADE);
            }
        }
        if (List.of(AR, CO, IA, ID, IL, IN, MI, NE, NM, OH, TN, UT, WA).contains(stateCode)) {
            additionalCoverages.add(SPECIAL_WATER_LOSS_LIMIT_TITLE);
        }
        if (stateCode.equals(CA)) {
            additionalCoverages.removeAll(List.of(UTILITY_LINE, ZERO_DEDUCTIBLE_GLASS, HOA_LOSS_PAYMENT, WATER_BACKUP_AND_SUMP_OVERFLOW));
            additionalCoverages.addAll(List.of(SERVICE_LINE, SEWER_AND_DRAIN, RESIDENCE_GLASS_WAIVER_OF_DEDUCTIBLE, ASSOCIATION_LOSS_ASSESSMENT));
        }
        if (stateCode.equals(MT)) {
            additionalCoverages.removeAll(List.of(UTILITY_LINE, LIMITED_LEAKAGE_AND_SEEPAGE, ZERO_DEDUCTIBLE_GLASS, HOA_LOSS_PAYMENT, WATER_BACKUP_AND_SUMP_OVERFLOW, E_BIKES_AND_GOLF_CARTS));
            additionalCoverages.addAll(List.of(ASSOCIATION_LOSS_ASSESSMENT, SERVICE_LINE, RESIDENCE_GLASS_WAIVER_OF_DEDUCTIBLE, SEWER_AND_DRAIN, SPECIAL_WATER_LOSS_LIMIT_TITLE));
        }
        if (isPrimaryResidenceHasFourOptions(stateCode) && isNonPrimaryApplicant) {
            String limitedLeakageVal = List.of(GA, MO).contains(stateCode) ? LIMITED_LEAKAGE_AND_SEEPAGE : "Limited Leakage & seepage";
            additionalCoverages.removeAll(List.of(PERSONAL_INJURY, E_BIKES_AND_GOLF_CARTS, limitedLeakageVal));
        }
        if (isEditPrimaryCoveragesState(stateCode)) {
            additionalCoverages.remove(INCREASED_COVERAGE_FOR_VALUABLES_TITLE);
        }
        return getSortedList(additionalCoverages);
    }

    protected String getCoveragePriceForCoverageTitle(String coverageTitle) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        String selectedPackageCode = appStore.getHome().getQuote().getSelectedPackageCode();
        String selectedPaymentMode = appStore.getHome().getQuote().getSelectedPaymentMode();
        AppStore.Home.Coverage coverage = appStore.getHome().getCoverageForPackage(selectedPackageCode, selectedPaymentMode);
        String cvgDesc = coverageTitle;
        switch (cvgDesc) {
            case WATER_BACKUP_AND_SUMP_OVERFLOW:
                cvgDesc += " - Covered property";
                break;
            case INCREASED_COVERAGE_FOR_VALUABLES_TITLE:
                cvgDesc = "Jewelry";
                break;
            case LIMITED_ESCAPED_LIQUID_FUEL:
                cvgDesc = "Liquid Fuel Limit";
                break;
            case SINKHOLE_LOSS:
                cvgDesc = selectedPackageCode.equals("S") ? "Sinkhole collapse" + SPACE : "Sinkhole collapse";
                break;
            case EARTHQUAKE:
                cvgDesc = "EarthQuake Dedutable";
                break;
        }

        AppStore.Home.CvgInfo cvgInfo = coverage.getCvgInfoForCvgDesc(cvgDesc);
        String coveragePrice;
        if (cvgDesc.equals("Jewelry")) {
            AppStore.Home.CvgInfo cvgInfo2 = coverage.getCvgInfoForCvgDesc("Other articles");
            String premium2 = coverage.getCvgInfoForCvgDesc("Other articles").getCvgAmt();
            String premium = coverage.getCvgInfoForCvgDesc("Jewelry").getCvgAmt();
            if ((!Objects.equals(premium, EMPTY_STRING)) && (!Objects.equals(premium2, EMPTY_STRING))) {
                if (CurrencyFormat.convertCurrencyStringToDouble(premium2) <
                        CurrencyFormat.convertCurrencyStringToDouble(premium)) {
                    cvgDesc = "Other articles";
                    cvgInfo = cvgInfo2;
                }
            }
        }
        if ((cvgInfo != null) && (cvgInfo.getDisplayPremium() != null)) {
            coveragePrice = coverage.getCvgInfoForCvgDesc(cvgDesc).getDisplayPremium();
            if (selectedPaymentMode.equals("EFT")) {
                Double cvgPrice = Double.parseDouble(coveragePrice) / 12;
                coveragePrice = CurrencyFormat.convertStringIntoCurrencyFormat(String.valueOf(cvgPrice)) + "/month";
            } else {
                coveragePrice = "$" + coveragePrice + "/year";
            }
            if (List.of(HOA_LOSS_PAYMENT, WATER_BACKUP_AND_SUMP_OVERFLOW, WATER_BACKUP_AND_SUMP_DISCHARGE, LIMITED_MOLD, IDENTITY_FRAUD,
                    INCREASED_LIMITS_FOR_LIMITED_MOLD, LIMITED_LEAKAGE_AND_SEEPAGE, LIMITED_WATER_LEAKAGE, INCREASED_COVERAGE_FOR_VALUABLES_TITLE,
                    LIMITED_ESCAPED_LIQUID_FUEL, EARTHQUAKE, SEWER_AND_DRAIN, "Sewer and Drain", CHILD_CARE_LIABILITY,
                    ASSOCIATION_LOSS_ASSESSMENT).contains(coverageTitle)) {
                coveragePrice = "Starting at " + coveragePrice;
            }
        } else {
            coveragePrice = EMPTY_STRING;
        }
        return coveragePrice;
    }

    public boolean isContinueButtonPresent() throws Exception {
        String continueButtonXpath = "//button[contains(text(),'Continue')]";
        if (isUseMobileViewEnabled()) {
            return (isElementPresent(PWBy.xpath(QUOTE_PRESENTMENT_MOBILE_XPATH + continueButtonXpath)));
        } else {
            return (isElementPresent(PWBy.xpath(QUOTE_PRESENTMENT_DESKTOP_XPATH + continueButtonXpath)));
        }
    }

    public boolean isRecalculateButtonDisplayed() {
        PWElement buttonToUse;
        if (isUseMobileViewEnabled()) {
            buttonToUse = isElementDisplayed(recalculateButtonBundleMobile, 2) ? recalculateButtonBundleMobile : recalculateButtonMobile;
        } else {
            buttonToUse = isElementDisplayed(recalculateButtonBundleDesktop, 2) ? recalculateButtonBundleDesktop : recalculateButtonDesktop;
        }
        return isElementDisplayed(buttonToUse, 3);
    }

    public void clickRecalculateButton() {
        PWElement buttonToUse;
        if (isUseMobileViewEnabled()) {
            buttonToUse = isElementDisplayed(recalculateButtonBundleMobile, 2) ? recalculateButtonBundleMobile : recalculateButtonMobile;
        } else {
            buttonToUse = isElementDisplayed(recalculateButtonBundleDesktop, 2) ? recalculateButtonBundleDesktop : recalculateButtonDesktop;
        }
        waitAndClickElement(buttonToUse);
        waitForSpinnerToBeGone();
        if (isRecalculateButtonDisplayed()) {
            waitAndClickElement(buttonToUse);
        }
        if (isTryAgainPagePresent() && !wasTryAgainSuccessful()) {
            throw new IllegalStateException("Recalculate did not succeed on AceHRCAdditionalCoveragesPage");
        }
    }

    public List<String> randomToggleSelection(ApplicantAceHome applicant, FarmersSoftAssert fsa, String lobType) throws Exception {
        List<String> togglesSelected = new ArrayList<>();
        String stateCode = applicant.getStateCode();
        if (stateCode.equals(MN)) {
            togglesSelected.add(WATERCRAFT_LIABILITY_FAMILY_PROTECTION);
        }
        // Ensure "Special water loss limit" toggle is ON for MI, NE, IA, NM, ID, IL, AR, OK, OR, TX, WA states
        if (lobType.equals(HOME) && isAccessThroughFoundationsAndWallsState(stateCode)) {
            toggleAdditionalCoverage(SPECIAL_WATER_LOSS_LIMIT_TITLE, true);
            if (isElementDisplayed(dialogButtonOk, 2)) {
                fsa.assertEquals(getTextFromElement(specialWaterLossLimitDialogTitle), SPECIAL_WATER_LOSS_LIMIT_TITLE, "Special water loss limit dialog title is matched");
                fsa.assertEquals(getTextFromElement(dialogContent), SPECIAL_WATER_LOSS_LIMIT_CONTENT, "Special water loss limit dialog title is matched");
                waitAndClickElement(dialogButtonOk);
            }
            togglesSelected.add(SPECIAL_WATER_LOSS_LIMIT_TITLE);
            Log.info(">> Toggle/coverage turned ON: " + SPECIAL_WATER_LOSS_LIMIT_TITLE);
        }

        List<String> additionalCoveragesTemp = toggleButtons.stream().map(this::getTextFromElement).collect(Collectors.toList());
        additionalCoveragesTemp.remove(WATERCRAFT_LIABILITY_FAMILY_PROTECTION);
        if (lobType.equals(HOME) && isAccessThroughFoundationsAndWallsState(stateCode)) {
            additionalCoveragesTemp.remove(SPECIAL_WATER_LOSS_LIMIT_TITLE);
        }
        for (int i = 0; i < 3; i++) {
            String toggle = additionalCoveragesTemp.get(new Random().nextInt(additionalCoveragesTemp.size()));
            additionalCoveragesTemp.remove(toggle);
            toggleAdditionalCoverage(toggle, true);
            if (toggle.equals(LIMITED_MOLD)) {
                if (isElementVisible(yearBuiltInputLimitedMold, 2)) {
                    waitAndClickElement(yearBuiltInputLimitedMold);
                    sendKeysToElement(yearBuiltInputLimitedMold, applicant.getYearBuilt());
                }
            } else if (List.of(INCREASED_COVERAGE_FOR_VALUABLES_TITLE, INCREASED_LIMITS_FOR_VALUABLES_TITLE).contains(toggle)) {
                for (PWElement matCheckbox : checkboxesIncreasedValuables) {
                    waitAndClickElement(waitElementBeVisible(matCheckbox));
                }
            } else if (toggle.equals(EARTHQUAKE)) {
                waitAndClickElement(toggleButtonsEarthquake.get(0)); // Coverage Type - Full (Home) or Yes - structure attached to the foundation (Condo)
                waitAndClickElement(radioButtonsEarthquakeLabels.get(0)); // 10% deductible
                int indexUnsupportedFoundations = lobType.equals(HOME) ? 5 : 3;
                clickElement(toggleButtonsEarthquake.get(indexUnsupportedFoundations)); // No - unsupported foundations
                if (lobType.equals(HOME)) {
                    clickElement(toggleButtonsEarthquake.get(2)); // Yes - structure attached to the foundation
                }
                if (lobType.equals(RENTERS)) {
                    sendKeysToElement(yearBuiltInputEarthquake, applicant.getYearBuilt());
                }
            }
            togglesSelected.add(toggle);
            Log.info(">> Toggle/coverage turned ON: " + toggle);
        }
        if (isRecalculateButtonDisplayed()) {
            clickRecalculateButton();
            waitForSpinnerToBeGone();
            if (isRecalculateButtonDisplayed()) {
                waitAndClickElement(recalculateButtonMobile);
            }
            waitContinueButtonVisibleClickable();
        }
        return togglesSelected;
    }

    public void validateSwitchingToAndFromReviewQuotePage(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        String stateCode = applicant.getStateCode();
        List<AppStore.Home.RateQuoteResponse> premierPackages = reviewQuotePage.getPackageFromRateResponse("P");
        boolean isPremierPackageAvailable = premierPackages.size() == 2;

        if ((isAccessThroughFoundationsAndWallsState(stateCode) || isFortifiedRoofState(stateCode)) && isPremierPackageAvailable) {
            reviewQuotePage.clickOnPremierPackage();
            if (stateCode.equals(MI)) {
                if (isEligibleForFortifiedRoofUpgradeOption(stateCode)) {
                    fsa.assertFalse(reviewQuotePage.getFoundSupplementalCoveragesNames(stateCode).contains(FORTIFIED_ROOF_UPGRADE));
                }
                reviewQuotePage.validateSupplementalCoverageNameAndValue(applicant, fsa, ACCESS_THROUGH_FOUNDATIONS_AND_WALLS_COVERAGE, ON);
            } else if (isEligibleForFortifiedRoofUpgradeOption(stateCode)) {
                fsa.assertFalse(reviewQuotePage.getFoundSupplementalCoveragesNames(stateCode).contains(FORTIFIED_ROOF_UPGRADE));
            } else {
                reviewQuotePage.validateSupplementalCoverageNameAndValue(applicant, fsa, ACCESS_THROUGH_FOUNDATIONS_AND_WALLS_COVERAGE, ON);
            }
        } else {
            Log.info("Premier package is not available for " + stateCode + " state");
        }
        reviewQuotePage.clickOnContinueButton();
        if (isPremierPackageAvailable && isEligibleForFortifiedRoofUpgradeOption(stateCode)) {
            new AceHRCAdditionalCoveragesBasePage().validateToggleOnAdditionalCoveragesPage(fsa, FORTIFIED_ROOF_UPGRADE);
        }
        List<String> togglesSelected = randomToggleSelection(applicant, fsa, HOME);

        String totalQuotePriceAdditionalCoverages = getQuotePriceOnCard();
        String allOtherPriceAdditionalCoverages = getAllOtherCoveragesPriceOnCard();
        String packageNameAdditionalCoverages = getSelectedPackageName();
        String paymentModeAdditionalCoverages = getSelectedPaymentMode();

        selectStepper(REVIEW_QUOTE);
        waitForSkeletonToBeGone();
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePage(true));

        String totalQuotePriceReviewQuote = reviewQuotePage.getQuotePriceOnCard();
        String allOtherPriceReviewQuote = reviewQuotePage.getOptionalCoveragesPriceOnCard();
        String packageNameReviewQuote = reviewQuotePage.getSelectedPackageName();
        String paymentModeReviewQuote = reviewQuotePage.getSelectedPaymentMode();
        if (isAccessThroughFoundationsAndWallsState(stateCode)) {
            if (isPremierPackageAvailable) {
                reviewQuotePage.clickOnPremierPackage();
                reviewQuotePage.validateSupplementalCoverageNameAndValue(applicant, fsa, ACCESS_THROUGH_FOUNDATIONS_AND_WALLS_COVERAGE, OFF);
            } else {
                Log.info("Premier package is not available for " + stateCode + " state");
            }
        }
        fsa.assertEquals(totalQuotePriceReviewQuote, totalQuotePriceAdditionalCoverages, "Review quote page - Total quote premium");
        fsa.assertEquals(allOtherPriceReviewQuote, allOtherPriceAdditionalCoverages, "Review quote page - All other coverages premium");
        fsa.assertEquals(packageNameReviewQuote, packageNameAdditionalCoverages, "Review quote page - Package name");
        fsa.assertEquals(paymentModeReviewQuote, paymentModeAdditionalCoverages, "Review quote page - Payment mode");
        reviewQuotePage.clickOnContinueButton();
        assert isOnAdditionalCoveragesPage();
        validatePageTitleSubtitle(fsa);

        String totalQuotePriceAdditionalCoverages2 = getQuotePriceOnCard();
        String allOtherPriceAdditionalCoverages2 = getAllOtherCoveragesPriceOnCard();
        String packageNameAdditionalCoverages2 = getSelectedPackageName();
        String paymentModeAdditionalCoverages2 = getSelectedPaymentMode();
        fsa.assertEquals(totalQuotePriceAdditionalCoverages2, totalQuotePriceAdditionalCoverages, "Additional coverages page - Total quote premium");
        fsa.assertEquals(allOtherPriceAdditionalCoverages2, allOtherPriceAdditionalCoverages, "Additional coverages page - All other coverages premium");
        fsa.assertEquals(packageNameAdditionalCoverages2, packageNameAdditionalCoverages, "Additional coverages page - Package name");
        fsa.assertEquals(paymentModeAdditionalCoverages2, paymentModeAdditionalCoverages, "Additional coverages page - Payment mode");
        fsa.assertEquals(getSelectedToggles(), getSortedList(togglesSelected), "Additional coverages page - Selected toggles");
    }

    public void validateADA(ApplicantAceHome applicant, boolean isNonPrimaryApplicant) throws Exception {
        performADATesting(this.getClass().getSimpleName(), MARKETING_IT, FFQ_ACE_HOME);
        List<String> additionalCoverages = getAdditionalCoverageNames(applicant, isNonPrimaryApplicant);
        for (String coverageTitle : additionalCoverages) {
            Log.info(">> Validating Additional coverage: " + coverageTitle);
            toggleAdditionalCoverage(coverageTitle, true);
            switch (coverageTitle) {
                case HOA_LOSS_PAYMENT:
                    performADATesting(this.getClass().getSimpleName() + "_HOALossPayment", MARKETING_IT, FFQ_ACE_HOME);
                    break;
                case WATER_BACKUP_AND_SUMP_OVERFLOW:
                    performADATesting(this.getClass().getSimpleName() + "_WaterBackup", MARKETING_IT, FFQ_ACE_HOME);
                    break;
                case LIMITED_MOLD:
                    performADATesting(this.getClass().getSimpleName() + "_LimitedMold", MARKETING_IT, FFQ_ACE_HOME);
                    break;
                case LIMITED_LEAKAGE_AND_SEEPAGE:
                    performADATesting(this.getClass().getSimpleName() + "_LimitedLeakage", MARKETING_IT, FFQ_ACE_HOME);
                    break;
                case INCREASED_COVERAGE_FOR_VALUABLES_TITLE:
                    performADATesting(this.getClass().getSimpleName() + "_IncreasedCoverageForValuables", MARKETING_IT, FFQ_ACE_HOME);
                    break;
                case LIMITED_ESCAPED_LIQUID_FUEL:
                    performADATesting(this.getClass().getSimpleName() + "_LimitedEscapedLiquidFuel", MARKETING_IT, FFQ_ACE_HOME);
                    break;
                case EARTHQUAKE:
                    performADATesting(this.getClass().getSimpleName() + "_Earthquake", MARKETING_IT, FFQ_ACE_HOME);
                    break;
            }
            toggleAdditionalCoverage(coverageTitle, false);
        }
    }

    public void verifyBundleContent(String propertyType, boolean isQuoteBindable, FarmersSoftAssert fsa) {
        String expectedPageTitle = "Optional " + propertyType.toLowerCase() + " coverages";
        fsa.assertEquals(getTextFromElement(additionalCoveragesHeading), expectedPageTitle, propertyType + " Optional coverages page title verification");
        String expectedPageSubtitle = propertyType.equals(RENTERS)? PAGE_SUBTITLE + " (optional)" : PAGE_SUBTITLE;
        fsa.assertEquals(getTextFromElement(additionalCoveragesSubheading), expectedPageSubtitle, propertyType + " Optional coverages page subtitle verification");
        PWElement continueButton = isUseMobileViewEnabled() ? buttonContinueMobile : buttonContinueDesktop;
        if (!isElementVisibleAndClickable(continueButton, 2)) {
            continueButton = fallbackContinueButton;
        }
        String expectedButtonLabel = isQuoteBindable ? "Continue to final wrap-up" : "Continue";
        fsa.assertEquals(getTextFromElement(continueButton), expectedButtonLabel, propertyType + " Optional coverages page button label verification");
        verifyBundleQuoteLedgerComponent(propertyType, propertyType, fsa);
    }

    public void validateContinueButtonAtPageBottom(FarmersSoftAssert fsa) {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(minimizeQuoteCard, 2)) {
                waitAndClickElement(minimizeQuoteCard);
            }
            fsa.assertTrue(isElementVisibleAndClickable(buttonContinueMobileAtPageBottom, 2), "Additional coverages page - Continue button is displayed at page bottom in mobile view.");
        } else {
            fsa.assertTrue(!isElementVisible(buttonContinueMobileAtPageBottom, 2), "Additional coverages page - Continue button is not displayed at page bottom in desktop view.");
        }
    }

    public void selectIncreaseCoverageForCertainValuables() throws Exception {
        toggleAdditionalCoverage(INCREASED_COVERAGE_FOR_VALUABLES_TITLE, true);
        clickElement(increaseCoverageJewelryCheckbox);
        clickElement(increaseCoverageOtherCheckbox);
        clickRecalculateButton();
    }

    public void validateRecalculateButtonAtPageBottom(FarmersSoftAssert fsa) throws Exception {
        if (isAdditionalCoverageToggleDisplayed("certain valuables")) {
            toggleAdditionalCoverage("certain valuables", true);
            clickOnHiddenElement(increaseCoverageJewelryCheckbox);
            waitAndClickElement(increaseCoverageJewelry);
        } else if (isAdditionalCoverageToggleDisplayed(SEWER_AND_DRAIN)) {
            toggleAdditionalCoverage(SEWER_AND_DRAIN, true);
        } else if (isAdditionalCoverageToggleDisplayed(WATER_BACKUP_AND_SUMP_OVERFLOW)){
            toggleAdditionalCoverage(WATER_BACKUP_AND_SUMP_OVERFLOW, true);
            if (!isElementVisible(buttonRecalculateMobileAtPageBottom, 2)) {
                waitAndClickElement(toggleButtonsWaterBackup2.findElement(PWBy.xpath("button")));
            }
        }
        if (isUseMobileViewEnabled()) {
            fsa.assertTrue(isElementVisible(buttonRecalculateMobileAtPageBottom, 2), "Additional coverages page - Recalculate button is displayed at page bottom in Mobile view.");
            clickRecalculateButtonAtBottom();
        } else {
            fsa.assertTrue(!isElementVisible(buttonRecalculateMobileAtPageBottom, 2), "Additional coverages page - Recalculate button is not displayed at page bottom in Desktop view.");
        }
    }

    public void validateSpecialWaterLossAndFoundationsWallValue(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        if (isAccessThroughFoundationsAndWallsState(applicant.getStateCode())) {
            AceHomeReviewQuotePage reviewQuotePage = new AceHomeReviewQuotePage();
            if (reviewQuotePage.getPackageFromRateResponse("P").size() == 2) {
                boolean isSpecialWaterLossLimitSelected = getSelectedToggles().contains(SPECIAL_WATER_LOSS_LIMIT_TITLE);
                String coverageValue = isSpecialWaterLossLimitSelected ? OFF : ON;
                selectStepper(REVIEW_QUOTE);
                reviewQuotePage.waitForSkeletonToBeGone();
                reviewQuotePage.clickOnPremierPackage();
                reviewQuotePage.validateSupplementalCoverageNameAndValue(applicant, fsa, ACCESS_THROUGH_FOUNDATIONS_AND_WALLS_COVERAGE, coverageValue);
            } else {
                Log.info("Premier package is not available for " + applicant.getStateCode() + " state");
            }
        } else {
            Log.info("Access through foundations and walls coverage is not available for " + applicant.getStateCode() + " state");
        }
    }

    private void validateFortifiedRoofUpgradeDialog(FarmersSoftAssert fsa, boolean isFortifiedRoofSelected) throws Exception {
        final String FORTIFIED_ROOF_DIALOG_TITLE = "Fortified Roof upgrade coverage";
        String expectedKey = isFortifiedRoofSelected ? "added" : "removed";
        String expectedCoverageName = isFortifiedRoofSelected ? "replacement cost" : "scheduled payment";
        final String FORTIFIED_ROOF_DIALOG_CONTENT = String.format("Since you %s this optional coverage, we must change your roof cost valuation method to %s.", expectedKey, expectedCoverageName);
        Assert.assertTrue(isElementVisible(fortifiedRoofUpgradeDialogTitle, 2), "Fortified roof upgrade dialog is displayed");
        fsa.assertEquals(getTextFromElement(fortifiedRoofUpgradeDialogTitle), FORTIFIED_ROOF_DIALOG_TITLE, "Fortified roof upgrade dialog title did not match");
        fsa.assertEquals(getTextFromElement(dialogContent), FORTIFIED_ROOF_DIALOG_CONTENT, "Fortified roof upgrade dialog content did not match");
        waitAndClickElement(dialogButtonOk, 2);
    }

    // F92125/US1064836
    public void validateRoofMaterialValueAndFortifiedRoofUpgradeDialog(AceHomeReviewQuotePage reviewQuotePage, FarmersSoftAssert fsa) throws Exception {
        // Fortified Roof Upgrade coverage is not applicable if Fortified Home certification checkbox is selected in Additional Info section.
        boolean isFortifiedHomeSelected = getSessionStorageAppStore().getHome().getAdditionalInfoHomeDetails().getFortifiedHome().isCheckboxChecked();
        if(!isFortifiedHomeSelected) {
            boolean isFortifiedRoofSelected = true;
            toggleAdditionalCoverage(FORTIFIED_ROOF_UPGRADE, isFortifiedRoofSelected);
            validateFortifiedRoofUpgradeDialog(fsa, isFortifiedRoofSelected);
            selectStepper(REVIEW_QUOTE);
            Assert.assertTrue(reviewQuotePage.isOnReviewQuotePage(true));
            reviewQuotePage.validateCoverageAndAmountOnReviewQuotePage(fsa, ROOF_MATERIALS, PRIMARY, REPLACEMENT_COST);
            reviewQuotePage.clickOnContinueButton();
            isFortifiedRoofSelected = false;
            toggleAdditionalCoverage(FORTIFIED_ROOF_UPGRADE, isFortifiedRoofSelected);
            validateFortifiedRoofUpgradeDialog(fsa, isFortifiedRoofSelected);
            selectStepper(REVIEW_QUOTE);
            Assert.assertTrue(reviewQuotePage.isOnReviewQuotePage(true));
            reviewQuotePage.validateCoverageAndAmountOnReviewQuotePage(fsa, ROOF_MATERIALS, PRIMARY, SCHEDULED_PAYMENT);
        }
        else {
            Log.info("Fortified Home checkbox is selected, hence, Fortified Roof Upgrade coverage is not applicable.");
        }
    }



    public boolean isRoofTypeEligibleForFortifiedRoofUpgrade() throws Exception {
        AppStore.Home.PropertyDetailsForm propertyDetailsForm = getSessionStorageAppStore().getHome().getPropertyDetailsForm();
        String roofCoverageType = propertyDetailsForm.getFields().stream().filter(i -> i.getFieldName().equals("roofCover"))
                .findFirst()
                .map(f -> f.getValues().get(0).getValue())
                .orElse(EMPTY_STRING);
        Log.info("Roof coverage type >> " + roofCoverageType);
        return List.of(A_COMP, COMP, I_COMP).contains(roofCoverageType);
    }

    public boolean isFortifiedRoofState(String stateCode) {
        return List.of(GA, KY, MI).contains(stateCode);
    }

    public boolean isEligibleForFortifiedRoofUpgradeOption(String stateCode) throws Exception {
        return isFortifiedRoofState(stateCode) && isRoofTypeEligibleForFortifiedRoofUpgrade();
    }
}
