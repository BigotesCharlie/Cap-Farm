package com.farmers.ffq.utils;

import java.text.NumberFormat;
import java.util.Locale;

import static com.farmers.ffq.utils.GlobalVariables.EMPTY_STRING;

public class CurrencyFormat {

    public static String convertStringIntoCurrencyFormat(String amount){
        return convertDoubleToCurrencyString(convertCurrencyStringToDouble(amount)).strip();
    }

    public static String convertStringIntoCurrencyFormatWithoutDecimal(String amount){
        return convertStringIntoCurrencyFormat(amount).replace(".00", EMPTY_STRING);
    }

    public static Double convertCurrencyStringToDouble(String amount){
        return Double.parseDouble(amount.replaceAll("[^\\d.]", EMPTY_STRING));
    }

    public static String convertDoubleToCurrencyString(Double amount){
        NumberFormat dollarFormat = NumberFormat.getCurrencyInstance(Locale.US);
        dollarFormat.setGroupingUsed(true);
        dollarFormat.setMinimumFractionDigits(2);
        return dollarFormat.format(amount).strip();
    }

    public static String convertDoubleToCurrencyStringNoDecimals(Double amount){
        return convertDoubleToCurrencyString(amount).replace(".00", EMPTY_STRING);
    }

}
