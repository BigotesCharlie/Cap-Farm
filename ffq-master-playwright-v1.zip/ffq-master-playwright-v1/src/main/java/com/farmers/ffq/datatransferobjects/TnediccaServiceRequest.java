package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

/**
 * POJO representing the request payload sent to the TNEDICCA service
 * when address details are saved.
 *
 * <p>Milestone: {@code "TNEDICCA Service Initiated"}
 *
 * <p>Example payload:
 * <pre>
 * {
 *   "riskAddresses": [ {
 *     "country":      "United States",
 *     "city":         "MAHOMET",
 *     "postalCode":   "61853",
 *     "addressLine1": "605 ISABELLA DR",
 *     "addressLine2": "",
 *     "state":        "IL"
 *   } ]
 * }
 * </pre>
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TnediccaServiceRequest {

    private List<RiskAddress> riskAddresses;

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class RiskAddress {

        private String country;
        private String city;
        private String postalCode;
        private String addressLine1;
        private String addressLine2;
        private String state;
    }
}

