/**
=============================================
* Author:	Zhabiz Sonee
* Create date:	05/01/2017
=============================================
*/
package com.farmers.ffq.datatransferobjects;
import lombok.Data;

@Data
public class SqlDiscount {
	private int discountId;
	private int applicantId;
	private String paymentMethod;
	private String startDateOfNewPolicy;

	private boolean autoInsurance;
	private boolean umbrellaInsurance;
	private boolean lifeInsurance;
	private boolean businessInsurance;
	private boolean homeInsurance;
	private boolean rentersInsurance;
	private boolean condoInsurance;
	private boolean valueTermLifeInsurance;
	private boolean recreationalBoatWatercraftInsurance;
	private boolean motorcycleInsurance;
	private boolean motorHome;
	private String ownOrRentHome;
	private String paymentMethodForDiscount;
	private String mediaAlphaTimeAtResidence;
	private boolean mediaAlphaHasGarage;
	private boolean signalSignup;
	private boolean multiPolicyCEA;
}

