package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;


@JsonIgnoreProperties
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class AdpfServiceServiceCallEnd {
    @JsonProperty("ADPFResponseBean")
    private ADPFResponseBean aDPFResponseBean;

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class ADPFResponseBean {
        private List<Driver> driver;
        private List<Vehicle> vehicle;

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class Driver {
            private String adpfDriverReferenceNumber;
            private boolean notRelatedToMe;
            private String firstName;
            private String lastName;
            private String maskedDateOfBirth;
            private String age;
            private String pni;
            private boolean isLicenseIssuedInUS;
            private boolean carrierNameAvailable;
        }

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class Vehicle {
            private String adpfVehicleReferenceNumber;
            private String year;
            private String make;
            private String model;
            private String makeDesc;
            private String modelDesc;
            private String maskedVin;
            private String vehicleType;
            private String vehcielFuelType;
            private String absCdDrv;
            private String passiveRestrCdDrv;
            private String passiveRstProtected;
            private String purchaseDate;
            private String validVehicle;
        }
    }

}
