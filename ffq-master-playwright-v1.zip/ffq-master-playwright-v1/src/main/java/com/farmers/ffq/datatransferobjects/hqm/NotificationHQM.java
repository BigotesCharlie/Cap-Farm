package com.farmers.ffq.datatransferobjects.hqm;

import java.util.List;

public class NotificationHQM {
    private String messageText;
    private List<String> mobileNumbers;
    private Boolean subscribe;
    private Boolean resubscribe;
    private Boolean override;
    private String keyword;
    private String sendTime;

    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public List<String> getMobileNumbers() {
        return mobileNumbers;
    }

    public void setMobileNumbers(List<String> mobileNumbers) {
        this.mobileNumbers = mobileNumbers;
    }

    public Boolean getSubscribe() {
        return subscribe;
    }

    public void setSubscribe(Boolean subscribe) {
        this.subscribe = subscribe;
    }

    public Boolean getResubscribe() {
        return resubscribe;
    }

    public void setResubscribe(Boolean resubscribe) {
        this.resubscribe = resubscribe;
    }

    public Boolean getOverride() {
        return override;
    }

    public void setOverride(Boolean override) {
        this.override = override;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getSendTime() {
        return sendTime;
    }

    public void setSendTime(String sendTime) {
        this.sendTime = sendTime;
    }

}
