package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoSignalEnrollmentSectionOneUI;
import com.farmers.ffq.auto.pages.bindpages.AutoPolicyPaymentBasePage;
import com.farmers.ffq.auto.pages.bindpages.ConsolidatedPaymentPage;
import com.farmers.ffq.common.enums.AceAutoCoveragesAndLiabilites;
import com.farmers.ffq.common.enums.AutoDiscounts;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.SkipException;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.auto.pages.DriverReviewPage.*;
import static com.farmers.ffq.common.enums.AceAutoCoveragesAndLiabilites.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter
public class QuoteSummaryAutoPage extends AutoBasePage {

    private static final String NON_DIGITS_EXCEPT_PERIOD = "[^\\d.]";
    private static final String TOGGLE_BACK_CROSS_SELL_LOB_XPATH = "//mat-dialog-container/app-manage-quotes//div[contains(text(),'%s')]/../div[contains(@class,'review-quote')]/button";

    private static final String BRISTOL_WEST_DISCLAIMER = "Bristol West is a proud member of the Farmers Insurance Group of Companies, one of the nation's largest insurer groups that offers a wide variety of home, life, specialty, commercial and auto insurance products and services across the United States.";
    private static final String COVERED = "Covered";
    private static final String NOT_COVERED = "Not covered";
    private static final String NON_STACKING = "Non Stacking";
    private static final String START_CHECKOUT = "Start checkout";
    private static final String CONTINUE_WITH_AUTO = "Continue with auto";
    private static final String CONTINUE_WITH_THIS_QUOTE = "Continue with this quote";
    private static final String BUNDLE_AND_SAVE = "Bundle and save";

    private static final String COMMON_XPATH_FOR_COVERAGE = "//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted')]//div[1][normalize-space(text())='%s']/..";
    private static final String XPATH_FOR_COVERAGE_VALUE = COMMON_XPATH_FOR_COVERAGE + "/div[2]";
    private static final String XPATH_FOR_COVERAGE_PRICE = COMMON_XPATH_FOR_COVERAGE + "/div[3]//span[not(contains(@class,'hide'))]";
    private final PWBy editLiabilityCoverageButton = PWBy.cssSelector(".tui-link-button.auto-quote-liability-edit-button");
    private static final String LIABILITY_SIDE_SUBTITLE = "Liability coverage";
    private final PWBy quotePresentmentCardDesktop = PWBy.xpath("//mat-card[.//div[@class='tui-quote-presentment-header']]");
    private final PWBy quotePresentmentCardMobile = PWBy.xpath("//mat-card[.//div[@class='quote-presentment-content-wrapper']]");
    private final PWBy sectionRadioButton = PWBy.cssSelector(".mat-radio-button");
    private final PWBy sectionSubTitle = PWBy.xpath("//div[contains(@class, 'auto-quote-coverage__description')]");
    private final PWBy sectionTitle = PWBy.xpath("//coverage-input-card//div[@class='row mt-4']");
    private final PWBy tableRow = PWBy.cssSelector(".row.auto-quote-liability-coverages-item-row.d-none.d-md-flex.ng-star-inserted");
    private final PWBy tableTitle = PWBy.cssSelector("h2");
    private final PWBy totalPrice = PWBy.xpath("//div[contains(@class,'tui-body-bold liability-price-column ng-star-inserted')] | //span[@class='coverage-total-amount col-3']");
    String unselectedRadioButtonsXpath = "//coverage-input-card[contains(.,'%s')]//mat-radio-button[not(contains(@class,'checked'))]";
    @PWFindBy(xpath = "//div[contains(@class,'price-alternative')]")
    private PWElement alternativePaymentMethodLink;
    @PWFindBy(xpath = "//div[@class='row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted']/div[1]")
    private List<PWElement> allDisplayedCoverages;
    @PWFindBy(xpath = "//div[@class='row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted']/div[2]")
    private List<PWElement> allDisplayedLimits;
    @PWFindBy(xpath = "//div[@class='row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted']/div[3]")
    private List<PWElement> allDisplayedPrices;
    @PWFindBy(xpath = "//footer[contains(@class, 'autoBW')]//div[contains(@class, 'footer-disclaimer-container')]")
    private PWElement bwDisclaimerFooter;
    @PWFindAll({
            @PWFindBy(xpath = "//a[@id='emailLink']"),
            @PWFindBy(xpath = "//a[@id='emailLinkSnackBar']")
    })
    private PWElement gotItButton;
    @PWFindBy(xpath = "//coverage-input-card/div[4][not(contains(@class,'d-none'))]//mat-radio-button[contains(@class,'checked')]//label")
    private List<PWElement> byDefaultSelectedRadioButtons;
    @PWFindBy(id = "auto-quote-liability__dialog-close-icon")
    private PWElement liabilitySideDialogCloseIcon;
    @PWFindBy(id = "auto-quote-vehicle__dialog-close-icon")
    private PWElement vehicleSideDialogCloseIcon;
    @PWFindBy(xpath = "//app-edit-liability-coverage//h2")
    private PWElement liabilitySideDialogTitle;
    @PWFindBy(xpath = "//span[contains(@class,'discount-name')]")
    private List<PWElement> discountsIncluded;
    @PWFindBy(xpath = "//div[contains(@class,'discount-description')]/p[contains(@class,'tui-subtitle')]")
    private PWElement discountsIncludedCount;
    @PWFindBy(css = "div.tui-email-link")
    private PWElement emailLink;
    @PWFindBy(xpath = "//button[contains(@class, 'tui-email-link tui-link') and not(contains(@class,'hide'))]")
    private PWElement mobileEmailButton;
    @PWFindBy(xpath = "//mat-dialog-container/app-manage-quotes//div[contains(text(),'Home')]/../div[contains(@class,'rate-value')]")
    private PWElement homeRateValue;
    @PWFindBy(xpath = "//app-coverage[not(@class)]")
    private PWElement liabilityCoverageSection;
    @PWFindBy(xpath = "//input[@id='Liability__BI__toggle-input']")
    private PWElement liabilityToggle;
    @PWFindBy(xpath = "//mat-slide-toggle[@id='Liability__MP__toggle']//input")
    private PWElement medicalCoverageToggle;
    private final String BI_RADIO_BUTTON_SIDE_SHEET_GROUP_XPATH = "//mat-radio-group[@aria-label='select Bodily Injury (required)' or @id='Liability__13023__radio' or @id='Liability__BI__radio']";
    @PWFindBy(xpath = BI_RADIO_BUTTON_SIDE_SHEET_GROUP_XPATH + "//mat-radio-button[not(contains(@class,'mat-radio-checked'))]")
    private List<PWElement> uncheckedBodilyInjuryRadioButtons;
    @PWFindBy(xpath = BI_RADIO_BUTTON_SIDE_SHEET_GROUP_XPATH + "//mat-radio-button//label")
    private List<PWElement> allBodilyInjuryRadioButtons;
    @PWFindBy(xpath = "//mat-radio-group[@aria-label='select Bodily Injury (required)' or @id='Liability__13023__radio' or @id='Liability__BI__radio']/../../../..//coverage-input-card//mat-error")
    private PWElement bodilyInjuryErrorMessage;
    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__13045__radio']//mat-radio-button")
    private List<PWElement> allBodilyInjuryPart5RadioButtons;
    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__BI__radio' or @id='Liability__OBI__radio']//mat-radio-button[not(contains(@class,'mat-mdc-radio-checked'))]")
    private List<PWElement> uncheckedBodilyInjuryRadioButtonsForBW;
    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__BI__radio' or @id='Liability__OBI__radio']//mat-radio-button")
    private List<PWElement> allBodilyInjuryRadioButtonsBW;
    private final String UNINSURED_MOTORIST_TOGGLE_XPATH = "//mat-slide-toggle[@id='Liability__11101__toggle' or @id='Liability__13137__toggle']";
    @PWFindBy(xpath = UNINSURED_MOTORIST_TOGGLE_XPATH)
    private PWElement unInsuredMotoristToggle;
    private final String UNINSURED_MOTORIST_TOGGLE_XPATH_BW = "//mat-slide-toggle[@id='Liability__UM__toggle']";
    @PWFindBy(xpath = UNINSURED_MOTORIST_TOGGLE_XPATH_BW)
    private PWElement unInsuredMotoristToggleBW;
    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__11101__radio' or @id='Liability__13137__radio']//mat-radio-button//label")
    private List<PWElement> unInsuredMotoristRadioButtons;
    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__UM__radio']//mat-radio-button")
    private List<PWElement> unInsuredMotoristRadioButtonsBW;
    @PWFindBy(xpath = UNINSURED_MOTORIST_TOGGLE_XPATH + "/ancestor::coverage-input-card//mat-error")
    private PWElement unInsuredMotoristErrorMessage;
    private final String UNDERINSURED_TOGGLE_XPATH = "//mat-slide-toggle[@id='Liability__13103__toggle' or @id='Liability__13138__toggle-input']";
    @PWFindBy(xpath = UNDERINSURED_TOGGLE_XPATH)
    private PWElement underInsuredMotoristToggle;
    private final String UNDERINSURED_TOGGLE_XPATH_BW = "//mat-slide-toggle[@id='Liability__UNDUM__toggle']";
    @PWFindBy(xpath = UNDERINSURED_TOGGLE_XPATH_BW)
    private PWElement underInsuredMotoristToggleBW;
    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__13103__radio' or @id='Liability__13138__radio']//mat-radio-button//label")
    private List<PWElement> underInsuredMotoristRadioButtons;
    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__UNDUM__radio']//mat-radio-button")
    private List<PWElement> underInsuredMotoristRadioButtonsBW;
    @PWFindBy(xpath = UNDERINSURED_TOGGLE_XPATH + "/ancestor::coverage-input-card//mat-error")
    private PWElement underInsuredMotoristErrorMessage;
    private final String UMBI_TOGGLE_XPATH = "//mat-slide-toggle[@id='Liability__13100__toggle' or @id='Liability__UMUIM__toggle' or @id='Liability__13106__toggle' or @id='Liability__11100__toggle' or @id='Liability__13104__toggle' or @id='Liability__UIMBI__toggle' or @id='Liability__UIM__toggle']";
    @PWFindBy(xpath = UMBI_TOGGLE_XPATH)
    private PWElement UMBISideSheetToggle;
    private final String UMUIM_SIDE_RADIO_BUTTONS_SHEET_XPATH = "//mat-radio-group[@id='Liability__13100__radio' or @id='Liability__13106__radio' or @id='Liability__11100__radio' or @id='Liability__13104__radio' or @id='Liability__UMBI__radio' or @id='Liability__UIMBI__radio' or @id='Liability__UIM__radio' or @id='Liability__UMUIM__radio']//mat-radio-button";
    @PWFindBy(xpath = UMUIM_SIDE_RADIO_BUTTONS_SHEET_XPATH)
    private List<PWElement> UMBISideSheetRadioButtons;
    @PWFindBy(xpath = "//p[contains(@class,'auto-quote-liability__notes')]")
    private PWElement UMBI_rule_message;
    @PWFindBy(xpath = UMBI_TOGGLE_XPATH + "/../../..//mat-error")
    private PWElement UMBI_rule_error_message;
    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__13024__radio']//mat-radio-button[not(contains(@class,'mat-radio-checked'))]")
    private List<PWElement> uncheckedPropertyDamageRadioButtons;
    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__13024__radio' or @id='Liability__PD__radio']//mat-radio-button")
    private List<PWElement> allPropertyDamageRadioButtons;
    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__13024__radio' or @id='Liability__PD__radio']/../../..//mat-error")
    private PWElement propertyDamageErrorMessage;
    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__PD__radio']//mat-radio-button[not(contains(@class,'mat-radio-checked'))]")
    private List<PWElement> uncheckedPropertyDamageRadioButtonsForBW;
    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__PD__radio']")
    private List<PWElement> allPropertyDamageRadioButtonsForBW;
    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__MP__radio' or @id='Liability__MEDPM__radio']//mat-radio-button")
    private List<PWElement> allMedicalPaymentsRadioButtonsForBW;
    @PWFindBy(xpath = "//mat-slide-toggle[@id='Liability__MP__toggle' or @id='Liability__MEDPM__toggle']")
    private PWElement medicalPaymentToggle;
    private final String CHECKED_ACCIDENT_DEATH_RADIO_BUTTON_XPATH = "//mat-radio-group[@id='Liability__34018__radio']//mat-radio-button[contains(@class,'checked')]";
    @PWFindBy(xpath = CHECKED_ACCIDENT_DEATH_RADIO_BUTTON_XPATH)
    private PWElement checkedAccidentDeathRadioButton;
    private final String UNCHECKED_ACCIDENT_DEATH_RADIO_BUTTON_XPATH = "//mat-radio-group[@id='Liability__34018__radio']//mat-radio-button[not(contains(@class,'checked'))]";
    @PWFindBy(xpath = UNCHECKED_ACCIDENT_DEATH_RADIO_BUTTON_XPATH)
    private List<PWElement> uncheckedAccidentDeathRadioButtons;

    @PWFindBy(xpath = "//mat-radio-group[@id='Vehicle__21000__radio' or @id='Vehicle__21031__radio']//mat-radio-button[not(contains(@class,'checked'))]//label")
    private List<PWElement> uncheckedCompRadioButtons;
    private final String COMP_UNCHECKED_RADIO_BUTTONS_BW = "//mat-radio-group[@id='Vehicle__COMP__radio' or @id='Vehicle__OTC__toggle' or @id='Vehicle__OTC__radio']//mat-radio-button[not(contains(@class,'checked'))]";
    @PWFindBy(xpath = COMP_UNCHECKED_RADIO_BUTTONS_BW)
    private List<PWElement> uncheckedCompRadioButtonsForBW;

    @PWFindBy(xpath = "//mat-slide-toggle[@id='Vehicle__COMP__toggle' or @id='Vehicle__21000__toggle' or @id='Vehicle__21031__toggle' or @id='Vehicle__OTC__toggle']//button")
    private PWElement comprehensiveToggle;
    @PWFindAll({
            @PWFindBy(xpath = "//button[@id='Vehicle__COMP__toggle-button']"),
            @PWFindBy(css = "button[id='Vehicle__OTC__toggle-button']")
    })
    private PWElement comprehensiveToggleForBW;
    @PWFindBy(xpath = "//mat-radio-group[@id='Vehicle__COMP__radio' or @id='Vehicle__OTC__toggle']//mat-radio-button")
    private List<PWElement> allComprehensiveRadioButtons_BW;
    @PWFindBy(xpath = "//mat-slide-toggle[@id='Vehicle__22000__toggle' or @id='Vehicle__22031__toggle' or @id='Vehicle__COL__toggle']//button")
    private PWElement collToggle;
    @PWFindBy(xpath = "//mat-slide-toggle[@id='Vehicle__LC__toggle']//button")
    private PWElement limitedCollisionToggle;
    @PWFindBy(xpath = "//coverage-input-card[contains(.,'Limited Collision')]//mat-error")
    private PWElement limitedCollisionErrorMessage;
    @PWFindBy(xpath = "//mat-slide-toggle[@id='Vehicle__COLL__toggle' or @id='Vehicle__COL__toggle']")
    private PWElement collToggle_BW;
    @PWFindBy(xpath = "//mat-slide-toggle[@id='Vehicle__UMPD__toggle']")
    private PWElement uimPD_collisonToggle_BW;
    @PWFindBy(xpath = "//mat-radio-group[@id='Vehicle__22000__radio' or @id='Vehicle__22031__radio' or @id='Vehicle__COL__radio']//mat-radio-button[not(contains(@class,'checked'))]//label")
    private List<PWElement> uncheckedCollRadioButtons;
    private final String COLL_UNCHECKED_RADIO_BUTTONS_BW = "//mat-radio-group[@id='Vehicle__COLL__radio' or @id='Vehicle__COL__radio']//mat-radio-button[not(contains(@class,'checked'))]";
    @PWFindBy(xpath = COLL_UNCHECKED_RADIO_BUTTONS_BW)
    private List<PWElement> uncheckedCollRadioButtonsForBW;
    @PWFindBy(xpath = "//mat-radio-group[@id='Vehicle__COLL__radio' or @id='Vehicle__COL__radio']//mat-radio-button")
    private List<PWElement> allRadioCollisionRadioButtons_BW;
    @PWFindBy(xpath = "//app-coverage[contains(.,'Liability')]//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted')]//div[2]")
    private List<PWElement> liabilityCoverageSectionLimits;
    @PWFindBy(xpath = "//app-coverage[contains(.,'Liability')]//mat-expansion-panel")
    private PWElement liabilityCoverageExpansionPanel;
    @PWFindBy(xpath = "//app-coverage[contains(.,'Vehicle')]//mat-expansion-panel")
    private PWElement vehicleCoverageExpansionPanel;
    @PWFindAll(
            @PWFindBy(id = "Liability__UMPD__toggle")
    )
    private PWElement umpdToggle;

    @PWFindAll(
            @PWFindBy(id = "Liability__UMUIM__toggle")
    )
    private PWElement umUimToggle;

    @PWFindAll(
            @PWFindBy(xpath = "//coverage-input-card[contains(.,'UM/UIM Bodily Injury') or contains(.,'UM/UIM Bodily injury')]//mat-error")
    )
    private PWElement umUimToggleErrorMessage;

    @PWFindAll(
            @PWFindBy(xpath = "//coverage-input-card[contains(.,'Uninsured Motorist Property Damage')]//mat-error")
    )
    private PWElement umpdErrorMessage;


    @PWFindBy(xpath = "//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and contains(.,'Included')]")
    private List<PWElement> includedItems;

    @PWFindBy(xpath = "//app-coverage[contains(.,'Vehicle')]//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and not(contains(.,'--'))]//div[2]")
    private List<PWElement> defaultVehicleCoverageSectionLimitsBrowser;

    @PWFindBy(xpath = "//app-coverage[contains(.,'Vehicle')]//div[contains(@class,'row auto-quote-liability-coverages-item-row auto-quote-coverages-mobile d-flex d-md-none ng-star-inserted')]//div[1]")
    private List<PWElement> defaultVehicleCoverageSectionLimitsMobile;

    @PWFindBy(xpath = "//tui-quote-presentment//div[.='See all my quotes']")
    private PWElement linkSeeAllMyQuotes;
    @PWFindBy(xpath = "//app-manage-quotes[contains(.,'My Farmers quotes')]")
    private PWElement myFarmersQuotesTitle;
    @PWFindBy(xpath = "//app-quote//h1[contains(@class, 'page-title')]")
    private PWElement pageTitle;
    @PWFindBy(xpath = "//mat-card[contains(@class,'mobile')]//div[contains(@class,'tui-price')]")
    private PWElement totalPriceDescMobile;
    @PWFindBy(xpath = "//mat-card[contains(@class,'desktop')]//div[contains(@class,'tui-price')]")
    private PWElement totalPriceDescDesktop;
    @PWFindBy(css = ".tui-price>div.lg-price-sides:nth-child(3)")
    private PWElement priceInCents;
    @PWFindBy(xpath = "//div[@class='md-price-sides' and contains(.,'.')]")
    private List<PWElement> priceInCentsMobile;
    @PWFindBy(css = ".tui-price .lg-price-main")
    private PWElement priceInDollars;
    @PWFindBy(xpath = "//div[contains(@class,'tui-quote-presentment-minimized')]//div[@class='md-price-main']")
    private PWElement priceInDollarsMobile;
    @PWFindBy(xpath = "//div[contains(@class,'tui-quote-presentment-expand-button')]")
    private PWElement quoteCardExpandIcon;
    @PWFindBy(css = "div.auto-agent-details__save-quote")
    private PWElement quoteNumber;
    @PWFindBy(xpath = "//button[contains(text(), 'Recalculate')]")
    private PWElement recalculateButton;
    @PWFindBy(css = "mat-dialog-content[id='bwInfoDialogContent']>ul>li")
    private List<PWElement> bwAdjustmentPopUpContents;
    @PWFindBy(xpath = "//div[contains(@class,'auto-quote-liability__button-section')]//a")
    private PWElement resetChangesButton;
    @PWFindBy(css = "p[class='tui-caption-text coverage-error']")
    private PWElement recalculateErrorMessage;
    @PWFindBy(xpath = "//app-edit-liability-coverage//div[@class='ng-star-inserted']")
    private List<PWElement> sectionsOnSideDialog;
    @PWFindBy(css = "div.tui-print-link")
    private PWElement seeAllMyQuotes;
    private static final String MOBILE_CHECKOUT_BUTTON_XPATH = "//mat-card[contains(@class,'mobile quote-presentment-card')]//button[contains(@class,'tui-quote-presentment-button')]";
    @PWFindAll({
            @PWFindBy(xpath = MOBILE_CHECKOUT_BUTTON_XPATH),
            @PWFindBy(partialLinkText = CONTINUE_WITH_AUTO),
            @PWFindBy(xpath = "(//button[@id='track-ctn-btn'])[1]"),
            @PWFindBy(xpath = "//button[contains(@class, 'auto-quote-start-checkout-button') and not(contains(text(),'Bundle'))]"),
    })
    private PWElement mobileStartCheckoutButtonExpended;

    @PWFindAll({
            @PWFindBy(xpath = "//mat-card[contains(@class,'tui-quote-presentment-desktop')]//button[contains(@class,'tui-quote-presentment-button') or contains(@class,'tui-btn tui-btn-cta tui-stacking-bottom')]"),
            @PWFindBy(partialLinkText = CONTINUE_WITH_AUTO),
            @PWFindBy(partialLinkText = CONTINUE_WITH_THIS_QUOTE),
            @PWFindBy(xpath = "//button[contains(@class, 'auto-quote-start-checkout-button')]")
    })
    private PWElement startCheckoutButton;

    @PWFindBy(partialLinkText = BUNDLE_AND_SAVE)
    private PWElement bundleAndContinueButton;

    @PWFindBy(xpath = "//button[@class='tui-btn tui-btn-primary']")
    private PWElement agreeAndSubmitButton;
    @PWFindBy(xpath = "//p[./span]")
    private PWElement subTitleRegardingCurrentCoverage;
    @PWFindBy(xpath = "//p//span[@class='tui-body-bold']")
    private PWElement subTitleRegardingCustomizing;
    @PWFindBy(xpath = "//app-coverage[@class]")
    private List<PWElement> vehicleCoverageSection;
    @PWFindBy(id = "priceAlternativeButton")
    private PWElement viewMonthlyOrFullPriceButton;
    @PWFindBy(xpath = "//mat-card[contains(@class,'tui-quote-presentment-mobile')]//button[@id='priceAlternativeButton']")
    private PWElement mobileviewMonthlyOrFullPriceButton;
    @PWFindBy(xpath = "//span[contains(@class,'contactEsignDisclaimer')]")
    private PWElement contactEsignDisclaimer;
    @PWFindBy(xpath = "//p[contains(@class,'tui-body-text tui-stacking-top-sm')]")
    private PWElement contactInfoDisclaimer;

    @PWFindBy(xpath = "//button[contains(@class, 'auto-quote-bundle-continue-button') or contains(@class, 'auto-quote-bundle-button')]")
    private PWElement bundleContinueToPropertyReviewCoveragePageButton;

    @PWFindBy(xpath = "//div[contains(@class,'tui-quote-presentment-header')]/div[contains(text(),'starting at')]/following::tui-price//div[@class='lg-price-main']")
    private PWElement lblMainPremiumAmount;

    @PWFindBy(xpath = "//button[@id='liabilitySection' or contains(@id,'vwo-liability-coverage-button-white-background')]")
    private PWElement btnEditLiabilityCoverage;

    @PWFindAll({
            @PWFindBy(xpath = "//button[@id='vehicle0Section']"),
            @PWFindBy(xpath = "//button[@id='vwo-vehicle-coverage-button-0-white-background']")
    })
    private PWElement btnEditSingleVehicleCoverage;

    @PWFindAll({
            @PWFindBy(xpath = "//app-edit-liability-coverage//h2"),
            @PWFindBy(xpath = "//p[normalize-space(text())='Liability coverage']")
    })
    private PWElement lblEditLiabilityCoverageHeader;

    @PWFindBy(xpath = "//p[@aria-label='Vehicle Coverage dialog']")
    private PWElement lblEditVehicleCoverageHeader;

    private static final String MEMBERSHIP_PRICE_XPATH = "//tr[contains(.,'Membership fee')]/td[contains(@class,'prices')]";
    @PWFindBy(xpath = MEMBERSHIP_PRICE_XPATH)
    private List<PWElement> membershipFeePrice;

    @PWFindBy(xpath = "//div[@class='col-4 tui-body ng-star-inserted'][2]")
    private List<PWElement> liabilityCoverages;

    @PWFindBy(xpath = "//div[@class='col-4 tui-body'][1]")
    private List<PWElement> vehicleCoverages;

    @PWFindBy(xpath = "//div[@class='col-4 tui-body ng-star-inserted'][2]")
    private List<PWElement> liabilityLimits;

    @PWFindBy(xpath = "//div[@class='col-4 tui-body'][2]")
    private List<PWElement> vehicleLimits;

    @PWFindBy(xpath = "//div[@class='col-2 tui-body liability-price-column ng-star-inserted']")
    private List<PWElement> liabilityPrices;

    @PWFindBy(xpath = "//div[@class='col-2 liability-price-column tui-body']")
    private List<PWElement> vehiclePrices;

    @PWFindBy(xpath = "//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and contains(.,'Vehicle Replacement Plus')]/div[1]")
    private PWElement vehicleReplacementPlusCoverage;

    @PWFindBy(xpath = "//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and contains(.,'Vehicle Replacement Plus')]/div[2]")
    private PWElement vehicleReplacementPlusLimit;

    @PWFindBy(xpath = "//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted') and contains(.,'Vehicle Replacement Plus')]/div[3]")
    private PWElement vehicleReplacementPlusPrice;

    // bundle related elements
    @PWFindBy(css = "button[class='tui-btn tui-btn-primary tui-button-text bw-info-dialog__action-buttons']")
    private PWElement adjustmentDialogCloseButton;

    @PWFindBy(xpath = "//p[contains(@class,'price-to-high-text')]")
    private List<PWElement> priceTooHighTitles;
    @PWFindBy(xpath = "//p[contains(@class,'price-to-high-text')]/following-sibling::p")
    private List<PWElement> priceTooHighDescriptions;
    @PWFindBy(xpath = "//p[contains(@class,'price-to-high-text')]/following-sibling::a")
    private List<PWElement> priceTooHighPhoneNumbers;

    @PWFindBy(css = "button[class='tui-btn tui-btn-primary tui-button-text content-info-dialog__action-buttons']")
    private PWElement quoteUpdateDialogCtaButton;

    @PWFindBy(xpath = "//app-bundle-presentment/div/table/tbody/tr[1]/td[3]")
    private List<PWElement> monthlyAutoPayPriceInBundleQuoteLedger;

    @PWFindBy(xpath = "//app-bundle-presentment/div/table/tbody/tr[1]/td[4]")
    private List<PWElement> payInFullPriceInBundleQuoteLedger;


    @PWFindBy(xpath = "//mat-slide-toggle[@id='Liability__35090__toggle' or @id='Liability__PIP__toggle']/..//h3[@class='tui-input-text-2 coverage-card-label ng-star-inserted']")
    private PWElement pipSideSheetCoverageLabel;

    @PWFindBy(xpath = "//mat-slide-toggle[@id='Liability__35090__toggle' or @id='Liability__PIP__toggle']/../../..//div[@class='col tui-input-text auto-quote-coverage__description mt-1 ng-star-inserted']")
    private PWElement pipSideSheetCoverageDescription;

    @PWFindBy(css = "p[class='pb-3 questionText']")
    private List<PWElement> pb3Question;

    @PWFindBy(id = "SHOW_YES-button")
    private List<PWElement> pipDeductibleYesButton;

    @PWFindBy(id = "SHOW_NO-button")
    private List<PWElement> pipDeductibleNoButton;

    @PWFindBy(css = "p[class='pt-3']")
    private PWElement pipDeductibleButtonsHeader;

    @PWFindBy(xpath = "//mat-radio-group[@id='Liability__35090__radio' or @id='Liability__PIP__radio']//mat-radio-button//label")
    private List<PWElement> pipRadioButtons;

    private final String CHECKED_PIP_RADIO_BUTTON = "//mat-radio-group[@id='Liability__35090__radio' or @id='Liability__PIP__radio']//mat-radio-button[contains(@class,'checked')]";
    @PWFindBy(xpath = CHECKED_PIP_RADIO_BUTTON)
    private PWElement pipCheckedRadioButton;

    @PWFindBy(css = "p[class='deductibleMsg ng-star-inserted']")
    private PWElement zeroDeductibleAppliesElement;

    @PWFindBy(css = "input[formcontrolname='emailAddress']")
    private PWElement emailInputFieldMediaAlpha;

    @PWFindBy(css = "input[formcontrolname='phoneNumber']")
    private PWElement phoneInputFieldMediaAlpha;

    @PWFindBy(css = "div[class='personalInfo-address']")
    private PWElement medialAlphaPrefilledAddress;

    @PWFindBy(xpath = "//div[contains(@class,'combo-coverage')]//div[@class='tooltip-content']//div")
    private PWElement comboCoverageTooltipHeader;

    @PWFindBy(xpath = "//div[contains(@class,'lightbulb-container')]")
    private PWElement comboCoverageTooltipLightBulb;

    @PWFindBy(xpath = "//div[contains(@class,'combo-coverage')]//div[@class='tooltip-content']//span")
    private PWElement comboCoverageTooltipContent;

    private final String ADDITIONAL_COVERAGE_TOGGLE_XPATH = "//div[@class='row tui-stacking-top-md' and contains(.,'Additional coverages')]//following-sibling::div//mat-slide-toggle";
    @PWFindBy(xpath = ADDITIONAL_COVERAGE_TOGGLE_XPATH)
    private List<PWElement> additionalCoverageToggles;

    @PWFindBy(xpath = "//div[contains(@class, 'signal-confirmation-container')]")
    private PWElement continueWithSignalDiscountDialog;

    @PWFindBy(id = "signalABTestYesBtn")
    private PWElement yesContinueWithSignalDiscount;

    @PWFindBy(id = "signalABTestNoBtn")
    private PWElement dontContinueWithSignalDiscount;

    @PWFindBy(xpath = "//div[text()='Permissive User Limit of Liability']/following::div")
    private PWElement permissiveUserLimitUpdatedValue;

    @PWFindBy(xpath = "//div[contains(@class,'reset-org-quote')]")
    private PWElement resetOriginalQuoteButton;

    // TL source code pop up elements
    @PWFindBy(xpath = "//app-sweep-stakes-popup//h4")
    private PWElement sourceCodePopUpHeader;
    @PWFindBy(xpath = "//app-sweep-stakes-popup//mat-dialog-content/p[1]")
    private PWElement sourceCodePopUpContentParagraph1;
    @PWFindBy(xpath = "//app-sweep-stakes-popup//mat-dialog-content/p[2]")
    private PWElement sourceCodePopUpContentParagraph2;
    @PWFindBy(xpath = "//app-sweep-stakes-popup//button")
    private PWElement sourceCodePopUpOkButton;
    @PWFindBy(xpath = "//app-coverage[not(@class)]//div[@class='row auto-quote-liability-coverages-item-row']//div[contains(@class,'liability-price-column')]")
    private  List<PWElement> liabilityCoveragePrice;

    @PWFindBy(xpath = "//app-coverage[not(@class)]//span[contains(@class,'coverage-total-amount')]")
    private List<PWElement> liabilityCoveragePrice1;

    @PWFindBy(xpath = "//app-coverage[(@class)]//div[@class='row auto-quote-liability-coverages-item-row']//div[contains(@class,'liability-price-column')]")
    private List<PWElement> vehicleCoveragePrice;

    @PWFindBy(xpath = "//app-coverage[(@class)]//span[contains(@class,'coverage-total-amount')]")
    private List<PWElement> vehicleCoveragePrice1;

    @PWFindBy(xpath = "//div[contains(@class,'banner-content')]")
    private PWElement payRollBanner;

    @PWFindBy(xpath = "//div[contains(@class,'tui-quote-presentment-content')]/a")
    private PWElement payRollContactButton;

    @PWFindBy(xpath =  "//div[contains(@class,'banner-content')]//p[2]")
    private PWElement payRollBannerContent;

    // BW promo card elements (review-quote page)
    @PWFindBy(css = "div.bw-promo-card")
    private PWElement bwPromoCard;
    @PWFindBy(css = "div.bw-promo-logo img[alt='Bristol West logo']")
    private PWElement bwPromoLogo;
    @PWFindBy(css = "mat-icon.bw-promo-info-icon")
    private PWElement bwPromoInfoIcon;
    @PWFindBy(xpath = "//div[contains(@class,'bw-custom-tooltip')]")
    private PWElement bwPromoInfoIconContent;
    @PWFindBy(css = "h2.bw-promo-header")
    private PWElement bwPromoHeader;
    @PWFindBy(css = "p.bw-promo-content")
    private PWElement bwPromoContent;
    @PWFindBy(css = "p.bw-promo-content a.textlink-color")
    private PWElement bwPromoPhoneLink;

    private static final String BW_PROMO_PHONE_NUMBER = "1-800-206-9469";
    private static final String BW_PROMO_PHONE_HREF = "tel:1-800-206-9469";
    private static final String BW_PROMO_INFO_ICON_ARIA_LABEL = "More information about Bristol West";

    private static final Random randomNumberGenerator = new Random();

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public QuoteSummaryAutoPage() throws Exception {
    }

    public void areLiabilityCoverageLimitsSelectedByDefault() throws Exception {
        List<String> filteredList = getLiabilityCoverageLimits();
        filteredList.removeIf(limit -> limit.equalsIgnoreCase(NOT_COVERED) || limit.equalsIgnoreCase(COVERED) || limit.equalsIgnoreCase(COVERAGE) || limit.equalsIgnoreCase(NO_COVERAGE));
        clickOnEditLiabilityCoverageButton();
        testStepAssert(isOnLiabilityCoverageFrameOfQuoteSummaryAutoPage(), "Liability coverage sidesheet should be displayed");
        List<String> radioButtonLabels = byDefaultSelectedRadioButtons.stream().map(this::getTextFromElement).collect(Collectors.toList());
        boolean isPAState = getSessionStorageAppStore().getData().getLandingStateCode().equals(PA);
        if (isPAState) {
            radioButtonLabels = radioButtonLabels.stream().map(each -> each.replace("Non-stacking", "Non Stacking")).collect(Collectors.toList());
        }
        closeLiabilitySideDialog();
        testStepAssert(areTwoListEqual(radioButtonLabels, filteredList), "Liability coverage sidesheet limits should be selected by default");
    }


    public void areVehicleCoverageLimitsSelectedByDefault() throws Exception {
        List<String> filteredList = getVehicleCoverageLimits();
        filteredList.removeIf(limit -> limit.equalsIgnoreCase(NOT_COVERED) || limit.equalsIgnoreCase(COVERED) || limit.equalsIgnoreCase(COVERAGE) || limit.equalsIgnoreCase(NO_COVERAGE));
        if(!filteredList.isEmpty()) {
            clickOnEditSingleVehicleCoverageButton();
            testStepAssert(isOnVehicleCoverageFrameOfQuoteSummaryAutoPage(), "Vehicle coverage sidesheet should be displayed");
            wait.until(PWExpectedConditions.visibilityOfAllElements(byDefaultSelectedRadioButtons));
            List<String> radioButtonLabels = byDefaultSelectedRadioButtons.stream().map(this::getTextFromElement).collect(Collectors.toList());
            testStepAssert(areTwoListEqual(radioButtonLabels, filteredList), "Vehicle coverage sidesheet limits should be selected by default");
            closeVehicleSideDialog();
        }
        else{
            testStep("No Coverage values are found");
        }
    }

    public void clickOnAlternativePaymentLink() throws Exception {
        // adding below inner if conditions for only pif states
        if (isUseMobileViewEnabled()) {
            clickOnExpandIconForMobileQuoteCardIfNotExpanded();
            if (!getTextFromElement(mobileviewMonthlyOrFullPriceButton).isEmpty()) {
                scrollAndClickOnElement(waitElementBeVisible(mobileviewMonthlyOrFullPriceButton));
            }
        } else {
            if (!getTextFromElement(viewMonthlyOrFullPriceButton).isEmpty()) {
                scrollAndClickOnElement(waitElementBeVisible(viewMonthlyOrFullPriceButton));
            }
        }
    }

    public String getAlternativePaymentLinkText() throws Exception {
        // adding below inner if conditions for only pif states
        if (isUseMobileViewEnabled()) {
            clickOnExpandIconForMobileQuoteCardIfNotExpanded();
            return getTextFromElement(mobileviewMonthlyOrFullPriceButton);
        } else {
            return getTextFromElement(viewMonthlyOrFullPriceButton);
        }
    }

    public void clickOnExpandIconForMobileQuoteCardIfNotExpanded() throws Exception {
        if (!isMobileCardViewExpanded() && isUseMobileViewEnabled()) {
            clickOnQuoteCardExpandIcon();
        }
    }

    public QuoteSummaryAutoPage clickOnEditLiabilityCoverageButton() {
        closeQualtricsPopUp();
        waitAndClickElement(btnEditLiabilityCoverage);
        if (!isElementVisible(liabilitySideDialogTitle, 1)) {
            clickOnEditLiabilityCoverageButton();
        }
        return this;
    }

    public void clickOnEmailLink() throws Exception {
        if (isUseMobileViewEnabled()) {
            clickOnExpandIconForMobileQuoteCardIfNotExpanded();
            scrollElementToMiddle(mobileEmailButton);
            waitAndClickElement(mobileEmailButton);
        } else {
            waitAndClickElement(emailLink);
        }
    }

    public void clickOnQuoteCardExpandIcon() {
        if (!isElementVisible(quoteCardExpandIcon, 1)) {
            return;
        }
        scrollAndClickOnElement(waitElementBeVisible(quoteCardExpandIcon));
    }

    public void clickOnStartCheckoutButton() throws Exception {
        closeQualtricsPopUp();
        if (isElementVisible(gotItButton, 1)) {
            clickGotItButton();
        }
        if (isUseMobileViewEnabled() && !isElementVisible(startCheckoutButton, 1)) {
            closeQualtricsPopUp();
            clickOnExpandIconForMobileQuoteCardIfNotExpanded();
            closeQualtricsPopUp();
            scrollToTopOfPage();
            waitAndClickElement(mobileStartCheckoutButtonExpended);
        } else {
            closeQualtricsPopUp();
            if (!isElementVisible(startCheckoutButton, 2)) {
                closeQualtricsPopUp();
                clickElement(mobileStartCheckoutButtonExpended);
            } else {
                closeQualtricsPopUp();
                clickElement(startCheckoutButton);
            }
        }
        //Signal discount dialog being A/B tested...
        if (isElementDisplayed(continueWithSignalDiscountDialog, 5)) {
            clickElement(yesContinueWithSignalDiscount);
        }
    }

    public void clickBundleAndContinueButton() throws Exception {
        closeQualtricsPopUp();
        if (isElementVisible(gotItButton, 1)) {
            clickGotItButton();
        }
        waitAndClickElement(bundleAndContinueButton);
    }


    public String getPifFullAmount() throws Exception {
        if (isOnMonthlyPay()) {
            clickOnAlternativePaymentLink();
        }

        if (isMobileCardViewExpanded()) {
            clickOnQuoteCardExpandIcon();
        }
        String priceInDollarsText = getTextFromElement(priceInDollars);
        String priceInCentTexts = getTextFromElement(priceInCents);
        if (isUseMobileViewEnabled()) {
            priceInDollarsText = getTextFromElement(priceInDollarsMobile);
            priceInCentTexts = getTextFromElement(priceInCentsMobile.get(0));
        }

        String price = priceInDollarsText.concat(priceInCentTexts);
        double fullPrice = NumberFormat.getNumberInstance().parse(price).doubleValue();
        return String.valueOf(Math.round(fullPrice));
    }

    public void validateDiscountCountOrTotalDiscountOnTheQuoteSummaryCart(AutoApplicant applicant) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        AppStore.Auto.Quote.Eft eft = appStore.getAuto().getQuote().getEft();
        AppStore.Auto.Quote.Pif pif = appStore.getAuto().getQuote().getPif();
        String totalEftDiscount = null;
        try {
            totalEftDiscount = String.valueOf(eft.getRateQuoteResponse().getPersAutoPolicy().getLiabilityCoverage().getCustomCoverages().getTotalDiscount());
        } catch (NullPointerException e) {
            Log.info("EFT is not available for the given state: " + applicant.getStateCode());
        }
        String totalPifDiscount = pif.getRateQuoteResponse().getPersAutoPolicy().getLiabilityCoverage().getCustomCoverages().getTotalDiscount();

        // even if flex, might not have this functionality enabled yet, hence filtering
        if (!StringUtils.isEmpty(totalEftDiscount)) {
            if (isFlexState(applicant.getStateCode()) && !StringUtils.isEmpty(totalPifDiscount)) {
                PWElement discountSavingElementAtTheBottom = driver().findElement(PWBy.xpath("//div[contains(text(),'Your policy premium')]"));
                String expectedPifDiscountMessageAtTheBottom = String.format("Your policy premium includes a total discount savings of $%s", totalPifDiscount);
                String expectedEftDiscountMessageAtTheBottom = String.format("Your policy premium includes a total discount savings of $%s", totalEftDiscount);
                testStepAssert(getTextFromElement(discountSavingElementAtTheBottom), expectedEftDiscountMessageAtTheBottom, "Expected eft discount message at the bottom of the page is not matchin");
                clickOnAlternativePaymentLink();
                waitForSpinnerToBeGone();
                testStepAssert(getTextFromElement(discountSavingElementAtTheBottom), expectedPifDiscountMessageAtTheBottom, "Pif discount messae on the bottom of the page");
            } else {
                int expectedDiscountCount = eft.getRateQuoteResponse().getPersAutoPolicy().getDiscount().size();
                String expectedDiscountTextOnTheQuoteSummaryCart = "" + expectedDiscountCount + " discounts applied";
                testStepAssert(getTextFromElement(waitElementBeVisible(discountsIncludedCount)), expectedDiscountTextOnTheQuoteSummaryCart, "Summary of discounts included to say");
            }
        } else {
            int expectedDiscountCount = pif.getRateQuoteResponse().getPersAutoPolicy().getDiscount().size();
            String expectedDiscountTextOnTheQuoteSummaryCart = "" + expectedDiscountCount + " discounts applied";
            testStepAssert(getTextFromElement(waitElementBeVisible(discountsIncludedCount)), expectedDiscountTextOnTheQuoteSummaryCart, "Summary of discounts included to say -> " + expectedDiscountTextOnTheQuoteSummaryCart);
        }
    }

    public void validateVehicleReplacementPlusCoverage_US819667(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        if (getLiabilityAndVehicleCoverageDefaultCoverages(applicant).getVehicleReplacementPlus().equals(NA)) {
            fsa.assertFalse(isElementVisible(vehicleReplacementPlusCoverage, 3), "If Vehicle Replacement Plus is N/A, the coverage should not be displayed at all");
            return;
        }
        String vehicleReplacementPlus = "Vehicle Replacement Plus";
        waitElementBeVisible(vehicleReplacementPlusCoverage);
        scrollToElement(vehicleReplacementPlusCoverage);
        fsa.assertTrue(vehicleReplacementPlusCoverage.isDisplayed(), vehicleReplacementPlus + " coverage is displayed");
        fsa.assertEquals(getTextFromElement(vehicleReplacementPlusLimit), "Not covered", vehicleReplacementPlus + " coverage limit is as expected");
        fsa.assertEquals(getTextFromElement(vehicleReplacementPlusPrice), "--", vehicleReplacementPlus + " coverage amount is initially empty as expected");
        clickOnEditSingleVehicleCoverageButton();
        PWElement vehicleReplacementToggleOnSideSheet = driver().findElement(PWBy.xpath("//mat-slide-toggle[contains(.,'Vehicle Replacement Plus')]"));
        waitAndClickElement(vehicleReplacementToggleOnSideSheet);
        testStepAssert(getAttributeData(vehicleReplacementToggleOnSideSheet, CLASS).contains(MAT_TOGGLE_CHECKED), "Side Vehicle Replacement Plus toggle turned on successfull");
        clickRecalculateButton();
        waitForSpinnerToBeGone();
        waitElementBeVisible(vehicleReplacementPlusCoverage);
        scrollToElement(vehicleReplacementPlusCoverage);
        fsa.assertTrue(vehicleReplacementPlusCoverage.isDisplayed(), vehicleReplacementPlus + " coverage is displayed after recalculation");
        fsa.assertEquals(getTextFromElement(vehicleReplacementPlusLimit), "Coverage", vehicleReplacementPlus + " coverage limit is as expected after recalculation");
        fsa.assertFalse(getTextFromElement(vehicleReplacementPlusPrice).equals("--"), vehicleReplacementPlus + " coverage amount is not empty after turning on the toggle");
        testStep(TEST_PASSED);
    }

    private boolean isOnMonthlyPay() {
        if (isUseMobileViewEnabled()) {
            return getTextFromElement(totalPriceDescMobile).contains("mo");
        } else {
            return getTextFromElement(totalPriceDescDesktop).contains("mo");
        }
    }

    public String getFullMonthlyPayAmount() throws Exception {
        if (!isOnMonthlyPay()) {
            clickOnAlternativePaymentLink();
        }
        // identifying monthly payment Amount
        String priceInCentTexts = getTextFromElement(priceInCents);
        String priceInDollarsText = getTextFromElement(priceInDollars);
        if (isUseMobileViewEnabled()) {
            priceInDollarsText = getTextFromElement(priceInDollarsMobile);
            priceInCentTexts = getTextFromElement(priceInCentsMobile.get(0));
        }
        String monthlyPayment = priceInDollarsText.concat(priceInCentTexts.substring(0, 3)).replace(",", EMPTY_STRING);
        double fullPriceAmount = Double.parseDouble(monthlyPayment) * 6;
        return String.valueOf(fullPriceAmount);
    }

    public List<String> getLiabilityCoverageLimits() {
        expandLiabilityCoverageCardIfPresent();
        scrollElementToTop(liabilityCoverageSectionLimits.get(0));
        List<String> coveredLiabilityItems = liabilityCoverageSectionLimits.stream().map(this::getTextFromElement).collect(Collectors.toList());
        return coveredLiabilityItems;
    }

    public List<String> getVehicleCoverageLimits() throws Exception {
          expandVehicleCoverageCardIfPresent();
          List<PWElement> selectedElements = isMobileCardViewExpanded() ? defaultVehicleCoverageSectionLimitsMobile : defaultVehicleCoverageSectionLimitsBrowser;
          return selectedElements.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public String getPresentedPremiumAmount() throws Exception {
        String sizeAdjuster = isUseMobileViewEnabled() ? "mobile" : "desktop";
        String premiumAmountXpath = String.format("//mat-card[contains(@class,'%s')]//div[contains(@class,'tui-price')]", sizeAdjuster);
        return getTextFromElement(driver().findElements(PWBy.xpath(premiumAmountXpath)).get(0));
    }

    public boolean isMonthlyOrFullPriceToggleLinkVisible() {
        return !getTextFromElement(viewMonthlyOrFullPriceButton).equals(EMPTY_STRING);
    }

    public boolean isAmountPresentedAsAMonthlyValue() throws Exception {
        if (isUseMobileViewEnabled()) {
            return true; // for mobile break point, /mo is not expected
        }
        return getTextFromElement(driver().findElement(PWBy.cssSelector("tui-price:has(.tui-price .lg-price-main"))).contains("/mo");
    }

    public double getTotalLiabilityCoveragePrice() {
        double totalLiabilityCoverageAmount = 0.0;
        List<PWElement> priceElements = !liabilityCoveragePrice.isEmpty() ? liabilityCoveragePrice : liabilityCoveragePrice1;
        for(PWElement priceValue : priceElements) {
            String liabilityCoverageAmount = getTextFromElement(priceValue).replace("$", EMPTY_STRING).replaceAll(NON_DIGITS_EXCEPT_PERIOD, EMPTY_STRING);
            if (!liabilityCoverageAmount.isEmpty()) {
                totalLiabilityCoverageAmount += Double.parseDouble(liabilityCoverageAmount);
            }
        }
        return totalLiabilityCoverageAmount ;
    }

    public double getTotalVehicleCoveragePrice() {
    	double totalVehicleCoverageAmount = 0.0;
    	List<PWElement> priceElements = !vehicleCoveragePrice.isEmpty() ? vehicleCoveragePrice : vehicleCoveragePrice1;
    	for(PWElement priceValue : priceElements){
    		String vehicleCoverageAmount = getTextFromElement(priceValue).replace("$", EMPTY_STRING).replaceAll(NON_DIGITS_EXCEPT_PERIOD, EMPTY_STRING);
    		if (!vehicleCoverageAmount.isEmpty()) {
    			totalVehicleCoverageAmount += Double.parseDouble(vehicleCoverageAmount);
    		}
    	}
    	return totalVehicleCoverageAmount;
    }

    public boolean goBackToQuoteSummaryPageByClickingBackBrowserButton() throws Exception {
        driver().navigate().back();
        closeQualtricsPopUp();
        testStepAssert(isOnQuoteSummaryAutoPage(), "User should land on the quote summary page");
        PWElement checkoutButton = startCheckoutButton;
        if (isUseMobileViewEnabled()) {
            clickOnExpandIconForMobileQuoteCardIfNotExpanded();
            checkoutButton = mobileStartCheckoutButtonExpended;
        }
        waitElementBeVisible(checkoutButton);
        return isExpectedTextDisplayed(checkoutButton, START_CHECKOUT);
    }

    public void goToQuoteSummaryAutoPageByClickingBrowserBackButton() throws Exception {
        super.navigateBackToPreviousPage();
        waitForSpinnerToBeGone();
    }

    public boolean isBristolWestDisclaimerPresent() {
        return isElementPresent((PWBy.xpath("//footer[contains(@class, 'autoBW')]")), 5);
    }

    public boolean hasProperBristolWestDisclaimer() {
        return isExpectedTextDisplayed(bwDisclaimerFooter, BRISTOL_WEST_DISCLAIMER);
    }

    public DefaultCoverages getLiabilityAndVehicleCoverageDefaultCoverages(AutoApplicant applicant) throws Exception {
        Vehicle vehicle = applicant.getVehicles().get(0);
        String ownership = vehicle.getOwnership();
        String isUsedForRideShare = vehicle.isRidesharing() ? YES : NO;
        String[] coverageLimits = applicant.getCurrentBodilyInjuryLimit().split("/");
        String coverage = Arrays.stream(coverageLimits)
                .map(this::normalizeCoverageLimitForDefaultCoverageFilter)
                .collect(Collectors.joining("/"));

        AutoDataProviders autoDataProviders = new AutoDataProviders();
        String filter = String.format("coverageAmount=%s&umbrella=%s&usedForRideshare=%s&ownership=%s", coverage, "No", isUsedForRideShare, ownership);
        Log.info("Default coverage filter : " + filter);
        return autoDataProviders.listOfCoveragesAndLiabilities(applicant.getStateCode(), filter).stream().findFirst().orElseThrow();
    }

    private String normalizeCoverageLimitForDefaultCoverageFilter(String coverageLimit) {
        String normalizedCoverageLimit = coverageLimit.trim();
        if (!normalizedCoverageLimit.contains("$") && !normalizedCoverageLimit.contains(",")) {
            return normalizedCoverageLimit;
        }

        String digitsOnlyCoverageLimit = normalizedCoverageLimit.replaceAll("[^\\d]", EMPTY_STRING);
        return digitsOnlyCoverageLimit.endsWith("000") && digitsOnlyCoverageLimit.length() > 3
                ? digitsOnlyCoverageLimit.substring(0, digitsOnlyCoverageLimit.length() - 3)
                : digitsOnlyCoverageLimit;
    }

    public boolean isOnQuoteSummaryAutoPage() {
        return isElementPresent(PWBy.xpath("//app-coverage[not(@class)] | //app-quote//h1[contains(@class, 'page-title')]"), 45);
    }

    public boolean quickIsOnQuoteSummaryAutoPage() {
        return isElementPresent(PWBy.xpath("//app-coverage[not(@class)] | //app-quote//h1[contains(@class, 'page-title')]"), 5);
    }

    public boolean isQuotePresentmentCardDisplayed() throws Exception {
        if (isUseMobileViewEnabled()) {
            clickOnExpandIconForMobileQuoteCardIfNotExpanded();
            return isElementDisplayed(quotePresentmentCardMobile);
        } else {
            return isElementDisplayed(quotePresentmentCardDesktop);
        }
    }

    public boolean isRoundedPresentedPremiumSumOfLiabilityAndVehicleCoveragePremium() throws Exception {
        double liabilityPriceValue = getTotalLiabilityCoveragePrice();
        double vehiclePriceValue = getTotalVehicleCoveragePrice();
        double presentedPremiumAmount = Double.parseDouble(getPresentedPremiumAmount().replace("$", "").replace("/mo", "").replace(",", EMPTY_STRING));

        // Round the values to two decimal places
        double roundedLiabilityPrice = Math.round(liabilityPriceValue * 100.0) / 100.0;
        double roundedVehiclePrice = Math.round(vehiclePriceValue * 100.0) / 100.0;
        double roundedPresentedPremium = Math.round(presentedPremiumAmount * 100.0) / 100.0;

        Log.info("Presented Premium: " + String.format("%.2f", roundedPresentedPremium));
        Log.info("Sum of Liability and Vehicle coverages: " + String.format("%.2f", roundedLiabilityPrice + roundedVehiclePrice));
        return Math.abs((roundedLiabilityPrice + roundedVehiclePrice) - roundedPresentedPremium) <= .02;
    }

    public boolean isVehicleCoverageTableContentDisplayedCorrectly(AutoApplicant applicant) {
        List<String> listOfExpectedCoverageNames = EnumSet.allOf(LiabilityCoverage.class).stream().map(liabilityCoverage -> liabilityCoverage.coverage).collect(Collectors.toList());
        return isCoverageNamesDisplayedCorrectly(vehicleCoverageSection.get(0), listOfExpectedCoverageNames);
    }

    public void refreshThePage() throws Exception {
        driver().navigate().refresh();
        waitUntilAngular5Ready();
    }

    public void selectRandomUncheckedLiabilityCoverageRadioButtons(String coverageName) throws Exception {
        PWElement displayedComprehensiveToggleSlider = isOnBristolWest() ? comprehensiveToggleForBW : comprehensiveToggle;
        if (coverageName.equals(VehicleCoverage.COMPREHENSIVE.coverage) && isButtonNotSelected(displayedComprehensiveToggleSlider)) {
            clickElement(displayedComprehensiveToggleSlider);
        }
        PWBy uncheckedLiabilityRadioButtons = PWBy.xpath(String.format(unselectedRadioButtonsXpath, coverageName));
        List<PWElement> listUncheckedRadioButtons = driver().findElements(uncheckedLiabilityRadioButtons);
        scrollAndClickOnElement(listUncheckedRadioButtons.get(randomNumberGenerator.nextInt(listUncheckedRadioButtons.size())));
    }

    public QuoteSummaryAutoPage validateAllLiabilityCoverageSectionContent() throws Exception {
        clickOnEditLiabilityCoverageButton();
        validateCoverageSectionContent();
        closeLiabilitySideDialog();
        return this;
    }

    public QuoteSummaryAutoPage validateAllVehicleCoverageSectionContents() {
        vehicleCoverageSection.forEach(vehicleTable -> {
            clickOnEditVehicleCoverageButton(vehicleTable);
            try {
                validateCoverageSectionContent();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            closeVehicleSideDialog();
        });
        return this;
    }

    public void validateDiscounts(AutoApplicant applicant, boolean monthlyPay, boolean isEarlyShopper, boolean eligibleOccupation, FarmersSoftAssert fsa) throws Exception {
        String stateCode = applicant.getStateCode();
        if (!stateCode.equals(IL)) {
            return;
            //For the moment, enabling only IL for discount validation as it is too complicated to handle at once
        }
        List<String> expectedDiscountsForGivenApplicant = AutoDiscounts.getExpectedDiscountsForGivenApplicant(applicant, monthlyPay, isEarlyShopper, eligibleOccupation);
        sleep(3);
        List<String> actualDiscountNames = getDisplayedDiscounts();
        Collections.sort(actualDiscountNames);
        Collections.sort(expectedDiscountsForGivenApplicant);
        fsa.assertEquals(actualDiscountNames, expectedDiscountsForGivenApplicant, String.format("Expected list -> %s, But found -> %s", expectedDiscountsForGivenApplicant, actualDiscountNames));
    }

    public void validateDiscountsE2E(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        applicant.setCompletedDriversSafetyCourse(true);
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        Log.info("Quote number for this flow: " + getSessionStorageAppStore().getData().getQuoteNumber());
        List<String> expectedDiscounts = new ArrayList<>();
        SqlDiscount sqlDiscount = applicant.getDiscounts().get(0);
        autoEnterAddressPage.clickHomeOwnerCheckBox();
        testStep("Homeowner checkbox is checked");
        autoEnterAddressPage.isSnackBarMessageDisplayed("Great! We've added the homeowner discount.");
        //unchecked
        autoEnterAddressPage.clickHomeOwnerCheckBox();
        autoEnterAddressPage.isSnackBarMessageDisplayed("Homeowner discount has been removed");
        sleep(1);
        sqlDiscount.setOwnOrRentHome("Own a home");
        testStep("Homeowner discount rules are validated on the Address page", true);
        autoEnterAddressPage.fillOutAddressPage(applicant);
        if (!isHomeownerDiscountDisabledState(applicant)) {
            expectedDiscounts.add("Homeowner");
        }
        String stateCode = applicant.getStateCode();
        if (isFlexState(stateCode)) {
            expectedDiscounts.add("Welcome");
        }

        InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
        if (interstitialBundlePage.isOnInterstitialBundlePage()) {
            interstitialBundlePage.continueWithAutoMonoLine();
        }

        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        List<Vehicle> vehicles = applicant.getVehicles();
        if (whoShouldWeInsurePage.isOnWhoShouldWeInsurePage()) {
            fsa.assertTrue(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the who should we insure page");
            whoShouldWeInsurePage.clickOnAddVehiclesAndDriversButton();
            for (int i = 0; i < vehicles.size(); i++) {
                whoShouldWeInsurePage.clickOnYMMButton();
                whoShouldWeInsurePage.fillOutVehicleYearModelMakeFields(vehicles.get(i));
                whoShouldWeInsurePage.fillOutVehicleTypeIfNeeded(vehicles.get(i).getVehicleType());
                whoShouldWeInsurePage.clickOnAddVehicleButton();
                if (i == 0) {
                    whoShouldWeInsurePage.clickOnAddAnotherVehicleButtonSideSheet();
                } else {
                    fsa.assertTrue(whoShouldWeInsurePage.isSnackBarMessageDisplayed("Great -- we added a multi-car discount!"), "Multi car discount snackbar message is validated");
                    whoShouldWeInsurePage.clickOnDoneAddingVehiclesButton();
                }
            }
            whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.clickContinueButton();

            expectedDiscounts.add("Multi-car");

        }
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        if (heresWhatWeFoundPage.isOnHeresWhatWeFoundPage()) {
            if (heresWhatWeFoundPage.getListOfCheckedVehicles().isEmpty()) {
                heresWhatWeFoundPage.addRandomNewVehicle(vehicles.get(0).getVehicleVIN());
            }
            String applicantFullName = applicant.getFirstName() + SPACE + applicant.getLastName();
            heresWhatWeFoundPage.addADPFApplicant(Optional.of(applicant), applicantFullName, applicant.getGender(), applicant.getLastName());
            if (heresWhatWeFoundPage.getListOfCheckedVehicles().size() > 1) {
                expectedDiscounts.add("Multi-car");
            }
            heresWhatWeFoundPage.clickContinueButton();
        }
        // Vehicle Review Page
        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        Collections.sort(expectedDiscounts);
        fsa.assertTrue(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on the Vehicle  Review Page");
        Vehicle vehicleInfo = vehicles.get(0);
        if (isAntiTheftRecoverySystemEnabledState(applicant.getStateCode())) {
            vehicleInfo.setTheftRecoverySystem(true);
            vehicleReviewPage.setTheftRecoverySystemDiscount(vehicleInfo, 1);
            vehicleReviewPage.setTheftRecoverySystemDiscount(vehicleInfo, 2);
            //fsa.assertTrue(isSnackBarMessageDisplayed("anti theft discount"), "Anti theft discount snackbar display validated");
            expectedDiscounts.add("Anti-theft device");
        }
        vehicleReviewPage.setVehicleUsagesToPersonal();
        vehicleReviewPage.reviewDiscountSection("Vehicle ReviewPage");
        int theDiscountCountFromBottomOfThePage = vehicleReviewPage.getTheDiscountCountFromBottomOfThePage();
        fsa.assertTrue(theDiscountCountFromBottomOfThePage == expectedDiscounts.size(), "The discount count on the bottom of the page is matching withe the expected discount count");
        List<String> displayedDiscounts = getDisplayedDiscounts();
        Collections.sort(expectedDiscounts);
        fsa.assertEquals(displayedDiscounts, expectedDiscounts, "Expected discounts matching the actual on " + vehicleReviewPage.getClass().getSimpleName());
        vehicleReviewPage.clickOnContinueButton();
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        // set occupation for the pni
        String occupation = EMPTY_STRING;
        try {
            occupation = getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("occupation")).findFirst().get().getDropDownValues().stream().filter(each -> StringUtils.isEmpty(each.getParentValue())).findFirst().get().getWebDesc();
        } catch (Exception e) {
            Log.info("Occupation set up no successful");
        }
        applicant.setOccupation(occupation);
        testStepAssert(driverReviewPage.isOnDriverReviewPage(), "User is on the driver review page");
        String applicantFullName = driverReviewPage.getApplicantFullName(applicant);
        String driverFullName = driverReviewPage.getDriverFullName(applicant.getAdditionalDrivers().get(0));
        // profession discount
        if (!driverReviewPage.isEmploymentDiscountDisabledState(stateCode) && !StringUtils.isEmpty(occupation)) {
            driverReviewPage.addEmployment(applicantFullName, applicant.getOccupation());
            //fsa.assertTrue(isSnackBarMessageDisplayed("Way to go! We added a profession group discount."), "Profession group discount is added");
            expectedDiscounts.add("Profession group");
        }
        // safety course discount if applicable
        if (driverReviewPage.isSafetyCourseExpectedState(stateCode)) {
            if (driverReviewPage.addSafetyCourse(applicantFullName)) {
                //TODO: this is still not showing up, even thoug removal shows up CHECK WITH QE
                // fsa.assertTrue(isSnackBarMessageDisplayed("Mature driver"), "Mature driver discount snackbar is validated");
                if (Arrays.asList(OK, GA, KS).contains(stateCode)) {
                    expectedDiscounts.add("Defensive driver");
                } else {
                    expectedDiscounts.add("Mature driver");
                }
            }
        }
        String additionalDriverXpath = driverReviewPage.getDriverCardXpathByFullName(driverFullName);
        // Good student discount
        String gpaCheckbox = additionalDriverXpath + GPA_OVER_3_INPUT_XPATH;
        if (isElementPresent(PWBy.xpath(gpaCheckbox))) {
            PWElement element = driver().findElement(PWBy.xpath(gpaCheckbox));
            clickElement(element);
            Collections.sort(expectedDiscounts);
            fsa.assertTrue(isSnackBarMessageDisplayed("Way to go! We've added the good student discount."), "Good student discount snackbar is displayed");
            expectedDiscounts.add("Good student");
        }
        // Distant student discount
        String distantStudentXpath = additionalDriverXpath + DISTANT_STUDENT_CHECKBOX_INPUT_XPATH;
        if (isElementPresent(PWBy.xpath(distantStudentXpath))) {
            waitAndClickElement(driver().findElement(PWBy.xpath(distantStudentXpath)));
            fsa.assertTrue(isSnackBarMessageDisplayed("Nice! We added the distant student discount."), "Distant student snackbar is displayed");
            expectedDiscounts.add("Distant student");
        }
        expectedDiscounts.add("Accident free"); // accident free discount is added
        theDiscountCountFromBottomOfThePage = driverReviewPage.getTheDiscountCountFromBottomOfThePage();
        displayedDiscounts = getDisplayedDiscounts();
        Collections.sort(expectedDiscounts);
        fsa.assertEquals(theDiscountCountFromBottomOfThePage, expectedDiscounts.size(), "The discount count on the bottom of the page is matching withe the expected discount count on " + driverReviewPage.getClass().getSimpleName());
        fsa.assertEquals(displayedDiscounts, expectedDiscounts, "The expected discounts are matching with the actual on " + driverReviewPage.getClass().getSimpleName());
        driverReviewPage.addDriverLicenseNumber(applicant, applicantFullName);
        driverReviewPage.addDriverLicenseNumber(applicant, driverFullName);
        driverReviewPage.enterDriverLicenseAge(applicant, driverReviewPage.getApplicantFullName(applicant), 16);
        applicant.getAdditionalDrivers().forEach(each -> {
            try {
                driverReviewPage.enterDriverLicenseAge(applicant, driverReviewPage.getDriverFullName(each), 16);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        });
        driverReviewPage.clickContinueButton();
        SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
        if (!isSignalDiscountDisabledState(stateCode)) {
            testStepAssert(signalPageOneUI.isOnSignalPage(), "User is on the signal page", true);
            signalPageOneUI.processSignalPage(true);
            //fsa.assertTrue(signalPageOneUI.isSnackBarMessageDisplayed("Let's go! We've added the Signal discount."), "Signal Discount snackbar validated");
            expectedDiscounts.add("Signal");
            Collections.sort(expectedDiscounts);
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.validateEarlyShopperDiscount(fsa);
        contactInfoAutoPage.validateBundleSaveSection(applicant, fsa);
        sqlDiscount.setBusinessInsurance(false);
        sqlDiscount.setCondoInsurance(false);
        sqlDiscount.setValueTermLifeInsurance(false);
        sqlDiscount.setMotorcycleInsurance(false);
        sqlDiscount.setRecreationalBoatWatercraftInsurance(false);
        sqlDiscount.setRentersInsurance(false);
        sqlDiscount.setUmbrellaInsurance(false);
        contactInfoAutoPage.sendKeysToPolicyStartDateInputField(getFormattedForPolicyStartDate(LocalDate.now().plusDays(8)));
        contactInfoAutoPage.setValuesAndContinue(applicant);
        expectedDiscounts.add("Early shopping");
        Collections.sort(expectedDiscounts);
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            if (stateCode.equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
        }
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if (bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            bwFarmersQuotePresentmentPage.continueWithFarmers();
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
        if (stateCode.equals(PA)) {
            expectedDiscounts.add("Driver Improvement");
            expectedDiscounts.remove("Mature driver");
            expectedDiscounts.add("Passive Restraint");
            expectedDiscounts.remove("Anti-theft device");
            Collections.sort(expectedDiscounts);
        } else if (stateCode.equals(IA)) {
            expectedDiscounts.add("Safe driver");
            expectedDiscounts.remove("Mature driver");
        } else if (stateCode.equals(OH)) {
            expectedDiscounts.add("Paperless");
        } else if (stateCode.equals(KY)) {
            expectedDiscounts.remove("Mature driver");
            expectedDiscounts.add("Safe driver");
            expectedDiscounts.add("Defensive driver");
        }
        displayedDiscounts = getDisplayedDiscounts();
        Collections.sort(expectedDiscounts);
        for (String expectedDiscount : expectedDiscounts) {
            fsa.assertTrue(displayedDiscounts.contains(expectedDiscount), "this list of displayed discounts" + displayedDiscounts + " should contain expected discount " + expectedDiscount);
        }
        testStep("Retrieve data: " + getSessionStorageAppStore().getData().getQuoteNumber() + SPACE + applicant.getLastName() + SPACE + getSessionStorageAppStore().getData().getLandingZipCode() + SPACE + applicant.getDateOfBirth());
    }

    public void validateExpectedCoveragesAndLiabilities(DefaultCoverages defaultCoverageValues, FarmersSoftAssert fsa, String testCase) throws Exception {
        String stateCode = defaultCoverageValues.getStateCode();
        boolean isBristolWestQuote = isOnBristolWest();
        boolean isRideshareVehicle = false;
        if (testCase.contains(DEFAULT_COVERAGE_VALIDATION)) {
            isRideshareVehicle = defaultCoverageValues.getUsedForRideshare().equals(YES);
        } else {
            try {
                getSessionStorageAppStore().getAuto().getVehicles().get(0).getRideShareVeh().equals("Y");

            } catch (Exception npe) {
                Log.info("Trying to access vehicle rideshare data from appStore is throwing exception " + npe
                        .getMessage());
            }
        }
        boolean isAutoLoanLeaseExpected = isBristolWestQuote && !Arrays.asList(MD, MN, NV).contains(stateCode) &&
                (stateCode.equals(OH) || !Arrays.asList(OR, ID, WA, OK, MS, MD, ND, NM).contains(stateCode) &&
                        !defaultCoverageValues.getOwnership().equals("Owned") &&
                        !NA.equals(defaultCoverageValues.getAutoLoanLease()));
        liabilityAndVehicleCoverageExpandIfExist();
        closeQualtricsPopUp();
        List<PWElement> listOfCoveragesAndLiabilitiesElementsOnPage = driver().findElements(PWBy.xpath("//div[contains(@class,'auto-quote-coverages-section')]//div[@aria-label and not(contains(@class, 'mobile'))]/div[1]"));
        List<String> listOfCoveragesAndLiabilitiesLabelsOnPage = listOfCoveragesAndLiabilitiesElementsOnPage.stream().map(this::getTextFromElement)
                .filter(label -> !label.isEmpty())
                .distinct().sorted()
                .collect(Collectors.toList());
        List<String> listOfExpectedCoveragesAndLiabilitiesOnPage = AceAutoCoveragesAndLiabilites.getListOfExpectedCoveragesAndLiabilities(stateCode, isBristolWestQuote, isRideshareVehicle, isAutoLoanLeaseExpected);
        //Conditional coverage
        if (listOfExpectedCoveragesAndLiabilitiesOnPage.contains(AceAutoCoveragesAndLiabilites.COLLISION_TYPE.getCoverageOrLiabilityText()) && defaultCoverageValues.getLossOfUse().equals(NA)) {
            listOfExpectedCoveragesAndLiabilitiesOnPage.remove(AceAutoCoveragesAndLiabilites.COLLISION_TYPE.getCoverageOrLiabilityText());
        }
        //DE210684, DE210686 and DE211414 allow for different label for coverage based on environment; lists are defined with MA11 in mind
        if (isRA11Environment()) {
            switch (stateCode) {
                case KS:
                    if (!isBristolWestQuote) {
                        listOfExpectedCoveragesAndLiabilitiesOnPage.remove(AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY.getCoverageOrLiabilityText());
                        listOfExpectedCoveragesAndLiabilitiesOnPage.add(AceAutoCoveragesAndLiabilites.UM_UIM_BODILY_INJURY.getCoverageOrLiabilityText());
                    }
                    break;
                case NM:
                    listOfExpectedCoveragesAndLiabilitiesOnPage.remove(AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY.getCoverageOrLiabilityText());
                    listOfExpectedCoveragesAndLiabilitiesOnPage.remove(AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE.getCoverageOrLiabilityText());
                    listOfExpectedCoveragesAndLiabilitiesOnPage.add(AceAutoCoveragesAndLiabilites.UM_UIM_BODILY_INJURY.getCoverageOrLiabilityText());
                    listOfExpectedCoveragesAndLiabilitiesOnPage.add(AceAutoCoveragesAndLiabilites.UM_UIM_PROPERTY_DAMAGE.getCoverageOrLiabilityText());
                    break;
                case TX:
                    listOfExpectedCoveragesAndLiabilitiesOnPage.remove(AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY.getCoverageOrLiabilityText());
                    listOfExpectedCoveragesAndLiabilitiesOnPage.remove(AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PD.getCoverageOrLiabilityText());
                    listOfExpectedCoveragesAndLiabilitiesOnPage.add(AceAutoCoveragesAndLiabilites.UM_UIM_BODILY_INJURY.getCoverageOrLiabilityText());
                    listOfExpectedCoveragesAndLiabilitiesOnPage.add(AceAutoCoveragesAndLiabilites.UM_UIM_PROPERTY_DAMAGE.getCoverageOrLiabilityText());
                    break;
                default:
                    // No action taken
            }
            listOfExpectedCoveragesAndLiabilitiesOnPage.sort(Comparator.comparing(String::toString));
        }

        // Check that the coverages listed are the ones we expect for each scenario
        // (will catch when any that we don't know about are added or if ones we do know about are removed)
        Collections.sort(listOfCoveragesAndLiabilitiesLabelsOnPage);
        Collections.sort(listOfExpectedCoveragesAndLiabilitiesOnPage);
        fsa.assertEquals(listOfCoveragesAndLiabilitiesLabelsOnPage, listOfExpectedCoveragesAndLiabilitiesOnPage, "listOfExpectedCoveragesAndLiabilitiesOnPage for " + testCase);

        // Should only check default coverage values if spreadsheet data and company match, that is, Farmers data -> Farmers quote , BW data -> BW quote
        if (isBristolWestQuote == testCase.contains("BW")) {
            // Check the default value for each defined coverage in alphabetical order when expected, absence from the page when not.
            String coverageToCheck = AceAutoCoveragesAndLiabilites.ONE_HUNDRED_DOLLAR_GLASS_COVERAGE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getGlassCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.COMPULSORY_BODILY_INJURY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.OPTIONAL_BODILY_INJURY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getOptionalBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.PROPERTY_DAMAGE_PART4.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getPropertyDamageLiability(), testCase);

            coverageToCheck = UNINSURED_MOTORIST_BODILY_INJURY_PART3.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUninsuredMotoristBodilyInjury(), testCase);

            coverageToCheck = UNDERINSURED_MOTORIST_BODILY_INJURY_PART12.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUnderInsuredMotoristBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.MEDICAL_PAYMENTS_PART6.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getMedicalCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.MEDICAL_PAYMENTS_PART6.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getMedicalCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.PERSONAL_INJURY_PROTECTION_PART2.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, "Included", testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.PERSONAL_INJURY_PROTECTION_DEDUCTIBLE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getPip(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, "Not covered", testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.COMPREHENSIVE_PART9.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getComprehensive(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.COLLISION_PART7.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getCollision(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.LIMITED_COLLISION_PART8.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getLimitedCollision(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.TOWING_AND_LABOR_PART11.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getRoadsideAssistance(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.COLLISION_WAIVER_OF_DEDUCTIBLE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, "Not covered", testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.SUBSTITUTE_TRANSPORTATION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getSubstituteTransportation(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.RIDESHARE_COVERAGE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getRideshareCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.ONE_HUNDRED_DOLLAR_GLASS_DEDUCTIBLE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getGlassCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.ACCIDENT_FORGIVENESS.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getAccidentForgiveness(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.ACCIDENTAL_DEATH.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getAccidentalDeathDisablingInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.AUTO_LOAN_LEASE.getCoverageOrLiabilityText();
            checkCoverage(fsa, isAutoLoanLeaseExpected, coverageToCheck, defaultCoverageValues.getAutoLoanLease(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.BODILY_INJURY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.BODILY_INJURY_LIABILITY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.COLLISION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getCollision(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.COLLISION_PLUS_LOSS_OF_USE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getLossOfUse(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.COLLISION_TYPE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getLossOfUse(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.COMPREHENSIVE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getComprehensive(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.CUSTOMIZATION_OVER_1000.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getCustomizationOver1000(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.DEATH_AND_DISMEMBERMENT.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getDeathAndDismemberment(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.DECLINING_DEDUCTIBLE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getDecliningDeductible(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.ENHANCED_UNDERINSURED_MOTORIST_BODILY_INJURY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, NOT_COVERED, testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.ENHANCED_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, NOT_COVERED, testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.EXCESS_MEDICAL_PAYMENTS.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getExcessMedicalPayments(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.GLASS_DEDUCTIBLE_BUYBACK.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getGlassCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.GUEST_PIP.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, NOT_COVERED, testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.INCOME_DISABILITY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getIncomeDisability(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.INCOME_LOSS_BENEFITS.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getIncomeLossBenefits(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.INCOME_LOSS.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getIncomeLossBenefits(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.LOSS_OF_USE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getLossOfUse(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.MEDICAL.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getMedicalCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.MEDICAL_AND_HOSPITAL_BENEFITS.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getMedicalAndHospitalBenefits(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.MEDICAL_COVERAGE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getMedicalCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.MEDICAL_PAYMENTS.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getMedicalCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.NEW_ORIGINAL_PARTS.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getNewOriginalParts(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.PERSONAL_INJURY_PROTECTION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getPip(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.PERMISSIVE_USER_LIMIT_OF_LIABILITY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getPermissiveUserLimitOfLiability(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.PERSONAL_INJURY_PROTECTION_MEDICAL.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, "Unlimited/$0", testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.PERSONAL_INJURY_PROTECTION_OTHER.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, isBristolWestQuote ? defaultCoverageValues.getPip() : COVERED, testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.PROPERTY_DAMAGE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getPropertyDamageLiability(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.PROPERTY_DAMAGE_LIABILITY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getPropertyDamageLiability(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.PROPERTY_PROTECTION_INSURANCE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, isBristolWestQuote ? defaultCoverageValues.getPpi() : COVERED, testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.RENTAL.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getRentalCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.RENTAL_ALTERNATIVE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getRentalAlternative(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.RENTAL_REIMBURSEMENT.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getRentalCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.RIDESHARE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getRideshareCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.RIDESHARE_AND_FOOD_DELIVERY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getRideshareCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.ROADSIDE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getRoadsideAssistance(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.ROADSIDE_ASSISTANCE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getRoadsideAssistance(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.SAFETY_GLASS_WAIVER_OF_DEDUCTIBLE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getGlassCoverage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.STATE_RECOUPMENT_FEES.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, "Included", testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.TORT.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, "Limited", testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.TOWING_AMPERSAND_ROAD_SERVICE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getRoadsideAssistance(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.TOWING_AND_LABOR_COSTS.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getTowingAndLaborCosts(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.TOWING_AND_ROAD_SERVICE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getRoadsideAssistance(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.TRAVEL_PACKAGE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getTravelPackage(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UIM_BODILY_LOWERCASE_INJURY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UM_BODILY_INJURY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UM_BODILY_LOWERCASE_INJURY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UM_PROPERTY_DAMAGE_WO_COLLISION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, NOT_COVERED, testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UM_UIM_BODILY_INJURY.getCoverageOrLiabilityText();
            String umUimBodilyInjuryValue = Arrays.asList(GA, LA, KS, NM, TX).contains(stateCode) ? defaultCoverageValues.getBodilyInjury() : defaultCoverageValues.getUmUIMBodilyInjury();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, umUimBodilyInjuryValue, testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UM_UIM_BODILY_LOWERCASE_INJURY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, stateCode.equals(AZ) ? defaultCoverageValues.getBodilyInjury() : defaultCoverageValues.getUmUIMBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_PD_WITHOUT_COLLISION_LOWER_CASE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmpdNoCollision(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UM_UIM_PROPERTY_DAMAGE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmpdNoCollision(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITHOUT_COLLISION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmpdNoCollision(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmpdWithCollision(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNDER_INSURED_MOTORIST.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUnderinsuredMotorist(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNDER_INSURED_MOTORIST_BODILY_INJURY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUninsuredMotoristBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNDERINSURED_MOTORIST.getCoverageOrLiabilityText();
            String underinsuredValue = defaultCoverageValues.getUninsuredUnderinsuredMotorist();
            if (stateCode.equals(IN)) {
                underinsuredValue = isBristolWestQuote ? defaultCoverageValues.getUnderinsuredMotorist() : defaultCoverageValues.getPip();
            }
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, underinsuredValue, testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNDERINSURED_MOTORIST_BI.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, NON_STACKING, testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNDERINSURED_MOTORIST_PD.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUnderinsuredMotorist(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST.getCoverageOrLiabilityText();
            String uninsuredValue = Arrays.asList(PA, UT, MO).contains(stateCode) && isBristolWestQuote ? defaultCoverageValues.getUninsuredMotorist() : defaultCoverageValues.getUninsuredUnderinsuredMotorist();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, uninsuredValue, testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_BI.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_BI_OPTIONS.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, "Full", testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_BODILY_INJURY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUninsuredUnderinsuredMotorist(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, NON_STACKING, testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNDERINSURED_MOTORIST_ELECTION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUninsuredMotoristElection(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_UNDERINSURED_MOTORIST_SELECTION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUninsuredMotoristSelection(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_PD.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmpdNoCollision(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_PD_WITHOUT_COLLISION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmpdNoCollision(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UMPD_WO_COLLISION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmpdNoCollision(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_PD_WO_COLLISION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmpdNoCollision(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_PROPERTY_DAMAGE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmpdNoCollision(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PD.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmpdNoCollision(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE.getCoverageOrLiabilityText();
            String umUimPropertyDamageValue = stateCode.equals(NM) ? defaultCoverageValues.getUmpdNoCollision() : defaultCoverageValues.getUmUimPD();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, umUimPropertyDamageValue, testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_UNDERINSURED_MOTORIST.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmUIMBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_UNDERINSURED_MOTORIST.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmUIMBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_UNDERINSURED_MOTORIST_BODILY_INJURY.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmUIMBodilyInjury(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_CONVERSION.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getUmUIMBIConversion(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.VEHICLE_REPLACEMENT_PLUS.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getVehicleReplacementPlus(), testCase);

            coverageToCheck = AceAutoCoveragesAndLiabilites.ZERO_GLASS_DEDUCTIBLE.getCoverageOrLiabilityText();
            checkCoverage(fsa, listOfExpectedCoveragesAndLiabilitiesOnPage.contains(coverageToCheck), coverageToCheck, defaultCoverageValues.getGlassCoverage(), testCase);
        } else {
            Log.warn("Can't validate expected values because spreadsheet data and rating company do not match");
        }
    }

    private void checkCoverage(FarmersSoftAssert fsa, boolean isCoverageExpected, String coverageToCheck, String expectedCoverageValue, String testCase) throws Exception {
        if (isCoverageExpected) {
            try {
                PWElement coverageToCheckValue = driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, coverageToCheck)));
                scrollElementToMiddle(coverageToCheckValue);
                fsa.assertEquals(getTextFromElement(coverageToCheckValue), expectedCoverageValue, testCase + SPACE + coverageToCheck);
                PWElement coverageToCheckPrice = driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_PRICE, coverageToCheck)));
                scrollElementToMiddle(coverageToCheckPrice);
                if (Arrays.asList(NO_COVERAGE, NOT_COVERED).contains(expectedCoverageValue) || Arrays.asList("Personal Injury Protection (Part 2)").contains(coverageToCheck)) {
                    fsa.assertEquals(getTextFromElement(coverageToCheckPrice), "--", testCase + SPACE + coverageToCheck + " price");
                } else if (Arrays.asList(FULL).contains(expectedCoverageValue)) {
                    fsa.assertEquals(getTextFromElement(coverageToCheckPrice), "Included", testCase + SPACE + coverageToCheck + " price");
                } else if (Arrays.asList(STANDARD, "Alternative").contains(expectedCoverageValue) && getSessionStorageAppStore().getData().getLandingStateCode().equals(VA)) {
                    fsa.assertEquals(getTextFromElement(coverageToCheckPrice), "--", testCase + SPACE + coverageToCheck + " price");
                } else {
                    String coveragePriceString = getTextFromElement(coverageToCheckPrice);
                    String coveragePriceAmount = coveragePriceString.replaceAll(NON_DIGITS_EXCEPT_PERIOD, EMPTY_STRING);
                    if (coveragePriceAmount.equals(EMPTY_STRING)) {
                        fsa.assertEquals(coveragePriceString, coveragePriceAmount, testCase + SPACE + coverageToCheck + " price of " + coveragePriceString + " should be a valid amount ");
                    } else {
                        double coverageAmount = Double.parseDouble(coveragePriceAmount);
                        fsa.assertTrue(coverageAmount > 0.0, testCase + SPACE + coverageToCheck + " price of " + coveragePriceString);
                    }
                }
            } catch (PWNoSuchElementException nse) {
                if (!coverageToCheck.contains("Personal Injury Protection") && getSessionStorageAppStore().getData().getLandingStateCode().equals(MA)) {
                    fsa.assertTrue(!driver().findElements(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, coverageToCheck))).isEmpty(), testCase + SPACE + coverageToCheck + " listed as a coverage/liability");
                }
            }
        } else {
            if (!coverageToCheck.contains("Personal Injury Protection") && getSessionStorageAppStore().getData().getLandingStateCode().equals(MA)) {
                fsa.assertTrue(driver().findElements(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, coverageToCheck))).isEmpty(), testCase + SPACE + coverageToCheck + " should not be a listed coverage/liability");
            }
        }
    }

    private void liabilityAndVehicleCoverageExpandIfExist() {
        expandVehicleCoverageCardIfPresent();
        expandLiabilityCoverageCardIfPresent();
    }

    private void expandLiabilityCoverageCardIfPresent() {
        if (isElementVisible(liabilityCoverageExpansionPanel, 1)) {
            if (!doesAttributeContainText(liabilityCoverageExpansionPanel, CLASS, "mat-expanded")) {
                scrollAndClickOnElement(liabilityCoverageExpansionPanel);
                wait.until(PWExpectedConditions.attributeContains(liabilityCoverageExpansionPanel, CLASS, "mat-expanded"));

            }
        }
    }

    private void expandVehicleCoverageCardIfPresent() {
        if (isElementVisible(vehicleCoverageExpansionPanel, 1)) {
            if (!doesAttributeContainText(vehicleCoverageExpansionPanel, CLASS, "mat-expanded")) {
                scrollAndClickOnElement(vehicleCoverageExpansionPanel);
                wait.until(PWExpectedConditions.attributeContains(vehicleCoverageExpansionPanel, CLASS, "mat-expanded"));
            }
        }
    }

    public void validateHqmToggleInMyQuotes(String homeQuoteRate, String quoteNumber, FarmersSoftAssert fsa) throws Exception {
        final String myQuotesSubtitle = "My Farmers quotes (#%s)";
        waitAndClickElement(linkSeeAllMyQuotes);
        waitElementBeVisible(myFarmersQuotesTitle);
        fsa.assertEquals(getTextFromElement(myFarmersQuotesTitle), String.format(myQuotesSubtitle, quoteNumber), "Quote Summary page - Quote number.");
        fsa.assertEquals(getTextFromElement(homeRateValue).replaceAll(NON_DIGITS_EXCEPT_PERIOD, EMPTY_STRING), homeQuoteRate.replaceAll(NON_DIGITS_EXCEPT_PERIOD, EMPTY_STRING), "Quote Summary page - Home quote rate value.");
        waitAndClickElement(driver().findElement(PWBy.xpath(String.format(TOGGLE_BACK_CROSS_SELL_LOB_XPATH, HOME))));
    }

    public QuoteSummaryAutoPage validateLiabilityCoverageTableTitle() {
        String liabilityCoverageTableTitleText = "Liability coverage";
        PWElement liabilityCoverageTableTitle = liabilityCoverageSection.findElement(tableTitle);
        Assert.assertTrue(isExpectedTextContainedInElement(liabilityCoverageTableTitle, liabilityCoverageTableTitleText));
        return this;
    }

    public QuoteSummaryAutoPage validatePageSubTitleRegardingCustomizing() {
        String subTitleRegardingCustomizingText = "Important: you can customize your quote below and select the insurance coverages you want.";
        String subTitleRegardingCustomizingTextAlt = "Feel free to customize your quote and select the coverages you want.";
        String subtitle = getTextFromElement(subTitleRegardingCustomizing);
        testStepAssert(subtitle.contains(subTitleRegardingCustomizingTextAlt) || subtitle.contains(subTitleRegardingCustomizingText), "Quote review page subtitle should contain '" + subTitleRegardingCustomizingText + "' or '" + subTitleRegardingCustomizingTextAlt + "'");
        return this;
    }

    public QuoteSummaryAutoPage validatePageTitle() {
        String pageTitleText = "Here is your quote";
        String pageTitleText2 = "Here's your quote";
        String yourQuoteIsReadyText = "Your quote is ready";
        String title = getTextFromElement(pageTitle);
        Assert.assertTrue(title.contains(pageTitleText) || title.contains(yourQuoteIsReadyText) || title.contains(pageTitleText2), "Quote review page title should contain '" + pageTitleText + "' or '" + yourQuoteIsReadyText + "' or '" + pageTitleText2 + "'");
        return this;
    }

    public void verifyBundleAutoReviewQuotePageContent(String propertyBundle, FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(pageTitle), "Auto coverages", "Auto quote review page title verification");
        fsa.assertEquals(getTextFromElement(subTitleRegardingCustomizing), "Important: you can customize your quote below and select the insurance coverages you want.", "Auto quote review page subtitle verification");
        PWElement lookForElement = liabilityCoverageSection.findElement(tableTitle);
        fsa.assertEquals(getTextFromElement(lookForElement), "Liability coverage", "Auto quote review page Liability coverage section title verification");
        lookForElement = liabilityCoverageSection.findElement(PWBy.cssSelector("p"));
        fsa.assertEquals(getTextFromElement(lookForElement), "Coverage limits for your liability for injuries and property damage to others", "Auto quote review page Liability coverage section subtitle verification");
        lookForElement = vehicleCoverageSection.get(0).findElement(tableTitle);
        fsa.assertEquals(getTextFromElement(lookForElement), "Vehicle coverage", "Auto quote review page Vehicle coverage section title verification");
        verifyBundleQuoteLedgerComponent(propertyBundle, AUTO, fsa);
        String expectedContinueButtonText = propertyBundle.equals(HOME) ? "Next: Review home coverages" : "Next: Review renters coverages";
        fsa.assertEquals(getTextFromElement(bundleContinueToPropertyReviewCoveragePageButton), expectedContinueButtonText, expectedContinueButtonText + " button text validation");
    }

    public boolean validateRecalculationOfLiabilityCoveragePriceWithNewSelection() throws Exception {
        expandLiabilityCoverageCardIfPresent();
        String previousPrice = getTextFromElement(liabilityCoverageSection.findElement(totalPrice));
        if (isBristolWestQuote()) {
            updateLiabilityAndCustomizeForBW();
        } else {
            updateLiabilityAndCustomize();
        }
        String postPrice = getTextFromElement(waitElementBeVisible(liabilityCoverageSection.findElement(totalPrice)));
        return !previousPrice.equals(postPrice);
    }

    public boolean validateRecalculationOfVehicleCoveragePriceWithNewSelection() throws Exception {
        waitForSpinnerToBeGone();
        PWElement vehicleTable = vehicleCoverageSection.get(0);
        String previousPrice = getTextFromElement(driver().findElements((totalPrice)).get(1));
        waitAndClickElement(vehicleTable.findElement(editLiabilityCoverageButton));
        selectRandomUncheckedLiabilityCoverageRadioButtons(VehicleCoverage.COMPREHENSIVE.coverage);
        clickRecalculateButton();
        waitForSpinnerToBeGone();
        String newPrice = EMPTY_STRING;
        if (!new KnockoutInconveniencePage().isQuoteKnockedOut()) {
            for (int i = 0; i < 3; i++) {
                try {
                    newPrice = getTextFromElement(driver().findElements((totalPrice)).get(1));
                    break;
                } catch (PWStaleElementReferenceException see) {
                    driver().navigate().refresh();
                }
            }
        }
        return !previousPrice.equals(newPrice);
    }

    public QuoteSummaryAutoPage validateVehicleCoverageTableTitle() {
        String vehicleCoverageTableTitle = "Vehicle coverage";
        PWElement liabilityCoverageTableTitle = vehicleCoverageSection.get(0).findElement(tableTitle);
        Assert.assertTrue(isExpectedTextContainedInElement(liabilityCoverageTableTitle, vehicleCoverageTableTitle));
        return this;
    }

    public void waitForPageTitleAppear() {
        waitElementBeVisible(pageTitle);
    }

    private QuoteSummaryAutoPage clickOnEditVehicleCoverageButton(PWElement table) {
        try {
            waitAndClickElement(table.findElement(editLiabilityCoverageButton));
        } catch (Exception exception) {
            throw new PWNoSuchElementException("Table or editLiabilityCoverageButton does not exist");
        }
        return this;
    }

    private QuoteSummaryAutoPage clickOnEditSingleVehicleCoverageButton() {
        closeQualtricsPopUp();
        waitAndClickElement(btnEditSingleVehicleCoverage);
        return this;
    }

    private void closeLiabilitySideDialog() {
        waitAndClickElement(liabilitySideDialogCloseIcon);
    }

    private void closeVehicleSideDialog() {
        waitAndClickElement(vehicleSideDialogCloseIcon);
    }

    public boolean isQualtricsSurveyPopUpDisplayed() {
        return isQualtricsSurveyFormDisplayed();
    }

    @SneakyThrows
    private boolean isCoverageNamesDisplayedCorrectly(PWElement table, List<String> listOfExpectedCoverageName) {
        waitUntilAngular5Ready();
        List<String> listOfActualCoverageName = table.findElements(tableRow).stream().map(row -> row.findElement(PWBy.cssSelector(":first-child")))
                .map(this::getTextFromElement).collect(Collectors.toList());
        return areTwoListEqual(listOfActualCoverageName, listOfExpectedCoverageName);
    }

    private void validateCoverageSectionContent() throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        String actualSubTitle;

        for (PWElement section : sectionsOnSideDialog) {
            // validate Dialog section title
            String actualTitle = getTextFromElement(section.findElement(sectionTitle));
            String expectedTitle;
            String expectedSubTitle;
            actualSubTitle = getTextFromElement(section.findElement(sectionSubTitle));
            if (getTextFromElement(liabilitySideDialogTitle).contains(LIABILITY_SIDE_SUBTITLE)) {
                LiabilityCoverage liabilityCoverage = EnumSet.allOf(LiabilityCoverage.class).stream().filter(coverage -> actualTitle.startsWith(coverage.coverage)).findFirst().orElseThrow();
                expectedTitle = liabilityCoverage.coverage;
                expectedSubTitle = liabilityCoverage.subTitleOnSideDialog;
                // validate Dialog section radio button options
                List<String> actualRadioButtonOptions = byDefaultSelectedRadioButtons.stream().map(this::getTextFromElement).collect(Collectors.toList());
                clickCloseIcon();
                List<String> expectedRadioButtonOptions = getLiabilityCoverageLimits();
                expectedRadioButtonOptions.removeIf(limit -> limit.equalsIgnoreCase(NOT_COVERED) || limit.equalsIgnoreCase(COVERED) || limit.equalsIgnoreCase(COVERAGE) || limit.equalsIgnoreCase(NO_COVERAGE));
                fsa.assertEquals(actualRadioButtonOptions, expectedRadioButtonOptions, expectedTitle + " Dialog section radio button options verification");
            } else {
                VehicleCoverage vehicleCoverage = EnumSet.allOf(VehicleCoverage.class).stream().filter(coverage -> actualTitle.startsWith(coverage.coverage)).findFirst().orElseThrow();
                expectedTitle = vehicleCoverage.coverage;
                expectedSubTitle = vehicleCoverage.subTitleOnSideDialog;
            }
            fsa.assertTrue(actualTitle.contains(expectedTitle), expectedTitle + " to match " + actualTitle);
            // validate Dialog section subtitle

            fsa.assertTrue(expectedSubTitle.equals(actualSubTitle), expectedSubTitle + " to match " + actualSubTitle);
        }
        fsa.assertAll();
    }

    public void clickGotItButton() {
        if (isElementVisible(gotItButton, 3)) {
            waitAndClickElement(gotItButton);
        }
    }

    public void validateADA_QuoteSummaryAutoPage() {
        if (!isADATestingEnabled()) return;
        isOnQuoteSummaryAutoPage();
        performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
        waitAndClickElement(btnEditLiabilityCoverage);
        waitElementBeVisible(lblEditLiabilityCoverageHeader);
        performADATesting(this.getClass().getSimpleName() + "_LiabilityCoveragesSideSheet", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(closeIcon);
        scrollAndClickOnElement(waitElementBeVisible(btnEditSingleVehicleCoverage));
        waitElementBeVisible(lblEditVehicleCoverageHeader);
        performADATesting(this.getClass().getSimpleName() + "_VehicleCoveragesSideSheet", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(closeIcon);
        scrollAndClickOnElement(reviewDiscountsButton);
        waitElementBeVisible(discountsSidesheetTitle);
        performADATesting(this.getClass().getSimpleName() + "_DiscountsSideSheet", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(closeIcon);
    }

    public void validateDiscountAndCoveragePersistAfterForthBack(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        List<String> liabilityCoveragesBeforeNavigation = liabilityCoverages.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> liabilityLimitsBeforeNavigation = liabilityLimits.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> liabilityPricesBeforeNavigation = liabilityPrices.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> vehicleCoveragesBeforeNavigation = vehicleCoverages.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> vehicleLimitsBeforeNavigation = vehicleLimits.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> vehiclePricesBeforeNavigation = vehiclePrices.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> discountsBeforeNavigation = getDisplayedDiscounts();
        closeQualtricsPopUp();
        new AceAutoNavigationHelper().getAdditionalInfoPolicyStartDateOneUI(true, false, this);
        closeQualtricsPopUp();
        driver().navigate().back();
        fsa.assertTrue(isOnQuoteSummaryAutoPage(), "User reached quote summary page after navigating back from additional info page");
        List<String> liabilityCoveragesAfterNavigation = liabilityCoverages.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> liabilityLimitsAfterNavigation = liabilityLimits.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> liabilityPricesAfterNavigation = liabilityPrices.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> vehicleCoveragesAfterNavigation = vehicleCoverages.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> vehicleLimitsAfterNavigation = vehicleLimits.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> vehiclePricesAfterNavigation = vehiclePrices.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> discountsAfterNavigation = getDisplayedDiscounts();
        fsa.assertEquals(liabilityCoveragesAfterNavigation, liabilityCoveragesBeforeNavigation, "Liability coverages check");
        fsa.assertEquals(liabilityLimitsAfterNavigation, liabilityLimitsBeforeNavigation, "Liability limits check");
        fsa.assertEquals(liabilityPricesAfterNavigation, liabilityPricesBeforeNavigation, "Liability prives check");
        fsa.assertEquals(vehicleCoveragesAfterNavigation, vehicleCoveragesBeforeNavigation, "Vehicle coveraages check");
        fsa.assertEquals(vehicleLimitsAfterNavigation, vehicleLimitsBeforeNavigation, "Vehicle limits check");
        fsa.assertEquals(vehiclePricesAfterNavigation, vehiclePricesBeforeNavigation, "Vehicle prices check");
        fsa.assertEquals(discountsAfterNavigation, discountsBeforeNavigation, "Discounts check");
    }

    public void toggleBackToCrossSell(String crossSellLob) throws Exception {
        waitAndClickElement(linkSeeAllMyQuotes);
        waitElementBeVisible(myFarmersQuotesTitle);
        PWElement toggleElement = driver().findElement(PWBy.xpath(String.format(TOGGLE_BACK_CROSS_SELL_LOB_XPATH, crossSellLob)));
        waitAndClickElement(toggleElement);
        waitForSpinnerToBeGone();
    }

    public String getCrossLobTotalPremiumValue(String lob) throws Exception {
        waitAndClickElement(linkSeeAllMyQuotes);
        waitElementBeVisible(myFarmersQuotesTitle);
        PWElement rateElement = driver().findElement(PWBy.xpath(String.format("//div[@class='static-manage-quotes-text' and contains(.,'%s')]/..//div[@class='rate-value']", lob)));
        String premium = getTextFromElement(rateElement).replace("/year", EMPTY_STRING);
        clickCloseIcon();
        return premium;
    }

    public void updateLiabilityAndCustomize() throws Exception {
        closeQualtricsPopUp();
        clickOnEditLiabilityCoverageButton();
        waitElementBeVisible(liabilitySideDialogCloseIcon);
        String biSelectedValue = updateBodilyInjurySelectionFromSideSheet();
        StringTokenizer pdValueToUse = new StringTokenizer(biSelectedValue);
        updatePropertyDamageSelectionFromSideSheet(pdValueToUse.nextToken("//"));
        matchUMBISelectionToBIValue(biSelectedValue);
        clickRecalculateButton();
        waitForSpinnerToBeGone();
        testStepAssert(isOnQuoteSummaryAutoPage() && !isElementDisplayed(recalculateErrorMessage, 2), "User successfully customized their liability coverage", true);
    }

    public void updateUMUIMCoverageLimitsWithHighestSelectionIfNeeded() {
        if (UMBISideSheetRadioButtons.isEmpty()) {
            return; // return if UMBI is not applicable
        }
        scrollAndClickOnElement(UMBISideSheetRadioButtons.get(UMBISideSheetRadioButtons.size() - 1));
    }

    public void updateLiabilityAndCustomizeForBW() throws Exception {
        closeQualtricsPopUp();
        clickOnEditLiabilityCoverageButton();
        waitElementBeVisible(liabilitySideDialogCloseIcon);
        updateBodilyInjurySelectionFromSideSheetForBW();
        updatePropertyDamageSelectionFromSideSheetForBW();
        closeQualtricsPopUp();
        if (!isElementVisible(recalculateButton, 1)) {
            updateMedicalPaymentsSelectionFromSideSheetForBW();
        }
        clickRecalculateButton();
        waitForSpinnerToBeGone();
        testStepAssert(isOnQuoteSummaryAutoPage() && !isElementDisplayed(recalculateErrorMessage, 2), "User successfully customized their BW liability coverage", true);
    }

    private void updatePropertyDamageSelectionFromSideSheetForBW() {
        PWElement randomUncheckedButton = allPropertyDamageRadioButtonsForBW.get(allPropertyDamageRadioButtonsForBW.size() - 1);
        scrollAndClickOnElement(randomUncheckedButton);
    }

    public void updateVehicleCoverageAndCustomizeForBW() throws Exception {
        clickOnEditVehicleCoverageButton(vehicleCoverageSection.get(0));
        waitElementBeVisible(vehicleSideDialogCloseIcon);
        updateCompSelectionFromSideSheetForBW();
        updateCollSelectionFromSideSheetForBW();
        clickRecalculateButton();
        waitForSpinnerToBeGone();
        testStepAssert(isOnQuoteSummaryAutoPage() && !isElementDisplayed(recalculateErrorMessage, 2), "User successfully customized and got new BW quote after vehicle coverage", true);
    }

    public void updateVehicleCoverageAndCustomize() throws Exception {
        clickOnEditVehicleCoverageButton(vehicleCoverageSection.get(0));
        waitElementBeVisible(vehicleSideDialogCloseIcon);
        updateCompSelectionFromSideSheet();
        updateCollSelectionFromSideSheet();
        clickRecalculateButton();
        waitForSpinnerToBeGone();
        testStepAssert(isOnQuoteSummaryAutoPage() && !isElementDisplayed(recalculateErrorMessage, 2), "User successfully customized and got new quote after vehicle coverage", true);
    }

    private String updateBodilyInjurySelectionFromSideSheet() throws Exception {
        List<PWElement> displayedListOfUncheckedBIRadioButtons = isBristolWestQuote() ? uncheckedBodilyInjuryRadioButtonsForBW : uncheckedBodilyInjuryRadioButtons;
        PWElement highestBi = displayedListOfUncheckedBIRadioButtons.get(displayedListOfUncheckedBIRadioButtons.size() - 1);
        scrollElementToMiddle(highestBi);
        waitAndClickElement(highestBi);
        sleep(1);
        if (!getAttributeData(highestBi, CLASS).contains(RADIO_BUTTON_CHECKED)) {
            Log.info("Bodily injury selection was not successful");
            jsClickElement(highestBi);
        }
        //Now get value to set UMBI
        String biSelectedValue = getTextFromElement(highestBi);
        matchUMBISelectionToBIValue(biSelectedValue);
        return biSelectedValue;
    }

    private void updateBodilyInjurySelectionFromSideSheet(String bodilyInjuryLimitValue) throws Exception {
        closeQualtricsPopUp();
        PWElement biLimitRadioButtonToSelect = driver().findElement(PWBy.xpath(String.format(BI_RADIO_BUTTON_SIDE_SHEET_GROUP_XPATH + "//mat-radio-button[contains(.,'%s')]", bodilyInjuryLimitValue)));
        scrollElementToMiddle(biLimitRadioButtonToSelect);
        clickElement(biLimitRadioButtonToSelect);
        sleep(1);
        if (!getAttributeData(biLimitRadioButtonToSelect, CLASS).contains(RADIO_BUTTON_CHECKED)) {
            waitAndClickElement(biLimitRadioButtonToSelect);
        }
        closeQualtricsPopUp();
        matchUMBISelectionToBIValue(bodilyInjuryLimitValue);
    }

    private void matchUMBISelectionToBIValue(String bodilyInjuryLimitValue) throws Exception {
        //to avoid rule check update the UMBI to match BI value
        if (!isElementVisible(UMBISideSheetToggle, 2) && UMBISideSheetRadioButtons.isEmpty()) {
            return;
        }
        if (!getAttributeData(UMBISideSheetToggle, CLASS).contains(SLIDE_TOGGLE_CHECKED)) {
            waitAndClickElement(UMBISideSheetToggle);
        }
        PWElement selectedUMBIRadioButton = driver().findElement(PWBy.xpath(String.format(UMUIM_SIDE_RADIO_BUTTONS_SHEET_XPATH + "[contains(.,'%s')]", bodilyInjuryLimitValue)));
        scrollElementToMiddle(selectedUMBIRadioButton);
        waitAndClickElement(selectedUMBIRadioButton);
        sleep(1);
        if (!getAttributeData(selectedUMBIRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED)) {
            clickElement(selectedUMBIRadioButton);
        }
        if (getSessionStorageAppStore().getData().getLandingStateCode().equals(IN)) {
            PWElement underInsuredElement = driver().findElement(PWBy.xpath("//mat-radio-group[@id='Liability__13101__radio']//mat-radio-button[contains(.,'$50,000/$50,000')]"));
            scrollElementToMiddle(underInsuredElement);
            waitAndClickElement(underInsuredElement);
            sleep(1);
            if (!getAttributeData(underInsuredElement, CLASS).contains(RADIO_BUTTON_CHECKED)) {
                clickElement(underInsuredElement);
            }
        }
    }

    private void updatePropertyDamageSelectionFromSideSheet(String pdLimit) throws Exception {
        List<PWElement> desiredRadioButtons = driver().findElements(PWBy.xpath(String.format("//mat-radio-group[@id='Liability__PD__radio' or @id='Liability__13024__radio']//mat-radio-button[contains(.,'%s')]", pdLimit)));
        PWElement selectedBiLimitRadioButton;
        if(desiredRadioButtons.isEmpty()) {
            // get the last index of the radio buttons if the desired limit is not found, to avoid NoSuchElementException
            List<PWElement> availableRadioButtons = driver().findElements(PWBy.xpath("//mat-radio-group[@id='Liability__PD__radio' or @id='Liability__13024__radio']//mat-radio-button"));
            selectedBiLimitRadioButton = availableRadioButtons.get(availableRadioButtons.size() - 1);
        } else {
            selectedBiLimitRadioButton = desiredRadioButtons.get(0);
        }
        scrollElementToMiddle(selectedBiLimitRadioButton);
        waitAndClickElement(selectedBiLimitRadioButton);
        if (!getAttributeData(selectedBiLimitRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED)) {
            Log.warn("Selecting property damage for " + pdLimit + " was not successful. Trying again");
            scrollElementToMiddle(selectedBiLimitRadioButton);
            jsClickElement(selectedBiLimitRadioButton);
        }
    }

    private void updateUMPDSelectionFromSideSheet(String umpdLimit) throws Exception {

        if (!umpdToggle.getAttribute(CLASS).contains(CHECKED)) {
            scrollElementToMiddle(umpdToggle);
            waitAndClickElement(umpdToggle);
            sleep(1);
        }

        PWElement selectedUmpdRadioButton = driver().findElement(PWBy.xpath(String.format("//mat-radio-group[@id='Liability__UMPD__radio']//mat-radio-button[contains(.,'%s')]", umpdLimit)));
        scrollElementToMiddle(selectedUmpdRadioButton);
        waitAndClickElement(selectedUmpdRadioButton);
        if (!getAttributeData(selectedUmpdRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED)) {
            Log.warn("Selecting UMPD with " + umpdLimit + " limit was not successful. Trying again");
            scrollElementToMiddle(selectedUmpdRadioButton);
            jsClickElement(selectedUmpdRadioButton);
        } else {
            Log.info("Selecting UMPD with " + umpdLimit + " limit was successful.");
        }
    }

    private String updateBodilyInjurySelectionFromSideSheetForBW() {
        if (uncheckedBodilyInjuryRadioButtonsForBW.isEmpty()) {
            waitAndClickElement(liabilityToggle);
            sleep(1);
        }
        PWElement highestBiLimit = allBodilyInjuryRadioButtons.get(allBodilyInjuryRadioButtons.size() - 1);
        waitAndClickElement(highestBiLimit);
        return getTextFromElement(highestBiLimit);
    }

    private void updateMedicalPaymentsSelectionFromSideSheetForBW() {
        if (!isElementVisible(medicalPaymentToggle, 1)) {
            Log.info("Medical payment toggle is not visible, likely due to it not being applicable for this quote, skipping medical payment selection");
            return;
        }
        if (isElementVisible(medicalPaymentToggle, 1) && !getAttributeData(medicalPaymentToggle, CLASS).contains(MAT_TOGGLE_CHECKED)) {
            waitAndClickElement(medicalPaymentToggle);
        }
        PWElement randomUncheckedButton = allMedicalPaymentsRadioButtonsForBW.get(randomNumberGenerator.nextInt(allMedicalPaymentsRadioButtonsForBW.size()));
        waitAndClickElement(randomUncheckedButton);
    }

    private void updateCompSelectionFromSideSheet() throws Exception {
        if (!getAttributeData(comprehensiveToggle, CLASS).contains(MDC_SWITCH_SELECTED)) {
            waitAndClickElement(comprehensiveToggle);
            sleep(1);
        }
        wait.until(PWExpectedConditions.numberOfElementsToBeMoreThan(PWBy.xpath("//mat-radio-group[@id='Vehicle__21000__radio']//mat-radio-button[not(contains(@class,'checked'))]"), 1));
        PWElement randomUncheckedButton = uncheckedCompRadioButtons.get(randomNumberGenerator.nextInt(uncheckedCompRadioButtons.size()));
        if (!getAttributeData(randomUncheckedButton, CLASS).contains(RADIO_BUTTON_CHECKED)) {
            waitAndClickElement(randomUncheckedButton);
        }
    }

    private void updateCompSelectionFromSideSheetForBW() {
        List<String> compRadioButtons = allComprehensiveRadioButtons_BW.stream().map(this::getTextFromElement).collect(Collectors.toList());
        if (!compRadioButtons.contains(NO_COVERAGE) && !isButtonSelected(waitElementBeVisible(comprehensiveToggleForBW))) {
            waitAndClickElement(comprehensiveToggleForBW);
            sleep(1);
        }
        wait.until(PWExpectedConditions.numberOfElementsToBeMoreThan(PWBy.xpath(COMP_UNCHECKED_RADIO_BUTTONS_BW), 1));
        PWElement randomUncheckedButton = uncheckedCompRadioButtonsForBW.get(randomNumberGenerator.nextInt(uncheckedCompRadioButtonsForBW.size()));
        scrollAndClickOnElement(randomUncheckedButton);
    }

    public void updateUIM_PD_FromSideSheet() throws Exception {
        clickOnEditVehicleCoverageButton(vehicleCoverageSection.get(0));
        waitElementBeVisible(vehicleSideDialogCloseIcon);
        //uncheck Collision coverage to add UIMPD coverage
        while (getAttributeData(collToggle_BW, CLASS).contains(MAT_TOGGLE_CHECKED)) {
            waitAndClickElement(collToggle_BW);
            sleep(1);
        }
        while (!getAttributeData(uimPD_collisonToggle_BW, CLASS).contains(MAT_TOGGLE_CHECKED)) {
            waitAndClickElement(uimPD_collisonToggle_BW);
            sleep(1);
        }
        clickRecalculateButton();
        waitForSpinnerToBeGone();
        testStepAssert(isOnQuoteSummaryAutoPage(), "User successfully customized and got new quote after vehicle coverage", true);
    }

    private void updateCollSelectionFromSideSheet() {
        if (!getAttributeData(collToggle, CLASS).contains(MDC_SWITCH_SELECTED)) {
            waitAndClickElement(collToggle);
            sleep(1);
        }
        wait.until(PWExpectedConditions.numberOfElementsToBeMoreThan(PWBy.xpath("//mat-radio-group[@id='Vehicle__22000__radio' or @id='Vehicle__22031__radio' or @id='Vehicle__COL__radio']//mat-radio-button[not(contains(@class,'checked'))]"),1));
        PWElement randomUncheckedButton = uncheckedCollRadioButtons.get(randomNumberGenerator.nextInt(uncheckedCollRadioButtons.size()));
        if (!getAttributeData(randomUncheckedButton, CLASS).contains(RADIO_BUTTON_CHECKED)) {
            scrollAndClickOnElement(randomUncheckedButton);
        }
    }

    private void updateCollSelectionFromSideSheetForBW() {
        List<String> collRadioButtons = allRadioCollisionRadioButtons_BW.stream().map(this::getTextFromElement).collect(Collectors.toList());
        if (!collRadioButtons.contains(NO_COVERAGE) || !getAttributeData(collToggle_BW, CLASS).contains(MAT_TOGGLE_CHECKED)) {
            scrollElementToMiddle(collToggle_BW);
            int retry = 3;
            while (!getAttributeData(collToggle_BW, CLASS).contains(MAT_TOGGLE_CHECKED) && retry > 0) {
                scrollElementToMiddle(collToggle_BW);
                waitAndClickElement(collToggle_BW);
                sleep(1);
                retry--;
            }
        }
        wait.until(PWExpectedConditions.numberOfElementsToBeMoreThan(PWBy.xpath(COLL_UNCHECKED_RADIO_BUTTONS_BW), 1));
        PWElement randomUncheckedButton = uncheckedCollRadioButtonsForBW.get(randomNumberGenerator.nextInt(uncheckedCollRadioButtonsForBW.size()));
        scrollAndClickOnElement(randomUncheckedButton);
        if (!getAttributeData(randomUncheckedButton, CLASS).contains(RADIO_BUTTON_CHECKED)) {
            scrollAndClickOnElement(randomUncheckedButton);
        }
    }

    public void validateBlankFieldsForMediaAlpha(AutoApplicant applicant, FarmersSoftAssert softAssert) throws Exception {
        if (isOnQuoteSummaryAutoPage()) {
            // clear email field and validate error message
            clearOutFieldUsingBackSpace(emailInputFieldMediaAlpha);
            sleep(1);
            clickAgreeAndSubmitButton();
            sleep(1);
            softAssert.assertFalse(driver().findElements(PWBy.xpath("//*[contains(.,'Please enter your email address')]")).isEmpty(), "User should get error message for not filling contact info - email");
            sendKeysToElement(emailInputFieldMediaAlpha, applicant.getEmail());

            // clear phone field and validate error message
            clearOutFieldUsingBackSpace(phoneInputFieldMediaAlpha);
            sleep(1);
            clickAgreeAndSubmitButton();
            sleep(1);
            softAssert.assertFalse(driver().findElements(PWBy.xpath("//*[contains(.,'Please enter your phone number')]")).isEmpty(), "User should get error message for not filling contact info - phone");
            sendKeysToElement(phoneInputFieldMediaAlpha, applicant.getPhoneNumber());

        } else {
            Log.warn("RC1 was not successful");

        }
    }

    public void verifyCoveragesDisplayedAlphaMedia(FarmersSoftAssert softAssert) throws Exception {
        String presentedPremiumAmount = getPresentedPremiumAmount();
        Log.info("Presented premium amount: " + presentedPremiumAmount);
        softAssert.assertFalse(Double.parseDouble(presentedPremiumAmount.replaceAll("\\D", EMPTY_STRING)) == 0.00, "Proper premium amount is present");
    }

    public void validateComboCoverage(FarmersSoftAssert fsa) throws Exception {
        List<String> comboCoverageToolTipEligibleStates = new ArrayList<>(Arrays.asList(AR, CO, ID, IL, MI, ND, NE, NM, OK, OR, PA, SD, TN, TX, WI, WY));

        // validate tooltip
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        boolean isDiscountExpected = false;
        clickOnEditSingleVehicleCoverageButton();
        if (comboCoverageToolTipEligibleStates.contains(landingStateCode)) {
            fsa.assertEquals(getTextFromElement(comboCoverageTooltipHeader), "We offer discounts for combining coverage!", "Tooltip header text validated");
            fsa.assertEquals(getTextFromElement(comboCoverageTooltipContent), "You may be eligible for an additional discount when you select 3 or more additional coverages.", "Tooltip content text validated");
            fsa.assertTrue(isElementVisible(comboCoverageTooltipLightBulb, 1), "Light bulb for combo coverage is visible");
        } else {
            fsa.assertFalse(isElementVisible(comboCoverageTooltipContent, 1), "Combo coverage tooltip content should not be visible for the given state: " + landingStateCode);
            fsa.assertFalse(isElementVisible(comboCoverageTooltipHeader, 1), "Combo coverage tooltip header should not be visible for the given state: " + landingStateCode);
            fsa.assertFalse(isElementVisible(comboCoverageTooltipLightBulb, 1), "Combo coverage tooltip lightbulb should not be visible for the given state: " + landingStateCode);
        }

        closeQualtricsPopUp();
        // turn on comp and coll
        if (!getAttributeData(comprehensiveToggle, ARIA_CHECKED).equals(LOWERCASE_TRUE)) {
            waitAndClickElement(comprehensiveToggle);
            // selecting max comp
            waitAndClickElement(uncheckedCompRadioButtons.get(uncheckedCompRadioButtons.size() - 1));
            sleep(1);
        }
        if (!getAttributeData(collToggle, ARIA_CHECKED).equals(LOWERCASE_TRUE)) {
            waitAndClickElement(collToggle);
            // selecting max coll
            waitAndClickElement(uncheckedCollRadioButtons.get(uncheckedCollRadioButtons.size() - 1));
            sleep(1);
        }
        List<String> availableAdditionalCoverages = additionalCoverageToggles.stream().map(this::getTextFromElement).collect(Collectors.toList());
        closeQualtricsPopUp();

        Log.info("Available additional coverages are: " + availableAdditionalCoverages);
        availableAdditionalCoverages.remove("Rental Alternative");
        availableAdditionalCoverages.remove("Uninsured Motorist Property Damage without Collision");
        availableAdditionalCoverages.remove("Limited Collision (Part 8)");
        availableAdditionalCoverages.remove("UM Property damage - without collision");
        availableAdditionalCoverages.remove("Uninsured Motorist Property Damage");

        List<PWElement> additionalCoverageToggles = new ArrayList<>();
        for (String availableAdditionalCoverage : availableAdditionalCoverages) {
            List<PWElement> elements = driver().findElements(PWBy.xpath(String.format(ADDITIONAL_COVERAGE_TOGGLE_XPATH + "[contains(.,'%s')]//button", availableAdditionalCoverage)));
            if (!elements.isEmpty()) {
                additionalCoverageToggles.add(elements.get(0));
            }
        }
        closeQualtricsPopUp();
        for (PWElement additionalCoverageToggle : additionalCoverageToggles) {
            if (isButtonNotSelected(additionalCoverageToggle)) {
                scrollAndClickOnElement(additionalCoverageToggle);
                sleep(1);
                if (isButtonNotSelected(additionalCoverageToggle)) {
                    scrollElementToMiddle(additionalCoverageToggle);
                    jsClickElement(additionalCoverageToggle);
                }
            }
        }

        clickRecalculateButton();
        waitForSpinnerToBeGone();
        isOnQuoteSummaryAutoPage();

        List<String> statesEligibleForComboCoverage = new ArrayList<>(Arrays.asList(AR, CO, ID, IL, MI, ND, NE, NM, GA, OK, OR, PA, SD, TN, TX, WI, WY, AZ, VA, MO, AL, CT, UT));
        isDiscountExpected = statesEligibleForComboCoverage.contains(landingStateCode);
        fsa.assertTrue(isDiscountExpected == isDiscountPresentInTheSideSheet("Coverage Combo"), "Coverage Combo discount should " + (isDiscountExpected ? "" : NOT) + " be present in the sidesheet on " + this.getClass().getSimpleName());

        navigateFromQuoteSummaryPageToPaymentPage(false);

        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();

        fsa.assertTrue(consolidatedPaymentPage.isOnContinueToPaymentPage(), "User is on the " + consolidatedPaymentPage.getClass().getSimpleName());
        List<String> consolidatedPaymentPageDiscountNames = consolidatedPaymentPage.getDiscountNames();
        Log.info("consolidatedPaymentPageDiscountNames : " + consolidatedPaymentPageDiscountNames);
        fsa.assertTrue(isDiscountExpected == consolidatedPaymentPageDiscountNames.contains("Coverage Combo"), "Coverage combo disocunt should " + (isDiscountExpected ? "" : NOT) + " be present on " + consolidatedPaymentPage.getClass().getSimpleName());
    }

    public List<String> getAllDisplayedCoverages() {
        return allDisplayedCoverages.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public List<String> getAllDisplayedLimits() {
        return allDisplayedLimits.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public List<String> getAllDisplayedPrices() {
        return allDisplayedPrices.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public void validateCustomizedCompAndCollCoveragesAreRetainedAfterRetrieval(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        farmersSoftAssert.assertTrue(isOnQuoteSummaryAutoPage(), "User is on Quote summary page");
        closeQualtricsPopUp();
        updateVehicleCoverageAndCustomize();
        String comprehensiveCoverageLabel = COMPREHENSIVE.getCoverageOrLiabilityText();
        String collisionCoverageLabel = COLLISION.getCoverageOrLiabilityText();
        String compCoverageBeforeRetrieval = getTextFromElement(driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, comprehensiveCoverageLabel))));
        String collCoverageBeforeRetrieval = getTextFromElement(driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, collisionCoverageLabel))));
        String quoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
        new LandingPage(isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, quoteNumber);
        farmersSoftAssert.assertTrue(isOnQuoteSummaryAutoPage(), "User is on Quote summary page after quote after retrieval");
        String compCoverageAfterRetrieval = getTextFromElement(driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, comprehensiveCoverageLabel))));
        String collCoverageAfterRetrieval = getTextFromElement(driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, collisionCoverageLabel))));
        farmersSoftAssert.assertEquals(compCoverageAfterRetrieval, compCoverageBeforeRetrieval, "Customized comprehensive coverage should be retained after quote retrieval. Value before retrieval: " + compCoverageBeforeRetrieval + ", value after retrieval: " + compCoverageAfterRetrieval);
        farmersSoftAssert.assertEquals(collCoverageAfterRetrieval, collCoverageBeforeRetrieval, "Customized collision coverage should be retained after quote retrieval. Value before retrieval: " + collCoverageBeforeRetrieval + ", value after retrieval: " + collCoverageAfterRetrieval);
        farmersSoftAssert.assertAll();
    }

    public void validateADPFOrderedFlagInQuoteXML(FarmersSoftAssert fsa) throws Exception {
        String quoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
        RateQuoteServiceInitiated rateQuoteServiceInitiated = new ApiHelper().getRateQuoteServiceInitiated(quoteNumber);
        List<RateQuoteServiceInitiated.GWRateRequest.CalculateQuotePremium.ReportsToOrder> reportsToOrder = getReportsToOrder(rateQuoteServiceInitiated);

        fsa.assertTrue(reportsToOrder.stream().anyMatch(report -> "ADPF".equals(report.getReportName()) && report.isOrderIndicator()),
                "ADPF report should be ordered in the rate request when ADPF is ordered for the quote");
   }

    public void validateADPFNotOrderedFlagInQuoteXML(FarmersSoftAssert fsa) throws Exception {
        String quoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
        RateQuoteServiceInitiated rateQuoteServiceInitiated = new ApiHelper().getRateQuoteServiceInitiated(quoteNumber);
        List<RateQuoteServiceInitiated.GWRateRequest.CalculateQuotePremium.ReportsToOrder> reportsToOrder = getReportsToOrder(rateQuoteServiceInitiated);

        fsa.assertTrue(reportsToOrder.stream().noneMatch(report -> "ADPF".equals(report.getReportName()) && report.isOrderIndicator()),
                "ADPF report should not be ordered in the rate request when ADPF is not ordered for the quote");
    }

    private List<RateQuoteServiceInitiated.GWRateRequest.CalculateQuotePremium.ReportsToOrder> getReportsToOrder(RateQuoteServiceInitiated rateQuoteServiceInitiated) {
        if (rateQuoteServiceInitiated == null) {
            return Collections.emptyList();
        }
        if (rateQuoteServiceInitiated.getCalculateQuotePremium() != null && rateQuoteServiceInitiated.getCalculateQuotePremium().getReportsToOrder() != null) {
            return rateQuoteServiceInitiated.getCalculateQuotePremium().getReportsToOrder();
        }
        if (rateQuoteServiceInitiated.getGwRateRequest() != null
                && rateQuoteServiceInitiated.getGwRateRequest().getCalculateQuotePremium() != null
                && rateQuoteServiceInitiated.getGwRateRequest().getCalculateQuotePremium().getReportsToOrder() != null) {
            return rateQuoteServiceInitiated.getGwRateRequest().getCalculateQuotePremium().getReportsToOrder();
        }
        return Collections.emptyList();
    }


    // TODO: refactor to use excel sheet provided coverages instead of below enum
    @AllArgsConstructor
    public enum LiabilityCoverage {

        BODILY_INJURY("Bodily Injury", "Covers the medical bills for which you are responsible in a collision. Select coverage per person / per accident.",
                List.of("$25,000/$50,000", "$50,000/$100,000", "$100,000/$300,000", "$250,000/$500,000", "$500,000/$500,000")),
        BODILY_INJURY_REQUIRED("Bodily Injury (required)", "Covers the medical bills for which you are responsible in a collision. Select coverage per person / per accident.",
                List.of("$25,000/$50,000", "$50,000/$100,000", "$100,000/$300,000", "$250,000/$500,000", "$500,000/$500,000")),
        PROPERTY_DAMAGE_LIABILITY("Property Damage Liability", "Covers the property damage you cause — to a vehicle, structure, bicycle, or other property. Select coverage per accident.",
                List.of("$25,000", "$50,000", "$100,000", "$250,000", "$500,000")),
        PROPERTY_DAMAGE_LIABILITY_REQUIRED("Property Damage Liability (required)", "Covers the medical bills for which you are responsible in a collision. Select coverage per person / per accident.Covers the property damage you cause — to a vehicle, structure, bicycle, or other property. Select coverage per accident.",
                List.of("$25,000", "$50,000", "$100,000", "$250,000", "$500,000")),
        MEDICAL_COVERAGE("Medical Coverage", "Helps with the cost of medical care for you and your passengers resulting from injuries in an accident, regardless of who is at fault.",
                List.of("$5,000", "$10,000", "$25,000", "$50,000")),
        UM_UIM_BODILY_INJURY("UM/UIM Bodily injury", "This option covers injuries to the insured or their passengers if the other party is at fault and is uninsured, \n" +
                "    unidentified (e.g. hit-and-run) or has an insufficient amount of insurance.",
                List.of("$25,000/$50,000", "$50,000/$100,000", "$100,000/$300,000", "$250,000/$500,000", "$500,000/$500,000")),
        UNINSURED_MOTORIST_SLASH_UNDER_INSURED_MOTORIST_BI("Uninsured Motorist/Under Insured Motorist Bodily Injury", "This option covers injuries to the insured or their passengers if the other party is at fault and is uninsured, \n" +
                "    unidentified (e.g. hit-and-run) or has an insufficient amount of insurance.",
                List.of("$25,000/$50,000", "$50,000/$100,000", "$100,000/$300,000", "$250,000/$500,000", "$500,000/$500,000")),
        UNINSURED_MOTORIST_SLASH_UNDER_INSURED_MOTORIST_BI_CONVERSION("Uninsured Motorist/Under Insured Motorist Bodily Injury Conversion", "This option is similar to the standard “UM/UIM Bodily injury” coverage. However, payments made with Underinsured Conversion Coverage are not reduced by payment from any source. If the insured's damages exceed the amount of the negligent party's insurance, your Underinsured Motorists Conversion Coverage will be available for damages not paid, up to the limit you select.Covers the medical bills for which you are responsible in a collision. Select coverage per person / per accident.\n",
                List.of("$25,000/$50,000", "$50,000/$100,000", "$100,000/$300,000", "$250,000/$500,000", "$500,000/$500,000")),
        ACCIDENT_DEATH_OR_DISABILITY_INJURY("Accidental Death or Disabling Injury", "This provides a specific amount of coverage in the event of death or specified disability of the named insured, family members, or listed drivers due to a covered accident.",
                List.of("$25,000/$50,000", "$50,000/$100,000", "$100,000/$300,000", "$250,000/$500,000", "$500,000/$500,000"));

        private final String coverage;
        private final String subTitleOnSideDialog;
        public final List<String> radioButtons;
    }

    @AllArgsConstructor
    public enum VehicleCoverage {
        COMPREHENSIVE("Comprehensive", "Covers things occurring outside of the driver's control, including theft, vandalism, natural disasters,\n" +
                "    and animal-related incidents. You’re responsible for the deductible amount. The higher your deductible\n" +
                "    the lower your cost of coverage."),
        COLLISION("Collision", "Covers your car if it collides with another vehicle or fixed object like a tree. You’re responsible for\n" +
                "    the deductible amount. The higher your deductible the lower your cost of coverage."),
        HUNDRED_DOLLAR_GLASS_COVERAGE("$100 Glass Coverage", "Waives the comprehensive deductible for a loss to your insured vehicle’s glass."),
        VEHICLE_REPLACEMENT_PLUS("Vehicle Replacement Plus", "Covers replacement with a vehicle one model year newer with 20,000 less miles. For financed vehicles, it will cover the difference between a total loss settlement and the remaining loan amount."),
        RENTAL("Rental", "Covers the cost of a renting a car for up to 30 days while your vehicle is repaired. Select from max $40, $60 or $100 reimbursement per day."),
        ROADSIDE_ASSISTANCE("Roadside Assistance", " Provides 24/7 roadside assistance if your car is disabled. Helps pay for towing, tire changing,\n" +
                "    locksmith service and jumpstarts. Select from regular or enhanced option that includes more towing miles\n" +
                "    and battery service. "),
        RIDESHARE_FOOD_DELIVERY("Rideshare and Food Delivery", "Extends limited coverage while you’re engaged in rideshare/food delivery activities.");


        private final String coverage;
        private final String subTitleOnSideDialog;
    }

    public void validatePremiumAccuracyInQuoteSummaryAutoPage() throws Exception {
        String premiumAmount = getPresentedPremiumAmount();
        boolean pifPresentedOnly = !premiumAmount.contains("/mo");
        premiumAmount = premiumAmount.replace("$", EMPTY_STRING);
        premiumAmount = premiumAmount.replace("/mo", EMPTY_STRING);
        premiumAmount = premiumAmount.replace(",", EMPTY_STRING);
        premiumAmount = premiumAmount.split("\\.")[0];
        int highestAmount = pifPresentedOnly ? 2000 : 500;
        testStepAssert(Integer.parseInt(premiumAmount) > 0 && Integer.parseInt(premiumAmount) < highestAmount, "Validate premium accuracy.Expected:premium should be within range of less than $200 for pni,1 vehicle and default coverage.Actual:premum amount is ( $" + premiumAmount + " )");
    }

    public boolean isOnLiabilityCoverageFrameOfQuoteSummaryAutoPage() {
        return isElementVisible(lblEditLiabilityCoverageHeader, 10);
    }

    public boolean isOnVehicleCoverageFrameOfQuoteSummaryAutoPage() {
        return isElementVisible(lblEditVehicleCoverageHeader, 10);
    }

    public String getMembershipFeeIfPresent() throws Exception {
        if (isElementDisplayed(PWBy.xpath(MEMBERSHIP_PRICE_XPATH))) {
            return getTextFromElement(membershipFeePrice.get(0));
        } else {
            return ZERO;
        }
    }

    public PWElement getStartCheckoutElement() {
        return isUseMobileViewEnabled() ? mobileStartCheckoutButtonExpended : startCheckoutButton;
    }

    public String getStartCheckoutButtonText() throws Exception {
        if (isUseMobileViewEnabled()) {
            clickOnExpandIconForMobileQuoteCardIfNotExpanded();
        }
        return getTextFromElement(getStartCheckoutElement());
    }

    private boolean isMobileCardViewExpanded() throws Exception {
        return getAttributeData(driver().findElements(PWBy.xpath("//tui-quote-presentment//mat-card[contains(@class,'mobile')]")).get(0), CLASS).contains("expanded");
    }

    public List<String> getDescriptionOfDisplayedVehicles() throws Exception {
        return driver().findElements(PWBy.xpath("//div[@class='row auto-quote-coverages-section']//h3")).stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public void clickRecalculateButton() throws Exception {
        closeQualtricsPopUp();
        waitAndClickElement(recalculateButton);
        waitForSpinnerToBeGone();
        if (isElementVisible(recalculateButton, 2)) {
            clickElement(recalculateButton);
        }
    }

    public void clickResetChangesButton() throws Exception {
        if (isElementPresent(PWBy.xpath("//div[contains(@class,'auto-quote-liability__button-section')]//a"), 2)) {
            closeQualtricsPopUp();
            scrollElementToMiddle(resetChangesButton);
            waitAndClickElement(resetChangesButton);
            sleep(1);
            clickElement(resetChangesButton);
        }
    }

    public void closeAdjustmentDialogIfPresent() {
        if (isElementVisible(adjustmentDialogCloseButton, 1)) {
            waitAndClickElement(adjustmentDialogCloseButton);
        }
    }

    public void clickNextToReviewPropertyCoveragePage() {
        scrollToBottomOfPage();
        scrollAndClickOnElement(bundleContinueToPropertyReviewCoveragePageButton);
        waitForSpinnerToBeGone();
    }

    public void validateRideShareCoverage_CA_State(FarmersSoftAssert fsa, boolean randomRideShare) throws Exception {
        String rideshareCoverageXpath;
        if (isUseMobileViewEnabled()) {
            rideshareCoverageXpath = "//div[contains(@class,'row auto-quote-liability-coverages-item-row auto-quote-coverages-mobile') and contains(.,'Rideshare')]";
        } else {
            rideshareCoverageXpath = "//div[contains(@class,'row auto-quote-liability-coverages-item') and not(contains(@class,'mobile')) and contains(.,'Rideshare')]";
        }
        String coverage = isUseMobileViewEnabled() ? "//span" : "//div[1]";
        String limit = isUseMobileViewEnabled() ? "//div[1]" : "//div[2]";
        String price = isUseMobileViewEnabled() ? "//div[2]" : "//div[3]";

        if (randomRideShare) {
            //default is coverage for rideshare
            PWElement coverageElement = driver().findElement(PWBy.xpath(rideshareCoverageXpath + coverage));
            scrollElementToMiddle(coverageElement);
            fsa.assertEquals(getTextFromElement(coverageElement), "Rideshare", "Rideshare coverage should be displayed");
            fsa.assertEquals(getTextFromElement(driver().findElement(PWBy.xpath(rideshareCoverageXpath + limit))).replace("Rideshare", EMPTY_STRING), "Covered", "Ridesahre should be covered");
            fsa.assertFalse(getTextFromElement(driver().findElement(PWBy.xpath(rideshareCoverageXpath + price))).equals("--"), "Coverage amount should be valid amount");

            //update and uncheck the coverage and validate
            clickOnEditSingleVehicleCoverageButton();
            clickElement(driver().findElement(PWBy.xpath("//mat-slide-toggle[contains(.,'Rideshare')]")));
            clickRecalculateButton();
            waitForSpinnerToBeGone();
            sleep(1);

            //updated is not covered for rideshare
            fsa.assertEquals(getTextFromElement(coverageElement), "Rideshare");
            fsa.assertEquals(getTextFromElement(driver().findElement(PWBy.xpath(rideshareCoverageXpath + limit))).replace("Rideshare", EMPTY_STRING), "Not covered");
            fsa.assertTrue(getTextFromElement(driver().findElement(PWBy.xpath(rideshareCoverageXpath + price))).equals("--"), "Coverage amount should be empty");

        } else {
            fsa.assertFalse(isElementDisplayed(PWBy.xpath(rideshareCoverageXpath)), "Rideshare element should not be displayed at all when there is no ride share");
        }
    }

    public boolean notAbleToOfferBundle() {
        return isElementPresent(PWBy.xpath("//div[contains(@class,'limited-message-card')]"), 3);
    }

    public void validateBDQSpecificRequirements(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        fsa.assertTrue(isDiscountSectionDisplayed(), "Discount section should be displayed on the quote summary page");
        validateValidateAndFooterForBDQ(fsa, applicant, this);
        validateAgentSectionBDQ(fsa, applicant);
    }

    public void validatePriceTooHighSection(FarmersSoftAssert fsa) throws Exception {
        closeQualtricsPopUp();
        if (!isElementDisplayed(PWBy.xpath("//p[contains(@class,'price-to-high-text')]"))) {
            testStep("Price too high section is not present, finishing test");
            return;
        }
        int index = isUseMobileViewEnabled() ? 0 : 1;
        String expectedTitle = "Price too high?";
        String expectedDescription = String.format("Give us a quick call to find out about%sother options", isSafariBrowser() ? EMPTY_STRING : SPACE);
        //String expectedPhoneNumber = "1-844-797-6823";
        fsa.assertEquals(getTextFromElement(priceTooHighTitles.get(index)), expectedTitle);
        fsa.assertEquals(getTextFromElement(priceTooHighDescriptions.get(index)), expectedDescription);
        fsa.assertFalse(StringUtils.isEmpty(getTextFromElement(priceTooHighPhoneNumbers.get(0))), "Phone number should not be empty");
    }

    public void validateUMBILimitDontExceedBiLimitFarmers(FarmersSoftAssert fsa) throws Exception {
        closeQualtricsPopUp();
        clickOnEditLiabilityCoverageButton();
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        List<String> listOfStatesUM_UIM_Separated = Arrays.asList(PA, MA);
        if (listOfStatesUM_UIM_Separated.contains(landingStateCode)) {
            if (!getAttributeData(unInsuredMotoristToggle, CLASS).contains(SLIDE_TOGGLE_CHECKED)) {
                waitAndClickElement(unInsuredMotoristToggle);
            }
            if (!landingStateCode.equals(MA) && !getAttributeData(underInsuredMotoristToggle, CLASS).contains(SLIDE_TOGGLE_CHECKED)) {
                waitAndClickElement(underInsuredMotoristToggle);
            }
        } else {
            if (!getAttributeData(UMBISideSheetToggle, CLASS).contains(SLIDE_TOGGLE_CHECKED)) {
                waitAndClickElement(UMBISideSheetToggle);
            }
        }
        List<PWElement> bilimits = landingStateCode.equals(MA) ? allBodilyInjuryPart5RadioButtons : allBodilyInjuryRadioButtons;
        int numberOfElements = bilimits.size();
        for (int i = 0; i < numberOfElements; i++) {
            PWElement biLimit = bilimits.get(i);
            scrollAndClickOnElement(biLimit);
            scrollElementToMiddle(biLimit);
            if (listOfStatesUM_UIM_Separated.contains(landingStateCode)) {
                if (i == numberOfElements - 1) {
                    break;
                }
                if (landingStateCode.equals(PA)) {
                    wait.until(PWExpectedConditions.visibilityOfAllElements(unInsuredMotoristRadioButtons));
                    PWElement unInsuredLimit=unInsuredMotoristRadioButtons.get(i+1);
                    scrollElementToTop(unInsuredLimit);
                    waitAndClickElement(unInsuredLimit);
                    scrollElementToTop(waitElementBeVisible(unInsuredMotoristErrorMessage));
                    fsa.assertTrue(isElementInRedColor(unInsuredMotoristErrorMessage),"UM or UIM Error message is not red color when selected higher than bi limit");
                }
                wait.until(PWExpectedConditions.visibilityOfAllElements(underInsuredMotoristRadioButtons));
                PWElement underInsuredLimit=underInsuredMotoristRadioButtons.get(i+1);
                scrollElementToTop(underInsuredLimit);
                waitAndClickElement(underInsuredLimit);
                scrollElementToTop(waitElementBeVisible(underInsuredMotoristErrorMessage));
                fsa.assertTrue(isElementInRedColor(underInsuredMotoristErrorMessage),"UM or UIM Error message is not red color when selected higher than bi limit");
            } else {
                PWElement errorMessageElement = Arrays.asList(CA, CT, OK, TN, MD, AL, OR, MN, VA, WA).contains(landingStateCode) ? UMBI_rule_error_message : UMBI_rule_message;
                if (i == numberOfElements - 1) {
                    break; // breaking to avoid IndexOutOfBoundsException
                }
                PWElement umbiLimit = UMBISideSheetRadioButtons.get(i + 1);
                scrollElementToTop(umbiLimit);
                waitAndClickElement(umbiLimit);
                scrollElementToTop(waitElementBeVisible(errorMessageElement));
                fsa.assertTrue(isElementInRedColor(errorMessageElement), "Umbi Note message is not red color when umbi selected higher than bi limit");
            }

            closeQualtricsPopUp();
            waitAndClickElement(recalculateButton);
            scrollElementToMiddle(recalculateErrorMessage);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(recalculateErrorMessage)), "One or more required fields is incomplete or incorrect. Please review.");
            fsa.assertTrue(isElementInRedColor(recalculateErrorMessage), "Recalculate error message is red color");
        }
        clickResetChangesButton();
    }

    //Validate UMBI limit cannot be higher than the BI limit on quote review screen.
    public void validateUMBILimitDontExceedBiLimitBW(FarmersSoftAssert fsa) throws Exception {
    	closeQualtricsPopUp();
    	clickOnEditLiabilityCoverageButton();

    	if (!getAttributeData(UMBISideSheetToggle, CLASS).contains(SLIDE_TOGGLE_CHECKED)) {
    		waitAndClickElement(UMBISideSheetToggle);
    	}
    	List<PWElement> bilimits = allBodilyInjuryRadioButtons;
    	int numberOfElements = bilimits.size();
    	for (int i = 0; i < numberOfElements-1; i++) {
    		PWElement biLimit = bilimits.get(i);
    		scrollAndClickOnElement(biLimit);
    		scrollElementToMiddle(biLimit);
    		PWElement umbiLimit = UMBISideSheetRadioButtons.get(i + 1);
    		scrollElementToTop(umbiLimit);
    		waitAndClickElement(umbiLimit);
    		PWElement errorMessage = UMBI_rule_error_message;
    		scrollElementToTop(waitElementBeVisible(errorMessage));
    		fsa.assertTrue(isElementInRedColor(errorMessage), "UMBI error message should be red when UMBI > BI");
    		fsa.assertEquals(getTextFromElement(errorMessage), "This coverage limit cannot be higher than your \"Bodily injury\" coverage limit.", "Error message should indicate UMBI cannot exceed BI");
    		// Try recalculate and validate error
    		closeQualtricsPopUp();
    		waitAndClickElement(recalculateButton);
    		scrollElementToMiddle(recalculateErrorMessage);
    		fsa.assertEquals(getTextFromElement(waitElementBeVisible(recalculateErrorMessage)), "One or more required fields is incomplete or incorrect. Please review.", "Recalculate error message should indicate required fields issue");
    		fsa.assertTrue(isElementInRedColor(recalculateErrorMessage), "Recalculate error message is red color");
    	}
    	clickResetChangesButton();
    }

    //Validate UMBI limit cannot be higher than the BI limit on quote review screen.
    public void validateUserCanSelectLowerBILimit(FarmersSoftAssert fsa) throws Exception {
        List<String> biLimits = List.of("$100,000/$300,000", "$50,000/$100,000"); // descending order
        for (String lowerBi : biLimits) {
            clickOnEditLiabilityCoverageButton();
            updateBodilyInjurySelectionFromSideSheet(lowerBi);
            matchUMBISelectionToBIValue(lowerBi);
            closeQualtricsPopUp();
            scrollElementToMiddle(recalculateButton);
            waitAndClickElement(recalculateButton);

            // Assert no error message is displayed after lowering BI limit
            fsa.assertFalse(isElementDisplayed(recalculateErrorMessage, 2), "No error should be shown when lowering BI limit to " + lowerBi);
        }
    }

    public void validateCompIsRequiredWithLimitedColl(FarmersSoftAssert fsa) throws Exception {
        clickOnEditVehicleCoverageButton(vehicleCoverageSection.get(0));
        if (isButtonSelected(comprehensiveToggleForBW)) {
            // disable comp
            scrollAndClickOnElement(comprehensiveToggleForBW);
        }
        if (isButtonNotSelected(limitedCollisionToggle)) {
        	scrollAndClickOnElement(limitedCollisionToggle);
        }
        fsa.assertTrue(isElementVisible(limitedCollisionErrorMessage, 1), "Limited collision error message should be visible when limited collision is selected without comprehensive");
        fsa.assertTrue(isElementInRedColor(limitedCollisionErrorMessage), "Limited collision error message should be in red color");
        fsa.assertTrue(getTextFromElement(limitedCollisionErrorMessage).contains("This coverage requires you to also select \"Comprehensive\" coverage."), "Limited collision error message should indicate comprehensive is required");
    }


    public void clickOnQuoteUpdateDialogOkIfNeeded() {
        if (isElementVisible(quoteUpdateDialogCtaButton, 2)) {
            clickElement(quoteUpdateDialogCtaButton);
        }
    }

    public String getMonthlyAutoPayPriceFromBundleQuoteLedger() {
        return getTextFromElement(monthlyAutoPayPriceInBundleQuoteLedger.get(1));
    }

    public String getPayInFullPriceFromBundleQuoteLedger() {
        return getTextFromElement(payInFullPriceInBundleQuoteLedger.get(1));
    }

    public List<String> getAvailablePdOptionsFromSideSheet() {
        isOnQuoteSummaryAutoPage();
        clickOnEditLiabilityCoverageButton();
        sleep(1);
        List<String> displayedPdOptions = allPropertyDamageRadioButtons.stream().map(each -> getTextFromElement(each)).collect(Collectors.toList());
        return displayedPdOptions;
    }

    public void verifyAutoEditLiabilityCoverageInBundleFlow(FarmersSoftAssert fsa) throws Exception {
        String previousMonthlyAutoPayPrice = getMonthlyAutoPayPriceFromBundleQuoteLedger();
        String previousPayInFullPrice = getPayInFullPriceFromBundleQuoteLedger();

        fsa.assertTrue(validateRecalculationOfLiabilityCoveragePriceWithNewSelection(), "Recalculate liability coverage price");

        String currentMonthlyAutoPayPrice = getMonthlyAutoPayPriceFromBundleQuoteLedger();
        String currentPayInFullPrice = getPayInFullPriceFromBundleQuoteLedger();

        fsa.assertTrue(!previousMonthlyAutoPayPrice.equals(currentMonthlyAutoPayPrice), "Monthly auto pay price change validation while editing the liability coverage");
        fsa.assertTrue(!previousPayInFullPrice.equals(currentPayInFullPrice), "Pay in full price change validation while editing the vehicle liability coverage");
    }

    public void verifyAutoEditVehicleCoverageInBundleFlow(FarmersSoftAssert fsa) throws Exception {
        String previousMonthlyAutoPayPrice = getMonthlyAutoPayPriceFromBundleQuoteLedger();
        String previousPayInFullPrice = getPayInFullPriceFromBundleQuoteLedger();

        fsa.assertTrue(validateRecalculationOfVehicleCoveragePriceWithNewSelection(), "Recalculate vehicle coverage price");

        String currentMonthlyAutoPayPrice = getMonthlyAutoPayPriceFromBundleQuoteLedger();
        String currentPayInFullPrice = getPayInFullPriceFromBundleQuoteLedger();

        fsa.assertTrue(!previousMonthlyAutoPayPrice.equals(currentMonthlyAutoPayPrice), "Monthly auto pay price change validation while editing the vehicle liability coverage");
        fsa.assertTrue(!previousPayInFullPrice.equals(currentPayInFullPrice), "Pay in full price change validation while editing the vehicle liability coverage");
    }

    public void validateWAState_Bi_PD_Combinations_Restriction(FarmersSoftAssert fsa) throws Exception {
        List<LimitPair> limits = new ArrayList<>();
        limits.add(new LimitPair("$25,000/$50,000", "$10,000"));
        limits.add(new LimitPair("$25,000/$50,000", "$25,000"));
        limits.add(new LimitPair("$25,000/$50,000", "$50,000"));
        limits.add(new LimitPair("$50,000/$100,000", "$25,000"));
        limits.add(new LimitPair("$50,000/$100,000", "$50,000"));
        limits.add(new LimitPair("$50,000/$100,000", "$100,000"));
        limits.add(new LimitPair("$100,000/$300,000", "$50,000"));
        limits.add(new LimitPair("$100,000/$300,000", "$100,000"));
        limits.add(new LimitPair("$250,000/$500,000", "$100,000"));
        for (LimitPair limit : limits) {
            clickOnEditLiabilityCoverageButton();
            String biLimit = limit.biLimit;
            updateBodilyInjurySelectionFromSideSheet(biLimit);
            String pdLimit = limit.pdLimit;
            updatePropertyDamageSelectionFromSideSheet(pdLimit);
            Log.info(String.format("Updating the limits on the side sheet: BI: %s, and PD: %s", biLimit, pdLimit));
            clickRecalculateButton();
            waitForSpinnerToBeGone();
            sleep(2);
            Log.info(String.format("Checking limits on page: BI: %s, and PD: %s", biLimit, pdLimit));

            checkCoverage(fsa, true, AceAutoCoveragesAndLiabilites.BODILY_INJURY.getCoverageOrLiabilityText(), biLimit, "WA - BI/PD combination BI check");
            checkCoverage(fsa, true, AceAutoCoveragesAndLiabilites.PROPERTY_DAMAGE.getCoverageOrLiabilityText(), pdLimit, "WA - BI/PD combination PD check");
        }
    }

    public void validatePIPHandling_MA_State(FarmersSoftAssert fsa, boolean isBwest) throws Exception {
        fsa.assertTrue(isOnQuoteSummaryAutoPage() && isBwest ? isOnBristolWest() : isOnFarmers(), String.format("User should be on %s quote summary page after quote creation", isBwest ? "Bristol West" : "Farmers"));

        closeQualtricsPopUp();
        String defaultExpectedCoverageLimitForPIP = "$8,000 limit / $0 deductible";

        String premiumBeforePipChange = getPresentedPremiumAmount().replaceAll(NON_DIGITS_EXCEPT_PERIOD, EMPTY_STRING);
        //Regression Scenario : #481: Validate pip coverage must be by default selected as no
        String coverageOrLiabilityText = PERSONAL_INJURY_PROTECTION_PART2_LOWER_CASE.getCoverageOrLiabilityText();
        PWElement coverageToCheckValue = driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, coverageOrLiabilityText)));
        scrollElementToMiddle(coverageToCheckValue);
        checkCoverage(fsa, true, coverageOrLiabilityText, defaultExpectedCoverageLimitForPIP, "Regression Scenario : #481: Validate pip coverage must be by default seleceted as no");

        clickOnEditLiabilityCoverageButton();
        closeQualtricsPopUp();
        scrollToElement(pipDeductibleNoButton.get(0));
        fsa.assertTrue(isButtonSelected(pipDeductibleNoButton.get(0)), "Regression Scenario : #481: Validate pip coverage must be by default seleceted as no");
        // validate labels and texts
        String yes = "Yes";
        String no = "No";
        String expectedCoverageCardLabel = "Personal injury protection (Part 2)";
        String expectedCoverageCardDescription = "Personal injury protection provides benefits, regardless of fault, for bodily injuries sustained in a covered accident. These benefits include reasonable medical expenses, lost wages, and the cost of replacement services. Coverage varies by state and is subject to conditions and limitations.";
        String pb3QuestionText = "Normally, you're covered for up to $8,000 per person with no deductible. You can lower your price by adding a deductible. Would you like the named insureds to have a deductible?";
        String zeroDeductibleApplies = "$0 deductible applies";
        String houseHoldQuestion = "Do you want a deductible to apply for everyone in your household (in addition to the named insureds), to further lower your price?";
        String pipDeductibleRadioButtonOptionsQuestion = "Please select your per-person deductible.";

        fsa.assertEquals(getTextFromElement(pipSideSheetCoverageLabel), expectedCoverageCardLabel, "Pip coverage label");
        fsa.assertEquals(getTextFromElement(pipSideSheetCoverageDescription), expectedCoverageCardDescription, "Pip coverage description");
        fsa.assertEquals(getTextFromElement(pipDeductibleYesButton.get(0)), yes, "Yes toggle button text validation");
        fsa.assertEquals(getTextFromElement(pipDeductibleNoButton.get(0)), no, "No toggle button text validation");
        fsa.assertEquals(getTextFromElement(pb3Question.get(0)), pb3QuestionText, "Question for yes and no buttons / toggle for pip");
        fsa.assertEquals(getTextFromElement(zeroDeductibleAppliesElement), zeroDeductibleApplies, "Zero deductible applies label validation");
        closeQualtricsPopUp();

        // select yes for deductibles (Would you like the named insured to have a deductible?)
        waitAndClickElement(pipDeductibleYesButton.get(0));
        fsa.assertEquals(getTextFromElement(pb3Question.get(1)), houseHoldQuestion, "Do you want to apply deductible to household question label validation");

        // Scenario 482#: Validate pip coverage select yes and we will get would you like to apply deductible question and by default that must be no
        fsa.assertTrue(isButtonSelected(pipDeductibleNoButton.get(1)), "Validate pip coverage select yes and we will get would you like to apply dedeuctible question and by default that must be no");
        fsa.assertEquals(getTextFromElement(pipDeductibleYesButton.get(1)), yes, "Yes toggle button text validation - deductible");
        fsa.assertEquals(getTextFromElement(pipDeductibleNoButton.get(1)), no, "No toggle button text validation- deductible");
        fsa.assertEquals(getTextFromElement(pipDeductibleButtonsHeader), pipDeductibleRadioButtonOptionsQuestion, "Pip radio buttons header label validation");

        //Validate pip coverage select yes and we will get would you like to apply deductible questiochange it to yes and by default it must be 100

        fsa.assertEquals(getTextFromElement(pipCheckedRadioButton), "$100", "Validate pip coverage select yes and we will get would you like to apply dedeuctible questiochange it to yes and by default it must be 100");

        // select yes for deductibles (Do you want a deductible to apply for everyone in your household (in addition to the named insureds), to further lower your price?)
        waitAndClickElement(pipDeductibleYesButton.get(1));
        fsa.assertTrue(isButtonSelected(pipDeductibleYesButton.get(1)), "HH Deductible question should be yes selected");

        // validate selecting No for deductible in PIP, does not show radio buttons
        waitAndClickElement(pipDeductibleNoButton.get(0));
        fsa.assertTrue(pipRadioButtons.isEmpty(), "validate selecting No for deductible in PIP, does not show radio buttons");

        //select yes again
        waitAndClickElement(pipDeductibleYesButton.get(0));
        waitAndClickElement(pipDeductibleYesButton.get(1));
        sleep(1);
        waitAndClickElement(pipRadioButtons.get(randomNumberGenerator.nextInt(pipRadioButtons.size())));
        sleep(1);
        String checkedRadioButtonLabel = getTextFromElement(driver().findElement(PWBy.xpath(CHECKED_PIP_RADIO_BUTTON + "//label")));
        Log.info("CheckedRadio button label: " + checkedRadioButtonLabel);
        clickRecalculateButton();
        waitForSpinnerToBeGone();
        String premiumAfterPipChange = getPresentedPremiumAmount().replaceAll(NON_DIGITS_EXCEPT_PERIOD, EMPTY_STRING);
        fsa.assertTrue(Double.parseDouble(premiumAfterPipChange) < Double.parseDouble(premiumBeforePipChange), "Premium with pip deductible selection should be less than default zero decutible");

        String updatedCoverage = String.format("$8,000 limit / %s deductible", checkedRadioButtonLabel);
        checkCoverage(fsa, true, coverageOrLiabilityText, updatedCoverage, "pip coverage limit should be updated on page when updated from side sheet");
    }

    public void validatePDDoesNotOffer15KWithRideshare(FarmersSoftAssert fsa) {
        isOnQuoteSummaryAutoPage();
        clickOnEditLiabilityCoverageButton();
        sleep(1);
        List<String> displayedPdOptions = allPropertyDamageRadioButtons.stream().map(each -> getTextFromElement(each)).collect(Collectors.toList());
        testStep("Validate that FFQ (CA) - Auto - Not to offer the $15K for PD coverage option if  Rideshare coverage is selected");
        fsa.assertFalse(displayedPdOptions.contains("$15,000"), "15k PD option should not be displayed");
    }

    public void validateStartWithNoRideShareAndAdd(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        isOnQuoteSummaryAutoPage();
        closeQualtricsPopUp();

        clickOnEditLiabilityCoverageButton();
        closeQualtricsPopUp();
        updateBodilyInjurySelectionFromSideSheet("$25,000/$50,000");
        updatePropertyDamageSelectionFromSideSheet("$25,000");
        clickRecalculateButton();
        waitForSpinnerToBeGone();
        sleep(1);
        checkCoverage(fsa, true, AceAutoCoveragesAndLiabilites.BODILY_INJURY.getCoverageOrLiabilityText(), "$25,000/$50,000", "Customized to 25/50 without rideshare - BI");
        checkCoverage(fsa, true, AceAutoCoveragesAndLiabilites.PROPERTY_DAMAGE.getCoverageOrLiabilityText(), "$25,000", "Customized to 25/50 without rideshare - PD");

        // go back and update the vehicle details with rideshare
        clickEnterInfoNavigationBarStepper();
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        if (nameAndDobPage.isOnNameAndDobPage()) {
            nameAndDobPage.clickContinueButton();
            AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
            autoEnterAddressPage.isOnEnterAddressPage();
            autoEnterAddressPage.clickAddressPageCtaButton();
        }
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on " + whoShouldWeInsurePage.getClass().getSimpleName());

        if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            String vehicleDescription = vehiclesDriversInfoPage.getVehicleDescriptionFromVehicle(applicant.getVehicles().get(0));
            String xpathForEditVehicleIcon = vehiclesDriversInfoPage.getEditVehicleButtonXpath(vehicleDescription);
            PWElement vehicleEditButton = driver().findElement(PWBy.xpath(xpathForEditVehicleIcon));
            waitAndClickElement(vehicleEditButton);
            vehiclesDriversInfoPage.clickRideShareCheckbox();
            vehiclesDriversInfoPage.clickVehicleSaveChangesButton();
            vehiclesDriversInfoPage.clickContinueButton();
        } else {
            whoShouldWeInsurePage.clickContinueButton();
            VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
            testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on " + vehicleReviewPage.getClass().getSimpleName());

            // add rideshare
            vehicleReviewPage.setVehicleUsage(applicant, "Rideshare", 0);
            vehicleReviewPage.clickContinueButton();
            DriverReviewPage driverReviewPage = new DriverReviewPage();
            driverReviewPage.clickContinueButton();
        }

        SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
        signalPageOneUI.processSignalPage(true);
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.clickContactInfoPageCTAButton();
        testStepAssert(isOnQuoteSummaryAutoPage(), "User is on " + this.getClass().getSimpleName() + " page after adding rideshare to the quote");


        String biAfterRideshareAdded = getTextFromElement(driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, AceAutoCoveragesAndLiabilites.BODILY_INJURY.getCoverageOrLiabilityText()))));
        String pdAfterRideshareAdded = getTextFromElement(driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, AceAutoCoveragesAndLiabilites.PROPERTY_DAMAGE.getCoverageOrLiabilityText()))));

        fsa.assertTrue(Double.parseDouble(biAfterRideshareAdded.replaceAll("\\D", EMPTY_STRING)) >= 50000, "Bi should be at least 50 with rideshare");
        fsa.assertTrue(Double.parseDouble(pdAfterRideshareAdded.replaceAll("\\D", EMPTY_STRING)) >= 50000, "PD should be at least 50 with rideshare");
    }

    public void validateRideShareMinLiabilityLimits(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String minBiLimit = "0";
        String stateCode = applicant.getStateCode();

        //bi limits per states
        List<String> biLimits50_100States = Arrays.asList(AL, AR, CO, GA, ID, IL, IN, IA, KS, KY, LA, ME, MD, MA, MN, MS, MO, MT, NV, NJ, NM, ND, OH, OK, OR, PA, SD, TN, UT, WA, WI, WY);
        List<String> biLimits10_20States = Arrays.asList(FL);

        if (biLimits50_100States.contains(stateCode)) {
            minBiLimit = "$50,000/$100,000";
        }

        if (biLimits10_20States.contains(stateCode)) {
            minBiLimit = "$10,000/$20,000";
        }

        //PD limits per states
        List<String> pdLimits10States = Arrays.asList(FL);
        List<String> pdLimits25States = Arrays.asList(AL, AR, ID, IA, IL, KS, KY, LA, ME, MD, MS, MO, MT, NV, NJ, NM, ND, OH, OK, OR, PA, SD, TN, WA, WI, WY);
        List<String> pdLimits30States = Arrays.asList(MA);
        List<String> pdLimits50States = Arrays.asList(CO, GA, IN, MN, UT);

        String minPdLimit = "0";
        if (pdLimits10States.contains(stateCode)) {
            minPdLimit = "$10,000";
        }
        if (pdLimits25States.contains(stateCode)) {
            minPdLimit = "$25,000";
        }
        if (pdLimits30States.contains(stateCode)) {
            minPdLimit = "$30,000";
        }
        if (pdLimits50States.contains(stateCode)) {
            minPdLimit = "$50,000";
        }


        // MA state has UMBI limit as well: 25,000/50,000
        //MI	No Surcharge is being applied

        liabilityAndVehicleCoverageExpandIfExist();

        String biCoverage = AceAutoCoveragesAndLiabilites.BODILY_INJURY.getCoverageOrLiabilityText();

        if (Arrays.asList(MA).contains(stateCode)) {
            biCoverage = OPTIONAL_BODILY_INJURY.getCoverageOrLiabilityText();
        }

        if (Arrays.asList(AZ, IL).contains(stateCode)) {
            biCoverage = AceAutoCoveragesAndLiabilites.BODILY_INJURY_LIABILITY.getCoverageOrLiabilityText();
        }

        String pdCoverage = AceAutoCoveragesAndLiabilites.PROPERTY_DAMAGE.getCoverageOrLiabilityText();

        if (Arrays.asList(AZ, IA, IL, ND, WI, NE, NM, OR, TN).contains(stateCode)) {
            pdCoverage = AceAutoCoveragesAndLiabilites.PROPERTY_DAMAGE_LIABILITY.getCoverageOrLiabilityText();
        }
        if (Arrays.asList(MA).contains(stateCode)) {
            pdCoverage = AceAutoCoveragesAndLiabilites.PROPERTY_DAMAGE_PART4.getCoverageOrLiabilityText();
        }

        String coverageToCheckValueBi = getTextFromElement(driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, biCoverage))));

        fsa.assertTrue(Double.parseDouble(coverageToCheckValueBi.replaceAll("\\D", EMPTY_STRING)) >= Double.parseDouble(minBiLimit.replaceAll("\\D", EMPTY_STRING)), "Default coverage limit for bi");

        String coverageToCheckValuePd = getTextFromElement(driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, pdCoverage))));

        fsa.assertTrue(Double.parseDouble(coverageToCheckValuePd.replaceAll("\\D", EMPTY_STRING)) >= Double.parseDouble(minPdLimit.replaceAll("\\D", EMPTY_STRING)), "Default coverage limit for PD");


        clickOnEditLiabilityCoverageButton();
        sleep(1);

        int numberOfElements = getAllBodilyInjuryRadioButtons().size();
        for (int i = 0; i < numberOfElements; i++) {
            PWElement bodilyInjuryButton = allBodilyInjuryRadioButtons.get(i);
            boolean isErrorExpected = false;
            String textFromElement = getTextFromElement(bodilyInjuryButton);
            if (Double.parseDouble(textFromElement.replaceAll("\\D", EMPTY_STRING)) < Double.parseDouble(minBiLimit.replaceAll("\\D", EMPTY_STRING))) {
                isErrorExpected = true;
            }

            updateBodilyInjurySelectionFromSideSheet(textFromElement);
            if (isErrorExpected) {
                //Error is expected
                String errorMessage = String.format("Bodily injury limit must be %s or higher when policy includes ride sharing", minBiLimit);
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(bodilyInjuryErrorMessage, 1)), errorMessage, "Error message should show for selecting less than min expected for rideshare");
            } else {
                fsa.assertFalse(isElementVisible(bodilyInjuryErrorMessage, 1), "Error message should not be visible with state min bi or higher: bi limit being tested " + textFromElement);
            }
        }

        numberOfElements = allPropertyDamageRadioButtons.size();
        for (int i = 0; i < numberOfElements; i++) {
            PWElement pdRadioButton = allPropertyDamageRadioButtons.get(i);
            boolean isErrorExpected = false;
            String textFromElement = getTextFromElement(pdRadioButton);
            if (Double.parseDouble(textFromElement.replaceAll("\\D", EMPTY_STRING)) < Double.parseDouble(minPdLimit.replaceAll("\\D", EMPTY_STRING))) {
                isErrorExpected = true;
            }
            updatePropertyDamageSelectionFromSideSheet(textFromElement);
            if (isErrorExpected) {
                //Error is expected
                String errorMessage = String.format("PD limit must be %s or higher when policy includes ride sharing", minPdLimit);
                if (Arrays.asList(CO, GA, IA, ID, IL, IN, MN, NM, NV, OR, OH, UT, WA, WI, WY).contains(stateCode)) {
                    errorMessage = String.format("Property Damage must be %s or higher when policy includes ride sharing", minPdLimit);
                }
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(propertyDamageErrorMessage, 1)), errorMessage, "Error message should show for selecting less than min expected for rideshare");
            } else {
                fsa.assertFalse(isElementVisible(propertyDamageErrorMessage, 1), "Error message shoudl not be visible with state min PD or higher: pd limit being tested " + textFromElement);
            }
        }
    }

    public void validateColAndCompMandatoryWithLeaseOrFinanceVeh(FarmersSoftAssert fsa) throws Exception {
        //validate coll and comp are not 'Not covered'
        PWElement collValue = driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, COLLISION.getCoverageOrLiabilityText())));
        PWElement compValue = driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, COMPREHENSIVE.getCoverageOrLiabilityText())));

        fsa.assertFalse(getTextFromElement(collValue).equals(NOT_COVERED), "Coll should not be 'Not covered'");
        fsa.assertFalse(getTextFromElement(compValue).equals(NOT_COVERED), "Comp should not be 'Not covered'");

        scrollElementToMiddle(vehicleCoverageSection.get(0));
        clickOnEditVehicleCoverageButton(vehicleCoverageSection.get(0));
        // turn off the toggle for comp
        waitAndClickElement(comprehensiveToggle);
        sleep(1);
        if (getAttributeData(comprehensiveToggle, CLASS).contains(SLIDE_TOGGLE_CHECKED)) {
            jsClickElement(comprehensiveToggle);
            sleep(1);
        }

        // validate error message for comp
        String xpathForErrorMessage = "//coverage-input-card[contains(.,'%s')]//mat-error";

        //NOTE: error message may be diff for different states
        String expectedErrorMessage = "Both comprehensive and collision coverages are required for leased and financed vehicles";

        PWElement errorMessageForCompElement = driver().findElement(PWBy.xpath(String.format(xpathForErrorMessage, COMPREHENSIVE.getCoverageOrLiabilityText())));
        fsa.assertEquals(getTextFromElement(errorMessageForCompElement), expectedErrorMessage, "Error message validated for comp with leased or finance vehicle");

        // turn off the toggle for comp
        waitAndClickElement(collToggle);
        sleep(1);
        if (getAttributeData(collToggle, CLASS).equals(SLIDE_TOGGLE_CHECKED)) {
            jsClickElement(collToggle);
        }

        // validate error message for coll
        PWElement errorMessageForCollElement = driver().findElement(PWBy.xpath(String.format(xpathForErrorMessage, COLLISION.getCoverageOrLiabilityText())));
        fsa.assertEquals(getTextFromElement(errorMessageForCollElement), expectedErrorMessage, "Error message validated for coll with leased or finance vehicle");
    }

    public double validateEachVehicleTotalPrice(FarmersSoftAssert fsa) throws Exception {
        String breakPointAdjuster = isUseMobileViewEnabled() ? "row auto-quote-liability-coverages-item-row auto-quote-coverages-mobile d-flex d-md-none ng-star-inserted" : "row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted";
        List<PWElement> prices = driver().findElements(PWBy.xpath(String.format("//app-coverage[@class='ng-star-inserted'][%s]//div[contains(@class,'%s')]//div[contains(@class,'price')]", "1", breakPointAdjuster)));
        List<String> displayedPrices = prices.stream().map(this::getTextFromElement).collect(Collectors.toList());
        double vehicleSectionTotalPrice;
        displayedPrices.removeIf(each -> each.equals("--"));

        vehicleSectionTotalPrice = displayedPrices.stream().mapToDouble(each -> Double.parseDouble(each.replace("$", EMPTY_STRING))).sum();

        // Format to two decimal places

        DecimalFormat df = new DecimalFormat("0.00");
        String formattedTotalPrice = "$" + df.format(vehicleSectionTotalPrice);

        String mobileAdjuster = isUseMobileViewEnabled() ? "//div[contains(@class,'tui-quote-presentment-expanded')]" : "//div[contains(@class,'auto-quote-presentment-card')]";
        if (isUseMobileViewEnabled()) {
            clickOnExpandIconForMobileQuoteCardIfNotExpanded();
        }
        PWElement sideSheetVehicleTotal = driver().findElement(PWBy.xpath(String.format("%s//tr[not(contains(.,'Liability')) and not(contains(.,'Price'))][%s]//td[contains(@class,'price')]", mobileAdjuster, "1")));


        String sideSheetVehicleTotalPrice = getTextFromElement(sideSheetVehicleTotal);
        Log.info("Vehicle section total price: " + formattedTotalPrice);
        Log.info("Vehicle quote card total price: " + sideSheetVehicleTotalPrice);
        fsa.assertEquals(sideSheetVehicleTotalPrice, formattedTotalPrice);

        return vehicleSectionTotalPrice;
    }

    public double validateLiabilityTotalPrice(FarmersSoftAssert fsa) throws Exception {
        String mobileAdjuster = isUseMobileViewEnabled() ? "//div[contains(@class,'row auto-quote-liability-coverages-item-row auto-quote-coverages-mobile d-flex d-md-none ng-star-inserted')]" : "//div[contains(@class,'row auto-quote-liability-coverages-item-row d-none d-md-flex ng-star-inserted')]";

        List<PWElement> prices = driver().findElements(PWBy.xpath(String.format("//app-coverage[contains(.,'Liability')]%s//div[contains(@class,'price') and not(contains(@class,'bold'))]", mobileAdjuster)));
        List<String> displayedPrices = prices.stream().map(this::getTextFromElement).collect(Collectors.toList());
        double liabilityTotalPrice;
        displayedPrices.removeIf(each -> each.equals("--"));
        liabilityTotalPrice = displayedPrices.stream().mapToDouble(each -> Double.parseDouble(each.replace("$", EMPTY_STRING))).sum();

        // Format to two decimal places

        DecimalFormat df = new DecimalFormat("0.00");
        String formattedTotalPrice = "$" + df.format(liabilityTotalPrice);

        if (isUseMobileViewEnabled()) {
            clickOnExpandIconForMobileQuoteCardIfNotExpanded();
        }
        List<PWElement> sideSheetLibTotal = driver().findElements(PWBy.xpath(String.format("//tr[contains(.,'Liability') and not(contains(.,'Price'))]//td[contains(@class,'price')]")));
        String sideSheetVehicleTotalPrice = getTextFromElement(sideSheetLibTotal.get(0));
        Log.info("Liability section total price: " + formattedTotalPrice);
        Log.info("Liability quote card total price: " + sideSheetVehicleTotalPrice);
        double actual = Double.parseDouble(sideSheetVehicleTotalPrice.replace("$", ""));
        double expected = Double.parseDouble(formattedTotalPrice.replace("$", ""));
        fsa.assertTrue(Math.abs(actual - expected) <= 0.1, "Price difference is greater than 1 cent. Actual: " + actual + ", Expected: " + expected);
        return liabilityTotalPrice;
    }

    public void validateSidePanelsClosedWithEscapeKey(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        applicant.setOccupation("Accountant");
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        whoShouldWeInsurePage.clickOnAddVehiclesAndDriversButton();
        PWActions actions = new PWActions(driver());

        // Simulate pressing the Escape key
        actions.sendKeys(PWKeys.ESCAPE).perform();
        sleep(1);
        fsa.assertFalse(whoShouldWeInsurePage.isVehicleAdditionSideSheetVisible(), "Vehicle addition side sheet should close with ESC key action");

        whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);

        if (whoShouldWeInsurePage.isDriverSideDialogOpen()) {
            // Simulate pressing the Escape key
            actions.sendKeys(PWKeys.ESCAPE).perform();
            sleep(1);
        }
        fsa.assertFalse(whoShouldWeInsurePage.isDriverSideDialogOpen(), "Driver addition side sheet should close with ESC key action");
        AppStore.Data.CustomerData customerData = whoShouldWeInsurePage.getSessionStorageAppStore().getData().getCustomerData();
        whoShouldWeInsurePage.clickEditButtonWithDriverFullName(customerData.getFirstName() + SPACE + customerData.getLastName());
        whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);

        whoShouldWeInsurePage.clickContinueButton();


        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on the Veh review page");
        vehicleReviewPage.clickEditBtn_VehicleReviewPage("0");
        // Simulate pressing the Escape key
        actions.sendKeys(PWKeys.ESCAPE).perform();
        sleep(1);
        fsa.assertFalse(vehicleReviewPage.isVehicleEditSideSheetOpen(), "Vehicle edit side sheet should close with ESC key action");

        vehicleReviewPage.addVehicleDetails(applicant);
        if (!applicant.getStateCode().equals(MN)) {
            vehicleReviewPage.clickReviewDiscountButton();
            fsa.assertTrue(vehicleReviewPage.isDiscountSideSheetOpen(), "Vehicle Review page discount side sheet should be open");
            // Simulate pressing the Escape key
            actions.sendKeys(PWKeys.ESCAPE).perform();
            sleep(1);
            fsa.assertFalse(vehicleReviewPage.isDiscountSideSheetOpen(), "Vehicle Review page discount  side sheet should close with ESC key action");
        }

        vehicleReviewPage.clickOnContinueButton();

        DriverReviewPage driverReviewPage = new DriverReviewPage();

        testStepAssert(driverReviewPage.isOnDriverReviewPage(), "User is on the driver review page");

        driverReviewPage.clickEditDriverButton(driverReviewPage.getApplicantFullName(applicant));

        fsa.assertTrue(driverReviewPage.isEditDriverSideSheetOpen(), "Edit driver side sheet open");

        // Simulate pressing the Escape key
        actions.sendKeys(PWKeys.ESCAPE).perform();
        sleep(1);
        fsa.assertFalse(driverReviewPage.isEditDriverSideSheetOpen(), "Edit driver side sheet close");

        if (!isEmploymentDisabledState(applicant.getStateCode())) {
            driverReviewPage.clickOccupationLink();
            fsa.assertTrue(driverReviewPage.isOccupationSideSheetOpen(), "Occupation side sheet open");

            // Simulate pressing the Escape key
            actions.sendKeys(PWKeys.ESCAPE).perform();
            sleep(1);
            fsa.assertFalse(driverReviewPage.isOccupationSideSheetOpen(), "Occupation side sheet close with ESC key");
        }

        driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
        driverReviewPage.clickOnSaveQuoteButton();
        fsa.assertTrue(driverReviewPage.isSaveQuoteSideSheetOpen(), "Save quote side sheet open");
        // Simulate pressing the Escape key
        actions.sendKeys(PWKeys.ESCAPE).perform();
        sleep(1);
        fsa.assertFalse(driverReviewPage.isSaveQuoteSideSheetOpen(), "Save quote side sheet close with ESC key");
        driverReviewPage.clickReviewDiscountButton();
        fsa.assertTrue(driverReviewPage.isDiscountSideSheetOpen(), "Driver Review page discount side sheet should be open");
        // Simulate pressing the Escape key
        actions.sendKeys(PWKeys.ESCAPE).perform();
        sleep(1);
        fsa.assertFalse(driverReviewPage.isDiscountSideSheetOpen(), "Driver Review page discount  side sheet should close with ESC key action");

        driverReviewPage.clickContinueButton();

        SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
        if (!driverReviewPage.isSignalDiscountDisabledState(applicant.getStateCode())) {
            signalPageOneUI.processSignalPage(true);
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        testStepAssert(contactInfoAutoPage.isOnContactInfoAutoPage(), "User is on the contact info page");
        contactInfoAutoPage.setValuesAndContinue();

        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if (bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            bwFarmersQuotePresentmentPage.continueWithFarmers();
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
        }
        testStepAssert(isOnQuoteSummaryAutoPage(), "User is on the quote summary page");

        closeQualtricsPopUp();
        this.clickOnEditLiabilityCoverageButton();

        fsa.assertTrue(isOnLiabilityCoverageFrameOfQuoteSummaryAutoPage(), "Liability side sheet open");
        // Simulate pressing the Escape key
        actions.sendKeys(PWKeys.ESCAPE).perform();
        sleep(1);
        closeQualtricsPopUp();
        fsa.assertFalse(isOnLiabilityCoverageFrameOfQuoteSummaryAutoPage(), "Liability side sheet close after ESC key");

        if (!applicant.getStateCode().equals(NC)) {
            this.clickOnEditSingleVehicleCoverageButton();

            fsa.assertTrue(isOnVehicleCoverageFrameOfQuoteSummaryAutoPage(), "Vehicle side sheet open");
            // Simulate pressing the Escape key
            actions.sendKeys(PWKeys.ESCAPE).perform();
            sleep(1);
            fsa.assertFalse(isOnVehicleCoverageFrameOfQuoteSummaryAutoPage(), "Vehicle side sheet close after ESC key");

        }

        clickReviewDiscountButton();
        fsa.assertTrue(isDiscountSideSheetOpen(), "Driver Review page discount side sheet should be open");
        // Simulate pressing the Escape key
        actions.sendKeys(PWKeys.ESCAPE).perform();
        sleep(1);
        fsa.assertFalse(isDiscountSideSheetOpen(), "Driver Review page discount  side sheet should close with ESC key action");
    }

    public void validateCustomizeAccidentDeathAndDisabilityInjury(FarmersSoftAssert fsa) throws Exception {
        closeQualtricsPopUp();
        String accidentalDeath = ACCIDENTAL_DEATH.getCoverageOrLiabilityText();
        expandLiabilityCoverageCardIfPresent();
        PWElement defaultValueOnThePage = driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, accidentalDeath)));
        closeQualtricsPopUp();
        clickOnEditLiabilityCoverageButton();
        sleep(1);

        // Validate for GA State Auto quotes if there is no toggle button displaying for 'Accidental Death or Disabling Injury' coverage in UI (Side sheet)
        fsa.assertFalse(isElementDisplayed(PWBy.id("Liability__34018__toggle")), accidentalDeath + " toggle should not be displayed to the customer");
        closeQualtricsPopUp();
        String defaultValueOnTheSideSheet = getTextFromElement(waitElementBeVisible(checkedAccidentDeathRadioButton));

        Log.info("By default the value selected for " + accidentalDeath + " is : " + defaultValueOnTheSideSheet);

        fsa.assertEquals(defaultValueOnTheSideSheet, getTextFromElement(defaultValueOnThePage), accidentalDeath + " coverage default values are matching between page and sidesheet");

        // updating to a new value randomly
        // Validate for GA State Auto quotes if can successfully modify the limits pertaining to 'Accidental Death or Disabling Injury' coverage and the quote should be custom rated successfully.
        PWElement updatedValueOnSideSheet = uncheckedAccidentDeathRadioButtons.get(randomNumberGenerator.nextInt(uncheckedAccidentDeathRadioButtons.size()));
        scrollElementToMiddle(updatedValueOnSideSheet);
        waitAndClickElement(updatedValueOnSideSheet);
        String updatedValueText = getTextFromElement(updatedValueOnSideSheet);
        Log.info(accidentalDeath + " is updated to " + updatedValueText);
        closeQualtricsPopUp();
        clickRecalculateButton();
        waitForSpinnerToBeGone();
        sleep(1);
        PWElement updatedValueOnThePage = driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, accidentalDeath)));
        fsa.assertEquals(updatedValueText, getTextFromElement(updatedValueOnThePage), accidentalDeath + " coverage value is matching between sidesheet and page after custimazation");
    }

    public void validateUMAdjustmentPopUp(FarmersSoftAssert softAssert) {
        /*
        "Create a quote for FL state.
Customer is quoting for 3 vehicles
Customer gets a quote with BI and UM coverage
Customer removes BI limit and recalculates
The system makes an adjustment by removing UM coverage which requires BI
Customer sees the pop-up content about BI being required to maintain UM three times. It should be displayed only once."
         */
        clickOnEditLiabilityCoverageButton();
        waitAndClickElement(liabilityToggle); // turn off bi liability toggle
        sleep(1);
        softAssert.assertTrue(isButtonNotSelected(liabilityToggle), "BI toggle was turned off");
        if (isButtonSelected(medicalCoverageToggle)) {
            waitAndClickElement(medicalCoverageToggle);
            sleep(1);
            softAssert.assertTrue(isButtonNotSelected(medicalCoverageToggle), "Medical coverage was turned off");
        }
        waitAndClickElement(recalculateButton);
        waitForSpinnerToBeGone();
        wait.until(PWExpectedConditions.visibilityOfAllElements(bwAdjustmentPopUpContents));
        softAssert.assertFalse(bwAdjustmentPopUpContents.isEmpty(), "there should be adjustment message for UM Coverage");
        softAssert.assertEquals(bwAdjustmentPopUpContents.size(), 1, "adjsutment content size should be only one");
        waitAndClickElement(adjustmentDialogCloseButton);
    }

    public void validatePrefillValuesForMediaAlpha(AutoApplicant applicant, FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(agreeAndSubmitButton), "Agree and submit", "Media Alpha agree and submit button text validated on the quote summary page");
        softAssert.assertEquals(getValueFromWebElement(emailInputFieldMediaAlpha), applicant.getEmail(), "Email is correclty prefilled");
        softAssert.assertEquals(getValueFromWebElement(phoneInputFieldMediaAlpha).replaceAll("\\D", EMPTY_STRING), applicant.getPhoneNumber().replaceAll("\\D", EMPTY_STRING).substring(0, 10), "Phone number is correclty prefilled");
        softAssert.assertTrue(isExpectedTextContainedInElement(medialAlphaPrefilledAddress, applicant.getResidentAddress()), "resident address prefiled correclty");
        softAssert.assertTrue(isExpectedTextContainedInElement(medialAlphaPrefilledAddress, applicant.getCity()), "City prefiled correclty");
        softAssert.assertTrue(isExpectedTextContainedInElement(medialAlphaPrefilledAddress, applicant.getZipCode()), "Zip code prefiled correclty");
    }

    public void validateDisclaimersInQuotePageWithAlphaMedia(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(contactEsignDisclaimer), EXPECTED_ESIGN_DISCLAIMER, "Partner flow esign disclaiemr validated on teh quote page");
        softAssert.assertEquals(getTextFromElement(contactInfoDisclaimer), EXPECTED_CTA_DISCLAIMER, "Partner flow we sometimes call or text.. validated on teh quote page");
    }

    public void clickAgreeAndSubmitButton() {
        clickElement(agreeAndSubmitButton);
    }

    public void updateLiabilityBiOnly(String biLimit) throws Exception {
        clickOnEditLiabilityCoverageButton();
        updateBodilyInjurySelectionFromSideSheet(biLimit);
        clickRecalculateButton();
        waitForSpinnerToBeGone();
    }


    public void validateUIM_MinimumLimits_NJ_State(FarmersSoftAssert fsa) throws Exception {
        String expectedBiUmBILimit = "$35,000/$70,000";
        checkCoverage(fsa, true, BODILY_INJURY.getCoverageOrLiabilityText(), expectedBiUmBILimit, "Default BI limit should be 35/70 for NJ state");
        checkCoverage(fsa, true, UNINSURED_UNDERINSURED_MOTORIST.getCoverageOrLiabilityText(), expectedBiUmBILimit, "Default UMUIM limit should be 35/70 for NJ state");
        // check the side sheet and validate min limit for selection is 35/70 for both BI and UMUIM
        clickOnEditLiabilityCoverageButton();
        PWElement selectedBi = allBodilyInjuryRadioButtons.stream().filter(element -> getAttributeData(element, CLASS).contains("radio-checked")).collect(Collectors.toList()).stream().findFirst().get();
        fsa.assertEquals(getTextFromElement(selectedBi), expectedBiUmBILimit, "BI limit selected should be 35/70 for NJ state");
        fsa.assertEquals(getTextFromElement(allBodilyInjuryRadioButtons.get(0)), expectedBiUmBILimit, "Minimum BI limit option should be 35/70 for NJ state");
        PWElement selectedUiUim = UMBISideSheetRadioButtons.stream().filter(element -> getAttributeData(element, CLASS).contains("radio-checked")).collect(Collectors.toList()).stream().findFirst().get();
        fsa.assertEquals(getTextFromElement(selectedUiUim), expectedBiUmBILimit, "BI limit selected should be 35/70 for NJ state");
        fsa.assertEquals(getTextFromElement(UMBISideSheetRadioButtons.get(0)), expectedBiUmBILimit, "Minimum UMUIM limit option should be 35/70 for NJ state");
        closeLiabilitySideDialog();
        clickOnStartCheckoutButton();
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        fsa.assertTrue(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User should land on additional info page after clicking start checkout from quote summary page");
        driver().navigate().back(); // navigate back to quote summary page
        fsa.assertTrue(isOnQuoteSummaryAutoPage(), "User should land back on quote summary page after navigating back from additional info page");

        // make sure the selected values are retained
        checkCoverage(fsa, true, BODILY_INJURY.getCoverageOrLiabilityText(), expectedBiUmBILimit, "Selected BI limit should be retained after navigating back from additional info page");
        checkCoverage(fsa, true, UNINSURED_UNDERINSURED_MOTORIST.getCoverageOrLiabilityText(), expectedBiUmBILimit, "Selected UMUIM limit should be retained after navigating back from additional info page");
        // check the side sheet and validate min limit for selection is 35/70 for both BI and UMUIM
        clickOnEditLiabilityCoverageButton();
        PWElement selectedBiAfterNavigation = allBodilyInjuryRadioButtons.stream().filter(element -> getAttributeData(element, CLASS).contains("radio-checked")).collect(Collectors.toList()).stream().findFirst().get();
        fsa.assertEquals(getTextFromElement(selectedBiAfterNavigation), expectedBiUmBILimit, "BI limit selected should be 35/70 for NJ state after navigation back");
        fsa.assertEquals(getTextFromElement(allBodilyInjuryRadioButtons.get(0)), expectedBiUmBILimit, "Minimum BI limit option should be 35/70 for NJ state  after navigation back");
        PWElement selectedUiUimAfterNavigation = UMBISideSheetRadioButtons.stream().filter(element -> getAttributeData(element, CLASS).contains("radio-checked")).collect(Collectors.toList()).stream().findFirst().get();
        fsa.assertEquals(getTextFromElement(selectedUiUimAfterNavigation), expectedBiUmBILimit, "BI limit selected should be 35/70 for NJ state  after navigation back");
        fsa.assertEquals(getTextFromElement(UMBISideSheetRadioButtons.get(0)), expectedBiUmBILimit, "Minimum UMUIM limit option should be 35/70 for NJ state  after navigation back");
        closeLiabilitySideDialog();
    }

    public void validateUMPDIsNotHigherThanPD_OR_State(FarmersSoftAssert fsa) throws Exception {
        clickOnEditLiabilityCoverageButton();
        closeQualtricsPopUp();
        updatePropertyDamageSelectionFromSideSheet("$20,000");
        updateUMPDSelectionFromSideSheet("$25,000 with $200 Deductible");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(umpdErrorMessage)), "This coverage limit cannot be higher than your \"Property damage\" coverage limit.", "UMPD limit cannot be higher than PD limit error message validated");
    }

    public void validateUserIsAbleToSelectAndRecalculatePD(FarmersSoftAssert fsa) throws Exception {
        clickOnEditLiabilityCoverageButton();
        closeQualtricsPopUp();
        String coverageOrLiabilityText = PROPERTY_DAMAGE_PART4.getCoverageOrLiabilityText();
        updatePropertyDamageSelectionFromSideSheet("$30,000");
        waitAndClickElement(recalculateButton);
        waitForSpinnerToBeGone();
        PWElement coverageToCheckValue = driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, coverageOrLiabilityText)));
        scrollElementToTop(coverageToCheckValue);
        fsa.assertEquals(getTextFromElement(coverageToCheckValue), "$30,000", "User is able to update PD to 30k" + SPACE + coverageOrLiabilityText);
    }

    public void validateUmUimSelectionAfterDeselection(FarmersSoftAssert fsa) throws Exception {
        clickOnEditLiabilityCoverageButton();
        closeQualtricsPopUp();
        scrollElementToMiddle(umUimToggle);
        fsa.assertTrue(getAttributeData(umUimToggle, CLASS).contains(CHECKED), "UMUIM toggle is ON by default");
        waitAndClickElement(umUimToggle); // turn off umuim toggle

        scrollToElement(waitElementBeVisible(umUimToggleErrorMessage));
        fsa.assertEquals(getTextFromElement(umUimToggleErrorMessage), "UM/UIM Bodily Injury Coverage is required when policy includes ride sharing", "UMUIM required error validation message");
        scrollElementToMiddle(umUimToggle);
        waitAndClickElement(umUimToggle); // turn on umuim toggle
        fsa.assertFalse(isElementVisible(umUimToggleErrorMessage, 2), "UMUIM required error message is not visible after turning on the toggle");
    }

    public void validateMinLiabilityLimitsAreEnforced(FarmersSoftAssert fsa) throws Exception {
        clickOnEditLiabilityCoverageButton();
        closeQualtricsPopUp();
        waitElementBeVisible(lblEditLiabilityCoverageHeader);

        // validate error message for BI limit less than state minimum
        updateBodilyInjurySelectionFromSideSheet("$25,000/$50,000");

        fsa.assertEquals(getTextFromElement(waitElementBeVisible(bodilyInjuryErrorMessage)), "Bodily injury limit must be $50,000/$100,000 or higher when policy includes ride sharing", "BI limit must be 50/100 or higher error message validation");

        // validate that user is able to select BI limit that is 50/100 or higher and error message is not visible
        updateBodilyInjurySelectionFromSideSheet("$50,000/$100,000");

        fsa.assertFalse(isElementVisible(bodilyInjuryErrorMessage, 1), "BI limit error message should not be visible when selected limit is 50/100 or higher with rideshare on the policy");

        // validate error message for PD limit less than state minimum
        updatePropertyDamageSelectionFromSideSheet("$20,000");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(propertyDamageErrorMessage)), "Property Damage must be $25,000 or higher when policy includes ride sharing", "PD limit must be 25k or higher error message validation");

        // validate error message not visible for PD limit or  state minimum or more
        updatePropertyDamageSelectionFromSideSheet("$50,000");
        fsa.assertFalse(isElementVisible(propertyDamageErrorMessage, 1), "PD limit error message should not be visible when selected limit is 25k or higher with rideshare on the policy");
        clickRecalculateButton();
    }

    public boolean navigateFromQuoteSummaryPageToPaymentPage(boolean isAdpf) throws Exception {
        clickOnStartCheckoutButton();
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        ThankYouPageAce thankYouPageAce = new ThankYouPageAce();
        if (!additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage() && thankYouPageAce.isOnThankYouPage()) {
            throw new SkipException("User landed on the Thank you page");
        }
        DriverMismatchPage driverMismatchPage = new DriverMismatchPage();

        if (driverMismatchPage.isOnDriverMismatchPage()) {
            driverMismatchPage.randomlySelectReasonForNonInclusion();
            driverMismatchPage.clickContinueButton();
            driverMismatchPage.waitForSpinnerToBeGone();
        }
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);

        if (driverMismatchPage.isOnDriverMismatchPage()) {
            driverMismatchPage.randomlySelectReasonForNonInclusion();
            driverMismatchPage.clickContinueButton();
            driverMismatchPage.waitForSpinnerToBeGone();
        }

        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
            navigateFromQuoteSummaryPageToPaymentPage(false);
        }

        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        return autoPolicyPaymentBasePage.isOnContinueToPaymentPage();
    }

    public void checkBundleOrContinueToAutoButtonDisplayed(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(startCheckoutButton.isDisplayed(), "Start checkout button displayed - Bundle or continue to auto");
        fsa.assertEquals(getTextFromElement(startCheckoutButton), CONTINUE_WITH_AUTO, "Start checkout button text validation - Bundle or continue to auto");
        fsa.assertTrue(driver().findElement(PWBy.partialLinkText(BUNDLE_AND_SAVE)).isDisplayed(), "Bundle and continue button validation - Bundle or continue to auto");
    }

    public void checkBundleOrContinueToAutoButtonNotDisplayed(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(startCheckoutButton.isDisplayed(), "Start checkout button validation - No bundle or continue to auto");
        fsa.assertEquals(getTextFromElement(startCheckoutButton), "Continue", "Start checkout button text validation - No bundle or continue to auto");
        fsa.assertTrue(driver().findElements(PWBy.partialLinkText(BUNDLE_AND_SAVE)).size() == 0, "Bundle and continue button validation - No bundle or continue to auto");
    }

    public void validateGoodDistantStudentDiscountApplied(FarmersSoftAssert fsa, String stateCode, boolean isOnQuoteSummaryPage) {
        String pageName = isOnQuoteSummaryPage ? "Quote Summary page" : "Payment selection page";
        if (List.of(AR, GA).contains(stateCode)) {
            fsa.assertTrue(isDiscountPresentInTheSideSheet("Good Student"), "Good Student discount is displayed in the side sheet for SNI with high GPA - " + pageName);
        }
        fsa.assertTrue(isDiscountPresentInTheSideSheet("Distant Student"), "Distant Student discount is displayed in the side sheet for SNI attending distant school - " + pageName);
    }

    public void checkSignalDiscount(FarmersSoftAssert fsa) throws Exception {
        List<String> displayedDiscounts = getDisplayedDiscounts();
            if (displayedDiscounts.contains("Signal")) {
                Log.info("Discounts list contains Signal");
                fsa.assertTrue(displayedDiscounts.contains("Signal"));
            } else {
                Log.info("Discounts list does not contain contains Signal");
                fsa.assertFalse(displayedDiscounts.contains("Signal"),"Discounts list contains Signal");
            }
    }

    public void removeSignalDiscountAndCheck(AutoApplicant applicant,FarmersSoftAssert fsa) throws Exception  {
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoPage=new AdditionalInfoSignalEnrollmentSectionOneUI();
        String state = applicant.getStateCode();
        if (state.equals(OR)) {
            checkSignalDiscount(fsa);
            scrollToTopOfPage();
            clickContinueButton();
            fsa.assertTrue(yesContinueWithSignalDiscount.isDisplayed());
            waitAndClickElement(yesContinueWithSignalDiscount);
            additionalInfoPage.cancelSignalEnrollmentAndReturnToQuoteReview();
            checkSignalDiscount(fsa);
        }
        else {
            checkSignalDiscount(fsa);
            clickOnStartCheckoutButton();
            additionalInfoPage.cancelSignalEnrollmentAndReturnToQuoteReview();
            checkSignalDiscount(fsa);
        }
    }

    public void validatePermissiveUserLimitOfLiabilityUpdateToLimited(String puLimit, FarmersSoftAssert fsa) throws Exception {
        clickOnEditLiabilityCoverageButton();
        PWElement selectedPuLimitRadioButton = driver().findElement(PWBy.xpath(String.format("//mat-radio-group[@aria-label='select Permissive User Limit of Liability']//mat-radio-button[contains(.,'%s')]", puLimit)));
        scrollAndClickOnElement(selectedPuLimitRadioButton);
        clickRecalculateButton();
        waitForSpinnerToBeGone();
        String getSelectedValue =getTextFromElement(permissiveUserLimitUpdatedValue);
        fsa.assertEquals(getSelectedValue, puLimit);
    }

    public void validateUpdatedPermissiveUserLimitValueCompAndCollAreRetainedAfterRetrieval(AutoApplicant applicant,FarmersSoftAssert fsa) throws Exception {
        closeQualtricsPopUp();
        String PermissiveValueBeforeRetrieval = getTextFromElement(permissiveUserLimitUpdatedValue);
        String comprehensiveCoverageLabel = COMPREHENSIVE.getCoverageOrLiabilityText();
        String collisionCoverageLabel = COLLISION.getCoverageOrLiabilityText();
        String compCoverageBeforeRetrieval = getTextFromElement(driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, comprehensiveCoverageLabel))));
        String collCoverageBeforeRetrieval = getTextFromElement(driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, collisionCoverageLabel))));
        String quoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
        new LandingPage(isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, quoteNumber);
        fsa.assertTrue(isOnQuoteSummaryAutoPage(), "User is on Quote summary page after quote after retrieval");
        String PermissiveValueAfterRetrieval = getTextFromElement(permissiveUserLimitUpdatedValue);
        fsa.assertEquals(PermissiveValueBeforeRetrieval, PermissiveValueAfterRetrieval, "Permissive User Limit coverage should be retained after quote retrieval. Value before retrieval: " + PermissiveValueBeforeRetrieval + ", value after retrieval: " + PermissiveValueAfterRetrieval);
        String compCoverageAfterRetrieval = getTextFromElement(driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, comprehensiveCoverageLabel))));
        String collCoverageAfterRetrieval = getTextFromElement(driver().findElement(PWBy.xpath(String.format(XPATH_FOR_COVERAGE_VALUE, collisionCoverageLabel))));
        fsa.assertEquals(compCoverageAfterRetrieval, compCoverageBeforeRetrieval, "Customized comprehensive coverage should be retained after quote retrieval. Value before retrieval: " + compCoverageBeforeRetrieval + ", value after retrieval: " + compCoverageAfterRetrieval);
        fsa.assertEquals(collCoverageAfterRetrieval, collCoverageBeforeRetrieval, "Customized collision coverage should be retained after quote retrieval. Value before retrieval: " + collCoverageBeforeRetrieval + ", value after retrieval: " + collCoverageAfterRetrieval);
    }

    public void validateResetButtonDisappearAfterRevertingCoverages(FarmersSoftAssert fsa) throws Exception {
        String premiumValueBeforeReset = getPresentedPremiumAmount();
        updateVehicleCoverageAndCustomize();
        testStepAssert(resetOriginalQuoteButton.isDisplayed(), "Reset Button is Displayed");
        waitAndClickElement(resetOriginalQuoteButton);
        waitForSpinnerToBeGone();
        String premiumValueAfterReset = getPresentedPremiumAmount();
        fsa.assertEquals(premiumValueBeforeReset, premiumValueAfterReset, "Premium value after resetting to original quote should be same as before. Premium before reset: " + premiumValueBeforeReset + ", premium after reset: " + premiumValueAfterReset);
        waitElementBeInvisible(resetOriginalQuoteButton);
    }

    public boolean is_TL_or_MLB_SourceCodePopUpPresent() {
        PWBy headerBy = PWBy.xpath("//app-sweep-stakes-popup//h4");
        try {
            return isElementPresent(headerBy, 3) && isElementDisplayed(headerBy);
        } catch (Exception e) {
            return false;
        }
    }

    public void validateContentForTlSourceCodePopUp(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(sourceCodePopUpHeader)), "Thanks for completing your quote!", "TL source code pop up header text validation");
        fsa.assertEquals(getTextFromElement(sourceCodePopUpContentParagraph1), "Now keep an eye out for an email from notifications@nadelstores.com with instructions and a link to access your gift options. It should arrive within 24 hours.", "TL source code pop up body text 1 validation");
        fsa.assertEquals(getTextFromElement(sourceCodePopUpContentParagraph2), "Didn't get the email? Send us a message at farmers@nadel.com for help.", "TL source code pop up body text 2 validation");
        fsa.assertEquals(getTextFromElement(sourceCodePopUpOkButton), "Ok", "TL source code pop up OK button text validation");
        clickElement(sourceCodePopUpOkButton);
    }

    public void validateContentForMLBSourceCodePopUp(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(sourceCodePopUpHeader)), "Thanks for completing your quote!", "MLB source code pop up header text validation");
        fsa.assertEquals(getTextFromElement(sourceCodePopUpContentParagraph1), "Completing a quote allows you to enter the sweepstakes, provided you meet all sweepstakes eligibility requirements.", "MLB source code pop up body text 1 validation");
        fsa.assertEquals(getTextFromElement(sourceCodePopUpContentParagraph2), "Entry is subject to the official rules.", "MLB source code pop up body text 2 validation");
        fsa.assertEquals(getTextFromElement(sourceCodePopUpOkButton), "Ok", "MLB source code pop up OK button text validation");
        clickSourceCodePopUpOkButton();
    }

    public void clickSourceCodePopUpOkButton() {
        clickElement(sourceCodePopUpOkButton);
    }

    public void validateTlSourceCodeFunctionality(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        // when user lands on the quote page first time, they should see the pop up
        fsa.assertTrue(is_TL_or_MLB_SourceCodePopUpPresent(), "TL source code pop up should be displayed after clicking on start checkout button for TL source code");
        // validate the content of the pop up and close
        validateContentForTlSourceCodePopUp(fsa);
        //user no longer should see the pop up if they refresh the page
        driver().navigate().refresh();
        fsa.assertFalse(is_TL_or_MLB_SourceCodePopUpPresent(), "TL source code pop up should not be displayed after page refresh");
        // user should not see the pop up if they navigate back and forth
        clickEnterInfoNavigationBarStepper();
        sleep(2);
        clickReviewQuoteNavigationBarStepper();
        fsa.assertFalse(is_TL_or_MLB_SourceCodePopUpPresent(), "TL source code pop up should not be displayed after navigating back and forth in the quote process");

        // User should not see the pop up if they retrieve the quote
        new LandingPage(isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, getSessionStorageAppStore().getData().getQuoteNumber());
        testStepAssert(isOnQuoteSummaryAutoPage(), "User is on Quote summary page after quote retrieval");
        fsa.assertFalse(is_TL_or_MLB_SourceCodePopUpPresent(), "TL source code pop up should not be displayed after quote retrieval");
    }

    public void validate_MLB_SourceCodeFunctionality(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(is_TL_or_MLB_SourceCodePopUpPresent(), "MLB source code pop up should be displayed after clicking on start checkout button for MLB source code");
        validateContentForMLBSourceCodePopUp(fsa);
        //user no longer should see the pop up if they refresh the page
        driver().navigate().refresh();
        fsa.assertFalse(is_TL_or_MLB_SourceCodePopUpPresent(), "MLB source code pop up should not be displayed after page refresh");
        // user should not see the pop up if they navigate back and forth
        clickEnterInfoNavigationBarStepper();
        sleep(2);
        clickReviewQuoteNavigationBarStepper();
        fsa.assertFalse(is_TL_or_MLB_SourceCodePopUpPresent(), "MLB source code pop up should not be displayed after navigating back and forth in the quote process");

        // User should not see the pop up if they retrieve the quote
        new LandingPage(isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, getSessionStorageAppStore().getData().getQuoteNumber());
        testStepAssert(isOnQuoteSummaryAutoPage(), "User is on Quote summary page after quote retrieval");
        fsa.assertFalse(is_TL_or_MLB_SourceCodePopUpPresent(), "MLB source code pop up should not be displayed after quote retrieval");
    }

    public boolean isPayrollDeductionBannerDisplayed() {
        return isElementDisplayed(payRollBanner, 5);
    }

    public void validatePayRollBannerContentForCAState(FarmersSoftAssert fsa) throws Exception {
        ArrayList<String> contentList = new ArrayList<>();
        contentList.add("Thanks for shopping with Farmers!");
        contentList.add("To buy, please call us at 855-503-1928.");
        for (String list : contentList) {
            fsa.assertEquals(getTextFromElement(driver().findElement(PWBy.xpath(String.format("//div[contains(@class,'banner-content')]//p[contains(normalize-space(),'%s')]", list)))), list, "Banner content validation for CA state");
        }
        String EMPLOYER_NAME = getSessionStorageAppStore().getData().getEmployerName();
        String PAYROLL_BANNER_CONTENT = String.format("You may be eligible to enroll in payroll deduction and other benefits through your employment at %s." +
                " A representative can discuss all your options and check for additional discounts.", EMPLOYER_NAME) ;
        fsa.assertEquals(getTextFromElement(payRollBannerContent), PAYROLL_BANNER_CONTENT, "Mismatch pay roll banner content");
        fsa.assertTrue(waitElementBeVisible(payRollContactButton).isDisplayed(), "Payroll contact button should be displayed");
    }

    /**
     * Validates the Bristol West promo card section on the review-quote page.
     * Covers: BW logo, info icon (tooltip trigger), promo header, promo content text,
     * phone number link, and tooltip expansion on info icon click.
     *
     * @param fsa FarmersSoftAssert instance for soft assertions
     */
    public void validateBwPromoCardSection(FarmersSoftAssert fsa) {
        // Promo card container is present and visible
        fsa.assertTrue(isElementVisible(bwPromoCard, 5), "BW promo card should be visible on the review-quote page");

        // Bristol West logo is displayed
        fsa.assertTrue(isElementVisible(bwPromoLogo, 5), "Bristol West logo should be visible in the promo card");

        // Info icon is visible and has the correct accessibility label
        fsa.assertTrue(isElementVisible(bwPromoInfoIcon, 5), "BW promo info icon should be visible");
        fsa.assertEquals(getAttributeData(bwPromoInfoIcon, "aria-label"), BW_PROMO_INFO_ICON_ARIA_LABEL,
                "BW promo info icon aria-label should be: " + BW_PROMO_INFO_ICON_ARIA_LABEL);

        // Header text validation
        fsa.assertEquals(getTextFromElement(bwPromoHeader), "Great news! We found you a competitive price.",
                "BW promo header text should be: " + "Great news! We found you a competitive price.");

        // Content text contains key phrases
        String promoContentText = getTextFromElement(bwPromoContent);
        fsa.assertEquals(promoContentText, "Bristol West\u00ae, part of the Farmers Insurance\u00ae family, specializes in affordable, quality coverage. Your quote details are saved, so you can buy now, or call Farmers at 1-800-206-9469 for more options.", "Bw co brand section description text is validated");

        // Phone number link text and href
        fsa.assertEquals(getTextFromElement(bwPromoPhoneLink), BW_PROMO_PHONE_NUMBER,
                "BW promo phone link text should be: " + BW_PROMO_PHONE_NUMBER);
        fsa.assertEquals(getAttributeData(bwPromoPhoneLink, "href"), BW_PROMO_PHONE_HREF,
                "BW promo phone link href should be: " + BW_PROMO_PHONE_HREF);

        // Tooltip: clicking info icon should expand it (aria-expanded becomes true)
        fsa.assertEquals(getAttributeData(bwPromoInfoIcon, "aria-expanded"), "false",
                "BW promo info icon should be collapsed before clicking");
        scrollElementToMiddle(bwPromoInfoIcon);
        clickElement(bwPromoInfoIcon);
        fsa.assertEquals(getAttributeData(bwPromoInfoIcon, "aria-expanded"), "true",
                "BW promo info icon should be expanded after clicking");
        fsa.assertEquals(getTextFromElement(bwPromoInfoIconContent), "Bristol West\u00ae has been serving drivers for over 45 years. And as a member of the Farmers Insurance Group of Companies\u00ae, they're committed to offering quality auto insurance at an affordable price. Bristol West\u00ae has helped customers with poor credit, no prior insurance, no driving history, traffic violations, accidents or a DUI. You can learn more at bristolwest.com.");
    }

}

class LimitPair {
    String biLimit;
    String pdLimit;

    public LimitPair(String bi, String pd) {
        this.biLimit = bi;
        this.pdLimit = pd;
    }
}
