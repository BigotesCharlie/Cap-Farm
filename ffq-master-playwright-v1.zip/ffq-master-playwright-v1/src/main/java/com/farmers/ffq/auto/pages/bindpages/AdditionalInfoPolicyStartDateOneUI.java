package com.farmers.ffq.auto.pages.bindpages;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.auto.pages.HeaderAndFooter;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import lombok.SneakyThrows;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.farmers.ffq.utils.GlobalVariables.*;


public class AdditionalInfoPolicyStartDateOneUI extends AutoBasePage {
    private static final String ADDITIONAL_INFO_HEADER_LABEL = "Just a few more things";
    private static final String ADDITIONAL_INFO_HEADER_LABEL_2 = "Let's complete your quote";
    private static final String ADDITIONAL_INFO_HEADER_LABEL_3 = "Review and complete auto";
    @PWFindBy(xpath = "//div[contains(@class, 'additional-info-main-page')]//h1")
    private PWElement justFewMoreThingsLabel;

    @PWFindBy(xpath = "//a[contains(text(),'Privacy Policy')]")
    private PWElement privacyPolicyLink;

    @PWFindBy(xpath="//h1/span/span[contains(text(),'Privacy Center')]")
    private PWElement privacyCenterHeading;

    @PWFindBy(xpath = "//div[@class='additional-info-main-page ng-star-inserted']//h1")
    private PWElement additionalInfoPageHeader;

    @PWFindBy(xpath= "//mat-progress-bar")
    private PWElement progressbarAceAuto;

//    private static final String ADDITIONAL_INFO_SUBHEADER_LABEL = "Please fill out these last few details so we can complete your purchase.";
//    @FindBy(xpath = "//span[contains(text(), 'Please fill out these last few details so we can complete your purchase.')]")
//    private WebElement additionalInfoSubHeader;

    private static final String POLICY_START_DATE_LABEL = "Auto policy start date";
    @PWFindBy(xpath = "//div[contains(@class, 'additional-info-effective-date-section')]//h2")
    private PWElement policyStartDateLabel;

    private static final String INSURANCE_BEGIN_LABEL = "Please confirm when you'd like your insurance to begin.";

    @PWFindBy(xpath = "//p[contains(text(), 'like your insurance to begin.')]")
    private List<PWElement> insuranceBeginLabel;

    private static final String POLICY_START_DATE_XPATH = "//input[@aria-label='Select policy start date in the format of mmddyyyy,']";
    @PWFindBy(xpath = POLICY_START_DATE_XPATH)
    private PWElement policyStartDatePicker;

    private static final String POLICY_START_DATE_PLACEHOLDER = "Policy start date";
    @PWFindBy(xpath = "//mat-label[contains(text(), 'Policy start date')]")
    private PWElement policyStartDatePlaceHolder;

    private static final String EARLY_SHOPPER_DISCOUNT_LABEL = "Early shopper discount";
    @PWFindBy(xpath = "//p[contains(text(), 'Early shopping discount')]")
    private PWElement earlyShopperDiscountLabelBrowser;
    @PWFindBy(xpath = "//h1[contains(text(), 'Early shopper discount')]")
    private PWElement earlyShopperDiscountLabelH1;
    @PWFindBy(xpath = "//div[@class='additional-info-effective-date-section']//mat-icon[contains(@class,'mobile')]")
    private PWElement earlyShopperMobileMatIcon;

    private static final String DISCOUNT_CONGRATULATIONS_MESSAGE_XPATH = "//div[contains(@class,'tui-simple-banner-success-left')]";
    @PWFindBy(xpath = DISCOUNT_CONGRATULATIONS_MESSAGE_XPATH)
    private PWElement discountCongratulationMessage;

    @PWFindBy(css="div[id='tui-save-quote-modal']")
    private PWElement sidesheet;

    public static final String GREEN_CHECK_CIRCLE_XPATH = "//div[contains(@class, 'tui-simple-banner-success-left')]";
    @PWFindBy(xpath = GREEN_CHECK_CIRCLE_XPATH)
    private PWElement greenCheckCircle;
    private static final String EARLY_SHOPPER_DISCOUNT_TEXT = "If your policy start date is 7 or more days from today, you get an early shopping discount. You can start your policy up to 60 days in the future.";
    @PWFindBy(xpath = "//p[contains(text(), 'If your policy start date is 7 or more days from today')]")
    private PWElement earlyShopperDiscountText;

    private String POLICY_PURCHASE_DATE_ERROR = "To continue with your policy purchase, you must select your policy effective date between "+
            formattedTomorrowDate + " and " + formattedDateAfterTwoMonths + ".";
    private static final String POLICY_PURCHASE_DATE_ERROR_XPATH = "//mat-error[contains(text(), 'To continue with your policy purchase, you must select your policy effective date between')]";
    @PWFindBy(xpath = POLICY_PURCHASE_DATE_ERROR_XPATH)
    private PWElement policyPurchaseDateError;

    private static final String POLICY_START_DATE_REQUIRED_MESSAGE = "Please enter a valid policy start date.";
    @PWFindBy(xpath = "//mat-error[contains(text(), '" + POLICY_START_DATE_REQUIRED_MESSAGE + "')]")
    private PWElement policyStartDateRequiredMessage;

    private static final String DATEPICKER_TOGGLE_ICON_XPATH = "//mat-datepicker-toggle[contains(@class,'mat-datepicker-toggle')]";
    @PWFindBy(xpath = DATEPICKER_TOGGLE_ICON_XPATH)
    private PWElement datePickerToggleIcon;

    @PWFindBy(xpath = "//div[contains(@class,'mat-calendar-body-selected')]")
    private PWElement selectedDateInDatePickerPopUp;

    @PWFindBy(xpath = "//mat-checkbox[@formcontrolname='signalAgreement']")
    private PWElement signalEnrollmentConfirmationCheckbox;

    @PWFindBy(xpath = "//button[contains(text(), 'Continue')]")
    private PWElement continueToPaymentButton;

    @PWFindBy(xpath = "//div[contains(@class,'additional_info_tips_section_medium')]")
    private List<PWElement> additionalInfoTipMediumIconMobileDevice;

    @PWFindBy(xpath = "//mat-icon[contains(text(), 'close')]")
    private PWElement closeIcon;
    @PWFindBy(xpath = "//p[contains(@class,'model-caption-text')]")
    private PWElement getEarlyShopperDiscountTextInMb;
    @PWFindBy(xpath = "//button[contains(@class, 'additional-info-submit-button-style-bundle')]")
    private PWElement continueButtonAutoFewMoreThingsPageBundle;
    @PWFindBy(xpath = "//input[@formcontrolname='distStudSchool']")
    private PWElement distantSchoolName;
    @PWFindBy(xpath = "//input[@formcontrolname='distStudCity']")
    private PWElement distantSchoolCity;
    @PWFindBy(xpath = "//mat-select[@formcontrolname='distStudState']")
    private PWElement distantSchoolState;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AdditionalInfoPolicyStartDateOneUI() throws Exception {
        super();
    }

    public void verifyAdditionalInfoHeader(FarmersSoftAssert fsa) throws Exception{
        removeQualtricsPopUp();
        waitElementBeVisible(additionalInfoPageHeader);
        String actualHeader = getTextFromElement(additionalInfoPageHeader);
        fsa.assertTrue(List.of(ADDITIONAL_INFO_HEADER_LABEL, ADDITIONAL_INFO_HEADER_LABEL_2, ADDITIONAL_INFO_HEADER_LABEL_3).contains(actualHeader), "Additional info header validation: " + actualHeader );
        // removing validation as part of US1063117
        // fsa.assertEquals(getTextFromElement(additionalInfoSubHeader), ADDITIONAL_INFO_SUBHEADER_LABEL, "Additional Info Sub Header verification");
        HeaderAndFooter pageHeaderAndFooter = new HeaderAndFooter();
        fsa.assertTrue(pageHeaderAndFooter.isPhoneNumberCorrectOnBindPages(), "Proper phone number present");
    }

    public void validateAdditionalInfoPageHeader(FarmersSoftAssert softAssert, String expectedHeader) throws Exception {
        waitElementBeVisible(additionalInfoPageHeader);
        String actualHeader = getTextFromElement(additionalInfoPageHeader);
        softAssert.assertEquals(actualHeader, expectedHeader, "Additional info header validation");
    }

    public void validateSubtitleIsNotDisplayed(FarmersSoftAssert softAssert, String notWantedSubtitle) throws Exception {
        waitElementBeVisible(additionalInfoPageHeader);
        PWElement wholePageElement = driver().findElement(PWBy.tagName("app-additional-info-main"));
        softAssert.assertFalse(getTextFromElement(wholePageElement).contains(notWantedSubtitle), "Additional info page should not contain subtitle: " + notWantedSubtitle);
    }

    public void validatePolicyStartDateLabelIsDisplayedAboveTheInputField(FarmersSoftAssert softAssert, String expectedPolicyInputFieldTitle) throws Exception {
        waitElementBeVisible(policyStartDateLabel);
        softAssert.assertEquals(getTextFromElement(policyStartDateLabel), expectedPolicyInputFieldTitle, "Policy start date label text verification");
        waitElementBeVisible(policyStartDatePicker);
        int labelY  = policyStartDateLabel.getRect().getY();
        int inputY  = policyStartDatePicker.getRect().getY();
        softAssert.assertTrue(labelY < inputY,
                "Policy start date label (y=" + labelY + ") should be above the input field (y=" + inputY + ")");
    }

    public void validateVinIsDisplayedFirstThenLoanLease(FarmersSoftAssert softAssert) throws Exception {
        // ancestor::div[contains(@class,...)] — 'ancestor' is an XPath axis, requires '::', not just '@'
        List<PWElement> listOfVehicleSections = driver().findElements(PWBy.xpath(
                "//input[@formcontrolname='vin']/ancestor::div[contains(@class,'additional-info-vehicle-info-section')]"));
        if (!listOfVehicleSections.isEmpty()) {
        	PWElement vehicleSection = listOfVehicleSections.get(FIRST_AVAILABLE_OPTION);
        	PWElement vinInputField = vehicleSection.findElement(PWBy.xpath(".//input[@formcontrolname='vin']"));

        	// removed hardcoded dynamic Angular class 'ng-tns-c23-99' — it changes every run
        	PWElement loanLeaseInputField = vehicleSection.findElement(PWBy.xpath(
        			"//div[contains(@class,'mat-mdc-form-field-infix') and contains(.,'company')]"));

        	// added leading '.' — without it '//span[...]' searches from document root, ignoring vehicleSection scope
        	PWElement vehicleLabelElement = vehicleSection.findElement(PWBy.xpath(
        			"//span[@class='col mb-4 tui-subtitle-text-1']"));
        	String vehicleLabel = getTextFromElement(vehicleLabelElement);

        	int labelY = vinInputField.getRect().getY();
        	int inputY = loanLeaseInputField.getRect().getY();
        	softAssert.assertTrue(labelY < inputY,
        			"VIN input field (y=" + labelY + ") should be above the Loan/Lease input field (y=" + inputY
        			+ ") for vehicle section with label: " + vehicleLabel);
        }
    }

    public void verifyPolicyStartDateSection(AppStore retrieveQuoteResponseSessionStorage, boolean validateOnlyPolicyStartDateDefaultValue, FarmersSoftAssert fsa) throws Exception {
        removeQualtricsPopUp();
        closeQualtricsPopUp();
        waitElementBeVisibleClickable(continueToPaymentButton);
        if (validateOnlyPolicyStartDateDefaultValue) {
            validatePolicyStartDateFieldValue(retrieveQuoteResponseSessionStorage, fsa);
        } else {
            validatePolicyStartFieldLabels(fsa);
            validatePolicyStartDateFieldValue(retrieveQuoteResponseSessionStorage, fsa);
            waitElementBeVisibleClickable(policyStartDatePicker);
            validateManuallyEnteredPolicyStartDate(fsa);
            refreshAdditionalInfoPolicyStartDateOneUI();
            verifyDatePickerPopUpValidation(fsa);
        }
    }

    public void validateProgressbar(FarmersSoftAssert fsa) throws Exception {
    	validateProgressbarStatus(this.getClass().getSimpleName(), progressbarAceAuto, fsa);
    }

    // validate label texts around policy start date
    public void validatePolicyStartFieldLabels(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(getTextFromElement(policyStartDateLabel).equals(POLICY_START_DATE_LABEL) || getTextFromElement(policyStartDateLabel).equals("Policy start date"), "Policy Start Date Label verification");
        int indexAdjuster = isUseMobileViewEnabled() ? 1 : 0;
        fsa.assertEquals(getTextFromElement(insuranceBeginLabel.get(indexAdjuster)), INSURANCE_BEGIN_LABEL,"Insurance Begin Label verification" );
        fsa.assertEquals(getTextFromElement(policyStartDatePlaceHolder), POLICY_START_DATE_PLACEHOLDER, "Policy Start Date Placeholder verification");
        fsa.assertEquals(policyStartDatePicker.isDisplayed(), true, "Policy Start Date Element present ");
        boolean isCA_State = getSessionStorageAppStore().getData().getLandingStateCode().equals(CA);
        String expectedDiscountText = isCA_State ?  "If your policy start date is 7 or more days from today, you get an early shopping discount. You can start your policy up to 30 days in the future." : EARLY_SHOPPER_DISCOUNT_TEXT;
        if(isUseMobileViewEnabled()) {
            if(isCA_State) {
                fsa.assertFalse(isElementVisible(earlyShopperMobileMatIcon, 1), "Early shopper info icon should not be visible in CA");
            } else {
                waitAndClickElement(earlyShopperMobileMatIcon);
                fsa.assertEquals(getTextFromElement(earlyShopperDiscountLabelH1), EARLY_SHOPPER_DISCOUNT_LABEL, "Early Shopper Mobile Discount Label verification");
                fsa.assertEquals(getTextFromElement(getEarlyShopperDiscountTextInMb), expectedDiscountText, "Early Shopper Mobile Discount Text vefrification");
                waitAndClickElement(closeIcon);
            }
        } else {
            if(isCA_State) {
                fsa.assertFalse(isElementVisible(earlyShopperDiscountLabelBrowser, 1), "Early shopper info icon should not be visible in CA");
            } else {
                fsa.assertEquals(getTextFromElement(earlyShopperDiscountLabelBrowser), "Early shopping discount","Early Shopper Browser Discount Label verification");
                fsa.assertEquals(getTextFromElement(earlyShopperDiscountText), expectedDiscountText,"Early Shopper Discount Browser Text verification");
            }

        }

    }

    public void validateEarlyShopperDiscount(FarmersSoftAssert fsa, Boolean isEarlyShopperDiscountVisible) throws Exception {
//        if(isEarlyShopperDiscountVisible){
//            fsa.assertEquals(isElementPresent(By.xpath("//div[contains(@class, 'tui-simple-banner-success-left')]")), true, "Green Check Circle Displayed");
//            fsa.assertEquals(isElementPresent(By.xpath(DISCOUNT_CONGRATULATIONS_MESSAGE_XPATH)), true, "Discount Congratulations Message Displayed");
//        }else {
//            List<WebElement> discountCongratulationMessageElement = driver().findElements(By.xpath(DISCOUNT_CONGRATULATIONS_MESSAGE_XPATH));
//            fsa.assertEquals(discountCongratulationMessageElement.size(), 0, "Discount Congratulations Message not displayed");
//        }
    }

    // validate policy start date when prior carrier expire date exists/not exists and early shopper discounts
    public void validatePolicyStartDateFieldValue(AppStore retrieveQuoteResponseSessionStorage, FarmersSoftAssert fsa) throws Exception {
        LocalDate dayAfterToday = currentDate.plusDays(1);
        LocalDate afterTwoWeekDate = currentDate.plusWeeks(2);
        LocalDate afterOneWeekDate = currentDate.plusWeeks(1);
        LocalDate policyStartDate = null;
        String effectiveDate = retrieveQuoteResponseSessionStorage.getData().getProjectCodeData().getAuto().getEffectiveDate();
        if (effectiveDate.contains("/")) {
            policyStartDate = LocalDate.parse(effectiveDate, dateTimeFormatter);
        } else {
            policyStartDate = LocalDate.parse(effectiveDate);
        }

        LocalDate policyStartDateFromDatePicker = LocalDate.parse(getAttributeData(policyStartDatePicker, VALUE), dateTimeFormatter);

        boolean isCarrierExpDateExists = retrieveQuoteResponseSessionStorage.getAuto().getDrivers().get(0).getCarrierExpDate().isEmpty();

        if (!isCarrierExpDateExists) {
            LocalDate priorCarrierExpDate = null;
            String carrierExpDate = retrieveQuoteResponseSessionStorage.getAuto().getDrivers().get(0).getCarrierExpDate();
            Log.info("carrierExpDate: " + carrierExpDate);
            if (carrierExpDate.contains("/")) {
                priorCarrierExpDate = LocalDate.parse(carrierExpDate, dateTimeFormatter);
            } else {
                priorCarrierExpDate = LocalDate.parse(carrierExpDate);
            }
            // LocalDate priorCarrierExpDate = LocalDate.parse(retrieveQuoteResponseSessionStorage.getAuto().getDrivers().get(0).getCarrierExpDate());
            if (priorCarrierExpDate.isAfter(currentDate) && priorCarrierExpDate.isBefore(afterTwoWeekDate)) {
                fsa.assertEquals(policyStartDateFromDatePicker, priorCarrierExpDate, "Policy Start Date Set As PriorCarrierExpDate");
                validateEarlyShopperDiscount(fsa, false);
                validatePolicyPurchaseDateError(fsa, false);

            } else if (priorCarrierExpDate.isBefore(currentDate)) {
                fsa.assertEquals(policyStartDateFromDatePicker, dayAfterToday, "Policy Start Date Set As Current Day + 1");
                validateEarlyShopperDiscount(fsa, false);
                validatePolicyPurchaseDateError(fsa, false);

            } else if (priorCarrierExpDate.equals(afterTwoWeekDate)) {
                fsa.assertEquals(policyStartDateFromDatePicker, afterTwoWeekDate, "Policy Start Date Set As After Two Weeks");
                validateEarlyShopperDiscount(fsa, true);
                validatePolicyPurchaseDateError(fsa, false);

            } else if (priorCarrierExpDate.isAfter(currentDate.plusMonths(2))) {
                validateEarlyShopperDiscount(fsa, false);
                validatePolicyPurchaseDateError(fsa, false);

            } else if (priorCarrierExpDate.isAfter(currentDate.plusMonths(2).plusDays(2))) {
                validateEarlyShopperDiscount(fsa, false);
                validatePolicyPurchaseDateError(fsa, true);
            }
        } else {
            if (policyStartDate.isBefore(currentDate)) {
                //fsa.assertEquals(policyStartDateFromDatePicker, dayAfterToday, "Policy Start Date Should Be Day After Current Date");
                validateEarlyShopperDiscount(fsa, false);
            } else if (policyStartDate.equals(currentDate.plusDays(7)) || policyStartDate.isAfter(afterOneWeekDate)) {
                fsa.assertEquals(policyStartDateFromDatePicker, policyStartDate, "Policy Start Date Should Be Policy Start Date From Quote Data");
                validateEarlyShopperDiscount(fsa, true);
            }

            if(getSessionStorageAppStore().getData().getLandingStateCode().equals(CA)) {
                Log.info("Validating CA state policy start date field value");
                // policy start field should allow up to 30 days in CA
                LocalDate thirtyDaysOut = currentDate.plusDays(30);
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                String formattedThirtyDaysOut = thirtyDaysOut.format(formatter);
                String formattedTomorrow = currentDate.plusDays(1).format(formatter);
                String formattedThirtyOneDaysOut = thirtyDaysOut.plusDays(1).format(formatter);
                String formattedToday = currentDate.format(formatter);

                // error messages validation
                String errorMessage = String.format("To continue with your policy purchase, you must select your policy effective date between %s and %s.", formattedTomorrow, formattedThirtyDaysOut);

                // validate error for today
                sendKeysToElement(policyStartDatePicker, formattedToday);
                sendKeysToElement(policyStartDatePicker, PWKeys.TAB);
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(policyPurchaseDateError)), errorMessage);

                clearOutTheValueInPolicyStartDateField(fsa);

                // validate error for 31 days out
                sendKeysToElement(policyStartDatePicker, formattedThirtyOneDaysOut);
                sendKeysToElement(policyStartDatePicker, PWKeys.TAB);
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(policyPurchaseDateError)), errorMessage);

                // validate no error for tomorrow
                clearOutTheValueInPolicyStartDateField(fsa);
                sendKeysToElement(policyStartDatePicker, formattedTomorrow);
                sendKeysToElement(policyStartDatePicker, PWKeys.TAB);
                fsa.assertFalse(isElementDisplayed(policyPurchaseDateError,1), "Error message should not come up with tomorrow date");

                // validate no error for thirty days out
                clearOutTheValueInPolicyStartDateField(fsa);
                sendKeysToElement(policyStartDatePicker, formattedThirtyDaysOut);
                sendKeysToElement(policyStartDatePicker, PWKeys.TAB);
                fsa.assertFalse(isElementDisplayed(policyPurchaseDateError,1), "Error message should not come up with thirty days out date");

            }
        }
    }

    // Validate scenarios when policy start date is edited manually and validate early shopper discount
    public void validateManuallyEnteredPolicyStartDate(FarmersSoftAssert fsa) throws Exception {
        waitAndClickElement(policyStartDatePicker);
        policyStartDatePicker.sendKeys(PWKeys.chord(PWKeys.BACK_SPACE));
        policyStartDatePicker.sendKeys(PWKeys.chord(PWKeys.TAB));
        validateEarlyShopperDiscount(fsa,false);
        validatePolicyStartDateError(fsa,true);
        validatePolicyPurchaseDateError(fsa, false);

        clearOutTheValueInPolicyStartDateField(fsa);
        waitAndClickElement(policyStartDatePicker);
        sendKeysToElement(policyStartDatePicker,currentDate.minusDays(2).format(dateTimeFormatter));
        policyStartDatePicker.sendKeys(PWKeys.chord(PWKeys.TAB));
        validateEarlyShopperDiscount(fsa,false);
        validatePolicyPurchaseDateError(fsa, true);

        clearOutTheValueInPolicyStartDateField(fsa);
        sendKeysToElement(policyStartDatePicker,currentDate.plusDays(2).format(dateTimeFormatter));
        policyStartDatePicker.sendKeys(PWKeys.chord(PWKeys.TAB));
        validateEarlyShopperDiscount(fsa,false);
        validatePolicyPurchaseDateError(fsa, false);

        clearOutTheValueInPolicyStartDateField(fsa);
        sendKeysToElement(policyStartDatePicker,currentDate.plusWeeks(1).format(dateTimeFormatter));
        policyStartDatePicker.sendKeys(PWKeys.chord(PWKeys.TAB));
        validateEarlyShopperDiscount(fsa,true);
        validatePolicyPurchaseDateError(fsa, false);

        clearOutTheValueInPolicyStartDateField(fsa);
        sendKeysToElement(policyStartDatePicker,currentDate.plusDays(8).format(dateTimeFormatter));
        policyStartDatePicker.sendKeys(PWKeys.chord(PWKeys.TAB));
        validateEarlyShopperDiscount(fsa,true);
        validatePolicyPurchaseDateError(fsa, false);

        clearOutTheValueInPolicyStartDateField(fsa);
        sendKeysToElement(policyStartDatePicker,currentDate.plusMonths(3).format(dateTimeFormatter));
        policyStartDatePicker.sendKeys(PWKeys.chord(PWKeys.TAB));
        validateEarlyShopperDiscount(fsa,false);
        validatePolicyPurchaseDateError(fsa, true);
    }

    public void validatePolicyPurchaseDateError(FarmersSoftAssert fsa, Boolean isVisible) throws Exception {
        if (isVisible) {
    		fsa.assertEquals(policyPurchaseDateError.isDisplayed(), true, "Policy Purchase Date Error displayed");
    		String errorMessage = getSessionStorageAppStore().getData().getLandingStateCode().equals(CA) ? POLICY_PURCHASE_DATE_ERROR.replace(formattedDateAfterTwoMonths, formattedDateAfterAMonth) : POLICY_PURCHASE_DATE_ERROR;
            fsa.assertEquals(getTextFromElement(policyPurchaseDateError), errorMessage, "Policy Purchase Date Error verification");
    	} else {
    		List<PWElement> policyPurchaseDateErrorElement = driver().findElements(PWBy.xpath(POLICY_PURCHASE_DATE_ERROR_XPATH));
    		fsa.assertTrue(policyPurchaseDateErrorElement.isEmpty(), "Policy Purchase Date Error not displayed");
    	}
    }

    public void validatePolicyStartDateError(FarmersSoftAssert fsa, Boolean isVisible) throws Exception {
        if (isVisible) {
            fsa.assertEquals(policyStartDateRequiredMessage.isDisplayed(), true, "Policy Purchase Date Error displayed");
            fsa.assertEquals(getTextFromElement(policyStartDateRequiredMessage), POLICY_START_DATE_REQUIRED_MESSAGE, "Policy Start Date Error verification");
        } else {
            List<PWElement> policyPurchaseDateRequiredErrorElement = driver().findElements(PWBy.xpath(POLICY_START_DATE_REQUIRED_MESSAGE));
            fsa.assertTrue(policyPurchaseDateRequiredErrorElement.isEmpty(), "Policy Start Date Error not displayed");
        }
    }
    public void clearOutTheValueInPolicyStartDateField(FarmersSoftAssert fsa){
        waitAndClickElement(policyStartDatePicker);
        while(!getAttributeData(policyStartDatePicker, VALUE).equals(EMPTY_STRING)){
            policyStartDatePicker.sendKeys(PWKeys.BACK_SPACE);
        }

        policyStartDatePicker.sendKeys(PWKeys.chord(PWKeys.TAB));
        waitElementBeVisible(policyStartDateRequiredMessage);
        fsa.assertEquals(getTextFromElement(policyStartDateRequiredMessage), POLICY_START_DATE_REQUIRED_MESSAGE, "Policy Start Date Required Error Message verification");
    }

    //Verify enabled/disabled scenarios in calender date pop up
    public void verifyDatePickerPopUpValidation(FarmersSoftAssert fsa) throws Exception {
        wait.until(PWExpectedConditions.visibilityOfElementLocated(PWBy.xpath(POLICY_START_DATE_XPATH)));
        LocalDate policyStartDateFromDatePicker = getFormattedDateFromStringDate(getAttributeData(policyStartDatePicker, VALUE));
        wait.until(PWExpectedConditions.visibilityOfElementLocated(PWBy.xpath(DATEPICKER_TOGGLE_ICON_XPATH)));
        fsa.assertEquals(datePickerToggleIcon.isDisplayed(), true, "DatePicker Toggle Icon displayed");
        sleepMillis(5000);
        waitAndClickElement(datePickerToggleIcon);
        sleepMillis(5000);
        fsa.assertEquals(String.valueOf(policyStartDateFromDatePicker.getDayOfMonth()).trim(), getTextFromElement(selectedDateInDatePickerPopUp), "Policy Start Date verification");

        waitAndClickElement(selectedDateInDatePickerPopUp);
        clearOutTheValueInPolicyStartDateField(fsa);
        waitAndClickElement(policyStartDatePicker);
        sendKeysToElement(policyStartDatePicker, formattedTodayDate);
        waitAndClickElement(datePickerToggleIcon);
        if(!isEndOfTheMonthDate(formattedTodayDate)){
            PWElement formattedTodayDateWebElement = driver().findElement(PWBy.xpath("//button[@aria-label=" + "'" + formattedTodayDate + "']"));
            String isTodayDateDisabledInDatePickerPopUp = getAttributeData(formattedTodayDateWebElement, ARIA_DISABLED);
            fsa.assertEquals(isTodayDateDisabledInDatePickerPopUp, "true", "Today's Date enabled In DatePicker PopUp");
        }

        PWElement formattedTomorrowDateWebElement = driver().findElement(PWBy.xpath("//button[@aria-label=" + "'" + formattedTomorrowDate + "']"));
        waitAndClickElement(formattedTomorrowDateWebElement);
    }

    public void waitPolicyStartDateVisible() throws Exception {
        waitElementBeVisible(policyStartDateLabel);
    }

    public boolean isOnAdditionalInfoPage() {
        waitForSpinnerToBeGone();
        return isElementVisible(additionalInfoPageHeader, 20);
    }

    public void waitForAdditionalInfoPageToVisible(int timer) {
        waitForSpinnerToBeGone();
        waitElementBeVisible(justFewMoreThingsLabel, timer);
    }

    public boolean goToAdditionalInfoPageByClickingForwardButton() throws Exception {
        driver().navigate().forward();
        waitElementBeVisible(policyStartDateLabel);
        return isExpectedTextDisplayed(policyStartDateLabel, POLICY_START_DATE_LABEL);
    }

    public boolean goToAdditionalInfoPageByClickingBrowserBackButton() throws Exception {
        driver().navigate().back();
        waitElementBeVisible(policyStartDateLabel);
        return isExpectedTextDisplayed(policyStartDateLabel, POLICY_START_DATE_LABEL);
    }

    public void enterDataAndContinueToPayment(String policyStartDate) {
        enterPolicyStartDate(policyStartDate);
        confirmSignalEnrollment();
        continueToPaymentPage();
    }

    public void continueToPaymentPage() {
        scrollAndClickOnElement(continueToPaymentButton);
        waitForSpinnerToBeGone();
        if (isElementVisible(continueToPaymentButton, 5)) {
            Log.info("Still on Additional Info page after clicking Continue button, reclicking Continue button");
            clickElement(continueToPaymentButton);
        }
    }

    public void enterPolicyStartDate(String policyStartDate) {
        Log.info("Setting policy start date to " + policyStartDate);
        sendKeysToElement(policyStartDatePicker, policyStartDate);
        sendKeysToElement(policyStartDatePicker, PWKeys.TAB);
    }

    public void confirmSignalEnrollment() {
        if (isElementVisible(signalEnrollmentConfirmationCheckbox, 3)) {
            scrollAndClickOnElement(signalEnrollmentConfirmationCheckbox);
        }
    }

    @SneakyThrows
    private void refreshAdditionalInfoPolicyStartDateOneUI() {
        driver().navigate().refresh();
        removeQualtricsPopUp();
    }

    public void fillOutAdditionalInfoPage(boolean clickContinueButton) throws Exception {

        AppStore retrieveQuoteResponseSessionStorage = getSessionStorageAppStore();

        AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoVehicleSectionOneUI.fillOutVehicleSectionAlternative();
        // enter dl number
        additionalInfoDriverSectionOneUI.enterDriverLicenseNumber(retrieveQuoteResponseSessionStorage);
        // fill out race section if required
        additionalInfoDriverSectionOneUI.fillOutDriverInfoSectionForRace();
        // enter mature driver date
        additionalInfoDriverSectionOneUI.enterMatureDriverSafetyCourseDate(retrieveQuoteResponseSessionStorage.getData().getLandingStateCode());
        //enter foreign dl info
        additionalInfoDriverSectionOneUI.enterForeignDriverLicenseDetails();
        // fill out health insurer PIP option
        additionalInfoDriverSectionOneUI.fillOutHealthInsuranceSection("United Healthcare", "UHC123456");
        // fill out signal section
        additionalInfoSignalEnrollmentSectionOneUI.fillOutSignalEnrollmentSection();

        if(isOnBristolWest() && (findIsDistantStudentFromAppStore() || isElementVisible(distantSchoolName,1))){
            scrollElementToMiddle(distantSchoolName);
            sendKeysToElement(distantSchoolName, "Davis College");
            sendKeysToElement(distantSchoolCity, "Pottersville");
            scrollAndClickOnElement(distantSchoolState);
            selectValueInDropDown(distantSchoolState, NY);
            Log.info("Filled out distant student information as part of Bristol West specific requirement");
        }

        if(clickContinueButton) {
            additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();
        }
    }

    public boolean findIsDistantStudentFromAppStore() throws Exception {
        return getSessionStorageAppStore().getAuto().getDrivers().stream().anyMatch(driver -> driver.getDistantStudent() != null && driver.getDistantStudent().equals("Y"));
    }
    public void fillOutAdditionalInfoPage() throws Exception {
    	fillOutAdditionalInfoPage(true);
    }

    public void validateSaveQuoteSideSheet(FarmersSoftAssert fsa) throws Exception {
        Log.info("Selecting Save quote to get Quote number and mailID in Sidesheet ");
        AutoBasePage autoBasePage = new AutoBasePage();
        autoBasePage.clickOnSaveQuoteButton();
        fsa.assertTrue(isElementDisplayed(sidesheet,5),"Side sheet displayed after clicking on Save Quote Button");
    }

    public void validateADA_AdditionalInfoPage() {
        isOnAdditionalInfoPage();
        if(isADATestingEnabled()) {
            performADATesting("AdditionalInfoPage", MARKETING_IT, ACE_AUTO);
        }
    }

    public void validate_AdditionalInfoPage_InvalidData(AutoApplicant applicant) throws Exception {

        AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        additionalInfoDriverSectionOneUI.fillOutInvalidDriverLicenseInputField(applicant);
        additionalInfoVehicleSectionOneUI.fillOutVehicleSection_InvalidDetails();
   }

    public void validate_Brightline_Suspended_RevokedDriversLicense(AutoApplicant applicant) throws Exception {
        AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
        additionalInfoDriverSectionOneUI.fillOutSuspended_RevokedDriverLicenseInputField(applicant);
   }

    public void verifyJFMTPagePrivacyPolicyLinks(FarmersSoftAssert fsa) throws Exception {
        String parentWindow= driver().getWindowHandle();
        waitAndClickElement(privacyPolicyLink);
        Set<String> windowHandles = driver().getWindowHandles();
        Iterator<String> iterator = windowHandles.iterator();
        while (iterator.hasNext()) {
            String childWindow = iterator.next();
            if(!childWindow.equals(parentWindow)){
                driver().switchTo().window(childWindow);
                fsa.assertEquals(driver().getTitle(), "Privacy Center : Farmers Insurance", "Window title verification");
                fsa.assertTrue(isElementDisplayed(privacyCenterHeading,5), "Validating Privacy Center heading");
            }
        }
        driver().switchTo().window(parentWindow);
    }

    public void validateBDQSpecificRequirements(FarmersSoftAssert fsa, AutoApplicant applicant, String preSelectedPolicyStartDate) throws Exception {

        // Validate Policy start date selected in Contact info screen is prefilled correctly in JAFMT screen. User can able to change the Policy start date in JAFMT screen
        fsa.assertEquals(getAutoPolicyStartDateInAutoFewMoreThingsPage(), preSelectedPolicyStartDate, "Policy start date selected on the contact info page is not properly prefilled on the JAFMT page");

        // validate today should be enabled for policy start date
        scrollAndClickOnElement(datePickerToggleIcon);
        LocalDate now = LocalDate.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        String formattedDate = now.format(formatter);
        String previousMonthXpath = "//button[@aria-label='Previous month' and not(contains(@class,'disabled'))]";
        if (isElementPresent(PWBy.xpath(previousMonthXpath), 2)) {
            PWElement previousMonth = driver().findElement(PWBy.xpath(previousMonthXpath));
            waitAndClickElement(previousMonth);
            sleep(1);
        }
        PWElement todayDateFromDatePicker = driver().findElement(PWBy.xpath(String.format("//td//button[contains(@aria-label,'%s')]", formattedDate)));
        fsa.assertTrue(!getAttributeData(todayDateFromDatePicker, CLASS).contains("disabled"), "Today's date enabled for policy start date in BDQ flow on " + this.getClass().getSimpleName());
        waitAndClickElement(datePickerToggleIcon);
        validateValidateAndFooterForBDQ(fsa, applicant, this);
    }

    public void verifyBundleChangesOnAdditionalInfoPageAuto(FarmersSoftAssert fsa, String propertyType){
        String expectedFewMoreThingsPageAutoHeader = "Review and complete auto";
        fsa.assertEquals(getTextFromElement(justFewMoreThingsLabel), expectedFewMoreThingsPageAutoHeader, expectedFewMoreThingsPageAutoHeader + " header text validation");

        String expectedAutoPolicyStartDateHeader = "Auto policy start date";
        fsa.assertEquals(getTextFromElement(policyStartDateLabel), expectedAutoPolicyStartDateHeader, expectedAutoPolicyStartDateHeader + " section header text validation");
        fsa.assertEquals(getTextFromElement(continueButtonAutoFewMoreThingsPageBundle), "Continue", "Continue button text validation");
    }

    public String getAutoPolicyStartDateInAutoFewMoreThingsPage(){
        return getElementValue(policyStartDatePicker, "Auto policy start date:").trim();
    }
}
