package com.farmers.ffq.common.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.List;
@Getter
public enum CoverageNameAceCondo {
    CONDO_COVERAGE_WITH_HOME_SHARING_MINE_SUBSIDENCE(Arrays.asList("Personal property", "Unit owner's building property", "Loss of use (Additional living expense term)", "Personal liability", "Medical payments to others",
            "Mine subsidence", "Increase of loss assessment", "Home sharing business", "Building ordinance or law")),
    CONDO_COVERAGE_WITH_MINE_SUBSIDENCE(Arrays.asList("Personal property", "Unit owner's building property", "Loss of use (Additional living expense term)", "Personal liability", "Medical payments to others",
            "Mine subsidence", "Increase of loss assessment", "Building ordinance or law")),
    CONDO_COVERAGE_WITH_HOME_SHARING(Arrays.asList("Personal property", "Unit owner's building property", "Loss of use (Additional living expense term)", "Personal liability", "Medical payments to others",
            "Increase of loss assessment", "Home sharing business", "Building ordinance or law")),
    CONDO_COVERAGE_WITHOUT_HOME_SHARING_MINE_SUBSIDENCE(Arrays.asList("Personal property", "Unit owner's building property", "Loss of use (Additional living expense term)", "Personal liability", "Medical payments to others",
            "Increase of loss assessment", "Building ordinance or law"));

    private final List<String> coverages;
    CoverageNameAceCondo(List<String> coverages) {
        this.coverages = coverages;
    }
}
