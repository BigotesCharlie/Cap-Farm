package com.farmers.ffq.ace.mobilehome;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.ace.hrc.common.AceHRCAddressBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceMobileHomeAddressPage extends AceHRCAddressBasePage {

	private static final String HOME_IN_MOBILE_PARK_XPATH = "//app-personal-info//div[@id='formField_isInMobileHomePark']";
	private static final String CURRENTLY_INSURED_XPATH = "//app-personal-info//div[@id='formField_isCurrentlyInsured']";

	@PWFindBy (xpath = "//button[contains(@class,'address-form__continue-cta')]")
	private PWElement agreeButton;

	@PWFindBy (xpath = "//app-start-quote-loader")
	private PWElement quoteLoaderPageElement;

	public AceMobileHomeAddressPage() throws Exception {
		super();
	}

	public boolean isOnAddressPage() {
		return isElementPresent(PWBy.xpath(CURRENTLY_INSURED_XPATH), 8);
	}

	public void fillOutPageAndContinue(ApplicantAceHome mobilehomeApplicant) throws Exception {
		if ( !mobilehomeApplicant.getTestCategory().equals(MEDIA_ALPHA) ) {
    		if (!enterGoogleAddress(formFieldAddressInput, mobilehomeApplicant.getAddress(), mobilehomeApplicant.getCity())) {
    			Log.warn("Lookup address failed");
    			PWCapabilities cap = ((PWRemoteDriver) driver()).getCapabilities();
    			String platformName = String.valueOf(cap.getCapability("platformName"));
    			if (platformName.toUpperCase().contains("MAC")) {
    				formFieldAddressInput.sendKeys(PWKeys.COMMAND + "a");
    				sleep(5);
    				formFieldAddressInput.sendKeys(SPACE);
    				sleep(3);
    			} else {
    				formFieldAddressInput.sendKeys(PWKeys.CONTROL + "a");
    				sleep(3);
    			}
    			formFieldAddressInput.sendKeys(PWKeys.DELETE);
    			sleep(3);
    			sendKeysToElement(formFieldAddressInput, mobilehomeApplicant.getAddress());
    			sleep(3);
    			sendKeysToElement(formFieldCityInput, mobilehomeApplicant.getCity());
    		}
		}
		selectPrimaryResidence(mobilehomeApplicant.isPrimaryResidence());
		if (!mobilehomeApplicant.isPrimaryResidence()) {
			selectNotPrimaryResidenceReason(mobilehomeApplicant.getReasonWhyNotPrimaryResidence().toUpperCase());
		}
		selectHomeInMobilePark(mobilehomeApplicant.isInMobilePark());
		selectHomeIsCurrentlyInsured(mobilehomeApplicant.getPreviousInsurance().equals(YES));
		scrollToBottomOfPage();
		scrollAndClickOnElement(agreeButton);
		waitForSpinnerToBeGone();
		waitElementBeInvisible(agreeButton);
	}

	public void verifyPageContent(FarmersSoftAssert fsa, ApplicantAceHome mobilehomeApplicant) throws Exception {
		String testCategory = mobilehomeApplicant.getTestCategory();
		boolean isForemostQuote = testCategory.equals(FOREMOST);
		boolean isForemostAffiliateQuote = testCategory.equals(USAA);
		boolean isAWSQuote = testCategory.equals(AWS_SCENARIOS);
		String activeStep = getActiveStep(testCategory);
		final String ADDRESS_PAGE_TITLE = "What's the address?";
		final String ADDRESS_SECTION_TEXT = "Please enter your %s address.";
		final List<String> NOT_PRIMARY_RESIDENCE_REASONS = List.of("I rent it out", "I use it part time", "Vacant");
		final List<String> NOT_PRIMARY_RESIDENCE_REASONS_SUBTEXT = List.of("My home is or will be occupied by a renter (short or long term)",
				"This home is for seasonal or secondary use", "Unoccupied");
		final String MOBILE_HOME_PARK_TEXT = "Is the home within a mobile home park? Yes No";
		final String CURRENTLY_INSURED_TEXT = "Is the home currently insured? Yes No";

		if (!isForemostQuote) {
			verifyMobileHomeCommonHeader(fsa, isForemostAffiliateQuote);
		}
		fsa.assertEquals(getTextFromElement(addressPageTitle), ADDRESS_PAGE_TITLE, "Address page - Page title.");
		fsa.assertEquals(getTextFromElement(addressSubheading), String.format(ADDRESS_SECTION_TEXT, mobilehomeApplicant.getState()), "Address page - Address section text.");
		fsa.assertEquals(getAttributeData(formFieldAddressManualInput, ARIA_LABEL), "Home Address (No Post Office Boxes)", "Address page - Address field text.");
		fsa.assertEquals(getTextFromElement(formFieldAddressManualInput), EMPTY_STRING, "Address page - Address field is blank.");
		fsa.assertEquals(getAttributeData(formFieldUnitInput, ARIA_LABEL), "Apartment ID", "Address page - Unit # field text.");
		fsa.assertEquals(getTextFromElement(formFieldUnitInput), EMPTY_STRING, "Address page - Unit # field is blank.");
		fsa.assertEquals(getTextFromElement(formFieldCityInput), EMPTY_STRING, "Address page - City field is blank.");
		fsa.assertEquals(getValueFromWebElement(formFieldZipCodeInput), mobilehomeApplicant.getZipCode(), "Address page - Correct Zip code value");
		final String PRIMARY_RESIDENCE_QUESTION_TEXT = "Is this your primary residence?";
		String primaryResidenceContainerText = getTextFromElement(driver().findElement(PWBy.xpath(PRIMARY_RESIDENCE_XPATH)));
		fsa.assertTrue(primaryResidenceContainerText.contains(PRIMARY_RESIDENCE_QUESTION_TEXT), "Address page - Primary Residence question text is displayed.");
		fsa.assertTrue(isPrimaryResidenceSelected(), "Address page - Primary Residence button is selected.");
		fsa.assertTrue(isYesButtonInGroupSelected(HOME_IN_MOBILE_PARK_XPATH), "Address page - Home in mobile park Yes button selected as default");
		fsa.assertTrue(isYesButtonInGroupSelected(CURRENTLY_INSURED_XPATH), "Address page - Currently insured Yes button selected as default");
		selectPrimaryResidence(false);
		List<String> subtextNotPrimaryReasons = driver().findElements(PWBy.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH +
				"//span[contains(@class,'primary-residence-usage__subtext')]")).stream().map(this::getTextFromElement)
				.filter(s -> !s.isBlank()).collect(Collectors.toList());
		fsa.assertEquals(getListOfNotPrimaryResidenceReasons(), NOT_PRIMARY_RESIDENCE_REASONS, "Address page - List of radio buttons for Non-primary reasons.");
		fsa.assertEquals(subtextNotPrimaryReasons, NOT_PRIMARY_RESIDENCE_REASONS_SUBTEXT, "Address page - Not Primary Residence Reasons subtext.");
		fsa.assertEquals(getNotPrimaryResidenceReason(), "RENT", "Address page - Correct default Not Primary Residence Reason selected.");
		PWElement nonPrimaryReasonSection = driver().findElement(PWBy.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH));
		selectPrimaryResidence(true);
		waitElementBeInvisible(nonPrimaryReasonSection);
		fsa.assertTrue(!isElementDisplayed(PWBy.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH)), "Address page - When Home is Primary Residence, Non Primary Reasons should not display.");
		fsa.assertEquals(getTextFromElement(driver().findElement(PWBy.xpath(HOME_IN_MOBILE_PARK_XPATH))), MOBILE_HOME_PARK_TEXT, "Address page - Mobile home park text.");
		fsa.assertEquals(getTextFromElement(driver().findElement(PWBy.xpath(CURRENTLY_INSURED_XPATH))), CURRENTLY_INSURED_TEXT, "Address page - Currently insured text.");
		verifyDisclaimers(fsa, mobilehomeApplicant);
		fsa.assertEquals(getTextFromElement(agreeButton), "Agree", "Address page - CTA button text label");
		validatePageLinksText(fsa, activeStep);
		if (!isForemostAffiliateQuote) {
			validatePageLinksNavigationTitles(fsa);
		}
		validateAgentSectionContent(fsa, isAWSQuote, testCategory);
	}

	private void verifyDisclaimers(FarmersSoftAssert fsa, ApplicantAceHome mobilehomeApplicant) throws Exception {
		String applicantStateCode = mobilehomeApplicant.getStateCode();
		String provider = mobilehomeApplicant.getTestCategory().equals(USAA)? "Foremost" : "Farmers";
		String THE_INSURER_MAY_REVIEW_YOUR_CREDIT_REPORT = "In connection with this application for insurance, the insurer may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. ";
		String THE_INSURER_MAY_USE_A_THIRD_PARTY = "The insurer may use a third"+ (applicantStateCode.equals(TX)? "-" : SPACE) + "party in connection with the development of your insurance"+ (applicantStateCode.equals(VA)? " credit " : SPACE) + "score" + (applicantStateCode.equals(NV)? EMPTY_STRING : PERIOD);
		String WE_MAY_USE_A_THIRD_PARTY = "We may use a third party in connection with the development of your insurance score. ";
		String YOU_MAY_REQUEST_LIFE_EVENT = "You may request re-consideration of an insurance score because of the direct influence of an extraordinary life event on your credit information. ";
		String YOU_MAY_REQUEST_LIFE_CIRCUMSTANCE = "You may request reconsideration of an insurance score because of the direct influence of an extraordinary life circumstance on your credit information. ";
		String PLEASE_HAVE_REPRESENTATIVE_CONTACT_UNDERWRITING_FOR_DETAILS = "Please have your insurance representative contact Underwriting for details on qualifying circumstances and how to request an exception. ";
		String REQUEST_RECEIVED_WITHIN_60_DAYS = "Your request must be received within 60 days " + (applicantStateCode.equals(IA)? "of":"from") + " the date of your application or renewal. ";
		String EXTRAORDINARY_LIFE_CIRCUMSTANCE = "If you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, in writing, that " + (List.of(DE, OK, NH, VT).contains(applicantStateCode)? "the insurer":"we") + " provide reasonable exceptions to "+ (List.of(DE, OK, NH, VT).contains(applicantStateCode)? "its":"our") + " underwriting and/or rating practices. ";
		String EXTRAORDINARY_EVENTS = "An extraordinary life event may include, but is not limited to" + (applicantStateCode.equals(NJ)? COLON : COMMA) + " catastrophic illness or injury; death of a spouse, child or parent; temporary loss of employment; divorce" + (applicantStateCode.equals(NJ)? SEMI_COLON : COMMA) + " identity theft; or military deployment overseas.";

		String creditReportDisclaimer = "//app-personal-info//div[contains(@class,'disclaimer__credit-report')]//p[1]";
		String consumerReportDisclaimer = "//app-personal-info//div[contains(@class,'disclaimer__credit-report')]//p[2]";
		String privacyPolicyDisclaimer = "//app-personal-info//div[contains(@class,'disclaimer__color') and not(@hidden)]";
		String privacyPolicyLink = "//app-personal-info//div[contains(@class,'disclaimer__color')]//a";

		String expectedCreditReportDisclaimer = THE_INSURER_MAY_REVIEW_YOUR_CREDIT_REPORT + THE_INSURER_MAY_USE_A_THIRD_PARTY;
		String expectedConsumerReportDisclaimer = provider + " entities may use any consumer report information their affiliates might currently have for you for your quote request. " +
				"Our Privacy Notice gives you the choice to opt out of allowing " + provider + " affiliates to share your consumer report information among " + provider + " entities. " +
				"You can still opt out of future sharing.";
		String expectedPrivacyPolicyDisclaimer = "By clicking \"Agree\", you acknowledge that you've read and agree to the Privacy Policy and the above consumer report information provisions. " +
				"Otherwise contact a " + provider + "\u00ae representative to discuss options.";

		switch (applicantStateCode) {
			case AK: case CA: case NY:
				expectedCreditReportDisclaimer = expectedConsumerReportDisclaimer;
				expectedConsumerReportDisclaimer = EMPTY_STRING;
				break;
			case CT:
				expectedConsumerReportDisclaimer = "Upon your written request, the insurer shall consider if your credit history has been adversely impacted by an extraordinary life circumstance which occurred within three years before the date of your application. " +
						"If the insurer determines that your credit history has been adversely impacted by such extraordinary life circumstance, the insurer will grant a reasonable exception to our rates, rating classification or underwriting rules for you. " +
						expectedConsumerReportDisclaimer;
				break;
			case DE:
				expectedCreditReportDisclaimer = expectedCreditReportDisclaimer + SPACE +
				"If the insurer does use a credit based score, you will have the right on an annual basis to request that the insurer obtain a current credit report for you and determine whether use of the new credit report would result in a decrease in your insurance premiums. " +
				"If the new credit report that the insurer receives would result in a decrease in your insurance premiums, the insurer will make that reduction. " +
				"If the new credit information would not reduce your insurance premiums, the credit report will not be used to impact your premiums in any way.";
				expectedConsumerReportDisclaimer = EXTRAORDINARY_LIFE_CIRCUMSTANCE + REQUEST_RECEIVED_WITHIN_60_DAYS +
						expectedConsumerReportDisclaimer;
				break;
			case GA:
				expectedCreditReportDisclaimer = expectedCreditReportDisclaimer + " The reunderwriting or rerating of a policy may result in a higher or lower rate.";
				break;
			case IA: case MI:
				expectedConsumerReportDisclaimer = EXTRAORDINARY_LIFE_CIRCUMSTANCE + REQUEST_RECEIVED_WITHIN_60_DAYS +
				"Please contact Underwriting at 1-866-302-4934 for details on qualifying circumstances and how to request an exception" +  (applicantStateCode.equals(IA)? SPACE :PERIOD + SPACE) +
				expectedConsumerReportDisclaimer;
				break;
			case KS:
				expectedCreditReportDisclaimer = expectedCreditReportDisclaimer + SPACE +
				"In the event you dispute any adverse action the insurer takes based on credit information, you may request an appeal of the decision. " +
				"Notify us in writing at Foremost Insurance Group, Attn: Manufactured Home Underwriting, P.O. Box 2047, Grand Rapids, MI 49501.";
				expectedConsumerReportDisclaimer = EXTRAORDINARY_LIFE_CIRCUMSTANCE + REQUEST_RECEIVED_WITHIN_60_DAYS + PLEASE_HAVE_REPRESENTATIVE_CONTACT_UNDERWRITING_FOR_DETAILS +
						expectedConsumerReportDisclaimer;
				break;
			case KY:
				expectedConsumerReportDisclaimer = EXTRAORDINARY_LIFE_CIRCUMSTANCE + REQUEST_RECEIVED_WITHIN_60_DAYS + PLEASE_HAVE_REPRESENTATIVE_CONTACT_UNDERWRITING_FOR_DETAILS +
				expectedConsumerReportDisclaimer;
				break;
			case MA:
				expectedCreditReportDisclaimer = "In Massachusetts, we may use your credit information in order to determine your eligibility for insurance, and not for rating purposes.";
				break;
			case MD:
				expectedCreditReportDisclaimer = "Maryland law provides the company with a 45 day underwriting period beginning on the effective date of your coverage. " +
						"We may cancel your policy during this 45 day underwriting period if the policy does not meet our underwriting standards. In addition, we may recalculate the premium from the effective date of the policy during the underwriting period.";
				break;
			case ME:
				expectedConsumerReportDisclaimer = "The insurer may obtain consumer reports or personal or privileged information from third parties. The information as well as other personal or privileged information subsequently collected by the insurer or your agent may in certain circumstances be disclosed to third parties without authorization, as permitted by law. " +
						"You have the right of access and correction with respect to all personal information collected. At your request, the insurer will provide you with more detailed information regarding the collection, use and disclosure of personal information, and your rights to access and correct such information. " +
						expectedConsumerReportDisclaimer;
				break;
			case MN:
				expectedCreditReportDisclaimer = "In connection with this application for insurance, we will review your credit report or obtain or use a credit score, insurance score or other credit information as part of the underwriting process, except when you are applying for a tenant policy. " +
						WE_MAY_USE_A_THIRD_PARTY +
						"You may qualify for an extraordinary life circumstance exception in the underwriting of your application or rating of your policy. " +
						EXTRAORDINARY_EVENTS;
				break;
			case ND:
				expectedConsumerReportDisclaimer = "The insurer may consider your claims history, or that of any member of your household, in determining whether to decline to write, cancel, nonrenew, or surcharge a policy and we may report any claims made to an insurance support organization. " +
						expectedConsumerReportDisclaimer;
				break;
			case NH:
				expectedCreditReportDisclaimer = expectedCreditReportDisclaimer + SPACE +
				"During the application process, the insurer will obtain your credit report at the time the quote is ordered. " +
				"When credit is ordered on a renewal, the insurer will obtain your credit report approximately 60 days prior to that renewal effective date.";
				expectedConsumerReportDisclaimer = EXTRAORDINARY_LIFE_CIRCUMSTANCE + PLEASE_HAVE_REPRESENTATIVE_CONTACT_UNDERWRITING_FOR_DETAILS +
						"The insurer uses information contained in a consumer report to develop a credit-based insurance score. That score is just one of many factors that are used to underwrite and/or rate your policy " +
						expectedConsumerReportDisclaimer;
				break;
			case NJ :
				expectedCreditReportDisclaimer = "In connection with this application for insurance, we may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. " +
						WE_MAY_USE_A_THIRD_PARTY + YOU_MAY_REQUEST_LIFE_EVENT + EXTRAORDINARY_EVENTS;
				break;
			case NM:
				expectedCreditReportDisclaimer = "In connection with your application for insurance coverage, the insurer may review and use information contained in your credit report to help determine your premium or your eligibility for coverage. " +
						THE_INSURER_MAY_USE_A_THIRD_PARTY;
				break;
			case NV:
				expectedConsumerReportDisclaimer = YOU_MAY_REQUEST_LIFE_CIRCUMSTANCE + REQUEST_RECEIVED_WITHIN_60_DAYS + PLEASE_HAVE_REPRESENTATIVE_CONTACT_UNDERWRITING_FOR_DETAILS +
				expectedConsumerReportDisclaimer;
				break;
			case OK: case VT:
				expectedConsumerReportDisclaimer = EXTRAORDINARY_LIFE_CIRCUMSTANCE + REQUEST_RECEIVED_WITHIN_60_DAYS + PLEASE_HAVE_REPRESENTATIVE_CONTACT_UNDERWRITING_FOR_DETAILS +
				expectedConsumerReportDisclaimer;
				break;
			case OR:
				expectedCreditReportDisclaimer = "In connection with this application for insurance, we may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. " +
						WE_MAY_USE_A_THIRD_PARTY +
						"We use credit risk information because there is statistical evidence showing a correlation between individuals' credit risk information and their insurance risk, or the likelihood that they will become involved in an occurrence or loss. We consider credit risk information to measure insurance risk. " +
						"The credit risk information we consider includes the total number of accounts, use of open accounts, months since most recent delinquency, numbers of collections, and other information. A lack of credit risk information for a person will be considered as neutral insurance risk information as provided by our filing with the Director of the Department of Consumer and Business Services. " +
						"If you have any questions about our consideration of credit risk information you may contact Foremost at: 866-302-4934.";
				break;
			case TX:
				expectedCreditReportDisclaimer = "The insurer will obtain and use credit information on you or any other member(s) of your household as part of the insurance credit scoring process (N/A Tenant, Landlord/Rental, Vacation/Short-term Rental). " +
						THE_INSURER_MAY_USE_A_THIRD_PARTY;
				break;
			case VA:
				expectedCreditReportDisclaimer = "In connection with this application for insurance, the insurer shall review your credit report or obtain or use an insurance credit score based on the information contained in that credit report. " +
						THE_INSURER_MAY_USE_A_THIRD_PARTY + SPACE +
						"You may request that your credit information be updated and if you question the accuracy of the credit information, the insurer will, upon your request, reevaluate you based on corrected credit information from a consumer reporting agency";
				break;
			case WV:
				expectedCreditReportDisclaimer = "Unless you are applying for a tenant policy, your credit information is used by the company to produce an insurance score. " +
						"This insurance score has an effect on the premium that you pay for your insurance. The company is required by the Insurance Commissioner to recheck your credit information no less than once every 36 months for changes. " +
						"You have the option to request that the company recheck your insurance score more frequently than once every 36 months, but you can only make this request once during any twelve month period. " +
						"If there has been a change in your insurance score, the company shall re-underwrite and re-rate the policy based upon the current credit report or insurance score. " +
						"The change in your insurance score may result in an increase or a decrease in the premium that you pay for your insurance. " +
						"Any changes in your premium will take place upon renewal if your request is made at least 45 days before your renewal. " +
						"If the request is made less than 45 days before your renewal date, the insurer shall re-underwrite and re-rate the policy for the following renewal.";
				break;
			default:
				break;
		}

		fsa.assertEquals(getTextFromElement(driver().findElement(PWBy.xpath(creditReportDisclaimer))), expectedCreditReportDisclaimer, "Address page - Credit report disclaimer for " + applicantStateCode);
		fsa.assertEquals(getTextFromElement(driver().findElement(PWBy.xpath(consumerReportDisclaimer))), expectedConsumerReportDisclaimer, "Address page - Consumer report disclaimer for " + applicantStateCode);
		fsa.assertEquals(getTextFromElement(driver().findElement(PWBy.xpath(privacyPolicyDisclaimer))), expectedPrivacyPolicyDisclaimer, "Address page - Privacy Policy disclaimer for " + applicantStateCode);
		fsa.assertEquals(getTextFromElement(driver().findElement(PWBy.xpath(privacyPolicyLink))), "Privacy Policy", "Address page - Privacy Policy link label");
		fsa.assertTrue(getAttributeData(driver().findElement(PWBy.xpath(privacyPolicyLink)), HREF).contains("https://www.farmers.com/privacy-center/"), "Address page - Privacy Policy link contains expected url.");
	}

	private void selectHomeInMobilePark(boolean inMobilePark) {
		selectGroupButton(HOME_IN_MOBILE_PARK_XPATH, inMobilePark);
	}

	private void selectHomeIsCurrentlyInsured(boolean currentlyInsured) {
		selectGroupButton(CURRENTLY_INSURED_XPATH, currentlyInsured);
	}

	private boolean isYesButtonInGroupSelected(String groupXpath) throws Exception {
		return isButtonSelected(driver().findElement(PWBy.xpath(groupXpath + "//button[contains(., 'Yes')]")));
	}

	private void selectGroupButton(String xpathToGroup, boolean pickYes){
		String buttonXpath = pickYes? "//button[contains(., 'Yes')]" : "//button[contains(., 'No')]";
		try {
			PWElement buttonElement;
			buttonElement = driver().findElement(PWBy.xpath(xpathToGroup + buttonXpath));
			scrollAndClickOnElement(buttonElement);
		} catch (PWTimeoutException toe) {
			Log.warn("Element " + xpathToGroup + buttonXpath + " not found");
		} catch (Exception e) {
			Log.error(e.toString());
		}
	}

	public void waitForQuoteLoaderToBeGone() {
		if (isElementVisible(quoteLoaderPageElement, 2)) {
			waitElementBeInvisible(quoteLoaderPageElement);
		}
	}
}
