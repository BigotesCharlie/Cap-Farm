package com.farmers.ffq.auto.pages.bw;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
public class BristolWestAdditionalDiscountsPage extends AutoBasePage {

    @PWFindBy(xpath = "//app-additional-discounts//h1")
    private PWElement pageHeader;

    @PWFindBy(xpath = "//app-additional-discounts//h1/../p")
    private PWElement pageSubheader;

    @PWFindBy(xpath = "//app-additional-discounts//h1/../div[1]")
    private PWElement otherPolicyGroupLabel;

    @PWFindBy(id = "RADIO_BUTTON_FOR_H")
    private PWElement homeownerPolicyRadioButton;
    
    @PWFindBy(xpath = "//label[contains (@for, 'RADIO_BUTTON_FOR_H')]")
    private PWElement homeownerPolicyRadioButtonLabel;
    
    @PWFindBy(id = "RADIO_BUTTON_FOR_M")
    private PWElement mobileHomeownerPolicyRadioButton;

    @PWFindBy(xpath = "//label[contains (@for, 'RADIO_BUTTON_FOR_M')]")
    private PWElement mobileHomeownerPolicyRadioButtonLabel;

    @PWFindBy(id = "RADIO_BUTTON_FOR_R")
    private PWElement rentersPolicyRadioButton;

    @PWFindBy(xpath = "//label[contains (@for, 'RADIO_BUTTON_FOR_R')]")
    private PWElement rentersPolicyRadioButtonLabel;

    @PWFindBy(id = "RADIO_BUTTON_FOR_N")
    private PWElement noPolicyRadioButton;

    @PWFindBy(xpath = "//label[contains (@for, 'RADIO_BUTTON_FOR_N')]")
    private PWElement noPolicyRadioButtonLabel;

    @PWFindBy(xpath = "//app-additional-discounts//h1/../div[2]")
    private PWElement otherPeopleInHouseholdLabel;

    @PWFindBy(id = "SHOW_HOUSEHOLD_COUNT_YES")
    private PWElement otherPeopleLivingInHouseholdButton;
    
    @PWFindBy(id = "SHOW_HOUSEHOLD_COUNT_NO")
    private PWElement noOtherPeopleLivingInHouseholdButton;
    
    @PWFindBy(id = "CONTINUE_CTA")
    private PWElement continueButton;
    
    public BristolWestAdditionalDiscountsPage() throws Exception {
    	super();
	}

    public boolean isOnBristolWestAdditionalDiscountsPage() {
    	return isElementPresent(PWBy.id("CONTINUE_CTA"), 3);
    }

    public QuoteSummaryAutoPage clickContinue() throws Exception {
    	scrollAndClickOnElement(continueButton);
    	waitForSpinnerToBeGone();
    	return new QuoteSummaryAutoPage();
    }    
}
