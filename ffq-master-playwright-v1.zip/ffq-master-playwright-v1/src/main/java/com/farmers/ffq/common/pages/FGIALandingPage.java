package com.farmers.ffq.common.pages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.utils.FarmersSoftAssert;

import com.farmers.framework.report.Log;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class FGIALandingPage extends AceHRCBasePage {

    @PWFindBy(xpath = "//app-fgia-page//a[contains(.,'No, thanks')]")
    PWElement noThanksButtonInFgiaPage;
    @PWFindBy(xpath = "//app-fgia-popup//*[@role='heading']")
    PWElement fgiaPopupHeader;
    @PWFindBy(xpath = "//app-fgia-popup//mat-dialog-content//div[@id='dnqMessage']")
    PWElement fgiaPopUpDescription;
    @PWFindBy(xpath = "//app-fgia-popup//a[contains(.,'No, thanks')]")
    PWElement noThanksButtonInFgiaPopup;
    @PWFindBy(xpath = "//app-fgia-popup//button[contains(.,'Continue to FGIA')]")
    PWElement continueButtonInFgiaPopup;
    @PWFindBy(xpath = "//app-fgia-page//h1")
    PWElement fgiaPageHeader;
    @PWFindBy(xpath = "//app-fgia-page//div[contains(@class,'fgia-page-rebrand-container')]")
    PWElement fgiaPageDescription;
    @PWFindBy(xpath = "//div[contains(@class,'fgia-rebrand-cta-section')]//a")
    PWElement callToFgiaPageButton;
    @PWFindBy(xpath = "//app-fgia-popup//button[contains(@class, 'info-dialog-button-no-thank')]")
    PWElement callToFgiaPopupButton;
    @PWFindBy(xpath = "//div[contains(@class,'fgia-rebrand-cta-section')]//button")
    PWElement continueButtonInFgiaPage;

    @PWFindBy(xpath = "//h1[@id='knockout_title']")
    PWElement weAreNotAbleToCompleteQuoteTitle;
    @PWFindBy(xpath = "//app-knockout//p")
    PWElement findExperiencedAgent;
    @PWFindBy(xpath = "//div[@id='mediaAlpha']")
    PWElement otherInsuranceOfferingCompanies;
    @PWFindBy(xpath = "//div[contains(@class, 'knockout__toll-free-monetization')]")
    PWElement tollFreeMonetizationSection;
    @PWFindBy(xpath = "//section[@id='pg_intro']")
    PWElement fgiaIntroPage;

    @PWFindBy(xpath="//div[@id='quote_unavailable-header_ffq-logo']")
    PWElement farmersLogo;
    @PWFindBy(xpath = "//div[@class='quote_blocked_header-title']/h2")
    PWElement unableToProvideQuoteTitle;
    @PWFindBy(xpath = "//div[contains(text(),'find an experienced Farmers agent')]")
    PWElement findExperiencedAgentText;
    @PWFindBy(xpath = "//div[contains(text(),'other options')]")
    PWElement otherOptionsText;
    @PWFindBy(xpath = "//div[contains(@class,'local-insurance-provier-list')]")
    PWElement otherInsuranceCompaniesList;
    @PWFindBy(xpath = "//span[@class='find_agent_text']")
    PWElement findAnAgentButton;
    @PWFindBy(xpath = "//div[text()=' Need more help?']")
    PWElement needMoreHelpText;
    private static final String FGIA_PAGE_HEADER = "It's not you. It's us";
    private static final String FGIA_PAGE_HEADER_2 = "We are unable to complete your request at this time";
    private static final String FGIA_POPUP_SUB_HEADER = "We are unable to offer you an online quote for a Farmers-branded policy at this time. Farmers General Insurance Agency, Inc. (FGIA) may be able to offer you a quote through other companies, or you can contact a Farmers agent in your area.";
    private static final String EXPECTED_INTERMEDIATE_PAGE_TITLE = "We're sorry, but we are unable to provide an online quote at this time.";
    private static final String EXPECTED_FIND_AGENT_TEXT = "Please find an experienced Farmers agent in your area for a quote, or";
    private static final String EXPECTED_OTHER_OPTIONS_TEXT = "Click below for other options";
    private static final String EXPECTED_MONETIZED_KNOCKOUT_PAGE_HEADER = "Thank you for your interest in Farmers Insurance\u00ae";
    private static final String EXPECTED_MONETIZED_KNOCKOUT_PAGE_SUB_HEADER = "We apologize for the inconvenience. Please try again later. In the meantime, the following companies may be able to provide you with an online quote. Please compare 2 or more of the following options.";
    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public FGIALandingPage() throws Exception {
    }

    public void validateContentOfFGIAPopUp(FarmersSoftAssert fsa, String lobType) throws Exception {
        String separator = isSafariBrowser() ? EMPTY_STRING : SPACE;
        String FGIA_PAGE_SUB_HEADER = "It's not you. It's us. You're still on your way to new coverage. We think you're great. " +
                "We just can't offer you a Farmers® quote right now. Why? It could be your location. It could be risk related. It could be something " +
                "out of our hands.The good news is that we can still help you find coverage today. Let us introduce you to another member of the Farmers " +
                "family: Farmers General Insurance Agency. Call them today and get multiple quotes and prices from other insurance brands." + separator +
                "Sound good?" + separator + "Tap below now to continue." + separator + "Continue" +separator + "or" + separator + "local_phone" + separator + CALL_FARMERS;
        waitForPageToBeReady();
        fsa.assertTrue(driver().getCurrentUrl().contains("interstitial"), "FGIA intermediate page validation - " + lobType);
        if (!isElementDisplayed(fgiaPopupHeader, 3)) {
            String fgiaPageHeaderText = getTextFromElement(fgiaPageHeader);
            Log.info("FGIA page - header found: " + fgiaPageHeaderText);
            fsa.assertTrue(fgiaPageHeaderText.equals(FGIA_PAGE_HEADER + PERIOD) ||
                    fgiaPageHeaderText.equals(FGIA_PAGE_HEADER_2 + PERIOD), "FGIA page - header validation (one of the 2 values)- " + lobType);
            fsa.assertEquals(getTextFromElement(fgiaPageDescription), FGIA_PAGE_SUB_HEADER, "FGIA page - description validation - " + lobType);
            if(!isElementDisplayed(callToFgiaPageButton, 3)) {
                fsa.assertTrue(isElementDisplayed(noThanksButtonInFgiaPage,3), "FGIA page - no thanks button validation - " + lobType);
            }
            fsa.assertTrue(isElementDisplayed(continueButtonInFgiaPage, 3), "FGIA page - continue to fgia button validation - " + lobType);
        } else {
            String fgiaPageHeaderText = getTextFromElement(fgiaPopupHeader);
            String fgiaPageSubHeaderText = getTextFromElement(fgiaPopUpDescription);
            fsa.assertTrue(fgiaPageHeaderText.equals(FGIA_PAGE_HEADER) ||
                    fgiaPageHeaderText.equals(FGIA_PAGE_HEADER_2), "FGIA popup - header validation (one of the 2 values)- " + lobType);
            fsa.assertTrue(fgiaPageSubHeaderText.equals(FGIA_POPUP_SUB_HEADER) ||
                            fgiaPageSubHeaderText.equals(FGIA_PAGE_SUB_HEADER), "FGIA popup - description validation - " + lobType);
            if(!isElementDisplayed(callToFgiaPopupButton, 3)) {
                fsa.assertTrue(isElementDisplayed(noThanksButtonInFgiaPopup, 3), "FGIA popup - no thanks button validation - " + lobType);
            }
            fsa.assertTrue(isElementDisplayed(continueButtonInFgiaPopup, 3), "FGIA popup - continue to fgia button validation - " + lobType);
        }
    }

    public void clickNoThanksButtonInFGIAPopUp(){
        if (isElementDisplayed(noThanksButtonInFgiaPopup, 3)) {
            waitAndClickElement(noThanksButtonInFgiaPopup);
        } else {
            waitAndClickElement(noThanksButtonInFgiaPage);
        }
    }

    public boolean isFgiaNoThanksButtonDisplayed() {
        return isElementDisplayed(noThanksButtonInFgiaPage, 3) || isElementDisplayed(noThanksButtonInFgiaPopup, 3);
    }

    public void clickContinueButtonInFGIAPopUp(){
        if (isElementDisplayed(continueButtonInFgiaPopup, 3)) {
            waitAndClickElement(continueButtonInFgiaPopup);
        } else {
            waitAndClickElement(continueButtonInFgiaPage);
        }
    }

    public void weAreNotAbleToCompleteQuotePageValidation(FarmersSoftAssert fsa, String lobType){
        waitForPageToBeReady();
        final String EXPECTED_WE_ARE_NOT_ABLE_TO_COMPLETE_QUOTE_HEADER = "We aren't able to complete your Farmers Fast Quote at this time.";
        fsa.assertEquals(getTextFromElement(weAreNotAbleToCompleteQuoteTitle), EXPECTED_WE_ARE_NOT_ABLE_TO_COMPLETE_QUOTE_HEADER, "Not able to complete Farmers fast quote title - " + lobType);
        final String EXPECTED_FIND_AGENT_NEAR_YOU = "Please find an experienced Farmers agent in your area for a quote, or, click below for other options.";
        fsa.assertEquals(getTextFromElement(findExperiencedAgent), EXPECTED_FIND_AGENT_NEAR_YOU, "Find experienced agent near you validation - " + lobType);
        fsa.assertTrue(otherInsuranceOfferingCompanies.isDisplayed(), "Other insurance offering validation - " + lobType);
        fsa.assertTrue(tollFreeMonetizationSection.isDisplayed(), " Toll free monetization section validation - " + lobType);
    }

    public void monetizedStateDirectKnockoutPageValidation(FarmersSoftAssert fsa, String lobType){
        waitForPageToBeReady();
        fsa.assertEquals(getTextFromElement(weAreNotAbleToCompleteQuoteTitle), EXPECTED_MONETIZED_KNOCKOUT_PAGE_HEADER, "Monetized state knockout page title not matching - " + lobType);
        fsa.assertEquals(getTextFromElement(findExperiencedAgent), EXPECTED_MONETIZED_KNOCKOUT_PAGE_SUB_HEADER, "Monetized state knockout page sub-title not matching - " + lobType);
        fsa.assertTrue(otherInsuranceOfferingCompanies.isDisplayed(), "Other insurance offering validation - " + lobType);
        fsa.assertTrue(tollFreeMonetizationSection.isDisplayed(), " Toll free monetization section validation - " + lobType);
    }
    public void fgiaIntroPageValidation(FarmersSoftAssert fsa, String lobType) throws Exception {
        waitForPageToBeReady();
        fsa.assertTrue(driver().getCurrentUrl().contains("farmersgeneralinsuranceagency"), "FGIA landing page url validation - " + lobType);
        fsa.assertTrue(fgiaIntroPage.isDisplayed(), "FGIA intro page is displayed - " + lobType);
    }

    public void otherCompaniesDigitalMonetizationPageValidation(FarmersSoftAssert fsa, String lobType){
        waitForPageToBeReady();
        fsa.assertTrue(isElementDisplayed(farmersLogo, 5), "Farmers logo displayed - " + lobType);
        fsa.assertEquals(getTextFromElement(unableToProvideQuoteTitle), EXPECTED_INTERMEDIATE_PAGE_TITLE, "Digital Monetization intermediate page title not matching - " + lobType);
        fsa.assertEquals(getTextFromElement(findExperiencedAgentText), EXPECTED_FIND_AGENT_TEXT, "Digital Monetization intermediate page find agent text not matching - " + lobType);
        fsa.assertEquals(getTextFromElement(otherOptionsText), EXPECTED_OTHER_OPTIONS_TEXT, "Digital Monetization intermediate page other options text not matching - " + lobType);
        fsa.assertTrue(isElementDisplayed(otherInsuranceCompaniesList, 5), "Other insurance offering validation - " + lobType);
        fsa.assertTrue(isElementDisplayed(needMoreHelpText, 5), "Need more help question is displayed - " + lobType);
        fsa.assertTrue(isElementDisplayed(findAnAgentButton, 5), "Find an agent button is displayed - " + lobType);
    }
}
