package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.framework.report.Log;
import com.farmers.ffq.utils.FarmersSoftAssert;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class FarmersGroupSelectPage extends AutoBasePage {

    @PWFindBy(xpath = "//div[@class='fws-page-container']//h1")
    private PWElement farmersGroupSelectPageTitle;

    @PWFindBy(className = "landing-text")
    private PWElement farmersGroupSelectPageDescription;

    @PWFindBy(xpath = "//div[@class='container']//p/span[@class='small-text']")
    private PWElement farmersGroupSelectPageDisclaimer;

    @PWFindBy(xpath = "//p/a[contains(@href,'tel:')]")
    private PWElement headerPhoneNumberLink;

    @PWFindBy(xpath = "//a[contains(@class, 'button-cta--desktop')][contains(@href,'tel:')]")
    private PWElement callNowButton;

    @PWFindBy(xpath = "//a[contains(@class, 'button-cta--desktop')][@data-gtm='Farmers_COLPGS_FFQLINK_Header']")
    private PWElement quoteWithFarmersOnlineLink;

    @PWFindBy(id = "employerdiv")
    private PWElement employerGroupAffinity;

    @PWFindBy(xpath = "//div[@class='tui-info-box-content mt-8']//p")
    private PWElement pageContent;
    //TODO: camelCase

    @PWFindBy(id = "fws-page-employer-img-container")
    private PWElement imageContainer;

    @PWFindBy(id = "whereYouWork")
    private PWElement whereYouWorkContext;

    @PWFindBy(xpath = "//input[@id='mat-input-fwsField']")
    private PWElement employerSelectDropdown;

    @PWFindBy(id = "cardMessage")
    private PWElement cardMessage;

    @PWFindBy(id = "cardErrorMessage")
    private PWElement cardErrorMessage;

    @PWFindBy(id = "cardSuccessMessage")
    private PWElement cardSuccessMessage;

    @PWFindBy(xpath = "//div[@class='fgs_employer-card-success_title tui-body-bold']")
    private PWElement farmersGroupSelectBenefitsTitle;

    @PWFindBy(xpath = "//span[@class='fgs_employer-card-success_desc']//li")
    private List<PWElement> discountDescriptions;


    @PWFindBy(xpath = "//span[@id='disclaimer']")
    private PWElement disclaimerContent;

    @PWFindBy(xpath = "//button[contains(text(),'Continue')]")
    private PWElement continueWithDiscountButton;

    @PWFindBy(xpath = "//a[contains(text(),' Skip this discount ')]")
    private PWElement skipThisDiscountButton;

    @PWFindBy(xpath = "//span[@class='selected-indicator']/preceding-sibling::span")
    private PWElement selectedInsuranceType;

    public static final String DROPDOWN_OPTIONS_XPATH = "//mat-option//span";


    private static final String DROPDOWN_DESCRIPTION = "Save money based on where you work, or the groups you belong to.";

    private static final String PAGE_CONTENT = "Affiliated employers, memberships, and credit unions may qualify for a discount through Farmers GroupSelect\u00AE.";
    private static final String VALID_EMPLOYEE_GROUP = "BANK OF AMERICA";

    private static final String INVALID_EMPLOYEE_GROUP = "DFAAR";

    private static final String DISCLAIMER_CONTENT = "*Savings based on average nationwide annual savings in 2022 reported by new customers who called the Farmers GroupSelect call center, switched to Farmers\u00AE branded auto insurance policies issued by Farmers GroupSelect's program, and realized savings. Potential savings vary by customer and may vary by state and product. Statistics don't reflect products sold on Agent360â„ .";

    public FarmersGroupSelectPage() throws Exception {
    }

    public boolean isOnFarmersGroupSelectSideSheet() {
        return isElementVisible(headerPhoneNumberLink, 5);
    }

    public boolean isOnFarmersGroupSelectPage() {
        return isElementVisible(farmersGroupSelectPageTitle, 5);
    }

    public boolean quoteWithFarmersInsuranceOnline() {
        if (isOnFarmersGroupSelectSideSheet()) {
            scrollAndClickOnElement(quoteWithFarmersOnlineLink);
            return true;
        } else {
            return false;
        }
    }

    public void validateFWSPage(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isOnFarmersGroupSelectPage(), "User is on " + this.getClass().getSimpleName());
        fsa.assertEquals(getTextFromElement(farmersGroupSelectPageTitle), "Let's check for a discount", "Red States FGS page header validation ");
        fsa.assertEquals(getTextFromElement(employerGroupAffinity), "Employer/group affinity", "Red States FGS page employer group affinity text validation ");
        fsa.assertEquals(getTextFromElement(pageContent), PAGE_CONTENT, "Red States FGS page description validation ");
        fsa.assertTrue(isElementDisplayed(imageContainer, 10), "FGS Page Content Image is displayed");
        fsa.assertEquals(getTextFromElement(whereYouWorkContext), DROPDOWN_DESCRIPTION, "Asking User to Enter the Employer/Group name ");
        fsa.assertTrue(isElementDisplayed(employerSelectDropdown, 10), "Employer/Group Dropdown Validation");

        // validate invalid group employer
        sendKeysToElement(employerSelectDropdown, "DF");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(cardErrorMessage)), "Members of this group are not eligible for our affinity discounts. Try another employer or group, or continue your quote and we'll look for other discounts for you.", "Invalid employer group message");

        // valid employer validation
        selectByValueWithGivenText(employerSelectDropdown, DROPDOWN_OPTIONS_XPATH, VALID_EMPLOYEE_GROUP);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(cardSuccessMessage)), "Good news! Discounts are available for members of this group. We'll ask you to verify your eligibility in a bit.", "Employer group selection success message validation");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(farmersGroupSelectBenefitsTitle)), "Farmers GroupSelect benefits", "Employer group selection benefits title validation");

        List<String> expectedBenefitsDescriptions = Arrays.asList("Others have saved 23%* on average by switching their auto insurance", "By bundling policies, you could save even more", "Get special employee or association member discounts");
        List<String> actualBenefits = discountDescriptions.stream().map(this::getTextFromElement).collect(Collectors.toList());

        Collections.sort(expectedBenefitsDescriptions);
        Collections.sort(actualBenefits);
        Log.info("actual benefits" + actualBenefits);
        Log.info("expected benefits" + expectedBenefitsDescriptions);
        fsa.assertEquals(actualBenefits, expectedBenefitsDescriptions, "Benefits description validation  " + this.getClass().getSimpleName());

        fsa.assertTrue(continueWithDiscountButton.isEnabled() && continueWithDiscountButton.isDisplayed(), "'Continue' button is displayed and enabled");
        fsa.assertTrue(skipThisDiscountButton.isEnabled() && skipThisDiscountButton.isDisplayed(), "'Skip this Discount' button is displayed and enabled");
    }

    public void processFarmersGroupSelectPage(boolean continueWithDiscount) {
        if (continueWithDiscount) {
            selectByValueWithGivenText(employerSelectDropdown, DROPDOWN_OPTIONS_XPATH, "bank of bluffs");
            sleep(1);
            waitAndClickElement(continueWithDiscountButton);
            waitForSpinnerToBeGone();
        } else {
            waitAndClickElement(skipThisDiscountButton);
        }
    }

    public void invalidEmployeeGroup() {
        sleep(10);
        sendKeysToElement(employerSelectDropdown, INVALID_EMPLOYEE_GROUP);
        sleep(10);
        waitAndClickElement(continueWithDiscountButton);

    }

    protected void selectByValueWithGivenText(PWElement dropdown, String xpath, String value) {
        sendKeysToElement(dropdown, value.substring(0, value.length() - 1));
        wait.until(PWExpectedConditions.numberOfElementsToBeMoreThan(PWBy.xpath(xpath), 1));
        sendKeysToElement(dropdown, PWKeys.ARROW_DOWN);
        sendKeysToElement(dropdown, PWKeys.ENTER);
    }

    public void validateSelectedInsuranceType(FarmersSoftAssert fsa) throws Exception {
        String currentUrl = driver().getCurrentUrl();
        String EXPECTED_DOMAIN = "farmersinsurancechoice.com";
        fsa.assertTrue(currentUrl.contains(EXPECTED_DOMAIN), "Current URL does not contain expected domain. Current URL: " + currentUrl);
        fsa.assertEquals(getTextFromElement(selectedInsuranceType), "Auto", "Selected insurance type is not as expected on bindable choice page.");
    }

}
