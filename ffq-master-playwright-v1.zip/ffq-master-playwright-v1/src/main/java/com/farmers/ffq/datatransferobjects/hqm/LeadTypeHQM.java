package com.farmers.ffq.datatransferobjects.hqm;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.lang.reflect.Field;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter @Setter
public class LeadTypeHQM {
    @JsonProperty("First_Name")
    private String firstName;
    @JsonProperty("Last_Name")
    private String lastName;
    @JsonProperty("DOB")
    private String dob;
    @JsonProperty("Gender")
    private String gender;
    @JsonIgnore
    @JsonProperty("MaritalStatus")
    private String maritalStatus;
    @JsonProperty("Street")
    private String street;
    @JsonProperty("City")
    private String city;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("Phone")
    private String phone;
    @JsonProperty("Zip_Code")
    private String zipCode;
    @JsonProperty("Source_Indicator")
    private String sourceIndicator;
    @JsonProperty("SourceID")
    private String sourceId;
    @JsonIgnore
    private String agentId;
    @JsonIgnore
    private String campaignId;
    @JsonIgnore
    @JsonProperty("LeadType")
    private String leadType;

    public LeadTypeHQM (ApplicantHQM applicant, String leadType) {
        switch (leadType) {
            case QQ:
            case QQNPS:
                this.firstName = applicant.firstName;
                this.lastName = applicant.lastName;
                String dateOfBirth = applicant.dateOfBirth;
                this.dob = dateOfBirth.split("/")[2] + "-" + dateOfBirth.split("/")[0] + "-" + dateOfBirth.split("/")[1];
                this.maritalStatus = applicant.maritalStatus.equalsIgnoreCase("married") ? applicant.maritalStatus : "SINGLE";
                this.street = applicant.addressApt;
                this.city = applicant.city;
                this.email = applicant.emailAddress;
                this.phone = applicant.phoneNumber;
                this.zipCode = applicant.zipCode;
                this.sourceIndicator = QQ;
                this.sourceId = QQ;
                this.leadType = leadType;
                break;
            case AS:
            case FC:
            case RQ:
            case MOBILE_BROWSER:
                this.sourceIndicator = leadType;
                this.sourceId = leadType;
                this.leadType = leadType;
                this.agentId = applicant.agentId;
                break;
            case AEM:
                this.sourceIndicator = leadType;
                this.sourceId = leadType;
                this.leadType = leadType;
                this.campaignId = applicant.campaignId;
                break;
            case CW:
            case MB:
                this.firstName = applicant.firstName;
                this.lastName = applicant.lastName;
                this.dob = applicant.dateOfBirth;
                this.gender = applicant.gender;
                this.street = applicant.addressApt;
                this.city = applicant.city;
                this.zipCode = applicant.zipCode;
                this.email = applicant.emailAddress;
                this.phone = applicant.phoneNumber;
                this.sourceId = leadType + "000000001";
                this.sourceIndicator = leadType;
                this.leadType = leadType;
                break;
            default:
                throw new IllegalStateException("Unexpected leadType value: " + leadType);
        }

    }

    public LeadTypeHQM (ApplicantHQM applicant, String leadType, String missingFields) throws NoSuchFieldException, IllegalAccessException {
        this(applicant, leadType);
        if (leadType.equals(QQ)) {
//          process empty fields
            for (String blankField: missingFields.split(",")) {
                Field field = this.getClass().getDeclaredField(blankField.split("_")[1].trim());
                field.set(this, "");
            }
        }
    }
}
