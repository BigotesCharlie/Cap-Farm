package com.farmers.ffq.auto.pages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class SignalPageOneUI extends AutoBasePage {
	@PWFindBy(xpath = "//div[@class='signal-container content-wrapper']//h1")
	private PWElement signalPageHeader;

	@PWFindBy(xpath = "//*[contains(@class, 'sec-title')]")
	private PWElement signalPageSubheader;

	@PWFindBy(xpath = "//img[@class='signal-mobile-image'][1]")
	private PWElement tripDirectionImage;

	@PWFindBy(xpath = "//img[@class='signal-mobile-image'][2]")
	private PWElement drivingBehaviourImage;

	@PWFindBy(xpath = "//*[@class='signal-container content-wrapper']//li[1]")
	private PWElement saveTodayLabel;

	@PWFindBy(xpath = "//*[@class='signal-container content-wrapper']//li[2]")
	private PWElement saveAtRenewalLabel;

	@PWFindBy(xpath = "//*[@class='signal-container content-wrapper']//li[3]")
	private PWElement saveAtRenewalWhenYoungDriverLabel;

	@PWFindBy(xpath = "//button[@data-test-id='FIND_OUT_MORE_BUTTON']")
	private PWElement findOutMoreLink;

	private static final String ADD_SIGNAL_BUTTON_XPATH = "//button[@data-test-id='ADD_SIGNAL_AND_SAVE_BUTTON']";
	@PWFindBy(xpath = ADD_SIGNAL_BUTTON_XPATH)
	private PWElement addSignalButton;

	@PWFindBy(xpath = "//button[@data-test-id='NOT_NOW_BUTTON']")
	private PWElement notNowButton;

	@PWFindBy(xpath = "//*[contains(@class, 'row disclosure')]")
	private PWElement signalPageDisclaimer;

	@PWFindBy(xpath = "//button[@data-gtm='FFQ_Auto_Signal_Discount_next_button']")
	private PWElement nextToMoreDiscountsButton;

	private static final String SIGNAL_PAGE_HEADER_TEXT = "Get rewarded for driving safely";
	private static final String SIGNAL_PAGE_SUBHEADER_TEXT = "Safe drivers can save with an initial Signal discount!*";
	private static final String SIGNAL_PAGE_SUBHEADER_TEXT_WITH_REGTRADEMARK = "Safe drivers can save with an initial Signal\u00ae discount!*";
	private static final String SAVE_5PCT_TODAY_TEXT = "Save 5% today with an initial Signal discount for enrolling, downloading, and using our Signal app";
	private static final String SAVE_10PCT_TODAY_TEXT = "Save 10% today with an initial Signal discount for enrolling, downloading, and using our Signal app";
	private static final String SAVE_UPTO_10PCT_TODAY_TEXT = "Save up to 10% today with an initial Signal discount when all eligible drivers enroll, download, and using our Signal app";
	private static final String SAVE_UPTO_10PCT_TODAY_TEXT_2 = "Save up to 10% today with an initial Signal discount for enrolling, downloading, and using the Signal app.";
	private static final String SAVE_UPTO_10PCT_TODAY_TEXT_WITH_TRADEMARK = "Save up to 10% today with an initial Signal\u00ae discount when all eligible drivers enroll, download, and using the Signal app.";
	private static final String SAVE_AT_RENEWAL_TEXT_SIGNAL2 = "Save up to 15% at renewal for consistent good driving behavior";
	private static final String SAVE_AT_RENEWAL_TEXT_YOUNG_DRIVER_5PCT = "Save up to an additional 5% with an initial Signal discount when you sign up drivers under 25";
	private static final String SAVE_AT_RENEWAL_TEXT_YOUNG_DRIVER_10PCT = "Save up to an additional 10% with an initial Signal discount when you sign up drivers under 25";
	private static final String SAVE_AT_RENEWAL_TEXT_35PCT = "Potential to save up to 35% at renewal for consistent good driving behavior**";
	private static final String SAVE_AT_RENEWAL_TEXT_35PCT_CONSISTENTLY = "Potential to save up to 35% at renewal for consistently good driving behavior**";
	private static final String SAVE_AT_RENEWAL_TEXT_NO_POTENTIAL_35PCT = "Save up to 35% at renewal for consistently good driver behavior**";
	private static final String SAVE_AT_RENEWAL_TEXT_NO_POTENTIAL_35PCT_DRIVING = "Save up to 35% at renewal for consistently good driving behavior**";
	private static final String ONLY_ONE_DISCOUNT = "Only one discount can be applied per policy, regardless of the number of enrolled drivers who complete the qualification requirements. If an enrolled driver does not complete 10 trips with the app within 30 days after completing enrollment, the initial discount will be removed back to the enrollment date.";
	private static final String ONLY_ONE_DISCOUNT_WITHIN = "Only one discount can be applied per policy, regardless of the number of enrolled drivers who complete the qualification requirements. If an enrolled driver does not complete 10 trips within the app. within 30 days after completing enrollment, the initial discount will be removed back to the enrollment date.";
	private static final String SIGNAL_PAGE_DISCLAIMER_ONE_INITIAL_5PCT = "*Once you enroll in Signal\u00ae by Farmers, you will receive an initial 5% discount on your Farmers Insurance auto policy. " + ONLY_ONE_DISCOUNT + " The youthful driver component of the Signal\u00ae factor could range from 1% to 10% and is not broken out separately from the overall Signal factor.";
	private static final String SIGNAL_PAGE_DISCLAIMER_ONE_INITIAL_10PCT = "*Once you enroll in Signal\u00ae by Farmers, you will receive an initial 10% discount on your Farmers Insurance auto policy. " + ONLY_ONE_DISCOUNT ;
	private static final String SIGNAL_PAGE_DISCLAIMER_ONE_ALTERNATE = "*Once you enroll in Signal by Farmers, you will receive an initial discount on your Farmers Insurance auto policy. All eligible rated drivers must enroll on the date of initial enrollment to receive the maximum initial discount of 10%. "+ ONLY_ONE_DISCOUNT;
	private static final String SIGNAL_PAGE_DISCLAIMER_ONE_ALTERNATE_WITH_TRADEMARKS = "*Once you enroll in Signal\u00ae by Farmers, you will receive an initial discount on your Farmers Insurance\u00ae auto policy. All eligible rated drivers must enroll on the date of initial enrollment to receive the maximum initial discount of 10%. "+ ONLY_ONE_DISCOUNT;
	private static final String SIGNAL_PAGE_DISCLAIMER_THREEDOTFIVE_ONE_ALTERNATE_WITH_TRADEMARKS = "*Once you enroll in Signal\u00ae by Farmers, you will receive an initial discount on your Farmers Insurance\u00ae auto policy. All eligible rated drivers must enroll on the date of initial enrollment to receive the maximum initial discount of 10%. "+ ONLY_ONE_DISCOUNT_WITHIN;
	private static final String SIGNAL_PAGE_DISCLAIMER_UPON_POLICY_RENEWAL_TEXT = "**Upon policy renewal, you could save money based on your safe driving. However, riskier driving behavior could increase your premium at renewal.";
	private static final String SIGNAL_PAGE_DISCLAIMER_UPON_POLICY_RENEWAL_ALTERNATIVE_TEXT = SIGNAL_PAGE_DISCLAIMER_UPON_POLICY_RENEWAL_TEXT+" Driving with the Signal program may not impact premium at renewal if vehicles are enrolled in other Farmers' telematics programs.";
	private static final String SIGNAL_PAGE_DISCLAIMER_AT_RENEWAL_TEXT = "**At renewal, the Signal discount may increase or decrease based on the percentage of enrolled drivers on your auto policy using the app and their driving scores.";
	private static final String SIGNAL_PAGE_DISCLAIMER_TWO = "Restrictions apply. Discounts may vary. Not available in all states. Insurance is underwritten by Farmers Insurance Exchange and other affiliated Insurance entities. Visit farmers.com for a complete listing of entities. Not all insurers are authorized to provide insurance in all states. Coverage is not available in all states.";
	private static final String SIGNAL_PAGE_DISCLAIMER_THREE = "System Requirements";
	private static final String SIGNAL_PAGE_DISCLAIMER_FOUR = "Signal\u00ae requires specific hardware and sensors for the app to function, such as location, network, an accelerometer, and a gyroscope. If the device does not meet the minimum standards, it cannot be used to participate in this program. In addition, the phone must be able to operate on Android 7.0 or newer or iOS 13.0 or newer.";
	private static final String SIGNAL_PAGE_DISCLAIMER_FOUR_DOT = "Signal\u00ae requires specific hardware and sensors for the app. to function, such as location, network, an accelerometer, and a gyroscope. If the device does not meet the minimum standards, it cannot be used to participate in this program. In addition, the phone must be able to operate on Android 7.0 or newer or iOS 13.0 or newer.";
	private static final String SIGNAL_PAGE_DISCLAIMER_FOUR_ALTERNATE = "Signal requires specific hardware and sensors for the app to function, such as location, network, an accelerometer, and a gyroscope. If the device does not meet the minimum standards, it cannot be used to participate in this program. In addition, the phone must be able to operate on Android 7.0 or newer or iOS 13.0 or newer.";
	private static final String SIGNAL_PAGE_DISCLAIMER_ONE_SIGNAL3_VA = "*Once you enroll in Signal\u00ae by Farmers, you will receive an initial 10% discount on your Farmers Insurance auto policy. "+ ONLY_ONE_DISCOUNT+ " The youthful driver component of the Signal factor could range from 1% to 5% and is not broken out separately from the overall Signal factor.";

	public SignalPageOneUI() throws Exception {
		super();
	}

	//Page validation methods
	public void isSignalPageHeaderCorrect(FarmersSoftAssert fsa) {
		fsa.assertEquals(getTextFromElement(signalPageHeader), SIGNAL_PAGE_HEADER_TEXT);
	}

	public void isSignalPageSubheaderCorrect(String stateCode, FarmersSoftAssert fsa) {
		String expectedSubheader = isSignalRegisteredTrademarkState(stateCode) ? SIGNAL_PAGE_SUBHEADER_TEXT_WITH_REGTRADEMARK : SIGNAL_PAGE_SUBHEADER_TEXT;
		fsa.assertEquals(getTextFromElement(signalPageSubheader), expectedSubheader);
	}

	public void isSaveTodayLabelCorrect(String stateCode, FarmersSoftAssert fsa) {
		String expectedSaveTodayText = EMPTY_STRING;
		switch (stateCode) {
		case IA: case IN: case KS: case KY: case LA: case MA: case MD:
		case MN: case MS: case NC: case NV: case OH: case WA:
			expectedSaveTodayText = SAVE_5PCT_TODAY_TEXT;
			break;
		case AL: case GA:
			expectedSaveTodayText = SAVE_10PCT_TODAY_TEXT;
			break;
		case AR: case CO: case ID: case IL: case MI: case MO: case ND: case NE: case NM:
		case PA: case OK: case OR: case SD: case TN: case TX: case UT: case VA: case WI:
        case WY:
			expectedSaveTodayText = SAVE_UPTO_10PCT_TODAY_TEXT_WITH_TRADEMARK;
                break;
            case CT:
                expectedSaveTodayText = SAVE_UPTO_10PCT_TODAY_TEXT_2;
                break;
            default:
                expectedSaveTodayText = SAVE_UPTO_10PCT_TODAY_TEXT;
                break;
        }
		fsa.assertEquals(getTextFromElement(saveTodayLabel), expectedSaveTodayText, "Correct content of first line item");
	}

	public void isSaveAtRenewalLabelCorrect(AutoApplicant applicant, FarmersSoftAssert fsa) {
		String expectedSaveAtRenewalText = setExpectedRenewalText(applicant.getStateCode());
		if (!Arrays.asList(AL, AR, AZ, CO, CT, ID, IL, MI, MO, ND, NE, NM, OK, PA, SD, TN, TX, UT, VA, WI, WY).contains(applicant.getStateCode()) && anyYoungApplicants(applicant)){
			if (!applicant.getStateCode().equals(OR)) {
				fsa.assertEquals(getTextFromElement(saveAtRenewalWhenYoungDriverLabel), expectedSaveAtRenewalText, "Correct content of third line item");
			}
			if (Arrays.asList(GA, OR).contains(applicant.getStateCode())) {
				boolean isYoungApplicant = anyYoungApplicants(applicant);
				if (applicant.getStateCode().equals(OR) && isYoungApplicant) {
					expectedSaveAtRenewalText = SAVE_AT_RENEWAL_TEXT_35PCT;
					fsa.assertEquals(getTextFromElement(saveAtRenewalLabel), expectedSaveAtRenewalText, "Correct content of second line item");
					fsa.assertFalse(isElementDisplayed(saveAtRenewalWhenYoungDriverLabel,1),"Young driver discount should not be present");
				} else {
					expectedSaveAtRenewalText = SAVE_AT_RENEWAL_TEXT_YOUNG_DRIVER_5PCT;
					fsa.assertEquals(getTextFromElement(saveAtRenewalLabel), expectedSaveAtRenewalText, "Correct content of second line item");
				}
			} else {
				expectedSaveAtRenewalText = SAVE_AT_RENEWAL_TEXT_YOUNG_DRIVER_10PCT;
				fsa.assertEquals(getTextFromElement(saveAtRenewalLabel), expectedSaveAtRenewalText, "Correct content of second line item");
			}
		}
	}

	public void isSignalPageDiscalimerCorrect(String stateCode, FarmersSoftAssert fsa) {
		String observedDisclaimerText = getTextFromElement(signalPageDisclaimer);
		String shouldContain = " should contain =>";
		String expectedDisclaimerOne = SIGNAL_PAGE_DISCLAIMER_ONE_INITIAL_10PCT;
		String expectedDisclaimerTwo = SIGNAL_PAGE_DISCLAIMER_TWO;
		String expectedDisclaimerFour = SIGNAL_PAGE_DISCLAIMER_FOUR;
		switch (stateCode) {
			case IA: case IN: case LA: case KS: case KY: case MA: case MD:
			case MN: case MS: case NC: case NV: case OH: case WA: case AL:
				expectedDisclaimerOne = SIGNAL_PAGE_DISCLAIMER_ONE_INITIAL_5PCT;
				break;
			case CT:
				expectedDisclaimerOne = SIGNAL_PAGE_DISCLAIMER_ONE_INITIAL_10PCT;
				expectedDisclaimerTwo = "Restrictions apply. Discounts may vary. Not available in all states. Insurance is underwritten by Farmers Insurance Exchange and other affiliated insurance entities. Visit farmers.com/companies/state/ for a complete listing of entities. Not all insurers are authorized to provide insurance in all states. Coverage is not available in all states.";
				expectedDisclaimerFour = SIGNAL_PAGE_DISCLAIMER_FOUR_DOT;
				break;
			case AR: case AZ: case CO: case ID: case IL:
			case MI: case MO: case ND: case NE: case NM:
			case OK: case OR: case PA: case SD: case TN:
			case TX: case UT: case VA: case WI: case WY:
				expectedDisclaimerOne = SIGNAL_PAGE_DISCLAIMER_THREEDOTFIVE_ONE_ALTERNATE_WITH_TRADEMARKS;
				expectedDisclaimerTwo = "Restrictions apply. Discounts may vary. Not available in all states. Insurance is underwritten by Farmers Insurance Exchange and other affiliated insurance entities. Visit farmers.com/companies/state/ for a complete listing of entities. Not all insurers are authorized to provide insurance in all states. Coverage is not available in all states.";
				expectedDisclaimerFour = SIGNAL_PAGE_DISCLAIMER_FOUR_DOT;
				break;
		}
		fsa.assertTrue(observedDisclaimerText.contains(expectedDisclaimerOne), "Disclaimer one check: " + observedDisclaimerText + shouldContain + expectedDisclaimerOne);
		if (isSignalThreeState(stateCode)) {
			fsa.assertTrue(observedDisclaimerText.contains(SIGNAL_PAGE_DISCLAIMER_UPON_POLICY_RENEWAL_TEXT), "Signal 3 state disclaimer check: " + observedDisclaimerText + shouldContain + SIGNAL_PAGE_DISCLAIMER_UPON_POLICY_RENEWAL_TEXT);
		} else if(isSignalThreeDotFiveState(stateCode)){
			fsa.assertTrue(observedDisclaimerText.contains(SIGNAL_PAGE_DISCLAIMER_UPON_POLICY_RENEWAL_ALTERNATIVE_TEXT), "Signal 3.5 state disclaimer check: " + observedDisclaimerText + shouldContain + SIGNAL_PAGE_DISCLAIMER_UPON_POLICY_RENEWAL_ALTERNATIVE_TEXT);
		} else {
			fsa.assertTrue(observedDisclaimerText.contains(SIGNAL_PAGE_DISCLAIMER_AT_RENEWAL_TEXT), "Signal 2 state disclaimer check: " + observedDisclaimerText + shouldContain + SIGNAL_PAGE_DISCLAIMER_AT_RENEWAL_TEXT);
		}
		fsa.assertTrue(observedDisclaimerText.contains(expectedDisclaimerTwo), "Disclaimer two check: " + observedDisclaimerText + shouldContain + SIGNAL_PAGE_DISCLAIMER_TWO );
		fsa.assertTrue(observedDisclaimerText.contains(SIGNAL_PAGE_DISCLAIMER_THREE), "Disclaimer three check: " + observedDisclaimerText + shouldContain + SIGNAL_PAGE_DISCLAIMER_THREE);
		fsa.assertTrue(observedDisclaimerText.contains(expectedDisclaimerFour), "Disclaimer four check: " + observedDisclaimerText + shouldContain + expectedDisclaimerFour);
	}

	private boolean anyYoungApplicants(AutoApplicant applicant) {
		boolean foundYoungApplicant = applicant.getAge() < MAX_YOUNG_AGE;
		if (!foundYoungApplicant) {
			List <SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
			for (SqlAdditionalDriver additionalDriver : additionalDrivers) {
				if (additionalDriver.getAge() < MAX_YOUNG_AGE) {
					foundYoungApplicant = true;
					break;
				}
			}
		}
		return foundYoungApplicant;
	}

	private static String setExpectedRenewalText(String stateCode) {
		switch (stateCode) {
			case FL: case IA: case IN: case KS: case KY:
			case LA: case MA: case MD: case MN: case MS: case NC:
			case NV: case OH: case WA:
				return  SAVE_AT_RENEWAL_TEXT_SIGNAL2;
			case AL:
                return SAVE_AT_RENEWAL_TEXT_NO_POTENTIAL_35PCT;
            case CT:
                return SAVE_AT_RENEWAL_TEXT_NO_POTENTIAL_35PCT_DRIVING;
			case AZ: case GA: case OR:
				return SAVE_AT_RENEWAL_TEXT_35PCT;
			case AR: case CO: case ID: case IL: case MI:
			case MO: case ND: case NE: case NM: case OK:
			case PA: case SD: case TN: case TX: case UT:
			case VA: case WI: case WY:
				return SAVE_AT_RENEWAL_TEXT_35PCT_CONSISTENTLY;
			default:
				throw new IllegalStateException("Unexpected value: " + stateCode);
		}
	}

	private boolean isSignalRegisteredTrademarkState(String stateCode) {
		return Arrays.asList(AL, AR, AZ, CO, CT, IA, IL, IN, ID, KS, KY, LA, MA, MD, MI, MO, MS, NC, ND, NE, NM, NV, OH, OK, OR, PA, SD, UT, TN, TX, WA, WI, WY).contains(stateCode);
	}

	private boolean isSignalThreeState(String stateCode) {
		return Arrays.asList(AR, AZ, CO, CT, GA, ID, IL, MI, MO, ND, NE, NM, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY).contains(stateCode);
	}

	public void verifySignalPageLinks() throws Exception {
		verifyListOfLinks(signalPageListOfLinks(), signalPageMapOfURLsAndPageTitles());
        validateColorOfTheLinks();
	}

	public boolean isSignalThreeDotFiveState(String stateCode) {
		return Arrays.asList(AZ,IL,LA, OK, SD, WY).contains(stateCode);
	}


	private LinkedHashMap<String, String> signalPageMapOfURLsAndPageTitles() {
		LinkedHashMap<String, String> urlsAndTitles = new LinkedHashMap<>();
		urlsAndTitles.put("https://www.farmers.com/signal/?lob=A", "Farmers\u00ae Signal\u00ae with CrashAssist | Farmers Insurance\u00ae");
		return urlsAndTitles;
	}

	private List<PWElement> signalPageListOfLinks() {
		List<PWElement> listOfLinks = new ArrayList<PWElement>();
		listOfLinks.add(findOutMoreLink);
		return listOfLinks;
	}

	// Page usage methods
	public boolean isOnSignalPage() {
		return isElementVisible(signalPageHeader, 10);
	}

	public void processSignalPage(boolean acceptsSignalOption) throws Exception {
		int maxRetries = 3;
		for (int attempt = 1; attempt <= maxRetries; attempt++) {
			if (acceptsSignalOption) {
				scrollElementToMiddle(addSignalButton);
                clickElement(addSignalButton);
			} else {
				scrollElementToMiddle(notNowButton);
				clickElement(notNowButton);
			}
			sleep(1);
			waitForSpinnerToBeGone();
			if (!isOnSignalPage()) {
				break;
			}
			Log.warn(String.format("Still on Signal page after attempt %d of %d — retrying click", attempt, maxRetries));
			driver().navigate().refresh();
			sleep(2);
			waitForSpinnerToBeGone();
			if (attempt == maxRetries) {
				throw new RuntimeException("Signal page was not navigated away from after " + maxRetries + " click attempts");
			}
		}
		Log.info(String.format("User %s signal discount", acceptsSignalOption? "accepted" : "declined"));
	}

	public void validateADA_AceSignalPage() {
		isOnSignalPage();
		if(isADATestingEnabled()) {
			performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
		}
	}
	public void validateImages(FarmersSoftAssert fsa) throws Exception {
		checkAllURLsAndImages(findAllURLsAndImages());
		fsa.assertTrue(checkImageIsDisplayed(tripDirectionImage), "Trip Direction Image is displayed");
		fsa.assertTrue(checkImageIsDisplayed(drivingBehaviourImage), "Driving Behaviour Image is displayed");
		testStep("Images and Link validations passed");
	}

	public QuoteSummaryAutoPage navigateFromSignalPageToQuoteSummaryPage(AutoApplicant applicant) throws Exception {
		ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
		contactInfoAutoPage.isOnContactInfoAutoPage();
		contactInfoAutoPage.setValuesAndContinue(applicant);
		QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
		if(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
			return quoteSummaryAutoPage;
		}
		VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
		if(vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
			String stateCode = applicant.getStateCode();
			if(stateCode.equals(VA)) {
				vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();

			} else {
				vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
			}
		}
		ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();

		if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
			continueWithBristolWestPage.continueWithBwPopUp();
			BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
			if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
				bristolWestAdditionalDiscountsPage.clickContinue();
			}
		}

		SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
		if(selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
			selectAQuoteToReviewPage.clickContinueMyQuote();
		}

		BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
		if(bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
			bwFarmersQuotePresentmentPage.continueWithFarmers();
		}
		checkForKnockout("QuoteSummaryAutoPage");
		testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote Summary page has been reached successfully");
		return quoteSummaryAutoPage;
	}
}
