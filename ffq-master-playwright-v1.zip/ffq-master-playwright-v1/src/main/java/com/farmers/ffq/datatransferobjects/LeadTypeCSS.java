package com.farmers.ffq.datatransferobjects;

import com.farmers.ffq.datatransferobjects.hqm.LeadTypeHQM;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class LeadTypeCSS {
    @JsonProperty("First_Name")
    private String firstName;
    @JsonProperty("Last_Name")
    private String lastName;
    @JsonProperty("DOB")
    private String dob;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("Phone")
    private String phone;
    @JsonProperty("Gender")
    private String gender;
    @JsonProperty("Street")
    private String street;
    @JsonProperty("City")
    private String city;
    @JsonProperty("Zip_Code")
    private String zipCode;
    @JsonProperty("LOB")
    private String lob;
    @JsonProperty("Source_Indicator")
    private String sourceIndicator;
    @JsonProperty("SRC")
    private String sourceId;

    public LeadTypeCSS() {}

    public LeadTypeCSS(LeadTypeHQM leadTypeHQM, String lob) {
        this.firstName = leadTypeHQM.getFirstName();
        this.lastName = leadTypeHQM.getLastName();
        this.dob = leadTypeHQM.getDob();
        this.email = leadTypeHQM.getEmail();
        this.phone = leadTypeHQM.getPhone();
        this.gender = leadTypeHQM.getGender().isBlank() ? "M" : leadTypeHQM.getGender().substring(0,1);
        this.street = leadTypeHQM.getStreet();
        this.city = leadTypeHQM.getCity();
        this.zipCode = leadTypeHQM.getZipCode();
        this.lob = lob;
        this.sourceId = leadTypeHQM.getSourceId();
        this.sourceIndicator = leadTypeHQM.getSourceIndicator();
    }

}
