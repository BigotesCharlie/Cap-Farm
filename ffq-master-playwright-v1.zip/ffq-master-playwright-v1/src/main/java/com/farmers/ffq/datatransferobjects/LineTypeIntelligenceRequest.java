package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
public class LineTypeIntelligenceRequest {

    @JsonProperty("LineTypeIntelligenceRequest")
    private LineTypeIntelligenceRequestBean lineTypeIntelligenceRequestBean;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties
    @Data
    public static class LineTypeIntelligenceRequestBean {
        private String countryCode;
        private String phoneNumber;
        private String quoteNumber;

    }

}
