package com.farmers.ffq.common.pages;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoContinueToPaymentOneUI;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Data.CustomerData;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class PolicyPaymentBasePage extends AdditionalInfoContinueToPaymentOneUI {
    protected static final String AUTO_POLICY_PAYMENT_HEADER = "Auto policy payment";
    @PWFindBy(xpath = "//h1[contains(text(), '" + AUTO_POLICY_PAYMENT_HEADER + "')]")
    protected PWElement autoPolicyPaymentHeader;

    private static final String FEES = "Fees";
    @PWFindBy(xpath = "//p[contains(@class,'tui-info-box-header')]")
    protected PWElement feeSideBarHeader;

    private static final String MEMBERSHIP_FEE_MESSAGE = "A membership fee per vehicle is applied for new auto policies and new vehicles added to your policy. It covers the administrative costs associated with you becoming a member of the insurance exchange and the issuance of your policy.";
    @PWFindBy(xpath = "//p[contains(text(), 'A membership fee per vehicle is applied ')]")
    protected PWElement membershipFeeMessageSideBar;

    private static final String POLICY_FEE_MESSAGE = "A policy fee per vehicle is applied for new auto policies and new vehicles added to your policy. This is for administrative costs associated with writing your new policy.";
    @PWFindBy(xpath = "//p[contains(text(), 'A policy fee per vehicle is applied for new auto')]")
    protected PWElement policyFeeMessageSideBar;

    private static final String VEHICLE_FEE_MESSAGE = "A fee per vehicle is applied for new auto policies and new vehicles added to your policy. This is for administrative costs associated with writing your new policy.";
    @PWFindBy(xpath = "//p[contains(text(), 'A fee per vehicle is applied for new auto')]")
    protected PWElement vehicleFeeMessageSideBar;

    private static final String SIX_MONTH_TERM_PAYMENT = "6-month term payment";
    @PWFindBy(xpath = "//span[contains(text(),'" + SIX_MONTH_TERM_PAYMENT + "')]")
    protected PWElement sixMonthTermPayment;

    @PWFindBy(xpath = "//span[contains(text(), '6-month term price')]")
    private PWElement sixTermPriceSubHeader;

    @PWFindBy(xpath = "//span[contains(text(),'" + FEES + "')]")
    protected PWElement fees;

    public static final String DUE_TODAY_LABEL = "Due today";
    @PWFindBy(xpath = "//section[contains(@class,'autopay-details')]//*[contains(text(),'" + DUE_TODAY_LABEL + "')]")
    private PWElement dueTodayLabel;

    private static final String SET_UP_PAYMENT_METHOD = "Set up payment method";
    private static final String SET_UP_PAYMENT_METHOD_XPATH = "//button[contains(text(),'" + SET_UP_PAYMENT_METHOD + "')]";
    @PWFindBy(xpath = SET_UP_PAYMENT_METHOD_XPATH)
    protected PWElement setUpPaymentMethodButton;

    @PWFindBy(xpath = "//mat-dialog-container//button[contains(text(),'" + SET_UP_PAYMENT_METHOD + "')]")
    protected PWElement setUpPaymentMethodButtonInIframe;

    @PWFindBy(xpath = "//mat-icon[contains(text(), 'close')]")
    private PWElement addPaymentMethodContainerCloseIcon;

    @PWFindBy(xpath = "//mat-dialog-container[@aria-labelledby='addPaymentHeading']")
    private PWElement addPaymentMethodDialogContainer;

    private static final String ADD_BUTTON = "ADD";
    @PWFindBy(xpath = "//button[@name='submitBtn']")
    private PWElement addButton;

    private static final String ADD_PAYMENT_METHOD_LABEL = "Add payment method";
    @PWFindBy(xpath = "//h1[text() = '" + ADD_PAYMENT_METHOD_LABEL + "']")
    private PWElement addPaymentMethodLabel;

    private static final String ADD_BANK = "Add bank";
    @PWFindBy(xpath = "//h1[contains(text(), '" + ADD_BANK + "')]")
    private PWElement addBankHeader;

    private static final String BANK_PAYMENT_BUTTON_TEXT = "Bank payment";
    @PWFindBy(xpath = "//app-add-payment//*[contains(text(),'" + BANK_PAYMENT_BUTTON_TEXT + "')]")
    protected PWElement bankPaymentButton;

    protected static final String BANK_BUTTON_TEXT = "Bank";
    @PWFindBy(xpath = "//app-add-payment//*[contains(text(),'" + BANK_BUTTON_TEXT + "')]")
    protected PWElement bankButton;

    private static final String DEBIT_CREDIT_CARD_BUTTON = "Debit / Credit card";
    @PWFindBy(xpath = "//div[@role='tab']//span[contains(text(),'Debit / Credit card')]")
    protected PWElement debitCreditCardButton;

    @PWFindBy(xpath = "//div[@role='tab']//span[contains(text(),'Card')]")
    protected PWElement cardButtonIframe;

    private static final String CARD_BUTTON = "Card";
    @PWFindBy(xpath = "//div[@class='mat-tab-label-content' and contains(text(),'" + CARD_BUTTON + "')]")
    private PWElement cardButton;

    private static final String PAPERLESS_TERMS_OF_USE = "Paperless Terms of Use";
    @PWFindBy(xpath = "//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]")
    private PWElement paperlessTermsOfUseLink;

    private static final String INFORMATION_STORAGE_AUTHORIZATION = "Information Storage Authorization";
    @PWFindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]")
    private PWElement informationStorageAuthorizationLink;

    private static final String PAYMENT_AUTHORIZATION = "Payment Authorization Terms & Conditions.";
    @PWFindBy(xpath = "//a[contains(text(), '" + PAYMENT_AUTHORIZATION + "')]")
    private PWElement paymentAuthorizationLink;


    List<PWElement> listOfLinksToClick = Arrays.asList(paperlessTermsOfUseLink, informationStorageAuthorizationLink, paymentAuthorizationLink);
    private static final String TERMS_AND_CONDITIONS_TITLE = "Terms of Use | Farmers Insurance";
    private static final String PAYMENT_AUTHORIZATION_TITLE = "Payment Authorization Terms and Conditions | Farmers Insurance";
    private static final String INFORMATION_STORAGE_AUTHORIZATION_TITLE = "Payment Card Storage Terms & Conditions | Farmers Insurance";

    private static final List<String> listOfTabTitles = Arrays.asList(TERMS_AND_CONDITIONS_TITLE, INFORMATION_STORAGE_AUTHORIZATION_TITLE, PAYMENT_AUTHORIZATION_TITLE);


    private static final String BY_CLICKING_COMPLETER_PURCHASE = "By clicking \"Complete purchase\" below:";
    @PWFindBy(xpath = "//div[contains(text(), '" + BY_CLICKING_COMPLETER_PURCHASE + "')]")
    private PWElement byClickingCompletePurchaseLabel;

    private static final String READ_AND_AGREED_TO_THE_BULLET_ONE = "I confirm that I have read and agree to the Paperless Terms of Use; and";
    @PWFindBy(xpath = "//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]/parent::p")
    private PWElement readAndAgreedToTheBulletPointOne;

    private static final String IF_DO_NOT_AGREE_WITH_TERMS = "If you do not agree with the Terms and Conditions above and/or have any questions, please contact your agent or Farmers Direct Sales Center to complete this transaction. You can always change your Paperless and Automatic Payment settings for future transactions by logging in to your Farmers.com account.";
    @PWFindBy(xpath = "//p[contains(text(), 'If you do not agree with the Terms and Conditions above ')]")
    private PWElement ifDoNotAgreeWithTermsAndConditionLabel;

    private static final String COMPLETE_PURCHASE_BUTTON = "Complete purchase";
    @PWFindBy(xpath = "//button[contains(text(), '" + COMPLETE_PURCHASE_BUTTON + "')]")
    protected PWElement completePurchaseButton;

    private static final String FINISH_DOCUMENTS_BUTTON = "Finish documents";
    @PWFindBy(xpath = "//button[contains(text(), '" + FINISH_DOCUMENTS_BUTTON + "')]")
    protected PWElement finishDocumentsButton;

    @PWFindBy(xpath = "//section[contains(@class,'document-sign-card-compact')]")
    protected PWElement finishDocumentsSection;

    protected static final String FINISH_DOCUMENTS_SECTION_TEXT = "Your payment details are confirmed! Next, complete your documents. " +
            "You'll do a final review before authorizing payments. Finish documents";

    private static final String PAYMENT_METHOD_ALREADY_ADDED_ERROR = "You have already saved this payment method. Cannot save duplicate.";
    @PWFindBy(xpath = "//li[@id='profile']")
    private PWElement paymentMethodAlreadyAdded;

    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO_MONTHLY_PAY = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate One-Time and Automatic Payment processes.";
    @PWFindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p")
    private PWElement readAndAgreedToTheBulletPointTwoMonthlyPay;

    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate:";
    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO_ALTERNATE = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries(\"Farmers\") to initiate:";
    @PWFindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p")
    private PWElement readAndAgreedToTheBulletPointTwo;

    private static final String FARMERS_FAST_QUOTE = "FARMERS FAST QUOTE";
    private static final String PAY_IN_FULL_HEADER = "Pay in full";
    @PWFindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL_HEADER + "')]")
    private PWElement payInFullHeader;

    protected static final String ADD_YOUR_PREFERRED_PAYMENT_METHOD1 = "Add your preferred payment method.";
    @PWFindBy(xpath = "//span[contains(text(),'" + ADD_YOUR_PREFERRED_PAYMENT_METHOD1 + "')]")
    private PWElement selectPreferredPaymentMethod;
    private static final String USE_BANK_DEBIT_CREDIT = "Use bank payment, debit card, or credit card";
    @PWFindBy(xpath = "//p[contains(text(), 'bank payment, debit card, or credit')]")
    private PWElement useBankDebitCreditCard;

    protected static final String NO_SERVICE_CHARGES_WHEN_YOU_PAY_IN_FULL = "No service charges when you pay in full";
    @PWFindBy(xpath = "//p[contains(text(), 'No service charges when you pay in full')]")
    private PWElement noServiceChargesWhenPayInFull;

    public static final String MONTHLY_AUTO_PAY_BANK_HEADER = "Monthly autopay - bank";
    public static final String MONTHLY_AUTO_PAY_CARD_HEADER = "Monthly autopay - card";
    @PWFindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_BANK_HEADER + "')]")
    private PWElement monthlyAutoPayBankHeader;
    @PWFindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_CARD_HEADER + "')]")
    private PWElement monthlyAutoPayCardHeader;
    @PWFindBy(xpath = "//h2[contains(text(), '" + MONTHLY_DIRECT_BILL + "')]")
    private PWElement monthlyDirectBillHeader;
    private static final String FIRST_MONTHLY_PAYMENT = "First monthly payment";
    @PWFindBy(xpath = "//p[contains(text(), '" + FIRST_MONTHLY_PAYMENT + "')]")
    private PWElement firstMonthlyPaymentLabel;
    private static final String FEES_LABEL = "Fees";
    @PWFindBy(xpath = "//p[contains(text(), '" + FEES_LABEL + "')]")
    private PWElement feesLabel;

    private static final String SELECT_PREFERRED_PAYMENT_LABEL = "Select your preferred payment method.";
    @PWFindBy(xpath = "//p[contains(text(), '" + SELECT_PREFERRED_PAYMENT_LABEL + "')]")
    private PWElement selectPreferredPaymentLabel;
    @PWFindBy(xpath = "//input[@value='bank-transfer']")
    private PWElement bankPaymentRadiobutton;
    @PWFindBy(xpath = "//mat-dialog-content//input[@value='bank-transfer']")
    private PWElement bankPaymentRadiobuttonInIframe;
    @PWFindBy(xpath = "//label[contains(text(),'Bank payment')]/preceding::input[@value='bank-transfer']")
    private PWElement changeBankPaymentRadiobutton;
    @PWFindBy(xpath = "//mat-radio-button[@value='bank-transfer']")
    protected PWElement bankPaymentRadiobuttonAlternate;

    @PWFindBy(xpath = "//mat-radio-button[@value='bank-transfer']//label")
    protected PWElement bankPaymentRadiobuttonLabel;

    @PWFindBy(xpath = "//mat-radio-group[@name='monthly-autopay-options-sidesheet']//mat-radio-button[@value='bank-transfer']")
    protected PWElement bankPaymentRadiobuttonSideSheet;

    @PWFindBy(xpath = "//mat-radio-button[@value='bank-transfer']//label")
    private PWElement bankPaymentLabel;
    @PWFindBy(xpath = "//mat-radio-button[@value='card']//label")
    private PWElement cardPaymentLabel;
    private static final String DOLLAR_ZERO = "$0";
    @PWFindBy(xpath = "//span[contains(text(), '$0')]")
    private PWElement dollarZeroLabel;

    private static final String IN_SERVICE_CHARGES_LABEL = "in service charges";
    @PWFindBy(xpath = "//li[contains(.,'" + IN_SERVICE_CHARGES_LABEL + "')]")
    private PWElement inServiceChargesElement;

    // @FindBy(xpath = "//p[contains(text(),' Select your preferred payment method. ')]//following::mat-radio-button[@value='card']")
    @PWFindBy(xpath = "//input[@value='card']")
    private PWElement cardPaymentRadiobutton;

    @PWFindBy(xpath = "//mat-radio-button[@value='card']")
    protected PWElement cardPaymentRadiobuttonAlternative;

    @PWFindBy(xpath = "//mat-radio-button[@value='card']//label")
    protected PWElement cardPaymentRadiobuttonLabel;

    @PWFindBy(xpath = "//label[contains(text(),'Card')]/preceding::input[@value='card']")
    private PWElement changeCardPaymentRadiobutton;

    private static final String FUTURE_MONTHLY_SERVICE_CHARGES = "Future monthly service charge:";
    @PWFindBy(xpath = "//p[contains(text(), 'Future monthly service charge:')]")
    private PWElement futureMonthlyChargesLabel;

    @PWFindBy(xpath = "//li[contains(.,'Debit card')]")
    private PWElement debitCardServiceChargeLabel;

    @PWFindBy(xpath = "//li[contains(.,'Credit card')]")
    private PWElement creditCardServiceChargeLabel;


    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public PolicyPaymentBasePage() throws Exception {
    }

    public boolean clickSetUpPaymentButton() throws Exception {
        waitAndClickElement(setUpPaymentMethodButton);
        waitForSpinnerToBeGone();
        wait.until(PWExpectedConditions.elementToBeClickable(addPaymentMethodContainerCloseIcon));
        sleep(2);
        return addPaymentMethodDialogContainer.isDisplayed();
    }

    public boolean clickSetUpPaymentButtonSideSheet() throws Exception {
        List<PWElement> setUpPaymentMethodElements = driver().findElements(PWBy.xpath("//button[contains(.,'Set up payment method')]"));
        waitAndClickElement(setUpPaymentMethodElements.get(1));
        wait.until(PWExpectedConditions.elementToBeClickable(addPaymentMethodContainerCloseIcon));
        sleep(2);
        return addPaymentMethodDialogContainer.isDisplayed();
    }

    public boolean closeAddPaymentMethodContainer(Boolean isComingFromChangePayment) throws Exception {
        waitAndClickElement(addPaymentMethodContainerCloseIcon);
        if (isComingFromChangePayment) {
            return true;
        }
        return setUpPaymentMethodButton.isEnabled();
    }

    public boolean goBackToHowWouldYouLikeToPayPage() throws Exception {
        driver().navigate().back();
        return isExpectedTextDisplayed(howWouldYouLikeToPay, HOW_WOULD_YOU_LIKE_TO_PAY);
    }

    public boolean isSixMonthTermPaymentAmountDisplayed(String payPlanDescription, String htmlElement, AppStore retrieveQuoteResponseSessionStorage) throws Exception {
        String downPayment = getDownPayment(retrieveQuoteResponseSessionStorage, payPlanDescription);
        PWElement sixTermPaymentAmount = listOfFullAmountWebElements(downPayment, htmlElement, true).get(0);
        return sixTermPaymentAmount.isDisplayed();
    }

    public boolean isPolicyFeeAmountDisplayedAuto(String htmlElement) throws Exception {
        AppStore.VerifyResponse verifyResponse = getAutoVerifyRateResponse();
        String policyFee = verifyResponse.getPolicyFee().getAmount();
        PWElement administrativeFeeAmount = listOfFullAmountWebElements(policyFee, htmlElement, true).get(0);
        return administrativeFeeAmount.isDisplayed();
    }

    public void isDueTodayAmountDisplayedAuto(String payPlanDescription, FarmersSoftAssert fsa) throws Exception {
        String policyFee = getAutoVerifyRateResponse().getPolicyFee().getAmount();
        String onePayDownPayment = getDownPayment(getSessionStorageAppStore(), payPlanDescription);
        Double dueToday = Double.parseDouble(policyFee) + Double.parseDouble(onePayDownPayment);
        PWElement dueTodayAmountElement = driver().findElement(PWBy.xpath("//div[contains(@class,'autopay-details-bottom-row')]/span[contains(.,'$')]"));
        fsa.assertEquals(getTextFromElement(dueTodayAmountElement), String.format("$%,.2f", dueToday), "Due today amount verification for " + payPlanDescription);
    }

    public boolean isAddButtonTextCorrect() {
        return isExpectedTextDisplayed(addButton, ADD_BUTTON);
    }

    public void clickAddButton() throws Exception {
        try {
            scrollAndClickOnElement(addButton);
            waitForSpinnerToBeGone();
        } catch (Exception e) {
            Log.info("Add button not clicked");
        }
    }


    public boolean isAddPaymentMethodLabelCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(addPaymentMethodLabel), ADD_PAYMENT_METHOD_LABEL);
    }

    public boolean isAddBankHeaderCorrect() {
        return isExpectedTextDisplayed(addBankHeader, ADD_BANK);
    }

    public boolean isBankPaymentButtonTextCorrect() {
        isOnPaymentAdditionSideSheet();
        if(isElementVisible(bankPaymentButton, 5)){
            return isExpectedTextDisplayed(bankPaymentButton, BANK_PAYMENT_BUTTON_TEXT);
        } else {
            return isExpectedTextDisplayed(waitElementBeVisible(bankButton), BANK_BUTTON_TEXT);
        }
    }

    public boolean isBankButtonTextCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(bankButton), BANK_BUTTON_TEXT);
    }

    public boolean isDebitCreditCardButtonTextCorrect() {
        return isExpectedTextDisplayed(debitCreditCardButton, DEBIT_CREDIT_CARD_BUTTON);
    }

    public boolean isCardButtonTextCorrect() {
        return isExpectedTextDisplayed(cardButtonIframe, CARD_BUTTON);
    }

    public void clickBankTransferButton() {
        sleep(1);
        scrollAndClickOnElement(bankPaymentButton);
    }

    public void clickDebitCreditCardButton() {
        waitAndClickElement(debitCreditCardButton);
    }

    public void clickCardButton() {
        waitAndClickElement(cardButton);
    }

    public String fullNameFromCustomerData(CustomerData customerData) {
        return customerData.getFirstName() + " " + customerData.getLastName();
    }

    public boolean validateOpeningLinksInNewTab() throws Exception {
        boolean isTitleFound = false;
    	int numberOfElements = listOfLinksToClick.size();
        String mainWindow = driver().getWindowHandle();
        for (int i = 0; i< numberOfElements; i++){
            clickElement(listOfLinksToClick.get(i));
            sleep(3);
            ArrayList<String> tabHandles = new ArrayList<String>(driver().getWindowHandles());
            for (String eachHandle : tabHandles) {
                driver().switchTo().window(eachHandle);
                if (List.of(FIREFOX, SAFARI).contains(Property.getDriver())) {
                    sleep(3);
                }
                // Check title of each opened tab
                if (!driver().getTitle().trim().equals(FARMERS_FAST_QUOTE)) {
                    if (driver().getTitle().equalsIgnoreCase(listOfTabTitles.get(i))) {
                        driver().close();
                        driver().switchTo().window(mainWindow);
                        isTitleFound = true;
                    }
                }
            }
        }
        return isTitleFound;
    }

    // validate if links are enabled/displayed
    public boolean validateClickableLinksPaymentPage() {
        boolean isLinkDisplayedAndEnabled = false;
    	int numberOfElements = listOfLinksToClick.size();
        for (int i = 0; i< numberOfElements; i++){
            isLinkDisplayedAndEnabled = listOfLinksToClick.get(i).isDisplayed() && listOfLinksToClick.get(i).isEnabled();
        }
        return isLinkDisplayedAndEnabled;
    }

    public boolean isByClickingCompletePurchaseLabelCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(byClickingCompletePurchaseLabel), BY_CLICKING_COMPLETER_PURCHASE);
    }

    public boolean isReadAndAgreedBulletPointOneCorrect() {
        return isExpectedTextDisplayed(readAndAgreedToTheBulletPointOne, READ_AND_AGREED_TO_THE_BULLET_ONE);
    }

    public boolean isIfDoNotAgreeWithTermsAndConditionLabelCorrect() {
        return isExpectedTextDisplayed(ifDoNotAgreeWithTermsAndConditionLabel, IF_DO_NOT_AGREE_WITH_TERMS);
    }

    public boolean isCompletePurchaseButtonTextMatching() {
        return isExpectedTextDisplayed(completePurchaseButton, COMPLETE_PURCHASE_BUTTON);
    }

    public void clickCompletePurchaseButton() throws Exception {
        scrollToBottomOfPage();
        waitElementBeVisibleClickable(completePurchaseButton);
        clickElement(completePurchaseButton);
        waitForSpinnerToBeGone();
    }

    public boolean isFinishDocumentsButtonTextMatching() {
        return isExpectedTextDisplayed(finishDocumentsButton, FINISH_DOCUMENTS_BUTTON);
    }

    public boolean isPaymentMethodAlreadyAddedMsgCorrect() {
        waitElementBeVisible(paymentMethodAlreadyAdded, 4);
        return isExpectedTextDisplayed(paymentMethodAlreadyAdded, PAYMENT_METHOD_ALREADY_ADDED_ERROR);
    }

    public boolean isReadAndAgreedBulletPointTwoMonthlyPayCorrect() {
        return isExpectedTextDisplayed(readAndAgreedToTheBulletPointTwoMonthlyPay, READ_AND_AGREED_TO_THE_BULLET_TWO_MONTHLY_PAY);
    }

    public boolean isReadAndAgreedBulletPointTwoCorrect() {
        return isAnyExpectedTextDisplayed(readAndAgreedToTheBulletPointTwo, READ_AND_AGREED_TO_THE_BULLET_TWO, READ_AND_AGREED_TO_THE_BULLET_TWO_ALTERNATE);
    }

    public boolean isDueTodayCorrect() {
        return isExpectedTextDisplayed(dueTodayLabel, DUE_TODAY_LABEL);
    }

    public boolean isSetUpPaymentMethodCorrect() {
        return isExpectedTextDisplayed(setUpPaymentMethodButton, SET_UP_PAYMENT_METHOD);
    }

    public boolean isOnPayInFullPage() {
        return isElementVisible(payInFullHeader, 25);
    }

    public boolean isPayInFullHeaderCorrect() {
        return isExpectedTextDisplayed(payInFullHeader, PAY_IN_FULL_HEADER);
    }

    public boolean isSelectPreferredPaymentCorrect() {
        return isExpectedTextDisplayed(selectPreferredPaymentMethod, ADD_YOUR_PREFERRED_PAYMENT_METHOD1);
    }

    public boolean isBankDebitCreditPaymentCorrect() {
        return isExpectedTextDisplayed(useBankDebitCreditCard, USE_BANK_DEBIT_CREDIT);
    }

    public boolean isNoServiceChargeCorrect() {
        return isExpectedTextDisplayed(noServiceChargesWhenPayInFull, NO_SERVICE_CHARGES_WHEN_YOU_PAY_IN_FULL);
    }

    public void validateADA_PayInFullPage() throws Exception {
        if (!isADATestingEnabled()) return;

        isOnPayInFullPage();
        performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.clickSetUpPaymentButton();
        performADATesting(this.getClass().getSimpleName() + "_AddPaymentMethodBankPaymentSideSheet", MARKETING_IT, ACE_AUTO);
        policyPaymentBasePage.clickDebitCreditCardButton();
        performADATesting(this.getClass().getSimpleName() + "_AddPaymentMethodDebitCreditCardPaymentSideSheet", MARKETING_IT, ACE_AUTO);
        policyPaymentBasePage.closeAddPaymentMethodContainer(false);
    }

    public boolean isMonthlyAutoPayBankHeaderCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(monthlyAutoPayBankHeader), MONTHLY_AUTO_PAY_BANK_HEADER);
    }

    public boolean isMonthlyAutoPayCardHeaderCorrect() {
        return isExpectedTextDisplayed(monthlyAutoPayCardHeader, MONTHLY_AUTO_PAY_CARD_HEADER);
    }

    public boolean isMonthlyDirectBillHeaderCorrect() {
        return isExpectedTextDisplayed(monthlyDirectBillHeader, MONTHLY_DIRECT_BILL);
    }

    public boolean isMonthlyAutoPayHeaderCardCorrect() {
        return isExpectedTextDisplayed(monthlyAutoPayBankHeader, MONTHLY_AUTO_PAY_BANK_HEADER);
    }

    public boolean isFirstMonthlyPaymentLabelCorrect() {
        return isExpectedTextDisplayed(firstMonthlyPaymentLabel, FIRST_MONTHLY_PAYMENT);
    }

    public boolean isOneTimeFeeLabelCorrect() {
        return isExpectedTextDisplayed(feesLabel, FEES_LABEL);
    }

    public boolean isSelectPreferredPaymentLabelCorrect() {
        return isExpectedTextDisplayed(selectPreferredPaymentLabel, SELECT_PREFERRED_PAYMENT_LABEL);
    }

    public boolean isBankPaymentRadioButtonDisplayed() {
        return bankPaymentRadiobutton.isDisplayed();
    }

    public boolean isBankPaymentRadioButtonDisplayedAlternative() {
        return isElementDisplayed(bankPaymentRadiobuttonAlternate, 15);
    }

    public boolean isBankPaymentLabelCorrect(String expectedText) {
        return getTextFromElement(bankPaymentLabel).equals(expectedText);
    }

    public boolean isCardPaymentLabelCorrect(String expectedText) {
        return getTextFromElement(cardPaymentLabel).equals(expectedText);
    }

    public void isBankAccountServiceChargesAmountCorrect(String expectedText, FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(inServiceChargesElement), expectedText, "Bank payment service amount verification");
    }

    public boolean isBankPaymentRadioButtonSelected() {
        return getAttributeData(bankPaymentRadiobutton, CLASS).contains(RADIO_BUTTON_CHECKED);
    }

    public boolean isCardPaymentRadioButtonDisplayed() {
        return isElementDisplayed(cardPaymentRadiobutton, 15);
    }

    public boolean isCardPaymentRadioButtonDisplayedAlternative() {
        return isElementDisplayed(cardPaymentRadiobuttonAlternative, 15);
    }

    public boolean isCardPaymentRadioButtonSelected() {
        return getAttributeData(cardPaymentRadiobutton, CLASS).contains(RADIO_BUTTON_CHECKED);
    }

    public boolean isFutureMonthlyChargesLabelCorrect() {
        return isExpectedTextDisplayed(futureMonthlyChargesLabel, FUTURE_MONTHLY_SERVICE_CHARGES);
    }

    public void isDebitCardAdministrativeFeeLabelCorrect(String expectedText, FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(debitCardServiceChargeLabel), expectedText, "Monthly Autopay page, Future service charge for Debit card verification");
    }

    public void isCreditCardAdministrativeFeeLabelCorrect(String expectedText, FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(creditCardServiceChargeLabel), expectedText, "Monthly Autopay page, Future service charge for Credit card verification");
    }

    public void selectCardPaymentRadioButtonHRC() throws Exception {
        sleep(2);
        clickOnHiddenElement(changeCardPaymentRadiobutton);
    }

    public void selectCardPaymentRadioButtonAlternative() throws Exception {
        waitAndClickElement(cardPaymentRadiobuttonLabel);
    }

    public void selectBankPaymentRadioButton() {
        if (!isElementDisplayed(bankPaymentRadiobutton, 5)) {
            sleep(2);
        }
        scrollToElement(bankPaymentRadiobutton);
        clickElement(bankPaymentRadiobutton);
    }
    public void selectBankPaymentRadioButtonInIframe() {
        if (!isElementDisplayed(bankPaymentRadiobuttonInIframe, 5)) {
            sleep(2);
        }
        scrollToElement(bankPaymentRadiobuttonInIframe);
        clickElement(bankPaymentRadiobuttonInIframe);
    }

    public void selectBankPaymentRadioButtonHRC() throws Exception {
        sleep(2);
        clickOnHiddenElement(changeBankPaymentRadiobutton);
    }

    public void selectBankPaymentRadioButtonAlternate() throws Exception {
        waitAndClickElement(bankPaymentRadiobuttonLabel);
    }

    public void selectBankPaymentRadioButtonSideSheet() throws Exception {
        waitAndClickElement(bankPaymentRadiobuttonSideSheet);
    }

    public boolean isOnAutoPolicyPaymentMonthlyBankPage() {
        return isElementVisible(monthlyAutoPayCardHeader, 25);
    }

    public void validateADA_AutoPolicyPaymentMonthlyPay() {
        isOnAutoPolicyPaymentMonthlyBankPage();
        if (isADATestingEnabled()) {
            performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
        }
    }

    public boolean isPolicyFeeSideBarHeaderCorrect() {
        return isExpectedTextDisplayed(feeSideBarHeader, FEES);
    }

    public void clickSetUpPaymentButtonBundle() throws Exception {
    	waitElementPresent(PWBy.xpath(SET_UP_PAYMENT_METHOD_XPATH),15);
        scrollAndClickOnElement(setUpPaymentMethodButton);
    }

    protected void switchToBankPaymentToggleInPaymentSideSheet() {
        if (isElementVisible(bankButton, 1)) {
            scrollAndClickOnElement(bankButton);
        } else {
            scrollAndClickOnElement(bankPaymentButton);
        }
    }

    protected boolean isOnPaymentAdditionSideSheet() {
        return isElementVisible(addPaymentMethodDialogContainer, 3);
    }

}
