package com.farmers.ffq.datatransferobjects.hqm;

import com.farmers.ffq.dataproviderframework.DataObjectBase;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ApplicantHQM extends DataObjectBase implements Cloneable {

    public String firstName;
    public String lastName;
    public String dateOfBirth;
    public String gender;
    public String maritalStatus;
    public String spouseFirstName;
    public String spouseLastName;
    public String spouseDateOfBirth;
    public String spouseGender;
    public String addressApt;
    public String city;
    public String county;
    public String stateCode;
    public String state;
    public String zipCode;
    public int yearBuilt;
    public String squareFeet;
    public String qualityGrade;
    public String numberOfStories;
    public String foundationType;
    public String finishedPercentOfLowestLevel;
    public String exteriorWallConstruction;
    public String exteriorWallFinish;
    public String roofCover;
    public String floorCoverings;
    public String heatingSystem;
    public String fireplaces;
    public String garageCarport;
    public String garageStyle;
    public boolean oilTankOnPremise;
    public String unitsAttached;
    public String poolOnPremises;
    public String solarPanels;
    public String trampoline;
    public String emailAddress;
    public String phoneNumber;
    public String occupation;
    public boolean centralBurglarAlarm;
    public boolean centralFireAlarm;
    public boolean ceaCoverage;
    public boolean adtSecurity;
    public boolean newlyOwned;
    public boolean theftAlarm;
    public boolean fireAlarm;
    public boolean waterShutoff;
    public boolean fortifiedHome;
    public String centralAlarm;
    public String directAlarm;
    public String localAlarm;
    public String autoSmokeDetectors;
    public String autoSprinklerSystem;
    public boolean lifeInsurance;
    public boolean autoInsurance;
    public boolean commercial;
    public boolean boatWaterCraft;
    public boolean offRoad;
    public boolean motorHome;
    public boolean umbrellaInsurance;
    public String quoteRate;
    public String earlyShoppingFactor;
    public boolean isKnockOutScenario;
    public boolean nonOffering;
    public boolean keep360Prefill;
    public String agentId;
    public boolean emailCheck;
    public String campaignId;
    public String quoteNumber;

    public ApplicantHQM() {
        super();
    }

    public ApplicantHQM(ApexHQM applicant) {
        this.firstName = applicant.firstName;
        this.lastName = applicant.lastName;
        this.dateOfBirth = applicant.dateOfBirth;
//        this.gender = applicant.gender;
        this.maritalStatus = applicant.maritalStatus;
        this.spouseFirstName = applicant.spouseFirstName;
        this.spouseLastName = applicant.spouseLastName;
        this.spouseDateOfBirth = applicant.spouseDateOfBirth;
//        this.spouseGender = applicant.spouseGender;
        this.addressApt = applicant.addressApt;
        this.city = applicant.city;

        this.stateCode = applicant.stateCode;
        this.state = applicant.stateCode;
        this.zipCode = applicant.zipCode;
        this.yearBuilt = applicant.yearBuilt;
        this.squareFeet = applicant.squareFeet;
        this.finishedPercentOfLowestLevel = "100";
        this.poolOnPremises = "No";
        this.solarPanels = "No";
        this.trampoline = "No";

        this.emailAddress = applicant.emailAddress;
        this.phoneNumber = applicant.phoneNumber;

        this.keep360Prefill = true;
        this.agentId = applicant.agentId;

    }


    @Override
    public ApplicantHQM clone() throws CloneNotSupportedException {
        return (ApplicantHQM) super.clone();
    }

    /**
     * String Representation of Applicant class.
     */
    public String toString() {
        return String.format("#%s %s %s %s %s %s %s", getId(), firstName, lastName, addressApt, city, state, zipCode );
    }

    /**
     * String Representation of Applicant class.
     */
    public String toStringMore() {
        return String.format("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                getId(), firstName, lastName, addressApt, city, state, zipCode, yearBuilt, squareFeet, qualityGrade,
                numberOfStories, foundationType, finishedPercentOfLowestLevel, exteriorWallFinish, roofCover,
                floorCoverings, heatingSystem, fireplaces, garageCarport, garageStyle, keep360Prefill,
                emailAddress, phoneNumber, occupation, quoteRate);
    }

}
