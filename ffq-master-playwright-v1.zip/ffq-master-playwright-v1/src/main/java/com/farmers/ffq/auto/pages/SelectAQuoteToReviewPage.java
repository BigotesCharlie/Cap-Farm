package com.farmers.ffq.auto.pages;



import com.farmers.framework.playwright.compat.*;
import static com.farmers.ffq.utils.GlobalVariables.ACE_AUTO;
import static com.farmers.ffq.utils.GlobalVariables.MARKETING_IT;


public class SelectAQuoteToReviewPage extends AutoBasePage {

    public SelectAQuoteToReviewPage() throws Exception {
    }

    @PWFindBy(xpath = "//button[normalize-space(.)='Continue my quote']")
    private PWElement btnContinueMyQuote;

    public boolean isOnSelectAQuoteToReviewPage() {
        return checkIsOnSelectAQuoteToReviewPage(false);
    }

    public QuoteSummaryAutoPage clickContinueMyQuote() throws Exception {
        waitAndClickElement(btnContinueMyQuote);
        waitForSpinnerToBeGone();
        return new QuoteSummaryAutoPage();
    }

    public boolean checkIsOnSelectAQuoteToReviewPage(boolean useQuickCheck) {
        waitForSpinnerToBeGone();
        int timerLength = useQuickCheck? 5 : 25;
        return isElementVisible(btnContinueMyQuote, timerLength);
    }

    public void validateADA_SelectAQuoteToReviewPage() {
        if(isADATestingEnabled()) {
            performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
        }
    }
}

