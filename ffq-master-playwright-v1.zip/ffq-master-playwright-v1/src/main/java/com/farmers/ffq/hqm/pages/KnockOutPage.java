package com.farmers.ffq.hqm.pages;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.datatransferobjects.hqm.AgentInfoHQM;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.QuoteRateHQM;
import com.farmers.ffq.datatransferobjects.hqm.StaticContentHQM;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;

import javax.annotation.Nullable;

import java.util.Arrays;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Knock Out Page - Home.
 *
 *
 */

public class KnockOutPage extends HqmBasePage {

    @PWFindBy(xpath = "//farmers-home-quote-knockouts//div//img")
    private PWElement linkFarmersLogo;

    @PWFindBy(xpath = "//farmers-home-quote-knockouts//h1")
    private PWElement pageTitle;

    @PWFindBy(xpath = "//farmers-home-quote-knockouts//span[contains(@class,'sub-title-one') and not(strong)]")
    private PWElement pageSubTitle1;

    @PWFindBy(xpath = "//farmers-home-quote-knockouts//div[contains(@class,'tui-subtitle-text-1')]/..")
    private PWElement pageSubTitle;

    @PWFindBy(xpath = "//farmers-home-quote-knockouts//span[contains(@class,'sub-title-one') and strong]")
    private PWElement pageSubTitle2;

    private static final String NEED_MORE_HELP = "//farmers-home-quote-knockouts//div/p[contains(@class,'quote-step-caption')]";
    @PWFindBy(xpath = NEED_MORE_HELP)
    private PWElement pageFooter1;

    @PWFindBy(xpath = "//farmers-home-quote-knockouts//div/p[contains(@class,'quote-agent-info-label')]")
    private PWElement pageFooter2;

    @PWFindBy(xpath = "//farmers-home-quote-knockouts//div//a[starts-with(@href,'tel:1-8')]")
    private PWElement pageFooter3;

    private static final String BUTTON_TO_START_PARTNER_QUOTE = "//farmers-home-quote-knockouts//button[contains(.,'Start my quote')]";
    @PWFindBy(xpath = BUTTON_TO_START_PARTNER_QUOTE)
    private PWElement buttonToStartMyQuote;

    private static final String PAGE_TITLE_TEXT = "Your quote requires special attention";

    private static final String PAGE_TITLE_TEXT_MONETIZE = "We're sorry. We are unable to complete your request at this time.";

    private static final String PAGE_SUBTITLE_TEXT = "We will need a bit more information about your property. Your Farmers agent " +
            "will contact you to complete your quote.\n\nYou may also contact an agent yourself with the information below. " +
            "Please reference your quote number : %s";

   private static final String PAGE_SUBTITLE_TEXT_EE = "We need more information about your property.  " +
            "Please contact a service representative at %s. Please reference your quote number: %s";

    private static final String PAGE_SUBTITLE_TEXT_CA = "Please contact a Farmers agent or call us to discuss the wildfire risk " +
            "at your property and potential coverage options. \n \n" +
            "Your reference quote number : %s";

    private static final String PAGE_SUBTITLE_TEXT_MONETIZE = "In the meantime, the following companies may be able to provide " +
            "you with an online quote. Please compare 2 or more of the following options.";

    private final String AGENT_INFO_SECTION_XPATH = "//farmers-home-quote-knockouts//farmers-home-quote-agent-info";

    @PWFindBy(xpath = "//farmers-home-quote-knockouts//farmers-home-quote-agent-info//div/span[contains(@class,'quote-agent-name')]")
    private PWElement agentNameFooter;

    @PWFindBy(xpath = "//farmers-home-quote-knockouts//span[contains(@class,'quote-agent-p')]")
    private PWElement agentInfoFooter;

    @PWFindBy(xpath = "//farmers-home-quote-knockouts//img[contains(@class,'agent-img')]")
    private PWElement agentImage;

    @PWFindBy(xpath = "//farmers-home-quote-knockouts//a[starts-with(@href,'mailto:')]//" +
            "div[contains(@class,'body-two')]")
    private PWElement agentEmailAddress;

    @PWFindBy(xpath = "//farmers-home-quote-knockouts//a[@id='phnTagId']//span[contains(@class,'body-two')]")
    private PWElement agentPhoneNumber;

    @PWFindBy(xpath = "//farmers-home-quote-knockouts//a[@id='locTagId']//span[contains(@class,'body-two')]")
    private PWElement agentAddress;

    private static final String AGENT_INFO_FOOTER_TEXT = "Your local Farmers Insurance\u00ae Agent is available if you have any questions.";

    /**
     * Constructor.
     * @throws Exception
     */
    public KnockOutPage() throws Exception {
        super();
        waitElementBeVisible(pageTitle);
    }

    public void validatePageTitles(ApplicantHQM applicant, FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) throws Exception {
        waitElementBeVisible(linkFarmersLogo);
        QuoteRateHQM quoteRate = new ApiHelper().getQuoteRateFromJson(applicant.quoteNumber, BASIC);
        String knockoutCode = quoteRate != null ? quoteRate.getKnockoutCode() : "";
        String titleH1 = getTextFromElement(pageTitle);
        fsa.assertEquals(getAttributeData(linkFarmersLogo, "alt"), "Farmers Insurance\u00ae Logo", "KnockOut page - Farmers Insurance Logo.");
        if (!isEasternExpansionState(applicant.stateCode)) {
            if (!Arrays.asList(AR, CA, GA, IA, NV, OK, TN, TX, WA).contains(applicant.stateCode) || !applicant.getAgentId().isBlank()) {
                fsa.assertEquals(titleH1, (titleH1.endsWith(".") ? PAGE_TITLE_TEXT + "." : PAGE_TITLE_TEXT), "KnockOut page - page h1 Title.");
                fsa.assertEquals(getTextFromElement(pageSubTitle), String.format(PAGE_SUBTITLE_TEXT, applicant.quoteNumber), "KnockOut page - page SubTitle.");
            } else {
                if (knockoutCode.equals("HOM213BR097")) {
                    fsa.assertEquals(titleH1, (titleH1.endsWith(".") ? PAGE_TITLE_TEXT + "." : PAGE_TITLE_TEXT), "KnockOut page - page h1 Title.");
                    fsa.assertEquals(getTextFromElement(pageSubTitle), String.format(PAGE_SUBTITLE_TEXT_CA, applicant.quoteNumber), "KnockOut page - page SubTitle CA FAIR plan.");
                } else if (knockoutCode.equals("DWCONS045")) {
                    fsa.assertEquals(titleH1, PAGE_TITLE_TEXT_MONETIZE, "KnockOut page - page h1 Title, Digital Monetization Home Leads.");
                    fsa.assertEquals(getTextFromElement(pageSubTitle), PAGE_SUBTITLE_TEXT_MONETIZE, "KnockOut page - page SubTitle, Digital Monetization Home Leads.");
                    fsa.assertTrue(isElementDisplayed(PWBy.xpath(BUTTON_TO_START_PARTNER_QUOTE)), "KnockOut page - Digital Monetization Home Leads, " +
                            "Start My Quote button is displayed.");
                } else {
                    fsa.assertEquals(titleH1, (titleH1.endsWith(".") ? PAGE_TITLE_TEXT + "." : PAGE_TITLE_TEXT), "KnockOut page - page h1 Title.");
                    fsa.assertEquals(getTextFromElement(pageSubTitle), String.format(PAGE_SUBTITLE_TEXT, applicant.quoteNumber), "KnockOut page - page general SubTitle.");
                }
            }
        } else {
            fsa.assertEquals(titleH1, (titleH1.endsWith(".") ? PAGE_TITLE_TEXT + "." : PAGE_TITLE_TEXT), "KnockOut page - page h1 Title.");
            fsa.assertEquals(getTextFromElement(pageSubTitle), String.format(PAGE_SUBTITLE_TEXT_EE, CALL_FARMERS_EE, applicant.quoteNumber),
                    "KnockOut page - page SubTitle EE.");
        }
        if (staticContent != null) {
            String staticTitleH1 = "";
            String staticSubtitle = "";
            if (!knockoutCode.equals("DWCONS045") || !applicant.getAgentId().isBlank()) {
                staticTitleH1 = titleH1.endsWith(".") ? staticContent.getKnockoutTitle() + "." : staticContent.getKnockoutTitle();
                staticSubtitle = staticContent.getKnockoutCaption();
            } else {
                staticTitleH1 = staticContent.getMaxCoverageExceededTitle();
                staticSubtitle = staticContent.getMaxCoverageExceededTitleKOCaption();
            }
            fsa.assertEquals(staticTitleH1, titleH1, "KnockOut page - page Title h1 (AEM).");
            if (!isEasternExpansionState(applicant.stateCode)) {
                if (!Arrays.asList(AR, CA, GA, IA, NV, OK, TN, TX, WA).contains(applicant.stateCode) || !applicant.getAgentId().isBlank()) {
                    fsa.assertEquals(staticSubtitle + " : " + applicant.quoteNumber,
                            String.format(PAGE_SUBTITLE_TEXT.replace("\n\n", ""), applicant.quoteNumber), "KnockOut page - page SubTitle (AEM).");
                } else {
                    if (knockoutCode.equals("HOM213BR097")) {
                        fsa.assertEquals(staticContent.getKnockoutCaptionCA() + ": " + applicant.quoteNumber,
                                String.format(PAGE_SUBTITLE_TEXT_CA.replace("\n\n", ""), applicant.quoteNumber), "KnockOut page - page SubTitle CA FAIR plan (AEM).");
                    } else if (knockoutCode.equals("DWCONS045")) {
                        staticSubtitle = staticSubtitle.replace(SPACE+SPACE,SPACE);
                        fsa.assertEquals(staticSubtitle, PAGE_SUBTITLE_TEXT_MONETIZE, "KnockOut page - page SubTitle, Digital Monetization Home Leads (AEM).");
                    } else {
                        fsa.assertEquals(staticSubtitle + ": " + applicant.quoteNumber,
                                String.format(PAGE_SUBTITLE_TEXT.replace("\n\n", ""), applicant.quoteNumber), "KnockOut page - page SubTitle (AEM).");
                    }
                }
            } else {
                fsa.assertEquals(staticContent.getKnockoutCaption().replace("[Phone_Number]", CALL_FARMERS_EE).replace("\n\n", " ") + ": " + applicant.quoteNumber,
                        String.format(PAGE_SUBTITLE_TEXT_EE, CALL_FARMERS_EE, applicant.quoteNumber), "KnockOut page - page SubTitle EE (AEM).");
            }
        }
    }

    public void validatePageFooters(ApplicantHQM applicant, String quoteSource, FarmersSoftAssert fsa) throws Exception {
        // @quoteSource param is re-used as AEM campaign phone number, when it's not null and not QQ.
        final String DIGITAL_MONETIZATION_HOME_LEAD_PHONE = "1-888-587-2121";
        if (!isEasternExpansionState(applicant.stateCode)) {
            AgentInfoHQM agentInfo = getAgentInfo(applicant.quoteNumber);
            if ((agentInfo == null) || (agentInfo.getAgent().getLastName() == null) || !isElementPresent(PWBy.xpath(AGENT_INFO_SECTION_XPATH))) {
                if (isElementPresent(PWBy.xpath(NEED_MORE_HELP))) {
                    fsa.assertEquals(getTextFromElement(pageFooter1), "Need more help?", "Validate KnockOut page footer 1.");
                    fsa.assertEquals(getTextFromElement(pageFooter2), "You can call customer service at", "Validate KnockOut page footer 2.");
                    fsa.assertEquals(getTextFromElement(pageFooter3), getContactUsPhoneNumber(applicant, quoteSource, false),
                            "KnockOut page - Call Farmers Insurance number is displayed.");
                } else {
                    fsa.assertEquals(getTextFromElement(pageFooter2), "You can call customer service at", "Validate KnockOut page footer Digital Monetization Home Lead.");
                    fsa.assertEquals(getTextFromElement(pageFooter3), DIGITAL_MONETIZATION_HOME_LEAD_PHONE,
                            "KnockOut page - Validate KnockOut page footer Phone number for Digital Monetization Home Lead.");
                }
            } else {
                if ((agentInfo.getAgent().getAgentImageUrl() != null) && !agentInfo.getAgent().getAgentImageUrl().isBlank()) {
                    fsa.assertEquals(getAttributeData(agentImage, SRC), agentInfo.getAgent().getAgentImageUrl(),
                            "Validate Thank You page - Agent Image Url in the footer.");
                }
                fsa.assertEquals(getTextFromElement(agentNameFooter), agentInfo.getAgent().getFirstName() + SPACE
                        + agentInfo.getAgent().getLastName(), "Validate Thank You page Agent Name footer.");
                fsa.assertEquals(getTextFromElement(agentInfoFooter), AGENT_INFO_FOOTER_TEXT, "Validate KnockOut page - Agent Info footer.");
                fsa.assertEquals(getTextFromElement(agentEmailAddress), agentInfo.getAgentEmailAddress(), "Validate KnockOut page - Agent Email Address.");
                fsa.assertEquals(getTextFromElement(agentPhoneNumber), agentInfo.getAgentPhoneNumber(), "Validate KnockOut page - Agent Phone Number.");
                if (!agentInfo.getAgent().getAddress().getCity().isEmpty()) {
                    fsa.assertEquals(getTextFromElement(agentAddress), agentInfo.getAgentFullAddress(), "Validate KnockOut page - Agent Address.");
                }
            }
        }
    }

}
