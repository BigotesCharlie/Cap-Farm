package com.farmers.ffq.datatransferobjects;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
public class CaptchaRequestBean {
    private ValidateCaptchaRequestBean validateCaptchaRequestBean;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties
    @Data
    public static class ValidateCaptchaRequestBean {
        private String quoteNumber;
        private String lob;
        private String caId;
    }


}
