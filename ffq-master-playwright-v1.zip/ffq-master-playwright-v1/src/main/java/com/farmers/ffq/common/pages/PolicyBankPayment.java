package com.farmers.ffq.common.pages;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.auto.pages.bindpages.AutoPolicyPaymentBasePage;
public class PolicyBankPayment extends AutoPolicyPaymentBasePage {

    private static final String BANK_ACCOUNT_TYPE_HEADER = "BANK ACCOUNT TYPE";
    @PWFindBy(xpath = "//legend[contains(text(), '" + BANK_ACCOUNT_TYPE_HEADER + "')]")
    private PWElement bankAccountTypeHeader;

    @PWFindBy(xpath = "//fieldset//div/div[1]")
    private PWElement checkingRadioButton;

    @PWFindBy(xpath = "//fieldset//div/div[1]/input")
    private PWElement checkingRadioButtonInput;

    private static final String CHECKING_LABEL = "Checking";
    @PWFindBy(xpath = "//label[text() = '" + CHECKING_LABEL + "']")
    private PWElement checkingLabel;

    @PWFindBy(xpath = "//fieldset//div/div[2]")
    private PWElement savingsRadioButton;

    @PWFindBy(xpath = "//fieldset//div/div[3]")
    private PWElement businessCheckingRadioButton;

    private static final String ACCOUNT_HOLDER_NAME_LABEL = "Account Holder Name";
    @PWFindBy(xpath = "//label[text() = '" + ACCOUNT_HOLDER_NAME_LABEL + "']")
    private PWElement accountHolderNameLabel;

    private static final String BANK_ROUTING_NUMBER = "Bank Routing Number (9 digits)";
    @PWFindBy(xpath = "//label[text() = '" + BANK_ROUTING_NUMBER + "']")
    private PWElement bankRoutingNumberLabel;

    @PWFindBy(xpath = "//input[@id='routingNumberField']")
    private PWElement routingNumberInputField;

    private static final String ACCOUNT_NUMBER = "Account Number";
    @PWFindBy(xpath = "//label[text() = '" + ACCOUNT_NUMBER + "']")
    private PWElement accountNumberLabel;

    @PWFindBy(xpath = "//input[@id='bankAccountField']")
    private PWElement accountNumberInputField;

    private static final String CONFIRM_ACCOUNT_NUMBER = "Confirm Account Number";
    @PWFindBy(xpath = "//label[text() = '" + CONFIRM_ACCOUNT_NUMBER + "']")
    private PWElement confirmAccountNumberLabel;

    @PWFindBy(xpath = "//input[@id='confirmBankAccountField']")
    private PWElement confirmBankAccountInputField;


    private static final String CHECK_CIRCLE = "check_circle";
    @PWFindBy(xpath = "//mat-icon[text() = '" + CHECK_CIRCLE + "']")
    private PWElement greenCheckMark;

    public static final String NO_SERVICE_CHARGE_WHEN_USING_BANK = "No service charges when using bank transfer.";
    @PWFindBy(xpath = "//span[text() = '" + NO_SERVICE_CHARGE_WHEN_USING_BANK + "']")
    private PWElement noServiceChargeWhenUsingBankTransfer;

    @PWFindBy(xpath = "//*[@id='accountNumber']")
    private PWElement maskedAccountNumber;

    protected static final String CHANGE_TO_NEW_PAYMENT_METHOD = "Change to a new payment method";
    @PWFindBy(xpath = "//span[contains(text(), 'Change to a new payment method')]")
    private PWElement changeToNewPaymentMethodHeader;

    private static final String INFORMATION_STORAGE_AUTHORIZATION = "Information Storage Authorization";
    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO_PAY_IN_FULL = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate:";
    @PWFindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p")
    private PWElement readAndAgreedToTheBulletPointTwoPayInFull;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public PolicyBankPayment() throws Exception {
    }

    public boolean isBankAccountTypeHeaderCorrect() {
        return isExpectedTextDisplayed(bankAccountTypeHeader, BANK_ACCOUNT_TYPE_HEADER);
    }

    public boolean isCheckingRadioButtonSelected(){
        waitElementBeVisible(checkingRadioButton);
        return checkingRadioButtonInput.isSelected();
    }

    public boolean isCheckingLabelCorrect(){
        return isExpectedTextDisplayed(checkingLabel, CHECKING_LABEL);
    }

    public boolean isSavingsRadioButtonEnabled(){
        return savingsRadioButton.isEnabled();
    }


    public boolean isBusinessCheckingRadioButtonEnabled(){
        return businessCheckingRadioButton.isEnabled();
    }

    public boolean isAccountHolderNameLabelCorrect(){
        return isExpectedTextDisplayed(accountHolderNameLabel, ACCOUNT_HOLDER_NAME_LABEL);
    }

    public boolean isBankRoutingNumberLabelCorrect(){
        return isExpectedTextDisplayed(bankRoutingNumberLabel, BANK_ROUTING_NUMBER);
    }

    public boolean isAccountNumberLabelCorrect(){
        return isExpectedTextDisplayed(accountNumberLabel, ACCOUNT_NUMBER);
    }

    public boolean isConfirmAccountNumberLabelCorrect(){
        return isExpectedTextDisplayed(confirmAccountNumberLabel, CONFIRM_ACCOUNT_NUMBER);
    }

    public void enterAccountNumber(String accountNumber){
        sendKeysOneByOne(accountNumberInputField, accountNumber);
    }

    public void enterConfirmAccountNumber(String accountNumber){
        sendKeysOneByOne(confirmBankAccountInputField, accountNumber);
    }

    public boolean isNoServiceChargeWhenUsingBankMsgCorrect(){
        return isExpectedTextDisplayed(noServiceChargeWhenUsingBankTransfer, NO_SERVICE_CHARGE_WHEN_USING_BANK);
    }


    public boolean isHiddenBankAccountMonthlyPayTextCorrect(String bankAccountNumber) throws Exception {
        String lastFourDigitOfAccountNumber;
        if(bankAccountNumber == null){
            lastFourDigitOfAccountNumber = getSessionStorageAppStore().getPaymentusIframeData().getMaskedAccountNumber().replaceAll("[*]","");
        }else{
            lastFourDigitOfAccountNumber = bankAccountNumber.substring(bankAccountNumber.length()-2);
        }
        wait.until(PWExpectedConditions.visibilityOf(maskedAccountNumber));
        return getTextFromElement(maskedAccountNumber).contains(lastFourDigitOfAccountNumber);
    }

    public boolean isHiddenBankAccountPayInFullTextCorrect(String bankAccountNumber) throws Exception {
        String lastFourDigitOfAccountNumber;
        if(bankAccountNumber == null){
            lastFourDigitOfAccountNumber = getSessionStorageAppStore().getPaymentusIframeData().getMaskedAccountNumber().replaceAll("[*]","");
        }else{
            lastFourDigitOfAccountNumber = bankAccountNumber.substring(bankAccountNumber.length()-4);
        }
        scrollElementToMiddle(maskedAccountNumber);
        return getTextFromElement(maskedAccountNumber).contains(lastFourDigitOfAccountNumber);
    }

    public boolean isChangeToPaymentMethodLabelCorrect(){
        wait.until(PWExpectedConditions.visibilityOf(changeToNewPaymentMethodHeader));
        return isExpectedTextDisplayed(changeToNewPaymentMethodHeader, CHANGE_TO_NEW_PAYMENT_METHOD);
    }

    public boolean isReadAndAgreedBulletPointTwoPayInFullCorrect(){
        return isExpectedTextDisplayed(readAndAgreedToTheBulletPointTwoPayInFull, READ_AND_AGREED_TO_THE_BULLET_TWO_PAY_IN_FULL);
    }

}
