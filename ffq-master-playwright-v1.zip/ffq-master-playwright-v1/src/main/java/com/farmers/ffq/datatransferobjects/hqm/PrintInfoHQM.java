package com.farmers.ffq.datatransferobjects.hqm;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.NEWLINE;
import static com.farmers.ffq.utils.GlobalVariables.SPACE;

public class PrintInfoHQM {
    private String quoteNumber;
    private String lob;
    private String lobHeading;
    private String firstName;
    private String lastName;
    private String annualPremium;
    private String monthlyPremium;
    private Agent agent;
    private List<Section> sections;

    public String getQuoteNumber() {
        return quoteNumber;
    }

    public String getLob() {
        return lob;
    }

    public String getLobHeading() {
        return lobHeading;
    }


    public List<Section> getSections() {
        return sections;
    }

    public String getAgentPhoneNumber () {
        String phone =  getAgent().getCommunication().getPhoneNumber().get(0).getPhoneNumber();
        return phone.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "$1-$2-$3");
    }

    public String getAgentEmailAddress () {
        if (getAgent().getCommunication().getEmailId() != null) {
            return getAgent().getCommunication().getEmailId().get(0).getEmailAddress();
        } else {
            return null;
        }
    }

    public String getAgentFullAddress() {
        return getAgent().getAddress().getStreet() + NEWLINE + getAgent().getAddress().getCity() + ", "
                + getAgent().getAddress().getState() + SPACE  + getAgent().getAddress().getZipCode();
    }

    public Agent getAgent() {
        return agent;
    }

    public static class Agent {
        private String firstName;
        private String lastName;
        private Address address;
        private Communication communication;
        private String agentId;
        private String agentImageUrl;
        private String reference;
        private String assign;
        private String agentTier;
        private String isBuyEnabled;
        private String leadId;

        public String getFirstName() {
            return firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public Address getAddress() {
            return address;
        }

        public Communication getCommunication() {
            return communication;
        }

        public String getAgentId() {
            return agentId;
        }

        public String getAgentImageUrl() {
            return agentImageUrl;
        }

        public String getReference() {
            return reference;
        }

        public String getAssign() {
            return assign;
        }

        public String getAgentTier() {
            return agentTier;
        }

        public String getIsBuyEnabled() {
            return isBuyEnabled;
        }

        public String getLeadId() {
            return leadId;
        }
    }

    public static class Address {
        private String city;
        private String state;
        private String zipCode;
        private String street;

        public String getCity() {
            return city;
        }

        public String getState() {
            return state;
        }

        public String getZipCode() {
            return zipCode;
        }

        public String getStreet() {
            return street;
        }
    }

    public static class Communication {
        private List<PhoneNumber> phoneNumber;
        private List<EmailId> emailId;

        public List<PhoneNumber> getPhoneNumber() {
            return phoneNumber;
        }

        public List<EmailId> getEmailId() {
            return emailId;
        }
    }

    public static class PhoneNumber {
        private String phoneNumber;

        public String getPhoneNumber() {
            return phoneNumber;
        }
    }

    public static class EmailId {
        private String emailAddress;

        public String getEmailAddress() {
            return emailAddress;
        }
    }

    public static class Section {
        private String sectionHeading;
        private String leftHeading;
        private String rightHeading;
        private List<SectionData> sectionData;

        public String getSectionHeading() {
            return sectionHeading;
        }

        public String getLeftHeading() {
            return leftHeading;
        }

        public String getRightHeading() {
            return rightHeading;
        }

        public List<SectionData> getSectionData() {
            return sectionData;
        }
    }

    public static class SectionData {
        private String webDesc;
        private String limit;
        private String discountCode;

        public String getWebDesc() {
            return webDesc;
        }

        public String getLimit() {
        	return limit; 
        }

        public String getDiscountCode() { 
        	return discountCode; 
        }

    }
}
