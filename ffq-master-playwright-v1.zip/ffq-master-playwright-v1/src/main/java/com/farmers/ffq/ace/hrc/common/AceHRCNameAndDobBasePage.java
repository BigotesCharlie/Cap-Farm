package com.farmers.ffq.ace.hrc.common;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCNameAndDobBasePage extends AceHRCBasePage {

    private static final String DATE_OF_BIRTH_IS_NOT_A_VALID_ENTRY = "Date of birth is not a valid entry.";
    private static final String INVALID_DATE_OF_BIRTH = "Invalid date of birth";
    private static final String LOG_MESSAGE_TEMPLATE = "Entering ";

    protected static final String LETS_BEGIN_TITLE = "Let's begin";
    @PWFindBy(xpath = "//div[contains(@class,'personal-info_name_dob_h1')][1]")
    protected PWElement letsBeginTitle;

    protected static final String LETS_BEGIN_SUBTITLE = "Get started with just a few details.";
    @PWFindBy(xpath = "//div[@id='personal-info_name_dob-subheading']")
    protected PWElement letsBeginSubtitle;

    private static final String FIRST_NAME = "First name";
    @PWFindBy(xpath = "//input[contains(@aria-label,'" + FIRST_NAME + "')]")
    protected PWElement firstNameInputBox;

    @PWFindBy(xpath = "//mat-label[contains(text(), '" + FIRST_NAME + "')]")
    private PWElement firstNameAriaLabelText;

    private static final String LAST_NAME = "Last name";
    @PWFindBy(xpath = "//input[contains(@aria-label,'" + LAST_NAME + "')]")
	protected PWElement lastNameInputBox;
    @PWFindBy(xpath = "//mat-label[contains(text(), '" + LAST_NAME + "')]")
    private PWElement lastNameAriaLabelText;

    private static final String DATE_OF_BIRTH = "Date of birth";
    @PWFindBy(xpath = "//input[contains(@aria-label,'" + DATE_OF_BIRTH + "')]")
    protected PWElement dateOfBirthInputBox;
    @PWFindBy(xpath = "//mat-label[contains(text(), '" + DATE_OF_BIRTH + "')]")
    private PWElement dateOfBirthAriaLabelText;
    @PWFindBy(xpath = "//mat-hint[contains(text(), 'mm/dd/yyyy')]")
    private PWElement mmddyyyyHint;

    private static final String REQUIRED_OR_INCOMPLETE_FIELD_ERROR_MESSAGE = "One or more required fields are incomplete or incorrect. Please review.";
    @PWFindBy(xpath = "//p[contains(text(), '" + REQUIRED_OR_INCOMPLETE_FIELD_ERROR_MESSAGE + "')]")
    private PWElement requiredOrIncompleteErrorMessage;

    @PWFindBy(xpath = "//app-personal-info//div[button]/preceding-sibling::p[contains(@class, 'tui-body-text-1')]")
    private PWElement footerSubtitle;

    @PWFindBy(xpath = "//button[contains(text(), 'Agree')]")
    private PWElement buttonAgree;

    @PWFindBy(xpath = "//app-personal-info//div[contains(@class,'disclaimer__credit-report')]//p[1]")
    private PWElement creditReportDisclaimer;
    @PWFindBy(xpath = "//app-personal-info//div[contains(@class,'disclaimer__credit-report')]//p[2]")
    private PWElement consumerReportDisclaimer;
    @PWFindBy(xpath = "//app-personal-info//div[contains(@class,'disclaimer__color') and not(@hidden)]")
    private PWElement privacyPolicyDisclaimer;
    @PWFindBy(xpath = "//app-personal-info//div[contains(@class,'disclaimer__color')]//a")
    private PWElement privacyPolicyLink;
    private static final String PRIVACY_POLICY_URL = "https://www.farmers.com/disclaimer/privacy-policy/";

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceHRCNameAndDobBasePage() throws Exception {
        super();
    }

    public boolean isOnNameAndDobPage(boolean longWait) {
        waitForSpinnerToBeGone();
        int timeout = longWait ? Property.PAGELOADTIMEOUT : 10;
        return isElementVisible(firstNameInputBox, timeout);
    }

    public void fillOutNameAndDobPage(ApplicantAceHome applicant) {
        waitAndClickElement(firstNameInputBox);
        enterValueInField(applicant.getFirstName(), firstNameInputBox, LOG_MESSAGE_TEMPLATE + FIRST_NAME + COLON + SPACE);
        enterValueInField(applicant.getLastName(), lastNameInputBox, LOG_MESSAGE_TEMPLATE + LAST_NAME + COLON + SPACE);
        enterValueInField(applicant.getDateOfBirth(), dateOfBirthInputBox, LOG_MESSAGE_TEMPLATE + DATE_OF_BIRTH + COLON + SPACE);
        clickAgreeButton();
    }

    public void clickAgreeButton() {
        waitAndClickElement(buttonAgree);
    }

    public void validateContentOfPrimaryApplicant(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isElementInViewport(letsBeginTitle), "About you - page title is in Viewport");
        fsa.assertEquals(getTextFromElement(letsBeginTitle), LETS_BEGIN_TITLE, "Name and DOB page title.");
        fsa.assertEquals(getTextFromElement(letsBeginSubtitle), LETS_BEGIN_SUBTITLE, "Name and DOB page sub-title.");
        fsa.assertTrue(isFirstNameInputBoxDisplayed(), "First name input box displayed");
        fsa.assertTrue(isLastNameInputBoxDisplayed(), "Last name input box displayed");
        fsa.assertTrue(isDateOfBirthInputBoxDisplayed(), "Date of birth input box displayed");
        fsa.assertTrue(isMMDDYYHintDisplayed(), "MMDDYYYY hint displayed");
    }

    public void validateNameAndDobPrimaryApplicant(FarmersSoftAssert fsa, ApplicantAceHome applicant) {
        fsa.assertEquals(getFirstName(), applicant.getFirstName(), "Name and DOB page - First name is saved.");
        fsa.assertEquals(getLastName(), applicant.getLastName(), "Name and DOB page - Last name is saved.");
        fsa.assertEquals(getDateOfBirth(), applicant.getDateOfBirth(), "Name and DOB page - Date of birth is saved.");
    }

    public boolean isFirstNameInputBoxDisplayed() {
        return firstNameInputBox.isDisplayed();
    }

    public boolean isLastNameInputBoxDisplayed() {
        return lastNameInputBox.isDisplayed();
    }

    public boolean isDateOfBirthInputBoxDisplayed() {
        return dateOfBirthInputBox.isDisplayed();
    }

    public boolean isMMDDYYHintDisplayed() {
        return isElementDisplayed(mmddyyyyHint, 3);
    }

    public String getFirstName() {
        return getValueFromWebElement(firstNameInputBox);
    }

    public boolean isFirstNameReadOnly() {
        return isAttributePresent(firstNameInputBox, DISABLED);
    }

    public String getLastName() {
        return getValueFromWebElement(lastNameInputBox);
    }

    public boolean isLastNameReadOnly() {
        return isAttributePresent(lastNameInputBox, DISABLED);
    }

    public String getDateOfBirth() {
        return getValueFromWebElement(dateOfBirthInputBox);
    }

    public boolean isDateOfBirthReadOnly() {
        return isAttributePresent(dateOfBirthInputBox, DISABLED);
    }

    public void validateDisclaimers(FarmersSoftAssert fsa, String stateCode, String propertyType) throws Exception {
        String FARMERS_MAY_REVIEW_YOUR_CREDIT_REPORT = "In connection with this application for insurance, Farmers may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report.";
        String FARMERS_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT = "In connection with this application for insurance, Farmers may review your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report.";
        String FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT = "In connection with this application for insurance, Farmers and/or affiliates may review your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report.";

        String WE_MAY_USE_THIRD_PARTIES = "We may use third parties in connection with the development of your insurance scores based on data from traditional credit bureaus and the National Consumer Telecom & Utilities Exchange database.";
        String WE_MAY_USE_A_THIRD_PARTY = "We may use a third party in connection with the development of your insurance scores based on data from traditional credit bureaus and the National Consumer Telecom & Utilities Exchange database.";

        String EXTRAORDINARY_CIRCUMSTANCES = "If you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, in writing, that we provide reasonable exceptions to our underwriting and/or rating practices.";
        String CONTACT_A_FARMERS_REPRESENTATIVE = "Please contact a Farmers\u00ae representative for details on qualifying circumstances and how to request an exception.";

        String CONSUMER_REPORT_ADDITIONAL_DISCLAIMER = "Any estimate provided will reflect rates in effect as of the date of that estimate and is subject to revision, including revision based on verification of information and inspection if needed." + SPACE +
                "Premium may vary based on additional information, coverages, and deductibles that you select, underwriting criteria, and any changes to assumptions." + SPACE +
                "Farmers reserves the right to accept, reject, or modify this quote after review of an application and other underwriting information." + SPACE +
                "Applications are subject to underwriting approval. Farmers online auto quotes are available for new auto customers.";

        String expectedCreditReportDisclaimer = FARMERS_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE + WE_MAY_USE_THIRD_PARTIES;
        String expectedConsumerReportDisclaimer = "Farmers entities may use any consumer report information their affiliates might currently have for you for your quote request." + SPACE +
                "Our Privacy Notice gives you the choice to opt out of allowing Farmers affiliates to share your consumer report information among Farmers entities." + SPACE +
                "You can still opt out of future sharing.";
        String expectedPrivacyPolicyDisclaimer = "By clicking \"Agree\", you acknowledge that you've read and agree to the Privacy Policy and the above consumer report information provisions." + SPACE +
                "Otherwise contact a Farmers\u00ae representative to discuss options.";
        String expectedSectionDisclaimer = "By clicking 'Agree', you agree to terms below.";

        if (isNoSpouseCreditInCondoRentersDisclaimersState(stateCode) && (propertyType.equals(CONDO) || propertyType.equals(RENTERS))) {
            expectedCreditReportDisclaimer = FARMERS_MAY_REVIEW_YOUR_CREDIT_REPORT + SPACE + WE_MAY_USE_THIRD_PARTIES;
        } else {
            switch (stateCode) {
                case CA:
                    expectedCreditReportDisclaimer = "In connection with this application for insurance, Farmers may obtain consumer reports or personal information from third parties. This information, as well as " +
                            "other personal information subsequently collected by the insurer or your agent, may in certain circumstances be disclosed to third parties without authorization, as permitted by law.";
                    if (propertyType.equals(RENTERS)) {
                        expectedConsumerReportDisclaimer = EMPTY_STRING;
                    } else if (propertyType.equals(HOME)) {
                        expectedConsumerReportDisclaimer = expectedConsumerReportDisclaimer + SPACE + CONSUMER_REPORT_ADDITIONAL_DISCLAIMER;
                    } else if (propertyType.equals(CONDO)) {
                        expectedConsumerReportDisclaimer = EMPTY_STRING;
                        expectedPrivacyPolicyDisclaimer = "By clicking \"Agree\", you acknowledge that you have read and agree to the Privacy Policy and agree to the use of consumer report information described above. " +
                                "Otherwise, you can contact a Farmers\u00ae representative to discuss your options.";
                    }
                    break;
                case CT:
                    expectedCreditReportDisclaimer = FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                            "We may use third parties in connection with the development of your insurance scores based on data from traditional credit bureaus." + SPACE +
                            "If you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, in writing, that we provide reasonable exceptions to our underwriting and/or rating practices for this quote or any policy issued." + SPACE +
                            CONTACT_A_FARMERS_REPRESENTATIVE;
                    break;
                case IA:
                    expectedCreditReportDisclaimer = FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                            WE_MAY_USE_THIRD_PARTIES + SPACE +
                            EXTRAORDINARY_CIRCUMSTANCES + SPACE +
                            CONTACT_A_FARMERS_REPRESENTATIVE;
                    break;
                case IL:
                    if (!propertyType.equals(CONDO) && !propertyType.equals(RENTERS)) {
                        expectedConsumerReportDisclaimer = expectedConsumerReportDisclaimer + SPACE + CONSUMER_REPORT_ADDITIONAL_DISCLAIMER;
                    }
                    break;
                case KS:
                    expectedCreditReportDisclaimer = FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                            WE_MAY_USE_THIRD_PARTIES + SPACE +
                            "We provide an internal appeal process whereby you may ask us to review an adverse action based on your credit information." + SPACE +
                            "Also, if you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, in writing, that we provide reasonable exceptions to our underwriting and/or rating practices." + SPACE +
                            CONTACT_A_FARMERS_REPRESENTATIVE;
                    break;
                case KY:
                    expectedCreditReportDisclaimer = FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                            WE_MAY_USE_THIRD_PARTIES + SPACE +
                            EXTRAORDINARY_CIRCUMSTANCES + SPACE +
                            CONTACT_A_FARMERS_REPRESENTATIVE;
                    break;
                case MD:
                    expectedCreditReportDisclaimer = "Farmers Privacy Notice gives you the choice to opt out of allowing Farmers affiliates to share your consumer report information among Farmers entities." + SPACE +
                            "May Farmers entities use any consumer report information their affiliates might currently have for you for this specific transaction. You can still opt out of future sharing.";
                    break;
                case MI:
                    expectedCreditReportDisclaimer = FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                            WE_MAY_USE_THIRD_PARTIES + SPACE +
                            EXTRAORDINARY_CIRCUMSTANCES + SPACE +
                            CONTACT_A_FARMERS_REPRESENTATIVE;
                    break;
                case MN:
                    expectedCreditReportDisclaimer = "The insurer may elect to cancel coverage at any time during the first 59 days following issuance of the coverage for any reason which is not specifically prohibited by statute.";
                    expectedConsumerReportDisclaimer = "Your state also requires us to tell you that we may obtain consumer reports or personal or privileged information from third parties." + SPACE +
                            "This information as well as other personal or privileged information subsequently collected by us or your agent may be used for underwriting or rating and in certain circumstances may be disclosed to third parties without authorization, as permitted by law." + SPACE +
                            "You have the right of access and correction with respect to all personal information collected." + SPACE +
                            "At your request, we will provide you with more detailed information regarding our collection, use and disclosure of personal information, and your rights to access and correct such information." + SPACE +
                            "By continuing, you authorize us and your agent to collect and disclose your personal and privileged information." + SPACE +
                            "This authorization will remain valid for as long as you are continually insured with us." + SPACE +
                            FARMERS_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                            WE_MAY_USE_THIRD_PARTIES + SPACE +
                            EXTRAORDINARY_CIRCUMSTANCES + SPACE +
                            "Please contact us for details on qualifying circumstances and how to request an exception." + SPACE +
                            expectedConsumerReportDisclaimer;
                    break;
                case MT:
                    expectedConsumerReportDisclaimer = "Also, Farmers entities may use any consumer report information their affiliates might currently have for you for this transaction.";
                    expectedPrivacyPolicyDisclaimer = "By clicking \"Agree\", you acknowledge that you have read and agree to the Privacy Policy and agree to the use of consumer report information described above. Otherwise, you can contact a Farmers\u00ae representative to discuss your options.";
                    break;
                case NC:
                    expectedCreditReportDisclaimer = FARMERS_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                            WE_MAY_USE_THIRD_PARTIES + SPACE +
                            "In addition to a $3 installment fee, we also may charge a $15 late fee, a $20 returned payment charge, or a $25 reinstatement fee." + SPACE +
                            "This policy is also subject to a policy fee of $25. By proceeding, you agree to pay any fees assessed.";
                    break;
                case NM:
                    expectedCreditReportDisclaimer = "In connection with this application for insurance coverage, Farmers may review and use information contained in your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report to help determine your premium or your eligibility for coverage." + SPACE +
                            WE_MAY_USE_A_THIRD_PARTY;
                    break;
                case OK:
                    expectedCreditReportDisclaimer = FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                            WE_MAY_USE_THIRD_PARTIES + SPACE +
                            EXTRAORDINARY_CIRCUMSTANCES + SPACE +
                            CONTACT_A_FARMERS_REPRESENTATIVE;
                    break;
                case OR:
                    expectedCreditReportDisclaimer = FARMERS_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                            WE_MAY_USE_THIRD_PARTIES + SPACE +
                            "You may request that we give you a written statement describing our use of credit history and insurance scores.";
                    break;
                case VA:
                    expectedCreditReportDisclaimer = "In connection with this application for insurance, Farmers shall review your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report." + SPACE +
                            WE_MAY_USE_THIRD_PARTIES + SPACE +
                            "You may request that your credit information be updated and if you question the accuracy of the credit information, we will, upon your request, reevaluate you based on corrected credit information from a consumer reporting agency.";
                    break;
                case TX:
                    expectedCreditReportDisclaimer =  "We will obtain and use credit information, from traditional credit bureaus and the National Consumer Telecom & Utilities Exchange database, on you [and your spouse] as a part of the insurance credit scoring process.";
                    break;
            }
        }
        fsa.assertEquals(getTextFromElement(footerSubtitle), expectedSectionDisclaimer, "Name and DOB page - footer disclaimer sub-title " + stateCode);
        fsa.assertTrue(buttonAgree.isDisplayed(), "Name and DOB page - Agree button is displayed " + stateCode);
        fsa.assertEquals(getTextFromElement(creditReportDisclaimer), expectedCreditReportDisclaimer, "Name and DOB page - Credit report disclaimer for " + stateCode);
        fsa.assertEquals(getTextFromElement(consumerReportDisclaimer), expectedConsumerReportDisclaimer, "Name and DOB page - Consumer report disclaimer for " + stateCode);
        fsa.assertEquals(getTextFromElement(privacyPolicyDisclaimer), expectedPrivacyPolicyDisclaimer, "Name and DOB page - Privacy Policy disclaimer for " + stateCode);
        fsa.assertEquals(getTextFromElement(privacyPolicyLink), "Privacy Policy", "Name and DOB page - Privacy Policy link label");
        fsa.assertTrue(getAttributeData(privacyPolicyLink, HREF).contains(PRIVACY_POLICY_URL), "Name and DOB page - Privacy Policy link contains expected url.");
    }

    public boolean isNoSpouseCreditInCondoRentersDisclaimersState (String stateCode) {
        return List.of(AL, AZ, AR, IL, MO, ND, PA, SD, TN, WI, WY).contains(stateCode);
    }

    public void capturePEWC(String filename) throws Exception {
    	scrollToBottomOfPage();
        screenCapture(buttonAgree, filename, LARGE, false);
    }

}
