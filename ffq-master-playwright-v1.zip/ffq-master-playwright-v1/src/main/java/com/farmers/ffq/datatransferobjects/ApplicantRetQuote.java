package com.farmers.ffq.datatransferobjects;
import lombok.Data;

@Data
public class ApplicantRetQuote {

	private String lastName;
    private int age;
    private String zipCode;
    private String emailAddress;
    private String quoteNumber;
    private String pageLeftOn;

	public String toString() {
		return String.format("quote %s left in %s for %s from %s", quoteNumber, pageLeftOn, lastName, zipCode);
	}
}
