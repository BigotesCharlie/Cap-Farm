/**
=============================================
* Author:	Zhabiz Sonee
* Create date:	05/01/2017
=============================================
*/
package com.farmers.ffq.datatransferobjects;
import lombok.Data;

@Data
public class SqlIncident {
	private int incidentId;
	private int applicantId;
	private int additionalDriverId;
	private String incidentType;
	private String description;
	private int dateOccuredOffsetInDays;
	private String dateOccured;
	private boolean anyInjuries;
	private String mediaAlphaIncidentType;
	private String mediaAlphaIncidentDescription;
	private String mediaAlphaAmountPaidByInsurance;
	private String mediaAlphaDamageTo;
	private boolean mediaAlphaDriverAtFault;
}
