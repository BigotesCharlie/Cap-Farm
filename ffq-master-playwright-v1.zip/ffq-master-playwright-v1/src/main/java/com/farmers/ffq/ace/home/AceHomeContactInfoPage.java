package com.farmers.ffq.ace.home;

import com.farmers.ffq.ace.hrc.common.AceHRCContactInfoBasePage;

public class AceHomeContactInfoPage extends AceHRCContactInfoBasePage {

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceHomeContactInfoPage() throws Exception {
        super();
    }
/*
    public void fillOutWildfireRiskReductionCA(String wildfireRiskReduction) throws Exception {
        if (isElementDisplayed(By.xpath(WILDFIRE_RISK_REDUCTION_XPATH))) {
            if (!wildfireRiskReduction.isBlank()) {
                if (!getAttributeData(wildfireRiskMatButtonToggleYes, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED)) {
                    clickElement(wildfireRiskButtonToggleYes);
                    enterWildfireRiskReductionOptions(wildfireRiskReduction);
                }
            } else {
                if (!getAttributeData(wildfireRiskMatButtonToggleNo, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED)) {
                    clickElement(wildfireRiskButtonToggleNo);
                }
            }
        }
    }

    public void enterWildfireRiskReductionOptions(String options) throws Exception {
        List<String> listOptions = Stream.of(options.split(COMMA)).map(String::trim).collect(Collectors.toList());
        boolean updated = false;
        for (String option: listOptions) {
            WebElement weMatCheckbox = driver().findElement(By.xpath(String.format(WILDFIRE_RISK_REDUCTION_MAT_CHECKBOX_XPATH,option)));
            if (getAttributeData(weMatCheckbox, CLASS).contains(MAT_CHECKBOX_DISABLED)) {
                continue;
            }
            if (!getAttributeData(weMatCheckbox, CLASS).contains(MAT_CHECKBOX_CHECKED)) {
                WebElement weOption = driver().findElement(By.xpath(String.format(WILDFIRE_RISK_REDUCTION_TEMPLATE_XPATH, option)));
                waitAndClickElement(weOption);
                updated = true;
            }
        }
        if (updated) {
            waitAndClickElement(saveButtonWildfireRisk);
        } else {
            waitAndClickElement(closeWildfireSideSheet);
            if (isElementDisplayed(buttonNoChangesOk,2)) {
                waitAndClickElement(buttonNoChangesOk);
            }
        }
    }

    public void fillOutContactInfoPage(ApplicantAceHome applicant) throws Exception {
        enterPolicyStartDate(applicant);
        enterFireHydrantData(applicant);
        if (applicant.getStateCode().equals(CA) && !applicant.getWildFireRisk().isBlank()) {
            fillOutWildfireRiskReductionCA(applicant.getWildFireRisk());
        }
        fillOutBundleAndSave(applicant, HOME);
        enterEmailIdAndPhoneNumberInContactInfoPage(applicant);
        clickOnAgreeAndSubmitButton();
    }
*/
}
