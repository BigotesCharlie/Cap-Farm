package com.farmers.ffq.datatransferobjects;

import lombok.Data;

@Data
public class AgentFlowData {
    private String agentOfRecords;
    private String cityName;
    private String residentialAddress;
    private String stateCode;
    private String zipCode;

    @Override
    public String toString() {
        return String.format("State: %s, Agent of Record: %s, Zip Code: %s, City:  %s, Residential Address: %s", stateCode, agentOfRecords, zipCode, cityName, residentialAddress);
    }
}
