package com.farmers.ffq.utils;

import com.farmers.framework.AutomationFramework;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;

import java.io.IOException;
import java.sql.*;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DbHelper extends AutomationFramework {

    private static Connection getPostgresSQLConnection() {
        String postgresUrl = Property.getEnvironmentProperty("postgres_url");
        String dbUser = Property.getEnvironmentProperty("postgres_user");
        String dbPwd = Property.getEnvironmentProperty("postgres_pwd");
        Connection conn = null;
        for (int i=0; i < 3; i++) {
            Log.info("Connection attempt to Postgres #" + (i+1));
            try {
                DriverManager.setLoginTimeout(15);
                conn = DriverManager.getConnection(postgresUrl, dbUser, dbPwd);
                Log.info("Connection Schema: " + conn.getSchema());
                break;
            } catch (SQLException e) {
                Log.info(e.getMessage());
                sleep(3);
            }
        }
        return conn;
    }

    private static String queryPostgreSQLGetFirstRow(String sqlQuery) throws SQLException {
        Connection connection = getPostgresSQLConnection();
        if (connection != null) {
            try {
                Log.info("PostgreSQL query: " + sqlQuery);
                Statement stmt = connection.createStatement();
                ResultSet rs;
                rs = stmt.executeQuery(sqlQuery);
                rs.next();
                Log.info("PostgreSQL query response: " + rs.getString(1));
                return rs.getString(1);
            } catch (SQLException sqle) {
                Log.info(sqle.getMessage());
            } finally {
                connection.close();
            }
        } else {
            Log.info("Unable to connect to PostgreSQL DB.");
        }
        return null;
    }

    private static List<String> queryPostgreSQLGetAllRows(String sqlQuery) throws SQLException {
        Connection connection = getPostgresSQLConnection();
        List<String> results = new ArrayList<>();
        if (connection != null) {
            try {
                Log.info("PostgreSQL query: " + sqlQuery);
                Statement stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(sqlQuery);
                while (rs.next()) {
                    results.add(rs.getString(1));
                }
                Log.info("PostgreSQL query results: " + results);
                rs.close();
                return results;
            } catch (SQLException sqle) {
                Log.info(sqle.getMessage());
            } finally {
                connection.close();
            }
        } else {
            Log.info("Unable to connect to PostgreSQL DB.");
        }
        return null;
    }

    private static String queryPostgresWeb(String sqlQuery) throws IOException {
        String postgresUrl = Property.getEnvironmentProperty("postgres_url");
        String dbUser = Property.getEnvironmentProperty("postgres_user");
        String dbPwd = Property.getEnvironmentProperty("postgres_pwd");
        String pgadminUrl = Property.getEnvironmentProperty("pgadmin_url");
        String apiConnectUrl = pgadminUrl + "api/connect";
        String apiQueryUrl = pgadminUrl + "api/query";
        String connectionUrl = "url=postgres://" + dbUser + ":" + dbPwd + "@" + postgresUrl.substring(18);
        Log.info("PostgreSQL Web connectionURL: " + connectionUrl);
        Log.info("PostgreSQL query: [" + sqlQuery + "]");

        OkHttpClient client = new OkHttpClient().newBuilder().build();
        String contentType = "application/x-www-form-urlencoded; charset=UTF-8,text/plain";
        MediaType mediaType = MediaType.parse(contentType);
//      api connection request
        RequestBody pgConnect = RequestBody.create(connectionUrl, mediaType);
        Request apiConnect = new Request.Builder()
                .url(apiConnectUrl)
                .method("POST", pgConnect)
                .addHeader("Content-Type", contentType)
                .build();
        Response response1 = client.newCall(apiConnect).execute();
        System.out.println(response1.code());
        ResponseBody responseBody = response1.body();
        String responseBodyText = responseBody  == null? "Null response body": responseBody.string();
        System.out.println(responseBodyText);
        response1.close();
        System.out.println();

//      sql query request
        String queryRequest = "query=" + sqlQuery;
        Log.info("PostgreSQL Web queryRequest: " + connectionUrl);
        RequestBody requestSqlQuery = RequestBody.create(queryRequest, mediaType);
        Request request2 = new Request.Builder()
                .url(apiQueryUrl)
                .method("POST", requestSqlQuery)
                .addHeader("Content-Type", contentType)
                .build();
        Response response2 = client.newCall(request2).execute();
        System.out.println(response2.code());
        responseBody = response2.body();
        String infoJson = responseBody == null? "Null response body": responseBody.string();
        System.out.println(infoJson);
        response2.close();

        return infoJson;
    }

    private static String queryPostgresWebGetFirstRow(String sqlQuery) throws IOException {
        String infoJson = queryPostgresWeb(sqlQuery);
        String textResponse = null;
        if (!infoJson.trim().isEmpty()) {
            try {
                JSONArray jsonArray = new JSONObject(infoJson).getJSONArray("rows");
                if (!jsonArray.isEmpty()) {
                    String infoJson2 = jsonArray.getJSONArray(0).toString();
                    textResponse = infoJson2.replace("\\n", "").replace("\\\"", "\"").replace("[\"", "").replace("\"]", "");
                }
            } catch (JSONException je) {
                je.printStackTrace();
            }
        }
        return textResponse;
    }

    private static List<String> queryPostgresWebGetAllRows(String sqlQuery) throws IOException {
        String infoJson = queryPostgresWeb(sqlQuery);
        List<String> rows = new ArrayList<>();
        if (!infoJson.trim().isEmpty()) {
            try {
                JSONArray jsonArray = new JSONObject(infoJson).getJSONArray("rows");
                for (int i=0; i<jsonArray.length(); i++) {
                    String infoJson2 = jsonArray.getJSONArray(i).toString();
                    rows.add(infoJson2.replace("\\n", "").replace("\\\"", "\"").replace("[\"", "").replace("\"]", ""));
                }
            } catch (JSONException je) {
                je.printStackTrace();
            }
        }
        return rows;
    }

    public static String queryPostgresGetFirstRow(String sqlQuery) throws SQLException, IOException {
        Log.info("Postgres query: [" + sqlQuery + "]");
//        String textResponse;
//        if (Property.LOCAL) {
//            textResponse = queryPostgresWebGetFirstRow(sqlQuery);
//        } else {
//            textResponse = queryPostgreSQLGetFirstRow(sqlQuery);
//        }
        return queryPostgreSQLGetFirstRow(sqlQuery);
    }

    public static List<String> queryPostgresGetAllRows(String sqlQuery) throws SQLException, IOException {
        Log.info("Postgres query: [" + sqlQuery + "]");
//        List<String> results;
//        if (Property.LOCAL) {
//            results = queryPostgresWebGetAllRows(sqlQuery);
//        } else {
//            results = queryPostgreSQLGetAllRows(sqlQuery);
//        }
        return queryPostgreSQLGetAllRows(sqlQuery);
    }
}
