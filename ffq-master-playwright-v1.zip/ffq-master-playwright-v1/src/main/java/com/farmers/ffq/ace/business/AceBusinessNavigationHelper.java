package com.farmers.ffq.ace.business;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.datatransferobjects.ApplicantBusiness;
import com.farmers.framework.report.Reporter;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AceBusinessNavigationHelper extends BasePage {
	@PWFindBy(xpath = "//tui-oneui-footer")
	private PWElement footer;

	private String resumeFromPage = EMPTY_STRING;
	private String businessLeadNumber = EMPTY_STRING;

	public AceBusinessNavigationHelper() throws Exception {
		super();
	}

	public AceBusinessThankYouPage navigateToBusinessThankYouPage(ApplicantBusiness businessApplicant) throws Exception {
		navigateToBusinessInsuranceLeadForm(businessApplicant).fillOutPageAndContinue(businessApplicant);
		AceBusinessThankYouPage businesThankYouPage = new AceBusinessThankYouPage();
		if (businesThankYouPage.quickIsOnThankYouPage()) {
			writeRatedQuoteInformationToFile("Ace Business - " + getBusinessLeadNumber() + SPACE + businessApplicant);
			Reporter.pass("Navigated to Business Thank You page");
			if (isADATestingEnabled()) {
				performADATesting(businesThankYouPage.getClass().getSimpleName(), MARKETING_IT, LOB_BUSINESS);
				screenCapture(footer, businesThankYouPage.getClass().getSimpleName(), MEDIUM, false);
			}
			return businesThankYouPage;
		} else {
			writeDataToKnockoutLogFile("Ace Business " + getBusinessLeadNumber() + SPACE + businessApplicant);
			throw new IllegalStateException("Did not reach " + businesThankYouPage.getClass().getSimpleName() + " for quote " + getBusinessLeadNumber() + NEWLINE);
		}
	}

	public AceBusinessLeadForm navigateToBusinessInsuranceLeadForm(ApplicantBusiness businessApplicant) throws Exception {
		AceBusinessLeadForm leadForm = new AceBusinessLeadForm();
		if (getResumeFromPage().equals(leadForm.getClass().getSimpleName())) {
			return leadForm;
		}
		processLandingPage(businessApplicant);
		setBusinessLeadNumber(getQuoteNumberFromStorage());
		if (leadForm.isOnBusinessLeadForm()) {
			writeCreatedQuoteInformationToFile("Ace Business " + getBusinessLeadNumber() + SPACE + businessApplicant);
			Reporter.pass("Navigated to Business Lead Form for quote "+  getBusinessLeadNumber());
			if (isADATestingEnabled()) {
				leadForm.clickCTAButton();
				performADATesting(leadForm.getClass().getSimpleName(), MARKETING_IT, LOB_BUSINESS);
				screenCapture(footer, leadForm.getClass().getSimpleName(), LARGE, false);
			}
			return leadForm;
		} else {
			writeDataToKnockoutLogFile("Ace Business " + getBusinessLeadNumber() + SPACE + businessApplicant);
			throw new IllegalStateException("Did not reach " + leadForm.getClass().getSimpleName() + " for quote " + getBusinessLeadNumber() + NEWLINE);
		}
	}

	private void processLandingPage(ApplicantBusiness applicant) throws Exception {
		if (applicant.getBusinessId().equals(AWS_SCENARIOS)) {
			new LandingPage(applicant);
			Reporter.pass("Application launched in AWS mode");
		} else {
			new LandingPage(isUseMobileViewEnabled(), true).enterLandingPageData(LOB_BUSINESS, applicant.getZipCode());
		}
		waitForSpinnerToBeGone();
	}

	private String getQuoteNumberFromStorage() throws Exception {
		if (getItemFromSessionStorage("appStore")!= null) {
			return getSessionStorageAppStore().getData().getQuoteNumber();
		} else {
			return EMPTY_STRING;
		}
	}
}
