package com.farmers.ffq.utils;

import lombok.Getter;

@Getter
public enum PaymentMethods {

    AMEX_CREDIT_CARD_1("371449635398431"),
    //this number is representing bank "routing number" for a checking account
    BANK_ACCOUNT_1("125000024"),
    BANK_ACCOUNT_2("021000021"),
    BANK_ACCOUNT_3("011401533"),
    BANK_ACCOUNT_4("091000019"),
    BANK_ACCOUNT_5("122000247"),
    BANK_ACCOUNT_6("1234567890"),
    DISCOVER_CREDIT_CARD_1("6011000000000012"),
    DISCOVER_CREDIT_CARD_2("6011111111111117"),
    MASTERCARD_CREDIT_CARD_1("5454545454545454"),
    INVALID_MASTERCARD_CREDIT_CARD("5105105105105100"),
    MASTERCARD_CREDIT_CARD_2("5555555555554444"),
    VISA_CREDIT_CARD_1("4444444444444448"),
    VISA_CREDIT_CARD_2("4111111111111111"),
    VISA_DEBIT_CARD_1("4444424444444440"),
    VISA_DEBIT_CARD_2("4400000000000008"),
    VISA_DEBIT_CARD_3("4852464911331840");

    private final String accountNumber;


    PaymentMethods(String accountNumber) {
        this.accountNumber = accountNumber;
    }

}
