package com.farmers.ffq.ace.renters;

import com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersNavigationHelper extends AceHRCNavigationHelperBasePage {
	/**
	 * Constructor.
	 *
	 * @throws Exception if driver() call fails
	 */
	public AceRentersNavigationHelper() throws Exception {
	}

	public AceRentersAddressPage navigateToAceRentersAddressPage(ApplicantAceHome applicant) throws Exception {
		AceRentersAddressPage addressPage = new AceRentersAddressPage();
		if (getResumeFromPage().equals(ADDRESS_PAGE)) {
			return addressPage;
		}
		processLandingPage(applicant, LOB_RENTERS);
		if (addressPage.isOnAddressPageRenters(true)) {
			Reporter.pass("Navigated to Address Page Renters");
			if (applicant.getQuoteNumber() == null) {
				String quoteNumber = addressPage.getSessionStorageAppStore().getData().getQuoteNumber();
				Log.info(NEW_QUOTE_NUMBER + quoteNumber, true);
				applicant.setQuoteNumber(quoteNumber);
			}
			if (isADATestingEnabled()) {
				addressPage.validateADA(FFQ_ACE_RENTERS);
			}
			return addressPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AddressPageRenters");
		}
	}

	public AceRentersAboutYouPage navigateToAceRentersAboutYouPage(ApplicantAceHome applicant) throws Exception {
		AceRentersAboutYouPage aboutYouPage = new AceRentersAboutYouPage();
		if (getResumeFromPage().equals(ABOUT_YOU)) {
			return aboutYouPage;
		}
		AceRentersAddressPage addressPage = navigateToAceRentersAddressPage(applicant);
		addressPage.enterAddress(applicant);
		sleep(2);
		addressPage.clickContinueButton();
		if (aboutYouPage.isOnAboutYouPage(true)) {
			Reporter.pass("Navigated to Ace Renters About You Page");
			if (isADATestingEnabled()) {
				aboutYouPage.validateADA(FFQ_ACE_RENTERS);
			}
			return aboutYouPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AceRentersAboutYouPage");
		}
	}

	public AceRentersContactInfoPage navigateToAceRentersContactInfoPage(ApplicantAceHome applicant) throws Exception {
		AceRentersContactInfoPage contactInfoPage = new AceRentersContactInfoPage();
		if(getResumeFromPage().equals(CONTACT_INFO)){
			return contactInfoPage;
		}
		AceRentersAboutYouPage aboutYouPage = navigateToAceRentersAboutYouPage(applicant);
		aboutYouPage.fillOutTheDataInAboutYouPageRenters(applicant, true);
		waitForSpinnerToBeGone();
		if (contactInfoPage.isOnContactInfoPage(true)) {
			Reporter.pass("Navigated to AceRentersContactInfoPage");
			if (isADATestingEnabled()) {
				contactInfoPage.validateADA(FFQ_ACE_RENTERS);
			}
			return contactInfoPage;
		} else {
			if (isTryAgainPagePresent() && !wasTryAgainSuccessful()) {
				throw new IllegalStateException("AceRentersContactInfoPage: " + TRY_AGAIN_ATTEMPTS_LIMIT_EXCEEDED);
			} else {
				if (contactInfoPage.isOnContactInfoPage(false)) {
					Reporter.pass("Navigated to AceRentersContactInfoPage");
					return contactInfoPage;
				}
				reportKnockout();
				throw new IllegalStateException(DID_NOT_REACH + "AceRentersContactInfoPage");
			}
		}
	}

	public AceRentersReviewQuotePage navigateToAceRentersReviewQuotePage(ApplicantAceHome applicant) throws Exception {
		AceRentersReviewQuotePage reviewQuotePage = new AceRentersReviewQuotePage();
		if (List.of(FAILED_RC2, FAILED_RC3, REVIEW_QUOTE).contains(getResumeFromPage())) {
			return reviewQuotePage;
		}
		AceRentersContactInfoPage contactInfoPage = navigateToAceRentersContactInfoPage(applicant);
		contactInfoPage.fillOutContactInfoPageRenters(applicant);
		return goToAceRentersReviewQuotePage(applicant);
	}

	public AceRentersReviewQuotePage goToAceRentersReviewQuotePage(ApplicantAceHome applicant) throws Exception {
		AceRentersReviewQuotePage reviewQuotePage = new AceRentersReviewQuotePage();
		if (reviewQuotePage.isOnReviewQuotePageAceRenters()) {
			Reporter.pass("Navigated to AceRentersReviewQuotePage");
			String quoteNumber = applicant.getQuoteNumber();
			Log.info("Ace Renters - Review Quote page. Quote number: " + quoteNumber, true);
			logQuoteNumber(applicant, RENTERS, quoteNumber);
			if (isADATestingEnabled()) {
				reviewQuotePage.validateADA(FFQ_ACE_RENTERS);
			}
			return reviewQuotePage;
		} else {
			if (isTryAgainPagePresent() && !wasTryAgainSuccessful()) {
				throw new IllegalStateException("AceRentersReviewQuotePage: " + TRY_AGAIN_ATTEMPTS_LIMIT_EXCEEDED);
			} else {
				if (reviewQuotePage.isOnReviewQuotePageAceRenters()) {
					Reporter.pass("Navigated to AceRentersReviewQuotePage");
					return reviewQuotePage;
				}
				AceRentersContactInfoPage contactInfoPage = new AceRentersContactInfoPage();
				if (contactInfoPage.isOnContactInfoPage(false)){
					contactInfoPage.clickOnAgreeAndSubmitButton();
					if (reviewQuotePage.isOnReviewQuotePage(true)) {
						Reporter.pass("Navigated to AceRentersReviewQuotePage");
						return reviewQuotePage;
					}
				}
				reportKnockout();
				throw new IllegalStateException(DID_NOT_REACH + "AceRentersReviewQuotePage");
			}
		}
	}

	public AceRentersJustAFewMoreThingsPage navigateToAceRentersJustAFewMoreThingsPage(ApplicantAceHome applicant) throws Exception {
		AceRentersJustAFewMoreThingsPage jFMTPage = new AceRentersJustAFewMoreThingsPage();
		if(getResumeFromPage().equals(JFMT_PAGE)){
			return jFMTPage;
		}
		navigateToAceRentersReviewQuotePage(applicant).clickOnContinueButton();
		if (jFMTPage.isOnJFMTPage(true)) {
			Reporter.pass("Navigated to AceRentersJustAFewMoreThingsPage");
			return jFMTPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AceRentersJustAFewMoreThingsPage");
		}
	}

	public AceHRCPaymentBasePage navigateToAceRentersPaymentPage(ApplicantAceHome applicant) throws Exception {
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		if(getResumeFromPage().equals(PAYMENT_PAGE)){
			return aceHRCPaymentBasePage;
		}
		AceRentersJustAFewMoreThingsPage jFMTPage = navigateToAceRentersJustAFewMoreThingsPage(applicant);
		if (!List.of(FAILED_RC2, FAILED_RC3).contains(getResumeFromPage())) {
			jFMTPage.fillOutJustFewMoreThingsPageRentersLob(applicant);
		} else {
			jFMTPage.clickContinueButton();
		}
		if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPageRenters()) {
			Reporter.pass("Navigated to Ace Renters Payment Selection Page");
			Log.info("Ace Renters - Payment page. Quote number: " + applicant.getQuoteNumber(), true);
			return aceHRCPaymentBasePage;
		} else {
			if (!getResumeFromPage().equals(FAILED_RC2)) {
				Log.info(DID_NOT_REACH + "Ace Renters - Payment page. Quote number: " + applicant.getQuoteNumber());
				retrieveQuoteByQuoteNumber(applicant);
				setResumeFromPage(FAILED_RC2);
                aceHRCPaymentBasePage = navigateToAceRentersPaymentPage(applicant);
				if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPageRenters()) {
					Reporter.pass("Navigated to Ace Renters Payment Page");
					return aceHRCPaymentBasePage;
				}
			}
			throw new IllegalStateException(DID_NOT_REACH + "Ace Renters - Payment Page.");
		}
	}

	public AceHRCPaymentBasePage navigateToMonthlyAutoPayBankPaymentPageAceRenters(ApplicantAceHome applicant) throws Exception {
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		if (getResumeFromPage().equals(PAYMENT_PAGE)) {
			return aceHRCPaymentBasePage;
		}
		navigateToAceRentersPaymentPage(applicant);
		if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPageRenters()) {
			Reporter.pass("Navigated to AceRentersMonthlyBankPaymentPage");
			Log.info("Ace Renters - monthly pay bank payment page. Quote number: " + applicant.getQuoteNumber(), true);
			return aceHRCPaymentBasePage;
		} else {
			if (!getResumeFromPage().equals(FAILED_RC3)) {
				Log.info(DID_NOT_REACH + "Ace Renters - Payment page. Quote number: " + applicant.getQuoteNumber());
				retrieveQuoteByQuoteNumber(applicant);
				setResumeFromPage(FAILED_RC3);
				aceHRCPaymentBasePage = navigateToMonthlyAutoPayBankPaymentPageAceRenters(applicant);
				if (aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPageRenters()) {
					Reporter.pass("Navigated to AceRentersMonthlyBankPaymentPage");
					return aceHRCPaymentBasePage;
				}
			}
			throw new IllegalStateException(DID_NOT_REACH + "Ace Renters - Payment Page");
		}
	}

}
