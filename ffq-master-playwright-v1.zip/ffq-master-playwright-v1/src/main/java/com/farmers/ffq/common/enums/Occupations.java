package com.farmers.ffq.common.enums;

import lombok.Getter;

@Getter
public enum Occupations {

    ACCOUNTANT("Accountant", "GA", "RA"),
    ARCHITECT("Architect", "GP", "RG"),
    ARCHITECT_COLLEGE_DEGREE("Architect - College Degree","GP","RG"),
    ARCHITECT_STATE_LICENSE_NO_DEGREE("Architect - State License-(NO DEGREE)","GQ","RG"),
    DENTIST("Dentist", "GB", "RB"),
    EDUCATOR("Educator", "GR", "RC"),
    EDUCATOR_PUBLIC_SCHOOL_K_12("Educator - Public School K-12","GR","RC"),
    EDUCATOR_PRIVATE_SCHOOL_K_12("Educator - Private School K-12","GS","RC"),
    EDUCATOR_COMMUNITY_COLLEGE("Educator - Community College","GT","RC"),
    EDUCATOR_UNIVERSITY_4_YEAR_COLLEGE("Educator - University/4-Year College","GU","RC"),
    ENGINEER("Engineer", "GV", "RD"),
    ENGINEER_COLLEGE_DEGREE("Engineer - College Degree","GV","RD"),
    ENGINEER_STATE_LICENSE_NO_DEGREE("Engineer - State License (NO DEGREE)","GW","RD"),
    FARMERS_ZURICH_EMPLOYEE("Farmers/Zurich Employee", "G0", "R0"),
    FARMERS_EMPLOYEE("Farmers Employee","G0","R0"),
    FARMERS_AGENT("Farmers Agent","G1","R1"),
    FARMERS_DISTRICT_MANAGER("Farmers District Manager","G2","R2"),
    FOREMOST_EMPLOYEE("Foremost Employee","IB","R3"),
    ZURICH_EMPLOYEE("Zurich Employee","IC","R4"),
    FARMERS_AGENT_EMPLOYEE("Farmers Agent Employee","I1","I1"),
    FARMERS_DISTRICT_MANAGER_EMPLOYEE("Farmers District Manager Employee","I2","I2"),
    BRISTOL_WEST_EMPLOYEE("Bristol West Employee","I3","T3"),
    TWENTY_FIRST_CENTURY_EMPLOYEES("21st Century Employees","I4","T4"),
    FIREFIGHTER("Firefighter", "GH", "RH"),
    LAW_ENFORCEMENT_OFFICER("Law Enforcement Officer", "GK", "RK"),
    LAWYER_JUDGE("Lawyer/Judge", "GI", "RI"),
    LIBRARIAN("Librarian", "G7", "R7"),
    MILITARY_PERSONNEL("Military Personnel", "", ""),
    MILITARY_HONORABLY_DISCHARGED("Military Honorably Discharged","HJ","R9"),
    AIR_FORCE("Air Force", "IS", "R9"),
    AIR_FORCE_OFFICER("Air Force Officer","IR","R9"),
    AIR_FORCE_ENLISTED("Air Force Enlisted","IS","R9"),
    AIR_FORCE_ACTIVE_RESERVE("Air Force Active Reserve","IT","R9"),
    ARMY("Army", "IM", "R9"),
    ARMY_OFFICER("Army Officer","IL","R9"),
    ARMY_ENLISTED("Army Enlisted","IM","R9"),
    ARMY_ACTIVE_RESERVE("Army Active Reserve","IN","R9"),
    COAST_GUARD("Coast Guard", "IY", "R9"),
    COAST_GUARD_OFFICER("Coast Guard Officer", "IX", "R9"),
    COAST_GUARD_ENLISTED("Coast Guard Enlisted", "IY", "R9"),
    COAST_GUARD_ACTIVE_RESERVE("Coast Guard Active Reserve", "IZ", "R9"),
    MARINE("Marine", "IV", "R9"),
    MARINE_OFFICER("Marine Officer", "IU", "R9"),
    MARINE_ENLISTED("Marine Enlisted", "IV", "R9"),
    MARINE_ACTIVE_RESERVE("Marine Active Reserve", "IW", "R9"),
    OTHER("Other","99","99"),
    NAVY("Navy", "IP", "R9"),
    NAVY_OFFICER("Navy Officer","IO","R9"),
    NAVY_ENLISTED("Navy Enlisted","IP","R9"),
    NAVY_ACTIVE_RESERVE("Navy Active Reserve","IQ","R9"),
    HONORABLY_DISCHARGED("Honorably discharged", "HJ", "HJ"),
    NURSE("Nurse", "GJ", "RJ"),
    PHYSICIAN_SURGEON("Physician/Surgeon", "GE", "RE"),
    PHYSICIAN_SURGEON_PHARMACISTS("Physician/Surgeon - Pharmacists","GX", "RE"),
    PHYSICIAN_SURGEON_PSYCHOLOGISTS("Physician/Surgeon -Psychologists","GY", "RE"),
    PHYSICIAN_SURGEON_PSYCHIATRISTS("Physician/Surgeon- Psychiatrists","GZ", "RE"),
    PROFESSIONAL_AVIATOR("Professional Aviator", "GM", "RM"),
    SCIENTIST("Scientist", "GF", "RF"),
    VETERINARIAN("Veterinarian", "GN", "RN");



    private final String occupationName;
    private final String employedCode;
    private final String retiredCode;


   Occupations(String occupationName, String employedCode, String retiredCode) {
        this.occupationName = occupationName;
        this.employedCode = employedCode;
        this.retiredCode = retiredCode;
    }
}
