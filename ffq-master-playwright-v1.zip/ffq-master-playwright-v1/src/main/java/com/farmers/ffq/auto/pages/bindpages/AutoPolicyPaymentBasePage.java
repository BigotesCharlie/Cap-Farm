package com.farmers.ffq.auto.pages.bindpages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.datatransferobjects.AppStore.VerifyResponse.PaymentSchedule;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import com.farmers.framework.report.Log;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.ONE_PAY;
import static com.farmers.ffq.utils.GlobalVariables.VALUE;

public class AutoPolicyPaymentBasePage extends PolicyPaymentBasePage {
    protected static final String AUTO_POLICY_PAYMENT_HEADER = "Auto policy payment";
    @PWFindBy(xpath = "//h1[contains(text(), '" + AUTO_POLICY_PAYMENT_HEADER + "')]")
    protected PWElement autoPolicyPaymentHeader;

    private static final String FEES = "Fees";
    @PWFindBy(xpath = "//p[contains(text(), '" + FEES + "')]")
    protected PWElement feeSideBarHeader;

    public final String AUTO_MEMBERSHIP_FEE_MESSAGE = "A membership fee per vehicle is applied for new auto policies and new vehicles added to your policy. It covers the administrative costs associated with you becoming a member of the insurance exchange and the issuance of your policy.";
    @PWFindBy(xpath = "//p[contains(text(), 'A membership fee per vehicle is applied ')]")
    protected PWElement membershipFeeMessageSideBar;

    public static final String POLICY_POLICY_FEE_MESSAGE = "A policy fee per vehicle is applied for new auto policies and new vehicles added to your policy. This is for administrative costs associated with writing your new policy.";
    @PWFindBy(xpath = "//p[contains(text(), 'A policy fee per vehicle is applied for new auto')]")
    protected PWElement policyFeeMessageSideBar;

    public static final String VEHICLE_FEE_MESSAGE = "A fee per vehicle is applied for new auto policies and new vehicles added to your policy. This is for administrative costs associated with writing your new policy.";
    @PWFindBy(xpath = "//p[contains(text(), 'A fee per vehicle is applied for new auto')]")
    protected PWElement vehicleFeeMessageSideBar;

    private static final String SIX_MONTH_TERM_PAYMENT = "6-month term payment";
    @PWFindBy(xpath = "//span[contains(text(),'" + SIX_MONTH_TERM_PAYMENT + "')]")
    protected PWElement sixMonthTermPayment;

    @PWFindBy(xpath = "//span[contains(text(), '6-month term price')]")
    private PWElement sixTermPriceSubHeader;

    @PWFindBy(xpath = "//span[contains(text(),'" + FEES + "')]")
    protected PWElement fees;

    private static final String SET_UP_PAYMENT_METHOD = "Set up payment method";
    @PWFindBy(xpath = "//button[contains(text(),'" + SET_UP_PAYMENT_METHOD + "')]")
    private PWElement setUpPaymentMethodButton;

    @PWFindBy(xpath = "//mat-icon[contains(text(), 'close')]")
    private PWElement addPaymentMethodContainerCloseIcon;

    @PWFindBy(xpath = "//mat-dialog-container[@aria-labelledby='addPaymentHeading']")
    private PWElement addPaymentMethodDialogContainer;

    private static final String PAYMENTUS_MANAGE_PAYMENT = "Paymentus Manage Payments";
    @PWFindBy(xpath = "//iframe[@title = '" + PAYMENTUS_MANAGE_PAYMENT + "']")
    private PWElement paymentUsIframe;

    private static final String ADD_BUTTON = "ADD";
    @PWFindBy(xpath = "//button[text() = '" + ADD_BUTTON + "']")
    private PWElement addButton;

    private static final String ADD_PAYMENT_METHOD_LABEL = "Add payment method";
    @PWFindBy(xpath = "//span[text() = '" + ADD_PAYMENT_METHOD_LABEL + "']")
    private PWElement addPaymentMethodLabel;

    private static final String PAPERLESS_TERMS_OF_USE = "Paperless Terms of Use";
    @PWFindBy(xpath = "//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]")
    private PWElement paperlessTermsOfUseLink;

    private static final String INFORMATION_STORAGE_AUTHORIZATION = "Information Storage Authorization";
    @PWFindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]")
    private PWElement informationStorageAuthorizationLink;

    private static final String PAYMENT_AUTHORIZATION = "Payment Authorization Terms & Conditions.";
    @PWFindBy(xpath = "//a[contains(text(), '" + PAYMENT_AUTHORIZATION + "')]")
    private PWElement paymentAuthorizationLink;


    List<PWElement> listOfLinksToClick = Arrays.asList(paperlessTermsOfUseLink, informationStorageAuthorizationLink, paymentAuthorizationLink);
    private static final String TERMS_AND_CONDITIONS_TITLE = "Terms of Use | Farmers Insurance";
    private static final String PAYMENT_AUTHORIZATION_TITLE = "Payment Authorization Terms and Conditions | Farmers Insurance";
    private static final String INFORMATION_STORAGE_AUTHORIZATION_TITLE = "Payment Card Storage Terms & Conditions | Farmers Insurance";

    private static final List<String> listOfTabTitles = Arrays.asList(TERMS_AND_CONDITIONS_TITLE, INFORMATION_STORAGE_AUTHORIZATION_TITLE, PAYMENT_AUTHORIZATION_TITLE);


    private static final String BY_CLICKING_COMPLETER_PURCHASE = "By clicking \"Complete purchase\" below:";
    @PWFindBy(xpath = "//div[contains(text(), '" + BY_CLICKING_COMPLETER_PURCHASE + "')]")
    private PWElement byClickingCompletePurchaseLabel;

    private static final String READ_AND_AGREED_TO_THE_BULLET_ONE = "I confirm that I have read and agree to the Paperless Terms of Use; and";
    @PWFindBy(xpath = "//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]/parent::p")
    private PWElement readAndAgreedToTheBulletPointOne;

    public static final String IF_DO_NOT_AGREE_WITH_TERMS = "If you do not agree with the Terms and Conditions above and/or have any questions, please contact your agent or Farmers Direct Sales Center to complete this transaction. You can always change your Paperless and Automatic Payment settings for future transactions by logging in to your Farmers.com account.";
    @PWFindBy(xpath = "//p[contains(text(), 'If you do not agree with the Terms and Conditions above ')]")
    private PWElement ifDoNotAgreeWithTermsAndConditionLabel;

    private static final String PAYMENT_METHOD_ALREADY_ADDED_ERROR = "You have already saved this payment method. Cannot save duplicate.";
    @PWFindBy(xpath = "//li[@id='profile']")
    private PWElement paymentMethodAlreadyAdded;

    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO_MONTHLY_PAY = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate One-Time and Automatic Payment processes.";
    @PWFindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p")
    private PWElement readAndAgreedToTheBulletPointTwoMonthlyPay;

    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate:";
    @PWFindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p")
    private PWElement readAndAgreedToTheBulletPointTwo;

    private static final String CARD_NUMBER_LABEL = "Card Number";
    @PWFindBy(xpath = "//label[text() = '" + CARD_NUMBER_LABEL + "']")
    private PWElement cardNumberLabel;

    private static final String EXPIRATION_DATE_LABEL = "Expiration Date";
    @PWFindBy(xpath = "//label[text() = '" + EXPIRATION_DATE_LABEL + "']")
    private PWElement expirationDateLabel;

    private static final String CARD_SECURITY_CODE_LABEL = "Card Security Code (CVV)";
    @PWFindBy(xpath = "//label[text() = '" + CARD_SECURITY_CODE_LABEL + "']")
    private PWElement cardSecurityCodeLabel;

    private static final String BILLING_ZIP_CODE_LABEL = "Billing ZIP Code";
    @PWFindBy(xpath = "//label[text() = '" + BILLING_ZIP_CODE_LABEL + "']")
    private PWElement billingZipCodeLabel;

    @PWFindBy(xpath = "//div[contains(@class,'methodVisa')]")
    private PWElement visaCardIconInARow;

    @PWFindBy(xpath = "//div[contains(@class,'methodDiscover')]")
    private PWElement masterCardIconInARow;


    @PWFindBy(xpath = "//div[contains(@class,'methodDiscover')]")
    private PWElement discoverCardIconInARow;

    @PWFindBy(xpath = "//div[contains(@class,'methodAmex')]")
    private PWElement amexCardIconInARow;

    private static final String NAME_ON_CARD_LABEL = "Name On Card";
    @PWFindBy(xpath = "//label[text() = '" + NAME_ON_CARD_LABEL + "']")
    private PWElement nameOnCardLabel;

    @PWFindBy(xpath = "//input[@id='cardHolderField']")
    private PWElement nameOnCardInPutField;

    private static final String ENTER_YOUR_NAME_ERROR = "Please enter your name exactly as it appears on your card.";
    @PWFindBy(xpath = "//span[contains(text(),'" + ENTER_YOUR_NAME_ERROR + "')]")
    private PWElement enterYourNameOnCardError;


    private static final String ENTER_VALID_CARD_NUMBER_ERROR = "Please enter a valid card number.";
    @PWFindBy(xpath = "//span[contains(text(),'" + ENTER_VALID_CARD_NUMBER_ERROR + "')]")
    private PWElement enterValidCardNumberError;

    private static final String ENTER_VALID_EXP_DATE_ERROR = "Please enter a valid expiration date MM/YY.";
    @PWFindBy(xpath = "//span[contains(text(),'" + ENTER_VALID_EXP_DATE_ERROR + "')]")
    private PWElement enterValidExpDateError;

    private static final String ENTER_VALID_CVV_NUMBER_ERROR = "Please enter a valid CVV.";
    @PWFindBy(xpath = "//span[contains(text(),'" + ENTER_VALID_CVV_NUMBER_ERROR + "')]")
    private PWElement enterValidCVVNumberError;

    private static final String ENTER_VALID_BILLING_ZIP_ERROR = "Please enter a valid CVV.";
    @PWFindBy(xpath = "//span[contains(text(),'" + ENTER_VALID_BILLING_ZIP_ERROR + "')]")
    private PWElement enterValidZipNumberError;


    @PWFindBy(xpath = "//input[@id='cardCVVField']")
    private PWElement cardSecurityCodeInputField;


    @PWFindBy(xpath = "//input[@id='zipCode']")
    private PWElement billingZipCodeInputField;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AutoPolicyPaymentBasePage() throws Exception {

    }

    public boolean isAutoPolicyPaymentHeaderCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(autoPolicyPaymentHeader), AUTO_POLICY_PAYMENT_HEADER);
    }

    public boolean isSixMonthTermPaymentCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(sixMonthTermPayment), SIX_MONTH_TERM_PAYMENT);
    }

    public boolean isPolicyFeesCorrect() {
        return isExpectedTextDisplayed(fees, FEES);
    }

    public boolean isMembershipFeesSideBarMsgCorrect() {
        return isExpectedTextDisplayed(membershipFeeMessageSideBar, AUTO_MEMBERSHIP_FEE_MESSAGE);
    }

    public boolean isPolicyFeesSideBarMsgCorrect() {
        return isExpectedTextDisplayed(policyFeeMessageSideBar, POLICY_POLICY_FEE_MESSAGE);
    }

    public boolean isVehicleFeesSideBarMsgCorrect() {
        return isExpectedTextDisplayed(vehicleFeeMessageSideBar, VEHICLE_FEE_MESSAGE);
    }

    @Override
    public boolean goBackToHowWouldYouLikeToPayPage() throws Exception {
        driver().navigate().back();
        return isExpectedTextDisplayed(howWouldYouLikeToPay, HOW_WOULD_YOU_LIKE_TO_PAY);
    }

    public boolean isSixTermPriceSubHeaderDisplayed() {
        return waitElementBeVisible(sixTermPriceSubHeader).isDisplayed();
    }

    public boolean isSixMonthTermPriceAmountDisplayed(String payPlanDescription) throws Exception {
        PaymentSchedule payPlanSchedule = filterListOfPaymentScheduleByPayPlan(getAutoVerifyRateResponse().getPaymentSchedules(), payPlanDescription).get(0);
        String fullTermPremium = payPlanSchedule.getFullTermPremium();
        String expectedSixMonthTotalPremium;
        if (payPlanDescription.equals(ONE_PAY)) {
            Double doublePolicyFees = doublePolicyFeeAmount(getAutoVerifyRateResponse().getPolicyFee().getAmount());
            Double sixMonthTermPriceAmount = Double.parseDouble(fullTermPremium) + doublePolicyFees;
            expectedSixMonthTotalPremium = String.format("$%,.2f for 6-month term price", sixMonthTermPriceAmount);
        } else {
            expectedSixMonthTotalPremium = String.format("$%,.2f for 6-month term price", Double.parseDouble(fullTermPremium));
        }

        return getTextFromElement(sixTermPriceSubHeader).equals(expectedSixMonthTotalPremium);
    }

    public boolean isAutoPolicyPaymentPageDisplayed() throws Exception {
        waitElementBeVisible(autoPolicyPaymentHeader);
        return isExpectedTextDisplayed(autoPolicyPaymentHeader, AUTO_POLICY_PAYMENT_HEADER);
    }


    public boolean isCardNumberLabelCorrect() {
        return isExpectedTextDisplayed(cardNumberLabel, CARD_NUMBER_LABEL);
    }

    public boolean isExpirationDateCorrect() {
        return isExpectedTextDisplayed(expirationDateLabel, EXPIRATION_DATE_LABEL);
    }

    public boolean isCardSecurityCodeLabelCorrect() {
        return isExpectedTextDisplayed(cardSecurityCodeLabel, CARD_SECURITY_CODE_LABEL);
    }

    public boolean isBillingZipCodeLabelCorrect() {
        return isExpectedTextDisplayed(billingZipCodeLabel, BILLING_ZIP_CODE_LABEL);
    }

    public boolean isVisaCardIconInRowDisplayed() {
        return visaCardIconInARow.isDisplayed();
    }

    public boolean isMasterCardIconInRowDisplayed() {
        return masterCardIconInARow.isDisplayed();
    }

    public boolean isDiscoverCardIconInRowDisplayed() {
        return discoverCardIconInARow.isDisplayed();
    }

    public boolean isAmexCardIconInRowDisplayed() {
        return amexCardIconInARow.isDisplayed();
    }

    public boolean isNameOnCardLabelCorrect() {
        return isExpectedTextDisplayed(nameOnCardLabel, NAME_ON_CARD_LABEL);
    }

    protected String getValueForFullNamePaymentusFrame() {
        return getAttributeData(nameOnCardInPutField, VALUE);
    }

    public void clearOutCardHolderNameInputField() {
        nameOnCardInPutField.clear();
    }

    public boolean isEnterYourNameErrorCorrect() {
        return isExpectedTextDisplayed(enterYourNameOnCardError, ENTER_YOUR_NAME_ERROR);
    }

    public boolean isEnterCardNumberErrorCorrect() {
        return isExpectedTextDisplayed(enterValidCardNumberError, ENTER_VALID_CARD_NUMBER_ERROR);
    }

    public boolean isEnterEXPDateNumberErrorCorrect() {
        return isExpectedTextDisplayed(enterValidExpDateError, ENTER_VALID_EXP_DATE_ERROR);
    }

    public boolean isEnterCVVNumberErrorCorrect() {
        return isExpectedTextDisplayed(enterValidCVVNumberError, ENTER_VALID_CVV_NUMBER_ERROR);
    }

    public boolean isEnterBillingZipCodeErrorCorrect() {
        return isExpectedTextDisplayed(enterValidZipNumberError, ENTER_VALID_BILLING_ZIP_ERROR);
    }

    public void enterCVVNumber(String cvvNumber) {
        sendKeysOneByOne(cardSecurityCodeInputField, cvvNumber);
    }

    public void enterBillingZipCode(String billingZipCode) {
        sendKeysOneByOne(billingZipCodeInputField, billingZipCode);
    }


    protected void enterNameOnCard(String nameOnCard) {
        sendKeysOneByOne(nameOnCardInPutField, nameOnCard);
    }

    public void validateBDQSpecificRequirements(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isDiscountSectionDisplayed(), "Discount section should be displayed on " + this.getClass().getSimpleName());
        validateValidateAndFooterForBDQ(fsa, applicant, this);
        validateAgentSectionBDQ(fsa, applicant);
    }

    public List<String> getTheListOfEligiblePaymentMethods() throws Exception {
        final String locator = "//span[@class='pov2__plan-title']";
        Log.info("Collecting eligible payment methods. locator=" + locator);
        List<PWElement> candidates = driver().findElements(PWBy.xpath(locator));
        Log.info("Found candidate payment method elements: " + candidates.size());

        List<String> methods = candidates.stream()
                .map(element -> {
                    String rawText = getTextFromElement(element);
                    if (rawText == null) {
                        Log.info("Skipping payment method element because text is null");
                        return "";
                    }
                    String normalized = rawText.replaceAll("[$0-9.]", "").trim();
                    Log.info("Payment method text parsed. raw='" + rawText + "', normalized='" + normalized + "'");
                    return normalized;
                })
                .filter(text -> !text.isBlank())
                .distinct()
                .collect(Collectors.toList());
        Log.info("Eligible payment methods extracted: " + methods);
        return methods;
    }

    public List<String> getTheListOfEligiblePaymentMethodsOldPaymentPage() throws Exception {
        final String locator = "//tui-presentment-card-header//h2";
        Log.info("Collecting eligible payment methods. locator=" + locator);
        List<PWElement> candidates = driver().findElements(PWBy.xpath(locator));
        Log.info("Found candidate payment method elements: " + candidates.size());

        List<String> methods = candidates.stream()
                .map(element -> {
                    String rawText = getTextFromElement(element);
                    if (rawText == null) {
                        Log.info("Skipping payment method element because text is null");
                        return "";
                    }
                    String normalized = rawText.replaceAll("[$0-9.]", "").trim();
                    Log.info("Payment method text parsed. raw='" + rawText + "', normalized='" + normalized + "'");
                    return normalized;
                })
                .filter(text -> !text.isBlank())
                .distinct()
                .collect(Collectors.toList());
        Log.info("Eligible payment methods extracted: " + methods);
        return methods;
    }

}
