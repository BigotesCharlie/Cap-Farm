package com.farmers.ffq.hqm.pages;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.PrefillResponseHQM;
import com.farmers.ffq.datatransferobjects.hqm.StaticContentHQM;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.testng.Assert;

import javax.annotation.Nullable;

import java.lang.invoke.StringConcatFactory;
import java.time.Year;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Home Quote Modernization (HQM) - Quote Property Page.
 */

public class PropertyPage extends HqmBasePage {

    @PWFindBy(xpath = "//tui-typeahead[@id='yearBuild']//input")
    private PWElement inputYearBuilt;

    @PWFindBy(xpath = "//div/ui-farmers-input[@fieldlabel='Total finished square feet']//input")
    private PWElement inputSquareFeet;

    @PWFindBy(xpath = "//span[starts-with(@aria-label,'year built')]//mat-icon")
    private PWElement helpYearBuilt;

    @PWFindBy(xpath = "//span[starts-with(@aria-label,'Total finished square feet')]//mat-icon")
    private PWElement helpSquareFeet;

    @PWFindBy(xpath = "//farmers-home-quote-property//farmers-home-quote-discount-journey//img[@id='clock-img']/../p")
    private PWElement discountSubTitleClock;

    private static final String DISCOUNT_CLOCK_TEXT = "For your convenience, we used your address to pre-fill some information.";

    @PWFindBy(xpath = "//farmers-home-quote-property//farmers-home-quote-discount-journey//img[@id='lock-img']/../p")
    private PWElement discountSubTitlePiggy;

    private static final String DISCOUNT_PIGGY_TEXT = "otential savings/discounts. Let's find some more.";

    private static final String HELP_BUTTON_PIGGY_XPATH = "//farmers-home-quote-property//div[@class='discount-journey-card']//mat-icon[text()='info']";
    @PWFindBy(xpath = HELP_BUTTON_PIGGY_XPATH)
    private PWElement discountHelpButtonPiggy;

    @PWFindBy(xpath = "//farmers-home-quote-discount-journey-dialog//h4")
    private PWElement discountHelpDialogTitle;

    private static final String DISCOUNT_HELP_DIALOG_TITLE = "Potential savings/discounts ($)";

    private static final String DISCOUNT_HELP_DIALOG_CONTENT_XPATH = "//farmers-home-quote-discount-journey-dialog//li";
    @PWFindBy(xpath = DISCOUNT_HELP_DIALOG_CONTENT_XPATH)
    private PWElement discountHelpDialogContent;

    @PWFindBy(xpath = "//farmers-home-quote-property//div[@class='djm-discount-check']/../p")
    private PWElement discountCheck;

    private String textDiscountCheck = "Awesome! This home may be eligible for our New Home Discount.";

    @PWFindBy(xpath = "//mat-dialog-actions//button[.='CLOSE']")
    private PWElement buttonCloseDialog;

    @PWFindBy(xpath = "//farmers-home-quote-tooltip-modal//h4")
    private PWElement helpDialogTitle;

    @PWFindBy(xpath = "//farmers-home-quote-tooltip-modal//div[@class='mat-dialog-content']")
    private PWElement helpDialogContent;

    private static final String YEAR_BUILT_HELP_TITLE = "Year Built";
    private static final String YEAR_BUILT_HELP_CONTENT = "If the majority of the home was stripped to the studs and remodeled, " +
            "use the original year built, and then select the correct new features.\nIf your home was built before 1945, " +
            "changes and improvements may not be accounted for in this quote. Please contact a Farmers agent for a more " +
            "detailed and complete quote.";
    private static final String YEAR_BUILT_HELP_CONTENT_KY = "If the majority of the home was stripped to the studs and remodeled, " +
            "use the original year built, and then select the correct new features.\nIf your home was built before 1945, " +
            "changes and improvements may not be accounted for in this quote. Please contact a Farmers representative for " +
            "a more detailed and complete quote.";

    private static final String SQUARE_FEET_HELP_TITLE = "Square Footage";
    private static final String SQUARE_FEET_HELP_CONTENT = "Finished square feet includes areas in attic, additions, and all living space " +
            "(including closets and stairwells) that is heated and/or cooled, has finished walls and ceilings, and has floor covering.\n" +
            "IMPORTANT: Finished square feet does not include all garage areas, basement areas (finished and unfinished), finished " +
            "living space partially below grade (including split level foundations), and attached and detached structures like decks, " +
            "balconies, patios, porches and carport.";

    @PWFindBy(xpath = "//farmers-home-quote-property//h1")
    private PWElement textPageTitle;

    @PWFindBy(xpath = "//farmers-home-quote-property//span[contains(@class,'tui-subtitle-text-1')]")
    private PWElement textPageSubTitle;

    private final PWBy pageFooters = PWBy.xpath("//farmers-home-quote-property//p[contains(@class,'caption')]");

    private final List<String> footersPropertyPage = Collections.singletonList("The pre-populated information throughout this quote " +
            "may be provided by third parties, which can use information from public and proprietary sources.");

    private final List<String> errorsPropertyPage1 = Arrays.asList("Please enter the year your house was built",
            "Please enter total finished square feet");
    private final List<String> errorsPropertyPage2 = Arrays.asList("Please enter a year after 1600",
            "Quotes not available for homes under construction");

    private static final String PROPERTY_PAGE_TITLE = "NOW WE'LL GET\nSOME BASICS";
    private static final String PROPERTY_PAGE_SUBTITLE = "It\u2019s time to build your estimated replacement cost.\n" +
            "When was your house built \u2014 and how big is it?";

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public PropertyPage() throws Exception {
        super();
        waitElementBeVisible(inputYearBuilt);
    }

    public void setRequiredFields(ApplicantHQM applicant, FarmersSoftAssert fsa, @Nullable PrefillResponseHQM propertyData) {
        if (getYearBuilt().isEmpty() || !applicant.keep360Prefill) {
            setYearBuilt(String.valueOf(applicant.yearBuilt));
        }
        if (getSquareFeet().isEmpty() || !applicant.keep360Prefill) {
            setSquareFeet(String.valueOf(applicant.squareFeet));
        }
        if ((propertyData == null) || (propertyData.getYearBuilt() == null) || (propertyData.getSquareFeet() == null)) {
            propertyData = null;
        }
        if (propertyData != null) {
            verifyPageFields(applicant, fsa, propertyData);
        }
    }

    public void clearRequiredFields() {
        String selectAll = PWKeys.chord(PWKeys.CONTROL, "a");
        sendKeysToElement(inputYearBuilt, selectAll);
        sendKeysToElement(inputYearBuilt, "1");
        sendKeysToElement(inputYearBuilt, PWKeys.BACK_SPACE);
        sendKeysToElement(inputYearBuilt, PWKeys.TAB);
        sendKeysToElement(inputSquareFeet, selectAll);
        sendKeysToElement(inputSquareFeet, PWKeys.BACK_SPACE);
    }

    public void clearYearBuilt() {
        String selectAll = PWKeys.chord(PWKeys.CONTROL, "a");
        sendKeysToElement(inputYearBuilt, selectAll);
        sendKeysToElement(inputYearBuilt, "1");
        sendKeysToElement(inputYearBuilt, PWKeys.BACK_SPACE);
        sendKeysToElement(inputYearBuilt, PWKeys.TAB);
    }

    public void clearSquareFeet() {
        sendKeysToElement(inputSquareFeet, "1"+ PWKeys.BACK_SPACE);
    }

    public void setYearBuilt(String yearBuilt) {
        waitAndClickElement(inputYearBuilt);
        sendKeysToElement(inputYearBuilt, yearBuilt);
    }

    public void setSquareFeet(String squareFeet) {
        waitAndClickElement(inputSquareFeet);
        sendKeysToElement(inputSquareFeet, squareFeet);
    }

    public void verifyPageFields(ApplicantHQM applicant, FarmersSoftAssert fsa, @Nullable PrefillResponseHQM propertyData) {
        String yearBuilt;
        String squareFeet;
        if ((propertyData == null) || (!applicant.keep360Prefill)) {
            Log.info("Property data is null or using data provider property data.");
            yearBuilt = Integer.toString(applicant.yearBuilt);
            squareFeet = (applicant.squareFeet.length() < 6) ? applicant.squareFeet : applicant.squareFeet.substring(0,5);
        } else {
            Log.info("Property data is going to be taken from Postgres.");
            yearBuilt = propertyData.getYearBuilt();
            squareFeet = propertyData.getSquareFeet();
            try {
                fsa.assertEquals(propertyData.getStreet().toUpperCase(), applicant.addressApt, "Property page - Street address");
                fsa.assertEquals(propertyData.getCity().toUpperCase(), applicant.city, "Property page - City address");
                fsa.assertEquals(propertyData.getZipCode(), applicant.zipCode, "Property page - Zip address");
                fsa.assertEquals(propertyData.getStateCode(), applicant.stateCode, "Property page - State address");
                if (applicant.stateCode.equals(NC)) {
                    if (!applicant.county.isEmpty()) {
                        String county = (propertyData.getCounty() == null) ? "" : propertyData.getCounty();
                        fsa.assertEquals(county, applicant.county, "Property page - County selected.");
                    } else {
                        // when applicant.county is blank, then first county on the drop-down list get selected
                        if (!propertyData.getCountyNameList().isEmpty()) {
                            fsa.assertEquals(propertyData.getCounty(), propertyData.getCountyNameList().get(0),
                                    "Property page - County selected.");
                        }
                    }
                }
            } catch (NullPointerException e) {
                Log.warn("Unable to verify property address, no data in Postgres.");
            }
        }
        fsa.assertEquals(getYearBuilt(), yearBuilt, "Property page - Year Built match");
        fsa.assertEquals(getSquareFeet(), squareFeet, "Property page - Square Footage match");
    }

    public String getYearBuilt() {
    	String yearBuilt = getAttributeData(inputYearBuilt, VALUE);
        Log.info("Year Built: " + yearBuilt);
        return yearBuilt;
    }

    public String getSquareFeet() {
    	String squareFootage = getAttributeData(inputSquareFeet, VALUE);
        Log.info("Square Footage: " + squareFootage);
        return squareFootage;
    }

    public void validateHelpDialogs(ApplicantHQM applicant, FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) throws InterruptedException {
        waitAndClickElement(helpYearBuilt);
        sleepMillis(500);  // Using this as waitElementBeVisible seems unreliable
        fsa.assertEquals(getTextFromElement(helpDialogTitle), YEAR_BUILT_HELP_TITLE, "Year Built Help Title validated.");
        String strYearBuiltHelp = isEasternExpansionState(applicant.stateCode) ?
                YEAR_BUILT_HELP_CONTENT_KY : YEAR_BUILT_HELP_CONTENT;
        fsa.assertEquals(getTextFromElement(helpDialogContent), strYearBuiltHelp, "Year Built Help Content validated.");
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getPropertyInfoContent().get(0), strYearBuiltHelp, "Year Built Help Content validated (AEM).");
        }
        waitAndClickElement(buttonCloseDialog);
        //
        waitAndClickElement(helpSquareFeet);
        sleepMillis(500);  // Using this as waitElementBeVisible seems unreliable
        fsa.assertEquals(getTextFromElement(helpDialogTitle), SQUARE_FEET_HELP_TITLE, "Square Feet Help Title validated.");
        fsa.assertEquals(getTextFromElement(helpDialogContent), SQUARE_FEET_HELP_CONTENT, "Square Feet Help Content validated.");
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getPropertyInfoContent().get(1), SQUARE_FEET_HELP_CONTENT, "Year Built Help Content validated (AEM).");
        }
        waitAndClickElement(buttonCloseDialog);
    }

    public void validatePageErrors(ApplicantHQM applicant) throws Exception {
        this.clearYearBuilt();
        this.setSquareFeet(applicant.squareFeet);
        this.clickButtonNext();
        List<String> pageErrors1 = this.getPageErrors();
        Log.info(FOUND_PAGE_ERRORS + pageErrors1);
        Assert.assertEquals(pageErrors1, errorsPropertyPage1.subList(0,1), "Property page - Found all expected errors.");

        this.clearSquareFeet();
        this.clickButtonNext();
        pageErrors1 = this.getPageErrors();
        Log.info(FOUND_PAGE_ERRORS + pageErrors1);
        Assert.assertEquals(pageErrors1, errorsPropertyPage1, "Property page - Found all expected errors.");

        this.setSquareFeet("1500");
        this.setYearBuilt("123");
        List<String> pageErrors2 = this.getPageErrors();
        Log.info(FOUND_PAGE_ERRORS + pageErrors2);
        Assert.assertEquals(pageErrors2, errorsPropertyPage2.subList(0,1), "Property page - Found expected error.");

        this.setYearBuilt("2200");
        List<String> pageErrors3 = this.getPageErrors();
        Log.info(FOUND_PAGE_ERRORS + pageErrors3);
        Assert.assertEquals(pageErrors3, errorsPropertyPage2.subList(1,2), "Property page - Found expected error.");
        this.setYearBuilt("");
    }

    public void validatePageTitles(FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) {
        fsa.assertEquals(getTextFromElement(textPageTitle), PROPERTY_PAGE_TITLE, "Property page - page Title.");
        fsa.assertEquals(getTextFromElement(textPageSubTitle), PROPERTY_PAGE_SUBTITLE, "Property page - page Sub-Title.");
        if (staticContent != null){
            fsa.assertEquals(staticContent.getPropertyTitle(), PROPERTY_PAGE_TITLE, "Property page - page Title (AEM).");
            fsa.assertEquals(staticContent.getPropertyCaption(), PROPERTY_PAGE_SUBTITLE, "Property page - page Sub-Title (AEM).");
        }
    }

    public  List<String> getDiscounts() throws Exception {
        List<String> listDiscounts = new ArrayList<>();
        if (isElementDisplayed(PWBy.xpath(HELP_BUTTON_PIGGY_XPATH))) {
            waitAndClickElement(discountHelpButtonPiggy);
            sleepMillis(500);  // Using this as waitElementBeVisible seems unreliable
            listDiscounts = driver().findElements(PWBy.xpath(DISCOUNT_HELP_DIALOG_CONTENT_XPATH)).stream()
                    .map(this::getTextFromElement).collect(Collectors.toList());
            waitAndClickElement(buttonCloseDialog);
        }
        return listDiscounts;
    }

    public void validateSubtitlesDiscountJourney(@Nullable List<String> discounts, String stateCode, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(discountSubTitleClock), DISCOUNT_CLOCK_TEXT,
                "Property page - Discount Journey Subtitle Clock image.");
        String yearBuilt = this.getYearBuilt();
        int discountCount = 0;
        ArrayList<String> discountsAvailable = new ArrayList<>();
        if (discounts == null) {
            if (!stateCode.equals(CA)) {
                discountCount = 1;
                discountsAvailable.add("Good Payer");
            }
        } else {
            discountCount = discounts.size();
            discountsAvailable = new ArrayList<>(discounts);
        }
        Year currentYear = Year.now();
        if ((discounts == null) && (currentYear.minusYears(Integer.parseInt(yearBuilt)).getValue() < 14)
             && !stateCode.equals(MN) && !isFlexState(stateCode)) {
            discountsAvailable.add(NEW_HOME);
            discountCount++;
        }
        String textDiscount = discountCount > 0? discountCount + " p" : "P";
        fsa.assertEquals(getTextFromElement(discountSubTitlePiggy), textDiscount + DISCOUNT_PIGGY_TEXT,
                "Property page - Discount Journey Subtitle Lock image.");
        if (discountCount > 0) {
            waitAndClickElement(discountHelpButtonPiggy);
            waitElementBeVisible(discountHelpDialogTitle);
            fsa.assertEquals(getTextFromElement(discountHelpDialogTitle), DISCOUNT_HELP_DIALOG_TITLE.replace("($)", "(" + discountCount + ")"),
                    "Property page - Discount Journey Help Dialog Title.");
            List<String> listDiscounts = driver().findElements(PWBy.xpath(DISCOUNT_HELP_DIALOG_CONTENT_XPATH)).stream()
                    .map(this::getTextFromElement).sorted(Comparator.naturalOrder()).collect(Collectors.toList());
            discountsAvailable.sort(Comparator.naturalOrder());
            fsa.assertEquals(listDiscounts, discountsAvailable, "Property page - Discount Journey Help Dialog Content.");
            waitAndClickElement(buttonCloseDialog);
        }
        //
        if (discountsAvailable.contains("New Home") && (discounts == null)) {
            fsa.assertEquals(getTextFromElement(discountCheck), textDiscountCheck, "Property page - Discount Journey, Discount Check.");
        }
    }

    public void validatePageFooters(@Nullable StaticContentHQM staticContent) throws Exception {
        List<String> listPageFooters = driver().findElements(pageFooters).stream().map(this::getTextFromElement)
                .filter(el-> !el.isEmpty()).collect(Collectors.toList());
        Log.info("Found Property page footers: " + listPageFooters);
        Assert.assertEquals(listPageFooters, footersPropertyPage, "Validate Property page footers.");
        if (staticContent != null) {
            Assert.assertEquals(Collections.singletonList(staticContent.getPropertyDisclaimer()), footersPropertyPage,
                    "Validate Property page footers (AEM).");
        }
    }

    public void verifyPageFieldsNotReadonly(FarmersSoftAssert fsa) {
        fsa.assertEquals(getAttributeData(inputYearBuilt, READONLY), EMPTY_STRING, "Property page - Year Built is not read-only");
        fsa.assertEquals(getAttributeData(inputSquareFeet, READONLY), EMPTY_STRING, "Property page - Square Feet is not read-only");
    }


}
