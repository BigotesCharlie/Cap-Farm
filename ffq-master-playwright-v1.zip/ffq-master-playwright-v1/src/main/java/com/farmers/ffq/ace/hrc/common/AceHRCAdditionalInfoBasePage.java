package com.farmers.ffq.ace.hrc.common;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.DateCalculations;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;

import org.testng.Assert;

import java.time.LocalDate;
import java.time.Year;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCAdditionalInfoBasePage extends AceHRCBasePage {
    private static final String expectedPleaseSpecifyHeaderText = "Please specify:";
    protected static final String expectedUnMonitoredLabel = "Unmonitored";
    protected static final String expectedProfessionallyMonitoredLabel = "Professionally monitored";
    protected static final String expectedSelfMonitoredLabel = "Self-monitored";
    private static final String expectedUnMonitoredSubtextLabel = "Alerts only by making a loud noise";
    private static final String expectedSelfMonitoredSubtextLabel = "Alerts you via email, text, or app";
    private static final String expectedFortifiedRoofLabel = "FORTIFIED Roof";
    private static final String expectedFortifiedSilverLabel = "FORTIFIED Silver";
    private static final String expectedFortifiedGoldLabel = "FORTIFIED Gold";
    private static final String expectedFortifiedInternationalCodeLabel = "2006 International Residential Code";
    private static final String expectedFortifiedForSaferLivingLabel = "FORTIFIED for Safer Living";
    private static final String expectedSprinklerSystemFullLabel = "Full";
    private static final String expectedSprinklerSystemPartialLabel = "Partial";
    private static final String expectedULRoofLabel = "A roof that is UL-certified with a rating of UL Class 3 or 4 can qualify you for a discount.";

    public static final String ARCHITECTURAL_SHINGLE = "Architectural shingle";
    public static final String THREE_TAB_SHINGLE = "3-tab shingle";
    public static final String IMPACT_RESISTANT_SHINGLE = "Impact resistant shingle";
    public static final String I_AM_NOT_SURE = "I am not sure";


    @PWFindBy(xpath = "//div[@class='home-additional-info-info_name_dob_h1']//h1")
    private PWElement additionalInfoHeader;

    @PWFindBy(xpath = "//div[@id='doAnyApplyHeading']//div[@id='home-additional-info_name_dob-subheading']")
    private PWElement anyOfTheFollowingApplyToYourHomeQuestion;

    protected static final String MAT_CHECKBOX_XPATH = "//mat-checkbox";
    @PWFindBy(xpath = MAT_CHECKBOX_XPATH)
    private PWElement matCheckBox;

    @PWFindBy (xpath = "//mat-checkbox[contains(@class,'mat-checkbox-checked')]")
    private List<PWElement> listOfCheckedCheckBoxes;
    @PWFindBy (xpath = "//div[@id='roofCoverage']//div[contains(@class,'subheading')]")
	protected PWElement roofCompletelyReplacedQuestion;
    @PWFindBy (xpath = "//div[@id='roofCoverage']//h2[contains(., 'replaced')]")
	protected PWElement roofCompletelyReplacedQuestionAlternate;
    @PWFindBy (xpath = "//div[@id='roofCoverage']//button")
    private List<PWElement> roofCompletelyReplacedToggleButtons;
    @PWFindBy(xpath = "//div[@id='roofCoverage']//button//span[contains(text(),'Yes')]")
    private PWElement roofCompletelyReplacedYesButton;
    @PWFindBy(xpath = "//div[@id='roofCoverage']//button//span[contains(text(),'No')]")
    private PWElement roofCompletelyReplacedNoButton;
    @PWFindBy(xpath = "//p[contains(@class,'roof-label')]")
	protected PWElement whenWasTheLastTimeRoofWasReplacedQuestion;
    @PWFindBy(xpath = "//div[contains(@class,'roof-question')]//input")
	protected PWElement roofYearInputField;
    @PWFindBy(xpath = "//div[contains(@class,'roof-question')]//label")
	protected PWElement yearPlaceHolderText;
    @PWFindBy(xpath = ROOF_TOGGLE_BUTTON_NO_XPATH + "//ancestor::mat-button-toggle")
    private PWElement roofToggleNoButton;
    private static final String ROOF_TOGGLE_BUTTON_NO_XPATH = "//div[@id='roofCoverage']//button//span[contains(text(),'No')]";
    @PWFindBy(xpath = "//div[@id='roofCoverage']/div[@id='roofReplacement']")
    private PWElement roofReplacedYearSubtitle;
    @PWFindBy(xpath = "//div[@id='roofCoverage']//div[contains(@class,'roof-year')]/span")
    private PWElement roofReplacedYearText;
    @PWFindBy(xpath = "//div[@id='roofCoverage']//div[contains(@class,'roof-year')]/button")
    private PWElement editRoofReplacedYearButton;
    @PWFindBy(xpath = "//div[@id='roofCoverage']//p[@id='roofReplacedLabel']")
    private PWElement roofReplacedYearInputText;
    @PWFindBy(xpath = "//div[@id='roofCoverage']//input[@aria-labelledby='roofReplacedLabel']")
    private PWElement roofReplacedYearInput;
    @PWFindBy (xpath = "//mat-select/ancestor::mat-form-field/preceding-sibling::h2")
	protected PWElement roofMaterialSectionLabel;
    @PWFindBy (xpath = "//mat-select")
	protected PWElement roofMaterialDropdown;

    @PWFindBy(xpath = "//div[@id='plumbingReplacement20yearBuiltCheck']//div[contains(@class,'subheading')]")
    private PWElement plumbingReplaced20YearQuestion;
    @PWFindBy(xpath = "//div[@id='plumbingReplacement20yearBuiltCheck']//mat-button-toggle[contains(.,'Yes')]")
    private PWElement plumbingReplaced20YearYesMatButton;
    @PWFindBy(xpath = "//div[@id='plumbingReplacement20yearBuiltCheck']//mat-button-toggle[contains(.,'Yes')]//button")
    private PWElement plumbingReplaced20YearYesButton;
    @PWFindBy(xpath = "//div[@id='plumbingReplacement20yearBuiltCheck']//mat-button-toggle[contains(.,'No')]")
    private PWElement plumbingReplaced20YearNoMatButton;
    @PWFindBy(xpath = "//div[@id='plumbingReplacement20yearBuiltCheck']//mat-button-toggle[contains(.,'No')]//button")
    private PWElement plumbingReplaced20YearNoButton;


    private static final String TEMPORARY_RENTAL_CHECKBOX_XPATH = "//div[contains(@class,'home-additional-info-rentals')]//mat-checkbox";
    @PWFindBy(xpath = TEMPORARY_RENTAL_CHECKBOX_XPATH + "//input")
    private PWElement temporaryRentalInputCheckbox;
    @PWFindBy(xpath = TEMPORARY_RENTAL_CHECKBOX_XPATH)
    private PWElement temporaryRentalMatCheckbox;
    @PWFindBy(xpath = TEMPORARY_RENTAL_CHECKBOX_XPATH + "//mat-label")
    private PWElement temporaryRentalCheckboxLabel;
    @PWFindBy(xpath = "//div[contains(@class,'home-additional-info-rentals')]//p")
    private PWElement temporaryRentalSubText;

    private static final String IMPACT_RESISTANT_GLASS_CHECKBOX_XPATH = "//div[contains(@class,'home-resistive-glass')]//mat-checkbox";
    @PWFindBy(xpath = IMPACT_RESISTANT_GLASS_CHECKBOX_XPATH)
    private PWElement impactResistantGlassMatCheckbox;
    @PWFindBy(xpath = IMPACT_RESISTANT_GLASS_CHECKBOX_XPATH + "//mat-label")
    private PWElement impactResistantGlassCheckboxLabel;
    private static final String OIL_TANK_ON_PREMISES_CHECKBOX_XPATH = "//div[contains(@class,'home-additional-info-oil-tank')]//mat-checkbox";
    @PWFindBy(xpath = OIL_TANK_ON_PREMISES_CHECKBOX_XPATH)
    private PWElement oilTankOnPremisesMatCheckbox;
    @PWFindBy(xpath = OIL_TANK_ON_PREMISES_CHECKBOX_XPATH + "//mat-label")
    private PWElement oilTankOnPremisesCheckboxLabel;
    private static final String SWIMMING_POOL_CHECKBOX_XPATH = "//div[contains(@class,'home-additional-info-swimming')]//mat-checkbox";
    @PWFindBy(xpath = SWIMMING_POOL_CHECKBOX_XPATH)
    private PWElement swimmingPoolCheckbox;
    @PWFindBy(xpath = SWIMMING_POOL_CHECKBOX_XPATH + "//mat-label")
    private PWElement swimmingPoolCheckboxLabel;
    @PWFindBy(xpath = "//app-additional-info//div[@id='swimmingPool']//div[contains(@class,'additional-info-card')]//label[contains(@class,'tui-caption')]")
    private PWElement pleaseSpecifyLabelSwimmingPool;
    private static final String SWIMMING_POOL_RADIO_XPATH = "//div[contains(@class,'home-additional-info-swimming')]//div[contains(@class,'additional-info-card')]//mat-radio-button";
    @PWFindBy(xpath = SWIMMING_POOL_RADIO_XPATH)
    private List<PWElement> fencedUnfencedSwimmingPoolRadioButtons;
    @PWFindBy(xpath = SWIMMING_POOL_RADIO_XPATH)
    private PWElement fencedUnfencedSwimmingPoolRadioButton;

    private static final String SOLAR_CHECKBOX_XPATH = "//div[contains(@class,'home-additional-info-solar')]//mat-checkbox";
    @PWFindBy(xpath = SOLAR_CHECKBOX_XPATH)
    private PWElement solarPanelCheckbox;
    @PWFindBy(xpath = "//div[contains(@class,'home-additional-info-solar')]//mat-label")
    private PWElement solarPanelCheckboxLabel;

    private static final String TRAMPOLINE_CHECKBOX_XPATH = "//div[contains(@class,'home-additional-info-trampoline')]//mat-checkbox";
    @PWFindBy(xpath = TRAMPOLINE_CHECKBOX_XPATH)
    private PWElement trampolineCheckbox;
    @PWFindBy(xpath = "//div[contains(@class,'home-additional-info-trampoline')]//mat-label")
    private PWElement trampolineCheckboxLabel;
    @PWFindBy(xpath = "//app-additional-info//div[@id='trampoline']//div[contains(@class,'additional-info-card')]//label[contains(@class,'tui-caption')]")
    private PWElement pleaseSpecifyLabelTrampoline;
    private static final String TRAMPOLINE_RADIO_XPATH = "//div[contains(@class,'home-additional-info-trampoline')]//div[contains(@class,'additional-info-card')]//mat-radio-button";
    @PWFindBy(xpath = TRAMPOLINE_RADIO_XPATH)
    private List<PWElement> fencedUnfencedTrampolineRadioButtons;
    @PWFindBy(xpath = TRAMPOLINE_RADIO_XPATH)
    private PWElement fencedUnfencedTrampolineRadioButton;
    private static final String STORM_SHUTTER_CHECKBOX_XPATH = "//div[contains(@class,'home-additional-storm-shutter')]//mat-checkbox";
    @PWFindBy(xpath = STORM_SHUTTER_CHECKBOX_XPATH)
    private PWElement stormShutterCheckbox;
    @PWFindBy(xpath = "//div[contains(@class,'home-additional-storm-shutter')]//mat-label")
    private PWElement stormShutterCheckboxLabel;

    @PWFindBy(xpath = "//mat-divider[contains(@class,'additional-discounts-divider')]")
    private PWElement matDividerDiscountSection;
    @PWFindBy(xpath = "//div[@id='headingDiscountDiv']//div[@id='home-additional-discount-subheading']")
    private PWElement additionalDiscountHeader;
    @PWFindBy(xpath = "//div[contains(@class,'additional-discounts')]//mat-checkbox//input")
    private List<PWElement> discountCheckboxInput;
    @PWFindBy(xpath = "//div[contains(@class,'additional-discounts')]//mat-checkbox")
    private List<PWElement> discountMatCheckbox;
    @PWFindBy(xpath = "//div[contains(@class,'additional-discounts')]//mat-checkbox//mat-label")
    private List<PWElement> discountCheckboxLabel;
    @PWFindBy(xpath = "//div[contains(@class,'additional-discounts-card')]//mat-card/div/label")
    private List<PWElement> pleaseSpecifyLabelDiscounts;

    private static final String FIRE_ALARM_DIV = "//div[@id='fireAlarmDiscount']";
    private static final String FIRE_ALARM_CHECKBOX_XPATH = FIRE_ALARM_DIV + "//mat-checkbox";
    @PWFindBy(xpath = FIRE_ALARM_CHECKBOX_XPATH)
    protected PWElement fireAlarmMatCheckbox;
    private static final String FIRE_ALARM_RADIO_XPATH = FIRE_ALARM_DIV + "//mat-card//mat-radio-button";
    @PWFindBy(xpath = FIRE_ALARM_RADIO_XPATH + "//input")
    private List<PWElement> fireAlarmRadioButtons;
    @PWFindBy(xpath = FIRE_ALARM_RADIO_XPATH)
    private PWElement fireAlarmRadioButton;
    @PWFindBy(xpath = FIRE_ALARM_RADIO_XPATH)
    protected List<PWElement> fireAlarmMatRadioButtons;
    @PWFindBy(xpath = FIRE_ALARM_RADIO_XPATH + "/following-sibling::span")
    private List<PWElement> fireAlarmRadioButtonsSubtext;
    @PWFindBy(xpath = FIRE_ALARM_CHECKBOX_XPATH + "//mat-label")
    private PWElement fireAlarmCheckboxLabel;
    @PWFindBy(xpath = FIRE_ALARM_DIV + "//mat-card/div/label")
    private PWElement fireAlarmPleaseSpecifyLabel;
    private static final String FIRE_PROTECTION_RADIO_XPATH = "//div[@id='fireProtectionDiscount']//mat-card//mat-radio-button";
    @PWFindBy(xpath = "//div[@id='fireProtectionDiscount']//mat-radio-button")
    private PWElement fireAlarmsRadioButton;
    private static final String FIRE_PROTECTION_CHECKBOX_XPATH = "//div[@id='fireProtectionDiscount']//mat-checkbox";
    @PWFindBy(xpath = FIRE_PROTECTION_CHECKBOX_XPATH)
    protected PWElement fireProtectionSystemsCheckbox;
    @PWFindBy(xpath = "//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Fire Alarms')]]//button[contains(.,'Yes')]")
    private PWElement fireAlarmsToggleButtonYes;
    @PWFindBy(xpath = "//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Fire Alarms')]]//button[contains(.,'No')]")
    private PWElement fireAlarmsToggleButtonNo;
    @PWFindBy(xpath = "//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Smoke Alarms')]]//button[contains(.,'Yes')]")
    private PWElement smokeAlarmsToggleButtonYes;
    @PWFindBy(xpath = "//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Smoke Alarms')]]//button[contains(.,'No')]")
    private PWElement smokeAlarmsToggleButtonNo;
    @PWFindBy(xpath = "//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Sprinkler systems')]]//button[contains(.,'Yes')]")
    private PWElement sprinklerSystemsToggleButtonYes;
    @PWFindBy(xpath = "//div[@id='fireProtectionDiscount']//div[mat-label[contains(text(),'Sprinkler systems')]]//button[contains(.,'No')]")
    private PWElement sprinklerSystemsToggleButtonNo;
    @PWFindBy(xpath = "//div[@id='fireProtectionDiscount']//mat-radio-button[contains(@id,'RADIO_BUTTON_FOR_SPRINKLER_ALARM_P')]")
    private PWElement sprinklerSystemRadioButtonPartial;
    @PWFindBy(xpath = "//div[@id='fireProtectionDiscount']//mat-radio-button[contains(@id,'RADIO_BUTTON_FOR_SPRINKLER_ALARM_F')]")
    private PWElement sprinklerSystemRadioButtonFull;

    protected static final String BURGLAR_ALARM_DIV = "//div[@id='burglarAlarmDiscount']";
    protected static final String BURGLAR_ALARM_CHECKBOX_XPATH = BURGLAR_ALARM_DIV + "//mat-checkbox";
    @PWFindBy(xpath = BURGLAR_ALARM_CHECKBOX_XPATH)
    protected PWElement burglarAlarmMatCheckbox;
    private static final String BURGLAR_ALARM_RADIO_XPATH = BURGLAR_ALARM_DIV + "//mat-card//mat-radio-button";
    @PWFindBy(xpath = BURGLAR_ALARM_RADIO_XPATH + "//input")
    protected List<PWElement> burglarAlarmRadioButtonsInput;
    @PWFindBy(xpath = BURGLAR_ALARM_RADIO_XPATH)
    protected PWElement burglarAlarmRadioButton;
    @PWFindBy(xpath = BURGLAR_ALARM_RADIO_XPATH)
    private List<PWElement> burglarAlarmMatRadioButtons;
    @PWFindBy(xpath = BURGLAR_ALARM_RADIO_XPATH + "/following-sibling::span")
    private List<PWElement> burglarAlarmRadioButtonsSubtext;
    @PWFindBy(xpath = BURGLAR_ALARM_CHECKBOX_XPATH + "//mat-label")
    private PWElement burglarAlarmCheckboxLabel;

    private static final String OTHER_HOME_PROTECTION_FEATURES_XPATH = "//div[@id='homeProtectionLossPreventionDiscount']//mat-checkbox";
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_XPATH)
    private PWElement otherHomeProtectionFeaturesMatCheckbox;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_XPATH + "//label")
    private PWElement otherHomeProtectionFeaturesCheckboxLabel;
    private static final String OTHER_HOME_PROTECTION_RADIO_BUTTONS_XPATH = "//div[@id='homeProtectionLossPreventionDiscount']//mat-radio-button[contains(@id,'RADIO_BUTTON_FOR_HOMEPROTECTION')]";
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_RADIO_BUTTONS_XPATH)
    private List<PWElement> otherHomeProtectionFeaturesRadioButtons;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_RADIO_BUTTONS_XPATH + "//label")
    private List<PWElement> otherHomeProtectionFeaturesRadioButtonLabels;
    @PWFindBy(xpath = "//div[@id='homeProtectionLossPreventionDiscount']//p[contains(@class,'tui-caption')]")
    private PWElement otherHomeProtectionSubtitleLabel;
    @PWFindBy(xpath = "//div[@id='homeProtectionLossPreventionDiscount']//span[@role='button']")
    private PWElement otherHomeProtectionHelpSideSheetLink;
    private static final String OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH = "//app-home-discount-descriptions-sidesheet";
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//h1")
    private PWElement otherHomeProtectionHelpSideSheetTitle;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-epa')]/p[contains(@class,'tui-subtitle-text-2')]")
    private PWElement otherHomeProtectionSideSheetEPASubTitle;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-epa')]/p[contains(@class,'tui-input-text')]")
    private PWElement otherHomeProtectionSideSheetEPAContent;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-fh')]/p[contains(@class,'tui-subtitle-text-2')]")
    private PWElement otherHomeProtectionSideSheetFortifiedHomeSubTitle;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-fh')]/p[contains(@class,'tui-input-text')]")
    private PWElement otherHomeProtectionSideSheetFortifiedHomeContent;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-ch')]/p[contains(@class,'tui-subtitle-text-2')]")
    private PWElement otherHomeProtectionSideSheetConnectedHomeSubTitle;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-ch')]/p[contains(@class,'tui-input-text')]")
    private PWElement otherHomeProtectionSideSheetConnectedHomeContent;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-ch')]/ul[contains(@class,'tui-input-text')]")
    private PWElement otherHomeProtectionSideSheetConnectedHomeContentMore;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-automatic-gas')]/p[contains(@class,'tui-subtitle-text-2')]")
    private PWElement otherHomeProtectionSideSheetAutomaticGasSubTitle;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-automatic-gas')]/p[contains(@class,'tui-input-text')]")
    private PWElement otherHomeProtectionSideSheetAutomaticGasContent;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-water-leak')]/p[contains(@class,'tui-subtitle-text-2')]")
    private PWElement otherHomeProtectionSideSheetWaterLeakSubTitle;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//div[contains(@class,'discount-description-water-leak')]/p[contains(@class,'tui-input-text')]")
    private PWElement otherHomeProtectionSideSheetWaterLeakContent;
    @PWFindBy(xpath = OTHER_HOME_PROTECTION_FEATURES_SIDE_SHEET_XPATH + "//mat-icon[text()='close']")
    private PWElement otherHomeProtectionSideSheetCloseButton;


    private static final String FIRE_SPRINKLER_XPATH = "//div[@id='fireSprinkler']//mat-checkbox";
    @PWFindBy(xpath = FIRE_SPRINKLER_XPATH + "//label")
    private PWElement fireSprinklerCheckbox;

    private static final String ALARM_SYSTEM_CHECKBOX_XPATH = "//div[@id='alarmSystemOnProperties']//mat-checkbox";
    @PWFindBy(xpath = ALARM_SYSTEM_CHECKBOX_XPATH)
    private PWElement alarmSystemMatCheckbox;
    @PWFindBy(xpath = ALARM_SYSTEM_CHECKBOX_XPATH + "//label")
    private PWElement alarmSystemCheckboxLabel;
    private static final String LOCAL_ALARMS_LABEL_XPATH = "//div[@id='alarmSystemOnProperties']//label[contains(text(),'Local alarms')]";
    @PWFindBy(xpath = LOCAL_ALARMS_LABEL_XPATH)
    private PWElement localAlarmsLabel;
    @PWFindBy(xpath = LOCAL_ALARMS_LABEL_XPATH + "/following::button[contains(.,'Yes')][1]")
    private PWElement localAlarmButtonYes;
    @PWFindBy(xpath = LOCAL_ALARMS_LABEL_XPATH + "/following::button[contains(.,'No')][1]")
    private PWElement localAlarmButtonNo;
    private static final String CENTRAL_ALARMS_LABEL_XPATH = "//div[@id='alarmSystemOnProperties']//label[contains(text(),'Central alarms')]";
    @PWFindBy(xpath = CENTRAL_ALARMS_LABEL_XPATH)
    private PWElement centralAlarmsLabel;
    @PWFindBy(xpath = CENTRAL_ALARMS_LABEL_XPATH + "/following::button[contains(.,'Yes')][1]")
    private PWElement centralAlarmButtonYes;
    @PWFindBy(xpath = CENTRAL_ALARMS_LABEL_XPATH + "/following::button[contains(.,'No')][1]")
    private PWElement centralAlarmButtonNo;
    private static final String DIRECT_SYSTEMS_LABEL_XPATH = "//div[@id='alarmSystemOnProperties']//label[contains(text(),'Direct systems')]";
    @PWFindBy(xpath = DIRECT_SYSTEMS_LABEL_XPATH)
    private PWElement directSystemsLabel;
    @PWFindBy(xpath = DIRECT_SYSTEMS_LABEL_XPATH + "/following::button[contains(.,'Yes')][1]")
    private PWElement directSystemsButtonYes;
    @PWFindBy(xpath = DIRECT_SYSTEMS_LABEL_XPATH + "/following::button[contains(.,'No')][1]")
    private PWElement directSystemsButtonNo;

    private static final String WATER_PROTECTION_DIV_XPATH = "//div[@id='waterLeakDiscount']";
    private static final String WATER_PROTECTION_CHECKBOX_XPATH = WATER_PROTECTION_DIV_XPATH + "//mat-checkbox";
    @PWFindBy(xpath = WATER_PROTECTION_CHECKBOX_XPATH)
    protected PWElement waterProtectionMatCheckbox;
    private static final String WATER_PROTECTION_INPUT_CHECKBOX_XPATH = WATER_PROTECTION_DIV_XPATH + "//mat-checkbox//input";
    @PWFindBy(xpath = WATER_PROTECTION_INPUT_CHECKBOX_XPATH)
    private PWElement waterProtectionInputCheckbox;
    @PWFindBy(xpath = WATER_PROTECTION_CHECKBOX_XPATH + "//mat-label")
    private PWElement waterProtectionCheckboxLabel;
    private static final String WATER_PROTECTION_RADIO_XPATH = WATER_PROTECTION_DIV_XPATH + "//mat-card//mat-radio-button";
    @PWFindBy(xpath = WATER_PROTECTION_RADIO_XPATH + "//input")
    private List<PWElement> waterProtectionRadioButtons;
    @PWFindBy(xpath = WATER_PROTECTION_RADIO_XPATH)
    private PWElement waterProtectionRadioButton;
    @PWFindBy(xpath = WATER_PROTECTION_RADIO_XPATH)
    private List<PWElement> waterProtectionMatRadioButtons;

    private static final String FORTIFIED_HOME_DIV_XPATH = "//div[@id='fortifiedHomeDiscount']";
    private static final String FORTIFIED_HOME_CHECKBOX_XPATH = FORTIFIED_HOME_DIV_XPATH + "//mat-checkbox";
    @PWFindBy(xpath = FORTIFIED_HOME_CHECKBOX_XPATH)
    private PWElement fortifiedHomeMatCheckbox;
    private static final String FORTIFIED_HOME_CHECKBOX_INPUT_XPATH = FORTIFIED_HOME_DIV_XPATH + "//mat-checkbox//input";
    @PWFindBy(xpath = FORTIFIED_HOME_CHECKBOX_INPUT_XPATH)
    private PWElement fortifiedHomeCheckboxInput;
    @PWFindBy(xpath = FORTIFIED_HOME_CHECKBOX_XPATH + "//mat-label")
    private PWElement fortifiedHomeCheckboxLabel;
    private static final String FORTIFIED_HOME_RADIO_XPATH = "//div[@id='fortifiedHomeDiscount']//mat-card//mat-radio-button";
    @PWFindBy(xpath = FORTIFIED_HOME_RADIO_XPATH + "//input")
    private List<PWElement> fortifiedHomeCertRadioButtons;
    @PWFindBy(xpath = FORTIFIED_HOME_RADIO_XPATH)
    private PWElement fortifiedHomeCertRadioButton;
    @PWFindBy(xpath = FORTIFIED_HOME_RADIO_XPATH)
    private List<PWElement> fortifiedHomeCertMatRadioButtons;
    @PWFindBy(xpath = FORTIFIED_HOME_DIV_XPATH + "//div[contains(@class,'additional-discounts-card')]//mat-card/div/label")
    private PWElement fortifiedHomePleaseSpecifyLabel;

    private static final String WROUGHT_IRON_BARS_DIV_XPATH = "//div[@id='wroughtIronBars']";
    private static final String WROUGHT_IRON_BARS_CHECKBOX_XPATH = WROUGHT_IRON_BARS_DIV_XPATH + "//mat-checkbox";
    @PWFindBy(xpath = WROUGHT_IRON_BARS_CHECKBOX_XPATH + "//input")
    private PWElement wroughtIronBarsInputCheckbox;
    @PWFindBy(xpath = WROUGHT_IRON_BARS_CHECKBOX_XPATH)
    private PWElement wroughtIronBarsMatCheckbox;
    @PWFindBy(xpath = WROUGHT_IRON_BARS_CHECKBOX_XPATH + "//mat-label")
    private PWElement wroughtIronBarsCheckboxLabel;

    private static final String PREVIOUS_INSURANCE_CHECKBOX_XPATH = "//div[@id='transferDiscount']//mat-checkbox";
    @PWFindBy(xpath = PREVIOUS_INSURANCE_CHECKBOX_XPATH + "//input")
    private PWElement previousInsuranceInputCheckbox;
    @PWFindBy(xpath = PREVIOUS_INSURANCE_CHECKBOX_XPATH)
    private PWElement previousInsuranceMatCheckbox;
    @PWFindBy(xpath = PREVIOUS_INSURANCE_CHECKBOX_XPATH + "//mat-label")
    private PWElement previousInsuranceCheckboxLabel;
    @PWFindBy(xpath="//div[@id='transferDiscount']//div[contains(@class,'transfer-discount')]")
    private PWElement previousInsuranceCheckboxSubtext;
    private static final String PREVIOUS_INSURANCE_RADIO_BUTTON_XPATH = "//app-home-transfer-discount//mat-radio-button";
    @PWFindBy(xpath = PREVIOUS_INSURANCE_RADIO_BUTTON_XPATH)
    List<PWElement> previousInsuranceRadioButtons;
    @PWFindBy(xpath = "//app-home-transfer-discount//h2")
    PWElement homeTransferDiscountHeader;
    @PWFindBy(xpath = "//app-home-transfer-discount//div[contains(@class,'tui-input-text')]")
    PWElement homeTransferDiscountSubheader;
    @PWFindBy(xpath = "//app-home-transfer-discount//button[text()='Cancel']")
    PWElement buttonCancelHomeTransferDiscount;
    @PWFindBy(xpath = "//app-home-transfer-discount//button[text()='Save']")
    PWElement buttonSaveHomeTransferDiscount;
    @PWFindBy(xpath = "//app-home-transfer-discount//mat-divider")
    PWElement homeTransferDiscountHeaderDivider;
    @PWFindBy(xpath = "//app-home-transfer-discount//div[contains(@class,'transfer-discount-button-container')]")
    PWElement getHomeTransferDiscountButtonContainer;
    @PWFindBy(xpath="//app-additional-info//div[contains(@class,'transfer-discount-selected-text')]/p")
    PWElement homeDiscountSelected;
    @PWFindBy(xpath="//app-additional-info//div[contains(@class,'transfer-discount-selected-text')]/button")
    PWElement editHomeDiscountSelected;
    @PWFindBy(xpath = "//app-home-transfer-discount//button[.='close']")
    PWElement buttonCloseHomeTransferDiscount;

    private static final String WILDFIRE_RISK_REDUCTION_XPATH = "//div[@id='wildfireDiscount']";
    @PWFindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//label")
    PWElement wildfireRiskReductionCheckboxLabel;
    private static final String WILDFIRE_RISK_REDUCTION_CHECKBOX_XPATH = WILDFIRE_RISK_REDUCTION_XPATH + "//mat-checkbox[contains(@class,'wildfire-riskreduction')]";
    @PWFindBy(xpath = WILDFIRE_RISK_REDUCTION_CHECKBOX_XPATH)
    PWElement wildfireRiskReductionMatCheckbox;
    private static final String WILDFIRE_RISK_REDUCTION_CHECKBOXES_XPATH = WILDFIRE_RISK_REDUCTION_XPATH + "//mat-card//mat-checkbox";
    @PWFindBy(xpath = WILDFIRE_RISK_REDUCTION_CHECKBOXES_XPATH)
    List<PWElement> wildfireRiskReductionMatCheckboxes;
    private static final String WILDFIRE_RISK_REDUCTION_CHECKBOXES_INPUT_XPATH = WILDFIRE_RISK_REDUCTION_CHECKBOXES_XPATH + "[%s]//input";
    @PWFindBy(xpath = "//div[@id='wildfireDiscount']//mat-card//label[@class='tui-caption']")
    PWElement wildfireRiskReductionCheckboxesLabel;

    private static final String ELECTRICAL_SYSTEM_UPDATED_XPATH = "//div[@id='eletricalSystemDiscount']";
    private static final String ELECTRICAL_SYSTEM_UPDATED_CHECKBOX_XPATH = "//div[@id='eletricalSystemDiscount']//mat-checkbox";
    private static final String ELECTRICAL_SYSTEM_AGE_SURITY_CHECK_XPATH = "//div[@id='eletricalSystemDiscount']//mat-checkbox[@name='surityCheckElectric']";

    @PWFindBy(xpath = ELECTRICAL_SYSTEM_UPDATED_CHECKBOX_XPATH)
    PWElement electricalSystemCheckbox;
    @PWFindBy(xpath = ELECTRICAL_SYSTEM_UPDATED_CHECKBOX_XPATH + "//mat-label")
    PWElement electricalSystemCheckboxLabel;
    @PWFindBy(xpath = ELECTRICAL_SYSTEM_UPDATED_CHECKBOX_XPATH + "/following-sibling::div")
    PWElement electricalSystemCheckboxInfoText;
    @PWFindBy(xpath = ELECTRICAL_SYSTEM_UPDATED_XPATH + "//input[@aria-label='Select the year']")
    PWElement electricalSystemYearInput;
    @PWFindBy(xpath = ELECTRICAL_SYSTEM_UPDATED_XPATH + "//mat-card//p")
    PWElement electricalSystemYearLabel;

    private static final String PLUMBING_SYSTEM_UPDATED_XPATH = "//div[@id='plumbingSystemDiscount']";
    private static final String PLUMBING_SYSTEM_UPDATED_CHECKBOX_XPATH = "//div[@id='plumbingSystemDiscount']//mat-checkbox";
    private static final String PLUMBING_SYSTEM_AGE_SURITY_CHECKBOX_XPATH = "//div[@id='plumbingSystemDiscount']//mat-checkbox[@name='surityCheckPlumbing']";

    @PWFindBy(xpath = PLUMBING_SYSTEM_UPDATED_CHECKBOX_XPATH)
    PWElement plumbingSystemCheckbox;
    @PWFindBy(xpath = PLUMBING_SYSTEM_UPDATED_CHECKBOX_XPATH + "//mat-label")
    PWElement plumbingSystemCheckboxLabel;
    @PWFindBy(xpath = PLUMBING_SYSTEM_UPDATED_CHECKBOX_XPATH + "/following-sibling::div")
    PWElement plumbingSystemCheckboxInfoText;
    @PWFindBy(xpath = PLUMBING_SYSTEM_UPDATED_XPATH + "//input[@aria-label='Select the year']")
    PWElement plumbingSystemYearInput;
    @PWFindBy(xpath = PLUMBING_SYSTEM_UPDATED_XPATH + "//mat-card//p")
    PWElement plumbingSystemYearLabel;

    private static final String PLUMBING_SYSTEM_REPLACED_20_XPATH = "//div[@id='plumbingReplacement20yearBuiltCheck']";
    @PWFindBy(xpath = PLUMBING_SYSTEM_REPLACED_20_XPATH + "//button[.='Yes']")
    PWElement plumbingSystemReplacedYes;
    @PWFindBy(xpath = PLUMBING_SYSTEM_REPLACED_20_XPATH + "//button[.='No']")
    PWElement plumbingSystemReplacedNo;
    @PWFindBy(xpath = PLUMBING_SYSTEM_REPLACED_20_XPATH + "//mat-button-toggle[.='Yes']")
    PWElement plumbingSystemReplacedMatToggleYes;
    @PWFindBy(xpath = PLUMBING_SYSTEM_REPLACED_20_XPATH + "//mat-button-toggle[.='No']")
    PWElement plumbingSystemReplacedMatToggleNo;

    private static final String HVAC_SYSTEM_UPDATED_XPATH = "//div[@id='hvacSystemDiscount']";
    private static final String HVAC_SYSTEM_UPDATED_CHECKBOX_XPATH = "//div[@id='hvacSystemDiscount']//mat-checkbox";
    private static final String HVAC_AGE_SURITY_CHECKBOX_XPATH = "//div[@id='hvacSystemDiscount']//mat-checkbox[@name='surityCheckHvac']";

    @PWFindBy(xpath = HVAC_SYSTEM_UPDATED_CHECKBOX_XPATH)
    PWElement hvacSystemCheckbox;
    @PWFindBy(xpath = HVAC_SYSTEM_UPDATED_CHECKBOX_XPATH + "//mat-label")
    PWElement hvacSystemCheckboxLabel;
    @PWFindBy(xpath = HVAC_SYSTEM_UPDATED_CHECKBOX_XPATH + "/following-sibling::div")
    PWElement hvacSystemCheckboxInfoText;
    @PWFindBy(xpath = HVAC_SYSTEM_UPDATED_XPATH + "//input[@aria-label='Select the year']")
    PWElement hvacSystemYearInput;
    @PWFindBy(xpath = HVAC_SYSTEM_UPDATED_XPATH + "//mat-card//p")
    PWElement hvacSystemYearLabel;

    private static final String NON_SMOKER_XPATH = "//div[@id='nonSmokerDiscount']//mat-checkbox";
    @PWFindBy(xpath = NON_SMOKER_XPATH)
    private PWElement nonSmokerMatCheckbox;

    private static final String CENTRAL_FIRE_ALARM_XPATH = "//div[@id='centralFireDiscount']//mat-checkbox";
    @PWFindBy(xpath = CENTRAL_FIRE_ALARM_XPATH)
    private PWElement centralFireAlarmMatCheckbox;
    @PWFindBy(xpath = CENTRAL_FIRE_ALARM_XPATH + "//label")
    private PWElement centralFireAlarmCheckboxLabel;

    private static final String CENTRAL_BURGLAR_ALARM_XPATH = "//div[@id='centralBurglarDiscount']//mat-checkbox";
    @PWFindBy(xpath = CENTRAL_BURGLAR_ALARM_XPATH)
    private PWElement centralBurglarAlarmMatCheckbox;
    @PWFindBy(xpath = CENTRAL_BURGLAR_ALARM_XPATH + "//label")
    private PWElement centralBurglarAlarmCheckboxLabel;

    @PWFindBy(xpath = "//label[contains(@class,'tui-error')]")
    private List<PWElement> pleaseSpecifyLabelInRedColor;
    //mat-error[contains(text(),"Please select an option.")]
    @PWFindBy(xpath = "//mat-error[contains(text(),'Please select an option.')]")
    private List<PWElement> pleaseSelectAnOptionErrors;
    @PWFindBy(xpath = "//mat-error[contains(text(),'Please provide the year.')]")
    private PWElement pleaseProvideTheYearError;
    @PWFindBy(xpath = "//mat-error[contains(text(),'Invalid year')]")
    private PWElement invalidYearError;
    @PWFindBy(xpath = "//mat-error[contains(text(),'Enter valid roof year')]")
    private PWElement roofYearRangeError;

    @PWFindBy(xpath = "//div[@id='fortifiedHomeDiscount']//span[contains(@class,'tui-body-text-1')]")
    private PWElement populatedFortifiedDesignationVal;

    private static final String FLOOR_RESIDENCE_XPATH = "//div[@id='floorResidence']";
    @PWFindBy(xpath = FLOOR_RESIDENCE_XPATH)
    private PWElement residenceFloorSection;
    @PWFindBy(xpath = FLOOR_RESIDENCE_XPATH + "//mat-checkbox")
    private PWElement residenceFloorCheckbox;
    @PWFindBy(xpath = FLOOR_RESIDENCE_XPATH + "//*[contains(@class,'label')]")
    private PWElement residenceFloorInfoLabel;
    @PWFindBy(xpath = FLOOR_RESIDENCE_XPATH + "//*[contains(@class,'floorResidence_checkbox-description')]")
    private PWElement residenceFloorInfoDescription;

    private static final String UL_ROOF_CHECKBOX_XPATH = "//div[@id='ulRoofDiscount']//mat-checkbox";
    private static final String UL_ROOF_CHECKBOX = "//div[@id='ulRoofDiscount']";
    @PWFindBy(xpath = UL_ROOF_CHECKBOX + "//mat-checkbox")
    private PWElement ulRoofMatCheckbox;
    @PWFindBy(xpath = UL_ROOF_CHECKBOX + "//mat-label")
    private PWElement ulRoofCheckboxLabel;
    @PWFindBy(xpath = UL_ROOF_CHECKBOX + "//label[@id='ulDescription']")
    private PWElement ulRoofDescriptionLabel;
    @PWFindBy(xpath = UL_ROOF_CHECKBOX + "//mat-radio-group")
    private PWElement ulRoofRadioButton;
    @PWFindBy(xpath = UL_ROOF_CHECKBOX + "//mat-radio-button")
    private List<PWElement> ulRoofMatRadioButtons;
    @PWFindBy(xpath = UL_ROOF_CHECKBOX + "//mat-radio-button//label")
    private List<PWElement> ulRoofRadioButtonLabels;


    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceHRCAdditionalInfoBasePage() throws Exception {
        super();
    }

    public boolean isOnAdditionalInfoPage() {
        waitForSpinnerToBeGone();
        scrollToTopOfPage();
        return isElementVisible(additionalInfoHeader, Property.PAGELOADTIMEOUT);
    }

    public void validateTheHeaderOfAdditionalInfoPage(FarmersSoftAssert fsa) throws Exception {
        waitElementBeVisible(additionalInfoHeader);
        String expectedHeaderText = "Additional home information";
        fsa.assertEquals(getTextFromElement(additionalInfoHeader), expectedHeaderText, "Additional info header");
        fsa.assertTrue(isElementInViewport(additionalInfoHeader), "Additional info - page title is in Viewport");
        String expectedQuestionText = "Do any of the following apply to your home?";
        fsa.assertEquals(getTextFromElement(anyOfTheFollowingApplyToYourHomeQuestion), expectedQuestionText, "Any of the following apply to your home question");
    }

    private boolean checkUncheckMatRadiobutton(String checkboxXpath, boolean check) throws Exception {
        boolean success = false;
        PWElement checkBoxWe = driver().findElement(PWBy.xpath(checkboxXpath));
        boolean selected = getAttributeData(checkBoxWe, CLASS).contains(RADIO_BUTTON_CHECKED);
        if (selected != check) {
            waitAndClickElement(checkBoxWe);
            checkBoxWe = driver().findElement(PWBy.xpath(checkboxXpath));
            selected = getAttributeData(checkBoxWe, CLASS).contains(RADIO_BUTTON_CHECKED);
            if (selected != check) {
                checkBoxWe = driver().findElement(PWBy.xpath(checkboxXpath + "/descendant::label"));
                waitAndClickElement(checkBoxWe);
                checkBoxWe = driver().findElement(PWBy.xpath(checkboxXpath));
                selected = getAttributeData(checkBoxWe, CLASS).contains(RADIO_BUTTON_CHECKED);
                if (selected == check) {
                    success = true;
                }
            } else {
                success = true;
            }
        }
        return success;
    }

    public int getNumberOfRoofReplacedToggleButtons() {
        return roofCompletelyReplacedToggleButtons.size();
    }

    public void validateContentOfRoofSection(FarmersSoftAssert fsa, String stateCode) throws Exception {
        final String EXPECTED_ROOF_REPLACED_QUESTION = stateCode.equals(CA) ? "The roof has been fully replaced in the last 10 years." :
                "Has your roof been completely replaced since the house was built?";
        final String EXPECTED_ROOF_REPLACED_NEAR_MAP_SUBTITLE = "Our records show the roof was last fully replaced in the following year:";
        final String EXPECTED_ROOF_REPLACED_YEAR_INPUT_TEXT = "What year was the roof most recently fully replaced?";
        if (!isElementDisplayed(roofReplacedYearText, 2)) {
            fsa.assertEquals(getTextFromElement(roofCompletelyReplacedQuestion), EXPECTED_ROOF_REPLACED_QUESTION,
                    "Roof completely replaced question verification.");

            fsa.assertEquals(getNumberOfRoofReplacedToggleButtons(), 2, "Yes and No roof replaced toggle buttons displayed.");
            clickOnYesToggleButtonForRoofYearSection();

            final String EXPECTED_ROOF_REPLACED_QUESTION_LABEL = stateCode.equals(CA) ? "Year roof was replaced" :
                    "When was the last time it was replaced";
            fsa.assertEquals(getTextFromElement(whenWasTheLastTimeRoofWasReplacedQuestion), EXPECTED_ROOF_REPLACED_QUESTION_LABEL,
                    "When was the last time it was replaced label text verification.");
            fsa.assertTrue(roofYearInputField.isDisplayed(), "Roof year input box displayed.");

            final String expectedYearPlaceHolderText = "Year";
            fsa.assertEquals(getTextFromElement(yearPlaceHolderText), expectedYearPlaceHolderText, "Year place holder text verification.");

            sendKeysToElement(roofYearInputField, LocalDate.now().getYear());
            clickOnNoToggleButtonForRoofYearSection();

            clickOnYesToggleButtonForRoofYearSection();
            fsa.assertEquals(getAttributeData(roofYearInputField, VALUE), EMPTY_STRING, "Roof year input box is blank as expected.");
        } else {
            String roofReplacedYear = getSessionStorageAppStore().getHome().getPropertyDetailsForm().getFieldValueByName("roofReplacedYear");
            fsa.assertEquals(getRoofYearPrefilledByNearMap(), roofReplacedYear, "Property details page - year roof replaced match to appStore.");
            fsa.assertEquals(getTextFromElement(roofReplacedYearSubtitle), EXPECTED_ROOF_REPLACED_NEAR_MAP_SUBTITLE, "Property details page - year roof replaced sub-title match.");
            waitAndClickElement(editRoofReplacedYearButton);
            fsa.assertEquals(getTextFromElement(roofReplacedYearInputText), EXPECTED_ROOF_REPLACED_YEAR_INPUT_TEXT, "Property details page - year roof replaced pre-text match.");
        }
    }

    public void validateContentOfPlumbingReplaced20YearsSection(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {
        if (applicant.getStateCode().equals(CA)) {
            String yearBuilt = getSessionStorageAppStore().getHome().getPropertyForm().getFields().get(0).getYearBuilt();
            if (DateCalculations.ageFromYear(yearBuilt) > 40) {
                String PLUMBING_REPLACED_20YEAR_QUESTION = "Has the entire home's plumbing system been replaced in the last 20 years?";
                fsa.assertEquals(getTextFromElement(plumbingReplaced20YearQuestion), PLUMBING_REPLACED_20YEAR_QUESTION,
                        "Plumbing System replaced in the last 20 years question verification.");
                clickOnYesPlumbingReplaced20Year();
                fsa.assertTrue(isSelectedYesPlumbingSystemReplaced20Year(), "Plumbing system replaced in the last 20 years - Yes selected");
                clickOnNoPlumbingReplaced20Year();
                fsa.assertTrue(isSelectedNoPlumbingSystemReplaced20Year(), "Plumbing system replaced in the last 20 years - No selected");
            } else {
                fsa.assertFalse(isElementDisplayed(plumbingReplaced20YearQuestion, 2), "Plumbing replaced question present");
            }
        }
    }

    public void validateContentOfTemporaryRentalSection(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(temporaryRentalMatCheckbox.isDisplayed(), "Temporary rental checkbox displayed");
        fsa.assertTrue(!getAttributeData(temporaryRentalMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Temporary rental checkbox unchecked on initial load.");

        String expectedTemporaryRentalCheckboxLabel = "It is used for home sharing or temporary rentals.";
        fsa.assertEquals(getTextFromElement(temporaryRentalCheckboxLabel), expectedTemporaryRentalCheckboxLabel, "Temporary rental label verification.");

        String expectedTemporaryRentalCheckboxSubLabel = "For example: Airbnb, Vrbo";
        fsa.assertEquals(getTextFromElement(temporaryRentalSubText), expectedTemporaryRentalCheckboxSubLabel, "Temporary rental sub text verification.");

        checkUncheckMatCheckbox(TEMPORARY_RENTAL_CHECKBOX_XPATH, true);
        fsa.assertTrue(getAttributeData(temporaryRentalMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Temporary rental checkbox checked.");
    }

    public void validateContentOfImpactResistantGlassSection(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(impactResistantGlassMatCheckbox.isDisplayed(), "Impact Resistant Glass checkbox displayed");
        fsa.assertTrue(!getAttributeData(impactResistantGlassMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Impact Resistant Glass checkbox unchecked on initial load.");

        String expectedImpactResistantCheckboxLabel = "It has impact-resistant glass on all windows in the dwelling.";
        fsa.assertEquals(getTextFromElement(impactResistantGlassCheckboxLabel), expectedImpactResistantCheckboxLabel, "Impact Resistant Glass label verification.");

        checkUncheckMatCheckbox(IMPACT_RESISTANT_GLASS_CHECKBOX_XPATH, true);
        fsa.assertTrue(getAttributeData(impactResistantGlassMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Impact Resistant Glass checkbox checked.");
    }

    public void validateContentOfSwimmingPoolSection(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(swimmingPoolCheckbox.isDisplayed(), "Swimming Pool checkbox displayed");

        String expectedSwimmingCheckboxLabel = "It has a swimming pool.";
        fsa.assertEquals(getTextFromElement(swimmingPoolCheckboxLabel), expectedSwimmingCheckboxLabel, "Swimming checkbox label verification.");

        checkUncheckMatCheckbox(SWIMMING_POOL_CHECKBOX_XPATH, true);
        sleep(3);
        fsa.assertTrue(getAttributeData(swimmingPoolCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Swimming pool checkbox checked.");
        fsa.assertEquals(getTextFromElement(pleaseSpecifyLabelSwimmingPool), expectedPleaseSpecifyHeaderText, "Please specify header verification for swimming pool.");
        fsa.assertEquals(fencedUnfencedSwimmingPoolRadioButtons.size(), 2, "Radio button size verification for swimming pool section.");
        List<PWElement> checkedRadioButtonSize = checkedRadioButton(fencedUnfencedSwimmingPoolRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.isEmpty(), "Fence or unfenced swimming pool radio buttons initially unchecked.");

        String expectedFencedPoolLabel = "The pool is fenced";
        fsa.assertEquals(getTextFromElement(fencedUnfencedSwimmingPoolRadioButtons.get(0)), expectedFencedPoolLabel, "Fenced pool text verification.");

        String expectedUnFencedPoolLabel = "The pool is unfenced";
        fsa.assertEquals(getTextFromElement(fencedUnfencedSwimmingPoolRadioButtons.get(1)), expectedUnFencedPoolLabel, "UnFenced pool text verification.");

        checkUncheckMatCheckbox(SWIMMING_POOL_RADIO_XPATH, true);
        checkUncheckMatRadiobutton(SWIMMING_POOL_RADIO_XPATH + "[1]", true);
        checkedRadioButtonSize = checkedRadioButton(fencedUnfencedSwimmingPoolRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.size() == 1, "fence or unfenced swimming pool radio button is already checked.");

        checkUncheckMatRadiobutton(SWIMMING_POOL_RADIO_XPATH + "[2]", true);
        checkedRadioButtonSize = checkedRadioButton(fencedUnfencedSwimmingPoolRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.size() == 1, "fence or unfenced swimming pool radio button is already checked.");
        checkUncheckMatCheckbox(SWIMMING_POOL_RADIO_XPATH, false);
    }

    public void validateContentOfSolarPanelSection(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(solarPanelCheckbox.isDisplayed(), "Solar panel checkbox displayed");

        String expectedSolarPanelCheckboxLabel = "It has solar panels.";
        fsa.assertEquals(getTextFromElement(solarPanelCheckboxLabel), expectedSolarPanelCheckboxLabel, "Solar panel label verification.");

        checkUncheckMatCheckbox(SOLAR_CHECKBOX_XPATH, true);
        fsa.assertTrue(getAttributeData(solarPanelCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Solar panel checkbox checked.");
        checkUncheckMatCheckbox(SOLAR_CHECKBOX_XPATH, false);
        fsa.assertTrue(!getAttributeData(solarPanelCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Solar panel checkbox unchecked.");

    }

    public void validateContentOfULRoof(FarmersSoftAssert fsa) throws Exception {
        String snackBarULDiscountAdded = "We've added the UL roof discount!";
        String snackBarULDiscountRemoved = "UL roof discount has been removed.";

        String roofCoverType = getSessionStorageAppStore().getHome().getPropertyDetailsForm()
                .getFields().stream().filter(i -> i.getFieldName().equals("roofCover")).findFirst()
                .map(f -> f.getValues().get(0).getWebDesc())
                .orElse(EMPTY_STRING);
        if (List.of(ARCHITECTURAL_SHINGLE, THREE_TAB_SHINGLE, IMPACT_RESISTANT_SHINGLE).contains(roofCoverType)) {
            fsa.assertTrue(isElementDisplayed(ulRoofMatCheckbox,5), "UL Roof checkbox displayed");
            String expectedUlRoofCheckboxLabel = "UL (Underwriters Laboratories) certified hail-resistant roof";
            fsa.assertEquals(getTextFromElement(ulRoofCheckboxLabel), expectedUlRoofCheckboxLabel, "UL roof checkbox label verification.");

            checkUncheckMatCheckbox(UL_ROOF_CHECKBOX_XPATH, true);
            fsa.assertTrue(getAttributeData(ulRoofMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "UL roof checkbox checked.");

            fsa.assertEquals(getTextFromElement(ulRoofDescriptionLabel), expectedULRoofLabel, "Header text verification for UL Roof.");
            fsa.assertEquals(ulRoofRadioButtonLabels.size(), 3, "Radio button size verification for UL roof section.");

            List<PWElement> checkedRadioButtonSize = checkedRadioButton(ulRoofMatRadioButtons);
            fsa.assertTrue(checkedRadioButtonSize.isEmpty(), "UL roof radio buttons unchecked on initial load.");

            String expectedUlClass3Label = "UL Class 3";
            fsa.assertEquals(getTextFromElement(ulRoofRadioButtonLabels.get(0)), expectedUlClass3Label, "UL Class 3 text verification.");
            waitSnackBarMessageInvisible(8);
            waitAndClickElement(ulRoofRadioButtonLabels.get(0), 3);
            fsa.assertTrue(isSnackBarMessageDisplayed(snackBarULDiscountAdded), "UL Roof discount added message displayed.");
            waitSnackBarMessageInvisible(8);
            checkedRadioButtonSize = checkedRadioButton(ulRoofMatRadioButtons);
            fsa.assertEquals(checkedRadioButtonSize.size(), 1, "UL Class 3 radio button checked for UL roof.");

            String expectedUlClass1Or2Label = "UL Class 1, 2, or not certified";
            fsa.assertEquals(getTextFromElement(ulRoofRadioButtonLabels.get(2)), expectedUlClass1Or2Label, "UL Class 1,2 text verification.");
            waitAndClickElement(ulRoofRadioButtonLabels.get(2), 3);
            fsa.assertTrue(isSnackBarMessageDisplayed(snackBarULDiscountRemoved), "UL Roof discount removed message displayed.");
            waitSnackBarMessageInvisible(8);
            checkedRadioButtonSize = checkedRadioButton(ulRoofMatRadioButtons);
            fsa.assertEquals(checkedRadioButtonSize.size(), 1, "UL Class 1,2 radio button checked for UL roof.");

            String expectedUlClass4Label = "UL Class 4";
            fsa.assertEquals(getTextFromElement(ulRoofRadioButtonLabels.get(1)), expectedUlClass4Label, "UL Class 4 text verification.");
            waitAndClickElement(ulRoofRadioButtonLabels.get(1), 3);
            fsa.assertTrue(isSnackBarMessageDisplayed(snackBarULDiscountAdded), "UL Roof discount added message displayed.");
            waitSnackBarMessageInvisible(8);
            checkedRadioButtonSize = checkedRadioButton(ulRoofMatRadioButtons);
            fsa.assertEquals(checkedRadioButtonSize.size(), 1, "UL Class 4 radio button checked for UL roof.");
            checkUncheckMatCheckbox(UL_ROOF_CHECKBOX_XPATH, false);
            waitSnackBarMessageInvisible(8);
        } else {
            fsa.assertFalse(isElementDisplayed(ulRoofMatCheckbox, 5), "UL Roof checkbox displayed");
        }

    }

    public void validateContentOfTrampolineSection(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(trampolineCheckbox.isDisplayed(), "Trampoline checkbox displayed");
        String trampolineQuestion = getSessionStorageAppStore().getHome().getPropertyDetailsForm().getFieldValueByName("trampolineQuestion");
        if (trampolineQuestion != null) {
            fsa.assertEquals(getAttributeData(trampolineCheckbox, CLASS).contains(CHECKBOX_CHECKED), trampolineQuestion.equals(YES), "Trampoline checkbox (un)checked on initial load.");
        }

        String expectedTrampolineCheckboxLabel = "It has a trampoline.";
        fsa.assertEquals(getTextFromElement(trampolineCheckboxLabel), expectedTrampolineCheckboxLabel, "Trampoline checkbox label verification.");

        checkUncheckMatCheckbox(TRAMPOLINE_CHECKBOX_XPATH, true);
        fsa.assertTrue(getAttributeData(trampolineCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Trampoline checkbox checked.");

        fsa.assertEquals(getTextFromElement(pleaseSpecifyLabelTrampoline), expectedPleaseSpecifyHeaderText, "Please specify header verification for Trampoline.");
        fsa.assertEquals(fencedUnfencedTrampolineRadioButtons.size(), 2, "Number of radio buttons in the trampoline section.");

        List<PWElement> checkedRadioButtons = checkedRadioButton(fencedUnfencedTrampolineRadioButtons);
        fsa.assertEquals(checkedRadioButtons.size(), 0, "No fenced/unfenced trampoline radio button is checked.");
        String expectedFencedPoolLabel = "The trampoline is fenced";
        fsa.assertEquals(getTextFromElement(fencedUnfencedTrampolineRadioButtons.get(0)), expectedFencedPoolLabel, "Fenced trampoline text verification.");

        String expectedUnFencedPoolLabel = "The trampoline is unfenced";
        fsa.assertEquals(getTextFromElement(fencedUnfencedTrampolineRadioButtons.get(1)), expectedUnFencedPoolLabel, "UnFenced trampoline text verification.");

        scrollToElement(fencedUnfencedTrampolineRadioButtons.get(0));
        checkUncheckMatRadiobutton(TRAMPOLINE_RADIO_XPATH + "[1]", true);
        checkedRadioButtons = checkedRadioButton(fencedUnfencedTrampolineRadioButtons);
        fsa.assertEquals(checkedRadioButtons.size(), 1, "Fence or unfenced trampoline radio button #1 is checked.");

        checkUncheckMatRadiobutton(TRAMPOLINE_RADIO_XPATH + "[2]", true);
        checkedRadioButtons = checkedRadioButton(fencedUnfencedTrampolineRadioButtons);
        fsa.assertEquals(checkedRadioButtons.size(), 1, "fence or unfenced trampoline radio button #2 is checked.");
        checkUncheckMatCheckbox(TRAMPOLINE_CHECKBOX_XPATH, false);
    }

    public void validateContentOfStormShutterSection(FarmersSoftAssert fsa, String stateCode) throws Exception {
        if (isStormShuttersEnabledState(stateCode)) {
            fsa.assertTrue(stormShutterCheckbox.isDisplayed(), "Storm shutter checkbox displayed");
            fsa.assertTrue(!getAttributeData(stormShutterCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Storm shutter checkbox unchecked on initial load.");

            String expectedStormShutterCheckBoxCheckboxLabel = "It has permanently installed storm shutters on all windows in the dwelling.";
            fsa.assertEquals(getTextFromElement(stormShutterCheckboxLabel), expectedStormShutterCheckBoxCheckboxLabel, "Storm shutter checkbox label verification.");

            checkUncheckMatCheckbox(STORM_SHUTTER_CHECKBOX_XPATH, true);
            fsa.assertTrue(getAttributeData(stormShutterCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Storm shutter checkbox checked.");
            checkUncheckMatCheckbox(STORM_SHUTTER_CHECKBOX_XPATH, false);
            fsa.assertTrue(!getAttributeData(stormShutterCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Storm shutter checkbox unchecked.");
        }
    }

    public void validateOilTankOnPremisesGlassSection(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(oilTankOnPremisesMatCheckbox.isDisplayed(), "Oil Tank on Premises checkbox displayed");
        fsa.assertTrue(!getAttributeData(oilTankOnPremisesMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Oil Tank on Premises checkbox unchecked on initial load.");

        String expectedImpactResistantCheckboxLabel = "It has an oil tank on the premises.";
        fsa.assertEquals(getTextFromElement(oilTankOnPremisesCheckboxLabel), expectedImpactResistantCheckboxLabel, "Oil Tank on Premises label verification.");

        checkUncheckMatCheckbox(OIL_TANK_ON_PREMISES_CHECKBOX_XPATH, true);
        fsa.assertTrue(getAttributeData(oilTankOnPremisesMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Oil Tank on Premises checkbox checked.");
    }

    public void validateDiscountHeadingAndDivider(FarmersSoftAssert fsa) {
        fsa.assertTrue(isElementDisplayed(matDividerDiscountSection, 3), "Mat dividers displayed.");
        String expectedAdditionalDiscountHeader = "Select additional discounts you may qualify for:";
        fsa.assertEquals(getTextFromElement(additionalDiscountHeader), expectedAdditionalDiscountHeader, "Additional discount header verification.");
    }

    public void validateContentOfFireAlarmSection(FarmersSoftAssert fsa) throws Exception {
        scrollToElement(fireAlarmMatCheckbox);
        fsa.assertTrue(fireAlarmMatCheckbox.isDisplayed(), "Fire alarm checkbox displayed");

        String expectedFireAlarmCheckboxLabel = "Fire alarm";
        fsa.assertEquals(getTextFromElement(fireAlarmCheckboxLabel), expectedFireAlarmCheckboxLabel, "Fire alarm checkbox label verification.");
        waitSnackBarMessageInvisible(8);
        checkUncheckMatCheckbox(FIRE_ALARM_CHECKBOX_XPATH, true);
        fsa.assertTrue(getAttributeData(fireAlarmMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Fire alarm checkbox checked.");

        waitSnackBarMessageInvisible(8);
        scrollAndClickOnHiddenElement(fireAlarmRadioButtons.get(0));
        String expectedSnackBarText = "Safety counts! Added the fire protection discount!";
        fsa.assertTrue(isSnackBarMessageDisplayed(expectedSnackBarText), "Fire protection added message displayed.");

        waitSnackBarMessageInvisible(8);
        checkUncheckMatCheckbox(FIRE_ALARM_CHECKBOX_XPATH, false);

        String fireDiscountRemoveText = "Fire protection discount removed.";
        fsa.assertTrue(!getAttributeData(fireAlarmMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Fire alarm checkbox unchecked.");
        fsa.assertTrue(isSnackBarMessageDisplayed(fireDiscountRemoveText), "Fire protection removed message displayed.");
        waitSnackBarMessageInvisible(8);
        checkUncheckMatCheckbox(FIRE_ALARM_CHECKBOX_XPATH, true);
        fsa.assertEquals(getTextFromElement(fireAlarmPleaseSpecifyLabel), expectedPleaseSpecifyHeaderText, "Please specify header verification for fire alarm.");
        fsa.assertEquals(fireAlarmRadioButtons.size(), 3, "Radio button size verification for fire alarm section.");

        fsa.assertEquals(getTextFromElement(fireAlarmMatRadioButtons.get(0)), expectedUnMonitoredLabel, "unmonitored radio button label text verification for fire alarm.");
        fsa.assertEquals(getTextFromElement(fireAlarmMatRadioButtons.get(1)), expectedSelfMonitoredLabel, "Self monitored radio button label text verification for fire alarm.");
        fsa.assertEquals(getTextFromElement(fireAlarmMatRadioButtons.get(2)), expectedProfessionallyMonitoredLabel, "Professionally monitored radio button label text verification for fire alarm.");

        fsa.assertEquals(getTextFromElement(fireAlarmRadioButtonsSubtext.get(0)), expectedUnMonitoredSubtextLabel, "unmonitored radio button label text verification for fire alarm.");
        fsa.assertEquals(getTextFromElement(fireAlarmRadioButtonsSubtext.get(1)), expectedSelfMonitoredSubtextLabel, "Self monitored radio button label text verification for fire alarm.");
        String expectedProfessionallyMonitoredSubtextLabel = "Alerts a security company or the fire department";
        fsa.assertEquals(getTextFromElement(fireAlarmRadioButtonsSubtext.get(2)), expectedProfessionallyMonitoredSubtextLabel, "Professionally monitored radio button label text verification for fire alarm.");

        List<PWElement> checkedRadioButtonSize = checkedRadioButton(fireAlarmMatRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.isEmpty(), "No Fire alarm radio buttons checked on initial load for fire alarm.");

        scrollAndClickOnHiddenElement(fireAlarmRadioButtons.get(0));
        checkedRadioButtonSize = checkedRadioButton(fireAlarmMatRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.size() == 1, "Unmonitored radio button checked for fire alarm.");

        scrollAndClickOnHiddenElement(fireAlarmRadioButtons.get(1));
        checkedRadioButtonSize = checkedRadioButton(fireAlarmMatRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.size() == 1, "Self-monitored radio button checked for fire alarm.");

        scrollAndClickOnHiddenElement(fireAlarmRadioButtons.get(2));
        checkedRadioButtonSize = checkedRadioButton(fireAlarmMatRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.size() == 1, "Professionally monitored radio button checked.");
        checkUncheckMatCheckbox(FIRE_ALARM_CHECKBOX_XPATH, false);
    }

	public void validateContentOfFireProtectionSection(FarmersSoftAssert fsa) throws Exception {
        checkUncheckMatCheckbox(FIRE_PROTECTION_CHECKBOX_XPATH, true);
        fsa.assertTrue(smokeAlarmsToggleButtonYes.isDisplayed(), "Smoke alarms toggle button Yes is displayed");
        fsa.assertTrue(smokeAlarmsToggleButtonNo.isDisplayed(), "Smoke alarms toggle button No is displayed");
        fsa.assertTrue(sprinklerSystemsToggleButtonYes.isDisplayed(), "Sprinkler systems toggle button Yes is displayed");
        fsa.assertTrue(sprinklerSystemsToggleButtonNo.isDisplayed(), "Sprinkler systems toggle button No is displayed");
    }

    public void validateContentOfBurglarAlarmSection(FarmersSoftAssert fsa) throws Exception {
        scrollToElement(burglarAlarmMatCheckbox);
        fsa.assertTrue(burglarAlarmMatCheckbox.isDisplayed(), "Burglar alarm checkbox displayed");

        String expectedBurglarAlarmCheckboxLabel = "Burglar alarm";
        fsa.assertEquals(getTextFromElement(burglarAlarmCheckboxLabel), expectedBurglarAlarmCheckboxLabel, "Burglar alarm checkbox label verification.");
        waitSnackBarMessageInvisible(8);
        checkUncheckMatCheckbox(BURGLAR_ALARM_CHECKBOX_XPATH, true);
        fsa.assertTrue(getAttributeData(discountMatCheckbox.get(1), CLASS).contains(CHECKBOX_CHECKED), "Burglar alarm checkbox checked.");
        waitSnackBarMessageInvisible(8);
        scrollAndClickOnHiddenElement(burglarAlarmRadioButtonsInput.get(0));
        String expectedAddedTheftProtectionDiscountMessageText = "Congrats! We added a theft protection discount.";
        fsa.assertTrue(isSnackBarMessageDisplayed(expectedAddedTheftProtectionDiscountMessageText), "Theft protection added message displayed.");
        waitSnackBarMessageInvisible(8);
        checkUncheckMatCheckbox(BURGLAR_ALARM_CHECKBOX_XPATH, false);

        String theftProtectionRemoveMessageText = "Theft protection discount has been removed.";
        fsa.assertTrue(!getAttributeData(discountMatCheckbox.get(1), CLASS).contains(CHECKBOX_CHECKED), "Burglar alarm checkbox unchecked.");
        fsa.assertTrue(isSnackBarMessageDisplayed(theftProtectionRemoveMessageText), "Theft protection removed message displayed.");

        checkUncheckMatCheckbox(BURGLAR_ALARM_CHECKBOX_XPATH, true);
        fsa.assertEquals(getTextFromElement(pleaseSpecifyLabelDiscounts.get(0)), expectedPleaseSpecifyHeaderText, "Please specify header verification for burglar alarm.");
        fsa.assertEquals(burglarAlarmRadioButtonsInput.size(), 3, "Radio button size verification for burglar alarm section.");


        fsa.assertEquals(getTextFromElement(burglarAlarmMatRadioButtons.get(0)), expectedUnMonitoredLabel, "unmonitored radio button label text verification for burglar alarm.");
        fsa.assertEquals(getTextFromElement(burglarAlarmMatRadioButtons.get(1)), expectedSelfMonitoredLabel, "Self monitored radio button label text verification for burglar alarm.");
        fsa.assertEquals(getTextFromElement(burglarAlarmMatRadioButtons.get(2)), expectedProfessionallyMonitoredLabel, "Professionally monitored radio button label text verification for burglar alarm.");
        fsa.assertEquals(getTextFromElement(burglarAlarmRadioButtonsSubtext.get(0)), expectedUnMonitoredSubtextLabel, "unmonitored radio button label sub text verification for burglar alarm.");
        fsa.assertEquals(getTextFromElement(burglarAlarmRadioButtonsSubtext.get(1)), expectedSelfMonitoredSubtextLabel, "Self monitored radio button label sub text verification for burglar alarm.");
        String expectedProfessionallyMonitoredSubtextLabel = "Alerts a security company or the police department";
        fsa.assertEquals(getTextFromElement(burglarAlarmRadioButtonsSubtext.get(2)), expectedProfessionallyMonitoredSubtextLabel, "Professionally monitored radio button label sub text verification for burglar alarm.");

        List<PWElement> checkedRadioButtonSize = checkedRadioButton(burglarAlarmMatRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.isEmpty(), "Burglar alarm radio buttons uncheckeded on initial load.");

        scrollAndClickOnHiddenElement(burglarAlarmRadioButtonsInput.get(0));
        checkedRadioButtonSize = checkedRadioButton(burglarAlarmMatRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.size() == 1, "Unmonitored radio button checked for burglar alarm.");

        scrollAndClickOnHiddenElement(burglarAlarmRadioButtonsInput.get(1));
        checkedRadioButtonSize = checkedRadioButton(burglarAlarmMatRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.size() == 1, "Self-monitored radio button checked for burglar alarm.");

        scrollAndClickOnHiddenElement(burglarAlarmRadioButtonsInput.get(1));
        checkedRadioButtonSize = checkedRadioButton(burglarAlarmMatRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.size() == 1, "Professionally monitored radio button checked for burglar alarm.");
        checkUncheckMatCheckbox(BURGLAR_ALARM_CHECKBOX_XPATH, false);
    }

    public void validateContentOfWaterLeakProtectionSection(FarmersSoftAssert fsa) throws Exception {
        scrollToElement(waterProtectionMatCheckbox);
        fsa.assertTrue(waterProtectionMatCheckbox.isDisplayed(), "Water leak protection checkbox displayed");

        String expectedLeakProtectionCheckboxLabel = "Water leak protection";
        fsa.assertEquals(getTextFromElement(waterProtectionCheckboxLabel), expectedLeakProtectionCheckboxLabel, "Water protection checkbox label verification.");
        waitSnackBarMessageInvisible(8);
        checkUncheckMatCheckbox(WATER_PROTECTION_CHECKBOX_XPATH, true);
        fsa.assertTrue(getAttributeData(waterProtectionMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Water protection checkbox checked.");
        String expectedAddedWaterProtectionDiscountMessageText = "Congrats! We added a water protection discount.";
        waitSnackBarMessageInvisible(8);
        scrollAndClickOnHiddenElement(waterProtectionRadioButtons.get(0));
        fsa.assertTrue(isSnackBarMessageDisplayed(expectedAddedWaterProtectionDiscountMessageText), "Water protection added message displayed.");
        waitSnackBarMessageInvisible(8);

        checkUncheckMatCheckbox(WATER_PROTECTION_CHECKBOX_XPATH, false);
        String waterProtectionRemoveMessageText = "Water protection discount has been removed.";
        fsa.assertTrue(!getAttributeData(waterProtectionMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Water protection checkbox unchecked.");
        fsa.assertTrue(isSnackBarMessageDisplayed(waterProtectionRemoveMessageText), "Water protection removed message displayed.");
        waitSnackBarMessageInvisible(8);

        checkUncheckMatCheckbox(WATER_PROTECTION_CHECKBOX_XPATH, true);
        fsa.assertEquals(getTextFromElement(pleaseSpecifyLabelDiscounts.get(0)), expectedPleaseSpecifyHeaderText, "Please specify header verification for burglar alarm.");
        fsa.assertEquals(waterProtectionRadioButtons.size(), 3, "Radio button size verification for water protection section.");

        String expectedSinglePointLeakProtection = "Single point leak detection only";
        fsa.assertEquals(getTextFromElement(waterProtectionMatRadioButtons.get(0)), expectedSinglePointLeakProtection, "Single point leak detection only radio button label text verification for burglar alarm.");
        String expectedWholeHomeLeakProtection = "Whole home leak detection";
        fsa.assertEquals(getTextFromElement(waterProtectionMatRadioButtons.get(1)), expectedWholeHomeLeakProtection, "Whole home leak detection radio button label text verification for burglar alarm.");
        String expectedWithAutomaticWaterShutOff = "With automatic water shut-off";
        fsa.assertEquals(getTextFromElement(waterProtectionMatRadioButtons.get(2)), expectedWithAutomaticWaterShutOff, "Automatic water shut off radio button label text verification for burglar alarm.");
        List<PWElement> checkedRadioButtonSize = checkedRadioButton(waterProtectionMatRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.isEmpty(), "Water protection radio buttons unchecked on initial load.");

        scrollAndClickOnHiddenElement(waterProtectionRadioButtons.get(0));
        checkedRadioButtonSize = checkedRadioButton(waterProtectionMatRadioButtons);
        fsa.assertEquals(checkedRadioButtonSize.size(), 1, "Leak detection radio button checked for water protection.");

        scrollAndClickOnHiddenElement(waterProtectionRadioButtons.get(1));
        checkedRadioButtonSize = checkedRadioButton(waterProtectionMatRadioButtons);
        fsa.assertEquals(checkedRadioButtonSize.size(), 1, "With automatic water shut-off radio button checked for water protection.");
        checkUncheckMatCheckbox(WATER_PROTECTION_CHECKBOX_XPATH, false);
    }

    public void validateContentOfFortifiedHomeSection(FarmersSoftAssert fsa) throws Exception {
        scrollToElement(fortifiedHomeMatCheckbox);
        fsa.assertTrue(fortifiedHomeMatCheckbox.isDisplayed(), "Fortified home certification checkbox displayed");

        String expectedFortifiedHomeCheckboxLabel = "FORTIFIED Home certification";
        fsa.assertEquals(getTextFromElement(fortifiedHomeCheckboxLabel), expectedFortifiedHomeCheckboxLabel, "Fortified home certification checkbox label verification.");

        waitSnackBarMessageInvisible(8);
        checkUncheckMatCheckbox(FORTIFIED_HOME_CHECKBOX_XPATH, true);
        fsa.assertTrue(getAttributeData(fortifiedHomeMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Fortified home certification checkbox checked.");

        waitSnackBarMessageInvisible(8);
        waitElementBeVisibleClickable(fortifiedHomeCertRadioButton);
        scrollAndClickOnHiddenElement(fortifiedHomeCertRadioButtons.get(0));
        String expectedAddedFortifiedHomeDiscountMessageText = "Congrats -- We added a FORTIFIED Home discount!";
        fsa.assertTrue(isSnackBarMessageDisplayed(expectedAddedFortifiedHomeDiscountMessageText), "Fortified home certification added message displayed.");

        waitSnackBarMessageInvisible(8);
        checkUncheckMatCheckbox(FORTIFIED_HOME_CHECKBOX_XPATH, false);

        String fortifiedHomeCertificationRemoveMessageText = "FORTIFIED home discount has been removed.";
        fsa.assertTrue(!getAttributeData(fortifiedHomeMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Fortified home certification checkbox unchecked.");
        fsa.assertTrue(isSnackBarMessageDisplayed(fortifiedHomeCertificationRemoveMessageText), "Fortified home certification removed message displayed.");

        checkUncheckMatCheckbox(FORTIFIED_HOME_CHECKBOX_XPATH, true);
        waitElementBeVisibleClickable(fortifiedHomeCertRadioButton);
        fsa.assertEquals(getTextFromElement(fortifiedHomePleaseSpecifyLabel), expectedPleaseSpecifyHeaderText, "Please specify header verification for Fortified home.");
        fsa.assertEquals(fortifiedHomeCertRadioButtons.size(), 3, "Radio button size verification for fortified home certification section.");
        fsa.assertEquals(getTextFromElement(fortifiedHomeCertMatRadioButtons.get(0)), expectedFortifiedRoofLabel, "Fortified roof radio button label text verification for fortified home certification.");
        fsa.assertEquals(getTextFromElement(fortifiedHomeCertMatRadioButtons.get(1)), expectedFortifiedSilverLabel, "Fortified silver radio button label text verification for fortified home certification.");
        fsa.assertEquals(getTextFromElement(fortifiedHomeCertMatRadioButtons.get(2)), expectedFortifiedGoldLabel, "Fortified gold radio button label text verification for fortified home certification.");

        List<PWElement> checkedRadioButtonSize = checkedRadioButton(fortifiedHomeCertMatRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.isEmpty(), "No Fortified home certification radio buttons checked on initial load.");

        scrollAndClickOnHiddenElement(fortifiedHomeCertRadioButtons.get(0));
        checkedRadioButtonSize = checkedRadioButton(fortifiedHomeCertMatRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.size() == 1, "Fortified roof radio button checked for water protection.");

        scrollAndClickOnHiddenElement(fortifiedHomeCertRadioButtons.get(1));
        checkedRadioButtonSize = checkedRadioButton(fortifiedHomeCertMatRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.size() == 1, "Fortified Silver radio button checked for burglar alarm.");

        scrollAndClickOnHiddenElement(fortifiedHomeCertRadioButtons.get(2));
        checkedRadioButtonSize = checkedRadioButton(fortifiedHomeCertMatRadioButtons);
        fsa.assertTrue(checkedRadioButtonSize.size() == 1, "Fortified Gold radio button checked for burglar alarm.");
        checkUncheckMatCheckbox(FORTIFIED_HOME_CHECKBOX_XPATH, false);
    }

    public void validateContentOfWroughtIronBarsSection(FarmersSoftAssert fsa) throws Exception {
        scrollToElement(wroughtIronBarsMatCheckbox);
        fsa.assertTrue(wroughtIronBarsMatCheckbox.isDisplayed(), "Wrought iron bar checkbox displayed");
        fsa.assertTrue(!getAttributeData(wroughtIronBarsMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Wrought iron bar checkbox unchecked on initial load.");
        String expectedWroughtIronBarsCheckboxLabel = "Wrought iron bars";
        fsa.assertEquals(getTextFromElement(wroughtIronBarsCheckboxLabel), expectedWroughtIronBarsCheckboxLabel, "Wrought iron bar label verification.");

        String expectedWroughtIronBarDiscountMessageText = "Safety counts! Added the Wrought iron bars discount!";
        waitSnackBarMessageInvisible(8);
        checkUncheckMatCheckbox(WROUGHT_IRON_BARS_CHECKBOX_XPATH, true);
        fsa.assertTrue(getAttributeData(wroughtIronBarsMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Wrought iron bar checkbox checked.");
        fsa.assertTrue(isSnackBarMessageDisplayed(expectedWroughtIronBarDiscountMessageText), "Wrought iron bar discount added message displayed.");

        waitSnackBarMessageInvisible(8);
        checkUncheckMatCheckbox(WROUGHT_IRON_BARS_CHECKBOX_XPATH, false);
        String expectedWroughtIronBarDiscountRemovedMessageText = "Wrought iron bars discount has been removed.";
        fsa.assertTrue(isSnackBarMessageDisplayed(expectedWroughtIronBarDiscountRemovedMessageText), "Wrought Iron Bars discount message removed displayed.");
    }

    public void validateContentOfHomeTransferDiscountSection(FarmersSoftAssert fsa) throws Exception {
        final String checkboxLabelText = "I've maintained continuous property insurance coverage for the past 6 months";
        final String checkboxSubtext = "Current insurer must be ACUITY, Allstate, American Family, or Travelers.";
        final String discountAdded = "Home transfer discount added!";
        final String discountRemoved = "Home transfer discount has been removed."; //"Home transfer discount discount has been removed."

        fsa.assertEquals(getTextFromElement(previousInsuranceCheckboxLabel), checkboxLabelText, "Previous insurance checkbox - label text matches");
        fsa.assertEquals(getTextFromElement(previousInsuranceCheckboxSubtext), checkboxSubtext, "Previous insurance checkbox - Subtext matches");

        checkUncheckMatCheckbox(PREVIOUS_INSURANCE_CHECKBOX_XPATH, true);
        waitElementBeVisible(previousInsuranceRadioButtons.get(0));

        fsa.assertEquals(getTextFromElement(homeTransferDiscountHeader), "Home transfer discount", "Home Transfer Discount - header text matches");
        fsa.assertEquals(getTextFromElement(homeTransferDiscountSubheader), "Please select your current insurance carrier:", "Home Transfer Discount - sub-header text matches");
        fsa.assertTrue(isElementVisible(homeTransferDiscountHeaderDivider, 3), "Home Transfer Discount - header divider is displayed.");
        fsa.assertTrue(isElementVisible(getHomeTransferDiscountButtonContainer, 3), "Home Transfer Discount - footer button container is displayed.");

        List<String> expectedInsurers = List.of("ACUITY", "Allstate", "American Family", "Travelers", "Other carrier");
        List<String> displayedInsurers = previousInsuranceRadioButtons.stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(expectedInsurers, displayedInsurers, "Home Transfer Discount radio-buttons with insurance carrier names displayed.");
        fsa.assertTrue(isElementVisible(buttonCancelHomeTransferDiscount, 3), "Home Transfer Discount - Cancel button displayed.");
        waitAndClickElement(previousInsuranceRadioButtons.get(0));
        String selectedCarrier = getTextFromElement(previousInsuranceRadioButtons.get(0));
        waitAndClickElement(buttonSaveHomeTransferDiscount);
        fsa.assertTrue(isSnackBarMessageDisplayed(discountAdded), discountAdded + " - snackBar message is displayed");
        fsa.assertEquals(getTextFromElement(homeDiscountSelected), selectedCarrier, "Home Transfer Discount - selected insurance carrier text is found.");

        waitAndClickElement(editHomeDiscountSelected);
        fsa.assertTrue(getAttributeData(previousInsuranceRadioButtons.get(0), CLASS).contains(RADIO_BUTTON_CHECKED), "Home Transfer Discount - radio button selected.");
        waitAndClickElement(buttonCancelHomeTransferDiscount);
        checkUncheckMatCheckbox(PREVIOUS_INSURANCE_CHECKBOX_XPATH, false);
        fsa.assertTrue(isSnackBarMessageDisplayed(discountRemoved), discountRemoved + " - snackBar message is displayed");
    }

    public void validateContentOfWildfireRiskReductionSection(FarmersSoftAssert fsa) throws Exception {
        final String checkboxLabelText = "Wildfire risk reduction";
        final String discountAdded = "Wildfire risk reduction discount has been added.";
        final String discountRemoved = "Wildfire risk reduction discount has been removed.";

        fsa.assertEquals(getTextFromElement(wildfireRiskReductionCheckboxLabel), checkboxLabelText, "Previous insurance checkbox - label text matches");

        checkUncheckMatCheckbox(WILDFIRE_RISK_REDUCTION_CHECKBOX_XPATH, true);
        waitElementBeVisible(wildfireRiskReductionMatCheckboxes.get(0));

        final String WFRR_HEADER_LABEL = "Please specify:";
        List<String> expectedCheckboxLabels = List.of("Home is located in a Firewise Community", "Home is located in a Fire Marshall Established Risk Reduction Community",
        "Home is IBHS Wildfire Prepared Home Designate");
        fsa.assertEquals(getTextFromElement(wildfireRiskReductionCheckboxesLabel), WFRR_HEADER_LABEL, "Wildfire risk reduction header label.");
        int numberOfCheckboxes = expectedCheckboxLabels.size();
        for (int i = 0; i < numberOfCheckboxes; i++) {
            waitSnackBarMessageInvisible(10);
            fsa.assertEquals(getTextFromElement(wildfireRiskReductionMatCheckboxes.get(i)), expectedCheckboxLabels.get(i), "Wildfire risk reduction checkbox label: " + (i + 1) + PERIOD);
            checkUncheckMatCheckbox(WILDFIRE_RISK_REDUCTION_CHECKBOXES_XPATH + "[" + (i+1) + "]", true);
            fsa.assertTrue(isSnackBarMessageDisplayed(discountAdded), discountAdded + " - snackBar message is displayed");
            waitSnackBarMessageInvisible(10);
            checkUncheckMatCheckbox(WILDFIRE_RISK_REDUCTION_CHECKBOXES_XPATH + "[" + (i+1) + "]", false);
            fsa.assertTrue(isSnackBarMessageDisplayed(discountRemoved), discountRemoved + " - snackBar message is displayed");
        }
        checkUncheckMatCheckbox(WILDFIRE_RISK_REDUCTION_CHECKBOX_XPATH, false);
    }

    public void validateContentOfElectricalPlumbingHvacSection(FarmersSoftAssert fsa, String stateCode) throws Exception {
        final String electricalCheckboxLabelText = "Electrical system updated";
        final String electricalCheckboxInfoText = "Dwelling has been completely rewired.";
        final String electricalYearInputLabelText = "Year electrical system updated";
        final String plumbingCheckboxLabelText = "Plumbing system updated";
        final String plumbingCheckboxInfoText = "All pipes and fixtures have been replumbed (with a static test certificate).";
        final String plumbingYearInputLabelText = "Year plumbing system updated";
        final String hvacCheckboxLabelText = "HVAC system updated";
        final String hvacCheckboxInfoText = "Heating and cooling systems have been completely replaced.";
        final String hvacYearInputLabelText = "Year HVAC system updated";
        final String electricalDiscountAdded = "Electrical system replacement discount has been added.";
        final String electricalDiscountRemoved = "Electrical system replacement discount has been removed.";
        final String plumbingDiscountAdded = "Plumbing system replacement discount has been added.";
        final String plumbingDiscountRemoved = "Plumbing system replacement discount has been removed.";
        final String hvacDiscountAdded = "HVAC replacement discount has been added.";
        final String hvacDiscountRemoved = "HVAC replacement discount has been removed.";

        fsa.assertEquals(getNodeText(electricalSystemCheckboxLabel), electricalCheckboxLabelText, "Electrical system updated checkbox - label text matches");
        fsa.assertEquals(getTextFromElement(electricalSystemCheckboxInfoText), electricalCheckboxInfoText, "Electrical system updated - info text matches");
        fsa.assertEquals(getNodeText(plumbingSystemCheckboxLabel), plumbingCheckboxLabelText, "Plumbing system updated checkbox - label text matches");
        fsa.assertEquals(getTextFromElement(plumbingSystemCheckboxInfoText), plumbingCheckboxInfoText, "Plumbing system updated - info text matches");
        fsa.assertEquals(getNodeText(hvacSystemCheckboxLabel), hvacCheckboxLabelText, "HVAC system updated checkbox - label text matches");
        fsa.assertEquals(getTextFromElement(hvacSystemCheckboxInfoText), hvacCheckboxInfoText, "HVAC system updated - info text matches");

        // added/removed electrical system replacement discount
        waitSnackBarMessageInvisible(10);
        checkUncheckMatCheckbox(ELECTRICAL_SYSTEM_UPDATED_CHECKBOX_XPATH, true);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(electricalSystemYearLabel)), electricalYearInputLabelText, "Electrical system updated - year input label matches");
        clickElement(electricalSystemYearInput);
        sendKeysToElement(electricalSystemYearInput, Year.now().getValue() - 5 + EMPTY_STRING);
        if (!stateCode.equals(MN)) {
            fsa.assertTrue(isSnackBarMessageDisplayed(electricalDiscountAdded), electricalDiscountAdded + " - snackBar message is displayed");
            waitSnackBarMessageInvisible(10);
        } else {
            fsa.assertFalse(isSnackBarMessageDisplayed(electricalDiscountAdded), electricalDiscountAdded + " - snackBar message is not displayed");
        }
        checkUncheckMatCheckbox(ELECTRICAL_SYSTEM_UPDATED_CHECKBOX_XPATH, false);
        if (!stateCode.equals(MN)) {
            fsa.assertTrue(isSnackBarMessageDisplayed(electricalDiscountRemoved), electricalDiscountRemoved + " - snackBar message is displayed");
            waitSnackBarMessageInvisible(10);
        } else {
            fsa.assertFalse(isSnackBarMessageDisplayed(electricalDiscountRemoved), electricalDiscountRemoved + " - snackBar message is not displayed");
        }

        // added/removed plumbing system replacement discount
        checkUncheckMatCheckbox(PLUMBING_SYSTEM_UPDATED_CHECKBOX_XPATH, true);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(plumbingSystemYearLabel)), plumbingYearInputLabelText, "Plumbing system updated checkbox - year input label matches");
        clickElement(plumbingSystemYearInput);
        sendKeysToElement(plumbingSystemYearInput, Year.now().getValue() - 5 + EMPTY_STRING);
        if (!stateCode.equals(MN)) {
            fsa.assertTrue(isSnackBarMessageDisplayed(plumbingDiscountAdded), plumbingDiscountAdded + " - snackBar message is displayed");
            waitSnackBarMessageInvisible(10);
        } else {
            fsa.assertFalse(isSnackBarMessageDisplayed(plumbingDiscountAdded), plumbingDiscountAdded + " - snackBar message is not displayed");
        }
        checkUncheckMatCheckbox(PLUMBING_SYSTEM_UPDATED_CHECKBOX_XPATH, false);
        if (!stateCode.equals(MN)) {
            fsa.assertTrue(isSnackBarMessageDisplayed(plumbingDiscountRemoved), plumbingDiscountRemoved + " - snackBar message is displayed");
            waitSnackBarMessageInvisible(10);
        } else {
            fsa.assertFalse(isSnackBarMessageDisplayed(plumbingDiscountRemoved), plumbingDiscountRemoved + " - snackBar message is not displayed");
        }

        // added/removed HVAC system replacement discount
        checkUncheckMatCheckbox(HVAC_SYSTEM_UPDATED_CHECKBOX_XPATH, true);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(hvacSystemYearLabel)), hvacYearInputLabelText, "HVAC system updated checkbox - year input label matches");
        clickElement(hvacSystemYearInput);
        sendKeysToElement(hvacSystemYearInput, Year.now().getValue() - 5 + EMPTY_STRING);
        if (!stateCode.equals(MN)) {
            fsa.assertTrue(isSnackBarMessageDisplayed(hvacDiscountAdded), hvacDiscountAdded + " - snackBar message is displayed");
            waitSnackBarMessageInvisible(10);
        } else {
            fsa.assertFalse(isSnackBarMessageDisplayed(hvacDiscountAdded), hvacDiscountAdded + " - snackBar message is not displayed");
        }
        checkUncheckMatCheckbox(HVAC_SYSTEM_UPDATED_CHECKBOX_XPATH, false);
        if (!stateCode.equals(MN)) {
            fsa.assertTrue(isSnackBarMessageDisplayed(hvacDiscountRemoved), hvacDiscountRemoved + " - snackBar message is displayed");
            waitSnackBarMessageInvisible(10);
        } else {
            fsa.assertFalse(isSnackBarMessageDisplayed(hvacDiscountRemoved), hvacDiscountRemoved + " - snackBar message is not displayed");
        }
    }

	public void validateAbsenseOfElectricalPlumbingHvacSection(FarmersSoftAssert fsa) {
		fsa.assertTrue(!isElementDisplayed(electricalSystemCheckboxLabel, 1), "Electrical system updated checkbox not present");
		fsa.assertTrue(!isElementDisplayed(electricalSystemCheckboxInfoText,1), "Electrical system updated info text not present");
		fsa.assertTrue(!isElementDisplayed(plumbingSystemCheckboxLabel, 1), "Plumbing system updated checkbox not present");
		fsa.assertTrue(!isElementDisplayed(plumbingSystemCheckboxInfoText, 1), "Plumbing system updated info text not present");
		fsa.assertTrue(!isElementDisplayed(hvacSystemCheckboxLabel, 1), "HVAC system updated checkbox not present");
		fsa.assertTrue(!isElementDisplayed(hvacSystemCheckboxInfoText,1 ), "HVAC system updated info text not present");
	}

    public void validateContentOfOtherHomeProtectionSection(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        String sectionCheckboxLabelText = "Other home protection and loss prevention features";
        String sectionStartLabelText = "Please select one (even if multiple options apply):";
        String sideSheetLinkLabel = "Tell me about these features";
        String snackBarDiscountAdded = "Home protection and loss prevention discount has been added.";
        String snackBarDiscountRemoved = "Home protection and loss prevention discount has been removed.";
        List<String> radioButtonsLabels = new ArrayList<>(List.of("Energy Star/EPA certified home", "FORTIFIED Home", "Connected home", "Automatic gas shut-off valve", "Whole house water leak detection"));
        String sideSheetTitle = "Loss prevention features";
        String sideSheetContentEPA = "An Energy Star/EPA Certified Home is a dwelling that has been independently verified to meet guidelines for energy efficiency set by the United States Environmental Protection agency. The dwelling has earned Energy Star/EPA certification.";
        String sideSheetContentFortifiedHome = "A Fortified Home is a dwelling that is constructed with added protection to resist natural disasters and extreme weather events such as high wind, wildfire, flood, hail, and earthquake. The home is certified to meet all requirements of a designation level of the IBHS FORTIFIED Home program.";
        String sideSheetContentConnectedHome = "Certificate of monitoring from a pre-approved vendor displaying an installed burglar and/or fire alarm. (If the date of installation was more than 6 months ago, we also require a monthly bill in the last 3 months.)";
        String sideSheetContentConnectedHomeMore = "ADT: Certificate of monitoring displaying an installed burglar and/or fire alarm Vivint: Certificate of installation displaying installation of \"Intrusion\", \"Emergency/Duress\", \"Sensor\", \"Camera\", \"Alarm\", or \"Lock\" equipment, and a copy of a monthly bill for service (depending on the date of installation)";
        String sideSheetContentAutomaticGas = "Automatic shut-off valves are professionally installed on all gas or propane lines into the home. The discount also applies to all-electric/all-solar homes with no external fuel lines.";
        String sideSheetContentWaterLeak = "A whole house water leak detection system shuts off the main water service when a water leak is detected. An automatic shut-off valve is installed on the main water service piping between the water meter and the first branch piping.";

        fsa.assertEquals(getTextFromElement(otherHomeProtectionFeaturesMatCheckbox), sectionCheckboxLabelText, "Other home protection section checkbox - label text matches");
        checkUncheckMatCheckbox(OTHER_HOME_PROTECTION_FEATURES_XPATH, true);
        waitElementBeVisible(otherHomeProtectionFeaturesRadioButtons.get(0));
        fsa.assertEquals(getTextFromElement(otherHomeProtectionSubtitleLabel), sectionStartLabelText, "Other home protection section sub-title - label text matches");
        fsa.assertEquals(getTextFromElement(otherHomeProtectionHelpSideSheetLink), sideSheetLinkLabel, "Other home protection section side-sheet link text matches");
        if (!applicant.getStateCode().equals(KS)) { // F98469: FFQ Home/eCheckout - PI40 Tweaks (AC3)
            radioButtonsLabels.remove("Connected home");
        }
        int radioButtonsCount = radioButtonsLabels.size();
        for (int i = 0; i < radioButtonsCount; i++) {
            fsa.assertEquals(getTextFromElement(otherHomeProtectionFeaturesRadioButtons.get(i)), radioButtonsLabels.get(i), "Other home protection section radio-button label: " + radioButtonsLabels.get(i));
        }
        int j = 0;
        waitAndClickElement(otherHomeProtectionHelpSideSheetLink);
        waitElementBeVisible(otherHomeProtectionHelpSideSheetTitle);
        fsa.assertEquals(getTextFromElement(otherHomeProtectionHelpSideSheetTitle), sideSheetTitle, "Other home protection section side-sheet title");
        fsa.assertEquals(getTextFromElement(otherHomeProtectionSideSheetEPASubTitle), radioButtonsLabels.get(j), "Other home protection section side-sheet EPA sub-title");
        fsa.assertEquals(getTextFromElement(otherHomeProtectionSideSheetEPAContent), sideSheetContentEPA, "Other home protection section side-sheet EPA content");
        j++;
        fsa.assertEquals(getTextFromElement(otherHomeProtectionSideSheetFortifiedHomeSubTitle), radioButtonsLabels.get(j), "Other home protection section side-sheet FORTIFIED Home sub-title");
        fsa.assertEquals(getTextFromElement(otherHomeProtectionSideSheetFortifiedHomeContent), sideSheetContentFortifiedHome, "Other home protection section side-sheet FORTIFIED Home content");
        j++;
        if (applicant.getStateCode().equals(KS)) {
            fsa.assertEquals(getTextFromElement(otherHomeProtectionSideSheetConnectedHomeSubTitle), radioButtonsLabels.get(j), "Other home protection section side-sheet Connected home sub-title");
            fsa.assertEquals(getTextFromElement(otherHomeProtectionSideSheetConnectedHomeContent), sideSheetContentConnectedHome, "Other home protection section side-sheet Connected home content");
            fsa.assertEquals(getTextFromElement(otherHomeProtectionSideSheetConnectedHomeContentMore), sideSheetContentConnectedHomeMore, "Other home protection section side-sheet Connected home content more");
            j++;
        }
        fsa.assertEquals(getTextFromElement(otherHomeProtectionSideSheetAutomaticGasSubTitle), radioButtonsLabels.get(j), "Other home protection section side-sheet Automatic gas sub-title");
        fsa.assertEquals(getTextFromElement(otherHomeProtectionSideSheetAutomaticGasContent), sideSheetContentAutomaticGas, "Other home protection section side-sheet Automatic gas content");
        j++;
        fsa.assertEquals(getTextFromElement(otherHomeProtectionSideSheetWaterLeakSubTitle), radioButtonsLabels.get(j), "Other home protection section side-sheet Water leak sub-title");
        fsa.assertEquals(getTextFromElement(otherHomeProtectionSideSheetWaterLeakContent), sideSheetContentWaterLeak, "Other home protection section side-sheet Water leak content");
        waitAndClickElement(otherHomeProtectionSideSheetCloseButton);
        waitAndClickElement(otherHomeProtectionFeaturesRadioButtons.get(2));
        fsa.assertTrue(isSnackBarMessageDisplayed(snackBarDiscountAdded), "Other home protection feature discount added");
        waitSnackBarMessageInvisible(8);
        checkUncheckMatCheckbox(OTHER_HOME_PROTECTION_FEATURES_XPATH, false);
        fsa.assertTrue(isSnackBarMessageDisplayed(snackBarDiscountRemoved), "Other home protection feature discount removed");
        waitSnackBarMessageInvisible(8);
    }

    public boolean isTemporaryRentalsCheckboxChecked() {
        return getAttributeData(temporaryRentalMatCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }
    public boolean isFireProtectionSystemCheckboxChecked() {
        return getAttributeData(fireProtectionSystemsCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public boolean isSwimmingPoolCheckboxChecked() {
        return getAttributeData(swimmingPoolCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public boolean isSolarPanelsCheckboxChecked() {
        return getAttributeData(solarPanelCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public boolean isTrampolineCheckboxChecked() {
        return getAttributeData(trampolineCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public boolean isFireAlarmCheckboxChecked() {
        return getAttributeData(fireAlarmMatCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public boolean isBurglarAlarmCheckboxChecked() {
        return getAttributeData(burglarAlarmMatCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public boolean isWaterProtectionCheckboxChecked() {
        return getAttributeData(waterProtectionMatCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public boolean isFortifiedHomeCheckboxChecked() {
        return getAttributeData(fortifiedHomeMatCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public boolean isOtherHomeProtectionFeaturesCheckboxChecked() {
        return getAttributeData(otherHomeProtectionFeaturesMatCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public boolean isNonSmokerCheckboxChecked() {
        return getAttributeData(nonSmokerMatCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public boolean isCentralFireAlarmCheckboxChecked() {
        return getAttributeData(centralFireAlarmMatCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public boolean isCentralBurglarAlarmCheckboxChecked() {
        return getAttributeData(centralBurglarAlarmMatCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public boolean isWroughtFortifiedHomeCheckboxChecked() {
        return getAttributeData(wroughtIronBarsMatCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public String getSelectedSwimmingPoolOption() {
        return fencedUnfencedSwimmingPoolRadioButtons.stream().filter(i -> getAttributeData(i,CLASS).contains(RADIO_BUTTON_CHECKED)).findFirst().map(this::getTextFromElement).orElse(null);
    }

    public String getSelectedTrampolineOption() {
        return fencedUnfencedTrampolineRadioButtons.stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).findFirst().map(this::getTextFromElement).orElse(null);
    }

    public String getRoofYearPrefilledByNearMap() {
        String roofReplacedYear = EMPTY_STRING;
        if (isElementVisible(roofReplacedYearText, 5)) {
            roofReplacedYear = getTextFromElement(roofReplacedYearText);
            for (int i = 0; i < 5; i++) {
                if (roofReplacedYear.isBlank()) {
                    sleep(1);
                    roofReplacedYear = getTextFromElement(roofReplacedYearText);
                } else {
                    break;
                }
            }
        }
        return roofReplacedYear;
    }

    public String getRoofReplacedYear() {
        String roofReplacedYear = EMPTY_STRING;
        if (!isElementDisplayed(roofReplacedYearText, 2)) {
            if (isElementDisplayed(roofYearInputField, 2)) {
                roofReplacedYear = getValueFromWebElement(roofYearInputField);
            }
        } else { // roofReplacedYear provided by NearMap service
            roofReplacedYear = getRoofYearPrefilledByNearMap();
        }
        return roofReplacedYear;
    }

    public String getSelectedFireAlarmOption() {
        return fireAlarmMatRadioButtons.stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).findFirst().map(this::getTextFromElement).orElse(null);
    }

    public String getSelectedBurglarAlarmOption() {
        return burglarAlarmMatRadioButtons.stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).findFirst().map(this::getTextFromElement).orElse(null);
    }

    public String getSelectedWaterProtectionOption() {
        return waterProtectionMatRadioButtons.stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).findFirst().map(this::getTextFromElement).orElse(null);
    }

    public String getSelectedFortifiedHomeOption() {
        return fortifiedHomeCertMatRadioButtons.stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).findFirst().map(this::getTextFromElement).orElse(null);
    }

    public String getSelectedOtherHomeProtectionFeature() {
        return otherHomeProtectionFeaturesRadioButtons.stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).findFirst().map(this::getTextFromElement).orElse(null);
    }

    public List<PWElement> checkedRadioButton(List<PWElement> listOfCheckBoxesWebElement) {
        return listOfCheckBoxesWebElement.stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).collect(Collectors.toList());
    }

    public void validateAdditionalInfoPageErrors(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {
        waitElementBeVisibleClickable(matCheckBox);
        String yearBuilt = getSessionStorageAppStore().getHome().getPropertyForm().getFields().get(0).getYearBuilt();

        List<PWElement> checkboxes = driver().findElements(PWBy.xpath("//mat-checkbox[not(contains(@class,'" + CHECKBOX_CHECKED + "'))]//input"));
        for (PWElement checkbox : checkboxes) {
            scrollAndClickOnElement(checkbox);
        }
        clickContinueButton();

        int expectedErrorSize;
        switch (applicant.getStateCode()) {
            case IA: case IN: case MD: case MN: case MT: case OH: case WA: case NC:
                expectedErrorSize = 3;
                break;
            case KS: case MS:
                expectedErrorSize = 5;
                break;
            case OR:
                expectedErrorSize = 7;
                break;
            default:
                expectedErrorSize = 6;
                break;
        }
        fsa.assertEquals(pleaseSelectAnOptionErrors.size(), expectedErrorSize, "Please select an option error count verification.");

        if (isElementVisible(buttonCloseHomeTransferDiscount, 2)) {
            waitAndClickElement(buttonCloseHomeTransferDiscount);
        }
        if (isElementDisplayed(roofCompletelyReplacedYesButton, 2)) {
            clickOnYesToggleButtonForRoofYearSection();
            fsa.assertTrue(pleaseProvideTheYearError.isDisplayed(), "Please provide the year error displayed");
            waitAndClickElement(roofYearInputField);
            sendKeysOneByOne(roofYearInputField, "21");
            fsa.assertTrue(invalidYearError.isDisplayed(), "Invalid year error displayed.");
            int roofYear = Integer.parseInt(yearBuilt) - 1;
            sendKeysToElement(roofYearInputField, PWKeys.chord(String.valueOf(roofYear), PWKeys.TAB));
            String roofYearRangeErrorMessage = "Enter valid roof year";
            fsa.assertEquals(getTextFromElement(roofYearRangeError), roofYearRangeErrorMessage, roofYearRangeErrorMessage + " message displayed.");
            sendKeysToElement(roofYearInputField, PWKeys.chord(String.valueOf(LocalDate.now().plusYears(12)), PWKeys.TAB));
            fsa.assertEquals(getTextFromElement(roofYearRangeError), roofYearRangeErrorMessage, roofYearRangeErrorMessage + " message displayed.");
        }
    }

    public void fillOutAdditionalInfoPageHomeLob(ApplicantAceHome applicant , boolean continueButton) throws Exception {
        String stateCode = applicant.getStateCode();
        if (stateCode.equals(CA)) {
        	String yearBuilt = getSessionStorageAppStore().getHome().getPropertyForm().getFields().get(0).getYearBuilt();
            if (DateCalculations.ageFromYear(yearBuilt) > 40) {
                fillOutPlumbingSystemCA(applicant.getPlumbingUpdated());
            }
        }
        if (!isNoHomeShareState(stateCode)) {
        	fillOutTemporaryRentalInfo(applicant.isTemporaryRentals());
        }
        fillOutSwimmingPoolInfo(applicant.getSwimmingPool());
        fillOutSolarPanelInfo(applicant.isSolarPanels());
        fillOutTrampolineInfo(applicant.getTrampoline());
        fillOutRoofInfo(applicant);

        if (isStormShuttersEnabledState(stateCode)) {
        	fillOutStormShutters(applicant.isStormShutters());
        }
        if(isValidateWroughtIronBarSection(applicant)) {
            fillOutWroughtIronBarsInfo(applicant.isWroughtIronBars());
        }
        if (List.of(MS, NC).contains(stateCode)) {
            if (stateCode.equals(MS)) {
                fillOutFireSystemsInfo(applicant.getFireAlarm(), stateCode);
            } else {
                fillOutSmokeAlarms(applicant.getSmokeAlarm());
            }
        } else if (!isCentralFireAlarmState(stateCode)) {
            fillOutFireAlarmInfo(applicant.getFireAlarm());
        }
        // Other home protection
        if (isOtherHomeProtectionFeaturesState(stateCode)) {
            if (!applicant.getFortifiedHome().isBlank() || applicant.getWaterLeakProtection().contains("Whole home")) {
                fillOutOtherHomeProtectionFeatures();
            }
        } else {
            fillOutWaterLeakProtectionInfo(applicant.getWaterLeakProtection());
            if (applicant.getExpectedFortifiedHomeDesignation().isBlank()) {
                fillOutFortifiedHomeInfo(applicant.getFortifiedHome());
            } else {
                validatePopulatedDesignationVal(applicant.getExpectedFortifiedHomeDesignation());
                if (isElementDisplayed(fortifiedHomeCertRadioButton,2)) {
                    fillOutFortifiedHomeInfo(applicant.getFortifiedHome());
                }
            }
        }
        if (stateCode.equals(NC)) {
            fillOutAlarmSystemInfo(applicant.getAlarmSystem());
        } else if (isCentralBurglarAlarmState(stateCode)) {
        	fillOutCentralBurglarAlarm(applicant.isCentralBurglarAlarm());
        } else {
        	fillOutBurglarAlarmInfo(applicant.getBurglarAlarm());
        }
        fillOutPreviousInsurance(applicant.getPreviousInsurance());
        if (!stateCode.equals(CA)) {
            fillOutWildfireRiskReduction(applicant.getWildFireRisk());
        }
        if (isNonSmokerState(stateCode)) {
            fillOutNonSmoker(applicant.isNonSmoker());
        }
        if (isCentralFireAlarmState(stateCode)) {
            fillOutCentralFireAlarm(applicant.isCentralFireAlarm());
        }
        if (isUlRoofState(stateCode)) {
            String roofCoverType = getSessionStorageAppStore().getHome().getPropertyDetailsForm().getFields().stream().filter(i -> i.getFieldName().equals("roofCover")).findFirst()
                    .map(f -> f.getValues().get(0).getWebDesc())
                    .orElse(EMPTY_STRING);
            if (List.of(ARCHITECTURAL_SHINGLE, THREE_TAB_SHINGLE, IMPACT_RESISTANT_SHINGLE).contains(roofCoverType)) {
                fillOutUlRoofInfo(applicant.getUlRoof());
            }
        }
        if (isElectricalPlumbingHvacState(stateCode)) {
            fillOutElectricalSystem(applicant.getElectricalUpdated());
            if (LocalDate.now().getYear() - applicant.getYearBuilt() > 20){
                String plumbingSystemYear = (applicant.getPlumbingUpdated().isBlank()) ?
                        String.valueOf(LocalDate.now().minusYears(5).getYear()) : applicant.getPlumbingUpdated();
                plumbingSystemYear = plumbingSystemYear.equalsIgnoreCase(I_AM_NOT_SURE) ? plumbingSystemYear : String.valueOf(Math.max(applicant.getYearBuilt() + 1, Integer.parseInt(plumbingSystemYear)));
                fillOutPlumbingSystem(plumbingSystemYear);
                applicant.setPlumbingUpdated(plumbingSystemYear);
            }
            fillOutHvacSystem(applicant.getHvacUpdated());
        }
        if(continueButton) {
        	clickContinueButton();
            waitForSpinnerToBeGone();
        }
    }

    private void fillOutAlarmSystemInfo(String alarmSystem) {
        if (!alarmSystem.isBlank()) {
            scrollToElement(alarmSystemMatCheckbox);
            waitAndClickElement(alarmSystemCheckboxLabel);
            switch (alarmSystem.trim()) {
                case "Local":
                    waitAndClickElement(localAlarmButtonYes);
                    waitAndClickElement(centralAlarmButtonNo);
                    waitAndClickElement(directSystemsButtonNo);
                    break;
                case "Central":
                    waitAndClickElement(localAlarmButtonNo);
                    waitAndClickElement(centralAlarmButtonYes);
                    waitAndClickElement(directSystemsButtonNo);
                    break;
                case "Direct":
                    waitAndClickElement(localAlarmButtonNo);
                    waitAndClickElement(centralAlarmButtonNo);
                    waitAndClickElement(directSystemsButtonYes);
                    break;
                default:
                    Log.error("Incorrect Alarm System label: [" + alarmSystem + "]");
            }
        }
    }

    public void fillOutTemporaryRentalInfo(boolean isTemporaryRentals) throws Exception {
        if (isElementDisplayed(PWBy.xpath(TEMPORARY_RENTAL_CHECKBOX_XPATH))) {
            checkUncheckMatCheckbox(TEMPORARY_RENTAL_CHECKBOX_XPATH, isTemporaryRentals);
        }
    }

    public void fillOutSwimmingPoolInfo(String swimmingPoolValue) throws Exception {
        if (!swimmingPoolValue.isBlank()) {
            checkUncheckMatCheckbox(SWIMMING_POOL_CHECKBOX_XPATH, true);
            waitElementBeVisibleClickable(fencedUnfencedSwimmingPoolRadioButton);
            if (swimmingPoolValue.equals("fenced")) {
                checkUncheckMatRadiobutton(SWIMMING_POOL_RADIO_XPATH + "[1]", true);
            } else {
                checkUncheckMatRadiobutton(SWIMMING_POOL_RADIO_XPATH + "[2]", true);
            }
        } else {
            if (isElementDisplayed(PWBy.xpath(SWIMMING_POOL_CHECKBOX_XPATH))) {
                checkUncheckMatCheckbox(SWIMMING_POOL_CHECKBOX_XPATH, false);
            }
        }
    }

    public void fillOutSolarPanelInfo(boolean isSolarPanelAvailable) throws Exception {
        if (isElementDisplayed(PWBy.xpath(SOLAR_CHECKBOX_XPATH))) {
            checkUncheckMatCheckbox(SOLAR_CHECKBOX_XPATH, isSolarPanelAvailable);
        }
    }

    public void fillOutTrampolineInfo(String trampolineValue) throws Exception {
        if (!trampolineValue.isBlank()) {
            checkUncheckMatCheckbox(TRAMPOLINE_CHECKBOX_XPATH, true);
            waitElementBeVisibleClickable(fencedUnfencedTrampolineRadioButton);
            if (trampolineValue.trim().equals("fenced")) {
                checkUncheckMatRadiobutton(TRAMPOLINE_RADIO_XPATH + "[1]", true);
            } else {
                checkUncheckMatRadiobutton(TRAMPOLINE_RADIO_XPATH + "[2]", true);
            }
        } else {
            if (isElementDisplayed(PWBy.xpath(TRAMPOLINE_CHECKBOX_XPATH))) {
                checkUncheckMatCheckbox(TRAMPOLINE_CHECKBOX_XPATH, false);
            }
        }
    }

    public void fillOutRoofInfo(ApplicantAceHome applicant) throws Exception {
        String yearBuilt = getSessionStorageAppStore().getHome().getPropertyForm().getFields().get(0).getYearBuilt();
        if ((LocalDate.now().getYear() - Integer.parseInt(yearBuilt)) < 10) {
            return;
        }
        String roofYearReplaced;
        if (isElementDisplayed(roofCompletelyReplacedYesButton, 2)) {
            if (applicant.getRoofReplaced().equalsIgnoreCase(TRUE) || applicant.getRoofReplaced().matches("\\d{4}")) {
                roofYearReplaced = applicant.getRoofReplaced().equalsIgnoreCase(TRUE) ? String.valueOf(LocalDate.now().minusYears(2).getYear()) : applicant.getRoofReplaced();
                clickOnYesToggleButtonForRoofYearSection();
                clickElement(roofYearInputField);
                sendKeysToElement(roofYearInputField, roofYearReplaced);
                applicant.setRoofReplaced(roofYearReplaced);
            } else {
                clickOnNoToggleButtonForRoofYearSection();
            }
        } else { // F95728: PL - Near map Integration for Roof Age Prefill in FFQ Home Quotes
            String yearReplaced = getTextFromElement(roofReplacedYearText);
            applicant.setRoofReplaced(yearReplaced);
            if (applicant.getRoofReplaced().equals(TRUE) && (Integer.parseInt(yearReplaced) < LocalDate.now().minusYears(10).getYear())) {
                roofYearReplaced = String.valueOf(LocalDate.now().minusYears(3).getYear());
                waitAndClickElement(editRoofReplacedYearButton);
                waitAndClickElement(roofReplacedYearInput);
                sendKeysToElement(roofReplacedYearInput, roofYearReplaced);
                applicant.setRoofReplaced(roofYearReplaced);
            }
        }
    }

    public void fillOutFireAlarmInfo(String fireAlarmValue) throws Exception {
        if (!fireAlarmValue.isBlank()) {
            checkUncheckMatCheckbox(FIRE_ALARM_CHECKBOX_XPATH, true);
            waitElementBeVisibleClickable(fireAlarmRadioButton);
            if (fireAlarmValue.trim().equals(expectedUnMonitoredLabel)) {
                scrollAndClickOnHiddenElement(fireAlarmRadioButtons.get(0));
            } else if (fireAlarmValue.trim().equals(expectedSelfMonitoredLabel)) {
                scrollAndClickOnHiddenElement(fireAlarmRadioButtons.get(1));
            } else if (fireAlarmValue.trim().equals(expectedProfessionallyMonitoredLabel)) {
                scrollAndClickOnHiddenElement(fireAlarmRadioButtons.get(2));
            }
        } else {
            if (isElementDisplayed(PWBy.xpath(FIRE_ALARM_CHECKBOX_XPATH))) {
                checkUncheckMatCheckbox(FIRE_ALARM_CHECKBOX_XPATH, false);
            }
        }
    }

    public void fillOutFireSystemsInfo(String fireSystemValue, String stateCode) throws Exception {
        if (!fireSystemValue.isBlank()) {
            checkUncheckMatCheckbox(FIRE_PROTECTION_CHECKBOX_XPATH, true);
            if (fireSystemValue.equalsIgnoreCase(NO)) {
                if(stateCode.equals(NC)){
                    waitAndClickElement(smokeAlarmsToggleButtonNo);
                }else{
                    waitAndClickElement(fireAlarmsToggleButtonNo);
                }

            } else {
                if(List.of(NC, KY).contains(stateCode)){
                    waitAndClickElement(smokeAlarmsToggleButtonYes);
                }else{
                    waitAndClickElement(fireAlarmsToggleButtonYes);
                }

                if (isElementVisible(fireAlarmsRadioButton, 2)) {
                    PWElement radioWe = driver().findElement(PWBy.xpath(FIRE_PROTECTION_RADIO_XPATH +
                            "[contains(.,'" + fireSystemValue + "')]"));
                    waitAndClickElement(radioWe);
                }
            }
        } else {
            if (isElementDisplayed(PWBy.xpath(FIRE_PROTECTION_CHECKBOX_XPATH))) {
                checkUncheckMatCheckbox(FIRE_PROTECTION_CHECKBOX_XPATH, false);
            }
        }
    }

    public void fillOutSmokeAlarms(String smokeAlarms) throws Exception {
        if (!smokeAlarms.isBlank()) {
            checkUncheckMatCheckbox(FIRE_PROTECTION_CHECKBOX_XPATH, true);
            if (smokeAlarms.equalsIgnoreCase(YES)) {
                waitAndClickElement(smokeAlarmsToggleButtonYes);
            } else {
                waitAndClickElement(smokeAlarmsToggleButtonNo);
            }
        } else {
            if (isElementDisplayed(PWBy.xpath(FIRE_PROTECTION_CHECKBOX_XPATH))) {
                checkUncheckMatCheckbox(FIRE_PROTECTION_CHECKBOX_XPATH, false);
            }
        }
    }

    public void fillOutSprinklerSystemsInfo(String sprinklerSystemValue) throws Exception {
        if (!sprinklerSystemValue.equals(EMPTY_STRING)) {
            checkUncheckMatCheckbox(FIRE_PROTECTION_CHECKBOX_XPATH, true);
            waitAndClickElement(sprinklerSystemsToggleButtonYes);
            waitElementBeVisibleClickable(sprinklerSystemRadioButtonPartial);
            if (sprinklerSystemValue.trim().equals(expectedSprinklerSystemPartialLabel)) {
                scrollAndClickOnHiddenElement(sprinklerSystemRadioButtonPartial);
            } else if (sprinklerSystemValue.trim().equals(expectedSprinklerSystemFullLabel)) {
                scrollAndClickOnHiddenElement(sprinklerSystemRadioButtonFull);
            }
        } else {
            if (isElementDisplayed(PWBy.xpath(FIRE_PROTECTION_CHECKBOX_XPATH))) {
                checkUncheckMatCheckbox(FIRE_PROTECTION_CHECKBOX_XPATH, false);
            }
        }
    }

    public void fillOutFireSprinkler(String hasFireSprinklerSystem) throws Exception {
        if (!hasFireSprinklerSystem.isBlank()) {
            checkUncheckMatCheckbox(FIRE_PROTECTION_CHECKBOX_XPATH, true);
            waitAndClickElement(sprinklerSystemsToggleButtonYes);
            if (hasFireSprinklerSystem.equals(FULL)) {
                waitAndClickElement(sprinklerSystemRadioButtonFull);
            } else {
                waitAndClickElement(sprinklerSystemRadioButtonPartial);
            }
        } else {
            if (isElementDisplayed(PWBy.xpath(FIRE_PROTECTION_CHECKBOX_XPATH))) {
                checkUncheckMatCheckbox(FIRE_PROTECTION_CHECKBOX_XPATH, true);
                waitAndClickElement(sprinklerSystemsToggleButtonNo);
            }
        }
    }

    public void fillOutStormShutters(boolean hasStormShutters) throws Exception {
        if (isElementDisplayed(PWBy.xpath(STORM_SHUTTER_CHECKBOX_XPATH))) {
            checkUncheckMatCheckbox(STORM_SHUTTER_CHECKBOX_XPATH, hasStormShutters);
        }
    }

    public void fillOutElectricalSystem(String electrical) throws Exception {
        if (!electrical.isBlank()) {
            scrollToElement(electricalSystemCheckbox);
            checkUncheckMatCheckbox(ELECTRICAL_SYSTEM_UPDATED_CHECKBOX_XPATH, true);
            if (!electrical.equalsIgnoreCase(I_AM_NOT_SURE)) {
                waitAndClickElement(electricalSystemYearInput);
                sendKeysToElement(electricalSystemYearInput, electrical);
            } else {
                checkUncheckMatCheckbox(ELECTRICAL_SYSTEM_AGE_SURITY_CHECK_XPATH, true);
            }
        } else {
            if (isElementDisplayed(PWBy.xpath(ELECTRICAL_SYSTEM_UPDATED_XPATH))) {
                checkUncheckMatCheckbox(ELECTRICAL_SYSTEM_UPDATED_XPATH + "//mat-checkbox", false);
            }
        }
    }

    public void fillOutPlumbingSystem(String plumbing) throws Exception {
        if (!plumbing.isBlank()) {
            scrollToElement(plumbingSystemCheckbox);
            checkUncheckMatCheckbox(PLUMBING_SYSTEM_UPDATED_CHECKBOX_XPATH, true);
            if (!plumbing.equalsIgnoreCase(I_AM_NOT_SURE)) {
                waitAndClickElement(plumbingSystemYearInput);
                sendKeysToElement(plumbingSystemYearInput, plumbing);
            } else {
                checkUncheckMatCheckbox(PLUMBING_SYSTEM_AGE_SURITY_CHECKBOX_XPATH, true);
            }
        } else {
            if (isElementDisplayed(PWBy.xpath(PLUMBING_SYSTEM_UPDATED_XPATH))) {
                checkUncheckMatCheckbox(PLUMBING_SYSTEM_UPDATED_XPATH + "//mat-checkbox", false);
            }
        }
    }

    public void fillOutPlumbingSystemCA(String plumbing) {
        if (!plumbing.isBlank()) {
            scrollToElement(plumbingSystemReplacedYes);
            if (plumbing.equalsIgnoreCase(YES)) {
                if (!getAttributeData(plumbingSystemReplacedMatToggleYes, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED)) {
                    waitAndClickElement(plumbingSystemReplacedYes);
                }
            } else {
                if (!getAttributeData(plumbingSystemReplacedMatToggleNo, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED)) {
                    waitAndClickElement(plumbingSystemReplacedNo);
                }
            }
        } else {
            scrollToElement(plumbingSystemReplacedNo);
            if (!getAttributeData(plumbingSystemReplacedMatToggleNo, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED)) {
                waitAndClickElement(plumbingSystemReplacedNo);
            }
        }
    }

    public void fillOutHvacSystem(String hvac) throws Exception {
        if (!hvac.isBlank()) {
            scrollToElement(hvacSystemCheckbox);
            checkUncheckMatCheckbox(HVAC_SYSTEM_UPDATED_CHECKBOX_XPATH, true);
            if (!hvac.equalsIgnoreCase(I_AM_NOT_SURE)) {
                waitAndClickElement(hvacSystemYearInput);
                sendKeysToElement(hvacSystemYearInput, hvac);
            } else {
                checkUncheckMatCheckbox(HVAC_AGE_SURITY_CHECKBOX_XPATH, true);
            }
        } else {
            if (isElementDisplayed(PWBy.xpath(HVAC_SYSTEM_UPDATED_XPATH))) {
                checkUncheckMatCheckbox(HVAC_SYSTEM_UPDATED_XPATH + "//mat-checkbox", false);
            }
        }
    }

    public void fillOutOtherHomeProtectionFeatures() {
        scrollToElement(otherHomeProtectionFeaturesMatCheckbox);
        waitAndClickElement(otherHomeProtectionFeaturesCheckboxLabel);
        waitAndClickElement(otherHomeProtectionFeaturesRadioButtonLabels.get(1));
    }

    public void validateDataNotSaved(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        waitForPageToBeReady();
        if (isElementDisplayed(roofToggleNoButton, 2)) {
            fsa.assertTrue(getAttributeData(roofToggleNoButton, CLASS).contains("mat-button-toggle-checked"), "By default no button is selected");
        } else {
            String roofReplacedYear = getSessionStorageAppStore().getHome().getPropertyDetailsForm().getFieldValueByName("roofReplacedYear");
            fsa.assertEquals(getTextFromElement(roofReplacedYearText), roofReplacedYear, "Replaced roof year is provided by NearMap service.");
        }
        if (!isNoHomeShareState(applicant.getStateCode())) {
            fsa.assertTrue(!isTemporaryRentalsCheckboxChecked(), "Temporary Rental check box unselected");
        }
        if (!applicant.getSwimmingPool().isBlank()) {
            fsa.assertTrue(!isSwimmingPoolCheckboxChecked(),"Swimming pool check box is unselected");
        }
        if (!isNoSolarPanelsState(applicant.getStateCode())) {
            fsa.assertTrue(!isSolarPanelsCheckboxChecked(), "Solar Panel check box is checked unselected");
        }
        if (!applicant.getTrampoline().isBlank()) {
            fsa.assertTrue(!isTrampolineCheckboxChecked(), "Trampoline Check box is checked unselected");
        }
        if (isStormShuttersEnabledState(applicant.getStateCode())) {
            fsa.assertTrue(!getAttributeData(stormShutterCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Storm Shutter check box is unselected");
        }
        if(isValidateWroughtIronBarSection(applicant)) {
            fsa.assertTrue(!getAttributeData(wroughtIronBarsMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "wrought Iron Bar check box is unselected");
        }
        if (!isCentralFireAlarmState(applicant.getStateCode()) && !applicant.getStateCode().equals(NC)) {
            fsa.assertTrue(!isFireAlarmCheckboxChecked(), "Fire Alarm check box is unselected");
        }
        if (isOtherHomeProtectionFeaturesState(applicant.getStateCode())) {
            if (!applicant.getFortifiedHome().isBlank() || applicant.getWaterLeakProtection().contains("Whole home")) {
                fsa.assertTrue(!isOtherHomeProtectionFeaturesCheckboxChecked(), "Home protection check box is unselected");
            }
        } else {
            fsa.assertTrue(!isWaterProtectionCheckboxChecked(), "Water protection check box is unselected");
            if (applicant.getExpectedFortifiedHomeDesignation().equals(EMPTY_STRING) && !applicant.getStateCode().equals(NC)) {
                fsa.assertTrue(!isFortifiedHomeCheckboxChecked(), "Fortified Home check box is unselected");
            }
        }
        if (!isCentralBurglarAlarmState(applicant.getStateCode())  && !applicant.getStateCode().equals(NC)) {
            fsa.assertTrue(!isBurglarAlarmCheckboxChecked(), "Burglar alarm check box is checked unselected");
        }
        if (!applicant.getPreviousInsurance().isBlank()) {
            fsa.assertTrue(!getAttributeData(previousInsuranceMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Previous Insurance check box is unselected");
        }
        if (!applicant.getWildFireRisk().isBlank() && !applicant.getStateCode().equals(CA)) {
            fsa.assertTrue(!getAttributeData(wildfireRiskReductionMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Previous Insurance check box is unselected");
        }
        if (applicant.getStateCode().equals(NC)) {
            fsa.assertTrue(!getAttributeData(alarmSystemMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Alarm System check box is unselected");
        }
        if (isNonSmokerState(applicant.getStateCode())) {
            fsa.assertTrue(!isNonSmokerCheckboxChecked(), "Non Smoker check box is unselected");
        }
        if (isCentralFireAlarmState(applicant.getStateCode())) {
            fsa.assertTrue(!isCentralFireAlarmCheckboxChecked(), "Fire Alarm check box is unselected");
        }
        if (isCentralBurglarAlarmState(applicant.getStateCode())) {
            fsa.assertTrue(!isCentralBurglarAlarmCheckboxChecked(), "Central Burglar Alarm check box is unselected");
        }
        if (!applicant.getElectricalUpdated().isBlank()) {
            fsa.assertTrue(!getAttributeData(electricalSystemCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Electrical System check box is unselected");
        }
        if (!applicant.getHvacUpdated().isBlank()) {
            fsa.assertTrue(!getAttributeData(hvacSystemCheckbox, CLASS).contains(CHECKBOX_CHECKED), "HVAC System check box is unselected");
        }

    }
    public void fillOutBurglarAlarmInfo(String burglarAlarmValue) throws Exception {
        if (!burglarAlarmValue.isBlank()) {
            scrollToElement(burglarAlarmMatCheckbox);
            checkUncheckMatCheckbox(BURGLAR_ALARM_CHECKBOX_XPATH, true);
            waitElementBeVisibleClickable(burglarAlarmRadioButton);
            if (burglarAlarmValue.trim().equals(expectedUnMonitoredLabel)) {
                scrollAndClickOnHiddenElement(burglarAlarmRadioButtonsInput.get(0));
            } else if (burglarAlarmValue.trim().equals(expectedSelfMonitoredLabel)) {
                scrollAndClickOnHiddenElement(burglarAlarmRadioButtonsInput.get(1));
            } else if (burglarAlarmValue.trim().equals(expectedProfessionallyMonitoredLabel)) {
                scrollAndClickOnHiddenElement(burglarAlarmRadioButtonsInput.get(2));
            }
        }
    }

    public void fillOutWaterLeakProtectionInfo(String waterLeakProtectionValue) throws Exception {
        if (!waterLeakProtectionValue.isBlank()) {
            scrollToElement(waterProtectionMatCheckbox);
            checkUncheckMatCheckbox(WATER_PROTECTION_CHECKBOX_XPATH, true);
            waitElementBeVisibleClickable(waterProtectionRadioButton);
            int i = 0;
            for (PWElement radio: waterProtectionMatRadioButtons) {
                if (getTextFromElement(radio).equals(waterLeakProtectionValue)) {
                    scrollAndClickOnHiddenElement(waterProtectionRadioButtons.get(i));
                    break;
                }
                i++;
            }
        } else {
            if (isElementDisplayed(PWBy.xpath(WATER_PROTECTION_CHECKBOX_XPATH))) {
                checkUncheckMatCheckbox(WATER_PROTECTION_CHECKBOX_XPATH, false);
            }
        }
    }

    public void fillOutFortifiedHomeInfo(String fortifiedHomeValues) throws Exception {
        if (!fortifiedHomeValues.isBlank()) {
            scrollToElement(fortifiedHomeMatCheckbox);
            checkUncheckMatCheckbox(FORTIFIED_HOME_CHECKBOX_XPATH, true);
            waitElementBeVisibleClickable(fortifiedHomeCertRadioButton);
            switch (fortifiedHomeValues.trim()) {
                case expectedFortifiedRoofLabel:
                    scrollAndClickOnHiddenElement(fortifiedHomeCertRadioButtons.get(0));
                    break;
                case expectedFortifiedSilverLabel:
                    scrollAndClickOnHiddenElement(fortifiedHomeCertRadioButtons.get(1));
                    break;
                case expectedFortifiedGoldLabel:
                    scrollAndClickOnHiddenElement(fortifiedHomeCertRadioButtons.get(2));
                    break;
                case expectedFortifiedInternationalCodeLabel:
                    scrollAndClickOnHiddenElement(fortifiedHomeCertRadioButtons.get(3));
                    break;
                case expectedFortifiedForSaferLivingLabel:
                    scrollAndClickOnHiddenElement(fortifiedHomeCertRadioButtons.get(4));
                    break;
                default:
                    Log.error("Incorrect FORTIFIED Home label: [" + fortifiedHomeValues + "]");
            }
        } else {
            if (isElementDisplayed(PWBy.xpath(FORTIFIED_HOME_CHECKBOX_XPATH))) {
                checkUncheckMatCheckbox(FORTIFIED_HOME_CHECKBOX_XPATH, false);
            }
        }
    }

    public void fillOutUlRoofInfo(String ulRoofValue) throws Exception {
        if (!ulRoofValue.isBlank()) {
            scrollToElement(ulRoofMatCheckbox);
            checkUncheckMatCheckbox(UL_ROOF_CHECKBOX_XPATH, true);
            waitElementBeVisibleClickable(ulRoofRadioButton);
            switch (ulRoofValue.trim()) {
                case "UL Class 3":
                    scrollAndClickOnHiddenElement(ulRoofRadioButtonLabels.get(0));
                    break;
                case "UL Class 4":
                    scrollAndClickOnHiddenElement(ulRoofRadioButtonLabels.get(1));
                    break;
                case "UL Class 1, 2, or not certified":
                    scrollAndClickOnHiddenElement(ulRoofRadioButtonLabels.get(2));
                    break;
                default:
                    Log.error("Incorrect UL Roof label: [" + ulRoofValue + "]");
            }
        } else {
            if (isElementDisplayed(PWBy.xpath(UL_ROOF_CHECKBOX_XPATH))) {
                checkUncheckMatCheckbox(UL_ROOF_CHECKBOX_XPATH, false);
            }
        }
    }

    public void fillOutWroughtIronBarsInfo(boolean isWroughtIronBars) throws Exception {
        checkUncheckMatCheckbox(WROUGHT_IRON_BARS_CHECKBOX_XPATH, isWroughtIronBars);
    }

    public void fillOutPreviousInsurance(String previousInsurance) throws Exception {
        if (!previousInsurance.isBlank()) {
            scrollToElement(previousInsuranceMatCheckbox);
            checkUncheckMatCheckbox(PREVIOUS_INSURANCE_CHECKBOX_XPATH, true);
            if (isElementPresent(PWBy.xpath(PREVIOUS_INSURANCE_RADIO_BUTTON_XPATH), 2)) {
                waitElementBeVisible(previousInsuranceRadioButtons.get(0));
                PWElement weRadio = driver().findElement(PWBy.xpath(PREVIOUS_INSURANCE_RADIO_BUTTON_XPATH + "[contains(.,'" + previousInsurance + "')]"));
                waitAndClickElement(weRadio);
                Log.info("Selected transfer discount insurance carrier: " + previousInsurance);
                if (isElementDisplayed(buttonSaveHomeTransferDiscount, 2)) {
                    waitAndClickElement(buttonSaveHomeTransferDiscount);
                } else {
                    waitAndClickElement(buttonCancelHomeTransferDiscount);
                }
            }
            Assert.assertEquals(getTextFromElement(homeDiscountSelected), previousInsurance, "Home Transfer Discount - expected insurance carrier text is found.");
        } else {
            if (isElementDisplayed(PWBy.xpath(PREVIOUS_INSURANCE_CHECKBOX_XPATH))) {
                checkUncheckMatCheckbox(PREVIOUS_INSURANCE_CHECKBOX_XPATH, false);
            }
        }
    }

    public void fillOutWildfireRiskReduction(String wildfireRiskReduction) throws Exception {
        if (!wildfireRiskReduction.isBlank()) {
            scrollToElement(wildfireRiskReductionMatCheckbox);
            checkUncheckMatCheckbox(WILDFIRE_RISK_REDUCTION_CHECKBOX_XPATH, true);
            waitElementBeVisible(wildfireRiskReductionMatCheckboxes.get(0));
            checkUncheckMatCheckbox(WILDFIRE_RISK_REDUCTION_XPATH + "//mat-card//mat-checkbox[contains(.,'" + wildfireRiskReduction + "')]", true);
            Log.info("Selected wildfire risk reduction checkbox: " + wildfireRiskReduction);
        } else {
            if (isElementDisplayed(PWBy.xpath(WILDFIRE_RISK_REDUCTION_CHECKBOX_XPATH))) {
                checkUncheckMatCheckbox(WILDFIRE_RISK_REDUCTION_CHECKBOX_XPATH, false);
            }
        }
    }

    public void fillOutNonSmoker(boolean nonSmoker) throws Exception {
        checkUncheckMatCheckbox(NON_SMOKER_XPATH, nonSmoker);
    }

    public void fillOutCentralFireAlarm(boolean centralFire) throws Exception {
        checkUncheckMatCheckbox(CENTRAL_FIRE_ALARM_XPATH, centralFire);
    }

    public void fillOutCentralBurglarAlarm(boolean centralBurglar) throws Exception {
        checkUncheckMatCheckbox(CENTRAL_BURGLAR_ALARM_XPATH, centralBurglar);
    }

    public void validatePopulatedDesignationVal(String fortifiedDesignation) {
        FarmersSoftAssert sa= new FarmersSoftAssert();
        waitAndClickElement(discountCheckboxLabel.get(3));
        waitForSpinnerToBeGone();
        sa.assertTrue(getTextFromElement(populatedFortifiedDesignationVal).contains(fortifiedDesignation),"Pre-populated value verification: "
                + getTextFromElement(populatedFortifiedDesignationVal) + ", contains: " + fortifiedDesignation);
    }

    public void validateAdditionalInfoSelections(ApplicantAceHome applicant, FarmersSoftAssert fsa) {
        if (!isNoHomeShareState(applicant.getStateCode())) {
            fsa.assertEquals(isTemporaryRentalsCheckboxChecked(), applicant.isTemporaryRentals(), "Additional Info page - temporary rentals checkbox.");
        }
        fsa.assertEquals(isSwimmingPoolCheckboxChecked(), !applicant.getSwimmingPool().isBlank(), "Additional Info page - swimming pool checkbox.");
        if (!applicant.getSwimmingPool().isBlank()) {
            sleep(3);
            fsa.assertEquals(getSelectedSwimmingPoolOption(), "The pool is " + applicant.getSwimmingPool(), "Additional Info page - swimming pool option selected.");
        }
        if (!isNoSolarPanelsState(applicant.getStateCode())) {
            fsa.assertEquals(isSolarPanelsCheckboxChecked(), applicant.isSolarPanels(), "Additional Info page - solar panels checkbox.");
        }
        fsa.assertEquals(isTrampolineCheckboxChecked(), !applicant.getTrampoline().isBlank(), "Additional Info page - trampoline checkbox.");
        if (!applicant.getTrampoline().isBlank()) {
            fsa.assertEquals(getSelectedTrampolineOption(), "The trampoline is " + applicant.getTrampoline(), "Additional Info page - trampoline option selected.");
        }
        String roofYearReplaced = applicant.getRoofReplaced().strip().equalsIgnoreCase(TRUE) ? String.valueOf(LocalDate.now().minusYears(2).getYear()) : applicant.getRoofReplaced().strip();
        if (!getRoofReplacedYear().isBlank()) {
            fsa.assertEquals(getRoofReplacedYear(), roofYearReplaced, "Additional Info page - year roof was replaced.");
        }
        if (!isCentralFireAlarmState(applicant.getStateCode()) && !applicant.getStateCode().equals(NC)) {
            fsa.assertEquals(isFireAlarmCheckboxChecked(), !applicant.getFireAlarm().isBlank(), "Additional Info page - fire alarm checkbox.");
            if (!applicant.getFireAlarm().isBlank()) {
                fsa.assertEquals(getSelectedFireAlarmOption(), applicant.getFireAlarm(), "Additional Info page - fire alarm option selected.");
            }
        }
        if (!isCentralBurglarAlarmState(applicant.getStateCode()) && !applicant.getStateCode().equals(NC)) {
            fsa.assertEquals(isBurglarAlarmCheckboxChecked(), !applicant.getBurglarAlarm().isBlank(), "Additional Info page - burglar alarm checkbox.");
            if (!applicant.getBurglarAlarm().isBlank()) {
                fsa.assertEquals(getSelectedBurglarAlarmOption(), applicant.getBurglarAlarm(), "Additional Info page - burglar alarm option selected.");
            }
        }
        if (isOtherHomeProtectionFeaturesState(applicant.getStateCode())) {
            if (!applicant.getFortifiedHome().isBlank() || applicant.getWaterLeakProtection().contains("Whole home")) {
                fsa.assertTrue(getAttributeData(otherHomeProtectionFeaturesRadioButtons.get(1), CLASS).contains(RADIO_BUTTON_CHECKED),
                        "Additional Info page - Other home protection features (FORTIFIED Home) option selected.");
            }
        } else {
            fsa.assertEquals(isWaterProtectionCheckboxChecked(), !applicant.getWaterLeakProtection().isBlank(), "Additional Info page - water protection checkbox.");
            if (!applicant.getWaterLeakProtection().isBlank()) {
                fsa.assertEquals(getSelectedWaterProtectionOption(), applicant.getWaterLeakProtection(), "Additional Info page - water protection option selected.");
            }
        }
        if (isNonSmokerState(applicant.getStateCode())) {
            fsa.assertEquals(isNonSmokerCheckboxChecked(), applicant.isNonSmoker(), "Additional Info page - Non-smoker checkbox.");
        }
        if (isCentralFireAlarmState(applicant.getStateCode())) {
            fsa.assertEquals(isCentralFireAlarmCheckboxChecked(), applicant.isCentralFireAlarm(), "Additional Info page - Central fire alarm checkbox.");
        }
        if (isCentralBurglarAlarmState(applicant.getStateCode())) {
            fsa.assertEquals(isCentralBurglarAlarmCheckboxChecked(), applicant.isCentralBurglarAlarm(), "Additional Info page - Central burglar alarm checkbox.");
        }
        if (!isOtherHomeProtectionFeaturesState(applicant.getStateCode()) && !applicant.getStateCode().equals(NC)) {
            fsa.assertEquals(isFortifiedHomeCheckboxChecked(), !applicant.getFortifiedHome().isBlank(), "Additional Info page - fortified home checkbox.");
            if (!applicant.getFortifiedHome().isBlank()) {
                fsa.assertEquals(getSelectedFortifiedHomeOption(), applicant.getFortifiedHome(), "Additional Info page - fortified home option selected.");
            }
        } else {
            if (!applicant.getStateCode().equals(NC)) {
                fsa.assertEquals(isOtherHomeProtectionFeaturesCheckboxChecked(), !applicant.getFortifiedHome().isBlank(), "Additional Info page - Other Home Protection features checkbox.");
                if (!applicant.getFortifiedHome().isBlank()) {
                    fsa.assertEquals(getSelectedOtherHomeProtectionFeature(), applicant.getFortifiedHome(), "Additional Info page - Other Home Protection feature selected.");
                }
            }
        }
    }

    public boolean validateFloorResidenceIsLocatedOnSection(String lob) {
        boolean result;
        if (lob.equals(HOME)) {
            result = !isElementDisplayed(residenceFloorSection, 1) &&
                    !isElementDisplayed(residenceFloorCheckbox, 1) &&
                    !isElementDisplayed(residenceFloorInfoLabel, 1) &&
                    !isElementDisplayed(residenceFloorInfoDescription,1);
        } else {
            result = isElementDisplayed(residenceFloorSection, 1) &&
                    getTextFromElement(residenceFloorInfoLabel).equals("My unit is on the third floor, or higher") &&
                    getTextFromElement(residenceFloorInfoDescription).equals("It is not located in the basement, first, or second floor");
        }
        return result;
    }

    public void validateADA(String lobType) throws Exception {
        if (lobType.equals(LOB_HOME)) {
            ((PWJavascriptExecutor) driver()).executeScript("document.querySelectorAll('input[type=\"checkbox\"]').forEach(e => e.click());");
            clickContinueButton();
            performADATesting(this.getClass().getSimpleName(),MARKETING_IT,lobType);
            driver().navigate().refresh(); // to restore the page to the original state
        } else if (lobType.equals(LOB_CONDO)) {
            performADATesting(this.getClass().getSimpleName(),MARKETING_IT,lobType);
        }
    }

    public void clickOnYesToggleButtonForRoofYearSection(){
        waitAndClickElement(roofCompletelyReplacedYesButton);
    }

    public void clickOnNoToggleButtonForRoofYearSection(){
        waitAndClickElement(roofCompletelyReplacedNoButton);
    }

    public void clickOnYesPlumbingReplaced20Year() {
        waitAndClickElement(plumbingReplaced20YearYesButton);
    }

    public void clickOnNoPlumbingReplaced20Year() {
        waitAndClickElement(plumbingReplaced20YearNoButton);
    }

    public boolean isSelectedYesPlumbingSystemReplaced20Year() {
        return getAttributeData(plumbingReplaced20YearYesMatButton, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED);
    }

    public boolean isSelectedNoPlumbingSystemReplaced20Year() {
        return getAttributeData(plumbingReplaced20YearNoMatButton, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED);
    }

}
