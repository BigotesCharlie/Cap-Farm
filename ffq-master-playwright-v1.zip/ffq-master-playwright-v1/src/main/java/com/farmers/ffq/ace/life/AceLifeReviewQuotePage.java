package com.farmers.ffq.ace.life;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.datatransferobjects.ApplicantLife;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceLifeReviewQuotePage extends BasePage {

	private static final String PREMIUM_LEVEL_TERM_BUTTONS_XPATH = "//mat-button-toggle-group//button";

	@PWFindBy(xpath = "//div[@class='personal-info_address_h1']//h1")
	private PWElement reviewQuotePageTitle;

	@PWFindBy(className = "mb-40")
	private PWElement reviewQuotePageSubtitle;

	@PWFindBy(className = "term-benefits")
	private PWElement coverageBenefitsSectionHeader;

	@PWFindBy(xpath = "//div[@class='personal-info_address_h1']//li")
	private List<PWElement> listOfCoverageBenefits;

	@PWFindBy(xpath = "//div[@class='personal-info_address_h1']//div[contains(@class,'col-md')]/p")
	private List<PWElement> listOfCoverageOptionTextParagraphs;

	@PWFindBy(xpath = "//label[contains(@class, 'coverage-limit-label')]")
	private PWElement coverageLimitLabel;

	@PWFindBy(xpath = "//mat-select")
	private PWElement coverageLimitSelectionDropdown;

	@PWFindBy(xpath = "//mat-option")
	private List<PWElement> listOfCoverageLimits;

	@PWFindBy(xpath = "//label[contains(@class, 'premium-level-label') or contains(@class, 'auto-add-driver-')]")
	private PWElement premiumLevelTermLabel;

	@PWFindBy(xpath = PREMIUM_LEVEL_TERM_BUTTONS_XPATH)
	private List<PWElement> listOfPremiumLevelTermButtons;

	@PWFindBy(xpath = "//label[@class='autopay']")
	private PWElement autopayPlanLabel;

	@PWFindBy(className = "tui-price")
	private PWElement autopayAmount;

	@PWFindBy(className = "life-policy-header")
	private PWElement getAllThisWithALifePolicyHeader;

	@PWFindBy(xpath = "//div[@class='fast-approval']/img")
	private List<PWElement> listOfGetAllThisIcons;

	@PWFindBy(className = "fast-div")
	private List<PWElement> listOfGetAllThisTextElements;

	@PWFindBy(xpath = "//div[@class='personal-info_address_h1']//div[contains(@class,'col-')]/div[not(@class)]/p[not(@class)]")
	private List<PWElement> listOfLifeInsuranceIssueDisclaimerText;

	@PWFindBy(xpath = "//button[@data-tui-tracking-id='review-quote_continue-button-cta']")
	private PWElement callNowButton;

	@PWFindBy(id = "emailLink")
	private PWElement emailThisQuoteLink;

	@PWFindBy(xpath = "//div[contains(@class, 'home-group-image-container')]/img")
	private PWElement reviewQuotePageImage;

	@PWFindBy(xpath = "//*[contains(@class, 'icc24_container')]")
	private PWElement legalDisclaimerText;

	@PWFindBy(className = "loading-skeleton-container")
	private PWElement pageLoadingSkeleton;

	private List<String> listOfCoverageValues = new ArrayList<>(Arrays.asList("$50,000", "$150,000", "$350,000", "$500,000", "$750,000", "$1,000,000", "$2,000,000"));

	public AceLifeReviewQuotePage() throws Exception {
		super();
	}

	public void contentValidation(ApplicantLife applicant, FarmersSoftAssert fsa) throws Exception {
		String connectingCharacterString = isSafariBrowser()? EMPTY_STRING : SPACE;
		fsa.assertEquals(getTextFromElement(reviewQuotePageTitle), "Explore policy options", "Review Quote page title");
		fsa.assertEquals(getTextFromElement(reviewQuotePageSubtitle), "You may want to consider term life insurance if affordable coverage is a primary goal or if you have short-term financial obligations. " +
				"You can select coverage for a specific period of time and your premiums are guaranteed to stay level during that period.", "Review Quote page subtitle");
		fsa.assertEquals(getTextFromElement(coverageBenefitsSectionHeader), "Farmers\u00ae Term Life1 from Farmers New World Life Insurance Company features coverage benefits such as:", "Coverage benefits header");
		String termMessage = setExpectedTermMessage(applicant.getAge());
		List<String> listOfExpectedCoverageBenefits = new ArrayList<>(Arrays.asList(
				termMessage,
				"Optionality to add or enhance coverage to fit your specific needs",
				"Death benefit proceeds that could be used to leave an inheritance, pay off a mortgage, or for funeral costs and other final expenses3"));
		List<String> listOfObservedCoverageBenefits = new ArrayList<>();
		listOfCoverageBenefits.forEach(benefitElement -> listOfObservedCoverageBenefits.add(getTextFromElement(benefitElement)));
		fsa.assertEquals(listOfObservedCoverageBenefits, listOfExpectedCoverageBenefits, "Actual and Expected Coverage benefit paragraphs match");
		List<String> listOfExpectedCoverageOptions = new ArrayList<>(Arrays.asList(
				"We've selected some popular options to get you started. (Other coverage options are available. Get in touch with a representative to get the coverage you want.)",
				"Our range spans from $50,000 to $10 million so you can find the amount that's right for you. Select an amount close to what you think you need."));
		List<String> listOfObservedCoverageOptions= new ArrayList<>();
		listOfCoverageOptionTextParagraphs.forEach(coverageOptionElement -> listOfObservedCoverageOptions.add(getTextFromElement(coverageOptionElement)));
		fsa.assertEquals(listOfObservedCoverageOptions, listOfExpectedCoverageOptions, "Actual and Expected Coverage options paragraphs match");
		fsa.assertEquals(getTextFromElement(coverageLimitLabel), "Coverage limit4", "Coverage limit section label");
		fsa.assertEquals(getTextFromElement(coverageLimitSelectionDropdown), "$150,000", "Default coverage amount");
		fsa.assertEquals(getTextFromElement(premiumLevelTermLabel), applicant.getAge()>70? "Premium level term: 10 years" : "Premium level term (years)", "Premium level term: 10 years section label");
		verifyTermButtonLabels(applicant.getAge(), fsa);
		fsa.assertEquals(getTextFromElement(autopayPlanLabel), "Monthly premium5 starting at", "Autopay header");
		scrollToBottomOfPage();
		fsa.assertEquals(getTextFromElement(callNowButton), "Call now", "CTA Button label verification");
		fsa.assertEquals(getTextFromElement(emailThisQuoteLink), "Email this quote", "Email link label verification");
		scrollAndClickOnElement(emailThisQuoteLink);
		waitForSpinnerToBeGone();
		fsa.assertTrue(isSnackBarMessageDisplayed("A copy of your quote number has been emailed to " + applicant.getEmailAddress()), "Email sent snackbar message found.");
		scrollAndClickOnElement(coverageLimitSelectionDropdown);
		List<String> listOfObservedCoverageLimitValues = new ArrayList<>();
		listOfCoverageLimits.forEach(coverageValue -> listOfObservedCoverageLimitValues.add(getTextFromElement(coverageValue)));
		List<String> listOfExpectedCoverageValues = new ArrayList<>(Arrays.asList("$50,000", "$150,000", "$350,000", "$500,000", "$750,000", "$1,000,000", "$2,000,000"));
		fsa.assertEquals(listOfObservedCoverageLimitValues, listOfExpectedCoverageValues, "Actual and Expected Available coverage values match");
		clickElement(reviewQuotePageTitle);
		fsa.assertEquals(getTextFromElement(getAllThisWithALifePolicyHeader), "You get all this with your life policy", "Get all this header");
		List<String> listOfExpectedGetAllThisTextParagraphs = new ArrayList<>(Arrays.asList(
				"Fast approval" + connectingCharacterString + "You may qualify for the convenience of same-day approval decisions, with no medical exam required.",
				"Peace of mind" + connectingCharacterString + "Get all your insurance coverage with one brand you know.",
				"Savings" + connectingCharacterString + "Discounts may be available for existing Farmers customers.6"));
		List<String> listOfObservedGetAllThisTextParagraphs = new ArrayList<>();
		listOfGetAllThisTextElements.forEach(getAllThisElement -> listOfObservedGetAllThisTextParagraphs.add(getTextFromElement(getAllThisElement)));
		fsa.assertEquals(listOfObservedGetAllThisTextParagraphs, listOfExpectedGetAllThisTextParagraphs, "Actual and Expected Get all this paragraphs match");
		List<String> listOfExpectedGetAllThisIcons = List.of("flash", "security", "money");
		List<String> listOfObservedGetAllThisIcons = new ArrayList<>();
		listOfGetAllThisIcons.forEach(iconElement -> listOfObservedGetAllThisIcons.add(getAttributeData(iconElement, SRC)));
		for (int index = 0; index < listOfExpectedGetAllThisIcons.size() && index < listOfObservedGetAllThisIcons.size(); index++) {
			fsa.assertTrue(listOfObservedGetAllThisIcons.get(index).contains(listOfExpectedGetAllThisIcons.get(index)), "Verifying the " + listOfExpectedGetAllThisIcons.get(index) + " icon is present.");
		}
		List<String> listOfObservedDisclaimerText= new ArrayList<>();
		listOfLifeInsuranceIssueDisclaimerText.forEach(disclaimerElement -> listOfObservedDisclaimerText.add(getTextFromElement(disclaimerElement)));
		List<String> listOfExpectedDisclaimerText = new ArrayList<>(Arrays.asList(
				"1. ICC25-FTL or applicable state variation",
				"2. Premiums are subject to change after the initial level premium period.",
				"3. Benefit amounts provided will depend on the product selected and the premium will vary with the amount of benefits.",
				"4. Available face amounts may vary.",
				"5. Premiums are subject to change. Issuance of a policy and premiums are subject to underwriting guidelines and approval. Premiums quoted are based on gender; age; nicotine/non-nicotine status; underwriting classification; frequency and payment method, i.e. monthly EFT, etc.",
				"6. Discounts apply to selected coverages, perils, and policy types. Eligibility and actual percentage of discounts may vary."));
		fsa.assertEquals(listOfObservedDisclaimerText, listOfExpectedDisclaimerText, "Actual and Expected Disclaimers match");
		String imageSourceValue = getAttributeData(reviewQuotePageImage, SRC);
		fsa.assertTrue(imageSourceValue!= null && imageSourceValue.contains("life-rebrand.png"), "life-rebrand.png image used in page");
		fsa.assertEquals(getTextFromElement(legalDisclaimerText), "Life insurance issued by Farmers New World Life Insurance Company, 12822 SE 32nd St, Suite 2 Bellevue, WA 98005. " +
				"Products and features, including same-day coverage, may not be available to all applicants or in all states and may vary by state. " +
				"Restrictions, exclusions, limits, and conditions apply. " +
				"Any product guarantees are subject to the financial strength and claims-paying ability of Farmers New World Life Insurance Company, which is solely responsible for the obligations under its own policies. " +
				"Farmers New World Life Insurance Company is not licensed and does not solicit or sell in the state of New York. " +
				"6952619.2 5/26", "Legal disclaimer text");
		// Validate screen refresh does not change the quote rate
		double initialQuotedAmount = Double.parseDouble(getTextFromElement(waitElementBeVisible(autopayAmount, 5)).replaceAll("[^0-9.]", EMPTY_STRING));
		driver().navigate().refresh();
		waitForSpinnerToBeGone();
		waitElementBeInvisible(pageLoadingSkeleton);
		double quotedAmountAfterRefresh = Double.parseDouble(getTextFromElement(waitElementBeVisible(autopayAmount, 5)).replaceAll("[^0-9.]", EMPTY_STRING));
		fsa.assertEquals(quotedAmountAfterRefresh, initialQuotedAmount, "Quoted amounts are equal before and after refresh");
	}

	public void testAgeScenario(int applicantAge, FarmersSoftAssert fsa) throws Exception {
		fsa.assertEquals(getTextFromElement(listOfCoverageBenefits.get(0)), setExpectedTermMessage(applicantAge), "Guaranteed protection term label");
		verifyTermButtonLabels(applicantAge, fsa);
		if (applicantAge>70) {
			validateEachCoverageValueQuoteAmount("10", fsa);
		} else if (new Random().nextBoolean()) {
			validateCoverageRateForEachTermLevel(fsa);
		} else {
			validateTermRateForEachCoverageValue(fsa);
		}
	}

	private void validateCoverageRateForEachTermLevel(FarmersSoftAssert fsa) throws Exception {
		KnockoutInconveniencePage knockoutPage = new KnockoutInconveniencePage();
		for (String coverageValue : listOfCoverageValues) {
			double initialQuotedAmount = 0.0;
			try {
				selectValueInDropdown(coverageValue, coverageLimitSelectionDropdown, coverageLimitLabel);
				waitForSpinnerToBeGone();
			} catch (Exception e) {
				fsa.fail("Select the coverage value in coverageLimitSelectionDropdown: " + e.getMessage());
			}
			if (knockoutPage.isQuoteKnockedOut()) {
				fsa.fail("Quote got knocked out, can't validate rate change");
				return;
			}
			for (PWElement termLevelButton: listOfPremiumLevelTermButtons) {
				scrollAndClickOnElement(termLevelButton);
				//Automation is too quick, need to give the GUI time to repaint amount
				sleep(1);
				double updatedQuotedAmount = getQuotedAmount();
				fsa.assertTrue(initialQuotedAmount <= updatedQuotedAmount, "validateCoverageRateForEachTermLevel - Rate of " + updatedQuotedAmount + " for coverage of " + coverageValue + " and Term level of "+ getTextFromElement(termLevelButton) + " years greater than or equal to " + initialQuotedAmount);
				initialQuotedAmount = updatedQuotedAmount;
			}
		}
	}

	private void validateTermRateForEachCoverageValue(FarmersSoftAssert fsa) throws Exception {
		for (PWElement termLevelButton: listOfPremiumLevelTermButtons) {
			scrollAndClickOnElement(termLevelButton);
			validateEachCoverageValueQuoteAmount(getTextFromElement(termLevelButton), fsa);
		}
	}

	private void validateEachCoverageValueQuoteAmount(String termLevelButtonLabel, FarmersSoftAssert fsa) throws Exception {
		double initialQuotedAmount = 0.0;
		KnockoutInconveniencePage knockoutPage = new KnockoutInconveniencePage();
		for (String coverageValue : listOfCoverageValues) {
			try {
				selectValueInDropdown(coverageValue, coverageLimitSelectionDropdown, coverageLimitLabel);
				waitForSpinnerToBeGone();
			} catch (Exception e) {
				fsa.fail("Select the coverage value in coverageLimitSelectionDropdown: " + e.getMessage());
			}
			if (knockoutPage.isQuoteKnockedOut()) {
				fsa.fail("Quote got knocked out, can't finish validating the rate change after each value is used");
				break;
			} else {
				double updatedQuotedAmount = getQuotedAmount();
				fsa.assertTrue(initialQuotedAmount < updatedQuotedAmount, "validateTermRateForEachCoverageValue - Rate of " + updatedQuotedAmount + " for Term level of " + termLevelButtonLabel + " years and coverage of " + coverageValue + " greater than " + initialQuotedAmount);
				initialQuotedAmount = updatedQuotedAmount;
			}
		}
	}

	public boolean isOnReviewQuotePage() {
		if (isElementVisible(reviewQuotePageTitle, 2)) {
			isElementVisible(coverageLimitSelectionDropdown, 20);
		}
		return isElementVisible(coverageLimitSelectionDropdown, 10);
	}

	public void saveQuoteForLater(ApplicantLife applicant) throws Exception {
		setPremiumLevelTerm(applicant);
		setCoverageLimit(applicant);
		saveLifeApplicantInHashMap(applicant, getClass().getSimpleName(), getSessionStorageAppStore().getData().getQuoteNumber());
	}

	public void testQuoteRetrieval(ApplicantLife applicant, FarmersSoftAssert fsa) throws Exception {
		fsa.assertEquals(getPremiumLevelTerm(), applicant.getPremiumYears(), "Verify retrieved premium level term years");
		fsa.assertEquals(getCoverageLimit(), applicant.getInsuranceAmount(), "Verify retrieved value of coverage limit");
	}

	private String setExpectedTermMessage(int applicantAge) {
		String termMessage = "Guaranteed financial protection for 10, 15, 20, or 30 years2";
		if (applicantAge > 70) {
			termMessage = "Guaranteed financial protection for 10 years2";
		} else if (applicantAge > 65) {
			termMessage = "Guaranteed financial protection for 10 or 15 years2";
		} else if (applicantAge > 50) {
			termMessage = "Guaranteed financial protection for 10, 15, or 20 years2";
		}
		return termMessage;
	}

	private List<String> setExpectedTermButtonLabels(int applicantAge) {
		List<String> listOfLevelTermButtonLabels = new ArrayList<>();
		if ((applicantAge <= 70) && (applicantAge > 65)) {
			listOfLevelTermButtonLabels.addAll(new ArrayList<>(Arrays.asList("10", "15")));
		} else if ((applicantAge <= 65) && (applicantAge > 50)) {
			listOfLevelTermButtonLabels.addAll(new ArrayList<>(Arrays.asList("10", "15", "20")));
		} else if (applicantAge <= 50){
			listOfLevelTermButtonLabels.addAll(new ArrayList<>(Arrays.asList("10", "15", "20", "30")));
		}
		return listOfLevelTermButtonLabels;
	}

	private void setCoverageLimit(ApplicantLife applicant) throws Exception {
		Random randomNumberGenerator = new Random();
		applicant.setInsuranceAmount(listOfCoverageValues.get(randomNumberGenerator.nextInt(listOfCoverageValues.size())));
		selectValueInDropdown(applicant.getInsuranceAmount(), coverageLimitSelectionDropdown, autopayPlanLabel);
	}

	public String getCoverageLimit() {
		return getTextFromElement(coverageLimitSelectionDropdown);
	}

	private void setPremiumLevelTerm(ApplicantLife applicant) throws Exception {
		List<PWElement> listOfPremiumLevelTermElements = driver().findElements(PWBy.xpath(PREMIUM_LEVEL_TERM_BUTTONS_XPATH + "/span[contains(text(), '"+ applicant.getPremiumYears() + "')]"));
		if (!listOfPremiumLevelTermElements.isEmpty()) {
			scrollAndClickOnElement(listOfPremiumLevelTermElements.get(0));
		}
	}

	public String getPremiumLevelTerm() throws Exception {
		List<PWElement> listOfPremiumLevelTermElements = driver().findElements(PWBy.xpath(PREMIUM_LEVEL_TERM_BUTTONS_XPATH + "[@aria-checked='true']"));
		if (!listOfPremiumLevelTermElements.isEmpty()) {
			return getTextFromElement(listOfPremiumLevelTermElements.get(0));
		} else {
			return EMPTY_STRING;
		}
	}

	public double getQuotedAmount() {
		return Double.parseDouble(getTextFromElement(waitElementBeVisible(autopayAmount, 5)).replaceAll("[^0-9.]", EMPTY_STRING));
	}

	private void verifyTermButtonLabels(int applicantAge, FarmersSoftAssert fsa) {
		List<String> listOfObservedPremiumLevelTermButtonLabels = new ArrayList<>();
		listOfPremiumLevelTermButtons.forEach(termLevelButton -> listOfObservedPremiumLevelTermButtonLabels.add(getTextFromElement(termLevelButton)));
		List<String> listOfLevelTermButtonLabels = setExpectedTermButtonLabels(applicantAge);
		fsa.assertEquals(listOfObservedPremiumLevelTermButtonLabels, listOfLevelTermButtonLabels, "Actual and Expected Term level button labels match");
	}

}
