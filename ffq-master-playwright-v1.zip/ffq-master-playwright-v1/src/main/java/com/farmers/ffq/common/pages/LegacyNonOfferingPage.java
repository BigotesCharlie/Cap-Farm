package com.farmers.ffq.common.pages;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import org.testng.Assert;
/**
 * Farmers Fast Quote (FFQ) - Non Offering States Page - Legacy version.
 * 
 */
public class LegacyNonOfferingPage extends BasePage {
	private PWWait wait;
	
	private static final String MAIN_AREA_ID = "farmers-landing-v2";
	@PWFindBy(id = MAIN_AREA_ID)
	private PWElement mainArea;
	
	private static final String BOX_AREA_ID = "BoxArea";
	@PWFindBy(id = BOX_AREA_ID)
	private PWElement intro;

	private static final String NOT_OFFERED_HEADER_ID = "quote_unavailable_header-title";
	@PWFindBy(id = NOT_OFFERED_HEADER_ID)
	private PWElement notOfferedHeader;

	private static final String FARMERS_DIRECT_PAGE_ID = "root";
	@PWFindBy(id = FARMERS_DIRECT_PAGE_ID)
	private PWElement farmersDirectPage;

	private static final String MEDIA_ALPHA_HEADER_ID = "MediaAlphaHead";
	@PWFindBy(id = MEDIA_ALPHA_HEADER_ID)
	private PWElement mediaAlphaHeader;
	
	private static final String QUOTE_UNAVAILABLE_CONTENT_ID = "quote_unavailable-content";
	@PWFindBy(id = QUOTE_UNAVAILABLE_CONTENT_ID)
	private PWElement quotingUnavailableText;
	
	private static final String QUOTES_TEMPORARILY_UNAVAILABLE_ID = "no-auto-quote_header-title";
	@PWFindBy (id = QUOTES_TEMPORARILY_UNAVAILABLE_ID)
	private PWElement quotingTemporarilyUnavailableHeader;
	
	private static final String DONT_OFFER_INSURANCE = "Sorry, we don't offer insurance in your area.";

	/**
	 * Constructor.
	 * 
	 * @throws Exception 
	 */
	public LegacyNonOfferingPage() throws Exception {
		PWDriver browserDriver = driver();
		PWPageFactory.initElements(browserDriver, this);
		wait = driverWait(60);
	}

	public boolean isNonOfferingTextExist() {
		if (isElementPresent(PWBy.id(NOT_OFFERED_HEADER_ID), 5)) {
			return (getTextFromElement(notOfferedHeader).contains(DONT_OFFER_INSURANCE));
		} else if (isElementPresent(PWBy.id(BOX_AREA_ID), 5)) {
			return getTextFromElement(intro).contains(DONT_OFFER_INSURANCE);
		} else {
			return false;
		}
	}
	
	public boolean isNewNonOfferingPage() throws Exception {
		if (isElementPresent(PWBy.id(MAIN_AREA_ID), 5)) {
			return driver().getPageSource().contains("Thanks for starting your quote online");
		} else {
			return false;
		}
	}
	
	public void verifyBristolWestNonOfferingPage() {
		waitElementBeVisible(intro);
		Assert.assertTrue(getTextFromElement(mediaAlphaHeader).contains("We're sorry - Farmers doesn't currently offer"), "BRISTOL WEST message (first line) is not visible!");
		Assert.assertTrue(getTextFromElement(mediaAlphaHeader).contains("online quoting in your area."), "BRISTOL WEST message (second line) is not visible!");
		Assert.assertTrue(getTextFromElement(mediaAlphaHeader).contains("Please call 1-800-206-9469 to complete this quote."), "BRISTOL WEST call center number is not visible!");
	}
	
	public boolean farmersInsuranceHawaiiState() throws Exception {
		wait.until(presenceOfElementLocated(PWBy.cssSelector("li.slogan")));
		return driver().getPageSource().contains("Farmers Hawaii");
	}
	
	public boolean quotingUnavailableTextExists() {
		if (isElementPresent(PWBy.id(QUOTE_UNAVAILABLE_CONTENT_ID), 3)) {
			return getTextFromElement(quotingUnavailableText).contains("We're sorry, but we are unable to provide an online quote at this time.");
		} else if (isElementPresent(PWBy.id(QUOTES_TEMPORARILY_UNAVAILABLE_ID), 3)) {
			return getTextFromElement(quotingTemporarilyUnavailableHeader).contains("Quotes Temporarily Unavailable");
		} else {
			return false;
		}
	}

	public boolean verifySouthCarolinaOfferingPage() throws Exception {
		if (isElementPresent(PWBy.id(FARMERS_DIRECT_PAGE_ID), 5)) {
			return driver().getCurrentUrl().contains("farmersdirect");
		} else {
			return false;
		}
	}
	
}
