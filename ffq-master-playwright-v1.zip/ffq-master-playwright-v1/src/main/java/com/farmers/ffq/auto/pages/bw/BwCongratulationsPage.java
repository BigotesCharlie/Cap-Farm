package com.farmers.ffq.auto.pages.bw;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.BWCSSRegistrationEnded;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import static com.farmers.ffq.utils.GlobalVariables.MA;

public class BwCongratulationsPage extends AutoBasePage {

    @PWFindAll({
            @PWFindBy(css = "h1[class='mb-10 rebrand-heading']"),
            @PWFindBy(xpath = "//h1[contains(.,'Congratulations')]")
    })
    private PWElement pageTitle;

    @PWFindBy(css = "p[class='tui-field-label-text']")
    private PWElement pageSubTitle;

    @PWFindBy(css = "button[id='download-id-cards']")
    private PWElement downloadIdCardsLink;

    @PWFindBy(id = "download-policy-documents")
    private PWElement downloadPolicyDocuments;

    @PWFindBy(css = "input[formcontrolname='password']")
    private PWElement passwordInput;

    @PWFindBy(css = "button[class='tui-btn tui-btn-primary']")
    private PWElement createAccountButton;

    @PWFindBy(xpath = "//p[@class='text_align' and  contains(.,'created')]")
    private PWElement createdConfirmation;

    @PWFindBy(xpath = "//p[contains(.,'Your account has been created!')]")
    private PWElement yourAccountCreatedConfirmation;

    @PWFindBy(xpath = "//button[contains(.,'Log in to my account')]")
    private PWElement loginToMyAccountButton;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public BwCongratulationsPage() throws Exception {
    }

    public boolean isOnBwCongratsPage() {
        return isElementVisible(downloadIdCardsLink, 45);
    }

    public void validateBwCongratsPage(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        validatePageTitle(fsa, getTheFullNameWithFirstLetterInCaps(applicant.getFirstName()));
        validatePageSubTitle(fsa, applicant.getEmail());
        validateLinks(fsa);
        validateAccountCreation(fsa, applicant);
        if (!applicant.getStateCode().equals(MA)) {
            validatedDownloads(fsa);
        }
    }

    private void validatedDownloads(FarmersSoftAssert fsa) {
        waitAndClickElement(downloadIdCardsLink);
        waitAndClickElement(downloadPolicyDocuments);
    }

    private void validatePageTitle (FarmersSoftAssert fsa, String firstName) {
        fsa.assertTrue(getTextFromElement(pageTitle).equals(String.format("Congratulations, %s!", firstName)) ||
        		getTextFromElement(pageTitle).equals(String.format("Congrats, %s!", firstName)) , "Bw Congrats page title validation");
    }

    private void validatePageSubTitle (FarmersSoftAssert fsa, String emailId) {
        fsa.assertEquals(getTextFromElement(pageSubTitle), String.format("Thank you for insuring with Bristol West Insurance. We sent a confirmation email with your purchase details and policy information to %s.", emailId), "Bw Congrats page sub title validation");
    }

    private void validateLinks(FarmersSoftAssert fsa) {
        fsa.assertTrue(downloadIdCardsLink.isDisplayed() && downloadIdCardsLink.isEnabled(), "Make sure id cards links is displayed and enabled");
        fsa.assertTrue(downloadPolicyDocuments.isDisplayed() && downloadPolicyDocuments.isEnabled(), "Make sure policy documents links is displayed and enabled");
    }

    private void fillOutPasswordInput(String password) {
        sendKeysOneByOne(passwordInput, password);
        Log.info(String.format("Password is entered for Congrats Page Account Creation: %s", password));
    }

    private void clickCreateAccountButton() {
        waitAndClickElement(createAccountButton);
    }

    private void validateAccountCreation(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        fillOutPasswordInput(randomPasswordGenerator());
        clickCreateAccountButton();
        fsa.assertTrue(isElementVisible(yourAccountCreatedConfirmation, 25), "Account created confirmation message validated");
        fsa.assertTrue(isElementVisible(loginToMyAccountButton, 25), "Log in button is visible validation");
        BWCSSRegistrationEnded bwcssRegisterRestServiceEnded = new ApiHelper().getBWCSSRegisterRestServiceEnded(getSessionStorageAppStore().getData().getQuoteNumber());
        fsa.assertEquals(bwcssRegisterRestServiceEnded.getResponseCode(), "-1");
       }

    public void registerUserForAnAccount() {
        fillOutPasswordInput(randomPasswordGenerator());
        clickCreateAccountButton();
        testStepAssert(getTextFromElement(waitElementBeVisible(createdConfirmation)), "Your account has been created!", "Account creation confirmed", true);
        sleep(2);
        waitForSpinnerToBeGone();
    }

    public void validateNavigateBackFromBWCongratsPage(FarmersSoftAssert fsa) throws Exception {
        this.navigateBack();
        // user should not be able to come back to payment summary page after navigating back from congrats page
        fsa.assertTrue(!new BwPaymentSummaryPage().isOnBwPaymentSummaryPage(), "User can't navigate back to the payment page from BW Congrats page");
    }

}
