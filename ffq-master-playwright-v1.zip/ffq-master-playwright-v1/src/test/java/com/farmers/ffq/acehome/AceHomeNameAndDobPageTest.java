package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCNameAndDobBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeNameAndDobPageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ABOUT_YOU_PAGE})
    public void testContentValidationNameAndDobPageHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCNameAndDobBasePage nameAndDobBasePage = new AceHomeNavigationHelper().navigateToAceHomeNameAndDobPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        nameAndDobBasePage.validateContentOfPrimaryApplicant(fsa);
        nameAndDobBasePage.validateDisclaimers(fsa, applicant.getStateCode(), HOME);
        fsa.assertAll("Ace Home - Address and DOB page content validation");
    }
}
