package com.farmers.ffq.acemobilehome;

import static com.farmers.ffq.utils.GlobalVariables.AK;
import static com.farmers.ffq.utils.GlobalVariables.FL;
import static com.farmers.ffq.utils.GlobalVariables.EMPTY_STRING;
import static com.farmers.ffq.utils.GlobalVariables.FFQ_MOBILE_HOME;
import static com.farmers.ffq.utils.GlobalVariables.LOB_MOBILE_HOME;
import static com.farmers.ffq.utils.GlobalVariables.PEWC;
import static com.farmers.ffq.utils.GlobalVariables.TRUE;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.farmers.ffq.ace.mobilehome.AceMobileHomeAddressPage;
import com.farmers.ffq.ace.mobilehome.AceMobileHomeLastStepPage;
import com.farmers.ffq.ace.mobilehome.AceMobileHomeNavigationHelper;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.dataproviders.SqlDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.State;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.Property;

public class AceMobileHomeQuoteScenarioTests extends AutomationFramework {
	@Test(dataProviderClass = SqlDataProviders.class, dataProvider = SqlDataProviders.STATES_DATA_PROVIDER_NAME, groups = FFQ_MOBILE_HOME)
	public void verifyStateSupportForMobileHome(State state) throws Exception {
		String applicantStateCode = state.getStateCode();
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		LandingPage landingPage = new LandingPage(false,true);
		boolean doesStateSupportMobileHome = DataProviders.getListOfAceMobileHomeStates(Property.getUri()).contains(applicantStateCode);
		if (landingPage.isLOBButtonAvailable(LOB_MOBILE_HOME)) {
			landingPage.enterLandingPageDataAndContinue(LOB_MOBILE_HOME, state.getZipCode());
	    	switch (applicantStateCode) {
	    		case AK:
	    			fsa.assertEquals(landingPage.getTextFromElement(new KnockoutInconveniencePage().getForemostKnockoutPageTitle()), "Thank you for your interest in Foremost", "Correct knockout message displayed for " + state.getStateName());
	    			break;
	    		case FL:
	    			fsa.assertTrue(driver().getCurrentUrl().contains("fgia"), "Continue with Farmers General Insurance Agency page displayed for " + state.getStateName());
	    			break;
	    		default:
	    			fsa.assertEquals(new AceMobileHomeAddressPage().isOnAddressPage(), doesStateSupportMobileHome, "Mobile home is " + (doesStateSupportMobileHome? EMPTY_STRING : "not ") + "supported in " + state.getStateName());
	    	}
		} else {
			throw new SkipException("Environment " + Property.getTestProperty("environment") + " is not enabled for Mobile Home");
		}
		fsa.assertAll();
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {PEWC})
	public void aceMobilehomePEWCScreen(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileHomeNavigationHelper().navigateToLastStepPage(mobilehomeApplicant).capturePEWC("AceMobilehome_LastStepPage");
		testStep("End Of Test");
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void createAnAceMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileCommonTestHelper(mobilehomeApplicant).createMobilehomeQuote(mobilehomeApplicant);
		testStep("End Of Test");
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void expectedDiscountVerification(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileCommonTestHelper(mobilehomeApplicant).expectedDiscountVerification(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void noPrimaryHeatSourceButHasSecondaryTest(ApplicantAceHome mobilehomeApplicant) throws Exception {
		mobilehomeApplicant.setPrimaryHeatingSource("No primary heat source");
		mobilehomeApplicant.setSecondaryHeatingSource(TRUE);
		AceMobileHomeLastStepPage lastStepPage = new AceMobileHomeNavigationHelper().navigateToLastStepPage(mobilehomeApplicant);
		lastStepPage.fillOutLastStepPageAndContinue(mobilehomeApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		if (!lastStepPage.isOnContactInfoPage(false)) {
			KnockoutInconveniencePage knockoutPage = new KnockoutInconveniencePage();
			fsa.assertTrue(knockoutPage.isOnForemostKnockoutPage(), "Quote knocked out");
		} else {
			fsa.fail("Quote remained in last step page");
		}
		fsa.assertAll();
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void retrieveRatedQuotePageValidationTest(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileCommonTestHelper(mobilehomeApplicant).retrievedQuotePageValidation(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void retrieveNonRatedQuoteKnockoutTest(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileCommonTestHelper(mobilehomeApplicant).retrieveQuoteBeforeItWasRated(mobilehomeApplicant);
	}

}
