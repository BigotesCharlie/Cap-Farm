package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyInfoBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoPropertyInfoPageValidationTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, OH, OR, TX, UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL})
    public void testPropertyInfoPageCondo(ApplicantAceHome applicant) throws Exception {
        AceHRCPropertyInfoBasePage propertyInfoPage = new AceCondoNavigationHelper().navigateToAceCondoPropertyInfoPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(propertyInfoPage.isPageTitleDisplayed(), "Property Info page - Page title is displayed.");
        fsa.assertTrue(propertyInfoPage.isPageTitleInViewport(), "Property Info page - Page title is in Viewport.");
        propertyInfoPage.validatePageLinksText(fsa, ENTER_INFO);
        propertyInfoPage.validatePageFormFields(fsa, CONDO);
        fsa.assertAll("Validate Ace Condo Property Info page.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, OH, OR, TX, UT})}, groups = {FFQ_ACE_CONDO})
    public void testPropertyInfoPageErrorMessageCondo(ApplicantAceHome applicant) throws Exception {
        AceHRCPropertyInfoBasePage propertyInfoPage = new AceCondoNavigationHelper().navigateToAceCondoPropertyInfoPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        propertyInfoPage.validateCurrentOrPriorHomeAddressErrorMessage(fsa);
        fsa.assertAll("Validate Ace Condo Property Info page error messages");
    }

}
