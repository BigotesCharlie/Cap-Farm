package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeBankDebitCreditCardPaymentTest extends AutomationFramework {
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL})
    public void testValidateContentAndErrorsForPayInFullBankAndDebitCreditIFrameAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHomeNavigationHelper().navigateToPayInFullPaymentPageAceHome(applicantAceHome, LOB_HOME, HOME);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.clickSetUpPaymentButton();
        AppStore appStore = policyPaymentBasePage.getSessionStorageAppStore();
        aceHRCPaymentBasePage.validateContentOfBankPaymentInIFrame(fsa, appStore.getData().getCustomerData() , HOME);
        aceHRCPaymentBasePage.validateBankPaymentErrorsInIFrame(fsa, HOME);
        aceHRCPaymentBasePage.validateContentOfDebitCreditCardPaymentInIframe(fsa, appStore.getData().getCustomerData(), HOME);
        aceHRCPaymentBasePage.validateDebitCreditCardPaymentErrorsInIFrame(fsa, HOME);
        fsa.assertAll();
    }
}
