package com.farmers.ffq.acelife;

import com.farmers.ffq.ace.life.AceLifeNameAndDOBPage;
import com.farmers.ffq.ace.life.AceLifeNavigationHelper;
import com.farmers.ffq.ace.life.AceLifePersonalInfoPage;
import com.farmers.ffq.ace.life.AceLifeReviewQuotePage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantLife;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.Test;

import java.util.Random;

import static com.farmers.ffq.utils.GlobalVariables.ACE_LIFE_PERSONAL_INFO_PAGE;
import static com.farmers.ffq.utils.GlobalVariables.AWS_SCENARIOS;
import static com.farmers.ffq.utils.GlobalVariables.ENTER_INFO;
import static com.farmers.ffq.utils.GlobalVariables.FFQ_ACE_LIFE;

public class AceLifeReviewQuotePageTests extends AutomationFramework {
	@Test(dataProvider = DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE, ACE_LIFE_PERSONAL_INFO_PAGE})
	public void aceLifeReviewQuotePageContentVerification(ApplicantLife applicant) throws Exception {
		if (new Random().nextBoolean()) {
			applicant.setId(AWS_SCENARIOS);
		}
		applicant.setAge(new Random().nextInt(75-18)+18);
		AceLifeReviewQuotePage lifeReviewQuotePage = new AceLifeNavigationHelper().navigateToAceLifeReviewQuotePage(applicant);
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		lifeReviewQuotePage.contentValidation(applicant, farmersSoftAssert);
		if (applicant.getId().equals(AWS_SCENARIOS)) {
			lifeReviewQuotePage.validateTFNIsNotDisplayedInAgentFlow(farmersSoftAssert);
		}
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE, ACE_LIFE_PERSONAL_INFO_PAGE})
	public void aceLifeReviewQuoteStepperBackNavigationAndContinueForwardValidation(ApplicantLife applicant) throws Exception {
		AceLifeReviewQuotePage lifeReviewQuotePage = new AceLifeNavigationHelper().navigateToAceLifeReviewQuotePage(applicant);
		String originalTerm = lifeReviewQuotePage.getPremiumLevelTerm();
		String originalCoverage = lifeReviewQuotePage.getCoverageLimit();
		double originalQuoted = lifeReviewQuotePage.getQuotedAmount();
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		lifeReviewQuotePage.selectStepper(ENTER_INFO);
		AceLifeNameAndDOBPage nameAndDobPage = new AceLifeNameAndDOBPage();
		if (nameAndDobPage.isOnNameAndDOBPage()) {
			nameAndDobPage.verifyFieldsAreSetAndDisabled(applicant, farmersSoftAssert);
			nameAndDobPage.clickOnContinueButton();
			AceLifePersonalInfoPage personalInfoPage = new AceLifePersonalInfoPage();
			if (personalInfoPage.isOnPersonalInfoPage()) {
				personalInfoPage.retrievedQuoteContentValidation(applicant, farmersSoftAssert);
				personalInfoPage.clickOnAgreeAndSubmitButton();
				if (lifeReviewQuotePage.isOnReviewQuotePage()) {
					farmersSoftAssert.assertEquals(lifeReviewQuotePage.getPremiumLevelTerm(), originalTerm, "Check original Selected Term value persisted");
					farmersSoftAssert.assertEquals(lifeReviewQuotePage.getCoverageLimit(), originalCoverage, "Check original Selected Coverage value persisted");
					farmersSoftAssert.assertEquals(lifeReviewQuotePage.getQuotedAmount(), originalQuoted, "Check original quoted amount persisted");
				}
			} else {
				farmersSoftAssert.fail("Did not continue forward to Personal Info page");
			}
		} else {
			farmersSoftAssert.fail("Did not step back to Name and DOB page");
		}
		farmersSoftAssert.assertAll();
	}
}
