package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCAddressBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCCallForQuotePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;


/**
 * Farmers Fast Quote (FFQ) - Call for Quote to FFQ Integration Scenario.
 */
public class AceCondoCallForQuoteTest extends AutomationFramework {

	private static final String GROUP = "BANK OF AMERICA";

	// Including some states which are applicable for Employer/group affinity discount.
	@Skip // Skipping the test cases as EG project code is enabled for most of the states
	@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, AL, GA, IL, OH, VA})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE})
	public void testCallForQuoteToAceReviewQuoteCondoLob(ApplicantAceHome applicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		applicant.setAgentId(null);
		AceCondoNavigationHelper navigator = new AceCondoNavigationHelper();
		AceHRCAddressBasePage aceHRCAddressBasePage = navigator.navigateToAceCondoAddressPage(applicant);
		aceHRCAddressBasePage.enterAddress(applicant);
		aceHRCAddressBasePage.enterAvailableFields(applicant);
		aceHRCAddressBasePage.acceptCookies();
		Assert.assertTrue(aceHRCAddressBasePage.isCheckYourEligibilityLinkDisplayed(fsa), "Check your eligibility link is not displayed for employer affinity - Condo");
		aceHRCAddressBasePage.setEmployerGroup(GROUP);
		fsa.assertEquals(aceHRCAddressBasePage.getSelectedEmployerName(), GROUP, "Employer group name is not displayed.");
		aceHRCAddressBasePage.clickContinueButton();
		aceHRCAddressBasePage.waitForSpinnerToBeGone();
		new AceHRCCallForQuotePage().validateCallForQuote(applicant, GROUP, fsa);

		AceHRCAddressBasePage addressPage = new AceHRCAddressBasePage();
		Assert.assertTrue(addressPage.isOnAddressPage(true), "Did not Reach to Address page when navigating back from Call for Quote page.");
		fsa.assertFalse(addressPage.isCheckYourEligibilityLinkDisplayed(fsa), "Back to Address page - No Employer question anymore.");
		navigator.setResumeFromPage(AceHRCBasePage.ADDRESS_PAGE);
		navigator.navigateToAceCondoReviewQuotePage(applicant);
		fsa.assertAll();
	}
}