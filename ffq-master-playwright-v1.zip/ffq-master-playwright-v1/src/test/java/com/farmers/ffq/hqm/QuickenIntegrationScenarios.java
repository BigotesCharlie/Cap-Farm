package com.farmers.ffq.hqm;

import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.hqm.*;
import com.farmers.ffq.hqm.pages.*;
import com.farmers.ffq.utils.AESHelper;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.Mailinator;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Quote Integration Scenarios - Home Quote Modernization (HQM).
 */
public class QuickenIntegrationScenarios extends AutomationFramework {

    private static final String NO_LAST_NAME = "no_lastName";
	private static final String NO_PHONE = "no_phone";
	private static final String NO_EMAIL = "no_email";
	private static final String QUOTE_PAGE_QUICKEN = "Quote Page - Quicken ";
	private static final String QUOTE_PAGE_EMAIL_TO_CUSTOMER_TEMPLATE = "Quote Page - Email To Customer Template.";
	private static final String CUSTOMER_EMAIL_ID = "CustomerEmailId";
	private static final String CUSTOMER_FIRST_NAME = "CustomerFirstName";
	private static final String ADDRESS_PAGE_QUICKEN = "Address Page - Quicken ";
	private static final Double quoteDelta = 0.30; // quote price fluctuation delta max (used when no Postgres connection)

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_QUICKEN, HQM_ALL})
    public void testQuickenAllData(ApplicantHQM applicant) throws Exception {
        createHomeQuoteFromQuickenLead(applicant, QQ);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_QUICKEN, HQM_ALL})
    public void testQuickenNoPpcSrc(ApplicantHQM applicant) throws Exception {
        createHomeQuoteFromQuickenLead(applicant, QQNPS);
    }

    private void  createHomeQuoteFromQuickenLead(ApplicantHQM applicant, String leadType) throws Exception {
//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, leadType, DESKTOP_BROWSER);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.setPolicyStartDateInFuture(applicant);
        addressPage.verifyPageFields(applicant, fsa);
        PageLinksHQM addressPageLinks = new PageLinksHQM("addressPage", applicant, QQ, false);
        addressPage.validatePageLinks(addressPageLinks, quoteNumber, fsa);
        StaticContentHQM staticContent = new ApiHelper().getStaticContentFromJson(quoteNumber);
        addressPage.validatePageTitlesSubtitles(applicant, "quickenConsent", fsa, staticContent);
        addressPage.validatePageFooters(applicant.stateCode, QQ, staticContent);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        ApiHelper apiHelper = new ApiHelper();
        EmailHQM email = apiHelper.getEmailRequestFromJson(quoteNumber);
        NotificationHQM notification = apiHelper.getNotificationRequestFromJson(quoteNumber);
        fsa.assertEquals(email.getTemplateName(), "Quicken_Welcome", "Address Page - Quicken Welcome Email Template.");
        fsa.assertEquals(email.getRecipientContactPoint(), applicant.emailAddress, "Address Page - Quicken Welcome Email Contact Point.");
        fsa.assertEquals(email.getDynamicPropertyByName(CUSTOMER_FIRST_NAME), applicant.firstName, ADDRESS_PAGE_QUICKEN +
                "Welcome Email Customer First Name.");
        fsa.assertEquals(email.getDynamicPropertyByName(CUSTOMER_EMAIL_ID), applicant.emailAddress, ADDRESS_PAGE_QUICKEN +
                "Welcome Email Customer Email Id.");
        fsa.assertEquals(notification.getMessageText(), String.format("Hello, %s. Thank you for choosing Farmers\u00ae for " +
                "your Home Insurance needs. A Farmers\u00ae licensed representative will be in contact with you shortly, " +
                "or you can call us directly at %s Note: This is a one-time text communication from FARMERS Insurance.",
                applicant.firstName, CALL_FARMERS_QUICKEN), "Address Page - Quicken Welcome Notification Text Message.");
        fsa.assertEquals(notification.getMobileNumbers().get(0), "1" + applicant.phoneNumber, "Address Page - Quicken Welcome " +
                "Notification Text Message Phone Number.");
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        PrefillResponseHQM propertyData = new ApiHelper().getPropertyData(applicant, quoteNumber, null);
        PageLinksHQM propertyPageLinks = new PageLinksHQM("propertyPage", applicant, QQ, false);
        propertyPageLinks.buttonNext = (propertyPage.getYearBuilt().isEmpty() || propertyPage.getSquareFeet().isEmpty()) ? 2 : 3;
        propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);
        propertyPage.validatePageTitles(fsa, staticContent);
        propertyPage.validatePageFooters(staticContent);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        List<String> discounts = propertyPage.getDiscounts();
        propertyPage.clickNext();

//       Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        propertyData = new ApiHelper().getPropertyData(applicant, quoteNumber, propertyData);
        if (applicant.keep360Prefill) {
            qualityPage.verifyPageFields(applicant, propertyData);
        } else {
            qualityPage.selectQualityGrade(applicant, propertyData);
        }
        PageLinksHQM qualityPageLinks = new PageLinksHQM("qualityPage", applicant, QQ, false);
        qualityPageLinks.buttonNext = qualityPage.getSelected().isEmpty() ? 2 : 3;
        qualityPage.validatePageLinks(qualityPageLinks, quoteNumber, fsa);
        qualityPage.validatePageTitles(fsa, staticContent);
        qualityPage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityPage.validatePageFooters(staticContent);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        PageLinksHQM propertyDetailsPageLinks = new PageLinksHQM("propertyDetailsPage", applicant, QQ, false);
        propertyDetailsPageLinks.buttonNext = propertyDetailsPage.isNextButtonEnabled(applicant.stateCode) ? 3 : 2;
        propertyDetailsPage.validatePageLinks(propertyDetailsPageLinks, quoteNumber, fsa);
        propertyDetailsPage.validatePageTitles(applicant, fsa, staticContent);
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        PageLinksHQM customerInfoPageLinks = new PageLinksHQM("customerInfoPage", applicant, QQ, false);
        customerInfoPageLinks.buttonNext = (applicant.maritalStatus.equalsIgnoreCase("married")) ? 2 : 3;
        customerInfoPage.validatePageLinks(customerInfoPageLinks, quoteNumber, fsa);
        customerInfoPage.setRequiredFieldsQuicken(applicant, null);
        customerInfoPage.validatePageFieldContents(applicant, false, fsa);
        customerInfoPage.validatePageTitles(applicant, fsa, staticContent);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        PageLinksHQM contactInfoPageLinks = new PageLinksHQM("contactInfoPage", applicant, QQ, false);
        contactInfoPageLinks.buttonNext = 3;
        contactInfoPage.validatePageLinks(contactInfoPageLinks, quoteNumber, fsa);
        contactInfoPage.validatePageFieldContents(applicant, false, fsa);
        contactInfoPage.validatePageTitles(applicant, fsa, staticContent);
        contactInfoPage.validatePageFooters(applicant, QQ, staticContent);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        PageLinksHQM discountsPageLinks = new PageLinksHQM("discountsPage", applicant, QQ, false);
        discountsPage.validatePageLinks(discountsPageLinks, quoteNumber, fsa);
        List<String> discountsBeforeRate = new ApiHelper().getDiscountsFromJsonBeforeRate(quoteNumber);
        discountsPage.validatePageFieldContents(applicant, true, fsa, discountsBeforeRate);
        discountsPage.validatePreappliedDiscountsBeforeRate(applicant, discountsBeforeRate, fsa);
        discountsPage.validatePageTitles(!discountsBeforeRate.isEmpty(), fsa, staticContent);
        discountsPage.validatePageSubtitles(applicant, !discountsBeforeRate.isEmpty(), staticContent);
        discountsPage.setRequiredFields(applicant);
        discountsPage.validatePageFieldContents(applicant, false, fsa, null);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
//           Quote Page
            QuotePage quotePage = new QuotePage();
            PageLinksHQM quotePageLinks = new PageLinksHQM("quotePage", applicant, QQ, true);
            quotePage.validatePageLinks(quotePageLinks, quoteNumber, fsa);
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            quotePage.validatePageTitles(quoteRate, fsa, staticContent);
            quotePage.validatePageFooters(applicant, staticContent);
            quotePage.validatePolicyPerks(applicant);
//            quotePage.validatePolicyFloAd(applicant, QQ);
            quotePage.validatePageCardTitles(applicant, quoteRate, true, QQ, fsa);
            quotePage.validateSendEmail(applicant, fsa);
            EmailHQM email2 = apiHelper.getEmailRequestFromJson(quoteNumber);
            if (!quotePage.isEasternExpansionState(applicant.stateCode)) {
                fsa.assertEquals(email2.getTemplateName(), "EMAILTOCUSTOMER", QUOTE_PAGE_EMAIL_TO_CUSTOMER_TEMPLATE);
            } else {
                fsa.assertEquals(email2.getTemplateName(), "EE_EMAILTOCUSTOMER", QUOTE_PAGE_EMAIL_TO_CUSTOMER_TEMPLATE);
            }
            fsa.assertEquals(email2.getRecipientContactPoint(), applicant.emailAddress, "Quote Page - Send Email Contact Point.");
            fsa.assertEquals(email2.getDynamicPropertyByName("QuoteNumber"), quoteNumber, "Quote Page - " +
                    "Send Email To Customer Quote Number.");
            fsa.assertEquals(email2.getDynamicPropertyByName(CUSTOMER_FIRST_NAME), applicant.firstName, "Quote Page - " +
                    "Send Email To Customer First Name.");
            fsa.assertEquals(email2.getDynamicPropertyByName("CustomerLastName"), applicant.lastName, QUOTE_PAGE_QUICKEN +
                    "Send Email To Customer Last Name.");
            fsa.assertEquals(email2.getDynamicPropertyByName(CUSTOMER_EMAIL_ID), applicant.emailAddress, QUOTE_PAGE_QUICKEN +
                    "Send Email To Customer Email Id.");
            quotePage.validateQuoteDiscounts(applicant, fsa, quoteRate);
            quotePage.validateQuotePremiums(applicant, quoteRate, quoteDelta, fsa);
            String quotePremiumYearly = quotePage.getQuotePremiumYearly(applicant.stateCode);
            String monthlyPremium = quotePage.getQuotePremiumMonthly();
            String reconstructionCost = quotePage.getQuoteReconstructionCost();
            quotePage.clickQuoteDetails();

            QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
            quoteDetailsPage.validatePageTitlesSubtitles(applicant, fsa, quoteRate, quoteDelta, quotePremiumYearly, staticContent);
            quoteDetailsPage.validateStandardPackageSliders(applicant, quoteRate, reconstructionCost, fsa);
            quoteDetailsPage.clickCloseModal();

            quotePage = new QuotePage();
            quotePage.clickNext();

//           Thank You Page
            ThankYouPage thankYouPage = new ThankYouPage();
            PageLinksHQM thankYouPageLinks = new PageLinksHQM("thankYouPage", applicant.stateCode);
            thankYouPage.validatePageLinks(thankYouPageLinks, quoteNumber, fsa);
            thankYouPage.validatePageValues(applicant, monthlyPremium, fsa, quoteRate);
            thankYouPage.validatePageTitles(applicant, QQ, fsa, staticContent);
            thankYouPage.validatePageFooters(applicant, QQ, fsa);

            if (applicant.emailCheck) {
                Mailinator.validateHqmEmails(applicant, null, true);
            }
        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, QQ, fsa);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_QUICKEN, HQM_ALL})
    public void  testQuickenNoEmail(ApplicantHQM applicant) throws Exception {
        createQuickenQuoteWithMissingData(applicant, NO_EMAIL);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_QUICKEN, HQM_ALL})
    public void  testQuickenNoPhone(ApplicantHQM applicant) throws Exception {
        createQuickenQuoteWithMissingData(applicant, NO_PHONE);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_QUICKEN, HQM_ALL})
    public void  testQuickenNoEmailNoPhone(ApplicantHQM applicant) throws Exception {
        createQuickenQuoteWithMissingData(applicant, "no_email,no_phone");
    }

    private void  createQuickenQuoteWithMissingData(ApplicantHQM applicant, String missingData) throws Exception {
//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        new LandingPage(applicant.zipCode, new LeadTypeHQM(applicant, QQ, missingData), DESKTOP_BROWSER);
        AddressPage addressPage = new AddressPage();
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.setPolicyStartDateInFuture(applicant);
        addressPage.verifyPageFields(applicant, fsa);
        PageLinksHQM addressPageLinks = new PageLinksHQM("addressPage", applicant, QQ, false);
        addressPage.validatePageLinks(addressPageLinks, quoteNumber, fsa);
        ApiHelper apiHelper = new ApiHelper();
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        if (missingData.contains(NO_LAST_NAME)) {
            addressPage.validatePageTitlesSubtitles(applicant, "quickenNoConsent", fsa, staticContent);
        } else {
            addressPage.validatePageTitlesSubtitles(applicant, "quickenConsent", fsa, staticContent);
        }
        addressPage.validatePageFooters(applicant.stateCode, QQ, staticContent);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        EmailHQM email = apiHelper.getEmailRequestFromJson(quoteNumber);
        NotificationHQM notification = apiHelper.getNotificationRequestFromJson(quoteNumber);
        fsa.assertEquals(email, null, "Address Page - Quicken Welcome Email did not go out.");
        fsa.assertEquals(notification, null, "Address Page - Quicken Welcome Notification Text did not go out.");
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        PageLinksHQM propertyPageLinks = new PageLinksHQM("propertyPage", applicant, QQ, false);
        propertyPageLinks.buttonNext = (propertyPage.getYearBuilt().isEmpty() || propertyPage.getSquareFeet().isEmpty()) ? 2 : 3;
        propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);
        propertyPage.validatePageTitles(fsa, staticContent);
        propertyPage.validatePageFooters(staticContent);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        List<String> discounts = propertyPage.getDiscounts();
        propertyPage.clickNext();

//       Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        if (applicant.keep360Prefill) {
            qualityPage.verifyPageFields(applicant, propertyData);
        } else {
            qualityPage.selectQualityGrade(applicant, propertyData);
        }
        PageLinksHQM qualityPageLinks = new PageLinksHQM("qualityPage", applicant, QQ, false);
        qualityPageLinks.buttonNext = qualityPage.getSelected().isEmpty() ? 2 : 3;
        qualityPage.validatePageLinks(qualityPageLinks, quoteNumber, fsa);
        qualityPage.validatePageTitles(fsa, staticContent);
        qualityPage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityPage.validatePageFooters(staticContent);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        PageLinksHQM propertyDetailsPageLinks = new PageLinksHQM("propertyDetailsPage", applicant, QQ, false);
        propertyDetailsPageLinks.buttonNext = propertyDetailsPage.isNextButtonEnabled(applicant.stateCode) ? 3 : 2;
        propertyDetailsPage.validatePageLinks(propertyDetailsPageLinks, quoteNumber, fsa);
        propertyDetailsPage.validatePageTitles(applicant, fsa, staticContent);
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        PageLinksHQM customerInfoPageLinks = new PageLinksHQM("customerInfoPage", applicant, QQ, false);
        customerInfoPageLinks.buttonNext = (applicant.maritalStatus.equalsIgnoreCase("married") ||
                                                                 missingData.contains(NO_LAST_NAME)) ? 2 : 3;
        customerInfoPage.validatePageLinks(customerInfoPageLinks, quoteNumber, fsa);
//        customerInfoPage.setRequiredFieldsQuicken(applicant, null);
        String blankNameParm = null;
        if (missingData.contains(NO_LAST_NAME)) {
        	blankNameParm = "lastName";
        }
        customerInfoPage.setRequiredFieldsQuicken(applicant, blankNameParm);
        customerInfoPage.validatePageFieldContents(applicant, false, fsa);
        customerInfoPage.validatePageTitles(applicant, fsa, staticContent);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        PageLinksHQM contactInfoPageLinks = new PageLinksHQM("contactInfoPage", applicant, QQ, false);
        contactInfoPageLinks.buttonNext = missingData.contains(NO_EMAIL) || missingData.contains(NO_PHONE) ? 2 : 3;
        contactInfoPage.validatePageLinks(contactInfoPageLinks, quoteNumber, fsa);
        if (missingData.contains(NO_EMAIL) && missingData.contains(NO_PHONE)) {
            fsa.assertEquals(contactInfoPage.getEmailText(), "", "Contact Info page - email address field is blank");
            fsa.assertEquals(contactInfoPage.getPhoneNumber(), "", "Contact Info page - phone number field is blank");
            contactInfoPage.setRequiredFields(applicant);
        } else if (missingData.equals(NO_EMAIL)) {
            Assert.assertEquals(contactInfoPage.getEmailText(), "", "Contact Info page - email address field is blank");
            contactInfoPage.setEmail(applicant.emailAddress);
        } else if (missingData.equals(NO_PHONE)) {
            Assert.assertEquals(contactInfoPage.getPhoneNumber(), "", "Contact Info page - phone number field is blank");
            contactInfoPage.setPhoneNumber(applicant.phoneNumber);
        }
        contactInfoPage.validatePageFieldContents(applicant, false, fsa);
        contactInfoPage.validatePageTitles(applicant, fsa, staticContent);
        contactInfoPage.validatePageFooters(applicant, QQ, staticContent);
        contactInfoPage.clickNext();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        email = apiHelper.getEmailRequestFromJson(quoteNumber);
        notification = apiHelper.getNotificationRequestFromJson(quoteNumber);
        fsa.assertEquals(email.getTemplateName(), "Quicken_Welcome", "Address Page - Quicken Welcome Email Template.");
        fsa.assertEquals(email.getRecipientContactPoint(), applicant.emailAddress, "Address Page - Quicken Welcome Email Contact Point.");
        fsa.assertEquals(email.getDynamicPropertyByName(CUSTOMER_FIRST_NAME), applicant.firstName, ADDRESS_PAGE_QUICKEN +
                "Welcome Email Customer First Name.");
        fsa.assertEquals(email.getDynamicPropertyByName(CUSTOMER_EMAIL_ID), applicant.emailAddress, ADDRESS_PAGE_QUICKEN +
                "Welcome Email Customer Email Id.");
        fsa.assertEquals(notification.getMessageText(), String.format("Hello, %s. Thank you for choosing Farmers\u00ae for " +
                        "your Home Insurance needs. A Farmers\u00ae licensed representative will be in contact with you shortly, " +
                        "or you can call us directly at %s Note: This is a one-time text communication from FARMERS Insurance.",
                applicant.firstName, CALL_FARMERS_QUICKEN), "Address Page - Quicken Welcome Notification Text Message.");
        fsa.assertEquals(notification.getMobileNumbers().get(0), "1" + applicant.phoneNumber, "Address Page - Quicken Welcome " +
                "Notification Text Message Phone Number.");
        PageLinksHQM discountsPageLinks = new PageLinksHQM("discountsPage", applicant, QQ, false);
        discountsPage.validatePageLinks(discountsPageLinks, quoteNumber, fsa);
        List<String> discountsBeforeRate = apiHelper.getDiscountsFromJsonBeforeRate(quoteNumber);
        discountsPage.validatePageFieldContents(applicant, true, fsa, discountsBeforeRate);
        discountsPage.validatePreappliedDiscountsBeforeRate(applicant, discountsBeforeRate, fsa);
        discountsPage.validatePageTitles(!discountsBeforeRate.isEmpty(), fsa, staticContent);
        discountsPage.validatePageSubtitles(applicant, !discountsBeforeRate.isEmpty(), staticContent);
        discountsPage.setRequiredFields(applicant);
        discountsPage.validatePageFieldContents(applicant, false, fsa, null);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
//           Quote Page
            QuotePage quotePage = new QuotePage();
            PageLinksHQM quotePageLinks = new PageLinksHQM("quotePage", applicant, QQ, true);
            quotePage.validatePageLinks(quotePageLinks, quoteNumber, fsa);
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            quotePage.validatePageTitles(quoteRate, fsa, staticContent);
            quotePage.validatePageFooters(applicant, staticContent);
            quotePage.validatePolicyPerks(applicant);
//            quotePage.validatePolicyFloAd(applicant, QQ);
            quotePage.validatePageCardTitles(applicant, quoteRate, true, QQ, fsa);

            // Send Email button on the Quote page
            quotePage.validateSendEmail(applicant, fsa);
            EmailHQM email2 = apiHelper.getEmailRequestFromJson(quoteNumber);
            if (quotePage.isEasternExpansionState(applicant.stateCode)) {
                fsa.assertEquals(email2.getTemplateName(), "EE_EMAILTOCUSTOMER", QUOTE_PAGE_EMAIL_TO_CUSTOMER_TEMPLATE);
            } else {
                fsa.assertEquals(email2.getTemplateName(), "EMAILTOCUSTOMER", QUOTE_PAGE_EMAIL_TO_CUSTOMER_TEMPLATE);
            }
            fsa.assertEquals(email2.getRecipientContactPoint(), applicant.emailAddress, "Quote Page - Send Email Contact Point.");
            fsa.assertEquals(email2.getDynamicPropertyByName("QuoteNumber"), quoteNumber, "Quote Page - " +
                    "Send Email To Customer Quote Number.");
            fsa.assertEquals(email2.getDynamicPropertyByName(CUSTOMER_FIRST_NAME), applicant.firstName, "Quote Page - " +
                    "Send Email To Customer First Name.");
            fsa.assertEquals(email2.getDynamicPropertyByName("CustomerLastName"), applicant.lastName, QUOTE_PAGE_QUICKEN +
                    "Send Email To Customer Last Name.");
            fsa.assertEquals(email2.getDynamicPropertyByName(CUSTOMER_EMAIL_ID), applicant.emailAddress, QUOTE_PAGE_QUICKEN +
                    "Send Email To Customer Email Id.");
            quotePage.validateQuoteDiscounts(applicant, fsa, quoteRate);
            quotePage.validateQuotePremiums(applicant, quoteRate, quoteDelta, fsa);
            String quotePremiumYearly = quotePage.getQuotePremiumYearly(applicant.stateCode);
            String monthlyPremium = quotePage.getQuotePremiumMonthly();
            String reconstructionCost = quotePage.getQuoteReconstructionCost();
            quotePage.clickQuoteDetails();

            QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
            quoteDetailsPage.validatePageTitlesSubtitles(applicant, fsa, quoteRate, quoteDelta, quotePremiumYearly, staticContent);
            quoteDetailsPage.validateStandardPackageSliders(applicant, quoteRate, reconstructionCost, fsa);
            quoteDetailsPage.clickCloseModal();
            quotePage = new QuotePage();
            quotePage.clickNext();

//           Thank You Page
            ThankYouPage thankYouPage = new ThankYouPage();
            PageLinksHQM thankYouPageLinks = new PageLinksHQM("thankYouPage", applicant.stateCode);
            thankYouPage.validatePageLinks(thankYouPageLinks, quoteNumber, fsa);
            thankYouPage.validatePageValues(applicant, monthlyPremium, fsa, quoteRate);
            thankYouPage.validatePageTitles(applicant, QQ, fsa, staticContent);
            thankYouPage.validatePageFooters(applicant, QQ, fsa);

            if (applicant.emailCheck) {
                Mailinator.validateHqmEmails(applicant, null, true);
            }
        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, QQ, fsa);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_QUICKEN, HQM_ALL})
    public void  testQuickenNoLastName(ApplicantHQM applicant) throws Exception {
        createQuickenQuoteWithMissingData(applicant, NO_LAST_NAME);
    }


    @Skip
    @Test(groups={HQM_ALL})
    public void testDecrypt() throws Exception {
//        String uriData = "Q28Xarhiyjvq9dg3ZXQOdo1OWxyijb4yTpG%2FfvF5biq6t9A0CpcxdqSMLqQkmUUY";
//        String uriData = "unQyzmj6eAo0VLO8ilyrtLrPfUiaOBOQevUF7v4A13H7YIyO9IkqfBBpIdNAbTObdc5R7yaovMZOUxQihXTcn9wiq4qdVbjoJwuUiaz9kSuwQFPt1kkOXliFCvp7qBQs4keuKmo8n2e97wyVKxmGdDYl3%2BaVqCjMGN%2B%2FIv%2BaNxUR6Ct86XkkPiEQXMQ0FuNDm9fTR1mZG2KM45vzC%2FlPayKnBk%2BfIYmGiPw0b4YSSepqtC02Z6nbwNIgbZ3MBqe6cphI6SqkQMefTjUkAzd9nA%3D%3D";
        String uriData = "kR%2FsdlJbiO91OEhaxC1U1rPMMzYtkTdh792RWHj6m5o%3D";
        String value = URLDecoder.decode(uriData, StandardCharsets.UTF_8);
        System.out.println();
        System.out.println("URL Decoded data >> " + value);
        String decryptText = AESHelper.decryptWithOutIV(value);
        System.out.println();
        System.out.println("Decrypted data >> " + decryptText);
        System.out.println();
    }

    @Skip
    @Test(groups={HQM_ALL})
    public void testEncrypt() throws Exception {
//        String text3 = "{\"First_Name\":\"John\", \"Last_Name\":\"Smith\", \"DOB\":\"1982-01-28\", \"MaritalStatus\":\"SINGLE\", \"Street\":\"102 KINGS CT\", \"City\":\"KILLEEN\", \"Email\":\"hqm.testing@abc.com\", \"Phone\":\"2158956772\", \"Zip_Code\":\"76542\", \"Source_Indicator\":\"QQ\", \"SourceID\":\"QQ\", \"LeadType\":\"QQ\"}";
//        String text4 = "{\"First_Name\":\"John\",\"Email\":\"hqm.testing@abc.com\",\"Last_Name\":\"Smith\",\"DOB\":\"01/28/1982\",\"Phone\":\"2158956772\",\"Street\":\"102 KINGS CT\",\"Gender\":\"M\",\"City\":\"KILLEEN\"}";
        String uriData = "{\"First_Name\":\"Peter\",\"Email\":\"test2@abc.com\",\"Last_Name\":\"Pan\",\"DOB\":\"11/13/1986\",\"Gender\":\"M\",\"Phone\":\"4244039910\",\"SourceID\":\"CW\",\"Street\":\"125 TOLLGATE WAY\",\"City\":\"FALSS CHURCH\",\"Source_Indicator\":\"CW\"}";
        String encryptText = AESHelper.encryptWithOutIV(uriData);
        String value = URLEncoder.encode(encryptText, StandardCharsets.UTF_8);
        System.out.println();
        System.out.println("URL encoded data >> " + value);
        System.out.println();
    }

    @Skip
    @Test(groups={HQM_ALL})
    public void testEncryptRS() throws Exception {
//        String customerData = "22025|Bakman|09/09/2001|1809635915";
        String customerData = "23188|data|01/01/1990|1733519100";
        String url = "https://ffqhomeuiqa.farmers.com/?Data=";
        url += AESHelper.encryptWithOutIV(customerData) + "&FLow=RQ";
        Log.info("HQM URL:"  + url);
    }

    @Skip
    @Test(groups={HQM_ALL})
    public void testDecryptRS() throws Exception {
        String textRS = "i9iIsiEDej3IcJ0usrSUn/tE/TVrsMRUOEv+Mo9nWTOGBXhw+vNd3BWl+/N+EvrQVDJVPNYuUgy6GSrvS/xTvkCMo9iIaUv1u4vXLHgLyLe/UGpdilnog2csvyniPn+PerzgBdLDkOBBHj1se5quwpCCV2ShnMJh23lwSSuBvGkc8Fpt1MpjFXfOPcYg9FZJSA/V3rZiDMzt7JET5K1kB8oNLzvJz7XmUIQru7gRu55qs9w5hEE3jy2XL3hY0byLrXPBN1eRwX7XT1CyyXLKflzzP71BSzQvWqJ8W0CT5L3Piu+fHWWu/tT6XdEsqEYgecutsA35Lya1qlDdplMRvlEliJEm0EBmYZMRSKcr8iI3b21zoNXlyOa8AAD6ibU+K/QT9sNXD7+EI+auqVF+4B0KnfcCe+WEDuSLuyyEQ1g=";
        String decryptText = AESHelper.decryptWithOutIV(textRS);
        System.out.println();
        System.out.println(">> " + decryptText);
    }

}



