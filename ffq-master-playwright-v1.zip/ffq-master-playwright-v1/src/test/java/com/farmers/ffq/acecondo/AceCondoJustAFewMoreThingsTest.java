package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoJustAFewMoreThingsPage;
import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.condo.AceCondoReviewQuotePage;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.JFMT_PAGE;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoJustAFewMoreThingsTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_JAFMT_PAGE})
    public void testValidateContentOfJustFewMoreThingsPageCondoLob(ApplicantAceHome applicant) throws Exception {
        applicant.setNewlyOwned(false);
        applicant.setInEscrow(false);
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceCondoNavigationHelper().navigateToAceCondoJustAFewMoreThingsPage(applicant);
        AceCondoJustAFewMoreThingsPage aceCondoJustAFewMoreThingsPage = new AceCondoJustAFewMoreThingsPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.verifyJustAFewMoreThingsHeader(fsa);
        jfmtPage.validatePolicyStartDateSection(fsa, applicant, CONDO);
        if (!applicant.isInEscrow() && applicant.isNewlyOwned()) {
            jfmtPage.validateHomePurchaseDateSection(fsa, CONDO);
        }
        jfmtPage.validateLenderInfoSection(fsa, applicant, CONDO);
        aceCondoJustAFewMoreThingsPage.validateOtherQuestionsSectionCondoLob(applicant, fsa);
        //Quote number and Agent details at the bottom validation
        jfmtPage.clickOnSaveQuoteButton();
        jfmtPage.validateQuoteText(JFMT_PAGE, applicant.getQuoteNumber(), fsa, true);
        jfmtPage.validateAgentSection(fsa, JFMT_PAGE, applicant.getAgentId(), CONDO);
        fsa.assertAll("Validate Content Of Just a Few More Things Page for Condo Lob");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE})
    public void testBusinessOperatedOnPremisesKnockOutScreenCondoLob(ApplicantAceHome applicant) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceCondoNavigationHelper().navigateToAceCondoJustAFewMoreThingsPage(applicant);
        AppStore sessionStorageData = jfmtPage.getSessionStorageAppStore();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceCondoJustAFewMoreThingsPage jfmtCondoPage = new AceCondoJustAFewMoreThingsPage();
        jfmtCondoPage.fillOutFMTPWithBusinessOperatedOnPremisesSelectedCondoLob(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, sessionStorageData.getData().getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - Business operated on premises");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE})
    public void testPetWithBiteHistoryKnockOutScreenCondoLob(ApplicantAceHome applicant) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceCondoNavigationHelper().navigateToAceCondoJustAFewMoreThingsPage(applicant);
        AppStore sessionStorageData = jfmtPage.getSessionStorageAppStore();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceCondoJustAFewMoreThingsPage jfmtCondoPage = new AceCondoJustAFewMoreThingsPage();
        jfmtCondoPage.fillOutFMTPWithPetWithBiteHistorySelectedCondoLob(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, sessionStorageData.getData().getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - Pet bite history");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO,FFQ_ACE_CONDO_JAFMT_PAGE})
    public void testKnockOutScreenWhenAllOtherQuestionsAreSelectedCondoLob(ApplicantAceHome applicant) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceCondoNavigationHelper().navigateToAceCondoJustAFewMoreThingsPage(applicant);
        AceCondoJustAFewMoreThingsPage jfmtCondoPage = new AceCondoJustAFewMoreThingsPage();
        AppStore sessionStorageData = jfmtPage.getSessionStorageAppStore();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtCondoPage.fillOutFMTPWithAllOtherQuestionsSelectedCondoLob(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, sessionStorageData.getData().getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - all other questions are selected");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE})
    public void testHOACoversWallsInKnockOutScreenCondoLob(ApplicantAceHome applicant) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceCondoNavigationHelper().navigateToAceCondoJustAFewMoreThingsPage(applicant);
        AppStore sessionStorageData = jfmtPage.getSessionStorageAppStore();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
       AceCondoJustAFewMoreThingsPage jfmtCondoPage = new AceCondoJustAFewMoreThingsPage();
        jfmtCondoPage.fillOutFMTPWithHOACoversWallsInSelectedCondoLob();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, sessionStorageData.getData().getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - HOA Covers walls in");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO,attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE})
    public void testContinueToBindWhenCantFindLenderSelectedCondoLob(ApplicantAceHome applicant) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceCondoNavigationHelper().navigateToAceCondoJustAFewMoreThingsPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.fillOutFMTPWithCantFindLenderSelected(fsa, applicant, CONDO);
        fsa.assertAll("Validated - can continue to bind flow, when no lender found selected - Condo.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
           suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_JAFMT_PAGE})
    public void testJFMTPageBackAndForthNavigationCondoLob(ApplicantAceHome applicant) throws Exception {
        AceCondoReviewQuotePage reviewQuotePage = new AceCondoNavigationHelper().navigateToAceCondoReviewQuotePage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        List<String> discountsOnReviewQuotePage = reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList());
        reviewQuotePage.clickOnContinueButton();
        AceHRCAdditionalCoveragesBasePage additionalCoveragePage = new AceHRCAdditionalCoveragesBasePage();
        Assert.assertTrue(additionalCoveragePage.isOnAdditionalCoveragesPage(), "Did not reach additional coverage page - Condo");
        List<String> toggleSelected = additionalCoveragePage.randomToggleSelection(applicant, fsa, CONDO);
        String quotePriceOnCoveragePage = additionalCoveragePage.getQuotePriceOnCard();
        additionalCoveragePage.clickOnContinueButton();
        AceCondoJustAFewMoreThingsPage jfmtPage = new AceCondoJustAFewMoreThingsPage();
        Assert.assertTrue(jfmtPage.isOnJFMTPage(true), "Did not reach JFMT page");
        jfmtPage.fillOutJustFewMoreThingsPageCondo(applicant, true);
        AceHRCPaymentSelectionPage paymentSelectionPage = new AceHRCPaymentSelectionPage();
        Assert.assertTrue(paymentSelectionPage.isOnPaymentPage(), "Did not reach payment page");
        List<String> discountsOnPaymentPage = new AceHRCBasePage().getDiscounts().stream().sorted().collect(Collectors.toList());
        fsa.assertEquals(discountsOnPaymentPage, discountsOnReviewQuotePage, "Discounts are not matching on payment page and Review quote page - Condo");
        paymentSelectionPage.validatePayInFullPaymentCard(fsa, applicant.getStateCode(), CONDO);
        paymentSelectionPage.clickSelectAndSetUpPaymentPayInFullCard(CONDO);
        paymentSelectionPage.waitForSkeletonToBeGone();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        double dDueTodayBeforeNavigation = aceHRCPaymentBasePage.getDueTodayAmountAceHRC(ONE_PAY, applicant.getStateCode());

        // Navigate back to JFMT page and validate selections are retained
        (new AceHRCBasePage()).navigateBack(2);
        Assert.assertTrue(jfmtPage.isOnJFMTPage(true), "Did not reach JFMT page when navigated back from payment page");
        jfmtPage.validateJFMTPageSelectionsCondo(applicant.getDogsOnPremises(), applicant, fsa, false);
        jfmtPage.clickContinueButton();

        // Navigate to payment page and validate due today amount is retained
        Assert.assertTrue(paymentSelectionPage.isOnPaymentPage(), "Did not reach payment page");
        paymentSelectionPage.clickSelectAndSetUpPaymentPayInFullCard(CONDO);
        paymentSelectionPage.waitForSkeletonToBeGone();
        double dDueTodayAfterNavigation = aceHRCPaymentBasePage.getDueTodayAmountAceHRC(ONE_PAY, applicant.getStateCode());
        fsa.assertEquals(dDueTodayBeforeNavigation, dDueTodayAfterNavigation, "Selected toggles are not retained when navigated back to additional coverage page from JFMT page");

        // Navigate back to Additional coverage page and validate selections are retained
        (new AceHRCBasePage()).navigateBack(3);
        Assert.assertTrue(additionalCoveragePage.isOnAdditionalCoveragesPage(), "Did not reach additional coverage page when navigated back from JFMT page");

        List<String> actualToggleSelected = additionalCoveragePage.getSelectedToggles();
        String actualQuotePriceOnCoveragePage = additionalCoveragePage.getQuotePriceOnCard();
        fsa.assertEquals(additionalCoveragePage.getSortedList(actualToggleSelected), additionalCoveragePage.getSortedList(toggleSelected), "Selected toggles are not retained when navigated back to additional coverage page from JFMT page");
        fsa.assertEquals(actualQuotePriceOnCoveragePage, quotePriceOnCoveragePage, "Quote price is not retained when navigated back to additional coverage page from JFMT page");
        additionalCoveragePage.navigateBack();

        // Navigate back to Review quote page and validate selections are retained
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePage(true), "Did not reach review quote page when navigated back from additional coverage page");
        String actualReviewQuotePrice = reviewQuotePage.getQuotePriceOnCard();
        fsa.assertEquals(actualReviewQuotePrice, quotePriceOnCoveragePage, "Quote price is not retained when navigated back to review quote page from additional coverage page");
        List<String> actualDiscountsOnReviewQuotePage = reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList());
        fsa.assertEquals(actualDiscountsOnReviewQuotePage, discountsOnReviewQuotePage, "Discounts are not retained when navigated back to review quote page from additional coverage page");
        fsa.assertAll("Validate navigation back and forth to JFMT page for Condo Lob");
        }
    }

