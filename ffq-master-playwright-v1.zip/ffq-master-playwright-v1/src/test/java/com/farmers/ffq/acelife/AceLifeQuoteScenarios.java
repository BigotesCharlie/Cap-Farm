package com.farmers.ffq.acelife;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.Random;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.farmers.ffq.ace.life.AceLifeNameAndDOBPage;
import com.farmers.ffq.ace.life.AceLifeNavigationHelper;
import com.farmers.ffq.ace.life.AceLifePersonalInfoPage;
import com.farmers.ffq.ace.life.AceLifeReviewQuotePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantLife;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.Property;
import com.farmers.framework.report.Reporter;

public class AceLifeQuoteScenarios extends AutomationFramework {

	@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})
	public void aceLifeQuoteOlderThan70(ApplicantLife applicant) throws Exception {
		applicant.setAge(new Random().nextInt(5)+71);
		performAgeScenarioTest(applicant);
	}

	@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})
	public void aceLifeQuoteBetweenAgesOf66And70(ApplicantLife applicant) throws Exception {
		applicant.setAge(new Random().nextInt(5)+66);
		performAgeScenarioTest(applicant);
	}

	@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})
	public void aceLifeQuoteBetweenAgesOf51And65(ApplicantLife applicant) throws Exception {
		applicant.setAge(new Random().nextInt(15)+51);
		performAgeScenarioTest(applicant);
	}

	@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})
	public void aceLifeQuoteYoungerThan50(ApplicantLife applicant) throws Exception {
		applicant.setAge(new Random().nextInt(32)+18);
		performAgeScenarioTest(applicant);
	}

	private void performAgeScenarioTest(ApplicantLife applicant) throws Exception {
		AceLifeReviewQuotePage lifeReviewQuotePage = new AceLifeNavigationHelper().navigateToAceLifeReviewQuotePage(applicant);
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		lifeReviewQuotePage.testAgeScenario(applicant.getAge(), farmersSoftAssert);
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})
	public void aceLifeSaveAndRetrieveNameAndDOBPage(ApplicantLife applicant) throws Exception {
		AceLifeNameAndDOBPage nameAndDobPage = new AceLifeNavigationHelper().navigateToAceLifeNameAndDOBPage(applicant);
		nameAndDobPage.saveQuoteForLater(applicant);
		retrieveQuote(applicant, nameAndDobPage.getSessionStorageAppStore().getData().getQuoteNumber());
	}

	@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})
	public void aceLifeSaveAndRetrievePersonalInfoPage(ApplicantLife applicant) throws Exception {
		AceLifePersonalInfoPage personalInfoPage = new AceLifeNavigationHelper().navigateToAceLifePersonalInfoPage(applicant);
		personalInfoPage.saveQuoteForLater(applicant);
		retrieveQuote(applicant, personalInfoPage.getSessionStorageAppStore().getData().getQuoteNumber());
	}

	@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE})
	public void aceLifeSaveAndRetrieveReviewQuotePage(ApplicantLife applicant) throws Exception {
		AceLifeReviewQuotePage reviewQuotePage = new AceLifeNavigationHelper().navigateToAceLifeReviewQuotePage(applicant);
		String quoteNumber = reviewQuotePage.getAceQuoteNumberInThePage();
		reviewQuotePage.saveQuoteForLater(applicant);
		retrieveQuote(applicant, quoteNumber);
	}

	@Test(dataProvider = DataProviders.PRODUCTION_TEST_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = PRODUCTION_VALIDATION)
	public void productionValidationAceLifeQuote(ApplicantLife applicant) throws Exception {
		aceLifeSaveAndRetrieveReviewQuotePage(applicant);
	}

	@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {ADA_SUITE, LIFE_ADA_SUITE})
	public void aceLifeAdaTest(ApplicantLife applicant) throws Exception {
		String adaTestingEnabled = Property.getTestProperty("adaTestingEnabled");
		if (adaTestingEnabled!=null && adaTestingEnabled.equalsIgnoreCase("true")) {
			testStep("Perform ADA tests on the Ace Life pages");
			new AceLifeNavigationHelper().navigateToAceLifeReviewQuotePage(applicant);
		} else {
			throw new SkipException("adaTestingEnabled flag not set, skipping ADA testing");
		}
		testStep("End of Test");
	}

	private void retrieveQuote(ApplicantLife applicant, String quoteNumber) throws Exception {
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		Object returningPage = new LandingPage().enterRetrieveQuote(applicant, quoteNumber);
		switch (returningPage.getClass().getSimpleName()) {
			case "LandingPage":
				Reporter.pass("Life quotes cannot be retrieved unless they reach the Review Quote page", true);
				break;
			case ACE_LIFE_NAME_DOB_PAGE:
				AceLifeNameAndDOBPage aceLifeNameAndDOBPage = (AceLifeNameAndDOBPage) returningPage;
				aceLifeNameAndDOBPage.testQuoteRetrieval(applicant, farmersSoftAssert);
				break;
			case ACE_LIFE_PERSONAL_INFO_PAGE:
				AceLifePersonalInfoPage aceLifePersonalInfoPage = (AceLifePersonalInfoPage) returningPage;
				aceLifePersonalInfoPage.testQuoteRetrieval(applicant, false, farmersSoftAssert);
				break;
			case ACE_LIFE_REVIEW_QUOTE_PAGE:
				aceLifePersonalInfoPage = new AceLifePersonalInfoPage();
				aceLifePersonalInfoPage.testQuoteRetrieval(applicant, true, farmersSoftAssert);
				aceLifePersonalInfoPage.waitForSpinnerToBeGone();
				aceLifePersonalInfoPage.waitForSkeletonToBeGone();
				AceLifeReviewQuotePage reviewQuotePage = new AceLifeReviewQuotePage();
				if (reviewQuotePage.isOnReviewQuotePage()) {
					reviewQuotePage.testQuoteRetrieval(applicant, farmersSoftAssert);
				} else {
					farmersSoftAssert.fail("Unable to reach review quote page");
				}
				break;
			default:
				throw new IllegalArgumentException("Wrong class name: " + returningPage.getClass().getSimpleName());
		}
		farmersSoftAssert.assertAll();
	}
}
