package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class BWDefaultCoverageValuesTests_WY extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_None_Unk(AutoApplicant applicant) throws Exception {
        //This is going to avoid BW condition based on the foreign driver's license
        randomizeApplicantPersonalData(applicant);
        updateLastNameForBristolWest(applicant);
        applicant.setTestCategory("BW->" + applicant.getTestCategory());
        defaultCoverageTestForBW(applicant, "coverageAmount=None/Unk&umbrella=No", "WY_None_Unk_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_25K50K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=25/50&umbrella=No", "WY_25K50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_25K65K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=25/65&umbrella=No", "WY_25K65K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_30K60K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=30/60&umbrella=No", "WY_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_30K65K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=30/65&umbrella=No", "WY_30K65K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_35K70K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35/70&umbrella=No", "WY_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_35K80K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35/80&umbrella=No", "WY_35K80K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_50K100K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=50/100&umbrella=No", "WY_50K100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_100K200K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/200&umbrella=No", "WY_100K200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_100K300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/300&umbrella=No", "WY_100K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_150K300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=150/300&umbrella=No", "WY_150K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_250K500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=250/500&umbrella=No", "WY_250K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_300K300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=300/300&umbrella=No", "WY_300K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_500K500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/500&umbrella=No", "WY_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_500K1000K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/1000&umbrella=No", "WY_500K1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_1000K1000K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=1000/1000&umbrella=No", "WY_1000K1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_35K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35&umbrella=No", "WY_35K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_45K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=45&umbrella=No", "WY_45K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_50K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=50&umbrella=No", "WY_50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_60K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=60&umbrella=No", "WY_60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_75K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=75&umbrella=No", "WY_75K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_85K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=85&umbrella=No", "WY_85K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_100K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100&umbrella=No", "WY_100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_200K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=200&umbrella=No", "WY_200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=300&umbrella=No", "WY_300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500&umbrella=No", "WY_500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WY_1000K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=1000&umbrella=No", "WY_1000K_");
    }

}
