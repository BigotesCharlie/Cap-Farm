package com.farmers.ffq.hqm;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.auto.pages.NameAndDobPage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.hqm.*;
import com.farmers.ffq.hqm.pages.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.Mailinator;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Quote Retrieval Scenarios - Home Quote Modernization (HQM).
 */
public class QuoteRetrievalScenarios extends AutomationFramework {

    private static final Double quoteDelta = 0.30; // quote price fluctuation delta max (used when no Postgres connection)

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})
    public void testRetrieveBeforeCustomerInfo(ApplicantHQM applicant) throws Exception {
        String browserType = DESKTOP_BROWSER;

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber );
        addressPage.populateFields(applicant, fsa);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        List<String> discounts = propertyPage.getDiscounts();
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityPage.selectQualityGrade(applicant, propertyData);
        qualityPage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
        propertyDetailsPage.clickNext();

//        Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);

//       Try to retrieve the quote before customer info submitted
        LandingPage landingPage = new LandingPage(applicant.zipCode, new LeadTypeHQM(applicant,RQ), browserType);
        landingPage.clickRetrieveSavedQuoteTab();
        landingPage.enterRetrieveSavedQuoteForHQM(applicant, quoteNumber);

        fsa.assertTrue(landingPage.isQuoteRetrievalErrorMessage(), "Quote Retrieval - Error message expected.");
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})
    public void testRetrieveOnContactInfo(ApplicantHQM applicant) throws Exception {

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, DESKTOP_BROWSER);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber );
        addressPage.populateFields(applicant, fsa);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        List<String> discounts = propertyPage.getDiscounts();
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityPage.selectQualityGrade(applicant, propertyData);
        qualityPage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        discounts = customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        callRetrieveQuote(applicant, quoteNumber);

//       Customer Info Page
        customerInfoPage = new CustomerInfoPage();
        Assert.assertEquals(customerInfoPage.getQuoteNumber(), quoteNumber, "Customer Info Page - Retrieved correct quote number.");
        PageLinksHQM customerInfoPageLinks = new PageLinksHQM("customerInfoPage", applicant.stateCode);
        customerInfoPageLinks.buttonNext = 3;
        customerInfoPage.validatePageLinks(customerInfoPageLinks, quoteNumber, fsa);
        StaticContentHQM staticContent = new ApiHelper().getStaticContentFromJson(quoteNumber);
        customerInfoPage.validatePageFieldContents(applicant, false, fsa);
        customerInfoPage.validatePageTitles(applicant, fsa, staticContent);
        customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
        customerInfoPage.clickNext();

//       Contact Info Page
        contactInfoPage = new ContactInfoPage();
        PageLinksHQM contactInfoPageLinks = new PageLinksHQM("contactInfoPage", applicant.stateCode);
        contactInfoPageLinks.buttonNext = 2;
        contactInfoPage.validatePageFieldContents(applicant, true, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})
    public void testSAFLOnContactInfoNoEmail(ApplicantHQM applicant) throws Exception {
        saveAndFinishLaterOnContactInfo(applicant, false);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})
    public void testSAFLOnContactInfoYesEmail(ApplicantHQM applicant) throws Exception {
        saveAndFinishLaterOnContactInfo(applicant, true);
    }

    private void saveAndFinishLaterOnContactInfo(ApplicantHQM applicant, boolean bEmail) throws Exception {

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, DESKTOP_BROWSER);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber );
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityPage.selectQualityGrade(applicant, propertyData);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        if (bEmail) {
            contactInfoPage.setRequiredFields(applicant);
            contactInfoPage.clickSaveAndFinishLater();
            Assert.assertTrue(contactInfoPage.isEmailInSAFLDialogReadOnly(), "Email field in Safe & finish later dialog is read-only");
        } else {
            contactInfoPage.clickSaveAndFinishLater();
            contactInfoPage.enterEmailInSaveAndFinishLaterDialog(applicant.emailAddress);
        }
        contactInfoPage.clickSaveAndExit();

        callRetrieveQuote(applicant, quoteNumber);

//       Contact Info Page
        contactInfoPage = new ContactInfoPage();
        Assert.assertEquals(contactInfoPage.getQuoteNumber(), quoteNumber, "Contact Info page - Retrieved correct quote number.");
        PageLinksHQM contactInfoPageLinks = new PageLinksHQM("contactInfoPage", applicant.stateCode);
        contactInfoPageLinks.buttonNext = bEmail ? 3 : 2;
        contactInfoPage.validatePageLinks(contactInfoPageLinks, quoteNumber, fsa);
        contactInfoPage.validatePageFieldContents(applicant, !bEmail, fsa);
        Log.info("Contact Info page, quote number: " + quoteNumber,true);
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})
    public void testRetrieveOnDiscountsPage(ApplicantHQM applicant) throws Exception {
        retrieveOnDiscountsPage(applicant, false, true);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})
    public void testRetrieveOnDiscountsPageByEmailId(ApplicantHQM applicant) throws Exception {
        retrieveOnDiscountsPage(applicant, true, false);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})
    public void testSAFLOnDiscountsPage(ApplicantHQM applicant) throws Exception {
        retrieveOnDiscountsPage(applicant, true, true);
    }

    private void retrieveOnDiscountsPage(ApplicantHQM applicant, boolean bSaveFinishLater, boolean bQuoteId) throws Exception {

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, DESKTOP_BROWSER);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber );
        addressPage.populateFields(applicant, fsa);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        List<String> discounts = propertyPage.getDiscounts();
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityPage.selectQualityGrade(applicant, propertyData);
        qualityPage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        discounts = customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        discountsPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        discounts = discountsPage.getDiscounts();
        if (bSaveFinishLater) {
            discountsPage.clickSaveAndFinishLater();
            Assert.assertTrue(discountsPage.isEmailInSAFLDialogReadOnly(), "Email field in Safe & finish later dialog is read-only");
            discountsPage.clickSaveAndExit();
            driverWait(Property.PAGELOADTIMEOUT).until(PWExpectedConditions.urlToBe(FARMERS_COM));
        }

        String quoteId = bQuoteId ? quoteNumber : applicant.getEmailAddress();
        callRetrieveQuote(applicant, quoteId);

//       Discounts Page
        discountsPage = new DiscountsPage();
        Log.info("Discounts page, quote number: " + quoteNumber,true);
        Assert.assertEquals(discountsPage.getQuoteNumber(), quoteNumber, "Discounts Page - Retrieved correct quote number.");
        PageLinksHQM discountsPageLinks = new PageLinksHQM("discountsPage", applicant.stateCode);
        discountsPage.validatePageLinks(discountsPageLinks, quoteNumber, fsa);
        List<String> discountsBeforeRate = apiHelper.getDiscountsFromJsonBeforeRate(quoteNumber);
        discountsPage.validatePageFieldContents(applicant, true, fsa, discountsBeforeRate);
        discountsPage.validatePreappliedDiscountsBeforeRate(applicant, discountsBeforeRate, fsa);
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        discountsPage.validatePageTitles(!discountsBeforeRate.isEmpty(), fsa, staticContent);
        discountsPage.validatePageSubtitles(applicant, !discountsBeforeRate.isEmpty(), staticContent);
        discountsPage.validateHelpDialogs(applicant, !discountsBeforeRate.isEmpty(), fsa, staticContent);
        discountsPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        discountsPage.clickStepperAddress(null);

//       Address Page
        addressPage = new AddressPage();
        addressPage.verifyPageFields(applicant, fsa);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Page
        propertyPage = new PropertyPage();
        propertyPage.verifyPageFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        propertyPage.clickNext();

//       Quality Grade Page
        qualityPage = new QualityGradePage();
        qualityPage.verifyPageFields(applicant, propertyData);
        qualityPage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityPage.clickNext();

//       Property Details Page
        propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.verifyPageFieldSelections(applicant, fsa, propertyData);
        propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        customerInfoPage = new CustomerInfoPage();
        customerInfoPage.validatePageFieldContents(applicant, false, fsa);
        customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
        customerInfoPage.clickNext();

//       Contact Info Page
        contactInfoPage = new ContactInfoPage();
        contactInfoPage.validatePageFieldContents(applicant, false, fsa);
        contactInfoPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        discountsPage = new DiscountsPage();
        discountsPage.validatePageLinks(discountsPageLinks, quoteNumber, fsa);
        discountsPage.validatePageFieldContents(applicant, true, fsa, discountsBeforeRate);
        discountsPage.validatePreappliedDiscountsBeforeRate(applicant, discountsBeforeRate, fsa);
        discountsPage.validatePageTitles(!discountsBeforeRate.isEmpty(), fsa, staticContent);
        discountsPage.validatePageSubtitles(applicant, !discountsBeforeRate.isEmpty(), staticContent);
        discountsPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})
    public void testRetrieveOnQuotePage(ApplicantHQM applicant) throws Exception {
        retrieveOnQuotePage(applicant, false, true);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})
    public void testRetrieveOnQuotePageByEmailId(ApplicantHQM applicant) throws Exception {
        retrieveOnQuotePage(applicant, false, false);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})
    public void testSAFLOnQuotePage(ApplicantHQM applicant) throws Exception {
        retrieveOnQuotePage(applicant, true, true);
    }

    private void retrieveOnQuotePage(ApplicantHQM applicant, boolean bSaveFinishLater, boolean bQuoteId) throws Exception {
        String browserType = DESKTOP_BROWSER;

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber );
        addressPage.populateFields(applicant, fsa);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        List<String> discounts = propertyPage.getDiscounts();
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityPage.selectQualityGrade(applicant, propertyData);
        qualityPage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        discounts = customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        discountsPage.setRequiredFields(applicant);
        discountsPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        discounts = discountsPage.getDiscounts();
        discountsPage.clickNext();

        QuotePage quotePage;
        if (!applicant.isKnockOutScenario) {
//           Quote Page
            quotePage = new QuotePage();
            Log.info("Quote Summary page, quote number: " + quoteNumber,true);
            quotePage.validateSubtitlesDiscountJourney(fsa);
            discounts = quotePage.getDiscounts();
            if (bSaveFinishLater) {
                quotePage.clickSaveAndFinishLater();
                Assert.assertTrue(quotePage.isEmailInSAFLDialogReadOnly(), "Email field in Safe & finish later dialog is read-only");
                quotePage.clickSaveAndExit();
                driverWait(Property.PAGELOADTIMEOUT).until(PWExpectedConditions.urlToBe(FARMERS_COM));
            }
        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            Log.info("Knockout page, quote number: " + quoteNumber,true);
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }

        String quoteId = bQuoteId ? quoteNumber : applicant.getEmailAddress();
        callRetrieveQuote(applicant, quoteId);

        QuoteRateHQM quoteRate = null;
        if (!applicant.isKnockOutScenario) {
//           Quote Page
            quotePage = new QuotePage();
            Assert.assertEquals(quotePage.getQuoteNumber(), quoteNumber, "Quote Page - Retrieved correct quote number.");
            quotePage.clickDismissSurveyPopup();
            PageLinksHQM quotePageLinks = new PageLinksHQM("quotePage", applicant, browserType, true);
            quotePage.validatePageLinks(quotePageLinks, quoteNumber, fsa);
            quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            quotePage.validatePageTitles(quoteRate, fsa, staticContent);
            quotePage.validatePageFooters(applicant, staticContent);
            quotePage.validatePageCardTitles(applicant, quoteRate, true, browserType, fsa);
            quotePage.validateSendEmail(applicant, fsa);
            quotePage.validateQuoteDiscounts(applicant, fsa, quoteRate);
            quotePage.validateQuotePremiums(applicant, quoteRate, quoteDelta, fsa);
            quotePage.validateSubtitlesDiscountJourney(fsa);
            quotePage.clickBack();
        }

//       Discounts Page
        discountsPage = new DiscountsPage();
        PageLinksHQM discountsPageLinks = new PageLinksHQM("discountsPage", applicant, browserType, true);
        discountsPage.validatePageLinks(discountsPageLinks, quoteNumber, fsa);
        discountsPage.validatePageFieldContents(applicant, false, fsa, null);
        List<String> preDiscounts = new ArrayList<>();
        if (!applicant.isKnockOutScenario) {
            assert quoteRate != null;
            discountsPage.validatePreappliedDiscountsAfterRate(applicant, quoteRate);
        } else {
            discountsPage.validatePreappliedDiscountsBeforeRate(applicant, preDiscounts, fsa);
        }
        discountsPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        discountsPage.clickStepperAddress(null);

//       Address Page
        addressPage = new AddressPage();
        addressPage.verifyPageFields(applicant, fsa);
        if (!applicant.isKnockOutScenario) {
            addressPage.verifyPageFieldsReadonly(fsa);
        }
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Page
        propertyPage = new PropertyPage();
        propertyPage.verifyPageFields(applicant, fsa, propertyData);
        propertyPage.verifyPageFieldsNotReadonly(fsa);
        propertyPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        propertyPage.clickNext();

//       Quality Grade Page
        qualityPage = new QualityGradePage();
        qualityPage.verifyPageFields(applicant, propertyData);
        qualityPage.verifyPageFieldsNotReadonly(fsa);
        qualityPage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityPage.clickNext();

//       Property Details Page
        propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.verifyPageFieldSelections(applicant, fsa, propertyData);
        propertyDetailsPage.verifyPageFieldsNotReadonly(fsa);
        propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        customerInfoPage = new CustomerInfoPage();
        customerInfoPage.validatePageFieldContents(applicant, false, fsa);
        if (!applicant.isKnockOutScenario) {
            customerInfoPage.verifyPageFieldsReadonly(applicant, false, fsa);
        }
        customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
        customerInfoPage.clickNext();

//       Contact Info Page
        contactInfoPage = new ContactInfoPage();
        contactInfoPage.validatePageFieldContents(applicant, false, fsa);
        if (!applicant.isKnockOutScenario) {
            contactInfoPage.verifyPageFieldsReadonly(fsa);
        }
        contactInfoPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        discountsPage = new DiscountsPage();
        discountsPage.validatePageFieldContents(applicant, false, fsa, null);
        if (!applicant.isKnockOutScenario) {
            assert quoteRate != null;
            discountsPage.validatePreappliedDiscountsAfterRate(applicant, quoteRate);
        }
        discountsPage.verifyPageFieldsNotReadonly();
        discountsPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
//       Quote Page
            quotePage = new QuotePage();
            quotePage.validatePageTitles(quoteRate, fsa, staticContent);
            quotePage.validatePageFooters(applicant, staticContent);
            quotePage.validatePolicyPerks(applicant);
//            quotePage.validatePolicyFloAd(applicant, FC);
            quotePage.validatePageCardTitles(applicant, quoteRate, true, browserType, fsa);
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                quotePage.validateEmailIconState(false, fsa);
            }
            quotePage.validateQuoteDiscounts(applicant, fsa, quoteRate);
            quotePage.validateQuotePremiums(applicant, quoteRate, quoteDelta, fsa);
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                applicant.quoteRate = quotePage.getQuotePremiumMonthly();
            } else {
                applicant.quoteRate = quotePage.getQuotePremiumYearly(applicant.stateCode);
            }
            quotePage.validateSubtitlesDiscountJourney(fsa);
            quotePage.clickNext();

//       Thank You Page
            ThankYouPage thankYouPage = new ThankYouPage();
            thankYouPage.validatePageValues(applicant, applicant.quoteRate, fsa, quoteRate);

            if (applicant.emailCheck && !thankYouPage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                Mailinator.validateHqmEmails(applicant, null, false);
            }
        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})
    public void testRetrieveQuoteDetailsPage(ApplicantHQM applicant) throws Exception {
        String browserType = DESKTOP_BROWSER;

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityPage.selectQualityGrade(applicant, propertyData);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        discountsPage.setRequiredFields(applicant);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
            List<String> quoteValues = new ArrayList<>();
//       Quote Page
            QuotePage quotePage = new QuotePage();
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            String quotePremiumYearly = quotePage.getQuotePremiumYearly(applicant.stateCode);
            String reconstructionCost = quotePage.getQuoteReconstructionCost();
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                applicant.quoteRate = quotePage.getQuotePremiumMonthly();
                quotePage.validateEmailIconState(true, fsa);
            } else {
                applicant.quoteRate = quotePremiumYearly;
            }
            quotePage.validateSendEmail(applicant, fsa);
            quotePage.clickQuoteDetails();

//       Quote Details Page
            QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
            quoteDetailsPage.validatePageTitlesSubtitles(applicant, fsa, quoteRate, quoteDelta, quotePremiumYearly, staticContent);
            quoteDetailsPage.validateStandardPackageSliders(applicant, quoteRate, reconstructionCost, fsa);
            quoteDetailsPage.updateSlidersRecalculate(applicant, fsa);
            QuoteRateHQM customRate = apiHelper.getQuoteRateFromJson(quoteNumber, "custom");
            quoteDetailsPage.verifyPremiums(applicant, fsa, customRate, null, null);
            quoteDetailsPage.clickCloseModal();

//       Quote Page
            quotePage = new QuotePage();
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                quotePage.validateEmailIconState(true, fsa);
                quoteValues.add(quotePage.getQuotePremiumMonthly());
                quotePage.validateSendEmail(applicant, fsa);
            }

            callRetrieveQuote(applicant, quoteNumber);

//       Quote Page
            quotePage = new QuotePage();
            Log.info("Quote Summary page, quote number: " + quoteNumber,true);
            quotePage.validatePageCardTitles(applicant, customRate, false, browserType, fsa);
            quotePage.clickQuoteDetails();

            quoteDetailsPage = new QuoteDetailsPage();
            quoteDetailsPage.validatePageTitlesSubtitles(applicant, fsa, customRate, quoteDelta, quotePremiumYearly, staticContent);
            quoteDetailsPage.validateStandardPackageSliders(applicant, customRate, reconstructionCost, fsa);
            quoteDetailsPage.verifyPremiums(applicant, fsa, customRate, null, null);
            quoteDetailsPage.clickCloseModal();

            //        Validate Quote Page after Custom Rate
            quotePage = new QuotePage();
            quotePage.validatePageTitles(quoteRate, fsa, staticContent);
            quotePage.validatePageFooters(applicant, staticContent);
            quotePage.validatePolicyPerks(applicant);
//            quotePage.validatePolicyFloAd(applicant, FC);
            customRate = apiHelper.getQuoteRateFromJson(quoteNumber, "custom");
            quotePage.validatePageCardTitles(applicant, customRate, false, browserType, fsa);
            quotePage.validateQuoteDiscounts(applicant, fsa, customRate);
            quotePage.validateQuotePremiums(applicant, customRate, quoteDelta, fsa);

//        Validate Quote changes back to Standard, if something is updated on Property Details page
            quotePage.clickBack();
            HqmBasePage basePage = new HqmBasePage();  // Discounts page
            basePage.clickBack();
            basePage = new HqmBasePage(); // Contact Info page
            basePage.clickBack();
            basePage = new HqmBasePage(); // Customer Info page
            basePage.clickBack();
            propertyDetailsPage = new PropertyDetailsPage();
            String numberOfStories = propertyDetailsPage.getSelectedNumberOfStories();
            List<String> listNumberOfStories = propertyDetailsPage.getAvailableNumberOfStories();
            listNumberOfStories.remove(numberOfStories);
            propertyDetailsPage.selectNumberOfStories(listNumberOfStories.get(0));
            propertyDetailsPage.clickNext();

            customerInfoPage = new CustomerInfoPage(); // Customer Info page
            customerInfoPage.clickNext();

            contactInfoPage = new ContactInfoPage(); // Contact Info page
            contactInfoPage.clickAgreeSubmitButton();

            discountsPage = new DiscountsPage(); // Discounts page
            discountsPage.clickNext();

            quotePage = new QuotePage();  // Quote page reverted back to Standard package
            quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                quotePage.validateEmailIconState(true, fsa);
                quoteValues.add(quotePage.getQuotePremiumMonthly());
            } else {
                quoteValues.add(quotePage.getQuotePremiumYearly(CA));
            }
            quotePage.validateSendEmail(applicant, fsa);
            quotePage.validatePageCardTitles(applicant, quoteRate, true, browserType, fsa);

            if (applicant.emailCheck && !quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                Mailinator.validateHqmEmails(applicant, quoteValues, false);
            }
        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            Log.info("Knockout page, quote number: " + quoteNumber,true);
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_RETRIEVE, HQM_ALL})
    public void testRetrieveThankYouPage(ApplicantHQM applicant) throws Exception {
        String browserType = DESKTOP_BROWSER;

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber );
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityPage.selectQualityGrade(applicant, propertyData);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        discountsPage.setRequiredFields(applicant);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
//       Quote Page
            QuotePage quotePage = new QuotePage();
            quotePage.clickDismissSurveyPopup();
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            quotePage.validateQuotePremiums(applicant, quoteRate, quoteDelta, fsa);
            quotePage.validateQuoteDiscounts(applicant, fsa, quoteRate);
            quotePage.validatePageCardTitles(applicant, quoteRate, true, browserType, fsa);
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                applicant.quoteRate = quotePage.getQuotePremiumMonthly();
            } else {
                applicant.quoteRate = quotePage.getQuotePremiumYearly(applicant.stateCode);
            }
            quotePage.clickNext();

//       Thank You Page
            ThankYouPage thankYouPage = new ThankYouPage();
            thankYouPage.validatePageValues(applicant, applicant.quoteRate, fsa, quoteRate);

            callRetrieveQuote(applicant, quoteNumber);

//       Quote Page
            quotePage = new QuotePage();
            Assert.assertEquals(quotePage.getQuoteNumber(), quoteNumber, "Quote Page - Retrieved correct quote number.");
            quotePage.clickDismissSurveyPopup();
            Log.info("Quote Summary page, quote number: " + quoteNumber,true);
            PageLinksHQM quotePageLinks = new PageLinksHQM("quotePage", applicant, browserType, true);
            quotePage.validatePageLinks(quotePageLinks, quoteNumber, fsa);
            quotePage.validatePageTitles(quoteRate, fsa, staticContent);
            quotePage.validatePageFooters(applicant, staticContent);
            quotePage.validatePageCardTitles(applicant, quoteRate, true, browserType, fsa);
            quotePage.validateSendEmail(applicant, fsa);
            quotePage.validateQuoteDiscounts(applicant, fsa, quoteRate);
            quotePage.validateQuotePremiums(applicant, quoteRate, quoteDelta, fsa);
            quotePage.clickNext();

//       Thank You Page
            thankYouPage = new ThankYouPage();
            PageLinksHQM thankYouPageLinks = new PageLinksHQM("thankYouPage", applicant.stateCode);
            thankYouPage.validatePageLinks(thankYouPageLinks, quoteNumber, fsa);
            thankYouPage.validatePageValues(applicant, applicant.quoteRate, fsa, quoteRate);
            thankYouPage.validatePageTitles(applicant, browserType, fsa, staticContent);
            thankYouPage.validatePageFooters(applicant, browserType, fsa);

            if (applicant.emailCheck && !thankYouPage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                Mailinator.validateHqmEmails(applicant, null, false);
            }
        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            Log.info("Knockout page, quote number: " + quoteNumber,true);
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }
        fsa.assertAll();
    }

    private void callRetrieveQuote(ApplicantHQM applicant, String quoteId) throws Exception {
        LandingPage landingPage = new LandingPage(applicant.zipCode, new LeadTypeHQM(applicant, RQ), DESKTOP_BROWSER);
        landingPage.clickRetrieveSavedQuoteTab();
        landingPage.enterRetrieveSavedQuoteForHQM(applicant, quoteId);
        sleep(2);

        String url = driver().getCurrentUrl();
        Log.info(">>> url: " + url);

//        if (url.endsWith("&Flow=RQ")) {
//            driver().quit();
//            new LandingPage(url, true);
//        }

        HqmBasePage basePage = new HqmBasePage();
        basePage.retrieveDialogContinue();
    }


    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {})}, groups = {}) // HQM_ALL
    public void testProdRetrieveOnQuotePageHQM(ApplicantHQM applicant) throws Exception {
        applicant.setFirstName(PRODUCTION_APPLICANT_FIRST_NAME);
        applicant.setLastName(PRODUCTION_APPLICANT_LAST_NAME);
        applicant.setEmailAddress(PRODUCTION_APPLICANT_EMAIL);

        LandingPage landingPage = new LandingPage(applicant);
        landingPage.enterLandingPageData(LOB_HOME, applicant.getZipCode());

//  Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber, true);
        addressPage.validatePageLinksNavigationTitles(fsa);
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//  Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        propertyPage.setRequiredFields(applicant, fsa, null);
        propertyPage.clickNext();

//  Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        qualityPage.selectQualityGrade(applicant, null);
        qualityPage.clickNext();

//  Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, null);
        propertyDetailsPage.clickNext();

//  Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//  Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.clickAgreeSubmitButton();

//  Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        if (driver().getCurrentUrl().endsWith("/discounts")) {
            discountsPage.setRequiredFields(applicant);
            discountsPage.getFieldValues(applicant);
            discountsPage.clickNext();
        }

        QuotePage quotePage;
        if (!applicant.isKnockOutScenario) {
//  Quote Page
            try {
                quotePage = new QuotePage();
                testStep("Quote Summary page, quote number: " + quoteNumber,true);
                quotePage.clickNext();
            } catch (com.farmers.framework.playwright.compat.PWTimeoutException | com.farmers.framework.playwright.compat.PWNotFoundException e) {
                Log.error("Did not reach Quote Summary page, quote number: " + quoteNumber, true);
                Log.error(e.getMessage());
                throw e;
            }
        } else {
            new KnockOutPage();
            testStep("Knockout page reached, quote number: " + quoteNumber,true);
        }

        callRetrieveQuote(applicant, quoteNumber);

        if (!applicant.isKnockOutScenario) {
//  Quote Page
            quotePage = new QuotePage();
            Assert.assertEquals(quotePage.getQuoteNumber(), quoteNumber, "Quote Page - Retrieved correct quote number.");
            testStep("Quote successfully retrieved on Quote Summary page.", true);
            quotePage.clickDismissSurveyPopup();
            quotePage.validateSendEmail(applicant, fsa);
            quotePage.clickStepperAddress(null);
        }

//  Address Page
        addressPage = new AddressPage();
        addressPage.verifyPageFields(applicant, fsa);
        if (!applicant.isKnockOutScenario) {
            addressPage.verifyPageFieldsReadonly(fsa);
        }
        addressPage.clickButtonAgree();

//  Property Page
        propertyPage = new PropertyPage();
        propertyPage.verifyPageFieldsNotReadonly(fsa);
        propertyPage.clickNext();

//  Quality Grade Page
        qualityPage = new QualityGradePage();
        qualityPage.verifyPageFieldsNotReadonly(fsa);
        qualityPage.clickNext();

//  Property Details Page
        propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.verifyPageFieldsNotReadonly(fsa);
        propertyDetailsPage.clickNext();

//  Customer Info Page
        customerInfoPage = new CustomerInfoPage();
        customerInfoPage.validatePageFieldContents(applicant, false, fsa);
        if (!applicant.isKnockOutScenario) {
            customerInfoPage.verifyPageFieldsReadonly(applicant, false, fsa);
        }
        customerInfoPage.clickNext();

//  Contact Info Page
        contactInfoPage = new ContactInfoPage();
        contactInfoPage.validatePageFieldContents(applicant, false, fsa);
        if (!applicant.isKnockOutScenario) {
            contactInfoPage.verifyPageFieldsReadonly(fsa);
        }
        contactInfoPage.clickAgreeSubmitButton();

//  Discounts Page
        discountsPage = new DiscountsPage();
        discountsPage.validatePageFieldContents(applicant, false, fsa, null);
        discountsPage.verifyPageFieldsNotReadonly();
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
//  Quote Page
               quotePage = new QuotePage();
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                applicant.quoteRate = quotePage.getQuotePremiumMonthly();
            } else {
                applicant.quoteRate = quotePage.getQuotePremiumYearly(applicant.stateCode);
            }
            quotePage.clickQuoteDetails();
            QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
            quoteDetailsPage.updateSlidersRecalculate(applicant, fsa);
            quoteDetailsPage.clickCloseModal();
            testStep("Quote successfully re-rated on Quote Summary page.", true);

//  Validate Quote Page after Custom Rate
            quotePage = new QuotePage();
            quotePage.clickNext();

//  Thank You Page
            ThankYouPage thankYouPage = new ThankYouPage();
            if (thankYouPage.isCrossOptionDisplayed()) {
                thankYouPage.validatePageCrossSellTitles(fsa);
                thankYouPage.selectCrossSellType(AUTO);
                thankYouPage.clickStartSaving();
                String crossSellUrl = driver().getCurrentUrl();
                testStep("Cross-selling to Auto url:: " + crossSellUrl, true);

                AutoApplicant autoApplicant = new AutoApplicant(applicant, true);
                NameAndDobPage nameAndDobPage = new NameAndDobPage();
                nameAndDobPage.waitForSpinnerToBeGone();
                nameAndDobPage.isOnNameAndDobPage();
                fsa.assertEquals(nameAndDobPage.getFormFieldWebElementValue("First name"), autoApplicant.getFirstName(), "Name and Dob page - Applicant First name.");
                fsa.assertEquals(nameAndDobPage.getFormFieldWebElementValue("Last name"), autoApplicant.getLastName(), "Name and Dob page - Applicant Last name.");
                fsa.assertEquals(nameAndDobPage.getFormFieldWebElementValue("Date of birth"), autoApplicant.getDateOfBirth(), "Name and Dob page - Applicant Date of birth.");
                fsa.assertEquals(nameAndDobPage.getFormFieldWebElementValue("City"), autoApplicant.getCity(), "Name and Dob page - Applicant City.");
                fsa.assertEquals(nameAndDobPage.getFormFieldWebElementValue("Zip code"), autoApplicant.getZipCode(), "Name and Dob page - Applicant Zip code.");
                testStep("Validated Cross-sell to Auto has started.", true);
            } else {
                testStep("Cross-sell options were not displayed.", true);
            }
        } else {
            new KnockOutPage();
            testStep("Landed on Knock-out page.", true);
        }
        fsa.assertAll("Validated landing on Auto - Name and Dob page");
    }
}



