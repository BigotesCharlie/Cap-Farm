package com.farmers.ffq.acebusiness;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.ace.business.AceBusinessLeadForm;
import com.farmers.ffq.ace.business.AceBusinessNavigationHelper;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.dataproviders.SqlDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantBusiness;
import com.farmers.ffq.datatransferobjects.State;
import com.farmers.ffq.datatransferobjects.ApplicantBusiness.contactMethods;
import com.farmers.ffq.datatransferobjects.ApplicantBusiness.contactTimes;
import com.farmers.ffq.datatransferobjects.ApplicantBusiness.insuranceStatusValues;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.Property;

public class AceBusinessQuoteScenarioTests extends AutomationFramework {
	private List<String> listOfPolicyTypes = List.of(BUSINESSOWNER, COMMERCIAL_AUTO, WORKERS_COMPENSATION, OTHER);
	private static final Random randomNumberGenerator = new Random();

	@Test(dataProviderClass = SqlDataProviders.class, dataProvider = SqlDataProviders.STATES_DATA_PROVIDER_NAME, groups = REGRESSION)
	public void verifyStateSupportForBusiness(State state) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		LandingPage landingPage = new LandingPage(false, true);
		if (landingPage.isLOBButtonAvailable(LOB_BUSINESS)) {
			String applicantStateCode = state.getStateCode();
			String applicantState = state.getStateName();
			if (DataProviders.getListOfAceBusinessStates().contains(applicantStateCode)) {
				landingPage.enterLandingPageDataAndContinue(LOB_BUSINESS, state.getZipCode());
				fsa.assertTrue(new AceBusinessLeadForm().isOnBusinessLeadForm(), "Ace business supported for " + applicantState);
			} else {
				landingPage.enterLandingPageDataAndRemainInPage(LOB_BUSINESS, state.getZipCode());
				fsa.assertTrue(!new AceBusinessLeadForm().isOnBusinessLeadForm(), "Ace business lead form not reached for " + applicantState);
				switch (applicantStateCode) {
					case AK: case DE: case FL: case GU: case HI: case ME: case NH:
					case SC: case PR: case RI: case VI: case VT: case WV:
						fsa.assertTrue(landingPage.isNoOnlineQuotingErrorMessageRedAndVisible(), "Ace business not supported for " + applicantState);
						break;
					case TT:
						landingPage.landingPageValidation(fsa);
						break;
					default:
						//maybe an invalid zip code was provided??
						if (landingPage.invalidZipCodeErrorMessageRedAndVisible()) {
							fsa.assertTrue(true, String.format("Zip code %s not valid for %s", state.getZipCode(), applicantState));
						} else {
							fsa.assertTrue(landingPage.isNotOfferedInStateErrorMessageRedAndVisible(applicantStateCode), "Farmers does not offer business policies in " + applicantState);
						}
						break;
				}
			}
		} else {
			throw new SkipException("Environment " + Property.getTestProperty("environment") + " is not enabled for Ace Business");
		}
		fsa.assertAll();
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = PEWC)
	public void aceBusinessPEWCScreen(ApplicantBusiness businessApplicant) throws Exception {
		new AceBusinessNavigationHelper().navigateToBusinessInsuranceLeadForm(businessApplicant).capturePEWC();
		testStep("End Of Test");
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = REGRESSION)
	public void createDefaultBusinessLead(ApplicantBusiness businessApplicant) throws Exception {
		if (new Random().nextBoolean()) {
			businessApplicant.setBusinessId(AWS_SCENARIOS);
		}
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new AceBusinessNavigationHelper().navigateToBusinessInsuranceLeadForm(businessApplicant).fillOutPageAndContinue(businessApplicant);
		AceBusinessLeadForm leadForm = new AceBusinessLeadForm();
		fsa.assertTrue(leadForm.isOnBusinessLeadForm(), "Lead cannot complete because of missing policy type");
		fsa.assertAll();
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = REGRESSION)
	public void createBusinessLeadAllPolicyTypes(ApplicantBusiness businessApplicant) throws Exception {
		businessApplicant.setListOfPolicyTypes(listOfPolicyTypes);
		createABusinessLead(businessApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = {REGRESSION, ADA_SUITE, BUSINESS_ADA_SUITE})
	public void createBusinessLeadWithRandomSelections(ApplicantBusiness businessApplicant) throws Exception {
		if (new Random().nextBoolean()) {
			businessApplicant.setBusinessId(AWS_SCENARIOS);
		}
		randomizeApplicantSelections(businessApplicant);
		createABusinessLead(businessApplicant);
	}

	@Test( dataProviderClass = DataProviders.class, dataProvider = DataProviders.PRODUCTION_TEST_BUSINESS_APPLICANT_DATA_PROVIDER, groups = PRODUCTION_VALIDATION)
	public void productionValidationBusinessQuote(ApplicantBusiness businessApplicant) throws Exception {
		randomizeApplicantSelections(businessApplicant);
		createABusinessLead(businessApplicant);
	}

	private void createABusinessLead(ApplicantBusiness businessApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new AceBusinessNavigationHelper().navigateToBusinessThankYouPage(businessApplicant);
		fsa.assertAll();
	}

	private void randomizeApplicantSelections(ApplicantBusiness businessApplicant) {
		List<String> policyTypes = new ArrayList<>();
		policyTypes.addAll(listOfPolicyTypes);
		Collections.shuffle(policyTypes);
		businessApplicant.setListOfPolicyTypes(List.of(policyTypes.get(FIRST_AVAILABLE_OPTION)));
		int randomIndex = randomNumberGenerator.nextInt(3);
		switch (randomIndex) {
			case 0:
				businessApplicant.setCurrentInsuranceStatus(insuranceStatusValues.HAVE);
				break;
			case 1:
				businessApplicant.setCurrentInsuranceStatus(insuranceStatusValues.DONT_HAVE);
				break;
			case 2: default:
				businessApplicant.setCurrentInsuranceStatus(insuranceStatusValues.INTERESTED);
				break;
		}
		randomIndex = randomNumberGenerator.nextInt(3);
		switch (randomIndex) {
			case 0:
				businessApplicant.setContactMethodPreference(contactMethods.PHONE);
				break;
			case 1:
				businessApplicant.setContactMethodPreference(contactMethods.EMAIL);
				break;
			case 2: default:
				businessApplicant.setContactMethodPreference(contactMethods.NOPREFERENCE);
				break;
		}
		randomIndex = randomNumberGenerator.nextInt(3);
		switch (randomIndex) {
			case 0:
				businessApplicant.setContactTimePreference(contactTimes.MORNING);
				break;
			case 1:
				businessApplicant.setContactTimePreference(contactTimes.AFTERNOON);
				break;
			case 2: default:
				businessApplicant.setContactTimePreference(contactTimes.NOPREFERENCE);
				break;
		}
	}

}
