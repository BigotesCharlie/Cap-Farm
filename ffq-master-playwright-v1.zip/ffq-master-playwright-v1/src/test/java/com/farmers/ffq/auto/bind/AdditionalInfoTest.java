package com.farmers.ffq.auto.bind;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.Vehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import net.datafaker.Faker;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;


import java.util.List;
import java.util.Random;

import static com.farmers.ffq.common.pages.BasePage.getFormattedDateAfter8days;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.MONTHLY_AUTOPAY;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AdditionalInfoTest extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})
    public void testValidateValidVIN_AdditionalInfoTest(AutoApplicant applicant) throws Exception {
        new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        whoShouldWeInsurePage.validateValidVIN_WhoShouldWeInsurePage();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})
    public void testValidateInvalidVIN_AdditionalInfoTest(AutoApplicant applicant) throws Exception {
        new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalInfoVehicleSectionOneUI.validateInvalidVIN_AdditionalInfoPage(fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})
    public void testValidateReplaceValidWithInvalidVIN_AdditionalInfoTest(AutoApplicant applicant) throws Exception {
        new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        whoShouldWeInsurePage.validateReplaceValidWithInvalidVIN_WhoShouldWeInsurePage();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})
    public void bindOneUIFullFewMoreThingsPageValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        // just to get signal enrollment section validation randomly
        applicant.getDiscounts().get(0).setSignalSignup(new Random().nextBoolean());

        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper(applicant.getStateCode().equals(MS) ? quoteFlow.AGENT : quoteFlow.DEFAULT).navigateToAdditionalInfoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalInfoPolicyStartDateOneUI.verifyAdditionalInfoHeader(fsa);
        AppStore retrieveQuoteResponseSessionStorage = additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore();
        additionalInfoPolicyStartDateOneUI.verifyPolicyStartDateSection(retrieveQuoteResponseSessionStorage, false, fsa);
        AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        additionalInfoVehicleSectionOneUI.verifyVehicleSection(retrieveQuoteResponseSessionStorage, false, fsa);
        additionalInfoDriverSectionOneUI.verifyDriverSection(retrieveQuoteResponseSessionStorage, fsa);
        additionalInfoSignalEnrollmentSectionOneUI.verifySignalEnrollmentSection(retrieveQuoteResponseSessionStorage, new Random().nextBoolean(), fsa);
        additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();
        additionalInfoContinueToPaymentOneUI.logInfoMessage(retrieveQuoteResponseSessionStorage.getData().getQuoteNumber().trim());
        fsa.assertAll();
    }


    @Skip // don't need seperate method for mobile break point
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, suiteName = "few more things page", dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})
    public void bindOneUIFullFewMoreThingsPageValidationMobileBreakPoint(AutoApplicant applicant) throws Exception {
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper(applicant.getStateCode().equals(MS) ? quoteFlow.AGENT : quoteFlow.DEFAULT).navigateToAdditionalInfoPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalInfoPolicyStartDateOneUI.verifyAdditionalInfoHeader(fsa);
        AppStore retrieveQuoteResponseSessionStorage = additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore();
        BasePage basePage = new BasePage();
        basePage.setBrowserDimensionToMobileBreakPoint();
        additionalInfoPolicyStartDateOneUI.verifyPolicyStartDateSection(retrieveQuoteResponseSessionStorage, false, fsa);

        AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        additionalInfoVehicleSectionOneUI.verifyVehicleSection(retrieveQuoteResponseSessionStorage, true, fsa);
        additionalInfoDriverSectionOneUI.enterDriverLicenseNumber(retrieveQuoteResponseSessionStorage);
        additionalInfoSignalEnrollmentSectionOneUI.verifySignalEnrollmentSection(retrieveQuoteResponseSessionStorage, true, fsa);
        additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();
        fsa.assertAll();
    }

    /**
     * S.No:658 in R01 Regression Suite, Feature: F96692/US1053298 and Release: R12/2025
     * Validate Odometer Reading Date Format on Additional Info Page for CA state
     */
    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})
    public void validateOdometerReadingDateFormatOnAdditionalInfoPage(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.setLastName("Brown");
        applicant.setMaritalStatus(SINGLE);
        if (!applicant.getVehicles().isEmpty()) {
            applicant.getVehicles().get(0).setVehicleUsage("Commute");
        }
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper(applicant.getStateCode().equals(MS) ? quoteFlow.AGENT : quoteFlow.DEFAULT).navigateToAdditionalInfoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalInfoPolicyStartDateOneUI.verifyAdditionalInfoHeader(fsa);
        AppStore retrieveQuoteResponseSessionStorage = additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore();
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        additionalInfoVehicleSectionOneUI.verifyVehicleSection(retrieveQuoteResponseSessionStorage, false, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, IL, IN, MO, OH, OK, OR, TX, UT, WI, SD, MI, PA, WY, KS, CO, NM, IA, VA}), @CustomAttribute(name = FILTER, values = "applicantId=1")},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, ADDITIONAL_INFO})
    public void validateAdditionalInfoPageForBW(AutoApplicant applicant) throws Exception {
        applicant.setLastName("Threeoabaa");
        applicant.setTestScenario("BW->" + applicant.getTestScenario());
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        additionalInfoPolicyStartDateOneUI.verifyAdditionalInfoHeader(fsa);
        additionalInfoPolicyStartDateOneUI.enterPolicyStartDate(getFormattedDateAfter8days());
        AppStore retrieveQuoteResponseSessionStorage = additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore();
        additionalInfoPolicyStartDateOneUI.verifyPolicyStartDateSection(retrieveQuoteResponseSessionStorage, true, fsa);
        AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        additionalInfoVehicleSectionOneUI.verifyVehicleSection(retrieveQuoteResponseSessionStorage, false, fsa);
        additionalInfoDriverSectionOneUI.verifyDriverSection(retrieveQuoteResponseSessionStorage, fsa);
        additionalInfoSignalEnrollmentSectionOneUI.verifySignalEnrollmentSection(retrieveQuoteResponseSessionStorage, true, fsa);
        additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();
        additionalInfoContinueToPaymentOneUI.logInfoMessage(retrieveQuoteResponseSessionStorage.getData().getQuoteNumber().trim());
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDITIONAL_INFO})
    public void testSaveAdditionalInfo_Call(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(false);
        BasePage basePage = new BasePage();
        additionalInfoPolicyStartDateOneUI.validateSaveQuoteSideSheet(fsa);
        basePage.clickSaveQuoteModalSubmitButton();
        basePage.isEmailConfirmationDisplayed(applicant.getEmail());
        AppStore retrieveQuoteResponseSessionStorage = additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore();
        String saveAdditionalInfoStatus = retrieveQuoteResponseSessionStorage.getServiceControlData().getSaveAdditionalInfo();
        fsa.assertEquals(saveAdditionalInfoStatus, "success", "SaveAdditional API verification");
        fsa.assertTrue(!retrieveQuoteResponseSessionStorage.getAuto().getDrivers().get(0).getLicNumber().isEmpty(), "Drivers LicenseNumber added");
        String mailID = retrieveQuoteResponseSessionStorage.getData().getCustomerData().getCommunication().getEmailId().getEmailAddress();
        fsa.assertEquals(mailID, applicant.getEmail(), "MailID verification");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {NC, NV, MA, CT, FL})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validate_mismatchedDrivers_performAutoVerify_JFMT(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        if (additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage()) {
            additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
            AppStore retrieveQuoteResponseSessionStorage = additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore();
            String mismatchedDriversStatus = retrieveQuoteResponseSessionStorage.getServiceControlData().getMismatchedDrivers();
            String performAutoVerifyStatus = retrieveQuoteResponseSessionStorage.getServiceControlData().getPerformAutoVerify();
            FarmersSoftAssert fsa = new FarmersSoftAssert();
            fsa.assertEquals(performAutoVerifyStatus, "success", "performAutoVerify API");
            fsa.assertEquals(mismatchedDriversStatus, "success", "mismatchedDrivers API");
            fsa.assertAll();
        }

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {IL, WY})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validate_mismatchedDrivers_performAutoVerify_clickingSaveQuote(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName(new Faker().name().lastName());
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AppStore retrieveQuoteResponseSessionStorage = additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore();
        String mismatchedDriversStatus = retrieveQuoteResponseSessionStorage.getServiceControlData().getMismatchedDrivers();
        String performAutoVerifyStatus = retrieveQuoteResponseSessionStorage.getServiceControlData().getPerformAutoVerify();
        if (additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage() && additionalInfoPolicyStartDateOneUI.isAutoSaveDisabled()) {
            // checking the API calls by clicking saveQuote button without filling any details
            additionalInfoPolicyStartDateOneUI.clickOnSaveQuoteButton();
            additionalInfoPolicyStartDateOneUI.clickSaveQuoteModalSubmitButton();
            try {
                fsa.assertTrue(mismatchedDriversStatus.equalsIgnoreCase("success"), "mismatchedDrivers API is getting called");
                fsa.assertTrue(performAutoVerifyStatus.equalsIgnoreCase("success"), "performAutoVerify API is getting called");
            } catch (Exception e) {
                Log.info("mismatchedDrivers & performAutoVerify Api calls status returning 'null' as expected without any Additional Info details");
            }
            // checking the API calls by clicking saveQuote button with Invalid details details
            additionalInfoPolicyStartDateOneUI.validate_AdditionalInfoPage_InvalidData(applicant);
            additionalInfoPolicyStartDateOneUI.clickOnSaveQuoteButton();
            additionalInfoPolicyStartDateOneUI.clickSaveQuoteModalSubmitButton();
            try {
                fsa.assertTrue(mismatchedDriversStatus.equalsIgnoreCase("success"), "mismatchedDrivers API is getting called");
                fsa.assertTrue(performAutoVerifyStatus.equalsIgnoreCase("success"), "performAutoVerify API is getting called");
            } catch (Exception e) {
                Log.info("mismatchedDrivers & performAutoVerify Api calls status returning 'null' as expected with Invalid Additional Info details");
            }
            // checking the API calls by clicking saveQuote button filling with valid details
            additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(false);
            additionalInfoPolicyStartDateOneUI.clickOnSaveQuoteButton();
            additionalInfoPolicyStartDateOneUI.clickSaveQuoteModalSubmitButton();
            try {
                fsa.assertTrue(mismatchedDriversStatus.equalsIgnoreCase("success"), "mismatchedDrivers API is getting called");
                fsa.assertTrue(performAutoVerifyStatus.equalsIgnoreCase("success"), "performAutoVerify API is getting called");
            } catch (Exception e) {
                Log.info("mismatchedDrivers & performAutoVerify Api calls status returning 'null' as expected with valid Additional Info details");
            }
        }
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {IL, WY})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validate_notTocall_mismatchedDrivers_performAutoVerify_clickingPurchaseStepper(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        AppStore retrieveQuoteResponseSessionStorage = additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore();
        String mismatchedDriversStatus = retrieveQuoteResponseSessionStorage.getServiceControlData().getMismatchedDrivers();
        String performAutoVerifyStatus = retrieveQuoteResponseSessionStorage.getServiceControlData().getPerformAutoVerify();

        //checking API calls after clicking Purchase stepper in JFMT
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(false);
        additionalInfoPolicyStartDateOneUI.clickPurchaseNavigationBarStepper();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        try {
            fsa.assertTrue(mismatchedDriversStatus.equalsIgnoreCase("success"), "mismatchedDrivers API is getting called");
            fsa.assertTrue(performAutoVerifyStatus.equalsIgnoreCase("success"), "performAutoVerify API is getting called");
        } catch (Exception e) {
            Log.info("mismatchedDrivers & performAutoVerify Api calls status returning 'null' as expected with valid Additional Info details");
        }

        //checking API calls by clicking Purchase stepper in Payment selection page
        additionalInfoPolicyStartDateOneUI.clickContinueButton();
        sleep(6);
        fsa.assertTrue(additionalInfoContinueToPaymentOneUI.isOnContinueToPaymentPage(), "Did not reach Payment Page");
        additionalInfoContinueToPaymentOneUI.clickPurchaseNavigationBarStepper();
        try {
            fsa.assertTrue(mismatchedDriversStatus.equalsIgnoreCase("success"), "mismatchedDrivers API is getting called");
            fsa.assertTrue(performAutoVerifyStatus.equalsIgnoreCase("success"), "performAutoVerify API is getting called");
        } catch (Exception e) {
            Log.info("mismatchedDrivers & performAutoVerify Api calls status returning 'null' as expected with valid Additional Info details");
        }
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {IL, NM})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validate_BrightLine_Suspended_RevokedDriversLicense(AutoApplicant applicant) throws Exception {
        //Setting Applicant dat to MVR data, to validate Reverse Brightline with Suspended or Revoked Drivers License in JAFMT page
        applicant.setTestScenario(SUSPENDED_DL + applicant.getTestScenario());
//        switch (applicant.getStateCode()) {
//            case AZ:
//                applicant.setZipCode("85209");
//                applicant.setFirstName("MARLISSA");
//                applicant.setLastName("LEDKAY");
//                applicant.setDateOfBirth("04/07/1986");
//                applicant.setResidentAddress("8522 E MILAGRO AVE");
//                applicant.setGender("Female");
//                break;
//            case IL:
//                applicant.setZipCode("62095");
//                applicant.setFirstName("RAY");
//                applicant.setLastName("BROWN");
//                applicant.setDateOfBirth("06/11/1935");
//                applicant.setResidentAddress("267 EDWARD ST");
//                applicant.setGender("Male");
//                break;
//            case NM:
//                applicant.setZipCode("87401");
//                applicant.setFirstName("TODD");
//                applicant.setLastName("JERRY");
//                applicant.setDateOfBirth("09/04/1959");
//                applicant.setResidentAddress("711 S ORCHARD AVE");
//                applicant.setGender("Male");
//                break;
//        }
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(false);
        additionalInfoPolicyStartDateOneUI.validate_Brightline_Suspended_RevokedDriversLicense(applicant);
        additionalInfoPolicyStartDateOneUI.clickContinueButton();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        sleep(10);
        fsa.assertTrue(new ContinueWithBristolWestPage().isContinueWithBristolWestDialogDisplayed(), "Brightlined BW Consent page appears");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=2"}), @CustomAttribute(name = EXCLUDED_STATES, values = {MA, CA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validate_reverseBrightlIne(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setCurrentlyInsuredStatus("Insured");
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
//        if (whoShouldWeInsurePage.isOnWhoShouldWeInsurePage()) {
//            switch (applicant.getStateCode()) {
//                case TN:
//                    whoShouldWeInsurePage.selectCurrentBodilyInjuryLimits("$25,000/$50,000");
//                    //                case MA:
//                    //                    whoShouldWeInsurePage.selectCurrentBodilyInjuryLimits("$100,000/$300,000");
//                case KY:
//                    whoShouldWeInsurePage.selectCurrentBodilyInjuryLimits(_500K_AND_500K);
//            }
//        }
//        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
//        if (vehicleReviewPage.isOnVehiclesReviewPage()) {
//            switch (applicant.getStateCode()) {
//                case TN:
//                    vehicleReviewPage.setVehicleOwnership("Owned", 1);
//                    //                case MA:
//                    //                    vehicleReviewPage.setVehicleOwnership("Leased", 1);
//                case KY:
//                    vehicleReviewPage.setVehicleOwnership("Financed", 1);
//            }
//        }
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
        //  sleep(4);
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        fsa.assertTrue(continueWithBristolWestPage.isOnContinueWithBristolWestPage(), "User should land on the BW continue page for reverse brightline");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void verifyJFMTPagePrivacyPolicyLinks(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalInfoPolicyStartDateOneUI.verifyJFMTPagePrivacyPolicyLinks(fsa);
        fsa.assertAll();
    }


    /**
     * "Create VA auto quote with spouse as lives away from home
     * Enroll for signal &  rate the quote
     * Proceed to Rate
     * Continue to land on JFMT
     * Verify signal enrollment option not displayed for spouse
     * Continue & bind it to policy"
     *
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = INCLUDED_STATES, values = {VA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateSignalSectionIsNotDisplayedForLivingAwaySpouse(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Bailey");
        applicant.getDiscounts().get(0).setSignalSignup(true);

        new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        testStepAssertTrue(vehiclesDriversInfoPage.isOnVehiclesDriversInfoPage(), "User is not navigated to Vehicles and Drivers Info page");
        if (vehiclesDriversInfoPage.isOnVehiclesDriversInfoPage()) {
            vehiclesDriversInfoPage.selectAndEditDefaultAdpfDrivers(List.of("Lives away from home"));
        }

        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is navigated to Quote Summary page");

        quoteSummaryAutoPage.clickOnStartCheckoutButton();
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        testStepAssertTrue(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User is  navigated to Additional Info page");

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        additionalInfoSignalEnrollmentSectionOneUI.verifySignalEnrollmentSectionForLivingAwaySpouse(applicant, fsa);
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        testStepAssertTrue(autoPolicyPaymentBasePage.isOnContinueToPaymentPage(), "User is not navigated to Payment page");
        completePurchase(MONTHLY_AUTOPAY, PaymentMethods.BANK_ACCOUNT_1, true, fsa);
        fsa.assertAll();
    }


    /**
     * Ace auto and bind- US1111703 (Test scenarios 709 - 715)
     * Applicant starts with 5 vehicles; trim to 3, set one Owned/one Leased/one Financed,
     * at least one identified by VIN and one by YMM, then validate the Additional Info page.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=9"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, NJ, CA, WA, AK, DC, DE, HI, ME, NH, NY, OR, RI, SC, VT, WV})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateR03_1_2026_for_US1111703(AutoApplicant applicant) throws Exception {

        updateApplicantDataToAvoidPossibleBw(applicant);

        // Applicant has 5 vehicles — keep exactly 3 (remove the last 2)
        applicant.setVehicles(new java.util.ArrayList<>(applicant.getVehicles().subList(0, 3)));

        // Vehicle 0 – Owned + identified by VIN
        Vehicle vehicle1 = applicant.getVehicles().get(0);
        vehicle1.setOwnership("Owned");
        vehicle1.setUseVIN(true);
        vehicle1.setVehicleUsage("Personal");

        // Vehicle 1 – Leased + identified by YMM
        Vehicle vehicle2 = applicant.getVehicles().get(1);
        vehicle2.setOwnership("Leased");
        vehicle2.setUseVIN(false);
        vehicle2.setVehicleUsage("Personal");

        // Vehicle 2 – Financed + identified by VIN
        Vehicle vehicle3 = applicant.getVehicles().get(2);
        vehicle3.setOwnership("Financed");
        vehicle3.setUseVIN(true);
        vehicle3.setVehicleUsage("Personal");

        // set signal discount to true
        applicant.getDiscounts().get(0).setSignalSignup(true);


        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI =
                new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        // Header validation : Validate if the title of JAFMT/Additional Info screen displays as "Review and complete auto" (Scenario 709)
        additionalInfoPolicyStartDateOneUI.validateAdditionalInfoPageHeader(fsa, "Review and complete auto");

        // Validate if the following text (subtitle) “Please fill out these las few details so we can complete your purchase” does NOT displays. (Scenario 710)
        additionalInfoPolicyStartDateOneUI.validateSubtitleIsNotDisplayed(fsa, "Please fill out these last few details so we can complete your purchase");

        // Validate if the following text “Auto policy start date” displays above the date input field. (Scenario 711)
        additionalInfoPolicyStartDateOneUI.validatePolicyStartDateLabelIsDisplayedAboveTheInputField(fsa, "Auto policy start date");

        // Validate if the VIN Input field displays first and only then the Loan/Leasing company field displays for Vehicles added via YMM with Leased/Financed ownerships.(Scenario 712)
        additionalInfoPolicyStartDateOneUI.validateVinIsDisplayedFirstThenLoanLease(fsa);

        // "Pre-requisite: 'Signal' should be added during the Quote flow
        //Validate if the below text displays under the signal enrollment section:
        //Safe driving leads to bigger rewards at renewal.
        //Fill out the info below to get a discount by enrolling drivers in Signal. Enrolling more drivers can help increase your discount. We'll send a text to download the Signal app later."
        // Scenario 713
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        additionalInfoSignalEnrollmentSectionOneUI.validateSignalMessages(fsa);

        //"Pre-requisite: 'Signal' should be added during the Quote flow
        //Validate if the following text displays under each driver listed on the signal enrollment section:
        //Text: This driver will need to download and use the Signal app to qualify for a discount."
        // Scenario 714
        additionalInfoSignalEnrollmentSectionOneUI.validateSignalMessagesForEachDriver(fsa);

        //"Pre-requisite: 'Signal' should be added during the Quote flow
        //Validate if the email address field does NOT displays for PNI & Additional drivers on the signal enrollment section."
        additionalInfoSignalEnrollmentSectionOneUI.validateEmailAddressesNotDisplayed(fsa);

        fsa.assertAll();
    }


}
