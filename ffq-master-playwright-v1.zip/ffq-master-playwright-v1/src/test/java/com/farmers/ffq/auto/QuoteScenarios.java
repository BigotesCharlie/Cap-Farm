package com.farmers.ffq.auto;


import com.farmers.framework.playwright.compat.*;
import static com.farmers.framework.playwright.compat.PWExpectedConditions.*;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.AutoBasePage.KnockoutException;
import com.farmers.ffq.auto.pages.legacy.AdditionalInformationPage;
import com.farmers.ffq.auto.pages.legacy.CongratulationsPage;
import com.farmers.ffq.auto.pages.legacy.DiscountsPage;
import com.farmers.ffq.auto.pages.legacy.DriversPage;
import com.farmers.ffq.auto.pages.legacy.PaymentPage;
import com.farmers.ffq.auto.pages.legacy.QuotePageAuto;
import com.farmers.ffq.auto.pages.legacy.ThankYouPage;
import com.farmers.ffq.auto.pages.legacy.VehiclesPage;
import com.farmers.ffq.auto.pages.legacy.YourInfoPageAuto;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.SqlDataProviders;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.datatransferobjects.SqlDiscount;
import com.farmers.ffq.datatransferobjects.SqlVehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class QuoteScenarios extends AutomationFramework {

	@Test(dataProvider = SqlDataProviders.HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = {REGRESSION, SPOT_TESTING})
	public void getAutoQuote(SqlApplicant applicant) throws Exception {
		createAutoQuote(applicant, false);
	}

	@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_SAVE_AND_RETRIEVE_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = {REGRESSION})
	public void getAutoQuoteForRetrieval(SqlApplicant applicant) throws Exception {
		createAutoQuote(applicant, false);
	}

	@Test(dataProvider = SqlDataProviders.BVT_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = {AUTO_BVT, PEWC, ENV_STABILITY})
	public void autoBuildValidationTest(SqlApplicant applicant) throws Exception {
		createAutoQuote(applicant, false);
	}

	@Test(dataProvider = SqlDataProviders.JENKINS_AUTO_APPLICANT_SMOKE_TEST_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = "smokeTest")
	public void autoSmokeTests(SqlApplicant applicant) throws Exception {
		createAutoQuote(applicant, false);
	}

	@Test(dataProvider = SqlDataProviders.JENKINS_AUTO_APPLICANT_QUOTE_SCENARIOS_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = "quoteScenarios")
	public void autoQuoteScenarioTests(SqlApplicant applicant) throws Exception {
		createAutoQuote(applicant, false);
	}

	@Test(dataProvider = SqlDataProviders.JENKINS_AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = "pageValidation")
	public void autoPageValidationTests(SqlApplicant applicant) throws Exception {
		createPartialAutoQuote(applicant);
	}

	@Test(dataProvider = SqlDataProviders.HIGH_VALUE_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = {MOBILE_REGRESSION})
	public void mobileAutoQuoteTests(SqlApplicant applicant) throws Exception {
		applicant.setTestCategory(MOBILE_BROWSER);
		createAutoQuote(applicant, false);
	}

	@Test(dataProvider = SqlDataProviders.ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, groups = CI_CD_SUITE)
	public void bvtAutoQuotes(SqlApplicant applicant) throws Exception {
		applicant.setTestScenario("FGS");
		autoBuildValidationTest(applicant);
	}

	@Test(dataProvider = SqlDataProviders.TEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = MONETIZED_STATES)}, groups = REGRESSION)
	public void createAutoQuoteWithAOR(SqlApplicant applicant) throws Exception {
		applicant.setTestCategory(AWS_SCENARIOS);
		if (applicant.getStateCode().equals(NY)) {
			applicant.setKnockoutExpected(true);
		}
		createAutoQuote(applicant, false);
	}
	public void createPartialAutoQuote(SqlApplicant applicant) throws Exception {
		String testScenario = applicant.getTestScenario();
		YourInfoPageAuto infoPage = enterLobAndZipCode(applicant);
		String applicantStateCode = applicant.getStateCode();
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		if (testScenario.equals(INFO_PAGE_VALIDATION)){
			infoPage.setCurrentlyInsured(false);
			fsa.assertEquals(infoPage.validatePageTitle(), true, "Your Info page title content valid");
			fsa.assertEquals(infoPage.validatePageSubtitle(), true, "Your Info page subtitle content valid");
			fsa.assertEquals(infoPage.validatePageDisclaimer(applicant), true, "Your Info page disclaimer valid");
			fsa.assertEquals(infoPage.validateSectionsLabel(), true, "Addess section label - Your Info Page");
			infoPage.validateGTMTags(applicantStateCode, fsa);
			fsa.assertEquals(infoPage.validateErrorMessages(applicantStateCode, fsa), true, "Your Info page error messages valid");
			if (!applicant.getTestCategory().equals(MOBILE_BROWSER)) {
				fsa.assertEquals(infoPage.validateHyperlinks(), true, "Your Info page hyperlinks valid");
			}
			if (infoPage.isEmployerGroupQuestionState(applicantStateCode)) {
				infoPage.validateWorkGroupDescription(fsa);
			} else {
				fsa.assertFalse(infoPage.isEmployerGroupDropDownPresent(), "Employer Group drop-down should not be displayed for " + applicantStateCode);
			}
			infoPage.validateFAQs(fsa);
		} else {
			VehiclesPage vehiclesPage = infoPage.fillOutPageAndContinue(applicant);
			vehiclesPage.logAutoQuoteNumber(applicant);
			if (applicantStateCode.equals(NC)) {
				applicant = setTestDataForNC(applicant);
			}
			if (applicant.getTestScenario().equalsIgnoreCase("Drop off - Vehicles") || testScenario.equals(VEHICLE_PAGES_VALIDATION)) {
				fsa.assertEquals(vehiclesPage.validateAddVehicleFAQButtons(applicantStateCode, fsa), true, "Add Vehicles dialog FAQ messages validation");
				vehiclesPage.validateGTMTags(fsa);
				fsa.assertEquals(vehiclesPage.validateAddVehicleErrorMessages(applicantStateCode, fsa), true, "Add Vehicles dialog error message validation");
				if (vehiclesPage.enterYMMTDataForFirstVehicle(applicant.getVehicles().get(0))) {
					vehiclesPage.validateAddVehicleDialogLabels(applicantStateCode, fsa);
				}
			} else {
				int maximumVehiclesAllowed = vehiclesPage.limitVehicleCountToMaxAllowed(applicantStateCode, applicant.getVehicles().size());
				for (int v=0; v < maximumVehiclesAllowed; v++) {
					SqlVehicle vehicleInfo = applicant.getVehicles().get(v);
					vehiclesPage.addAVehicle(vehicleInfo, applicant);
				}
				DriversPage driversPage = vehiclesPage.forwardToDriversPage();
				if (testScenario.equals(DRIVER_PAGES_VALIDATION)) {
					driversPage.validateDriversPageContent(fsa);
					driversPage.validatePNIPageErrorMessages(applicant, fsa);
					driversPage.validatePNIFAQs(applicant, fsa);
					driversPage.validateGTMTags(fsa);
				}
				driversPage.addPNIDriverInformation(applicant);
				for (int d=0; d<applicant.getAdditionalDrivers().size() && d< MAX_NUMBER_OF_ADDITIONALDRIVERS; d++) {
					SqlAdditionalDriver additionalDriver = applicant.getAdditionalDrivers().get(d);
					if (testScenario.equals(DRIVER_PAGES_VALIDATION)) {
						driversPage.validateAdditionalDriversFAQs(additionalDriver, applicantStateCode, fsa);
						driversPage.validateAdditionalDriverErrorMessages(additionalDriver, applicantStateCode, fsa);
					}
					driversPage.addAdditionalDriver(additionalDriver, applicant.getIncidents(), applicantStateCode, d+1);
				}
				if (testScenario.equals(QUOTE_PAGE_VALIDATION)) {
					driversPage.enterAdditionalDetails(applicant, fsa);
					driversPage.enterVehicleAssignmentData(applicant, false, fsa);
					DiscountsPage discountsPage = new DiscountsPage();
					if (applicant.isKnockoutExpected()) {
						discountsPage.fillForm(applicant, fsa);
						verifyKnockoutPage(applicant.getTestCategory());
					} else {
						try {
							QuotePageAuto quotePage = discountsPage.fillForm(applicant, fsa);
							quotePage.validatePage(applicant, true, fsa);
						} catch (AssertionError ae) {
							fsa.fail("Encountered a problem in Quote Page validation: " + ae.getMessage()); //to generate a screenshot
						}
					}
				}
			}
		}
		fsa.assertAll();
	}

	public void createCrossSellAutoQuote(SqlApplicant applicant, String returnToLOB) throws Exception {
		// Normalize bundle information
		SqlDiscount  applicantDiscounts = applicant.getDiscounts();
		applicantDiscounts.setRentersInsurance(false);
		applicantDiscounts.setHomeInsurance(false);
		applicantDiscounts.setCondoInsurance(false);
		applicantDiscounts.setValueTermLifeInsurance(false);

		FarmersSoftAssert fsa = new FarmersSoftAssert();
		YourInfoPageAuto yourInfoPageAuto = new YourInfoPageAuto();
		yourInfoPageAuto.selectSubscriptionCheckbox();
		yourInfoPageAuto.clickContinueToVehiclesPage();
		VehiclesPage vehiclesPage = new VehiclesPage();
		addDataForAutoQuote(applicant, vehiclesPage, false, fsa);
		QuotePageAuto quotePage = new QuotePageAuto();
		if (quotePage.hasCrossSellQuote(returnToLOB)) {
			quotePage.clickCrossSellQuote(returnToLOB);
		} else {
			quotePage.clickContinueButton();
			quotePage.clickCrossSellQuote(returnToLOB);
		}
	}

	public void createAutoQuote(SqlApplicant applicant, boolean performDeepValidation) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		try {
			YourInfoPageAuto infoPage = enterLobAndZipCode(applicant);
			if (applicant.getTestCategory().contains(AWS_SCENARIOS) && performDeepValidation) {
				fsa.assertTrue(infoPage.isAgentAssigned(applicant), "Expected agent assigned found");
			}
			VehiclesPage vehiclesPage = infoPage.fillOutPageAndContinue(applicant);
			vehiclesPage.logAutoQuoteNumber(applicant);
			addDataForAutoQuote(applicant, vehiclesPage, performDeepValidation, fsa);
		} catch (KnockoutException knockout) {
			BasePage.writeDataToKnockoutLogFile("Legacy Auto - " + applicant.logInformationString() + SPACE + knockout.getMessage());
			if (!applicant.isKnockoutExpected()) {
				fsa.fail("Quote was knocked out: " + knockout.getMessage() + NEWLINE); //to generate a screenshot
			}
		} finally {
			fsa.assertAll();
		}
	}

	private void addDataForAutoQuote(SqlApplicant applicant, VehiclesPage vehiclesPage, boolean performDeepValidation, FarmersSoftAssert fsa) throws Exception {
		// For US479280: select a BMW vehicle from the ADPF list
		if (applicant.getTestCategory().contains("US479280")) {
			vehiclesPage.checkVehicleByName("2002 BMW 325 XI 4D 4WD");
			vehiclesPage.addAVehicleADPF(null);
		}
		//
		String applicantStateCode = applicant.getStateCode();
		if (applicantStateCode.equals(NC)) {
			applicant = setTestDataForNC(applicant);
		}
		int maximumVehiclesAllowed = vehiclesPage.limitVehicleCountToMaxAllowed(applicantStateCode, applicant.getVehicles().size());
		for (int v=0; v < maximumVehiclesAllowed; v++) {
			SqlVehicle vehicleInfo = applicant.getVehicles().get(v);
			fsa.assertEquals(vehiclesPage.addAVehicle(vehicleInfo, applicant), true, "Sucessfully adding vehicle " + Integer.toString(v+1));
		}
		if (!vehiclesPage.saveQuoteAndFinishLater(applicant)) {
			DriversPage driversPage = vehiclesPage.forwardToDriversPage();
			driversPage.addPNIDriverInformation(applicant);
			for (int d=0; d<applicant.getAdditionalDrivers().size() && d< MAX_NUMBER_OF_ADDITIONALDRIVERS; d++) {
				SqlAdditionalDriver additionalDriver = applicant.getAdditionalDrivers().get(d);
				fsa.assertEquals(driversPage.addAdditionalDriver(additionalDriver, applicant.getIncidents(), applicantStateCode, d+1), true, "Adding additional driver: " + Integer.toString(d+1));
			}
			if (!driversPage.saveQuoteAndFinishLater(applicant)) {
				boolean isCrossSellQuote = driversPage.findInCallStack(CREATE_CROSS_SELL_AUTO_QUOTE);
				if (isCrossSellQuote) {
					driversPage.forwardToAdditionalInfo();
					driversPage.clickAdditionalDetailsNextButton();
				} else {
					driversPage.enterAdditionalDetails(applicant, fsa);
				}
				DiscountsPage discountsPage = driversPage.enterVehicleAssignmentData(applicant, performDeepValidation, fsa);
				if (!discountsPage.saveQuoteAndFinishLater(applicant)) {
					QuotePageAuto quotePage = discountsPage.fillForm(applicant, fsa);
					if (!quotePage.saveQuoteAndFinishLater(applicant)) {
						if (quotePage.findInCallStack(SAVE_AUTO_QUOTE)) {
							// Implicitly saved completed quote
							fsa.assertTrue(quotePage.isOnLegacyAutoQuotePage(),"Quote page found");
							quotePage.saveImplicitQuoteAndRetrieveLater(applicant);
							retrieveAutoQuote(applicant, fsa);
						} else {
							if (isCrossSellQuote || quotePage.findInCallStack(AUTO_STABILITY) || quotePage.findInCallStack("createAnAutoQuote") ||
									quotePage.findInCallStack("autoQuoteScenarioTests") || quotePage.findInCallStack("autoSmokeTests") ||
									applicant.getTestCategory().equals("Bristol West") || quotePage.findInCallStack("productionValidationNonAceAutoQuote") ||
									(!performDeepValidation && quotePage.findInCallStack(AUTO_BVT))) {
								fsa.assertTrue(quotePage.isOnLegacyAutoQuotePage(),"Quote page found");
								quotePage.logQuoteNumber(applicant);
							} else {
								if (applicant.getTestScenario().equals("DE164212Test")) {
									Log.warn("Quote Page", "QuotePage_" + applicant.getStateCode());
								} else {
									quotePage.validatePage(applicant, performDeepValidation, fsa);
								}
								if (applicant.isAttemptToBind()) {
									attemptToBindQuote(applicant, discountsPage, quotePage, fsa);
								}
							}
						}
					} else { // Saved quote in quote page
						retrieveAutoQuote(applicant, fsa);
					}
				} else { // Saved quote in discounts page
					retrieveAutoQuote(applicant, fsa);
				}
			} else { // Saved quote in drivers page
				retrieveAutoQuote(applicant, fsa);
			}
		} else { // Saved quote in vehicles page
			retrieveAutoQuote(applicant, fsa);
		}
	}


	private YourInfoPageAuto enterLobAndZipCode(SqlApplicant applicant) throws Exception {
		String testCategory = applicant.getTestCategory();
		if (testCategory.contains(AWS_SCENARIOS)) {
			new LandingPage(applicant).enterLandingPageDataAndContinue(LOB_AUTO, applicant.getZipCode());
		} else {
			new LandingPage(testCategory.equals(MOBILE_BROWSER)).enterLandingPageDataAndContinue(LOB_AUTO, applicant.getZipCode());
		}
		return new YourInfoPageAuto();
	}

	private void verifyKnockoutPage(String testScenario) throws Exception {
		KnockOutPage knockoutPage = new KnockOutPage(testScenario);
		knockoutPage.verifyKnockoutPage(testScenario);
	}

	private void verifyCongratulationsPage(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		new CongratulationsPage().verifyCongratulationsPage(applicant, fsa);
	}

	private void verifyPaymentPage(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		new PaymentPage().processPaymentPage(applicant, fsa);
	}

	private boolean verifyAdditionalInformationPage(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		AdditionalInformationPage additionalInformationPage = new AdditionalInformationPage();
		if (applicant.getTestScenario().equals("DE164212Test")) {
			Log.warn("Additional Info Page", "AdditionalInfoPage_" + applicant.getStateCode());
		}
		return additionalInformationPage.verifyAdditionalInformationPage(applicant, fsa);
	}

	private void retrieveAutoQuote(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		Object resumeOnPage = new LandingPage().enterRetrieveQuote(applicant, EMPTY_STRING);
		switch (resumeOnPage.getClass().getSimpleName()) {
		case VEHICLES_PAGE_AUTO :
			VehiclesPage vehiclesPage = VehiclesPage.class.cast(resumeOnPage);
			fsa.assertTrue(vehiclesPage.isQuoteNumberPresent(), "Returned to vehicles page");
			resumeFromVehiclesPage(applicant, vehiclesPage, fsa);
			break;
		case DRIVERS_PAGE_AUTO :
			DriversPage driversPage = DriversPage.class.cast(resumeOnPage);
			fsa.assertTrue(driversPage.isQuoteNumberPresent(), "Returned to drivers page");
			resumeFromDriversPage(applicant, driversPage, false, fsa);
			break;
		case DISCOUNTS_PAGE_AUTO :
			DiscountsPage discountsPage = DiscountsPage.class.cast(resumeOnPage);
			fsa.assertTrue(discountsPage.isQuoteNumberPresent(), "Returned to discounts page");
			resumeFromDiscountsPage(applicant, discountsPage, fsa);
			break;
		case QUOTE_PAGE_AUTO :
			QuotePageAuto quotePageAuto = QuotePageAuto.class.cast(resumeOnPage);
			fsa.assertTrue(quotePageAuto.isQuoteNumberPresent(), "Returned to quote page");
			new ThankForRetreivingQuotePage().clickContinueButton();
			resumeFromQuotePage(applicant, quotePageAuto, fsa);
			// For US479280: move back to Vehicles page and update a BMW vehicle, continue to the quote page again
			if (applicant.getTestCategory().contains("US479280")) {
				quotePageAuto.clickQuickLink(VEHICLES);
				vehiclesPage = new VehiclesPage();
				vehiclesPage.editVehicleByName("2002 BMW 325 XI 4D 4WD");
				vehiclesPage.addAVehicleADPF("Pleasure");
				vehiclesPage.forwardToDriversPage();
				driversPage = new DriversPage();
				driversPage.forwardToAdditionalInfo();
				discountsPage = new DiscountsPage();
				discountsPage.clickContinueToNextPage();
				discountsPage.clickContinueToNextPage();
				discountsPage.continueToQuotePage();
				quotePageAuto = new QuotePageAuto();
				fsa.assertTrue(quotePageAuto.isOnLegacyAutoQuotePage(), "Quote page - quote was re-rated successfully.");
			}
			//
			if (applicant.getTestScenario().contains("update premium")) {
				quotePageAuto.updateQuoteAndRate(applicant, applicant.getStateCode().equals(MA));
			}
			break;
		default:
			throw new IllegalArgumentException("Wrong class name: " + resumeOnPage.getClass().getSimpleName());
		}
	}

	private void resumeFromVehiclesPage(SqlApplicant applicant, VehiclesPage vehiclesPage, FarmersSoftAssert fsa) throws Exception {
		int maximumVehiclesAllowed = vehiclesPage.limitVehicleCountToMaxAllowed(applicant.getStateCode(), applicant.getVehicles().size());
		for (int v=0; v < maximumVehiclesAllowed; v++) {
			SqlVehicle vehicleInfo = applicant.getVehicles().get(v);
			fsa.assertTrue(vehiclesPage.verifyVehiclePresent(vehicleInfo), "Checking vehicle: " + v);
		}
		DriversPage driversPage = vehiclesPage.forwardToDriversPage();
		resumeFromDriversPage(applicant, driversPage, true, fsa);
	}

	private void resumeFromDriversPage(SqlApplicant applicant, DriversPage driversPage, boolean addPNIDriver, FarmersSoftAssert fsa) throws Exception {
		if (addPNIDriver) {
			driversPage.addPNIDriverInformation(applicant);
		}
		for (int d=0; d<applicant.getAdditionalDrivers().size() && d< MAX_NUMBER_OF_ADDITIONALDRIVERS; d++) {
			SqlAdditionalDriver additionalDriver = applicant.getAdditionalDrivers().get(d);
			fsa.assertEquals(driversPage.addAdditionalDriver(additionalDriver, applicant.getIncidents(), applicant.getStateCode(), d+1), true, "Adding additional driver: " + d+1);
		}
		driversPage.enterAdditionalDetails(applicant, fsa);
		resumeFromDiscountsPage(applicant, driversPage.enterVehicleAssignmentData(applicant, false, fsa), fsa);
	}

	private void resumeFromDiscountsPage(SqlApplicant applicant, DiscountsPage discountsPage, FarmersSoftAssert fsa) throws Exception {
		resumeFromQuotePage(applicant, discountsPage.fillForm(applicant, fsa), fsa);
	}

	private void resumeFromQuotePage(SqlApplicant applicant, QuotePageAuto quotePage, FarmersSoftAssert fsa) throws Exception {
		quotePage.validatePageTitle(fsa);
		quotePage.validateCoveragePackages(applicant.getStateCode(), fsa);
	}

	private void attemptToBindQuote(SqlApplicant applicant, DiscountsPage discountsPage, QuotePageAuto quotePage, FarmersSoftAssert fsa) throws Exception, KnockoutException {
		if(quotePage.isEligibleToBuyQuote()) {
			quotePage.attemptToBuyQuote(applicant);
			if (verifyAdditionalInformationPage(applicant, fsa)){
				if (isAffiliateQuote()) {
					if (discountsPage.onDiscountsPage()) {
						discountsPage.continueToQuotePage();
					}
					if (quotePage.isOnLegacyAutoQuotePage()) {
						quotePage.clickBuyNow();
						if (verifyAdditionalInformationPage(applicant, fsa)) {
							verifyPaymentPage(applicant, fsa);
							verifyCongratulationsPage(applicant, fsa);
						}
					}
				} else {
					verifyPaymentPage(applicant, fsa);
					verifyCongratulationsPage(applicant, fsa);
				}
			} else {
				fsa.fail("Problem found in additional info page");
			}
		} else {
			if (applicant.getTestCategory().equalsIgnoreCase("Cross Sell ")) {
				ThankYouPage thankYouPage = new ThankYouPage();
				if(applicant.getDiscounts().isSignalSignup()) {
					thankYouPage.testSignalLink();
				}
				thankYouPage.selectCrossSellType(applicant.getTestScenario());
			} else if (applicant.getGender().equalsIgnoreCase("Not Specified")) {
				ThankYouPage thankYouPage = new ThankYouPage();
				if(applicant.getDiscounts().isSignalSignup()) {
					thankYouPage.testSignalLink();
				}
				List<String> availableCrossSellTypes = thankYouPage.getAvailableCrossSellTypes();
				fsa.assertTrue(!availableCrossSellTypes.contains("Renters"), "Renters not available as a cross sell option");
				fsa.assertTrue(!availableCrossSellTypes.contains("Condo"), "Condo not available as a cross sell option");
			}
		}
	}

	private boolean isAffiliateQuote() throws Exception {
		List<PWElement> bwImages = driver().findElements(PWBy.xpath("//*[contains(@alt, 'Bristol') and not(string-length(@style)>0)]"));
		List<PWElement> foremostImages = driver().findElements(PWBy.xpath("//*[contains(@alt, 'foremost') and not(string-length(@style)>0)]"));
		return !(bwImages.isEmpty() && foremostImages.isEmpty());
	}

	public void validateAllPages(SqlApplicant applicant) throws Exception {
		YourInfoPageAuto infoPage = enterLobAndZipCode(applicant);
		String applicantStateCode = applicant.getStateCode();
		if (applicantStateCode.equals(NC)) {
			applicant = setTestDataForNC(applicant);
		}
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		fsa.assertEquals(infoPage.validatePageTitle(), true, "Your Info page title content valid");
		fsa.assertEquals(infoPage.validatePageSubtitle(), true, "Your Info page subtitle content valid");
		fsa.assertEquals(infoPage.validatePageDisclaimer(applicant), true, "Your Info page disclaimer valid");
		fsa.assertEquals(infoPage.validateHyperlinks(), true, "Your Info page hyperlinks valid");
		fsa.assertEquals(infoPage.validateSectionsLabel(), true, "Addess section label - Your Info Page");
		infoPage.validateGTMTags(applicantStateCode, fsa);
		fsa.assertEquals(infoPage.validateErrorMessages(applicantStateCode, fsa), true, "Your Info page error messages valid");
		if (infoPage.isEmployerGroupQuestionState(applicantStateCode)) {
			infoPage.validateWorkGroupDescription(fsa);
		} else {
			fsa.assertFalse(infoPage.isEmployerGroupDropDownPresent(), "Employer Group drop-down should not be displayed for " + applicantStateCode);
		}
		infoPage.validateFAQs(fsa);
		VehiclesPage vehiclesPage = infoPage.fillOutPageAndContinue(applicant);
		vehiclesPage.logAutoQuoteNumber(applicant);
		fsa.assertEquals(vehiclesPage.validateAddVehicleFAQButtons(applicantStateCode, fsa), true, "Add Vehicles dialog FAQ messages validation");
		vehiclesPage.validateGTMTags(fsa);
		fsa.assertEquals(vehiclesPage.validateAddVehicleErrorMessages(applicantStateCode, fsa), true, "Add Vehicles dialog error message validation");
		if (vehiclesPage.enterYMMTDataForFirstVehicle(applicant.getVehicles().get(0))) {
			vehiclesPage.validateAddVehicleDialogLabels(applicantStateCode, fsa);
		}
		vehiclesPage.closeAddVehicleDialog(true);
		int maximumVehiclesAllowed = vehiclesPage.limitVehicleCountToMaxAllowed(applicantStateCode, applicant.getVehicles().size());
		for (int v=0; v < maximumVehiclesAllowed; v++) {
			SqlVehicle vehicleInfo = applicant.getVehicles().get(v);
			vehiclesPage.addAVehicle(vehicleInfo, applicant);
		}
		DriversPage driversPage = vehiclesPage.forwardToDriversPage();
		driversPage.validateDriversPageContent(fsa);
		driversPage.validatePNIPageErrorMessages(applicant, fsa);
		driversPage.validatePNIFAQs(applicant, fsa);
		driversPage.validateGTMTags(fsa);
		driversPage.addPNIDriverInformation(applicant);
		for (int d=0; d<applicant.getAdditionalDrivers().size() && d< MAX_NUMBER_OF_ADDITIONALDRIVERS; d++) {
			SqlAdditionalDriver additionalDriver = applicant.getAdditionalDrivers().get(d);
			driversPage.validateAdditionalDriversFAQs(additionalDriver, applicantStateCode, fsa);
			driversPage.validateAdditionalDriverErrorMessages(additionalDriver, applicantStateCode, fsa);
			driversPage.addAdditionalDriver(additionalDriver, applicant.getIncidents(), applicantStateCode, d+1);
		}
		driversPage.enterAdditionalDetails(applicant, fsa);
		driversPage.enterVehicleAssignmentData(applicant, false, fsa);
		DiscountsPage discountsPage = new DiscountsPage();
		QuotePageAuto quotePage = discountsPage.fillForm(applicant, fsa);
		quotePage.validatePage(applicant, true, fsa);
		fsa.assertAll();
	}

	private SqlApplicant setTestDataForNC(SqlApplicant applicant) {
		List<SqlVehicle> listOfVehicles = applicant.getVehicles();
		listOfVehicles.replaceAll(vehicle -> {
			vehicle.setUseVIN(true);
			return vehicle;
		});
		applicant.setVehicles(listOfVehicles);
		return applicant;
	}
}