package com.farmers.ffq.acemobilehome;

import static com.farmers.ffq.utils.GlobalVariables.AK;
import static com.farmers.ffq.utils.GlobalVariables.AWS_SCENARIOS;
import static com.farmers.ffq.utils.GlobalVariables.DE;
import static com.farmers.ffq.utils.GlobalVariables.LA;
import static com.farmers.ffq.utils.GlobalVariables.ME;
import static com.farmers.ffq.utils.GlobalVariables.MOBILE_HOME;
import static com.farmers.ffq.utils.GlobalVariables.NC;
import static com.farmers.ffq.utils.GlobalVariables.NH;
import static com.farmers.ffq.utils.GlobalVariables.NJ;
import static com.farmers.ffq.utils.GlobalVariables.RI;
import static com.farmers.ffq.utils.GlobalVariables.SC;
import static com.farmers.ffq.utils.GlobalVariables.VT;
import static com.farmers.ffq.utils.GlobalVariables.WV;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import com.farmers.ffq.ace.mobilehome.AceMobileHomeAboutYouPage;
import com.farmers.ffq.ace.mobilehome.AceMobileHomeLastStepPage;
import com.farmers.ffq.ace.mobilehome.AceMobileHomeNavigationHelper;
import com.farmers.ffq.ace.mobilehome.AceMobileHomeTellUsMorePage;
import com.farmers.ffq.ace.mobilehome.AceMobileQuoteReviewPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.SqlDiscount;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;

public class AceMobileCommonTestHelper extends AutomationFramework {

	public AceMobileCommonTestHelper() {
	}

	public AceMobileCommonTestHelper(ApplicantAceHome mobilehomeApplicant) {
		//These states don't have agents in the database or have not been set up yet
		if (!List.of(AK, DE, LA, ME, NC, NH, NJ, RI, SC, VT, WV).contains(mobilehomeApplicant.getStateCode()) && new Random().nextBoolean()) {
			mobilehomeApplicant.setTestCategory(AWS_SCENARIOS);
		}
	}

	public void verifyAddressPageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new AceMobileHomeNavigationHelper().navigateToAddressPage(mobilehomeApplicant).verifyPageContent(fsa, mobilehomeApplicant);
		fsa.assertAll();
	}

	public void validateAddressPageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new AceMobileHomeNavigationHelper().navigateToAddressPage(mobilehomeApplicant).validatePageErrors(fsa, mobilehomeApplicant);
		fsa.assertAll();
	}

	public void verifyTellUsMorePageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new AceMobileHomeNavigationHelper().navigateToTellUsMorePage(mobilehomeApplicant).verifyPageContent(fsa, mobilehomeApplicant);
		fsa.assertAll();
	}

	public void validateTellUsMorePageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AceMobileHomeTellUsMorePage  tellUsMorePage = new AceMobileHomeNavigationHelper().navigateToTellUsMorePage(mobilehomeApplicant);
		tellUsMorePage.validatePageErrors(fsa, mobilehomeApplicant);
		tellUsMorePage.validateSnackbarMessages(fsa);
		fsa.assertAll();
	}

	public void verifyAboutYouPageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new AceMobileHomeNavigationHelper().navigateToAboutYouPage(mobilehomeApplicant).verifyPageContent(fsa, mobilehomeApplicant);
		fsa.assertAll();
	}

	public void validateAboutYouPageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AceMobileHomeAboutYouPage aboutYouPage = new AceMobileHomeNavigationHelper().navigateToAboutYouPage(mobilehomeApplicant);
		aboutYouPage.validatePageErrors(fsa, mobilehomeApplicant);
		aboutYouPage.validateSnackbarMessages(fsa);
		fsa.assertAll();
	}

	public void verifyLastStepPageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AceMobileHomeLastStepPage lastStepPage = new AceMobileHomeNavigationHelper().navigateToLastStepPage(mobilehomeApplicant);
		lastStepPage.verifyPageContent(fsa, mobilehomeApplicant);
		lastStepPage.validateSnackbarMessages(mobilehomeApplicant, fsa);
		fsa.assertAll();
	}

	public void validateLastStepPageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new AceMobileHomeNavigationHelper().navigateToLastStepPage(mobilehomeApplicant).validateErrorMessages(fsa, mobilehomeApplicant, MOBILE_HOME);
		fsa.assertAll();
	}

	public void verifyQuotePageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new AceMobileHomeNavigationHelper().navigateToQuotePage(mobilehomeApplicant).verifyPageContent(mobilehomeApplicant, fsa);
		fsa.assertAll();
	}

	public void createMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileHomeNavigationHelper().navigateToQuotePage(mobilehomeApplicant);
	}

	public void expectedDiscountVerification(ApplicantAceHome mobilehomeApplicant) throws Exception {
		DateTimeFormatter dd_yy_mmFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDate todaysDate = LocalDate.now();
		mobilehomeApplicant.setInMobilePark(true);
		mobilehomeApplicant.setYearBuilt(todaysDate.minusYears(5).getYear());
		mobilehomeApplicant.setDateOfBirth(todaysDate.minusYears(52).format(dd_yy_mmFormat));
		mobilehomeApplicant.setEarlyShoppingFactor(todaysDate.plusDays(10).format(dd_yy_mmFormat));
		List<SqlDiscount> listOfDiscounts = mobilehomeApplicant.getDiscounts();
		listOfDiscounts.forEach(bundleGroup-> {
			bundleGroup.setAutoInsurance(true);
			bundleGroup.setLifeInsurance(true);
			bundleGroup.setUmbrellaInsurance(true);
		});
		mobilehomeApplicant.setDiscounts(listOfDiscounts);
		List<String> expectedDiscounts = new ArrayList<>(Arrays.asList("Multi-policy", "Early shopper", "Age of insured", "Newer home", "Park"));
		AceMobileQuoteReviewPage quotepage =  new AceMobileHomeNavigationHelper().navigateToQuotePage(mobilehomeApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		fsa.assertTrue(quotepage.areTwoListEqual(quotepage.getListOfDiscountsFromAppstore().stream().map(AppStore.Home.Discounts::getName).collect(Collectors.toList()), expectedDiscounts), "Expected discounts and appstore content check");
		fsa.assertAll();
	}

	public void retrievedQuotePageValidation(ApplicantAceHome mobilehomeApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AceMobileHomeNavigationHelper navigationHelper = new AceMobileHomeNavigationHelper();
		AceMobileQuoteReviewPage quotepage =  navigationHelper.navigateToQuotePage(mobilehomeApplicant);
		quotepage.verifyPageContent(mobilehomeApplicant, fsa);
		navigationHelper.retrieveMobilehomeQuote(mobilehomeApplicant, navigationHelper.getMobileHomeQuoteNumber());
		if (quotepage.isOnMobileHomeQuotePage()) {
			quotepage.setRetrievedQuoteFlag();
			quotepage.verifyPageContent(mobilehomeApplicant, fsa);
			quotepage.navigateBack();
			fsa.assertTrue(quotepage.isOnMobileHomeQuotePage(), "Back navigation not allowed on retrieved quotes");
		} else {
			fsa.fail("Did not return to quote page after retrieval as expected");
		}
		fsa.assertAll();
	}

	public void retrieveQuoteBeforeItWasRated(ApplicantAceHome mobilehomeApplicant) throws Exception {
		AceMobileHomeNavigationHelper navigationHelper = new AceMobileHomeNavigationHelper();
		int pageNumber = new Random().nextInt(4);
		switch (pageNumber) {
			case 0:
				navigationHelper.navigateToAddressPage(mobilehomeApplicant);
				break;
			case 1:
				navigationHelper.navigateToAboutYouPage(mobilehomeApplicant);
				break;
			case 2:
				navigationHelper.navigateToTellUsMorePage(mobilehomeApplicant);
				break;
			case 3:
				navigationHelper.navigateToLastStepPage(mobilehomeApplicant);
				break;
		}
		navigationHelper.retrieveMobilehomeQuote(mobilehomeApplicant, navigationHelper.getMobileHomeQuoteNumber());
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		if (pageNumber == 3) {
			KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
			fsa.assertTrue(knockoutInconveniencePage.isOnForemostKnockoutPage(), "Mobile home knockout reached");
		} else {
			LandingPage landingPage = new LandingPage(0);
			fsa.assertTrue(landingPage.isQuoteNotFoundPopUpPresent(), "Quote not found dialog present");
			fsa.assertTrue(landingPage.getInfoDialogContent().contains("Please try again or if you would like to speak to Farmers\u00ae representative immediately, call 1-800-515-1896. " +
					"If you're an employee or member of a group with access to the Farmers GroupSelect\u2120 program, please call"), "Unable to locate quote dialog content");
		}
		fsa.assertAll();
	}

}
