package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentSelectionPage;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoMonthlyAutoPayBankPageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MT,NC,MS,UT})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE})
    public void testValidateContentOfMonthlyAutoPayBankPageOnLandingAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        applicantAceHome.setSquareFeet("400");
        AceHRCPaymentBasePage aceHRCPayInFullPaymentBasePage = new AceCondoNavigationHelper().navigateToMonthlyAutoPayBankPaymentPageAceCondo(applicantAceHome);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceHRCPayInFullPaymentBasePage.validateContentOfMonthlyPayBankOrCardPageOnLanding(fsa, MONTHLY_EFT, applicantAceHome, CONDO);
        //Quote number and Agent details at the bottom validation
        AceHRCBasePage aceHRCBasePage = new AceHRCBasePage();
        aceHRCBasePage.validateQuoteSavedText(applicantAceHome.getQuoteNumber(), fsa);
        aceHRCPayInFullPaymentBasePage.validateAssignedAgentSection(aceHRCPayInFullPaymentBasePage, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_HOME_BIND, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE})
    public void testChangingMonthlyPayBankToPayInFullCardPaymentAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        // updating sq feet to avoid reconstruction KO
        applicantAceHome.setSquareFeet("450");
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceCondoNavigationHelper().navigateToMonthlyAutoPayBankPaymentPageAceCondo(applicantAceHome);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, CONDO);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, CONDO);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, CONDO);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, CONDO);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, CONDO);

        // Navigating back and selecting "Pay In Full" pay plan and proceeding with payment
        AceHRCBasePage aceHRCBasePage = new AceHRCBasePage();
        aceHRCBasePage.navigateBack();
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
        aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentPayInFullCard(CONDO);
        aceHRCPaymentBasePage.waitForSkeletonToBeGone();
        policyPaymentBasePage.clickSetUpPaymentButton();
        policyPaymentBasePage.clickDebitCreditCardButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(VISA_CREDIT_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPagePayInFull(fsa, VISA_CREDIT_CARD, CARD_NAME_VISA, true, CONDO);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPagePayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.validateOneTimePaymentRecurringRadioButtonText(fsa, CONDO);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, CONDO);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphPayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, CONDO);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE})
    public void testMonthlyAutoPayCreditCardPaymentEndToEndAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicantAceHome.setSquareFeet("400");
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceCondoNavigationHelper().navigateToMonthlyAutoPayBankPaymentPageAceCondo(applicantAceHome);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.selectBankPaymentRadioButtonHRC();
        policyPaymentBasePage.selectCardPaymentRadioButtonHRC();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, CONDO);
        aceHRCPaymentBasePage.validateFutureCreditDebitCardServiceCharges(fsa, true, CONDO);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, CONDO);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, CONDO);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, CONDO);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, CONDO);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE})
    public void testMonthlyAutoPayBankChangeBankPaymentToCardEndToEndAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicantAceHome.setSquareFeet("400");
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceCondoNavigationHelper().navigateToMonthlyAutoPayBankPaymentPageAceCondo(applicantAceHome);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, CONDO);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, CONDO);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, CONDO);
        policyDebitCreditPayment.clickChangeLink();
        policyPaymentBasePage.selectCardPaymentRadioButtonAlternative();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, CONDO);
        aceHRCPaymentBasePage.validateFutureCreditDebitCardServiceCharges(fsa, true, CONDO);
        aceHRCPaymentBasePage.switchToParentWindow();
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, CONDO);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE})
    public void testMonthlyAutoPayBankChangeCreditCardPaymentToBankEndToEndAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicantAceHome.setSquareFeet("400");
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceCondoNavigationHelper().navigateToMonthlyAutoPayBankPaymentPageAceCondo(applicantAceHome);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        policyPaymentBasePage.selectBankPaymentRadioButtonHRC();
        policyPaymentBasePage.selectCardPaymentRadioButtonHRC();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, CONDO);
        aceHRCPaymentBasePage.validateFutureCreditDebitCardServiceCharges(fsa, true, CONDO);
        policyDebitCreditPayment.clickChangeLink();
        policyPaymentBasePage.selectBankPaymentRadioButtonAlternate();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, CONDO);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, CONDO);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, CONDO);
        aceHRCPaymentBasePage.switchToParentWindow();
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, CONDO);
        fsa.assertAll();
    }

}
