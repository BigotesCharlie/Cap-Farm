package com.farmers.ffq.specialtyDwelling;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import com.farmers.ffq.ace.home.AceSpecialtyDwellingNavigationHelper;
import com.farmers.ffq.ace.home.AceSpecialtyDwellingOtherPolicyQuestionsPage;
import com.farmers.ffq.ace.home.AceSpecialtyDwellingQuoteReviewPage;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyTypeBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.SqlDiscount;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;

public class AceHomeSpecialtyDwellingTestHelper extends AutomationFramework {

	public AceHomeSpecialtyDwellingTestHelper(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		this(specialtyDwellingApplicant, specialtyDwellingApplicant.getReasonWhyNotPrimaryResidence());
	}

	public AceHomeSpecialtyDwellingTestHelper(ApplicantAceHome specialtyDwellingApplicant, String nonPrimaryReason) throws Exception {
		applicantAdjustment(specialtyDwellingApplicant, nonPrimaryReason);
	}

	public void verifyDwellingTypePageContent(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		boolean cameFromMediaAlpha = specialtyDwellingApplicant.getTestCategory().equals(MEDIA_ALPHA);
		AceHRCPropertyTypeBasePage propertyTypePage = new AceSpecialtyDwellingNavigationHelper().navigateToDwellingTypePage(specialtyDwellingApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		propertyTypePage.validatePageCardsNewFlow(fsa, cameFromMediaAlpha);
		propertyTypePage.validatePageFormFieldsNewFlow(fsa, specialtyDwellingApplicant.getStateCode());
		fsa.assertAll();
	}

	public void verifyTellUsMorePageContent(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new AceSpecialtyDwellingNavigationHelper().navigateToDwellingDetailsPage(specialtyDwellingApplicant).verifyPageContent(fsa, specialtyDwellingApplicant);
		fsa.assertAll();
	}

	public void verifyAdditionalDwellingInformationPageContent(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new AceSpecialtyDwellingNavigationHelper().navigateToAdditionalDwellingInformationPage(specialtyDwellingApplicant).verifySpecialtyDwellingAdditionalInformationPageContent(fsa, specialtyDwellingApplicant);
		fsa.assertAll();
	}

	public void verifyOtherPolicyQuestionsPage(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AceSpecialtyDwellingOtherPolicyQuestionsPage otherPolicyQuestionsPage = new AceSpecialtyDwellingNavigationHelper().navigateToOtherPolicyQuestionsPage(specialtyDwellingApplicant);
		otherPolicyQuestionsPage.verifyPageContent(specialtyDwellingApplicant, fsa);
		otherPolicyQuestionsPage.validateSnackbarMessages(specialtyDwellingApplicant, fsa);
		fsa.assertAll();
	}

	public void createQuote(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		new AceSpecialtyDwellingNavigationHelper().navigateToAceSpecialtyDwellingReviewQuotePage(specialtyDwellingApplicant);
	}

	public void verifyQuoteReviewPage(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new AceSpecialtyDwellingNavigationHelper().navigateToAceSpecialtyDwellingReviewQuotePage(specialtyDwellingApplicant).verifyPageContent(specialtyDwellingApplicant, fsa);;
		fsa.assertAll();
	}

	public void verifyDisplayOfExpectedDiscounts(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		String ageOfHome = "Age of home";
		String burglarAlarm = "Burglar alarm";
		String centralFireAlarm = "Central fire alarm";
		String claimsFree = "Claims free";
		String masonry = "Masonry";
		String multiPolicy = "Multi-policy";
		String stateCode = specialtyDwellingApplicant.getStateCode();
		applicantAdjustment(specialtyDwellingApplicant, PARTTIME);
		DateTimeFormatter dd_yy_mmFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDate todaysDate = LocalDate.now();
		specialtyDwellingApplicant.setInMobilePark(false);
		specialtyDwellingApplicant.setYearBuilt(todaysDate.minusYears(5).getYear());
		specialtyDwellingApplicant.setDateOfBirth(todaysDate.minusYears(52).format(dd_yy_mmFormat));
		specialtyDwellingApplicant.setEarlyShoppingFactor(todaysDate.plusDays(10).format(dd_yy_mmFormat));
		specialtyDwellingApplicant.setBrickConstruction(true);
		specialtyDwellingApplicant.setCentralBurglarAlarm(true);
		specialtyDwellingApplicant.setCentralFireAlarm(true);
		List<SqlDiscount> listOfDiscounts = specialtyDwellingApplicant.getDiscounts();
		listOfDiscounts.forEach(bundleGroup-> {
			bundleGroup.setHomeInsurance(true);
			bundleGroup.setAutoInsurance(true);
			bundleGroup.setLifeInsurance(true);
			bundleGroup.setUmbrellaInsurance(true);
		});
		specialtyDwellingApplicant.setDiscounts(listOfDiscounts);
		AceSpecialtyDwellingQuoteReviewPage quotepage =  new AceSpecialtyDwellingNavigationHelper().navigateToAceSpecialtyDwellingReviewQuotePage(specialtyDwellingApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		List<String> expectedDiscounts = new ArrayList<>(Arrays.asList(ageOfHome, burglarAlarm, centralFireAlarm, claimsFree, masonry, multiPolicy));
		//Discount exceptions for certain states
		if (List.of(MN, NC, NE).contains(stateCode)) {
			expectedDiscounts.remove(ageOfHome);
		}
		if (stateCode.equals(TX)) {
			expectedDiscounts.remove(burglarAlarm);
		}
		if (List.of(AL, GA, KY, LA, MS, NC, NM, NY, OK, SC, TN, VA).contains(stateCode)) {
			expectedDiscounts.remove(claimsFree);
		}
		if (stateCode.equals(CA)) {
			expectedDiscounts.remove(masonry);
		}
		if (List.of(CA, MN).contains(stateCode)) {
			expectedDiscounts.remove(multiPolicy);
		}
		List<String> actualDiscounts = quotepage.getListOfDiscountsFromAppstore().stream().map(AppStore.Home.Discounts::getName).collect(Collectors.toList());
		Collections.sort(expectedDiscounts);
		Collections.sort(actualDiscounts);
		fsa.assertEquals(actualDiscounts, expectedDiscounts, "Expected discounts and actual discounts match");
		fsa.assertAll();
	}

	private void applicantAdjustment(ApplicantAceHome specialtyDwellingApplicant, String nonPrimaryReason) {
		String stateCode = specialtyDwellingApplicant.getStateCode();
		//Default values, any changes should be done on the individual tests
		if (!LIST_OF_NONPRIMARY_REASONS.contains(nonPrimaryReason)) {
			nonPrimaryReason = LIST_OF_NONPRIMARY_REASONS.get(new Random().nextInt(LIST_OF_NONPRIMARY_REASONS.size()));
			Log.warn("Setting nonPrimaryReason to :" + nonPrimaryReason);
		}
		//Naming differences...
		if (nonPrimaryReason.equals(PARTTIME) && List.of(AZ, MO, PA).contains(stateCode)) {
			nonPrimaryReason = SECONDARY;
		} else if (nonPrimaryReason.equals(UNOCCUPIED) &&
				(stateCode.equals(CA) ||
				List.of(MN, NE, OH, OR, TX, UT, WI, WY).contains(stateCode) && specialtyDwellingApplicant.getTestCategory().equals(MEDIA_ALPHA))) {
			nonPrimaryReason = OTHER;
		}
		specialtyDwellingApplicant.setAgentId(EMPTY_STRING);
		specialtyDwellingApplicant.setPrimaryResidence(false);
		specialtyDwellingApplicant.setReasonWhyNotPrimaryResidence(nonPrimaryReason);
    	specialtyDwellingApplicant.setRoofCover("Asphalt shingle");
    	specialtyDwellingApplicant.setTrampoline(EMPTY_STRING);
    	specialtyDwellingApplicant.setBusinessOperatedOnPremises(false);
    	specialtyDwellingApplicant.setCentralBurglarAlarm(false);
    	specialtyDwellingApplicant.setSmokeAlarm(EMPTY_STRING);
    	specialtyDwellingApplicant.setCentralFireAlarm(false);
    	specialtyDwellingApplicant.setOccupation(EMPTY_STRING);
    	specialtyDwellingApplicant.setMaritalStatus(EMPTY_STRING);
	}
}
