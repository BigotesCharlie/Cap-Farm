package com.farmers.ffq.acerenters;

import com.farmers.ffq.ace.hrc.common.AceHRCFwsInterstitialPage;
import com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage;
import com.farmers.ffq.ace.renters.AceRentersAboutYouPage;
import com.farmers.ffq.ace.renters.AceRentersAddressPage;
import com.farmers.ffq.ace.renters.AceRentersNavigationHelper;
import com.farmers.ffq.common.pages.FGIALandingPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersAddressPageValidationTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_ADDRESS_PAGE})
    public void validateRentersAddressPage(ApplicantAceHome applicant) throws Exception {
        AceRentersAddressPage addressPage = new AceRentersNavigationHelper().navigateToAceRentersAddressPage(applicant);

    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        addressPage.validateQuoteSourceInd(fsa, applicant, RENTERS, ADDRESS_PAGE);
        addressPage.validatePageTitlesFooters(fsa, applicant, RENTERS);
        addressPage.validatePageLinksText(fsa, ENTER_INFO);
        addressPage.validateRentersPageFormFields(fsa, applicant);
        addressPage.validateAddressPageErrorsRenters(fsa, applicant);
        addressPage.validateAgentSection(fsa, ADDRESS_PAGE, applicant.getAgentId(), RENTERS);
        addressPage.validateQuoteText(ADDRESS_PAGE, applicant.getQuoteNumber(), fsa, false);
        addressPage.clickContinueButton();
        fsa.assertAll("Validate Ace Renters - Address page.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE})
    public void validateDataWhenNavigatedBackAndForthAddressPageRentersLob(ApplicantAceHome applicant) throws Exception {
        String DIFFERENT_ZIP = "20190";
        AceRentersAddressPage addressPage = new AceRentersNavigationHelper().navigateToAceRentersAddressPage(applicant);
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        Assert.assertTrue(addressPage.isOnAddressPageRenters(true), "Reached Address page");
        addressPage.enterAddress(applicant);
        addressPage.validateAddressPageCrossIcon(fsa);
        // Data is saved when navigated forward from the page
        addressPage.enterAddress(applicant);
        addressPage.clickContinueButton();
        addressPage.waitForSpinnerToBeGone();
        addressPage.navigateBack();
        Assert.assertTrue(addressPage.isOnAddressPageRenters(true), "Reached Address page");
        addressPage.validateAddressPageFieldsSaved(applicant, RENTERS, fsa);

        // Navigate back to the landing page, change the zip code(i.e., enter any random valid zip code) and validate the data on Address page
        addressPage.navigateBack(2);
        AceHRCNavigationHelperBasePage aceHRCNavigationHelperBasePage = new AceHRCNavigationHelperBasePage();
        applicant.setZipCode(DIFFERENT_ZIP);
        aceHRCNavigationHelperBasePage.processLandingPage(applicant, LOB_RENTERS);
        Assert.assertTrue(addressPage.isOnAddressPageRenters(true), "Did not Reach to Address page when navigating back and forth");
        addressPage.validateAddressPageFieldsNotSaved(fsa, RENTERS);
        fsa.assertAll("Address page Renters - Data is saved when navigated forth from the page, but when we navigated back and changing the zip code then Data is vanished.");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {LA, MA, NC})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE})
    public void testFGIANotOfferingValidationRentersLob(ApplicantAceHome applicant) throws Exception {
        applicant.setAgentId(null);
        AceHRCNavigationHelperBasePage aceHRCNavigationHelperBasePage = new AceHRCNavigationHelperBasePage();
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        FGIALandingPage fgiaLandingPage = new FGIALandingPage();
        aceHRCNavigationHelperBasePage.processLandingPage(applicant, LOB_RENTERS);
        if (applicant.getStateCode().equals(LA)) {
            fgiaLandingPage.monetizedStateDirectKnockoutPageValidation(fsa, RENTERS);
        } else {
            fgiaLandingPage.validateContentOfFGIAPopUp(fsa, RENTERS);
            if (fgiaLandingPage.isFgiaNoThanksButtonDisplayed()) {
                fgiaLandingPage.clickNoThanksButtonInFGIAPopUp();
                fgiaLandingPage.weAreNotAbleToCompleteQuotePageValidation(fsa, RENTERS);
            }
        }
        fsa.assertAll("FGIA - Not offering validation Renters");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {LA, MA, NC})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE})
    public void testFGIALandingPageValidationRentersLob(ApplicantAceHome applicant) throws Exception {
        applicant.setAgentId(null);
        AceHRCNavigationHelperBasePage aceHRCNavigationHelperBasePage = new AceHRCNavigationHelperBasePage();
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        FGIALandingPage fgiaLandingPage = new FGIALandingPage();
        aceHRCNavigationHelperBasePage.processLandingPage(applicant, LOB_RENTERS);
        if (applicant.getStateCode().equals(LA)){
            fgiaLandingPage.monetizedStateDirectKnockoutPageValidation(fsa, RENTERS);
        } else {
            fgiaLandingPage.validateContentOfFGIAPopUp(fsa, RENTERS);
            fgiaLandingPage.clickContinueButtonInFGIAPopUp();
            fgiaLandingPage.fgiaIntroPageValidation(fsa, RENTERS);
            fsa.assertAll("FGIA - intro page validation Renters");
        }
    }

    /*
    Feature no - F88827 (Digital Monetization)
    */
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_DIGITAL_MONETIZATION_NON_AWS, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {ME, MS, NH, NJ, NY, VT, WV})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE})
    public void testDigitalMonetizationValidationNonAWSRentersLob(ApplicantAceHome applicant) throws Exception {
        AceHRCNavigationHelperBasePage aceHRCNavigationHelperBasePage = new AceHRCNavigationHelperBasePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceHRCNavigationHelperBasePage.processLandingPage(applicant, LOB_RENTERS);
        FGIALandingPage fgiaLandingPage = new FGIALandingPage();
        if (aceHRCNavigationHelperBasePage.isQnBState(applicant.getStateCode())) { // F103049 / US1165203 - QnB Redirection for Condo LOB
            AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
            Assert.assertTrue(fwsInterstitialPage.isOnQnBSite(), "User did not navigate to QnB portal - Home LOB");
            fwsInterstitialPage.validateQnBUrl(fsa);
        } else if (applicant.getStateCode().equals(NJ)) {
            fgiaLandingPage.validateContentOfFGIAPopUp(fsa, RENTERS);
        } else {
            fgiaLandingPage.otherCompaniesDigitalMonetizationPageValidation(fsa, RENTERS);
        }
        fsa.assertAll("Monetized state validation - Renters LOB");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_DIGITAL_MONETIZATION_AWS, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {NJ, NY})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE})
    public void testDigitalMonetizationValidationAWSRentersLob(ApplicantAceHome applicant) throws Exception {
        AceHRCNavigationHelperBasePage aceHRCNavigationHelperBasePage = new AceHRCNavigationHelperBasePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceHRCNavigationHelperBasePage.processLandingPage(applicant, LOB_RENTERS);
        KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
        koPage.digitalMonetizationKOAgentValidation(fsa, applicant.getAgentId());
        fsa.assertAll("Digital monetization - Call for Quote page validation - " + RENTERS);
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_ADDRESS_PAGE})
    public void validateLongCityNameAccepted(ApplicantAceHome applicant) throws Exception {
        applicant.setZipCode("43160");
        applicant.setStateCode("OH");
        applicant.setCity("Washington Court House");
        applicant.setState("Ohio");
        applicant.setAddress("152 South Elm Street");

        AceRentersAddressPage addressPage = new AceRentersNavigationHelper().navigateToAceRentersAddressPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        addressPage.enterAddress(applicant);
        addressPage.clickContinueButton();
        fsa.assertEquals(new AceRentersAboutYouPage().isOnAboutYouPageRenters(false), true, "Reached about you page");
        fsa.assertAll();
    }
}
