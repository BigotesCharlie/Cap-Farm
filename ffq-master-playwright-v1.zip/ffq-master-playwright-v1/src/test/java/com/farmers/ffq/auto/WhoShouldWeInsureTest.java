package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.Vehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.apache.commons.lang.RandomStringUtils;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class WhoShouldWeInsureTest extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testAddDriverDialog(AutoApplicant applicant) throws Exception {
        // removing fifth additional driver
        if (applicant.getAdditionalDrivers().size() > MAX_NUMBER_OF_ADDITIONALDRIVERS) {
            applicant.getAdditionalDrivers().remove(0);
        }
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
//        whoShouldWeInsurePage.validatePageTitle()
//                             .validatePageContent()

        if (whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        } else {
            whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
        }
        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        // below two methods handles both the old and streamline flow internally
        whoShouldWeInsurePage
                .validateDisplayedListOfVehicles(farmersSoftAssert, applicant)
                .validateDisplayedListOfDriversWithAges(applicant);
        farmersSoftAssert.assertAll();
    }

    @Skip // there will be no message as user no longer able to click on add another driver when reached the max number of additional driver. Need to do some more work to validate that add another driver button is not displayed when there are already 4 additional drivers added.
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=4"})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testErrorMessageForMoreThanFourAdditionalDrivers(AutoApplicant applicant) throws Exception {
        Log.info("Starting test to validate error message when there are more than four additional drivers.");

        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        Log.info("Navigated to 'Who Should We Insure' page.");

        whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
        Log.info("Added vehicles when none were found.");

        whoShouldWeInsurePage.addAllDriversWithMoreThan4AdditionalDriversWhenNonFound(applicant);
        Log.info("Added all drivers with more than 4 additional drivers when none were found.");

        // Click the 'Continue' button to trigger the error message
        whoShouldWeInsurePage.clickOnContinueButton();
        Log.info("Clicked on the 'Continue' button.");

        String actualErrorMessage = whoShouldWeInsurePage.getErrorMessageForVehicleAndDriverSelection();
        Log.info("Obtained the actual error message.");

        String expectedErrorMessage = "Online quotes are limited to five drivers. Please remove the extra driver(s), or call (888) 555-5555 to speak with an agent.";

        testStepAssert(actualErrorMessage.equals(expectedErrorMessage), "Error message mismatch. Actual: " + actualErrorMessage);

        Log.info("Test completed.");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testGuidanceMessagesForZeroDriverZeroVehicleAndZeroDriverWithZeroVehicle(AutoApplicant applicant) throws Exception {
        Log.info("Starting test to verify guidance messages when applicant tries to proceed with Zero Driver or Zero vehicle or both with Zero driver and Zero vehicle.");

        randomizeApplicantPersonalData(applicant);
        applicant.setLastName("A" + RandomStringUtils.randomAlphabetic(6).toLowerCase());

        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        Log.info("Navigated to 'Who Should We Insure' page.");
        boolean streamlineFlow = whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();

        if (streamlineFlow) {
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        } else {
            whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
        }

        Log.info("Added vehicles when none were found.");
        Log.info("Added drivers when none were found.");


        if (streamlineFlow) {
            vehiclesDriversInfoPage.setAllVehicleCheckboxesTo(false);
        } else {
            whoShouldWeInsurePage.uncheckAllCheckedVehicleCheckboxes();
        }

        Log.info("Zero vehicles are selected");
        whoShouldWeInsurePage.clickContinueButton();
        String pleaseSelectAtLeastOneVehicle = "Please select at least one vehicle.";
        String pleaseSelectAtLeastOneVehicle_no_period = "Please select at least one vehicle";
        List<String> noVehicleSelectionErrorMessages = Arrays.asList(pleaseSelectAtLeastOneVehicle_no_period, pleaseSelectAtLeastOneVehicle);
        testStepAssertTrue(noVehicleSelectionErrorMessages.contains(whoShouldWeInsurePage.getErrorMessageForVehicleAndDriverSelection()),
                "Incorrect guidance message for scenario a");

        if (streamlineFlow) {
            vehiclesDriversInfoPage.setAllDriversCheckboxesTo(false);
        } else {
            whoShouldWeInsurePage.uncheckAllCheckedDriverCheckboxes();
        }

        Log.info("Zero drivers and zero vehicles are selected");
        whoShouldWeInsurePage.clickContinueButton();
        String applicantFullName = applicant.getFirstName() + SPACE + applicant.getLastName();
        if (streamlineFlow) {
            vehiclesDriversInfoPage.setCheckboxTo(vehiclesDriversInfoPage.getCheckboxForGivenDriver(applicantFullName), true);
        } else {
            whoShouldWeInsurePage.setCheckboxTo(whoShouldWeInsurePage.getDriverEditCheckboxInputButtonByFullName(applicantFullName), true);
        }
        testStepAssertTrue(noVehicleSelectionErrorMessages.contains(whoShouldWeInsurePage.getErrorMessageForVehicleAndDriverSelection()),
                "Incorrect guidance message for scenario c");

        Log.info(" Zero drivers are selected");
        if (streamlineFlow) {
            vehiclesDriversInfoPage.setAllVehicleCheckboxesTo(true);
            vehiclesDriversInfoPage.setAllDriversCheckboxesTo(false);
        } else {
            whoShouldWeInsurePage.uncheckAllCheckedDriverCheckboxes();
            whoShouldWeInsurePage.checkAllUnCheckedVehicleCheckboxes();
        }

        whoShouldWeInsurePage.clickContinueButton();
        String expectedErrorMessage = "Applicant '" + applicantFullName + "' must be selected";
        testStepAssert(whoShouldWeInsurePage.getErrorMessageForVehicleAndDriverSelection(), expectedErrorMessage,
                "Incorrect guidance message for scenario b");

        Log.info("Test completed.");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})})
    public void testInfoTextsAndFieldLabelTextForVehicleAndDriversDialog(AutoApplicant applicant) throws Exception {
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        //validate who Should we ensure Page content
        if (whoShouldWeInsurePage.isOnWhoShouldWeInsurePage()) {
            whoShouldWeInsurePage.validatePageTitle().validatePageContent().validateAddVehicleAndDriversButton();
        }
        // validate Side Add vehicle/driver dialog content
        whoShouldWeInsurePage.validateHeader().validateInfoText();
        whoShouldWeInsurePage.validateVINAndYMMFormFields(fsa);
        // validate link below Car VIN input box
        whoShouldWeInsurePage.clickOnVinButton().validateWhereCanIFindThis();
        // validate YMM dialog sub note
        whoShouldWeInsurePage.clickOnYMMButton().validateSubNote();
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testListedVehiclesAndDriversInfoSavedAndDisplayedOnNavigationFromNextPageBackAndOnRefresh(AutoApplicant applicant) throws Exception {

        // Navigate to the Vehicle Review Page
        AceAutoNavigationHelper aceAutoNavigationHelper=new AceAutoNavigationHelper();
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        if (vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {

            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
            vehiclesDriversInfoPage.clickContinueButton();
        } else {
            whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.clickContinueButton();
        }
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        boolean isStreamlineExpected = vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        if (isStreamlineExpected) {
            driverReviewPage.clickContinueButton();
            aceAutoNavigationHelper.navigateBackToWhoShouldWeInsurePage();

        } else {
            VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
            testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on the vehicle review page", true);
            aceAutoNavigationHelper.navigateBackToWhoShouldWeInsurePage();
        }

        // Assertion 1: Verify that the added list of drivers with ages is displayed after navigation
        testStepAssertTrue(whoShouldWeInsurePage.areAddedListOfDriversWithAgesDisplayed(applicant), "Expected:List of added drivers with ages should be displayed after navigation.Actual:List of added drivers with ages is displayed after navigation");

        // Assertion 2: Verify that the list of added vehicles is displayed after navigation
        testStepAssertTrue(whoShouldWeInsurePage.areListOfAddedVehiclesDisplayed(applicant), "Expected:List of added vehicles should be displayed after navigation.Actual:List of added vehicles is displayed after navigation");

        whoShouldWeInsurePage.refreshPage();
        testStep("Refreshed the page.");

        // Assertion 3: Verify that the added list of drivers with ages is still displayed after page refresh
        testStepAssertTrue(whoShouldWeInsurePage.areAddedListOfDriversWithAgesDisplayed(applicant), "Expected:List of added drivers with ages should be displayed after page refresh.Actual:List of added drivers with ages is displayed after page refresh");

        // Assertion 4: Verify that the list of added vehicles is still displayed after page refresh
        testStepAssertTrue(whoShouldWeInsurePage.areListOfAddedVehiclesDisplayed(applicant), "Expected:List of added vehicles should be displayed after page refresh.Actual:List of added vehicles is displayed after page refresh");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=31"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testMaritalChangeNotificationAndPopUpMessage(AutoApplicant applicant) throws Exception {
        // removing more than 1 vehicle, if there is any. Don't need more than one vehicle for this test case.
        Log.info("Limiting the number of vehicles to 1, as we don't need multi vehicle for this test case");
        List<Vehicle> vehicles = applicant.getVehicles();
        int numberOfVehicles = vehicles.size();
        if (numberOfVehicles > 1) {
            applicant.setVehicles(new ArrayList<>(Arrays.asList(vehicles.get(0))));
        }

        Log.info("Starting marital status change among drivers in drivers review page and notification messages and pop up messages it creates on who should we insure page");

        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        Log.info("Navigated to Driver Review Page.");

        driverReviewPage.selectSpouseAsSecondaryNameInsured(applicant);
        Log.info("Selected Spouse as Secondary Name Insured.");

        driverReviewPage.selectRandomAdditionalDriverAndAssignToRandomSpouse(applicant);
        Log.info("Selected a random additional driver and assigned them to a random spouse.");

        driverReviewPage.clickOnDriversRevisionHyperlink();
        Log.info("Clicked on the Drivers Revision Hyperlink.");

        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();

        // Soft Assert for PNI Removal Notification Text
        String pniRemovalNotificationText = whoShouldWeInsurePage.getPniRemovalNotificationText();
        testStepAssert(pniRemovalNotificationText, "This driver is the \"Primary named insured\" and cannot be removed from the quote.", "PNI Removal Notification Text is as expected.");

        // Soft Assert for SNI Removal Notification Text
        String sniRemovalNotificationText = whoShouldWeInsurePage.getSniRemovalNotificationText();
        String caAdjuster = applicant.getStateCode().equals(CA) ? "The spouse" : "This driver";
        String expectedSniDescription = caAdjuster + " is the \"Secondary named insured\" and cannot be removed from the quote.";
        testStepAssert(sniRemovalNotificationText, expectedSniDescription, "SNI Removal Notification Text is as expected.");

        // Uncheck a random additional driver checkbox
        whoShouldWeInsurePage.uncheckRandomAdditionalDriverCheckbox();
        Log.info("Unchecked a random additional driver checkbox.");

        // Soft Assert for Spouse Select Pop-Up Header Text
        String spouseSelectPopUpHeaderText = whoShouldWeInsurePage.getSpouseSelectPopUpHeaderText();
        testStepAssert(spouseSelectPopUpHeaderText, "This person is another driver's spouse", "Spouse Select Pop-Up Header Text is as expected.");

        // Soft Assert for Spouse Select Pop-Up Context Text
        String spouseSelectPopUpContextText = whoShouldWeInsurePage.getSpouseSelectPopUpContextText();
        testStepAssert(spouseSelectPopUpContextText, "If two drivers are married or in a domestic partnership, they must either both be included or both removed from the quote.", "Spouse Select Pop-Up Context Text is as expected.");

        // Soft Assert for Keep Both Button Text
        String keepBothButtonText = whoShouldWeInsurePage.getKeepBothButtonText();
        testStepAssert(keepBothButtonText, "Keep both", "Keep Both Button Text is as expected.");

        // Soft Assert for Remove Both Button Text
        String removeBothButtonText = whoShouldWeInsurePage.getRemoveBothButtonText();
        testStepAssert(removeBothButtonText, "Remove both", "Remove Both Button Text is as expected.");

        Log.info("Test completed.");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=31"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testMaritalRelationShipSelection(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper oneUiPage = new AceAutoNavigationHelper();
        oneUiPage.navigateToDriverReviewPage(applicant).selectSpouseAsSecondaryNameInsured(applicant)
                .clickOnDriversRevisionHyperlink();

        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        whoShouldWeInsurePage.validatePageTitle().validatePniAndSniStatus(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE}, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})})
    public void testVehiclePageFormFieldsErrorMessages(AutoApplicant applicant) throws Exception {
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        //validate Vehicle VIN error message
        whoShouldWeInsurePage.clickOnAddVehicleAndDriversButton()
                .clickOnVinButton()
                .clickOnAddVehicleButton()
                .validateVehicleVINFieldErrorMessage(fsa)
                //attempting to submit empty form fields in order to validate required field error messages and vehicle year field error message.
                .clickOnVehicleAdditionCancelButton()
                .clickOnAddVehicleAndDriversButton()
                .clickOnYMMButton()
                .clickOnAddVehicleButton()
                .validateVehicleYearFieldErrorMessage(fsa)
                .validateRequiredFieldErrorMessage(fsa)
                //validate Vehicle Make error message
                .clickOnYMMButton()
                .selectVehicleYear("2022")
                .clickOnAddVehicleButton()
                .validateVehicleMakeFieldErrorMessage(fsa)
                //validate Vehicle Model and trim error message
                .clickOnYMMButton()
                .enterVehicleMake("TOYOTA")
                .clickOnAddVehicleButton()
                .validateVehicleModelAndTrimFieldErrorMessage(fsa)
                //validate Vehicle type error message
                .clickOnYMMButton()
                .enterVehicleModelAndTrim("HIGHLANDER 4D 2WD")
                .clickOnAddVehicleButton()
                .validateVehicleTypeFieldErrorMessage(fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testVinHelperModal(AutoApplicant applicant) throws Exception {
        Log.info("Starting test to verify the 'Where can I find this?' link.");

        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        Log.info("Navigated to 'Who Should We Insure' page.");

        whoShouldWeInsurePage.clickOnAddVehicleAndDriversButton();
        whoShouldWeInsurePage.clickOnVinButton();
        Log.info("Clicked on 'VIN' button.");

        // Click on the 'Where can I find this?' link

        if (whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.clickVinInfoIcon();
        } else {
            whoShouldWeInsurePage.clickOnWhereCanIFindThisLink();
        }

        testStepAssert(whoShouldWeInsurePage.getVinHelperModalHeader(), "How to find the VIN", "VIN Helper Modal Header is correct.");
        Log.info("Verified VIN Helper Modal Header.");

        testStepAssert(whoShouldWeInsurePage.getDriverSideDriverSideText(), "Driver side door", "Driver side door VIN helper text is correct.");
        Log.info("Verified Driver side door VIN helper text.");

        testStepAssert(whoShouldWeInsurePage.isVinHelperImageOneVisible(), "VIN Helper Image One is visible.");
        Log.info("Verified VIN Helper Image One visibility.");

        testStepAssert(whoShouldWeInsurePage.getDashboardOnTheDriverSideDriverSideDoorJambText(), "Dashboard on the driver side Driver side door jamb", "Dashboard and Driver Side Door Jamb Texts are correct.");
        Log.info("Verified Dashboard and Driver Side Door Jamb Text.");

        testStepAssert(whoShouldWeInsurePage.isVinHelperImageTwoVisible(), "VIN Helper Image Two is visible.");
        Log.info("Verified VIN Helper Image Two visibility.");

        testStepAssert(whoShouldWeInsurePage.isVinHelperImageThreeVisible(), "VIN Helper Image Three is visible.");
        Log.info("Verified VIN Helper Image Three visibility.");

        // Click on the 'Back to VIN' button
        whoShouldWeInsurePage.clickOnBackToVinButton();

        Log.info("Test completed.");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testVinTips(AutoApplicant applicant) throws Exception {
        Log.info("Starting test to verify VIN tips.");

        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        Log.info("Navigated to 'Who Should We Insure' page.");

        whoShouldWeInsurePage.clickOnAddVehicleAndDriversButton();

        List<String> expectedListOfVinTips = new ArrayList<>(List.of(
                "Every VIN has 17 alpha/numeric characters",
                "9th-digit: a number or X only",
                "At least 6 characters are numeric",
                "The letters \"I\",\"O\", and \"Q\" are never used",
                "Common typos: \"B\" and #8; \"S\" and #5; \"O\" and #0; \"I\" and #1"
        ));

        if (whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.sendKeysToVinInputField("AB");
            sleep(1);
            List<String> actualVinTips = vehiclesDriversInfoPage.getVinTipsDisplayed();
            testStepAssert(whoShouldWeInsurePage.areTwoListEqual(actualVinTips, expectedListOfVinTips), "VIN tips are displayed correctly for streamlined states.");
        } else {
            whoShouldWeInsurePage.clickOnVinButton();
            whoShouldWeInsurePage.vehicleVINEntryField.sendKeys("AB");
            sleep(1);
            List<String> actualVinTips = whoShouldWeInsurePage.getVinTipsDisplayed();
            testStepAssert(whoShouldWeInsurePage.areTwoListEqual(actualVinTips, expectedListOfVinTips), "VIN tips are displayed correctly on 'Where can I find this?' module.");
        }

        Log.info("Test completed.");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testWhoShouldWeInsurePage(AutoApplicant applicant) throws Exception {
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        whoShouldWeInsurePage.validatePageTitle().validatePageContent().validateAddVehicleAndDriversButton();
        // quote number doesn`t exist on the page anymore. Need to do some investigations.
//        whoShouldWeInsurePage.validateQuoteNumberAndSaveQuoteLink();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void validateAdditionalDriverFieldsAreEditable(AutoApplicant applicant) throws Exception {
        Log.info("Starting test to validate if all fields for Additional drivers, including First Name, Last Name, and DOB, are editable.");

        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        Log.info("Navigated to 'Who Should We Insure' page.");
        boolean areFieldsEditable = false;
        if (whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
            areFieldsEditable = vehiclesDriversInfoPage.areAllFirstNameLastNameAndDobFieldsEditable();
        } else {
            whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
            Log.info("Added vehicles when none were found.");

            whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
            Log.info("Added drivers when none were found.");

            areFieldsEditable = whoShouldWeInsurePage.areAllFirstNameLastNameAndDobFieldsEditable();
        }
        // Perform the assertion with a descriptive message
        testStepAssert(areFieldsEditable, "Not all FirstName, LastName, and DOB fields are editable.");
        Log.info("Test completed.");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testValidateValidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest(AutoApplicant applicant) throws Exception {
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        whoShouldWeInsurePage.validateValidVIN_WhoShouldWeInsurePage();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testValidateInvalidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest(AutoApplicant applicant) throws Exception {
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        whoShouldWeInsurePage.validateInvalidVIN_WhoShouldWeInsurePage();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testValidateReplaceValidWithInvalidVINInVehiclesDriversReviewPage_WhoShouldWeInsureTest(AutoApplicant applicant) throws Exception {
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        boolean vehiclesDriversConsolidationImpl = whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        if (vehiclesDriversConsolidationImpl) {
            Log.info("Currently this test is not configured for streamlined states as the edit flow is different and we are not sure if we want to allow replacing valid VIN with invalid VIN for streamlined states. Need to have some discussions and then implement this test for streamlined states as well and then remove this if condition");
        } else {
            whoShouldWeInsurePage.validateReplaceValidWithInvalidVIN_WhoShouldWeInsurePage();
        }
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testVINFieldHasFocus(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        Vehicle applicantVehicle = applicant.getVehicles().get(0);
        applicantVehicle.setUseVIN(true);
        applicant.setVehicles(Arrays.asList(applicantVehicle));
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        testStep("Navigated to \"Who should we insure?\" page", true);
        whoShouldWeInsurePage.clickOnAddVehicleAndDriversButton();
        testStep("Click on add vehicle and drivers button");
        if(whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode()))
        {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            fsa.assertTrue(vehiclesDriversInfoPage.doesVINFieldHaveFocus(), "VIN field does not have focus on initial display of side dialog when adding vehicle");
            vehiclesDriversInfoPage.addVehicleDetails(applicantVehicle);
            vehiclesDriversInfoPage.clickOnAddVehicleButton();
            vehiclesDriversInfoPage.waitForSpinnerToBeGone(); // ensuring the api call is completed and app store is updated with the newly added vehicle before we retrieve the vehicle object from app store
            testStep("Added vehicle using VIN");
            AppStore.Auto.AppStoreVehicle appStoreVehicle = vehiclesDriversInfoPage.getSessionStorageAppStore().getAuto().getVehicles().get(0);
            whoShouldWeInsurePage.updateVehicleObjectWithNewlyAddedVehicleByVIN(appStoreVehicle, applicantVehicle);
            vehiclesDriversInfoPage.clickCloseIcon();
            vehiclesDriversInfoPage.clickEditVehicleButton(applicantVehicle);
            testStep("Editing vehicle");
            fsa.assertTrue(!vehiclesDriversInfoPage.doesVINFieldHaveFocus(), "VIN field have focus on initial display of side dialog when editing vehicle");
            testStep("VIN field had focus when adding and did not had focus when editing a vehicle for streamlined states");
        }
        else {
            fsa.assertTrue(whoShouldWeInsurePage.doesVINFieldHaveFocus(), "VIN field does not have focus on initial display of side dialog when adding vehicle");
            whoShouldWeInsurePage.addVehicles(applicant);
            testStep("Added vehicle using VIN");
            whoShouldWeInsurePage.clickOnDriverDialogCloseIcon();
            whoShouldWeInsurePage.clickFirstVehicleEditLink();
            testStep("Editing vehicle");
            fsa.assertTrue(whoShouldWeInsurePage.doesVINFieldHaveFocus(), "VIN field does not have focus on initial display of side dialog when editing vehicle");
            testStep("VIN field had focus when adding or editing a vehicle for non-streamlined states");
        }
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testFirstNameFieldHasFocus(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        testStep("Navigated to \"Who should we insure?\" page", true);
        whoShouldWeInsurePage.clickOnAddVehicleAndDriversButton();
        if (whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            fsa.assertTrue(!vehiclesDriversInfoPage.doesDriverFirstNameFieldHaveFocus(), "Driver's first name field should not have focus on initial display of edit driver side dialog");
            vehiclesDriversInfoPage.clickCloseIcon();
            AppStore.Auto.Driver appStoreDriver = vehiclesDriversInfoPage.getSessionStorageAppStore().getAuto().getDrivers().get(0);
            vehiclesDriversInfoPage.clickEditButtonWithDriverFullName(appStoreDriver.getFirstName() + SPACE + appStoreDriver.getLastName());
            fsa.assertTrue(!vehiclesDriversInfoPage.doesDriverFirstNameFieldHaveFocus(), "Driver's first name field should not have focus on edit driver side dialog when editing driver");
            testStep("Driver's first name field did not have focus when editing a driver");
        } else {
            whoShouldWeInsurePage.addVehicles(applicant);
            fsa.assertTrue(whoShouldWeInsurePage.doesDriverFirstNameFieldHaveFocus(), "Driver's first name field should have focus on initial display of edit driver side dialog");
            whoShouldWeInsurePage.clickOnDriverDialogCloseIcon();
            whoShouldWeInsurePage.clickOnEditDriverLink();
            testStep("Editing user");
            fsa.assertTrue(whoShouldWeInsurePage.doesDriverFirstNameFieldHaveFocus(), "Driver's first name field should have focus on edit driver side dialog when editing driver");
            testStep("Driver's first name field had focus when editing a driver");
        }
        fsa.assertAll();
    }


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CA)}, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void test_CA_State_HasNoPriorInsuranceSection(AutoApplicant applicant) throws Exception {
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper(quoteFlow.AGENT).navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        whoShouldWeInsurePage.validateCaHasNoPriorInsuranceQuestionAsked(applicant, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, CT})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void testValidateCurrentInsuranceCompanyNoPrior_WhoShouldWeInsureTest(AutoApplicant applicant) throws Exception {
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        boolean vehiclesDriversConsolidationImpl = whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        if (vehiclesDriversConsolidationImpl) {
            Log.info("Currently this test is not configured for streamlined states as the edit flow is different and we are not sure if we want to allow replacing valid VIN with invalid VIN for streamlined states. Need to have some discussions and then implement this test for streamlined states as well and then remove this if condition");
        } else {
            whoShouldWeInsurePage.validateNoPriorInCurrentInsurnaceCompanyField_WhoShouldWeInsurePage(applicant);
        }
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA, CT, MA, KS})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, WHO_SHOULD_WE_INSURE})
    public void validateOrderOfBI_Limits(AutoApplicant applicant) throws Exception {
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the who should we insure page");
        if (whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.selectYesOrNoForInsuredStatus(YES);
            vehiclesDriversInfoPage.validateOrderOfBi_Limits();
        } else {
            whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.selectGenderTabButton(applicant.getGender());
            String hasUSLicense = applicant.getFirstAgeForeignDriverLicense() == 18 ? NO : YES;
            whoShouldWeInsurePage.selectUsOrCanadaLicensedRadioButton(hasUSLicense);
            whoShouldWeInsurePage.selectCurrentlyInsuredRadioButton(applicant);
            whoShouldWeInsurePage.validateOrderOfBi_Limits();
        }
    }

}
