package com.farmers.ffq.hqm;

import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.hqm.*;
import com.farmers.ffq.hqm.pages.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.junit.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Random;

import static com.farmers.ffq.utils.GlobalVariables.*;


/**
 * Farmers Fast Quote (FFQ) - HQM to Metlife Integration Scenarios - Home Quote Modernization (HQM).
 */
public class PageValidationFWSScenarios extends AutomationFramework {

    private static final String URBN_GROUP = "URBN";
	private static final String EXCLUDED_STATES = "excludedStates";
	private static final String INCLUDED_STATES = "includedStates";
	private static final Double quoteDelta = 0.30; // quote price fluctuation delta max (used when no Postgres connection)

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_REGRESSION, HQM_ALL},
            testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MT, CT})})
    public void testAddressPageFWS_PLA(ApplicantHQM applicant) throws Exception {
        validateAddressPageFWS(applicant, DESKTOP_BROWSER,  null);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_MOBILE, HQM_ALL},
            testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MT, CT})})
    public void testAddressPageFWS_PLAMobile(ApplicantHQM applicant) throws Exception {
        validateAddressPageFWS(applicant, MOBILE_BROWSER, null);
    }

//    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_REGRESSION, HQM_ALL},
//            testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, LA, MA, MS, NC})})
//    public void testAddressPageFWS_EE(ApplicantHQM applicant) throws Exception {
//        validateAddressPageFWS(applicant, DESKTOP_BROWSER, ABC_GROUP);
//    }
//
//    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_MOBILE, HQM_ALL},
//            testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, LA, MA, MS, NC})})
//    public void testAddressPageFWS_EEMobile(ApplicantHQM applicant) throws Exception {
//        validateAddressPageFWS(applicant, MOBILE_BROWSER, ABC_GROUP);
//    }
//
//    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_REGRESSION, HQM_ALL},
//            testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MT, CT, KY, LA, MA, MS, NC})})
//    public void testAddressPageFWS_PC(ApplicantHQM applicant) throws Exception {
//        validateAddressPageFWS(applicant, DESKTOP_BROWSER, ABC_GROUP);
//    }
//
//    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_MOBILE, HQM_ALL},
//            testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MT, CT, KY, LA, MA, MS, NC})})
//    public void testAddressPageFWS_PCMobile(ApplicantHQM applicant) throws Exception {
//        validateAddressPageFWS(applicant, MOBILE_BROWSER, ABC_GROUP);
//    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_REGRESSION, HQM_ALL},
            testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MT, CT})})
    public void testAddressPageFWSFarmersChoicePC(ApplicantHQM applicant) throws Exception {
        validateAddressPageFWS(applicant, DESKTOP_BROWSER, URBN_GROUP);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_MOBILE, HQM_ALL},
            testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MT, CT})})
    public void testAddressPageFWSFarmersChoicePCMobile(ApplicantHQM applicant) throws Exception {
        validateAddressPageFWS(applicant, MOBILE_BROWSER, URBN_GROUP);
    }

    private void validateAddressPageFWS(ApplicantHQM applicant, String browserType, String group) throws Exception {
    	//       Quote Start - Address Page
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
    	AddressPage addressPage = new AddressPage(applicant, FC, browserType);
    	addressPage.acceptCookies();
    	String quoteNumber = addressPage.getQuoteNumber();
    	applicant.quoteNumber = quoteNumber;
    	Log.info(NEW_QUOTE_NUMBER + quoteNumber);

    	PageLinksHQM addressPageLinks = new PageLinksHQM("addressPage", applicant, browserType, false);
    	addressPage.validatePageLinks(addressPageLinks, quoteNumber, fsa);
		ApiHelper apiHelper = new ApiHelper();
		StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
    	addressPage.validatePageTitlesSubtitles(applicant, browserType, fsa, staticContent);
    	addressPage.validatePageMetlifeTitles(applicant, fsa);
    	addressPage.validatePageFooters(applicant.stateCode, browserType, staticContent);
    	addressPage.populateFields(applicant, fsa);

    	if (!addressPage.isPLAState(applicant.stateCode)) {
    		addressPage.setEmployerGroup(group);
    		String agentYesNo = (new Random()).nextBoolean() ? YES : NO;
    		if (!addressPage.isEasternExpansionState(applicant.stateCode)) {
    			addressPage.setFarmersAgent(agentYesNo);
    		}
    		addressPage.clickButtonAgree();
    		if (addressPage.isEasternExpansionState(applicant.stateCode) || agentYesNo.equals(NO)) {
    			if (!group.equals(URBN_GROUP)) {
    				//                Call For Quote page - Metlife Integration
    				CallForQuotePage callForQuotePage = new CallForQuotePage();
    				Log.info("FWS Call for quote page, quote number: " + quoteNumber,true);
    				callForQuotePage.verifyPageElements(fsa);
    				callForQuotePage.goBackToFarmersQuote();
    				addressPage = new AddressPage();
    				Assert.assertFalse("Back to Address page - No Employer question anymore.", addressPage.isEmployerGroupInputDisplayed());
    				addressPage.clickButtonAgree();
    				new PropertyPage();
    			} else {
    				//                Farmers Insurance Choice page - Metlife Integration
    				FarmersChoicePage farmersChoicePage = new FarmersChoicePage();
    				Log.info("Farmers Choice page, quote number: " + quoteNumber,true);
    				farmersChoicePage.verifyPageElements("urbn-logo", fsa);
    			}
    			return;
    		}
    	} else {
    		addressPage.clickButtonAgree();
    	}
    	//       Property Basics Page
    	PropertyPage propertyPage = new PropertyPage();
    	PageLinksHQM propertyPageLinks = new PageLinksHQM("propertyPage", applicant, browserType, false);
    	PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
    	propertyPageLinks.buttonNext = (propertyPage.getYearBuilt().isEmpty() || propertyPage.getSquareFeet().isEmpty()) ? 2 : 3;
    	propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);
    	propertyPage.setRequiredFields(applicant, fsa, propertyData);
    	propertyPage.clickNext();

    	//        Quality Grade Page
    	QualityGradePage qualityPage = new QualityGradePage();
    	propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
    	qualityPage.selectQualityGrade(applicant, propertyData);
    	qualityPage.clickNext();

    	//        Property Details Page
    	PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
    	propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
    	propertyDetailsPage.clickNext();

    	//       Customer Info Page
    	CustomerInfoPage customerInfoPage = new CustomerInfoPage();
    	customerInfoPage.setRequiredFields(applicant);
    	customerInfoPage.clickNext();

    	//       Contact Info Page
    	ContactInfoPage contactInfoPage = new ContactInfoPage();
    	contactInfoPage.setRequiredFields(applicant);
    	contactInfoPage.clickAgreeSubmitButton();

    	//       Discounts Page
    	DiscountsPage discountsPage = new DiscountsPage();
    	if (driver().getCurrentUrl().endsWith("/discounts")) {
    		discountsPage.setRequiredFields(applicant);
    		discountsPage.getFieldValues(applicant);
    		discountsPage.clickNext();
    	}

    	if (!applicant.isKnockOutScenario) {
    		//           Quote Page
    		QuotePage quotePage = new QuotePage();
    		QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
    		quotePage.validateQuotePremiums(applicant, quoteRate, quoteDelta, fsa);
    		quotePage.validateQuoteDiscounts(applicant, fsa, quoteRate);
    		quotePage.validatePageCardTitles(applicant, quoteRate, true, browserType, fsa);
    		String quotePremiumYearly = quotePage.getQuotePremiumYearly(applicant.stateCode);
    		if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
    			applicant.quoteRate = quotePage.getQuotePremiumMonthly();
    		} else {
    			applicant.quoteRate = quotePremiumYearly;
    		}
    		quotePage.clickQuoteDetails();

    		//           Quote Details dialog
    		QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
    		quoteDetailsPage.validatePageTitlesSubtitles(applicant, fsa, quoteRate, quoteDelta, quotePremiumYearly, null);
    		quoteDetailsPage.validateStandardPackageSliders(applicant, quoteRate, null, fsa);
    		quoteDetailsPage.clickCloseModal();

    		quotePage = new QuotePage();
    		Log.info("HQM Quote Summary page, quote number: " + quoteNumber,true);
    		quotePage.clickNext();

    		ThankYouPage thankYouPage = new ThankYouPage();
    		thankYouPage.validatePageValues(applicant, applicant.quoteRate, fsa, quoteRate);
    	} else {
    		staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
    		KnockOutPage knockOutPage = new KnockOutPage();
    		knockOutPage.validatePageTitles(applicant, fsa, staticContent);
    		knockOutPage.validatePageFooters(applicant, browserType, fsa);
    	}
    	fsa.assertAll();
    }
}
