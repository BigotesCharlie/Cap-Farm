package com.farmers.ffq.auto.defaultcoverage;



import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;
public class BWDefaultCoverageValuesTests_AR extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = AR)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_None_Unk_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        //This is going to avoid BW condition based on the foreign driver's license
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        applicant.setFirstAgeForeignDriverLicense(0);
        defaultCoverageTestForBW(applicant, "coverageAmount=None/Unk&umbrella=No", "AR_None_Unk_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_PIPPD_Only(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=PIPPD_Only&umbrella=No", "AR_PIPPD_Only_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_10K20K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=10/20&umbrella=No", "AR_10K20K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_15K30K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=15/30&umbrella=No", "AR_15K30K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_20K40K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=20/40&umbrella=No", "AR_20K40K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=25/50&umbrella=No", "AR_25K50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = AR)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=30/60&umbrella=No", "AR_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = AR)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_30K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=30/65&umbrella=No", "AR_30K65K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35/70&umbrella=No", "AR_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_35K80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35/80&umbrella=No", "AR_35K80K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_35K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35&umbrella=No", "AR_35K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=45&umbrella=No", "AR_45K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=50&umbrella=No", "AR_50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=60&umbrella=No", "AR_60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=75&umbrella=No", "AR_75K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_85K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=85&umbrella=No", "AR_85K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100&umbrella=No", "AR_100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=200&umbrella=No", "AR_200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=300&umbrella=No", "AR_300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500&umbrella=No", "AR_500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=1000&umbrella=No", "AR_1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = AR)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_25K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=25/65&umbrella=No", "AR_25K65K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = AR)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=50/100&umbrella=No", "AR_50K100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = AR)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/200&umbrella=No", "AR_100K200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = AR)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/300&umbrella=No", "AR_100K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = AR)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=250/500&umbrella=No", "AR_250K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = AR)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=300/300&umbrella=No", "AR_300K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = AR)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/500&umbrella=No", "AR_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = AR)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_500K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/1000&umbrella=No", "AR_500K1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = AR)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AR_1000K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=1000/1000&umbrella=No", "AR_1000K1000K_");
    }

}
