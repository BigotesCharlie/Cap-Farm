package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCContactInfoBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCFwsInterstitialPage;
import com.farmers.ffq.ace.hrc.common.AceHRCNameAndDobBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.CONTACT_INFO;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeContactInfoPageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_CONTACT_INFO_PAGE})
    public void validateContactInfoPageHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCContactInfoBasePage contactInfoPageAceHome = new AceHomeNavigationHelper().navigateToAceHomeContactInfoPage(applicant, LOB_HOME, HOME);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        boolean isPEWCFlowEnabled = contactInfoPageAceHome.isNewFlowEnabledState(applicant.getStateCode());
        contactInfoPageAceHome.validateHeaderAndSubHeaderContactInfoPage(fsa);
        contactInfoPageAceHome.validateAgentSection(fsa, CONTACT_INFO, applicant.getAgentId(), HOME);
        contactInfoPageAceHome.validateQuoteText(CONTACT_INFO, applicant.getQuoteNumber(), fsa, isPEWCFlowEnabled);
        contactInfoPageAceHome.validateContentOfEstimatedClosingOrPolicyStartDate(fsa, HOME);
        contactInfoPageAceHome.validateContentOfFireHydrantSection(fsa, HOME);
        contactInfoPageAceHome.validateContentOfWildfireRiskReductionSection(fsa);
        if (isPEWCFlowEnabled) {
            contactInfoPageAceHome.validateContentOfAboutYouSection(fsa, applicant, HOME);
            fsa.assertTrue(contactInfoPageAceHome.isContinueButtonDisplayed(), "Continue button is displayed on Contact Info Page: " + HOME);
        } else {
            contactInfoPageAceHome.validateContentOfContactInfo(fsa);
            contactInfoPageAceHome.validateDisclaimerOnContactInfoPage(fsa);
            contactInfoPageAceHome.validateContentOfAgreeAndSubmit(fsa);
            contactInfoPageAceHome.enterEmailIdAndPhoneNumberInContactInfoPage(applicant);
            contactInfoPageAceHome.validateDisclaimerFooterLinks(fsa, HOME);
        }
        contactInfoPageAceHome.validateBundleSaveSection(applicant, fsa, HOME);
        contactInfoPageAceHome.validateContentOfMailingAndOtherMailingAddress(fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_CONTACT_INFO_PAGE})
    public void validateContactInfoPageErrorMessagesHomeLob(ApplicantAceHome applicantAceHome) throws Exception {
        AceHRCContactInfoBasePage contactInfoPageAceHome = new AceHomeNavigationHelper().navigateToAceHomeContactInfoPage(applicantAceHome, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoPageAceHome.validateErrorMessages(fsa, applicantAceHome, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})
    public void validateEarlyShoppingDiscountFunctionalityHomeLob(ApplicantAceHome applicantAceHome) throws Exception {
        AceHRCContactInfoBasePage contactInfoPageAceHome = new AceHomeNavigationHelper().navigateToAceHomeContactInfoPage(applicantAceHome, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoPageAceHome.validateEarlyShopperDiscount(fsa, applicantAceHome.getStateCode());
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},groups = {PEWC})
    public void aceHomePEWCScreen(ApplicantAceHome applicantAceHome) throws Exception {
    	applicantAceHome.setAgentId(EMPTY_STRING);
        AceHRCContactInfoBasePage contactInfoPageAceHome = new AceHomeNavigationHelper().navigateToAceHomeContactInfoPage(applicantAceHome, LOB_HOME, HOME);
        contactInfoPageAceHome.capturePEWC("AceHome_ContactInfoPage");
        testStep("End Of Test");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
    		attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})},groups = {PEWC})
    public void aceHomeRelocatedPEWCScreen(ApplicantAceHome applicantAceHome) throws Exception {
    	applicantAceHome.setAgentId(EMPTY_STRING);
    	AceHRCNameAndDobBasePage nameAndDobPage = new AceHomeNavigationHelper().navigateToAceHomeNameAndDobPage(applicantAceHome);
    	nameAndDobPage.capturePEWC("AceHome_NameAndDobPage");
    	testStep("End Of Test");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_BINDABLE_CHOICE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})
    public void validateFWSInterstitialToBindableChoiceIntegrationHome(ApplicantAceHome applicant) throws Exception {

        applicant.setAgentId(EMPTY_STRING);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCContactInfoBasePage contactInfoPageAceHome = new AceHomeNavigationHelper().navigateToAceHomeContactInfoPage(applicant, LOB_HOME, HOME);
        contactInfoPageAceHome.fillOutContactInfoPage(applicant, HOME);
        contactInfoPageAceHome.waitForSpinnerToBeGone();
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        Assert.assertTrue(fwsInterstitialPage.isOnFarmersChoiceInterstitialPage(), "User did not navigate to FWS Interstitial - Farmers choice page");
        driver().navigate().refresh(); //F96276
        fwsInterstitialPage.validateFwsFarmersChoicePage(fsa, HOME);
        fwsInterstitialPage.clickOnApplyDiscountButton();
        fwsInterstitialPage.validateFWSInterstitialDialogContent(fsa);
        fwsInterstitialPage.clickOnDialogContainerAgreeButton();
        fwsInterstitialPage.waitForSpinnerToBeGone();
        Assert.assertTrue(fwsInterstitialPage.isOnBindableChoicePage(20), "User did not navigate to Bindable Choice page after clicking on Apply Discount button from FWS Interstitial page");
        fwsInterstitialPage.validateSelectedInsuranceType(fsa, HOME);
        fsa.assertAll("Validate FWS Interstitial to Bindable Choice Integration from Contact Info page - Home LOB.");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_COLP, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})
    public void validateFWSInterstitialColpPageHome(ApplicantAceHome applicant) throws Exception {

        applicant.setAgentId(EMPTY_STRING);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCContactInfoBasePage contactInfoPageAceHome = new AceHomeNavigationHelper().navigateToAceHomeContactInfoPage(applicant, LOB_HOME, HOME);
        contactInfoPageAceHome.fillOutContactInfoPage(applicant, HOME);
        contactInfoPageAceHome.waitForSpinnerToBeGone();
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        Assert.assertTrue(fwsInterstitialPage.isOnColpInterstitialPage(), "User did not navigate to FWS Interstitial - Colp page");
        driver().navigate().refresh(); //F96276
        fwsInterstitialPage.validateFwsColpPage(fsa, HOME);
        fsa.assertAll("Validate FWS Interstitial COLP page content from Contact Info page - Home LOB.");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_QNB, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})
    public void validateFWSInterstitialQnBPageHome(ApplicantAceHome applicant) throws Exception {

        applicant.setAgentId(EMPTY_STRING);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCContactInfoBasePage contactInfoPageAceHome = new AceHomeNavigationHelper().navigateToAceHomeContactInfoPage(applicant, LOB_HOME, HOME);
        contactInfoPageAceHome.fillOutContactInfoPage(applicant, HOME);
        contactInfoPageAceHome.waitForSpinnerToBeGone();
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        Assert.assertTrue(fwsInterstitialPage.isOnQnBInterstitialPage(), "User did not navigate to FWS Interstitial - QnB page");
        driver().navigate().refresh(); //F96276
        fwsInterstitialPage.validateFwsQnBPage(fsa);
        fwsInterstitialPage.clickOnGetMyQuoteButton();
        fwsInterstitialPage.waitForSpinnerToBeGone();
        Assert.assertTrue(fwsInterstitialPage.isOnQnBSite(), "User did not land on QnB site after clicking on Get My Quote button from FWS Interstitial page - Home LOB");
        fwsInterstitialPage.validateQnBUrl(fsa);
        fsa.assertAll("Validate FWS Interstitial QnB page content from Contact Info page - Home LOB.");
    }
}
