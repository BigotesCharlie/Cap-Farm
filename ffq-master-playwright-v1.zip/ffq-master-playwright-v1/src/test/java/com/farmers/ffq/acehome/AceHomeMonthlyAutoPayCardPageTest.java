package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCJustAFewMoreThingsBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentSelectionPage;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeMonthlyAutoPayCardPageTest extends AutomationFramework {
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE})
    public void testValidateContentOfMonthlyAutoPayCardPageAndNavigateToJFMTPage(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHomeNavigationHelper().navigateToAceHomePaymentSelectionPage(applicantAceHome, LOB_HOME, HOME);
        aceHRCPaymentSelectionPage.validateMonthlyAutoPayPaymentCard(fsa, applicantAceHome.getStateCode(), LOB_HOME);
        aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayCard();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        Assert.assertTrue(aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage(), "Monthly Pay Card Payment Page is not displayed.");
        aceHRCPaymentBasePage.validateContentOfMonthlyPayBankOrCardPageOnLanding(fsa, MONTHLY_DEBIT_CREDIT_CARD, applicantAceHome, HOME);
        AceHRCBasePage aceHRCBasePage = new AceHRCBasePage();
        aceHRCBasePage.navigateBack(2);
        AceHRCJustAFewMoreThingsBasePage justAFewMoreThingsBasePage = new AceHRCJustAFewMoreThingsBasePage();
        fsa.assertTrue(justAFewMoreThingsBasePage.isOnJFMTPage(true), "Navigation from Payment page to JFMT page is not working");
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE})
    public void testMonthlyAutoPayCardCreditCardPaymentEndToEndAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHomeNavigationHelper().navigateToMonthlyAutoPayCardPaymentPageAceHome(applicantAceHome, LOB_HOME, HOME);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, HOME);
        aceHRCPaymentBasePage.validateFutureCreditDebitCardServiceCharges(fsa, true, HOME);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, HOME);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, HOME);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, HOME);
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE})
    public void testMonthlyAutoPayCardBankPaymentEndToEndAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHomeNavigationHelper().navigateToMonthlyAutoPayCardPaymentPageAceHome(applicantAceHome, LOB_HOME, HOME);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.selectBankPaymentRadioButtonAlternate();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, HOME);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, HOME);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, HOME);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, HOME);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, HOME);
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE})
    public void testMonthlyAutoPayCardChangeCreditCardPaymentToBankEndToEndAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHomeNavigationHelper().navigateToMonthlyAutoPayCardPaymentPageAceHome(applicantAceHome, LOB_HOME, HOME);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, HOME);
        aceHRCPaymentBasePage.validateFutureCreditDebitCardServiceCharges(fsa, true, HOME);

        policyDebitCreditPayment.clickChangeLink();
        policyPaymentBasePage.selectBankPaymentRadioButtonInIframe();
        policyPaymentBasePage.clickSetUpPaymentButtonSideSheet();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, HOME);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, HOME);
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_MONTHLY_AUTOPAY_CARD_PAGE})
    public void testMonthlyAutoPayCardChangeBankPaymentToCardEndToEndAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHomeNavigationHelper().navigateToMonthlyAutoPayCardPaymentPageAceHome(applicantAceHome, LOB_HOME, HOME);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        policyPaymentBasePage.selectBankPaymentRadioButtonAlternate();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, HOME);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, HOME);
        policyDebitCreditPayment.clickChangeLink();
        policyPaymentBasePage.selectCardPaymentRadioButtonAlternative();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, HOME);
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }
}
