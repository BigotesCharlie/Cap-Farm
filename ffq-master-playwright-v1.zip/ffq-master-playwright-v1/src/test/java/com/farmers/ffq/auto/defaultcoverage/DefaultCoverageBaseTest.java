package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.DefaultCoverageValueTestHelper;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.ADPFApplicant;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

import java.util.Arrays;

import static com.farmers.ffq.utils.GlobalVariables.EMPTY_STRING;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class DefaultCoverageBaseTest extends BaseTest {

    protected void defaultCoverageTestFor(AutoApplicant applicant, String filter, String testCategory) throws Exception {
        applicant.setOccupation(EMPTY_STRING);
        applicant.getVehicles().forEach(vehicle -> vehicle.setUseVIN(false));
        testCategory = DEFAULT_COVERAGE_VALIDATION + SPACE + testCategory;
        String stateCode = applicant.getStateCode();
        if(stateCode.equals(VA)) {
            applicant.setCurrentInsuranceExpirationDate("11012024");
        }

        if(Arrays.asList(UT, OR, KS).contains(stateCode)) {
            applicant.getVehicles().forEach(vehicle -> vehicle.setVehicleYear("2025"));
        }

        DefaultCoverageValueTestHelper dcHelper = new DefaultCoverageValueTestHelper();
        dcHelper.testDefaultCoverages(applicant, filter, testCategory, false);
    }

    protected void defaultCoverageTestFor(ADPFApplicant adpfApplicant, String filter, String testCategory) throws Exception {
        adpfApplicant.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(30));
        if(adpfApplicant.getStateCode().equals(VA)) {
            adpfApplicant.setCurrentInsuranceExpirationDate("11012024");
        }

        if(adpfApplicant.getStateCode().equals(CT)) {
            adpfApplicant.setCurrentInsuranceExpirationDate("11202024");
        }
        DefaultCoverageValueTestHelper dcHelper = new DefaultCoverageValueTestHelper();
        dcHelper.testDefaultCoverages(adpfApplicant, filter, testCategory, false);
    }

    protected void defaultCoverageTestForBW(AutoApplicant applicant, String filter, String testCategory) throws Exception {
        applicant.setOccupation(EMPTY_STRING);
        applicant.setLastName("Threeoabaa");
        DefaultCoverageValueTestHelper dcHelper = new DefaultCoverageValueTestHelper();
        dcHelper.testDefaultCoverages(applicant, filter, testCategory, true);
    }

}
