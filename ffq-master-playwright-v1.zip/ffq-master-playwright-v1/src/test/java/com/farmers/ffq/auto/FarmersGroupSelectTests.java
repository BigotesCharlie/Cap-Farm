package com.farmers.ffq.auto;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.BaseTest;
import com.farmers.ffq.ace.hrc.common.AceHRCFwsInterstitialPage;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;
import com.farmers.framework.Property;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.RandomUtils;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class FarmersGroupSelectTests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, CT, MA, MS, NC, NV, CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void testFarmersGroupSelectContent(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario("FGS: " + applicant.getTestScenario());
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        testStep("Navigate to Address Page");
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        boolean egImpl = autoEnterAddressPage.getSessionStorageAppStore().getData().getProjectCodeData().getAuto().isEgImpl();
        Log.info("EgIPM project code set to " + egImpl);
        // if egImply project code is set to true, we don't show the affinity section, thus need to finish the job early
        if (egImpl) {
            autoEnterAddressPage.validateAffinitySectionIsNotDisplayed(fsa);
        } else {
            testStep("Verify Employer/Group Affinity Section " + autoEnterAddressPage.verifyEmployerAffinitySection());
            testStep("Verify FGS sidesheet " + autoEnterAddressPage.verifyFGSSideSheet());
        }
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MA, MS, NC, NV, CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void testFarmersGroupSelectFunction(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario("FGS: " + applicant.getTestScenario());
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        testStep("Navigate to Address Page");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        boolean egImpl = autoEnterAddressPage.getSessionStorageAppStore().getData().getProjectCodeData().getAuto().isEgImpl();
        Log.info("EgIPM project code set to " + egImpl);
        // if egImply project code is set to true, we don't show the affinity section, thus need to finish the job early
        if (egImpl) {
            autoEnterAddressPage.validateAffinitySectionIsNotDisplayed(fsa);
        } else {
            testStep("Validate skip discount function " + autoEnterAddressPage.validateSkipFGSDiscount());
            testStep("Validate remove employer group function " + autoEnterAddressPage.validateRemoveEmployerGroupFunction());
            testStep("Validate continue with group discount function " + autoEnterAddressPage.continueWithFGSDiscount(applicant));
            testStepAssert(new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant).isOnQuoteSummaryAutoPage(), "Quote Summary page reached");
        }
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA})},
            dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI})
    public void redStatesFarmersGroupSelectPageValidation_F75337(AutoApplicant applicant) throws Exception {
        CurrentlyInsuredPage currentlyInsuredPage = new AceAutoNavigationHelper().navigateToCurrentlyInsuredPage(applicant);
        currentlyInsuredPage.processCurrentlyInsuredPage(true);
        currentlyInsuredPage.waitForSpinnerToBeGone();
        FarmersGroupSelectPage farmersGroupSelectPage = new FarmersGroupSelectPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        farmersGroupSelectPage.validateFWSPage(fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, suiteName = "FWS Interstitial To Bindable Choice Integration",
            dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, WI, MO, TX, AL, IN, OH})})
    public void validateFWSInterstitialToBindableChoiceIntegrationAuto(AutoApplicant applicant) throws Exception {
        String stateCode = applicant.getStateCode();
        if (stateCode.equals(AZ)) {
            //F96273
            applicant.setFirstName("Cynthia");
            applicant.setLastName("Martin");
            applicant.setResidentAddress("2081 S AGNES LN");
            applicant.setZipCode("85295");
        }
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper(AceAutoNavigationHelper.quoteFlow.DEFAULT).navigateToAutoEnterAddressPage(applicant);
        testStep("Navigate to Address Page");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        autoEnterAddressPage.fillOutAddressPage(applicant);
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        fsa.assertTrue(fwsInterstitialPage.isOnFarmersChoiceInterstitialPage(), "User did not navigate to FWS Interstitial - Farmers choice page");
        fwsInterstitialPage.validateFwsFarmersChoicePage(fsa, AUTO);
        fwsInterstitialPage.clickOnApplyDiscountButton();
        fwsInterstitialPage.validateFWSInterstitialDialogContent(fsa);
        fwsInterstitialPage.clickOnDialogContainerAgreeButton();
        fwsInterstitialPage.waitForSpinnerToBeGone();
        fsa.assertTrue(fwsInterstitialPage.isOnBindableChoicePage(10), "User did not navigate to Bindable Choice page after clicking on Apply Discount button from FWS Interstitial page");
        FarmersGroupSelectPage farmersGroupSelectPage = new FarmersGroupSelectPage();
        farmersGroupSelectPage.validateSelectedInsuranceType(fsa);
        fsa.assertAll("Validate FWS Interstitial to Bindable Choice Integration - AUTO LOB.");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, suiteName = "FWS Interstitial Colp Page Auto",
            dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, WI, MO, TX, AL, IN, OH})})
    public void validateFWSInterstitialColpPageAuto(AutoApplicant applicant) throws Exception {
        String stateCode = applicant.getStateCode();
        if (stateCode.equals(AZ)) {
            //F96273
            applicant.setFirstName("Matt");
            applicant.setLastName("Ellenberger");
            applicant.setResidentAddress("6497 W GEORGETOWN WAY");
            applicant.setZipCode("85132");
        }
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        testStep("Navigate to Address Page");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        autoEnterAddressPage.fillOutAddressPage(applicant);
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        fsa.assertTrue(fwsInterstitialPage.isOnColpInterstitialPage(), "User did not navigate to FWS Interstitial - Colp page");
        driver().navigate().refresh(); //F96276
        fwsInterstitialPage.validateFwsColpPage(fsa, AUTO);
        fsa.assertAll("Validate FWS Interstitial COLP page content - Auto LOB.");
    }

    /**
     * "Validate if FWS Choice Insurance Screen gets displayed only for Eligible users (i.e.) when the customer info (FN, LN, Address, Zip) matches with the values in T_MKT_GRP_ELGBL_EMPE table.
     * <p>
     * Sample data below:
     * CA State [R10]
     * FN: DIEGO
     * LN: JUAREZ
     * Address: 13528 SOMERSET ST, HESPERIA, CA, 92344
     * Company name [UI]: Entertainment Benefits Group
     * <p>
     * FN: DALLAS
     * LN: SCHURR
     * Address: 310 S 6TH ST, RICHMOND, 77469"
     */

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX, CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void validateFWSPageDisplayedWithValidData(AutoApplicant applicant) throws Exception {

        // update the data for applicant to match with the eligible data in T_MKT_GRP_ELGBL_EMPE table to trigger the FWS interstitial page
        String stateCode = applicant.getStateCode();
        if (stateCode.equals(TX)) {
            applicant.setFirstName("Dallas");
            applicant.setLastName("Schurr");
            applicant.setCity("Richmond");
            applicant.setResidentAddress("310 S 6TH ST");
            applicant.setZipCode("77469");
        } else if (stateCode.equals(CA)) {
            applicant.setFirstName("Diego");
            applicant.setLastName("Juarez");
            applicant.setCity("Hesperia");
            applicant.setResidentAddress("13528 SOMERSET ST");
            applicant.setZipCode("92344");
        }
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        AutoEnterAddressPage autoEnterAddressPage = aceAutoNavigationHelper.navigateToAutoEnterAddressPage(applicant);
        testStep("Navigate to Address Page");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        autoEnterAddressPage.fillOutAddressPage(applicant);
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        fsa.assertTrue(fwsInterstitialPage.isOnFarmersChoiceInterstitialPage(), "User did not navigate to Farmers Choice Interstitial Page");
        fwsInterstitialPage.validateFwsFarmersChoicePage(fsa, AUTO);

        boolean acceptDiscount = RandomUtils.nextBoolean(); // randomize the discount acceptance to cover both scenarios in the test
        Log.info("Randomly " + (acceptDiscount ? "accepting" : "rejecting") + " the discount offer on FWS Interstitial page.");
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        if (!acceptDiscount) {
            fwsInterstitialPage.clickContinueWithoutDiscount();
            if (aceAutoNavigationHelper.isVehiclesDriversConsolidationImpl(stateCode)) {
                VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
                fsa.assertTrue(vehiclesDriversInfoPage.isOnVehiclesDriversInfoPage(), "User did not navigate to Vehicles and Drivers Info page after clicking on Continue without Discount button from FWS Interstitial page - Auto LOB with Vehicles and Drivers consolidation implemented");
                vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
                vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
            } else {
                fsa.assertTrue(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User did not navigate to Who Should We Insure page after clicking on Continue without Discount button from FWS Interstitial page - Auto LOB");
                whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
                whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
            }
            QuoteSummaryAutoPage quoteSummaryAutoPage = whoShouldWeInsurePage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
            fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User did not navigate to Quote Summary page after filling out Who Should We Insure page with default values - Auto LOB");
            fsa.assertAll("Validate FWS Interstitial continue without discount flow - Auto LOB.");
        } else {
            fwsInterstitialPage.clickOnApplyDiscountButton();
            fwsInterstitialPage.clickOnDialogContainerAgreeButton();
            fwsInterstitialPage.waitForSpinnerToBeGone();
            fsa.assertTrue(fwsInterstitialPage.isOnFwsFarmersInsuranceChoicePage(), "User did not navigate to FWS Farmers Insurance Choice page after accepting the discount offer on FWS Interstitial page");
            fsa.assertAll("Validate FWS Interstitial QnB page content - Auto LOB.");
        }
    }

    /**
     *  F104174
     *  Test data: WOODS	DON		31131 PINE ROSE DR		SPRING	TX	77386
     * Luanch URL: URL: https://ffqautouiuat.farmers.com/fastquote/?Lob=Auto&Zip_Code=77386&source_indicator=ML&source_id=MLB0001
     *
     * Steps
     * Launch the above URL and use the above mentioned data
     * Observe the behavior of the system during FFQ launch.
     * Verify whether the FWS Eligibility-MET screen is displayed.

     *  Expected Results
     * The system should suppress (not display) the FWS Eligibility-MET screen, even though FWS data is being used, when FFQ is launched via MLB source code.
     * User should be able to continue with FFQ rating and verify process successfully
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, BW_ACE_TESTS}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX}), @CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void validateFWS_is_SuppressedWithMLB_SourceCode(AutoApplicant applicant) throws Exception {

        // data update
        applicant.setFirstName("Woods");
        applicant.setLastName("Don");
        applicant.setResidentAddress("31131 PINE ROSE DR");
        applicant.setCity("Spring");
        applicant.setStateCode("TX");
        applicant.setZipCode("77386");


        FarmersSoftAssert fsa = new FarmersSoftAssert();

        // navigate until bind
        String url = String.format("%s?Lob=Auto&Zip_Code=%s&source_indicator=ML&source_id=MLB0001", Property.getUri(), applicant.getZipCode());
        driver().get(url);
        updateApplicantDataToAvoidPossibleBw(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        quoteSummaryAutoPage.validateContentForMLBSourceCodePopUp(fsa);
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        completePurchase(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, fsa);
        fsa.assertAll();
    }
}
