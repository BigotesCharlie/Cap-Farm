package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoAdditionalCoveragesPage;
import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.ADDITIONAL_COVERAGES;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoAdditionalCoveragesPageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ADDITIONAL_COVERAGES_PAGE})
    public void testAdditionalCoveragesPageQuotePresentmentCardCondo(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        AceCondoAdditionalCoveragesPage additionalCoveragesPage = new AceCondoNavigationHelper().navigateToAceCondoAdditionalCoveragesPage(applicant);

        additionalCoveragesPage.validatePageTitleSubtitle(fsa);
        additionalCoveragesPage.verifyQuotePresentmentCard(fsa);
        additionalCoveragesPage.validateEmailThisQuoteLink(applicant, fsa);
        additionalCoveragesPage.validateDiscounts(ADDITIONAL_COVERAGES, applicant, CONDO, fsa);
        driver().navigate().refresh();
        additionalCoveragesPage.validatePageTitleSubtitle(fsa);
        additionalCoveragesPage.verifyQuotePresentmentCard(fsa);
        additionalCoveragesPage.verifyTogglesOff(applicant, fsa);
        additionalCoveragesPage.validateContinueButtonAtPageBottom(fsa);
        additionalCoveragesPage.validateRecalculateButtonAtPageBottom(fsa);
        additionalCoveragesPage.validateDiscounts(ADDITIONAL_COVERAGES, applicant, CONDO, fsa);
        //Quote number and Agent details at the bottom validation
        additionalCoveragesPage.validateQuoteText(ADDITIONAL_COVERAGES, applicant.getQuoteNumber(), fsa, true);
        additionalCoveragesPage.validateAgentSection(fsa, ADDITIONAL_COVERAGES, applicant.getAgentId(), CONDO);
        fsa.assertAll("Validate Ace Condo Additional Coverages page - Quote Presentment Card.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDITIONAL_COVERAGES_PAGE})
    public void testAdditionalCoveragesPageTogglesValidationCondo(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicant.setSquareFeet("400");
        AceCondoAdditionalCoveragesPage additionalCoveragesPage = new AceCondoNavigationHelper().navigateToAceCondoAdditionalCoveragesPage(applicant);

        additionalCoveragesPage.validateAdditionalCoveragesTogglesText(applicant, fsa);
        additionalCoveragesPage.validateAdditionalCoveragesTogglesPremium(applicant, fsa);
        additionalCoveragesPage.validateSwitchingToAndFromReviewQuotePageCondo(applicant, fsa);

        fsa.assertAll("Validate Ace Condo Additional Coverages page - Toggles Validation.");
    }

}
