package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Arrays;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class RedStatesHandlingTest extends BaseTest {

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})},
    				dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateCurrentlyInsuredPage_F75337(AutoApplicant applicant) throws Exception {
        CurrentlyInsuredPage currentlyInsuredPage = new AceAutoNavigationHelper().navigateToCurrentlyInsuredPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        currentlyInsuredPage.validateCurrentlyInsuredPage(applicant, fsa);
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})},
    				dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateCurrentlyInsuredValidEmployerWithDiscount_F75337(AutoApplicant applicant) throws Exception {
        CurrentlyInsuredPage currentlyInsuredPage = new AceAutoNavigationHelper().navigateToCurrentlyInsuredPage(applicant);
        FarmersGroupSelectPage farmersGroupSelectPage = new FarmersGroupSelectPage();
        CallForQuotePage callForQuotePage = new CallForQuotePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        currentlyInsuredPage.processCurrentlyInsuredPage(true);
        farmersGroupSelectPage.processFarmersGroupSelectPage(true);
        sleep(5);
        callForQuotePage.validateCallForQuotePage(fsa);
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})},
    				dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateCurrentlyInsuredValidEmployerSkipDiscount_F75337(AutoApplicant applicant) throws Exception {
        CurrentlyInsuredPage currentlyInsuredPage = new AceAutoNavigationHelper().navigateToCurrentlyInsuredPage(applicant);
        FarmersGroupSelectPage farmersGroupSelectPage = new FarmersGroupSelectPage();
        FarmersGeneralInsuranceAgencyPage farmersGeneralInsuranceAgencyPage = new FarmersGeneralInsuranceAgencyPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(currentlyInsuredPage.isOnCurrentlyInsuredPage(), "User is successfully landed on CurrentlyInsuredPage");
        currentlyInsuredPage.processCurrentlyInsuredPage(true);
        farmersGroupSelectPage.processFarmersGroupSelectPage(false);
        sleep(5);
        farmersGeneralInsuranceAgencyPage.validateFGIAPromptPage(fsa, true, applicant.getZipCode());
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})},
    				dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateCurrentlyInsuredValidEmployerSkipDiscount_SkipFGIA_F75337(AutoApplicant applicant) throws Exception {
        CurrentlyInsuredPage currentlyInsuredPage = new AceAutoNavigationHelper().navigateToCurrentlyInsuredPage(applicant);
        FarmersGroupSelectPage farmersGroupSelectPage = new FarmersGroupSelectPage();
        FarmersGeneralInsuranceAgencyPage farmersGeneralInsuranceAgencyPage = new FarmersGeneralInsuranceAgencyPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(currentlyInsuredPage.isOnCurrentlyInsuredPage(), "User is successfully landed on CurrentlyInsuredPage");
        currentlyInsuredPage.processCurrentlyInsuredPage(true);
        farmersGroupSelectPage.processFarmersGroupSelectPage(false);
        sleep(5);
        farmersGeneralInsuranceAgencyPage.validateFGIAPromptPage(fsa, false, applicant.getZipCode());
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})},
    				dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateCurrentlyInsured_InValidEmployerWithDiscount_F75337(AutoApplicant applicant) throws Exception {
        CurrentlyInsuredPage currentlyInsuredPage = new AceAutoNavigationHelper().navigateToCurrentlyInsuredPage(applicant);
        FarmersGroupSelectPage farmersGroupSelectPage = new FarmersGroupSelectPage();
        FarmersGeneralInsuranceAgencyPage farmersGeneralInsuranceAgencyPage = new FarmersGeneralInsuranceAgencyPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(currentlyInsuredPage.isOnCurrentlyInsuredPage(), "User is successfully landed on CurrentlyInsuredPage");
        currentlyInsuredPage.processCurrentlyInsuredPage(true);
        farmersGroupSelectPage.invalidEmployeeGroup();
        sleep(5);
        farmersGeneralInsuranceAgencyPage.validateFGIAPromptPage(fsa, true, applicant.getZipCode());
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})},
    				dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateCurrentlyNotInsured_ContinueWithBristolWest_OR_ContinueWithFGIA_F75337(AutoApplicant applicant) throws Exception {
        CurrentlyInsuredPage currentlyInsuredPage = new AceAutoNavigationHelper().navigateToCurrentlyInsuredPage(applicant);
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        FarmersGeneralInsuranceAgencyPage farmersGeneralInsuranceAgencyPage = new FarmersGeneralInsuranceAgencyPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(currentlyInsuredPage.isOnCurrentlyInsuredPage(), "User is successfully landed on CurrentlyInsuredPage");
        currentlyInsuredPage.processCurrentlyInsuredPage(false);
        boolean redStates_2 = Arrays.asList(NC, NV).contains(applicant.getStateCode());
        if (redStates_2) {
            farmersGeneralInsuranceAgencyPage.validateFGIAPromptPage(fsa, true, applicant.getZipCode());
            String FGIA_URL = "https://quote-uat.farmersgeneralinsuranceagency.com";
            String FGIA_ActualURL = driver().getCurrentUrl();
            fsa.assertTrue(FGIA_ActualURL.contains(FGIA_URL), "User Landed on 'FARMERS GENERAL INSURANCE AGENCY' page");
            sleep(5);
            String PAGE_TITLE = "Farmers General Insurance Agency, Inc. | Select insurance type";
            String pageTitle = driver().getTitle();
            Log.info("Found page title: " + pageTitle);
            fsa.assertTrue(pageTitle.contains(PAGE_TITLE), "'Farmers Insurance Choice' page title validation");
        } else {
            fsa.assertTrue(continueWithBristolWestPage.isBristolWestAlternatePageDialogTitleCorrect(applicant.getStateCode()), "Correct content of BW dialog title");
            fsa.assertTrue(continueWithBristolWestPage.isBristolWestAlternatePageDialogTextContentCorrect(), "Correct content of BW dialog text");
            fsa.assertTrue(continueWithBristolWestPage.isBristolWestAlternatePageDialogDisclaimerCorrect(), "Correct content of BW dialog disclaimer");
            fsa.assertTrue(continueWithBristolWestPage.areBristolWestAlternatePageDialogButtonsCorrect(), "Correct content of BW dialog buttons");
            continueWithBristolWestPage.continueWithBWPage(true);
            NameAndDobPage nameAndDobPage = new NameAndDobPage();
            nameAndDobPage.isOnNameAndDobPage();
        }
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CT, MA, NC, NV})},
    				dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateCurrentlyNotInsured_NOThanksBW_MonetizationPage_F75337(AutoApplicant applicant) throws Exception {
        CurrentlyInsuredPage currentlyInsuredPage = new AceAutoNavigationHelper().navigateToCurrentlyInsuredPage(applicant);
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        FarmersGeneralInsuranceAgencyPage farmersGeneralInsuranceAgencyPage = new FarmersGeneralInsuranceAgencyPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(currentlyInsuredPage.isOnCurrentlyInsuredPage(), "User is successfully landed on CurrentlyInsuredPage");
        currentlyInsuredPage.processCurrentlyInsuredPage(false);
        boolean redStates_2 = Arrays.asList(NC, NV).contains(applicant.getStateCode());
        if (redStates_2) {
            farmersGeneralInsuranceAgencyPage.validateFGIAPromptPage(fsa, false, applicant.getZipCode());
        } else {
            fsa.assertTrue(continueWithBristolWestPage.isBristolWestAlternatePageDialogTitleCorrect(applicant.getStateCode()), "Correct content of BW dialog title");
            fsa.assertTrue(continueWithBristolWestPage.isBristolWestAlternatePageDialogTextContentCorrect(), "Correct content of BW dialog text");
            fsa.assertTrue(continueWithBristolWestPage.isBristolWestAlternatePageDialogDisclaimerCorrect(), "Correct content of BW dialog disclaimer");
            fsa.assertTrue(continueWithBristolWestPage.areBristolWestAlternatePageDialogButtonsCorrect(), "Correct content of BW dialog buttons");
            continueWithBristolWestPage.continueWithBWPage(false);
            farmersGeneralInsuranceAgencyPage.validateFGIAPromptPage(fsa, false, applicant.getZipCode());
        }
        fsa.assertAll();
    }


    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = FL)},
    				dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validate_FL_ContinueWithBW_F75337(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
    	ContinueWithBristolWestPage continueWithBristolWestPage = navigateToGetABristolWestQuotePage(applicant, fsa);
    	if(!continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()) {
           return;
        }
        continueWithBristolWestPage.continueWithBWPage(true);
    	continueWithBristolWestPage.waitForSpinnerToBeGone();
    	NameAndDobPage nameAndDobPage = new NameAndDobPage();
    	fsa.assertTrue(nameAndDobPage.isOnNameAndDobPage(), "Reached Name and DOB page");
    	fsa.assertTrue(nameAndDobPage.isBristolWestQuote(), "Quoting on Bristol West");
    	fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = FL)},
    				dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validate_FL_NoThanksBW_F75337(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
    	ContinueWithBristolWestPage continueWithBristolWestPage = navigateToGetABristolWestQuotePage(applicant, fsa);
        if(!continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()) {
            return;
        }
        continueWithBristolWestPage.continueWithBWPage(false);
    	continueWithBristolWestPage.waitForSpinnerToBeGone();
        FarmersGeneralInsuranceAgencyPage farmersGeneralInsuranceAgencyPage = new FarmersGeneralInsuranceAgencyPage();
        farmersGeneralInsuranceAgencyPage.validateFGIAPromptPage(fsa, true, applicant.getZipCode());
        String FGIA_URL = "https://quote-uat.farmersgeneralinsuranceagency.com";
        String FGIA_ActualURL = driver().getCurrentUrl();
        fsa.assertTrue(FGIA_ActualURL.contains(FGIA_URL),"User Landed on 'FARMERS GENERAL INSURANCE AGENCY' page");
        fsa.assertAll();
    }


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,  testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {FL})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateRedirectionToBwInterstitialPage(AutoApplicant applicant) throws Exception {
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        new LandingPage(continueWithBristolWestPage.isUseMobileViewEnabled()).enterLandingPageDataAndContinue(LOB_AUTO, applicant.getZipCode());
        continueWithBristolWestPage.validateRedirectionToBwInterstitialPage(applicant);
    }

    private ContinueWithBristolWestPage navigateToGetABristolWestQuotePage(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
    	new LandingPage().enterLandingPageData(LOB_AUTO, applicant.getZipCode());
    	ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
    	continueWithBristolWestPage.waitForSpinnerToBeGone();
    	if (continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()) {
    		fsa.assertTrue(continueWithBristolWestPage.isBristolWestAlternatePageDialogTitleCorrect(applicant.getStateCode()), "Correct content of BW dialog title");
    		fsa.assertTrue(continueWithBristolWestPage.isBristolWestAlternatePageDialogTextContentCorrect(), "Correct content of BW dialog text");
    		fsa.assertTrue(continueWithBristolWestPage.isBristolWestAlternatePageForFL_DialogDisclaimerCorrect(), "Correct content of BW dialog disclaimer");
    		fsa.assertTrue(continueWithBristolWestPage.areBristolWestAlternatePageDialogButtonsCorrect(), "Correct content of BW dialog buttons");
    	} else {
    		Log.warn("Did not reach \"Get a Bristol West Quote\" page");
    	}
    	return continueWithBristolWestPage;
    }
}

