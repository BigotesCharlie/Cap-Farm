package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyInfoBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCQualityGradeBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.QUALITY_GRADE;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoQualityGradePageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_QUALITY_GRADE_PAGE})
    public void validateContentOfQualityGradePageCondoLob(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceCondoNavigationHelper navigator = new AceCondoNavigationHelper();
        boolean quoteDisplayed = navigator.isNewFlowEnabledState(applicant.getStateCode());
        AceHRCPropertyInfoBasePage propertyInfoBasePage = navigator.navigateToAceCondoPropertyInfoPage(applicant);
        navigator.setResumeFromPage(PROPERTY_INFO);
        AceHRCQualityGradeBasePage qualityGradePage;
        if (!propertyInfoBasePage.isQualityGradePageAvailable()) {
            // New flow - F109072: FFQ Home: Suppression of "Your Home Quality Grade" Screen (A/B test)
            qualityGradePage = navigator.navigateToHRCPropertyDetailsQualityGradePage(applicant, LOB_CONDO, CONDO);
            qualityGradePage.validateHeaderForQualityGradeSection(fsa, CONDO);
            qualityGradePage.validateAddressOnQualityGradeSection(fsa, CONDO);
        } else {
            // Old flow - Quality grade page is a separate page
            qualityGradePage = navigator.navigateToHRCQualityGradePage(applicant, LOB_CONDO, CONDO);
            qualityGradePage.validateHeaderAndSubHeaderForQualityGradePage(fsa, CONDO);
            qualityGradePage.validateAddressOnQualityGradePage(fsa, CONDO);
        }
        AppStore appStore = qualityGradePage.getSessionStorageAppStore();
        qualityGradePage.validateErrorOnQualityGradePage(fsa, appStore.getHome().getHomeQualityGradeForm(), CONDO);
        qualityGradePage.validateGeneralShapeAndStyleSection(fsa, appStore.getHome(), CONDO);
        qualityGradePage.validateExteriorFeaturesAndFinishedSection(fsa, appStore.getHome(), CONDO);
        qualityGradePage.validateInteriorFeaturesAndFinishedSection(fsa, appStore.getHome(), CONDO);
        qualityGradePage.validateCabinetsAndCounterTopsSection(fsa, appStore.getHome(), CONDO);
        qualityGradePage.validateWhyIsThisImportantQuestionSectionValidation(fsa, CONDO);
        qualityGradePage.validateDiscounts(QUALITY_GRADE, applicant, CONDO, fsa);
        qualityGradePage.validateQuoteText(QUALITY_GRADE, applicant.getQuoteNumber(), fsa, quoteDisplayed);
        qualityGradePage.validateAgentSection(fsa, QUALITY_GRADE, applicant.getAgentId(), CONDO);
        fsa.assertAll("Ace Condo - Quality grade validation");
    }
}
