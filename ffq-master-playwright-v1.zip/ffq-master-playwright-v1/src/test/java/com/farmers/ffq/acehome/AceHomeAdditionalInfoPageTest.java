package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCAdditionalInfoBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyDetailsBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AddressNearMap;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.data.ExcelDataProvider;
import com.farmers.framework.report.Log;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeAdditionalInfoPageTest extends AutomationFramework {

    private static final String STATE_EQ = "state=";
    private static final String NEARMAP_SPREADSHEET = "src/test/resources/Nearmap+Roof+Age+Prefill+Test+Addresses.xlsx";
    private static final String NEARMAP_WORKSHEET_EVD_7_OR_8 = "Addresses w-Evidence 7 or 8";
    private static final String NEARMAP_WORKSHEET_EVD_NOT_7_OR_8 = "Addresses w-Evid Type NOT 7 8";

    private AddressNearMap getRandomAddressNearMapEvd7or8FromState(String stateCode) throws Exception {
        List<AddressNearMap> listOfAddressesFromState = getAddresses(NEARMAP_WORKSHEET_EVD_7_OR_8, STATE_EQ + stateCode);
        AddressNearMap addressNearMap = null;
        if (!listOfAddressesFromState.isEmpty()) {
            Collections.shuffle(listOfAddressesFromState);
            addressNearMap = listOfAddressesFromState.get(0);
        }
        return addressNearMap;
    }

    private AddressNearMap getRandomAddressNearMapEvdNot7or8FromState(String stateCode) throws Exception {
        List<AddressNearMap> listOfAddressesFromState = getAddresses(NEARMAP_WORKSHEET_EVD_NOT_7_OR_8, STATE_EQ + stateCode);
        AddressNearMap addressNearMap = null;
        if (!listOfAddressesFromState.isEmpty()) {
            Collections.shuffle(listOfAddressesFromState);
            addressNearMap = listOfAddressesFromState.get(0);
        }
        return addressNearMap;
    }

    private List<AddressNearMap> getAddresses(String xlDataSheetName, String filter) throws Exception {
        ExcelDataProvider excel = new ExcelDataProvider();
        JSONArray json = excel.filterJsonData(filter, excel.getDataJson(NEARMAP_SPREADSHEET, xlDataSheetName));
        List<AddressNearMap> addressList = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
        for (int i = 0; i < json.length(); i++) {
            String js = json.getJSONObject(i).toString();
            AddressNearMap address = mapper.readValue(js, AddressNearMap.class);
            addressList.add(address);
        }
        return addressList;
    }

    private void updateApplicantWithAddressNearMap(ApplicantAceHome applicant, AddressNearMap addressNearMap) {
        applicant.setAddress(addressNearMap.getStreet_address());
        applicant.setCity(addressNearMap.getCity());
        applicant.setStateCode(addressNearMap.getState());
        applicant.setZipCode(addressNearMap.getZip_code());
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, CT, ID, KY, LA, MA, MD, MI, MN, MS, MT, NC, NJ, NV, NY, OR, PA, UT, VA, WA})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE})
    public void testAdditionalInfoPageNearMapRoofYearPrefilled(ApplicantAceHome applicant) throws Exception {
        // F97409: PL - Nearmap Integration for Roof Age Prefill in FFQ Home Quotes - PI40 Rollout
        AddressNearMap addressNearMap = getRandomAddressNearMapEvd7or8FromState(applicant.getStateCode());
        if (addressNearMap != null) {
            updateApplicantWithAddressNearMap(applicant, addressNearMap);
            applicant.setKeep360Prefill(true);
            Log.info(" >>> Address pulled from Near map prefill validation with evidence 7 or 8: " + addressNearMap);
        } else {
            throw new SkipException(" >>> Test case skipped - No address found in Near map data with evidence 7 or 8 for state: " + applicant.getStateCode());
        }
        AceHRCAdditionalInfoBasePage additionalInfoPage = new AceHomeNavigationHelper().navigateToAceHomeAdditionalInfoPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertEquals(additionalInfoPage.getRoofYearPrefilledByNearMap(), addressNearMap.getRoof_installation_year(), "Additional info page - Year roof replaced matches.");
        fsa.assertAll("Additional info page - Roof year prefilled from Near map.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, CT, ID, KY, LA, MA, MD, MI, MN, MS, MT, NC, NJ, NV, NY, OR, PA, UT, VA, WA})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE})
    public void testAdditionalInfoPageNearMapRoofYearNotPrefilled(ApplicantAceHome applicant) throws Exception {
        // F97409: PL - Nearmap Integration for Roof Age Prefill in FFQ Home Quotes - PI40 Rollout
        AddressNearMap addressNearMap = getRandomAddressNearMapEvdNot7or8FromState(applicant.getStateCode());
        if (addressNearMap != null) {
            updateApplicantWithAddressNearMap(applicant, addressNearMap);
            applicant.setKeep360Prefill(true);
            Log.info(" >>> Address pulled from Near map prefill validation with evidence NOT 7 or 8: " + addressNearMap);
        } else {
            throw new SkipException(" >>> Test case skipped - No address found in Near map data with evidence NOT 7 or 8 for state: " + applicant.getStateCode());
        }
        AceHRCAdditionalInfoBasePage additionalInfoPage = new AceHomeNavigationHelper().navigateToAceHomeAdditionalInfoPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertEquals(additionalInfoPage.getNumberOfRoofReplacedToggleButtons(), 2, "Additional info page - Year roof replaced toggle buttons are displayed.");
        fsa.assertAll("Additional info page - Roof year is NOT prefilled from Near map.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE})
    public void validateAdditionalInfoPageContentHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCAdditionalInfoBasePage additionalInfoPage = new AceHomeNavigationHelper().navigateToAceHomeAdditionalInfoPage(applicant, LOB_HOME, HOME);

        FarmersSoftAssert fsa = new FarmersSoftAssert();

        List<String> wroughtIronBarsState = List.of(NM);
        List<String> homeTransferDiscountState = List.of(WI);
        List<String> wildfireRiskReductionState = List.of(OR);
        List<String> nonFireAlarmState = List.of(IA);
        List<String> fireProtectionSystemState = List.of(MS, NC);
        List<String> nonBurglarAlarmState = List.of(KS, NC, IA);
        List<String> nonWaterLeakProtectionState = List.of(KS, IA);
        List<String> nonFortifiedHomeState = List.of(KS, MS, NC, IA);
        List<String> impactResistantGlassState = List.of(CT);
        List<String> oilTankOnPremisesState = List.of(MA);
        String stateCode = applicant.getStateCode();

        additionalInfoPage.validateTheHeaderOfAdditionalInfoPage(fsa);
        additionalInfoPage.validateContentOfRoofSection(fsa, stateCode);
        additionalInfoPage.validateContentOfPlumbingReplaced20YearsSection(fsa, applicant);
        if (!additionalInfoPage.isNoHomeShareState(stateCode)) {
            additionalInfoPage.validateContentOfTemporaryRentalSection(fsa);
        }
        if (impactResistantGlassState.contains(stateCode)) {
            additionalInfoPage.validateContentOfImpactResistantGlassSection(fsa);
        }
        additionalInfoPage.validateContentOfSwimmingPoolSection(fsa);
        if (!additionalInfoPage.isNoSolarPanelsState(stateCode)) {
            additionalInfoPage.validateContentOfSolarPanelSection(fsa);
        }
        additionalInfoPage.validateContentOfTrampolineSection(fsa);

        additionalInfoPage.validateContentOfStormShutterSection(fsa, stateCode);
        if (oilTankOnPremisesState.contains(stateCode)) {
            additionalInfoPage.validateOilTankOnPremisesGlassSection(fsa);
        }
        additionalInfoPage.validateDiscountHeadingAndDivider(fsa);
        if (!fireProtectionSystemState.contains(stateCode) &&
                !additionalInfoPage.isCentralFireAlarmState(stateCode)) {
            additionalInfoPage.validateContentOfFireAlarmSection(fsa);
        }
        if (!nonBurglarAlarmState.contains(stateCode) &&
                !additionalInfoPage.isCentralBurglarAlarmState(stateCode)) {
            additionalInfoPage.validateContentOfBurglarAlarmSection(fsa);
        }
        if (!List.of(KS, MS, NC).contains(stateCode) &&
                !additionalInfoPage.isOtherHomeProtectionFeaturesState(stateCode)) {
            additionalInfoPage.validateContentOfFortifiedHomeSection(fsa);
        }

        if (!nonFireAlarmState.contains(stateCode) &&
                !fireProtectionSystemState.contains(stateCode) &&
                !additionalInfoPage.isCentralFireAlarmState(stateCode)) {
            additionalInfoPage.validateContentOfFireAlarmSection(fsa);
        }
        if (!nonBurglarAlarmState.contains(stateCode) &&
                !additionalInfoPage.isCentralBurglarAlarmState(stateCode)) {
            additionalInfoPage.validateContentOfBurglarAlarmSection(fsa);
        }
        if (!nonWaterLeakProtectionState.contains(stateCode) &&
                !additionalInfoPage.isOtherHomeProtectionFeaturesState(stateCode)) {
            additionalInfoPage.validateContentOfWaterLeakProtectionSection(fsa);
        }
        if (!nonFortifiedHomeState.contains(stateCode) &&
                !additionalInfoPage.isOtherHomeProtectionFeaturesState(stateCode)) {
            additionalInfoPage.validateContentOfFortifiedHomeSection(fsa);
        }

        if (wroughtIronBarsState.contains(stateCode)) {
            additionalInfoPage.validateContentOfWroughtIronBarsSection(fsa);
        }

        if (homeTransferDiscountState.contains(stateCode)) {
            additionalInfoPage.validateContentOfHomeTransferDiscountSection(fsa);
        }

        if (wildfireRiskReductionState.contains(stateCode)) {
            additionalInfoPage.validateContentOfWildfireRiskReductionSection(fsa);
        }

        if (additionalInfoPage.isElectricalPlumbingHvacState(stateCode)) {
        	additionalInfoPage.validateContentOfElectricalPlumbingHvacSection(fsa, stateCode);
        } else {
        	additionalInfoPage.validateAbsenseOfElectricalPlumbingHvacSection(fsa);
        }

        if (new AceHRCBasePage().isUlRoofState(stateCode)) {
            additionalInfoPage.validateContentOfULRoof(fsa);
        }

        if (new AceHRCBasePage().isOtherHomeProtectionFeaturesState(stateCode)) {
            additionalInfoPage.validateContentOfOtherHomeProtectionSection(applicant, fsa);
        }

        // fill out existing options in order to check the discounts
        boolean newFlowState = additionalInfoPage.isNewFlowEnabledState(stateCode);
        additionalInfoPage.fillOutAdditionalInfoPageHomeLob(applicant, !newFlowState); // do not go to the next page, if it's not new flow state
        additionalInfoPage.validateDiscounts(AceHRCBasePage.ADDITIONAL_INFO, applicant, HOME, fsa);
        additionalInfoPage.validateQuoteText(AceHRCBasePage.ADDITIONAL_INFO, applicant.getQuoteNumber(), fsa, newFlowState); // quote number is available in new flow state
        additionalInfoPage.validateAgentSection(fsa, AceHRCBasePage.ADDITIONAL_INFO, applicant.getAgentId(), HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE})
    public void validateAdditionalInfoErrorsHomeLob(ApplicantAceHome applicantAceHome) throws Exception {

        AceHRCAdditionalInfoBasePage additionalInfoPageAceHome = new AceHomeNavigationHelper().navigateToAceHomeAdditionalInfoPage(applicantAceHome, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalInfoPageAceHome.validateAdditionalInfoPageErrors(fsa, applicantAceHome);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE})
    public void validateFloorResidenceLocatedHomeLob(ApplicantAceHome applicantAceHome) throws Exception {
        applicantAceHome.setAddress("26072 Perdido Beach");
        applicantAceHome.setUnit("100E");
        applicantAceHome.setCity("Orange Beach");
        applicantAceHome.setZipCode("36561");

        AceHRCAdditionalInfoBasePage additionalInfoPageAceHome = new AceHomeNavigationHelper().navigateToAceHomeAdditionalInfoPage(applicantAceHome, LOB_HOME, HOME);
        testStepAssertTrue(additionalInfoPageAceHome.validateFloorResidenceIsLocatedOnSection(HOME), "Floor residence is located section is not displayed", true);
        testStep("End Of Test");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_INFO_PAGE})
    public void testDataSaveChangesWhenNavigatedBackandForthAdditionalInfoPageHomeLob(ApplicantAceHome applicantAceHome) throws Exception {

        AceHRCAdditionalInfoBasePage additionalInfoPage = new AceHomeNavigationHelper().navigateToAceHomeAdditionalInfoPage(applicantAceHome, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        Assert.assertTrue(additionalInfoPage.isOnAdditionalInfoPage(), "Additional Info page is reached");
        additionalInfoPage.fillOutAdditionalInfoPageHomeLob(applicantAceHome,false);
        additionalInfoPage.navigateBack();

        AceHRCPropertyDetailsBasePage propertyDetailsBasePage = new AceHRCPropertyDetailsBasePage();
        Assert.assertTrue(propertyDetailsBasePage.isOnPropertyDetailsPage(), "Properties details page is reached");
        propertyDetailsBasePage.clickContinueButton();

        additionalInfoPage = new AceHRCAdditionalInfoBasePage();
        Assert.assertTrue(additionalInfoPage.isOnAdditionalInfoPage(), "Additional Info page is reached");
        additionalInfoPage.validateDataNotSaved(applicantAceHome, fsa);
        Log.info("Data is not saved when navigate back from addition info page without clicking continue button.", true);
        additionalInfoPage.fillOutAdditionalInfoPageHomeLob(applicantAceHome,true);

        additionalInfoPage.waitForSpinnerToBeGone();
        additionalInfoPage.navigateBack();
        additionalInfoPage.validateAdditionalInfoSelections(applicantAceHome, fsa);
        Log.info("Data is saved when navigate back , after clicking continue button.", true);

        fsa.assertAll("Additional info page - Data is saved when navigated back and forth from the page.");
    }
}