package com.farmers.ffq.specialtyDwelling;

import static com.farmers.ffq.utils.GlobalVariables.AZ;
import static com.farmers.ffq.utils.GlobalVariables.EXCLUDED_STATES;
import static com.farmers.ffq.utils.GlobalVariables.FOREMOST;
import static com.farmers.ffq.utils.GlobalVariables.GA;
import static com.farmers.ffq.utils.GlobalVariables.MO;
import static com.farmers.ffq.utils.GlobalVariables.PA;
import static com.farmers.ffq.utils.GlobalVariables.PARTTIME;
import static com.farmers.ffq.utils.GlobalVariables.RENT;
import static com.farmers.ffq.utils.GlobalVariables.SHORTRENT_DWELLING;
import static com.farmers.ffq.utils.GlobalVariables.SPECIALTY_DWELLING;
import static com.farmers.ffq.utils.GlobalVariables.UNOCCUPIED;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.AutomationFramework;

public class ForemostHomeSpecialtyDwellingPageValidationTests extends AutomationFramework {

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING)}, groups = {SPECIALTY_DWELLING})
	public void verifyForemostDwellingTellUsMorePageContent(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableForemostMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant).verifyTellUsMorePageContent(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING)}, groups = {SPECIALTY_DWELLING})
	public void verifyForemostAdditionalDwellingInformationPageContent(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableForemostMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant).verifyAdditionalDwellingInformationPageContent(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, GA, MO, PA})}, groups = {SPECIALTY_DWELLING})
	public void verifyForemostOtherPolicyQuestionsPageContent(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableForemostMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, PARTTIME).verifyOtherPolicyQuestionsPage(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, GA, MO, PA})}, groups = {SPECIALTY_DWELLING})
	public void verifyForemostQuoteReviewPageContentParttime(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableForemostMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, PARTTIME).verifyQuoteReviewPage(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING)}, groups = {SPECIALTY_DWELLING})
	public void verifyForemostQuoteReviewPageContentRenter(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableForemostMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, RENT).verifyQuoteReviewPage(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING)}, groups = {SPECIALTY_DWELLING})
	public void verifyForemostQuoteReviewPageContentShortRenter(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableForemostMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, SHORTRENT_DWELLING).verifyQuoteReviewPage(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING)}, groups = {SPECIALTY_DWELLING})
	public void verifyForemostQuoteReviewPageContentVacant(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableForemostMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, UNOCCUPIED).verifyQuoteReviewPage(specialtyDwellingApplicant);
	}

	private void enableForemostMode(ApplicantAceHome specialtyDwellingApplicant) {
		specialtyDwellingApplicant.setTestCategory(FOREMOST);
	}
}
