package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static com.farmers.ffq.utils.GlobalVariables.FFQ_ONEUI;

public class BWDefaultCoverageValuesTests_GA extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = GA), @CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION, BW_ACE_TESTS})
    public void BW_testDefaultCoverageValues_GA_100K300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/300&umbrella=No", "GA_100K300K_");
    }

}
