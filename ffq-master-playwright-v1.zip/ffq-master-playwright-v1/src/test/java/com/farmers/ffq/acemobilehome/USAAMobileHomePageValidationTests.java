package com.farmers.ffq.acemobilehome;

import static com.farmers.ffq.utils.GlobalVariables.PARTTIME;
import static com.farmers.ffq.utils.GlobalVariables.UNOCCUPIED;
import static com.farmers.ffq.utils.GlobalVariables.USAA;

import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.AutomationFramework;

public class USAAMobileHomePageValidationTests extends AutomationFramework {

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {"FFQ_MOBILE_HOME"})
	public void verifyUSAAAddressPageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableUSAAMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().verifyAddressPageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {"FFQ_MOBILE_HOME"})
	public void validateUSAAAddressPageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableUSAAMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().validateAddressPageErrorHandling(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {"FFQ_MOBILE_HOME"})
	public void verifyUSAATellUsMorePageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableUSAAMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().verifyTellUsMorePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {"FFQ_MOBILE_HOME"})
	public void validateUSAATellUsMorePageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableUSAAMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().validateTellUsMorePageErrorHandling(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {"FFQ_MOBILE_HOME"})
	public void verifyUSAAAboutYouPageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableUSAAMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().verifyAboutYouPageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {"FFQ_MOBILE_HOME"})
	public void validateUSAAAboutYouPageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableUSAAMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().validateAboutYouPageErrorHandling(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {"FFQ_MOBILE_HOME"})
	public void verifyUSAALastStepPageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableUSAAMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().verifyLastStepPageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {"FFQ_MOBILE_HOME"})
	public void validateUSAALastStepPageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableUSAAMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().validateLastStepPageErrorHandling(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {"FFQ_MOBILE_HOME"})
	public void verifyUSAAQuotePageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableUSAAMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {"FFQ_MOBILE_HOME"})
	public void verifyUSAALandlordMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		//RENT is the default for all applicants
		enableUSAAMode(mobilehomeApplicant);
		mobilehomeApplicant.setPrimaryResidence(false);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {"FFQ_MOBILE_HOME"})
	public void verifyUSAASeasonalSecondaryMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableUSAAMode(mobilehomeApplicant);
		mobilehomeApplicant.setPrimaryResidence(false);
		mobilehomeApplicant.setReasonWhyNotPrimaryResidence(PARTTIME);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_STATE, groups = {"FFQ_MOBILE_HOME"})
	public void verifyUSAAVacantMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableUSAAMode(mobilehomeApplicant);
		mobilehomeApplicant.setPrimaryResidence(false);
		mobilehomeApplicant.setReasonWhyNotPrimaryResidence(UNOCCUPIED);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	private void enableUSAAMode(ApplicantAceHome mobilehomeApplicant) {
		mobilehomeApplicant.setTestCategory(USAA);
	}
}
