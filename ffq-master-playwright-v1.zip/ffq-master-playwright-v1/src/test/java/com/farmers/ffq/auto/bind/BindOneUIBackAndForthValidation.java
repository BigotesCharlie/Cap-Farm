package com.farmers.ffq.auto.bind;
import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.framework.annotation.Skip;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class BindOneUIBackAndForthValidation extends BaseTest {

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BACKANDFORTH}, enabled = false)
    public void bindOneUIEndToEndBackAndForthValidation(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper(applicant.getStateCode().equals(MS)? quoteFlow.AGENT : quoteFlow.DEFAULT).navigateToAdditionalInfoPage(applicant);

        // Back and forth quote summary - few more things page
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        additionalInfoPolicyStartDateOneUI.waitPolicyStartDateVisible();
        fsa.assertTrue(quoteSummaryAutoPage.goBackToQuoteSummaryPageByClickingBackBrowserButton(), errorMessage("Start checkout button"));
        fsa.assertTrue(additionalInfoPolicyStartDateOneUI.goToAdditionalInfoPageByClickingForwardButton(), errorMessage("Policy start date label"));

        AppStore retrieveQuoteResponseSessionStorage = quoteSummaryAutoPage.getSessionStorageAppStore();

        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoContinueToPaymentOneUI.waitForChangeYorCoverageXpathToBeClickable();

        // Back and forth - few more things page - payment summary page
        fsa.assertTrue(additionalInfoPolicyStartDateOneUI.goToAdditionalInfoPageByClickingBrowserBackButton(), "Few more things page loaded successfully");
        fsa.assertTrue(additionalInfoContinueToPaymentOneUI.goToPaymentSummaryByClickingContinueButton(), errorMessage("Payment summary page loaded successfully"));
        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();

        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        // Checking payment setup validation
        autoPolicyPaymentBasePage.selectCardPaymentRadioButtonAlternative();
        autoPolicyPaymentBasePage.clickSetUpPaymentButton();
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyDebitCreditPayment.enterCardNumber(MASTER_CARD);
        policyDebitCreditPayment.enterExpDate(EXP_DATE);
        policyDebitCreditPayment.enterCVVNumber(CVV_NUMBER);
        policyDebitCreditPayment.enterBillingZipCode(ZIP_CODE);
        autoPolicyPaymentBasePage.clickAddButton();
        driver().switchTo().defaultContent();
        policyDebitCreditPayment.waitForCompletePurchaseButtonToBeClickable();
        fsa.assertTrue(policyDebitCreditPayment.isHiddenCardNumberAndExpDateMonthlyPayCorrect(MASTER_CARD, EXP_DATE, CARD_NAME_MASTER),"Hidden card number and exp date");
        fsa.assertTrue(policyDebitCreditPayment.isCreditCardAddedMsgCorrect(), errorMessage("Credit card added message") );
        fsa.assertTrue(policyDebitCreditPayment.isFutureCreditCardServiceChargesTextMatching(),errorMessage("Future service credit card charge"));

        // Back and forth - payment summary page - auto policy payment
        fsa.assertTrue(additionalInfoContinueToPaymentOneUI.goToPaymentSummaryByClickingBackButton(), errorMessage("Payment summary page loaded successfully"));
        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();
        fsa.assertTrue(autoPolicyPaymentBasePage.isAutoPolicyPaymentPageDisplayed(), errorMessage("Auto policy payment page loaded successfully"));
        autoPolicyPaymentBasePage.logInfoMessage(retrieveQuoteResponseSessionStorage.getData().getQuoteNumber());
        autoPolicyPaymentBasePage.addSauceLabsLinkInLog();
        fsa.assertAll();
    }

    private String errorMessage(String item) {
        return item + " text is not correct";
    }

}
