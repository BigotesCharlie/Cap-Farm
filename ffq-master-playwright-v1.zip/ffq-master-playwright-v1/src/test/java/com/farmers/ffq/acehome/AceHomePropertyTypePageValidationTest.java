package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCAddressBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyTypeBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomePropertyTypePageValidationTest extends AutomationFramework {

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_TYPE_PAGE})
    public void testPropertyTypePage(ApplicantAceHome applicant) throws Exception {
        AceHRCPropertyTypeBasePage propertyTypePage = new AceHomeNavigationHelper().navigateToAceHomePropertyTypePage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(propertyTypePage.isPageTitleDisplayed(), "Property Type page - Page title is displayed.");
        fsa.assertTrue(propertyTypePage.isPageTitleInViewport(), "Property Type page - Page title is in Viewport.");
        propertyTypePage.validatePageLinksText(fsa, ENTER_INFO);
        propertyTypePage.validatePageCards(fsa, HOME);
        final List<String> propertyTypes = List.of(HOME,TOWNHOME,DUPLEX);
        for (String propertyType : propertyTypes) {
            propertyTypePage.selectPropertyType(propertyType);
            AceHRCAddressBasePage addressPage = new AceHRCAddressBasePage();
            if (addressPage.isOnAddressPage(true)) {
                addressPage.navigateBack();
                propertyTypePage = new AceHRCPropertyTypeBasePage();
                if (propertyTypePage.isOnPropertyTypePage()) {
                    fsa.assertTrue(propertyTypePage.isImageCardSelected(propertyType), "Property Type page - " + propertyType + " Card is selected.");
                } else {
                    fsa.fail("Did not reach Ace Home Property type page for Property type: " + propertyType);
                }
            }
        }
        fsa.assertAll("Validate Ace Home Property Type page.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,OH,OR,TX,UT})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_TYPE_PAGE})
    public void testPropertyTypePageNewFlow(ApplicantAceHome applicant) throws Exception {
        AceHRCPropertyTypeBasePage propertyTypePage = new AceHomeNavigationHelper().navigateToAceHomePropertyTypePage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(propertyTypePage.isPageTitleDisplayed(), "Property Type page - Page title is displayed.");
        fsa.assertTrue(propertyTypePage.isPageTitleInViewport(), "Property Type page - Page title is in Viewport.");
        propertyTypePage.validatePageLinksText(fsa, ENTER_INFO);
        propertyTypePage.validatePageCardsNewFlow(fsa, false);
        propertyTypePage.validatePageFormFieldsNewFlow(fsa, EMPTY_STRING);
        fsa.assertAll("Validate Ace Home Property Type page.");
    }
}

