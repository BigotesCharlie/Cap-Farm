package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyInfoBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomePropertyInfoPageValidationTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_TYPE_PAGE})
    public void testPropertyInfoPage(ApplicantAceHome applicant) throws Exception {
        AceHRCPropertyInfoBasePage propertyInfoPage = new AceHomeNavigationHelper().navigateToAceHomePropertyInfoPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(propertyInfoPage.isPageTitleDisplayed(), "Property Info page - Page title is displayed.");
        fsa.assertTrue(propertyInfoPage.isPageTitleInViewport(), "Property Info page - Page title is in Viewport.");
        propertyInfoPage.validatePageLinksText(fsa, ENTER_INFO);
        propertyInfoPage.validatePageFormFields(fsa, HOME);
        fsa.assertAll("Validate Ace Home Property Info page.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, OH, OR, TX, UT})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_PROPERTY_TYPE_PAGE})
    public void testPropertyInfoPageErrorMessage(ApplicantAceHome applicant) throws Exception {
        AceHRCPropertyInfoBasePage propertyInfoPage = new AceHomeNavigationHelper().navigateToAceHomePropertyInfoPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        propertyInfoPage.validateCurrentOrPriorHomeAddressErrorMessage(fsa);
        fsa.assertAll("Validate Ace Home Property Info page error messages");
    }

}
