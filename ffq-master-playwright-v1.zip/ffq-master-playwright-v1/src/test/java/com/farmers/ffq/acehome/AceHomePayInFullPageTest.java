package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.home.AceHomeReviewQuotePage;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCJustAFewMoreThingsBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentSelectionPage;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomePayInFullPageTest extends AutomationFramework {

//    F64861: FFQ Ace - Home, Condo, Renters QUOTE & BIND Analysis, Updates, Release - NE, NM, CO, ID, UT -- according to this feature UT has only Pay in full option

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})
    public void testValidateContentOfPayInFullPageOnLandingAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeReviewQuotePage reviewQuotePage = navigator.navigateToAceHomeReviewQuotePage(applicantAceHome, LOB_HOME, HOME);
        String defaultPayPlan = reviewQuotePage.getSessionStorageAppStore().getHome().getQuote().getSelectedPaymentMode();
        if(applicantAceHome.getStateCode().equals(MN) && defaultPayPlan.equals("PIF")){ // F98974/US1101544
            reviewQuotePage.clickPriceAlternative();
        }
        navigator.setResumeFromPage(REVIEW_QUOTE);
        AceHRCPaymentSelectionPage aceHomePaymentSelectionPage = navigator.navigateToAceHomePaymentSelectionPage(applicantAceHome, LOB_HOME, HOME);
        aceHomePaymentSelectionPage.validatePayInFullPaymentCard(fsa, applicantAceHome.getStateCode(), LOB_HOME);
        aceHomePaymentSelectionPage.clickSelectAndSetUpPaymentPayInFullCard(LOB_HOME);
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        Assert.assertTrue(aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage(), "Pay in full payment page is not displayed.");
        aceHRCPaymentBasePage.validateContentOfPayInFullPageOnLanding(fsa, applicantAceHome, HOME, ONE_PAY);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})
    public void testValidateContentOfPayInFullPageAndECheckoutWithLenderSelectedAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicantAceHome.setImpoundAccountSelection(NEW_POLICY_AND_RENEWAL);
        AceHRCJustAFewMoreThingsBasePage aceHRCJustAFewMoreThingsBasePage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicantAceHome, LOB_HOME, HOME);
        aceHRCJustAFewMoreThingsBasePage.fillOutFMTPWithLenderCompanySelected(applicantAceHome, HOME);
        aceHRCJustAFewMoreThingsBasePage.waitForSpinnerToBeGone();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        aceHRCPaymentBasePage.validateContentOfPayInFullPageWithMortgageeInfoOnLanding(fsa, applicantAceHome, HOME);
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})
    public void testValidateContentOfPayInFullPageAndECheckoutWithRenewalSelectedAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicantAceHome.setImpoundAccountSelection(RENEWAL);
        AceHRCJustAFewMoreThingsBasePage aceHRCJustAFewMoreThingsBasePage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicantAceHome, LOB_HOME, HOME);
        aceHRCJustAFewMoreThingsBasePage.fillOutFMTPWithLenderCompanySelected(applicantAceHome, HOME);
        aceHRCJustAFewMoreThingsBasePage.waitForSpinnerToBeGone();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        aceHRCPaymentBasePage.validateContentOfPayInFullPageWithNewPolicyOnLanding(fsa, applicantAceHome, HOME, applicantAceHome.getStateCode());
        PolicyPaymentBasePage PolicyPaymentBasePage = new PolicyPaymentBasePage();
        PolicyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPagePayInFull(fsa, HOME);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateThreeBulletPointsAtTheBottomOfThePaymentPageWithPaperless(fsa, HOME);
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})
    public void validatePaymentByChangingPayInFullBankToMonthlyPayCardAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHomeNavigationHelper().navigateToPayInFullPaymentPageAceHome(applicantAceHome, LOB_HOME, HOME);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPagePayInFull(fsa, HOME);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, HOME);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPagePayInFull(fsa, HOME);
        aceHRCPaymentBasePage.validateOneTimePaymentRecurringRadioButtonText(fsa, HOME);

        // Navigating back and selecting different pay plan and proceeding with payment
        AceHRCBasePage aceHRCBasePage = new AceHRCBasePage();
        aceHRCBasePage.navigateBack();
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
        aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayCard();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, HOME);
        aceHRCPaymentBasePage.validateFutureCreditDebitCardServiceCharges(fsa, true, HOME);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, HOME);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, HOME);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, HOME);
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})
    public void testPayInFullCreditCardEndToEndAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHomeNavigationHelper().navigateToPayInFullPaymentPageAceHome(applicantAceHome, LOB_HOME, HOME);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.clickSetUpPaymentButton();
        policyPaymentBasePage.clickDebitCreditCardButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(VISA_CREDIT_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPagePayInFull(fsa, VISA_CREDIT_CARD, CARD_NAME_VISA, true, HOME);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, HOME);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPagePayInFull(fsa, HOME);
        aceHRCPaymentBasePage.validateOneTimePaymentRecurringRadioButtonText(fsa, HOME);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, HOME);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphPayInFull(fsa, HOME);
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})
    public void testPayInFullChangeBankPaymentToCardPaymentEndToEndAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHomeNavigationHelper().navigateToPayInFullPaymentPageAceHome(applicantAceHome, LOB_HOME, HOME);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPagePayInFull(fsa, HOME);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, HOME);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        policyDebitCreditPayment.clickChangeLink();
        policyPaymentBasePage.clickDebitCreditCardButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPagePayInFull(fsa, MASTER_CARD, CARD_NAME_MASTER, true, HOME);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, HOME);
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_PAY_IN_FULL_PAGE})
    public void testPayInFullChangeCreditCardPaymentToBankPaymentEndToEndAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHomeNavigationHelper().navigateToPayInFullPaymentPageAceHome(applicantAceHome, LOB_HOME, HOME);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        policyPaymentBasePage.clickSetUpPaymentButton();
        policyPaymentBasePage.clickDebitCreditCardButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.switchToParentWindow();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPagePayInFull(fsa, MASTER_CARD, CARD_NAME_MASTER, true, HOME);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, HOME);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        policyDebitCreditPayment.clickChangeLink();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPagePayInFull(fsa, HOME);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, HOME);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {ACE_STABILITY})
    public void testQuoteToPaymentSelectionPageHome(ApplicantAceHome applicantAceHome) throws Exception {
        new AceHomeNavigationHelper().navigateToAceHomePaymentSelectionPage(applicantAceHome, LOB_HOME, HOME);
    }

}
