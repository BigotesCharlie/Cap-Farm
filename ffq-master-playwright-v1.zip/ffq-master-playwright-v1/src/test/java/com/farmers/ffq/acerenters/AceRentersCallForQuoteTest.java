package com.farmers.ffq.acerenters;

import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCCallForQuotePage;
import com.farmers.ffq.ace.renters.AceRentersAddressPage;
import com.farmers.ffq.ace.renters.AceRentersNavigationHelper;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;


/**
 * Farmers Fast Quote (FFQ) - Call for Quote to FFQ Integration Scenario.
 */
public class AceRentersCallForQuoteTest extends AutomationFramework {

	private static final String GROUP = "BANK OF AMERICA";

	// Including some states which are applicable for Employer/group affinity discount.
	@Skip // Skipping the test cases as EG project code is enabled for most of the states
	@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, AL, GA, IL, OH, VA})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ADDRESS_PAGE})
	public void testCallForQuoteToAceReviewQuoteRentersLob(ApplicantAceHome applicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		applicant.setAgentId(null);
		AceRentersNavigationHelper navigator = new AceRentersNavigationHelper();
		AceRentersAddressPage addressPage = navigator.navigateToAceRentersAddressPage(applicant);
		addressPage.enterAddress(applicant);
		addressPage.acceptCookies();
		Assert.assertTrue(addressPage.isCheckYourEligibilityLinkDisplayed(fsa), "Check your eligibility link is not displayed for employer affinity - Renters");
		addressPage.setEmployerGroup(GROUP);
		fsa.assertEquals(addressPage.getSelectedEmployerName(), GROUP, "Employer group name is not displayed.");
		addressPage.clickContinueButton();
		new AceHRCCallForQuotePage().validateCallForQuote(applicant, GROUP, fsa);

		Assert.assertTrue(addressPage.isOnAddressPageRenters(true), "Did not Reach to Address page when navigating back from Call for Quote page.");
		fsa.assertFalse(addressPage.isCheckYourEligibilityLinkDisplayed(fsa), "Back to Address page - No Employer question anymore.");
		navigator.setResumeFromPage(AceHRCBasePage.ADDRESS_PAGE);
		navigator.navigateToAceRentersReviewQuotePage(applicant);

		fsa.assertAll("Validate Call for Quote to FFQ integration - Renters Lob");
	}
}