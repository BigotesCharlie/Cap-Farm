package com.farmers.ffq.auto.e2e;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.BaseTest;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.common.pages.MediaAlphaPageAuto;
import com.farmers.ffq.common.pages.MediaAlphaStartPage;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.ADPFRequestPayload;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;
import com.farmers.framework.report.Log;

import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceAutoMediaAlphaTests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=29"),
    		@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {"mediaAlphaAuto", FFQ_ONEUI})
    public void mediaAlphaFlowMarriedWith2Veh(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        // For specific test case purpose, setting relationship to applicant as "Other" for the additional driver to check if the PNI is passed/mapped as married.
        applicant.getAdditionalDrivers().get(0).setRelationshipToApplicant("Other");
        applicant.setLastName("Bailey");
        applicant.setContinuosInsurancePeriod("1 year");
        applicant.getVehicles().remove(2); // remove 3rd vehicle
        MediaAlphaStartPage mediaAlphaStartPage = new MediaAlphaStartPage();


        mediaAlphaStartPage.processMediaAlphaStartPage(applicant.getZipCode(), AUTO);

        MediaAlphaPageAuto mediaAlphaPageHome = new MediaAlphaPageAuto();
        Assert.assertTrue(mediaAlphaPageHome.isOnMediaAlphaPageAuto(), "Did not reach Media Alpha Auto page.");
        mediaAlphaPageHome.enterAutoApplicantData(applicant);

        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        processAlphaMediaFlowInFfq(applicant, softAssert, false, true);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=29"),
    		@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {"mediaAlphaAuto", FFQ_ONEUI})
    public void mediaAlphaFlowMarriedWith2VehBw(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        randomizeApplicantPersonalData(applicant);
        // For specific test case purpose, setting relationship to applicant as "Other" for the additional driver to check if the PNI is passed/mapped as married.
        applicant.getAdditionalDrivers().get(0).setRelationshipToApplicant("Other");
        applicant.setLastName("Threeoabaa");
        applicant.getVehicles().remove(2); // remove 3rd vehicle
        MediaAlphaStartPage mediaAlphaStartPage = new MediaAlphaStartPage();

        mediaAlphaStartPage.processMediaAlphaStartPage(applicant.getZipCode(), AUTO);

        MediaAlphaPageAuto mediaAlphaPageHome = new MediaAlphaPageAuto();
        Assert.assertTrue(mediaAlphaPageHome.isOnMediaAlphaPageAuto(), "Did not reach Media Alpha Auto page.");
        mediaAlphaPageHome.enterAutoApplicantData(applicant);

        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        processAlphaMediaFlowInFfq(applicant, softAssert, false, true);
        String maritalStatus = mediaAlphaPageHome.getSessionStorageAppStore().getAuto().getDrivers().get(0).getMaritalStatus();
        // as we dont choose the add driver as sni in the partner flow, the marital status in the PNI should be S for the primary driver as per the discussion with media alpha team.
        softAssert.assertEquals(maritalStatus, "S", "Marital status should be S in the PNI for the primary driver.");
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"),
    		@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {"mediaAlphaAuto", FFQ_ONEUI})
    public void mediaAlphaFlowWith1Veh1Driver(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.setLastName("Brown");
        applicant.setContinuosInsurancePeriod("2 years");
        MediaAlphaStartPage mediaAlphaStartPage = new MediaAlphaStartPage();

        mediaAlphaStartPage.processMediaAlphaStartPage(applicant.getZipCode(), AUTO);

        MediaAlphaPageAuto mediaAlphaPageHome = new MediaAlphaPageAuto();
        Assert.assertTrue(mediaAlphaPageHome.isOnMediaAlphaPageAuto(), "Did not reach Media Alpha Auto page.");
        mediaAlphaPageHome.enterAutoApplicantData(applicant);

        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        processAlphaMediaFlowInFfq(applicant, softAssert, false, true);
        softAssert.assertAll();
    }

    /**
     * Retrieve quote for Bristol West flow * @param applicant
     *
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"),
    		@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {"mediaAlphaAuto", FFQ_ONEUI})
    public void validateRetrievalFromQuotePageForBWFlow(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        MediaAlphaStartPage mediaAlphaStartPage = new MediaAlphaStartPage();

        mediaAlphaStartPage.processMediaAlphaStartPage(applicant.getZipCode(), AUTO);

        MediaAlphaPageAuto mediaAlphaPageAuto = new MediaAlphaPageAuto();
        Assert.assertTrue(mediaAlphaPageAuto.isOnMediaAlphaPageAuto(), "Did not reach Media Alpha Auto page.");
        mediaAlphaPageAuto.enterAutoApplicantData(applicant);

        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        processAlphaMediaFlowInFfq(applicant, softAssert, false, false);

        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        quoteSummaryAutoPage.isOnQuoteSummaryAutoPage();
        String premiumBeforeRetrieval = quoteSummaryAutoPage.getPresentedPremiumAmount();
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, quoteSummaryAutoPage.getSessionStorageAppStore().getData().getQuoteNumber());

        softAssert.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote page after retrieval");
        String premiumAfterRetrieval = quoteSummaryAutoPage.getPresentedPremiumAmount();
        softAssert.assertEquals(premiumAfterRetrieval, premiumBeforeRetrieval, "Premium before and after retrieval are matching");
        softAssert.assertTrue(mediaAlphaPageAuto.isOnBristolWest(), "User should be on the BW page");
        softAssert.assertAll();
    }

    /**
     * Media Alpha quote with continuous coverage less than 6 months -Validation of Bristol West Quote (RC1 fail - Prefill Flow)
     *
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"),
    		@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {"mediaAlphaAuto", FFQ_ONEUI})
    public void mediaAlphaFlowWithLessThan6MonthToBW(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        updateLastNameForBristolWest(applicant);
        applicant.setContinuosInsurancePeriod("< 6 Months");
        MediaAlphaStartPage mediaAlphaStartPage = new MediaAlphaStartPage();

        mediaAlphaStartPage.processMediaAlphaStartPage(applicant.getZipCode(), AUTO);

        MediaAlphaPageAuto mediaAlphaPageAuto = new MediaAlphaPageAuto();
        Assert.assertTrue(mediaAlphaPageAuto.isOnMediaAlphaPageAuto(), "Did not reach Media Alpha Auto page.");
        mediaAlphaPageAuto.enterAutoApplicantData(applicant);

        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        processAlphaMediaFlowInFfq(applicant, softAssert, false, true);

        softAssert.assertTrue(mediaAlphaPageAuto.isOnBristolWest(), "User should be on the BW page");
        softAssert.assertAll();
    }

    /**
     * Validation of ADPF flow (State 1- PC) (get prefill- SkipADPF- True Flag)
     *
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"),
    		@CustomAttribute(name = INCLUDED_STATES, values = {AR})}, dataProviderClass = AutoDataProviders.class, groups = {"mediaAlphaAuto", FFQ_ONEUI})
    public void alphaMediaAdpfDataSkipAdpfValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.setFirstName("Adamar");
        applicant.setLastName("Millerar");
        applicant.setDateOfBirth("12/23/1984");
        applicant.setCity("Bella Vista");
        applicant.setResidentAddress("1 Chelsea Ln");
        applicant.setZipCode("72715");
        applicant.setContinuosInsurancePeriod("2 years");
        MediaAlphaStartPage mediaAlphaStartPage = new MediaAlphaStartPage();
        mediaAlphaStartPage.processMediaAlphaStartPage(applicant.getZipCode(), AUTO);

        MediaAlphaPageAuto mediaAlphaPageAuto = new MediaAlphaPageAuto();
        Assert.assertTrue(mediaAlphaPageAuto.isOnMediaAlphaPageAuto(), "Did not reach Media Alpha Auto page.");
        mediaAlphaPageAuto.enterAutoApplicantData(applicant);

        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        processAlphaMediaFlowInFfq(applicant, softAssert, true, false);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"),
    		@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {"mediaAlphaAuto", FFQ_ONEUI})
    public void validateUserIsNotAbleToMoveOnWithBlankContactDetailsOnRatePage(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.setContinuosInsurancePeriod("1 year");
        MediaAlphaStartPage mediaAlphaStartPage = new MediaAlphaStartPage();
        mediaAlphaStartPage.processMediaAlphaStartPage(applicant.getZipCode(), AUTO);

        MediaAlphaPageAuto mediaAlphaPageHome = new MediaAlphaPageAuto();
        Assert.assertTrue(mediaAlphaPageHome.isOnMediaAlphaPageAuto(), "Did not reach Media Alpha Auto page.");
        mediaAlphaPageHome.enterAutoApplicantData(applicant);
        FarmersSoftAssert softAssert = new FarmersSoftAssert();

        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        if (!quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            Log.info("Test is not valid if user is not on the quote summary page");
            return;
        }
        AppStore.Data data = quoteSummaryAutoPage.getSessionStorageAppStore().getData();
        AppStore.Data.CustomerData customerData = data.getCustomerData();

        Log.info("Retrieval data: " + customerData.getLastName() + COMMA + SPACE + customerData.getDateOfBirth() + COMMA + SPACE + data.getQuoteNumber() + COMMA + SPACE + data.getLandingZipCode());

        quoteSummaryAutoPage.validateBlankFieldsForMediaAlpha(applicant, softAssert);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=29"),
    		@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, LA, MS, NC, NJ, NV, OR, WA})}, dataProviderClass = AutoDataProviders.class, groups = {"mediaAlphaAuto", FFQ_ONEUI})
    public void mediaAlphaFlowMarriedWith2VehWithNoPriorInsurance(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.setLastName("Brown");
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        applicant.getVehicles().remove(2); // remove 3rd vehicle
        MediaAlphaStartPage mediaAlphaStartPage = new MediaAlphaStartPage();


        mediaAlphaStartPage.processMediaAlphaStartPage(applicant.getZipCode(), AUTO);

        MediaAlphaPageAuto mediaAlphaPageHome = new MediaAlphaPageAuto();
        Assert.assertTrue(mediaAlphaPageHome.isOnMediaAlphaPageAuto(), "Did not reach Media Alpha Auto page.");
        mediaAlphaPageHome.enterAutoApplicantData(applicant);

        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        processAlphaMediaFlowInFfq(applicant, softAssert, false, true);
        softAssert.assertAll();
    }

    /**
     * Validate Existing customer KO for partner flow
     *
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {"mediaAlphaAuto", FFQ_ONEUI})
    public void validateExistingCustomerKOForAlphaMedia(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.setContinuosInsurancePeriod("1 year");
        //set data for existing customer
        applicant.setZipCode("30135");
        applicant.setFirstName("Alyssa");
        applicant.setLastName("Brown");
        applicant.setDateOfBirth("08041984");
        applicant.setCity("Douglasville");
        applicant.setResidentAddress("5109 Central Church Rd");

        MediaAlphaStartPage mediaAlphaStartPage = new MediaAlphaStartPage();

        mediaAlphaStartPage.processMediaAlphaStartPage(applicant.getZipCode(), AUTO);

        MediaAlphaPageAuto mediaAlphaPageHome = new MediaAlphaPageAuto();
        Assert.assertTrue(mediaAlphaPageHome.isOnMediaAlphaPageAuto(), "Did not reach Media Alpha Auto page.");
        mediaAlphaPageHome.enterAutoApplicantData(applicant);
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        sleep(15);
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()) {
            continueWithBristolWestPage.continueWithBWPage(true);
            continueWithBristolWestPage.waitForSpinnerToBeGone();
        }

        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        if (nameAndDobPage.isOnNameAndDobPage()) {
            nameAndDobPage.clickContinueButton();
            AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
            softAssert.assertTrue(autoEnterAddressPage.isOnEnterAddressPage(), "user is on the address page");
            autoEnterAddressPage.clickAddressPageCtaButton();
        }
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        softAssert.assertTrue(knockoutInconveniencePage.verifyExistingCustomerKnockout(), "Existing customer validated");
        softAssert.assertAll();
    }


    private void processAlphaMediaFlowInFfq(AutoApplicant applicant, FarmersSoftAssert softAssert, boolean isAdpf, boolean doesProcessBindPages) throws Exception {
        // Personal info page
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()) {
            //FL always displays BW dialog, so click on Continue to BW and resume normal flow
            continueWithBristolWestPage.continueWithBWPage(true);
            continueWithBristolWestPage.waitForSpinnerToBeGone();
        }
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        boolean rc1Passed = quoteSummaryAutoPage.quickIsOnQuoteSummaryAutoPage();
        boolean rc1Failed = nameAndDobPage.quickIsOnNameAndDobPage();
        AppStore.Data data = nameAndDobPage.getSessionStorageAppStore().getData();
        String quoteNumber = data.getQuoteNumber();
        testStep("Quote number for this flow: " + quoteNumber);
        AppStore.Data.CustomerData customerData = data.getCustomerData();
        testStep("Retrieval Data: " + customerData.getLastName() + COMMA + SPACE + customerData.getDateOfBirth() + COMMA + SPACE + quoteNumber + COMMA + SPACE + data.getLandingZipCode());
        if (rc1Failed) {
        	if (nameAndDobPage.getTextFromElement(nameAndDobPage.getNameAndDobTitle()).contains("Welcome")) {
        		nameAndDobPage.arePrefilledValuesMatching(applicant, softAssert);
        	} else {
        		nameAndDobPage.validateDisclaimersOnMediaAlphaFlow(softAssert);
        	}
            nameAndDobPage.clickContinueButton();
            nameAndDobPage.waitForSpinnerToBeGone();
            // address page
            AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
            if(autoEnterAddressPage.isOnEnterAddressPage()) {
				autoEnterAddressPage.validatePrefillValues(applicant);
				autoEnterAddressPage.verifyDisclaimers(applicant.getStateCode(), softAssert);
				autoEnterAddressPage.clickAddressPageCtaButton();
			}
        } else if (rc1Passed) {
            quoteSummaryAutoPage.verifyCoveragesDisplayedAlphaMedia(softAssert);
            quoteSummaryAutoPage.validatePrefillValuesForMediaAlpha(applicant, softAssert);
            quoteSummaryAutoPage.validateDisclaimersInQuotePageWithAlphaMedia(softAssert);
            quoteSummaryAutoPage.clickAgreeAndSubmitButton();
        } else if (new PartnerPremiumDetailsPage().isOnPartnerPremiumDetailsPage()) {
    		nameAndDobPage.validateDisclaimersOnMediaAlphaFlow(softAssert);
    		quoteSummaryAutoPage.clickContinueButton();
        }
        navigateFromWhoShouldWeInsurePageToQuoteSummaryPage(applicant, softAssert, rc1Failed);
        if (isAdpf) {
            ADPFRequestPayload adpfCallPayload = new ApiHelper().getAdpfCallPayload(quoteNumber);
            softAssert.assertTrue(adpfCallPayload.getADPFRequestBean().isSkipADPF(), "SKIP ADPF Should be true");
        }

        if (applicant.getStateCode().equals(MI)) {
            quoteSummaryAutoPage.updateLiabilityBiOnly("$250,000/$500,000");
        }

        if (doesProcessBindPages) {
        	if (quoteSummaryAutoPage.quickIsOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(isAdpf)) {
        		completePurchase(PAY_IN_FULL, PaymentMethods.AMEX_CREDIT_CARD_1, !isAdpf, softAssert);
        	} else {
        		if (new KnockoutInconveniencePage().isQuoteKnockedOut()) {
        			softAssert.fail("Quote is knocked out, cannot proceed to bind");
				} else {
					softAssert.fail("User is not on the quote summary page, cannot proceed to bind");
				}
        	}
        }
    }

    private void navigateFromWhoShouldWeInsurePageToQuoteSummaryPage(AutoApplicant applicant, FarmersSoftAssert softAssert, boolean comingFromPersonalInfoPage) throws Exception {
    	AceAutoNavigationHelper autoNavigator = new AceAutoNavigationHelper();
    	WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
    	if (whoShouldWeInsurePage.isOnWhoShouldWeInsurePage()) {
        	autoNavigator.setResumeFromPage(whoShouldWeInsurePage.getClass().getSimpleName());
    	} else {
        	VehiclesDriversInfoPage vehiclesDriversInfoPage =  new VehiclesDriversInfoPage();
        	vehiclesDriversInfoPage.clickContinueButton();
        	vehiclesDriversInfoPage.waitForSpinnerToBeGone();
        	VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
            if (vehicleReviewPage.isOnVehiclesReviewPage()) {
            	vehicleReviewPage.clickOnContinueButton();
            	vehicleReviewPage.waitForSpinnerToBeGone();
                DriverReviewPage driverReviewPage = new DriverReviewPage();
                testStepAssert(driverReviewPage.isOnDriverReviewPage(), "User is on the driver review page", true);

                AppStore.Auto.Driver driver = driverReviewPage.getSessionStorageAppStore().getAuto().getDrivers().get(0);
                if (driver.getMaritalStatus().equals("M")) {
                    PWElement maritalCheckbox = driverReviewPage.getMaritalCheckbox(driver.getFirstName() + SPACE + driver.getLastName());
                    softAssert.assertTrue(driverReviewPage.getAttributeData(maritalCheckbox,CLASS).contains(MDC_CHECKBOX_SELECTED), "Marital status of the driver is married and the checkbox is checked");
                }
                driverReviewPage.fillOutDriverLicenseAges();
                driverReviewPage.fillOutDriverLicenseNumbers();
                driverReviewPage.fillOutOccupationAffinitySection();
                driverReviewPage.clickContinueButton();
            }
        	autoNavigator.setResumeFromPage(new SignalPageOneUI().getClass().getSimpleName());
    	}
    	autoNavigator.navigateToEitherQuoteSummaryPage(applicant);
    }
}
