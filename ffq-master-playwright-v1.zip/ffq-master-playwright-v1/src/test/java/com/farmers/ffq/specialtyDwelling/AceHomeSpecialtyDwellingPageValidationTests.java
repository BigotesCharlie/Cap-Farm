package com.farmers.ffq.specialtyDwelling;

import static com.farmers.ffq.utils.GlobalVariables.AZ;
import static com.farmers.ffq.utils.GlobalVariables.CA;
import static com.farmers.ffq.utils.GlobalVariables.EXCLUDED_STATES;
import static com.farmers.ffq.utils.GlobalVariables.GA;
import static com.farmers.ffq.utils.GlobalVariables.MO;
import static com.farmers.ffq.utils.GlobalVariables.PA;
import static com.farmers.ffq.utils.GlobalVariables.PARTTIME;
import static com.farmers.ffq.utils.GlobalVariables.REMOVE_SPECIALTY_REDSTATES;
import static com.farmers.ffq.utils.GlobalVariables.RENT;
import static com.farmers.ffq.utils.GlobalVariables.SHORTRENT_DWELLING;
import static com.farmers.ffq.utils.GlobalVariables.SPECIALTY_DWELLING;
import static com.farmers.ffq.utils.GlobalVariables.UNOCCUPIED;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.AutomationFramework;

public class AceHomeSpecialtyDwellingPageValidationTests extends AutomationFramework {

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING)}, groups = {SPECIALTY_DWELLING})
	public void verifyPropertyTypePageContent(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant).verifyDwellingTypePageContent(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES)}, groups = {SPECIALTY_DWELLING})
	public void verifyDwellingTellUsMorePageContent(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant).verifyTellUsMorePageContent(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES)}, groups = {SPECIALTY_DWELLING})
	public void verifyAdditionalDwellingInformationPageContent(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant).verifyAdditionalDwellingInformationPageContent(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, GA, MO, PA})}, groups = {SPECIALTY_DWELLING})
	public void verifyOtherPolicyQuestionsPageContent(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, PARTTIME).verifyOtherPolicyQuestionsPage(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, GA, MO, PA})}, groups = {SPECIALTY_DWELLING})
	public void verifyQuoteReviewPageContentParttime(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, PARTTIME).verifyQuoteReviewPage(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES)}, groups = {SPECIALTY_DWELLING})
	public void verifyQuoteReviewPageContentRenter(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, RENT).verifyQuoteReviewPage(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {SPECIALTY_DWELLING})
	public void verifyQuoteReviewPageContentShortRenter(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, SHORTRENT_DWELLING).verifyQuoteReviewPage(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES)}, groups = {SPECIALTY_DWELLING})
	public void verifyQuoteReviewPageContentVacant(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, UNOCCUPIED).verifyQuoteReviewPage(specialtyDwellingApplicant);
	}
}
