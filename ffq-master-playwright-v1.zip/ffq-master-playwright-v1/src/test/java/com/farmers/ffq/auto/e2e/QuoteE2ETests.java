package com.farmers.ffq.auto.e2e;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.Vehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import com.farmers.framework.saucelabs.SauceRest;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class QuoteE2ETests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, "QuoteE2ESelective"})
    public void validateQuoteFlowWithSelectiveData(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        getTheQuoteFlowUntilQuoteSummaryPage(applicant, applicant.getStateCode().equals(MS));
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE, dataProviderClass = AutoDataProviders.class,
    		attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, NC})}, groups = {FFQ_ACE_AUTO_E2E, QUOTE_E2E})
    public void validateQuoteE2E_RandomSingle_Applicant_From_Each_State(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        applicant.setAge(getRandomAge(applicant.getAge()));
        if(applicant.getStateCode().equals(WA)) {
            applicant.setLastName("Wilson");
        }
        applicant.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(applicant.getAge()));
        getTheQuoteFlowUntilAdditionalInfoPage(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, groups = {"partialRegression"})
    public void validateQuoteFlowWithReleaseStatesAllApplicants(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        getTheQuoteFlowUntilQuoteSummaryPage(applicant, applicant.getStateCode().equals(MS));
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE})
    public void validateQuoteFlowWithRandomSingleStateSingleApplicant(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        getTheQuoteFlowUntilQuoteSummaryPage(applicant, applicant.getStateCode().equals(MS));
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=29"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, MS, NV, TX})}, groups = {SMOKE_ACE, PRODUCTION_VALIDATION})
    public void validateQuoteFlowWithRandomSingleStateWithMoreThanOneVehiclesAndTwoDrivers(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        updatePersonalInfoForProd(applicant);
        getTheQuoteFlowUntilQuoteSummaryPage(applicant, applicant.getStateCode().equals(MS));
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_E2E})
    public void validateMultipleSimilarVehicles(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        List<Vehicle> listOfApplicantVehicles = applicant.getVehicles();
        Vehicle applicantVehicle = listOfApplicantVehicles.get(0);
        applicantVehicle.setUseVIN(false);
        applicantVehicle.setVehicleUsage("Personal");
        applicantVehicle.setRidesharing(false);
        listOfApplicantVehicles.add(applicantVehicle);
        listOfApplicantVehicles.add(applicantVehicle);
        applicant.setVehicles(listOfApplicantVehicles);
        getTheQuoteFlowUntilQuoteSummaryPage(applicant, applicant.getStateCode().equals(MS));
    }

    // prod validation
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, MS, NV, TX})}, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE,
            dataProviderClass = AutoDataProviders.class, groups = {PRODUCTION_VALIDATION})
    public void validateQuoteWithSingleVehSingleDriver(AutoApplicant applicant) throws Exception {
        //set the applicant details appropriate for prod
        updatePersonalInfoForProd(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        getTheQuoteFlowUntilQuoteSummaryPage(applicant, false);

    }


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=34"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, TX})}, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES,
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateLinksForAutoFlow(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if(aceAutoNavigationHelper.isProdEnvironment()) {
            //set the applicant details appropriate for prod
            updatePersonalInfoForProd(applicant);
        }
        //Set signal to yes
        applicant.getDiscounts().get(0).setSignalSignup(true);
        // avoid possible bw scenarios
        updateApplicantDataToAvoidPossibleBw(applicant);
        validateLinksForAllPages(applicant);
    }


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")},
    		dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, "agentFlow"})
    public void validateAgentQuoteFlow(AutoApplicant applicant) throws Exception {
    	getTheQuoteFlowUntilQuoteSummaryPage(applicant,true);
    }

    public QuoteSummaryAutoPage getTheQuoteFlowUntilQuoteSummaryPage(AutoApplicant applicant, boolean isAgentFlow) throws Exception {
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper(isAgentFlow? quoteFlow.AGENT : quoteFlow.DEFAULT).navigateToEitherQuoteSummaryPage(applicant);
        List<AppStore.KnockOut> knockOutList = quoteSummaryAutoPage.getSessionStorageAppStore().getKnockouts();
        if (!knockOutList.isEmpty()) {
            testStep(TEST_PASSED);
        } else {
            quoteSummaryAutoPage.closeQualtricsPopUp();
            testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User successfully landed on the quote summary page", true);
        }
        return quoteSummaryAutoPage;
    }

    /*
    Feature: F84424
    Scenario: S.No 543 from R9 Regression Suite.
    Scenario Description: To Validate JFMT should be the final page to show progress bar in ACE Auto
    */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MI, CO, OR, KY}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {FFQ_ONEUI})
    public void validateJFMTShouldBeFinalPageToShowProgressbarInAceAuto(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalInfoPolicyStartDateOneUI.validateProgressbar(fsa);
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        testStepAssert(consolidatedPaymentPage.isOnConsolidatedPaymentPage(),"Bind reached Consolidated Payment Page");
        consolidatedPaymentPage.validateProgressbar(fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CO, FL, MI, NJ, OR}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {FFQ_ONEUI})
    public void validateProgressbarShouldPresentInAllScreensTillJFMTPage(AutoApplicant applicant) throws Exception {
    	AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
    	aceAutoNavigationHelper.setProgressbarChecked(true);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = aceAutoNavigationHelper.navigateToAdditionalInfoPage(applicant);
        FarmersSoftAssert fsa = aceAutoNavigationHelper.getFsa();
        additionalInfoPolicyStartDateOneUI.validateProgressbar(fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {ACE_STABILITY})
    public void aceAutoEnvStabilityValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class,
    		attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, NC, NE}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {FFQ_ONEUI})
    public void autoBDQPhoneNumberTest(AutoApplicant applicant) throws Exception {
    	new AutoEnterAddressPage().setBDQEnabled(true);
    	switchTestToBDQIfNeeded(applicant);
    	AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper(quoteFlow.BDQ);
    	aceAutoNavigationHelper.setPhoneNumberChecked(true);
    	aceAutoNavigationHelper.navigateToAdditionalInfoPage(applicant);
    	FarmersSoftAssert fsa = aceAutoNavigationHelper.getFsa();
    	fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class,
    		attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, NC}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {FFQ_ONEUI})
    public void autoBWPhoneNumberTest(AutoApplicant applicant) throws Exception {
    	bwSpecificDataSetUp(applicant);
    	applicant.setLastName("Threeoabaa");
    	applicant.setCurrentlyInsuredStatus(EXPIRED);
    	AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
    	aceAutoNavigationHelper.setPhoneNumberChecked(true);
    	aceAutoNavigationHelper.navigateToAdditionalInfoPage(applicant);
    	FarmersSoftAssert fsa = aceAutoNavigationHelper.getFsa();
    	fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class,
       		attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {FFQ_ONEUI})
    public void autoFarmersPhoneNumberTest(AutoApplicant applicant) throws Exception {
    	if (applicant.getStateCode().equals(NC)) {
			applicant.setTestScenario(applicant.getTestScenario() + "FGS");
		}
    	AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
    	aceAutoNavigationHelper.setPhoneNumberChecked(true);
    	aceAutoNavigationHelper.navigateToAdditionalInfoPage(applicant);
    	FarmersSoftAssert fsa = aceAutoNavigationHelper.getFsa();
    	fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CO, FL, MI, NJ, OR}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {ACE_STABILITY})
    public void aceAutoEndToEndOneRandomApplicant(AutoApplicant applicant) throws Exception {
    	updateApplicantDataToAvoidPossibleBw(applicant);
    	applicant.setLastName("Brown");
    	new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
    }

    public void getTheQuoteFlowUntilAdditionalInfoPage(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.setRemoveQualtricsPopup(false);
        QuoteSummaryAutoPage quoteSummaryAutoPage =  aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        List<AppStore.KnockOut> knockOutList = quoteSummaryAutoPage.getSessionStorageAppStore().getKnockouts();
        if (!knockOutList.isEmpty()) {
            testStep(TEST_PASSED);
            testStep("SauceLabs links for the job => " + SauceRest.getPublicJobLink(), true);
            return;
        }
        // CA state is only quote / No Bind
        if (applicant.getStateCode().equals(CA)) {
            testStepAssert(Arrays.asList("Continue", "Continue with this quote").contains(quoteSummaryAutoPage.getStartCheckoutButtonText()), "Correct button text is displayed for CA state");
            return;
        }
        if (quoteSummaryAutoPage.isBristolWestQuote()) {
            return;
        }
        aceAutoNavigationHelper.setResumeFromPage(quoteSummaryAutoPage.getClass().getSimpleName());
        //  aceAutoNavigationHelper.navigateToPaymentSelectionPage(applicant);
        //  testStep(TEST_PASSED, true);
        //  testStep("SauceLabs links for the job => " + SauceRest.getPublicJobLink(), true);
    }

    private void validateLinksForAllPages(AutoApplicant applicant) throws Exception {
        NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);
        nameAndDobPage.validateLinks();
        nameAndDobPage.validatePrivacyPolicyLink();
        //fill out the name page
        nameAndDobPage.filloutApplicantForm(applicant);
        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        testStepAssert(autoEnterAddressPage.isOnEnterAddressPage(), "User is on the address page", true);
        autoEnterAddressPage.validateColorOfTheLinks();
        autoEnterAddressPage.fillOutAddressPage(applicant);
        InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
        if (interstitialBundlePage.isOnInterstitialBundlePage()) {
            interstitialBundlePage.continueWithAutoMonoLine();
        }
        boolean isStreamlineFlow = autoEnterAddressPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();

        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the who should we insure page", true);
        if(isStreamlineFlow) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
            vehiclesDriversInfoPage.validateColorOfTheLinks();
            vehiclesDriversInfoPage.clickContinueButton();
        } else {
            testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the who should we insure page", true);
            whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.enterEmailAndPhoneNumber(applicant);
            whoShouldWeInsurePage.validateColorOfTheLinks();
            whoShouldWeInsurePage.clickOnContinueButton();
        }

        if(!isStreamlineFlow) {
            VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
            testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on the vehicle review page", true);
            vehicleReviewPage.clickReviseVehiclesLink();
            testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the Who Should we Insure page after clicking Revise link from Vehicle review page");
            whoShouldWeInsurePage.clickContinueButton();
            testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on the vehicle review page after revise link click -second time", true);
            vehicleReviewPage.addVehicleDetails(applicant);
            whoShouldWeInsurePage.validateColorOfTheLinks();
            vehicleReviewPage.clickOnContinueButton();
            DriverReviewPage driverReviewPage = new DriverReviewPage();
            testStepAssert(driverReviewPage.isOnDriverReviewPage(), "User is on the driver review page");
            driverReviewPage.clickOnDriversRevisionHyperlink();
            testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the Who Should we Insure page after clicking Revise link from Drviers review page");
            whoShouldWeInsurePage.clickContinueButton();
            testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on the " + vehicleReviewPage.getClass().getSimpleName());
            vehicleReviewPage.clickContinueButton();
            testStepAssert(driverReviewPage.isOnDriverReviewPage(), "User is on the " + driverReviewPage.getClass().getSimpleName());
            driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
            driverReviewPage.validateColorOfTheLinks();
            driverReviewPage.clickContinueButton();
        }

        String stateCode = applicant.getStateCode();
        if (!autoEnterAddressPage.isSignalDiscountDisabledState(stateCode)) {
            SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
            testStepAssert(signalPageOneUI.isOnSignalPage(), "User is on the signal page", true);
            //signal page links validation
            signalPageOneUI.verifySignalPageLinks();
            signalPageOneUI.processSignalPage(true);
        }

        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        testStepAssert(contactInfoAutoPage.isOnContactInfoAutoPage(), "User is on the contact info page successfully");
        contactInfoAutoPage.validateColorOfTheLinks();
        contactInfoAutoPage.setValuesAndContinue(applicant);

        new VehicleDriverAssignmentPage().processVehiclesDriversAssignmentPageIfNeeded();
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if(bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            bwFarmersQuotePresentmentPage.continueWithFarmers();
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();;
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName(), true);
        quoteSummaryAutoPage.closeQualtricsPopUp();
        //validate email link
        quoteSummaryAutoPage.clickOnEmailLink();
        quoteSummaryAutoPage.waitForSpinnerToBeGone();
        testStepAssert(quoteSummaryAutoPage.isSnackBarMessageDisplayed(String.format("A copy of your quote number has been emailed to %s",
                applicant.getEmail())), "Email sent snackbar message diplayed");
        quoteSummaryAutoPage.clickGotItButton();
        quoteSummaryAutoPage.clickOnAlternativePaymentLink();
        quoteSummaryAutoPage.waitForSpinnerToBeGone();
        sleep(1);
        String presentedPremiumAmount = quoteSummaryAutoPage.getPresentedPremiumAmount();
        Log.info("Presented premium amount : " + presentedPremiumAmount);
        testStepAssertFalse(presentedPremiumAmount.contains("/mo"), "Premium amount should not show /mo after swithing to full pay option", true);

        //validate discount side sheet opens or not
        quoteSummaryAutoPage.getDisplayedDiscounts();

        quoteSummaryAutoPage.validateColorOfTheLinks();
        quoteSummaryAutoPage.clickOnStartCheckoutButton();

        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User is on the additional info page", true);

        AdditionalInfoSignalEnrollmentSectionOneUI signalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        // signal enrollment section no available for CA state or Bristol West flow, so skipping the validation for those scenarios
        if(!stateCode.equals(CA) && !additionalInfoPolicyStartDateOneUI.isOnBristolWest()){
            signalEnrollmentSectionOneUI.validateCancelSignalEnrollmentModal(stateCode, fsa);
            signalEnrollmentSectionOneUI.validateColorOfTheLinks();
            signalEnrollmentSectionOneUI.validateOpeningTermsOfUseInNewTab(fsa);
        }

        fsa.assertAll();
    }

}
