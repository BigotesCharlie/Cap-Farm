package com.farmers.ffq.api;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.Test;

import com.farmers.framework.AutomationFramework;
import com.farmers.framework.Property;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.api.Rest;
import com.farmers.framework.api.RestResponse;
import com.farmers.framework.report.Log;

public class TestServiceCalls extends AutomationFramework {
	private static final String SERVICE_CALL_RESULTS_FILE = System.getProperty(USER_DIR_PROPERTY) + "/build/serviceCall.log";
	private static final String ACCESS_DENIED = "Access Denied";
	private static final String COMMENTS = "comments";
	private static final String SERVICE_NAME = "serviceName";
	private static final String SERVICE_RESPONSE = "serviceRespose";
	private static final String STATUS = "status";
	private static final String SUCCESS = "SUCCESS";

	@Skip
	@Test(groups = {REGRESSION, SPOT_TESTING, AUTO_REDESIGN})
	public void serviceCallTest() throws Exception {
		if (Property.getTestProperty("environment").equals("RA11")) {
			try (Scanner in = new Scanner(new File(RATED_QUOTES_FILE)).useDelimiter(Pattern.compile("AUTO:"))) {
				writeStringToFile("**** BEGIN validateServiceCalls ****" + NEWLINE, SERVICE_CALL_RESULTS_FILE);
				while (in.hasNext()) {
					String quoteNumber = in.next().trim().substring(0, 10);
					if (quoteNumber.matches("\\d+")) {
						Rest r = new Rest();
						String endpoint = "https://ffqreg.farmers.com/validateServiceCalls";
						String json = "{\"quoteNumber\":\"" + quoteNumber + "\",\"serviceRequest\":[{\"serviceName\":\"AGENT_ASSIGNMENT\"},{\"serviceName\":\"ACXIOM\"}]}";
						RestResponse response = r.post(endpoint, json);
						String responseString = response.body().toString();
						if (responseString.contains(ACCESS_DENIED)) {
							sleep(2);
							response = r.post(endpoint, json);
							responseString = response.body().toString();
						}
						if (responseString.contains(ACCESS_DENIED)) {
							writeStringToFile("Access denied for quote [" + quoteNumber + "]" + NEWLINE, SERVICE_CALL_RESULTS_FILE);
						} else if (!responseString.contains(SUCCESS)) {
							try {
								JSONObject result = response.body();
								if (result.has(SERVICE_RESPONSE)) {
									JSONArray status = (JSONArray) result.get(SERVICE_RESPONSE);
									for (int service=0; service<status.length(); service++) {
										String serviceName = status.getJSONObject(service).getString(SERVICE_NAME);
										String callStatus = status.getJSONObject(service).getString(STATUS);
										String callComments = status.getJSONObject(service).getString(COMMENTS);					
										Log.info(serviceName + SPACE + quoteNumber + SPACE + callStatus + SPACE + callComments);
										writeStringToFile(serviceName + SPACE + quoteNumber + SPACE + callStatus + SPACE + callComments + NEWLINE, SERVICE_CALL_RESULTS_FILE);
									}
								} else {
									writeStringToFile(SERVICE_RESPONSE + " missing for [" + quoteNumber + "]:" + SPACE + responseString +  NEWLINE, SERVICE_CALL_RESULTS_FILE);
								}
							} catch (JSONException je) {
								Log.warn(je.getMessage());
							}
						}
					}
				}
				writeStringToFile("**** END validateServiceCalls ****" + NEWLINE, SERVICE_CALL_RESULTS_FILE);
			} catch (FileNotFoundException fnfe) {
				Log.warn(fnfe.getMessage());
			}
		}
	}

	private static void writeStringToFile(String stringToWrite, String filePath) {
		try {
			Files.write(Paths.get(filePath), stringToWrite.getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}
