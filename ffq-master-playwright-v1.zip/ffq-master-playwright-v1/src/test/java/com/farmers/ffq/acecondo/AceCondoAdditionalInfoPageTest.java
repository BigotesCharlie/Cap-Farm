package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoAdditionalInfoPage;
import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyDetailsBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoAdditionalInfoPageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ADDITIONAL_INFO_PAGE})
    public void validateAdditionalInfoPageContentCondoLob(ApplicantAceHome applicant) throws Exception {

        AceCondoAdditionalInfoPage additionalInfoPageAceCondo = new AceCondoNavigationHelper().navigateToAceCondoAdditionalInfoPage(applicant);
        String stateCode = applicant.getStateCode();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalInfoPageAceCondo.validateTheHeaderOfAdditionalInfoPage(fsa);
        boolean hasTemporaryRentalSection = !additionalInfoPageAceCondo.hasTemporaryRentalSectionOption(stateCode);
        if (hasTemporaryRentalSection) {
            additionalInfoPageAceCondo.validateContentOfTemporaryRentalSection(fsa);
        }
        additionalInfoPageAceCondo.validateDiscountHeadingAndDivider(fsa);

        if (List.of(KY, LA, MA, MS).contains(stateCode)) {
            additionalInfoPageAceCondo.validateNoCentralAlarmSections(fsa);
            if (stateCode.equals(KY)) {
                additionalInfoPageAceCondo.validateContentOfFireProtectionSection(fsa);
                additionalInfoPageAceCondo.fillOutFireSystemsInfo(applicant.getFireAlarm(), stateCode);
                additionalInfoPageAceCondo.fillOutSprinklerSystemsInfo(applicant.getSprinklerSystem());
            } else {
                additionalInfoPageAceCondo.validateContentOfFireAlarmSection(fsa);
                additionalInfoPageAceCondo.fillOutFireAlarmInfo(applicant.getFireAlarm());
            }
            additionalInfoPageAceCondo.validateContentOfBurglarAlarmSection(fsa);
            additionalInfoPageAceCondo.fillOutBurglarAlarmInfo(applicant.getBurglarAlarm());

            additionalInfoPageAceCondo.validateContentOfWaterLeakProtectionSection(fsa);
            additionalInfoPageAceCondo.fillOutWaterLeakProtectionInfo(applicant.getWaterLeakProtection());
        } else {
            if (stateCode.equals(NC)) {
                additionalInfoPageAceCondo.validateContentOfFireProtectionSection(fsa);
                additionalInfoPageAceCondo.fillOutFireSystemsInfo(applicant.getFireAlarm(), stateCode);
                additionalInfoPageAceCondo.fillOutSprinklerSystemsInfo(applicant.getSprinklerSystem());

                additionalInfoPageAceCondo.validateContentOfWaterLeakProtectionSection(fsa);
                additionalInfoPageAceCondo.fillOutWaterLeakProtectionInfo(applicant.getWaterLeakProtection());

                additionalInfoPageAceCondo.validateContentOfLocalFireAlarmSection(fsa);
                additionalInfoPageAceCondo.fillOutLocalFireAlarmInfo(applicant.isLocalFireAlarm());

                additionalInfoPageAceCondo.validateContentOfLocalBurglarAlarmSection(fsa);
                additionalInfoPageAceCondo.fillOutLocalBurglarAlarmInfo(applicant.isLocalBurglarAlarm());
            }
            additionalInfoPageAceCondo.validateContentOfCentralFireAlarmSection(fsa);
            additionalInfoPageAceCondo. fillOutCentralFireAlarmInfo(applicant.isCentralFireAlarm());

            additionalInfoPageAceCondo.validateContentOfCentralBurglarAlarmSection(fsa);
            additionalInfoPageAceCondo.fillOutCentralBurglarAlarmInfo(applicant.isCentralBurglarAlarm());
        }
        boolean isQuoteContentApplicable = additionalInfoPageAceCondo.isNewFlowEnabledState(stateCode);
        additionalInfoPageAceCondo.validateQuoteText(AceHRCBasePage.ADDITIONAL_INFO, applicant.getQuoteNumber(), fsa, isQuoteContentApplicable);
        additionalInfoPageAceCondo.validateAgentSection(fsa, AceHRCBasePage.ADDITIONAL_INFO, applicant.getAgentId(), CONDO);
        additionalInfoPageAceCondo.validateDiscounts(AceHRCBasePage.ADDITIONAL_INFO, applicant, CONDO, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDITIONAL_INFO_PAGE})
    public void validateFloorResidenceLocatedCondoLob(ApplicantAceHome applicantAceHome) throws Exception {
        applicantAceHome.setAddress("26072 Perdido Beach");
        applicantAceHome.setUnit("300E");
        applicantAceHome.setCity("Orange Beach");
        applicantAceHome.setZipCode("36561");

        AceCondoAdditionalInfoPage additionalInfoPage = new AceCondoNavigationHelper().navigateToAceCondoAdditionalInfoPage(applicantAceHome);
        testStepAssertTrue(additionalInfoPage.validateFloorResidenceIsLocatedOnSection(CONDO), "Floor residence is located section is displayed", true);
        testStep("End Of Test");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDITIONAL_INFO_PAGE})
    public void validateDataWhenNavigatedBackAndFrothToAdditionalInfoPageCondoLob(ApplicantAceHome applicant) throws Exception {
        AceCondoAdditionalInfoPage additionalInfoPage = new AceCondoNavigationHelper().navigateToAceCondoAdditionalInfoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        Assert.assertTrue(additionalInfoPage.isOnAdditionalInfoPage(), "Additional Info page is reached");
        additionalInfoPage.fillOutAdditionalInfoPageCondo(applicant,false);
        additionalInfoPage.navigateBack();

        AceHRCPropertyDetailsBasePage propertyDetailsBasePage = new AceHRCPropertyDetailsBasePage();
        Assert.assertTrue(propertyDetailsBasePage.isOnPropertyDetailsPage(), "Properties details page is reached");
        propertyDetailsBasePage.clickContinueButton();

        additionalInfoPage = new AceCondoAdditionalInfoPage();
        Assert.assertTrue(additionalInfoPage.isOnAdditionalInfoPage(), "Additional Info page is reached");
        additionalInfoPage.validateDataNotSavedCondo(applicant, fsa);
        Log.info("Data is not saved when navigate back from addition info page without clicking continue button.", true);

        // Forward navigation from Additional Info page and coming back to the page again and validating the prefilled data.
        additionalInfoPage.fillOutAdditionalInfoPageCondo(applicant,true);
        additionalInfoPage.waitForSpinnerToBeGone();
        additionalInfoPage.navigateBack();
        additionalInfoPage.validateAdditionalInfoSelections(applicant, fsa);
        Log.info("Data is prefilled on Additional Info page when navigate back from About you page by clicking the browser back button.", true);

        // Backward navigation from Additional Info page and coming back to the page again and validating the prefilled data.
        additionalInfoPage.navigateBack();
        Assert.assertTrue(propertyDetailsBasePage.isOnPropertyDetailsPage(), "Properties details page is reached");
        propertyDetailsBasePage.clickContinueButton();
        additionalInfoPage.waitForSpinnerToBeGone();
        additionalInfoPage.validateAdditionalInfoSelections(applicant, fsa);
        Log.info("Data is prefilled on Additional Info page when navigate back to and clicked clicking continue button from Property details page.", true);

        fsa.assertAll("Additional info page Condo - Data is not saved");
    }
}
