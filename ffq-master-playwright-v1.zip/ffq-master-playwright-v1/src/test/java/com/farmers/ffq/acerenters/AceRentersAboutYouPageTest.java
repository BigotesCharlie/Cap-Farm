package com.farmers.ffq.acerenters;

import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCContactInfoBasePage;
import com.farmers.ffq.ace.renters.AceRentersAboutYouPage;
import com.farmers.ffq.ace.renters.AceRentersAddressPage;
import com.farmers.ffq.ace.renters.AceRentersNavigationHelper;
import com.farmers.ffq.ace.renters.AceRentersReviewQuotePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.ABOUT_YOU;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersAboutYouPageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE})
    public void pageContentValidationAboutYouPageRentersLob(ApplicantAceHome applicant) throws Exception {
        AceRentersAboutYouPage aboutYouPage = new AceRentersNavigationHelper().navigateToAceRentersAboutYouPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        //validate content for primary applicant
        aboutYouPage.validateContentOfPrimaryApplicant(fsa, applicant.getStateCode(), RENTERS);

        // validate content in spouse section
        aboutYouPage.clickOnMarriedOrInDomesticRelationCheckbox();
        aboutYouPage.validateMarriedOrInDomesticRelationCheckBoxDescription(fsa);
        aboutYouPage.validateContentOfSpouseApplicant(fsa, applicant.getStateCode(), RENTERS);

        // validate contact info section
        aboutYouPage.validateContentOfContactInfoRenters(fsa);

        // validate disclaimer section
        aboutYouPage.validateDisclaimerOnContactInfoPage(fsa);
        (new AceHRCContactInfoBasePage()).validateDisclaimerFooterLinks(fsa, RENTERS);

        // validate Agree and submit button
        aboutYouPage.validateAgreeAndSubmitButton(fsa);

        // validate discount
        aboutYouPage.validateDiscounts(AceHRCBasePage.ABOUT_YOU, applicant, RENTERS, fsa);

        aboutYouPage.validateAgentSection(fsa, ABOUT_YOU, applicant.getAgentId(), RENTERS);
        aboutYouPage.validateQuoteText(ABOUT_YOU, applicant.getQuoteNumber(), fsa, false);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE})
    public void validateErrorMessagesAboutYouPageRentersLob(ApplicantAceHome applicantAceHome) throws Exception {
        AceRentersAboutYouPage aboutYouPageAceRenters = new AceRentersNavigationHelper().navigateToAceRentersAboutYouPage(applicantAceHome);
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        //attempting to skip field entering
        aboutYouPageAceRenters.fillOutApplicantFormWithNoInput();
        aboutYouPageAceRenters.validateErrorMessageForNoInput(true, applicantAceHome, fsa);

        // validate error message for incorrect input
        aboutYouPageAceRenters.fillOutApplicantFormWithIncorrectInput(true);
        aboutYouPageAceRenters.validateErrorMessageForInvalidInput(true,applicantAceHome, fsa);

        // validate is age<=15 and age>=99 & Date of Birth is a valid entry
        aboutYouPageAceRenters.validateInvalidErrorMessagesForAgeLimitAndDob(fsa, applicantAceHome, true);
        driver().navigate().refresh();

        //validate First/Last name char limit - 15 char and 20 char max respectively
        aboutYouPageAceRenters.fillOutApplicantFormWithValues("MoreThanFifteenChars","MoreThanTwentyCharacters", "09/09/1600" );
        aboutYouPageAceRenters.validateCharacterLimitForFirstNameLastName(fsa);
        driver().navigate().refresh();

        //Not allowed special chars and numeric chars in First name and last name field
        aboutYouPageAceRenters.validateNotAllowedSpecialCharsInFirstLastName(fsa);
        driver().navigate().refresh();
        aboutYouPageAceRenters.validateNotAllowedNumericInFirstLastName(fsa);

        //Not allowed special chars in DOB and spouse's DOB field
        aboutYouPageAceRenters.validateNotAllowedSpecialCharInDOB(fsa);
        aboutYouPageAceRenters.selectGender(applicantAceHome);

        // check the spouse checkbox in order to validate errors in spouse section
        aboutYouPageAceRenters.clickOnMarriedOrInDomesticRelationCheckbox();
        aboutYouPageAceRenters.fillOutApplicantFormWithValues(applicantAceHome.getFirstName(), applicantAceHome.getLastName(), applicantAceHome.getDateOfBirth());

        // validate error messages when no input is provided
        aboutYouPageAceRenters.fillOutApplicantFormWithNoInput();
        aboutYouPageAceRenters.validateErrorMessageForNoInput(false,applicantAceHome, fsa);
        aboutYouPageAceRenters.validateRequiredIncompleteFieldErrorMessage(fsa);

        aboutYouPageAceRenters.fillOutApplicantFormWithIncorrectInput(false);
        aboutYouPageAceRenters.validateErrorMessageForInvalidInput(false, applicantAceHome, fsa);

        //validate First/Last name char limit - 15 char and 20 char max respectively
        aboutYouPageAceRenters.fillOutSpouseApplicantFormWithValues("MoreThanFifteenChars","MoreThanTwentyCharacters", "09/09/1600" );
        aboutYouPageAceRenters.validateCharLimitFirstLastNameSpouse(fsa);

        // invalidate condition is age<=15 and age>=99 & Date of Birth is a valid entry
        aboutYouPageAceRenters.validateInvalidErrorMessagesForAgeLimitAndDob(fsa, applicantAceHome, false);

        //basePageAboutYouAceHome.clickOnMarriedOrInDomesticRelationCheckbox();
        //Not allowed special chars and numeric chars in Spouse's First name and Spouse's last name field
        aboutYouPageAceRenters.validateNotAllowedSpecialCharsInFirstLastNameSpouse(fsa);
        driver().navigate().refresh();
        aboutYouPageAceRenters.validateNotAllowedNumericInFirstLastNameSpouse(fsa);

        //Not allowed special chars in DOB and spouse's DOB field
        aboutYouPageAceRenters.validateNotAllowedSpecialCharInDOBSpouse(fsa);

        // validate email address and phone number inputs
        aboutYouPageAceRenters.validateEmailAddressAndPhoneNumberInput(fsa);

        fsa.assertAll("About you page Renters - validate error messages.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE})
    public void enteredDetailsRetainedWhenNavigatedBackAndForthAboutYouPageRentersLob(ApplicantAceHome applicant) throws Exception {
        // Navigate to the "About You" page for renters
        AceRentersAboutYouPage aceRentersAboutYouPage = new AceRentersNavigationHelper().navigateToAceRentersAboutYouPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        // Fill out the "About You" page with applicant data and click "Continue"
        aceRentersAboutYouPage.fillOutTheDataInAboutYouPageRenters(applicant, true);

        // Wait for the spinner to disappear after clicking "Continue"
        aceRentersAboutYouPage.waitForSpinnerToBeGone();

        // Navigate back to the "About You" page
        aceRentersAboutYouPage.navigateBack();

        // Validate that the entered details are retained on the "About You" page
        aceRentersAboutYouPage.validateAboutYouSelections(applicant, false, fsa);

        // Assert all validations
        fsa.assertAll("About You page - Data is saved when navigated back and forth from the page.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE})
    public void testDataNotSavedWhenNavigatedBackAboutYouPageRentersLob(ApplicantAceHome applicant) throws Exception {
        // Navigate to the "About You" page for renters
        AceRentersAboutYouPage aboutYouPageAceRenters = new AceRentersNavigationHelper().navigateToAceRentersAboutYouPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();

        // Verify that the "About You" page is displayed
        AceRentersAboutYouPage aceRentersAboutYouPage = new AceRentersAboutYouPage();
        Assert.assertTrue(aceRentersAboutYouPage.isOnAboutYouPage(true), "About You page is reached");

        // Fill out the "About You" page with applicant data without clicking "Continue"
        aceRentersAboutYouPage.fillOutTheDataInAboutYouPageRenters(applicant, false);

        // Navigate back from the "About You" page
        aboutYouPageAceRenters.navigateBack();

        // Verify that the "Address" page is displayed
        AceRentersAddressPage addressPage = new AceRentersAddressPage();
        Assert.assertTrue(addressPage.isOnAddressPageRenters(false), "Address page is reached");

        // Click "Continue" on the "Address" page
        addressPage.clickContinueButton();

        // Navigate back to the "About You" page
        aceRentersAboutYouPage = new AceRentersAboutYouPage();
        Assert.assertTrue(aceRentersAboutYouPage.isOnAboutYouPage(true), "About You page is reached");

        // Validate that the data entered earlier is not retained on the "About You" page
        aceRentersAboutYouPage.validateDataNotSaved(applicant, fsa);

        // Assert all validations
        fsa.assertAll("About You page - Data not saved when navigated back from the page.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_ABOUT_YOU_PAGE})
    public void validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageRentersLob(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        // Create an instance of the "About You" page
        AceRentersAboutYouPage aboutYouPage = new AceRentersAboutYouPage();

        // Navigate to the "Review quote" page for renters
        AceRentersReviewQuotePage reviewQuotePage = new AceRentersNavigationHelper().navigateToAceRentersReviewQuotePage(applicant);

        // Attempt to navigate back to the "About You" page from the "Review quote" page
        int i = 5; // Maximum number of attempts
        do {
            reviewQuotePage.navigateBack(); // Navigate back
            i--;
        } while (!aboutYouPage.isOnAboutYouPageRenters(false) && (i > 0)); // Check if the "About You" page is reached

        aboutYouPage = new AceRentersAboutYouPage();

        // Validate that the fields on the "About You" page are not editable when the quote is rated
        aboutYouPage.validateAboutYouSelections(applicant, true, fsa);

        // Assert all validations
        fsa.assertAll("About You page - Data is not editable when quote is rated - Renters");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {PEWC})
    public void aceRentersPEWCScreen(ApplicantAceHome applicantAceHome) throws Exception {
    	AceRentersAboutYouPage aboutYouPage = new AceRentersNavigationHelper().navigateToAceRentersAboutYouPage(applicantAceHome);
    	aboutYouPage.capturePEWC("AceRenters_AboutYouPage");
        testStep("End Of Test");
    }
}
