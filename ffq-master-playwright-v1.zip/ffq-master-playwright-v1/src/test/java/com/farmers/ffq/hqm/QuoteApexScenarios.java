package com.farmers.ffq.hqm;

import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.hqm.ApexHQM;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.hqm.pages.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.Property;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Quote Scenarios - Home Quote Modernization (HQM).
 */
public class QuoteApexScenarios extends AutomationFramework {

    String resultsOut = System.getProperty("user.dir") + "/" +
            Property.getReportProperties("archiveOutputDir").split("/")[0] + "/HQMApexTestData_" +
            LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"))+".xlsx";

    @Test(dataProvider = DataProviders.APEX_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_APEX_TEST, HQM_ALL})
    public void hqmApexNewQuote(ApexHQM applicant) throws Exception {
        createNewHqmQuote(applicant);
    }

    @Skip
    @Test(dataProvider = DataProviders.APEX_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_APEX_TEST, HQM_ALL})
    public void oneApexHqmNewQuote(ApexHQM applicant) throws Exception {
        createNewHqmQuote(applicant);
    }

    private void createNewHqmQuote(ApexHQM apexHQM) throws Exception {
        ApplicantHQM applicant = new ApplicantHQM(apexHQM);
//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, DESKTOP_BROWSER);
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        apexHQM.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.setRequiredFields(applicant);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        propertyPage.setRequiredFields(applicant, fsa, null);
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        qualityPage.selectQualityGrade(applicant, null);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, null);
        if (apexHQM.isKnockOutScenario) {
            propertyDetailsPage.selectRoofCover("Metal - Copper Shingle");
        }
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        discountsPage.setRequiredFields(applicant);
        if (!apexHQM.isIncompleteQuoteScenario) {
            discountsPage.clickNext();
        }

        if (!apexHQM.isKnockOutScenario && !apexHQM.isIncompleteQuoteScenario) {
            if (apexHQM.isRerateScenario) {
                reRateQuote(false);
            } else if (apexHQM.isMultiRerateScenario) {
                reRateQuote(false);
                reRateQuote(true);
            } else if (apexHQM.isCustomRateScenario) {
                customRateQuote(apexHQM, false);
            } else if (apexHQM.isMultiCustomRateScenario) {
                customRateQuote(apexHQM, false);
                customRateQuote(apexHQM, false);
            } else if (apexHQM.isResetRateScenario) {
                customRateQuote(apexHQM, true);
            }
            QuotePage quotePage = new QuotePage();
            apexHQM.premium = quotePage.getQuotePremiumMonthly() + "/mo   "
                    + quotePage.getQuotePremiumYearly(applicant.stateCode) + "/yr";

        }
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = DataProviders.APEX_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_ALL})
    public void tempTest(ApexHQM apexHQM) throws Exception {
        if (apexHQM.id == 1) {
            apexHQM.quoteNumber = "1234567891";
            apexHQM.premium = "$175.00/mo  $2100.00/yr";
        } else if (apexHQM.id == 2) {
            apexHQM.quoteNumber = "1234567892";
            apexHQM.premium = "$185.00/mo  $2220.00/yr";
        } else if (apexHQM.id == 3) {
            apexHQM.quoteNumber = "1234567893";
            apexHQM.premium = "$195.00/mo  $2340.00/yr";
        }
        writeApplicantHQM(apexHQM);
    }

    private void reRateQuote(boolean multi) throws Exception {
        QuotePage quotePage = new QuotePage();
        quotePage.clickBack();
        HqmBasePage basePage = new HqmBasePage();  // Discounts page
        basePage.clickBack();
        basePage = new HqmBasePage(); // Contact Info page
        basePage.clickBack();
        basePage = new HqmBasePage(); // Customer Info page
        basePage.clickBack();
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        String numberOfStories = propertyDetailsPage.getSelectedNumberOfStories();
        List<String> listNumberOfStories = propertyDetailsPage.getAvailableNumberOfStories();
        listNumberOfStories.remove(numberOfStories);
        if (multi) {
            propertyDetailsPage.selectNumberOfStories(listNumberOfStories.get(listNumberOfStories.size() - 1));
        } else {
            propertyDetailsPage.selectNumberOfStories(listNumberOfStories.get(0));
        }
        propertyDetailsPage.clickNext();

        CustomerInfoPage customerInfoPage = new CustomerInfoPage(); // Customer Info page
        customerInfoPage.clickNext();

        ContactInfoPage contactInfoPage = new ContactInfoPage(); // Contact Info page
        contactInfoPage.clickAgreeSubmitButton();

        DiscountsPage discountsPage = new DiscountsPage(); // Discounts page
        discountsPage.clickNext();
    }

    private void customRateQuote(ApexHQM apexHQM, boolean isResetRate) throws Exception {
        QuotePage quotePage = new QuotePage();
        quotePage.clickQuoteDetails();

        QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
        quoteDetailsPage.customRateRecalculate(apexHQM.stateCode);
        quoteDetailsPage.clickCloseModal();

        if (isResetRate) {
            quotePage = new QuotePage();
            quotePage.clickQuoteDetails();
            quoteDetailsPage = new QuoteDetailsPage();
            quoteDetailsPage.clickReset();
            quoteDetailsPage.clickCloseModal();
        }
    }


    private void writeApplicantHQM(ApexHQM applicant) throws Exception {
        List<String> fields = new ArrayList<>();
        for (Field element: applicant.getClass().getFields()) {
            String name = element.getName();
            if (!name.equals("isKnockOutScenario")) {
                fields.add(name);
            } else {
                break;
            }
        }
        //Create a workbook
        XSSFWorkbook workbook;
        try {
            FileInputStream inputStream = new FileInputStream(resultsOut);
            workbook = new XSSFWorkbook(inputStream);
        } catch (FileNotFoundException e) {
            workbook = new XSSFWorkbook();
        }

        // Create a Sheet
        XSSFSheet sheet = workbook.getSheet("ApexHQM");
        if (sheet == null) {
            sheet = workbook.createSheet("ApexHQM");
            Row row = sheet.createRow(0); // add header row
            for(int i = 0; i < fields.size(); i++) {
                row.createCell(i).setCellValue(fields.get(i));
            }
        }

        Class<ApexHQM> aClass = ApexHQM.class;
        Row row = sheet.createRow(sheet.getLastRowNum() + 1);
        for(int i = 0; i < fields.size(); i++) {
            Field field = aClass.getField(fields.get(i));
            String val = field.get(applicant).toString();
            row.createCell(i).setCellValue(val);
            sheet.autoSizeColumn(i);
        }

        // Write the output to a file
        Log.info("resultsOut: " + resultsOut);
        File file = new File(resultsOut);
        file.getParentFile().mkdirs();
        file.createNewFile();
        FileOutputStream fileOutput = new FileOutputStream(file);
        workbook.write(fileOutput);
        fileOutput.close();

        // Closing the workbook
        workbook.close();
    }


}



