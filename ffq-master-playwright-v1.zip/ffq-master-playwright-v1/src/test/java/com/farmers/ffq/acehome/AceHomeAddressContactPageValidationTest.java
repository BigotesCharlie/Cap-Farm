package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.common.pages.FGIALandingPage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage.DID_NOT_REACH;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeAddressContactPageValidationTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDRESS_PAGE})
    public void testAddressContactPageHome(ApplicantAceHome applicant) throws Exception {
        AceHRCAddressContactBasePage addressContactPage = new AceHomeNavigationHelper().navigateToAceHomeAddressContactBasePage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        addressContactPage.validateQuoteSourceInd(fsa, applicant, HOME, ADDRESS_PAGE);
        addressContactPage.validatePageTitlesFooters(fsa, applicant);
        addressContactPage.validateAgentSection(fsa, AceHRCBasePage.ADDRESS_CONTACT_PAGE, applicant.getAgentId(), HOME);
        addressContactPage.validateQuoteText(AceHRCBasePage.ADDRESS_CONTACT_PAGE, applicant.getQuoteNumber(), fsa, false);
        addressContactPage.validatePageLinksText(fsa, ENTER_INFO);
        addressContactPage.validatePageFormFields(fsa);
        addressContactPage.validatePageErrors(fsa, applicant);
        addressContactPage.validatePageLinksNavigationTitles(fsa);
        addressContactPage.enterContactInfo(applicant);
        addressContactPage.waitForSpinnerToBeGone();
        addressContactPage.validateAddressContactPageFieldsMatchInput(applicant, fsa);
        addressContactPage.clickAgreeAndSubmit();
        addressContactPage.waitForSpinnerToBeGone();
        addressContactPage.navigateBack();
        AceHRCNameAndDobBasePage nameAndDobPage = new AceHRCNameAndDobBasePage();
        Assert.assertTrue(nameAndDobPage.isOnNameAndDobPage(false), DID_NOT_REACH + AceHRCBasePage.NAME_AND_DOB_PAGE);
        nameAndDobPage.validateNameAndDobPrimaryApplicant(fsa, applicant);
        nameAndDobPage.clickAgreeButton();
        Assert.assertTrue(addressContactPage.isOnAddressContactPage(false), DID_NOT_REACH + AceHRCBasePage.ADDRESS_CONTACT_PAGE);
        addressContactPage.validateAddressContactPageFieldsMatchInput(applicant, fsa);
        fsa.assertAll("Validate Ace Home - Address Contact page.");
    }

    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_BINDABLE_CHOICE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})
    public void validateFWSInterstitialToBindableChoiceIntegrationHome(ApplicantAceHome applicant) throws Exception {

        applicant.setAgentId(EMPTY_STRING);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCAddressContactBasePage addressContactPage = new AceHomeNavigationHelper().navigateToAceHomeAddressContactBasePage(applicant);
        addressContactPage.fillOutAddressContactPage(applicant);
        addressContactPage.waitForSpinnerToBeGone();
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        Assert.assertTrue(fwsInterstitialPage.isOnFarmersChoiceInterstitialPage(), "User did not navigate to FWS Interstitial - Farmers choice page");
        driver().navigate().refresh(); //F96276
        fwsInterstitialPage.validateFwsFarmersChoicePage(fsa, HOME);
        fwsInterstitialPage.clickOnApplyDiscountButton();
        fwsInterstitialPage.validateFWSInterstitialDialogContent(fsa);
        fwsInterstitialPage.clickOnDialogContainerAgreeButton();
        fwsInterstitialPage.waitForSpinnerToBeGone();
        Assert.assertTrue(fwsInterstitialPage.isOnBindableChoicePage(20), "User did not navigate to Bindable Choice page after clicking on Apply Discount button from FWS Interstitial page");
        fwsInterstitialPage.validateSelectedInsuranceType(fsa, HOME);
        fsa.assertAll("Validate FWS Interstitial to Bindable Choice Integration from Address Contact Info page - Home LOB.");
    }

    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_COLP, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})
    public void validateFWSInterstitialColpPageHome(ApplicantAceHome applicant) throws Exception {

        applicant.setAgentId(EMPTY_STRING);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCAddressContactBasePage addressContactPage = new AceHomeNavigationHelper().navigateToAceHomeAddressContactBasePage(applicant);
        addressContactPage.fillOutAddressContactPage(applicant);
        addressContactPage.waitForSpinnerToBeGone();
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        Assert.assertTrue(fwsInterstitialPage.isOnColpInterstitialPage(), "User did not navigate to FWS Interstitial - Colp page");
        driver().navigate().refresh(); //F96276
        fwsInterstitialPage.validateFwsColpPage(fsa, HOME);
        fsa.assertAll("Validate FWS Interstitial COLP page content from Address Contact Info page - Home LOB.");
    }

    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_QNB, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE})
    public void validateFWSInterstitialQnBPageHome(ApplicantAceHome applicant) throws Exception {

        applicant.setAgentId(EMPTY_STRING);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCAddressContactBasePage addressContactPage = new AceHomeNavigationHelper().navigateToAceHomeAddressContactBasePage(applicant);
        addressContactPage.fillOutAddressContactPage(applicant);
        addressContactPage.waitForSpinnerToBeGone();
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        Assert.assertTrue(fwsInterstitialPage.isOnQnBInterstitialPage(), "User did not navigate to FWS Interstitial - QnB page");
        driver().navigate().refresh(); //F96276
        fwsInterstitialPage.validateFwsQnBPage(fsa);
        fwsInterstitialPage.clickOnGetMyQuoteButton();
        fwsInterstitialPage.waitForSpinnerToBeGone();
        Assert.assertTrue(fwsInterstitialPage.isOnQnBSite(), "User did not land on QnB site after clicking on Get My Quote button from FWS Interstitial page - Home LOB");
        fwsInterstitialPage.validateQnBUrl(fsa);
        fsa.assertAll("Validate FWS Interstitial QnB page content from Address Contact Info page - Home LOB.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {MA, NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})
    public void testFGIANotOfferingValidationHomeLob(ApplicantAceHome applicant) throws Exception {
        applicant.setAgentId(null);
        AceHRCNavigationHelperBasePage aceHRCNavigationHelperBasePage = new AceHRCNavigationHelperBasePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        FGIALandingPage fgiaLandingPage = new FGIALandingPage();
        aceHRCNavigationHelperBasePage.processLandingPage(applicant, LOB_HOME);
        fgiaLandingPage.validateContentOfFGIAPopUp(fsa, HOME);
        if (fgiaLandingPage.isFgiaNoThanksButtonDisplayed()) {
            fgiaLandingPage.clickNoThanksButtonInFGIAPopUp();
            fgiaLandingPage.weAreNotAbleToCompleteQuotePageValidation(fsa, HOME);
        }
        fsa.assertAll("FGIA - Not offering validation Home");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {MA, NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})
    public void testFGIALandingPageValidationHomeLob(ApplicantAceHome applicant) throws Exception {
        applicant.setAgentId(null);
        AceHRCNavigationHelperBasePage aceHRCNavigationHelperBasePage = new AceHRCNavigationHelperBasePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        FGIALandingPage fgiaLandingPage = new FGIALandingPage();
        aceHRCNavigationHelperBasePage.processLandingPage(applicant, LOB_HOME);
        fgiaLandingPage.validateContentOfFGIAPopUp(fsa, HOME);
        fgiaLandingPage.clickContinueButtonInFGIAPopUp();
        fgiaLandingPage.fgiaIntroPageValidation(fsa, HOME);
        fsa.assertAll("FGIA - intro page validation Home");
    }

    /*
    Feature no - F88827 (Digital Monetization)
    */
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
        suiteName = AceHomeDataProviders.CATEGORY_DIGITAL_MONETIZATION_NON_AWS, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {NJ, DC, DE, HI, ME, NH, RI, VT, WV, NY})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})
    public void testDigitalMonetizationValidationNonAWSHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCNavigationHelperBasePage aceHRCNavigationHelperBasePage = new AceHRCNavigationHelperBasePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceHRCNavigationHelperBasePage.processLandingPage(applicant, LOB_HOME);
        FGIALandingPage fgiaLandingPage = new FGIALandingPage();
        if (aceHRCNavigationHelperBasePage.isQnBState(applicant.getStateCode())) { // F103049 - US1140591 - QnB Redirection for Home LOB
            AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
            Assert.assertTrue(fwsInterstitialPage.isOnQnBSite(), "User did not navigate to QnB portal - Home LOB");
            fwsInterstitialPage.validateQnBUrl(fsa);
        } else if(applicant.getStateCode().equals(NY)){
            fgiaLandingPage.validateContentOfFGIAPopUp(fsa, HOME);
        } else {
            AceHRCCallForQuotePage callForQuotePage = new AceHRCCallForQuotePage();
            callForQuotePage.validateCallForQuotePageElements(fsa, EMPTY_STRING);
        }
        fsa.assertAll("Digital monetization - Call for Quote page validation - " + HOME);
    }
}

