package com.farmers.ffq.auto.bind;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;

import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoDriverSectionOneUI;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.datatransferobjects.AppStore;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class BindOneUIDriverSectionValidationTest extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, FFQ_BIND_JFMT_PAGE}, enabled = false)
    public void bindOneUIAutoQuoteAdditionalInfoDriverSection(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateApplicantDataToAvoidPossibleBw(applicant);
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);

        additionalInfoPolicyStartDateOneUI.verifyAdditionalInfoHeader(fsa);
        AppStore retrieveQuoteResponseSessionStorage = additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore();
        AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
        additionalInfoDriverSectionOneUI.verifyDriverSection(retrieveQuoteResponseSessionStorage, fsa);
        additionalInfoDriverSectionOneUI.logInfoMessage(retrieveQuoteResponseSessionStorage.getData().getQuoteNumber());
        fsa.assertAll();
        driver().quit();
    }

}
