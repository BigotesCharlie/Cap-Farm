package com.farmers.ffq.auto.bind;

import com.farmers.ffq.BaseTest;

import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.common.pages.PolicyBankPayment;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;
import com.farmers.framework.annotation.Skip;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.common.pages.PolicyBankPayment.NO_SERVICE_CHARGE_WHEN_USING_BANK;
import static com.farmers.ffq.utils.GlobalVariables.*;
import static com.farmers.ffq.utils.PaymentMethods.DISCOVER_CREDIT_CARD_1;

public class BindOneUIAutoPolicyCreditDebitPaymentTest extends BaseTest {

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_DEBITCREDITPAYMENT_PAGE}, enabled = false)
    public void payInFullCreditCardToBankPaymentMethodChange(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoContinueToPaymentOneUI.waitForSpinnerToBeGone();
        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentPayInFull();

        PolicyBankPayment policyBankPayment = new PolicyBankPayment();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        autoPolicyPaymentBasePage.clickSetUpPaymentButton();
        autoPolicyPaymentBasePage.clickDebitCreditCardButton();
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();

        // Validate AMEX credit card details and validate success messages
        policyDebitCreditPayment.enterCardNumber(AMERICAN_EXPRESS_CARD);
        policyDebitCreditPayment.enterExpDate(EXP_DATE);
        policyDebitCreditPayment.enterCVVNumber(0 + CVV_NUMBER);
        policyDebitCreditPayment.enterBillingZipCode(ZIP_CODE);
        autoPolicyPaymentBasePage.clickAddButton();
        policyDebitCreditPayment.waitForCompletePurchaseButtonToBeClickable();
        fsa.assertTrue(policyDebitCreditPayment.isHiddenCardNumberAndExpDatePayInfFullCorrect(AMERICAN_EXPRESS_CARD, EXP_DATE, CARD_NAME_AMEX), "Hidden card number and exp date");
        fsa.assertTrue(policyDebitCreditPayment.isCreditCardAddedMsgCorrect(), errorMessage("Debit card added message"));
        fsa.assertTrue(policyDebitCreditPayment.isNoServiceChargeWhenPayInFullMsgCorrect(AUTO), errorMessage("No service charge when using card message"));

        policyBankPayment.clickChangeLink();
        String accountNumber = RandomStringUtils.randomNumeric(10);
        // Changing payment from credit card to bank
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        sleep(1);
        fsa.assertTrue(policyBankPayment.isBOFABankNameLabelCorrect(), errorMessage("BOFA bank label"));

        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        autoPolicyPaymentBasePage.clickAddButton();

        fsa.assertTrue(policyBankPayment.isBankPaymentAccountAddedMsgCorrect(), errorMessage("Bank account added"));
        fsa.assertTrue(policyDebitCreditPayment.isNoServiceChargeWhenPayInFullMsgCorrect(AUTO), errorMessage("No service charge when using bank transfer"));
        fsa.assertTrue(policyBankPayment.isBankIconDisplayed(), "Bank icon is not displayed");
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountPayInFullTextCorrect(accountNumber), errorMessage("Hidden account number pay in full"));
        autoPolicyPaymentBasePage.logInfoMessage(additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore().getData().getQuoteNumber());
        autoPolicyPaymentBasePage.addSauceLabsLinkInLog();
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_DEBITCREDITPAYMENT_PAGE}, enabled = false)
    public void monthlyPayDebitCreditIframeValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();

        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        autoPolicyPaymentBasePage.selectCardPaymentRadioButtonAlternative();
        autoPolicyPaymentBasePage.clickSetUpPaymentButton();

        autoPolicyPaymentBasePage.switchToPaymentUsIframe();

        // validate VISA, MASTER, AMEX, DISCOVER card symbol
        policyDebitCreditPayment.enterCardNumber(VISA_DEBIT_CARD);
        fsa.assertTrue(policyDebitCreditPayment.isVisaCardIconDisplayed(), "Visa card symbol is not displayed");
        policyDebitCreditPayment.clearOutCardNumberInputField();

        policyDebitCreditPayment.enterCardNumber(MASTER_CARD);
        fsa.assertTrue(policyDebitCreditPayment.isMasterCardIconDisplayed(), "Master card symbol is not displayed");
        policyDebitCreditPayment.clearOutCardNumberInputField();

        policyDebitCreditPayment.enterCardNumber(DISCOVER_CARD);
        fsa.assertTrue(policyDebitCreditPayment.isDiscoverCardIconDisplayed(), "Discover card symbol is not displayed");
        policyDebitCreditPayment.clearOutCardNumberInputField();

        policyDebitCreditPayment.enterCardNumber(AMERICAN_EXPRESS_CARD);
        fsa.assertTrue(policyDebitCreditPayment.isAmexCardIconDisplayed(), "American express card symbol is not displayed");
        policyDebitCreditPayment.clearOutCardNumberInputField();

        // Validate VISA debit card details and validate success messages
        policyDebitCreditPayment.enterCardNumber(VISA_DEBIT_CARD);
        policyDebitCreditPayment.enterExpDate(EXP_DATE);
        policyDebitCreditPayment.enterCVVNumber(CVV_NUMBER);
        policyDebitCreditPayment.enterBillingZipCode(ZIP_CODE);
        autoPolicyPaymentBasePage.clickAddButton();
        policyDebitCreditPayment.waitForCompletePurchaseButtonToBeClickable();
        fsa.assertTrue(policyDebitCreditPayment.isHiddenCardNumberAndExpDateMonthlyPayCorrect(VISA_DEBIT_CARD, EXP_DATE, CARD_NAME_VISA), "Hidden card number and exp date visa debit");
        fsa.assertTrue(policyDebitCreditPayment.isDebitCardAddedMsgCorrect(), errorMessage("Debit card added message"));
        fsa.assertTrue(policyDebitCreditPayment.isFutureDebitCardServiceChargesTextMatching(), errorMessage("Future service debit card charge"));

        // Validate duplicate card added
        policyDebitCreditPayment.clickChangeLink();
        autoPolicyPaymentBasePage.selectCardPaymentRadioButtonAlternative();
        autoPolicyPaymentBasePage.switchToParentWindow();
        autoPolicyPaymentBasePage.clickSetUpPaymentButtonSideSheet();
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyDebitCreditPayment.enterCardNumber(VISA_DEBIT_CARD);
        policyDebitCreditPayment.enterExpDate(EXP_DATE);
        policyDebitCreditPayment.enterCVVNumber(CVV_NUMBER);
        policyDebitCreditPayment.enterBillingZipCode(ZIP_CODE);
        autoPolicyPaymentBasePage.clickAddButton();
        fsa.assertTrue(autoPolicyPaymentBasePage.isPaymentMethodAlreadyAddedMsgCorrect(), errorMessage("Payment method already added"));
        autoPolicyPaymentBasePage.switchToParentWindow();
        autoPolicyPaymentBasePage.closeAddPaymentMethodContainer(true);

        autoPolicyPaymentBasePage.clickSetUpPaymentButton();
        autoPolicyPaymentBasePage.addCardPaymentMethod(PaymentMethods.VISA_DEBIT_CARD_2.getAccountNumber(), applicant.getZipCode());
        // Validate agreement bullet points and various links inside agreement text
        fsa.assertTrue(autoPolicyPaymentBasePage.isByClickingCompletePurchaseLabelCorrect(), errorMessage("By clicking complete purchase"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isReadAndAgreedBulletPointOneCorrect(), errorMessage("Read and agreed bullet point one"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isReadAndAgreedBulletPointTwoMonthlyPayCorrect(), errorMessage("Read and agreed bullet point two for monthly pay"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isIfDoNotAgreeWithTermsAndConditionLabelCorrect(), errorMessage("If you do not agree term and condition label"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isCompletePurchaseButtonTextMatching(), errorMessage("Complete purchase button"));
        fsa.assertTrue(autoPolicyPaymentBasePage.validateOpeningLinksInNewTab(), "Title is not matching for one or more opened tab");

        // Validate adding AMEX card details
        policyDebitCreditPayment.clickChangeLink();
        autoPolicyPaymentBasePage.selectCardPaymentRadioButtonAlternative();
        autoPolicyPaymentBasePage.clickSetUpPaymentButtonSideSheet();
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyDebitCreditPayment.enterCardNumber(AMERICAN_EXPRESS_CARD);
        policyDebitCreditPayment.enterExpDate(EXP_DATE);
        policyDebitCreditPayment.enterCVVNumber(0 + CVV_NUMBER);
        policyDebitCreditPayment.enterBillingZipCode(ZIP_CODE);
        autoPolicyPaymentBasePage.clickAddButton();
        policyDebitCreditPayment.waitForCompletePurchaseButtonToBeClickable();
        fsa.assertTrue(autoPolicyPaymentBasePage.isCompletePurchaseButtonTextMatching(), errorMessage("Complete purchase button"));
        autoPolicyPaymentBasePage.logInfoMessage(additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore().getData().getQuoteNumber());
        autoPolicyPaymentBasePage.addSauceLabsLinkInLog();
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_DEBITCREDITPAYMENT_PAGE}, enabled = false)
    public void monthlyPayCreditCardToBankPaymentMethodChange(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();

        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        PolicyBankPayment policyBankPayment = new PolicyBankPayment();
        autoPolicyPaymentBasePage.selectCardPaymentRadioButtonAlternative();
        autoPolicyPaymentBasePage.clickSetUpPaymentButton();

        autoPolicyPaymentBasePage.addCardPaymentMethod(DISCOVER_CREDIT_CARD_1.getAccountNumber(), applicant.getZipCode());
        policyDebitCreditPayment.waitForCompletePurchaseButtonToBeClickable();
        fsa.assertTrue(policyDebitCreditPayment.isHiddenCardNumberAndExpDateMonthlyPayCorrect(DISCOVER_CREDIT_CARD_1.getAccountNumber(), EXP_DATE, CARD_NAME_DISCOVER), "Hidden card number and exp date");
        fsa.assertTrue(policyDebitCreditPayment.isCreditCardAddedMsgCorrect(), errorMessage("Credit card added message"));
        fsa.assertTrue(policyDebitCreditPayment.isFutureCreditCardServiceChargesTextMatching(), errorMessage("Future service credit card charge"));

        policyBankPayment.clickChangeLink();
        String accountNumber = RandomStringUtils.randomNumeric(10);

        // Checking payment setup validation
        autoPolicyPaymentBasePage.selectBankPaymentRadioButtonSideSheet();
        autoPolicyPaymentBasePage.clickSetUpPaymentButtonSideSheet();
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        sleep(1);
        fsa.assertTrue(policyBankPayment.isBOFABankNameLabelCorrect(), errorMessage("BOFA bank label"));

        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        autoPolicyPaymentBasePage.clickAddButton();

        fsa.assertTrue(policyBankPayment.isBankPaymentAccountAddedMsgCorrect(), errorMessage("Bank account added"));
        autoPolicyPaymentBasePage.isDisclaimerChargeTextCorrect(fsa, NO_SERVICE_CHARGE_WHEN_USING_BANK);
        fsa.assertTrue(policyBankPayment.isNoServiceChargeWhenUsingBankMsgCorrect(), errorMessage("No service charge when using bank transfer"));
        fsa.assertTrue(policyBankPayment.isBankIconDisplayed(), "Bank icon is not displayed");
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountMonthlyPayTextCorrect(accountNumber), errorMessage("Hidden account number"));

        autoPolicyPaymentBasePage.logInfoMessage(additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore().getData().getQuoteNumber());
        autoPolicyPaymentBasePage.addSauceLabsLinkInLog();
        fsa.assertAll();
    }

    private String errorMessage(String item) {
        return item + " text is not correct";
    }
}
