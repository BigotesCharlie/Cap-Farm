package com.farmers.ffq.acemobilehome;

import static com.farmers.ffq.utils.GlobalVariables.EXCLUDED_STATES;
import static com.farmers.ffq.utils.GlobalVariables.EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES;
import static com.farmers.ffq.utils.GlobalVariables.FFQ_MOBILE_HOME;
import static com.farmers.ffq.utils.GlobalVariables.MEDIA_ALPHA;
import static com.farmers.ffq.utils.GlobalVariables.MN;
import static com.farmers.ffq.utils.GlobalVariables.PARTTIME;
import static com.farmers.ffq.utils.GlobalVariables.UNOCCUPIED;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.AutomationFramework;

public class AceMobileHomePartnerIntegrationTests extends AutomationFramework {

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {FFQ_MOBILE_HOME})
	public void verifyMediaAlphaMobilehomeQuotePageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableMediaAlphaMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {FFQ_MOBILE_HOME})
	public void verifyMediaAlphaLandlordMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		//RENT is the default for all applicants
		enableMediaAlphaMode(mobilehomeApplicant);
		mobilehomeApplicant.setPrimaryResidence(false);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {FFQ_MOBILE_HOME})
	public void verifyMediaAlphaSeasonalSecondaryMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableMediaAlphaMode(mobilehomeApplicant);
		mobilehomeApplicant.setPrimaryResidence(false);
		mobilehomeApplicant.setReasonWhyNotPrimaryResidence(PARTTIME);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MN}), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {FFQ_MOBILE_HOME})
	public void verifyMediaAlphaVacantMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableMediaAlphaMode(mobilehomeApplicant);
		mobilehomeApplicant.setPrimaryResidence(false);
		mobilehomeApplicant.setReasonWhyNotPrimaryResidence(UNOCCUPIED);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	private void enableMediaAlphaMode(ApplicantAceHome mobilehomeApplicant) {
		mobilehomeApplicant.setTestCategory(MEDIA_ALPHA);
	}

}
