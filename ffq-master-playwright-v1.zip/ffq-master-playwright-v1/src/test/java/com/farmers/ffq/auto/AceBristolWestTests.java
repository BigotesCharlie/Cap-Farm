package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.datatransferobjects.SqlDiscount;
import com.farmers.ffq.datatransferobjects.Vehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.RandomUtils;
import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.*;

import static com.farmers.ffq.auto.pages.VehicleReviewPage.RIDESHARE;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceBristolWestTests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, CT, FL, ID, KS, MA, MI, MO, MS, NC, NE, NJ, NM, NV, NY, OK, PA, TN, VA, WA, OR})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void bwPageValidationTests(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        if (applicant.getStateCode().equalsIgnoreCase(MA)) {
            applicant.getVehicles().forEach(each -> each.setParkInResidentAddress(true));
        }
        applicant.setLastName("Threeoabaa");
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        applicant.setFullTimeStudentWithHighGPA(true);
        applicant.setAge(20);
        applicant.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(applicant.getAge()));
        ContinueWithBristolWestPage continueWithBristolWestPage = new AceAutoNavigationHelper().navigateToContinueWithBristolWestPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        if (continueWithBristolWestPage.isContinueWithBristolWestDialogDisplayedForRebranding()) {
            continueWithBristolWestPage.validatePageHeader(fsa);
            continueWithBristolWestPage.validatePageCantOfferTextForFarmersToBwReBrandPage(fsa);
            continueWithBristolWestPage.validatePageGoodNewsTextForFarmersToBwReBrandPage(fsa);
            continueWithBristolWestPage.validatePageSoundsGoodTextForFarmersToBwReBrandPage(fsa);
        } else if (continueWithBristolWestPage.isContinueWithBristolWestDialogDisplayed()) {
            continueWithBristolWestPage.validateDialogContent(applicant, fsa);
            continueWithBristolWestPage.continueWithBwPopUp();
        } else {
            continueWithBristolWestPage.validatePageContent(fsa);
            continueWithBristolWestPage.clickContinueButton();
            continueWithBristolWestPage.waitForSpinnerToBeGone();
        }
        if (new KnockoutInconveniencePage().isQuoteKnockedOut()) {
            fsa.assertAll();
            throw new SkipException("Can't complete test due to knockout");
        } else if (new BristolWestAdditionalDiscountsPage().isOnBristolWestAdditionalDiscountsPage()) {
            new BristolWestAdditionalDiscountsPage().clickContinue();
        }
        fsa.assertTrue(new QuoteSummaryAutoPage().isOnBristolWest(), "User should get rated in BW.");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, FL, ID, KS, MO, NJ, NM, OK, PA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void bwNeverHadInsuranceTest(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        testStep("BW Never had Insurance validation", false);
        createAceBWQuote(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, TX})},
            dataProviderClass = AutoDataProviders.class, groups = {PRODUCTION_VALIDATION})
    public void bwNeverHadInsuranceTestForProd(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        updatePersonalInfoForProd(applicant);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        testStep("BW Never had Insurance test started", false);
        createAceBWQuote(applicant);
        testStep("Test completed for BW Never had Insurance validation", true);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CO, FL, ID, KS, MO, NC, NJ, NM, NV, OK, PA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void bwInsuredLT6MonthsTest(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.setContinuosInsurancePeriod("< 6 Months");
        testStep("BW Less Than 6 Month validation", false);
        createAceBWQuote(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, FL, ID, KS, MA, MO, NM, OK, PA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void bwExpiredInsuranceTest(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.setCurrentlyInsuredStatus(EXPIRED);
        testStep("BW Expired Insurance", false);
        createAceBWQuote(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, FL, ID, KS, MA, MO, NM, OK, PA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void bwForeignDriverTest(AutoApplicant applicant) throws Exception {
        if (!applicant.getTestScenario().contains("BW")) {
            applicant.setTestScenario("BW -> " + applicant.getTestScenario());
        }
        applicant.setFirstAgeForeignDriverLicense(18);
        createAceBWQuote(applicant);
    }

    /*
        Feature: F90012 from R10 Suite
        Scenario: Validtae NJ customer starts an auto quote organically, Customer to be shown Continue to BW interstitial page (Refer US1010865 for screenshot)
     */
    @Skip // NJ now goes to the Farmers Flow
    @Test(groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void validateAceBWInterstitialPageContent() throws Exception {
        // Now NJ will land on the Farmers Flow, instead using zipCode from PA
        new LandingPage().enterLandingPageData(LOB_AUTO, "18058");
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        continueWithBristolWestPage.waitForSpinnerToBeGone();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        continueWithBristolWestPage.validatePageContentForNJ(fsa);
    }

    /*
        Feature: F90012 from R10 Suite
        Scenario: Validate If a customer choses to Continue the user must be taken through NJ Ace experience (Refer US1010865 for screenshot)

     */
    @Skip // NJ now goes to the Farmers Flow
    @Test(groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void validateIfCustomerTakenToNJAceExperienceOnClickOfContinueCTAOnBWInterstitialPage() throws Exception {
        new LandingPage().enterLandingPageData(LOB_AUTO, "08014");
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        continueWithBristolWestPage.waitForSpinnerToBeGone();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        continueWithBristolWestPage.continueWithBWPage(true);
        continueWithBristolWestPage.waitForSpinnerToBeGone();
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        fsa.assertTrue(nameAndDobPage.isOnNameAndDobPage(), "Reached Name and DOB page");
    }

    /*
        Feature: F90012 from R10 suite
        Scenario: 1. Validate If a consumer choses to "Continue to FGIA" the user must be taken to Farmers General Insurance page (Refer US1010865 for screenshot)
                  2. Validate If a consumer declines by clicking on "No, thanks" the customer to be directed to FGIA interstitial page (Refer US1010865 for screenshot)
     */
    @Skip // New Jersey Now Goes to Farmers Flow, No interstial page expected
    @Test(groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void validateFGIAInterstitialPageAndFarmersGeneralInsurancePageOnClickOfContinueToFGIACTA() throws Exception {
        new LandingPage().enterLandingPageData(LOB_AUTO, "08014");
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        continueWithBristolWestPage.waitForSpinnerToBeGone();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        continueWithBristolWestPage.continueWithBWPage(false);
        continueWithBristolWestPage.waitForSpinnerToBeGone();
        FarmersGeneralInsuranceAgencyPage farmersGeneralInsuranceAgencyPage = new FarmersGeneralInsuranceAgencyPage();
        farmersGeneralInsuranceAgencyPage.validateFGIAPromptPage(fsa, true, "08014");
        String FGIA_ActualURL = driver().getCurrentUrl();
        fsa.assertTrue(FGIA_ActualURL.contains(FGIA_URL), "User Landed on 'FARMERS GENERAL INSURANCE AGENCY' page");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, FL, ID, KS, MO, NJ, NM, OK, PA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void createAutoQuoteAndEnsureBrightlineToBW(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.getVehicles().forEach(each -> each.setUseVIN(true));
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        if (!applicant.getStateCode().equals(OR)) {
            applicant.setFirstAgeForeignDriverLicense(18);
        }
        // validates that brightlines to BW
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
        }
        String stateCode = applicant.getStateCode();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        if (Arrays.asList(NC, WY).contains(stateCode)) {
            fsa.assertTrue(new QuoteSummaryAutoPage().isOnQuoteSummaryAutoPage(), stateCode + " quotes, user should get rated by Farmers.");
        } else {
            ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
            if (continueWithBristolWestPage.isContinueWithBristolWestDialogDisplayed()) {
                continueWithBristolWestPage.continueWithBwPopUp();
                continueWithBristolWestPage.waitForSpinnerToBeGone();
                fsa.assertTrue(continueWithBristolWestPage.isBwLogoImageDisplayed(), "BW logo is displayed in quote");
            } else {
                fsa.assertTrue(continueWithBristolWestPage.isOnContinueWithBristolWestPage(), "User should land on BW switch page");
                fsa.assertTrue(continueWithBristolWestPage.isBwLogoImageDisplayed(), "BW logo is displayed in quote");
            }
            if (new KnockoutInconveniencePage().isQuoteKnockedOut()) {
                throw new SkipException("Can't continue test due to knockout");
            } else {
                continueWithBristolWestPage.navigateBack();
                continueWithBristolWestPage.waitForSpinnerToBeGone();
                fsa.assertTrue(contactInfoAutoPage.isBwLogoImageDisplayed(), "BW logo persists when navigating backwards");
            }
        }
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {MA, OR, AZ, CA, CO, FL, ID, KS, MO, NM, OK, PA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void testAutoQuoteStaysOnBWOnceBWScreenAccepted(AutoApplicant applicant) throws Exception {
        applicant.setFirstAgeForeignDriverLicense(18);
        applicant.getDiscounts().get(0).setSignalSignup(false);
        //setting vehicle use vin to true to avoid bw rate failures
        applicant.getVehicles().forEach(each -> each.setUseVIN(true));
        createAceBWQuote(applicant);
        String stateCode = applicant.getStateCode();
        if (Arrays.asList(CA, GA, NC, OR, FL).contains(stateCode)) {
            return; // these states will land on the KO page or already in BW (FL)
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is BW Quote Page", true);
        // navigate back after quote submission and validate that previous pages still has BW logo
        // navigate back to EnterInfo page
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();

        if (!whoShouldWeInsurePage.isOnWhoShouldWeInsurePage()) {
            new NameAndDobPage().clickContinueButton();
            new AutoEnterAddressPage().clickContinueButton();
        }

        testStepAssert(whoShouldWeInsurePage.isOnBristolWest(), "BW logo should be displayed once BW switch is accepted");
        String fullName = String.join(SPACE, applicant.getFirstName(), applicant.getLastName());
        // Removing condition for brightlining to BW
        boolean vehiclesDriversConsolidationImpl = whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        if (vehiclesDriversConsolidationImpl) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.clickEditButtonWithDriverFullName(fullName);
            vehiclesDriversInfoPage.selectUSOrCALicensedButton(YES);
            vehiclesDriversInfoPage.clickSaveChangesDriverSheet();
            vehiclesDriversInfoPage.clickContinueButton();
        } else {
            whoShouldWeInsurePage.clickEditButtonWithDriverFullName(String.join(SPACE, applicant.getFirstName(), applicant.getLastName()));
            whoShouldWeInsurePage.selectUsOrCanadaLicensedRadioButton(YES);
            whoShouldWeInsurePage.clickOnSaveButton();
            whoShouldWeInsurePage.clickOnContinueButton();
        }

        applicant.setFirstAgeForeignDriverLicense(0);
        if (!vehiclesDriversConsolidationImpl) {
            new VehicleReviewPage().clickOnContinueButton();
            DriverReviewPage driverReviewPage = new DriverReviewPage();
            driverReviewPage.enterDriverLicenseAge(applicant, driverReviewPage.getApplicantFullName(applicant), applicant.getFirstAgeUnitedStatesDriverLicense());
            driverReviewPage.addDriverLicenseNumber(applicant, driverReviewPage.getApplicantFullName(applicant));

            for (SqlAdditionalDriver additionalDriver : applicant.getAdditionalDrivers()) {
                String additionalDriverFullName = additionalDriver.getFirstName() + SPACE + additionalDriver.getLastName();
                driverReviewPage.enterDriverLicenseAge(applicant, additionalDriverFullName, additionalDriver.getFirstAgeUnitedStatesDriverLicense());
                driverReviewPage.addDriverLicenseNumber(applicant, additionalDriverFullName);
            }
            driverReviewPage.clickContinueButton();
        }

        SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
        if (signalPageOneUI.isOnSignalPage()) {
            List<SqlDiscount> applicantDiscounts = applicant.getDiscounts();
            if (applicantDiscounts.isEmpty()) {
                signalPageOneUI.processSignalPage(false);
            } else {
                signalPageOneUI.processSignalPage(applicantDiscounts.get(0).isSignalSignup());
            }
            signalPageOneUI.waitForSpinnerToBeGone();
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        if (contactInfoAutoPage.isOnContactInfoAutoPage()) {
            contactInfoAutoPage.clickContactInfoPageCTAButton();
            contactInfoAutoPage.waitForSpinnerToBeGone();
        }
        BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
        if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            bristolWestAdditionalDiscountsPage.clickContinue();
        }
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page after navigation");
        testStepAssert(quoteSummaryAutoPage.isOnBristolWest(), "User is on the BW quote summary page after navigation");
        // Assert if farmers logo at the top
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, FL, GA, ID, IL, KS, MO, NC, NM, OK, PA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void testUserShouldGetFarmersQuoteIfBWConditionRemovedBeforeSwitchingToBW(AutoApplicant applicant) throws Exception {
        applicant.setFirstAgeForeignDriverLicense(18);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.navigateToContinueWithBristolWestPage(applicant);
        driver().navigate().back();
        // navigate back before quote submission and validate that previous pages does not have BW logo
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        if (nameAndDobPage.isOnNameAndDobPage()) {
            new NameAndDobPage().clickContinueButton();
        }

        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        if (autoEnterAddressPage.isOnEnterAddressPage()) {
            testStepAssert(autoEnterAddressPage.isOnEnterAddressPage(), "User is on the Address page");
            sleep(1);
            autoEnterAddressPage.clickAddressPageCtaButton();
        }
        InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
        if (interstitialBundlePage.isOnInterstitialBundlePage()) {
            interstitialBundlePage.continueWithAutoMonoLine();
        }

        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage() && whoShouldWeInsurePage.isOnFarmers(), "User should be on the Who Should we insure page and BW logo should not be present");
        // Removing condition for brightlining to BW
        String fullName = String.join(SPACE, applicant.getFirstName(), applicant.getLastName());
        if (aceAutoNavigationHelper.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.clickEditButtonForDriver(fullName);
            vehiclesDriversInfoPage.selectUSOrCALicensedButton(YES);
            vehiclesDriversInfoPage.clickSaveChangesDriverSheet();
        } else {
            whoShouldWeInsurePage.clickEditButtonWithDriverFullName(fullName);
            whoShouldWeInsurePage.selectUsOrCanadaLicensedRadioButton(YES);
            applicant.setFirstAgeForeignDriverLicense(0);
            whoShouldWeInsurePage.clickOnSaveButton();
            whoShouldWeInsurePage.clickOnDoneAddingDriversButton();
        }

        aceAutoNavigationHelper.setResumeFromPage(new VehicleReviewPage().getClass().getSimpleName());
        quoteSummaryAutoPage = whoShouldWeInsurePage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        quoteSummaryAutoPage.closeQualtricsPopUp();
        testStepAssert(quoteSummaryAutoPage.isOnFarmers(), "User is NOT on the BW quote summary page after removing the BW condition");
        testStep(TEST_PASSED);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {IL, OR, AZ, CA, CO, FL, ID, KS, MA, MO, NM, OK, PA, NJ, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void bwRideshareYesTest(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage(RIDESHARE);
            each.setRidesharing(true);
        });
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        QuoteSummaryAutoPage quoteSummaryAutoPage;
        String stateCode = applicant.getStateCode();
        if (Arrays.asList(VA, WA).contains(stateCode)) {
            aceAutoNavigationHelper.navigateToVehicleDriverAssignmentPage(applicant).processVehiclesDriversAssignmentPageIfNeeded();
            fsa.assertTrue(new KnockoutInconveniencePage().isOnKnockOutPage(), "User should land on the KO page with Rideshare in the state of " + stateCode);
        } else if (Arrays.asList(FL, NJ).contains(stateCode)) {
            quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
            fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User should land on the BW quote summary page when vehicle is rideshare in state : " + stateCode);
        } else {
            quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
            fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && !quoteSummaryAutoPage.isOnBristolWest(), "Ride share should get farmers quote for the state of " + stateCode);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"}), @CustomAttribute(name = INCLUDED_STATES, values = {IL, AZ})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void bwMoreThanOneInjuryTest(AutoApplicant applicant) throws Exception {
        applicant.getIncidents().forEach(each -> each.setAnyInjuries(true));
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage("Personal");
            each.setParkInResidentAddress(true);
            each.setUseVIN(true);
        });
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        String stateCode = applicant.getStateCode();
        quoteSummaryAutoPage.closeQualtricsPopUp();
        if (Arrays.asList(CA, CT, MN, UT).contains(stateCode)) {
            fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && !quoteSummaryAutoPage.isOnBristolWest(), "User should be on farmers quote page with more than one injury in the state of " + stateCode);
        } else {
            fsa.assertTrue(quoteSummaryAutoPage.isOnBristolWest(), "User should get BW page with more than one injury in the state of " + stateCode);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, ID, KS, MO, NM, OK, PA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void bwFinancialFilingInStateTest(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        // Setting Vin use to true to avoid bw rate failures
        applicant.getVehicles().forEach(each -> each.setUseVIN(true));
        applicant.setFinancialFiling(SR_22);
        if (!applicant.getTestScenario().contains("BW")) {
            applicant.setTestScenario("BW -> " + applicant.getTestScenario());
        }
        applicant.getVehicles().forEach(each -> {
            each.setUseVIN(false);
            each.setVehicleUsage("Personal");
        });
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        String stateCode = applicant.getStateCode();
        if (Arrays.asList(IA, IN, KS, LA, MA, MD, MN, MS, NV, OH, OK, PA).contains(stateCode)) {
            fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && !quoteSummaryAutoPage.isOnBristolWest(), "User lands on the Farmers quote page with in state financial filing for the state of " + stateCode);
        } else if (Arrays.asList(AL, AR, AZ, CT, FL, GA, ID, IL, MI, MO, ND, NE, NJ, SD, TN, TX, UT, VA, WI, WY).contains(stateCode)) {
            fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User lands on the BW quote summary page when selecting in state financial filing for the state of " + stateCode);
        } else {
            KnockoutInconveniencePage knockoutPage = new KnockoutInconveniencePage();
            fsa.assertTrue(knockoutPage.isOnKnockOutPage(), "Quote was knocked out");
            List<String> listOfKnockoutCodes = knockoutPage.getAllKnockOutErrorCodes();
            //EK33 is the code for financial filling issues, EK21 is generic for WA.
            fsa.assertTrue(listOfKnockoutCodes.stream().anyMatch(List.of("EK21", "EK33")::contains), "List of knockout codes " + listOfKnockoutCodes + " contains FinancialFiling Knockout On UI code when selecting in state financial filing for the state of " + stateCode);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, ID, KS, MO, NM, OK, PA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void bwFinancialFilingInAnotherStateTest(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        applicant.setFinancialFiling(SR_22_ANOTHER_STATE);
        if (!applicant.getTestScenario().contains("BW")) {
            applicant.setTestScenario("BW -> " + applicant.getTestScenario());
        }
        applicant.getVehicles().forEach(each -> {
            each.setUseVIN(false);
            each.setVehicleUsage("Personal");
        });
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        String stateCode = applicant.getStateCode();
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if (Arrays.asList(IN, MN, OH, OK, AR, AZ, CO, ID, IL, KY, MI, MO, NJ, OR, TN, VA, MA).contains(stateCode)) {
            boolean expectBW = Arrays.asList(AR, AZ, CO, ID, IL, MI, MO, NJ, OR, TN, VA, MA).contains(stateCode);
            QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
            String msg = expectBW
                    ? "User lands on the BW quote summary page when selecting financial filing in another state for "
                    : "User lands on the Farmers quote summary page when selecting financial filing in another state for ";
            fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest() == expectBW, msg + stateCode);
        } else {
            ContactInfoAutoPage contactInfoAutoPage = aceAutoNavigationHelper.navigateToContactInfoAutoPage(applicant);
            contactInfoAutoPage.setValuesAndContinue(applicant);
            KnockoutInconveniencePage knockoutPage = new KnockoutInconveniencePage();
            fsa.assertTrue(knockoutPage.isOnKnockOutPage(), "Quote was knocked out");
            List<String> listOfKnockoutCodes = knockoutPage.getAllKnockOutErrorCodes();
            //EK33 is the code for financial filling issues, EK21 is generic for WA.
            fsa.assertTrue(listOfKnockoutCodes.stream().anyMatch(List.of("EK21", "EK33")::contains), "List of knockout codes " + listOfKnockoutCodes + " contains FinancialFiling Knockout On UI code when selecting financial filing in another state for " + stateCode);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CA), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void validateNoBWFor_CA_State(AutoApplicant applicant) throws Exception {
        // add BW condition
        applicant.setFirstAgeForeignDriverLicense(18);
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            vehicleDriverAssignmentPage.processVehiclesDriversAssignmentPageIfNeeded();
        }
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        knockoutInconveniencePage.validateFGIA_KO_Page(farmersSoftAssert);
        farmersSoftAssert.assertAll();
    }

    // Florida quotes should be going into BW immediately
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = FL)},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BRISTOL_WEST_TESTS})
    public void bwDialogAtQuoteStartTest(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        autoEnterAddressPage.fillOutAddressPage(applicant);
        ContinueWithBristolWestPage cwbw = new ContinueWithBristolWestPage();
        if (cwbw.isOnGetAQuoteFromBristolWestPage()) {
            fsa.assertTrue(cwbw.isBristolWestAlternatePageDialogTitleCorrect(applicant.getStateCode()), "Correct content of BW dialog title");
            cwbw.validatePageContentForFarmersToBwReBrandPage(fsa);
            cwbw.validatePageSubheaderForFarmersToBwReBrandPage(fsa);
            cwbw.validatePageCantOfferTextForFarmersToBwReBrandPage(fsa);
            cwbw.validatePageGoodNewsTextForFarmersToBwReBrandPage(fsa);
            cwbw.validatePageSoundsGoodTextForFarmersToBwReBrandPage(fsa);
            cwbw.validatePageDisclosuresForFarmersToBwReBrandPage(fsa);
        } else {
            fsa.fail("Quote did not start in Bristol West");
        }
        fsa.assertAll();
    }

    /**
     * BW: Validate on SRC 6th letter must be ""W"" for all source indicators (check for QW,QU,ME,EV source indicators)
     *
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {CO, MI, PA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BRISTOL_WEST_TESTS})
    public void validateAggregators_F90017(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        if (!applicant.getTestScenario().contains("BW")) {
            applicant.setTestScenario("BW -> " + applicant.getTestScenario());
        }
        List<String> sourceIndicators = new ArrayList<>(Arrays.asList("EV", "QW", "QU", "ME"));
        Collections.shuffle(sourceIndicators);
        String randomSourceIndicator = sourceIndicators.get(0);
        Log.info("Random source indicator: " + randomSourceIndicator);
        String framedUrl = Property.getUri() + "?Lob=A&Source_Indicator=" + randomSourceIndicator + "&Zip_Code=" + applicant.getZipCode() + "&SRC=%s";
        String navigationUrl = EMPTY_STRING;
        switch (applicant.getStateCode()) {
            case MI:
                navigationUrl = String.format(framedUrl, "PERAMWEVFQ_ AAANB4E7SDATKWN");
                break;
            case PA:
                navigationUrl = String.format(framedUrl, "PERAMWQWFQ_ 7SDATKWNP27AX6");
                break;
            case WA:
                navigationUrl = String.format(framedUrl, "PERAMWEVFQ_ AAANB4E7SDATKWN");
                break;
            case CO:
                navigationUrl = String.format(framedUrl, "PERAMWQUFQ_ 7SDATKWNP27AX6");
                break;
            default:
                Log.error("State is not supported");
        }
        Log.info("Aggregator navigation URL: " + navigationUrl);
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        if (nameAndDobPage.isUseMobileViewEnabled()) {
            nameAndDobPage.setBrowserDimensionToMobileBreakPoint();
        } else {
            nameAndDobPage.maximizeTheBrowser();
        }
        driver().get(navigationUrl);
        testStepAssert(nameAndDobPage.isOnNameAndDobPage() && nameAndDobPage.isOnBristolWest(), "User on name and dob page and on BW with Quote Number: " + nameAndDobPage.getSessionStorageAppStore().getData().getQuoteNumber());
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.setResumeFromPage(nameAndDobPage.getClass().getSimpleName());
        aceAutoNavigationHelper.navigateToPaymentSelectionPage(applicant);
        processBwDocuSignAndPayments(PAY_IN_FULL, true);
    }

    /**
     * BW: DE276968
     *
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, ID, KS, MO, NC, NM, OK, PA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BRISTOL_WEST_TESTS})
    public void validateBwHomeOrRentersDiscount(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        applicant.setDiscounts(Collections.emptyList()); // clear discounts;
        SqlDiscount sqlDiscount = new SqlDiscount();
        boolean isHome = RandomUtils.nextBoolean();
        String homeOrRenters = isHome ? "Home" : "Renters";
        //set home or renters randomly
        if (isHome) {   // homeinsurance
            sqlDiscount.setHomeInsurance(true);
            sqlDiscount.setRentersInsurance(false);
            sqlDiscount.setOwnOrRentHome("Own");
        } else { // renters insurance
            sqlDiscount.setOwnOrRentHome("Rent");
            sqlDiscount.setRentersInsurance(true);
            sqlDiscount.setHomeInsurance(false);
        }
        applicant.setDiscounts(List.of(sqlDiscount));
        Log.info(String.format("Testing with %s insurance", homeOrRenters));

        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the quote summary page for BW");
        List<String> displayedDiscounts = quoteSummaryAutoPage.getDisplayedDiscounts();
        Log.info("displayedDiscounts => " + displayedDiscounts);
        testStepAssert(displayedDiscounts.contains("Auto & Home"), "Auto & Home discount is displayed on quote summary page");
    }

    /**
     * Feature: F91388 R11/2025
     * To validate :
     * Quotes redirected from Click2Buy have Valid VIN# [Use the Stub URL from Test Data]
     * Quotes are redirected to BDQ application with encrypted URL.
     * And when user move forward with quote flow the following details are properly prefilled into BDQ application
     * Customer Data
     * Vehicles information using VIN#
     * VIN Should be masked
     * Test data  URL: https://ffqautouiuat.farmers.com/quote/?Flow=CB&Source_Indicator=BDQI&param=i9iIsiEDej3IcJ0usrSUn0GwO8G4TyejgQzYHfOO8NlzdIYIRVkUqx5PaAcXvD0gLo5ED/6u1/cBzONtdonaj67iE2wU4LMnzmP7ZKOMWcOJAJbyphghhTOp4UUK1qvvofqOPt8g497KqDUQ2MAu/QtcdMKrMjZwVuuNZAKzD7pchAU4k73v8DJtC+UbNH/3iSc3+Zym9jOXcZ6nDP3wFmu8ugI+Yo1iBwVMZNHZUIhFOt8P/s5UGkz+fehof8Dx+zKsXrK55bTZEJBL/Q/DymvtV6ztco1+zmMvl3JDe4hHTjz2AQY/qpS/N0u9Z4WWG4JeE3vsb3AgdHwJ9MngVr8qWWe7Z/xImGjMtG6I8mlvn46QXAooivu+6YuFK+vS&AOR=2999999&Agent_Name=Confie&DsplayPhn=18007775620&SRC=CNF_sJaVx2eUrknLA45X_M9mY4ydfMFwugwIrZRJiE3Y
     */
    @Test(groups = BDQ_TESTS)
    public void validateBDQClick2BuyCustomerDataAndValidVinForNJState() throws Exception {
        AutoApplicant applicant = new AutoApplicant();
        applicant.setFirstName("Lindsay");
        applicant.setLastName("THREEOABAA");
        applicant.setDateOfBirth("09/13/1986");
        applicant.setResidentAddress("49056 sourdough Rd ");
        applicant.setCity("Maple Shade");
        applicant.setZipCode("08052");
        applicant.setEmail("heavensentlynze@gmail.com");
        applicant.setPhoneNumber("7608838230");
        String vehicleVinText = "VIN: •••341";
        String click2BuyURL = "https://ffqautouiuat.farmers.com/quote/?Flow=CB&Source_Indicator=BDQI&param=i9iIsiEDej3IcJ0usrSUn0GwO8G4TyejgQzYHfOO8NlzdIYIRVkUqx5PaAcXvD0gLo5ED/6u1/cBzONtdonaj67iE2wU4LMnzmP7ZKOMWcOJAJbyphghhTOp4UUK1qvvofqOPt8g497KqDUQ2MAu/QtcdMKrMjZwVuuNZAKzD7pchAU4k73v8DJtC+UbNH/3iSc3+Zym9jOXcZ6nDP3wFmu8ugI+Yo1iBwVMZNHZUIhFOt8P/s5UGkz+fehof8Dx+zKsXrK55bTZEJBL/Q/DymvtV6ztco1+zmMvl3JDe4hHTjz2AQY/qpS/N0u9Z4WWG4JeE3vsb3AgdHwJ9MngVr8qWWe7Z/xImGjMtG6I8mlvn46QXAooivu+6YuFK+vS&AOR=2999999&Agent_Name=Confie&DsplayPhn=18007775620&SRC=CNF_sJaVx2eUrknLA45X_M9mY4ydfMFwugwIrZRJiE3Y";
        Log.info("Click2Buy URL for NJ State: " + click2BuyURL);
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        if (nameAndDobPage.isUseMobileViewEnabled()) {
            nameAndDobPage.setBrowserDimensionToMobileBreakPoint();
        } else {
            nameAndDobPage.maximizeTheBrowser();
        }
        driver().get(click2BuyURL);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(nameAndDobPage.isOnNameAndDobPage(), "User is on Name and DOB Page");
        nameAndDobPage.arePrefilledValuesMatching(applicant, fsa);
        nameAndDobPage.clickContinueButton();
        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        autoEnterAddressPage.validatePrefillValues(applicant);
        autoEnterAddressPage.fillOutEmailAndPhoneIfPresent(applicant.getEmail(), applicant.getPhoneNumber());
        autoEnterAddressPage.clickAddressPageCtaButton();
        OneMomentPage oneMomentPage = new OneMomentPage();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        fsa.assertTrue(oneMomentPage.isOnOneMomentPage(), "User is on One Moment Page");
        fsa.assertTrue(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on Who Should We Insure Page");
        if (!whoShouldWeInsurePage.getDisplayedCompleteDrivers().isEmpty()) {
            whoShouldWeInsurePage.validateVehicleVinLabel(vehicleVinText, fsa);
        }

        fsa.assertAll();
    }

    /**
     * Validate if the user is redirected to the Vehicles/Drivers Review page with the following error message when submitting the BW Quote for rating, where the vehicle has one of the following errors: VEHICLE SYMBOL ERRORS, UNACCEPTABLE VEHICLE, or RATING ERRORS. Also, ensure that there is no error message displayed below the valid vehicles.
     * Error Message: “We are unable to locate details for this vehicle. Please provide the VIN and try again.”
     * <p>
     * Note: Use below vehicles and create BW quote.
     * Test data:
     * Year: 2025
     * Make: TOYOTA
     * Model: CAMRY 4D 2WD
     * <p>
     * Test data:
     * Year: 2024
     * Make: INEOS
     * Model: GRENADIER 4D 4WD
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=36"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, ID, KS, MO, NM, OK, PA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void validateVinErrorMessageForBWRateFailureAndContinueWithValidVin(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);

        //update vehicles
        Vehicle firstVehicle = applicant.getVehicles().get(0);
        Vehicle secondVehicle = applicant.getVehicles().get(1);
        // update first vehicle
        firstVehicle.setUseVIN(false);
        firstVehicle.setVehicleYear("2025");
        firstVehicle.setVehicleMake("TOYOTA");
        firstVehicle.setVehicleModel("CAMRY 4D 2WD");
        firstVehicle.setVehicleType("Sedan");

        // update second vehicle
        secondVehicle.setUseVIN(false);
        secondVehicle.setVehicleYear("2024");
        secondVehicle.setVehicleMake("INEOS");
        secondVehicle.setVehicleModel("GRENADIER 4D 4WD");
        secondVehicle.setVehicleType("Sedan");

        // navigate for BW
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if (!Arrays.asList(FL, NJ).contains(applicant.getStateCode()) && !aceAutoNavigationHelper.isBDQFlowEnabled()) {
            ContinueWithBristolWestPage continueWithBristolWestPage = aceAutoNavigationHelper.navigateToContinueWithBristolWestPage(applicant);
            continueWithBristolWestPage.continueWithBwPopUp();
        } else {
            ContactInfoAutoPage contactInfoAutoPage = aceAutoNavigationHelper.navigateToContactInfoAutoPage(applicant);
            contactInfoAutoPage.setValuesAndContinue(applicant);
        }
        if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            bristolWestAdditionalDiscountsPage.clickContinue();
        }

        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            vehicleDriverAssignmentPage.processVehiclesDriversAssignmentPageIfNeeded();
        }

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();

        // when there is vin error, user either can update the vin or uncheck the vehicle
        boolean userWantedToUncheckOneVehicle = RandomUtils.nextBoolean();
        if (vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            vehiclesDriversInfoPage.validateVinErrorAndAddValidVin(fsa, firstVehicle);
            if (userWantedToUncheckOneVehicle) {
                vehiclesDriversInfoPage.uncheckVehicleCheckbox(secondVehicle);
            } else {
                vehiclesDriversInfoPage.validateVinErrorAndAddValidVin(fsa, secondVehicle);
            }
        } else {
            whoShouldWeInsurePage.validateVinErrorAndAddValidVin(fsa, firstVehicle);
            if (userWantedToUncheckOneVehicle) {
                whoShouldWeInsurePage.uncheckVehicleCheckbox(secondVehicle);
            } else {
                whoShouldWeInsurePage.validateVinErrorAndAddValidVin(fsa, secondVehicle);
            }
        }

        whoShouldWeInsurePage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();

        fsa.assertAll();
    }

    /**
     * Validate the following:
     * 1. Initiate a BW Auto quote for any state and add the following vehicle [Year: 2025, Make: TOYOTA, Model: CAMRY 4D 2WD]
     * 2. Add another vehicle using a VIN [Ex: 5NPDH4AE0DH194307]
     * 3. Proceed and submit the quote for rate
     * 4. Verify that the user is directed to the Vehicles/Drivers review screen, where one vehicle displays a Vehicle Symbol error and the other vehicle (with a valid VIN) shows no error message.
     * 5. Uncheck the errored vehicle, click 'Save quote' link at the bottom and then click 'Continue'
     * 6. Verify if user should be able to proceed forward without any error or issues.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=36"}), @CustomAttribute(name = EXCLUDED_STATES, values = {OR, AZ, CA, CO, ID, KS, MO, NC, NM, OK, PA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void validateVinErrorMessageWithOneVinOneYMM(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);

        //update vehicles
        Vehicle firstVehicle = applicant.getVehicles().get(0);
        Vehicle secondVehicle = applicant.getVehicles().get(1);

        // update first vehicle
        firstVehicle.setUseVIN(false);
        firstVehicle.setVehicleYear("2025");
        firstVehicle.setVehicleMake("TOYOTA");
        firstVehicle.setVehicleModel("CAMRY 4D 2WD");
        firstVehicle.setVehicleType("Sedan");

        // update second vehicle
        secondVehicle.setUseVIN(true);

        // navigate for BW
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        ContactInfoAutoPage contactInfoAutoPage = aceAutoNavigationHelper.navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);

        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
        }

        if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            bristolWestAdditionalDiscountsPage.clickContinue();
        }

        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            vehicleDriverAssignmentPage.processVehiclesDriversAssignmentPageIfNeeded();
        }


        FarmersSoftAssert fsa = new FarmersSoftAssert();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        if (vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            fsa.assertTrue(vehiclesDriversInfoPage.isVehicleErrorMessageDisplayed(vehiclesDriversInfoPage.getVehicleDescriptionFromVehicle(firstVehicle)), "Error message should be visible for the vehicle with YMM");
            fsa.assertFalse(vehiclesDriversInfoPage.isVehicleErrorMessageDisplayed(vehiclesDriversInfoPage.getVehicleDescriptionFromVehicle(secondVehicle)), "Error message should not be visible for the vehicle with VIN");
            vehiclesDriversInfoPage.uncheckVehicleCheckbox(firstVehicle);
        } else {
            fsa.assertTrue(whoShouldWeInsurePage.isVehicleErrorMessageDisplayed(vehiclesDriversInfoPage.getVehicleDescriptionFromVehicle(firstVehicle)), "Error message should be visible for the vehicle with YMM");
            fsa.assertFalse(whoShouldWeInsurePage.isVehicleErrorMessageDisplayed(vehiclesDriversInfoPage.getVehicleDescriptionFromVehicle(secondVehicle)), "Error message should not be visible for the vehicle with VIN");
            whoShouldWeInsurePage.uncheckVehicleCheckbox(firstVehicle);
        }

        whoShouldWeInsurePage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();

        fsa.assertAll();
    }

    private AutoApplicant setTestDataForAceApplicant(AutoApplicant applicant) {
        if (!applicant.getTestScenario().contains("BW")) {
            applicant.setTestScenario("BW -> " + applicant.getTestScenario());
        }
        Iterator<Vehicle> vehiclesIterator = applicant.getVehicles().iterator();
        List<Vehicle> udpatedApplicantVehicleList = new ArrayList<>();
        while (vehiclesIterator.hasNext()) {
            Vehicle vehicleToUpdate = vehiclesIterator.next();
            vehicleToUpdate.setParkInResidentAddress(true);
            udpatedApplicantVehicleList.add(vehicleToUpdate);
        }
        applicant.setVehicles(udpatedApplicantVehicleList);
        List<SqlAdditionalDriver> noAdditionalDrivers = new ArrayList<>();
        applicant.setAdditionalDrivers(noAdditionalDrivers);
        return applicant;
    }

    private void createAceBWQuote(AutoApplicant applicant) throws Exception {
        applicant = setTestDataForAceApplicant(applicant);
        String stateCode = applicant.getStateCode();
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        switch (stateCode) {
            case FL:
            case NJ:
                //FL is monetized to only go to BW
                aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
                testStepAssert(quoteSummaryAutoPage.isOnBristolWest(), stateCode + " state only has BW flow");
                break;
            case CA:
            case NC:
                aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
                testStepAssert(!quoteSummaryAutoPage.isOnBristolWest(), stateCode + " state requires special test data for BW, hence will land on farmers quote page");
                break;
            default:
                if (Arrays.asList(OR, GA).contains(stateCode) && applicant.getFirstAgeForeignDriverLicense() == 18) {
                    aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
                    testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User should land on Farmers quote summary page with foreign dl in state of " + stateCode);
                    return;
                }
                if (Arrays.asList(NV).contains(stateCode) && applicant.getCurrentlyInsuredStatus().equals(EXPIRED)) {
                    aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
                    testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User should land on Farmers quote summary page with expired in state of " + stateCode);
                    return;
                }
                ContinueWithBristolWestPage continueWithBristolWestPage = aceAutoNavigationHelper.navigateToContinueWithBristolWestPage(applicant);
                if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
                    continueWithBristolWestPage.continueWithBwPopUp();
                }
                BristolWestAdditionalDiscountsPage bwAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
                if (bwAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                    bwAdditionalDiscountsPage.clickContinue();
                }
                if(stateCode.equals(VA) && applicant.getFirstAgeForeignDriverLicense() == 18) {
                    KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
                    testStepAssert(knockoutInconveniencePage.isOnKnockOutPage(), "Quote was knocked out for VA");
                } else {
                    validateIfOnBWQuotePage(true);
                }
                break;
        }
    }

    private void validateIfOnBWQuotePage(boolean shouldBeOnBWPage) throws Exception {
        QuoteSummaryAutoPage quoteSummaryPage = new QuoteSummaryAutoPage();
        quoteSummaryPage.getSessionStorageAppStore();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        String connector = shouldBeOnBWPage ? "is on" : "is not on";
        fsa.assertEquals(quoteSummaryPage.isOnBristolWest(), shouldBeOnBWPage, "Check that quote " + connector + " Bristol West Quote Summary Page");
        fsa.assertEquals(quoteSummaryPage.isBristolWestDisclaimerPresent(), shouldBeOnBWPage, "Bristol West disclaimer " + shouldBeOnBWPage + " page");
        if (shouldBeOnBWPage) {
            fsa.assertTrue(quoteSummaryPage.hasProperBristolWestDisclaimer(), "Correct BW disclaimer content");
        }
        fsa.assertAll();
    }

}
