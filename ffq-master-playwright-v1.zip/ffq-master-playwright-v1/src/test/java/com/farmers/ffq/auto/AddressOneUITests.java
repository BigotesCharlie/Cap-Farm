package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.common.enums.AutoDiscounts;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.annotation.Skip;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AddressOneUITests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {IL})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADDRESS_CHANGE_ZIP_ONEUI})
    public void testAddressChangePopUp(AutoApplicant applicant) throws Exception {
        applicant.setZipCode("61853");
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        applicant.setResidentAddress("123 County Road 2000 North");
        autoEnterAddressPage.fillOutAddressUsingGooglePrefillORManual(applicant);
        autoEnterAddressPage.fillOutEmailAndPhoneIfPresent(applicant.getEmail(), applicant.getPhoneNumber());
        autoEnterAddressPage.fillOutInsuredAutoElsewhereIfPresent(applicant);
        autoEnterAddressPage.clickAddressPageCtaButton();
        WhoShouldWeInsurePage whoShouldWeInsurePageOneUi = new WhoShouldWeInsurePage();
        sleep(10);
        Assert.assertTrue(whoShouldWeInsurePageOneUi.isOnWhoShouldWeInsurePage(), "Reached \"Who should be insure?\" page");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {UT, FL, IL, OK})})
    public void testAddressOneUIAutoQuotePageContent(AutoApplicant applicant) throws Exception {
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        autoEnterAddressPage.validateAddressPageForF87669(fsa, applicant);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void testErrorMessagesWhenAddressFieldIsBlankInvalidAndNotSelectedFromDropDown(AutoApplicant applicant) throws Exception {
        AutoEnterAddressPage enterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        enterAddressPage.clickAddressPageCtaButton();
        fsa.assertTrue(enterAddressPage.isBlankAddressFieldErrorMessageDisplayed(), "Error messages from not entering an address displayed");
        driver().navigate().refresh();
        enterAddressPage.validateInvalidAddressInput(fsa);
        driver().navigate().refresh();
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI})
    public void testFieldResetOnAddressUpdate(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        DriverReviewPage driverReviewPage = aceAutoNavigationHelper.navigateToDriverReviewPage(applicant);
        applicant.setResidentAddress("545 South Danyell Drive");
        applicant.setCity("Chandler");
        applicant.setStateCode(AZ);
        applicant.setZipCode("85225");
        // navigating to Name and DOB screen
        driverReviewPage.clickEnterInfoNavigationBarStepper();
        aceAutoNavigationHelper.setResumeFromPage(new NameAndDobPage().getClass().getSimpleName());
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        //validate if previous driver and vehicle info has been removed
        fsa.assertTrue(!whoShouldWeInsurePage.isDriverSectionDisplayed(), "Previous driver info removed");
        fsa.assertTrue(!whoShouldWeInsurePage.isVehicleSectionDisplayed(), "Previous vehicle info removed");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
    		attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, NJ, MA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {ADDRESS_ONEUI, FFQ_ONEUI})
    public void testHomeOwnerDiscount(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateApplicantDataToAvoidPossibleBw(applicant);
        List<SqlDiscount> listOfDiscounts = applicant.getDiscounts();
        SqlDiscount discounts = listOfDiscounts.get(0);
        discounts.setOwnOrRentHome("Own a home");
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnFarmers(), "User is on Quote Summary page of Farmers");
        if (quoteSummaryAutoPage.isHomeownerDiscountDisabledState(applicant)) {
            fsa.assertFalse(quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(AutoDiscounts.HOMEOWNER.getName()), "Homeowner discount is not applied");
        } else {
            fsa.assertTrue(quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(AutoDiscounts.HOMEOWNER.getName()), "Homeowner discount applied");
        }
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})
    public void testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh(AutoApplicant applicant) throws Exception {
        applicant.getDiscounts().get(0).setOwnOrRentHome("Rent");
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        // navigate back to Address page and test if input data is retained
        whoShouldWeInsurePage.navigateBackToPreviousPage();
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        nameAndDobPage.clickContinueButton();
        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        autoEnterAddressPage.isAddressInputDataSaved(applicant, fsa);

        // refresh the page when user is on NameAndDob page
        autoEnterAddressPage.refreshPage();
        autoEnterAddressPage.isAddressInputDataSaved(applicant, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = {ADDRESS_ONEUI, FFQ_ONEUI, BDQ_TESTS})
    public void testSubmitYouInfoApiCall(AutoApplicant applicant) throws Exception {

        // submitYourInfo API is triggered when user submits address details and click on submit button
        // below is the step to complete user address detail submission
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if (aceAutoNavigationHelper.isBDQFlowEnabled()) {
            applicant.setTestScenario(BW_ORGANIC_FLOW + " -> " + applicant.getTestScenario());
        }
        aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        // retrieve submitYourInfo API response from appStore(session storage)
        AppStore retrieveQuoteResponseSessionStorage = aceAutoNavigationHelper.getSessionStorageAppStore();

        // extract address from submitYourInfo response payload saved in session storage
        AppStore.Data data = retrieveQuoteResponseSessionStorage.getData();
        AppStore.Data.CustomerData.Address address = data.getCustomerData().getAddress();

        FarmersSoftAssert fsa = new FarmersSoftAssert();

        final String OBSERVED = "observed [";
        final String EQUAL_TO = "] equal to entered [";
        final String END = "]";
        fsa.assertTrue(address.getStreet().toUpperCase().contains(applicant.getResidentAddress().toUpperCase().strip()), OBSERVED + address.getStreet().toUpperCase() + "] contains [" + applicant.getResidentAddress().toUpperCase().strip() + END);
        fsa.assertTrue(address.getCity().equalsIgnoreCase(applicant.getCity().strip()), OBSERVED + address.getCity() + EQUAL_TO + applicant.getCity().toUpperCase().strip() + END);
        fsa.assertTrue(address.getState().equalsIgnoreCase(applicant.getStateCode().strip()), OBSERVED + address.getState() + EQUAL_TO + applicant.getStateCode().strip() + END);
        fsa.assertTrue(address.getZip().equalsIgnoreCase(applicant.getZipCode().strip()), OBSERVED + address.getZip() + EQUAL_TO + applicant.getZipCode().strip() + END);

        fsa.assertTrue(address.getIsStandardized().equals("Y"), "Address  should be standardized");

        RateQuoteServiceInitiated rateQuoteServiceInitiated = new ApiHelper().getRateQuoteServiceInitiated(data.getQuoteNumber());
        if (!aceAutoNavigationHelper.isBDQFlowEnabled()) {
            String passedAddressStandardizationInRateResponse = rateQuoteServiceInitiated.getCalculateQuotePremium().getQuoteDetails().getCustomer().get(0).getAddress().get(0).getAddressStandardizedIndicator();
            fsa.assertTrue(passedAddressStandardizationInRateResponse.equals(LOWERCASE_TRUE), "We shuold pass true for address standardization indicator");
        }
        fsa.assertAll();

    }

    @Skip // now adpf is being call for bdq
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = {ADDRESS_ONEUI, BDQ_TESTS}, expectedExceptions = NullPointerException.class)
    public void validateADPFIsNotCalledWithBDQ(AutoApplicant applicant) throws Exception {
        // submitYourInfo API is triggered when user submits address details and click on submit button
        // below is the step to complete user address detail submission
        VehicleReviewPage vehicleReviewPage = new AceAutoNavigationHelper(switchTestToBDQIfNeeded(applicant)? quoteFlow.BDQ: quoteFlow.DEFAULT).navigateToVehicleReviewPage(applicant);
        new ApiHelper().getAdpfCallPayload(vehicleReviewPage.getSessionStorageAppStore().getData().getQuoteNumber()).getADPFRequestBean().getQuoteNumber();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI})
    public void validateManualEntrySection(AutoApplicant applicant) throws Exception {
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        autoEnterAddressPage.validateManualEntrySection(fsa, applicant);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MA)}, groups = {ADDRESS_ONEUI, FFQ_ONEUI})
    public void validateTownDropdown_MA_State(AutoApplicant applicant) throws Exception {
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        if (!applicant.getStateCode().equals(MA)) {
            testStep("Given state does not have drop down option on the address page" + applicant.getStateCode());
            return;
        }
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        autoEnterAddressPage.validateTownSection(applicant, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI, BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void testAutoAddressPageDisclaimers(AutoApplicant applicant) throws Exception {
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        autoEnterAddressPage.verifyDisclaimers(applicant.getStateCode(), farmersSoftAssert);
        autoEnterAddressPage.fillOutAddressPage(applicant);
        InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
        if(interstitialBundlePage.isOnInterstitialBundlePage()) {
            interstitialBundlePage.continueWithAutoMonoLine();
        }
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage() || heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "User is on either Who should we insure page or Here s what we have found page");
        String quoteNumber = autoEnterAddressPage.getSessionStorageAppStore().getData().getQuoteNumber();
        FCCAuditServiceInitiated fccAuditServiceRequestPayload = new ApiHelper().getFccAuditServiceRequestPayload(quoteNumber);
        farmersSoftAssert.assertEquals(fccAuditServiceRequestPayload.getCustomerConsentDataRequest().getApplicationId(), quoteNumber, "Quote number (application id) is matching");
        String expectedfcc_disclaimerMsg = "By clicking “Agree and submit”, you agree to these ESIGN terms and conditions and to receive marketing calls and texts as detailed below. We call and/or text consumers with information about products and services. By clicking “Agree and submit”, you consent to receive marketing calls and texts on behalf of Farmers<sup>®</sup>, Foremost<sup>®</sup>, Bristol West<sup>®</sup>, and Farmers Life<sup>®</sup> associated entities and their representatives using an automated telephone dialing system, AI-generated and artificial or pre-recorded voice, even for numbers listed on national, state, or business do-not-call registries. Consent is not a condition of purchase. Go to Farmers.com for alternative contact options. Message and data rates may apply.";
        expectedfcc_disclaimerMsg = autoEnterAddressPage.isBDQFlowEnabled() ? expectedfcc_disclaimerMsg.replace("Farmers.com", "Bristolwest.com") : expectedfcc_disclaimerMsg;
        String actualFccDisclaimer = fccAuditServiceRequestPayload.getCustomerConsentDataRequest().getFcc_disclaimerMsg();
        farmersSoftAssert.assertEquals(actualFccDisclaimer, expectedfcc_disclaimerMsg, "fcc_disclaimerMsg is matching");
        FCCAuditServiceEnded fccAuditServiceResponsePayload = new ApiHelper().getFccAuditServiceResponsePayload(quoteNumber);
        farmersSoftAssert.assertEquals(fccAuditServiceResponsePayload.getCustomerConsentDataResponse().getTransactionNotification().getTransactionStatus(), "S", "transactionStatus is matching");
        farmersSoftAssert.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, IN, LA, MI, ND, NJ, NV, TX, WI})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, CONTACT_INFO, ADDRESS_ONEUI})
    public void validateBrandSelectionRule(AutoApplicant applicant) throws Exception {
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        autoEnterAddressPage.validateBrandSelectionRule(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CO, CT, FL, MA, MI, MO, MS, MT, NC, NE, NJ, NM, NV, NY, PA, TN, VA, WA, WY})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, CONTACT_INFO, ADDRESS_ONEUI})
    public void validateSourceID(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        autoEnterAddressPage.validateSourceID(applicant, "APPLE INC", fsa);
        autoEnterAddressPage.validateSourceID(applicant, "Bank Of America", fsa);
        autoEnterAddressPage.validateSourceID(applicant, "United", fsa);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, IL, OK})})
    public void validateInvalidAndEmptyInputErrorMessages(AutoApplicant applicant) throws Exception {
        AutoEnterAddressPage enterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        // Business disabled this feature for now, will re-enable once business enables it again
//        boolean lineTypeIntelligenceImpl = enterAddressPage.getSessionStorageAppStore().getData().getProjectCodeData().getAuto().isLineTypeIntelligenceImpl();//US1182103
//        fsa.assertTrue(lineTypeIntelligenceImpl, "LineTypeIntelligence should be true for state: " + applicant.getStateCode());
        enterAddressPage.validateRequiredErrorFieldsInputErrorMessages(fsa);
        enterAddressPage.validateInvalidContactDetailsErrorMessages(fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, IL, OK})})
    public void validateBrightVerifyAPI_EmailStatus(AutoApplicant applicant) throws Exception {
        AutoEnterAddressPage enterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        enterAddressPage.fillOutEmailAndPhoneIfPresent(applicant.getEmail(), applicant.getPhoneNumber());
        enterAddressPage.validateBrightVerifyStatus();
    }

    @Skip//Business disabled this feature for now, will re-enable once business enables it again
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {CA, TX})})
    public void validateLineTypeIntelligenceServicedIsCalled(AutoApplicant applicant) throws Exception {
        AutoEnterAddressPage enterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        enterAddressPage.fillOutEmailAndPhoneIfPresent(applicant.getEmail(), applicant.getPhoneNumber());
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        enterAddressPage.verifyLineTypeIntelligenceServicedIsCalled(fsa);
        fsa.assertAll();

    }

    /**
     * TC1936994: Ensure TNEDICCA service is triggered when address details are saved.
     *
     * <p>Navigates through the address page, submits address details, then queries
     * the backend event log to assert that the TNEDICCA service was triggered and
     * that the request payload contains the correct address details.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})},
            groups = {ADDRESS_ONEUI, FFQ_ONEUI})
    public void validateTnediccaServiceIsTriggeredWhenAddressDetailsSaved(AutoApplicant applicant) throws Exception {
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper(switchTestToBDQIfNeeded(applicant) ? quoteFlow.BDQ : quoteFlow.DEFAULT)
                .navigateToContactInfoAutoPage(applicant);
        boolean isTnedicaExpected = contactInfoAutoPage.isFlexState(applicant.getStateCode()) && !Arrays.asList(AL, WY, AR, VA).contains(applicant.getStateCode());
        
        String quoteNumber = contactInfoAutoPage.getSessionStorageAppStore().getData().getQuoteNumber();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        TnediccaServiceRequest tnediccaServiceRequest = new ApiHelper().getTnediccaServiceRequest(quoteNumber);
        if (isTnedicaExpected) {
            fsa.assertNotNull(tnediccaServiceRequest, "TNEDICCA service should be triggered when address details are saved. Quote: " + quoteNumber);
            fsa.assertNotNull(tnediccaServiceRequest.getRiskAddresses(), "TNEDICCA request riskAddresses should not be null");
            fsa.assertFalse(tnediccaServiceRequest.getRiskAddresses().isEmpty(), "TNEDICCA request should contain at least one risk address");
            TnediccaServiceRequest.RiskAddress riskAddress = tnediccaServiceRequest.getRiskAddresses().get(0);
            fsa.assertEquals(riskAddress.getState(), applicant.getStateCode(), "TNEDICCA request state matches applicant state");
            fsa.assertEquals(riskAddress.getPostalCode(), applicant.getZipCode(), "TNEDICCA request postal code matches applicant zip code");
            fsa.assertNotNull(riskAddress.getAddressLine1(), "TNEDICCA request addressLine1 should not be null");
        } else {
            fsa.assertNull(tnediccaServiceRequest, "TNEDICCA service should NOT be triggered for non-flex states. Quote: " + quoteNumber);
        }
        fsa.assertAll();
    }

}
