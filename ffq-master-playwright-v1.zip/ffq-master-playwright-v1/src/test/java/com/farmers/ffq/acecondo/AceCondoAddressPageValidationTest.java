package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.common.pages.FGIALandingPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoAddressPageValidationTest extends AutomationFramework {

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ADDRESS_PAGE})
    public void testAddressPageCondoLob(ApplicantAceHome applicant) throws Exception {
        String DIFFERENT_ZIP = "20190";
        AceCondoNavigationHelper navigator = new AceCondoNavigationHelper();
        AceHRCAddressBasePage addressPage = navigator.navigateToAceCondoAddressPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        addressPage.validateQuoteSourceInd(fsa, applicant, CONDO, ADDRESS_PAGE);
        addressPage.validatePageTitlesFooters(fsa, applicant, CONDO);
        addressPage.validateQuoteText(AceHRCBasePage.ADDRESS_PAGE, applicant.getQuoteNumber(), fsa, false);
        addressPage.validateAgentSection(fsa, AceHRCBasePage.ADDRESS_PAGE, applicant.getAgentId(), CONDO);
        addressPage.validatePageErrors(fsa,applicant);
        addressPage.enterAvailableFields(applicant);
        addressPage.validateAddressPageCrossIcon(fsa);
        addressPage.enterAddress(applicant);
        addressPage.enterAvailableFields(applicant);
        addressPage.navigateBack();
        (new AceHRCPropertyTypeBasePage()).selectPropertyType(CONDO);
        addressPage.validateAddressPageFieldsNotSaved(fsa, CONDO);
        addressPage.enterAddress(applicant);
        addressPage.enterAvailableFields(applicant);
        addressPage.clickContinueButton();
        addressPage.waitForSpinnerToBeGone();
        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        qualityGradePage.isOnQualityGradePage();
        addressPage.navigateBack();
        Assert.assertTrue(addressPage.isOnAddressPage(false), "Reached Address page");
        addressPage.validateAddressPageFieldsSaved(applicant, CONDO, fsa);

        // Navigate back to the landing page, change the zip code(i.e., enter any random valid zip code) and validate the data on Address page
        addressPage.navigateBack(3);
        applicant.setZipCode(DIFFERENT_ZIP);
        navigator.navigateToAceCondoAddressPage(applicant);
        addressPage.validateAddressPageFieldsNotSaved(fsa, CONDO);
        fsa.assertAll("Validate Ace Condo - Address page.");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values =  {AZ,OH,OR,LA,MA,MS,MT,NC,TX,UT})}, groups = {FFQ_ACE_CONDO})
    public void testAddressPageTwoOrMorePropertyClaimsInLastThreeYearsCondoLob(ApplicantAceHome applicant) throws Exception {
        AceHRCAddressBasePage aceHRCAddressBasePage = new AceCondoNavigationHelper().navigateToAceCondoAddressPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceHRCAddressBasePage.enterAddress(applicant);
        aceHRCAddressBasePage.enterAvailableFields(applicant);
        aceHRCAddressBasePage.validateTwoOrMorePropertyClaims(fsa, applicant, CONDO);
        fsa.assertAll("Validate Two or more property claims in the last 3 years Knock-out.");
    }

    // KY is a monetized state, but it is temporarily enabled for Condo in lower environments for testing purposes. Hence, it is currently excluded from this test case.
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA, NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE})
    public void testFGIANotOfferingValidationCondoLob(ApplicantAceHome applicant) throws Exception {
        applicant.setAgentId(null);
        AceHRCNavigationHelperBasePage aceHRCNavigationHelperBasePage = new AceHRCNavigationHelperBasePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        FGIALandingPage fgiaLandingPage = new FGIALandingPage();
        aceHRCNavigationHelperBasePage.processLandingPage(applicant, LOB_CONDO);
        fgiaLandingPage.validateContentOfFGIAPopUp(fsa, CONDO);
        if (fgiaLandingPage.isFgiaNoThanksButtonDisplayed()) {
            fgiaLandingPage.clickNoThanksButtonInFGIAPopUp();
            fgiaLandingPage.weAreNotAbleToCompleteQuotePageValidation(fsa, CONDO);
        }
        fsa.assertAll("FGIA - Not offering validation Condo");
    }

    // KY is a monetized state, but it is temporarily enabled for Condo in lower environments for testing purposes. Hence, it is currently excluded from this test case.
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {LA, MA, NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE})
    public void testFGIALandingPageValidationCondoLob(ApplicantAceHome applicant) throws Exception {
        applicant.setAgentId(null);
        AceCondoNavigationHelper navigator = new AceCondoNavigationHelper();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        FGIALandingPage fgiaLandingPage = new FGIALandingPage();
        navigator.processLandingPage(applicant, LOB_CONDO);
        navigator.waitForSpinnerToBeGone();
        if (applicant.getStateCode().equals(LA)){
            AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
            Assert.assertTrue(propertyTypePage.quickIsOnPropertyTypePageCheck(), "User did not navigate to Property Type page - Condo LOB");
            propertyTypePage.fillOutPropertyType(applicant, CONDO);
            fgiaLandingPage.monetizedStateDirectKnockoutPageValidation(fsa, CONDO);
        } else {
            fgiaLandingPage.validateContentOfFGIAPopUp(fsa, CONDO);
            fgiaLandingPage.clickContinueButtonInFGIAPopUp();
            fgiaLandingPage.fgiaIntroPageValidation(fsa, CONDO);
            fsa.assertAll("FGIA - intro page validation Condo");
        }
    }

    /*
    Feature no - F88827 (Digital Monetization)
    */

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_DIGITAL_MONETIZATION_NON_AWS, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {ME, MS, NH, NJ, NY, VT, WV})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE})
    public void testDigitalMonetizationValidationNonAWSCondoLob(ApplicantAceHome applicant) throws Exception {
        AceCondoNavigationHelper navigator = new AceCondoNavigationHelper();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        navigator.processLandingPage(applicant, LOB_CONDO);
        FGIALandingPage fgiaLandingPage = new FGIALandingPage();
        if (navigator.isQnBState(applicant.getStateCode())) { // F103049 / US1165204 - QnB Redirection for Condo LOB
            AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
            Assert.assertTrue(fwsInterstitialPage.isOnQnBSite(), "User did not navigate to QnB portal - Home LOB");
            fwsInterstitialPage.validateQnBUrl(fsa);
        } else if (applicant.getStateCode().equals(NJ)) {
            fgiaLandingPage.validateContentOfFGIAPopUp(fsa, CONDO);
        } else {
            fgiaLandingPage.otherCompaniesDigitalMonetizationPageValidation(fsa, CONDO);
        }
        fsa.assertAll("Monetized state validation - Condo LOB");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_DIGITAL_MONETIZATION_AWS, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {NJ, NY})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ADDRESS_PAGE})
    public void testDigitalMonetizationValidationAWSCondoLob(ApplicantAceHome applicant) throws Exception {
        AceCondoNavigationHelper navigator = new AceCondoNavigationHelper();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        navigator.processLandingPage(applicant, CONDO);
        KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
        koPage.digitalMonetizationKOAgentValidation(fsa, applicant.getAgentId());
        fsa.assertAll("Digital monetization - Call for Quote page validation - " + CONDO);
    }
}
