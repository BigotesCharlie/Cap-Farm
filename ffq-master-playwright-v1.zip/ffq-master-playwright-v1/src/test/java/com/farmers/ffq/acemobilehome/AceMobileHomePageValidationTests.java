package com.farmers.ffq.acemobilehome;

import static com.farmers.ffq.utils.GlobalVariables.EXCLUDED_STATES;
import static com.farmers.ffq.utils.GlobalVariables.FFQ_MOBILE_HOME;
import static com.farmers.ffq.utils.GlobalVariables.MN;
import static com.farmers.ffq.utils.GlobalVariables.PARTTIME;
import static com.farmers.ffq.utils.GlobalVariables.UNOCCUPIED;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.AutomationFramework;

public class AceMobileHomePageValidationTests extends AutomationFramework {

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void verifyAddressPageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileCommonTestHelper(mobilehomeApplicant).verifyAddressPageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void validateAddressPageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileCommonTestHelper(mobilehomeApplicant).validateAddressPageErrorHandling(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void verifyTellUsMorePageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileCommonTestHelper(mobilehomeApplicant).verifyTellUsMorePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void validateTellUsMorePageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileCommonTestHelper(mobilehomeApplicant).validateTellUsMorePageErrorHandling(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void verifyAboutYouPageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileCommonTestHelper(mobilehomeApplicant).verifyAboutYouPageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void validateAboutYouPageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileCommonTestHelper(mobilehomeApplicant).validateAboutYouPageErrorHandling(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void verifyLastStepPageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileCommonTestHelper(mobilehomeApplicant).verifyLastStepPageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void validateLastStepPageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileCommonTestHelper(mobilehomeApplicant).validateLastStepPageErrorHandling(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {FFQ_MOBILE_HOME})
	public void verifyQuotePageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		new AceMobileCommonTestHelper(mobilehomeApplicant).verifyQuotePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {FFQ_MOBILE_HOME})
	public void verifyLandlordMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		//RENT is the default for all applicants
		mobilehomeApplicant.setPrimaryResidence(false);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {FFQ_MOBILE_HOME})
	public void verifySeasonalSecondaryMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		mobilehomeApplicant.setPrimaryResidence(false);
		mobilehomeApplicant.setReasonWhyNotPrimaryResidence(PARTTIME);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MN})}, groups = {FFQ_MOBILE_HOME})
	public void verifyVacantMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		mobilehomeApplicant.setPrimaryResidence(false);
		mobilehomeApplicant.setReasonWhyNotPrimaryResidence(UNOCCUPIED);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}
}
