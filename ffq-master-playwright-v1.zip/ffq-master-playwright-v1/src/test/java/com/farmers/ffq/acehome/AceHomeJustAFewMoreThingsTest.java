package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCJustAFewMoreThingsBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentSelectionPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.JFMT_PAGE;
import static com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage.DID_NOT_REACH;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeJustAFewMoreThingsTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_JAFMT_PAGE})
    public void testValidateContentOfJustFewMoreThingsPageHomeLob(ApplicantAceHome applicant) throws Exception {
        applicant.setNewlyOwned(true);
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicant, LOB_HOME, HOME);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.verifyJustAFewMoreThingsHeader(fsa);
        jfmtPage.validatePolicyStartDateSection(fsa, applicant, HOME);
        if (!applicant.isInEscrow() && applicant.isNewlyOwned()) {
            jfmtPage.validateHomePurchaseDateSection(fsa, HOME);
        }

        if (!applicant.getFortifiedHome().isBlank()) {
            jfmtPage.validateFortifiedCertificationSection(applicant, fsa);
        }
        jfmtPage.validateLenderInfoSection(fsa, applicant, HOME);
        jfmtPage.validateOtherQuestionsSection(applicant, fsa, HOME);
        if (!applicant.isInEscrow() && jfmtPage.getHomePurchaseDate().isBlank()) {
            jfmtPage.fillOutHomePurchaseDate(LocalDate.now().minusDays(1). format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        }
        applicant.setDogsOnPremises(EMPTY_STRING);
        jfmtPage.fillOutJustFewMoreThingsPage(applicant, false);
        jfmtPage.validateSaveQuoteModal(true);
        jfmtPage.validateAgentSection(fsa, JFMT_PAGE, applicant.getAgentId(), HOME);
        jfmtPage.validateQuoteText(JFMT_PAGE, applicant.getQuoteNumber(), fsa, true);
        fsa.assertAll("Validate Content of JFMT Page Home Lob.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})
    public void testUnrepairedStructureKnockOutScreenHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.fillOutFMTPWithUnrepairedStructureSelected(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, applicant.getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - Unrepaired structures on property");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})
    public void testBusinessOperatedOnPremisesKnockOutScreenHomeLob(ApplicantAceHome applicant) throws Exception {
        applicant.setBusinessOperatedOnPremises(true);
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.fillOutFMTPWithBusinessOperatedOnPremisesSelected(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, applicant.getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - Business operated on premises");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})
    public void testPetWithBiteHistoryKnockOutScreenHomeLob(ApplicantAceHome applicant) throws Exception {
        applicant.setPetWithBiteHistory(true);
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.fillOutFMTPWithPetWithBiteHistorySelected(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, applicant.getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - Pet bite history");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})
    public void testPlumbingOtherThanCopperPEXPVCKnockOutScreenHomeLob(ApplicantAceHome applicant) throws Exception {
        applicant.setPlumbingOtherThanCopperPexPVC(true);
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.fillOutFMTPWithPlumbingOtherThanCopperPEXPVCSelected(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, applicant.getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - Plumbing other than copper EXP PVC selected");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})
    public void testPrimaryHeatingSourceKnockOutScreenHomeLob(ApplicantAceHome applicant) throws Exception {
        applicant.setPrimaryHeatingSource("Space heater");
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.fillOutFMTPWithPrimaryHeatingSourceSelected(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, applicant.getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - Primary heating source");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME})
    public void testDogsOnPremisesKnockOutScreenHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.fillOutFMTPWithDogsOnPremisesSelected(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, applicant.getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - Dogs On Premises Selection");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})
    public void testKnockOutScreenWhenAllOtherQuestionsAreSelectedHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.fillOutFMTPWithAllOtherQuestionsSelected(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, applicant.getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - all other questions are selected");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO,attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})
    public void testContinueToBindWhenCantFindLenderSelectedHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.fillOutFMTPWithCantFindLenderSelected(fsa, applicant, HOME);
        fsa.assertAll("Validated - can continue to bind flow, when no lender found selected - Home.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_FORTIFIED_HOME_SECTION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_JAFMT_PAGE})
    public void validateDefaultValuesInFortifiedHomeSectionHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.validateFortifiedCertificateSectionVisibility(fsa);
        fsa.assertAll("Validated cert home default populated values in additional info and JFMT screens");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})
    public void testDataSaveWhenNavigatedBackAndForthJFMTPageHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicant, LOB_HOME, HOME);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.fillOutJustFewMoreThingsPage(applicant, true);
        AceHRCPaymentSelectionPage paymentSelectionPage = new AceHRCPaymentSelectionPage();
        paymentSelectionPage.waitForSpinnerToBeGone();
        Assert.assertTrue(paymentSelectionPage.isOnPaymentPage(), DID_NOT_REACH + "Ace Home - Payment Selection Page.");
        paymentSelectionPage.navigateBack();
        Assert.assertTrue(jfmtPage.isOnJFMTPage(false), DID_NOT_REACH + "Ace Home - JFMTP Page.");
        jfmtPage.validateJFMTPageSelections(applicant.getDogsOnPremises(),applicant,fsa);
        fsa.assertAll("Validate test data save on JFMT Page");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})
    public void testHomePurchaseDatePicker(ApplicantAceHome applicant) throws Exception {
        applicant.setNewlyOwned(true);
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.validatePastFutureDateOfHomePurchaseDatePicker(fsa, LOB_HOME);
        fsa.assertAll("Validate Home Purchase Date Picker for Past and Future date");
    }

}

