package com.farmers.ffq.auto.defaultcoverage;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class DefaultCoverageValuesTests_OR extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_15K30K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=No", "OR_15K30K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_15K30K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=Yes", "OR_15K30K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_20K40K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=No", "OR_20K40K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_20K40K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=Yes", "OR_20K40K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "OR_25K50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "OR_25K50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "OR_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "OR_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "OR_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "OR_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "OR_50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "OR_50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "OR_50K100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "OR_50K100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "OR_75K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "OR_75K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "OR_100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "OR_100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "OR_100K200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "OR_100K200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "OR_100K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "OR_100K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "OR_200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "OR_200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "OR_250K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "OR_250K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "OR_300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "OR_300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "OR_300K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "OR_300K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "OR_500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "OR_500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "OR_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "OR_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_500K1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "OR_500K1M_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_500K1M_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "OR_500K1M_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "OR_1M_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_1M_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "OR_1M_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_1M1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "OR_1M1M_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = OR)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OR_1M1M_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "OR_1M1M_");
    }

}
