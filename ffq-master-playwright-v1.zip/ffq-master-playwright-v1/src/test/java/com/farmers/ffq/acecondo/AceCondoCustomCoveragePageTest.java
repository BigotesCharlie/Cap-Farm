package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoCustomCoveragePage;
import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.CUSTOM_COVERAGE;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoCustomCoveragePageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_CUSTOM_COVERAGE_PAGE})
    public void customCoveragePageContentValidationCondoLob(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceCondoCustomCoveragePage customCoveragePageAceCondo = new AceCondoNavigationHelper().navigateToAceCondoCustomCoveragePage(applicantAceHome);
        AppStore appStore = customCoveragePageAceCondo.getSessionStorageAppStore();
        customCoveragePageAceCondo.validateQuoteProgressSavedContent(fsa);
        String reconstructionCost = appStore.getHome().getReconstructionCost();
        if (reconstructionCost != null) {
            if (!(Integer.parseInt(reconstructionCost) > THREELAKH)) {
                customCoveragePageAceCondo.validateCustomCoverageHeaderAndImage(fsa);
                customCoveragePageAceCondo.validateWhyHomeQualityGradeImportantSection(fsa);
                customCoveragePageAceCondo.validateBuildingInteriorInfoSection(fsa);
                customCoveragePageAceCondo.validateMainCoverageTextSection(fsa);
                customCoveragePageAceCondo.validateMainCoveragesValuesSection(fsa, appStore);
                customCoveragePageAceCondo.validateCustomCoverageEditCoverageAndQualityGradeLinkSection(fsa);
                customCoveragePageAceCondo.clickOnLearnMoreLinkOnCustomCoveragePage();
                customCoveragePageAceCondo.validateContentOfLearnMoreSideSheet(fsa);
                customCoveragePageAceCondo.clickOnEditCoveragesAndQualityGradeLink();
                customCoveragePageAceCondo.validateContentOfCoveragesAndGradeInCondo(fsa, appStore, true, applicantAceHome.getStateCode());
                customCoveragePageAceCondo.validateBrowserForwardButtonIsDisableAfterUpdatingCustomCoveragePage(fsa, CONDO);
                customCoveragePageAceCondo.validateDiscounts(CUSTOM_COVERAGE, applicantAceHome, CONDO, fsa);
                //validate Save Quote
                customCoveragePageAceCondo.validateSaveQuoteModal(true);
                //Quote number and Agent details at the bottom validation
                customCoveragePageAceCondo.validateQuoteText(CUSTOM_COVERAGE, applicantAceHome.getQuoteNumber(), fsa, true);
                customCoveragePageAceCondo.validateAgentSection(fsa, CUSTOM_COVERAGE, applicantAceHome.getAgentId(), CONDO);
            } else {
                KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
                knockoutInconveniencePage.validateHRCKnockOuts(fsa);
            }
            fsa.assertAll();
        }
    }
}
