package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;
import static com.farmers.ffq.utils.GlobalVariables.NV;

public class DefaultCoverageValuesTests_NV extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "NV_25K50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "NV_25K50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "NV_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "NV_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "NV_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "NV_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "NV_50K100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "NV_50K100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "NV_100K200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "NV_100K200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "NV_100K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "NV_100K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "NV_250K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "NV_250K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "NV_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "NV_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "NV_500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NV)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NV_500K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "NV_500K_");
    }

}
