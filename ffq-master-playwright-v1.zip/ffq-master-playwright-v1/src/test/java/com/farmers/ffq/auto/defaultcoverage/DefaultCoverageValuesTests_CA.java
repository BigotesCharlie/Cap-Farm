package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.ADPFApplicant;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.framework.annotation.Skip;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class DefaultCoverageValuesTests_CA extends DefaultCoverageBaseTest {

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = CA)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CA_None_Unk(AutoApplicant applicant) throws Exception {
        //This is going to avoid BW condition based on the foreign driver's license
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        defaultCoverageTestFor(applicant, "coverageAmount=None/Unk&umbrella=No", "CA_None_Unk_");
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"55"})}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CA_15K30K(ADPFApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=No", "CA_15K30K_");
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"56"})}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CA_20K40K(ADPFApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=No", "CA_20K40K_");
    }


    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"57"})}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CA_25K50K(ADPFApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "CA_25K50K_");
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"58"})}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CA_30K60K(ADPFApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "CA_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"59"})}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CA_35K70K(ADPFApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "CA_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"60"})}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CA_50K100K(ADPFApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "CA_50K100K_");
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"61"})}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CA_100K200K(ADPFApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "CA_100K200K_");
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"62"})}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CA_100K300K(ADPFApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "CA_100K300K_");
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"63"})}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CA_250K500K(ADPFApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "CA_250K500K_");
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"64"})}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CA_500K500K(ADPFApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "CA_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"65"})}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CA_500K(ADPFApplicant applicant) throws Exception {
        applicant.setLastName("Grace");
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "CA_500K");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_Non_ADPF_Defaults(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=NonAdpf&umbrella=No", "DEFAULT_NONADPF");
    }

}
