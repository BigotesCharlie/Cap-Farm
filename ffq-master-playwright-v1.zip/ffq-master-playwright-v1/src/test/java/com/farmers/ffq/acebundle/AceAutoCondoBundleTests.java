package com.farmers.ffq.acebundle;

import com.farmers.ffq.ace.hrc.common.*;
import org.testng.annotations.Test;

import com.farmers.ffq.ace.bundle.AceBundleNavigationHelper;
import com.farmers.ffq.ace.home.AceHomeReviewQuotePage;
import com.farmers.ffq.dataproviders.AceBundleDataProviders;
import com.farmers.ffq.datatransferobjects.AceBundleApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.annotation.Skip;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceAutoCondoBundleTests extends AceBundleTestHelper {

	@Skip
	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void aceAutoCondoBundleE2ETest(AceBundleApplicant bundleApplicant) throws Exception {
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		applicantAdjustment(bundleApplicant);
		AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceBundleNavigationHelper(AUTO_CONDO_BUNDLE).navigateToHRCReviewDwellingCoveragePage(bundleApplicant);
		if (dwellingCoveragePage.isOnDwellingCoveragePage()) {
			dwellingCoveragePage.scrollAndClickOnContinueButton();
		}
		farmersSoftAssert.assertTrue(new AceHomeReviewQuotePage().isOnReviewQuotePage(true), "HRC quote summary page reached");
		farmersSoftAssert.assertAll();
	}

	@Skip
	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceBundleCondoPropertyQuestionsPageContent(AceBundleApplicant bundleApplicant) throws Exception {
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		applicantAdjustment(bundleApplicant);
		AceHRCAddressBasePage homePropertyQuestionsPage = new AceBundleNavigationHelper(AUTO_CONDO_BUNDLE).navigateToAceHRCPropertyQuestionsPage(bundleApplicant);
		homePropertyQuestionsPage.verifyAutoHRCBundlePageContent(CONDO, bundleApplicant.getHrcApplicant(), farmersSoftAssert);
		farmersSoftAssert.assertAll();
	}
}
