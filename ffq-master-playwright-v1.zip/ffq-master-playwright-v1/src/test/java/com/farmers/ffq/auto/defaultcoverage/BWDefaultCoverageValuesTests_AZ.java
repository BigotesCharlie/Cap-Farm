package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class BWDefaultCoverageValuesTests_AZ extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = AZ)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_AZ_None_Unk(AutoApplicant applicant) throws Exception {
        //This is going to avoid BW condition based on the foreign driver's license
        randomizeApplicantPersonalData(applicant);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        //applicant.setFirstAgeForeignDriverLicense(0);
        defaultCoverageTestForBW(applicant, "coverageAmount=None/Unk&umbrella=No", "AZ_None_Unk_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_100K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100&umbrella=No", "AZ_100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_200K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=200&umbrella=No", "AZ_200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=300&umbrella=No", "AZ_300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500&umbrella=No", "AZ_500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_1000K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=1000&umbrella=No", "AZ_1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_50K100K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=50/100&umbrella=No", "AZ_50K100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_100K200K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/200&umbrella=No", "AZ_100K200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_100K300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/300&umbrella=No", "AZ_100K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_250K500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=250/500&umbrella=No", "AZ_250K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_500K500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/500&umbrella=No", "AZ_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_500K1000K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/1000&umbrella=No", "AZ_500K1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_25K50K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=25/50&umbrella=No", "AZ_25K50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_30K60K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=30/60&umbrella=No", "AZ_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AZ_35K70K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35/70&umbrella=No", "AZ_35K70K_");
    }

}
