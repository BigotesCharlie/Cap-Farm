package com.farmers.ffq.specialtyDwelling;

import static com.farmers.ffq.utils.GlobalVariables.AZ;
import static com.farmers.ffq.utils.GlobalVariables.EXCLUDED_STATES;
import static com.farmers.ffq.utils.GlobalVariables.EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES;
import static com.farmers.ffq.utils.GlobalVariables.MEDIA_ALPHA;
import static com.farmers.ffq.utils.GlobalVariables.OH;
import static com.farmers.ffq.utils.GlobalVariables.OR;
import static com.farmers.ffq.utils.GlobalVariables.PARTTIME;
import static com.farmers.ffq.utils.GlobalVariables.RENT;
import static com.farmers.ffq.utils.GlobalVariables.SHORTRENT_DWELLING;
import static com.farmers.ffq.utils.GlobalVariables.SPECIALTY_DWELLING;
import static com.farmers.ffq.utils.GlobalVariables.TX;
import static com.farmers.ffq.utils.GlobalVariables.UNOCCUPIED;
import static com.farmers.ffq.utils.GlobalVariables.UT;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.AutomationFramework;

public class AceHomeSpecialtyDwellingPartnerIntegrationTests extends AutomationFramework {

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {SPECIALTY_DWELLING})
	public void verifyMediaAlphaSpecialtyDwellingPropertyTypePageContent(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableMediaAlphaMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant).verifyDwellingTypePageContent(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {SPECIALTY_DWELLING})
	public void verifyMediaAlphaQuoteReviewPageContentParttime(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableMediaAlphaMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, PARTTIME).verifyQuoteReviewPage(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {SPECIALTY_DWELLING})
	public void verifyMediaAlphaQuoteReviewPageContentRenter(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableMediaAlphaMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, RENT).verifyQuoteReviewPage(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, OH, OR, TX, UT}), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {SPECIALTY_DWELLING}, enabled = false)
	public void verifyMediaAlphaQuoteReviewPageContentShortRenter(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableMediaAlphaMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, SHORTRENT_DWELLING).verifyQuoteReviewPage(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {SPECIALTY_DWELLING})
	public void verifyMediaAlphaQuoteReviewPageContentVacant(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableMediaAlphaMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant, UNOCCUPIED).verifyQuoteReviewPage(specialtyDwellingApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {SPECIALTY_DWELLING})
	public void verifyMediaAlphaExpectedDiscounts(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableMediaAlphaMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant).verifyDisplayOfExpectedDiscounts(specialtyDwellingApplicant);
		testStep("End Of Test");
	}

	private void enableMediaAlphaMode(ApplicantAceHome specialtyDwellingApplicant) {
		specialtyDwellingApplicant.setTestCategory(MEDIA_ALPHA);
	}
}
