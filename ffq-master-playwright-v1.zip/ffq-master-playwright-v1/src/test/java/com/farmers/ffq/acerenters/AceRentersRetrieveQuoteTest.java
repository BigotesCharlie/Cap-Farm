package com.farmers.ffq.acerenters;

import com.farmers.ffq.ace.condo.AceCondoContactInfoPage;
import com.farmers.ffq.ace.condo.AceCondoCustomCoveragePage;
import com.farmers.ffq.ace.hrc.common.AceHRCContactInfoBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCJustAFewMoreThingsBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.ace.renters.AceRentersJustAFewMoreThingsPage;
import com.farmers.ffq.ace.renters.AceRentersNavigationHelper;
import com.farmers.ffq.ace.renters.AceRentersReviewQuotePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersRetrieveQuoteTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_RETRIEVE_FLOW})
    public void testRetrieveNonRatedQuoteRenters(ApplicantAceHome applicant) throws Exception {
        new AceRentersNavigationHelper().navigateToAceRentersContactInfoPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);

        // Validate [Contact info] page
        AceHRCContactInfoBasePage contactInfoPage = new AceCondoContactInfoPage();
        Assert.assertTrue(contactInfoPage.isOnContactInfoPage(true), "Did not reach Contact info page - Renters.");
        fsa.assertEquals(contactInfoPage.getAceQuoteNumberInThePage(), applicant.getQuoteNumber(), "Contact info page - quote number match.");

        fsa.assertAll("Ace Renters - Retrieve non-rated quote.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_RETRIEVE_FLOW})
    public void testRetrieveRatedQuoteRenters(ApplicantAceHome applicant) throws Exception {
        AceRentersReviewQuotePage reviewQuotePage = new AceRentersNavigationHelper().navigateToAceRentersReviewQuotePage(applicant);
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePageAceRenters(), "Did not reach Review quote page - Renters");
        Map<String, String> coveragesBeforeRetrieve = reviewQuotePage.getExpectedCoverageAndCoverageAmountFromAppStoreRentersLob(applicant);
        reviewQuotePage.clickOnAddEditCoverageLinkButton();
        reviewQuotePage.editTheRentersCoveragesAndValidateContentOnMainPage(coveragesBeforeRetrieve, applicant.getStateCode());

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        coveragesBeforeRetrieve = reviewQuotePage.getCoverageNamesAndCoverageLimitsFromPage(RENTERS);
        String allPeril = reviewQuotePage.editDeductiblesSideSheet();
        String quotePrice = reviewQuotePage.getQuotePriceOnCard();
        List<String> discountsBeforeRetrieve = reviewQuotePage.getDiscounts();

        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);

        // Validate [Review quote] page
        reviewQuotePage = new AceRentersReviewQuotePage();
        fsa.assertTrue(reviewQuotePage.isSnackBarMessageDisplayed("Welcome back " + applicant.getFirstName()), "Welcome back snack bar message is displayed.");
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePageAceRenters(), "Did not reach Review quote page - Renters");
        fsa.assertEquals(reviewQuotePage.getQuotePriceOnCard() ,quotePrice, "Review quote page - quote premium after retrieval match.");
        reviewQuotePage.verifyQuotePresentmentCard(fsa);
        reviewQuotePage.clickPriceAlternative();
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        fsa.assertEquals(reviewQuotePage.getSortedList(reviewQuotePage.getDiscounts()), reviewQuotePage.getSortedList(discountsBeforeRetrieve),
                "Review quote page - quote discounts after retrieval match.");

        reviewQuotePage.selectStepper(ENTER_INFO);  // move back to the Contact info page, using stepper

        // Validate [Contact info] page
        AceHRCContactInfoBasePage contactInfoPage = new AceHRCContactInfoBasePage();
        Assert.assertTrue(contactInfoPage.isOnContactInfoPage(true), "Did not reach Contact info page - Renters.");
        contactInfoPage.validateContactInfoSelections(applicant, false, RENTERS, fsa);
        contactInfoPage.clickOnAgreeAndSubmitButton();

        // Validate [Review quote] page
        reviewQuotePage = new AceRentersReviewQuotePage();
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePageAceRenters(), "Did not reach Review quote page - Renters");
        reviewQuotePage.verifyQuotePresentmentCard(fsa);

        reviewQuotePage.validateAgentSection(fsa, REVIEW_QUOTE, applicant.getAgentId(), RENTERS);
        reviewQuotePage.validateQuoteText(REVIEW_QUOTE, applicant.getQuoteNumber(), fsa, true);

        Map<String, String> coveragesAfterRetrieve = reviewQuotePage.getCoverageNamesAndCoverageLimitsFromPage(RENTERS);
        fsa.assertEquals(coveragesAfterRetrieve, coveragesBeforeRetrieve, "Review quote page - Retrieve quote - coverages before and after retrieve match.");
        fsa.assertEquals(reviewQuotePage.getAllPerilDeductible(), allPeril, "Review quote page - Retrieve quote - All Peril deductible before and after retrieve match.");
        reviewQuotePage.validateDiscounts(REVIEW_QUOTE, applicant, RENTERS, fsa);
        List<String> discountsAfterRetrieve = contactInfoPage.getDiscounts().stream().sorted().collect(Collectors.toList());
        fsa.assertEquals(discountsAfterRetrieve, discountsBeforeRetrieve, "Review quote page - discounts before and after retrieval.");

        fsa.assertAll("Ace Renters - Retrieve rated quote.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_RETRIEVE_FLOW})
    public void testRetrieveRatedQuoteFromJFMTPageRenters(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceRentersReviewQuotePage hrcReviewQuoteBasePage = new AceRentersNavigationHelper().navigateToAceRentersReviewQuotePage(applicant);
        List<String> discountsBeforeRetrieve = hrcReviewQuoteBasePage.getDiscounts().stream().sorted().collect(Collectors.toList());
        String quotePrice = hrcReviewQuoteBasePage.getQuotePriceOnCard();
        hrcReviewQuoteBasePage.clickContinueButton();
        AceRentersJustAFewMoreThingsPage justAFewMoreThingsPage = new AceRentersJustAFewMoreThingsPage();
        Assert.assertTrue(justAFewMoreThingsPage.isOnJFMTPage(true),"Did not reach JFMT page");
        justAFewMoreThingsPage.fillOutFMTPWithDogsOnPremisesSelectedRentersLob(applicant, fsa, false);

        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);
        AceRentersReviewQuotePage reviewQuotePage = new AceRentersReviewQuotePage();
        // Validate RC2 screen is not displayed in retrieval flow.
        fsa.assertFalse(new AceCondoCustomCoveragePage().isOnRC2LoadingPage(2), "RC2 loading page is displayed after retrieving rated quote - " + RENTERS);
        fsa.assertTrue(reviewQuotePage.isSnackBarMessageDisplayed("Welcome back " + applicant.getFirstName()), "Welcome back snack bar message is displayed.");
        reviewQuotePage = new AceRentersNavigationHelper().goToAceRentersReviewQuotePage(applicant);
        fsa.assertEquals(reviewQuotePage.getQuotePriceOnCard(), quotePrice, "Review quote page - quote premium after retrieval match.");
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        fsa.assertEquals(reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList()), discountsBeforeRetrieve,
                "Review quote page - quote discounts after retrieval match.");

        reviewQuotePage.validateDefaultDeductibleAmount(fsa, applicant, "on quote retrieval");
        reviewQuotePage.clickContinueButton();
        Assert.assertTrue(justAFewMoreThingsPage.isOnJFMTPage(true), "Did not reach JFMT page.");
        justAFewMoreThingsPage.validateJFMTPageSelectionsRenters(applicant.getDogsOnPremises(), fsa);
        justAFewMoreThingsPage.clickContinueButton();
        // Validate RC3 screen in retrieval flow.
        justAFewMoreThingsPage.validateRC3LoadingScreen(fsa);
        fsa.assertAll("Ace Renters - Retrieve rated quote left from payment page");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_RETRIEVE_FLOW})
    public void testRetrieveRatedQuoteFromPaymentPageRenters(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceRentersNavigationHelper().navigateToAceRentersPaymentPage(applicant);
        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);
        AceRentersReviewQuotePage reviewQuotePage = new AceRentersReviewQuotePage();
        // Validate RC2 screen is not displayed in retrieval flow.
        fsa.assertFalse(new AceCondoCustomCoveragePage().isOnRC2LoadingPage(2), "RC2 loading page is displayed after retrieving rated quote - " + RENTERS);
        reviewQuotePage.waitForSkeletonToBeGone();
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePageAceRenters(), "Did not reach Review quote page - Renters");
        reviewQuotePage.clickOnContinueButton();
        AceHRCJustAFewMoreThingsBasePage aceHRCJustAFewMoreThingsBasePage = new AceHRCJustAFewMoreThingsBasePage();
        Assert.assertTrue(aceHRCJustAFewMoreThingsBasePage.isOnJFMTPage(true), "Did not reach JFMT page.");
        aceHRCJustAFewMoreThingsBasePage.clickContinueButton();
        aceHRCJustAFewMoreThingsBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        Assert.assertTrue(aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPageRenters(),"Did not reach Consolidated payment page - Renters");

        fsa.assertAll("Ace Renters - Retrieve rated quote left from payment page");
    }
}
