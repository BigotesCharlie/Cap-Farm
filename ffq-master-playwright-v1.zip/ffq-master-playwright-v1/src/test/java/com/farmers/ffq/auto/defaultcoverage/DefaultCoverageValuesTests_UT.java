package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.framework.annotation.Skip;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class DefaultCoverageValuesTests_UT extends DefaultCoverageBaseTest {
    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT25K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=No", "UT_25K65K_");
	}

    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT25K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=Yes", "UT_25K65K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "UT_30K60K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "UT_30K60K_");
	}

    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT30K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=No", "UT_30K65K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT30K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=Yes", "UT_30K65K_");
	}

    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "UT_35K70K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "UT_35K70K_");
	}

    @Skip//PASS
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT35K80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=No", "UT_35K80K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT35K80K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=Yes", "UT_35K80K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "UT_50K100K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "UT_50K100K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "UT_100K200K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "UT_100K200K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "UT_100K300K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "UT_100K300K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT150K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=No", "UT_150K300K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT150K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=Yes", "UT_150K300K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "UT_250K500K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "UT_250K500K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "UT_300K300K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "UT_300K300K_");
	}
    @Skip//PASS
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "UT_500K500K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "UT_500K500K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT500K1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "UT_500K1M_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT500K1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "UT_500K1M_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT1M1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "UT_1M1M_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT1M1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "UT_1M1M_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT35K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=No", "UT_35K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT35K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=Yes", "UT_35K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=No", "UT_45K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT45K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=Yes", "UT_45K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "UT_50K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT50K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "UT_50K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=No", "UT_60K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT60K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=Yes", "UT_60K_");
	}

    @Skip//PASS
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "UT_75K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT75K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "UT_75K_");
	}

    @Skip//PASS
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT85K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=No", "UT_85K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT85K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=Yes", "UT_85K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "UT_100K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "UT_100K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "UT_200K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "UT_200K_");
	}
    @Skip//PASS

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "UT_300K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "UT_300K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "UT_500K_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "UT_500K_");
	}

    @Skip//PASS
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "UT_1M_");
	}
    @Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT), @CustomAttribute(name= FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "UT_1M_");
	}

}
