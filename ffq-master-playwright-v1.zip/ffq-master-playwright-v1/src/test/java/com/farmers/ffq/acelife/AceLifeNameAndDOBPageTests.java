package com.farmers.ffq.acelife;

import static com.farmers.ffq.utils.GlobalVariables.ACE_LIFE_NAME_DOB_PAGE;
import static com.farmers.ffq.utils.GlobalVariables.AWS_SCENARIOS;
import static com.farmers.ffq.utils.GlobalVariables.FFQ_ACE_LIFE;

import java.util.Random;
import org.testng.annotations.Test;
import com.farmers.ffq.ace.life.AceLifeNameAndDOBPage;
import com.farmers.ffq.ace.life.AceLifeNavigationHelper;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantLife;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;

public class AceLifeNameAndDOBPageTests extends AutomationFramework {

	@Test(dataProvider = DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE, ACE_LIFE_NAME_DOB_PAGE})
	public void aceLifeNameAndDOBPageContentVerification(ApplicantLife applicant) throws Exception {
		if (new Random().nextBoolean()) {
			applicant.setId(AWS_SCENARIOS);
		}
		AceLifeNameAndDOBPage lifeNameAndDOBPage = new AceLifeNavigationHelper().navigateToAceLifeNameAndDOBPage(applicant);
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		lifeNameAndDOBPage.contentValidation(farmersSoftAssert);
		if (applicant.getId().equals(AWS_SCENARIOS)) {
			lifeNameAndDOBPage.validateTFNIsNotDisplayedInAgentFlow(farmersSoftAssert);
		}
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE, ACE_LIFE_NAME_DOB_PAGE})
	public void aceLifeNameAndDOBPageErrorValidation(ApplicantLife applicant) throws Exception {
		AceLifeNameAndDOBPage lifeNameAndDOBPage = new AceLifeNavigationHelper().navigateToAceLifeNameAndDOBPage(applicant);
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		lifeNameAndDOBPage.errorMessageValidation(farmersSoftAssert);
		farmersSoftAssert.assertAll();
	}
}
