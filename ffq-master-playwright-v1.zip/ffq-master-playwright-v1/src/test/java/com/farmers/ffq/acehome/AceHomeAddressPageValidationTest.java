package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.common.pages.FGIALandingPage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeAddressPageValidationTest extends AutomationFramework {

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDRESS_PAGE})
    public void testAddressPageHome(ApplicantAceHome applicant) throws Exception {
        validateAddressPage(applicant, HOME);
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})
    public void testAddressPageTownHome(ApplicantAceHome applicant) throws Exception {
        validateAddressPage(applicant, TOWNHOME);
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})
    public void testAddressPageDuplex(ApplicantAceHome applicant) throws Exception {
        validateAddressPage(applicant, DUPLEX);
    }

    private void  validateAddressPage(ApplicantAceHome applicant, String propertyType) throws Exception {
        AceHRCAddressBasePage addressPage = new AceHomeNavigationHelper().navigateToAceHomeAddressPage(applicant, LOB_HOME, propertyType);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        addressPage.validateQuoteSourceInd(fsa, applicant, HOME, ADDRESS_PAGE);
        addressPage.validatePageTitlesFooters(fsa, applicant, HOME);
        addressPage.validateAgentSection(fsa, AceHRCBasePage.ADDRESS_PAGE, applicant.getAgentId(), HOME);
        addressPage.validateQuoteText(AceHRCBasePage.ADDRESS_PAGE, applicant.getQuoteNumber(), fsa, false);
        addressPage.validatePageLinksText(fsa, ENTER_INFO);
        addressPage.validatePageFormFields(fsa, applicant, propertyType);
        addressPage.validatePageErrors(fsa, applicant);
        addressPage.validatePageLinksNavigationTitles(fsa);
        if (addressPage.getAddress().isBlank()) {
            addressPage.enterAddress(applicant);
        }
        addressPage.enterAvailableFields(applicant);
        addressPage.clickContinueButton();
        addressPage.waitForSpinnerToBeGone();

        AppStore appStore = addressPage.getSessionStorageAppStore();
        applicant.setAddress(appStore.getHome().getAddressForm().getFields().get(0).getAddress());

        String enteredAddress = appStore.getHome().getAddressForm().getFields().get(0).getAddress();
        String enteredCity = appStore.getHome().getAddressForm().getFields().get(0).getCity();
        String enteredStateCode = appStore.getHome().getAddressForm().getFields().get(0).getState();
        String enteredZip = appStore.getHome().getAddressForm().getFields().get(0).getZipCode();

        Log.info("Google Standardized Street Address: " + applicant.getAddress());
        AceHRCPropertyBasePage propertyBasePage = new AceHRCPropertyBasePage();
        if (propertyBasePage.isOnHRCPropertyBasePage(false)) {
            fsa.assertEquals(propertyBasePage.getPropertyAddress().toUpperCase(), enteredAddress.toUpperCase() + COMMA + SPACE + enteredCity.toUpperCase() + COMMA + SPACE +
                    enteredStateCode + SPACE + enteredZip, "Property page - Address, City, State, Zip match.");
            propertyBasePage.enterPropertyPageFields(applicant);
            propertyBasePage.clickContinueButton();
            propertyBasePage.waitForSpinnerToBeGone();
        }

        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        Assert.assertTrue(qualityGradePage.isOnQualityGradeOrPropertyDetailsAndQualityCombined(false), "Did not reach Property details and/or Quality grade page.");
        qualityGradePage.validateAddressOnQualityGradePage(fsa, propertyType);
        qualityGradePage.navigateBack();
        for (int i = 0; i < 3; i++) {
            if (addressPage.isOnAddressPage(false)) {
                break;
            }
            (new AceHRCBasePage()).navigateBack();
        }
        addressPage = new AceHRCAddressBasePage();
        fsa.assertEquals(addressPage.getAddress().toUpperCase(), enteredAddress.toUpperCase(), "Address page - Address Street match.");
        fsa.assertEquals(addressPage.getCity().toUpperCase(), applicant.getCity().toUpperCase(), "Address page - Address City match.");
        fsa.assertEquals(addressPage.getZipCode(), applicant.getZipCode(), "Address page - Address Zip code match.");
        addressPage.navigateBack();
        AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
        if (propertyTypePage.isOnPropertyTypePage()) {
            fsa.assertTrue(propertyTypePage.isImageCardSelected(propertyType), "Property Type page - " + propertyType + " Card is selected.");
        }
        fsa.assertAll("Validate Ace Home (" + propertyType + ") Address page.");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDRESS_PAGE})
    public void testAddressPageNonPrimaryResidence(ApplicantAceHome applicant) throws Exception {
        AceHRCAddressBasePage addressPage = new AceHomeNavigationHelper().navigateToAceHomeAddressPage(applicant, LOB_HOME, HOME);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        addressPage.enterAddress(applicant);
        addressPage.enterAvailableFields(applicant);
        addressPage.validateNonPrimaryResidence(fsa, applicant, HOME);
        fsa.assertAll("Validate Non-primary Residence Knock-out.");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL})
    public void testAddressPageTwoOrMorePropertyClaimsInLastThreeYearsHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCAddressBasePage addressPage = new AceHomeNavigationHelper().navigateToAceHomeAddressPage(applicant, LOB_HOME, HOME);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        addressPage.enterAddress(applicant);
        addressPage.enterAvailableFields(applicant);
        addressPage.validateTwoOrMorePropertyClaims(fsa, applicant, HOME);
        fsa.assertAll("Validate Two or more property claims in the last 3 years Knock-out.");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDRESS_PAGE})
    public void validateDataWhenNavigatedBackAndForthAddressPageHomeLob(ApplicantAceHome applicant) throws Exception {
        String DIFFERENT_ZIP = "20190";
        String YOUR_ZIP_CODE_WAS_RESET = "Your ZIP code was reset.";
        String ZIP_CODE_UPDATED = "ZIP Code updated!";

        AceHRCAddressBasePage addressPage = new AceHomeNavigationHelper().navigateToAceHomeAddressPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        addressPage.enterAddress(applicant);
        addressPage.enterAvailableFields(applicant);
        addressPage.navigateBack();
        AceHRCPropertyTypeBasePage aceHRCPropertyTypeBasePage = new AceHRCPropertyTypeBasePage();
        aceHRCPropertyTypeBasePage.selectPropertyType(HOME);
        aceHRCPropertyTypeBasePage.waitForSpinnerToBeGone();
        Assert.assertTrue(addressPage.isOnAddressPage(true), "Reached Address page 2nd time");
        addressPage.validateAddressPageFieldsNotSaved(fsa, HOME);

        addressPage.enterAddress(applicant);
        addressPage.enterAvailableFields(applicant);
        addressPage.clickContinueButton();
        addressPage.waitForSpinnerToBeGone();
        addressPage.navigateBack();
        Assert.assertTrue(addressPage.isOnAddressPage(true), "Reached Address page 3rd time");
        addressPage.validateAddressPageFieldsSaved(applicant, HOME, fsa);

        // validate zip change on the page and cleanup of the street and city fields
        // DE311054: Address (Street number and City) is not getting removed when updating zip to different state
        addressPage.enterZipCode(DIFFERENT_ZIP);
        addressPage.clickZipChangeYes();
        addressPage.waitForSpinnerToBeGone();
        fsa.assertTrue(addressPage.isSnackBarMessageDisplayed(ZIP_CODE_UPDATED), "Address page - Snack bar message Zip code updated displayed.");
        fsa.assertEquals(addressPage.getZipCode(), DIFFERENT_ZIP, "Address page - Zip code was updated after Yes is clicked.");
        fsa.assertEquals(addressPage.getAddress(), EMPTY_STRING, "Address page - Address field is cleared.");
        fsa.assertEquals(addressPage.getCity(), EMPTY_STRING, "Address page - City field is cleared.");
        addressPage.waitSnackBarMessageInvisible(8);
        addressPage.enterZipCode(applicant.getZipCode());
        addressPage.clickZipChangeGoBack();
        fsa.assertTrue(addressPage.isSnackBarMessageDisplayed(YOUR_ZIP_CODE_WAS_RESET), "Address page - Snack bar message Your Zip code was reset displayed.");
        fsa.assertEquals(addressPage.getZipCode(), DIFFERENT_ZIP, "Address page - Zip code was reset after Go back is clicked.");
        fsa.assertEquals(addressPage.getAddress(), EMPTY_STRING, "Address page - Address field is blank.");
        fsa.assertEquals(addressPage.getCity(), EMPTY_STRING, "Address page - City field is blank.");

        fsa.assertAll("Address page Home - Data is saved when navigated forward from the page, but not when navigated backward.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {MA, NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})
    public void testFGIANotOfferingValidationHomeLob(ApplicantAceHome applicant) throws Exception {
        applicant.setAgentId(null);
        AceHRCNavigationHelperBasePage aceHRCNavigationHelperBasePage = new AceHRCNavigationHelperBasePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        FGIALandingPage fgiaLandingPage = new FGIALandingPage();
        aceHRCNavigationHelperBasePage.processLandingPage(applicant, LOB_HOME);
        fgiaLandingPage.validateContentOfFGIAPopUp(fsa, HOME);
        if (fgiaLandingPage.isFgiaNoThanksButtonDisplayed()) {
            fgiaLandingPage.clickNoThanksButtonInFGIAPopUp();
            fgiaLandingPage.weAreNotAbleToCompleteQuotePageValidation(fsa, HOME);
        }
        fsa.assertAll("FGIA - Not offering validation Home");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {MA, NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})
    public void testFGIALandingPageValidationHomeLob(ApplicantAceHome applicant) throws Exception {
        applicant.setAgentId(null);
        AceHRCNavigationHelperBasePage aceHRCNavigationHelperBasePage = new AceHRCNavigationHelperBasePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        FGIALandingPage fgiaLandingPage = new FGIALandingPage();
        aceHRCNavigationHelperBasePage.processLandingPage(applicant, LOB_HOME);
        fgiaLandingPage.validateContentOfFGIAPopUp(fsa, HOME);
        fgiaLandingPage.clickContinueButtonInFGIAPopUp();
        fgiaLandingPage.fgiaIntroPageValidation(fsa, HOME);
        fsa.assertAll("FGIA - intro page validation Home");
    }

    /*
    Feature no - F88827 (Digital Monetization)
    */
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
        suiteName = AceHomeDataProviders.CATEGORY_DIGITAL_MONETIZATION_NON_AWS, attributes = {@CustomAttribute(name = DISABLED_STATES, values = {LA, NJ, DC, DE, HI, ME, MS, NH, RI, VT, WV, NY})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})
    public void testDigitalMonetizationValidationNonAWSHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCNavigationHelperBasePage aceHRCNavigationHelperBasePage = new AceHRCNavigationHelperBasePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceHRCNavigationHelperBasePage.processLandingPage(applicant, LOB_HOME);
        FGIALandingPage fgiaLandingPage = new FGIALandingPage();
        if (aceHRCNavigationHelperBasePage.isQnBState(applicant.getStateCode())) { // F103049 - US1140591 - QnB Redirection for Home LOB
            AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
            Assert.assertTrue(fwsInterstitialPage.isOnQnBSite(), "User did not navigate to QnB portal - Home LOB");
            fwsInterstitialPage.validateQnBUrl(fsa);
        } else if(applicant.getStateCode().equals(NY)){
            fgiaLandingPage.validateContentOfFGIAPopUp(fsa, HOME);
        } else {
            AceHRCCallForQuotePage callForQuotePage = new AceHRCCallForQuotePage();
            callForQuotePage.validateCallForQuotePageElements(fsa, EMPTY_STRING);
        }
        fsa.assertAll("Digital monetization - Call for Quote page validation - " + HOME);
    }
}

