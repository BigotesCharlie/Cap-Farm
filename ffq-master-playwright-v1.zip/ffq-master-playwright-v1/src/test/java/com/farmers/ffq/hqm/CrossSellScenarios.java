package com.farmers.ffq.hqm;

import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.legacy.DriversPage;
import com.farmers.ffq.auto.pages.legacy.VehiclesPage;
import com.farmers.ffq.auto.pages.legacy.YourInfoPageAuto;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.datatransferobjects.hqm.*;
import com.farmers.ffq.hqm.pages.DiscountsPage;
import com.farmers.ffq.hqm.pages.KnockOutPage;
import com.farmers.ffq.hqm.pages.ThankYouPage;
import com.farmers.ffq.hqm.pages.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.Property;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Arrays;

import static com.farmers.ffq.dataproviderframework.DataProviderBase.getListOfAceAutoStates;
import static com.farmers.ffq.utils.GlobalVariables.*;


/**
 * Farmers Fast Quote (FFQ) - Cross Sell Scenarios - Home Quote Modernization (HQM).
 */
public class CrossSellScenarios extends AutomationFramework {

    private static final double quoteDelta = 0.30; // quote price fluctuation delta max (5%) (used when no Postgres connection)

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW,
            groups = {HQM_CROSS_SELL, HQM_ALL})
    public void testCrossSellFromHQM(ApplicantHQM applicant) throws Exception {
        String browserType = DESKTOP_BROWSER;
        FarmersSoftAssert fsa = new FarmersSoftAssert();

//       Quote Start - Address Page
        AddressPage addressPage = new AddressPage(applicant, FC, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityGradePage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityGradePage.selectQualityGrade(applicant, propertyData);
        qualityGradePage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        discountsPage.setRequiredFields(applicant);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
//           Quote Page
            QuotePage quotePage = new QuotePage();
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            String monthlyPremium = quotePage.getQuotePremiumMonthly();
            quotePage.clickNext();

//           Thank You Page
            ThankYouPage thankYouPage = new ThankYouPage();
            PageLinksHQM thankYouPageLinks = new PageLinksHQM("thankYouPage", applicant.stateCode);
            thankYouPage.closeQualtricsPopUp();
            thankYouPage.validatePageLinks(thankYouPageLinks, quoteNumber, fsa);
            thankYouPage.validatePageValues(applicant, monthlyPremium, fsa, quoteRate);
            thankYouPage.validatePageTitles(applicant, browserType, fsa, staticContent);
            thankYouPage.validatePageFooters(applicant, browserType, fsa);
            assert quoteRate != null;
            validateCrossSellOptions(applicant, quoteRate.getYearlyPremium());
        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }
        fsa.assertAll();
    }

    private void validateCrossSellOptions(ApplicantHQM applicant, String yearlyPremium) throws Exception {
        String browserType = DESKTOP_BROWSER;
        ApiHelper apiHelper = new ApiHelper();
        CrossSellInfoHQM crossSellInfo = apiHelper.getCrossSellFromJson(applicant.quoteNumber);
        if ((crossSellInfo != null) && (!crossSellInfo.getCrossSellOptions().isEmpty())) {
            FarmersSoftAssert fsa = new FarmersSoftAssert();
            ThankYouPage thankYouPage = new ThankYouPage();
            thankYouPage.validatePageCrossSellTitles(fsa);
            for (CrossSellInfoHQM.CSOption csOption : crossSellInfo.getCrossSellOptions()) {
                Log.info("Selecting Cross Sell Option: " + csOption.getLabel());
                if (csOption.getLabel().equals(AUTO)) {
                    thankYouPage.selectCrossSellType(csOption.getLabel());
                    thankYouPage.clickStartSaving();
                    if (!getListOfAceAutoStates(Property.getUri()).contains(applicant.stateCode)) {
                        YourInfoPageAuto pageAuto = new YourInfoPageAuto();
                        fsa.assertEquals(pageAuto.getQuoteNumber(), applicant.quoteNumber, "Auto Quote - Quote number match.");
                        fsa.assertEquals(pageAuto.getFirstName(), applicant.firstName, "Auto Quote - Applicant First name.");
                        fsa.assertEquals(pageAuto.getLastName(), applicant.lastName, "Auto Quote - Applicant Last name.");
                        fsa.assertEquals(pageAuto.getDateOfBirth(), applicant.dateOfBirth, "Auto Quote - Applicant Date of birth.");
                        fsa.assertEquals(pageAuto.getAddress().toUpperCase(), applicant.addressApt, "Auto Quote - Applicant Address.");
                        fsa.assertEquals(pageAuto.getCity().toUpperCase(), applicant.city, "Auto Quote - Applicant City.");
                        fsa.assertEquals(pageAuto.getState(), applicant.state, "Auto Quote - Applicant State.");
                        fsa.assertEquals(pageAuto.getZipCode(), applicant.zipCode, "Auto Quote - Applicant Zip Code.");

                        // Continue HQM-to-Auto cross-sell validation
                        //
                        pageAuto.setCurrentlyInsured(true);
                        pageAuto.clickContinueToVehiclesPage();
                        VehiclesPage vehiclesPage = new VehiclesPage();
                        vehiclesPage.addAVehicle();
                        DriversPage driversPage = vehiclesPage.forwardToDriversPage();
                        driversPage.selectDriverToInsure(true);
                        applicant.gender = applicant.gender.isEmpty() ? MALE : applicant.gender;
                        fsa.assertEquals(driversPage.isMarried(), (Boolean) applicant.maritalStatus.equalsIgnoreCase("married"),
                                "Drivers Page - Drivers Marital Status match.");
                        if (driversPage.getOccupation() != null) {
                            fsa.assertEquals(driversPage.getOccupation(), applicant.occupation, "Drivers Page - Drivers Occupation match.");
                        }
                        driversPage.fillDriverInfo(applicant, true);
                        if (applicant.maritalStatus.equals(MARRIED)) {
                            driversPage.selectDriverToInsure(false);
                            if (applicant.spouseGender.isEmpty()) {
                                applicant.spouseGender = applicant.gender.isEmpty() || applicant.gender.equals(MALE) ? FEMALE : MALE;
                            }
                            driversPage.fillDriverInfo(applicant, false);
                        }
                        driversPage.clickContinueToNextPage();
                        //
                        fsa.assertEquals(driversPage.getEmailAddress(), applicant.emailAddress, "Additional Details Page - Email address match.");
                        fsa.assertTrue(driversPage.isEmailAddressDisabled(), "Additional Details Page - Email address is disabled.");
                        fsa.assertEquals(driversPage.getPhoneNumber().replaceAll("\\D", ""), applicant.phoneNumber, "Additional Details Page - Phone number match.");
                        fsa.assertTrue(driversPage.isPhoneNumberDisabled(), "Additional Details Page - Phone number is disabled.");
                        driversPage.clickAdditionalDetailsNextButton();

                        driversPage.assignCarsToDrivers();

                        com.farmers.ffq.auto.pages.legacy.DiscountsPage discountsPage = new com.farmers.ffq.auto.pages.legacy.DiscountsPage();
                        discountsPage.fillDiscountsInfo(fsa);
                        discountsPage.continueToQuotePage();

                        com.farmers.ffq.auto.pages.legacy.QuotePageAuto autoQuotePage = new com.farmers.ffq.auto.pages.legacy.QuotePageAuto();
                        Log.info("Auto Quote Summary page, quote number: " + applicant.quoteNumber,true);
                        autoQuotePage.validateHQMCrossSell(fsa);
                        autoQuotePage.clickOnHomeLob();

                        QuotePage quotePage = new QuotePage();
                        Assert.assertEquals(quotePage.getQuoteNumber(), applicant.quoteNumber, "HQM Quote Page - Linked to correct quote number.");
//                    sleep(2);
                        Log.info("HQM Quote Summary page, quote number: " + applicant.quoteNumber,true);
                        QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(applicant.quoteNumber, BASIC, 2);
                        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(applicant.quoteNumber);
                        quotePage.validatePageTitles(quoteRate, fsa, staticContent);
                        quotePage.validatePageFooters(applicant, staticContent);
                        quotePage.validatePolicyPerks(applicant);
                        quotePage.validatePageCardTitles(applicant, quoteRate, true, browserType, fsa);
                        quotePage.validateQuoteDiscounts(applicant, fsa, quoteRate);
                        quotePage.validateQuotePremiums(applicant, quoteRate, quoteDelta, fsa);
                        quotePage.validateAutoLobLink();
//                    Assert.assertFalse(quotePage.isEmailButtonDisplayed(), "Email button should not be displayed in cross-sell.");
                        Assert.assertFalse(quotePage.isPrintButtonDisplayed(), "Print button should not be displayed in cross-sell.");
                        quotePage.validateSubtitlesDiscountJourney(fsa);
                        quotePage.clickNext();
                    } else {
                        validateCrossSellHQMtoAutoRedesign(applicant, browserType, fsa);

                        // toggle back to HQM
                        validateToggleBackToHQM(applicant, yearlyPremium, fsa);
                        // toggle forth to Auto Redesign
                        validateToggleBackToAutoRedesign(applicant.quoteNumber, applicant.getFirstName(), fsa);
                        // toggle back to HQM
                        validateToggleBackToHQM(applicant, yearlyPremium, fsa);

                        (new QuotePage()).clickNext();
                        thankYouPage = new ThankYouPage();
                    }
//
                }            }
            fsa.assertAll("Validated Cross Sell Options.");
        }
    }

    @Skip
    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT, NV})},
            groups = {HQM_CROSS_SELL, HQM_ALL, FFQ_ONEUI})
    public void testCrossSellHQMToAutoAce(ApplicantHQM applicant) throws Exception {
        String browserType = DESKTOP_BROWSER;
        FarmersSoftAssert fsa = new FarmersSoftAssert();

//       Quote Start - Address Page
        AddressPage addressPage = new AddressPage(applicant, FC, browserType);
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityGradePage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityGradePage.selectQualityGrade(applicant, propertyData);
        qualityGradePage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        discountsPage.setRequiredFields(applicant);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
//           Quote Page
            QuotePage quotePage = new QuotePage();
            quotePage.closeQualtricsPopUp();
            Log.info("HQM Quote Summary page, quote number: " + quoteNumber,true);
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            ThankYouPage thankYouPage = new ThankYouPage();
            applicant.quoteRate = quotePage.getQuotePremiumYearly(applicant.stateCode);

            if(!Arrays.asList(CA).contains(applicant.stateCode)) {
                String monthlyPremium = quotePage.getQuotePremiumMonthly();
                quotePage.clickNext();
                thankYouPage.validatePageValues(applicant, monthlyPremium, fsa, quoteRate);
            } else {
                quotePage.clickNext();
            }

//           Thank You Page
            PageLinksHQM thankYouPageLinks = new PageLinksHQM("thankYouPage", applicant.stateCode);
            thankYouPage.closeQualtricsPopUp();
            thankYouPage.validatePageLinks(thankYouPageLinks, quoteNumber, fsa);

            thankYouPage.validatePageTitles(applicant, browserType, fsa, staticContent);
//            thankYouPage.validatePageFooters(applicant, quoteNumber, browserType);
            thankYouPage.validatePageCrossSellTitles(fsa);
            thankYouPage.selectCrossSellType(AUTO);
            thankYouPage.clickStartSaving();
            validateCrossSellHQMtoAutoRedesign(applicant, browserType, fsa);

            // toggle back to HQM
            assert quoteRate != null;
            validateToggleBackToHQM(applicant, quoteRate.getYearlyPremium(), fsa);

            // toggle forth to Auto Redesign
            validateToggleBackToAutoRedesign(quoteNumber, applicant.getFirstName(), fsa);

        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            Log.info("Knockout page, quote number: " + quoteNumber,true);
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }
        fsa.assertAll();
    }

    private void validateCrossSellHQMtoAutoRedesign(ApplicantHQM applicantHQM, String browserType, FarmersSoftAssert fsa) throws Exception {

        String crossSellUrl = driver().getCurrentUrl();
        Log.info("Cross-sell Url:: " + crossSellUrl);

        AutoApplicant autoApplicant = new AutoApplicant(applicantHQM, true);
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        nameAndDobPage.waitForSpinnerToBeGone();
        nameAndDobPage.isOnNameAndDobPage();
        fsa.assertEquals(nameAndDobPage.getFormFieldWebElementValue("First name"), autoApplicant.getFirstName(), "Name and Dob page - Applicant First name.");
        fsa.assertEquals(nameAndDobPage.getFormFieldWebElementValue("Last name"), autoApplicant.getLastName(), "Name and Dob page - Applicant Last name.");
        fsa.assertEquals(nameAndDobPage.getFormFieldWebElementValue("Date of birth"), autoApplicant.getDateOfBirth(), "Name and Dob page - Applicant Date of birth.");
        nameAndDobPage.clickContinueButton();

        AutoEnterAddressPage addressPage = new AutoEnterAddressPage();
        addressPage.waitForAutoEnterAddressPageToRender();
        String fullAddress = autoApplicant.getResidentAddress() + SPACE + autoApplicant.getCity() + ", " + autoApplicant.getStateCode() + " " + autoApplicant.getZipCode();
        fsa.assertEquals(addressPage.getAddressSubheading().toUpperCase(), fullAddress, "Name and Dob page - Applicant Home address.");
        //TODO: replace try-catch block to a one-liner assertion, once the field name is settled to either Unit number ot Apartment number
//        try {
//            String apartmentNumber = addressPage.getFormFieldWebElementValue("Apartment number");
//            sa.assertEquals(apartmentNumber, EMPTY_STRING, "Address page - Applicant Address Apartment number.");
//        } catch (NoSuchElementException e) {
//            Log.info("Ace Auto Address page - Apartment number field was not found, check for Unit number field instead.");
//            sa.assertEquals(addressPage.getFormFieldWebElementValue("Unit number"), EMPTY_STRING, "Address page - Applicant Address Unit number.");
//        }
        fsa.assertTrue(addressPage.isHomeOwnerChecked(), "Address page - Home owner checkbox is checked.");
        addressPage.clickContinueButton();

        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        whoShouldWeInsurePage.validatePageTitle();
        fsa.assertEquals(whoShouldWeInsurePage.getAceQuoteNumberInThePage(), applicantHQM.quoteNumber, "Who should we insure page - Quote number.");
        whoShouldWeInsurePage.addVehicles(autoApplicant);
        whoShouldWeInsurePage.addDisplayedDrivers(autoApplicant);
        whoShouldWeInsurePage.clickContinueButton();

        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        fsa.assertEquals(vehicleReviewPage.getAceQuoteNumberInThePage(), applicantHQM.quoteNumber, "Vehicles review page - Quote number.");
        vehicleReviewPage.validateVehiclesForCrossSell(autoApplicant, browserType, fsa);
        vehicleReviewPage.clickContinueButton();

        DriverReviewPage driverReviewPage = new DriverReviewPage();
        fsa.assertEquals(driverReviewPage.getAceQuoteNumberInThePage(), applicantHQM.quoteNumber, "Drivers review page - Quote number.");
        driverReviewPage.validateDriversAges(autoApplicant, fsa);
        driverReviewPage.validateOccupation(autoApplicant, fsa);
        driverReviewPage.validateMaritalStatus(autoApplicant, fsa);

        String applicantFullName = autoApplicant.getFirstName() + SPACE + autoApplicant.getLastName();
        driverReviewPage.enterDriverLicenseAge(autoApplicant, applicantFullName, autoApplicant.getFirstAgeUnitedStatesDriverLicense());
        driverReviewPage.addDriverLicenseNumber(autoApplicant, applicantFullName);
        for (int i = 0; i < autoApplicant.getAdditionalDrivers().size(); i++) {
            SqlAdditionalDriver sqlAdditionalDriver = autoApplicant.getAdditionalDrivers().get(i);
            String driverFullName = sqlAdditionalDriver.getFirstName() + SPACE + sqlAdditionalDriver.getLastName();
            driverReviewPage.enterDriverLicenseAge(autoApplicant, driverFullName, sqlAdditionalDriver.getFirstAgeUnitedStatesDriverLicense());
            driverReviewPage.addDriverLicenseNumber(autoApplicant, applicantFullName);
        }
        driverReviewPage.clickContinueButton();
        if(addressPage.isSignalDiscountDisabledState(applicantHQM.getStateCode())) {
            SignalPageOneUI signalPage = new SignalPageOneUI();
            if (signalPage.isOnSignalPage()) {
                String quoteNumber;
                int i = 3;
                do {
                    quoteNumber = signalPage.getAceQuoteNumberInThePage();
                    i--;
                } while (quoteNumber.isBlank() && (i > 0));
                fsa.assertEquals(quoteNumber, applicantHQM.quoteNumber, "Signal page - Quote number.");
                signalPage.processSignalPage(true);
            }
        }

        ContactInfoAutoPage contactInfo = new ContactInfoAutoPage();
        fsa.assertTrue(contactInfo.isOnContactInfoAutoPage(), "Contact Info page - Is on Contact Info page.");
        fsa.assertEquals(contactInfo.getAceQuoteNumberInThePage(), applicantHQM.quoteNumber, "Contact Info page - Quote number.");
        contactInfo.validatePrefilledValuesAndContinue(autoApplicant, fsa);

        QuoteSummaryAutoPage quoteSummaryPage = new QuoteSummaryAutoPage();
        quoteSummaryPage.waitForPageTitleAppear();
        Log.info("Auto Ace Quote Summary page, quote number: " + applicantHQM.quoteNumber,true);
        fsa.assertEquals(quoteSummaryPage.getAceQuoteNumberInThePage(), applicantHQM.quoteNumber, "Quote Summary page - Quote number.");
        quoteSummaryPage.validatePageTitle();
        quoteSummaryPage.validateVehicleCoverageTableTitle();
        quoteSummaryPage.validateLiabilityCoverageTableTitle();
        String premiumAmount = quoteSummaryPage.getPresentedPremiumAmount();
        Log.info("Auto Ace premium amount: " + premiumAmount);
        fsa.assertNotEquals(premiumAmount.split("/")[0].replaceAll("\\D", EMPTY_STRING).strip(), EMPTY_STRING,
                "Auto Ace Quote Summary page - Premium value is not blank.");
        fsa.assertTrue(quoteSummaryPage.isRoundedPresentedPremiumSumOfLiabilityAndVehicleCoveragePremium(),
                "Auto Ace Quote Summary page - Premium amount match to the Liability + Vehicles coverages.");
    }

    private void validateToggleBackToHQM(ApplicantHQM applicantHQM, String yearlyPremium, FarmersSoftAssert fsa) throws Exception {
        QuoteSummaryAutoPage quoteSummaryPage = new QuoteSummaryAutoPage();
        quoteSummaryPage.validateHqmToggleInMyQuotes(yearlyPremium, applicantHQM.quoteNumber, fsa);
        QuotePage quotePage = new QuotePage();
        Assert.assertEquals(quotePage.getQuoteNumber(), applicantHQM.quoteNumber, "HQM Quote Page - Linked to correct quote number.");
        Log.info("HQM Quote Summary page, quote number: " + applicantHQM.quoteNumber,true);
        ApiHelper apiHelper = new ApiHelper();
        QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(applicantHQM.quoteNumber, BASIC, 2);
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(applicantHQM.quoteNumber);
        quotePage.validatePageTitles(quoteRate, fsa, staticContent);
        quotePage.validatePageCardTitles(applicantHQM, quoteRate, true, DESKTOP_BROWSER, fsa);
        quotePage.validateQuoteDiscounts(applicantHQM, fsa, quoteRate);
        quotePage.validateQuotePremiums(applicantHQM, quoteRate, quoteDelta, fsa);
        quotePage.validateAutoLobLink();
    }

    private void validateToggleBackToAutoRedesign(String quoteNumber, String name, FarmersSoftAssert fsa) throws Exception {
        QuotePage quotePageHQM = new QuotePage();
        quotePageHQM.toggleToAutoLob();

        QuoteSummaryAutoPage quoteSummaryPage = new QuoteSummaryAutoPage();
        quoteSummaryPage.isOnQuoteSummaryAutoPage();
        Log.info("Auto Ace Quote Summary page, quote number: " + quoteNumber,true);
        fsa.assertEquals(quoteSummaryPage.getAceQuoteNumberInThePage(), quoteNumber, "Auto Quote Summary page - Auto Quote number.");
        quoteSummaryPage.validatePageTitle();
        quoteSummaryPage.isSnackBarMessageDisplayed(String.format("Welcome back %s" , name));
        quoteSummaryPage.validateVehicleCoverageTableTitle();
        quoteSummaryPage.validateLiabilityCoverageTableTitle();
        String premiumAmount = quoteSummaryPage.getPresentedPremiumAmount();
        Log.info("Auto Ace premium amount: " + premiumAmount);
        fsa.assertNotEquals(premiumAmount.split("/")[0].replaceAll("\\D", EMPTY_STRING).strip(), EMPTY_STRING,
                "Auto Ace Quote Summary page - Premium value is not blank.");
        fsa.assertTrue(quoteSummaryPage.isRoundedPresentedPremiumSumOfLiabilityAndVehicleCoveragePremium(),
                "Auto Ace Quote Summary page - Premium amount match to the Liability + Vehicles coverages.");
    }

}
