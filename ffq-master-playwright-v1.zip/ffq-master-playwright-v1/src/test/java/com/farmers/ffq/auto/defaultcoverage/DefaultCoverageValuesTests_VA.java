package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;


import static com.farmers.ffq.utils.GlobalVariables.*;

public class DefaultCoverageValuesTests_VA extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "VA_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "VA_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_30K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=No", "VA_30K65K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_30K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=Yes", "VA_30K65K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "VA_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "VA_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_35K80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=No", "VA_35K80K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_35K80K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=Yes", "VA_35K80K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "VA_50K100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "VA_50K100K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "VA_100K200K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "VA_100K200K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "VA_100K300K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "VA_100K300K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_150K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=No", "VA_150K300K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_150K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=Yes", "VA_150K300K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "VA_250K500K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "VA_250K500K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "VA_300K300K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "VA_300K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "VA_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "VA_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_500K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "VA_500K1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_500K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "VA_500K1000K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_1000K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "VA_1000K1000K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_1000K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "VA_1000K1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_35K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=No", "VA_35K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_35K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=Yes", "VA_35K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=No", "VA_45K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_45K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=Yes", "VA_45K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=No", "VA_60K_");
    }

        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=Yes", "VA_60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "VA_75K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "VA_75K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_85K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=No", "VA_85K_");
    }

        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_85K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=Yes", "VA_85K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "VA_100K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "VA_100K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "VA_200K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "VA_200K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "VA_300K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "VA_300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "VA_500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "VA_500K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "VA_1000K_");
    }
        
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = VA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_VA_1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "VA_1000K_");
    }

}
