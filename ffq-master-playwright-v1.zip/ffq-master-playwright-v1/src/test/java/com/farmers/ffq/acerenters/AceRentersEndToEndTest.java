package com.farmers.ffq.acerenters;

import com.farmers.ffq.ace.condo.AceCondoContactInfoPage;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentSelectionPage;
import com.farmers.ffq.ace.renters.AceRentersJustAFewMoreThingsPage;
import com.farmers.ffq.ace.renters.AceRentersNavigationHelper;
import com.farmers.ffq.ace.renters.AceRentersReviewQuotePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersEndToEndTest extends AutomationFramework {
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {})
    public void testReviewQuotePagePresentmentCardRentersLob(ApplicantAceHome applicant) throws Exception {
        applicant.setFirstName(PRODUCTION_APPLICANT_FIRST_NAME);
        applicant.setLastName(PRODUCTION_APPLICANT_LAST_NAME);
        applicant.setEmailAddress(PRODUCTION_APPLICANT_EMAIL);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceRentersReviewQuotePage reviewQuotePage = new AceRentersNavigationHelper().navigateToAceRentersReviewQuotePage(applicant);

        String personalPropertyValue = reviewQuotePage.getSessionStorageAppStore().getHome().getCoverageForPackage("C", "EFT").getCvgInfoForCvgDesc("Personal property").getCvgAmt();
        fsa.assertEquals(reviewQuotePage.getPageSubtitle(), reviewQuotePage.getPageSubtitle(personalPropertyValue), "Review quote page - Subtitle is displayed.");

        reviewQuotePage.verifyQuotePresentmentCard(fsa);
        reviewQuotePage.validateEmailThisQuoteLink(applicant, fsa);
        reviewQuotePage.validateAgentSection(fsa, REVIEW_QUOTE, applicant.getAgentId(), RENTERS);
        reviewQuotePage.validateQuoteText(REVIEW_QUOTE, applicant.getQuoteNumber(), fsa, true);
        fsa.assertAll("Validate Ace Renters Review Quote page - Quote Presentment Card.");

    }

    @Test(dataProvider = AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,TX,LA,MA,MS,NC})}, groups = {PRODUCTION_VALIDATION}) // FFQ_ACE_RENTERS
    public void testProdRetrieveRatedQuoteAceRenters(ApplicantAceHome applicant) throws Exception {
        (new AceHRCBasePage()).updateApplicantForProdValidation(applicant);

        AceRentersReviewQuotePage reviewQuotePage = new AceRentersNavigationHelper().navigateToAceRentersReviewQuotePage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        reviewQuotePage.validatePageLinksText(fsa, REVIEW_QUOTE);
        reviewQuotePage.validatePageLinksNavigationTitles(fsa);
        testStep("Verified quote rating and page links work on Review quote page.", true);

        reviewQuotePage.editDeductiblesSideSheet();
        reviewQuotePage = new AceRentersNavigationHelper().goToAceRentersReviewQuotePage(applicant);
        String quotePrice = reviewQuotePage.getQuotePriceOnCard();
        List<String> discountsBeforeRetrieve = reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList());
        testStep("Verified quote is rated and re-rated on Review quote page.", true);

        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);

        // Validate [Review quote] page
        reviewQuotePage = new AceRentersReviewQuotePage();
        fsa.assertTrue(reviewQuotePage.isSnackBarMessageDisplayed("Welcome back " + applicant.getFirstName()), "Welcome back snack bar message is displayed.");
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePageAceRenters(), "Did not reach Review quote page - Renters");
        testStep("Verified rated quote is retrieved on Review quote page.", true);

        fsa.assertEquals(reviewQuotePage.getQuotePriceOnCard(), quotePrice, "Review quote page - quote premium after retrieval match.");
        reviewQuotePage.verifyQuotePresentmentCard(fsa);
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        fsa.assertEquals(reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList()), discountsBeforeRetrieve,
                "Review quote page - quote discounts after retrieval match.");
        reviewQuotePage.selectStepper(ENTER_INFO);  // move back to the Contact info page, using stepper

        // Validate [Contact info] page
        AceCondoContactInfoPage contactInfoPage = new AceCondoContactInfoPage();
        Assert.assertTrue(contactInfoPage.isOnContactInfoPage(true), "Did not reach Contact info page - Renters.");
        contactInfoPage.validateContactInfoSelections(applicant, true, RENTERS, fsa);
        contactInfoPage.clickOnAgreeAndSubmitButton();

        // Validate [Review quote] page
        reviewQuotePage = new AceRentersNavigationHelper().goToAceRentersReviewQuotePage(applicant);
        reviewQuotePage.verifyQuotePresentmentCard(fsa);
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        reviewQuotePage.validateDiscounts(REVIEW_QUOTE, applicant, RENTERS, fsa);
        List<String> discountsAfterRetrieve = reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList());
        fsa.assertEquals(discountsAfterRetrieve, discountsBeforeRetrieve, "Review quote page - discounts before and after retrieval.");
        testStep("Verified quote retrieval and navigation back to Enter Info and forth to Review quote page.", true);

        // Validate Bind flow
        reviewQuotePage.clickOnContinueButton();

        AceRentersJustAFewMoreThingsPage aceRentersJustAFewMoreThingsPage = new AceRentersJustAFewMoreThingsPage();
        aceRentersJustAFewMoreThingsPage.fillOutJustFewMoreThingsPageRentersLob(applicant);

        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
        Assert.assertTrue(aceHRCPaymentSelectionPage.isOnPaymentPage(), "Did not reach Payment selection page: " + RENTERS);
        aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayCardLabelRenters();

        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        fsa.assertTrue(aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPageRenters(), "Reached to the Consolidated Payment page.");
        testStep("Verified quote bind flow up to Ace Renters Payment page.", true);

        fsa.assertAll("Ace Renters - Prod Retrieve rated quote.");
    }
}
