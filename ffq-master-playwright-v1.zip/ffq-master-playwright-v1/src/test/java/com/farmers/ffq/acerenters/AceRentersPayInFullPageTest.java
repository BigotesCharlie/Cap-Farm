package com.farmers.ffq.acerenters;

import com.farmers.ffq.ace.hrc.common.AceHRCConsolidatedPaymentPage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.ace.renters.AceRentersNavigationHelper;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.MONTHLY_AUTOPAY;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersPayInFullPageTest  extends AutomationFramework {

    // Test case add bank payment, validate content after adding bank payment and validate eCheckout page - Pay in full
    // excluding KY, LA, MA, MS, NC, as they are monetized and still do not use Consolidated payment page
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MT,MO,UT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL})
    public void validatePaymentByChangingPayInFullBankToMonthlyPayCardAceRenters(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceRentersNavigationHelper().navigateToAceRentersPaymentPage(applicantAceHome);
        AceHRCConsolidatedPaymentPage aceHRCConsolidatedPaymentPage = new AceHRCConsolidatedPaymentPage();
        // This is the new method for consolidated payment page
        aceHRCConsolidatedPaymentPage.selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
        aceHRCConsolidatedPaymentPage.clickBankPaymentRadioButton();
        aceHRCConsolidatedPaymentPage.validateBankAccountAdditionRenters(fsa, PAY_IN_FULL);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPagePayInFull(fsa, RENTERS);

        // Selecting different pay plan and proceeding with payment
        aceHRCConsolidatedPaymentPage.selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
        aceHRCPaymentBasePage.waitForSkeletonToBeGone();
        aceHRCConsolidatedPaymentPage.clickCardRadioButton();
        // This is the new method for consolidated payment page
        aceHRCConsolidatedPaymentPage.validateCreditCardPaymentRenters(fsa, MONTHLY_AUTOPAY, false);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, RENTERS);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, RENTERS);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, RENTERS);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, RENTERS);
        fsa.assertAll();
    }

    // Test case add credit card payment, validate content after adding bank payment and validate eCheckout page - Pay in full
    // excluding KY, LA, MA, MS, NC, as they are monetized and still do not use Consolidated payment page
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL})
    public void testPayInFullCreditCardEndToEndTestCaseAceRenters(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceRentersNavigationHelper().navigateToAceRentersPaymentPage(applicantAceHome);
        AceHRCConsolidatedPaymentPage aceHRCConsolidatedPaymentPage = new AceHRCConsolidatedPaymentPage();
        aceHRCConsolidatedPaymentPage.selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
        aceHRCConsolidatedPaymentPage.clickCardRadioButton();
        // This is the new method for consolidated payment page
        aceHRCConsolidatedPaymentPage.validateCreditCardPaymentRenters(fsa, PAY_IN_FULL, false);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPagePayInFull(fsa, RENTERS);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, RENTERS);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphPayInFull(fsa, RENTERS);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, RENTERS);
        fsa.assertAll();
    }
}
