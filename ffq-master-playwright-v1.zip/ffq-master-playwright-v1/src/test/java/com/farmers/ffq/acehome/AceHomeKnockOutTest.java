package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeContactInfoPage;
import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.home.AceHomeReviewQuotePage;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.common.pages.FGIALandingPage;
import com.farmers.ffq.common.pages.ForemostLandingPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;

import static com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage.DID_NOT_REACH;
import static com.farmers.ffq.ace.hrc.common.AceHRCPropertyDetailsBasePage.TYPE_OF_HOME;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeKnockOutTest extends AutomationFramework {
    // Need to find out address for all the states which has more than 1.5 M reconstruction cost
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_RECONSTRUCTION_COST_KO, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {IL})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})
    public void oneMillionReconstructionCostKnockOutValidation(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        AceHRCContactInfoBasePage contactInfoPage = new AceHomeNavigationHelper().navigateToAceHomeContactInfoPage(applicant, LOB_HOME, HOME);

        contactInfoPage.enterFireHydrantData(applicant);
        contactInfoPage.fillOutBundleAndSave(applicant, HOME);
        contactInfoPage.enterEmailIdAndPhoneNumberInContactInfoPage(applicant);
//        contactInfoPage.enterCommunicationConsent(applicant.getStateCode());
        contactInfoPage.clickOnAgreeAndSubmitButton();

        AppStore sessionStorageData = new AceHomeContactInfoPage().getSessionStorageAppStore();
        String reconstructionCost = sessionStorageData.getHome().getReconstructionCost();

        if (reconstructionCost != null) {
            if (!(Integer.parseInt(reconstructionCost) > ONE_POINT_FIVE_MILLION)) {
                AceHRCDwellingCoverageBasePage dwellingCoveragePageAceHome = new AceHRCDwellingCoverageBasePage();
                Assert.assertTrue(dwellingCoveragePageAceHome.isOnDwellingCoveragePage(), "Did not reach Dwelling coverage page.");
                dwellingCoveragePageAceHome.fillOutDwellingCoveragePage(applicant);
            } else {
//                KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
//                knockoutInconveniencePage.validateHRCKnockOuts(fsa);
                FGIALandingPage fgiLandingPage = new FGIALandingPage();
                fgiLandingPage.validateContentOfFGIAPopUp(fsa, HOME);
            }
            fsa.assertAll();
        }
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)},
            suiteName = AceHomeDataProviders.CATEGORY_UNFENCED_POOL_TRAMPOLINE, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_KNOCKOUT_FLOW})
    public void unfencedTrampolineSelectionKnockOutValidation(ApplicantAceHome applicantAceHome) throws Exception {
        AceHRCDwellingCoverageBasePage dwellingCoveragePageAceHome = new AceHomeNavigationHelper().navigateToAceHomeDwellingCoveragePage(applicantAceHome, LOB_HOME, HOME);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        dwellingCoveragePageAceHome.clickContinueButton();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        Assert.assertTrue(knockoutInconveniencePage.isOnKnockOutPage(), "Did not reach Knock-out page.");
        knockoutInconveniencePage.validateHRCKnockOuts(fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)},
            suiteName = AceHomeDataProviders.CATEGORY_RECONSTRUCTION_COST_KO, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})
    public void propertyTypeKnockOutOther(ApplicantAceHome applicantAceHome) throws Exception {

        AceHRCPropertyTypeBasePage aceHRCPropertyTypeBasePage = new AceHomeNavigationHelper().navigateToAceHomePropertyTypePage(applicantAceHome);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(aceHRCPropertyTypeBasePage.isPageTitleDisplayed(), "Property Type page - Page title is displayed.");
        aceHRCPropertyTypeBasePage.selectPropertyType(OTHER);
        if(List.of(AR, AL).contains(applicantAceHome.getStateCode())){
            KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
            if (koPage.isOnKnockOutPage()) {
                koPage.validateKnockOutForNotOffering(fsa);
                fsa.assertTrue(koPage.isOnKnockOutPage(), "Property Type page - Page title is displayed.");
            } else {
                Log.info("Did not reach Ace Home KO page for Property type - Other.", true);
                fsa.assertFalse(koPage.isOnKnockOutPage(),"Did not reach Ace Home KO page for Property type - Other.");
                fsa.fail();
            }
        } else {
            ForemostLandingPage foremostLandingPage = new ForemostLandingPage();
            foremostLandingPage.validateContentOfContinueWithForeMostScreen(fsa, HOME);
            foremostLandingPage.validateURLAfterClickingOnContinueWithForeMostButton(fsa, OTHER, HOME);
        }
        fsa.assertAll("Validate Ace Home Property Type page - Other navigation");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)},
            suiteName = AceHomeDataProviders.CATEGORY_RECONSTRUCTION_COST_KO, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW}, enabled = false)
    public void propertyTypeKnockOutMobileManufactured(ApplicantAceHome applicantAceHome) throws Exception {

        AceHRCPropertyTypeBasePage aceHRCPropertyTypeBasePage = new AceHomeNavigationHelper().navigateToAceHomePropertyTypePage(applicantAceHome);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(aceHRCPropertyTypeBasePage.isPageTitleDisplayed(), "Property Type page - Page title is displayed.");
        aceHRCPropertyTypeBasePage.selectPropertyType(MOBILE_MANUFACTURED_HOME);
        if(List.of(AR, AL).contains(applicantAceHome.getStateCode())){
            KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
            if (koPage.isOnKnockOutPage()) {
                koPage.validateKnockOutForNotOffering(fsa);
                fsa.assertTrue(koPage.isOnKnockOutPage(), "Property Type page - Page title is displayed.");
            } else {
                Log.info("Did not reach Ace Home KO page for Property type - Other.", true);
                fsa.assertFalse(koPage.isOnKnockOutPage(),"Did not reach Ace Home KO page for Property type - Mobile Manufactured.");
                fsa.fail();
            }
        }else {
            ForemostLandingPage foremostLandingPage = new ForemostLandingPage();
            foremostLandingPage.validateContentOfContinueWithForeMostScreen(fsa, HOME);
            foremostLandingPage.validateURLAfterClickingOnContinueWithForeMostButton(fsa, MOBILE_MANUFACTURED_HOME, HOME);
        }
        fsa.assertAll("Validate Ace Home Property Type page - Mobile Manufactured home navigation");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)},
            suiteName = AceHomeDataProviders.CATEGORY_FOUNDATIONTYPE_KO,groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})
    public void testFoundationTypeDeepPilingsKnockout(ApplicantAceHome applicantAceHome) throws Exception {

        AceHRCDwellingCoverageBasePage aceHRCDwellingCoverageBasePage = new AceHomeNavigationHelper().navigateToAceHomeDwellingCoveragePage(applicantAceHome,LOB_HOME,HOME);
        Log.info("Applicant reached to Dwelling Coverage Page ", true);
        aceHRCDwellingCoverageBasePage.clickContinueButton();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
        if (koPage.isOnKnockOutPage()) {
            koPage.validateKnockOutOnSelectingFoundationTypeDeepPilings(fsa);
            Log.info("Ace Home Foundation Type KO page - Deep Pilings ", true);
        } else {
            Log.info("Did not reach Ace Home KO page ", true);
            fsa.fail();
        }
        fsa.assertAll("Validate Ace Home Foundation Type Deep Pilings KO - The property has a foundation type that isn't eligible for coverage.");
    }
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)},
            suiteName = AceHomeDataProviders.CATEGORY_PPC_FIRE_HYDRANT_KO, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})
    public void ppcFireHydrantKO(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceHomeNavigationHelper().navigateToAceHomeDwellingCoveragePage(applicantAceHome, LOB_HOME, HOME);
        dwellingCoveragePage.clickContinueButton();
        KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
        if (koPage.isOnKnockOutPage()) {
            koPage.policyExclusionKOValidation(fsa);
            Log.info("Ace Home PPC Fire hydrant KO ", true);
        } else {
            Log.info("Did not reach Ace Home KO page ", true);
            fsa.fail();
        }
        fsa.assertAll("Validate Ace Home PPC Fire hydrant KO");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)},
            suiteName = AceHomeDataProviders.CATEGORY_PPC_ZIP_MISMATCH_KO, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})
    public void ppcZipMismatchKO(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCContactInfoBasePage contactInfoPage = new AceHomeNavigationHelper().navigateToAceHomeContactInfoPage(applicantAceHome, LOB_HOME, HOME);
        contactInfoPage.fillOutContactInfoPage(applicantAceHome, HOME);
        FGIALandingPage fgiaLandingPage = new FGIALandingPage();
        fgiaLandingPage.validateContentOfFGIAPopUp(fsa, HOME);
        if (fgiaLandingPage.isFgiaNoThanksButtonDisplayed()) {
            fgiaLandingPage.clickNoThanksButtonInFGIAPopUp();
            fgiaLandingPage.weAreNotAbleToCompleteQuotePageValidation(fsa, HOME);
        }
        fsa.assertAll("Validate Ace Home PPC Zip mismatch KO");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA, MO, PA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})
    public void testPropertyTypeDuplexNonPrimaryResidenceKnockOut(ApplicantAceHome applicantAceHome) throws Exception {
        AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
        AceHRCAddressBasePage addressPage = navigator.navigateToAceHomeAddressPage(applicantAceHome, LOB_HOME, DUPLEX);
        final String EXPECTED_KNOCKOUT_ERROR_CODE = "NOTPRIMRESKO";
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        addressPage.enterAddress(applicantAceHome);
        addressPage.enterAvailableFields(applicantAceHome);
        addressPage.selectPrimaryResidence(false);
        navigator.setResumeFromPage(AceHRCBasePage.ADDRESS_PAGE);
        navigator.navigateToAceHomeContactInfoPage(applicantAceHome, LOB_HOME, DUPLEX);
        AceHomeContactInfoPage contactInfoPage = new AceHomeContactInfoPage();
        contactInfoPage.fillOutContactInfoPage(applicantAceHome, HOME);
        contactInfoPage.waitForSpinnerToBeGone();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutForNotOffering(fsa);
        fsa.assertTrue(knockoutInconveniencePage.getAllKnockOutErrorCodes().contains(EXPECTED_KNOCKOUT_ERROR_CODE), EXPECTED_KNOCKOUT_ERROR_CODE + " Knockout error code returned.");
        fsa.assertAll("Validate property type Duplex, and non primary residence KO");
    }

    // F82552: Wind/Hail Exclusion Knockout Validation
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)},
            suiteName = AceHomeDataProviders.CATEGORY_POLICY_EXCLUSION, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})
    public void testPolicyExclusionKnockout(ApplicantAceHome applicant) throws Exception {

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceHomeNavigationHelper().navigateToAceHomeDwellingCoveragePage(applicant, LOB_HOME, HOME);
        Assert.assertTrue(dwellingCoveragePage.isOnDwellingCoveragePage(), DID_NOT_REACH + "DwellingCoveragePage");
        dwellingCoveragePage.clickContinueButton();
        dwellingCoveragePage.waitForSpinnerToBeGone();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeReviewQuotePage();
        Assert.assertTrue(reviewQuotePage.isPolicyExclusionPopUpDisplayed(), "Policy exclusion pop up not displayed");
        reviewQuotePage.clickCancelOnPolicyExclusionPopup();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        Assert.assertTrue(knockoutInconveniencePage.isOnKnockOutPage(), "Did not reach Knock-out page.");
        knockoutInconveniencePage.policyExclusionKOValidation(fsa);
        fsa.assertAll("Validate Ace Home Policy Exclusion Knockout");
    }

    // F92439 : Optimization - FFQ Funnel Analysis and Improvements - PI38
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})
    public void propertyTypeKnockOutFromPropertyDetailsSideSheet(ApplicantAceHome applicantAceHome) throws Exception {

        AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHomeNavigationHelper().navigateToAceHomePropertyDetailsPage(applicantAceHome, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(propertyDetailsPage.isPageTitleDisplayed(), "Property Type page - Page title is displayed.");
        propertyDetailsPage.enterNotPrefilledPropertyDetails(applicantAceHome);
        propertyDetailsPage.clickEditDetailsButton();
        propertyDetailsPage.clickEditModalPropertyDetailsFieldEditButton(TYPE_OF_HOME);
        propertyDetailsPage.selectEditModalRadioButtonByName(OTHER);
        propertyDetailsPage.clickUpdatePropertyDetail(TYPE_OF_HOME, true);
        propertyDetailsPage.pressEscKey();
        propertyDetailsPage.clickContinueButton();
        propertyDetailsPage.waitForSpinnerToBeGone();
        KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
        Assert.assertTrue(koPage.isOnKnockOutPage(), "Did not reach Knock-out page.");
        koPage.validateKnockOutForNotOffering(fsa);
        fsa.assertAll("Validate Ace Home Property details page - Type of home knock out");
    }

    // Unacceptable Roof Knockout Validation
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_UNACCEPTABLE_ROOF_KO, attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})
    public void validateUnacceptableRoofKO(ApplicantAceHome applicantAceHome) throws Exception {

        AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceHomeNavigationHelper().navigateToAceHomeDwellingCoveragePage(applicantAceHome, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        Assert.assertTrue(dwellingCoveragePage.isOnDwellingCoveragePage(), DID_NOT_REACH + "DwellingCoveragePage");
        dwellingCoveragePage.clickContinueButton();
        dwellingCoveragePage.waitForSpinnerToBeGone();
        KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
        Assert.assertTrue(koPage.isOnKnockOutPage(), "Did not reach Knock-out page.");
        koPage.verifyUnableToCompleteOnlineKnockout(applicantAceHome, fsa);
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeReviewQuotePage();
        String unacceptableRoofKOCode = reviewQuotePage.getSessionStorageAppStore().getKnockouts().get(0).getKnockoutCode();
        fsa.assertEquals(unacceptableRoofKOCode, "HORT0165", "Unacceptable Roof KO code mismatch.");

        fsa.assertAll("Validate Unacceptable Roof Knockout");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_PRE_BIND_CONTINGENCY_KO, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MN})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_KNOCKOUT_FLOW})
    public void validatePreBindContingencyKO(ApplicantAceHome applicantAceHome) throws Exception {

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHomeNavigationHelper().navigateToAceHomeJustAFewMoreThingsPage(applicantAceHome, LOB_HOME, HOME);
        jfmtPage.fillOutJustFewMoreThingsPage(applicantAceHome, true);
        KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
        Assert.assertTrue(koPage.isOnKnockOutPage(), "Did not reach Knock-out page.");
        List<String> actualKOCodes = jfmtPage.getKnockoutCodes();
        List<String> expectedKOCodes = jfmtPage.prebindContingencyKOCode(applicantAceHome);
        fsa.assertEquals(actualKOCodes, expectedKOCodes, "Pre-bind contingency KO codes mismatch.");
        fsa.assertAll("Pre-bind contingency Knockout validation");
    }
}
