package com.farmers.ffq.acebusiness;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.Random;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.ace.business.AceBusinessNavigationHelper;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantBusiness;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;

public class AceBusinessPageValidationTests extends AutomationFramework {

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER, testName = LOB_BUSINESS,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = REGRESSION)
	public void verifyBusinessLeadFormContent(ApplicantBusiness businessApplicant) throws Exception {
		if (new Random().nextBoolean()) {
			businessApplicant.setBusinessId(AWS_SCENARIOS);
		}
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new AceBusinessNavigationHelper().navigateToBusinessInsuranceLeadForm(businessApplicant).verifyPageContent(fsa, businessApplicant);;
		fsa.assertAll();
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ONE_BUSINESS_APPLICANT_DATA_PROVIDER, testName = LOB_BUSINESS,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, groups = REGRESSION)
	public void validateBusinessLeadFormErrorHandling(ApplicantBusiness businessApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new AceBusinessNavigationHelper().navigateToBusinessInsuranceLeadForm(businessApplicant).validatePageErrors(fsa, businessApplicant);;
		fsa.assertAll();
	}
}
