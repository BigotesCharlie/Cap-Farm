package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoCustomCoveragePage;
import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.condo.AceCondoReviewQuotePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyInfoBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCQualityGradeBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoReviewQuotePageTest extends AutomationFramework {
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_REVIEW_QUOTE_PAGE})
    public void testValidateReviewQuotePageAndRC2screenCondoLob(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceCondoCustomCoveragePage customCoveragePageAceCondo = new AceCondoNavigationHelper().navigateToAceCondoCustomCoveragePage(applicant);
        customCoveragePageAceCondo.fillOutCustomCoveragePageCondo(applicant);
        customCoveragePageAceCondo.clickOnContinueButton();
        customCoveragePageAceCondo.validateRC2LoadingScreen(fsa);

        (new AceCondoNavigationHelper()).goToAceCondoReviewQuotePage(applicant);
        AceCondoReviewQuotePage reviewQuotePage = new AceCondoReviewQuotePage();

        fsa.assertTrue(reviewQuotePage.isPageTitleInViewport(), "Review quote page - page title is in Viewport");
        reviewQuotePage.validateQuoteSourceInd(fsa, applicant, CONDO, REVIEW_QUOTE);
        reviewQuotePage.validateContentOfDeductiblesSection(fsa, CONDO);
        reviewQuotePage.clickEditDeductiblesLink();
        reviewQuotePage.validateContentOfDeductiblesSideSheet(fsa, CONDO);
        reviewQuotePage.validateContentOfCoverageSectionCondoLob(fsa, applicant, CONDO);
        reviewQuotePage.validateEditCoverageSideSheetCondoLob(fsa, applicant, CONDO);
        reviewQuotePage.validateYouGetAllTheseWithYourPolicySection(fsa, CONDO);

        String personalPropertyValue = reviewQuotePage.getSessionStorageAppStore().getHome().getCoverageForPackage("C", "EFT").getCvgInfoForCvgDesc("Personal property").getCvgAmt();
        fsa.assertEquals(reviewQuotePage.getPageSubtitle(), reviewQuotePage.getPageSubtitle(personalPropertyValue), "Property Details page - Subtitle is displayed.");

        reviewQuotePage.verifyQuotePresentmentCard(fsa);
        reviewQuotePage.validateContinueButtonAtPageBottom(fsa);
        reviewQuotePage.validateEmailThisQuoteLink(applicant, fsa);
        reviewQuotePage.validateDiscounts(REVIEW_QUOTE, applicant, CONDO, fsa);
        reviewQuotePage.validateQuoteText(REVIEW_QUOTE, applicant.getQuoteNumber(), fsa, true);
        reviewQuotePage.validateAgentSection(fsa, REVIEW_QUOTE, applicant.getAgentId(), CONDO);

        // F76803 - Validate RC2 screen is not displayed on navigating back from Review quote page to Custom coverage page and proceeding forward to Review quote page again without making any changes.
        reviewQuotePage.navigateBack();
        customCoveragePageAceCondo.clickOnContinueButton();
        fsa.assertFalse(new AceCondoCustomCoveragePage().isOnRC2LoadingPage(2), "RC2 loading page displayed in back and forth from Custom coverage page - " + CONDO);
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePage(true), "Review quote page is not displayed when clicked continue from custom coverage page - " + CONDO);

        // Moving to Quality Grade page using stepper
        reviewQuotePage.selectStepper(ENTER_INFO);
        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        if (reviewQuotePage.isNewFlowEnabledState(applicant.getStateCode())) {
            AceHRCPropertyInfoBasePage personalInfoPage = new AceHRCPropertyInfoBasePage();
            Assert.assertTrue(personalInfoPage.isOnPropertyInfoPage(false), "Clicked on Enter Info stepper but did not reach Property Info page");
            personalInfoPage.clickContinueButton();
        } else {
            Assert.assertTrue(qualityGradePage.isOnQualityGradeOrPropertyDetailsAndQualityCombined(false), "Clicked on Enter Info stepper but did not reach Quality grade page");
        }
        //Steppers are disabled after making any change on Quality Grade page
        qualityGradePage.updateExteriorValidateReviewQuoteAndPurchaseStepper(fsa);
        fsa.assertAll("Validate content of RC2 screen and Review quote page, then stepper navigation from quality grade page - Condo.");
    }
}
