package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;
import static com.farmers.ffq.utils.GlobalVariables.NM;

public class DefaultCoverageValuesTests_NM extends DefaultCoverageBaseTest {
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})

	public void testDefaultCoverageValues_NM_15K30K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=No", "NM_15K30K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_15K30K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=Yes", "NM_15K30K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_20K40K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=No", "NM_20K40K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_20K40K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=Yes", "NM_20K40K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "NM_25K50K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "NM_25K50K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "NM_30K60K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "NM_30K60K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "NM_35K70K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "NM_35K70K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "NM_50K100K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "NM_50K100K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "NM_100K200K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "NM_100K200K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "NM_100K300K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "NM_100K300K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No","NM_300K300K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "NM_300K300K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No","NM_250K500K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "NM_250K500K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "NM_500K500K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "NM_500K500K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_500K1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "NM_500K1M_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_500K1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "NM_500K1M_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_1M1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "NM_1M1M_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_1M1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "NM_1M1M_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "NM_50K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_50K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "NM_50K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "NM_75K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "NM_75K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "NM_100K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "NM_100K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "NM_200K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "NM_200K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "NM_300K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "NM_300K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "NM_500K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "NM_500K_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "NM_1M_");
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = NM)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_NM_1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "NM_1M_");
	}


}
