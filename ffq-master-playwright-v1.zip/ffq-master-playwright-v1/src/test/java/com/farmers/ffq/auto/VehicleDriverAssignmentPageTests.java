package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.auto.pages.VehicleDriverAssignmentPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.datatransferobjects.Vehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.annotation.Skip;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class VehicleDriverAssignmentPageTests extends BaseTest {

    private final static String VEHICLE_DRIVER_ASSIGNMENT = "vehicleDriverAssignment";

    private enum DriversToVehicleCount {DRIVERS_EQ_VEHICLES, DRIVERS_GT_VEHICLES, DRIVERS_LT_VEHICLES}

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=30"}), @CustomAttribute(name = CA)},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLE_DRIVER_ASSIGNMENT})
    public void testDriversEqualToVehicles(AutoApplicant applicant) throws Exception {
        setupDriversAndVehicles(applicant, DriversToVehicleCount.DRIVERS_EQ_VEHICLES);
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = navigateToVehicleDriverAssignmentPage(applicant);
        testStepAssertTrue(vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage(), "Navigate to VehicleDriverAssignment Page", true);
        //for each vehicle, select a random driver and check that it is unavailable for other vehicles
        for (int vehicle = 1; vehicle <= applicant.getVehicles().size(); vehicle++) {
            vehicleDriverAssignmentPage.selectARandomDriverForAVehicle(vehicle);
            testStepAssertTrue(vehicleDriverAssignmentPage.isSelectedDriverListedForOtherVehicles(vehicle, true), "Ensure selected driver for vehicle " + vehicle + " is unavailable for other vehicles.", true);
        }
        testStepAssertTrue(vehicleDriverAssignmentPage.saveAndCheckForNoErrors(), "Save and check for no errors");
        testStep("END OF TEST");
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=30"}), @CustomAttribute(name = CA)},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLE_DRIVER_ASSIGNMENT})
    public void testDriversGreaterThanVehicles(AutoApplicant applicant) throws Exception {
        setupDriversAndVehicles(applicant, DriversToVehicleCount.DRIVERS_GT_VEHICLES);
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = navigateToVehicleDriverAssignmentPage(applicant);
        testStepAssertTrue(vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage(), "Navigate to VehicleDriverAssignment Page", true);
        //for each vehicle, select a random driver and check that it is unavailable for other vehicles
        for (int vehicle = 1; vehicle <= applicant.getVehicles().size(); vehicle++) {
            vehicleDriverAssignmentPage.selectARandomDriverForAVehicle(vehicle);
            testStepAssertTrue(vehicleDriverAssignmentPage.isSelectedDriverListedForOtherVehicles(vehicle, true), "Ensure selected driver for vehicle " + vehicle + " is unavailable for other vehicles.", true);
        }
        boolean isNoErrorPresent = vehicleDriverAssignmentPage.saveAndCheckForNoErrors();
        testStepAssertTrue(isNoErrorPresent, "Save and check for no errors");
        testStep("END OF TEST");
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=4"}), @CustomAttribute(name = CA)},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLE_DRIVER_ASSIGNMENT})
    public void testDriversLessThanVehicles(AutoApplicant applicant) throws Exception {
        setupDriversAndVehicles(applicant, DriversToVehicleCount.DRIVERS_LT_VEHICLES);
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = navigateToVehicleDriverAssignmentPage(applicant);
        testStepAssertTrue(vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage(), "Navigate to VehicleDriverAssignment Page", true);
        int numberOfVehicles = applicant.getVehicles().size();
        //for each vehicle, select a random driver and check that it is available for other vehicles
        for (int vehicle = 1; vehicle <= numberOfVehicles; vehicle++) {
            vehicleDriverAssignmentPage.selectARandomDriverForAVehicle(vehicle);
            testStepAssertTrue(vehicleDriverAssignmentPage.isSelectedDriverListedForOtherVehicles(vehicle, false), "Ensure selected driver for vehicle " + vehicle + " is available for other vehicles.", true);
            vehicleDriverAssignmentPage.clickResetButton();
        }
        //This loop selects the same driver on all vehicles until it cannot, then it picks the next available one.
        for (int vehicle = 1; vehicle <= numberOfVehicles; vehicle++) {
            testStep("Selecting a driver for vehicle " + vehicleDriverAssignmentPage.selectASpecificDriverForAVehicle(vehicle, 0), true);
        }
        boolean isNoErrorPresent = vehicleDriverAssignmentPage.saveAndCheckForNoErrors();
        testStepAssertTrue(isNoErrorPresent, "Save and check for no errors");
        testStep("END OF TEST");
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=10"}), @CustomAttribute(name = CA)},
            dataProviderClass = AutoDataProviders.class, groups = {ADA_SUITE, FFQ_ONEUI, ACE_AUTO_ADA_SUITE, VEHICLE_DRIVER_ASSIGNMENT})
    public void pageContentAndErrorValidation(AutoApplicant applicant) throws Exception {
        applicant.getVehicles().forEach(vehicle -> vehicle.setParkInResidentAddress(true));
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = navigateToVehicleDriverAssignmentPage(applicant);
        testStepAssertTrue(vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage(), "Navigate to VehicleDriverAssignment Page", true);
        testStepAssertTrue(vehicleDriverAssignmentPage.isPageTitleCorrect(), "Validate page title", false);
        testStepAssertTrue(vehicleDriverAssignmentPage.isPageSubtitleCorrect(), "Validate page subtitle", false);
        testStepAssertTrue(vehicleDriverAssignmentPage.areNoDriversSelectedErrorMessagesPresent(), "Validate error message when no drivers are selected", true);
        //do following if ADA is not enabled
        if (!vehicleDriverAssignmentPage.isADATestingEnabled()) {
            testStepAssertTrue(vehicleDriverAssignmentPage.someDriversSelectedErrorMessagesPresent(applicant), "Validate error message when some drivers are selected", true);
            vehicleDriverAssignmentPage.clickResetButton();
            testStepAssertTrue(vehicleDriverAssignmentPage.areAllDriversListedOnAllSelectionDropdowns(applicant), "Ensure all drivers are listed on all vehicle dropdowns", false);
            testStepAssertTrue(vehicleDriverAssignmentPage.areAllVehiclesListedOnPage(applicant), "Ensure all vehicles are listed on page", false);
        }
        testStep("END OF TEST");
    }

    /**
     * Auto Scenario: 707 (Defect number: DE294866)
     * "Validate that user is able to land on next page up
     * (a)Initiate an Auto quote for VA & CA State
     * (b)Add 2 Vehicles and 1 Driver
     * (c)Select Personal on Vehicle review page
     * (d)Navigate till Vehicle Driver Assignment Page
     * (e)Select the same driver for both the vehicles
     * (f)Click on ""Save"" Button "
     *
     * @param applicant
     * @throws Exception
     */
    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=36"}), @CustomAttribute(name = INCLUDED_STATES, values = {VA, CA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLE_DRIVER_ASSIGNMENT})
    public void validatePageIsSubmittedWithFirstCTAClick(AutoApplicant applicant) throws Exception {
        applicant.getVehicles().forEach(vehicle -> {
            vehicle.setParkInResidentAddress(true);
            vehicle.setVehicleUsage("Personal");
            vehicle.setRidesharing(false);
        });
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = navigateToVehicleDriverAssignmentPage(applicant);
        vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
        vehicleDriverAssignmentPage.validateUserSuccessfullySubmittedVehicleDriverAssignmentPage(softAssert);
        softAssert.assertAll();
        testStep("END OF TEST");
    }

    private VehicleDriverAssignmentPage navigateToVehicleDriverAssignmentPage(AutoApplicant applicant) throws Exception {
        applicant = setupApplicant(applicant);
        return new AceAutoNavigationHelper(quoteFlow.AGENT).navigateToVehicleDriverAssignmentPage(applicant);
    }

    private AutoApplicant setupApplicant(AutoApplicant autoApplicant) {
        autoApplicant.setIncidents(new ArrayList<>());
        autoApplicant.getVehicles().forEach(vehicle -> vehicle.setUseVIN(false));
        autoApplicant.getVehicles().forEach(vehicle -> vehicle.setVehicleUsage("Personal"));
        autoApplicant.getVehicles().forEach(vehicle -> vehicle.setOwnership("Owned"));
        return autoApplicant;
    }

    private AutoApplicant setupDriversAndVehicles(AutoApplicant autoApplicant, DriversToVehicleCount scenario) {
        autoApplicant.setMaritalStatus(SINGLE);
        int numberOfDrivers = autoApplicant.getAdditionalDrivers().size() + 1;
        int numberOfVehicles = autoApplicant.getVehicles().size();
        boolean equalCarsAndPeople = numberOfDrivers == numberOfVehicles;
        boolean moreCarsThanPeople = numberOfVehicles > numberOfDrivers;
        switch (scenario) {
            case DRIVERS_EQ_VEHICLES:
                if (!equalCarsAndPeople) {
                    if (moreCarsThanPeople) {
                        autoApplicant = removeCarsFromApplicant(autoApplicant, numberOfDrivers);
                    } else {
                        autoApplicant = removePeopleFromApplicant(autoApplicant, numberOfVehicles);
                    }
                }
                break;
            case DRIVERS_GT_VEHICLES:
                if (moreCarsThanPeople || equalCarsAndPeople) {
                    autoApplicant = removeCarsFromApplicant(autoApplicant, numberOfDrivers - 1);
                }
                break;
            case DRIVERS_LT_VEHICLES:
                if (!moreCarsThanPeople || equalCarsAndPeople) {
                    autoApplicant = removePeopleFromApplicant(autoApplicant, numberOfVehicles - 1);
                }
                break;
        }
        autoApplicant.getAdditionalDrivers().forEach(each -> each.setRelationshipToApplicant(SON));
        return autoApplicant;
    }

    private AutoApplicant removePeopleFromApplicant(AutoApplicant autoApplicant, int numberOfVehicles) {
        List<SqlAdditionalDriver> listOfAdditionalDrivers = autoApplicant.getAdditionalDrivers();
        while (numberOfVehicles < listOfAdditionalDrivers.size() + 1) {
            listOfAdditionalDrivers.remove(listOfAdditionalDrivers.size() - 1);
        }
        autoApplicant.setAdditionalDrivers(listOfAdditionalDrivers);
        return autoApplicant;
    }

    private AutoApplicant removeCarsFromApplicant(AutoApplicant autoApplicant, int numberOfDrivers) {
        List<Vehicle> listOfVehicles = autoApplicant.getVehicles();
        while (numberOfDrivers < listOfVehicles.size()) {
            listOfVehicles.remove(listOfVehicles.size() - 1);
        }
        autoApplicant.setVehicles(listOfVehicles);
        return autoApplicant;
    }
}
