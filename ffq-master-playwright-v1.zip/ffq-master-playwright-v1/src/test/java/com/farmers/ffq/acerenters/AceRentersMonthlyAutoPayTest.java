package com.farmers.ffq.acerenters;

import com.farmers.ffq.ace.hrc.common.AceHRCConsolidatedPaymentPage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.ace.renters.AceRentersNavigationHelper;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.MONTHLY_AUTOPAY;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersMonthlyAutoPayTest extends AutomationFramework {

    // Test case add bank payment, validate content after adding bank payment and validate eCheckout page - Monthly pay
    // excluding KY, LA, MA, MS, NC, as they are monetized and still do not use Consolidated payment page
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,MT,UT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_HOME_BIND,FFQ_ACE_RENTERS_MONTHLY_AUTOPAY_BANK_PAGE})
    public void testMonthlyAutoPayBankPaymentEndToEndAceRenters(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceRentersNavigationHelper().navigateToAceRentersPaymentPage(applicantAceHome);
        AceHRCConsolidatedPaymentPage aceHRCConsolidatedPaymentPage = new AceHRCConsolidatedPaymentPage();
        // This is the new method for consolidated payment page
        aceHRCConsolidatedPaymentPage.selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
        aceHRCConsolidatedPaymentPage.clickBankPaymentRadioButton();
        aceHRCConsolidatedPaymentPage.validateBankAccountAdditionRenters(fsa, MONTHLY_AUTOPAY);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, RENTERS);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, RENTERS);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, RENTERS);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, RENTERS);
        fsa.assertAll();
    }

    // Test case add credit card payment, validate content after adding bank payment and validate eCheckout page - Monthly pay
    // excluding KY, MA, MS, NC, as they are monetized and still do not use Consolidated payment page
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MT,MO,UT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_MONTHLY_AUTOPAY_BANK_PAGE})
    public void testMonthlyAutoPayCreditCardPaymentEndToEndAceRenters(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceRentersNavigationHelper().navigateToAceRentersPaymentPage(applicantAceHome);
        AceHRCConsolidatedPaymentPage aceHRCConsolidatedPaymentPage = new AceHRCConsolidatedPaymentPage();
        aceHRCConsolidatedPaymentPage.selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
        aceHRCConsolidatedPaymentPage.clickCardRadioButton();
       // This is the new method for consolidated payment page
        aceHRCConsolidatedPaymentPage.validateCreditCardPaymentRenters(fsa, MONTHLY_AUTOPAY, false);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, RENTERS);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, RENTERS);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, RENTERS);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, RENTERS);
        fsa.assertAll();
    }
}
