package com.farmers.ffq.specialtyDwelling;

import static com.farmers.ffq.utils.GlobalVariables.REMOVE_SPECIALTY_REDSTATES;
import static com.farmers.ffq.utils.GlobalVariables.SPECIALTY_DWELLING;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;

public class AceHomeSpecialtyDwellingQuoteScenarioTests extends AutomationFramework {

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES)}, groups = {SPECIALTY_DWELLING})
	public void verifyExpectedDiscounts(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant).verifyDisplayOfExpectedDiscounts(specialtyDwellingApplicant);
		testStep("End Of Test");
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES)}, groups = {SPECIALTY_DWELLING})
	public void domehomeKnockoutPageVerification(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		specialtyDwellingApplicant.setTypeOfHome("Dome home");
		try {
			new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant).createQuote(specialtyDwellingApplicant);
			fsa.fail("Quote page should not be reached for Dome home, but it was reached.");
		} catch (IllegalStateException ise) {
			if (ise.getMessage().contains("Did not reach")) {
				//Quote page not reached, so we should be on the Knockout page.
				KnockoutInconveniencePage knockoutPage = new KnockoutInconveniencePage();
				if (knockoutPage.isOnForemostKnockoutPage()) {
					knockoutPage.verifyForemostKnockoutPageContent(fsa);
				} else {
					fsa.fail("Expected to be on Foremost Knockout page, but was not.");
				}
			} else {
				throw ise;
			}
		}
		fsa.assertAll();
	}
}
