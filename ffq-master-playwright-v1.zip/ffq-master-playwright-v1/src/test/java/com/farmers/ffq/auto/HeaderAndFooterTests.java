package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.annotation.Skip;
import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class HeaderAndFooterTests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})
	public void testHeaderAndFooterDesktopMode(AutoApplicant applicant) throws Exception {
		HeaderAndFooter pageHeaderAndFooter = new HeaderAndFooter();
		if (pageHeaderAndFooter.isUseMobileViewEnabled()) {
		    throw new SkipException("Test only valid in Desktop mode");
		} else {
		    new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
		    pageHeaderAndFooter.desktopHeaderValidation();
		    pageHeaderAndFooter.desktopFooterValidation();
		}
	}

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,  
    		attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ}), @CustomAttribute (name = FILTER, values = "applicantId=1")},
    		dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})
    public void testHeaderNavigationDesktopMode(AutoApplicant applicant) throws Exception {
    	HeaderAndFooter pageHeaderAndFooter = new HeaderAndFooter();
    	if (pageHeaderAndFooter.isUseMobileViewEnabled()) {
    		throw new SkipException("Test only valid in Desktop mode");
    	} else {
            FarmersSoftAssert fsa = new FarmersSoftAssert();
    		new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
    		WhoShouldWeInsurePage destinationPage = pageHeaderAndFooter.selectNavigationStep(ENTER_INFO);
    		fsa.assertTrue(destinationPage.isOnWhoShouldWeInsurePage(), "Navigate to \"Who should we insure?\" page");
    		QuoteSummaryAutoPage quoteSummaryPage = pageHeaderAndFooter.selectNavigationStep(REVIEW_QUOTE);
    		quoteSummaryPage.waitForPageTitleAppear();
    		fsa.assertTrue(quoteSummaryPage.isOnQuoteSummaryAutoPage(), "Navigate to Quote Summary Page");
    		fsa.assertAll();				
    	}
    }

	@Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, FL, GA, KY, LA, MA, MS, NC, NJ, NV, NY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})
	public void testDisplayedPhoneNumberNameAndDOBPage(AutoApplicant applicant) throws Exception {
	    new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);
	    validateCorrectPhoneNumberIsDisplayedInHeader(false);
	}

	@Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, FL, GA, KY, LA, MA, MS, NC, NJ, NV, NY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})
	public void testDisplayedPhoneNumberAddressPage(AutoApplicant applicant) throws Exception {
	    new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
	    validateCorrectPhoneNumberIsDisplayedInHeader(false);
	}

	@Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, FL, GA, KY, LA, MA, MS, NC, NJ, NV, NY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})
	public void testDisplayedPhoneNumberWhoShouldWeInsurePage(AutoApplicant applicant) throws Exception {
	    new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
	    validateCorrectPhoneNumberIsDisplayedInHeader(false);
	}

	@Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, FL, GA, KY, LA, MA, MS, NC, NJ, NV, NY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})
	public void testDisplayedPhoneNumberVehicleReviewPage(AutoApplicant applicant) throws Exception {
	    new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant);
	    validateCorrectPhoneNumberIsDisplayedInHeader(false);
	}

	@Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, FL, GA, KY, LA, MA, MS, NC, NJ, NV, NY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})
	public void testDisplayedPhoneNumberDriverReviewPage(AutoApplicant applicant) throws Exception {
	    new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
	    validateCorrectPhoneNumberIsDisplayedInHeader(false);
	}

	@Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, FL, GA, KY, LA, MA, MS, NC, NJ, NV, NY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})
	public void testDisplayedPhoneNumberQuoteReviewPage(AutoApplicant applicant) throws Exception {
		updateApplicantDataToAvoidPossibleBw(applicant);
	    new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
	    validateCorrectPhoneNumberIsDisplayedInHeader(true);
	}

	@Skip
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HEADER_AND_FOOTER_TEST})
	public void validateKOPageHasOnlyFarmersLogoInHeader(AutoApplicant applicant) throws Exception {
		updateApplicantDataToAvoidPossibleBw(applicant);
		applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
		applicant.getVehicles().forEach(each -> each.setUseVIN(true));
		applicant.setTestScenario(HIGH_END_VEHICLE + " -> " + applicant.getTestScenario());
		ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
		contactInfoAutoPage.setValuesAndContinue(applicant);
		ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
		testStepAssert(continueWithBristolWestPage.isOnContinueWithBristolWestPage(), "User successfully landed on the Continue with the BW pop up");
		continueWithBristolWestPage.continueWithBwPopUp();
		BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
		if(bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
			bristolWestAdditionalDiscountsPage.clickContinue();
		}
		KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
		testStepAssert(knockoutInconveniencePage.isOnKnockOutPage(), "User successfully landed on the KO page");
		HeaderAndFooter headerAndFooter = new HeaderAndFooter();
		testStepAssert(headerAndFooter.isKOFarmersHeaderLogoPresent(), "Farmers logo is present in the header for KO page");
		testStepAssert(headerAndFooter.getLogoElementsInHeader().size() == 1, "There should be only one logo on the header for the KO page");
		headerAndFooter.closeQualtricsPopUp();
		testStepAssert(headerAndFooter.isBWLogoPresentInTheFooter(), "BW logo is present in the footer");
		headerAndFooter.closeQualtricsPopUp();
		//testStepAssert(headerAndFooter.isFarmersLogoPresentInFooter(), "Farmers Logo Present in the footer");
		testStep(TEST_PASSED);
	}

	private void validateCorrectPhoneNumberIsDisplayedInHeader(boolean isQuoteComplete) throws Exception, AssertionError {
	    HeaderAndFooter pageHeader = new HeaderAndFooter();
	    testStepAssertTrue(pageHeader.isPhoneNumberCorrect(isQuoteComplete), "Validate displayed phone number is correct", true);
	    testStep("END OF TEST");
	}

}
