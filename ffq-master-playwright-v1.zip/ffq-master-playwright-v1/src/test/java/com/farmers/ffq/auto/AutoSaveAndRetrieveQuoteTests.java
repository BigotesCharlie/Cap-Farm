package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;

import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.*;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.*;

public class AutoSaveAndRetrieveQuoteTests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {/*FL*/}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS, SAVE_AND_RETRIEVE})
    public void testWhoShouldWeInsurePageSaveQuote(AutoApplicant applicant) throws Exception {
        updateApplicantDetailsForSaveQuotePurposes(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        if (whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        } else {
            whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
        }

        fsa.assertTrue(whoShouldWeInsurePage.validateSaveQuoteModal(true), "Save Quote Modal validation in the WhoShouldWeInsurePage");
        String applicantFullName = applicant.getFirstName() + SPACE + applicant.getLastName();

        if (whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            vehiclesDriversInfoPage.clickEditButtonForDriver(applicantFullName);
            vehiclesDriversInfoPage.clickCloseIcon();
        } else {
            whoShouldWeInsurePage.clickEditButtonWithDriverFullName(applicantFullName);
            whoShouldWeInsurePage.clickOnDriverDialogCloseIcon();
        }

        sendAndValidateIncompleteSaveQuoteEmailFlow(applicant, fsa, whoShouldWeInsurePage);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS, SAVE_AND_RETRIEVE})
    public void testVehiclesPageSaveQuote(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateApplicantDetailsForSaveQuotePurposes(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        VehicleReviewPage vehicleReviewPage = new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant);
        vehicleReviewPage.addVehicleDetails(applicant);
        fsa.assertTrue(vehicleReviewPage.validateSaveQuoteModal(true), "Save Quote Modal validation failed in the VehiclesReviewPage");
        sendAndValidateIncompleteSaveQuoteEmailFlow(applicant, fsa, vehicleReviewPage);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS, SAVE_AND_RETRIEVE})
    public void testDriversPageSaveQuote(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateApplicantDetailsForSaveQuotePurposes(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        driverReviewPage.reviewAllDrivers(applicant, Optional.of(fsa));
        sleep(2);
        fsa.assertTrue(driverReviewPage.validateSaveQuoteModal(true), "Save Quote Modal validation failed in the DriversReviewPage");
        sendAndValidateIncompleteSaveQuoteEmailFlow(applicant, fsa, driverReviewPage);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS, SAVE_AND_RETRIEVE})
    public void testContactInfoPageSaveQuote(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateApplicantDetailsForSaveQuotePurposes(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValues(applicant);
        fsa.assertTrue(contactInfoAutoPage.validateSaveQuoteModal(true), "Save Quote Modal validation failed in the ContactInfoPage");
        sendAndValidateIncompleteSaveQuoteEmailFlow(applicant, fsa, contactInfoAutoPage);
        fsa.assertAll();
    }


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})
    public void testQuoteSummaryPageDefaultSaveQuote(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateApplicantDataToAvoidPossibleBw(applicant);
        updateApplicantDetailsForSaveQuotePurposes(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        validateCompleteSaveQuoteEmailFlow(applicant, fsa, quoteSummaryAutoPage);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})
    public void testQuoteSummaryPagePayInFullSaveQuote(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateApplicantDetailsForSaveQuotePurposes(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        quoteSummaryAutoPage.clickOnAlternativePaymentLink();
        sleep(2);
        validateCompleteSaveQuoteEmailFlow(applicant, fsa, quoteSummaryAutoPage);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})
    public void testRetrieveNonRatedQuoteWithQuoteNumber(AutoApplicant applicant) throws Exception {
        updateApplicantDetailsForSaveQuotePurposes(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if (aceAutoNavigationHelper.isProdEnvironment()) {
            updatePersonalInfoForProd(applicant);
        }
        ContactInfoAutoPage contactInfoAutoPage = aceAutoNavigationHelper.navigateToContactInfoAutoPage(applicant);

        String quoteNumber = contactInfoAutoPage.getSessionStorageAppStore().getData().getQuoteNumber();
        new LandingPage(contactInfoAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, quoteNumber);
        verifyNonRatedRetrievedQuote(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})
    public void testRetrieveRatedQuoteWithQuoteNumber(AutoApplicant applicant) throws Exception {
        updateApplicantDetailsForSaveQuotePurposes(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if (aceAutoNavigationHelper.isProdEnvironment()) {
            updatePersonalInfoForProd(applicant);
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        sleep(2);

        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote Summary page is reached successfully", true);

        String monthlyPremiumBeforeRetriaval = quoteSummaryAutoPage.getPresentedPremiumAmount();
        String quoteNumber = quoteSummaryAutoPage.getAceQuoteNumberInThePage();
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteWithLink(applicant, quoteNumber);
        SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
        String monthlyPremiumAfterRetriaval = null;
        if (quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            testStepAssert(quoteSummaryAutoPage.isSnackBarMessageDisplayed(String.format("Welcome back %s", applicant.getFirstName())), "Welcome back snackbar message is displayed", true);
            monthlyPremiumAfterRetriaval = quoteSummaryAutoPage.getPresentedPremiumAmount();
        } else {
            selectAQuoteToReviewPage.clickContinueMyQuote();
            testStepAssert(quoteSummaryAutoPage.isSnackBarMessageDisplayed(String.format("Welcome back %s", applicant.getFirstName())), "Welcome back snackbar message is displayed", true);
            monthlyPremiumAfterRetriaval = quoteSummaryAutoPage.getPresentedPremiumAmount();
        }
        testStepAssert(monthlyPremiumAfterRetriaval, monthlyPremiumBeforeRetriaval, "Premiums before after retrieval are matching", true);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA, NJ, FL})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})
    public void testRetrieveNonRatedQuoteWitEmailId(AutoApplicant applicant) throws Exception {
        updateApplicantDetailsForSaveQuotePurposes(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        if (applicant.getStateCode().equals(WA)) {
            applicant.setLastName("Wilson");
        }
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if (aceAutoNavigationHelper.isProdEnvironment()) {
            updatePersonalInfoForProd(applicant);
        }
        DriverReviewPage driverReviewPage = aceAutoNavigationHelper.navigateToDriverReviewPage(applicant);
        driverReviewPage.setMaritalRelationToSomeOneNotListed(applicant, true, false);
        driverReviewPage.clickOnSaveQuoteButton();
        String email = applicant.getEmail();
        driverReviewPage.enterEmailInSaveQuoteModal(email);
        driverReviewPage.waitForSpinnerToBeGone();
        testStepAssert(driverReviewPage.isEmailConfirmationDisplayed(applicant.getEmail()), "Email sent snackbar confirmation validation");
        new LandingPage(driverReviewPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, email);
        verifyNonRatedRetrievedQuote(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})
    public void testRetrieveRatedQuoteWitEmailId(AutoApplicant applicant) throws Exception {
        updateApplicantDetailsForSaveQuotePurposes(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        sleep(2);
//        quoteSummaryAutoPage.clickOnEmailLink();
//        quoteSummaryAutoPage.isEmailConfirmationDisplayed(applicant);
        String premiumBeforeRetrieval = quoteSummaryAutoPage.getPresentedPremiumAmount();
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, applicant.getEmail());
        SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
        if (!quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
            selectAQuoteToReviewPage.clickContinueMyQuote();
        }
        quoteSummaryAutoPage.isSnackBarMessageDisplayed(String.format("Welcome back %s", applicant.getFirstName()));
        quoteSummaryAutoPage.isOnQuoteSummaryAutoPage();
        String premiumAfterQuoteRetrieval = quoteSummaryAutoPage.getPresentedPremiumAmount();
        Assert.assertEquals(premiumAfterQuoteRetrieval, premiumBeforeRetrieval);

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, WA, PA, AZ, KS, IL, OR, NM, IA, WI, AR, CO, ID, NE})}, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE, FFQ_BIND_BANKPAYMENT_PAGE})
    public void validateBindAfterRatedQuoteRetrieval(AutoApplicant applicant) throws Exception {

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateApplicantDataToAvoidPossibleBw(applicant);
        updateApplicantDetailsForSaveQuotePurposes(applicant);
        applicant.setLastName("Bailey");
        applicant.getDiscounts().get(0).setSignalSignup(false); // To avoid Signal related blocks during checkout
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        sleep(2);
        quoteSummaryAutoPage.clickOnStartCheckoutButton();
        AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        if (!additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage()) {
            testStep(TEST_COMPLETED + " because user did not land on the Additional info page", true);
            return;
        }

        AppStore retrieveQuoteResponseSessionStorage = quoteSummaryAutoPage.getSessionStorageAppStore();
        additionalInfoVehicleSectionOneUI.verifyVehicleSection(retrieveQuoteResponseSessionStorage, true, fsa);
        additionalInfoDriverSectionOneUI.enterDriverLicenseNumber(retrieveQuoteResponseSessionStorage);
        additionalInfoDriverSectionOneUI.enterMatureDriverSafetyCourseDate(retrieveQuoteResponseSessionStorage.getData().getLandingStateCode());
        additionalInfoSignalEnrollmentSectionOneUI.verifySignalEnrollmentSection(retrieveQuoteResponseSessionStorage, true, fsa);
        additionalInfoDriverSectionOneUI.closeQualtricsPopUp();
        additionalInfoDriverSectionOneUI.fillOutHealthInsuranceSection("United Healthcare", "UHC123456");
        additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();
        additionalInfoContinueToPaymentOneUI.waitForSpinnerToBeGone();

        DriverMismatchPage driverMismatchPage = new DriverMismatchPage();
        if (driverMismatchPage.isOnDriverMismatchPage()) {
            driverMismatchPage.dontIncludeAnyMismatchedDriversInQuote();
        }

        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        testStepAssert(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User is on the consolidated payment page", true);

        //Retrieve quote from email
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, applicant.getEmail());
        SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
        quoteSummaryAutoPage.isSnackBarMessageDisplayed(String.format("Welcome back %s", applicant.getFirstName()));
        if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
            selectAQuoteToReviewPage.clickContinueMyQuote();
        }
        completePurchase(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, CO, MI, CO, OR})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE})
    public void testReRateAfterRetrievalAndChange(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User landed on the quote summary page");
        String quoteNumber = quoteSummaryAutoPage.getSessionStorageAppStore().getData().getQuoteNumber();
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, quoteNumber);
        SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
        if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
            selectAQuoteToReviewPage.clickContinueMyQuote();
        }
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User landed on the quote summary page after retrieval of rated quote");

        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the Who Should we Insure page after clicking on the Enter navigation bar from Quote Summary page");

        testStep("Adding new Driver to the Quote");
        SqlAdditionalDriver additionalDriver = getRandomAdditionalDriver();
        applicant.getAdditionalDrivers().add(additionalDriver);
        if (whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.addRandomNewVehicle();
        } else {
            whoShouldWeInsurePage.clickAddAnotherDriverButton();
            whoShouldWeInsurePage.enterAdditionalDriverData(applicant, additionalDriver);
            whoShouldWeInsurePage.clickOnSaveButton();
            whoShouldWeInsurePage.addRandomAdditionalVehicle();
        }

        verifyNonRatedRetrievedQuote(applicant);
        testStep("Validate user able to add/edit vehicles and drivers after retrieval without any error. Should quote will rate based on the current details.");

    }

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.ONE_TO_FIVE_VEHICLES)}, groups = {FFQ_ONEUI, SAVE_AND_RETRIEVE, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void validateUserIsAbleToGetRateAfterRetrieval_ADPF(ADPFApplicant applicant) throws Exception {
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        String fullName = heresWhatWeFoundPage.getPniFullNameFromAutoAdpfApplicant(applicant);
        boolean isStreamLineFlow = heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        if (isStreamLineFlow) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.selectAndEditDefaultAdpfVehicles();
            vehiclesDriversInfoPage.selectAndEditDefaultAdpfDrivers(Collections.emptyList());
            vehiclesDriversInfoPage.clickContinueButton();
        } else {
            heresWhatWeFoundPage.addADPFApplicant(Optional.empty(), fullName, applicant.getGender(), applicant.getDateOfBirth());
            if (heresWhatWeFoundPage.getListOfCheckedVehicles().isEmpty()) {
                heresWhatWeFoundPage.addRandomNewVehicle(heresWhatWeFoundPage.getRandomVinNumber(2));
            }
            heresWhatWeFoundPage.clickContinueButton();
        }
        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        if (!isStreamLineFlow) {
            testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on the Vehicle review page");
        }
        new LandingPage().retrieveQuoteFromLandingPage(applicant.getLastName(), applicant.getDateOfBirth(), heresWhatWeFoundPage.getSessionStorageAppStore().getData().getQuoteNumber(), applicant.getZipCode());
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        testStepAssert(whoShouldWeInsurePage.getTitle(), "Welcome back " + applicant.getFirstName() + "!", "Welcome back snackbar message on " + whoShouldWeInsurePage.getClass().getSimpleName(), true);
        testStepAssertTrue(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the " + whoShouldWeInsurePage.getClass().getSimpleName());
        vehicleReviewPage.clickContinueButton();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateFromVehicleReviewToQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Objective: User should be able to successfully rate the Quote after retrieval(ADPF/Non-ADPF flow) - This specific test is only applicaple for ADPF");
    }


    /**
     * BW_Auto_Ace 156
     * "Validate Age of the PNI is not missing with Retrieval Quote
     * Steps to produce:
     * 1- Start Auto quote in NJ, accept bw pop up and continue with the flow
     * 2- Add vehicles and drivers(1V, 1D or more)
     * 3- Continue to Vehicles Review page
     * (Note : you can drop here and continue with retrieval of non rated quote, other wise rate the quote and then retrieve)
     * 4- rate the quote
     * 6- Retrieval(rated or non rated quote)
     * 7- Come to the who should we insure page
     * Expected: PNI age should be visible
     * Actual: it is missing"
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {NJ})}, groups = {SAVE_AND_RETRIEVE, BW_ACE_TESTS, BDQ_TESTS})
    public void validateAgeOfPNIisNotMissingWithRetrievalQuote(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        bwSpecificDataSetUp(applicant);
        boolean ratedQuote = RandomUtils.nextBoolean();
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        if (ratedQuote) {
            quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
            quoteSummaryAutoPage.closeQualtricsPopUp();
            testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName() + " with BW");
        } else {
            ContactInfoAutoPage contactInfoAutoPage = aceAutoNavigationHelper.navigateToContactInfoAutoPage(applicant);
            testStepAssert(contactInfoAutoPage.isOnContactInfoAutoPage(), "User is on the " + contactInfoAutoPage.getClass().getSimpleName());
        }
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant.getLastName(), applicant.getDateOfBirth(), aceAutoNavigationHelper.getSessionStorageAppStore().getData().getQuoteNumber(), applicant.getZipCode());

        if (ratedQuote) {
            quoteSummaryAutoPage.isSnackBarMessageDisplayed(String.format("Welcome back %s", applicant.getFirstName()));
            quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        }
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the " + whoShouldWeInsurePage.getClass().getSimpleName() + " with " + (ratedQuote ? "rated" : "unrated") + " quote");
        fsa.assertEquals(whoShouldWeInsurePage.getTitle(), "Welcome back " + applicant.getFirstName() + "!", "Welcome back snackbar message on " + whoShouldWeInsurePage.getClass().getSimpleName());
        fsa.assertEquals(whoShouldWeInsurePage.getSubTitle(), "Please review your information so we can get you that quote", "Page description upon retrieval for " + whoShouldWeInsurePage.getClass().getSimpleName());
        int ageOfDisplayedDriverByName = whoShouldWeInsurePage.getAgeOfDisplayedDriverByName(applicant.getFirstName() + SPACE + applicant.getLastName());
        fsa.assertEquals(ageOfDisplayedDriverByName, applicant.getAge(), "Age of PNI is displayed correctly as " + applicant.getAge());
        fsa.assertAll();

    }

    /**
     * Validate Retrieve flow by dropping off in Vehicle review screen /  Contact Info screen / Quote review screen in the Bristol west flow, upon retrieving user should land on Enter Info screen.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MA, FL, NJ})}, groups = {SAVE_AND_RETRIEVE, BW_ACE_TESTS, BDQ_TESTS})
    public void validateRetrievalWhenDroppedBeforeRate_BW(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper(AceAutoNavigationHelper.quoteFlow.DEFAULT);

        boolean navigateToContactInfoPage = RandomUtils.nextBoolean();
        if (navigateToContactInfoPage) {
            ContactInfoAutoPage contactInfoAutoPage = aceAutoNavigationHelper.navigateToContactInfoAutoPage(applicant);
            testStepAssert(contactInfoAutoPage.isOnContactInfoAutoPage(), "User is on the " + contactInfoAutoPage.getClass().getSimpleName() + " before retrieval of quote dropped before rate", true);
        } else {
            VehicleReviewPage vehicleReviewPage = aceAutoNavigationHelper.navigateToVehicleReviewPage(applicant);
            testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on the " + vehicleReviewPage.getClass().getSimpleName() + " before retrieval of quote dropped before rate", true);
        }
        // early finish the test if the user is not on the bristol west flow
        if(!aceAutoNavigationHelper.isOnBristolWest()) {
            testStep(TEST_COMPLETED + " because user is not on the Bristol West flow", true);
            return;
        }
        String quoteNumber = aceAutoNavigationHelper.getSessionStorageAppStore().getData().getQuoteNumber();
        new LandingPage().retrieveQuoteFromLandingPage(applicant, quoteNumber);
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        fsa.assertTrue(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the " + whoShouldWeInsurePage.getClass().getSimpleName() + " after retrieval of quote dropped before rate");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})},
            dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS, SAVE_AND_RETRIEVE})
    public void validateBDQRetrieval(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setTestScenario(BW_ORGANIC_FLOW + SPACE + applicant.getTestScenario());
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper(AceAutoNavigationHelper.quoteFlow.BDQ);
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote Summary page is reached successfully", true);
        String quoteNumber = quoteSummaryAutoPage.getSessionStorageAppStore().getData().getQuoteNumber();
        retrieveAndValidateBW_BDQ_Flow(applicant, quoteNumber);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS, SAVE_AND_RETRIEVE})
    public void validateBwRetrieval(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        applicant.setLastName("Threeoabaa");
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the Quote Summary page", true);
        String quoteNumber = quoteSummaryAutoPage.getSessionStorageAppStore().getData().getQuoteNumber();
        // retrieval from landing page
        retrieveAndValidateBW_BDQ_Flow(applicant, quoteNumber);
    }

    /**
     * F102632
     * Validate when user drops of after rate screen and user tries to create a quote with same ZIP code and AUTO LOB user should land on New Retrieve quote offer screen
     * "1. Create a Auto QUote with mentioned States.
     * 2. Rate the quote.
     * 3. Validate whether retrieve key is present in your local. (THis we don't have to validate as confirmed by QE - Anusha Gatti)
     * 4. Drop off and create a new auto quote with same ZIP user should land on new quote retrieval screen.
     * 5. Validate details and enter details and click on proceed user should land on rate screen.
     * 6. New quote retrieval screen work only when user lands on rate screen."
     * @param applicant
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {TX, GA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS, FFQ_ONEUI, SAVE_AND_RETRIEVE})
    public void validateUserLandsOnNewRetrievalPageWithSameZipCode_Farmers(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.getVehicles().forEach(each -> each.setOwnership("Owned"));
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        String applicantLastName = applicant.getLastName();
        String applicantDoB = applicant.getDateOfBirth();

        FarmersSoftAssert fsa = new FarmersSoftAssert();

        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnFarmers(), "User is on Farmers quote summary page");

        sleep(4); // waiting four seconds to make sure when user restart the same zipcode code creation, we ensure new retrieval quote page

        NewRetrievalPage newRetrievalPage = new NewRetrievalPage();
        LandingPage landingPage = new LandingPage();
        landingPage.enterLandingPageData(LOB_AUTO, applicant.getZipCode());

        // validate user lands on the new retrieval page
        fsa.assertTrue(newRetrievalPage.isOnNewRetrievalPage(), "User is on the new retrieval page");

        newRetrievalPage.retrieveSavedQuote(applicantLastName, applicantDoB);

        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnFarmers(), "User is on the Farmers rate page after retrieving from the new retrieval page");

        fsa.assertAll();
    }

    /**
     * F102632
     * Validate when user drops of after rate screen and user tries to create a quote with same ZIP code and AUTO LOB user should land on New Retrieve quote offer screen
     * "1. Create a Auto QUote with mentioned States.
     * 2. Rate the quote.
     * 3. Validate whether retrieve key is present in your local. (THis we don't have to validate as confirmed by QE - Anusha Gatti)
     * 4. Drop off and create a new auto quote with same ZIP user should land on new quote retrieval screen.
     * 5. Validate details and enter details and click on proceed user should land on rate screen.
     * 6. New quote retrieval screen work only when user lands on rate screen."
     * @param applicant
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {TX, IL})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS, SAVE_AND_RETRIEVE})
    public void validateUserLandsOnNewRetrievalPageWithSameZipCode_BW(AutoApplicant applicant) throws Exception {

        boolean isBDQFlow = Property.getTestProperty("isBDQFlow").equals(LOWERCASE_TRUE);
        Log.info("User is using " + (isBDQFlow ? " BDQ " : "BW") + " flow for this test");
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if (isBDQFlow) {
            aceAutoNavigationHelper = new AceAutoNavigationHelper(AceAutoNavigationHelper.quoteFlow.BDQ);
        } else {
            bwSpecificDataSetUp(applicant);
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        String applicantLastName = applicant.getLastName();
        String applicantDoB = applicant.getDateOfBirth();

        FarmersSoftAssert fsa = new FarmersSoftAssert();

        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on BW quote summary page");
        sleep(4); // waiting four seconds to make sure when user restart the same zipcode code creation, we ensure new retrieval quote page

        NewRetrievalPage newRetrievalPage = new NewRetrievalPage();
        LandingPage landingPage = new LandingPage();
        landingPage.enterLandingPageData(LOB_AUTO, applicant.getZipCode());

        // validate user lands on the new retrieval page
        fsa.assertTrue(newRetrievalPage.isOnNewRetrievalPage(), "User is on the new retreival page");

        newRetrievalPage.retrieveSavedQuote(applicantLastName, applicantDoB);

        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the BW rate page after retrieving from the new retreival page");

        fsa.assertAll();
    }


    private void retrieveAndValidateBW_BDQ_Flow(AutoApplicant applicant, String quoteNumber) throws Exception {
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        // retrieval from landing page
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant.getLastName(), applicant.getDateOfBirth(), quoteNumber, applicant.getZipCode());
        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();

        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page after retrieval");

        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        new WhoShouldWeInsurePage().navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();

        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page after retrieval back and forth navigation");

        List<String> brightlineResponses = DbHelper.queryPostgresGetAllRows(String.format("select event_status from ffqdb.quote_event_log qe join ffqdb.quote_milestone qm on qm.milestone_id=qe.milestone_id where qe.quote_number='%s' and milestone_description='Brightline Status Check Rest Service Ended';", quoteNumber));

        farmersSoftAssert.assertEquals(brightlineResponses.size(), 2, "Brightline Status Check Rest Service Ended is called twice - once during initial quote and once during retrieval");

        brightlineResponses.forEach(each -> {
            farmersSoftAssert.assertTrue(each.equals("success"), "Brightline response is success before and after retrieval");
        });

        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        completePurchase(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, farmersSoftAssert);
        farmersSoftAssert.assertAll();
    }

    private void verifyNonRatedRetrievedQuote(AutoApplicant applicant) throws Exception {

        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        testStepAssert(whoShouldWeInsurePage.getTitle(), "Welcome back " + applicant.getFirstName() + "!", "Welcome back snackbar message on " + whoShouldWeInsurePage.getClass().getSimpleName(), true);
        boolean vehiclesDriversConsolidationImpl = whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());

        if (!vehiclesDriversConsolidationImpl) {
            testStepAssert(whoShouldWeInsurePage.getSubTitle(), "Please review your information so we can get you that quote", "Page descripton upon retreival for " + whoShouldWeInsurePage.getClass().getSimpleName(), false);
            whoShouldWeInsurePage.clickOnContinueButton();
        } else {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            String actualPageDescription = vehiclesDriversInfoPage.getPageDescriptionText();
            List<String> expectedDescriptions = List.of(
                    "Here's what we have so far. Does it all look good?",
                    "Please check the information we have. You can edit anything that doesn't look right."
            );
            testStepAssert(expectedDescriptions.contains(actualPageDescription), vehiclesDriversInfoPage.getClass().getSimpleName() + " page description upon retrieval should be one of: " + expectedDescriptions + " but was: [" + actualPageDescription + "]");
            vehiclesDriversInfoPage.clickContinueButton();
        }

        if (!vehiclesDriversConsolidationImpl) {
            VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
            testStepAssert(vehicleReviewPage.validateVehicleReviewPageDescription(), "Page description after retrieval of non rated quote");
            vehicleReviewPage.setVehicleUsagesToPersonal();
            vehicleReviewPage.clickOnContinueButton();
            DriverReviewPage driverReviewPage = new DriverReviewPage();
            driverReviewPage.validatePageHeaderAndDescription();
            driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
            driverReviewPage.clickContinueButton();
        }
        SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
        if (!signalPageOneUI.isSignalDiscountDisabledState(applicant.getStateCode())) {
            signalPageOneUI.processSignalPage(true);
        }
        new ContactInfoAutoPage().setValuesAndContinue(applicant);
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();

        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            String stateCode = applicant.getStateCode();
            if (stateCode.equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
        }

        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        if (quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            quoteSummaryAutoPage.clickOnStartCheckoutButton();
            return;
        }

        ContinueWithBristolWestPage continueWithBristolWest = new ContinueWithBristolWestPage();
        SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
        if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
            selectAQuoteToReviewPage.clickContinueMyQuote();
        }
        if (continueWithBristolWest.isOnContinueWithBristolWestPage()) {
            continueWithBristolWest.continueWithBwPopUp();
            BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
            if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                bristolWestAdditionalDiscountsPage.clickContinue();
            }
        }
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if (bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            bwFarmersQuotePresentmentPage.continueWithFarmers();
        }
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User landed on the quote summary page", true);
        quoteSummaryAutoPage.clickOnStartCheckoutButton();
    }

    private void updateApplicantDetailsForSaveQuotePurposes(AutoApplicant applicant) {
        applicant.setFirstName(StringUtils.capitalize(RandomStringUtils.randomAlphabetic(5).toLowerCase()));
        if (applicant.getStateCode().equals(MI)) {
            applicant.setLastName(Arrays.asList("Wilson", "Brooks", "Spencer").get(new Random().nextInt(3)));
        } else if (applicant.getStateCode().equals(WA)) {
            applicant.setLastName("Wilson");
        } else {
            applicant.setLastName(StringUtils.capitalize(RandomStringUtils.randomAlphabetic(5).toLowerCase()));
        }

        String emailUserName = applicant.getFirstName() + "_" + applicant.getLastName() + RandomStringUtils.randomAlphanumeric(5).replace(" ", "");
        emailUserName = emailUserName.replace(SPACE, EMPTY_STRING);
        if (emailUserName.length() > 24) {
            emailUserName = emailUserName.substring(emailUserName.length() - 24);
        }
        String newEmail = emailUserName + "@" + Mailinator.MAILINATOR_FARMERS_PRIVATE_DOMAIN;
        applicant.setEmail(newEmail);
    }

    private void sendAndValidateIncompleteSaveQuoteEmailFlow(AutoApplicant applicant, FarmersSoftAssert fsa, AutoBasePage page) throws Exception {
        AutoBasePage autoBasePage = new AutoBasePage();
        boolean isOnBw = autoBasePage.isOnBristolWest();

        if (page.isAutoSaveDisabled()) {
            page.enterEmailInSaveQuoteModal(applicant.getEmail());
            if (!isOnBw) {
                fsa.assertTrue(page.isEmailConfirmationDisplayed(applicant.getEmail()), "Email Sent Confirmation snackbar is NOT Displayed");
                String quoteNumberInThePage = page.getAceQuoteNumberInThePage();
                // switching from mailinator UI use to api
                new Mailinator().validateAceNotRatedEmail(applicant, fsa, quoteNumberInThePage);
            }

        } else {
            Log.warn("Quote Auto Save enabled");
        }
    }

    private void validateCompleteSaveQuoteEmailFlow(AutoApplicant applicant, FarmersSoftAssert fsa, QuoteSummaryAutoPage quoteSummaryAutoPage) throws Exception {
        quoteSummaryAutoPage.closeQualtricsPopUp();
        AutoBasePage autoBasePage = new AutoBasePage();
        boolean isOnBw = autoBasePage.isOnBristolWest();

        String quoteNumber = quoteSummaryAutoPage.getAceQuoteNumberInThePage();
//        quoteSummaryAutoPage.clickOnEmailLink();
//        fsa.assertTrue(quoteSummaryAutoPage.isEmailConfirmationDisplayed(applicant), "Email Sent Confirmation snackbar is NOT Displayed");
        String premiumAmount = quoteSummaryAutoPage.getPresentedPremiumAmount().replace("$", EMPTY_STRING).replace("/mo", EMPTY_STRING).replace(",", EMPTY_STRING).strip();

        String membershipFeeIfPresent = quoteSummaryAutoPage.getMembershipFeeIfPresent().replace("$", EMPTY_STRING);
        String totalPremiumAmount = String.valueOf((Double.parseDouble(premiumAmount) + Double.parseDouble(membershipFeeIfPresent)));
        Log.info("Total Premium Amount - Membership fee included: " + totalPremiumAmount);
        quoteSummaryAutoPage.clickOnEmailLink();
        if (!isOnBw) {
            // switching from mailinator UI use to api
            new Mailinator().validateAceRatedEmail(applicant, fsa, quoteNumber, totalPremiumAmount);
        }

    }

}
