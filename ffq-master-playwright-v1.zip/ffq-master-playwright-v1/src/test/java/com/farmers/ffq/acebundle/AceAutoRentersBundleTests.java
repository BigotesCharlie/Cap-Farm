package com.farmers.ffq.acebundle;

import com.farmers.ffq.ace.bundle.*;
import com.farmers.ffq.ace.home.AceHomeContactInfoPage;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.ace.renters.AceRentersJustAFewMoreThingsPage;
import com.farmers.ffq.ace.renters.AceRentersReviewQuotePage;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.auto.pages.bindpages.ConsolidatedPaymentPage;
import com.farmers.ffq.auto.pages.bindpages.EcheckoutSuccessfulPageOneUI;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.datatransferobjects.*;

import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AceBundleDataProviders;
import com.farmers.ffq.dataproviders.SqlDataProviders;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.MONTHLY_AUTOPAY;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.*;

public class AceAutoRentersBundleTests extends AceBundleTestHelper {

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void aceAutoRentersBundleE2ETest(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		EcheckoutSuccessfulPageOneUI finalPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToECheckoutPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		if (new KnockoutInconveniencePage().isQuoteKnockedOut()) {
			Log.warn("Payment failed, cannot complete process");
		} else {
			fsa.assertTrue(finalPage.isPaymentSuccessfulMessageCorrect(), "Payment successful on final page");
		}
		fsa.assertAll();
	}

	// AR - Auto monthly pay card and renters monthly pay card
	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyPaymentPagesContentAndUseSamePaymentDialogFunctionalityAR(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		setVINInBundleApplicantForNonBWAuto(bundleApplicant);
		AceBundleAutoPaymentPage aceBundleAutoPaymentPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToPayForAutoPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		aceBundleAutoPaymentPage.verifyAceBundleAutoPaymentPageContent(fsa);
		aceBundleAutoPaymentPage.fillOutAutoPaymentPageAndContinue(bundleApplicant.getAutoApplicant());
		AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
		aceHRCPaymentSelectionPage.verifyAceBundleHRCPaymentPageContent(fsa);

		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		AceHRCConsolidatedPaymentPage aceHRCConsolidatedPaymentPage = new AceHRCConsolidatedPaymentPage();
		aceHRCConsolidatedPaymentPage.selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
		aceHRCConsolidatedPaymentPage.clickCardRadioButton();
		aceHRCPaymentBasePage.verifyContentOfUseSamePaymentMethodPopUP(fsa, MONTHLY_DEBIT_CREDIT_CARD);
		aceHRCPaymentBasePage.clickSameButtonSamePaymentModal();
		aceHRCPaymentBasePage.waitForReuseSamePaymentPopUPInvisible();
		// This is the new method for consolidated payment page
		aceHRCConsolidatedPaymentPage.validateCreditCardPaymentRenters(fsa, MONTHLY_AUTOPAY, true);
		aceHRCPaymentBasePage.navigateBack();

		aceHRCConsolidatedPaymentPage.selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
		aceHRCConsolidatedPaymentPage.validateFeeInfoSectionRenters(fsa);
		aceHRCConsolidatedPaymentPage.clickCardRadioButton();
		aceHRCPaymentBasePage.clickDifferentButtonSamePaymentModal();
		aceHRCPaymentBasePage.waitForReuseSamePaymentPopUPInvisible();
		aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(DISCOVER_CARD);
		aceHRCPaymentBasePage.switchToParentWindow();
		aceHRCPaymentBasePage.waitForSpinnerToBeGone();
		aceHRCPaymentBasePage.clickCompletePurchaseButton();
		aceHRCPaymentBasePage.validateECheckOutPage(fsa, HOME);
		fsa.assertAll();
	}

	// AR - Auto pay in full card and renters pay in full bank
	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAutoPayInFullCardAndRentersPayInFullBank(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		setVINInBundleApplicantForNonBWAuto(bundleApplicant);
		new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToPayForAutoPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		if(consolidatedPaymentPage.isOnConsolidatedPaymentPage()){
			consolidatedPaymentPage.validateFeeInfoSection(fsa);
			consolidatedPaymentPage.selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
			consolidatedPaymentPage.clickCardRadioButton();
			consolidatedPaymentPage.addCardPaymentMethod(MASTER_CARD, bundleApplicant.getHrcApplicant().getZipCode());
			aceHRCPaymentBasePage.clickCompletePurchaseButton();
			consolidatedPaymentPage.selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
			if(!bundleApplicant.getHrcApplicant().getStateCode().equals(KS)){
				new AceHRCConsolidatedPaymentPage().validateFeeInfoSectionRenters(fsa);
			}
			consolidatedPaymentPage.clickBankPaymentRadioButton();
			aceHRCPaymentBasePage.addCheckingAccountPaymentMethod(BOFA_ROUTING_NUMBER, RandomStringUtils.randomNumeric(6));
			aceHRCPaymentBasePage.clickCompletePurchaseButton();
			aceHRCPaymentBasePage.validateECheckOutPage(fsa, RENTERS);
		}else{
			fsa.fail("Did not reach consolidated payment page" + NEWLINE);
		}
		fsa.assertAll();
	}

	// AR - Auto monthly pay bank and renters monthly pay card
	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAutoMonthlyPayBankAndRentersMonthlyPayCard(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		setVINInBundleApplicantForNonBWAuto(bundleApplicant);
		new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToPayForAutoPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		consolidatedPaymentPage.selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
		consolidatedPaymentPage.clickBankPaymentRadioButton();
		aceHRCPaymentBasePage.addCheckingAccountPaymentMethod(BOFA_ROUTING_NUMBER, RandomStringUtils.randomNumeric(6));
		aceHRCPaymentBasePage.clickCompletePurchaseButton();
		consolidatedPaymentPage.selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
		if(!bundleApplicant.getHrcApplicant().getStateCode().equals(KS)){
			new AceHRCConsolidatedPaymentPage().validateFeeInfoSectionRenters(fsa);
		}
		consolidatedPaymentPage.clickCardRadioButton();
		consolidatedPaymentPage.addCardPaymentMethod(MASTER_CARD, bundleApplicant.getHrcApplicant().getZipCode());
		aceHRCPaymentBasePage.clickCompletePurchaseButton();
		aceHRCPaymentBasePage.validateECheckOutPage(fsa, RENTERS);
		fsa.assertAll();
	}

	// BW - AR - Auto Monthly pay card and Renters Monthly pay bank
	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void aceBWAutoRentersBundleE2EWithAutoMonthlyPayCardAndRentersMonthlyPayInBank(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToPayForPropertyPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayBankRenters();
		aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayBankPaymentLabelRenters();
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, RENTERS);
		aceHRCPaymentBasePage.waitForSpinnerToBeGone();
		aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, RENTERS);
		aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, RENTERS);
		aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, RENTERS);
		aceHRCPaymentBasePage.clickCompletePurchaseButton();
		aceHRCPaymentBasePage.validateECheckOutPage(fsa, RENTERS);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAutoPayInFullCardAndRentersPayInFullCardWithOneTimePayment(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		setVINInBundleApplicantForNonBWAuto(bundleApplicant);
		new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToPayForAutoPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();

		consolidatedPaymentPage.selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
		consolidatedPaymentPage.clickCardRadioButton();
		consolidatedPaymentPage.addCardPaymentMethod(MASTER_CARD, bundleApplicant.getHrcApplicant().getZipCode());
		consolidatedPaymentPage.waitForSpinnerToBeGone();
		new PolicyDebitCreditPayment().selectOneTimePaymentRadioButton();
		aceHRCPaymentBasePage.clickCompletePurchaseButton();

		consolidatedPaymentPage.selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
		consolidatedPaymentPage.clickCardRadioButton();
		consolidatedPaymentPage.addCardPaymentMethod(MASTER_CARD, bundleApplicant.getHrcApplicant().getZipCode());
		consolidatedPaymentPage.waitForSpinnerToBeGone();
		aceHRCPaymentBasePage.clickCompletePurchaseButton();
		aceHRCPaymentBasePage.validateECheckOutPage(fsa, RENTERS);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAutoPolicyStartDatePageAndRC2PageContentAR(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		ContactInfoAutoPage autoPolicyStartDatePage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToPolicyStartDatePage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoPolicyStartDatePage.verifyAutoHRCBundlePageContent(fsa, bundleApplicant.getAutoApplicant().getStateCode());
		autoPolicyStartDatePage.validateDisclaimers(fsa);
		autoPolicyStartDatePage.clickContactInfoPageCTAButton();
		autoPolicyStartDatePage.validateRC2ScreenBundle(fsa);
		fsa.assertAll();
	}
	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceBundleRentersFinalReviewQuotePage(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceBundleFinalReviewPage finalReviewPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToFinalReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		finalReviewPage.verifyBundleFinalReviewQuotePageContent(bundleApplicant, RENTERS, fsa);
		finalReviewPage.navigateBack();
		fsa.assertTrue(finalReviewPage.isOnFinalReviewPage(), "Browser back button is disabled on bundle final review page.");
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceBundleRentersJFMTPageAndNavigateBackToAutoJFMTP(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceHRCJustAFewMoreThingsBasePage rentersJFMTPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToBundlePropertyJustAFewMoreThingsPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		rentersJFMTPage.verifyBundlePropertyJustAFewMoreThingsPageContent(RENTERS, fsa);
		rentersJFMTPage.navigateBack();
		if (new DriverMismatchPage().isOnDriverMismatchPage()) {
			rentersJFMTPage.navigateBack();
		}
		AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
		fsa.assertTrue(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "Landed on auto few more things page - AR");
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceBundleRentersPropertyQuestionsPageContent(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceHRCAddressBasePage homePropertyQuestionsPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToAceHRCPropertyQuestionsPage(bundleApplicant);
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		homePropertyQuestionsPage.verifyAutoHRCBundlePageContent(RENTERS, bundleApplicant.getHrcApplicant(), farmersSoftAssert);
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceAutoRentersBundleReviewPageContent(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		if (new Random().nextBoolean()) {
			bundleApplicant.getAutoApplicant().setTestCategory(AWS_SCENARIOS);
		}
		AceBundleReviewQuotesPage autoRentersBundleQuoteSummaryPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToBundleQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		autoRentersBundleQuoteSummaryPage.verifyBundleReviewQuotePageContent(RENTERS, bundleApplicant, farmersSoftAssert);
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceBWAutoRentersBundleReviewPageContent(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		if (new Random().nextBoolean()) {
			bundleApplicant.getAutoApplicant().setTestCategory(AWS_SCENARIOS);
		}
		AceBundleReviewQuotesPage autoRentersBundleQuoteSummaryPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToBundleQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		autoRentersBundleQuoteSummaryPage.verifyBundleReviewQuotePageContent(RENTERS, bundleApplicant, farmersSoftAssert);
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceAutoRentersBundleAutoQuoteReviewPageContent(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		QuoteSummaryAutoPage  autoQuoteSummaryPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToBundleAutoQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		autoQuoteSummaryPage.verifyBundleAutoReviewQuotePageContent(RENTERS, farmersSoftAssert);
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceAutoRentersBundleAutoQuoteEditCoverage(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		QuoteSummaryAutoPage  autoQuoteSummaryPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToBundleAutoQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoQuoteSummaryPage.verifyAutoEditLiabilityCoverageInBundleFlow(fsa);
		autoQuoteSummaryPage.verifyAutoEditVehicleCoverageInBundleFlow(fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceBundleRentersQuoteReviewPageContent(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceHRCReviewQuoteBasePage rentersQuoteReviewPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToBundlePropertyQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		rentersQuoteReviewPage.verifyBundlePropertyQuoteReviewPage(RENTERS, fsa);
		rentersQuoteReviewPage.validateYouGetAllTheseWithYourPolicySection(fsa, RENTERS);
		rentersQuoteReviewPage.clickContinueToMoreCoveragesButton();
		AceHRCAdditionalCoveragesBasePage propertyOptionalCoveragesPage = new AceHRCAdditionalCoveragesBasePage();
		if (propertyOptionalCoveragesPage.isOnBundlePropertyOptionalCoveragesPage()) {
			propertyOptionalCoveragesPage.verifyBundleContent(RENTERS, true, fsa);
		} else {
			fsa.fail("Did not reach Optional Coverages Page" + NEWLINE);
		}
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, LA, MA, MS, MT})},dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void aceBundleRentersRestrictedMonolineAutoTest(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceBundleNavigationHelper navigationHelper = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE);
		navigationHelper.setMonoline(true);
		navigationHelper.completeAutoQuoteNavigation(bundleApplicant);
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		farmersSoftAssert.assertTrue(new QuoteSummaryAutoPage().isOnQuoteSummaryAutoPage(), "Ace auto quote summary page reached");
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MT, TX})},dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void aceBundleMonolineRentersTest(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		//addresses in this zip code are disabled for bundle, ok for renters
		if (bundleApplicant.getAutoApplicant().getStateCode().equals(TX)) {
			ApplicantAceHome hrcApplicant = bundleApplicant.getHrcApplicant();
			bundleApplicant.getAutoApplicant().setZipCode("77406");
			hrcApplicant.setZipCode("77406");
			hrcApplicant.setAddress("9626 Stratton Ridge Dr");
			hrcApplicant.setCity("Richmond");
			hrcApplicant.setStateCode(TX);
			bundleApplicant.setHrcApplicant(hrcApplicant);
		}
		AceBundleNavigationHelper navigationHelper = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE);
		navigationHelper.setMonoline(true);
		navigationHelper.navigateToHRCReviewDwellingCoveragePage(bundleApplicant);
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		farmersSoftAssert.assertTrue(new AceRentersReviewQuotePage().isOnReviewQuotePageAceRenters(), "Ace Renters quote summary page reached");
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyLimitedAvailabilityDialogContentAutoRentersBundleUnavailable(AceBundleApplicant bundleApplicant) throws Exception {
		AceBundleNavigationHelper navigationHelper = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE);
		AceBundleLimitedAvailabilityDialog limitedAvailabilityDialog = navigationHelper.navigateToLimitedAvailabilityDialog(bundleApplicant);
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		limitedAvailabilityDialog.verifyLimitedAvailabilityDialogContentWhenBundleNotAvailable(RENTERS, farmersSoftAssert);
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyLimitedAvailabilityDialogContentRentersBundleAutoRestricted(AceBundleApplicant bundleApplicant) throws Exception {
		//addresses in this zip code are disabled for bundle
		List<String> listOfRestrictedZipCodes =  new ArrayList<>(Arrays.asList("77022", "77304"));
		Collections.shuffle(listOfRestrictedZipCodes);
		bundleApplicant.getAutoApplicant().setZipCode(listOfRestrictedZipCodes.get(0));
		AceBundleNavigationHelper navigationHelper = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE);
		AceBundleLimitedAvailabilityDialog limitedAvailabilityDialog = navigationHelper.navigateToLimitedAvailabilityDialog(bundleApplicant);
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		limitedAvailabilityDialog.verifyRestrictedLimitedAvailabilityDialogContent("renters", farmersSoftAssert);
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void aceBundleAutoRestrictedRentersKnockoutTest(AceBundleApplicant bundleApplicant) throws Exception {
		List<String> listOfRestrictedZipCodes = new ArrayList<>(Arrays.asList("77022", "77304"));
		Collections.shuffle(listOfRestrictedZipCodes);
		bundleApplicant.getAutoApplicant().setZipCode(listOfRestrictedZipCodes.get(0));
		AceBundleNavigationHelper navigationHelper = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE);
		navigationHelper.navigateToSpeakToRepresentative(bundleApplicant);
		KnockoutInconveniencePage bundleKnockOutPage = new KnockoutInconveniencePage();
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		farmersSoftAssert.assertTrue(bundleKnockOutPage.isOnKnockOutPage(), "Knock out page reached");
		bundleKnockOutPage.verifyBundleKnockoutPageContent(AUTO_RENTERS_BUNDLE, farmersSoftAssert);
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateBundleFlowWhenSelectedTwoOrMoreClaimsAR(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceHRCAddressBasePage aceHRCPropertyTypeBasePage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToAceHRCPropertyQuestionsPage(bundleApplicant);
		aceHRCPropertyTypeBasePage.selectNumberOfPropertyLosses("Two or more");
		aceHRCPropertyTypeBasePage.scrollAndClickOnContinueButton();
		AceBundleLimitedAvailabilityDialog limitedAvailabilityDialog = new AceBundleLimitedAvailabilityDialog();
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		if (limitedAvailabilityDialog.isLimitedAvailabilityDialogDisplayed()) {
			limitedAvailabilityDialog.verifyPropertyLOBNotAvailableLimitedAvailabilityDialogContent(farmersSoftAssert);
			boolean continueToAuto = new Random().nextBoolean();
			if (continueToAuto) {
				testStep("Selecting \"Yes, Continue\" with auto quote");
				limitedAvailabilityDialog.selectYesContinue();
				verifyBundleDiscountHasDroppedAutoReviewQuotePage(RENTERS, farmersSoftAssert);
			} else {
				testStep("Selecting \"No thank you\" don't want to continue with auto quote");
				limitedAvailabilityDialog.selectNoThanks();
				KnockoutInconveniencePage bundleKnockOutPage = new KnockoutInconveniencePage();
				farmersSoftAssert.assertTrue(bundleKnockOutPage.isOnKnockOutPage(), "Knock out page reached");
				bundleKnockOutPage.verifyBundleKnockoutPageContent(PROPERTY_KNOCKOUT, farmersSoftAssert);
			}
		} else {
			farmersSoftAssert.fail("Limited availability dialog reached");
		}
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAR(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		autoApplicant.setLastName("Brown");
		bundleApplicant.setAutoApplicant(bundleApplicant.getAutoApplicant());
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoPropertyBundleToMonolineAutoAndPurchase(bundleApplicant, RENTERS, fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionARBW(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoPropertyBundleToMonolineAutoAndPurchase(bundleApplicant, RENTERS, fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyLandedOnRentersQuoteSummaryPageWhenSelectRentersFromBundleOptionAR(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoRentersBundleToMonolineRentersAndPurchase(bundleApplicant, fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyLandedOnRentersQuoteSummaryPageWhenSelectRentersFromBundleOptionARBW(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoRentersBundleToMonolineRentersAndPurchase(bundleApplicant, fsa);
		fsa.assertAll();
	}

	private void autoRentersBundleToMonolineRentersAndPurchase(AceBundleApplicant bundleApplicant, FarmersSoftAssert fsa) throws Exception {
		AceBundleReviewQuotesPage autoHomeBundleQuoteSummaryPage = new AceBundleReviewQuotesPage();
		if (!autoHomeBundleQuoteSummaryPage.isOnBundleReviewQuotesPage()) {
			autoHomeBundleQuoteSummaryPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToBundleQuoteReviewPage(bundleApplicant);
		}
		autoHomeBundleQuoteSummaryPage.selectSingleQuoteOptionInCPPopUp(RENTERS);
		autoHomeBundleQuoteSummaryPage.waitForSkeletonToBeGone();
		AceRentersReviewQuotePage aceRentersReviewQuotePage = new AceRentersReviewQuotePage();
		if (aceRentersReviewQuotePage.isOnBundlePropertyReviewQuotePage()) {
			verifyBundleDiscountHasDroppedHRCReviewQuotePage(fsa);

			// go to pay in full payment page and complete purchase using bank payment and validate eCheckout
			aceRentersReviewQuotePage.scrollAndClickOnContinueButton();
			AceHRCAdditionalCoveragesBasePage aceHRCAdditionalCoveragesBasePage = new AceHRCAdditionalCoveragesBasePage();
			aceHRCAdditionalCoveragesBasePage.clickContinueToFinalWrapupButton(true);
			if (!new ThankYouPageAce().quickIsOnThankYouPage()) {
				AceRentersJustAFewMoreThingsPage aceRentersJustAFewMoreThingsPage = new AceRentersJustAFewMoreThingsPage();
				aceRentersJustAFewMoreThingsPage.fillOutJustFewMoreThingsPageRentersLob(bundleApplicant.getHrcApplicant());
				AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
				if (aceHRCPaymentSelectionPage.isOnPaymentPage()) {
					aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayCardLabelRenters();
					AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
					aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
					aceHRCPaymentBasePage.waitForSpinnerToBeGone();
					aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, RENTERS);
					aceHRCPaymentBasePage.validateIfCompletePurchaseButtonIsEnabled(fsa, RENTERS);
				} else {
					fsa.fail("Did not reach payment selection page for quote " + bundleApplicant.getHrcApplicant().getQuoteNumber() + NEWLINE);
				}
			}
		} else {
			fsa.fail("Did not reach Renters quote summary page");
		}
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateBWLogoInAutoPagesBundleARBW(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		AceBundleNavigationHelper navigator = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE);
		AceBundleReviewQuotesPage aceBundleReviewQuotesPage = navigator.navigateToBundleQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		aceBundleReviewQuotesPage.validateBWLogoOnAutoPagesBWBundleFlow(fsa);
		navigator.setResumeFromPage("ContactInfoPage");
		navigator.navigateToBundleQuoteReviewPage(bundleApplicant);
		aceBundleReviewQuotesPage.goToDriverMismatchPageFromBundleReviewPageAndValidateBWLogoOnAutoPages(fsa, bundleApplicant);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateBundleChangesForRentersContactInfoPage(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceHomeContactInfoPage hrcPropertyPolicyStartPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToHRCPolicyStartPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		hrcPropertyPolicyStartPage.verifyBundleTextChangesForHRCContactInfoPage(fsa, false);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateBundleChangesForAutoFewMoreThingsPageARAndNavigateBackToPropertyTypePage(AceBundleApplicant bundleApplicant) throws Exception {
		boolean continueToBWAuto = new Random().nextBoolean();
		if(continueToBWAuto){
			modifyApplicantToTriggerBWFlow(bundleApplicant);
		}else{
			applicantAdjustment(bundleApplicant);
		}
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToBundleJustAFewMoreThingsPage(bundleApplicant);
		additionalInfoPolicyStartDateOneUI.verifyBundleChangesOnAdditionalInfoPageAuto(fsa, RENTERS);

		additionalInfoPolicyStartDateOneUI.navigateBack();
		fsa.assertTrue(new AceHRCAdditionalCoveragesBasePage().isOnBundlePropertyOptionalCoveragesPage(), "Landed on HRC additional coverage page - AR");
		AceRentersReviewQuotePage aceRentersReviewQuotePage = new AceRentersReviewQuotePage();
		aceRentersReviewQuotePage.navigateBack();
		fsa.assertTrue(aceRentersReviewQuotePage.isOnReviewQuotePageAceRenters(), "Landed on renters review quote page - AR");
		QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
		quoteSummaryAutoPage.navigateBack();
		fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Landed on auto review quote page - AR");
		AceBundleReviewQuotesPage aceBundleReviewQuotesPage = new AceBundleReviewQuotesPage();
		aceBundleReviewQuotesPage.navigateBack();
		fsa.assertTrue(aceBundleReviewQuotesPage.isOnBundleReviewQuotesPage(), "Landed on bundle review quote page - AR");
		AceHRCContactInfoBasePage aceHRCContactInfoBasePage = new AceHomeContactInfoPage();
		aceHRCContactInfoBasePage.navigateBack();
		fsa.assertTrue(aceHRCContactInfoBasePage.isOnBundlePolicyStartDatePage(), "Landed on property question page - AH");
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyLandedOnRentersReviewQuotePageWhenUsingKOVINAR(AceBundleApplicant bundleApplicant) throws Exception {
		boolean continueToBWAuto = new Random().nextBoolean();
		if (continueToBWAuto) {
			modifyApplicantToTriggerBWFlow(bundleApplicant);
		} else {
			applicantAdjustment(bundleApplicant);
		}
		// Set ZHWUA6ZX2NLA18047 VIN for auto KO
		setKOVINInBundleApplicant(bundleApplicant);

		AceBundleNavigationHelper aceBundleNavigationHelper = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE);
		aceBundleNavigationHelper.setResumeFromPage("switchToMonoline");
		aceBundleNavigationHelper.navigateToHRCReviewDwellingCoveragePage(bundleApplicant);
		AceRentersReviewQuotePage aceRentersReviewQuotePage = new AceRentersReviewQuotePage();
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		if (aceRentersReviewQuotePage.isOnReviewQuotePageAceRenters()) {
			aceRentersReviewQuotePage.verifyNotAbleToOfferBundleCardContent(fsa, RENTERS);
		} else {
			fsa.fail("Did not reach renters review quote page " + bundleApplicant.getHrcApplicant().getQuoteNumber() + NEWLINE);
		}
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceAutoRentersPolicyStartDateInFewMoreThingsPage(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceBundleReviewQuotesPage  autoRentersBundleQuoteSummaryPage = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToBundleQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoRentersBundleQuoteSummaryPage.validatePolicyStartDateAutoHomeFewMoreThingsPage(fsa, bundleApplicant);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceAutoRentersBundleRetrievedQuoteAllowsMonolineChoice(AceBundleApplicant bundleApplicant) throws Exception {
		AceBundleNavigationHelper navigatorHelper = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE);
		//Randomly pick Farmers or BW auto quote
		if (new Random().nextBoolean()) {
			modifyApplicantToTriggerBWFlow(bundleApplicant);
		} else {
			applicantAdjustment(bundleApplicant);
		}
		AceBundleReviewQuotesPage autoRentersBundleQuoteSummaryPage = navigatorHelper.navigateToBundleQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		navigatorHelper.retrieveAceBundleQuote(bundleApplicant, navigatorHelper.getBundleQuoteNumber());
		autoRentersBundleQuoteSummaryPage.selectStepper(AUTO_INFO);
		new NameAndDobPage().validateBundleFieldsAreDisabledOnRetrieve(bundleApplicant.getAutoApplicant(), fsa);
		retrieveQuoteAndGoToBundleReviewPage(bundleApplicant, navigatorHelper, autoRentersBundleQuoteSummaryPage, fsa);
		fsa.assertTrue(autoRentersBundleQuoteSummaryPage.isOnBundleReviewQuotesPage(), "Retrieved quote navigated to Bundle Quote Summary page");
		//Select Auto monoline and purchase quote
		autoPropertyBundleToMonolineAutoAndPurchase(bundleApplicant, RENTERS, fsa);
		retrieveQuoteAndGoToBundleReviewPage(bundleApplicant, navigatorHelper, autoRentersBundleQuoteSummaryPage, fsa);
		fsa.assertTrue(autoRentersBundleQuoteSummaryPage.isOnBundleReviewQuotesPage(), "Retrieved quote navigated to Bundle Quote Summary page");
		//Select Renters monoline and purchase quote
		autoRentersBundleToMonolineRentersAndPurchase(bundleApplicant, fsa);
		retrieveQuoteAndGoToBundleReviewPage(bundleApplicant, navigatorHelper, autoRentersBundleQuoteSummaryPage, fsa);
		fsa.assertTrue(autoRentersBundleQuoteSummaryPage.isOnBundleReviewQuotesPage(), "Retrieved quote navigated to Bundle Quote Summary page");
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX, VA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateChangeZipcodeDifferentState(AceBundleApplicant bundleApplicant) throws Exception {
		String newZipcode = bundleApplicant.getAutoApplicant().getStateCode().equals(TX)? "24502" : "75703";
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AutoEnterAddressPage addressPage = changeZipcode(bundleApplicant, newZipcode);
		addressPage.validateZipcodeChange(bundleApplicant.getAutoApplicant().getStateName(), false, fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateChangeZipcodeSameState(AceBundleApplicant bundleApplicant) throws Exception {
		String newZipcode = bundleApplicant.getAutoApplicant().getZipCode().equals("75703")? "75219" : "75703";
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AutoEnterAddressPage addressPage = changeZipcode(bundleApplicant, newZipcode);
		addressPage.validateZipcodeChange(bundleApplicant.getAutoApplicant().getStateName(), true, fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateChangeZipcodeInvalidState(AceBundleApplicant bundleApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		changeZipcode(bundleApplicant, "57915");
		KnockoutLeadFormPage knockoutLeadFormPage = new KnockoutLeadFormPage();
		knockoutLeadFormPage.validatePageContent(fsa);
		fsa.assertAll();
	}

	private AutoEnterAddressPage changeZipcode(AceBundleApplicant bundleApplicant, String newZipcode) throws Exception {
		applicantAdjustment(bundleApplicant);
		new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToAutoLetsBeginPage(bundleApplicant);
		AutoEnterAddressPage addressPage = new AutoEnterAddressPage();
		addressPage.changeZipcode(newZipcode);
		addressPage.clickAddressPageCtaButton();
		return addressPage;
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceAutoRentersBundleWhenSelectingRentersLOBInLandingPage(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceBundleNavigationHelper navigatorHelper = new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE);
		navigatorHelper.setResumeFromPage(LOB_RENTERS);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		fsa.assertTrue(navigatorHelper.navigateToECheckoutPage(bundleApplicant).isPaymentSuccessfulMessageCorrect(), "Quote A/R bundle completed bind process");
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = PEWC)
	public void aceBundlePEWCScreen(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToAutoLetsBeginPage(bundleApplicant);
		new AutoEnterAddressPage().captureBundlePEWC();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,TX})}, dataProviderClass = AceBundleDataProviders.class, groups = {PRODUCTION_VALIDATION})
	public void verifyAceAutoRentersBundleLandedOnOptionalCoveragePageProd(AceBundleApplicant bundleApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		applicantAdjustment(bundleApplicant);
		setVINInBundleApplicantForNonBWAuto(bundleApplicant);
		setDataForProdValidation(bundleApplicant);
		//navigator handles the messaging of getting/not getting to the destination
		new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToBundleQuoteReviewPage(bundleApplicant);
		fsa.assertAll();
	}

	@Test (dataProvider = SqlDataProviders.STATES_DATA_PROVIDER_NAME, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = RANDOM_STATE)}, groups = BUNDLE)
	public void landingPageContentAndErrorMessagesTest(State state) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		LandingPage landingPage = new LandingPage();
		landingPage.landingPageValidation(fsa);
		landingPage.landingPageErrorValidation(fsa);
		fsa.assertAll("Landing page tested using " + state.getStateName());
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = ACE_STABILITY)
	public void autoRentersBundleEnvironmentStabilityTest(AceBundleApplicant bundleApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		applicantAdjustment(bundleApplicant);
		setVINInBundleApplicantForNonBWAuto(bundleApplicant);
		new AceBundleNavigationHelper(AUTO_RENTERS_BUNDLE).navigateToBundlePropertyOptionalCoveragesPage(bundleApplicant);
		fsa.assertAll();
	}

}
