package com.farmers.ffq.acerenters;

import com.farmers.ffq.ace.hrc.common.AceHRCReviewQuoteBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCThankYouBasePage;
import com.farmers.ffq.ace.renters.AceRentersContactInfoPage;
import com.farmers.ffq.ace.renters.AceRentersNavigationHelper;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersKnockOutTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_PPC_ZIP_MISMATCH_KO, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_KNOCKOUT_FLOW})
    public void ppcZipMismatchKORenters(ApplicantAceHome applicant) throws Exception {
        new AceRentersNavigationHelper().navigateToAceRentersContactInfoPage(applicant);
        AceRentersContactInfoPage aceRentersContactInfoPage = new AceRentersContactInfoPage();
        aceRentersContactInfoPage.enterPolicyStartDate(applicant);
        aceRentersContactInfoPage.enterFireHydrantData(applicant);
        aceRentersContactInfoPage.fillOutBundleAndSave(applicant, HOME);
        aceRentersContactInfoPage.clickContinueToQuoteButton();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
        if (koPage.isOnKnockOutPage()) {
            koPage.validateHRCKnockOuts(fsa);
            Log.info("Ace Renters PPC Zip mismatch KO ", true);
        } else {
            Log.info("Did not reach Ace Renters KO page ", true);
            fsa.fail();
        }
        fsa.assertAll("Validate Ace Renters PPC Zip mismatch KO");
    }
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_PPC_FIRE_HYDRANT_KO, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_KNOCKOUT_FLOW})
    public void ppcFireHydrantKORenters(ApplicantAceHome applicant) throws Exception {
        AceHRCReviewQuoteBasePage aceHRCReviewQuoteBasePage = new AceRentersNavigationHelper().navigateToAceRentersReviewQuotePage(applicant);
        aceHRCReviewQuoteBasePage.clickContinueButton();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCThankYouBasePage aceHomeThankYouPage = new AceHRCThankYouBasePage();
        if (aceHomeThankYouPage.isOnThankYouPage()) {
            aceHomeThankYouPage.clickViewPayInFullPricing();
            aceHomeThankYouPage.validateThankYouPage(applicant, fsa, RENTERS, false);
            Log.info("Ace Renters PPC fire hydrant KO ", true);
        } else {
            Log.info("Did not reach Ace Renters Thank you page ", true);
            fsa.fail();
        }
        fsa.assertAll("Validate Ace Renters PPC fire hydrant KO");
    }

}
