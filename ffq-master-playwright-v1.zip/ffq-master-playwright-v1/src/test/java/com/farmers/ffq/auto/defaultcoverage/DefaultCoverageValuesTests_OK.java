package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class DefaultCoverageValuesTests_OK extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = false)
    public void testDefaultCoverageValues_OK_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "OK_25K50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = false)
    public void testDefaultCoverageValues_OK_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "OK_25K50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "OK_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "OK_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "OK_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "OK_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "OK_50K100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "OK_50K100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "OK_100K200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "OK_100K200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "OK_100K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "OK_100K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "OK_300K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "OK_300K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "OK_250K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "OK_250K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "OK_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "OK_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_500K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "OK_500K1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_500K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "OK_500K1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_1000K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "OK_1000K1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_1000K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "OK_1000K1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "OK_50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "OK_50K_");
    }
   @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "OK_75K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "OK_75K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "OK_100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "OK_100K_");
    }
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "OK_200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "OK_200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "OK_300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "OK_300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "OK_500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "OK_500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "OK_1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = OK)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OK_1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "OK_1000K_");
    }

}
