package com.farmers.ffq.acerenters;

import com.farmers.ffq.ace.hrc.common.AceHRCConsolidatedPaymentPage;
import com.farmers.ffq.ace.hrc.common.AceHRCJustAFewMoreThingsBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCThankYouBasePage;
import com.farmers.ffq.ace.renters.AceRentersJustAFewMoreThingsPage;
import com.farmers.ffq.ace.renters.AceRentersNavigationHelper;
import com.farmers.ffq.ace.renters.AceRentersReviewQuotePage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.JFMT_PAGE;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersJustAFewMoreThingsTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_JAFMT_PAGE})
    public void testValidateContentOfJustFewMoreThingsPageRentersLob(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceRentersNavigationHelper().navigateToAceRentersJustAFewMoreThingsPage(applicant);

        AceRentersJustAFewMoreThingsPage aceRentersJustAFewMoreThingsPage = new AceRentersJustAFewMoreThingsPage();
        jfmtPage.verifyJustAFewMoreThingsHeader(fsa);
        jfmtPage.validatePolicyStartDateSection(fsa, applicant, RENTERS);
        jfmtPage.validateOtherQuestionsSection(applicant, fsa, RENTERS);
        aceRentersJustAFewMoreThingsPage.validateContentOfMailingAndOtherMailingAddress(fsa);
        jfmtPage.validateSaveQuoteModal(true);
        jfmtPage.validateAgentSection(fsa, JFMT_PAGE, applicant.getAgentId(), RENTERS);
        jfmtPage.validateQuoteText(JFMT_PAGE, applicant.getQuoteNumber(), fsa, true);
        fsa.assertAll("Validate JFMT content");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE})
    public void testBusinessOperatedOnPremisesKnockOutScreenRentersLob(ApplicantAceHome applicant) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceRentersNavigationHelper().navigateToAceRentersJustAFewMoreThingsPage(applicant);
        AppStore sessionStorageData = jfmtPage.getSessionStorageAppStore();
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        AceRentersJustAFewMoreThingsPage aceRentersJustAFewMoreThingsPage = new AceRentersJustAFewMoreThingsPage();
        aceRentersJustAFewMoreThingsPage.fillOutFMTPWithBusinessOperatedOnPremisesSelectedRentersLob(applicant);

        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, sessionStorageData.getData().getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - Business operated on premises");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE})
    public void testPetWithBiteHistoryKnockOutScreenRentersLob(ApplicantAceHome applicant) throws Exception {
        AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceRentersNavigationHelper().navigateToAceRentersJustAFewMoreThingsPage(applicant);
        AppStore sessionStorageData = jfmtPage.getSessionStorageAppStore();
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        AceRentersJustAFewMoreThingsPage aceRentersJustAFewMoreThingsPage = new AceRentersJustAFewMoreThingsPage();
        aceRentersJustAFewMoreThingsPage.fillOutFMTPWithPetWithBiteHistorySelectedRentersLob(applicant);

        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, sessionStorageData.getData().getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - Pet bite history");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE})
    public void validateJFMTBackAndForthAndRC3LoadingScreenRenters(ApplicantAceHome applicant) throws Exception {
        AceRentersJustAFewMoreThingsPage rentersJFMTPage = new AceRentersNavigationHelper().navigateToAceRentersJustAFewMoreThingsPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        driver().navigate().refresh();
        rentersJFMTPage.waitForSpinnerToBeGone();
        rentersJFMTPage.navigateBack();
        AceRentersReviewQuotePage reviewQuotePage = new AceRentersReviewQuotePage();
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePageAceRenters(2), "Did not land on the Review Quote page immediately after navigating back from the JFMT page.");
        reviewQuotePage.clickOnContinueButton();
        Assert.assertTrue(rentersJFMTPage.isOnJFMTPage(true), "Did not land back on the JFMT page after clicking Continue from the Review Quote page.");
        rentersJFMTPage.fillOutFMTPWithDogsOnPremisesSelectedRentersLob(applicant, fsa, true);
        fsa.assertTrue(new AceHRCConsolidatedPaymentPage().isOnConsolidatedPaymentPage(), "Did not land on Consolidated Payment Page after selecting Dogs on premises question");
        fsa.assertAll("Validate JFMT back and forth navigation and RC3 loading screen - " + RENTERS);
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE})
    public void testKnockOutScreenWhenAllOtherQuestionsAreSelectedRentersLob(ApplicantAceHome applicant) throws Exception {
        AceRentersJustAFewMoreThingsPage jfmtPage = new AceRentersNavigationHelper().navigateToAceRentersJustAFewMoreThingsPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        jfmtPage.fillOutFMTPWithAllOtherQuestionsSelectedRentersLob(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, applicant.getQuoteNumber());
        fsa.assertAll("Validated KnockOut Scenario from JFMT other questions - all other questions are selected");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_THANK_YOU_SCREEN_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_JAFMT_PAGE})
    public void testValidateThankYouPageCannotGoBindRentersLob(ApplicantAceHome applicant) throws Exception {
        //F91675: FFQ - Tech Feature - Additional checks for bind disabled
        applicant.setAddress("412 E Chandler Blvd");
        applicant.setCity("Phoenix");
        applicant.setZipCode("85048");
        applicant.setStateCode("AZ");
        applicant.setState("Arizona");
        try {
            AceRentersReviewQuotePage aceRentersReviewQuotePage = (new AceRentersNavigationHelper()).navigateToAceRentersReviewQuotePage(applicant);
            aceRentersReviewQuotePage.clickContinueButton();
            AceHRCThankYouBasePage thankYouPage = new AceHRCThankYouBasePage();
            thankYouPage.attemptToChangeUrlOnThankYouPage(RENTERS);
        } catch (Exception e) {
            if (e.getMessage().equals("Did not reach AceHomeThankYouPage")) {
                AceHRCJustAFewMoreThingsBasePage aceJAFMTPage = new AceHRCJustAFewMoreThingsBasePage();
                Assert.assertTrue(aceJAFMTPage.isOnJFMTPage(false), "Quote reached to Just a few more things page.");
                Log.info(">> Reached Just a few more things page.");
            } else {
                throw e;
            }
        }
    }
}
