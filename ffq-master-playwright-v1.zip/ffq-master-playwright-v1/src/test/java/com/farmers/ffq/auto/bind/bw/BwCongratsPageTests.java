package com.farmers.ffq.auto.bind.bw;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.auto.pages.bw.BwCongratulationsPage;
import com.farmers.ffq.auto.pages.bw.BwPaymentSummaryPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class BwCongratsPageTests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {MT})},
    		dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void bwValidateCongratsPage(AutoApplicant applicant) throws Exception {
        applicant.setLastName("Threeoabaa");
        applicant.setTestScenario("BW->" + applicant.getTestScenario());
        applicant.getDiscounts().get(0).setSignalSignup(false);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        new AceAutoNavigationHelper(switchTestToBDQIfNeeded(applicant)? quoteFlow.BDQ: quoteFlow.DEFAULT).navigateToPaymentSelectionPage(applicant);
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        processBwDocuSignAndPayments(PAY_IN_FULL, false);
        sleep(6);
        bwPaymentSummaryPage.clickCompletePurchaseButton();
        sleep(3);
        BwCongratulationsPage bwCongratulationsPage = new BwCongratulationsPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        testStepAssert(bwCongratulationsPage.isOnBwCongratsPage(), "User should be on the Congrats page for bw bind", true);
        bwCongratulationsPage.validateBwCongratsPage(softAssert, applicant);
        bwCongratulationsPage.validateNavigateBackFromBWCongratsPage(softAssert);
        softAssert.assertAll();
    }

}
