package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;

import org.apache.commons.lang3.RandomUtils;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Optional;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class FfqAutoAdaTests extends BaseTest {

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
			attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})},
			dataProviderClass = AutoDataProviders.class, groups = {ADA_SUITE, ACE_AUTO_ADA_SUITE})
	public void validateADA(AutoApplicant applicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		if (new BasePage().isADATestingEnabled()) {
			Reporter.pass("Perform ADA tests on the Ace Auto pages");
			applicant.getVehicles().forEach(vehicle -> {
				vehicle.setUseVIN(false);
				vehicle.setOwnership(RandomUtils.nextBoolean() ? "Financed" : "Leased");
			});
			updateApplicantDataToAvoidPossibleBw(applicant);
			applicant.setLastName("Brown");
			NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper(quoteFlow.AGENT).navigateToNameAndDobPage(applicant);
			// validate name and date of birth ada
			nameAndDobPage.validateADA_NameAndDobPage();

			// fill out name and dob form and continue to the next page
			nameAndDobPage.filloutApplicantForm(applicant);
			nameAndDobPage.waitForSpinnerToBeGone();
			AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();

			// validate ada in the address page
			autoEnterAddressPage.validateADA_AutoEnterAddressPage();

			// fill out the address page and continue
			autoEnterAddressPage.fillOutAddressPage(applicant);

			// validate ada on the WhoShouldWeInsurePage
			WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
			if (whoShouldWeInsurePage.isOnWhoShouldWeInsurePage()) {
				whoShouldWeInsurePage.validateADA_whoShouldWeInsurePage();

				// fill out the WhoShouldWeInsurePage
				whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
				whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
				whoShouldWeInsurePage.clickOnEditDriverLink();
				whoShouldWeInsurePage.clickCloseIcon();

				// ada validation for the save quote side sheet
				if (whoShouldWeInsurePage.isAutoSaveDisabled()) {
					whoShouldWeInsurePage.clickOnSaveQuoteButton();
					whoShouldWeInsurePage.clickSaveQuoteModalSubmitButton();
					whoShouldWeInsurePage.performADATesting("SaveQuoteSideSheet", MARKETING_IT, ACE_AUTO);
					whoShouldWeInsurePage.clickCloseIcon();
				}

				// set remaining values and continue to the next page
				whoShouldWeInsurePage.enterEmailAndPhoneNumber(applicant);
				whoShouldWeInsurePage.clickOnContinueButton();
			}
			HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
			if (heresWhatWeFoundPage.isOnHeresWhatWeFoundPageShort()) {
				heresWhatWeFoundPage.validateADA_HeresWhatWeFoundPage();
			}
			// validate ada on VehiclesReviewPage
			VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
			vehicleReviewPage.validateADA_VehicleReviewPage();

			// set Vehicles Details and continue
			vehicleReviewPage.addVehicleDetails(applicant);
			vehicleReviewPage.clickOnContinueButton();

			// validate ada for the driver review page
			DriverReviewPage driverReviewPage = new DriverReviewPage();
			driverReviewPage.validateADA_DriverReviewPage();
			driver().navigate().refresh();
			driverReviewPage.isOnDriverReviewPage();
			driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
			driverReviewPage.clickContinueButton();
			SignalPageOneUI signalPage  = new SignalPageOneUI();
			if(!driverReviewPage.isSignalDiscountDisabledState(applicant.getStateCode())) {
				signalPage.validateADA_AceSignalPage();
				//setting this to true to expose signal section later
				signalPage.processSignalPage(true);
			}

			ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
			contactInfoAutoPage.validateADA_ContactInfoAutoPage();
			contactInfoAutoPage.setValuesAndContinue(applicant);
			QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
			ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
			if(!quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
				if(continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
					continueWithBristolWestPage.validateADA_ContinueWitBristoWestPage();
					continueWithBristolWestPage.continueWithBwPopUp();
				}
				SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
				if(selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
					selectAQuoteToReviewPage.validateADA_SelectAQuoteToReviewPage();
					selectAQuoteToReviewPage.clickContinueMyQuote();
				}
			}

			quoteSummaryAutoPage.validateADA_QuoteSummaryAutoPage();
			quoteSummaryAutoPage.clickOnStartCheckoutButton();

			// Additional Info Page
			AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
			additionalInfoPolicyStartDateOneUI.validateADA_AdditionalInfoPage();
			AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
			additionalInfoSignalEnrollmentSectionOneUI.validateADA_AdditionalInfoSignalEnrollmentSection();
			AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
			AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
			additionalInfoVehicleSectionOneUI.validateADA_AdditionalInfoPageVehicleSection();
			AppStore retrieveQuoteResponseSessionStorage = quoteSummaryAutoPage.getSessionStorageAppStore();
			additionalInfoPolicyStartDateOneUI.verifyPolicyStartDateSection(retrieveQuoteResponseSessionStorage, true, fsa);
			AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
			additionalInfoVehicleSectionOneUI.verifyVehicleSection(retrieveQuoteResponseSessionStorage, true, fsa);
			additionalInfoDriverSectionOneUI.enterDriverLicenseNumber(retrieveQuoteResponseSessionStorage);
			additionalInfoDriverSectionOneUI.enterMatureDriverSafetyCourseDate(retrieveQuoteResponseSessionStorage.getData().getLandingStateCode());
			additionalInfoSignalEnrollmentSectionOneUI.verifySignalEnrollmentSection(retrieveQuoteResponseSessionStorage, true, fsa);

			additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();
			additionalInfoContinueToPaymentOneUI.validateADA_PaymentSummaryPage();
			additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentPayInFull();
			AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
			autoPolicyPaymentBasePage.validateADA_PayInFullPage();
			driver().navigate().back();
			additionalInfoContinueToPaymentOneUI.isOnContinueToPaymentPage();
			additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();

			autoPolicyPaymentBasePage.validateADA_AutoPolicyPaymentMonthlyPay();
			driver().navigate().back();
			additionalInfoContinueToPaymentOneUI.isOnContinueToPaymentPage();
			additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayCard();

			PolicyDebitCreditPayment autoPolicyDebitCreditPayment = new PolicyDebitCreditPayment();
			autoPolicyDebitCreditPayment.validateADA_AutoPolicyPaymentAutoPayCard();
			autoPolicyPaymentBasePage.clickSetUpPaymentButton();
			autoPolicyDebitCreditPayment.addCardPaymentMethod(MASTER_CARD, ZIP_CODE);
			performADATesting(autoPolicyDebitCreditPayment.getClass().getSimpleName() + "_AfterPaymentMethodAdded", MARKETING_IT, ACE_AUTO);
			autoPolicyPaymentBasePage.clickCompletePurchaseButton();

			EcheckoutSuccessfulPageOneUI echeckoutSuccessfulPageOneUI = new EcheckoutSuccessfulPageOneUI();
			echeckoutSuccessfulPageOneUI.waitForSpinnerToBeGone();
		} else {
			Log.warn("adaTestingEnabled flag not set, skipping ADA testing");
		}
		fsa.assertAll();
	}

}
