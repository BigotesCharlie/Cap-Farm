package com.farmers.ffq.acehome;


import com.farmers.ffq.ace.home.AceHomeContactInfoPage;
import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.home.AceHomeReviewQuotePage;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.*;
import static com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage.DID_NOT_REACH;
import static com.farmers.ffq.dataproviders.DataProviders.ONE_APPLICANT_PER_STATE;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeRetrieveQuoteTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_RETRIEVE_FLOW})
    public void testRetrieveNonRatedQuoteHome(ApplicantAceHome applicant) throws Exception {
        AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceHomeNavigationHelper().navigateToAceHomeDwellingCoveragePage(applicant, LOB_HOME, HOME);
        String dwellingCoverageAmount = dwellingCoveragePage.getDwellingCoverageAmount();
        String dwellingCoverageQualityGrade = dwellingCoveragePage.getDwellingCoverageQualityGrade();
        List<String> discountsBeforeRetrieve = dwellingCoveragePage.getDiscounts();
        Collections.sort(discountsBeforeRetrieve);

    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);

        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        if (qualityGradePage.isQualityGradePageAvailable()) {
            // [Quality grade] page
            Assert.assertTrue(qualityGradePage.isOnQualityGradePage(), "Did not reach Quality grade page.");
            qualityGradePage.validateHeaderAndSubHeaderForQualityGradePage(fsa, HOME);
            qualityGradePage.validateAddressOnQualityGradePage(fsa, HOME);
            qualityGradePage.verifyDisplayedFeatures(fsa, applicant);
            qualityGradePage.validateDiscounts(QUALITY_GRADE, discountsBeforeRetrieve, fsa);
            qualityGradePage.clickContinueButton();
        } else {
            // [Property details + Quality grade] page
            Assert.assertTrue(qualityGradePage.isOnPropertyDetailsQualityGradePage(true), "Did not reach Property details + Quality grade page.");
            qualityGradePage.validateHeaderForQualityGradeSection(fsa, HOME);
            qualityGradePage.validateAddressOnQualityGradeSection(fsa, HOME);
            qualityGradePage.verifyDisplayedFeatures(fsa, applicant);
        }

        // Validate [Property details] page
        AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
        Assert.assertTrue(propertyDetailsPage.isOnPropertyDetailsPage(), "Did not reach Property details page.");
        fsa.assertTrue(propertyDetailsPage.isPageTitleDisplayed(), "Property details page title is displayed.");
        propertyDetailsPage.validatePropertyDetails(applicant, HOME, fsa);
        propertyDetailsPage.validateDiscounts(PROPERTY_DETAILS, discountsBeforeRetrieve, fsa);
        propertyDetailsPage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        propertyDetailsPage.clickContinueButton();

        // Validate [Additional info] page
        AceHRCAdditionalInfoBasePage additionalInfo = new AceHRCAdditionalInfoBasePage();
        Assert.assertTrue(additionalInfo.isOnAdditionalInfoPage(), "Did not reach Additional info page.");
        additionalInfo.validateAdditionalInfoSelections(applicant, fsa);
        additionalInfo.clickContinueButton();

        // Validate [About You] page
        if (!additionalInfo.isNewFlowEnabledState(applicant.getStateCode())) {
            AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
            Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "Did not reach About you page.");
            aboutYouPage.validateAboutYouSelections(applicant, false, fsa);
            aboutYouPage.clickContinueButton();
        }

        // Validate [Contact info] page
        AceHomeContactInfoPage contactInfoPage = new AceHomeContactInfoPage();
        Assert.assertTrue(contactInfoPage.isOnContactInfoPage(true), "Did not reach Contact info page.");
        contactInfoPage.validateContactInfoSelections(applicant, false, HOME, fsa);
        contactInfoPage.clickOnAgreeAndSubmitButton();

        // Validate [Dwelling coverage] page
        AceHRCDwellingCoverageBasePage dwellingCoverageBasePage = new AceHRCDwellingCoverageBasePage();
        Assert.assertTrue(dwellingCoverageBasePage.isOnDwellingCoveragePage(), "Did not reach Dwelling coverage page.");
        fsa.assertEquals(dwellingCoveragePage.getDwellingCoverageAmount(), dwellingCoverageAmount,
                "Dwelling coverage page - dwelling coverage amount.");
        fsa.assertEquals(dwellingCoveragePage.getDwellingCoverageQualityGrade(), dwellingCoverageQualityGrade,
                "Dwelling coverage page - dwelling coverage quality grade.");
        List<String> discountsAfterRetrieve = dwellingCoveragePage.getDiscounts();
        Collections.sort(discountsAfterRetrieve);
        fsa.assertEquals(discountsAfterRetrieve, discountsBeforeRetrieve, "Dwelling coverage page - discounts.");
        fsa.assertEquals(dwellingCoveragePage.getAceQuoteNumberInThePage(), applicant.getQuoteNumber(),
                "Dwelling coverage page - dwelling coverage page quote number.");

        fsa.assertAll("Ace Home - Retrieve non-rated quote.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_RETRIEVE_FLOW})
    public void testRetrieveRatedQuoteHome(ApplicantAceHome applicant) throws Exception {
        AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceHomeNavigationHelper().navigateToAceHomeDwellingCoveragePage(applicant, LOB_HOME, HOME);
        String stateCode = applicant.getStateCode();
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        String dwellingCoverageAmount = dwellingCoveragePage.getDwellingCoverageAmount();
        String dwellingCoverageQualityGrade = dwellingCoveragePage.getDwellingCoverageQualityGrade();
        dwellingCoveragePage.clickContinueButton();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        String quotePrice = reviewQuotePage.getQuotePriceOnCard();
        List<String> discountsBeforeRetrieve = reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList());

        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);

        // Validate [Review quote] page
        reviewQuotePage = new AceHomeReviewQuotePage();
        fsa.assertTrue(reviewQuotePage.isSnackBarMessageDisplayed("Welcome back " + applicant.getFirstName()), "Welcome back snack bar message is displayed.");
        reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);

        fsa.assertEquals(reviewQuotePage.getQuotePriceOnCard(), quotePrice, "Review quote page - quote premium after retrieval match.");
        reviewQuotePage.verifyQuotePresentmentCard(stateCode, fsa);
//        reviewQuotePage.clickPriceAlternative();
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        fsa.assertEquals(reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList()), discountsBeforeRetrieve,
                "Review quote page - quote discounts after retrieval match.");
        reviewQuotePage.selectStepper(ENTER_INFO);  // move back to the Property details page, using stepper

        if (reviewQuotePage.isNewFlowEnabledState(applicant.getStateCode())) {
            AceHRCPropertyInfoBasePage propertyInfoPage = new AceHRCPropertyInfoBasePage();
            Assert.assertTrue(propertyInfoPage.isOnPropertyInfoPage(false), "Did not reach Property info page.");
            propertyInfoPage.checkSelectedValues(fsa, applicant, HOME);
            propertyInfoPage.clickContinueButton();
        }
        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        if (qualityGradePage.isQualityGradePageAvailable()) {
            // [Quality grade] page
            Assert.assertTrue(qualityGradePage.isOnQualityGradePage(), "Did not reach Quality grade page.");
            qualityGradePage.validateHeaderAndSubHeaderForQualityGradePage(fsa, HOME);
            qualityGradePage.validateAddressOnQualityGradePage(fsa, HOME);
            qualityGradePage.verifyDisplayedFeatures(fsa, applicant);
            qualityGradePage.validateDiscounts(QUALITY_GRADE, discountsBeforeRetrieve, fsa);
            qualityGradePage.clickContinueButton();
        } else {
            // [Property details + Quality grade] page
            Assert.assertTrue(qualityGradePage.isOnPropertyDetailsQualityGradePage(true), "Did not reach Property details + Quality grade page.");
            qualityGradePage.validateHeaderForQualityGradeSection(fsa, HOME);
            qualityGradePage.validateAddressOnQualityGradeSection(fsa, HOME);
            qualityGradePage.verifyDisplayedFeatures(fsa, applicant);
        }

        // Validate [Property details] page
        AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
        Assert.assertTrue(propertyDetailsPage.isOnPropertyDetailsPage(), "Did not reach Property details page.");
        fsa.assertEquals(propertyDetailsPage.getPageTitle(), "Here's what we have so far", "Property details page title after quote retrieval.");
        propertyDetailsPage.validatePropertyDetails(applicant, HOME, fsa);
        propertyDetailsPage.validateDiscounts(PROPERTY_DETAILS, discountsBeforeRetrieve, fsa);
        propertyDetailsPage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        propertyDetailsPage.clickContinueButton();

        // Validate [Additional info] page
        AceHRCAdditionalInfoBasePage additionalInfo = new AceHRCAdditionalInfoBasePage();
        Assert.assertTrue(additionalInfo.isOnAdditionalInfoPage(), "Did not reach Additional info page.");
        additionalInfo.validateAdditionalInfoSelections(applicant, fsa);
        additionalInfo.clickContinueButton();

        // Validate [About You] page
        if (!additionalInfo.isNewFlowEnabledState(applicant.getStateCode())) {
            AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
            Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "Did not reach About you page.");
            aboutYouPage.validateAboutYouSelections(applicant, true, fsa);
            aboutYouPage.clickContinueButton();
        }

        // Validate [Contact info] page
        AceHomeContactInfoPage contactInfoPage = new AceHomeContactInfoPage();
        Assert.assertTrue(contactInfoPage.isOnContactInfoPage(true), "Did not reach Contact info page.");
        contactInfoPage.validateContactInfoSelections(applicant, true, HOME, fsa);
        contactInfoPage.clickOnAgreeAndSubmitButton();

        // Validate [Dwelling coverage] page
        AceHRCDwellingCoverageBasePage dwellingCoverageBasePage = new AceHRCDwellingCoverageBasePage();
        Assert.assertTrue(dwellingCoverageBasePage.isOnDwellingCoveragePage(), "Did not reach Dwelling coverage page.");
        fsa.assertEquals(dwellingCoveragePage.getDwellingCoverageAmount(), dwellingCoverageAmount,
                "Dwelling coverage page - dwelling coverage amount.");
        fsa.assertEquals(dwellingCoveragePage.getDwellingCoverageQualityGrade(), dwellingCoverageQualityGrade,
                "Dwelling coverage page - dwelling coverage quality grade.");
        List<String> discountsAfterRetrieve = dwellingCoveragePage.getDiscounts();
        Collections.sort(discountsAfterRetrieve);
        fsa.assertEquals(discountsAfterRetrieve, discountsBeforeRetrieve, "Dwelling coverage page - discounts.");
        fsa.assertEquals(dwellingCoveragePage.getAceQuoteNumberInThePage(), applicant.getQuoteNumber(),
                "Dwelling coverage page - dwelling coverage page quote number.");
        dwellingCoverageBasePage.clickContinueButton();

        // Validate [Review quote] page
        reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        reviewQuotePage.verifyQuotePresentmentCard(stateCode, fsa);
        reviewQuotePage.validateAgentSection(fsa, REVIEW_QUOTE, applicant.getAgentId(), HOME);
        reviewQuotePage.validateQuoteText(REVIEW_QUOTE, applicant.getQuoteNumber(), fsa, true);
        reviewQuotePage.validateDiscounts(REVIEW_QUOTE, applicant, HOME, fsa);
        fsa.assertAll("Ace Home - Retrieve rated quote.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_RETRIEVE_FLOW})
    public void testRetrieveQuoteFromAdditionalCoveragePage(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().navigateToAceHomeReviewQuotePage(applicant,LOB_HOME,HOME);
        if(reviewQuotePage.isAllPackagesDisplayedOnReviewQuotePage()){
            reviewQuotePage.clickOnPremierPackage();
        }
        reviewQuotePage.clickOnContinueButton();
        AceHRCAdditionalCoveragesBasePage additionalCoveragesPage = new AceHRCAdditionalCoveragesBasePage();
        Assert.assertTrue(additionalCoveragesPage.isOnAdditionalCoveragesPage(), DID_NOT_REACH + ADDITIONAL_COVERAGES);
        List<String> selectedToggles = additionalCoveragesPage.randomToggleSelection(applicant, fsa, HOME);
        additionalCoveragesPage.clickOnContinueButton();
        additionalCoveragesPage.waitForSpinnerToBeGone();
        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);
        reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        reviewQuotePage.clickOnContinueButton();
        additionalCoveragesPage = new AceHRCAdditionalCoveragesBasePage();
        Assert.assertTrue(additionalCoveragesPage.isOnAdditionalCoveragesPage(), DID_NOT_REACH + ADDITIONAL_COVERAGES);
        List<String> actualSelectedToggles = additionalCoveragesPage.getSelectedToggles();
        fsa.assertEquals(additionalCoveragesPage.getSortedList(actualSelectedToggles), additionalCoveragesPage.getSortedList(selectedToggles) ,"Toggle selections are not retained after quote retrieval");
        additionalCoveragesPage.validateSpecialWaterLossAndFoundationsWallValue(applicant, fsa);
        fsa.assertAll("Ace Home - Retrieve rated quote left from additional coverage page");

    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_RETRIEVE_FLOW})
    public void testRetrieveRatedQuoteFromJFMTPage(ApplicantAceHome applicant) throws Exception {
        AceHomeReviewQuotePage hrcReviewQuoteBasePage = new AceHomeNavigationHelper().navigateToAceHomeReviewQuotePage(applicant,LOB_HOME,HOME);
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        String quotePrice = hrcReviewQuoteBasePage.getQuotePriceOnCard();
        List<String> discountsBeforeRetrieve = hrcReviewQuoteBasePage.getDiscounts().stream().sorted().collect(Collectors.toList());
        hrcReviewQuoteBasePage.clickOnContinueButton();
        AceHRCAdditionalCoveragesBasePage coveragesBasePage = new AceHRCAdditionalCoveragesBasePage();
        fsa.assertTrue(coveragesBasePage.isOnAdditionalCoveragesPage()  ,"Did not reach additional coverage page");
        coveragesBasePage.clickOnContinueButton();
        AceHRCJustAFewMoreThingsBasePage justAFewMoreThingsBasePage = new AceHRCJustAFewMoreThingsBasePage();
        fsa.assertTrue(justAFewMoreThingsBasePage.isOnJFMTPage(true),"Did not reach JFMT page");
        justAFewMoreThingsBasePage.fillOutJustFewMoreThingsPage(applicant,false);

        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeReviewQuotePage();
        fsa.assertTrue(reviewQuotePage.isSnackBarMessageDisplayed("Welcome back " + applicant.getFirstName()), "Welcome back snack bar message is displayed.");
        reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        fsa.assertEquals(reviewQuotePage.getQuotePriceOnCard(), quotePrice, "Review quote page - quote premium after retrieval match.");
        reviewQuotePage.verifyQuotePresentmentCard(applicant.getStateCode(), fsa);
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        fsa.assertEquals(reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList()), discountsBeforeRetrieve,
                "Review quote page - quote discounts after retrieval match.");
        fsa.assertAll("Ace Home - Retrieve rated quote left from JFMT page");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
      attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_RETRIEVE_FLOW})
    public void testRetrieveRatedQuoteFromPaymentPage(ApplicantAceHome applicant) throws Exception {
        AceHomeReviewQuotePage hrcReviewQuoteBasePage = new AceHomeNavigationHelper().navigateToAceHomeReviewQuotePage(applicant,LOB_HOME,HOME);
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        String quotePrice = hrcReviewQuoteBasePage.getQuotePriceOnCard();
        List<String> discountsBeforeRetrieve = hrcReviewQuoteBasePage.getDiscounts().stream().sorted().collect(Collectors.toList());
        hrcReviewQuoteBasePage.clickOnContinueButton();
        AceHRCAdditionalCoveragesBasePage coveragesBasePage = new AceHRCAdditionalCoveragesBasePage();
        fsa.assertTrue(coveragesBasePage.isOnAdditionalCoveragesPage()  ,"Did not reach additional coverage page");
        coveragesBasePage.clickOnContinueButton();
        AceHRCJustAFewMoreThingsBasePage justAFewMoreThingsBasePage = new AceHRCJustAFewMoreThingsBasePage();
        fsa.assertTrue(justAFewMoreThingsBasePage.isOnJFMTPage(true),"Did not reach JFMT page");
        justAFewMoreThingsBasePage.fillOutJustFewMoreThingsPage(applicant,true);
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        Assert.assertTrue(aceHRCPaymentBasePage.isOnContinueToPaymentPage(),"Did not reach to Payment page");
        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeReviewQuotePage();
        // F76803 - Validate RC2 screen is not displayed in retrieval flow.
        fsa.assertFalse(new AceHRCDwellingCoverageBasePage().isOnRC2LoadingPage(2), "RC2 loading page is displayed after retrieving rated quote - " + HOME);
        fsa.assertTrue(reviewQuotePage.isSnackBarMessageDisplayed("Welcome back " + applicant.getFirstName()), "Welcome back snack bar message is displayed.");
        reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        fsa.assertEquals(reviewQuotePage.getQuotePriceOnCard(), quotePrice, "Review quote page - quote premium after retrieval match.");
        reviewQuotePage.verifyQuotePresentmentCard(applicant.getStateCode(), fsa);
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        fsa.assertEquals(reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList()), discountsBeforeRetrieve,
                "Review quote page - quote discounts after retrieval is not matching.");
        reviewQuotePage.clickOnContinueButton();
        Assert.assertTrue(coveragesBasePage.isOnAdditionalCoveragesPage(), "Did not reach Additional coverage page.");
        coveragesBasePage.clickOnContinueButton();
        Assert.assertTrue(justAFewMoreThingsBasePage.isOnJFMTPage(true), "Did not reach JFMT page.");
        justAFewMoreThingsBasePage.validateJFMTPageSelections(applicant.getDogsOnPremises(),applicant,fsa);
        justAFewMoreThingsBasePage.clickContinueButton();
        // F76803 - Validate RC3 screen in retrieval flow.
        justAFewMoreThingsBasePage.validateRC3LoadingScreen(fsa);
        fsa.assertTrue(aceHRCPaymentBasePage.isOnContinueToPaymentPage(),"Verify rate failure, Retrieved quote did not reach to Payment page");
        fsa.assertAll("Ace Home - Retrieve rated quote left from payment page");

    }

    // F82552: AL and TX - WindHail exclusion
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_POLICY_EXCLUSION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, TX})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})
    public void testWindHailExclusionCoverage(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        String stateCode = applicant.getStateCode();
        AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceHomeNavigationHelper().navigateToAceHomeDwellingCoveragePage(applicant, LOB_HOME, HOME);
        Assert.assertTrue(dwellingCoveragePage.isOnDwellingCoveragePage(), DID_NOT_REACH + "DwellingCoveragePage");
        dwellingCoveragePage.clickContinueButton();
        dwellingCoveragePage.waitForSpinnerToBeGone();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeReviewQuotePage();
        Assert.assertTrue(reviewQuotePage.isPolicyExclusionPopUpDisplayed(), "Policy exclusion pop up not displayed");

        // Validate Wind/Hail exclusion pop up and coverages on review quote page after quote retrieval
        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);
        Assert.assertTrue(reviewQuotePage.isPolicyExclusionPopUpDisplayed(), "Policy exclusion pop up not displayed after quote retrieval");
        reviewQuotePage.validateWindHailExclusionPopUpAndCoverages(fsa, stateCode);
        fsa.assertAll("Validate Wind/Hail exclusions popup and coverage on review quote page");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = ONE_APPLICANT_PER_STATE,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_RETRIEVE_FLOW}, enabled = false)
    public void testSweepStakesCampaignReviewAndRetrieveQuoteHome(ApplicantAceHome applicant) throws Exception {
        // F104174: AL,AZ,AR,CA,CO,IL,IN,IA,KS,KY,MD,MI,MO,NM,OH,OK,TX,TN,VA,WI
        String SOURCE_INDICATOR = "ML";
        String SOURCE_ID = "MLB0001";

        AceHomeNavigationHelper navigatorHome = new AceHomeNavigationHelper();
        navigatorHome.processSweepStakesCampaign(applicant, HOME, SOURCE_INDICATOR, SOURCE_ID);
        AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
        if (propertyTypePage.quickIsOnPropertyTypePageCheck()) {
            String quoteNumber = propertyTypePage.getSessionStorageAppStore().getData().getQuoteNumber();
            applicant.setQuoteNumber(quoteNumber);
            Log.info(NEW_QUOTE_NUMBER + quoteNumber, true);
            propertyTypePage.selectPropertyType(HOME);
        } else {
            throw new IllegalStateException(DID_NOT_REACH + PROPERTY_TYPE + SPACE + HOME);
        }
        navigatorHome.setResumeFromPage(AceHRCBasePage.ADDRESS_PAGE);
        AceHomeReviewQuotePage reviewQuotePage = navigatorHome.navigateToAceHomeReviewQuotePage(applicant, LOB_HOME, HOME);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(reviewQuotePage.isSweepStakesPopupDisplayed(), "Sweepstakes pop-up is displayed on Review quote page.");
        reviewQuotePage.validateSweepStakesPopup(fsa);
        AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceHRCDwellingCoverageBasePage();
        dwellingCoveragePage.changeDwellingCoverage();
        dwellingCoveragePage.clickContinueButton();
        reviewQuotePage = new AceHomeReviewQuotePage();
        fsa.assertTrue(reviewQuotePage.isOnReviewQuotePageHome(true), "After clicking continue from Dwelling coverage page, user should navigate back to Review quote page.");
        fsa.assertFalse(reviewQuotePage.isSweepStakesPopupDisplayed(), "Sweepstakes pop-up should not be displayed on Review quote page after recalculate.");

        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);
        reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        fsa.assertFalse(reviewQuotePage.isSweepStakesPopupDisplayed(), "Sweepstakes pop-up should not be displayed on Review quote page after quote retrieval.");

        fsa.assertAll("Ace Home - Sweepstakes campaign popup validation.");
    }

}
