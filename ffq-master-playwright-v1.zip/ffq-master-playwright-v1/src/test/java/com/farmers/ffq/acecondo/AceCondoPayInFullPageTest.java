package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCJustAFewMoreThingsBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentSelectionPage;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.PAYMENT_PAGE;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoPayInFullPageTest extends AutomationFramework {


    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})
    public void testValidateContentOfPayInFullPageAndNavigateToJFMTPageAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        applicantAceHome.setSquareFeet("400");
        AceHRCPaymentBasePage aceHRCPayInFullPaymentBasePage = new AceCondoNavigationHelper().navigateToPayInFullPaymentPageAceCondo(applicantAceHome);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceHRCPayInFullPaymentBasePage.validateContentOfPayInFullPageOnLanding(fsa, applicantAceHome, CONDO, ONE_PAY);
        //Quote number and Agent details at the bottom validation
        AceHRCBasePage aceHRCBasePage = new AceHRCBasePage();
        aceHRCBasePage.validateQuoteText(PAYMENT_PAGE, applicantAceHome.getQuoteNumber(), fsa, true);
        aceHRCBasePage.validateAgentSection(fsa, PAYMENT_PAGE, applicantAceHome.getAgentId(), CONDO);
        // Navigating back to JFMT page and default selection validation
        aceHRCBasePage.navigateBack(2);
        AceHRCJustAFewMoreThingsBasePage justAFewMoreThingsBasePage = new AceHRCJustAFewMoreThingsBasePage();
        fsa.assertTrue(justAFewMoreThingsBasePage.isOnJFMTPage(true), "Navigation from Payment page to JFMT page is not working - " + CONDO);
        justAFewMoreThingsBasePage.validateJFMTPageSelectionsCondo(applicantAceHome.getDogsOnPremises(),applicantAceHome,fsa, false);
        fsa.assertAll();
    }


    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})
    public void testValidateContentOfPayInFullPageAndECheckoutWithLenderSelectedAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicantAceHome.setSquareFeet("400");
        applicantAceHome.setImpoundAccountSelection(NEW_POLICY_AND_RENEWAL);
        AceHRCJustAFewMoreThingsBasePage aceHRCJustAFewMoreThingsBasePage = new AceCondoNavigationHelper().navigateToAceCondoJustAFewMoreThingsPage(applicantAceHome);
        aceHRCJustAFewMoreThingsBasePage.fillOutFMTPWithLenderCompanySelected(applicantAceHome, CONDO);
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        aceHRCPaymentBasePage.validateContentOfPayInFullPageWithMortgageeInfoOnLanding(fsa, applicantAceHome, CONDO);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, CONDO);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})
    public void testValidateContentOfPayInFullPageAndECheckoutWithRenewalSelectedAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicantAceHome.setSquareFeet("400");
        applicantAceHome.setImpoundAccountSelection(RENEWAL);
        AceHRCJustAFewMoreThingsBasePage aceHRCJustAFewMoreThingsBasePage = new AceCondoNavigationHelper().navigateToAceCondoJustAFewMoreThingsPage(applicantAceHome);
        aceHRCJustAFewMoreThingsBasePage.fillOutFMTPWithLenderCompanySelected(applicantAceHome, CONDO);
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        aceHRCPaymentBasePage.validateContentOfPayInFullPageWithNewPolicyOnLanding(fsa, applicantAceHome, CONDO, applicantAceHome.getStateCode());
        PolicyPaymentBasePage PolicyPaymentBasePage = new PolicyPaymentBasePage();
        PolicyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, CONDO);
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPagePayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateThreeBulletPointsAtTheBottomOfThePaymentPageWithPaperless(fsa, CONDO);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, CONDO);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})
    public void validatePaymentByChangingPayInFullBankToMonthlyPayCardAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicantAceHome.setSquareFeet("400");
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceCondoNavigationHelper().navigateToPayInFullPaymentPageAceCondo(applicantAceHome);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, CONDO);
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPagePayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPagePayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.validateOneTimePaymentRecurringRadioButtonText(fsa, CONDO);

        // Navigating back and selecting different pay plan and proceeding with payment
        AceHRCBasePage aceHRCBasePage = new AceHRCBasePage();
        aceHRCBasePage.navigateBack();
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
        aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayCard();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, CONDO);
        aceHRCPaymentBasePage.validateFutureCreditDebitCardServiceCharges(fsa, true, CONDO);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, CONDO);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, CONDO);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, CONDO);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, CONDO);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})
    public void testPayInFullCreditCardEndToEndAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        // updating sq feet to avoid reconstruction KO
        applicantAceHome.setSquareFeet("400");
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceCondoNavigationHelper().navigateToPayInFullPaymentPageAceCondo(applicantAceHome);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.clickSetUpPaymentButton();
        policyPaymentBasePage.clickDebitCreditCardButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(VISA_CREDIT_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPagePayInFull(fsa, VISA_CREDIT_CARD, CARD_NAME_VISA, true, CONDO);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPagePayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.validateOneTimePaymentRecurringRadioButtonText(fsa, CONDO);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, CONDO);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphPayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, CONDO);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})
    public void testPayInFullChangeBankPaymentToCardPaymentEndToEndAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicantAceHome.setSquareFeet("400");
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceCondoNavigationHelper().navigateToPayInFullPaymentPageAceCondo(applicantAceHome);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, CONDO);
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPagePayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        policyDebitCreditPayment.clickChangeLink();
        policyPaymentBasePage.clickDebitCreditCardButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPagePayInFull(fsa, MASTER_CARD, CARD_NAME_MASTER, true, CONDO);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, CONDO);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})
    public void testPayInFullChangeCreditCardPaymentToBankPaymentEndToEndAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicantAceHome.setSquareFeet("400");
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceCondoNavigationHelper().navigateToPayInFullPaymentPageAceCondo(applicantAceHome);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        policyPaymentBasePage.clickSetUpPaymentButton();
        policyPaymentBasePage.clickDebitCreditCardButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.switchToParentWindow();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPagePayInFull(fsa, MASTER_CARD, CARD_NAME_MASTER, true, CONDO);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        policyDebitCreditPayment.clickChangeLink();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, CONDO);
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPagePayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, CONDO);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, CONDO);
        fsa.assertAll();
    }
}
