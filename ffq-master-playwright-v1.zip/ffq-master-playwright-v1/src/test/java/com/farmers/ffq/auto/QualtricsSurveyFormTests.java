package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.RandomUtils;
import org.testng.annotations.Test;

import java.util.Optional;

import static com.farmers.ffq.utils.GlobalVariables.FFQ_ONEUI;

public class QualtricsSurveyFormTests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = FFQ_ONEUI, enabled = false)
    public void testQualtricsTriggerQuoteSummary_40_SecondsInactivity(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.setRemoveQualtricsPopup(false);
        QuoteSummaryAutoPage quoteSummaryAutoPage =  aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote Summary page has been reached");
        sleep(60);
        testStepAssert(quoteSummaryAutoPage.isQualtricsSurveyPopUpDisplayed(), "Qualtrics survey pop up came up after 40 seconds inactivity");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = FFQ_ONEUI, enabled = false)
    public void testQualtricsTriggerQuoteSummaryContinueButton_20_SecondsInactivity(AutoApplicant applicant) throws Exception {
        applicant.setResidentAddress("123 NonStandardized address");
        applicant.setCity("Nonstandardized city");
        updateApplicantDataToAvoidPossibleBw(applicant);
        //avoiding garage address failure due to zipCode change ^^
        applicant.getVehicles().forEach(vehicle -> vehicle.setParkInResidentAddress(true));
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.setRemoveQualtricsPopup(false);
        QuoteSummaryAutoPage quoteSummaryAutoPage =  aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        sleep(21);
        testStepAssert(quoteSummaryAutoPage.isQualtricsSurveyPopUpDisplayed(), "Qualtrics QuoteSummaryContinueButton_20_SecondsInactivity pop up is not displayed");
    }

    // TODO: need to find out how to track 50% selection for pop up
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = FFQ_ONEUI, enabled = false)
    public void testQualtricsTriggerAdditionalInfoPage_20_Delay(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.setRemoveQualtricsPopup(false);
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = aceAutoNavigationHelper.navigateToAdditionalInfoPage(applicant);
//        softAssertTrue(additionalInfoPolicyStartDateOneUI.isQualtricsSurveyPopUpDisplayed(), "Qualtrics pop up is not displayed");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = FFQ_ONEUI, enabled = false)
    public void testQualtricsTriggerKnockoutPage_10_secondsDelay(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        driverReviewPage.setMaritalRelationToSomeOneNotListed(applicant, true, false);
        driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
        driverReviewPage.clickContinueButton();
        SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
        signalPageOneUI.processSignalPage(RandomUtils.nextBoolean());
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.setValuesAndContinue(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        if (knockoutInconveniencePage.isOnKnockOutPage()) {
            sleep(11);
            testStepAssert(knockoutInconveniencePage.isQualtricsSurveyPopUpDisplayed(), "Qualtrics KnockoutPage_10_seconds pop up is not displayed");
        }else {
            Log.error("Did not reach Knockout page... ");
        }

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = FFQ_ONEUI, enabled = false)
    public void testQualtricsTriggerFormSubmission(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.setRemoveQualtricsPopup(false);
        QuoteSummaryAutoPage quoteSummaryAutoPage =  aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        sleep(40);
        testStepAssert(quoteSummaryAutoPage.isQualtricsSurveyPopUpDisplayed(), "Qualtrics form was not submitted");
    }

}
