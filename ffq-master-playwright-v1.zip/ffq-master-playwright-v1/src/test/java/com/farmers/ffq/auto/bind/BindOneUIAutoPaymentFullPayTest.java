package com.farmers.ffq.auto.bind;

import com.farmers.ffq.BaseTest;

import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.annotation.Skip;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class BindOneUIAutoPaymentFullPayTest extends BaseTest {

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)
    public void autoPaymentPayInFullPageContentValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        String landingStateCode = applicant.getStateCode();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        AppStore sessionStorageAppStore = additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore();

        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentPayInFull();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        fsa.assertTrue(autoPolicyPaymentBasePage.isAutoPolicyPaymentHeaderCorrect(), errorMessage("Auto Policy Payment Header"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isPayInFullHeaderCorrect(), errorMessage("Pay In Full Header"));

        fsa.assertTrue(autoPolicyPaymentBasePage.isSixMonthTermPaymentCorrect(), errorMessage("Six Month Term Payment"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isSixMonthTermPriceAmountDisplayed(ONE_PAY), errorMessage("Six Month Term Price Amount"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isSixMonthTermPaymentAmountDisplayed(ONE_PAY, "span", sessionStorageAppStore), errorMessage("Six Month Term Payment Amount"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isPolicyFeeAmountDisplayedAuto("span"), errorMessage("Policy/Membership Fee Amount"));
        autoPolicyPaymentBasePage.isDueTodayAmountDisplayedAuto(ONE_PAY, fsa);
        fsa.assertTrue(autoPolicyPaymentBasePage.isDueTodayCorrect(), errorMessage("Due Today"));

        if (!landingStateCode.equals(KS)) {
            fsa.assertTrue(autoPolicyPaymentBasePage.isPolicyFeesCorrect(), errorMessage("Policy Fee Header"));
            fsa.assertTrue(autoPolicyPaymentBasePage.isPolicyFeeSideBarHeaderCorrect(), errorMessage("Policy Fee Side Bar"));

            if (autoPolicyPaymentBasePage.isRequiredMembershipFees(landingStateCode)) {
                fsa.assertTrue(autoPolicyPaymentBasePage.isMembershipFeesSideBarMsgCorrect(), errorMessage("Membership Fee Message for " + landingStateCode));
            } else if (autoPolicyPaymentBasePage.isRequiredVehicleFees(landingStateCode)) {
                if (!sessionStorageAppStore.getVerifyResponse().getPolicyFee().getAmount().equals("0.00")) {
                    fsa.assertTrue(autoPolicyPaymentBasePage.isVehicleFeesSideBarMsgCorrect(), errorMessage("Vehicle Fee Message for " + landingStateCode));
                }
            } else {
                fsa.assertTrue(autoPolicyPaymentBasePage.isPolicyFeesSideBarMsgCorrect(), errorMessage("Policy Fee Message for " + landingStateCode));
            }
        }

        fsa.assertTrue(autoPolicyPaymentBasePage.isSelectPreferredPaymentCorrect(), errorMessage("Add Preferred Payment Header"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isBankDebitCreditPaymentCorrect(), errorMessage("Bank Debit Credit Payment Line"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isNoServiceChargeCorrect(), errorMessage("No Service Charge Line"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isSetUpPaymentMethodCorrect(), errorMessage("Set Up Payment Method"));

        autoPolicyPaymentBasePage.logInfoMessage(sessionStorageAppStore.getData().getQuoteNumber());
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_PAYINFULL_PAGE}, enabled = false)
    public void autoPaymentPayInFullPageBackAndForthValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentPayInFull();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();

        fsa.assertTrue(autoPolicyPaymentBasePage.goBackToHowWouldYouLikeToPayPage(), errorMessage("How Would You Like To Pay"));
        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentPayInFull();
        autoPolicyPaymentBasePage.logInfoMessage(additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore().getData().getQuoteNumber());
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_PAYINFULL_PAGE}, enabled = false)
    public void autoPaymentPayInFullPageSetUpPaymentMethodValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentPayInFull();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        fsa.assertTrue(autoPolicyPaymentBasePage.clickSetUpPaymentButton(), "Set Up Payment Method Button Clicked Successfully");
        fsa.assertTrue(autoPolicyPaymentBasePage.closeAddPaymentMethodContainer(false), "Add Payment Method Container Closed Successfully");
        autoPolicyPaymentBasePage.logInfoMessage(additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore().getData().getQuoteNumber());
        autoPolicyPaymentBasePage.addSauceLabsLinkInLog();
        fsa.assertAll();
    }

    private String errorMessage(String item) {
        return item + " displays expected text";
    }
}
