package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.home.AceHomeReviewQuotePage;
import com.farmers.ffq.ace.hrc.common.AceHRCAdditionalCoveragesBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCReviewQuoteBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.ADDITIONAL_COVERAGES;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeAdditionalCoveragesPageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ADDITIONAL_COVERAGES_PAGE})
    public void testAdditionalCoveragesPageQuotePresentmentCardHome(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
        AceHRCReviewQuoteBasePage reviewQuoteBasePage = navigator.navigateToAceHomeReviewQuotePage(applicant, LOB_HOME, HOME);
        if (reviewQuoteBasePage.getNumberOfPackageTabs() > 1 && !reviewQuoteBasePage.getSelectedPackage().equals(ENHANCED)) {
            reviewQuoteBasePage.selectRatePackage(ENHANCED);
        }
        navigator.setResumeFromPage(REVIEW_QUOTE);
        AceHRCAdditionalCoveragesBasePage additionalCoveragesPage = navigator.navigateToAceHomeAdditionalCoveragesPage(applicant, LOB_HOME, HOME);
        additionalCoveragesPage.validatePageTitleSubtitle(fsa);
        additionalCoveragesPage.verifyQuotePresentmentCard(fsa);
        additionalCoveragesPage.validateEmailThisQuoteLink(applicant, fsa);
        additionalCoveragesPage.validateDiscounts(ADDITIONAL_COVERAGES, applicant, HOME, fsa);
        driver().navigate().refresh();
        additionalCoveragesPage.validatePageTitleSubtitle(fsa);
        additionalCoveragesPage.verifyQuotePresentmentCard(fsa);
        additionalCoveragesPage.verifyTogglesOff(applicant, fsa);
        additionalCoveragesPage.validateContinueButtonAtPageBottom(fsa);
        additionalCoveragesPage.validateRecalculateButtonAtPageBottom(fsa);
        additionalCoveragesPage.validateDiscounts(ADDITIONAL_COVERAGES, applicant, HOME, fsa);

        fsa.assertAll("Validate Ace Home Additional Coverages page - Quote Presentment Card.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_COVERAGES_PAGE})
    public void testAdditionalCoveragesPageTogglesValidationHome(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
        AceHRCReviewQuoteBasePage reviewQuoteBasePage = navigator.navigateToAceHomeReviewQuotePage(applicant, LOB_HOME, HOME);
        if (reviewQuoteBasePage.getNumberOfPackageTabs() > 1 && !reviewQuoteBasePage.getSelectedPackage().equals(ENHANCED)) {
            reviewQuoteBasePage.selectRatePackage(ENHANCED);
        }
        navigator.setResumeFromPage(REVIEW_QUOTE);
        AceHRCAdditionalCoveragesBasePage additionalCoveragesPage = navigator.navigateToAceHomeAdditionalCoveragesPage(applicant, LOB_HOME, HOME);
        additionalCoveragesPage.validateAdditionalCoveragesTogglesText(applicant, fsa, false);
        additionalCoveragesPage.validateAdditionalCoveragesTogglesPremium(applicant, fsa, false);
        additionalCoveragesPage.selectStepper(REVIEW_QUOTE); // Navigate to review quote page
        reviewQuoteBasePage.waitForSkeletonToBeGone();
        additionalCoveragesPage.validateSwitchingToAndFromReviewQuotePage(applicant, fsa);
        fsa.assertAll("Validate Ace Home Additional Coverages page - Toggles functionality validation.");
    }


    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA, MO, PA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDITIONAL_COVERAGES_PAGE})
    public void testSecondarySeasonalHomeAceHome(ApplicantAceHome applicant) throws Exception {
        AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
        applicant.setPrimaryResidence(false);
        applicant.setReasonWhyNotPrimaryResidence(SECONDARY);

        AceHRCAdditionalCoveragesBasePage additionalCoveragesPage = navigator.navigateToAceHomeAdditionalCoveragesPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalCoveragesPage.validateAdditionalCoveragesTogglesText(applicant, fsa, true);
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeReviewQuotePage();
        if(reviewQuotePage.isAllPackagesDisplayedOnReviewQuotePage()) {
            additionalCoveragesPage.selectStepper(REVIEW_QUOTE);
            reviewQuotePage.waitForSkeletonToBeGone();
            reviewQuotePage.clickOnPremierPackage();
            reviewQuotePage.clickOnContinueButton();
            additionalCoveragesPage.validateAdditionalCoveragesTogglesText(applicant, fsa, true);
            additionalCoveragesPage.selectStepper(REVIEW_QUOTE);
            reviewQuotePage.waitForSkeletonToBeGone();
            reviewQuotePage.clickOnStandardPackage();
            reviewQuotePage.clickOnContinueButton();
            additionalCoveragesPage.validateAdditionalCoveragesTogglesText(applicant, fsa, true);
        }
        fsa.assertAll("Validate Ace Home - Seasonal or secondary home rated.");
    }

}
