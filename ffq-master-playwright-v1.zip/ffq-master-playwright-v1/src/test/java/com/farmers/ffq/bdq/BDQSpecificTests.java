package com.farmers.ffq.bdq;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.auto.pages.bindpages.AutoPolicyPaymentBasePage;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.auto.pages.bw.BwPaymentSummaryPage;
import com.farmers.ffq.auto.pages.legacy.AdditionalInformationPage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.common.pages.PaymentSelectionBasePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class BDQSpecificTests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQSpecificRequirements_OrganicFlow(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        validateBDQRules(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQSpecificRequirements_Buy_Lite_Flow(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        applicant.setTestScenario(BW_CLICK_TO_BUY_LITE_FLOW + "-> " + applicant.getTestScenario());
        validateBDQRules(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {FL, AZ, CO, IA, IL, NJ, OR, PA, TN, TX, UT, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQSpecificRequirements_Buy_Full_Flow(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        applicant.setTestScenario(BW_CLICK_TO_BUY_FULL_FLOW + "-> " + applicant.getTestScenario());
        validateBDQRules(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQSpecificRequirements_Marketing_ID_Flow(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        applicant.setTestScenario(BW_MARKETING_ID_FLOW + "-> " + applicant.getTestScenario());
        validateBDQRules(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQRetrievalForNotRatedQuote(AutoApplicant applicant) throws Exception {
        applicant.getVehicles().forEach(each -> each.setUseVIN(true));
        updateLastNameForBristolWest(applicant);
        applicant.setTestScenario(getRandomBdqFlow(applicant.getStateCode()) + "-> " + applicant.getTestScenario());
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        driverReviewPage.reviewAllDrivers(applicant, Optional.empty());

        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        AppStore.Data.CustomerData customerData = whoShouldWeInsurePage.getSessionStorageAppStore().getData().getCustomerData();
        applicant.setFirstName(customerData.getFirstName());
        applicant.setLastName(customerData.getLastName());
        String customerDataDoB = customerData.getDateOfBirth().replaceAll("\\D", EMPTY_STRING);
        String formattedDoB = customerDataDoB.substring(4) + customerDataDoB.substring(0, 4);
        applicant.setDateOfBirth(formattedDoB);
        applicant.setZipCode(whoShouldWeInsurePage.getSessionStorageAppStore().getData().getLandingZipCode());
        new LandingPage(Property.getUri() + "?retrieve=true&Source_Indicator=BW", whoShouldWeInsurePage.isUseMobileViewEnabled())
        	.retrieveQuoteFromLandingPage(applicant, whoShouldWeInsurePage.getSessionStorageAppStore().getData().getQuoteNumber());
        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User should land on the " + whoShouldWeInsurePage.getClass().getSimpleName() + " after retrieval");
        testStepAssert(whoShouldWeInsurePage.getTitle(), "Welcome back " + applicant.getFirstName() + "!", "Page title after retrieval");
        testStepAssert(whoShouldWeInsurePage.isOnBristolWest(), "User should land on the BW after retrieval");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQRetrievalForRatedQuote(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        applicant.getVehicles().forEach(each -> each.setUseVIN(true));
        applicant.setTestScenario(getRandomBdqFlow(applicant.getStateCode()) + "-> " + applicant.getTestScenario());

        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        AppStore.Data sessionData = quoteSummaryAutoPage.getSessionStorageAppStore().getData();
        AppStore.Data.CustomerData customerData = sessionData.getCustomerData();
        applicant.setFirstName(customerData.getFirstName());
        applicant.setLastName(customerData.getLastName());
        String customerDataDoB = customerData.getDateOfBirth().replaceAll("\\D", EMPTY_STRING);
        String formattedDoB = customerDataDoB.substring(4) + customerDataDoB.substring(0, 4);
        applicant.setDateOfBirth(formattedDoB);
        String quoteNumber = sessionData.getQuoteNumber();

        applicant.setZipCode(sessionData.getLandingZipCode());
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
        new LandingPage(Property.getUri() + "?retrieve=true&Source_Indicator=BW", quoteSummaryAutoPage.isUseMobileViewEnabled())
        	.retrieveQuoteFromLandingPage(applicant, quoteNumber);

        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page after retrieval");
        testStepAssert(quoteSummaryAutoPage.isSnackBarMessageDisplayed(String.format("Welcome back %s", applicant.getFirstName())), "Welcome back snackbar message is displayed", true);
    }

    /*
     * Validate "Has had more than two personal injury loss in last 3 years" upon chosing this checkbox user should land on KO page after contact info screen.
     */
    @Skip // Skipping this as this scenario no longer lands on the KO page
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void validateMoreThanTwoInjuryGetsKO(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        List<SqlIncident> incidents = applicant.getIncidents();
        incidents.forEach(incident -> {
            List<String> randomMonth = new ArrayList<>(Arrays.asList("01", "02", "03", "04", "05", "06", "06", "07", "08", "09"));
            Collections.shuffle(randomMonth);
            incident.setDateOccured(randomMonth.get(0) + LocalDate.now().minusYears(1).getYear());
        });
        applicant.getVehicles().forEach(each -> each.setUseVIN(true));
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);

        BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
        if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            bristolWestAdditionalDiscountsPage.clickContinue();
        }

        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();

        testStepAssert(knockoutInconveniencePage.isOnKnockOutPage(), "User should be on the KO page with two or more injuries with BDQ application");

    }

    /**
     * Click on back browser from Payplan screen and validate DCM screen is NOT displaying
     */
    //TODO: DE260312: [RA11] DCM Screen SHows up After Navigating Back From Payment Summary Page
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void validateDCMScreenIsNotShownWhenAlreadySubmitted(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        applicant.getVehicles().forEach(each -> each.setUseVIN(true));
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        sleep(3);
        driver().navigate().back();
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User landed additional info page as expected");
    }

    /**
     * Validate BDQ landing page. Enter zip code & click on start quote. Validate application is navigating to Enter info screen of BDQ Ace application
     */
    @Skip //TODO: need to figure out to access bw landing page on saucelabs
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void validateBDQLandingPageNavigatesToPersonalInfoPage(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        //Property.getRemote()
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        sleep(3);
        driver().navigate().back();
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User landed additional info page as expected");
    }

    /**
     * Validate Retrieve flow by dropping off in JAFMT/Additional drivers/Payplan/Payment
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void validateRetrievalFromBindPages(AutoApplicant applicant) throws Exception {
        switchTestToBDQIfNeeded(applicant);
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        DriverMismatchPage driverMismatchPage = new DriverMismatchPage();
        List<AutoBasePage> possiblePages = new ArrayList<>(Arrays.asList(additionalInfoPolicyStartDateOneUI, bwPaymentSummaryPage, driverMismatchPage));
        Collections.shuffle(possiblePages);
        AutoBasePage selectedPage = possiblePages.get(0);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();

        switch (selectedPage.getClass().getSimpleName()) {
            case "AdditionalInfoPolicyStartDateOneUI":
                aceAutoNavigationHelper.navigateToAdditionalInfoPage(applicant);
                testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User is " + additionalInfoPolicyStartDateOneUI.getClass().getSimpleName());
                break;
            case "BwPaymentSummaryPage":
                aceAutoNavigationHelper.navigateToPaymentSelectionPage(applicant);
                testStepAssert(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User is on " + bwPaymentSummaryPage.getClass().getSimpleName());
                break;
            default:
                aceAutoNavigationHelper.navigateToAdditionalInfoPage(applicant);
                testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User is " + additionalInfoPolicyStartDateOneUI.getClass().getSimpleName());
                additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
        }

        Log.info("User will be dropping off from the page: " + selectedPage.getClass().getSimpleName() + ". And will be retrieving from the landing page");
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        AppStore.Data sessionData = quoteSummaryAutoPage.getSessionStorageAppStore().getData();
        AppStore.Data.CustomerData customerData = sessionData.getCustomerData();
        applicant.setFirstName(customerData.getFirstName());
        applicant.setLastName(customerData.getLastName());
        String customerDataDoB = customerData.getDateOfBirth().replaceAll("\\D", EMPTY_STRING);
        String formattedDoB = customerDataDoB.substring(4) + customerDataDoB.substring(0, 4);
        applicant.setDateOfBirth(formattedDoB);
        String quoteNumber = sessionData.getQuoteNumber();
        applicant.setZipCode(sessionData.getLandingZipCode());
        new LandingPage(Property.getUri() + "?retrieve=true&Source_Indicator=BW", quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, quoteNumber);
        // Requirement change: When a quote is retrieved from the bind pages, the user will now land on the additional info page
        AdditionalInformationPage additionalInformationPage = new AdditionalInformationPage();
        testStepAssert(additionalInformationPage.isOneAdditionalInfoPage(), "User is on the additional info page after retrieval");

    }

    /**
     * BDQ: Validate upon submitting the field values in JAFMT, when we try to navigate back and come forward additional fields will NOT be displayed as the details have been provided earlier
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void validateJAFMTFieldsAreNotDisplayedAfterAlreadySubmitted(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        applicant.getVehicles().forEach(each -> {
            each.setUseVIN(true);
            each.setOwnership("Financed");
        });
        applicant.setTestScenario(getRandomBdqFlow(applicant.getStateCode()) + "-> " + applicant.getTestScenario());
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        PaymentSelectionBasePage paymentSelectionBasePage = new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        testStepAssert(autoPolicyPaymentBasePage.isOnContinueToPaymentPage(), "User is on the bw payment page");
        paymentSelectionBasePage.clickReviewQuoteNavigationBarStepper();

        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();

        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on " + quoteSummaryAutoPage.getClass().getSimpleName());

        quoteSummaryAutoPage.clickOnStartCheckoutButton();
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User landed additional info page as expected");
        additionalInfoPolicyStartDateOneUI.continueToPaymentPage();
        testStepAssert(autoPolicyPaymentBasePage.isOnContinueToPaymentPage(), "User is on the bw payment page");

    }

    /**
     * "Create a quote for FL state.
     * Customer is quoting for 3 vehicles
     * Customer gets a quote with BI and UM coverage
     * Customer removes BI limit and recalculates
     * The system makes an adjustment by removing UM coverage which requires BI
     * Customer sees the pop-up content about BI being required to maintain UM three times. It should be displayed only once."
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=29"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void validateAdjustmentPopUpShowsOnlyOnce(AutoApplicant applicant) throws Exception {
        applicant.getVehicles().forEach(each -> {
                    each.setVehicleUsage("Personal");
                    each.setRidesharing(false);
                }
        );
        switchTestToBDQIfNeeded(applicant);
        applicant.setFinancialFiling(NO);
        applicant.setMaritalStatus(SINGLE);
        applicant.setAdditionalDrivers(Collections.emptyList());
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnBristolWest(), "User is on the quote summary page for bw / bdq");
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        quoteSummaryAutoPage.validateUMAdjustmentPopUp(softAssert);
        softAssert.assertAll();
    }


    /**
     * "Sherlock report- R07 scope- AR state (BDQ & BW)
     * Validation of Sherlock report getting called in BW Verify request for a BDQ Organic & Marketing ID flow quote in AR state with valid effective date on or after 07/25/2025"
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AR})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void validateSherlockReportIsCalled(AutoApplicant applicant) throws Exception {

        List<String> applicableBDQFlows = new ArrayList<>(Arrays.asList(BW_ORGANIC_FLOW, BW_MARKETING_ID_FLOW));
        Collections.shuffle(applicableBDQFlows);
        applicant.setTestScenario(applicableBDQFlows.get(0) + " -> " + applicant.getTestScenario());

        FarmersSoftAssert softAssert = new FarmersSoftAssert();

        PaymentSelectionBasePage paymentSelectionBasePage = new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        BWAutoVerifyServiceStarted bwAutoQuoteVerifyServiceInitiated = new ApiHelper().getBwAutoQuoteVerifyServiceInitiated(paymentSelectionBasePage.getSessionStorageAppStore().getData().getQuoteNumber());
        boolean orderDCH = bwAutoQuoteVerifyServiceInitiated.getAutoQuote().getReports().stream().anyMatch(each -> each.getCode().equals("orderDCH") && each.getValue().equals("Y"));
        softAssert.assertTrue(orderDCH, "Sherlock report is getting called in bw verify rate call");
        softAssert.assertAll();

    }

    /**
     * BDQ: Validate retrieve functionaility of Bind success quote
     */
    @Test(groups = {BDQ_TESTS})
    public void validateRetrievalOfAlreadyBoughtQuote() throws Exception {
        LandingPage landingPage = new LandingPage();
        landingPage.retrieveQuoteFromLandingPage("Threeoabaa", "03/11/1984", "1631929376", "37862");
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        landingPage.validateUnableToRetrieveContent(softAssert, "We can't retrieve your quote because you already purchased your policy.");
        landingPage.validateUnableToRetrieveContent(softAssert, "Thanks for choosing");
        softAssert.assertAll();
    }

    /**
     * BDQ: On quote retrieval the coverage display order must be the same as it was on quote completion
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void validateOrderOfCoveragesSameAfterRetrieval(AutoApplicant applicant) throws Exception {
        switchTestToBDQIfNeeded(applicant);
        updateLastNameForBristolWest(applicant);
        applicant.setTestScenario(BW_ORGANIC_FLOW + SPACE + applicant.getTestScenario());
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the quote summary page for bw / bdq");
        String quoteNumber = quoteSummaryAutoPage.getSessionStorageAppStore().getData().getQuoteNumber();
        Log.info("Quote number for this flow: " + quoteNumber);
        FarmersSoftAssert softAssert = new FarmersSoftAssert();

        List<String> coveragesBeforeRetrieval = quoteSummaryAutoPage.getAllDisplayedCoverages();
        List<String> limitsBeforeRetrieval = quoteSummaryAutoPage.getAllDisplayedLimits();
        List<String> pricesBeforeRetrieval = quoteSummaryAutoPage.getAllDisplayedPrices();
        Log.info("coveragesBeforeRetrieval : " + coveragesBeforeRetrieval);
        Log.info("limitsBeforeRetrieval : " + limitsBeforeRetrieval);
        Log.info("pricesBeforeRetrieval : " + pricesBeforeRetrieval);
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, quoteNumber);
        quoteSummaryAutoPage.waitForSpinnerToBeGone();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the quote summary page for bw / bdq after retrieval");

        List<String> coveragesAfterRetrieval = quoteSummaryAutoPage.getAllDisplayedCoverages();
        List<String> limitsAfterRetrieval = quoteSummaryAutoPage.getAllDisplayedLimits();
        List<String> pricesAfterRetrieval = quoteSummaryAutoPage.getAllDisplayedPrices();
        Log.info("coveragesAfterRetrieval : " + coveragesAfterRetrieval);
        Log.info("limitsAfterRetrieval : " + limitsAfterRetrieval);
        Log.info("pricesAfterRetrieval : " + pricesAfterRetrieval);

        softAssert.assertEquals(coveragesBeforeRetrieval, coveragesAfterRetrieval, "COverages before and after are matching");
        softAssert.assertEquals(limitsBeforeRetrieval, limitsAfterRetrieval, "Limits before and after are matching");
        softAssert.assertEquals(pricesBeforeRetrieval, pricesAfterRetrieval, "Prices before and after are matching");
        softAssert.assertAll();

    }

    //F91547
    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {/*AL, AR, AZ, CO, IL, IN, KS, MI, MN, MO, NE, NM, OH, OK, OR, PA, TN, TX, UT, VA, WA*/TN, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, enabled = true)
    public void testBdqCacheFunctionality(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the quote summary page");
        sleep(1);
        driver().navigate().refresh();
        sleep(1);
        aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the quote summary page second time with same data");

    }

    private void validateBDQRules(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        applicant.getVehicles().forEach(each -> each.setUseVIN(true));
        //name and dob page
        NameAndDobPage nameAndDobPage = aceAutoNavigationHelper.navigateToNameAndDobPage(applicant);
        nameAndDobPage.waitForNameAndDobPageToRender();
        nameAndDobPage.updateTheApplicantFromClickToBuyFlow(applicant);
        nameAndDobPage.validateBDQSpecificRules(fsa, applicant);
        boolean isClickToBuyFullFlow = applicant.getTestScenario().contains(BW_CLICK_TO_BUY_FULL_FLOW);
        if (isClickToBuyFullFlow) {
            nameAndDobPage.clickContinueButton();
        } else {
            nameAndDobPage.filloutApplicantForm(applicant);
        }

        // address page
        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        testStepAssert(autoEnterAddressPage.isOnEnterAddressPage(), "User is on the " + autoEnterAddressPage.getClass().getSimpleName());
        autoEnterAddressPage.validateBDQSpecificRules(fsa, applicant);
        if (isClickToBuyFullFlow) {
            String landingZipCode = autoEnterAddressPage.getSessionStorageAppStore().getData().getLandingZipCode();
            Log.info("Zipcode: " + landingZipCode);
            applicant.setZipCode(landingZipCode);
            autoEnterAddressPage.fillOutEmailAndPhoneIfPresent(applicant.getEmail(), applicant.getPhoneNumber());
            autoEnterAddressPage.clickAddressPageCtaButton();
        } else {
            autoEnterAddressPage.fillOutAddressPage(applicant);
        }

        //Who should we insure page
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the " + whoShouldWeInsurePage.getClass().getSimpleName());
        whoShouldWeInsurePage.validateValidateAndFooterForBDQ(fsa, applicant, whoShouldWeInsurePage);
        fsa.assertFalse(whoShouldWeInsurePage.isDiscountSectionDisplayed(), "Discount section should not be displayed on " + whoShouldWeInsurePage.getClass().getSimpleName());
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        boolean streamlineFlow = vehiclesDriversInfoPage.isOnVehiclesDriversInfoPage();
        if (isClickToBuyFullFlow && !heresWhatWeFoundPage.getDisplayedCompleteVehicles().isEmpty()) {
            heresWhatWeFoundPage.addADPFApplicant(Optional.of(applicant), applicant.getFirstName() + SPACE + applicant.getLastName(), applicant.getGender(), applicant.getDateOfBirth());
        } else if (streamlineFlow) {
            if (vehiclesDriversInfoPage.getDisplayedVehicles().isEmpty()) {
                vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
                vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
            }
        } else {
            List<Vehicle> vehicles = applicant.getVehicles();
            vehicles.forEach(each -> {
                try {
                    String bwAcceptableVin = whoShouldWeInsurePage.getRandomVinNumber(3);
                    List<String> vins = vehicles.stream().map(veh -> veh.getVehicleVIN()).collect(Collectors.toList());
                    while (vins.contains(bwAcceptableVin)) {
                        bwAcceptableVin = whoShouldWeInsurePage.getRandomVinNumber(3);
                    }
                    each.setVehicleVIN(bwAcceptableVin);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });
            whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
        }
        whoShouldWeInsurePage.enterEmailAndPhoneNumber(applicant);
        whoShouldWeInsurePage.validateAgentSectionBDQ(fsa, applicant);

        if (streamlineFlow) {
            vehiclesDriversInfoPage.clickContinueButton();
        } else {
            whoShouldWeInsurePage.clickContinueButton();

            // Vehicle Review page
            VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
            testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on the vehicle review page", true);
            vehicleReviewPage.validateBDQSpecificRule(fsa, applicant);
            vehicleReviewPage.addVehicleDetails(applicant);
            vehicleReviewPage.clickContinueButton();

            // driver review page
            DriverReviewPage driverReviewPage = new DriverReviewPage();
            driverReviewPage.validateBDQSpecificRequirements(fsa, applicant);
            driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
            driverReviewPage.clickContinueButton();
        }


        //Contact info page
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.validateBDQSpecificRule(fsa, applicant);
        String randomPolicyStartDate = BasePage.getFormattedForPolicyStartDate(LocalDate.now().plusDays(new Random().nextInt(29)));
        contactInfoAutoPage.sendKeysToPolicyStartDateInputField(randomPolicyStartDate);
        contactInfoAutoPage.setValuesAndContinue(applicant);

        BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
        if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            bristolWestAdditionalDiscountsPage.clickContinue();
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on teh quote summary page", true);

        quoteSummaryAutoPage.validateBDQSpecificRequirements(fsa, applicant);

        quoteSummaryAutoPage.clickOnStartCheckoutButton();

        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        ThankYouPageAce thankYouPageAce = new ThankYouPageAce();
        if (thankYouPageAce.isOnThankYouPage()) {
            testStep(TEST_COMPLETED + " as the quote landed on the Thank you page");
            return;
        }
        testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User is on the Additional Info Page");

        additionalInfoPolicyStartDateOneUI.validateBDQSpecificRequirements(fsa, applicant, randomPolicyStartDate);
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
        DriverMismatchPage driverMismatchPage = new DriverMismatchPage();
        if (driverMismatchPage.isOnDriverMismatchPage()) {
            driverMismatchPage.validateBDQSpecificRequirements(applicant, fsa);
            driverMismatchPage.dontIncludeAnyMismatchedDriversInQuote();
        }

        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();

        testStepAssert(autoPolicyPaymentBasePage.isOnContinueToPaymentPage(), "User is on the payment selection page");
        autoPolicyPaymentBasePage.validateBDQSpecificRequirements(applicant, fsa);
        processBwDocuSignAndPayments(getRandomPaymentMethodForBW(), false);

        fsa.assertAll();
    }

}
