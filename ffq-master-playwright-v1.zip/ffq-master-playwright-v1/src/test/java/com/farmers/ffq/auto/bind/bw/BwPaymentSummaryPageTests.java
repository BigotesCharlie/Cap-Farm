package com.farmers.ffq.auto.bind.bw;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoContinueToPaymentOneUI;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.auto.pages.bindpages.AutoPolicyPaymentBasePage;
import com.farmers.ffq.auto.pages.bw.BwCongratulationsPage;
import com.farmers.ffq.auto.pages.bw.BwDocuSignPage;
import com.farmers.ffq.auto.pages.bw.BwPaymentSummaryPage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.utils.FarmersSoftAssert;

import com.farmers.ffq.utils.PaymentMethods;
import com.farmers.framework.Property;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage.MONTHLY_AUTO_PAY_BANK;
import static com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage.MONTHLY_AUTO_PAY_CARD;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.MONTHLY_DIRECT_BILL;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class BwPaymentSummaryPageTests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}) /*@CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, IL, IN, MO, OH, OK, OR, TX, UT, WI, SD, MI, PA, WY, KS, CO, NM, IA, VA, GA})*/},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void validateBwPaymentSummaryPageWithRetrieval(AutoApplicant applicant) throws Exception {
        boolean useBDQ = switchTestToBDQIfNeeded(applicant);
        updateLastNameForBristolWest(applicant);
        applicant.setTestScenario("BW->" + applicant.getTestScenario());
        applicant.getDiscounts().get(0).setSignalSignup(false);
        setApplicantPriorBiConditionRandomly(applicant);
        // Added this temporary due to DE291447, as we are getting duplicate discount records for some applicants which is causing issue in payment summary page,
        // This should be removed once DE291447 is fixed.
        applicant.getDiscounts().get(0).setOwnOrRentHome("Rent");
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper(useBDQ? quoteFlow.BDQ: quoteFlow.DEFAULT);
        aceAutoNavigationHelper.navigateToPaymentSelectionPage(applicant);
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User landed on the BW payment summary page");
        bwPaymentSummaryPage.validateBwPaymentSummaryPage(fsa, applicant);

        // Validate that user can navigate to BW payment summary page and see required payplans
        new LandingPage(bwPaymentSummaryPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, bwPaymentSummaryPage.getSessionStorageAppStore().getData().getQuoteNumber());
        testStepAssert(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User landed on the BW payment summary page");
        bwPaymentSummaryPage.validateBwPaymentSummaryPage(fsa, applicant);
        fsa.assertAll();
    }
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, IL, IN, MO, OH, OK, OR, TX, UT, WI, SD, MI, PA, WY, KS, CO, NM, IA, VA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void validatePayInFullPage(AutoApplicant applicant) throws Exception {
        boolean useBDQ = switchTestToBDQIfNeeded(applicant);
        updateLastNameForBristolWest(applicant);
        applicant.setTestScenario("BW->" + applicant.getTestScenario());
        applicant.getDiscounts().get(0).setSignalSignup(false);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        BwPaymentSummaryPage bwPaymentSummaryPage = navigateToPaymentMethodSetUpPage(applicant, PAY_IN_FULL, useBDQ);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        bwPaymentSummaryPage.validatePaymentSetUpPage(PAY_IN_FULL, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, IL, IN, MO, OH, OK, OR, TX, UT, WI, SD, MI, PA, WY, KS, CO, NM, IA, VA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void validateMonthlyPayBank(AutoApplicant applicant) throws Exception {
        boolean useBDQ = switchTestToBDQIfNeeded(applicant);
        applicant.setTestScenario("BW->" + applicant.getTestScenario());
        updateLastNameForBristolWest(applicant);
        applicant.getDiscounts().get(0).setSignalSignup(false);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        BwPaymentSummaryPage bwPaymentSummaryPage = navigateToPaymentMethodSetUpPage(applicant, MONTHLY_AUTO_PAY_BANK, useBDQ);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        bwPaymentSummaryPage.validatePaymentSetUpPage(MONTHLY_AUTO_PAY_BANK, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, IL, IN, MO, OH, OK, OR, TX, UT, WI, SD, MI, PA, WY, KS, CO, NM, IA, VA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void validateMonthlyPayCard(AutoApplicant applicant) throws Exception {
        boolean useBDQ = switchTestToBDQIfNeeded(applicant);
        updateLastNameForBristolWest(applicant);
        applicant.setTestScenario("BW->" + applicant.getTestScenario());
        applicant.getDiscounts().get(0).setSignalSignup(false);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        BwPaymentSummaryPage bwPaymentSummaryPage = navigateToPaymentMethodSetUpPage(applicant, MONTHLY_AUTO_PAY_CARD, useBDQ);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        bwPaymentSummaryPage.validatePaymentSetUpPage(MONTHLY_AUTO_PAY_CARD, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, IL, IN, MO, OH, OK, OR, TX, UT, WI, SD, MI, PA, WY, KS, CO, NM, IA, VA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void validateMonthlyDirectBill(AutoApplicant applicant) throws Exception {
        boolean useBDQ = switchTestToBDQIfNeeded(applicant);
        updateLastNameForBristolWest(applicant);
        applicant.setTestScenario("BW->" + applicant.getTestScenario());
        applicant.getDiscounts().get(0).setSignalSignup(false);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        BwPaymentSummaryPage bwPaymentSummaryPage = navigateToPaymentMethodSetUpPage(applicant, MONTHLY_DIRECT_BILL, useBDQ);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        bwPaymentSummaryPage.validatePaymentSetUpPage(MONTHLY_DIRECT_BILL, fsa);
        fsa.assertAll();
    }


    /**
     * BDQ: Validate Change in Payplan from Payinfull to Monthly autopay-card and complete Bind
     * BDQ: Validate Change in Payplan from Monthly-direct bill to Pay in full and complete Bind
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {MT, CA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void switchPaymentMethodAndBind(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        boolean useBDQ = switchTestToBDQIfNeeded(applicant);
        applicant.setTestScenario("BW->" + applicant.getTestScenario());
        applicant.getDiscounts().get(0).setSignalSignup(false);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        new AceAutoNavigationHelper(useBDQ? quoteFlow.BDQ: quoteFlow.DEFAULT).navigateToPaymentSelectionPage(applicant);
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        testStepAssert(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User landed on the BW payment summary page");
        List<String> pifToMonthlyCard = new ArrayList<>(Arrays.asList(PAY_IN_FULL, MONTHLY_AUTO_PAY_CARD));
        List<String> directToMonthlyCard = new ArrayList<>(Arrays.asList(MONTHLY_DIRECT_BILL, MONTHLY_AUTO_PAY_CARD));
        List<List<String>> combinationsOfPayments = new ArrayList<>();
        combinationsOfPayments.add(pifToMonthlyCard);
        combinationsOfPayments.add(directToMonthlyCard);
        Collections.shuffle(combinationsOfPayments);
        List<String> paymentMethods = combinationsOfPayments.get(0);
        testStep("Testing payment method switch from '" + paymentMethods.get(0) + "' to '" + paymentMethods.get(1) + "'");
        selectPaymentMethodFillOutDocusignAndAddPaymentMethod(paymentMethods.get(0));
        // navigate to the url - https://ffqautouiuat.farmers.com/quote/auto/payment
        driver().navigate().to(Property.getUri().replace("fastquote", "quote") + "auto/payment");
        selectPaymentMethodFillOutDocusignAndAddPaymentMethod(paymentMethods.get(1));
        testStep("Payment method is added", true);
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        autoPolicyPaymentBasePage.clickCompletePurchaseButton();
        BwCongratulationsPage bwCongratulationsPage = new BwCongratulationsPage();
        testStepAssert(bwCongratulationsPage.isOnBwCongratsPage(), "Congratulation page is reached", true);
        bwCongratulationsPage.registerUserForAnAccount();

    }

    /**
     * Validate the following in Organic/Marketing/C2BL/C2BF:
     * 1. Initiate a BW Auto quote and navigate to Pay plan selection page
     * 2. Select 'Pay in full' and complete eSign
     * 3. On the Payments screen, the Down Payment and Future Payments sections will appear for entering payment details.
     * 4. Enter the following: Credit card: 5105105105105100 for Down payment section, and bank account details for Future payment section
     * 5. Click 'Complete Purchase' and verify if 'Payment Declined' pop up displays or not.
     * 6. Close the 'Payment Declined' pop-up and verify on the Payments page if the saved Wallet Info does not displays and the user is always allowed to add the payment info from scratch.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_PayInFull(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateLastNameForBristolWest(applicant);
        boolean useBDQ = switchTestToBDQIfNeeded(applicant);
        applicant.setTestScenario("BW->" + applicant.getTestScenario());
        applicant.getDiscounts().get(0).setSignalSignup(false);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        new AceAutoNavigationHelper(useBDQ? quoteFlow.BDQ: quoteFlow.DEFAULT).navigateToPaymentSelectionPage(applicant);
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        testStepAssert(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User landed on the BW payment summary page");
        addInvalidAndThenValidPaymentMethodAndBind(PAY_IN_FULL, fsa);
        fsa.assertAll();
    }

    /**
     * "Validate the following in Organic/Marketing/C2BL/C2BF:
     * 1. Initiate a BW Auto quote and navigate to Pay plan selection page
     * 2. Select 'Monthly autopay - bank' and complete eSign
     * 3. On the Payments screen, the Down Payment and Future Payments sections will appear for entering payment details.
     * 4. Enter the following: Credit card: 5105105105105100 for Down payment section, and bank account details for Future payment section
     * 5. Click 'Complete Purchase' and verify if 'Payment Declined' pop up displays or not.
     * 6. Close the 'Payment Declined' pop-up and verify on the Payments page if the saved Wallet Info (Future payments info should also be not displaying, if applicable) does not displays and the user is always allowed to add the payment info from scratch."
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyAutoPayBank(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateLastNameForBristolWest(applicant);
        boolean useBDQ = switchTestToBDQIfNeeded(applicant);
        applicant.setTestScenario("BW->" + applicant.getTestScenario());
        applicant.getDiscounts().get(0).setSignalSignup(false);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        new AceAutoNavigationHelper(useBDQ? quoteFlow.BDQ: quoteFlow.DEFAULT).navigateToPaymentSelectionPage(applicant);
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        testStepAssert(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User landed on the BW payment summary page");
        addInvalidAndThenValidPaymentMethodAndBind(MONTHLY_AUTO_PAY_BANK, fsa);
        fsa.assertAll();
    }

    /**
     * "Validate the following in Organic/Marketing/C2BL/C2BF:
     * 1. Initiate a BW Auto quote and navigate to Pay plan selection page
     * 2. Select 'Monthly autopay - card' and complete eSign
     * 3. On the Payments screen, the Down Payment and Future Payments sections will appear for entering payment details.
     * 4. Enter the following: Credit card: 5105105105105100 for Down payment section, and bank account details for Future payment section
     * 5. Click 'Complete Purchase' and verify if 'Payment Declined' pop up displays or not.
     * 6. Close the 'Payment Declined' pop-up and verify on the Payments page if the saved Wallet Info does not displays and the user is always allowed to add the payment info from scratch."
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyAutoPayCard(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateLastNameForBristolWest(applicant);
        boolean useBDQ = switchTestToBDQIfNeeded(applicant);
        applicant.setTestScenario("BW->" + applicant.getTestScenario());
        applicant.getDiscounts().get(0).setSignalSignup(false);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        new AceAutoNavigationHelper(useBDQ? quoteFlow.BDQ: quoteFlow.DEFAULT).navigateToPaymentSelectionPage(applicant);
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        testStepAssert(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User landed on the BW payment summary page");
        addInvalidAndThenValidPaymentMethodAndBind(MONTHLY_AUTO_PAY_CARD, fsa);
        fsa.assertAll();
    }

    /**
     * "Validate the following in Organic/Marketing/C2BL/C2BF:
     * 1. Initiate a BW Auto quote and navigate to Pay plan selection page
     * 2. Select 'Monthly - direct bill' and complete eSign
     * 3. On the Payments screen, the Down Payment and Future Payments sections will appear for entering payment details.
     * 4. Enter the following: Credit card: 5105105105105100 for Down payment section, and bank account details for Future payment section
     * 5. Click 'Complete Purchase' and verify if 'Payment Declined' pop up displays or not.
     * 6. Close the 'Payment Declined' pop-up and verify on the Payments page if the saved Wallet Info does not displays and the user is always allowed to add the payment info from scratch."
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyDirectBill(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateLastNameForBristolWest(applicant);
        boolean useBDQ = switchTestToBDQIfNeeded(applicant);
        applicant.setTestScenario("BW->" + applicant.getTestScenario());
        applicant.getDiscounts().get(0).setSignalSignup(false);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        new AceAutoNavigationHelper(useBDQ? quoteFlow.BDQ: quoteFlow.DEFAULT).navigateToPaymentSelectionPage(applicant);
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        testStepAssert(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User landed on the BW payment summary page");
        addInvalidAndThenValidPaymentMethodAndBind(MONTHLY_DIRECT_BILL, fsa);
        fsa.assertAll();
    }


    private void addInvalidAndThenValidPaymentMethodAndBind(String paymentMethod, FarmersSoftAssert fsa) throws Exception {
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        bwPaymentSummaryPage.processBwPaymentSummaryPage(paymentMethod);
        BwDocuSignPage bwDocuSignPage = new BwDocuSignPage();
        bwDocuSignPage.signDocuments();
        bwPaymentSummaryPage.clickSetUpPaymentButton();
        bwPaymentSummaryPage.addCardPaymentMethod(PaymentMethods.INVALID_MASTERCARD_CREDIT_CARD.getAccountNumber(), bwPaymentSummaryPage.getSessionStorageAppStore().getData().getLandingZipCode());
        bwPaymentSummaryPage.waitForSpinnerToBeGone();
        bwPaymentSummaryPage.clickCompletePurchaseButton();
        bwPaymentSummaryPage.validatePaymentDeclineModalContent(fsa);
        bwPaymentSummaryPage.clickOkOnPaymentDeclinedModal();
        fsa.assertFalse(bwPaymentSummaryPage.isCreditCardEditMessageDisplayed(), "Validate that saved Wallet Info is not displayed and user is allowed to add payment info from scratch");
        bwPaymentSummaryPage.addBwPaymentMethod(paymentMethod);
        bwPaymentSummaryPage.clickCompletePurchaseButton();
        BwCongratulationsPage bwCongratulationsPage = new BwCongratulationsPage();
        testStepAssert(bwCongratulationsPage.isOnBwCongratsPage(), "Congratulation page is reached", true);
        bwCongratulationsPage.registerUserForAnAccount();
    }

    /**
     * Validates that the Good Distant Student Discount is not dropped after verifying the BW payment summary page.
     *
     * Steps:
     * 1. Set the applicant's insurance status, age, and other attributes.
     * 2. Configure the additional driver's details, such as age, GPA, and school distance.
     * 3. Navigate to the quote summary page and validate that the discount is applied.
     * 4. Navigate to the payment page and validate that the discount is still applied.
     * 5. Assert all validations.
     *
     * @param applicant The applicant whose discount details are being validated.
     * @throws Exception If any error occurs during the validation process.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"}), @CustomAttribute(name = INCLUDED_STATES, values = {GA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})
    public void validateGoodDistantStudentDiscountAreNotDroppedAfterVerifyBW(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        applicant.setAge(60);
        applicant.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(applicant.getAge()));
        applicant.setCompletedDriversSafetyCourse(false);

        SqlAdditionalDriver sni = applicant.getAdditionalDrivers().get(0);
        sni.setAge(20);
        sni.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(sni.getAge()));
        sni.setFullTimeStudentWithHighGPA(true);
        sni.setAttendsDistantSchool(true);

        applicant.setTestScenario(BW_ORGANIC_FLOW + SPACE + applicant.getTestScenario());
        applicant.getDiscounts().get(0).setSignalSignup(false);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        testStepAssertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User landed on BDQ/Bw quote summary page");
        String stateCode = applicant.getStateCode();
        quoteSummaryAutoPage.validateGoodDistantStudentDiscountApplied(fsa, stateCode, true);
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        testStepAssert(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User landed on the BW payment summary page");
        quoteSummaryAutoPage.validateGoodDistantStudentDiscountApplied(fsa, stateCode, false);
        fsa.assertAll();
    }

    private BwPaymentSummaryPage navigateToPaymentMethodSetUpPage(AutoApplicant applicant, String paymentMethod, boolean useBDQ) throws Exception {
        new AceAutoNavigationHelper(useBDQ? quoteFlow.BDQ: quoteFlow.DEFAULT).navigateToPaymentSelectionPage(applicant);
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        bwPaymentSummaryPage.processBwPaymentSummaryPage(paymentMethod);
        BwDocuSignPage bwDocuSignPage = new BwDocuSignPage();
        bwDocuSignPage.signDocuments();
        return bwPaymentSummaryPage;
    }
}
