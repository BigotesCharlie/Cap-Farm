package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCAddressBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyDetailsBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCQualityGradeBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomePropertyPageValidationTest extends AutomationFramework {

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE})
    public void testPropertyPage(ApplicantAceHome applicant) throws Exception {
        final String PROPERTY_PAGE_URL_END = "/yearbuilt-area";

        AceHRCAddressBasePage addressPage = new AceHomeNavigationHelper().navigateToAceHomeAddressPage(applicant, LOB_HOME, HOME);
        addressPage.enterAddress(applicant);
        addressPage.enterAvailableFields(applicant);
        addressPage.clickContinueButton();

        AppStore appStore = addressPage.getSessionStorageAppStore();
        applicant.setAddress(appStore.getHome().getAddressForm().getFields().get(0).getAddress());
        Log.info("Google Standardized Street Address: " + applicant.getAddress());
        AceHRCPropertyBasePage propertyBasePage = new AceHRCPropertyBasePage();
        if (!propertyBasePage.isOnHRCPropertyBasePage(false)) {
            (new AceHRCQualityGradeBasePage()).clickContinueButton();
            String currentUrl = driver().getCurrentUrl();
            driver().get(currentUrl + PROPERTY_PAGE_URL_END);
        }

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPropertyBasePage propertyPage = new AceHRCPropertyBasePage();
        fsa.assertEquals(propertyPage.getPropertyAddress().toUpperCase(), applicant.getAddress().toUpperCase() + ", " + applicant.getCity() + ", " +
                applicant.getStateCode() + SPACE + applicant.getZipCode(), "Property page - Address, City, State, Zip match.");
        fsa.assertTrue(propertyPage.isPageTitleDisplayed(), "Property page - Page title is displayed.");
        fsa.assertTrue(propertyPage.isPageTitleInViewport(), "Property page - Page title is in Viewport.");
        propertyPage.validatePageFormFields(fsa);
        applicant.setYearBuilt(Integer.parseInt(propertyPage.getPropertyYearBuiltFieldValue()));
        applicant.setSquareFeet(propertyPage.getPropertyTotalSqFtFieldValue());
        propertyPage.validatePageErrors(fsa, applicant);
        propertyPage.validatePageLinksText(fsa, ENTER_INFO);
        propertyPage.enterPropertyPageFields(applicant);
        propertyPage.clickContinueButton();

        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        if (qualityGradePage.isOnQualityGradePage()) {
            qualityGradePage.fillOutQualityGradePage(applicant, appStore.getHome().getHomeQualityGradeForm());
        }

        AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
        fsa.assertTrue(propertyDetailsPage.isPageTitleDisplayed(), "Property page - arrived at Property details page.");
        fsa.assertAll("Validate Ace Home Property (Year built) page.");
    }
 }

