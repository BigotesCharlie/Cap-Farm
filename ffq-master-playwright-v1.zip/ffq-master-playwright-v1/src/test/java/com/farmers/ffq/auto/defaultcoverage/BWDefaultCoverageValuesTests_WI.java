package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class BWDefaultCoverageValuesTests_WI extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_None_Unk(AutoApplicant applicant) throws Exception {
        //This is going to avoid BW condition based on the foreign driver's license
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        applicant.setFirstAgeForeignDriverLicense(0);
        defaultCoverageTestForBW(applicant, "coverageAmount=None/Unk&umbrella=No", "WI_None_Unk_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_15K30K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=15/30&umbrella=No", "WI_15K30K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_20K40K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=20/40&umbrella=No", "WI_20K40K_");
    }


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_25K50K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=25/50&umbrella=No", "WI_25K50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_30K60K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=30/60&umbrella=No", "WI_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_35K70K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35/70&umbrella=No", "WI_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_50K100K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=50/100&umbrella=No", "WI_50K100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_100K200K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/200&umbrella=No", "WI_100K200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_100K300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/300&umbrella=No", "WI_100K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_150K300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=150/300&umbrella=No", "WI_150K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_300K300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=300/300&umbrella=No", "WI_300K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_250K500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=250/500&umbrella=No", "WI_250K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_500K500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/500&umbrella=No", "WI_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_500K1000K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/1000&umbrella=No", "WI_500K1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_50K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=50&umbrella=No", "WI_50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_75K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=75&umbrella=No", "WI_75K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_100K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100&umbrella=No", "WI_100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_200K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=200&umbrella=No", "WI_200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=300&umbrella=No", "WI_300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500&umbrella=No", "WI_500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = WI)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_WI_1000K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=1000&umbrella=No", "WI_1000K_");
    }

}
