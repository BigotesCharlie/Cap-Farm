package com.farmers.ffq.auto;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.framework.Property;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.LOWERCASE_TRUE;

public class PcSessionClearanceTest {

    @Test(groups = {"pcSessionClear"})
    protected void clearInactiveUserSessionsInPC() throws Exception {
        new BasePage().clearPcUserSessions();
    }

}