package com.farmers.ffq.auto.e2e;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;

import org.apache.commons.lang3.RandomUtils;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class BindOneUIEndToEndTest extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void bindOneUIE2EdWithPifBankAccountAndServiceVirtualizationData(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchase(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void bindOneUIE2EdWithMonthlyAutopayBankAccountAndServiceVirtualizationData(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchase(MONTHLY_AUTOPAY, PaymentMethods.BANK_ACCOUNT_1, true, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void bindOneUIE2EdWithPifDebitCardAndServiceVirtualizationData(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchase(PAY_IN_FULL, PaymentMethods.VISA_DEBIT_CARD_1, true, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void bindOneUIE2EdWithMonthlyAutopayDebitCardAndServiceVirtualizationData(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchase(MONTHLY_AUTOPAY, PaymentMethods.VISA_DEBIT_CARD_1, true, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void bindOneUIE2EdWithPifCreditCardAndServiceVirtualizationData(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        List<PaymentMethods> availableCreditCards = Arrays.asList(PaymentMethods.VISA_CREDIT_CARD_1, PaymentMethods.AMEX_CREDIT_CARD_1, PaymentMethods.MASTERCARD_CREDIT_CARD_1);
        PaymentMethods randomPaymentMethod = availableCreditCards.get(new Random().nextInt(availableCreditCards.size()));
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchase(PAY_IN_FULL, randomPaymentMethod, true, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void bindOneUIE2EdWithMonthlyAutopayCreditCardAndServiceVirtualizationData(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);

        List<PaymentMethods> availableCreditCards = Arrays.asList(PaymentMethods.VISA_CREDIT_CARD_1, PaymentMethods.AMEX_CREDIT_CARD_1, PaymentMethods.MASTERCARD_CREDIT_CARD_1);
        PaymentMethods randomPaymentMethod = availableCreditCards.get(new Random().nextInt(availableCreditCards.size()));
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchase(MONTHLY_AUTOPAY, randomPaymentMethod, true, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.BIND_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ACE_AUTO_E2E, FFQ_BIND_WITH_ADPFDATA_ENDTOEND})
    public void bindOneUIE2EndWithDebitCardAndAdpfData(ADPFApplicant applicant) throws Exception {
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchase(PAY_IN_FULL, PaymentMethods.VISA_DEBIT_CARD_1, false, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=5")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void validateBindWithDLObtainedFromDifferentState(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.getVehicles().forEach(each -> {
            each.setParkInResidentAddress(true);
            each.setVehicleUsage("Personal");
        });
        applicant.setTestScenario(DIFFERENT_STATE_DL + applicant.getTestScenario());
        applicant.setLastName("Bailey");
        new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);

        AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        additionalInfoVehicleSectionOneUI.fillOutVehicleSectionAlternative();
        additionalInfoVehicleSectionOneUI.closeQualtricsPopUp();
        // enter mature driver date
        additionalInfoDriverSectionOneUI.enterMatureDriverSafetyCourseDate(additionalInfoDriverSectionOneUI.getSessionStorageAppStore().getData().getLandingStateCode());

        // select a different state for dl
        List<String> stateCodes = listOfAllStates();
        stateCodes.removeIf(each -> Arrays.asList(applicant.getStateCode(), NY, NJ).contains(each));
        Collections.shuffle(stateCodes);

        additionalInfoDriverSectionOneUI.enterDriverLicenseNumber(stateCodes.get(0));
        additionalInfoDriverSectionOneUI.fillOutDriverInfoSectionForRace();
        // fill out signal section
        additionalInfoSignalEnrollmentSectionOneUI.fillOutSignalEnrollmentSection();
        additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();

        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        DriverMismatchPage driverMismatchPage = new DriverMismatchPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
            BristolWestAdditionalDiscountsPage additionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
            if (additionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                additionalDiscountsPage.clickContinue();
            }
            QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
            if(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            	quoteSummaryAutoPage.clickOnStartCheckoutButton();
            	quoteSummaryAutoPage.waitForSpinnerToBeGone();
            }
            AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
            if (additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage()) {
            	additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
            }
        }
        if (driverMismatchPage.isOnDriverMismatchPage()) {
        	driverMismatchPage.dontIncludeAnyMismatchedDriversInQuote();
        	driverMismatchPage.clickContinueButton();
        	driverMismatchPage.waitForSpinnerToBeGone();
        }
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchase(MONTHLY_AUTOPAY, PaymentMethods.BANK_ACCOUNT_1, true, fsa);
        fsa.assertAll();
    }

    /**
     * F87642
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")},
            dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validate_bind_disabled_when_fasttrackIndicator_false_otherwise_continue_with_bind(AutoApplicant applicant) throws Exception {
        boolean fastTrackVinProvided = RandomUtils.nextBoolean();
        String updatedTestScenario = (fastTrackVinProvided ? EMPTY_STRING : NO_FAST_TRACK) + applicant.getTestScenario();
        applicant.setTestScenario(updatedTestScenario);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        AutoRateQuoteResponseBean autoRateQuote = new ApiHelper().getAutoRateQuote(consolidatedPaymentPage.getSessionStorageAppStore().getData().getQuoteNumber());
        AutoRateQuoteResponseBean.AutoRateQuoteResponseBean__1.RateQuoteResponse rateQuoteResponse = autoRateQuote.getAutoRateQuoteResponseBean().getRateQuoteResponses().get(0);
        boolean bindEnabled = rateQuoteResponse.getBuyEnableInd().equals("Y");
        boolean fastTrackIndicator = rateQuoteResponse.getIsFastTrackInd().equals("true");
        quoteSummaryAutoPage.clickOnStartCheckoutButton();
        if (!bindEnabled || !fastTrackIndicator) {
            ThankYouPageAce thankYouPageAce = new ThankYouPageAce();
            softAssert.assertTrue(thankYouPageAce.isOnThankYouPage(), "User should be on the thank you page with non fast track vin");
        } else {
            AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
            testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "Additional info page reached", true);
            additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
            testStepAssert(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "Consolidated payment page reached", true);
            completePurchase(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, softAssert);
        }

    }

    /**
     * F87642 Validate that [2 Vehicle + 2 Driver] FFQ (CA) - Auto - Send the odometer reading information in RC3 call to PC
     * 471, 472 , 474 [Scenario numbers covered]
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"}),@CustomAttribute(name = INCLUDED_STATES, values = {CA})},
            dataProviderClass = AutoDataProviders.class,groups = {FFQ_ONEUI})
    public void validateOdometer_Rideshare_InfoIsSentToPC_Bind_F87642(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        Vehicle vehicle1 = applicant.getVehicles().get(0);
        Vehicle vehicle2 = vehicle1.clone();
        vehicle1.setUseVIN(false);
        vehicle1.setVehicleUsage("Rideshare");
        vehicle1.setRidesharing(true);
        vehicle2.setUseVIN(true);
        vehicle2.setVehicleUsage("Personal");
        vehicle2.setRidesharing(false);
        applicant.setVehicles(Arrays.asList(vehicle1, vehicle2));
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);

        // customize

        quoteSummaryAutoPage.updateLiabilityAndCustomize();
        quoteSummaryAutoPage.updateVehicleCoverageAndCustomize();
        quoteSummaryAutoPage.clickOnStartCheckoutButton();


        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User should be on the additional info page");
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
       // testStepAssert(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User should be on the Consolidated Payment page");

        AutoQuoteVerifyServiceInitiated autoQuoteVerifyServiceInitiated = new ApiHelper().getAutoQuoteVerifyServiceInitiated(consolidatedPaymentPage.getSessionStorageAppStore().getData().getQuoteNumber());
        AutoQuoteVerifyServiceInitiated.AutoQuote.PersonalAuto personalAuto = autoQuoteVerifyServiceInitiated.getAutoQuote().get(0).getPersonalAuto();

        // validate  odometer readings are passed
        personalAuto.getVehicles().forEach(eachVeh -> {
            softAssert.assertTrue(!eachVeh.getOdometerReading().isEmpty(), "Odometer data should be provided in the verify rate response");
            softAssert.assertTrue(!eachVeh.getOdometerReadingDate().isEmpty(), "Odometer reading date should be provided in the verify rate response");
        });

        // validate rideshare and RNOG are passed
        boolean hasRideSharingDriver = personalAuto.getDrivers().stream()
                .anyMatch(driver -> "Y".equals(driver.getRideSharingIndicator()));

        softAssert.assertTrue(hasRideSharingDriver, "No driver has rideSharingIndicator set to 'Y'");

        boolean anyHasRNOGConsent = personalAuto.getDrivers().stream()
                .anyMatch(driver -> driver.getCustomerRNOGConsentInd() != null);

        softAssert.assertTrue(anyHasRNOGConsent, "No driver has a non-null customerRNOGConsentInd.");

       // completePurchase(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, softAssert);

        softAssert.assertAll();
    }
}