package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bindpages.ConsolidatedPaymentPage;
import com.farmers.ffq.auto.pages.bw.BwPaymentSummaryPage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.RandomUtils;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;


import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.common.pages.BasePage.calculateDateOfBirthFromAge;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class VehiclesDriversInfoPageTests extends BaseTest {

    /**
     * F88009 : Auto Sheet: Create auto quote for MVP state with VE project code is ON,verify user lands on new UI(vehicle driver info) is displayed  after submiting contact info screen
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {FFQ_ONEUI})
    public void validateEVProjectAndDiscountSectionOnVehiclesDriversReviewPage(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        AutoBasePage autoBasePage = aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        String quoteNumber = autoBasePage.getSessionStorageAppStore().getData().getQuoteNumber();
        ApiHelper apiHelper = new ApiHelper();

        ProjectCodeStatusServiceCallEnd projectCodeStatusServiceCallResponse = apiHelper.getProjectCodeStatusServiceCallResponse(quoteNumber);
        String expectedFinalPathSegment = "vehicles-drivers-review";
        if (projectCodeStatusServiceCallResponse.getCommonProjectCodeStatusResponseBean().getAuto().isVehiclesDriversConsolidationImpl()) {
            expectedFinalPathSegment = "vehicles-drivers-info";
        }

        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        softAssert.assertTrue(driver().getCurrentUrl().contains(expectedFinalPathSegment), "Url of the page is correctly navigated");
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        vehiclesDriversInfoPage.validateDiscountSectionAndSideSheet(applicant, softAssert);
        softAssert.assertAll();
    }

    /**
     * F88009 : "Create auto quote for MVP state with VE project code is ON (Validate for ADPF data), Below info text is displayed along with vehicle & driver section
     * Please check the information we have. You can edit anything that doesn’t look right."
     * F88009 : "Create auto quote for MVP state with VE project code is ON (Validate for ADPF data) & navigate till vehicle driver info screen .Vehicle summary view validation - verify whether ADPF returned vehicle details are displayed in summary view - vehicle card & validate the below
     * - check vehicle order is displayed (vehicle 1,2 ,3 …) with VIN number showing only last three digits & others are masked
     * - YMM should be displayed below VIN
     * - Verify the following fields are displayed with values prefilled from  ADPF in vehicle card -  Vehicle use,Rideshare, Ownership,Parked at."
     */
    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70", "72", "73", "74"})}, groups = {FFQ_ONEUI})
    public void validateAdpfDataPrefilledCorrectly(ADPFApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.navigateToHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        vehiclesDriversInfoPage.validatePageDescription(softAssert);
        vehiclesDriversInfoPage.validatePrefilledValues(softAssert);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70", "72"})}, groups = {FFQ_ONEUI})
    public void validateMarriedButtonAndNestedSpouseSideSheet(ADPFApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.navigateToHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        vehiclesDriversInfoPage.validatePageDescription(softAssert);
        vehiclesDriversInfoPage.validateMarriedCheckboxAndOptions(softAssert, applicant);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateVehDriverErrorMessagesAndFilledValues(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        randomizeApplicantPersonalData(applicant);
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        List<Vehicle> vehicles = applicant.getVehicles();
        vehiclesDriversInfoPage.validateVehicleSideSheetAndVehicleCard(softAssert, vehicles.get(0));
        vehiclesDriversInfoPage.validateDriverSideSheetAndDriverCard(softAssert, applicant);
        softAssert.assertAll();
    }

    /**
     * Validates the error message for a faulty VIN and ensures the vehicle is correctly reflected on the vehicle card.
     * This test performs the following steps:
     * - Adds a vehicle with a faulty VIN and validates the error message.
     * - Updates the vehicle details with updated YMM.
     * - Validates that the added vehicle details are correctly displayed on the vehicle card.
     *
     * @param applicant The applicant object containing vehicle details.
     * @throws Exception If any error occurs during execution.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MN, WA, IL, OK, VA, AZ, MO, OH, TN, NM, ID, IN, AR, CO, MI, OR})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void testFaultyVINErrorAndVehicleCardReflectionWithUpdatedYMMDetails(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        List<Vehicle> vehicles = applicant.getVehicles();
        Vehicle firstVehicle = vehicles.get(0);
        vehiclesDriversInfoPage.addVehicleWithYMMAndFaultyVINAndValidateVINError(softAssert, firstVehicle);
        vehiclesDriversInfoPage.addVehicleWithUpdatedYMM(firstVehicle);
        vehiclesDriversInfoPage.validateAddedVehicleDetailsOnCard(firstVehicle, softAssert);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70"})}, groups = {FFQ_ONEUI})
    public void validateVehDriverPageToolTips(ADPFApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.navigateToHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        vehiclesDriversInfoPage.validateDriverToolTips(applicant, softAssert);
        softAssert.assertAll();
    }

    /**
     * Test Scenario numbers: 667
     * Page navigations: Vehicle driver info_Non driving Spouse
     *
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {IL, AZ, WA, OH, MO, OK, OR, MI}), @CustomAttribute(name = FILTER, values = "applicantId=1")},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateNonDriverSpouseQuestions(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        randomizeApplicantPersonalData(applicant);
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        vehiclesDriversInfoPage.validateAdditionalQuestionsAreNotAskedForNonDrivingSpouse(applicant, softAssert);
        softAssert.assertAll();
    }

    /**
     * Test Scenario numbers: 668
     * Page navigations: Vehicle driver info_Non driving Spouse
     *
     * @param applicant
     * @throws Exception "Create auto quote for MVP state with VE & SN  project code is ON & navigate till vehicle driver info screen.
     *                   Add Vehicle
     *                   Add PNI & SNI as non-driving spouse
     *                   Add additional drivers & add spouse as nondriver for  any one additional driver
     *                   Rate the quote
     *                   Validate in rate request - non driver flag is set as 'EX' for non-driving spouse
     *                   Retrieve the quote
     *                   Validate the sidesheet of all drivers & check non driving question of spouse is displayed only in spouse edit sidesheet"
     */

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {IL, AZ, WA, OH, MO, OK, OR, MI}), @CustomAttribute(name = FILTER, values = "applicantId=12")},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateNonDriverSpouseValuesPassedCorrectlyForFarmers(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        randomizeApplicantPersonalData(applicant);
        applicant.setMaritalStatus(MARRIED);
        // update additional driver as spouse non driver
        SqlAdditionalDriver sni = applicant.getAdditionalDrivers().get(0);
        sni.setMaritalStatus(MARRIED);
        sni.setLicenseToDriveInUSA(NO);
        sni.setRelationshipToApplicant(SPOUSE);
        sni.setFirstName("Snifirstname");
        sni.setLastName("Snilastname");

        for (int i = applicant.getAdditionalDrivers().size() - 1; i > 1; i--) {
            applicant.getAdditionalDrivers().remove(i); // remove nth additional driver to avoid duplicate entries
        }

        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        vehiclesDriversInfoPage.validateNonDrivingSpouseProperlyPassedInRateRequest(applicant, false);
    }

    /**
     * Test Scenario numbers: 669
     * Page navigations: Vehicle driver info_Non driving Spouse
     *
     * @param applicant
     * @throws Exception "Create auto quote for MVP state with VE & SN  project code is ON & navigate till vehicle driver info screen.
     *                   Add Vehicle
     *                   Add PNI with brightline consdition (select NO insurance) ,, select married checkbox  &  add SNI as non-driving spouse  (select 'No' for Will your spouse be driving ....)& SNI as non-driving spouse
     *                   Add additional drivers & add spouse as nondriver for  any one additioanl driver
     *                   Rate the quote in BW
     *                   Validate in rate request - non driver flag is set as '2' for non-driving spouse
     *
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {IL, AZ, WA, OH, MO, OK, OR, MI}), @CustomAttribute(name = FILTER, values = "applicantId=12")},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateNonDriverSpouseValuesPassedCorrectlyForBW(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        randomizeApplicantPersonalData(applicant);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        updateLastNameForBristolWest(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.setMaritalStatus(MARRIED);
        // update additional driver as spouse non driver
        SqlAdditionalDriver sni = applicant.getAdditionalDrivers().get(0);
        sni.setMaritalStatus(MARRIED);
        sni.setLicenseToDriveInUSA(NO);
        sni.setRelationshipToApplicant(SPOUSE);
        sni.setFirstName("Snifirstname");
        sni.setLastName("Snilastname");

        for (int i = applicant.getAdditionalDrivers().size() - 1; i > 1; i--) {
            applicant.getAdditionalDrivers().remove(i); // remove nth additional driver to avoid duplicate entries
        }

        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        vehiclesDriversInfoPage.validateNonDrivingSpouseProperlyPassedInRateRequest(applicant, true);

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=31"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})
    public void validateDriverCheckboxesAndContinue_Married(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateVehicleCountToOne(applicant);
        randomizeApplicantPersonalData(applicant);
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        if (!vehiclesDriversInfoPage.isAddVehicleAndDriversButtonPresent()) {
            testStep("Test skipped as vehicles and drivers are prefilled");
            return;
        }
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(softAssert, applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=7"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS, BW_ACE_TESTS})
    public void validateCheckboxesAfterRetrievalOfRatedQuote(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateVehicleCountToOne(applicant);

        if (Property.getTestProperty("suite").contains(BW_ACE_TESTS)) {
            // providing brightline condition to run bw tests when suite is BW_ACE_TESTS
            applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
            if (applicant.getStateCode().equals(OR)) {
                applicant.setFinancialFiling(SR_22);
            }
            applicant.setLastName("Threeoabaa");
        }

        // randomize the dateOfBirth and age to cover more ages
        applicant.setAge(RandomUtils.nextInt(56, 98));
        applicant.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(applicant.getAge()));
        randomizeApplicantPersonalData(applicant);
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, applicant.getEmail());
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        testStepAssert(vehiclesDriversInfoPage.isOnWhoShouldWeInsurePage(), "User is on the Who Should we Insure page after clicking on the Enter navigation bar from Quote Summary page");
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(softAssert, applicant);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=22"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})
    public void validateDriverCheckboxesAndContinue_YoungApplicant(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateVehicleCountToOne(applicant);
        randomizeApplicantPersonalData(applicant);
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        if (!vehiclesDriversInfoPage.isAddVehicleAndDriversButtonPresent()) {
            testStep("Test skipped as vehicles and drivers are prefilled");
            return;
        }
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(softAssert, applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=7"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})
    public void validateDriverCheckboxesAndContinue_OldApplicant(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateVehicleCountToOne(applicant);
        randomizeApplicantPersonalData(applicant);
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        if (!vehiclesDriversInfoPage.isAddVehicleAndDriversButtonPresent()) {
            testStep("Test skipped as vehicles and drivers are prefilled");
            return;
        }
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(softAssert, applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=28"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})
    public void validateDriverCheckboxesAndContinue_Applicant_With_Incidents(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateVehicleCountToOne(applicant);
        randomizeApplicantPersonalData(applicant);
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        if (!vehiclesDriversInfoPage.isAddVehicleAndDriversButtonPresent()) {
            testStep("Test skipped as vehicles and drivers are prefilled");
            return;
        }
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(softAssert, applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=12"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})
    public void validateDriverCheckboxesAndContinue_4_AdditionalDrivers(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateVehicleCountToOne(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.getVehicles().forEach(each -> {
            each.setRidesharing(false);
            each.setVehicleUsage("Personal");
        });
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        if (!vehiclesDriversInfoPage.isAddVehicleAndDriversButtonPresent()) {
            testStep("Test skipped as vehicles and drivers are prefilled");
            return;
        }
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(softAssert, applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=31"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})
    public void validateDriverCheckboxesAndContinue_3_AdditionalDrivers(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateVehicleCountToOne(applicant);
        randomizeApplicantPersonalData(applicant);
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        if (!vehiclesDriversInfoPage.isAddVehicleAndDriversButtonPresent()) {
            testStep("Test skipped as vehicles and drivers are prefilled");
            return;
        }
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(softAssert, applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=30"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, BDQ_TESTS})
    public void validateDriverCheckboxesAndContinue_2_AdditionalDrivers(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateVehicleCountToOne(applicant);
        randomizeApplicantPersonalData(applicant);
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        if (!vehiclesDriversInfoPage.isAddVehicleAndDriversButtonPresent()) {
            testStep("Test skipped as vehicles and drivers are prefilled");
            return;
        }
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(softAssert, applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        softAssert.assertAll();
    }

    /**
     * Validates the functionality of editing vehicles when navigating back to the Vehicle Driver Info Page
     * from the Quote Summary Page. This test performs the following steps:
     * - Updates the applicant data to avoid potential issues with Bristol West (BW).
     * - Randomizes applicant personal data for broader test coverage.
     * - Updates the vehicle count to two, ensuring both VIN and YMM vehicle additions are covered.
     * - Navigates to the "Who Should We Insure" page and adds vehicles and drivers if none are found.
     * - Navigates to the Quote Summary Page and verifies the navigation.
     * - Returns to the Vehicle Driver Info Page from the Quote Summary Page and performs the following:
     * - Updates the VIN for a vehicle added by YMM.
     * - Updates the YMM for a vehicle added by VIN.
     * - Updates the VIN for a newly added vehicle by VIN.
     * - Edits a vehicle by adding a new VIN but does not save the changes, validating the vehicle card.
     * - Asserts all validations.
     *
     * @param applicant The applicant object containing vehicle and driver details.
     * @throws Exception If any error occurs during execution.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=8"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void updateVehicleVinWhichWasAddedByYMMAndValidateVehicleCard(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        List<Vehicle> vehicles = applicant.getVehicles();
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on Quote Summary Auto Page");
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        testStepAssert(vehiclesDriversInfoPage.isOnWhoShouldWeInsurePage(), "User is navigated back to Vehicle Driver Info Page from Quote Summary Page");
        vehiclesDriversInfoPage.updateVehicleVinWhichWasAddedByYMMAndValidateVehicleCard(vehicles.stream().filter(each -> !each.isUseVIN()).collect(Collectors.toList()).stream().findFirst().get(), fsa);
        fsa.assertAll();
    }

    /**
     * Validates the functionality of editing vehicles when navigating back to the Vehicle Driver Info Page
     * from the Quote Summary Page. This test performs the following steps:
     * - Updates the applicant data to avoid potential issues with Bristol West (BW).
     * - Randomizes applicant personal data for broader test coverage.
     * - Updates the vehicle count to two, ensuring both VIN and YMM vehicle additions are covered.
     * - Navigates to the "Who Should We Insure" page and adds vehicles and drivers if none are found.
     * - Navigates to the Quote Summary Page and verifies the navigation.
     * - Returns to the Vehicle Driver Info Page from the Quote Summary Page and performs the following:
     * - Updates the VIN for a vehicle added by YMM.
     * - Updates the YMM for a vehicle added by VIN.
     * - Updates the VIN for a newly added vehicle by VIN.
     * - Edits a vehicle by adding a new VIN but does not save the changes, validating the vehicle card.
     * - Asserts all validations.
     *
     * @param applicant The applicant object containing vehicle and driver details.
     * @throws Exception If any error occurs during execution.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=8"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void updateVehicleYMMWhichWasAddedByVINAndValidateVehicleCard(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        updateVehicleCountToOne(applicant);
        applicant.getVehicles().get(0).setUseVIN(true);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on Quote Summary Auto Page");
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        testStepAssert(vehiclesDriversInfoPage.isOnWhoShouldWeInsurePage(), "User is navigated back to Vehicle Driver Info Page from Quote Summary Page");
        vehiclesDriversInfoPage.updateVehicleYMMWhichWasAddedByVINAndValidateVehicleCard(applicant.getVehicles().get(0), fsa);
        fsa.assertAll();
    }

    /**
     * Validates the functionality of editing vehicles when navigating back to the Vehicle Driver Info Page
     * from the Quote Summary Page. This test performs the following steps:
     * - Updates the applicant data to avoid potential issues with Bristol West (BW).
     * - Randomizes applicant personal data for broader test coverage.
     * - Updates the vehicle count to two, ensuring both VIN and YMM vehicle additions are covered.
     * - Navigates to the "Who Should We Insure" page and adds vehicles and drivers if none are found.
     * - Navigates to the Quote Summary Page and verifies the navigation.
     * - Returns to the Vehicle Driver Info Page from the Quote Summary Page and performs the following:
     * - Updates the VIN for a vehicle added by YMM.
     * - Updates the YMM for a vehicle added by VIN.
     * - Updates the VIN for a newly added vehicle by VIN.
     * - Edits a vehicle by adding a new VIN but does not save the changes, validating the vehicle card.
     * - Asserts all validations.
     *
     * @param applicant The applicant object containing vehicle and driver details.
     * @throws Exception If any error occurs during execution.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=8"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void updateNewVehicleVinWhichWasAddedByVINAndValidateVehicleCard(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.getVehicles().forEach(each -> {
            each.setRidesharing(false);
            each.setVehicleUsage("Personal");
        });
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on Quote Summary Auto Page");
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        testStepAssert(vehiclesDriversInfoPage.isOnWhoShouldWeInsurePage(), "User is navigated back to Vehicle Driver Info Page from Quote Summary Page");
        vehiclesDriversInfoPage.updateNewVehicleVinWhichWasAddedByVINAndValidateVehicleCard(applicant.getVehicles().get(1), fsa);
        fsa.assertAll();
    }

    /**
     * Validates the functionality of editing vehicles when navigating back to the Vehicle Driver Info Page
     * from the Quote Summary Page. This test performs the following steps:
     * - Updates the applicant data to avoid potential issues with Bristol West (BW).
     * - Randomizes applicant personal data for broader test coverage.
     * - Updates the vehicle count to two, ensuring both VIN and YMM vehicle additions are covered.
     * - Navigates to the "Who Should We Insure" page and adds vehicles and drivers if none are found.
     * - Navigates to the Quote Summary Page and verifies the navigation.
     * - Returns to the Vehicle Driver Info Page from the Quote Summary Page and performs the following:
     * - Updates the VIN for a vehicle added by YMM.
     * - Updates the YMM for a vehicle added by VIN.
     * - Updates the VIN for a newly added vehicle by VIN.
     * - Edits a vehicle by adding a new VIN but does not save the changes, validating the vehicle card.
     * - Asserts all validations.
     *
     * @param applicant The applicant object containing vehicle and driver details.
     * @throws Exception If any error occurs during execution.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=8"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void editVehicleByAddingNewVinButDoNotSaveVehicleAndValidateVehicleCard(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();

        applicant.getVehicles().add(applicant.getVehicles().get(1).clone());

        applicant.getVehicles().forEach(each -> {
            try {
                each.setVehicleVIN(vehiclesDriversInfoPage.getRandomVinNumber(3));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        // adding new vehicle with VIN
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on Quote Summary Auto Page");
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        testStepAssert(vehiclesDriversInfoPage.isOnWhoShouldWeInsurePage(), "User is navigated back to Vehicle Driver Info Page from Quote Summary Page");
        vehiclesDriversInfoPage.editVehicleByAddingNewVinButDoNotSaveVehicleAndValidateVehicleCard(applicant.getVehicles().get(1), fsa);
        fsa.assertAll();
    }

    /**
     * Validates the Quote Summary Page for an applicant with 2 vehicles and 2 drivers using ADPF data.
     * This test performs the following steps:
     * - Navigates to the "Here's What We Found" page.
     * - Validates the page description on the Vehicles and Drivers Info Page.
     * - Edits the Primary Named Insured (PNI) driver details if needed using ADPF data.
     * - Navigates to the Quote Summary Page and validates the navigation.
     * - Proceeds to the Payment Page from the Quote Summary Page.
     * - Asserts all validations.
     *
     * @param applicant The ADPFApplicant object containing vehicle and driver details.
     * @throws Exception If any error occurs during execution.
     */

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70"})}, groups = {FFQ_ONEUI})
    public void validateQuoteSummaryPageWith2Veh2DriverAdpfData(ADPFApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.navigateToHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        vehiclesDriversInfoPage.validatePageDescription(softAssert);
        vehiclesDriversInfoPage.editPNIDriverIfNeededWithAdpfData(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=26"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, ID, IL, MN, OH, OK, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateMatureDriverOrDefensiveDriverDiscountFarmers(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        String stateCode = applicant.getStateCode();

        updateVehicleCountToOne(applicant);
        if (applicant.getStateCode().equals(AZ)) {
            applicant.getVehicles().forEach(each -> each.setUseVIN(false));
        }
        randomizeApplicantPersonalData(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setCompletedDriversSafetyCourse(false);
        // Mature driver discount appears for random last name for TN state - some PC data set up
        if (!stateCode.equals(TN)) {
            applicant.setLastName("Brown");
        }

        // OK state does not have age limit for mature driver discount
        setRandomAgeForApplicantToSafetyCourse(applicant, false);

        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();

        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        if (heresWhatWeFoundPage.isOnHeresWhatWeFoundPage()) {
            vehiclesDriversInfoPage.selectAndEditDefaultAdpfDrivers(Collections.emptyList());
        } else {
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        }


        // check snackbar message on adding and removing safety course
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(fsa, applicant);
        vehiclesDriversInfoPage.validateMatureDriverDiscountAndSnackBarMessage(applicant, fsa);

        // check mature driver discount is present when adding safety course
        vehiclesDriversInfoPage.clickEditButtonWithDriverFullName(vehiclesDriversInfoPage.getPniFullNameFromAutoApplicant(applicant));
        vehiclesDriversInfoPage.addSafetyCourse(applicant.getAge(), true, vehiclesDriversInfoPage.getPniFullNameFromAutoApplicant(applicant));

        boolean isDefensiveDriverDiscountEnabled = vehiclesDriversInfoPage.isDefensiveDriverDiscountEnabledFarmersStreamlineState(stateCode);
        vehiclesDriversInfoPage.validateMatureOrDefensiveDriverDiscountAddedSnackBar(fsa, isDefensiveDriverDiscountEnabled);
        vehiclesDriversInfoPage.clickSaveChangesDriverSheet();
        vehiclesDriversInfoPage.validateMatureOrDefensiveDriverDiscountPresent(fsa, isDefensiveDriverDiscountEnabled);

        // check mature driver discount is present on quote summary page
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        vehiclesDriversInfoPage.validateMatureOrDefensiveDriverDiscountPresent(fsa, isDefensiveDriverDiscountEnabled);

        // check mature driver discount is present on consolidated payment page
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        if (consolidatedPaymentPage.isOnConsolidatedPaymentPage()) {
            consolidatedPaymentPage.checkDefensiveOrMatureDriverDiscountOnConsolidatedPaymentPage(fsa, isDefensiveDriverDiscountEnabled);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=7"}), @CustomAttribute(name = INCLUDED_STATES, values = {MO, IN})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateMatureDriverDiscountNotPresentFarmers(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();

        updateVehicleCountToOne(applicant);
        randomizeApplicantPersonalData(applicant);

        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();

        applicant.getVehicles().get(0).setUseVIN(false);
        if (!vehiclesDriversInfoPage.isAddVehicleAndDriversButtonPresent()) {
            testStep("Test skipped as vehicles and drivers are prefilled");
            return;
        }
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);

        // Check safety course option is not available and mature driver discount is not applied
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(softAssert, applicant);
        vehiclesDriversInfoPage.clickEditButtonWithDriverFullName(vehiclesDriversInfoPage.getPniFullNameFromAutoApplicant(applicant));
        vehiclesDriversInfoPage.validateDriverSafetyCheckBoxIsNotPresent(softAssert);
        softAssert.assertFalse(vehiclesDriversInfoPage.isDiscountPresentInTheSideSheet(MATURE_DRIVER), "Mature Driver discount is not displayed after brightline");
        softAssert.assertAll();
    }

    // DE287591 is added for BW review discount link not displayed
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=26"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, ID, IL, MN, NM, OH, OK, TN, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS})
    public void validateMatureDefensiveDriverDiscountForBWBrightLine(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();

        updateVehicleCountToOne(applicant);
        randomizeApplicantPersonalData(applicant);
        updatePersonalInfoForProd(applicant);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        applicant.setCompletedDriversSafetyCourse(false);
        setRandomAgeForApplicantToSafetyCourse(applicant, true);

        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();

        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        if (heresWhatWeFoundPage.isOnHeresWhatWeFoundPage()) {
            vehiclesDriversInfoPage.selectAndEditDefaultAdpfDrivers(Collections.emptyList());
        } else {
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        }

        // check snackbar message on adding and removing safety course
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(softAssert, applicant);
        vehiclesDriversInfoPage.validateMatureDriverDiscountAndSnackBarMessage(applicant, softAssert);

        // check mature driver discount is present when adding safety course
        String pniFullNameFromAutoApplicant = vehiclesDriversInfoPage.getPniFullNameFromAutoApplicant(applicant);
        vehiclesDriversInfoPage.clickEditButtonWithDriverFullName(pniFullNameFromAutoApplicant);
        vehiclesDriversInfoPage.addSafetyCourse(applicant.getAge(), true, pniFullNameFromAutoApplicant);
        vehiclesDriversInfoPage.clickSaveChangesDriverSheet();
        boolean isDefensiveDiscountEnabled = vehiclesDriversInfoPage.isDefensiveDriverDiscountEnabledFarmersStreamlineState(applicant.getStateCode());
        vehiclesDriversInfoPage.validateMatureOrDefensiveDriverDiscountPresent(softAssert, isDefensiveDiscountEnabled);

        // check mature driver discount is present on quote summary page
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();

        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        quoteSummaryAutoPage.validateMatureDriverDiscountPresenceBW(softAssert, applicant);

        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        if (bwPaymentSummaryPage.isOnBwPaymentSummaryPage()) {
            quoteSummaryAutoPage.validateMatureDriverDiscountPresenceBW(softAssert, applicant);
        }
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=26"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, IN, VA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS})
    public void validateMatureDefensiveDriverDiscountNotPresentBWBrightLine(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();

        updateVehicleCountToOne(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        updateLastNameForBristolWest(applicant);
        applicant.setCompletedDriversSafetyCourse(false);

        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();

        if (!vehiclesDriversInfoPage.isAddVehicleAndDriversButtonPresent()) {
            testStep("Test skipped as vehicles and drivers are prefilled");
            return;
        }
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);

        // check snackbar message on adding and removing safety course
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(softAssert, applicant);
        vehiclesDriversInfoPage.validateMatureDriverDiscountAndSnackBarMessage(applicant, softAssert);

        // check mature driver discount is present when adding safety course
        vehiclesDriversInfoPage.clickEditButtonWithDriverFullName(vehiclesDriversInfoPage.getPniFullNameFromAutoApplicant(applicant));
        vehiclesDriversInfoPage.addSafetyCourse(applicant.getAge(), true, vehiclesDriversInfoPage.getPniFullNameFromAutoApplicant(applicant));
        vehiclesDriversInfoPage.clickSaveChangesDriverSheet();
        softAssert.assertTrue(vehiclesDriversInfoPage.isDiscountPresentInTheSideSheet(MATURE_DRIVER), "Mature Driver discount is displayed in the side sheet after adding safety course on vehicle driver page");

        // check mature driver discount is present on quote summary page
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();

        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        testStepAssert(vehiclesDriversInfoPage.isOnVehiclesDriversInfoPage(), "User is navigated back to Vehicle Driver Info Page from Quote Summary Page");

        softAssert.assertFalse(vehiclesDriversInfoPage.isDiscountPresentInTheSideSheet(MATURE_DRIVER), "Mature Driver discount is not displayed after brightline");
        vehiclesDriversInfoPage.clickEditButtonWithDriverFullName(vehiclesDriversInfoPage.getPniFullNameFromAutoApplicant(applicant));
        vehiclesDriversInfoPage.validateDriverSafetyCheckBoxIsNotPresent(softAssert);

        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=26"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, ID, IL, MN, NM, OH, OK, TN, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void validateMatureDriverOrDefensiveDriverDiscountBDQ(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        updateVehicleCountToOne(applicant);
        randomizeApplicantPersonalData(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setCompletedDriversSafetyCourse(true);
        setRandomAgeForApplicantToSafetyCourse(applicant, true);
        // OK state does not have age limit for mature driver discount

        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();

        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        if (heresWhatWeFoundPage.isOnHeresWhatWeFoundPage()) {
            vehiclesDriversInfoPage.selectAndEditDefaultAdpfDrivers(Collections.emptyList());
        } else {
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        }

        // check mature driver discount is present on quote summary page
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        vehiclesDriversInfoPage.validateMatureDriverDiscountPresenceBW(softAssert, applicant);

        // check mature driver discount is present on consolidated payment page
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        if (bwPaymentSummaryPage.isOnBwPaymentSummaryPage()) {
            quoteSummaryAutoPage.validateMatureDriverDiscountPresenceBW(softAssert, applicant);
        }
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=26"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, IN, MO, VA})},
            dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void validateMatureDefensiveDriverDiscountNotPresentBDQ(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        updateVehicleCountToOne(applicant);
        applicant.setCompletedDriversSafetyCourse(false);
        setRandomAgeForApplicantToSafetyCourse(applicant, true);

        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);

        if (heresWhatWeFoundPage.isOnHeresWhatWeFoundPage()) {
            vehiclesDriversInfoPage.selectAndEditDefaultAdpfDrivers(Collections.emptyList());
        } else {
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        }
        // check snackbar message on adding and removing safety course
        vehiclesDriversInfoPage.clickEditButtonWithDriverFullName(vehiclesDriversInfoPage.getPniFullNameFromAutoApplicant(applicant));
        vehiclesDriversInfoPage.validateDriverSafetyCheckBoxIsNotPresent(softAssert);

        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70", "72"})}, groups = {FFQ_ONEUI})
    public void validateNewlyAddedVehicleGotMergedWithExistingVehicleHavingSameVin(ADPFApplicant applicant) throws Exception {
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        boolean isStreamlinedState = vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        fsa.assertTrue(heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "user is supposed to be on Here's What We Found page");
        int numberOfVehiclesBeforeAddingVehicleWithSameVin = isStreamlinedState ? vehiclesDriversInfoPage.getEleCount(vehiclesDriversInfoPage.foundVehicles, 5) : whoShouldWeInsurePage.getEleCount(whoShouldWeInsurePage.lblVehiclesList, 5);
        String vin = heresWhatWeFoundPage.getFullVinOfVehicleUsingQuoteNumberAndMaskedVin();
        if (isStreamlinedState) {
            vehiclesDriversInfoPage.addAnotherVehicleUsingVin(vin);
        } else {
            whoShouldWeInsurePage.addAnotherVehicleUsingVin(vin);
        }
        String expectedSnackbarSuccessMessage = isStreamlinedState ? "vehicle added" : "vehicle has been added";
        fsa.assertTrue(heresWhatWeFoundPage.isVehicleAddedSuccessfully(expectedSnackbarSuccessMessage, isStreamlinedState), "Vehicle added successfully message was supposed to be displayed");
        int numberOfVehiclesAfterAddingVehicleWithSameVin = isStreamlinedState ? vehiclesDriversInfoPage.getEleCount(vehiclesDriversInfoPage.foundVehicles, 5) : whoShouldWeInsurePage.getEleCount(whoShouldWeInsurePage.lblVehiclesList, 5);
        fsa.assertNotEquals(numberOfVehiclesAfterAddingVehicleWithSameVin, 0, "Vehicles are supposed to be available");
        fsa.assertEquals(numberOfVehiclesAfterAddingVehicleWithSameVin, numberOfVehiclesBeforeAddingVehicleWithSameVin, "Vehicle with same VIN should merge, not get added as new vehicle");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70", "72"})}, groups = {FFQ_ONEUI})
    public void validateVehicleWithDifferentVinGotAddedAndNotMerged(ADPFApplicant applicant) throws Exception {
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        boolean isStreamlinedState = vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        fsa.assertTrue(heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "user is supposed to be on Here's What We Found page");
        int numberOfVehiclesBeforeAddingVehicleWithDifferentVin = isStreamlinedState ? vehiclesDriversInfoPage.getEleCount(vehiclesDriversInfoPage.foundVehicles, 5) : whoShouldWeInsurePage.getEleCount(whoShouldWeInsurePage.lblVehiclesList, 5);
        String vin = heresWhatWeFoundPage.getRandomVinNumber(3);
        if (isStreamlinedState) {
            vehiclesDriversInfoPage.addAnotherVehicleUsingVin(vin);
        } else {
            whoShouldWeInsurePage.addAnotherVehicleUsingVin(vin);
        }
        String expectedSnackbarSuccessMessage = isStreamlinedState ? "vehicle added" : "vehicle has been added";
        fsa.assertTrue(heresWhatWeFoundPage.isVehicleAddedSuccessfully(expectedSnackbarSuccessMessage, isStreamlinedState), "Vehicle added successfully message was supposed to be displayed");
        int numberOfVehiclesAfterAddingVehicleWithDifferentVin = isStreamlinedState ? vehiclesDriversInfoPage.getEleCount(vehiclesDriversInfoPage.foundVehicles, 5) : whoShouldWeInsurePage.getEleCount(whoShouldWeInsurePage.lblVehiclesList, 5);
        fsa.assertNotEquals(numberOfVehiclesAfterAddingVehicleWithDifferentVin, 0, "Vehicles are supposed to be available");
        fsa.assertEquals(numberOfVehiclesAfterAddingVehicleWithDifferentVin, numberOfVehiclesBeforeAddingVehicleWithDifferentVin + 1, "Vehicle with different VIN should not merge, should get added as new vehicle");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.INCOMPLETE_DRIVERS_AND_VEHICLES)}, groups = {FFQ_ONEUI})
    public void validateVehicleWithPartialInfoGetsUpdatedAndCheckboxGetsCheckedWhenWeAddAnotherVehicleWithSameVin(ADPFApplicant applicant) throws Exception {
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        boolean isStreamlinedState = vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        fsa.assertTrue(heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "user is supposed to be on Here's What We Found page");
        int numberOfVehiclesBeforeAddingVehicleWithSameVin = isStreamlinedState ? vehiclesDriversInfoPage.getEleCount(vehiclesDriversInfoPage.foundVehicles, 5) : whoShouldWeInsurePage.getEleCount(whoShouldWeInsurePage.lblVehiclesList, 5);
        String vin = heresWhatWeFoundPage.getFullVinOfVehicleUsingQuoteNumberAndMaskedVin();
        int uncheckedVehiclesCountBeforeAddingVehicleWithSameVin = isStreamlinedState ? vehiclesDriversInfoPage.uncheckedVehiclesCheckboxes.size() : heresWhatWeFoundPage.getNumberOfUncheckedVehicles();
        int checkedVehiclesCountBeforeAddingVehicleWithSameVin = isStreamlinedState ? vehiclesDriversInfoPage.selectedVehiclesCheckboxes.size() : heresWhatWeFoundPage.getNumberOfCheckedVehicles();
        if (isStreamlinedState) {
            vehiclesDriversInfoPage.addAnotherVehicleUsingVin(vin);
        } else {
            whoShouldWeInsurePage.addAnotherVehicleUsingVin(vin);
        }
        String expectedSnackbarSuccessMessage = isStreamlinedState ? "vehicle added" : "vehicle has been added";
        fsa.assertTrue(heresWhatWeFoundPage.isVehicleAddedSuccessfully(expectedSnackbarSuccessMessage, isStreamlinedState), "Vehicle added successfully message was supposed to be displayed");
        int numberOfVehiclesAfterAddingVehicleWithSameVin = isStreamlinedState ? vehiclesDriversInfoPage.getEleCount(vehiclesDriversInfoPage.foundVehicles, 5) : whoShouldWeInsurePage.getEleCount(whoShouldWeInsurePage.lblVehiclesList, 5);
        fsa.assertNotEquals(numberOfVehiclesAfterAddingVehicleWithSameVin, 0, "Vehicles are supposed to be available");
        fsa.assertEquals(numberOfVehiclesAfterAddingVehicleWithSameVin, numberOfVehiclesBeforeAddingVehicleWithSameVin, "Vehicle with same VIN should merge, not get added as new vehicle");
        int uncheckedVehiclesCountAfterAddingVehicleWithSameVin = isStreamlinedState ? vehiclesDriversInfoPage.uncheckedVehiclesCheckboxes.size() : heresWhatWeFoundPage.getNumberOfUncheckedVehicles();
        int checkedVehiclesCountAfterAddingVehicleWithSameVin = isStreamlinedState ? vehiclesDriversInfoPage.selectedVehiclesCheckboxes.size() : heresWhatWeFoundPage.getNumberOfCheckedVehicles();
        fsa.assertEquals(uncheckedVehiclesCountAfterAddingVehicleWithSameVin, uncheckedVehiclesCountBeforeAddingVehicleWithSameVin - 1, "Unchecked vehicles count should reduce by 1");
        fsa.assertEquals(checkedVehiclesCountAfterAddingVehicleWithSameVin, checkedVehiclesCountBeforeAddingVehicleWithSameVin + 1, "Checked vehicles count should increase by 1");
        if (isStreamlinedState) {
            vehiclesDriversInfoPage.editCheckedVehicleAndvalidateNoErrorDisplayed();
        } else {
            heresWhatWeFoundPage.editCheckedVehicleAndvalidateNoErrorDisplayed();
        }
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_0)}, groups = {FFQ_ONEUI})
    public void validateNewlyAddedDriverGotMergedAndNameGotUnmaskedWhenDriverWithSameDetailsAddedAgain(ADPFApplicant applicant) throws Exception {
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        boolean isStreamlinedState = vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        fsa.assertTrue(heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "user is supposed to be on Here's What We Found page");
        int numberOfDriversBeforeAddingDriverWithSameDetails = isStreamlinedState ? vehiclesDriversInfoPage.getFoundDriversCount() : whoShouldWeInsurePage.getDriversCount();
        Map<String, String> driverDetails = heresWhatWeFoundPage.getDriverDetailsUsingQuoteNumberMaskedFirstNameAndMaskedDOB();
        if (isStreamlinedState) {
            vehiclesDriversInfoPage.addAnotherDriverUsingRetrievedDriverDetails(driverDetails);
        } else {
            whoShouldWeInsurePage.addAnotherDriverUsingRetrievedDriverDetails(driverDetails);
        }
        String expectedSnackbarSuccessMessage = isStreamlinedState ? "driver added" : "driver has been added";
        fsa.assertTrue(heresWhatWeFoundPage.isSnackBarMessageDisplayed(expectedSnackbarSuccessMessage), "Driver added successfully message was supposed to be displayed");
        int numberOfDriversAfterAddingDriverWithSameDetails = isStreamlinedState ? vehiclesDriversInfoPage.getFoundDriversCount() : whoShouldWeInsurePage.getDriversCount();
        fsa.assertNotEquals(numberOfDriversAfterAddingDriverWithSameDetails, 0, "Drivers are supposed to be available");
        fsa.assertEquals(numberOfDriversAfterAddingDriverWithSameDetails, numberOfDriversBeforeAddingDriverWithSameDetails, "Driver with same details should merge, not get added as new driver");
        fsa.assertTrue(heresWhatWeFoundPage.isDriverFirstNameUnmasked(driverDetails), "Driver's full name should be visible without any masking");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_0)}, groups = {FFQ_ONEUI})
    public void validateNewDriverGotAddedWithExistingDriverDetailsAndDifferentDOB(ADPFApplicant applicant) throws Exception {
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        boolean isStreamlinedState = vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        fsa.assertTrue(heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "user is supposed to be on Here's What We Found page");
        int numberOfDriversBeforeAddingDriverWithSameDetailsAndDifferentDOB = isStreamlinedState ? vehiclesDriversInfoPage.getFoundDriversCount() : whoShouldWeInsurePage.getDriversCount();
        Map<String, String> driverDetails = heresWhatWeFoundPage.getDriverDetailsUsingQuoteNumberMaskedFirstNameAndMaskedDOB();
        String[] dobParts = driverDetails.get("dob").split("/");
        String updatedDOB = dobParts[0] + "/" + dobParts[1] + "/" + String.valueOf(Integer.parseInt(dobParts[2]) + 1);
        driverDetails.put("dob", updatedDOB);
        if (isStreamlinedState) {
            vehiclesDriversInfoPage.addAnotherDriverUsingRetrievedDriverDetails(driverDetails);
        } else {
            whoShouldWeInsurePage.addAnotherDriverUsingRetrievedDriverDetails(driverDetails);
        }
        String expectedSnackbarSuccessMessage = isStreamlinedState ? "driver added" : "driver has been added";
        fsa.assertTrue(heresWhatWeFoundPage.isSnackBarMessageDisplayed(expectedSnackbarSuccessMessage), "Driver added successfully message was supposed to be displayed");
        int numberOfDriversAfterAddingDriverWithSameDetailsAndDifferentDOB = isStreamlinedState ? vehiclesDriversInfoPage.getFoundDriversCount() : whoShouldWeInsurePage.getDriversCount();
        fsa.assertNotEquals(numberOfDriversAfterAddingDriverWithSameDetailsAndDifferentDOB, 0, "Drivers are supposed to be available");
        fsa.assertEquals(numberOfDriversAfterAddingDriverWithSameDetailsAndDifferentDOB, numberOfDriversBeforeAddingDriverWithSameDetailsAndDifferentDOB + 1, "Driver with same details and different DOB should not merge, should get added as new driver");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"70", "72"})}, groups = {FFQ_ONEUI})
    public void validateErrorWhenAddingVehicleWithSameVinSecondTime(ADPFApplicant applicant) throws Exception {
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        boolean isStreamlinedState = vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        fsa.assertTrue(heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "user is supposed to be on Here's What We Found page");
        int numberOfVehiclesBeforeAddingVehicleWithSameVin = isStreamlinedState ? vehiclesDriversInfoPage.getEleCount(vehiclesDriversInfoPage.foundVehicles, 5) : whoShouldWeInsurePage.getEleCount(whoShouldWeInsurePage.lblVehiclesList, 5);
        String vin = heresWhatWeFoundPage.getFullVinOfVehicleUsingQuoteNumberAndMaskedVin();
        if (isStreamlinedState) {
            vehiclesDriversInfoPage.addAnotherVehicleUsingVin(vin);
        } else {
            whoShouldWeInsurePage.addAnotherVehicleUsingVin(vin);
        }
        String expectedSnackbarSuccessMessage = isStreamlinedState ? "vehicle added" : "vehicle has been added";
        fsa.assertTrue(heresWhatWeFoundPage.isVehicleAddedSuccessfully(expectedSnackbarSuccessMessage, isStreamlinedState), "Vehicle added successfully message was supposed to be displayed");
        if (isStreamlinedState) {
            vehiclesDriversInfoPage.attemptAddingVehicleWithDuplicateVin(vin, fsa);
        } else {
            whoShouldWeInsurePage.addAnotherVehicleUsingVin(vin);
        }
        fsa.assertTrue(whoShouldWeInsurePage.isElementDisplayed(whoShouldWeInsurePage.fieldErrorMessage, 5), "VIN duplicate error message is supposed to be displayed");
        fsa.assertEquals(whoShouldWeInsurePage.getTextFromElement(whoShouldWeInsurePage.fieldErrorMessage), "This VIN is already added for a vehicle.");
        heresWhatWeFoundPage.clickCloseIcon();
        int numberOfVehiclesAfterAddingVehicleWithSameVin = isStreamlinedState ? vehiclesDriversInfoPage.getEleCount(vehiclesDriversInfoPage.foundVehicles, 5) : whoShouldWeInsurePage.getEleCount(whoShouldWeInsurePage.lblVehiclesList, 5);
        fsa.assertNotEquals(numberOfVehiclesAfterAddingVehicleWithSameVin, 0, "Vehicles are supposed to be available");
        fsa.assertEquals(numberOfVehiclesAfterAddingVehicleWithSameVin, numberOfVehiclesBeforeAddingVehicleWithSameVin, "Vehicle with same VIN should not get added as new vehicle");
        fsa.assertAll();
    }

    // F96505/US1054123 - On first attempt of adding driver with same details, driver name gets unmasked and on second attempt we should get duplicate driver error
    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_0)}, groups = {FFQ_ONEUI})
    public void validateErrorWhenAddingDriverWithSameDetailsSecondTime(ADPFApplicant applicant) throws Exception {
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        boolean isStreamlinedState = vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        fsa.assertTrue(heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "user is supposed to be on Here's What We Found page");
        Map<String, String> driverDetails = heresWhatWeFoundPage.getDriverDetailsUsingQuoteNumberMaskedFirstNameAndMaskedDOB();
        String expectedSnackbarSuccessMessage = isStreamlinedState ? "driver added" : "driver has been added";

        if (isStreamlinedState) {
            vehiclesDriversInfoPage.addAnotherDriverUsingRetrievedDriverDetails(driverDetails);
        } else {
            whoShouldWeInsurePage.addAnotherDriverUsingRetrievedDriverDetails(driverDetails);
        }

        fsa.assertTrue(heresWhatWeFoundPage.isSnackBarMessageDisplayed(expectedSnackbarSuccessMessage), "Driver added successfully message was supposed to be displayed");
        if (isStreamlinedState) {
            vehiclesDriversInfoPage.fillOutDriverDetailsUsingRetrievedDetails(driverDetails);
        } else {
            whoShouldWeInsurePage.fillOutDriverDetailsUsingRetrievedDetails(driverDetails);
        }
        fsa.assertTrue(heresWhatWeFoundPage.isDuplicateDriverErrorMessageDisplayed());
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=26"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, ID, IL, MN, NM, OH, OK, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateGaragingAddressFunctionalityAndValidateValueAfterRetrieval(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();

        updateVehicleCountToOne(applicant);
        randomizeApplicantPersonalData(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        Vehicle vehicle = applicant.getVehicles().get(0);
        vehicle.setParkInResidentAddress(false);

        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();

        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        if (heresWhatWeFoundPage.isOnHeresWhatWeFoundPage()) {
            vehiclesDriversInfoPage.selectAndEditDefaultAdpfDrivers(Collections.emptyList());
        } else {
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        }

        vehiclesDriversInfoPage.validateGaragingAddressFieldDisplayed(vehicle, applicant.getStateCode(), softAssert);
        vehiclesDriversInfoPage.clickParkedAtPrimaryAddressRadioButton();
        vehiclesDriversInfoPage.selectGarageAddress(vehicle);
        vehiclesDriversInfoPage.clickVehicleSaveChangesButton();

        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");

        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, applicant.getEmail());
        quoteSummaryAutoPage.clickOnQuoteUpdateDialogOkIfNeeded();
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        testStepAssert(vehiclesDriversInfoPage.isOnWhoShouldWeInsurePage(), "User is on the Who Should we Insure page after clicking on the Enter navigation bar from Quote Summary page");
        vehiclesDriversInfoPage.clickEditVehicleButton(vehicle);
        vehiclesDriversInfoPage.validateGaragingAddressFieldValueAfterRetrieval(softAssert);
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {FFQ_ONEUI})
    public void validateIfTheYearDropdownDisplays2027ForAllStates(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        randomizeApplicantPersonalData(applicant);
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        if (vehiclesDriversInfoPage.isOnWhoShouldWeInsurePage()) {
            whoShouldWeInsurePage.clickOnAddVehicleAndDriversButton();
            whoShouldWeInsurePage.addVehicleDetailsWith2027YMM(applicant, fsa);
        } else if (vehiclesDriversInfoPage.isOnHeresWhatWeFoundPage()) {
            heresWhatWeFoundPage.addVehicleDetailsWith2027YMM(applicant, fsa);
        } else {
            testStep("Unexpected navigation: expected to be on Who Should We Insure page or Here's What We Found page, but was on neither.");
        }
        fsa.assertAll();
    }

    private static void updateVehicleCountToOne(AutoApplicant applicant) {
        Vehicle firstVehicle = applicant.getVehicles().get(0);
        firstVehicle.setParkInResidentAddress(true);
        applicant.setVehicles(new ArrayList<>(Collections.singletonList(firstVehicle)));
    }

    private void setRandomAgeForApplicantToSafetyCourse(AutoApplicant applicant, boolean isBW) {
        String stateCode = applicant.getStateCode();
        if (stateCode.equals(OK)) {
            List<Integer> randomIntegers = Arrays.asList(18, 25, 40, 55, 65, 85);
            applicant.setAge(randomIntegers.get(new Random().nextInt(randomIntegers.size())));
        } else if (stateCode.equals(OH)) {
            if (isBW) {
                applicant.setAge(61);
            } else {
                applicant.setAge(56);
            }

        } else if (stateCode.equals(NM)) {
            if (isBW) {
                applicant.setAge(56);
            } else {
                applicant.setAge(51);
            }
        } else {
            applicant.setAge(RandomUtils.nextInt(56, 70));
        }
        applicant.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(applicant.getAge()));
    }

    /**
     * Ace Auto and Bind Sheet Row-613
     * Create auto quote for MVP state with VE project code is ON (Validate for ADPF data) & navigate till vehicle driver info screen.
     * Add vehicle using YMM model & add PNI
     * Navigate to signal screen
     * click on browser back button
     * Edit vehicle update YMM & verify updates are reflecting correctly in vehicle summary
     * Again Edit vehicle add VIN & save vehicle
     * verify newly added VIN  reflecting correctly in vehicle summary
     * @param applicant
     * @throws Exception
     */

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MN, WA, IL, OK, VA, AZ, MO, OH, TN, NM, ID, IN, AR, CO, MI, OR})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void testUpdateNewYMMAndVINAndVehicleCardReflectionWithUpdatedYMMDetails(AutoApplicant applicant) throws Exception {

        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicant.getVehicles().forEach(each -> each.setUseVIN(false));
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        vehiclesDriversInfoPage.clickContinueButton();
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        boolean isStreamlineExpected = vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        if (isStreamlineExpected) {
            driverReviewPage.clickContinueButton();

        } else {
            VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
            testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on the vehicle review page", true);
            vehicleReviewPage.clickContinueButton();
        }
        SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
        if (signalPageOneUI.isOnSignalPage()) {
            signalPageOneUI.processSignalPage(true);
            Log.info("User has chosen to add Signal to the policy");
            aceAutoNavigationHelper.navigateBackToWhoShouldWeInsurePage();
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        if (contactInfoAutoPage.isOnContactInfoAutoPage()) {
            aceAutoNavigationHelper.navigateBackToWhoShouldWeInsurePage();
        }
        testStepAssert(vehiclesDriversInfoPage.isOnWhoShouldWeInsurePage(), "User is on the Who Should We Insure page after navigating back from Signal or Contact Info page");
        Vehicle firstVehicle = applicant.getVehicles().get(0);
        vehiclesDriversInfoPage.updateVehicleYMMWhichWasAddedByVINAndValidateVehicleCard(firstVehicle, fsa);
        vehiclesDriversInfoPage.updateVehicleVinWhichWasAddedByYMMAndValidateVehicleCard(firstVehicle, fsa);
        fsa.assertAll();
    }

    /**
     * Ace Auto and Bind Sheet Row-616
     * Create auto quote for MVP state with VE project code is ON & navigate till vehicle driver info screen.
     * Add 2 vehicle using YMM & VIN . Also have parked at as residence for V1 & other location for V2
     * Add PNI & add 2 additional drivers one as minor & other one as major
     * Select all possible checkbox for all drivers
     * Save drivers & proceed to contact info
     * Navigate back using browser back button & check all selections are retained
     * Proceed & rate the quote
     * Retrieve the quote & make sure all applied discounts are retained
     * Navigate to vehicle driver info & check if all selections are retained
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MN, WA, IL, OK, VA, AZ, MO, OH, TN, NM, ID, IN, AR, CO, MI, OR})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void createQuoteWith2VehiclesAnd3DriversAndValidateDiscountsAfterRetrievalOfRatedQuote(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        while (applicant.getVehicles().size() < 2) {
            applicant.getVehicles().add(applicant.getVehicles().get(0).clone());
        }
        applicant.setVehicles(new ArrayList<>(applicant.getVehicles().subList(0, 2)));
        Vehicle vehicle1 = applicant.getVehicles().get(0); // YMM + parked at residence
        vehicle1.setUseVIN(false);
        vehicle1.setParkInResidentAddress(true);
        Vehicle v2 = applicant.getVehicles().get(1); // VIN + parked at other location
        v2.setUseVIN(true);
        v2.setParkInResidentAddress(false);
        while (applicant.getAdditionalDrivers().size() < 2) {
            applicant.getAdditionalDrivers().add(getRandomAdditionalDriver());
        }
        applicant.setAdditionalDrivers(new ArrayList<>(applicant.getAdditionalDrivers().subList(0, 2)));

        SqlAdditionalDriver minor = applicant.getAdditionalDrivers().get(0);
        minor.setAge(16);//minor driver
        minor.setDateOfBirth(calculateDateOfBirthFromAge(16));
        SqlAdditionalDriver major = applicant.getAdditionalDrivers().get(1);
        major.setAge(30);//major driver
        major.setDateOfBirth(calculateDateOfBirthFromAge(30));
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
        vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
        //validateCheckboxesForAllDrivers
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(fsa, applicant);
        vehiclesDriversInfoPage.clickContinueButton();
        //Save drivers & proceed to contact info and navigate back to check all section retained
        SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
        if (signalPageOneUI.isOnSignalPage()) {
            signalPageOneUI.processSignalPage(true);
            Log.info("User has chosen to add Signal to the policy");
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        if (contactInfoAutoPage.isOnContactInfoAutoPage()) {
            aceAutoNavigationHelper.navigateBackToWhoShouldWeInsurePage();
        }
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(fsa, applicant);
        //proceed and rate the quote
        vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        QuoteSummaryAutoPage quoteSummaryAutoPage=new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
        List<String> discountsBeforeRetrieve = quoteSummaryAutoPage.getDisplayedDiscounts();
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, applicant.getEmail());
        List<String> discountsAfterRetrieve = quoteSummaryAutoPage.getDisplayedDiscounts();
        //validate discounts after retrieval
        fsa.assertEquals(discountsBeforeRetrieve,discountsAfterRetrieve,"Discounts check");
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        testStepAssert(vehiclesDriversInfoPage.isOnWhoShouldWeInsurePage(), "User is on the Who Should we Insure page after clicking on the Enter navigation bar from Quote Summary page");
        //validateCheckboxesForAllDrivers after Navigation
        vehiclesDriversInfoPage.validateCheckboxesForAllDrivers(fsa, applicant);
        fsa.assertAll();


    }

    }