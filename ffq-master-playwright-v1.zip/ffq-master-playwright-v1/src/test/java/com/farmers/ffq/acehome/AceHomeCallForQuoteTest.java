package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCAddressBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCCallForQuotePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;


/**
 * Farmers Fast Quote (FFQ) - Call for Quote to FFQ Integration Scenario.
 */
public class AceHomeCallForQuoteTest extends AutomationFramework {

	private static final String GROUP = "BANK OF AMERICA";

	// Including some states which are applicable for Employer/group affinity discount.
	@Skip // Skipping the test cases as EG project code is enabled for most of the states
	@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, AL, GA, IL, OH, VA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ADDRESS_PAGE})
	public void testCallForQuoteToAceReviewQuoteHomeLob(ApplicantAceHome applicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		applicant.setAgentId(null);
		AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
		AceHRCAddressBasePage aceHRCAddressBasePage = navigator.navigateToAceHomeAddressPage(applicant, LOB_HOME, HOME);
		aceHRCAddressBasePage.enterAddress(applicant);
		aceHRCAddressBasePage.enterAvailableFields(applicant);
		aceHRCAddressBasePage.acceptCookies();
		// Employer affinity question is no longer available for AZ and IL states from R1 onwards.
		if (List.of(AZ, IL).contains(applicant.getStateCode())) {
			fsa.assertFalse(aceHRCAddressBasePage.isCheckYourEligibilityLinkDisplayed(fsa));
		} else {
			Assert.assertTrue(aceHRCAddressBasePage.isCheckYourEligibilityLinkDisplayed(fsa), "Check your eligibility link is not displayed for employer affinity.");
			aceHRCAddressBasePage.setEmployerGroup(GROUP);
			fsa.assertEquals(aceHRCAddressBasePage.getSelectedEmployerName(), GROUP, "Employer group name is not displayed.");
			aceHRCAddressBasePage.clickContinueButton();
			aceHRCAddressBasePage.waitForSpinnerToBeGone();
			new AceHRCCallForQuotePage().validateCallForQuote(applicant, GROUP, fsa);

			AceHRCAddressBasePage addressPage = new AceHRCAddressBasePage();
			Assert.assertTrue(addressPage.isOnAddressPage(true), "Did not Reach to Address page when navigating back from Call for Quote page.");
			fsa.assertFalse(addressPage.isCheckYourEligibilityLinkDisplayed(fsa), "Back to Address page - No Employer question anymore.");
			navigator.setResumeFromPage(AceHRCBasePage.ADDRESS_PAGE);
			navigator.navigateToAceHomeReviewQuotePage(applicant, LOB_HOME, HOME);
		}
		fsa.assertAll("Validate Call for Quote to FFQ integration - Home Lob");
	}
}