package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.HeresWhatWeFoundPage;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import com.farmers.ffq.auto.pages.VehiclesDriversInfoPage;
import com.farmers.ffq.auto.pages.bindpages.ConsolidatedPaymentPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.Vehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AutoDiscountTests extends BaseTest {


    /**
     * Validate when we select vehicle age less than 5years we should see disscount applied in  PAYPLAN and rate screen (make sure you select vehicle age must be less than 5 years JTJGKCEZXN5004436)
     * Scneario 431 from auto quote and bind sheet
     *
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {NE, NM, UT, VA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DISCOUNTS})
    public void validateAutoDiscountForVehicleAgeLessThan5Years(AutoApplicant applicant) throws Exception {

        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");

        //navigate to quote summary page
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);

        if (aceAutoNavigationHelper.isOnBristolWest()) {
            Log.info("Bristol West is not supporting this test case, skipping the test");
            return;
        }

        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();

        if (!heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            heresWhatWeFoundPage.uncheckAllCheckedVehicleCheckboxes();
            heresWhatWeFoundPage.addRandomNewVehicle("JTJGKCEZXN5004436");
            heresWhatWeFoundPage.clickOnEditButtonOfPNIDriver();
            heresWhatWeFoundPage.addMainDriver(applicant);
        } else {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.uncheckAllCheckedVehicleCheckboxes();
            vehiclesDriversInfoPage.addAnotherVehicleUsingVin("JTJGKCEZXN5004436");
            vehiclesDriversInfoPage.clickOnAddVehicleButton();
            vehiclesDriversInfoPage.clickDriverCheckbox(applicant.getFirstName() + SPACE + applicant.getLastName());
            vehiclesDriversInfoPage.addApplicantDetails(applicant);
        }

        QuoteSummaryAutoPage quoteSummaryAutoPage = heresWhatWeFoundPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");

        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        List<String> quoteSummaryPageDisplayedDiscounts = quoteSummaryAutoPage.getDisplayedDiscounts();
        Log.info("Discounts displayed on quote summary page: " + quoteSummaryPageDisplayedDiscounts);
        String expectedDiscountName = "New car";

        // validate the presence of discount on quote summary page based on vehicle age less than 5 years
        farmersSoftAssert.assertTrue(quoteSummaryPageDisplayedDiscounts.contains(expectedDiscountName), "Check if '" + expectedDiscountName + "' is displayed as expected based on vehicle age less than 5 years");

        // navigate to payment page
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        testStepAssert(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User is on the consolidated payment page");
        List<String> consolidatedPaymentPageDiscountNames = consolidatedPaymentPage.getDiscountNames();
        Log.info("Discounts displayed on consolidated payment page: " + consolidatedPaymentPageDiscountNames);
        //validate the presence of discount on payment page based on vehicle age less than 5 years
        farmersSoftAssert.assertTrue(consolidatedPaymentPageDiscountNames.contains(expectedDiscountName), "Check if '" + expectedDiscountName + "' is displayed on payment page as expected based on vehicle age less than 5 years");
        farmersSoftAssert.assertAll();


    }

}
