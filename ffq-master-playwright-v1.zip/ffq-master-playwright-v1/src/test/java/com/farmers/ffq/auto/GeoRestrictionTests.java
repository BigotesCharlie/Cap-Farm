package com.farmers.ffq.auto;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bw.BwPaymentSummaryPage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AgentFlowData;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.Vehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.RandomUtils;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class GeoRestrictionTests extends BaseTest {

    private final String GEO_RESTRICTION_TEST = "geoRestrictionTest";


    /**
     * TC1953461, TC1953462, TC1953464,TC1941181, TC1941182, TC1941183
     * TC1929294, TC1929295,TC1929296, TC1929297
     *
     * @throws Exception
     */
    @Test(groups = {FFQ_ONEUI, GEO_RESTRICTION_TEST})
    public void validateUserGetFWSPage_NonAWS() throws Exception {
        Map<String, String> stateZipCode = new HashMap<>();
        stateZipCode.put(SC, "29154");
        stateZipCode.put(HI, "96748");


        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        AutoCallForQuotePage autoCallForQuotePage = new AutoCallForQuotePage();

        for (Map.Entry<String, String> entry : stateZipCode.entrySet()) {
            if (autoCallForQuotePage.isUseMobileViewEnabled()) {
                autoCallForQuotePage.setBrowserDimensionToMobileBreakPoint();
            }
            String state = entry.getKey();
            String zipCode = entry.getValue();
            new LandingPage(autoCallForQuotePage.isUseMobileViewEnabled()).enterLandingPageData(LOB_AUTO, zipCode);
            farmersSoftAssert.assertTrue(autoCallForQuotePage.isOnCallForQuotePage(), String.format("User is on the FWS page successful for %s with zipcode %s", state, zipCode));
            autoCallForQuotePage.validateCallForAQuotePage(farmersSoftAssert);
            Log.info(String.format("Testing for %s and zipcode: %s", state, zipCode), true);
        }
        farmersSoftAssert.assertAll();
    }


    /**
     * TC1953456, TC1953457, TC1953458, TC1941176,TC1941177
     *
     * @throws Exception
     */
    @Test(groups = {FFQ_ONEUI, GEO_RESTRICTION_TEST})
    public void validateUserGetFWSPage_AWS_Without_AOR() throws Exception {
        Map<String, String> stateAndUrl = new HashMap<>();
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if(aceAutoNavigationHelper.isUseMobileViewEnabled()) {
            aceAutoNavigationHelper.setBrowserDimensionToMobileBreakPoint();
        }
        stateAndUrl.put(SC, Property.getUri() + "?Agent_Code=&State_Code=&Source_Indicator=FC&lob=Auto&Zip_Code=29414&_gl=1*2nrun3*_ga*OTYzODY3MjAwLjE3NTg2OTg0NDc.*_ga_6H7TLKVS38*czE3NTg2OTg0NDYkbzEkZzEkdDE3NTg3MDIxMDckajYwJGwwJGgw");
        stateAndUrl.put(HI, Property.getUri() + "?Agent_Code=&State_Code=&Source_Indicator=FC&lob=Auto&Zip_Code=96748&_gl=1*9ome7u*_ga*MTY5NTgwMDkwOS4xNzU4MTgzNDYx*_ga_6H7TLKVS38*czE3NTgxODM0NTkkbzEkZzEkdDE3NTgxODQ0ODEkajYwJGwwJGgw&addressline=77868");

        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        AutoCallForQuotePage autoCallForQuotePage = new AutoCallForQuotePage();

        for (Map.Entry<String, String> entry : stateAndUrl.entrySet()) {
            if (autoCallForQuotePage.isUseMobileViewEnabled()) {
                autoCallForQuotePage.setBrowserDimensionToMobileBreakPoint();
            }
            String state = entry.getKey();
            String url = entry.getValue();
            driver().get(url);
            farmersSoftAssert.assertTrue(autoCallForQuotePage.isOnCallForQuotePage(), String.format("User is on the FWS page successful for %s with url %s", state, url));
            autoCallForQuotePage.validateCallForAQuotePage(farmersSoftAssert);
            Log.info(String.format("Testing for %s and url: %s", state, url), true);
        }
        farmersSoftAssert.assertAll();
    }

    /**
     * TC1953459,TC1941179
     *
     * @throws Exception
     */
    @Skip// Behaviour has changed
    @Test(groups = {FFQ_ONEUI, GEO_RESTRICTION_TEST})
    public void validateUserLandsOnCallOnlyLandingPage_NegativeTest() throws Exception {
        Map<String, String> stateAndUrl = new HashMap<>();
        stateAndUrl.put(AK, Property.getUri() + "?Source_Indicator=AP&Agent_Code=88284N%246724CX%2496055R&State_Code=AK&Lob=Auto&Zip_Code=99712&_gl=1*1jqvkme*_ga*MTY5NTgwMDkwOS4xNzU4MTgzNDYx*_ga_6H7TLKVS38*czE3NTgxODM0NTkkbzEkZzAkdDE3NTgxODM0NjAkajU5JGwwJGgw&addressline=9");
        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        AutoCallForQuotePage autoCallForQuotePage = new AutoCallForQuotePage();
        for (Map.Entry<String, String> entry : stateAndUrl.entrySet()) {
            if (autoCallForQuotePage.isUseMobileViewEnabled()) {
                autoCallForQuotePage.setBrowserDimensionToMobileBreakPoint();
            }
            String state = entry.getKey();
            String url = entry.getValue();
            driver().get(url);
            farmersSoftAssert.assertTrue(autoCallForQuotePage.isOnCallForQuotePage(), String.format("User is on the FWS page successful for %s with url %s", state, url));
            autoCallForQuotePage.validateCallForAQuotePage(farmersSoftAssert);
            Log.info(String.format("Testing for %s and url: %s", state, url), true);
        }
        farmersSoftAssert.assertAll();
    }

    /**
     * TC1953460, TC1941180
     *
     * @throws Exception
     */
    @Test(groups = {FFQ_ONEUI, GEO_RESTRICTION_TEST})
    public void validateUserGetsAceFlowWithAWS_AOR_NegativeTesting_AZ_State() throws Exception {
        Map<String, String> stateAndUrl = new HashMap<>();
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();

        if(aceAutoNavigationHelper.isUseMobileViewEnabled()) {
            aceAutoNavigationHelper.setBrowserDimensionToMobileBreakPoint();
        }

        stateAndUrl.put(AZ, Property.getUri() + "?Source_Indicator=AP&Agent_Code=88284N%246724CX%2496055R&State_Code=AZ&Lob=Auto&Zip_Code=86001&_gl=1*12tnf4p*_ga*MTY5NTgwMDkwOS4xNzU4MTgzNDYx*_ga_6H7TLKVS38*czE3NTgxODM0NTkkbzEkZzEkdDE3NTgxODUyODIkajM4JGwwJGgw&addressline=86001");
        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        for (Map.Entry<String, String> entry : stateAndUrl.entrySet()) {
            String state = entry.getKey();
            String url = entry.getValue();
            Log.info(String.format("Testing for %s and url: %s", state, url));
            driver().get(url);
            NameAndDobPage nameAndDobPage = new NameAndDobPage();
            farmersSoftAssert.assertTrue(nameAndDobPage.isOnNameAndDobPage(), "User is on the " + nameAndDobPage.getClass().getSimpleName());
            Log.info(String.format("Testing for %s and url: %s", state, url), true);
        }
        farmersSoftAssert.assertAll();
    }

    /**
     * TC1953449, TC1953450, TC1953451
     *
     * @throws Exception
     */
    @Skip // Functional Testing is pending
    @Test(groups = {FFQ_ONEUI, GEO_RESTRICTION_TEST})
    public void validateUserGetsAceFlow_AWS_AOR_Negative_Testing() throws Exception {
        List<String> statesToTest = new ArrayList<>(Arrays.asList(VT, WV, HI));
        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        AutoDataProviders autoDataProviders = new AutoDataProviders();
        List<AgentFlowData> listOfAgentFlowData = autoDataProviders.listOfAgentFlowData();
        for (String state : statesToTest) {
            AgentFlowData agentFlowData = listOfAgentFlowData.stream().filter(agentData -> agentData.getStateCode().equals(state)).collect(Collectors.toList()).get(0);
            String agentUri = String.format(Property.getUri() + "?Lob=A&Source_Indicator=AS&State_Code=%s&Agent_Code=%s&Zip_Code=%s", state, agentFlowData.getAgentOfRecords(), agentFlowData.getZipCode());
            AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
            if(aceAutoNavigationHelper.isUseMobileViewEnabled()) {
                aceAutoNavigationHelper.setBrowserDimensionToMobileBreakPoint();
            }

            driver().get(agentUri);
            NameAndDobPage nameAndDobPage = new NameAndDobPage();
            farmersSoftAssert.assertTrue(nameAndDobPage.isOnNameAndDobPage(), "User is on the " + nameAndDobPage.getClass().getSimpleName());
            Log.info(String.format("Testing for %s and url: %s", state, agentUri), true);
        }
        farmersSoftAssert.assertAll();
    }

    /**
     * TC1935661, TC1935663, TC1935664,TC1935665,TC1935666,TC1935674,TC1935675,TC1935676,TC1935677,TC1935678,TC1935679,TC1935680
     * TC1935746, TC1935749,TC1935751, TC1935752,TC1935755,TC1935756
     *
     * @throws Exception
     */


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {MA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, GEO_RESTRICTION_TEST})
    public void validateToBWModalToFgia_or_BWFlow(AutoApplicant applicant) throws Exception {
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        String zipCode = applicant.getZipCode();
        boolean acceptBwFlow = RandomUtils.nextBoolean();
        String stateCode = applicant.getStateCode();
        new LandingPage(continueWithBristolWestPage.isUseMobileViewEnabled()).enterLandingPageData(LOB_AUTO, zipCode);

        if (continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()) {
            farmersSoftAssert.assertTrue(continueWithBristolWestPage.isBristolWestAlternatePageDialogTitleCorrect(applicant.getStateCode()), "Correct content of BW dialog title");
            continueWithBristolWestPage.validatePageContentForFarmersToBwReBrandPage(farmersSoftAssert);
            continueWithBristolWestPage.validatePageSubheaderForFarmersToBwReBrandPage(farmersSoftAssert);
            continueWithBristolWestPage.validatePageCantOfferTextForFarmersToBwReBrandPage(farmersSoftAssert);
            continueWithBristolWestPage.validatePageGoodNewsTextForFarmersToBwReBrandPage(farmersSoftAssert);
            continueWithBristolWestPage.validatePageSoundsGoodTextForFarmersToBwReBrandPage(farmersSoftAssert);
            continueWithBristolWestPage.validatePageDisclosuresForFarmersToBwReBrandPage(farmersSoftAssert);
        } else {
            farmersSoftAssert.assertTrue(continueWithBristolWestPage.isContinueWithBristolWestDialogDisplayedForRebranding(), "User is on the Bw Switch page");
            farmersSoftAssert.assertTrue(continueWithBristolWestPage.isBristolWestAlternatePageDialogTitleCorrect(stateCode), "Correct content of BW dialog title");
            farmersSoftAssert.assertTrue(continueWithBristolWestPage.isBristolWestAlternatePageDialogTextContentCorrect(), "Correct content of BW dialog text");
            farmersSoftAssert.assertTrue(continueWithBristolWestPage.isBristolWestAlternatePageDialogDisclaimerCorrect(), "Correct content of BW dialog disclaimer");
            farmersSoftAssert.assertTrue(continueWithBristolWestPage.areBristolWestAlternatePageDialogButtonsCorrect(), "Correct content of BW dialog buttons");
        }
        continueWithBristolWestPage.continueWithBWPage(acceptBwFlow);
        if (acceptBwFlow) {
            applicant.setTestScenario("BW" + SPACE + applicant.getTestScenario());
            NameAndDobPage nameAndDobPage = new NameAndDobPage();
            testStepAssert(nameAndDobPage.isOnNameAndDobPage() && nameAndDobPage.isOnBristolWest(), "User is on the name and dob page");
            updateLastNameForBristolWest(applicant);
            Log.info("QuoteNumber: "  + nameAndDobPage.getSessionStorageAppStore().getData().getQuoteNumber());
            nameAndDobPage.filloutApplicantForm(applicant);
            AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
            testStepAssert(autoEnterAddressPage.isOnEnterAddressPage(), "User is on the address page");
            autoEnterAddressPage.fillOutAddressPage(applicant);
            HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
            WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
            // fetching random vin number for the flow as we have been getting your vehicle is already in our system error a lot :)
            for (int i = 0; i < applicant.getVehicles().size(); i++) {
                Vehicle vehicle = applicant.getVehicles().get(i);
                if (vehicle.isUseVIN()) {
                    if (applicant.getTestScenario().contains("BW")) {
                        vehicle.setVehicleVIN(heresWhatWeFoundPage.getRandomVinNumber(3));
                    } else if (applicant.getTestScenario().contains(HIGH_END_VEHICLE)) {
                        vehicle.setVehicleVIN("ZFF65MJA0C0012553");
                    } else if (applicant.getTestScenario().contains(NO_FAST_TRACK)) {
                        vehicle.setVehicleVIN("KNDJT2A63C7467015");
                    } else {
                        vehicle.setVehicleVIN(heresWhatWeFoundPage.getRandomVinNumber(5));
                    }
                }
            }

            if (whoShouldWeInsurePage.isOnWhoShouldWeInsurePageShort()) {
                if (applicant.getTestScenario().contains("BW")) {
                    applicant.getVehicles().forEach(each -> {
                        try {
                            each.setVehicleVIN(heresWhatWeFoundPage.getRandomVinNumber(3));
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    });
                }

                whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
                whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
                whoShouldWeInsurePage.enterEmailAndPhoneNumber(applicant);
            } else {
                String fullName = applicant.getFirstName() + SPACE + applicant.getLastName();
                if (heresWhatWeFoundPage.getListOfCheckedVehicles().isEmpty()) {
                    whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
                } else if (applicant.getStateCode().equals(CA)) {
                    heresWhatWeFoundPage.updateVinsForVehicles(autoEnterAddressPage.getRandomVinNumber(3));
                    sleep(1);
                } else if (applicant.getTestScenario().contains("BW")) {
                    heresWhatWeFoundPage.updateVinsForVehicles(autoEnterAddressPage.getRandomVinNumber(3));
                }
                heresWhatWeFoundPage.addADPFApplicant(Optional.of(applicant), fullName, applicant.getGender(), applicant.getDateOfBirth());
                heresWhatWeFoundPage.clickOnDoneAddingDriversButton();
                int vehicleCountFromDataProvider = applicant.getVehicles().size();
                if (vehicleCountFromDataProvider == 1) {
                    heresWhatWeFoundPage.uncheckVehiclesOnlyForOne();
                }
                List<PWElement> listOfCheckedVehicles = heresWhatWeFoundPage.getListOfCheckedVehicles();
                int numberOfElements = listOfCheckedVehicles.size();
                for (int i = 5; i < numberOfElements; i++) {
                    heresWhatWeFoundPage.setCheckboxTo(listOfCheckedVehicles.get(i), false);
                }
                heresWhatWeFoundPage.excludeDriversEqualOrLessThan15();
                if (heresWhatWeFoundPage.isOnHeresWhatWeFoundPage() && applicant.getTestScenario().contains(DIFFERENT_STATE_DL) || applicant.getTestScenario().contains(SUSPENDED_DL)) {
                    whoShouldWeInsurePage.clickAddAnotherDriverButton();
                    whoShouldWeInsurePage.enterAdditionalDriverData(applicant, applicant.getAdditionalDrivers().get(0));
                    whoShouldWeInsurePage.clickOnSaveButton();
                    whoShouldWeInsurePage.clickOnDoneAddingDriversButton();
                }
            }
            heresWhatWeFoundPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
            QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
            testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
            quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
            BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
            testStepAssert(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User is on the bw payment page");
            selectPaymentMethodFillOutDocusignAndAddPaymentMethod(PAY_IN_FULL);
        } else {
            FarmersGeneralInsuranceAgencyPage farmersGeneralInsuranceAgencyPage = new FarmersGeneralInsuranceAgencyPage();
            farmersGeneralInsuranceAgencyPage.validateFGIAPromptPage(farmersSoftAssert, true, zipCode);
        }
        Log.info(String.format("Validated %s state with %s zipcode and user selected %s continue from bw modal", stateCode, zipCode, acceptBwFlow ? "" : "not"));
        farmersSoftAssert.assertAll();
    }
}

