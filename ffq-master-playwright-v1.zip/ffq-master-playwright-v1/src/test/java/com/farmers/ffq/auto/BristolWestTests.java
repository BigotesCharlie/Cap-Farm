package com.farmers.ffq.auto;

import static com.farmers.ffq.utils.GlobalVariables.*;

import com.farmers.ffq.auto.pages.KnockOutPage;
import com.farmers.ffq.auto.pages.legacy.QuotePageAuto;
import com.farmers.ffq.dataproviders.SqlDataProviders;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.datatransferobjects.SqlVehicle;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BristolWestTests {

	private static final String BW_TESTS = "bwLegacyStatesTesting";

	//Non ace states
	@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class,
			attributes = {@CustomAttribute(name = FILTER, values = {"testScenario=PNI never had insurance"})}, groups = {REGRESSION, BW_TESTS})
	public void bwNeverHadInsuranceTest(SqlApplicant applicant) throws Exception {
		createNonAceAutoQuote(applicant, !applicant.getStateCode().equals(MT));
	}

	@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class,
			attributes = {@CustomAttribute(name = FILTER, values = {"testScenario=PNI insured LT 6 months"})}, groups = {REGRESSION, BW_TESTS})
	public void bwInsuredLT6MonthsTest(SqlApplicant applicant) throws Exception {
		createNonAceAutoQuote(applicant, !Arrays.asList(AL, MT, VA).contains(applicant.getStateCode()));
	}

	@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class,
			attributes = {@CustomAttribute(name = FILTER, values = {"testScenario=PNI expired insurance"})}, groups = {REGRESSION, BW_TESTS})
	public void bwExpiredInsuranceTest(SqlApplicant applicant) throws Exception {
		createNonAceAutoQuote(applicant, !Arrays.asList(AL, MT).contains(applicant.getStateCode()));
	}

	@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class,
			attributes = {@CustomAttribute(name = FILTER, values = {"testScenario=PNI foreign license"})}, groups = {REGRESSION, BW_TESTS})
	public void bwForeignDriverTest(SqlApplicant applicant) throws Exception {
		createNonAceAutoQuote(applicant, !applicant.getStateCode().equals(MT));
	}

	@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class,
			attributes = {@CustomAttribute(name = FILTER, values = {"testScenario=Rideshare vehicle"})}, groups = {REGRESSION, BW_TESTS})
	public void bwRideshareYesTest(SqlApplicant applicant) throws Exception {
		try {
			createNonAceAutoQuote(applicant, Arrays.asList(FL, IN, KY, MA, MS, ND, NJ, OK, PA, SD, TN, TX).contains(applicant.getStateCode()));
		} catch (SkipException se) {
		    if (applicant.getStateCode().equals(VA)) {
			KnockOutPage knockoutPage = new KnockOutPage(SPECIAL_ATTENTION);
			Assert.assertTrue(knockoutPage.isOnKnockOutPage(), "Special Attention page expected");			
		    }
		}
	}

	@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class,
			attributes = {@CustomAttribute(name = FILTER, values = {"testScenario=More than one injury"})}, groups = {REGRESSION, BW_TESTS})
	public void bwMoreThanOneInjuryTest(SqlApplicant applicant) throws Exception {
		createNonAceAutoQuote(applicant, Arrays.asList(FL, IN, KY, MA, MD, MS, ND, NJ, OK, PA, SD, TN, UT, VA, WY).contains(applicant.getStateCode()));
	}

	@Test(dataProvider = SqlDataProviders.BRISTOL_WEST_AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class,
			attributes = {@CustomAttribute(name = FILTER, values = {"testScenario=PNI financial filing"})}, groups = {REGRESSION, BW_TESTS})
	public void bwFinancialFilingTest(SqlApplicant applicant) throws Exception {
		createNonAceAutoQuote(applicant, Arrays.asList(CO, FL, ID, IN, KY, MA, MS, ND, NJ, OK, PA, SD, TN, TX, VA, WY).contains(applicant.getStateCode()));
	}

	private void createNonAceAutoQuote(SqlApplicant applicant, boolean isBristolWestExpected) throws Exception {
		applicant = setTestDataForNonAceApplicant(applicant);
		QuoteScenarios nonAceQuoteSenarios = new QuoteScenarios();
		try {
			nonAceQuoteSenarios.createAutoQuote(applicant, false);
		} catch (IllegalStateException ise) {
			throw new SkipException("Test skipped: " + ise.getMessage() +  SPACE + NEWLINE);
		} catch (AssertionError ae) {
			throw new SkipException("Test cannot be conducted because " + ae.getMessage() + SPACE + NEWLINE);
		}
		QuotePageAuto quotePage = new QuotePageAuto();
		Assert.assertEquals(quotePage.isBristolWestQuote(), isBristolWestExpected, "Display Quote Page for Bristol West");
		Assert.assertTrue(quotePage.updateQuoteAndRate(applicant, applicant.getStateCode().equals(MA)), "Quote updated and recalculated");
		quotePage.showSaucelabsLinkOnSuccessfulTest(true);
	}

	private SqlApplicant setTestDataForNonAceApplicant(SqlApplicant applicant) {
		List<SqlAdditionalDriver> noAdditionalDrivers = new ArrayList<>();
		applicant.setAdditionalDrivers(noAdditionalDrivers);
		List<SqlVehicle> listOfVehicles = applicant.getVehicles();
		listOfVehicles.replaceAll(vehicle -> {
			vehicle.setOwnership("Owned");
			vehicle.setUseVIN(false);
			vehicle.setParkInresidentAddress(true);
			return vehicle;
		});
		applicant.setVehicles(listOfVehicles);
		return applicant;
	}
}
