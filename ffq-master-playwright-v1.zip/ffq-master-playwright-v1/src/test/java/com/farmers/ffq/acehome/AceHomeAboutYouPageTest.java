package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.home.AceHomeReviewQuotePage;
import com.farmers.ffq.ace.hrc.common.AceHRCAboutYouBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCAdditionalInfoBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Home.Field;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.ABOUT_YOU;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeAboutYouPageTest extends AutomationFramework {

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_ABOUT_YOU_PAGE})
    public void pageContentValidationAboutYouPageHomeLob(ApplicantAceHome applicant) throws Exception {
        applicant.setInEscrow(true);
        AceHRCAboutYouBasePage aboutYouPageAceHome = new AceHomeNavigationHelper().navigateToAceHomeAboutYouPage(applicant, LOB_HOME, HOME);
        AppStore sessionStorageData = aboutYouPageAceHome.getSessionStorageAppStore();
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        // validate content for primary applicant
        aboutYouPageAceHome.validateContentOfPrimaryApplicant(fsa, applicant.getStateCode(), HOME);

        // validate content of eligible occupation button, title, side sheet
        // Add occupation as per applicant, validate added occupation, remove occupation, validate content of remove occupation pop up
        if (!aboutYouPageAceHome.isNoEligibleOccupationState(applicant.getStateCode())) {
            aboutYouPageAceHome.validateContentForEligibleOccupationButtonAndTitle(fsa, true);
            aboutYouPageAceHome.validateContentOfEligibleOccupationSideSheet(fsa, sessionStorageData.getData().getLandingStateCode(), true);
            aboutYouPageAceHome.clickEligibleOccupationButton(true);
            if (!applicant.getStateCode().equals(TN)) {
                aboutYouPageAceHome.selectOccupationRadioButtonAndValidateSelectedOccupation(fsa, applicant.getOccupation());
                aboutYouPageAceHome.clickRemoveOccupationLink(true);
                aboutYouPageAceHome.validateRemoveOccupationHeaderAndQuestion(fsa);
                aboutYouPageAceHome.clickKeepOccupationButton();
                aboutYouPageAceHome.clickRemoveOccupationLink(true);
                aboutYouPageAceHome.clickRemoveOccupationButton();
                if (!applicant.getOccupation().isBlank()) {
                    aboutYouPageAceHome.clickEligibleOccupationButton(true);
                    aboutYouPageAceHome.selectOccupationRadioButton(applicant.getOccupation());
                    aboutYouPageAceHome.clickAddButton();
                }
            } else {
                aboutYouPageAceHome.clickCloseIcon();
            }
        }

        // validate content in spouse section
        aboutYouPageAceHome.validateSpouseSectionIsDisplayed(fsa);
        aboutYouPageAceHome.clickOnMarriedOrInDomesticRelationCheckbox();
        aboutYouPageAceHome.validateMarriedOrInDomesticRelationCheckBoxDescription(fsa);
        aboutYouPageAceHome.validateContentOfSpouseApplicant(fsa, applicant.getStateCode(), HOME);

        // validate content of eligible occupation button, title, side sheet in spouse section
        // Add occupation as per applicant, validate added occupation, remove occupation, validate content of remove occupation pop up
        if (!aboutYouPageAceHome.isNoEligibleOccupationState(applicant.getStateCode())) {
            aboutYouPageAceHome.validateContentForEligibleOccupationButtonAndTitle(fsa,false);
            aboutYouPageAceHome.clickEligibleOccupationButton(false);
            if (!applicant.getStateCode().equals(TN)) {
                aboutYouPageAceHome.selectOccupationRadioButtonAndValidateSelectedOccupation(fsa, applicant.getOccupation());
                aboutYouPageAceHome.clickRemoveOccupationLink(false);
                aboutYouPageAceHome.clickKeepOccupationButton();
                aboutYouPageAceHome.clickRemoveOccupationLink(false);
                aboutYouPageAceHome.clickRemoveOccupationButton();
                if (!applicant.getOccupation().isBlank()) {
                    aboutYouPageAceHome.clickEligibleOccupationButton(false);
                    aboutYouPageAceHome.selectOccupationRadioButton(applicant.getOccupation());
                    aboutYouPageAceHome.clickAddButton();
                }
            } else {
                aboutYouPageAceHome.clickCloseIcon();
            }
        }

        // validate prior or current address content
        Field field = sessionStorageData.getHome().getAddressForm().getFields().get(0);
        aboutYouPageAceHome.validateContentOfPriorOrCurrentAddress(fsa, field);
        aboutYouPageAceHome.validateDiscounts(ABOUT_YOU, applicant, HOME, fsa);
        aboutYouPageAceHome.validateAgentSection(fsa, ABOUT_YOU, applicant.getAgentId(), HOME);
        aboutYouPageAceHome.validateQuoteText(ABOUT_YOU, applicant.getQuoteNumber(), fsa, false);

        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ABOUT_YOU_PAGE})
    public void validateErrorMessagesAboutYouPageHomeLob(ApplicantAceHome applicantAceHome) throws Exception {
        AceHRCAboutYouBasePage aboutYouPageAceHome = new AceHomeNavigationHelper().navigateToAceHomeAboutYouPage(applicantAceHome, LOB_HOME, HOME);
        AppStore sessionStorageData = aboutYouPageAceHome.getSessionStorageAppStore();

    	FarmersSoftAssert fsa = new FarmersSoftAssert();

        //attempting to skip field entering
        aboutYouPageAceHome.waitAboutYouPageToRender();
        aboutYouPageAceHome.fillOutApplicantFormWithNoInput();
        aboutYouPageAceHome.validateErrorMessageForNoInput(true, applicantAceHome, fsa);

        // validate error message for incorrect input
        aboutYouPageAceHome.fillOutApplicantFormWithIncorrectInput(true);
        aboutYouPageAceHome.validateErrorMessageForInvalidInput(true, applicantAceHome, fsa);

        // validate is age<=15 and age>=99 & Date of Birth is a valid entry
        aboutYouPageAceHome.validateInvalidErrorMessagesForAgeLimitAndDob(fsa, applicantAceHome, true);
        driver().navigate().refresh();

        //validate First/Last name char limit - 15 char and 20 char max respectively
        aboutYouPageAceHome.fillOutApplicantFormWithValues("MoreThanFifteenChars","MoreThanTwentyCharacters", "09/09/1600" );
        aboutYouPageAceHome.validateCharacterLimitForFirstNameLastName(fsa);
        driver().navigate().refresh();

        //Not allowed special chars and numeric chars in First name and last name field
        aboutYouPageAceHome.validateNotAllowedSpecialCharsInFirstLastName(fsa);
        driver().navigate().refresh();
        aboutYouPageAceHome.validateNotAllowedNumericInFirstLastName(fsa);

        //Not allowed special chars in DOB and spouse's DOB field
        aboutYouPageAceHome.validateNotAllowedSpecialCharInDOB(fsa);

        // check the spouse checkbox in order to validate errors in spouse section
        aboutYouPageAceHome.clickOnMarriedOrInDomesticRelationCheckbox();
        aboutYouPageAceHome.fillOutApplicantFormWithValues(applicantAceHome.getFirstName(), applicantAceHome.getLastName(), applicantAceHome.getDateOfBirth());
        aboutYouPageAceHome.selectGender(applicantAceHome);

        // validate error messages when no input is provided
        aboutYouPageAceHome.fillOutApplicantFormWithNoInput();
        aboutYouPageAceHome.validateErrorMessageForNoInput(false, applicantAceHome, fsa);
        aboutYouPageAceHome.validateRequiredIncompleteFieldErrorMessage(fsa);

        aboutYouPageAceHome.fillOutApplicantFormWithIncorrectInput(false);
        aboutYouPageAceHome.validateErrorMessageForInvalidInput(false,applicantAceHome, fsa);

        //validate First/Last name char limit - 15 char and 20 char max respectively
        aboutYouPageAceHome.fillOutSpouseApplicantFormWithValues("MoreThanFifteenChars","MoreThanTwentyCharacters", "09/09/1600" );
        aboutYouPageAceHome.validateCharLimitFirstLastNameSpouse(fsa);

        // invalidate condition is age<=15 and age>=99 & Date of Birth is a valid entry
         aboutYouPageAceHome.validateInvalidErrorMessagesForAgeLimitAndDob(fsa, applicantAceHome, false);

        //basePageAboutYouAceHome.clickOnMarriedOrInDomesticRelationCheckbox();
        //Not allowed special chars and numeric chars in Spouse's First name and Spouse's last name field
        aboutYouPageAceHome.validateNotAllowedSpecialCharsInFirstLastNameSpouse(fsa);
        driver().navigate().refresh();
        if (!aboutYouPageAceHome.isMarriedCheckboxChecked()) {
            aboutYouPageAceHome.clickOnMarriedOrInDomesticRelationCheckbox();
        }
        aboutYouPageAceHome.validateNotAllowedNumericInFirstLastNameSpouse(fsa);

        //Not allowed special chars in DOB and spouse's DOB field
        aboutYouPageAceHome.validateNotAllowedSpecialCharInDOBSpouse(fsa);


        // validate error message if prior or current address available
        if(sessionStorageData.getHome().getAddressForm().getFields().get(0).getIsNewHome().equals("Y")){
            aboutYouPageAceHome.fillOutApplicantFormWithNoInput();
            aboutYouPageAceHome.validateErrorForNoInputInCurrentOrPriorAddressFields(fsa);

            aboutYouPageAceHome.fillOutCurrentOrPriorAddressFieldWithInValidData();
            aboutYouPageAceHome.clickContinueButton();
            aboutYouPageAceHome.validateErrorForInvalidInputInCurrentOrPriorAddressFields(fsa);

            aboutYouPageAceHome.validateNotAllowedSpecialCharInCity(fsa);
            aboutYouPageAceHome.fillOutUnitNumberWithInValidData();
            fsa.assertTrue(aboutYouPageAceHome.isInvalidUnitErrorDisplayed(), "Invalid unit# is not displayed");
        }

        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ABOUT_YOU_PAGE})
    public void testDataNotSavedWhenNavigatedBackAboutYouPageHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCAboutYouBasePage aboutYouPageAceHome = new AceHomeNavigationHelper().navigateToAceHomeAboutYouPage(applicant, LOB_HOME, HOME);

    	FarmersSoftAssert fsa = new FarmersSoftAssert();

        AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
        Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "About You page is reached");
        aboutYouPage.fillOutTheDataInAboutYouPage(applicant, false);
        aboutYouPageAceHome.navigateBack();

        AceHRCAdditionalInfoBasePage additionalInfoPage = new AceHRCAdditionalInfoBasePage();
        Assert.assertTrue(additionalInfoPage.isOnAdditionalInfoPage(), "Additional Info page is reached");
        additionalInfoPage.clickContinueButton();

        aboutYouPage = new AceHRCAboutYouBasePage();
        Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "About You page is reached");
        aboutYouPageAceHome.validateDataNotSaved(applicant, fsa);
        fsa.assertAll("About You page - Data not saved when navigated back from the page.");

    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,TX,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_ABOUT_YOU_PAGE})
    public void validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageHomeLob(ApplicantAceHome applicant) throws Exception {

        AceHRCAboutYouBasePage aboutYouPageAceHome = new AceHRCAboutYouBasePage();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().navigateToAceHomeReviewQuotePage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        int i = 5;
        do {
            reviewQuotePage.navigateBack();
            i--;
        }while(!aboutYouPageAceHome.isOnAboutYouPage(false) && (i > 0));
        aboutYouPageAceHome = new AceHRCAboutYouBasePage();
        aboutYouPageAceHome.validateAboutYouSelections(applicant,true, fsa);
        fsa.assertAll("About You page - Data is not editable when quote is rated");

    }
}
