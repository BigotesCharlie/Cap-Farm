package com.farmers.ffq.acerenters;

import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCConsolidatedPaymentPage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentSelectionPage;
import com.farmers.ffq.ace.renters.AceRentersNavigationHelper;
import com.farmers.ffq.ace.renters.AceRentersReviewQuotePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.PAYMENT_PAGE;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.MONTHLY_AUTOPAY;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersConsolidatedPaymentPageTest extends AutomationFramework {
    // Test case validate content of consolidated payment page
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONSOLIDATED_PAYMENT_PAGE})
    public void validateAceRentersConsolidatedPaymentPage(ApplicantAceHome applicant) throws Exception {
        AceRentersNavigationHelper navigator = new AceRentersNavigationHelper();
        AceRentersReviewQuotePage aceRentersReviewQuotePage = navigator.navigateToAceRentersReviewQuotePage(applicant);
        double monthlyPremiumAmountOnReviewQuotePage = aceRentersReviewQuotePage.getPremiumAmountFromQuotePresentmentCard();
        aceRentersReviewQuotePage.clickOnViewPricingLink();
        double payInFullPremiumAmountOnReviewQuotePage = aceRentersReviewQuotePage.getPremiumAmountFromQuotePresentmentCard();
        navigator.setResumeFromPage(REVIEW_QUOTE);
        navigator.navigateToAceRentersPaymentPage(applicant);
        AceHRCConsolidatedPaymentPage aceHRCConsolidatedPaymentPage = new AceHRCConsolidatedPaymentPage();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceHRCConsolidatedPaymentPage.validateConsolidatedPaymentPageRenters(fsa, applicant.getStateCode(), monthlyPremiumAmountOnReviewQuotePage, payInFullPremiumAmountOnReviewQuotePage);
        AceHRCBasePage aceHRCBasePage = new AceHRCBasePage();
        aceHRCBasePage.validateAgentSection(fsa, PAYMENT_PAGE, applicant.getAgentId(), RENTERS);
        aceHRCBasePage.validateQuoteText(PAYMENT_PAGE, applicant.getQuoteNumber(), fsa, true);
        fsa.assertAll();
    }

    // Test case add all the payment methods (bank, credit card and debit card) for monthly pay and pay in full
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONSOLIDATED_PAYMENT_PAGE})
    public void consolidatePaymentPageValidatePaymentsRenters(ApplicantAceHome applicant) throws Exception {
        new AceRentersNavigationHelper().navigateToAceRentersPaymentPage(applicant);
        AceHRCConsolidatedPaymentPage aceHRCConsolidatedPaymentPage = new AceHRCConsolidatedPaymentPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceHRCConsolidatedPaymentPage.validatePaymentsRenters(fsa);
        fsa.assertAll();
    }

    // Test case adds bank details and complete purchase for env stability check
    @Test(dataProvider = AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {ACE_STABILITY, FFQ_ACE_RENTERS_PAYMENT_SELECTION_PAGE})
    public void testQuoteAndBindRentersLob(ApplicantAceHome applicant) throws Exception {
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceRentersNavigationHelper().navigateToMonthlyAutoPayBankPaymentPageAceRenters(applicant);
        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
        aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayBankRenters();
        aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayBankPaymentLabelRenters();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, RENTERS);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, RENTERS);
        List<AppStore.Home.VerifyResponse.PaymentSchedule> paymentSchedules = aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC().getPaymentSchedules();
        int administrativeCharge = aceHRCPaymentBasePage.getAdministrativeFeeForGivenPayPlanDescriptionHRC(paymentSchedules, MONTHLY_EFT);
        if (administrativeCharge <= 0) {
            aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, RENTERS);
        }
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, RENTERS);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, RENTERS);
        fsa.assertAll("Ace Renters - Validate quote and bind, end-to-end.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONSOLIDATED_PAYMENT_PAGE})
    public void verifyPremiumNotChangedOnBackAndForthFromPaymentPageToJFMTP(ApplicantAceHome applicantAceHome) throws Exception {
        new AceRentersNavigationHelper().navigateToAceRentersPaymentPage(applicantAceHome);
        AceHRCConsolidatedPaymentPage aceHRCConsolidatedPaymentPage = new AceHRCConsolidatedPaymentPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        Assert.assertTrue(aceHRCConsolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User landed on the Consolidated payment page");
        aceHRCConsolidatedPaymentPage.verifyPremiumNotChangedOnBackAndForthFromPaymentPageToJFMTP(fsa, PAY_IN_FULL);
        aceHRCConsolidatedPaymentPage.verifyPremiumNotChangedOnBackAndForthFromPaymentPageToJFMTP(fsa, MONTHLY_AUTOPAY);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONSOLIDATED_PAYMENT_PAGE})
    public void verifyPremiumChangedOnBackAndForthFromPaymentPageToReviewQuote(ApplicantAceHome applicantAceHome) throws Exception {
        new AceRentersNavigationHelper().navigateToAceRentersPaymentPage(applicantAceHome);
        AceHRCConsolidatedPaymentPage aceHRCConsolidatedPaymentPage = new AceHRCConsolidatedPaymentPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        Assert.assertTrue(aceHRCConsolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User landed on the Consolidated payment page");
        aceHRCConsolidatedPaymentPage.verifyPremiumChangedOnBackAndForthFromPaymentPageToReviewQuote(fsa, PAY_IN_FULL, applicantAceHome);
        aceHRCConsolidatedPaymentPage.verifyPremiumChangedOnBackAndForthFromPaymentPageToReviewQuote(fsa, MONTHLY_AUTOPAY, applicantAceHome);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {ACE_STABILITY})
    public void testQuoteAndBindEndToEndRenters(ApplicantAceHome applicant) throws Exception {
        new AceRentersNavigationHelper().navigateToMonthlyAutoPayBankPaymentPageAceRenters(applicant);
    }
}
