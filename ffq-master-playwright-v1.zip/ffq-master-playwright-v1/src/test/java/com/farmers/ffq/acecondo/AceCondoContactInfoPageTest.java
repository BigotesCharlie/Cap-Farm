package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCContactInfoBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCFwsInterstitialPage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoContactInfoPageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_CONTACT_INFO_PAGE})
    public void validateContactInfoPageCondoLob(ApplicantAceHome applicant) throws Exception {
        AceHRCContactInfoBasePage contactInfoPage = new AceCondoNavigationHelper().navigateToAceCondoContactInfoPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoPage.validateHeaderAndSubHeaderContactInfoPage(fsa);
        contactInfoPage.validateContentOfEstimatedClosingOrPolicyStartDate(fsa, CONDO);
        contactInfoPage.validateContentOfFireHydrantSection(fsa, CONDO);
        boolean isPEWCFlowEnabled = contactInfoPage.isNewFlowEnabledState(applicant.getStateCode());
        if (!isPEWCFlowEnabled) {
            contactInfoPage.validateContentOfContactInfo(fsa);
            contactInfoPage.validateDisclaimerOnContactInfoPage(fsa);
            contactInfoPage.validateContentOfAgreeAndSubmit(fsa);
            contactInfoPage.enterEmailIdAndPhoneNumberInContactInfoPage(applicant);
            contactInfoPage.validateDisclaimerFooterLinks(fsa, CONDO);
        } else {
            contactInfoPage.validateContentOfAboutYouSection(fsa, applicant, CONDO);
            fsa.assertTrue(contactInfoPage.isContinueButtonDisplayed(), "Continue button is not displayed on Contact Info Page: " + CONDO);
        }
        contactInfoPage.validateBundleSaveSection(applicant, fsa, CONDO);
        contactInfoPage.validateContentOfMailingAndOtherMailingAddress(fsa);
        contactInfoPage.validateSaveQuoteModal(true);
        contactInfoPage.validateAgentSection(fsa, AceHRCBasePage.CONTACT_INFO, applicant.getAgentId(), CONDO);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_CONTACT_INFO_PAGE})
    public void validateContactInfoPageErrorMessagesCondoLob(ApplicantAceHome applicantAceHome) throws Exception {
        AceHRCContactInfoBasePage contactInfoPageAceCondo = new AceCondoNavigationHelper().navigateToAceCondoContactInfoPage(applicantAceHome);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoPageAceCondo.validateErrorMessages(fsa, applicantAceHome, CONDO);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CONTACT_INFO_PAGE})
    public void validateEarlyShoppingDiscountFunctionalityCondoLob(ApplicantAceHome applicantAceHome) throws Exception {
        AceHRCContactInfoBasePage contactInfoPageAceCondo = new AceCondoNavigationHelper().navigateToAceCondoContactInfoPage(applicantAceHome);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoPageAceCondo.validateEarlyShopperDiscount(fsa, applicantAceHome.getStateCode());
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC,AZ,OH,OR,TX,UT})}, groups = {PEWC})
    public void aceCondoPEWCScreen(ApplicantAceHome applicantAceHome) throws Exception {
        AceHRCContactInfoBasePage contactInfoPageAceCondo = new AceCondoNavigationHelper().navigateToAceCondoContactInfoPage(applicantAceHome);
        contactInfoPageAceCondo.capturePEWC("AceCondo_ContactInfoPage");
        testStep("End Of Test");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_BINDABLE_CHOICE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,LA,MA,MS,MT,NC,OH,OR,TX,UT})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CONTACT_INFO_PAGE})
    public void validateFWSInterstitialToBindableChoiceIntegrationCondo(ApplicantAceHome applicantAceHome) throws Exception {

        applicantAceHome.setAgentId(EMPTY_STRING);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCContactInfoBasePage contactInfoPageAceCondo = new AceCondoNavigationHelper().navigateToAceCondoContactInfoPage(applicantAceHome);
        contactInfoPageAceCondo.fillOutContactInfoPage(applicantAceHome, CONDO);
        contactInfoPageAceCondo.waitForSpinnerToBeGone();
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        Assert.assertTrue(fwsInterstitialPage.isOnFarmersChoiceInterstitialPage(), "User is not navigated to FWS Interstitial - Farmers choice page");
        driver().navigate().refresh(); //F96276
        fwsInterstitialPage.validateFwsFarmersChoicePage(fsa, CONDO);
        fwsInterstitialPage.clickOnApplyDiscountButton();
        Assert.assertTrue(fwsInterstitialPage.isOnBindableChoicePage(20), "User is not navigated to Bindable Choice page after clicking on Apply Discount button from FWS Interstitial page");
        fwsInterstitialPage.validateSelectedInsuranceType(fsa, CONDO);
        fsa.assertAll("Validate FWS Interstitial to Bindable Choice Integration from Contact Info page - Condo LOB.");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_COLP, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,LA,MA,MS,MT,NC,OH,OR,TX,UT})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CONTACT_INFO_PAGE})
    public void validateFWSInterstitialColpPageCondo(ApplicantAceHome applicantAceHome) throws Exception {

        applicantAceHome.setAgentId(EMPTY_STRING);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCContactInfoBasePage contactInfoPageAceCondo = new AceCondoNavigationHelper().navigateToAceCondoContactInfoPage(applicantAceHome);
        contactInfoPageAceCondo.fillOutContactInfoPage(applicantAceHome, CONDO);
        contactInfoPageAceCondo.waitForSpinnerToBeGone();
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        Assert.assertTrue(fwsInterstitialPage.isOnColpInterstitialPage(), "User is not navigated to FWS Interstitial - Colp page");
        driver().navigate().refresh(); //F96276
        fwsInterstitialPage.validateFwsColpPage(fsa, CONDO);
        fsa.assertAll("Validate FWS Interstitial COLP page content from Contact Info page - Condo LOB.");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_QNB, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,LA,MA,MS,MT,NC,OH,OR,TX,UT})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CONTACT_INFO_PAGE})
    public void validateFWSInterstitialQnBPageCondo(ApplicantAceHome applicantAceHome) throws Exception {

        applicantAceHome.setAgentId(EMPTY_STRING);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCContactInfoBasePage contactInfoPageAceCondo = new AceCondoNavigationHelper().navigateToAceCondoContactInfoPage(applicantAceHome);
        contactInfoPageAceCondo.fillOutContactInfoPage(applicantAceHome, CONDO);
        contactInfoPageAceCondo.waitForSpinnerToBeGone();
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        Assert.assertTrue(fwsInterstitialPage.isOnQnBInterstitialPage(), "User is not navigated to FWS Interstitial - QnB page");
        driver().navigate().refresh(); //F96276
        fwsInterstitialPage.validateFwsQnBPage(fsa);
        fwsInterstitialPage.clickOnGetMyQuoteButton();
        fwsInterstitialPage.waitForSpinnerToBeGone();
        Assert.assertTrue(fwsInterstitialPage.isOnQnBSite(), "User did not landed on QnB site after clicking on Get My Quote button from FWS Interstitial page - Condo LOB");
        fwsInterstitialPage.validateQnBUrl(fsa);
        fsa.assertAll("Validate FWS Interstitial QnB page content from Contact Info page - Condo LOB.");
    }
}
