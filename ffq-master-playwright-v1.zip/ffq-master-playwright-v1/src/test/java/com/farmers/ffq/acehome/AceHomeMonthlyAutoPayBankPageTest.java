package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentSelectionPage;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.SELECT_PAYMENT;
import static com.farmers.ffq.utils.GlobalVariables.*;

// F64071: FFQ Ace - Home, Condo, Renters QUOTE & BIND Analysis, Updates, Release - MO, SD, VA, ND -- according to this feature MO has only one payment option - Pay in full

public class AceHomeMonthlyAutoPayBankPageTest extends AutomationFramework {
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE})
    public void testValidateContentOfMonthlyAutoPayBankPageOnLandingAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHomeNavigationHelper().navigateToAceHomePaymentSelectionPage(applicantAceHome, LOB_HOME, HOME);
        aceHRCPaymentSelectionPage.validateMonthlyAutoPayPaymentBank(fsa, applicantAceHome.getStateCode(), LOB_HOME);
        AceHRCBasePage basePage = new AceHRCBasePage();
        basePage.validateQuoteText(SELECT_PAYMENT, applicantAceHome.getQuoteNumber(), fsa, true);
        basePage.validateAgentSection(fsa, SELECT_PAYMENT, applicantAceHome.getAgentId(), HOME);
        aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayBank();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        Assert.assertTrue(aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage(), "Monthly Pay Bank or Card Payment Page is not displayed.");
        aceHRCPaymentBasePage.validateContentOfMonthlyPayBankOrCardPageOnLanding(fsa, MONTHLY_EFT, applicantAceHome, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_BIND, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE})
public void testMonthlyAutoPayBankPaymentEndToEndAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHomeNavigationHelper().navigateToMonthlyAutoPayBankPaymentPageAceHome(applicantAceHome, LOB_HOME, HOME);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, HOME);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, HOME);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, HOME);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, HOME);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, HOME);
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE})
    public void testMonthlyAutoPayBankCreditCardPaymentAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHomeNavigationHelper().navigateToMonthlyAutoPayBankPaymentPageAceHome(applicantAceHome, LOB_HOME, HOME);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.selectBankPaymentRadioButtonHRC();
        policyPaymentBasePage.selectCardPaymentRadioButtonHRC();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, HOME);
        driver().switchTo().defaultContent();
        aceHRCPaymentBasePage.validateFutureCreditDebitCardServiceCharges(fsa, true, HOME);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, HOME);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, HOME);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, HOME);
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE})
    public void testMonthlyAutoPayBankChangeBankPaymentToCardAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHomeNavigationHelper().navigateToMonthlyAutoPayBankPaymentPageAceHome(applicantAceHome, LOB_HOME, HOME);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, HOME);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, HOME);
        policyDebitCreditPayment.clickChangeLink();
        policyPaymentBasePage.selectCardPaymentRadioButtonAlternative();
        policyPaymentBasePage.clickSetUpPaymentButtonSideSheet();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateFutureCreditDebitCardServiceCharges(fsa, true, HOME);
        aceHRCPaymentBasePage.switchToParentWindow();
        policyDebitCreditPayment.waitForCompletePurchaseButtonToBeClickable();
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE})
public void testMonthlyAutoPayBankChangeCreditCardPaymentToBankAceHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHomeNavigationHelper().navigateToMonthlyAutoPayBankPaymentPageAceHome(applicantAceHome, LOB_HOME, HOME);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        policyPaymentBasePage.selectBankPaymentRadioButtonHRC();
        policyPaymentBasePage.selectCardPaymentRadioButtonHRC();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, HOME);
        aceHRCPaymentBasePage.validateFutureCreditDebitCardServiceCharges(fsa, true, HOME);
        policyDebitCreditPayment.clickChangeLink();
        policyPaymentBasePage.selectBankPaymentRadioButtonAlternate();
        policyPaymentBasePage.clickSetUpPaymentButton();

        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, HOME);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, HOME);
        aceHRCPaymentBasePage.switchToParentWindow();
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll();
    }
}
