package com.farmers.ffq.auto.bind;

import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;

import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class BindOneUIPolicyStartDateValidationTest extends AutomationFramework {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, FFQ_BIND_JFMT_PAGE}, enabled = false)
    public void bindOneUIPolicyStartDateValidation(AutoApplicant applicant) throws Exception {
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalInfoPolicyStartDateOneUI.verifyAdditionalInfoHeader(fsa);
        AppStore retrieveQuoteResponseSessionStorage = additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore();
        additionalInfoPolicyStartDateOneUI.verifyPolicyStartDateSection(retrieveQuoteResponseSessionStorage, false, fsa);
        additionalInfoPolicyStartDateOneUI.logInfoMessage(retrieveQuoteResponseSessionStorage.getData().getQuoteNumber());
        fsa.assertAll();
        driver().quit();
    }
}
