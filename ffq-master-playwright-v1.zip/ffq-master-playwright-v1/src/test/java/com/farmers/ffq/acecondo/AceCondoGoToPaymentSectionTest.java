package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoGoToPaymentSectionTest extends AutomationFramework {
    @Test(dataProvider = AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {ACE_STABILITY, FFQ_ACE_CONDO_PAYMENT_SELECTION_PAGE})
    public void testQuoteAndBindCondoLob(ApplicantAceHome applicant) throws Exception {
        applicant.setSquareFeet("400");
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceCondoNavigationHelper().navigateToMonthlyAutoPayCardPaymentPageAceCondo(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, CONDO);
        aceHRCPaymentBasePage.validateFutureCreditDebitCardServiceCharges(fsa, true, CONDO);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, CONDO);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, CONDO);
        fsa.assertAll("Ace Condo - Validate quote and bind, end-to-end.");
    }
}
