package com.farmers.ffq.acebundle;

import com.farmers.ffq.ace.bundle.*;
import com.farmers.ffq.ace.home.AceHomeContactInfoPage;
import com.farmers.ffq.ace.home.AceHomeReviewQuotePage;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoSignalEnrollmentSectionOneUI;
import com.farmers.ffq.auto.pages.bindpages.ConsolidatedPaymentPage;
import com.farmers.ffq.auto.pages.bindpages.EcheckoutSuccessfulPageOneUI;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.PaymentSelectionBasePage;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.dataproviders.AceBundleDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;
import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.*;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceAutoHomeBundleTests extends AceBundleTestHelper {

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void aceAutoHomeBundleE2ETest(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		setVINInBundleApplicantForNonBWAuto(bundleApplicant);
		EcheckoutSuccessfulPageOneUI finalPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToECheckoutPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		if (new KnockoutInconveniencePage().isQuoteKnockedOut()) {
			Log.warn("Payment failed, cannot complete process");
		} else {
			fsa.assertTrue(finalPage.isPaymentSuccessfulMessageCorrect(), "Payment successful on final page");
		}
		fsa.assertAll();
	}

	// AH - BW - Auto monthly pay card and home pay in full card
	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void aceBWAutoHomeBundleE2EWithAutoMonthlyPayCardAndHomePayInFullCard(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToPayForPropertyPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentPayInFullCard(HOME);
		PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
		policyPaymentBasePage.clickSetUpPaymentButton();
		policyPaymentBasePage.clickDebitCreditCardButton();
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(VISA_CREDIT_CARD);
		aceHRCPaymentBasePage.waitForSpinnerToBeGone();
		aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPagePayInFull(fsa, VISA_CREDIT_CARD, CARD_NAME_VISA, true, HOME);
		aceHRCPaymentBasePage.validateFeesSideBarHeaderAndDescription(fsa, MONTHLY_EFT, bundleApplicant.getHrcApplicant(), HOME);
		aceHRCPaymentBasePage.validateFeesOrOneTimeFeesOrExpenseConstantLabelAndAmountHC(fsa, bundleApplicant.getHrcApplicant().getStateCode(), PaymentSelectionBasePage.PAY_IN_FULL, HOME);
		aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, HOME);
		aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPagePayInFull(fsa, HOME);
		aceHRCPaymentBasePage.validateOneTimePaymentRecurringRadioButtonText(fsa, HOME);
		aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, HOME);
		aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphPayInFull(fsa, HOME);
		aceHRCPaymentBasePage.clickCompletePurchaseButton();
		aceHRCPaymentBasePage.validateECheckOutPage(fsa, HOME);
		fsa.assertAll();
	}

	// AH - BW - Auto monthly pay card and home monthly pay bank
	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void aceBWAutoHomeBundleE2EWithAutoMonthlyPayCardAndHomeMonthlyPayInBank(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToPayForPropertyPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayBank();
		PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
		policyPaymentBasePage.clickSetUpPaymentButton();
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		aceHRCPaymentBasePage.validateContentOfMonthlyPayBankOrCardPageOnLanding(fsa, MONTHLY_EFT, bundleApplicant.getHrcApplicant(), HOME);
		aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
		aceHRCPaymentBasePage.waitForSpinnerToBeGone();
		aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, HOME);
		aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, HOME);
		aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, HOME);
		aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, HOME);
		aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, HOME);
		aceHRCPaymentBasePage.clickCompletePurchaseButton();
		aceHRCPaymentBasePage.validateECheckOutPage(fsa, HOME);
		fsa.assertAll();
	}

	// AH - Auto monthly pay card and home monthly pay card
	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyPaymentPagesContentAndUseSamePaymentDialogFunctionalityAH(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		setVINInBundleApplicantForNonBWAuto(bundleApplicant);
		AceBundleAutoPaymentPage aceBundleAutoPaymentPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToPayForAutoPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		aceBundleAutoPaymentPage.verifyAceBundleAutoPaymentPageContent(fsa);
		aceBundleAutoPaymentPage.fillOutAutoPaymentPageAndContinue(bundleApplicant.getAutoApplicant());
		AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
		aceHRCPaymentSelectionPage.verifyAceBundleHRCPaymentPageContent(fsa);
		aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayCard();
		PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
		policyPaymentBasePage.clickSetUpPaymentButtonBundle();
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		aceHRCPaymentBasePage.verifyContentOfUseSamePaymentMethodPopUP(fsa, MONTHLY_DEBIT_CREDIT_CARD);
		aceHRCPaymentBasePage.clickSameButtonSamePaymentModal();
		aceHRCPaymentBasePage.waitForReuseSamePaymentPopUPInvisible();
		aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, HOME);

		aceHRCPaymentBasePage.navigateBack();
		aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayCard();
		policyPaymentBasePage.clickSetUpPaymentButtonBundle();
		aceHRCPaymentBasePage.clickDifferentButtonSamePaymentModal();
		aceHRCPaymentBasePage.waitForReuseSamePaymentPopUPInvisible();
		aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(DISCOVER_CARD);
		aceHRCPaymentBasePage.waitForSpinnerToBeGone();
		aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, DISCOVER_CARD, CARD_NAME_DISCOVER, true, HOME);
		aceHRCPaymentBasePage.validateFutureCreditDebitCardServiceCharges(fsa, true, HOME);
		aceHRCPaymentBasePage.clickCompletePurchaseButton();
		aceHRCPaymentBasePage.validateECheckOutPage(fsa, HOME);
		fsa.assertAll();
	}

	// Auto - Pay in full bank, home - monthly pay bank
	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyAutoPayInFullCardAndHomeMonthlyPayBank(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		setVINInBundleApplicantForNonBWAuto(bundleApplicant);
		new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToPayForAutoPage(bundleApplicant);
		ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
		consolidatedPaymentPage.selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
		consolidatedPaymentPage.clickCardRadioButton();
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		aceHRCPaymentBasePage.addCardPaymentMethod(VISA_DEBIT_CARD_2, bundleApplicant.getAutoApplicant().getZipCode());
		aceHRCPaymentBasePage.clickCompletePurchaseButton();
		new AceHRCPaymentSelectionPage().clickSelectAndSetUpPaymentMonthlyPayBank();
		new PolicyPaymentBasePage().clickSetUpPaymentButton();
		aceHRCPaymentBasePage.validateContentOfMonthlyPayBankOrCardPageOnLanding(fsa, MONTHLY_EFT, bundleApplicant.getHrcApplicant(), HOME);
		aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
		aceHRCPaymentBasePage.waitForSpinnerToBeGone();
		aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, HOME);
		aceHRCPaymentBasePage.clickCompletePurchaseButton();
		aceHRCPaymentBasePage.validateECheckOutPage(fsa, HOME);
		fsa.assertAll();
	}

	// Auto - pay in full bank and home pay in full bank with one time payment only selected in auto payment
	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyAutoPayInFullBankAndHomePayInFullBankWithOneTimePayment(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		setVINInBundleApplicantForNonBWAuto(bundleApplicant);
		new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToPayForAutoPage(bundleApplicant);
		ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
		consolidatedPaymentPage.selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
		consolidatedPaymentPage.clickBankPaymentRadioButton();
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
		aceHRCPaymentBasePage.waitForSpinnerToBeGone();
		new PolicyDebitCreditPayment().selectOneTimePaymentRadioButton();
		aceHRCPaymentBasePage.clickCompletePurchaseButton();
		new AceHRCPaymentSelectionPage().clickSelectAndSetUpPaymentPayInFullCard(HOME);
		new PolicyPaymentBasePage().clickSetUpPaymentButton();
		aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
		aceHRCPaymentBasePage.waitForSpinnerToBeGone();
		aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPagePayInFull(fsa, HOME);
		aceHRCPaymentBasePage.clickCompletePurchaseButton();
		aceHRCPaymentBasePage.validateECheckOutPage(fsa, HOME);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyAceBundleHomeFinalReviewQuotePage(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceBundleFinalReviewPage finalReviewPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToFinalReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		finalReviewPage.verifyBundleFinalReviewQuotePageContent(bundleApplicant, HOME, fsa);
		finalReviewPage.navigateBack();
		fsa.assertTrue(finalReviewPage.isOnFinalReviewPage(), "Browser back button is disabled on bundle final review page.");
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyAceBundleHomeJFMTPageAndNavigateBackToAutoJFMTP(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceHRCJustAFewMoreThingsBasePage homeJFMTPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToBundlePropertyJustAFewMoreThingsPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		homeJFMTPage.verifyBundlePropertyJustAFewMoreThingsPageContent(HOME, fsa);
		homeJFMTPage.navigateBack();
		if (new DriverMismatchPage().isOnDriverMismatchPage()) {
			homeJFMTPage.navigateBack();
		}
		AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
		fsa.assertTrue(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "Landed on auto few more things page - AH");
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyAceBundleLetsBeginPageContent(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		NameAndDobPage letsBeginPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToAutoLetsBeginPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		letsBeginPage.verifyLetsBeginPageContent(autoApplicant, fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyAutoPolicyStartDatePageAndRC2PageContentAH(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		ContactInfoAutoPage autoPolicyStartDatePage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToPolicyStartDatePage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoPolicyStartDatePage.verifyAutoHRCBundlePageContent(fsa, bundleApplicant.getAutoApplicant().getStateCode());
		autoPolicyStartDatePage.validateDisclaimers(fsa);
		autoPolicyStartDatePage.clickContactInfoPageCTAButton();
		VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
		if(vehicleDriverAssignmentPage.quickIsOnVehicleDriverAssignmentPage()){
			vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
		}
		autoPolicyStartDatePage.validateRC2ScreenBundle(fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyAceBundleHomePropertyQuestionsPageContent(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceHRCAddressBasePage homePropertyQuestionsPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToAceHRCPropertyQuestionsPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		homePropertyQuestionsPage.verifyAutoHRCBundlePageContent(HOME, bundleApplicant.getHrcApplicant(), fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyAceAutoHomeBundleReviewPageContent(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		if (new Random().nextBoolean()) {
			bundleApplicant.getAutoApplicant().setTestCategory(AWS_SCENARIOS);
		}
		AceBundleReviewQuotesPage autoHomeBundleQuoteSummaryPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToBundleQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoHomeBundleQuoteSummaryPage.verifyBundleReviewQuotePageContent(HOME, bundleApplicant, fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyAceBWAutoHomeBundleReviewPageContent(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		if (new Random().nextBoolean()) {
			bundleApplicant.getAutoApplicant().setTestCategory(AWS_SCENARIOS);
		}
		AceBundleReviewQuotesPage autoRentersBundleQuoteSummaryPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToBundleQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoRentersBundleQuoteSummaryPage.verifyBundleReviewQuotePageContent(HOME, bundleApplicant, fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceAutoHomeBundleAutoQuoteReviewPageContent(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		QuoteSummaryAutoPage autoQuoteSummaryPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToBundleAutoQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoQuoteSummaryPage.verifyBundleAutoReviewQuotePageContent(HOME, fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyAceAutoHomeBundleAutoQuoteEditCoverage(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		QuoteSummaryAutoPage autoQuoteSummaryPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToBundleAutoQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoQuoteSummaryPage.verifyAutoEditLiabilityCoverageInBundleFlow(fsa);
		autoQuoteSummaryPage.verifyAutoEditVehicleCoverageInBundleFlow(fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyAceBundleHomeQuoteReviewPageContent(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceHRCReviewQuoteBasePage homeQuoteReviewPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToBundlePropertyQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		homeQuoteReviewPage.verifyBundlePropertyQuoteReviewPage(HOME, fsa);
		homeQuoteReviewPage.validateYouGetAllTheseWithYourPolicySection(fsa, HOME);
		//commenting out until this validation method is cleaned up
		//	homeQuoteReviewPage.validatePackageOnReviewQuotePage(fsa, bundleApplicant.getHrcApplicant());
		homeQuoteReviewPage.clickContinueToMoreCoveragesButton();
		AceHRCAdditionalCoveragesBasePage propertyOptionalCoveragesPage = new AceHRCAdditionalCoveragesBasePage();
		if (propertyOptionalCoveragesPage.isOnBundlePropertyOptionalCoveragesPage()) {
			propertyOptionalCoveragesPage.verifyBundleContent(HOME, true, fsa);
		} else {
			fsa.fail("Did not reach Optional Coverages Page" + NEWLINE);
		}
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAH(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoPropertyBundleToMonolineAutoAndPurchase(bundleApplicant, HOME, fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAHBW(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoPropertyBundleToMonolineAutoAndPurchase(bundleApplicant, HOME, fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyLandedOnHomeQuoteSummaryPageWhenSelectHomeFromBundleOptionAH(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoHomeBundleToMonolineHomeAndPurchase(bundleApplicant, fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})
	public void verifyLandedOnHomeQuoteSummaryPageWhenSelectHomeFromBundleOptionAHBW(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoHomeBundleToMonolineHomeAndPurchase(bundleApplicant, fsa);
		fsa.assertAll();
	}

	private void autoHomeBundleToMonolineHomeAndPurchase(AceBundleApplicant bundleApplicant, FarmersSoftAssert fsa) throws Exception {
		AceBundleReviewQuotesPage autoHomeBundleQuoteSummaryPage = new AceBundleReviewQuotesPage();
		if (!autoHomeBundleQuoteSummaryPage.isOnBundleReviewQuotesPage()) {
			autoHomeBundleQuoteSummaryPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToBundleQuoteReviewPage(bundleApplicant);
		}
		AppStore appStore = autoHomeBundleQuoteSummaryPage.getSessionStorageAppStore();
		Double homeBundlePremiumMonthly = autoHomeBundleQuoteSummaryPage.getMonthlyHomeBundlePremium(appStore.getHome(), HOME);
		autoHomeBundleQuoteSummaryPage.selectSingleQuoteOptionInCPPopUp(HOME);
		AceHomeReviewQuotePage aceHomeReviewQuotePage = new AceHomeReviewQuotePage();
		fsa.assertTrue(aceHomeReviewQuotePage.isOnReviewQuotePageHome(true), "Home quote summary page reached");
		Double homeMonoLinePremiumMonthly = autoHomeBundleQuoteSummaryPage.getMonthlyHomeMonoLinePremium(appStore.getHome(), HOME);
		verifyBundleDiscountHasDroppedHRCReviewQuotePage(fsa);
		fsa.assertTrue(homeMonoLinePremiumMonthly > homeBundlePremiumMonthly, "MonoLine premium is recalculated");
		aceHomeReviewQuotePage.clickOnContinueButton();
		AceHRCAdditionalCoveragesBasePage aceHRCAdditionalCoveragesBasePage = new AceHRCAdditionalCoveragesBasePage();
		aceHRCAdditionalCoveragesBasePage.clickOnContinueButton();
		if (!new ThankYouPageAce().quickIsOnThankYouPage()) {
			AceHRCJustAFewMoreThingsBasePage aceHRCJustAFewMoreThingsBasePage = new AceHRCJustAFewMoreThingsBasePage();
			aceHRCJustAFewMoreThingsBasePage.fillOutJustFewMoreThingsPage(bundleApplicant.getHrcApplicant(), true);
			// go to pay in full payment page and complete purchase using bank payment and validate eCheckout
			AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
			if (aceHRCPaymentSelectionPage.isOnPaymentPage()) {
				AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
				aceHRCPaymentBasePage.clickSelectAndSetUpPaymentPayInFull();
				PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
				policyPaymentBasePage.clickSetUpPaymentButton();
				aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
				aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPagePayInFull(fsa, HOME);
				aceHRCPaymentBasePage.validateNoServiceChargeWhenPayInFull(fsa, HOME);
				aceHRCPaymentBasePage.waitForSpinnerToBeGone();
				aceHRCPaymentBasePage.clickCompletePurchaseButton();
				aceHRCPaymentBasePage.validateECheckOutPage(fsa, HOME);
			} else {
				fsa.fail("Did not reach payment selection page for quote " + bundleApplicant.getHrcApplicant().getQuoteNumber() + NEWLINE);
			}
		}
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateInEscrowAceAutoHomeBundleAdditionalInfoPage(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		setApplicantForEscrow(bundleApplicant, new Random().nextBoolean());
		AceHRCAdditionalInfoBasePage aceHRCAdditionalInfoBasePage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToAdditionalHomeInformationPage(bundleApplicant);
		AceHRCAboutYouBasePage aceHRCAboutYouBasePage = new AceHRCAboutYouBasePage();
		AppStore.Home.Field field = aceHRCAdditionalInfoBasePage.getSessionStorageAppStore().getHome().getAddressForm().getFields().get(0);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		aceHRCAboutYouBasePage.validateContentOfPriorOrCurrentAddress(fsa, field);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateBundleFlowWhenSelectingPropertyTypeOtherAH(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceHRCPropertyTypeBasePage aceHRCPropertyTypeBasePage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToAceHRCPropertyTypePage(bundleApplicant);
		aceHRCPropertyTypeBasePage.selectPropertyType(OTHER);
		completeBundleFlow(QUOTE_KNOCKOUT);
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {LA, MA, MS})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void aceBundleMonolineAutoTestHomeRestricted(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceBundleNavigationHelper navigationHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		navigationHelper.setMonoline(true);
		navigationHelper.completeAutoQuoteNavigation(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		fsa.assertTrue(new QuoteSummaryAutoPage().isOnQuoteSummaryAutoPage(), "Quote summary page reached");
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE, enabled = false)
	public void aceBundleMonolineHomeTest(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		if (bundleApplicant.getAutoApplicant().getStateCode().equals(TX)) {
			//addresses in this zip code are disabled for bundle, ok for home
			ApplicantAceHome hrcApplicant = bundleApplicant.getHrcApplicant();
			bundleApplicant.getAutoApplicant().setZipCode("77304");
			hrcApplicant.setZipCode("77304");
			hrcApplicant.setAddress("503 Woodsy Pine Ct");
			hrcApplicant.setCity("Panorama Village");
			hrcApplicant.setStateCode(TX);
			bundleApplicant.setHrcApplicant(hrcApplicant);
		}
		AceBundleNavigationHelper navigationHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		navigationHelper.setMonoline(true);
		AceHRCDwellingCoverageBasePage dwellingCoveragePage = navigationHelper.navigateToHRCReviewDwellingCoveragePage(bundleApplicant);
		if (dwellingCoveragePage.isOnDwellingCoveragePage()) {
			dwellingCoveragePage.scrollAndClickOnContinueButton();
		}
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		fsa.assertTrue(new AceHomeReviewQuotePage().isOnReviewQuotePageHome(true), "HRC quote summary page reached");
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {LA, MA, MS})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyLimitedAvailabilityDialogContentAutoHomeBundleUnavailable(AceBundleApplicant bundleApplicant) throws Exception {
		AceBundleNavigationHelper navigationHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		AceBundleLimitedAvailabilityDialog limitedAvailabilityDialog = navigationHelper.navigateToLimitedAvailabilityDialog(bundleApplicant);
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		limitedAvailabilityDialog.verifyLimitedAvailabilityDialogContentWhenBundleNotAvailable(HOME, farmersSoftAssert);
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyLimitedAvailabilityDialogContentHomeBundleAutoRestricted(AceBundleApplicant bundleApplicant) throws Exception {
		List<String> listOfRestrictedZipCodes = new ArrayList<>(Arrays.asList("77022", "77304"));
		Collections.shuffle(listOfRestrictedZipCodes);
		bundleApplicant.getAutoApplicant().setZipCode(listOfRestrictedZipCodes.get(0));
		AceBundleNavigationHelper navigationHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		AceBundleLimitedAvailabilityDialog limitedAvailabilityDialog = navigationHelper.navigateToLimitedAvailabilityDialog(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		limitedAvailabilityDialog.verifyRestrictedLimitedAvailabilityDialogContent("home", fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX, VA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyLimitedAvailabilityDialogContentHomeRestricted(AceBundleApplicant bundleApplicant) throws Exception {
		List<String> listOfRestrictedZipCodes = new ArrayList<>(Arrays.asList("78114", "23116", "22473", "76017"));
		Collections.shuffle(listOfRestrictedZipCodes);
		bundleApplicant.getAutoApplicant().setZipCode(listOfRestrictedZipCodes.get(0));
		AceBundleNavigationHelper navigationHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		AceBundleLimitedAvailabilityDialog limitedAvailabilityDialog = navigationHelper.navigateToLimitedAvailabilityDialog(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		limitedAvailabilityDialog.verifyRestrictedLimitedAvailabilityDialogContent("auto", fsa);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE, enabled = false)
	public void allLOBsRestrictedKnockoutTest(AceBundleApplicant bundleApplicant) throws Exception {
		List<String> listOfRestrictedZipCodes = new ArrayList<>(Arrays.asList("75002", "75479", "75844"));
		Collections.shuffle(listOfRestrictedZipCodes);
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		autoApplicant.setZipCode(listOfRestrictedZipCodes.get(0));
		bundleApplicant.setAutoApplicant(autoApplicant);
		new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToRestricted(bundleApplicant);
		KnockoutInconveniencePage bundleKnockOutPage = new KnockoutInconveniencePage();
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		if (bundleKnockOutPage.isOnKnockOutPage()) {
			bundleKnockOutPage.verifyBundleKnockoutPageContent(NO_BUNDLE, fsa);
		} else {
			fsa.fail("Did not reach knockout page" + NEWLINE);
		}
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void aceBundleAutoRestrictedHomeKnockoutTest(AceBundleApplicant bundleApplicant) throws Exception {
		List<String> listOfRestrictedZipCodes = new ArrayList<>(Arrays.asList("77304"));
		Collections.shuffle(listOfRestrictedZipCodes);
		bundleApplicant.getAutoApplicant().setZipCode(listOfRestrictedZipCodes.get(0));
		AceBundleNavigationHelper navigationHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		navigationHelper.navigateToSpeakToRepresentative(bundleApplicant);
		KnockoutInconveniencePage bundleKnockOutPage = new KnockoutInconveniencePage();
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		if (bundleKnockOutPage.isOnKnockOutPage()) {
			bundleKnockOutPage.verifyBundleKnockoutPageContent(AUTO_HOME_BUNDLE, fsa);
		} else {
			fsa.fail("Did not reach knockout page" + NEWLINE);
		}
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, MT, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateAutoReviewQuotePageWhenSelectedUnfencedPoolForHomeAH(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		setApplicantForUnfencedPool(bundleApplicant);
		AceHRCDwellingCoverageBasePage aceHRCDwellingCoverageBasePage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToHRCReviewDwellingCoveragePage(bundleApplicant);
		aceHRCDwellingCoverageBasePage.scrollAndClickOnContinueButton();
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		QuoteSummaryAutoPage autoQuoteSummaryPage = new QuoteSummaryAutoPage();
		if (autoQuoteSummaryPage.isOnQuoteSummaryAutoPage()) {
			autoQuoteSummaryPage.verifyNotAbleToOfferBundleCardContent(fsa, AUTO);
		} else {
			fsa.fail("Did not reach Auto quote summary page" + NEWLINE);
		}
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, MT, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateAutoReviewQuotePageWhenSelectedUnfencedTrampolineForHome(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		setApplicantForUnfencedTrampoline(bundleApplicant);
		AceHRCDwellingCoverageBasePage aceHRCDwellingCoverageBasePage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToHRCReviewDwellingCoveragePage(bundleApplicant);
		aceHRCDwellingCoverageBasePage.scrollAndClickOnContinueButton();
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		QuoteSummaryAutoPage autoQuoteSummaryPage = new QuoteSummaryAutoPage();
		if (autoQuoteSummaryPage.isOnQuoteSummaryAutoPage()) {
			autoQuoteSummaryPage.verifyNotAbleToOfferBundleCardContent(fsa, AUTO);
		} else {
			fsa.fail("Did not reach Auto quote summary page" + NEWLINE);
		}
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateBundleFlowWhenSelectedTwoOrMoreClaimsAH(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceHRCAddressBasePage aceHRCPropertyTypeBasePage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToAceHRCPropertyQuestionsPage(bundleApplicant);
		aceHRCPropertyTypeBasePage.selectNumberOfPropertyLosses("Two or more");
		aceHRCPropertyTypeBasePage.scrollAndClickOnContinueButton();
		completeBundleFlow(PROPERTY_KNOCKOUT);
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CT, LA, MA, MN, MS, NC, NE, OH, OR, PA, TX, UT, WI, WY}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateBundleFlowWhenSelectedPrimaryResidenceAsNoAH(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		ApplicantAceHome applicantAceHome = bundleApplicant.getHrcApplicant();
		AceHRCAddressBasePage aceHRCPropertyTypeBasePage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToAceHRCPropertyQuestionsPage(bundleApplicant);
		aceHRCPropertyTypeBasePage.selectPrimaryResidence(false);
		aceHRCPropertyTypeBasePage.selectPrimaryResidenceAsNoWithRandomReason(applicantAceHome.getStateCode());
		aceHRCPropertyTypeBasePage.scrollAndClickOnContinueButton();
		if (Arrays.asList(AL, AR, CA, CO, GA, IA, ID, IL, IN, KS, KY, MD, MI, MN, MO, MT, ND, NE, NM, OK, SD, TN, VA, WI, WA, WY).contains(bundleApplicant.getAutoApplicant().getStateCode())) {
			completeBundleFlow(QUOTE_KNOCKOUT);
		} else {
			FarmersSoftAssert fsa = new FarmersSoftAssert();
			fsa.assertTrue(new AceHRCQualityGradeBasePage().isOnQualityGradePage(), "Not primary residence homes allowed to continue in " + bundleApplicant.getAutoApplicant().getStateName());
			fsa.assertAll();
		}
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateHomeChangeCoveragesDeductibleAndPackages(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceHRCAdditionalCoveragesBasePage homeQuoteOptionalCoveragesPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToBundlePropertyOptionalCoveragesPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		homeQuoteOptionalCoveragesPage.validateAdditionalCoveragesTogglesPremium(bundleApplicant.getHrcApplicant(), fsa, false);
		if (bundleApplicant.getAutoApplicant().getStateCode().equals(CA)) {
			homeQuoteOptionalCoveragesPage.clickContinueToFinalWrapupButton(true);
			if (new ThankYouPageAce().quickIsOnThankYouPage()) {
				new AceBundleReviewQuotesPage().verifyBundleReviewQuotePageContent(HOME, bundleApplicant, fsa);
			} else {
				fsa.fail("Thank You page not reached "+ NEWLINE);
			}
		}
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA, IA, MD, ND, TX, WI}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateBWLogoInAutoPagesBundleAHBW(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		AceBundleNavigationHelper navigator = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		AceBundleReviewQuotesPage aceBundleReviewQuotesPage = navigator.navigateToBundleQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		aceBundleReviewQuotesPage.validateBWLogoOnAutoPagesBWBundleFlow(fsa);
		navigator.setResumeFromPage("ContactInfoPage");
		navigator.navigateToBundleQuoteReviewPage(bundleApplicant);
		aceBundleReviewQuotesPage.goToDriverMismatchPageFromBundleReviewPageAndValidateBWLogoOnAutoPages(fsa, bundleApplicant);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateBundleChangesForHomeContactInfoPage(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		boolean continueToEscrow = new Random().nextBoolean();
		if (continueToEscrow) {
			setApplicantForEscrow(bundleApplicant, continueToEscrow);
		}
		AceHomeContactInfoPage hrcPropertyPolicyStartPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToHRCPolicyStartPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		hrcPropertyPolicyStartPage.verifyBundleTextChangesForHRCContactInfoPage(fsa, continueToEscrow);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT_WITH_THREE_VEHICLES,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateBundleChangesForAutoFewMoreThingsPageAHAndNavigateBackToPropertyTypePage(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		Vehicle vehicle1 = autoApplicant.getVehicles().get(0);
		vehicle1.setOwnership("Leased");
		vehicle1.setUseVIN(false);
		vehicle1.setVehicleUsage("Personal");
		Vehicle vehicle2 = autoApplicant.getVehicles().get(1);
		vehicle2.setOwnership("Leased");
		vehicle2.setUseVIN(false);
		vehicle2.setVehicleUsage("Personal");
		Vehicle vehicle3 = autoApplicant.getVehicles().get(2);
		vehicle3.setOwnership("Financed");
		vehicle3.setUseVIN(false);
		vehicle3.setVehicleUsage("Personal");
		autoApplicant.getDiscounts().get(0).setSignalSignup(true);

		bundleApplicant.setAutoApplicant(autoApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToBundleJustAFewMoreThingsPage(bundleApplicant);
		additionalInfoPolicyStartDateOneUI.verifyBundleChangesOnAdditionalInfoPageAuto(fsa, HOME);
        additionalInfoPolicyStartDateOneUI.validateVinIsDisplayedFirstThenLoanLease(fsa);
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        additionalInfoSignalEnrollmentSectionOneUI.validateSignalMessages(fsa);
        additionalInfoSignalEnrollmentSectionOneUI.validateSignalMessagesForEachDriver(fsa);
        additionalInfoSignalEnrollmentSectionOneUI.validateEmailAddressesNotDisplayed(fsa);
		QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
		if (!quoteSummaryAutoPage.isShortcutToPurchaseState(bundleApplicant.getAutoApplicant().getStateCode())) {
			additionalInfoPolicyStartDateOneUI.navigateBack();
    		fsa.assertTrue(new AceHRCAdditionalCoveragesBasePage().isOnBundlePropertyOptionalCoveragesPage(), "Landed on HRC additional coverage page - AH");
    		AceHomeReviewQuotePage aceHomeReviewQuotePage = new AceHomeReviewQuotePage();
    		aceHomeReviewQuotePage.navigateBack();
    		fsa.assertTrue(aceHomeReviewQuotePage.isOnReviewQuotePageHome(true), "Landed on home review quote page - AH");
    		quoteSummaryAutoPage.navigateBack();
    		fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Landed on auto review quote page - AH");
		}
		AceBundleReviewQuotesPage aceBundleReviewQuotesPage = new AceBundleReviewQuotesPage();
		aceBundleReviewQuotesPage.navigateBack();
		fsa.assertTrue(aceBundleReviewQuotesPage.isOnBundleReviewQuotesPage(), "Landed on bundle review quote page - AH");
		AceHRCDwellingCoverageBasePage aceHRCDwellingCoverageBasePage = new AceHRCDwellingCoverageBasePage();
		aceHRCDwellingCoverageBasePage.navigateBack();
		fsa.assertTrue(aceHRCDwellingCoverageBasePage.isOnDwellingCoveragePage(), "Landed on home dwelling coverage page - AH");
		int maxPagesToNavigateBack = 5;
		while (!driver().getCurrentUrl().contains("/home/property-type") && maxPagesToNavigateBack > 0) {
			aceBundleReviewQuotesPage.navigateBack();
			aceBundleReviewQuotesPage.waitForSpinnerToBeGone();
			maxPagesToNavigateBack--;
		}
		AceHRCPropertyTypeBasePage aceHRCPropertyTypeBasePage = new AceHRCPropertyTypeBasePage();
		aceHRCPropertyTypeBasePage.navigateBack();
		fsa.assertTrue(aceHRCPropertyTypeBasePage.isOnPropertyTypePage(), "User is staying on property type page on click of browser back button - AH");
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyLandedOnHomeReviewQuotePageWhenUsingKOVINAH(AceBundleApplicant bundleApplicant) throws Exception {
		boolean continueToBWAuto = new Random().nextBoolean();
		if (continueToBWAuto) {
			modifyApplicantToTriggerBWFlow(bundleApplicant);
		} else {
			applicantAdjustment(bundleApplicant);
		}
		// Set ZHWUA6ZX2NLA18047 VIN for auto KO
		setKOVINInBundleApplicant(bundleApplicant);

		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AceHRCDwellingCoverageBasePage aceHRCDwellingCoverageBasePage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToHRCReviewDwellingCoveragePage(bundleApplicant);
		aceHRCDwellingCoverageBasePage.scrollAndClickOnContinueButton();
		if (isKnockoutExpectedState(bundleApplicant.getAutoApplicant().getStateCode())) {
			AceHomeReviewQuotePage aceHomeReviewQuotePage = new AceHomeReviewQuotePage();
			if (aceHomeReviewQuotePage.isOnReviewQuotePageHome(true)) {
				aceHomeReviewQuotePage.verifyNotAbleToOfferBundleCardContent(fsa, HOME);
			} else {
				fsa.fail("Did not reach home review quote page " + bundleApplicant.getHrcApplicant().getQuoteNumber() + NEWLINE);
			}
		} else {
			fsa.assertTrue(new AceBundleReviewQuotesPage().isOnBundleReviewQuotesPage(), "Bundle review quote page reached");
		}
		fsa.assertAll();
	}

	private boolean isKnockoutExpectedState(String stateCode) {
		return !List.of(AR, CA, GA, IA, ID, MD, MN, MO, MT, ND, NM, OH, OK, OR, SD, TN, TX, UT, VA, WI).contains(stateCode);
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceAutoHomePolicyStartDateInFewMoreThingsPage(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceBundleReviewQuotesPage autoHomeBundleQuoteSummaryPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToBundleQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		autoHomeBundleQuoteSummaryPage.validatePolicyStartDateAutoHomeFewMoreThingsPage(fsa, bundleApplicant);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {VA}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyThankYouPageWhenQuoteIsBindDisabled(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		ApplicantAceHome applicantAceHome = bundleApplicant.getHrcApplicant();
		applicantAceHome.setKeep360Prefill(true);
		bundleApplicant.setHrcApplicant(applicantAceHome);
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		if (autoApplicant.getStateCode().equals(VA)) {
			// Bind disabled when home is more than 1M
			autoApplicant.setZipCode("23229");
			autoApplicant.setResidentAddress("119 Countryside Ln");
			autoApplicant.setCity("Richmond");
			bundleApplicant.setAutoApplicant(autoApplicant);
		}
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		try {
			new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToFinalReviewPage(bundleApplicant);
			fsa.fail("Thank You page not reached "+ NEWLINE);
		} catch (SkipException skipException) {
			String exceptionMessage = skipException.getMessage();
			if (exceptionMessage.contains("Bundling not available")) {
				// no-op
			} else if (exceptionMessage.contains("Binding not available")) {
				new AceBundleReviewQuotesPage().verifyBundleReviewQuotePageContent(HOME, bundleApplicant, fsa);
			} else {
				fsa.fail("Thank You page not reached "+ NEWLINE);
			}
		}
		fsa.assertAll();
	}

	private void completeBundleFlow(String scenario) throws Exception {
		AceBundleLimitedAvailabilityDialog limitedAvailabilityDialog = new AceBundleLimitedAvailabilityDialog();
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		if (limitedAvailabilityDialog.isLimitedAvailabilityDialogDisplayed()) {
			limitedAvailabilityDialog.verifyPropertyLOBNotAvailableLimitedAvailabilityDialogContent(fsa);
			boolean continueToAuto = new Random().nextBoolean();
			if (continueToAuto) {
				testStep("Selecting \"Yes, Continue\" with auto quote");
				limitedAvailabilityDialog.selectYesContinue();
				verifyBundleDiscountHasDroppedAutoReviewQuotePage(HOME, fsa);
			} else {
				testStep("Selecting \"No thank you\" don't want to continue with auto quote");
				limitedAvailabilityDialog.selectNoThanks();
				KnockoutInconveniencePage bundleKnockOutPage = new KnockoutInconveniencePage();
				fsa.assertTrue(bundleKnockOutPage.isOnKnockOutPage(), "Knock out page reached");
				bundleKnockOutPage.verifyBundleKnockoutPageContent(scenario, fsa);

				// Browser back is disabled in KO page validation
				bundleKnockOutPage.navigateBack();
				fsa.assertTrue(driver().getCurrentUrl().contains("/knockout"), "Browser back is disabled in KO page validation");
			}
		} else {
			fsa.fail("Limited availability dialog not displayed");
		}
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT_WITH_INCIDENTS,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceAutoHomeBundleAutoIncidentKnockout(AceBundleApplicant bundleApplicant) throws Exception {
		//Save incident list before it gets cleared
		List<SqlIncident> listOfIncidents = bundleApplicant.getAutoApplicant().getIncidents();
		applicantAdjustment(bundleApplicant);
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		autoApplicant.setIncidents(listOfIncidents);
		autoApplicant.setHaveAccidentOrViolations(true);
		bundleApplicant.setAutoApplicant(autoApplicant);
		// Auto portion is knocked out since there is no BW in these states, but should be able to provide home quote
		AceBundleNavigationHelper navigator = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		navigator.setResumeFromPage("BundlingNotAvailable");
		AceBundleReviewQuotesPage bundleQuoteSummaryPage = navigator.navigateToBundleQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		if (new AceHomeReviewQuotePage().isOnReviewQuotePageHome(true)) {
			bundleQuoteSummaryPage.verifyNotAbleToOfferBundleCardContent(fsa, HOME);
			fsa.assertFalse(bundleQuoteSummaryPage.getDisplayedDiscounts().contains("Auto & Home"), "Auto & Home discount not given");
		} else {
			fsa.fail("Home monoline quote review page not reached");
		}
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceAutoHomeBundleAutoForeignDriverKnockout(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		autoApplicant.setFirstAgeForeignDriverLicense(18);
		autoApplicant.getAdditionalDrivers().forEach(additionalDriver-> additionalDriver.setLicenseToDriveInUSA(NO));
		bundleApplicant.setAutoApplicant(autoApplicant);
		// Auto portion is knocked out since there is no BW in these states, but should be able to provide home quote
		AceBundleNavigationHelper navigator = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		navigator.setResumeFromPage("BundlingNotAvailable");
		AceBundleReviewQuotesPage bundleQuoteSummaryPage = navigator.navigateToBundleQuoteReviewPage(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		fsa.assertTrue(new AceHomeReviewQuotePage().isOnReviewQuotePageHome(true), "Home quote summary page reached");
		bundleQuoteSummaryPage.verifyNotAbleToOfferBundleCardContent(fsa, HOME);
		fsa.assertFalse(bundleQuoteSummaryPage.getDisplayedDiscounts().contains("Auto & Home"), "Auto & Home discount not given");
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,TX})},  dataProviderClass = AceBundleDataProviders.class, groups = {PRODUCTION_VALIDATION})
	public void verifyAceAutoHomeBundleLandedOnOptionalCoveragePageProd(AceBundleApplicant bundleApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		applicantAdjustment(bundleApplicant);
		setVINInBundleApplicantForNonBWAuto(bundleApplicant);
		setDataForProdValidation(bundleApplicant);
		//navigator handles the messaging of getting/not getting to the destination
		new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToBundleQuoteReviewPage(bundleApplicant);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceAutoHomeBundleRetrievedQuoteAllowsMonolineChoice(AceBundleApplicant bundleApplicant) throws Exception {
		AceBundleNavigationHelper navigatorHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		//Randomly pick Farmers or BW auto quote
		if (new Random().nextBoolean()) {
			modifyApplicantToTriggerBWFlow(bundleApplicant);
		} else {
			applicantAdjustment(bundleApplicant);
		}
		AceBundleReviewQuotesPage bundleQuoteSummaryPage = navigatorHelper.navigateToBundleQuoteReviewPage(bundleApplicant);
		if (navigatorHelper.retrieveAceBundleQuote(bundleApplicant, navigatorHelper.getBundleQuoteNumber())) {
			FarmersSoftAssert fsa = new FarmersSoftAssert();
			bundleQuoteSummaryPage.selectStepper(AUTO_INFO);
			new NameAndDobPage().validateBundleFieldsAreDisabledOnRetrieve(bundleApplicant.getAutoApplicant(), fsa);
			if (retrieveQuoteAndGoToBundleReviewPage(bundleApplicant, navigatorHelper, bundleQuoteSummaryPage, fsa)) {
				fsa.assertTrue(bundleQuoteSummaryPage.isOnBundleReviewQuotesPage(), "Retrieved quote navigated to Bundle Quote Summary page");
				//Select Auto monoline and purchase quote
				autoPropertyBundleToMonolineAutoAndPurchase(bundleApplicant, HOME, fsa);
				if (retrieveQuoteAndGoToBundleReviewPage(bundleApplicant, navigatorHelper, bundleQuoteSummaryPage, fsa)) {
					fsa.assertTrue(bundleQuoteSummaryPage.isOnBundleReviewQuotesPage(), "Retrieved quote navigated to Bundle Quote Summary page");
					//Select Home monoline and purchase quote
					autoHomeBundleToMonolineHomeAndPurchase(bundleApplicant, fsa);
					if (retrieveQuoteAndGoToBundleReviewPage(bundleApplicant, navigatorHelper, bundleQuoteSummaryPage, fsa)) {
						fsa.assertTrue(bundleQuoteSummaryPage.isOnBundleReviewQuotesPage(), "Retrieved quote navigated to Bundle Quote Summary page");
					}
				}
			}
			fsa.assertAll();
		}
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyReverseBrightlineLoaderPage(AceBundleApplicant bundleApplicant) throws Exception {
		modifyApplicantToTriggerBWFlow(bundleApplicant);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AceBundleFinalReviewPage finalReviewPage = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToFinalReviewPage(bundleApplicant);
		fsa.assertTrue(finalReviewPage.isOnBristolWest(), "Quote is in Bristol West");
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceAutoHomeBundleFromInterstitialPage(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceBundleNavigationHelper navigatorHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		navigatorHelper.setResumeFromPage("interstitial");
		navigatorHelper.navigateToBundleQuoteReviewPage(bundleApplicant);
	}

	@Skip (skipReason = "This behavior has been deemed unsuitable for CA but may be enabled in the future for other states.")
	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyAceAutoHomeBundleWhenSelectingHomeLOBInLandingPage(AceBundleApplicant bundleApplicant) throws Exception {
		applicantAdjustment(bundleApplicant);
		AceBundleNavigationHelper navigatorHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		navigatorHelper.setResumeFromPage(LOB_HOME);
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		fsa.assertTrue(navigatorHelper.navigateToECheckoutPage(bundleApplicant).isPaymentSuccessfulMessageCorrect(), "Quote completed bind process");
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void verifyHomeQualityGradeDialogPath(AceBundleApplicant bundleApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		applicantAdjustment(bundleApplicant);
		bundleApplicant.getAutoApplicant().setResidentAddress("1550 Calinoma Dr");
		bundleApplicant.getAutoApplicant().setCity("San Jose");
		bundleApplicant.getAutoApplicant().setZipCode("95118");
		bundleApplicant.getHrcApplicant().setAddress("1550 Calinoma Dr");
		bundleApplicant.getHrcApplicant().setCity("San Jose");
		bundleApplicant.getHrcApplicant().setZipCode("95118");
		AceBundleNavigationHelper navigatorHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		AceHRCJustAFewMoreThingsBasePage propertyJFMTPage = navigatorHelper.navigateToBundlePropertyJustAFewMoreThingsPage(bundleApplicant);
		propertyJFMTPage.fillOutBundleJFMTPageAndContinue(bundleApplicant.getHrcApplicant(), HOME);
		navigatorHelper.setResumeFromPage(AceHRCQualityGradeBasePage.class.getSimpleName());
		try {
			navigatorHelper.navigateToFinalReviewPage(bundleApplicant);
		} catch (IllegalStateException e) {
			fsa.assertEquals(new KnockoutInconveniencePage().getPageDescription(), "We are unable to complete your quote online at this time. Please contact us to see if you qualify.",
					"Quote requires special attention knockout page reached");
		} finally {
			fsa.assertAll();
		}
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = ACE_STABILITY)
	public void autoHomeBundleEnvironmentStabilityTest(AceBundleApplicant bundleApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		applicantAdjustment(bundleApplicant);
		setVINInBundleApplicantForNonBWAuto(bundleApplicant);
		new AceBundleNavigationHelper(AUTO_HOME_BUNDLE).navigateToBundlePropertyOptionalCoveragesPage(bundleApplicant);
		fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CA, CO, CT, FL, IA, ID, IL, IN, KS, KY, LA, MD, MI, MO, MS, MT, NM, NV, OH, OK, OR, TN, TX, VA, WA, WI})},
			dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateMLBCampaignFunctionalityRefreshTest(AceBundleApplicant bundleApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AceBundleNavigationHelper navigatorHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		QuoteSummaryAutoPage quoteSummaryAutoPage = navigateToBundleQuoteSummaryForMLBCampaign(bundleApplicant, navigatorHelper, fsa);
        //user no longer should see the pop up if they refresh the page
        driver().navigate().refresh();
        fsa.assertTrue(!quoteSummaryAutoPage.is_TL_or_MLB_SourceCodePopUpPresent(), "MLB sweepstakes dialog not found after refresh");
        fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CA, CO, CT, FL, IA, ID, IL, IN, KS, KY, LA, MD, MI, MO, MS, MT, NM, NV, OH, OK, OR, TN, TX, VA, WA, WI})},
			dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateMLBCampaignFunctionalityBackNavigationTest(AceBundleApplicant bundleApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AceBundleNavigationHelper navigatorHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		QuoteSummaryAutoPage quoteSummaryAutoPage = navigateToBundleQuoteSummaryForMLBCampaign(bundleApplicant, navigatorHelper, fsa);
        // user should not see the pop up if they navigate back
        quoteSummaryAutoPage.selectStepper("Property info");
    	navigatorHelper.navigateToBundleQuoteReviewPageUsingDefaults();
        fsa.assertTrue(!quoteSummaryAutoPage.is_TL_or_MLB_SourceCodePopUpPresent(), "MLB sweepstakes dialog not found after navigating back and progressing to bundle summary");
        fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CA, CO, CT, FL, IA, ID, IL, IN, KS, KY, LA, MD, MI, MO, MS, MT, NM, NV, OH, OK, OR, TN, TX, VA, WA, WI})},
			dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void validateMLBCampaignFunctionalityRetrievalTest(AceBundleApplicant bundleApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		AceBundleNavigationHelper navigatorHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		QuoteSummaryAutoPage quoteSummaryAutoPage = navigateToBundleQuoteSummaryForMLBCampaign(bundleApplicant, navigatorHelper, fsa);
        // User should not see the pop up if they retrieve the quote
        if (navigatorHelper.retrieveAceBundleQuote(bundleApplicant, navigatorHelper.getBundleQuoteNumber())) {
        	navigatorHelper.navigateToBundleQuoteReviewPageUsingDefaults();
        	fsa.assertTrue(!quoteSummaryAutoPage.is_TL_or_MLB_SourceCodePopUpPresent(), "MLB sweepstakes dialog not found after quote is retrieved and bundle summary is reached");
        }
        fsa.assertAll();
	}

	@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
			attributes = {@CustomAttribute(name = CO)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)
	public void autoHomeBundleWildfireMitigationTest(AceBundleApplicant bundleApplicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		applicantAdjustment(bundleApplicant);
		List<String> wildfireMitigationList = List.of("within 5 ft", "within 30 ft", "within 100 ft");
		bundleApplicant.getHrcApplicant().setWildFireRisk(wildfireMitigationList.get(new Random().nextInt(wildfireMitigationList.size())));
		AceBundleNavigationHelper navigatorHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
		AceBundleReviewQuotesPage bundleReviewQuotePage = navigatorHelper.navigateToBundleQuoteReviewPage(bundleApplicant);
		fsa.assertTrue(bundleReviewQuotePage.getPropertyDiscounts().contains("Wildfire mitigation"), "Wildfire mitigation discount given in bundle quote summary");
		navigatorHelper.setResumeFromPage(bundleReviewQuotePage.getClass().getSimpleName());
		navigatorHelper.navigateToECheckoutPage(bundleApplicant);
		fsa.assertAll();
	}

	private QuoteSummaryAutoPage navigateToBundleQuoteSummaryForMLBCampaign(AceBundleApplicant bundleApplicant, AceBundleNavigationHelper navigatorHelper, FarmersSoftAssert fsa) throws Exception {
		// Start the MLB flow with the URL
		applicantAdjustment(bundleApplicant);
		String url = String.format("%s?Lob=AutoHome&Zip_Code=%s&source_indicator=ML&source_id=MLB0001", Property.getUri(), bundleApplicant.getAutoApplicant().getZipCode());
		driver().get(url);
		Reporter.pass("Navigated to URL with MLB source code: " + url);
		InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
		if (interstitialBundlePage.isOnInterstitialBundlePage()) {
			interstitialBundlePage.continueWithBundle();
		}
		navigatorHelper.setResumeFromPage(new NameAndDobPage().getClass().getSimpleName());
		navigatorHelper.navigateToBundleQuoteReviewPage(bundleApplicant);
		QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        fsa.assertTrue(quoteSummaryAutoPage.is_TL_or_MLB_SourceCodePopUpPresent(), "MLB sweepstakes dialog found");
        quoteSummaryAutoPage.validateContentForMLBSourceCodePopUp(fsa);
        return quoteSummaryAutoPage;
	}

	private void setApplicantForEscrow(AceBundleApplicant bundleApplicant, boolean isInEscrow){
		ApplicantAceHome applicantAceHome = bundleApplicant.getHrcApplicant();
		applicantAceHome.setNewlyOwned(true);
		applicantAceHome.setInEscrow(isInEscrow);
		bundleApplicant.setHrcApplicant(applicantAceHome);
	}

	private void setApplicantForUnfencedPool(AceBundleApplicant bundleApplicant){
		ApplicantAceHome applicantAceHome = bundleApplicant.getHrcApplicant();
		applicantAceHome.setSwimmingPool("Unfenced");
		bundleApplicant.setHrcApplicant(applicantAceHome);
	}

	private void setApplicantForUnfencedTrampoline(AceBundleApplicant bundleApplicant){
		ApplicantAceHome applicantAceHome = bundleApplicant.getHrcApplicant();
		applicantAceHome.setTrampoline("Unfenced");
		bundleApplicant.setHrcApplicant(applicantAceHome);
	}
}
