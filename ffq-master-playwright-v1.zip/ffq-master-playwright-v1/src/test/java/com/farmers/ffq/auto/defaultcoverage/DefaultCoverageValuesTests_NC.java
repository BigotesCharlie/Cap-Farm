package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class DefaultCoverageValuesTests_NC extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_30K60K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "NC_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_35K70K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "NC_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_50K100K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "NC_50K100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_100K200K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "NC_100K200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_100K300K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "NC_100K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_250K500K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "NC_250K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_500K500K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "NC_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_500K1000K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "NC_500K1000K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_85K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=No", "NC_85K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_100K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "NC_100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_200K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "NC_200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_300K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "NC_300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_500K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "NC_500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NC), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NC_1000K(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "NC_1000K_");
    }

}
