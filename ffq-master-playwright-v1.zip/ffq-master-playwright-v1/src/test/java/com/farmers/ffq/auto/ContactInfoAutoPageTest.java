package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;

import static com.farmers.ffq.common.enums.AutoDiscounts.*;
import static com.farmers.ffq.utils.GlobalVariables.*;


public class ContactInfoAutoPageTest extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}),
    		@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NC, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})
    public void validateContactInfoPage(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoAutoPage.validatePageContent(applicant, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}),
    		@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CO, FL, ID, KS, MO, NC, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})
    public void validateContactInfoPageErrorMessages(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoAutoPage.validateErrorMessages(applicant, fsa);
        fsa.assertAll();

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}),
    		@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NC, NJ, NM, OK, PA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})
    public void validateEarlyShoppingDiscountFunctionality(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoAutoPage.validateEarlyShopperDiscount(fsa);
        fsa.assertAll();

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}),
    		@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NC, NJ, NM, OK, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})
    public void validateBundleSaveSectionHomeOwnerCheckboxChecked(AutoApplicant applicant) throws Exception {
        //update the date to avoid possible bw navigation
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        // making sure applicant is homeowner
        applicant.getDiscounts().forEach(each -> each.setOwnOrRentHome("Own a home"));
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoAutoPage.validateBundleSaveSection(applicant, fsa);
        contactInfoAutoPage.fillOutPrimaryResidenceInsuranceSection(applicant.getStateCode().equals(MA));
        contactInfoAutoPage.enterEmailAndPhoneNumber(applicant.getEmail(), applicant.getPhoneNumber());
        //contactInfoAutoPage.processConsentSelection("Farmers");
        QuoteSummaryAutoPage quoteSummaryAutoPage = contactInfoAutoPage.navigateFromContactInfoPageToQuotePage(true);
        fsa.assertTrue(quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(AUTO_HOME.getName()), "Discount should include " + AUTO_HOME.getName() + " ,but it does not at the moment");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}),
    		@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NC, NJ, NM, OK, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})
    public void validateBundleSaveSectionHomeOwnerCheckboxCheckedForCondo(AutoApplicant applicant) throws Exception {
        //update the date to avoid possible bw navigation
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        // making sure applicant is homeowner
        applicant.getDiscounts().forEach(each -> each.setOwnOrRentHome("Own a home"));
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoAutoPage.selectBundle(true, "Condo");
        contactInfoAutoPage.fillOutPrimaryResidenceInsuranceSection(applicant.getStateCode().equals(MA));
        contactInfoAutoPage.enterEmailAndPhoneNumber(applicant.getEmail(), applicant.getPhoneNumber());
        //contactInfoAutoPage.processConsentSelection("Farmers");
        QuoteSummaryAutoPage quoteSummaryAutoPage = contactInfoAutoPage.navigateFromContactInfoPageToQuotePage(true);
        fsa.assertTrue(quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(AUTO_HOME.getName()), "Discount should include " + AUTO_HOME.getName() + " ,but it does not at the moment");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}),
    		@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NC, NM, OK, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})
    public void validateBundleSaveSectionHomeOwnerCheckboxNotChecked(AutoApplicant applicant) throws Exception {
        //update the date to avoid possible bw navigation
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        //making sure that home owner checkbox is not check by updating the data
        applicant.getDiscounts().forEach(each -> each.setOwnOrRentHome("Rent a home"));
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoAutoPage.validateBundleSaveSection(applicant, fsa);
        contactInfoAutoPage.fillOutPrimaryResidenceInsuranceSection(applicant.getStateCode().equals(MA));
        contactInfoAutoPage.enterEmailAndPhoneNumber(applicant.getEmail(), applicant.getPhoneNumber());
        //contactInfoAutoPage.processConsentSelection("Farmers");
        QuoteSummaryAutoPage quoteSummaryAutoPage = contactInfoAutoPage.navigateFromContactInfoPageToQuotePage(true);
        fsa.assertTrue(quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(AUTO_HOME.getName()), "Discount should include " + AUTO_HOME.getName() + " ,but it does not at the moment");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"),
    		@CustomAttribute(name = MA)}, groups = {FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, CONTACT_INFO})
    public void validatePrimaryResidenceSection(AutoApplicant applicant) throws Exception {
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(contactInfoAutoPage.isOnContactInfoAutoPage(), "User landed on the Contact Info Auto Page");
        fsa.assertTrue(!contactInfoAutoPage.getPrimaryResidenceInsuranceRadioButtons().isEmpty(), "For MA state, primary residence section should appear");
        if (contactInfoAutoPage.isADATestingEnabled()) {
            contactInfoAutoPage.clickContactInfoPageCTAButton();
            performADATesting(contactInfoAutoPage.getClass().getSimpleName() + "_PrimaryResidenceSectionPresent", MARKETING_IT, ACE_AUTO);
            return;
        }
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}),
    		@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})
    public void validateDefaultBundleSelected_MDMdata(AutoApplicant applicant) throws Exception {
        applicant.setZipCode("92649");
        applicant.setCity("Huntington Beach");
        applicant.setFirstName("BARBARA");
        applicant.setLastName("MUELLER");
        applicant.setDateOfBirth("09-01-1946");
        applicant.setResidentAddress("17132 Camelot Cir");
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.validateDefaultBundleOption_MDMdata(applicant);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}),
            @CustomAttribute(name = INCLUDED_STATES, values = {MN, NV, OH, IN, MD, IA, KS})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONTACT_INFO})
    public void validateBusinessBundleDiscountIsApplied(AutoApplicant applicant) throws Exception {
        //update the date to avoid possible bw navigation
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        //making sure that home owner checkbox is not check by updating the data

        applicant.getDiscounts().forEach(each -> {
            each.setBusinessInsurance(true);
            each.setRentersInsurance(false);
            each.setHomeInsurance(false);
            each.setMotorcycleInsurance(true);
            each.setCondoInsurance(false);
            each.setValueTermLifeInsurance(true);
            each.setUmbrellaInsurance(true);
            each.setRecreationalBoatWatercraftInsurance(true);
            each.setMotorHome(false);

        });
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        List<String> displayedDiscounts = quoteSummaryAutoPage.getDisplayedDiscounts();
        Log.info("Displayed Discounts: " + displayedDiscounts.toString());
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), quoteSummaryAutoPage.isOnFarmers(), "User is not able to land on the Quote Summary Auto Page for Farmers");
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        softAssert.assertTrue(displayedDiscounts.contains(AUTO_BUSINESS.getName()), "Discount should include " + AUTO_BUSINESS.getName());
        softAssert.assertTrue(displayedDiscounts.contains(AUTO_LIFE.getName()), "Discount should include " + AUTO_LIFE.getName());
        softAssert.assertTrue(displayedDiscounts.contains(AUTO_UMBRELLA.getName()), "Discount should include " + AUTO_UMBRELLA.getName());
        softAssert.assertTrue(displayedDiscounts.contains(AUTO_MOTORCYCLE.getName()), "Discount should include " + AUTO_MOTORCYCLE.getName());
        softAssert.assertTrue(displayedDiscounts.contains(AUTO_WATERCRAFT.getName()), "Discount should include " + AUTO_WATERCRAFT.getName());
        softAssert.assertAll();
    }

}