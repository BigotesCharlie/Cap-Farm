package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;
import static com.farmers.ffq.utils.GlobalVariables.IN;

public class BWDefaultCoverageValuesTests_IN extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = IN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_None_Unk_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        //This is going to avoid BW condition based on the foreign driver's license
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        applicant.setFirstAgeForeignDriverLicense(0);
        defaultCoverageTestForBW(applicant, "coverageAmount=None/Unk&umbrella=No", "IN_None_Unk_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = IN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_IN_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=25/50&umbrella=No", "IN_25K50K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = IN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_IN_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=30/60&umbrella=No", "IN_30K60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = IN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_IN_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35/70&umbrella=No", "IN_35K70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = IN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_IN_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=50/100&umbrella=No", "IN_50K100K_");
    }


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = IN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_IN_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/200&umbrella=No", "IN_100K200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = IN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_IN_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/300&umbrella=No", "IN_100K300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = IN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_IN_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=250/500&umbrella=No", "IN_250K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = IN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_IN_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/500&umbrella=No", "IN_500K500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = IN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_IN_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500&umbrella=No", "IN_500K_");
    }

}
