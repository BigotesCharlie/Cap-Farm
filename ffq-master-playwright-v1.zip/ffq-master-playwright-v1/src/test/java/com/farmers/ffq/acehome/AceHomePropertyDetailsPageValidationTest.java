package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCNameAndDobBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyDetailsBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.stream.Stream;

import static com.farmers.ffq.ace.hrc.common.AceHRCPropertyDetailsBasePage.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomePropertyDetailsPageValidationTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE})
    public void testPropertyDetailsPageHome(ApplicantAceHome applicant) throws Exception {
        validatePropertyDetailsPage(applicant, HOME);
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE})
    public void testPropertyDetailsPageTownHome(ApplicantAceHome applicant) throws Exception {
        validatePropertyDetailsPage(applicant, TOWNHOME);
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME})
    public void testPropertyDetailsPageDuplex(ApplicantAceHome applicant) throws Exception {
        validatePropertyDetailsPage(applicant, DUPLEX);
    }

    private void validatePropertyDetailsPage(ApplicantAceHome applicant, String propertyType) throws Exception {
        AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
        AceHRCNameAndDobBasePage nameAndDobBasePage = navigator.navigateToAceHomeNameAndDobPage(applicant);
        navigator.setResumeFromPage(NAME_AND_DOB_PAGE);
        if (nameAndDobBasePage.isQualityGradePageAvailable()) {
            navigator.navigateToHRCPropertyDetailsPage(applicant, LOB_HOME, propertyType);
        } else {
            navigator.navigateToHRCPropertyDetailsQualityGradePage(applicant, LOB_HOME, propertyType);
        }
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
        AppStore appStore = propertyDetailsPage.getSessionStorageAppStore();

        fsa.assertTrue(propertyDetailsPage.isPageTitleDisplayed(), "Property Details page - Title is displayed");
        fsa.assertTrue(propertyDetailsPage.isPageTitleInViewport(), "Property Details page - page title is in Viewport");
        fsa.assertTrue(propertyDetailsPage.isPageSubtitleDisplayed(), "Property Details page - Subtitle is displayed.");
        String propertyAddress = appStore.getHome().getAddressForm().getFields().get(0).getAddress().toUpperCase() +
                ", " + appStore.getHome().getAddressForm().getFields().get(0).getCity().toUpperCase() +
                ", " + appStore.getHome().getAddressForm().getFields().get(0).getState().toUpperCase() +
                SPACE + appStore.getHome().getAddressForm().getFields().get(0).getZipCode().toUpperCase();

        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsAddress().toUpperCase(), propertyAddress, "Property Details page - Address, City, State, Zip match.");
        propertyDetailsPage.validatePageLinksText(fsa, ENTER_INFO);
        propertyDetailsPage.validateAgentSection(fsa, PROPERTY_DETAILS, applicant.getAgentId(), HOME);
        boolean quoteDisplayed = propertyDetailsPage.isNewFlowEnabledState(applicant.getStateCode());
        propertyDetailsPage.validateQuoteText(PROPERTY_DETAILS, applicant.getQuoteNumber(), fsa, quoteDisplayed);
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue(YEAR_BUILT),
                appStore.getHome().getPropertyForm().getFields().get(0).getYearBuilt(), "Property Details page - Year built.");
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue(TOTAL_SQ_FT).replaceAll("\\D", EMPTY_STRING),
                appStore.getHome().getPropertyForm().getFields().get(0).getSqFeet(), "Property Details page - Total square footage.");
        if (appStore.getHome().getPropertyDetailsForm() == null) {
            propertyDetailsPage.enterNotPrefilledPropertyDetails(applicant);
            appStore = propertyDetailsPage.getSessionStorageAppStore();
        }
        String stories = appStore.getHome().getPropertyDetailsForm().getFieldValueByName(NUMBER_OF_STORIES);
        stories = (stories.matches("^\\d.*") ? stories.split(SPACE)[0] : stories);
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue(STORIES), stories, "Property Details page - Number of Stories.");
        String bathrooms = appStore.getHome().getPropertyDetailsForm().getFieldValueByName(NUMBER_OF_BATHROOM);
        if (bathrooms.contains(COMMA)) {
            bathrooms = Integer.toString(Stream.of(bathrooms.split(COMMA)).map(String::strip).mapToInt(Integer::parseInt).sum());
        }
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue(BATHROOMS), bathrooms, "Property Details page - Number of Bathrooms.");
        String firePlaces = appStore.getHome().getPropertyDetailsForm().getFieldValueByName("firePlaces");
        firePlaces = (firePlaces == null) ? "None" : firePlaces;
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue(FIREPLACE), firePlaces, "Property Details page - Fireplace.");
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue(FLOORS),
                appStore.getHome().getPropertyDetailsForm().getFieldValueByName(FLOOR_COVERINGS), "Property Details page - Floors.");
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue(GARAGE_STYLE),
                appStore.getHome().getPropertyDetailsForm().getFieldValueByName("garageStyle"), "Property Details page - Garage style.");
        if (propertyDetailsPage.isPropertyDetailsFieldDisplayed(GARAGE_CARPORT)) {
            String garageCarport = appStore.getHome().getPropertyDetailsForm().getFieldValueByName("garageCarport");
            garageCarport = (garageCarport == null) ? "---" : garageCarport;
            if (Integer.parseInt(garageCarport.substring(0,1)) > 3) {
                garageCarport = "4 or more cars";
            }
            fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue(GARAGE_CARPORT), garageCarport, "Property Details page - Garage / carport.");
        }
        if (!propertyType.equals(CONDO)) {
            String foundationType = appStore.getHome().getPropertyDetailsForm().getFieldValueByName("foundationType");
            String exteriorWallFinish = appStore.getHome().getPropertyDetailsForm().getFieldValueByName("exteriorWallFinish");
            exteriorWallFinish = (exteriorWallFinish.equals(EMPTY_STRING)) ? "---" : exteriorWallFinish;
            fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue(EXTERIOR_WALL_FINISH), exteriorWallFinish, "Property Details page - Exterior wall finish.");
            fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue(FOUNDATION_TYPE), foundationType, "Property Details page - Foundation type.");
            if (foundationType.equals(BASEMENT) || foundationType.equals("Shallow basement")) {
                String finishedBasement = propertyDetailsPage.getFinishedBasement();
                finishedBasement = finishedBasement.equals(ZERO) ? "Unfinished" : finishedBasement + "% finished";
                fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue(FINISHED_BASEMENT), finishedBasement, "Property Details page - Finished basement.");
            } else {
                fsa.assertFalse(propertyDetailsPage.isPropertyDetailsFieldDisplayed(FINISHED_BASEMENT), "Property Details page - Finished basement is not displayed.");
            }
            fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue(ROOF_COVER),
                    appStore.getHome().getPropertyDetailsForm().getFieldValueByName("roofCover"), "Property Details page - Roof cover.");
        }
        if (propertyType.equals(TOWNHOME)) {
            fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue(TYPE_OF_HOME),
                    appStore.getHome().getPropertyDetailsForm().getFieldValueByName("typeOfHome"), "Property Details page - Type of Home.");
        }

        propertyDetailsPage.validateDiscounts(PROPERTY_DETAILS, applicant, propertyType, fsa);

        // check if browser forward button is disabled
        propertyDetailsPage.validateBrowserForwardButtonIsDisabled(fsa,"property-details");
        propertyDetailsPage.validateQuoteText(PROPERTY_DETAILS, applicant.getQuoteNumber(), fsa, quoteDisplayed);
        fsa.assertAll("Validate Ace Home (" + propertyType + ") Property Details Page.");

    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE})
    public void testPropertyDetailsPageEditModalHome(ApplicantAceHome applicant) throws Exception {
        validatePropertyDetailsPageEditModal(applicant, HOME);
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME})
    public void testPropertyDetailsPageEditModalTownHome(ApplicantAceHome applicant) throws Exception {
        validatePropertyDetailsPageEditModal(applicant, TOWNHOME);
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_PROPERTY_DETAILS_PAGE})
    public void testPropertyDetailsPageEditModalDuplex(ApplicantAceHome applicant) throws Exception {
        validatePropertyDetailsPageEditModal(applicant, DUPLEX);
    }

    private void validatePropertyDetailsPageEditModal(ApplicantAceHome applicant, String propertyType) throws Exception {
        final String PLEASE_REVIEW = "Please review";
        AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
        AceHRCNameAndDobBasePage nameAndDobBasePage = navigator.navigateToAceHomeNameAndDobPage(applicant);
        navigator.setResumeFromPage(NAME_AND_DOB_PAGE);
        if (nameAndDobBasePage.isQualityGradePageAvailable()) {
            navigator.navigateToHRCPropertyDetailsPage(applicant, LOB_HOME, HOME);
        } else {
            navigator.navigateToHRCPropertyDetailsQualityGradePage(applicant, LOB_HOME, HOME);
        }
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
        AppStore appStore = propertyDetailsPage.getSessionStorageAppStore();

        fsa.assertTrue(propertyDetailsPage.isPageTitleDisplayed(), "Property Details page - Title is displayed");
        fsa.assertTrue(propertyDetailsPage.isPageSubtitleDisplayed(), "Property Details page - Subtitle is displayed.");
        String propertyAddress = appStore.getHome().getAddressForm().getFields().get(0).getAddress().toUpperCase() +
                ", " + appStore.getHome().getAddressForm().getFields().get(0).getCity().toUpperCase() +
                ", " + appStore.getHome().getAddressForm().getFields().get(0).getState().toUpperCase() +
                SPACE + appStore.getHome().getAddressForm().getFields().get(0).getZipCode().toUpperCase();
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsAddress().toUpperCase(), propertyAddress, "Property Details page - Address, City, State, Zip match.");
        propertyDetailsPage.validatePageLinksText(fsa, ENTER_INFO);
        propertyDetailsPage.clickEditDetailsButton();
        appStore = propertyDetailsPage.getSessionStorageAppStore();
        applicant.setYearBuilt(Integer.parseInt(appStore.getHome().getPropertyForm().getFields().get(0).getYearBuilt()));
        applicant.setSquareFeet(appStore.getHome().getPropertyForm().getFields().get(0).getSqFeet());

        fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(YEAR_BUILT),
                appStore.getHome().getPropertyForm().getFields().get(0).getYearBuilt(), "Property Details page - Edit Modal - Year built.");
        fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(TOTAL_SQ_FT),
                appStore.getHome().getPropertyForm().getFields().get(0).getSqFeet(), "Property Details page - Edit Modal - Total finished square footage.");
        if (appStore.getHome().getPropertyDetailsForm() != null) {
            String stories = appStore.getHome().getPropertyDetailsForm().getFieldValueByName("numberOfStories");
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(STORIES), stories,
                    "Property Details page - Edit Modal - Number of Stories.");
            String bathrooms = appStore.getHome().getPropertyDetailsForm().getFieldValueByName(NUMBER_OF_BATHROOM);
            if (bathrooms.contains(COMMA)) {
                bathrooms = Integer.toString(Stream.of(bathrooms.split(COMMA)).map(String::strip).mapToInt(Integer::parseInt).sum());
            }
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(BATHROOMS), bathrooms, "Property Details page - Edit Modal - Number of Bathrooms.");
            String fireplaces = appStore.getHome().getPropertyDetailsForm().getFieldValueByName("firePlaces");
            fireplaces = (fireplaces == null) ? NONE : fireplaces;
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(FIREPLACE), fireplaces, "Property Details page - Edit Modal - Fireplace.");
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(FLOORS),
                    appStore.getHome().getPropertyDetailsForm().getFieldValueByName("floorCoverings"), "Property Details page - Edit Modal - Floors.");
            String garageStyle = appStore.getHome().getPropertyDetailsForm().getFieldValueByName("garageStyle");
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(GARAGE_STYLE), garageStyle, "Property Details page - Edit Modal - Garage style.");
            String garageCarport = appStore.getHome().getPropertyDetailsForm().getFieldValueByName("garageCarport");
            if (propertyDetailsPage.isPropertyDetailsFieldDisplayed(GARAGE_CARPORT)) {
                garageCarport = (garageCarport == null) ? EMPTY_STRING : garageCarport;
                if (Integer.parseInt(garageCarport.substring(0, 1)) > 3) {
                    garageCarport = "4 or more cars";
                }
                if (garageStyle.equals(NO_GARAGE)) {
                    fsa.assertFalse(propertyDetailsPage.isEditModalPropertyDetailsFieldDisplayed(GARAGE_CARPORT), "Property Details page - Edit Modal - Garage carport is not displayed.");
                } else {
                    fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(GARAGE_CARPORT), garageCarport, "Property Details page - Edit Modal - Garage carport.");
                }
            }
            String exteriorWallFinish = appStore.getHome().getPropertyDetailsForm().getFieldValueByName("exteriorWallFinish");
            exteriorWallFinish = exteriorWallFinish.equals(EMPTY_STRING) ? "Please review" : exteriorWallFinish;
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(EXTERIOR_WALL_FINISH), exteriorWallFinish, "Property Details page - Edit Modal - Exterior wall finish.");
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(FOUNDATION_TYPE),
                    appStore.getHome().getPropertyDetailsForm().getFieldValueByName("foundationType"), "Property Details page - Edit Modal - Foundation type.");
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(ROOF_COVER),
                    appStore.getHome().getPropertyDetailsForm().getFieldValueByName("roofCover"), "Property Details page - Edit Modal - Roof cover.");
            if (propertyType.equals(TOWNHOME)) {
                fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(TYPE_OF_HOME),
                        appStore.getHome().getPropertyDetailsForm().getFieldValueByName("typeOfHome"), "Property Details page - Type of Home.");
            }
            propertyDetailsPage.validateEditYearBuilt(String.valueOf(appStore.getHome().getPropertyForm().getFields().get(0).getYearBuilt()), fsa);
            propertyDetailsPage.validateEditTotalSquareFoot(appStore.getHome().getPropertyForm().getFields().get(0).getSqFeet(), fsa);

            propertyDetailsPage.validateEditNumberOfStories(stories, fsa);
            propertyDetailsPage.validateEditBathrooms(appStore.getHome().getPropertyDetailsForm().getFieldValueByName(NUMBER_OF_BATHROOM), fsa);
            propertyDetailsPage.validateEditFireplace(appStore.getHome().getPropertyDetailsForm().getFieldValueByName("firePlaces"), fsa);
            propertyDetailsPage.validateEditFloors(appStore.getHome().getPropertyDetailsForm().getFieldValueByName("floorCoverings"), fsa, applicant.getStateCode());
            propertyDetailsPage.validateEditGarageStyle(garageStyle, fsa);
            if (!garageStyle.equals(NO_GARAGE)) {
                propertyDetailsPage.validateEditGarageCarport(garageCarport, fsa);
            }
            propertyDetailsPage.validateEditExteriorWallFinish(appStore.getHome().getPropertyDetailsForm().getFieldValueByName("exteriorWallFinish"), fsa);
            String foundationType = appStore.getHome().getPropertyDetailsForm().getFieldValueByName("foundationType");
            propertyDetailsPage.validateEditFoundationType(foundationType, fsa);
            if (foundationType.contains(BASEMENT) || foundationType.contains("basement")) {
                propertyDetailsPage.validateEditFinishedBasement(appStore.getHome().getPropertyDetailsForm().getFieldValueByName("finishedPercentOfLowestLevel"), fsa);
            }
            propertyDetailsPage.validateEditRoofCover(appStore.getHome().getPropertyDetailsForm().getFieldValueByName("roofCover"), fsa);
            propertyDetailsPage.validateEditTypeOfHome(appStore.getHome().getPropertyDetailsForm().getFieldValueByName("typeOfHome"), fsa);
        } else {
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(STORIES), PLEASE_REVIEW,
                    "Property Details page - Edit Modal - Number of Stories (no property details in the appStore).");
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(BATHROOMS), PLEASE_REVIEW,
                    "Property Details page - Edit Modal - Number of Bathrooms (no property details in the appStore).");
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(FIREPLACE), NONE,
                    "Property Details page - Edit Modal - Fireplace (no property details in the appStore).");
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(FLOORS), PLEASE_REVIEW,
                    "Property Details page - Edit Modal - Floors (no property details in the appStore).");
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(GARAGE_STYLE), PLEASE_REVIEW,
                    "Property Details page - Edit Modal - Garage style (no property details in the appStore).");
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(EXTERIOR_WALL_FINISH), PLEASE_REVIEW,
                    "Property Details page - Edit Modal - Exterior wall finish (no property details in the appStore).");
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(FOUNDATION_TYPE), PLEASE_REVIEW,
                    "Property Details page - Edit Modal - Foundation type (no property details in the appStore).");
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(ROOF_COVER), PLEASE_REVIEW,
                    "Property Details page - Edit Modal - Roof cover (no property details in the appStore).");
            fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue(TYPE_OF_HOME), PLEASE_REVIEW,
                    "Property Details page - Type of Home (no property details in the appStore).");
            propertyDetailsPage.validateEditYearBuilt(String.valueOf(appStore.getHome().getPropertyForm().getFields().get(0).getYearBuilt()), fsa);
            propertyDetailsPage.validateEditTotalSquareFoot(appStore.getHome().getPropertyForm().getFields().get(0).getSqFeet(), fsa);
            propertyDetailsPage.validateEditNumberOfStories("0", fsa);
            propertyDetailsPage.validateEditBathrooms("0,0,0,0", fsa);
            propertyDetailsPage.validateEditFireplace(NONE, fsa);
            propertyDetailsPage.validateEditFloors(NONE, fsa, applicant.getStateCode());
            propertyDetailsPage.validateEditGarageStyle(NONE, fsa);
            propertyDetailsPage.validateEditExteriorWallFinish(NONE, fsa);
            propertyDetailsPage.validateEditFoundationType(NONE, fsa);
            propertyDetailsPage.validateEditFinishedBasement(null, fsa);
            propertyDetailsPage.validateEditRoofCover(NONE, fsa);
            propertyDetailsPage.validateEditTypeOfHome(NONE, fsa);
        }
        propertyDetailsPage.closeSideSheetByEscKey(fsa);

        fsa.assertAll("Validate Ace Home Property Details - Edit " + propertyType + " details modal fields.");
    }

}

