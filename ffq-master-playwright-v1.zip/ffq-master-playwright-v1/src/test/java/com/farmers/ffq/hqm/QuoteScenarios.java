package com.farmers.ffq.hqm;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.PrefillResponseHQM;
import com.farmers.ffq.datatransferobjects.hqm.QuoteRateHQM;
import com.farmers.ffq.datatransferobjects.hqm.StaticContentHQM;
import com.farmers.ffq.hqm.pages.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.Mailinator;
import com.farmers.ffq.utils.MixpanelApiHelper;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Quote Scenarios - Home Quote Modernization (HQM).
 */
public class QuoteScenarios extends AutomationFramework {

    private static final Double quoteDelta = 0.30; // quote price fluctuation delta max (used when no Postgres connection)

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_E2E_REGRESSION, HQM_ALL})
    public void hqmNewQuote(ApplicantHQM applicant) throws Exception {
        createNewHqmQuote(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_SMOKE, HQM_ALL})
    public void smokeHqmNewQuote(ApplicantHQM applicant) throws Exception {
        createNewHqmQuote(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {PEWC})
    public void hqmPEWCScreen(ApplicantHQM applicant) throws Exception {
    	applicant.setKeep360Prefill(false);
    	createNewHqmQuote(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = "randomStatesByGroup", groups = {HQM_SMOKE})
    public void smokeHqmRandomStates(ApplicantHQM applicant) throws Exception {
        createNewHqmQuote(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_E2E_MOBILE, HQM_ALL})
    public void hqmMobileQuote(ApplicantHQM applicant) throws Exception {
        createNewHqmQuote(applicant, MOBILE_BROWSER);
    }

    private void createNewHqmQuote(ApplicantHQM applicant, String browserType) throws Exception {

        //       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityPage.selectQualityGrade(applicant, propertyData);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        if (contactInfoPage.findInCallStack("hqmPEWCScreen")) {
        	fsa.assertAll();
        	return;
        }
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        if (driver().getCurrentUrl().endsWith("/discounts")) {
            discountsPage.setRequiredFields(applicant);
            discountsPage.getFieldValues(applicant);
            discountsPage.clickNext();
        }

        if (!applicant.isKnockOutScenario) {
//       Quote Page
            QuotePage quotePage = null;
            try {
                quotePage = new QuotePage();
            } catch (com.farmers.framework.playwright.compat.PWTimeoutException | com.farmers.framework.playwright.compat.PWNotFoundException e) {
                String failed = apiHelper.getQuoteRateFailedFromJson(quoteNumber);
                Log.error("Quote #" + quoteNumber + " was not rated successfully. " + "API Response: " + failed);
                Log.error(e.getMessage());
                throw e;
            }
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            quotePage.validateQuotePremiums(applicant, quoteRate, quoteDelta, fsa);
            quotePage.validateQuoteDiscounts(applicant, fsa, quoteRate);
            quotePage.validatePageCardTitles(applicant, quoteRate, true, browserType, fsa);
            String quotePremiumYearly = quotePage.getQuotePremiumYearly(applicant.stateCode);
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                applicant.quoteRate = quotePage.getQuotePremiumMonthly();
            } else {
                applicant.quoteRate = quotePremiumYearly;
            }
            quotePage.clickQuoteDetails();

//       Quote Details dialog
            QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
            quoteDetailsPage.validatePageTitlesSubtitles(applicant, fsa, quoteRate, quoteDelta, quotePremiumYearly, null);
            quoteDetailsPage.validateStandardPackageSliders(applicant, quoteRate, null, fsa);
            quoteDetailsPage.clickCloseModal();

            quotePage = new QuotePage();
            Log.info("Quote Summary page, quote number: " + quoteNumber,true);
            if (applicant.emailCheck && !quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                quotePage.validateSendEmail(applicant, fsa);
            }
            quotePage.clickNext();

            ThankYouPage thankYouPage = new ThankYouPage();
            thankYouPage.validatePageValues(applicant, applicant.quoteRate, fsa, quoteRate);

            if (applicant.emailCheck && !thankYouPage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                Mailinator.validateHqmEmails(applicant, null, false);
            }
        } else {
            StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
            KnockOutPage knockOutPage = new KnockOutPage();
            Log.info("Knockout page, quote number: " + quoteNumber,true);
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_PROD_DATA_PROVIDER, dataProviderClass = DataProviders.class,
            attributes = {@CustomAttribute(name = "includedStates", values = {MT})}, groups = {})
    public void testProdSmokeHqm(ApplicantHQM applicant) throws Exception {
        String browserType = DESKTOP_BROWSER;

        // start HQM quote from the landing page
        LandingPage landingPage = !applicant.getAgentId().isBlank() ? new LandingPage(applicant) : new LandingPage(browserType.equals(MOBILE_BROWSER));
        landingPage.enterLandingPageData(LOB_HOME, applicant.getZipCode());

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage();
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber, true);
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        propertyPage.setRequiredFields(applicant, fsa, null);
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        qualityPage.selectQualityGrade(applicant, null);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, null);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        if (driver().getCurrentUrl().endsWith("/discounts")) {
            discountsPage.setRequiredFields(applicant);
            discountsPage.getFieldValues(applicant);
            discountsPage.clickNext();
        }

        if (!applicant.isKnockOutScenario) {
//       Quote Page
            QuotePage quotePage;
            try {
                quotePage = new QuotePage();
            } catch (com.farmers.framework.playwright.compat.PWTimeoutException | com.farmers.framework.playwright.compat.PWNotFoundException e) {
                Log.error("Quote Summary page was not found, quote number: " + quoteNumber, true);
                Log.error(e.getMessage());
                throw e;
            }
            quotePage.clickQuoteDetails();

//       Quote Details dialog
            QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
            quoteDetailsPage.clickCloseModal();

            quotePage = new QuotePage();
            Log.warn("Quote Summary page, quote number: " + quoteNumber,true);
            quotePage.clickNext();

        } else {
            Log.warn("Knockout page, quote number: " + quoteNumber,true);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_PROD_DATA_PROVIDER, dataProviderClass = DataProviders.class,
    attributes = {@CustomAttribute(name = "includedStates", values = {MT})}, groups = {HQM_ADA_SUITE,ADA_SUITE})
    public void testHqmADA(ApplicantHQM applicant) throws Exception {
        String browserType = DESKTOP_BROWSER;

        // start HQM quote from the landing page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();

//       Quote Start - Address Page
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber, true);
        testStep("Address page - ADA call start");
        addressPage.performADATesting(addressPage.getClass().getSimpleName()+"_"+applicant.getStateCode(),MARKETING_IT,HQM);
        testStep("Address page - ADA call end");
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        testStep("Property page - ADA call start");
        propertyPage.performADATesting(propertyPage.getClass().getSimpleName()+"_"+applicant.getStateCode(),MARKETING_IT,HQM);
        testStep("Property page - ADA call end");
        propertyPage.setRequiredFields(applicant, fsa, null);
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        testStep("Quality grade page - ADA call start");
        qualityPage.performADATesting(qualityPage.getClass().getSimpleName()+"_"+applicant.getStateCode(),MARKETING_IT,HQM);
        testStep("Quality grade page - ADA call end");
        qualityPage.selectQualityGrade(applicant, null);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        testStep("Property details page - ADA call start");
        qualityPage.performADATesting(propertyDetailsPage.getClass().getSimpleName()+"_"+applicant.getStateCode(),MARKETING_IT,HQM);
        testStep("Property details page - ADA call end");
        propertyDetailsPage.setRequiredFields(applicant, fsa, null);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        testStep("Customer info page - ADA call start");
        customerInfoPage.performADATesting(customerInfoPage.getClass().getSimpleName()+"_"+applicant.getStateCode(),MARKETING_IT,HQM);
        testStep("Customer info page - ADA call end");
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        testStep("Contact info page - ADA call start");
        customerInfoPage.performADATesting(contactInfoPage.getClass().getSimpleName()+"_"+applicant.getStateCode(),MARKETING_IT,HQM);
        testStep("Contact info page - ADA call end");
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        if (driver().getCurrentUrl().endsWith("/discounts")) {
            testStep("Discounts page - ADA call start");
            discountsPage.performADATesting(discountsPage.getClass().getSimpleName()+"_"+applicant.getStateCode(),MARKETING_IT,HQM);
            testStep("Discounts info page - ADA call end");
            discountsPage.setRequiredFields(applicant);
            discountsPage.getFieldValues(applicant);
            discountsPage.clickNext();
        }

        if (!applicant.isKnockOutScenario) {
//       Quote Page
            QuotePage quotePage;
            try {
                quotePage = new QuotePage();
                testStep("Quote summary page - ADA call start");
                quotePage.performADATesting(quotePage.getClass().getSimpleName()+"_"+applicant.getStateCode(),MARKETING_IT,HQM);
                testStep("Quote summary page - ADA call end");
            } catch (com.farmers.framework.playwright.compat.PWTimeoutException | com.farmers.framework.playwright.compat.PWNotFoundException e) {
                Log.error("Quote Summary page was not found, quote number: " + quoteNumber, true);
                Log.error(e.getMessage());
                throw e;
            }
            quotePage.clickQuoteDetails();

//       Quote Details dialog
            QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
            testStep("Quote details page - ADA call start");
            quoteDetailsPage.performADATesting(quoteDetailsPage.getClass().getSimpleName()+"_"+applicant.getStateCode(),MARKETING_IT,HQM);
            testStep("Quote details page - ADA call end");
            quoteDetailsPage.clickCloseModal();

            quotePage = new QuotePage();
            Log.warn("Quote Summary page, quote number: " + quoteNumber,true);
            quotePage.clickNext();

            ThankYouPage thankYouPage = new ThankYouPage();
            testStep("Thank You page - ADA call start");
            quoteDetailsPage.performADATesting(thankYouPage.getClass().getSimpleName()+"_"+applicant.getStateCode(),MARKETING_IT,HQM);
            testStep("Thank You page - ADA call end");

        } else {
            Log.warn("Knockout page, quote number: " + quoteNumber,true);
            KnockOutPage koPage = new KnockOutPage();
            testStep("Knock-out page - ADA call start");
            koPage.performADATesting(koPage.getClass().getSimpleName()+"_"+applicant.getStateCode(),MARKETING_IT,HQM);
            testStep("Knock-out page - ADA call end");
        }
        fsa.assertAll();
        driver().quit();
    }

    @Skip
    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_ALL})
    public void updatePropertyDetailsDataProvider(ApplicantHQM applicant) throws Exception {

        if (applicant.keep360Prefill) {
//       Quote Start - Address Page
            FarmersSoftAssert fsa = new FarmersSoftAssert();
            AddressPage addressPage = new AddressPage(applicant, FC, DESKTOP_BROWSER);
            String quoteNumber = addressPage.getQuoteNumber();
            applicant.quoteNumber = quoteNumber;
            Log.info(NEW_QUOTE_NUMBER + quoteNumber );
            addressPage.populateFields(applicant, fsa);
            addressPage.clickButtonAgree();

//       Property Basics Page
            PropertyPage propertyPage = new PropertyPage();
//            propertyPage.setRequiredFields(applicant,quoteNumber);
            if (!propertyPage.getYearBuilt().isEmpty()) {
                applicant.yearBuilt = Integer.parseInt(propertyPage.getYearBuilt());
            }
            if (!propertyPage.getSquareFeet().isEmpty()) {
                applicant.squareFeet = propertyPage.getSquareFeet();
            }
            propertyPage.clickNext();

//        Quality Grade Page
            QualityGradePage qualityPage = new QualityGradePage();
            if (qualityPage.getSelected().isEmpty()) {
                qualityPage.selectQualityGrade(applicant, null);
            } else {
                applicant.qualityGrade = qualityPage.getSelected();
            }
            qualityPage.clickNext();

//        Property Details Page
            PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
            applicant.numberOfStories = propertyDetailsPage.getSelectedNumberOfStories();
            applicant.foundationType = propertyDetailsPage.getSelectedFoundationType();
            if (applicant.foundationType.equalsIgnoreCase("basement")
                    || applicant.foundationType.equalsIgnoreCase("shallow basement")) {
                if (propertyDetailsPage.getFinishedPercent().isEmpty()) {
                    applicant.finishedPercentOfLowestLevel = "100";
                } else {
                    applicant.finishedPercentOfLowestLevel = propertyDetailsPage.getFinishedPercent();
                }
            } else {
                applicant.finishedPercentOfLowestLevel = "";
            }
            applicant.exteriorWallFinish = propertyDetailsPage.getSelectedExteriorWallFinish();
            applicant.roofCover = propertyDetailsPage.getSelectedRoofCover();
//            applicant.floorCoverings = propertyDetailsPage.getSelectedFloorCovering();
            applicant.heatingSystem = propertyDetailsPage.getSelectedHeatingSystem();
            applicant.fireplaces = propertyDetailsPage.getSelectedFireplaces();
            applicant.garageCarport = propertyDetailsPage.getSelectedGarageCarport();
            if (!applicant.garageCarport.equals(NONE)) {
                applicant.garageStyle = propertyDetailsPage.getSelectedGarageStyle();
            } else {
                applicant.garageStyle = "";
            }
            fsa.assertAll();
        }
        writeApplicantHQM(applicant);
    }


    private void writeApplicantHQM(ApplicantHQM applicant) throws Exception {
        String hqmDataProviderNew = "src/test/resources/HQMTestDataNew.xlsx";

        List<String> applicantList = Arrays.stream(applicant.getClass().getFields())
                .map(Field::getName).collect(Collectors.toList());

        File fineIn = new File(hqmDataProviderNew);
        XSSFWorkbook workbook;
        try {
            FileInputStream inputStream = new FileInputStream(fineIn);
            workbook = new XSSFWorkbook(inputStream);
        } catch (FileNotFoundException e) {
            workbook = new XSSFWorkbook();
        }

        // Create a Sheet
        XSSFSheet sheet = workbook.getSheet("ApplicantHQM");
        if (sheet == null) {
            sheet = workbook.createSheet("ApplicantHQM");
            Row row = sheet.createRow(0); // add header row
            for(int i = 0; i < applicantList.size(); i++) {
                row.createCell(i).setCellValue(applicantList.get(i));
            }
        }

        Class<ApplicantHQM> aClass = ApplicantHQM.class;
        Row row = sheet.createRow(sheet.getLastRowNum() + 1);
        for(int i = 0; i < applicantList.size(); i++) {
            Field field = aClass.getField(applicantList.get(i));
            String val = field.get(applicant).toString();
            row.createCell(i).setCellValue(val);
        }

        // Write the output to a file
        FileOutputStream fileOut = new FileOutputStream(hqmDataProviderNew);
        workbook.write(fileOut);
        fileOut.close();

        // Closing the workbook
        workbook.close();
    }



    @Skip
    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_ALL})
    public void tempTestEmail(ApplicantHQM applicant) throws Exception {
        String quoteNumber = "1786798724";  // "1290898002";
        applicant.firstName = "Debbffad";   // "Dcfbdbab";
        applicant.lastName = "Cadfeeca";    // "Baabafbd";
        applicant.quoteRate = "$669.66";    // "$114.83";
        Mailinator.validateHqmEmails(applicant, null, true);
    }

    @Skip
    @Test(groups = {HQM_ALL})
    public void tempTestMixPanel() throws Exception {

        String quoteNumber = "1004257823";

        JSONArray jsa = MixpanelApiHelper.getEvents("","",quoteNumber);
        Log.info("");
        Log.info(">>> Response Converted to Json size: " + jsa.size());
        Log.info(">>> Response Converted to Json:");
        for (Object obj : jsa) {
            JSONObject jso = (JSONObject) obj;
            Log.info("event: " + MixpanelApiHelper.getEventData(jso.toJSONString()).getEvent());
            Log.info("quote number: " + MixpanelApiHelper.getEventData(jso.toJSONString()).getProperties().getQuote_number());
            Log.info("lob: " + MixpanelApiHelper.getEventData(jso.toJSONString()).getProperties().getLob());
            if (MixpanelApiHelper.getEventData(jso.toJSONString()).getProperties().getAction() != null){
                Log.info("action: " + MixpanelApiHelper.getEventData(jso.toJSONString()).getProperties().getAction());
            }
            Log.info(jso.toString());
        }
    }
}



