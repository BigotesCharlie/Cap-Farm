package com.farmers.ffq.acerenters;

import com.farmers.ffq.ace.condo.AceCondoCustomCoveragePage;
import com.farmers.ffq.ace.renters.AceRentersContactInfoPage;
import com.farmers.ffq.ace.renters.AceRentersNavigationHelper;
import com.farmers.ffq.ace.renters.AceRentersReviewQuotePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Map;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersReviewQuotePageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_REVIEW_QUOTE_PAGE})
    public void testValidateReviewQuotePageAndRC2screenRentersLob(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceRentersContactInfoPage contactInfoPageAceRenters = new AceRentersNavigationHelper().navigateToAceRentersContactInfoPage(applicant);
        contactInfoPageAceRenters.fillOutContactInfoPageRenters(applicant);
        (new AceCondoCustomCoveragePage()).validateRC2LoadingScreen(fsa);

        AceRentersReviewQuotePage reviewQuotePage = new AceRentersReviewQuotePage();
        (new AceRentersNavigationHelper()).goToAceRentersReviewQuotePage(applicant);

        fsa.assertTrue(reviewQuotePage.isPageTitleInViewport(), "Review quote page - page title is in Viewport");
        reviewQuotePage.validateQuoteSourceInd(fsa, applicant, RENTERS, REVIEW_QUOTE);
        reviewQuotePage.validateContentOfDeductiblesSection(fsa, RENTERS);
        reviewQuotePage.validateBrowserForwardButtonIsDisabled(fsa ,"review-quote");
        reviewQuotePage.clickEditDeductiblesLink();
        reviewQuotePage.validateContentOfDeductiblesSideSheet(fsa, RENTERS);
        reviewQuotePage.validateContentOfCoverageSectionRentersLob(fsa, applicant, RENTERS);
        reviewQuotePage.validateEditCoverageSideSheetRentersLob(fsa, applicant, RENTERS);
        reviewQuotePage.validatePersonalPropertySideSheetRenters(fsa, applicant);
        reviewQuotePage.validateAdditionalCoveragesTogglesText(fsa, applicant);
        reviewQuotePage.validateYouGetAllTheseWithYourPolicySection(fsa, RENTERS);

        reviewQuotePage.verifyQuotePresentmentCard(fsa);
        reviewQuotePage.validateContinueButtonAtPageBottom(fsa);
        reviewQuotePage.validateEmailThisQuoteLink(applicant, fsa);
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        reviewQuotePage.validateDiscounts(REVIEW_QUOTE, applicant, RENTERS, fsa);
        reviewQuotePage.validateAgentSection(fsa, REVIEW_QUOTE, applicant.getAgentId(), RENTERS);
        reviewQuotePage.validateQuoteText(REVIEW_QUOTE, applicant.getQuoteNumber(), fsa, true);

        // Validate RC2 screen is not displayed on navigating back from Review quote page to Custom coverage page and proceeding forward to Review quote page again without making any changes.
        reviewQuotePage.navigateBack();
        contactInfoPageAceRenters.clickOnAgreeAndSubmitButton();
        fsa.assertFalse(new AceCondoCustomCoveragePage().isOnRC2LoadingPage(2), "RC2 loading page is displayed after retrieving rated quote - " + RENTERS);
        fsa.assertTrue(reviewQuotePage.isOnReviewQuotePageAceRenters(), "Review quote page is not displayed when clicked continue from custom coverage page - " + RENTERS);
        reviewQuotePage.selectStepper(PURCHASE);
        fsa.assertTrue(reviewQuotePage.isOnReviewQuotePageAceRenters(), "User is on review quote page on clicking purchase stepper - " + RENTERS);
        reviewQuotePage.selectStepper(ENTER_INFO);
        fsa.assertTrue(contactInfoPageAceRenters.isOnContactInfoPage(false), "User is on contact info page on clicking enter info stepper - " + RENTERS);
        reviewQuotePage.selectStepper(REVIEW_QUOTE);
        fsa.assertTrue(reviewQuotePage.isOnReviewQuotePageAceRenters(), "User is on review quote page on clicking review quote stepper - " + RENTERS);
        reviewQuotePage.validateFooterTextOnReviewQuotePage(fsa);
        fsa.assertAll("Validate Ace Renters RC2 screen and Review Quote page - Content validation.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CO, MD, MI, PA, TX})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_REVIEW_QUOTE_PAGE})
    public void validateDefaultDeductibleAndOptionalCoverage(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceRentersReviewQuotePage aceRentersReviewQuotePage = new AceRentersNavigationHelper().navigateToAceRentersReviewQuotePage(applicant);
        aceRentersReviewQuotePage.validateDefaultDeductibleAmount(fsa, applicant, "on first load of Review Quote Page");
        Map<String, String> coveragesBeforeRetrieve = aceRentersReviewQuotePage.getExpectedCoverageAndCoverageAmountFromAppStoreRentersLob(applicant);
        aceRentersReviewQuotePage.clickOnAddEditCoverageLinkButton();
        aceRentersReviewQuotePage.editTheRentersCoveragesAndValidateContentOnMainPage(coveragesBeforeRetrieve, applicant.getStateCode());
        aceRentersReviewQuotePage.validateDefaultDeductibleAmount(fsa, applicant, "after custom rate");
        driver().navigate().back();
        new AceRentersContactInfoPage().clickContinueToQuoteButton();
        if (aceRentersReviewQuotePage.isOnReviewQuotePageAceRenters()) {
            aceRentersReviewQuotePage.validateDefaultDeductibleAmount(fsa, applicant, "back and forth navigation from Contact Info page to Review Quote page");
        } else {
            Log.warn("Unable to test back and forth navigation, not on quote review page");
        }
        aceRentersReviewQuotePage.validateSewerAndDrainForPropertyLimit(fsa, applicant.getStateCode());
        fsa.assertAll("Validate Ace Renters Review Quote page - Default deductible and Optional coverage Sewer and drain.");
    }
}
