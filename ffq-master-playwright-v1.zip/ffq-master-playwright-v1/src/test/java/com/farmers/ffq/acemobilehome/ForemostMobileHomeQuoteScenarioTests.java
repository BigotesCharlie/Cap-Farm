package com.farmers.ffq.acemobilehome;

import static com.farmers.ffq.utils.GlobalVariables.FFQ_MOBILE_HOME;
import static com.farmers.ffq.utils.GlobalVariables.FOREMOST;

import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.AutomationFramework;

public class ForemostMobileHomeQuoteScenarioTests extends AutomationFramework {

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void createForemostMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().createMobilehomeQuote(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void expectedForemostDiscountVerification(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().expectedDiscountVerification(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void retrieveForemostRatedQuotePageValidationTest(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().retrievedQuotePageValidation(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void retrieveForemostNonRatedQuoteKnockoutTest(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().retrieveQuoteBeforeItWasRated(mobilehomeApplicant);
	}

	private void enableForemostMode(ApplicantAceHome mobilehomeApplicant) {
		mobilehomeApplicant.setTestCategory(FOREMOST);
	}
}
