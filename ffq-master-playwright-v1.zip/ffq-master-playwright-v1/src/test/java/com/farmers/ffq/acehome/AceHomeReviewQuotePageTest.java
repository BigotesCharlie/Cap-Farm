package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.bundle.AceBundleNavigationHelper;
import com.farmers.ffq.ace.bundle.AceBundleReviewQuotesPage;
import com.farmers.ffq.ace.home.AceHomeContactInfoPage;
import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.home.AceHomeReviewQuotePage;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.acebundle.AceBundleTestHelper;
import com.farmers.ffq.auto.pages.WhoShouldWeInsurePage;
import com.farmers.ffq.dataproviders.AceBundleDataProviders;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AceBundleApplicant;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.ADDITIONAL_COVERAGES;
import static com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage.DID_NOT_REACH;
import static com.farmers.ffq.ace.hrc.common.AceHRCReviewQuoteBasePage.SCHEDULED_PAYMENT;
import static com.farmers.ffq.common.enums.CoveragesNameAceHome.Coverage.ROOF_MATERIALS;
import static com.farmers.ffq.utils.CurrencyFormat.convertCurrencyStringToDouble;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeReviewQuotePageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})
    public void testValidateReviewQuotePageAndRC2screenHomeLob(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        String stateCode = applicant.getStateCode();

        AceHRCDwellingCoverageBasePage dwellingCoveragePageAceHome = new AceHomeNavigationHelper().navigateToAceHomeDwellingCoveragePage(applicant, LOB_HOME, HOME);
        dwellingCoveragePageAceHome.fillOutDwellingCoveragePage(applicant);
        if (dwellingCoveragePageAceHome.isOnRC2LoadingPage(15)) {
            dwellingCoveragePageAceHome.validateRC2LoadingScreen(fsa);
        }

        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        fsa.assertTrue(reviewQuotePage.isPageTitleInViewport(), "Review quote page - page title is in Viewport");
        reviewQuotePage.validateQuoteSourceInd(fsa, applicant, HOME, REVIEW_QUOTE);

        reviewQuotePage.validateContentOfPolicyDeductibleSection(fsa, applicant.getStateCode());
        reviewQuotePage.clickAllPerilsInfoIcon();
        reviewQuotePage.validateBrowserForwardButtonIsDisabled(fsa ,"review-quote");
        reviewQuotePage.validateContentOfPolicyDeductiblesSideSheetAllPerils(fsa, applicant);

        // skipping review quote package for NC state as we need more work for edit functionality
        if (!stateCode.equals(NC)){
            reviewQuotePage.validatePackageOnReviewQuotePage(fsa, applicant);
        }

        // for TX state, wind hail and cyclone info side sheet shows same results as all perils deductibles
        if (!stateCode.equals(TX)) {
            if (!stateCode.equals(CA)) {
                reviewQuotePage.clickWindAndHailInfoIcon();
            } else {
                reviewQuotePage.clickWaterInfoIcon();
            }
            reviewQuotePage.validateContentOfPolicyDeductiblesSideSheetWindAndHail(fsa, applicant);
        }
        if(!List.of(TN, VA).contains(stateCode)){
            reviewQuotePage.clickEditDeductiblesLink();
            if (!stateCode.equals(TX)) {
                reviewQuotePage.validateContentOfDeductiblesSideSheetHomeLob(fsa, stateCode);
            } else {
                reviewQuotePage.validateContentOfDeductibleSideSheetWithOnlyAllPerilSection(fsa, stateCode);
            }
        }
        reviewQuotePage.validateYouGetAllTheseWithYourPolicySection(fsa, HOME);

        String dwellingCoverage = reviewQuotePage.getSessionStorageAppStore().getHome().getDwellingCoverage();
        reviewQuotePage.validatePageTitleSubtitle(fsa, CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(dwellingCoverage));
        reviewQuotePage.verifyQuotePresentmentCard(stateCode, fsa);
        reviewQuotePage.validateEmailThisQuoteLink(applicant, fsa);
        reviewQuotePage.validateDiscounts(REVIEW_QUOTE, applicant, HOME, fsa);
        reviewQuotePage.validateAgentSection(fsa, REVIEW_QUOTE, applicant.getAgentId(), HOME);
        reviewQuotePage.validateQuoteText(REVIEW_QUOTE, applicant.getQuoteNumber(), fsa, true);
        //Back to previous page and then continue to quote
        reviewQuotePage.navigateBack();
        AceHRCDwellingCoverageBasePage aceHRCDwellingCoverageBasePage = new AceHRCDwellingCoverageBasePage();
        if (aceHRCDwellingCoverageBasePage.quickIsOnDwellingCoveragePage()) {
            aceHRCDwellingCoverageBasePage.scrollAndClickOnContinueButton();
        }

        reviewQuotePage.validateContentOfPolicyDeductibleSection(fsa, applicant.getStateCode());
        reviewQuotePage.clickAllPerilsInfoIcon();
        reviewQuotePage.validateBrowserForwardButtonIsDisabled(fsa ,"review-quote");
        reviewQuotePage.validateContentOfPolicyDeductiblesSideSheetAllPerils(fsa, applicant);
        // skipping review quote package for NC state as we need more work for edit functionality
        if(stateCode.equals(NC)){
            reviewQuotePage.validatePackageOnReviewQuotePage(fsa, applicant);
        }
        // for TX state, wind hail and cyclone info side sheet shows same results as all perils deductibles
        if (!stateCode.equals(TX)) {
            if (!stateCode.equals(CA)) {
                reviewQuotePage.clickWindAndHailInfoIcon();
            } else {
                reviewQuotePage.clickWaterInfoIcon();
            }
            reviewQuotePage.validateContentOfPolicyDeductiblesSideSheetWindAndHail(fsa, applicant);
        }

        if(!List.of(TN, VA).contains(stateCode)){
            reviewQuotePage.clickEditDeductiblesLink();
            if (!stateCode.equals(TX)) {
                reviewQuotePage.validateContentOfDeductiblesSideSheetHomeLob(fsa, stateCode);
            } else {
                reviewQuotePage.validateContentOfDeductibleSideSheetWithOnlyAllPerilSection(fsa, stateCode);
            }
        }

        if (reviewQuotePage.isOnReviewQuotePageHome(false)) {
            // F83404: PL - Home - Offer Named Perils coverage for Cov C customer selection (HO3) - PI36
            reviewQuotePage.validatePersonalPropertyWithPerils(fsa, applicant);
            reviewQuotePage.validateYouGetAllTheseWithYourPolicySection(fsa, HOME);
            dwellingCoverage = reviewQuotePage.getSessionStorageAppStore().getHome().getDwellingCoverage();
            reviewQuotePage.validatePageTitleSubtitle(fsa, CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(dwellingCoverage));
            reviewQuotePage.verifyQuotePresentmentCard(stateCode, fsa);
            reviewQuotePage.validateContinueButtonAtPageBottom(fsa);
            reviewQuotePage.validateEmailThisQuoteLink(applicant, fsa);
            reviewQuotePage.validateDiscounts(REVIEW_QUOTE, applicant, HOME, fsa);
            reviewQuotePage.validateQuoteText(REVIEW_QUOTE, applicant.getQuoteNumber(), fsa, true);
            reviewQuotePage.validateAgentSection(fsa, REVIEW_QUOTE, applicant.getAgentId(), HOME);
        }
        fsa.assertAll("Validate Ace Home RC2 screen and Review Quote page - content validation.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})
    public void validateContentOfReviewQuoteComparePackageSideSheetHomeLob(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().navigateToAceHomeReviewQuotePage(applicantAceHome, LOB_HOME, HOME);
        reviewQuotePage.validateContentOfCompareQuoteSideSheet(fsa, applicantAceHome, HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AR,AZ,CO,ID,IL,MO,ND,NE,NM,OK,OR,PA,SD,UT,VA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})
    public void validateEditPrimaryCoveragesHomeLob(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
        AceHomeReviewQuotePage reviewQuotePage = navigator.navigateToAceHomeReviewQuotePage(applicantAceHome, LOB_HOME, HOME);
        String selectedPackage = (reviewQuotePage.getSelectedPackage() != null) ? reviewQuotePage.getSelectedPackage() : reviewQuotePage.getSelectedPackageName();
        fsa.assertEquals(selectedPackage, STANDARD, "Default selected package is Standard.");
        reviewQuotePage.verifyQuotePresentmentCard(applicantAceHome.getStateCode(), fsa);
        reviewQuotePage.validateEditPrimaryCoveragesSideSheetContent(applicantAceHome, fsa);
        reviewQuotePage.updateVerifyPrimaryCoveragesInSideSheet(fsa, applicantAceHome);
        if (reviewQuotePage.getNumberOfPackageTabs() > 1) {
            if (!reviewQuotePage.getSelectedPackage().equals(ENHANCED)) {
                reviewQuotePage.selectRatePackage(ENHANCED);
            }
            reviewQuotePage.clickOnContinueButton();
            AceHRCAdditionalCoveragesBasePage additionalCoveragePage = new AceHRCAdditionalCoveragesBasePage();
            Assert.assertTrue(additionalCoveragePage.isOnAdditionalCoveragesPage(), "Did not reach to Additional Coverage page - Home");
            additionalCoveragePage.selectIncreaseCoverageForCertainValuables();
            additionalCoveragePage.navigateBack();
            Assert.assertTrue(reviewQuotePage.isOnReviewQuotePageHome(true), "Did not navigate back to review quote page after navigating back from");
            reviewQuotePage.validatePersonalPropertyLossSettlementValueToACV(fsa, applicantAceHome);
        }
        reviewQuotePage.clickCloseEditPrimaryCoveragesSideSheet();
        reviewQuotePage.validateDiscounts(REVIEW_QUOTE, applicantAceHome, HOME, fsa);
        fsa.assertAll("Review quote page - Validate Edit primary coverages side-sheet.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})
    public void validateRoofMaterialAndFortifiedRoofCoverage(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
        AceHomeReviewQuotePage reviewQuotePage = navigator.navigateToAceHomeReviewQuotePage(applicantAceHome, LOB_HOME, HOME);
        fsa.assertEquals(reviewQuotePage.getSelectedPackageName(), STANDARD, "Default selected package is not standard.");
        reviewQuotePage.validateCoverageAndAmountOnReviewQuotePage(fsa, ROOF_MATERIALS, PRIMARY, SCHEDULED_PAYMENT);
        reviewQuotePage.clickOnContinueButton();
        AceHRCAdditionalCoveragesBasePage additionalCoveragePage = new AceHRCAdditionalCoveragesBasePage();
        additionalCoveragePage.validateRoofMaterialValueAndFortifiedRoofUpgradeDialog(reviewQuotePage, fsa);
        fsa.assertAll("Review quote page - Validate Roof Material, and Fortified Roof on optional coverage screen.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})
    public void validateReviewQuoteStepper(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().navigateToAceHomeReviewQuotePage(applicantAceHome, LOB_HOME, HOME);

        // F76803 - Validate RC2 screen is not displayed on navigating back from Review quote page to Dwelling coverage page and proceeding forward to Review quote page again without making any changes.
        reviewQuotePage.navigateBack();
        AceHRCDwellingCoverageBasePage aceHRCDwellingCoverageBasePage = new AceHRCDwellingCoverageBasePage();
        aceHRCDwellingCoverageBasePage.clickContinueButton();
        fsa.assertFalse(aceHRCDwellingCoverageBasePage.isOnRC2LoadingPage(2), "RC2 loading page is displayed after retrieving rated quote - " + HOME);
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePageHome(true));

        reviewQuotePage.selectStepper(ENTER_INFO);
        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        qualityGradePage.updateExteriorValidateReviewQuoteAndPurchaseStepper(fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}, enabled = false)
    public void validateCAMinimumWaterPerilDeductibleInTerritories9n10(ApplicantAceHome applicant) throws Exception {
        //  US853834: [Unfinished] FFQ Ace home CA state - Mono-line home policies - When dwelling is more than 41 year in Water territory 9 and 10 - deductible rules
        //  address: 10473 Smoke River Ct, Fountain Valley, CA 92708
        String ADDRESS_STREET = "10473 SMOKE RIVER COURT";
        String ADDRESS_CITY = "FOUNTAIN VALLEY";
        String ADDRESS_ZIP = "92708";
        applicant.setAddress(ADDRESS_STREET);
        applicant.setCity(ADDRESS_CITY);
        applicant.setZipCode(ADDRESS_ZIP);
        applicant.setYearBuilt(1980);
        applicant.setPlumbingUpdated(EMPTY_STRING);
        applicant.setWaterLeakProtection(EMPTY_STRING);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().navigateToAceHomeReviewQuotePage(applicant, LOB_HOME, HOME);

        String waterDeductible = reviewQuotePage.getDeductibleAmountByName("Water");
        // $5,450 (1% of Dwelling limit) deductible
        double dAmount = convertCurrencyStringToDouble(waterDeductible);
        Double dDwellingCoverage = convertCurrencyStringToDouble(reviewQuotePage.getDwellingCoverageFromHeading());
        fsa.assertTrue(dAmount >= 5000d, "Water deductible amount is >= $5,000: " + waterDeductible);
        fsa.assertTrue(dAmount >= (dDwellingCoverage * .01d), "Water deductible amount is >=n 1% of Dwelling coverage: " + dDwellingCoverage);

        fsa.assertAll("Validate CA Minimum Water Peril Deductible in territories 9 and 10 for homes > 41 years old and Plumbing not replaced.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE}, enabled = false)
    public void validateCAWildfireRiskReductionEligibilityByRoofType(ApplicantAceHome applicant) throws Exception {
        // US914919: FFQ CA Home: Class A eligible roof type - UI changes
        // Address: 20831 Timberline Ln, Walnut CA 91789
        String ADDRESS_STREET = "20831 TIMBERLINE LN";
        String ADDRESS_CITY = "WALNUT";
        String ADDRESS_ZIP = "91789";
        String WILDFIRE_RISK_REDUCTION = "Class-A";
        applicant.setAddress(ADDRESS_STREET);
        applicant.setCity(ADDRESS_CITY);
        applicant.setZipCode(ADDRESS_ZIP);
        applicant.setWildFireRisk(WILDFIRE_RISK_REDUCTION);

        AceHRCContactInfoBasePage contactInfoPage = new AceHomeNavigationHelper().navigateToAceHomeContactInfoPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoPage.validateHeaderAndSubHeaderContactInfoPage(fsa);
        contactInfoPage.validateContentOfWildfireRiskReductionSection(fsa);

        contactInfoPage.fillOutContactInfoPage(applicant, HOME);
        AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceHRCDwellingCoverageBasePage();
        Assert.assertTrue(dwellingCoveragePage.isOnDwellingCoveragePage(),  DID_NOT_REACH + "DwellingCoveragePage");
        dwellingCoveragePage.clickContinueButton();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        reviewQuotePage.validateDiscounts(REVIEW_QUOTE, applicant, HOME, fsa);
        fsa.assertAll("CA Wildfire Risk reduction eligibility, based on Roof type.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}, enabled = false)
    public void testCAQuoteFAIRPlanExclusionCoverage(ApplicantAceHome applicant) throws Exception {
        // F87743: CA Home - Offer FAIR Plan Quotes in FFQ
        // address: 5795 W Camino Cielo, Santa Barbara, CA 93105
        final String ADDRESS_STREET = "5795 W Camino Cielo";
        final String ADDRESS_CITY = "Santa Barbara";
        final String ADDRESS_ZIP = "93105";
        applicant.setAddress(ADDRESS_STREET);
        applicant.setCity(ADDRESS_CITY);
        applicant.setZipCode(ADDRESS_ZIP);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().navigateToAceHomeReviewQuotePage(applicant, LOB_HOME, HOME);
        reviewQuotePage.validateCAFairPlanDialog(fsa); // validate the CA FAIR plan dialog and it's contents
        reviewQuotePage.validateContentOfPolicyDeductibleSection(fsa, applicant.getStateCode());
        reviewQuotePage.clickAllPerilsInfoIcon();
        reviewQuotePage.validateContentOfCAFairPlanEndorsementExclusionsSection(fsa);

        // validate CA FAIR plan dialog pop-up does not appear on rate Recalculate (US993206)
        reviewQuotePage.updateAllPerilsDeductibleAndRecalculate();
        fsa.assertFalse(reviewQuotePage.isCAFairPlanDialogPresent(), "Review quote page - CA FAIR plan dialog is not displayed.");

        // validate CA FAIR plan dialog pop-up does not appear after retrieval of rated quote (US993206)
        (new AceHRCNavigationHelperBasePage()).retrieveQuoteByQuoteNumber(applicant);
        reviewQuotePage = new AceHomeReviewQuotePage();
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePageHome(true), "Did not reach Review quote page after quote retrieval.");
        fsa.assertFalse(reviewQuotePage.isCAFairPlanDialogPresent(), "Review quote page - CA FAIR plan dialog is not displayed after quote retrieval.");

        fsa.assertAll("Validate CA Quote FAIR plan exclusions popup and description in Deductibles side-sheet.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})
    public void validateBundleInterstitialToHomeMonoline(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceHomeNavigationHelper().navigateToAceHomeDwellingCoveragePage(applicantAceHome, LOB_HOME, HOME);
        dwellingCoveragePage.fillOutDwellingCoveragePage(applicantAceHome);
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeReviewQuotePage();
        Assert.assertTrue(reviewQuotePage.isOnBundleInterstitialPage(true), "Bundle discount interstitial page is displayed - " + HOME);
        reviewQuotePage.validateBundleDiscountInterstitialPage(fsa);
        reviewQuotePage.clickContinueWithHomeOnly();
        fsa.assertTrue(reviewQuotePage.isOnReviewQuotePageHome(false), "Did not navigate to review quote page after clicking continue with home only button - " + HOME);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {OR})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})
    public void validateBundleDiscountOnReviewQuotePageHome(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().navigateToAceHomeReviewQuotePage(applicantAceHome, LOB_HOME, HOME);
        reviewQuotePage.validateBundleDiscountContent(fsa, applicantAceHome.getStateCode());
        reviewQuotePage.clickApplyBundleDiscountButton();
        reviewQuotePage.waitForSkeletonToBeGone();
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePageHome(true));
        reviewQuotePage.validateBundleDiscountAppliedContent(fsa);
        reviewQuotePage.clickRemoveDiscountLink();
        Assert.assertTrue(reviewQuotePage.isRemoveDiscountDialogDisplayed(), "Remove bundle discount dialog is displayed");
        reviewQuotePage.validateRemoveDiscountDialogContent(fsa);
        reviewQuotePage.clickKeepDiscountDialogButton();
        reviewQuotePage.clickRemoveDiscountLink();
        reviewQuotePage.clickRemoveDiscountDialogButton();
        reviewQuotePage.waitForSkeletonToBeGone();
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePageHome(true), "Did not reach to Review Quote page");
        reviewQuotePage.validateBundleDiscountContent(fsa, applicantAceHome.getStateCode());
        fsa.assertAll();
    }

    @Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)},
            dataProviderClass = AceBundleDataProviders.class, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})
    public void testHomeMonolineToAutoBundleQuoteVariant1(AceBundleApplicant bundleApplicant) throws Exception {
        // F95103 [US1111014] Home Monoline #1 - Bundle review page changes

        AceBundleTestHelper bundleTestHelper = new AceBundleTestHelper();
        bundleTestHelper.applicantAdjustment(bundleApplicant);
        ApplicantAceHome applicantAceHome = bundleApplicant.getHrcApplicant();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeNavigationHelper navigatorHome = new AceHomeNavigationHelper();
        navigatorHome.navigateToAceHomeAutoWhoShouldWeInsurePageVariant1(applicantAceHome, LOB_HOME, HOME);
        AceHomeReviewQuotePage aceHomeReviewQuotePage = new AceHomeReviewQuotePage();
        if (aceHomeReviewQuotePage.isOnReviewQuotePageHome(false)) {
            aceHomeReviewQuotePage.verifyNotAbleToOfferBundleCardContent(fsa, HOME);
        } else {
            AceBundleNavigationHelper navigatorBundle = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
            navigatorBundle.setResumeFromPage(WhoShouldWeInsurePage.class.getSimpleName());
            navigatorBundle.completeAutoQuoteNavigation(bundleApplicant);
            AceBundleReviewQuotesPage aceBundleReviewQuotesPage = new AceBundleReviewQuotesPage();
            Assert.assertTrue(aceBundleReviewQuotesPage.isOnBundleReviewQuotesPage(), "Did not reach Auto+Home Bundle Review quote page.");
            Log.info("Reached Auto+Home Bundle review quote page.", true);
            aceBundleReviewQuotesPage.verifyBundleReviewQuotePageContent(HOME_TO_AUTO, bundleApplicant, fsa);

        }
        fsa.assertAll("Validate Ace Home Monoline to Auto Bundle quote flow Variant #1.");
    }

    @Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {OR}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)},
            dataProviderClass = AceBundleDataProviders.class, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})
    public void testHomeMonolineToAutoBundleQuoteVariant2(AceBundleApplicant bundleApplicant) throws Exception {
        // F95103 [US1111014] Home Monoline #2 - Bundle review page changes

        AceBundleTestHelper bundleTestHelper = new AceBundleTestHelper();
        bundleTestHelper.applicantAdjustment(bundleApplicant);
        ApplicantAceHome applicantAceHome = bundleApplicant.getHrcApplicant();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeNavigationHelper navigatorHome = new AceHomeNavigationHelper();
        AceHomeReviewQuotePage aceHomeReviewQuotePage = navigatorHome.navigateToAceHomeReviewQuotePage(applicantAceHome, LOB_HOME, HOME);
        if (!aceHomeReviewQuotePage.isApplyBundleDiscountButtonPresent()) {
            aceHomeReviewQuotePage.verifyNotAbleToOfferBundleCardContent(fsa, HOME);
        } else {
            aceHomeReviewQuotePage.clickApplyBundleDiscountButton();
            aceHomeReviewQuotePage.waitForSkeletonToBeGone();
            Assert.assertTrue(aceHomeReviewQuotePage.isOnReviewQuotePageHome(false));
            aceHomeReviewQuotePage.validateBundleDiscountAppliedToHomeContent(fsa, applicantAceHome.getStateCode());
            navigatorHome.setResumeFromPage(REVIEW_QUOTE);
            navigatorHome.navigateToAceHomeAutoWhoShouldWeInsurePageVariant2(applicantAceHome, LOB_HOME, HOME);

            AceBundleNavigationHelper navigatorBundle = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
            navigatorBundle.setResumeFromPage(WhoShouldWeInsurePage.class.getSimpleName());
            navigatorBundle.completeAutoQuoteNavigation(bundleApplicant);
            AceBundleReviewQuotesPage aceBundleReviewQuotesPage = new AceBundleReviewQuotesPage();
            Assert.assertTrue(aceBundleReviewQuotesPage.isOnBundleReviewQuotesPage(), "Did not reach Auto+Home Bundle Review quote page.");
            Log.info("Reached Home to Auto Bundle review quote page.", true);
            aceBundleReviewQuotesPage.verifyBundleReviewQuotePageContent(HOME_TO_AUTO, bundleApplicant, fsa);
        }
        fsa.assertAll("Validate Ace Home Monoline to Auto Bundle quote flow Variant #2.");
    }

    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_PAYROLL_DEDUCTION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})
    public void testPayrollDeductionBannerForNonAWSFlow(ApplicantAceHome applicant) throws Exception {
        // US1165656: Non AWS Flow - Payroll Deduction Banner Displayed for CA Home LOB

        applicant.setAgentId(EMPTY_STRING);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().navigateToAceHomeReviewQuotePage(applicant, LOB_HOME, HOME);
        reviewQuotePage.clickFairPlanDialogContinueButton();
        reviewQuotePage.validatePayrollDeductionPopup(fsa, REVIEW_QUOTE);
        fsa.assertFalse(reviewQuotePage.isStepperDisplayed(), "Stepper should not display on Review Quote page");
        fsa.assertFalse(reviewQuotePage.isEmailThisQuoteLinkDisplayed(), "Email this quote link should not displayed");
        reviewQuotePage.clickReviewOptionalCoverageButton();
        AceHRCAdditionalCoveragesBasePage additionalCoverage = new AceHRCAdditionalCoveragesBasePage();
        Assert.assertTrue(additionalCoverage.isOnAdditionalCoveragesPage(), "Did not reach to Additional Coverage page - Home");
        additionalCoverage.validatePayrollDeductionPopup(fsa, ADDITIONAL_COVERAGES);
        fsa.assertFalse(additionalCoverage.isStepperDisplayed(), "Stepper should not display on Additional Coverage page");
        fsa.assertFalse(additionalCoverage.isEmailThisQuoteLinkDisplayed(), "Email this quote link should not display");
        fsa.assertFalse(additionalCoverage.isContinueButtonDisplayed(), "Continue button should not display");
        fsa.assertTrue(additionalCoverage.isCallButtonDisplayed(), "Call button displayed on Additional Coverage page - Home LOB");
        additionalCoverage.randomToggleSelection(applicant, fsa, HOME);
        fsa.assertFalse(additionalCoverage.isContinueButtonDisplayed(), "Continue button should not display on Additional Coverage page");
        fsa.assertTrue(additionalCoverage.isCallButtonDisplayed(), "Call button displayed after recalculate on Additional Coverage page - Home LOB");
        fsa.assertAll("Validate Payroll deduction banner in Non AWS flow for CA Sate.");
    }

    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_PAYROLL_DEDUCTION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})
    public void testPayrollDeductionBannerForAWSFlow(ApplicantAceHome applicant) throws Exception {
        // US1165656: AWS Flow - Payroll Deduction Banner Displayed for CA Home LOB

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().navigateToAceHomeReviewQuotePage(applicant, LOB_HOME, HOME);
        reviewQuotePage.clickFairPlanDialogContinueButton();
        fsa.assertFalse(reviewQuotePage.isPayrollDeductionBannerDisplayed(), "Payroll deduction banner not displayed on Review quote page in AWS flow");
        fsa.assertTrue(reviewQuotePage.isStepperDisplayed(), "Steppers validation on Review quote page");
        fsa.assertTrue(reviewQuotePage.isEmailThisQuoteLinkDisplayed(), "Email this quote link is displayed on Review quote page - Home LOB");
        reviewQuotePage.clickOnContinueButton();
        AceHRCAdditionalCoveragesBasePage additionalCoverage = new AceHRCAdditionalCoveragesBasePage();
        Assert.assertTrue(additionalCoverage.isOnAdditionalCoveragesPage(), "Did not reach to Additional Coverage page - Home");
        fsa.assertFalse(additionalCoverage.isPayrollDeductionBannerDisplayed(), "Payroll deduction banner not displayed on Additional coverage page in AWS flow");
        fsa.assertTrue(additionalCoverage.isStepperDisplayed(), "Steppers validation on Additional coverage page");
        fsa.assertTrue(additionalCoverage.isEmailThisQuoteLinkDisplayed(), "Email this quote link is displayed on Additional Coverage - Home LOB");
        fsa.assertTrue(additionalCoverage.isContinueButtonDisplayed(), "Continue button displayed on Additional Coverage page");
        additionalCoverage.randomToggleSelection(applicant, fsa, HOME);
        fsa.assertTrue(additionalCoverage.isContinueButtonDisplayed(), "Continue button displayed on Additional Coverage page");
        fsa.assertAll("Validate Payroll deduction banner in AWS flow for CA Sate.");
    }

}