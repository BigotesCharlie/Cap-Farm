package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;

public class BWDefaultCoverageValuesTests_MT extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)
    public void testDefaultCoverageValues_Nne_Unk_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        defaultCoverageTestForBW(applicant, "coverageAmount=Nne/Unk&umbrella=No", "MT_Nne/Unk_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)
    public void testDefaultCoverageValues_25K_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=25/50&umbrella=No", "MT_25K_50K_");
    }


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)
    public void testDefaultCoverageValues_MT_30K_60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=30/60&umbrella=No", "MT_30K_60K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)
    public void testDefaultCoverageValues_MT_35K_70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35/70&umbrella=No", "MT_35K_70K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)
    public void testDefaultCoverageValues_MT_50K_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=50/100&umbrella=No", "MT_50K_100K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)
    public void testDefaultCoverageValues_MT_100K_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/200&umbrella=No", "MT_100K_200K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)
    public void testDefaultCoverageValues_MT_100K_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/300&umbrella=No", "MT_100K_300K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)
    public void testDefaultCoverageValues_MT_250K_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=250/500&umbrella=No", "MT_250K_500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)
    public void testDefaultCoverageValues_MT_500K_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/500&umbrella=No", "MT_500K_500K_");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)
    public void testDefaultCoverageValues_MT_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500&umbrella=No", "MT_500K_");
    }

}
