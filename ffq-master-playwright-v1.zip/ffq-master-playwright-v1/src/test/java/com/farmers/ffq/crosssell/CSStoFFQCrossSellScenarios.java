package com.farmers.ffq.crosssell;

import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.legacy.DriversPage;
import com.farmers.ffq.auto.pages.legacy.QuotePageAuto;
import com.farmers.ffq.auto.pages.legacy.VehiclesPage;
import com.farmers.ffq.auto.pages.legacy.YourInfoPageAuto;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.hqm.*;
import com.farmers.ffq.hqm.pages.DiscountsPage;
import com.farmers.ffq.hqm.pages.KnockOutPage;
import com.farmers.ffq.hqm.pages.ThankYouPage;
import com.farmers.ffq.hqm.pages.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;


/**
 * Cross-sell scenarios from CSS to HQM
 */
public class CSStoFFQCrossSellScenarios extends AutomationFramework {

    private static final String EXCLUDED_STATES = "excludedStates";
    private static final double quoteDelta = 0.30; // quote price fluctuation delta max (5%) (used when no Postgres connection)

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, GA, NJ, NY})}, groups = {CROSS_SELL})
    public void testCrossSellFromCSStoHQM(ApplicantHQM applicant) throws Exception {
        validateCrossSellFromCSStoHQM(applicant, CW);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, GA, NJ, NY})}, groups = {CROSS_SELL})
    public void testCrossSellFromMobileToHQM(ApplicantHQM applicant) throws Exception {
        validateCrossSellFromCSStoHQM(applicant, MB);
    }

    private void validateCrossSellFromCSStoHQM(ApplicantHQM applicant, String leadType) throws Exception {
        String browserType = leadType.equals(MB) ? MOBILE_BROWSER : DESKTOP_BROWSER;
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, leadType, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.setPolicyStartDateInFuture(applicant);
        addressPage.verifyPageFields(applicant, fsa);
        PageLinksHQM addressPageLinks = new PageLinksHQM("addressPage", applicant, leadType, false);
        addressPage.validatePageLinks(addressPageLinks, quoteNumber, fsa);
        ApiHelper apiHelper = new ApiHelper();
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        addressPage.validatePageTitlesSubtitles(applicant, browserType, fsa, staticContent);
        addressPage.validatePageFooters(applicant.stateCode, browserType, staticContent);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();

        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        PageLinksHQM propertyPageLinks = new PageLinksHQM("propertyPage", applicant, browserType, false);
        propertyPageLinks.buttonNext = (propertyPage.getYearBuilt().isEmpty() || propertyPage.getSquareFeet().isEmpty()) ? 2 : 3;
        propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);
        propertyPage.validatePageTitles(fsa, staticContent);
        propertyPage.validatePageFooters(staticContent);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        List<String> discounts = propertyPage.getDiscounts();
        propertyPage.clickNext();

//       Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        if (applicant.keep360Prefill) {
            qualityPage.verifyPageFields(applicant, propertyData);
        } else {
            qualityPage.selectQualityGrade(applicant, propertyData);
        }
        PageLinksHQM qualityPageLinks = new PageLinksHQM("qualityPage", applicant, browserType, false);
        qualityPageLinks.buttonNext = qualityPage.getSelected().isEmpty() ? 2 : 3;
        qualityPage.validatePageLinks(qualityPageLinks, quoteNumber, fsa);
        qualityPage.validatePageTitles(fsa, staticContent);
        qualityPage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityPage.validatePageFooters(staticContent);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        PageLinksHQM propertyDetailsPageLinks = new PageLinksHQM("propertyDetailsPage", applicant, browserType, false);
        propertyDetailsPageLinks.buttonNext = propertyDetailsPage.isNextButtonEnabled(applicant.stateCode) ? 3 : 2;
        propertyDetailsPage.validatePageLinks(propertyDetailsPageLinks, quoteNumber, fsa);
        propertyDetailsPage.validatePageTitles(applicant, fsa, staticContent);
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        PageLinksHQM customerInfoPageLinks = new PageLinksHQM("customerInfoPage", applicant, browserType, false);
        customerInfoPage.setRequiredFieldsCrossSell(applicant);
        customerInfoPageLinks.buttonNext = 3;
        customerInfoPage.validatePageLinks(customerInfoPageLinks, quoteNumber, fsa);
        customerInfoPage.validatePageFieldContents(applicant, false, fsa);
        customerInfoPage.validatePageTitles(applicant, fsa, staticContent);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        PageLinksHQM contactInfoPageLinks = new PageLinksHQM("contactInfoPage", applicant, browserType, false);
        contactInfoPageLinks.buttonNext = 3;
        contactInfoPage.validatePageLinks(contactInfoPageLinks, quoteNumber, fsa);
        contactInfoPage.validatePageFieldContents(applicant, false, fsa);
        contactInfoPage.validatePageTitles(applicant, fsa, staticContent);
        contactInfoPage.validatePageFooters(applicant, null, staticContent);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        PageLinksHQM discountsPageLinks = new PageLinksHQM("discountsPage", applicant, browserType, false);
        discountsPage.validatePageLinks(discountsPageLinks, quoteNumber, fsa);
        List<String> discountsBeforeRate = apiHelper.getDiscountsFromJsonBeforeRate(quoteNumber);
        discountsPage.validatePageFieldContents(applicant, true, fsa, discountsBeforeRate);
        discountsPage.validatePreappliedDiscountsBeforeRate(applicant, discountsBeforeRate, fsa);
        discountsPage.validatePageTitles(!discountsBeforeRate.isEmpty(), fsa, staticContent);
        discountsPage.validatePageSubtitles(applicant, !discountsBeforeRate.isEmpty(), staticContent);
        discountsPage.setRequiredFields(applicant);
        discountsPage.validatePageFieldContents(applicant, false, fsa, null);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
//           Quote Page
            QuotePage quotePage = new QuotePage();
            PageLinksHQM quotePageLinks = new PageLinksHQM("quotePage", applicant, leadType, true);
            quotePage.validatePageLinks(quotePageLinks, quoteNumber, fsa);
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            quotePage.validatePageTitles(quoteRate, fsa, staticContent);
            quotePage.validatePageFooters(applicant, staticContent);
            quotePage.validatePolicyPerks(applicant);
//            quotePage.validatePolicyFloAd(applicant, QQ);
            quotePage.validatePageCardTitles(applicant, quoteRate, true, leadType, fsa);
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                quotePage.validateSendEmail(applicant, fsa);
                EmailHQM email2 = apiHelper.getEmailRequestFromJson(quoteNumber);
                if (!quotePage.isEasternExpansionState(applicant.stateCode)) {
                    fsa.assertEquals(email2.getTemplateName(), "EMAILTOCUSTOMER", "Quote Page - Email To Customer Template.");
                } else {
                    fsa.assertEquals(email2.getTemplateName(), "EE_EMAILTOCUSTOMER", "Quote Page - Email To Customer EE Template.");
                }
                fsa.assertEquals(email2.getRecipientContactPoint(), applicant.emailAddress, "Quote Page - Send Email Contact Point.");
                fsa.assertEquals(email2.getDynamicPropertyByName("QuoteNumber"), quoteNumber, "Quote Page - " +
                        "Send Email To Customer Quote Number.");
                fsa.assertEquals(email2.getDynamicPropertyByName("CustomerFirstName"), applicant.firstName, "Quote Page - " +
                        "Send Email To Customer First Name.");
                fsa.assertEquals(email2.getDynamicPropertyByName("CustomerLastName"), applicant.lastName, "Quote Page - " +
                        "Send Email To Customer Last Name.");
                fsa.assertEquals(email2.getDynamicPropertyByName("CustomerEmailId"), applicant.emailAddress, "Quote Page - " +
                        "Send Email To Customer Email Id.");
            }
            quotePage.validateQuoteDiscounts(applicant, fsa, quoteRate);
            quotePage.validateQuotePremiums(applicant, quoteRate, quoteDelta, fsa);
            String quotePremiumYearly = quotePage.getQuotePremiumYearly(applicant.stateCode);
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                applicant.quoteRate = quotePage.getQuotePremiumMonthly();
            } else {
                applicant.quoteRate = quotePremiumYearly;
            }
            String reconstructionCost = quotePage.getQuoteReconstructionCost();
            quotePage.clickQuoteDetails();

            QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
            quoteDetailsPage.validatePageTitlesSubtitles(applicant, fsa, quoteRate, quoteDelta, quotePremiumYearly, staticContent);
            quoteDetailsPage.validateStandardPackageSliders(applicant, quoteRate, reconstructionCost, fsa);
            quoteDetailsPage.clickCloseModal();

            quotePage = new QuotePage();
            Log.info("Quote Summary page, quote number: " + quoteNumber,true);
            quotePage.clickNext();

//           Thank You Page
            ThankYouPage thankYouPage = new ThankYouPage();
            PageLinksHQM thankYouPageLinks = new PageLinksHQM("thankYouPage", applicant.stateCode);
            thankYouPage.validatePageLinks(thankYouPageLinks, quoteNumber, fsa);
            thankYouPage.validatePageValues(applicant, applicant.quoteRate, fsa, quoteRate);
            thankYouPage.validatePageTitles(applicant, leadType, fsa, staticContent);
            thankYouPage.validatePageFooters(applicant, leadType, fsa);

        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            Log.info("Knockout page, quote number: " + quoteNumber,true);
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AR,AZ,IA,IL,KS,MI,MN,NM,OR,WI})}, groups = {CROSS_SELL})
    public void testCrossSellFromCSStoAuto(ApplicantHQM applicant) throws Exception {
        validateCrossSellFromCSStoAuto(applicant, CW);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AR,AZ,IA,IL,KS,MI,MN,NM,OR,WI})}, groups = {CROSS_SELL})
    public void testCrossSellFromMobileToAuto(ApplicantHQM applicant) throws Exception {
        validateCrossSellFromCSStoAuto(applicant, MB);
    }

    private void validateCrossSellFromCSStoAuto(ApplicantHQM applicant, String leadType) throws Exception {
        String browserType = leadType.equals(MB) ? MOBILE_BROWSER : DESKTOP_BROWSER;

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        new LandingPage(applicant.zipCode, new LeadTypeHQM(applicant, leadType), browserType, AUTO);
        YourInfoPageAuto pageAuto = new YourInfoPageAuto();
        fsa.assertEquals(pageAuto.getFirstName(), applicant.firstName, "Auto Quote - Applicant First name.");
        fsa.assertEquals(pageAuto.getLastName(), applicant.lastName, "Auto Quote - Applicant Last name.");
        fsa.assertEquals(pageAuto.getDateOfBirth(), applicant.dateOfBirth, "Auto Quote - Applicant Date of birth.");
        fsa.assertEquals(pageAuto.getAddress().toUpperCase(), applicant.addressApt, "Auto Quote - Applicant Address.");
        fsa.assertEquals(pageAuto.getCity().toUpperCase(), applicant.city, "Auto Quote - Applicant City.");
        fsa.assertEquals(pageAuto.getState(), applicant.state, "Auto Quote - Applicant State.");
        fsa.assertEquals(pageAuto.getZipCode(), applicant.zipCode, "Auto Quote - Applicant Zip Code.");

        // Continue CSS to Auto Cross-sell validation
        //
        pageAuto.setCurrentlyInsured(true);
        pageAuto.selectSubscriptionCheckbox();
        pageAuto.clickContinueToVehiclesPage();
        VehiclesPage vehiclesPage = new VehiclesPage();
        vehiclesPage.addAVehicle();
        Log.info("Auto quote number:: " + vehiclesPage.getQuoteNumber());
        DriversPage driversPage = vehiclesPage.forwardToDriversPage();
        applicant.gender = applicant.gender.isEmpty() ? MALE : applicant.gender;
        driversPage.selectDriverToInsure(true);
        driversPage.fillDriverInfo(applicant, true);
        if (applicant.maritalStatus.equals(MARRIED)) {
            driversPage.selectDriverToInsure(false);
            driversPage.setSpouseName (applicant.spouseFirstName, applicant.spouseLastName, applicant.spouseDateOfBirth);
            if (applicant.spouseGender.isEmpty()) {
                applicant.spouseGender = applicant.gender.isEmpty() || applicant.gender.equals(MALE) ? FEMALE : MALE;
            }
            driversPage.fillDriverInfo(applicant, false);
        }
        String quoteNumber = driversPage.getRedesignedQuoteNumber();
        driversPage.clickContinueToNextPage();
        //
        fsa.assertEquals(driversPage.getEmailAddress(), applicant.emailAddress, "Additional Details Page - Email address match.");
        fsa.assertEquals(driversPage.getPhoneNumber().replaceAll("\\D", EMPTY_STRING), applicant.phoneNumber,
                "Additional Details Page - Phone number match.");
        driversPage.clickContinueToNextPage();
        driversPage.assignCarsToDrivers();

        com.farmers.ffq.auto.pages.legacy.DiscountsPage discountsPage = new com.farmers.ffq.auto.pages.legacy.DiscountsPage();
        discountsPage.fillDiscountsInfo(fsa);
        discountsPage.continueToQuotePage();

        QuotePageAuto autoQuotePage = new QuotePageAuto();
        Log.info("Quote Summary page, quote number: " + quoteNumber,true);
        autoQuotePage.validatePageTitle(fsa);
        autoQuotePage.validatePageDisclaimer(applicant.stateCode, fsa);
        Log.info("Auto Quote page - premium found: " + autoQuotePage.getPremiumAmount());
        fsa.assertTrue(autoQuotePage.getPremiumAmount().strip().replaceAll("[\\D]", EMPTY_STRING).length() > 0, "Quote page - Premium is not blank");

        fsa.assertAll("CSS to FFQ Auto Cross-sell validation");
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,IA,IL,NM,OR,WI})}, groups = {CROSS_SELL})
//            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AR,AZ,IA,IL,KS,MI,MN,NM,OR,WI})}, groups = {CROSS_SELL})
    public void testCrossSellFromCSStoAutoAce(ApplicantHQM applicant) throws Exception {
        validateCrossSellFromCSStoAutoAce(applicant, CW);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,IA,IL,NM,OR,WI})}, groups = {CROSS_SELL})
//            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AR,AZ,IA,IL,KS,MI,MN,NM,OR,WI})}, groups = {CROSS_SELL})
    public void testCrossSellFromMobileToAutoAce(ApplicantHQM applicant) throws Exception {
        validateCrossSellFromCSStoAutoAce(applicant, MB);
    }

    private void validateCrossSellFromCSStoAutoAce(ApplicantHQM applicant, String leadType) throws Exception {
        String browserType = leadType.equals(MB) ? MOBILE_BROWSER : DESKTOP_BROWSER;

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        new LandingPage(applicant.zipCode, new LeadTypeHQM(applicant, leadType), browserType, AUTO);
        AutoApplicant autoApplicant = new AutoApplicant(applicant, false);
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        nameAndDobPage.waitForNameAndDobPageToRender();
        fsa.assertEquals(nameAndDobPage.getFormFieldWebElementValue("First name"), autoApplicant.getFirstName(), "Name and Dob page - Applicant First name.");
        fsa.assertEquals(nameAndDobPage.getFormFieldWebElementValue("Last name"), autoApplicant.getLastName(), "Name and Dob page - Applicant Last name.");
        fsa.assertEquals(nameAndDobPage.getFormFieldWebElementValue("Date of birth"), autoApplicant.getDateOfBirth(), "Name and Dob page - Applicant Date of birth.");
        nameAndDobPage.clickContinueButton();

        AutoEnterAddressPage addressPage = new AutoEnterAddressPage();
        addressPage.waitForAutoEnterAddressPageToRender();
        String fullAddress = autoApplicant.getResidentAddress() + ", " + autoApplicant.getCity() + ", " + autoApplicant.getStateCode() + " " + autoApplicant.getZipCode();
        fsa.assertEquals(addressPage.getFormFieldWebElementValue("Home address").toUpperCase(), fullAddress,
                "Name and Dob page - Applicant Home address.");
        fsa.assertEquals(addressPage.getFormFieldWebElementValue("Apartment number"), EMPTY_STRING, "Address page - Applicant Apartment number.");
        addressPage.checkHomeOwner(autoApplicant);
        fsa.assertFalse(addressPage.isHomeOwnerChecked(), "Address page - Home owner checkbox is checked.");
        addressPage.clickContinueButton();

        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        whoShouldWeInsurePage.validatePageTitle();
        whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(autoApplicant);
        whoShouldWeInsurePage.addDriversWhenNoneAreFound(autoApplicant);
        applicant.quoteNumber = whoShouldWeInsurePage.getAceQuoteNumberInThePage();
        Log.info("Quote number on Who Should We Insure page: " + applicant.quoteNumber);
        whoShouldWeInsurePage.clickContinueButton();

        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        fsa.assertEquals(vehicleReviewPage.getAceQuoteNumberInThePage(), applicant.quoteNumber, "Vehicles review page - Quote number.");
        vehicleReviewPage.validateVehiclesForCrossSell(autoApplicant, browserType, fsa);
        vehicleReviewPage.clickContinueButton();

        DriverReviewPage driverReviewPage = new DriverReviewPage();
        fsa.assertEquals(driverReviewPage.getAceQuoteNumberInThePage(), applicant.quoteNumber, "Drivers review page - Quote number.");
        driverReviewPage.validateDriversAges(autoApplicant, fsa);
        driverReviewPage.addEmployment(autoApplicant.getFirstName(), autoApplicant.getOccupation());
        if (autoApplicant.getMaritalStatus().equals(MARRIED)) {
            driverReviewPage.setMaritalRelationship(applicant.getFirstName() + SPACE + applicant.getLastName(),
                    (applicant.getSpouseFirstName() + SPACE + applicant.getSpouseLastName()));
        }
        driverReviewPage.clickContinueButton();

        SignalPageOneUI signalPage = new SignalPageOneUI();
        if (signalPage.isOnSignalPage()) {
            String quoteNumber;
            int i = 3;
            do {
                quoteNumber = signalPage.getAceQuoteNumberInThePage();
                i--;
            } while (quoteNumber.isBlank() && (i > 0));
            fsa.assertEquals(quoteNumber, applicant.quoteNumber, "Signal page - Quote number.");
            signalPage.processSignalPage(true);
        }

        ContactInfoAutoPage contactInfo = new ContactInfoAutoPage();
        fsa.assertTrue(contactInfo.isOnContactInfoAutoPage(), "Contact Info page - Is on Contact Info page.");
        fsa.assertEquals(contactInfo.getAceQuoteNumberInThePage(), applicant.quoteNumber, "Contact Info page - Quote number.");
        contactInfo.validatePrefilledValuesAndContinue(autoApplicant, fsa);

        QuoteSummaryAutoPage quoteSummaryPage = new QuoteSummaryAutoPage();
        quoteSummaryPage.waitForPageTitleAppear();
        Log.info("Auto Ace Quote Summary page, quote number: " + applicant.quoteNumber,true);
        fsa.assertEquals(quoteSummaryPage.getAceQuoteNumberInThePage(), applicant.quoteNumber, "Quote Summary page - Quote number.");
        quoteSummaryPage.validatePageTitle();
        quoteSummaryPage.validateVehicleCoverageTableTitle();
        quoteSummaryPage.validateLiabilityCoverageTableTitle();
        String premiumAmount = quoteSummaryPage.getPresentedPremiumAmount();
        Log.info("Auto Ace premium amount: " + premiumAmount);
        fsa.assertNotEquals(premiumAmount.split("/")[0].replaceAll("\\D", EMPTY_STRING).strip(), EMPTY_STRING,
                "Auto Ace Quote Summary page - Premium value is not blank.");
        fsa.assertTrue(quoteSummaryPage.isRoundedPresentedPremiumSumOfLiabilityAndVehicleCoveragePremium(),
                "Auto Ace Quote Summary page - Premium amount match to the Liability + Vehicles coverages.");

        fsa.assertAll("CSS to FFQ Auto Ace Cross-sell validation.");
    }

}
