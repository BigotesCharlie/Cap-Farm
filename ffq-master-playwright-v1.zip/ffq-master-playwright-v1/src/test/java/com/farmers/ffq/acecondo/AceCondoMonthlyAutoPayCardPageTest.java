package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoMonthlyAutoPayCardPageTest extends AutomationFramework {
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_CARD_PAGE})
    public void testValidateContentOfMonthlyAutoPayCardPageOnLandingAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        applicantAceHome.setSquareFeet("400");
        AceHRCPaymentBasePage aceHRCPayInFullPaymentBasePage = new AceCondoNavigationHelper().navigateToMonthlyAutoPayCardPaymentPageAceCondo(applicantAceHome);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceHRCPayInFullPaymentBasePage.validateContentOfMonthlyPayBankOrCardPageOnLanding(fsa, MONTHLY_DEBIT_CREDIT_CARD, applicantAceHome, CONDO);
        //Quote number and Agent details at the bottom validation
        AceHRCBasePage aceHRCBasePage = new AceHRCBasePage();
        aceHRCBasePage.validateQuoteSavedText(applicantAceHome.getQuoteNumber(), fsa);
        aceHRCPayInFullPaymentBasePage.validateAssignedAgentSection(aceHRCPayInFullPaymentBasePage, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_CARD_PAGE})
    public void testMonthlyAutoPayCardCreditCardPaymentEndToEndAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicantAceHome.setSquareFeet("400");
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceCondoNavigationHelper().navigateToMonthlyAutoPayCardPaymentPageAceCondo(applicantAceHome);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(fsa, MASTER_CARD, CARD_NAME_MASTER, true, CONDO);
        aceHRCPaymentBasePage.validateFutureCreditDebitCardServiceCharges(fsa, true, CONDO);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, CONDO);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, HOME);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, CONDO);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, CONDO);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_CARD_PAGE})
    public void testMonthlyAutoPayCardBankPaymentEndToEndAceCondo(ApplicantAceHome applicantAceHome) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicantAceHome.setSquareFeet("400");
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceCondoNavigationHelper().navigateToMonthlyAutoPayCardPaymentPageAceCondo(applicantAceHome);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.selectBankPaymentRadioButton();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, CONDO);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, CONDO);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, CONDO);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, CONDO);
        aceHRCPaymentBasePage.validateOpeningLinksIntoNewTabsOnPaymentPage(fsa, CONDO);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, CONDO);
        aceHRCPaymentBasePage.clickCompletePurchaseButton();
        aceHRCPaymentBasePage.validateECheckOutPage(fsa, CONDO);
        fsa.assertAll();
    }
}
