package com.farmers.ffq.auto.bind;

import com.farmers.ffq.BaseTest;

import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.annotation.Skip;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class BindOneUIAutoPaymentMonthlyPayTest extends BaseTest {

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}, enabled = false)
    public void autoPaymentMonthlyPayBankPageContentValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();

        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();

        fsa.assertTrue(autoPolicyPaymentBasePage.isAutoPolicyPaymentHeaderCorrect(), errorMessage("Auto policy payment header"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isMonthlyAutoPayBankHeaderCorrect(), errorMessage("Monthly auto pay bank header"));

        fsa.assertTrue(autoPolicyPaymentBasePage.isSixTermPriceSubHeaderDisplayed(), errorMessage("Six term price subheader"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isSixMonthTermPriceAmountDisplayed(MONTHLY_EFT), errorMessage("Six Month  Auto Pay Bank Term Price Amount"));

        AppStore sessionStorageAppStore = additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore();

        fsa.assertTrue(autoPolicyPaymentBasePage.isFirstMonthlyPaymentLabelCorrect(), errorMessage("First monthly payment label"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isSixMonthTermPaymentAmountDisplayed(MONTHLY_EFT, "p", sessionStorageAppStore), errorMessage("First monthly payment amount"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isOneTimeFeeLabelCorrect(), errorMessage("One time fee label"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isPolicyFeeAmountDisplayedAuto("p"), errorMessage("One time fee amount"));

        fsa.assertTrue(autoPolicyPaymentBasePage.isDueTodayCorrect(), errorMessage("Due today label"));
        autoPolicyPaymentBasePage.isDueTodayAmountDisplayedAuto(MONTHLY_EFT, fsa);

        // validating the down payment, due today amount, and full term amount for the card payment

        autoPolicyPaymentBasePage.selectCardPaymentRadioButtonAlternative();
        fsa.assertTrue(autoPolicyPaymentBasePage.isMonthlyAutoPayCardHeaderCorrect(), errorMessage("Monthly auto pay card header"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isOneTimeFeeLabelCorrect(), errorMessage("One time fee label"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isPolicyFeeAmountDisplayedAuto("p"), errorMessage("One time fee amount"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isSixMonthTermPriceAmountDisplayed(MONTHLY_DEBIT_CREDIT_CARD), errorMessage("Six Month Term Price Amount for Card"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isSixMonthTermPaymentAmountDisplayed(MONTHLY_DEBIT_CREDIT_CARD, "p", sessionStorageAppStore), errorMessage("First monthly payment amount for Card"));
        autoPolicyPaymentBasePage.isDueTodayAmountDisplayedAuto(MONTHLY_DEBIT_CREDIT_CARD, fsa);
        fsa.assertTrue(autoPolicyPaymentBasePage.isPolicyFeeSideBarHeaderCorrect(), errorMessage("Policy Fee Header"));


        String landingStateCode = sessionStorageAppStore.getData().getLandingStateCode();
        if (autoPolicyPaymentBasePage.isRequiredMembershipFees(landingStateCode)) {
            fsa.assertTrue(autoPolicyPaymentBasePage.isMembershipFeesSideBarMsgCorrect(), errorMessage("Administrative Fee Message for " + landingStateCode));
        } else if (autoPolicyPaymentBasePage.isRequiredVehicleFees(landingStateCode)) {
            if (!sessionStorageAppStore.getVerifyResponse().getPolicyFee().getAmount().equals("0.00")) {
                fsa.assertTrue(autoPolicyPaymentBasePage.isVehicleFeesSideBarMsgCorrect(), errorMessage("Vehicle Fee Message for " + landingStateCode));
            }
        } else {
            fsa.assertTrue(autoPolicyPaymentBasePage.isPolicyFeesSideBarMsgCorrect(), errorMessage("Policy/Membership Fee Message for " + landingStateCode));
        }

        fsa.assertTrue(autoPolicyPaymentBasePage.isBankPaymentRadioButtonDisplayedAlternative(), "Bank payment radio button is displayed");
        fsa.assertTrue(autoPolicyPaymentBasePage.isBankPaymentLabelCorrect("Bank payment"), errorMessage("Bank payment label"));
        // re-assigning session storage
        sessionStorageAppStore = additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore();
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = sessionStorageAppStore.getVerifyResponse().getPaymentSchedules();

        String administrativeChargeForDebitCard = paymentSchedules.stream().filter(p -> p.getPayPlanDescription().equals(MONTHLY_DEBIT_CARD_DESCRIPTION)).findFirst().get().getAdministrativeCharges().getCurrencyAmount();
        String administrativeChargeForCreditCard = paymentSchedules.stream().filter(p -> p.getPayPlanDescription().equals(MONTHLY_DEBIT_CREDIT_CARD)).findFirst().get().getAdministrativeCharges().getCurrencyAmount();
        String administrativeChargeForBankAccount = paymentSchedules.stream().filter(p -> p.getPayPlanDescription().equals(MONTHLY_EFT)).findFirst().get().getAdministrativeCharges().getCurrencyAmount();

        String expectedBankAccountServiceChargeLabel = String.format("$%d in service charges", Math.round(Double.parseDouble(administrativeChargeForBankAccount)));
        String expectedDebitCardServiceChargeLabel = String.format("$%d: Debit card", Math.round(Double.parseDouble(administrativeChargeForDebitCard)));
        String expectedCreditCardServiceChargeLabel = String.format("$%d: Credit card", Math.round(Double.parseDouble(administrativeChargeForCreditCard)));

        autoPolicyPaymentBasePage.isBankAccountServiceChargesAmountCorrect(expectedBankAccountServiceChargeLabel, fsa);
        fsa.assertTrue(autoPolicyPaymentBasePage.isCardPaymentRadioButtonDisplayedAlternative(), errorMessage("Card radio button is displayed"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isFutureMonthlyChargesLabelCorrect(), errorMessage("Future monthly service charges"));
        autoPolicyPaymentBasePage.isDebitCardAdministrativeFeeLabelCorrect(expectedDebitCardServiceChargeLabel, fsa);
        autoPolicyPaymentBasePage.isCreditCardAdministrativeFeeLabelCorrect(expectedCreditCardServiceChargeLabel, fsa);
        autoPolicyPaymentBasePage.logInfoMessage(sessionStorageAppStore.getData().getQuoteNumber());

        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}, enabled = false)
    public void autoPaymentMonthlyPayCardPageContentValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();

        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayCard();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        AppStore sessionStorageAppStore = additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore();
        fsa.assertTrue(autoPolicyPaymentBasePage.isAutoPolicyPaymentHeaderCorrect(), errorMessage("Auto policy payment header"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isMonthlyAutoPayCardHeaderCorrect(), errorMessage("Monthly auto pay card header"));

        fsa.assertTrue(autoPolicyPaymentBasePage.isSixTermPriceSubHeaderDisplayed(), errorMessage("Six term price subheader"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isSixMonthTermPriceAmountDisplayed(MONTHLY_DEBIT_CREDIT_CARD), errorMessage("Six Month Term Price Amount"));

        fsa.assertTrue(autoPolicyPaymentBasePage.isFirstMonthlyPaymentLabelCorrect(), errorMessage("First monthly payment label"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isSixMonthTermPaymentAmountDisplayed(MONTHLY_DEBIT_CREDIT_CARD, "p", sessionStorageAppStore), errorMessage("First monthly payment amount"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isOneTimeFeeLabelCorrect(), errorMessage("One time fee label"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isPolicyFeeAmountDisplayedAuto("p"), errorMessage("One time fee amount"));

        fsa.assertTrue(autoPolicyPaymentBasePage.isDueTodayCorrect(), errorMessage("Due today label"));
        autoPolicyPaymentBasePage.isDueTodayAmountDisplayedAuto(MONTHLY_DEBIT_CREDIT_CARD, fsa);

        // validating the down payment, due today amount, and full term amount for the bank payment

        autoPolicyPaymentBasePage.selectBankPaymentRadioButtonAlternate();
        fsa.assertTrue(autoPolicyPaymentBasePage.isMonthlyAutoPayBankHeaderCorrect(), errorMessage("Monthly auto pay bank header"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isOneTimeFeeLabelCorrect(), errorMessage("One time fee label"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isPolicyFeeAmountDisplayedAuto("p"), errorMessage("One time fee amount"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isSixMonthTermPriceAmountDisplayed(MONTHLY_EFT), errorMessage("Six Month Term Price Amount for Card"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isSixMonthTermPaymentAmountDisplayed(MONTHLY_EFT, "p", sessionStorageAppStore), errorMessage("First monthly payment amount for Card"));
        autoPolicyPaymentBasePage.isDueTodayAmountDisplayedAuto(MONTHLY_EFT, fsa);
        fsa.assertTrue(autoPolicyPaymentBasePage.isPolicyFeeSideBarHeaderCorrect(), errorMessage("Policy Fee Header"));

        String landingStateCode = sessionStorageAppStore.getData().getLandingStateCode();
        if (autoPolicyPaymentBasePage.isRequiredMembershipFees(landingStateCode)) {
            fsa.assertTrue(autoPolicyPaymentBasePage.isMembershipFeesSideBarMsgCorrect(), errorMessage("Administrative Fee Message for " + landingStateCode));
        } else if (autoPolicyPaymentBasePage.isRequiredVehicleFees(landingStateCode)) {
            if (!sessionStorageAppStore.getVerifyResponse().getPolicyFee().getAmount().equals("0.00")) {
                fsa.assertTrue(autoPolicyPaymentBasePage.isVehicleFeesSideBarMsgCorrect(), errorMessage("Vehicle Fee Message for " + landingStateCode));
            }
        } else {
            fsa.assertTrue(autoPolicyPaymentBasePage.isPolicyFeesSideBarMsgCorrect(), errorMessage("Policy/Membership Fee Message for " + landingStateCode));
        }

        //   sa.assertTrue(autoPolicyPaymentMonthlyPayOneUI.isSelectPreferredPaymentLabelCorrect(), errorMessage("Select preferred payment method label"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isBankPaymentRadioButtonDisplayedAlternative(), "Bank payment radio button is displayed");
        fsa.assertTrue(autoPolicyPaymentBasePage.isBankPaymentLabelCorrect("Bank payment"), errorMessage("Bank payment label"));
        // re-assigning session storage
        sessionStorageAppStore = autoPolicyPaymentBasePage.getSessionStorageAppStore();
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = sessionStorageAppStore.getVerifyResponse().getPaymentSchedules();

        String administrativeChargeForDebitCard = paymentSchedules.stream().filter(p -> p.getPayPlanDescription().equals(MONTHLY_DEBIT_CARD_DESCRIPTION)).findFirst().get().getAdministrativeCharges().getCurrencyAmount();
        String administrativeChargeForCreditCard = paymentSchedules.stream().filter(p -> p.getPayPlanDescription().equals(MONTHLY_DEBIT_CREDIT_CARD)).findFirst().get().getAdministrativeCharges().getCurrencyAmount();
        String administrativeChargeForBankAccount = paymentSchedules.stream().filter(p -> p.getPayPlanDescription().equals(MONTHLY_EFT)).findFirst().get().getAdministrativeCharges().getCurrencyAmount();

        String expectedBankAccountServiceChargeLabel = String.format("$%d in service charges", Math.round(Double.parseDouble(administrativeChargeForBankAccount)));
        String expectedDebitCardServiceChargeLabel = String.format("$%d: Debit card", Math.round(Double.parseDouble(administrativeChargeForDebitCard)));
        String expectedCreditCardServiceChargeLabel = String.format("$%d: Credit card", Math.round(Double.parseDouble(administrativeChargeForCreditCard)));

        autoPolicyPaymentBasePage.isBankAccountServiceChargesAmountCorrect(expectedBankAccountServiceChargeLabel, fsa);
        fsa.assertTrue(autoPolicyPaymentBasePage.isCardPaymentRadioButtonDisplayedAlternative(), errorMessage("Card radio button is displayed"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isFutureMonthlyChargesLabelCorrect(), errorMessage("Future monthly service charges"));
        autoPolicyPaymentBasePage.isDebitCardAdministrativeFeeLabelCorrect(expectedDebitCardServiceChargeLabel, fsa);
        autoPolicyPaymentBasePage.isCreditCardAdministrativeFeeLabelCorrect(expectedCreditCardServiceChargeLabel, fsa);
        autoPolicyPaymentBasePage.logInfoMessage(sessionStorageAppStore.getData().getQuoteNumber());

        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}, enabled = false)
    public void autoPaymentMonthlyPayPageBackAndForthValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);


        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        fsa.assertTrue(autoPolicyPaymentBasePage.isMonthlyAutoPayBankHeaderCorrect());
        fsa.assertTrue(autoPolicyPaymentBasePage.goBackToHowWouldYouLikeToPayPage(), errorMessage("How Would You Like To Pay"));
        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();
        fsa.assertTrue(autoPolicyPaymentBasePage.isMonthlyAutoPayBankHeaderCorrect());

        autoPolicyPaymentBasePage.logInfoMessage(additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore().getData().getQuoteNumber());
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}, enabled = false)
    public void monthlyPayBankPaymentSidebarValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();

        fsa.assertTrue(policyPaymentBasePage.clickSetUpPaymentButton(), "Add bank side bar card opened successfully");
        fsa.assertTrue(policyPaymentBasePage.closeAddPaymentMethodContainer(false), "Add bank side bar card closed successfully");
        policyPaymentBasePage.logInfoMessage(additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore().getData().getQuoteNumber());

        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_MONTHLYPAY_PAGE}, enabled = false)
    public void monthlyPayCardPaymentSidebarValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        autoPolicyPaymentBasePage.selectCardPaymentRadioButtonAlternative();
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        fsa.assertTrue(policyPaymentBasePage.clickSetUpPaymentButton(), "Add card side bar opened successfully");
        fsa.assertTrue(policyPaymentBasePage.closeAddPaymentMethodContainer(false), "Add card side bar closed successfully");
        autoPolicyPaymentBasePage.logInfoMessage(additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore().getData().getQuoteNumber());
        autoPolicyPaymentBasePage.addSauceLabsLinkInLog();
        fsa.assertAll();
    }

    private String errorMessage(String item) {
        return item + " displays expected text";
    }

}
