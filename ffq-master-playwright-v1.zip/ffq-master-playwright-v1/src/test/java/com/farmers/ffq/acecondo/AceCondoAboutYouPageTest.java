package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoAdditionalInfoPage;
import com.farmers.ffq.ace.condo.AceCondoContactInfoPage;
import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.condo.AceCondoReviewQuotePage;
import com.farmers.ffq.ace.hrc.common.AceHRCAboutYouBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCAdditionalInfoBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoAboutYouPageTest extends AutomationFramework {
    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,LA,MA,MS,MT,NC,TX,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ABOUT_YOU_PAGE})
    public void pageContentValidationAboutYouPageCondoLob(ApplicantAceHome applicant) throws Exception {
        applicant.setInEscrow(true);
        applicant.setNewlyOwned(true);
        AceHRCAboutYouBasePage aboutYouPage = new AceCondoNavigationHelper().navigateToAceCondoAboutYouPage(applicant);

        AppStore sessionStorageData = aboutYouPage.getSessionStorageAppStore();
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        // validate content for primary applicant
        aboutYouPage.validateContentOfPrimaryApplicant(fsa, applicant.getStateCode(), CONDO);
        if (!aboutYouPage.isNoEligibleOccupationState(applicant.getStateCode())) {
            validateEligibleOccupation(applicant, fsa, aboutYouPage, sessionStorageData.getData().getLandingStateCode(), applicant.getOccupation(), true);
        }

        // validate content in spouse section
        aboutYouPage.validateSpouseSectionIsDisplayed(fsa);
        aboutYouPage.clickOnMarriedOrInDomesticRelationCheckbox();
        aboutYouPage.validateMarriedOrInDomesticRelationCheckBoxDescription(fsa);
        aboutYouPage.validateContentOfSpouseApplicant(fsa, applicant.getStateCode(), CONDO);
        if (!aboutYouPage.isNoEligibleOccupationState(applicant.getStateCode())) {
            validateEligibleOccupation(applicant, fsa, aboutYouPage, sessionStorageData.getData().getLandingStateCode(), applicant.getOccupation(), false);
        }

        //validate the discounts
        aboutYouPage.validateDiscounts(AceHRCBasePage.ABOUT_YOU, applicant, CONDO, fsa);

        aboutYouPage.validateQuoteText(AceHRCBasePage.ABOUT_YOU, applicant.getQuoteNumber(), fsa, false);
        aboutYouPage.validateAgentSection(fsa, AceHRCBasePage.ABOUT_YOU, applicant.getAgentId(), CONDO);

        //validate occupations
        if (!applicant.getOccupation().isBlank() && !aboutYouPage.isNoEligibleOccupationState(applicant.getStateCode())) {
            aboutYouPage.clickRemoveOccupationLink(true);
            aboutYouPage.clickRemoveOccupationButton();
            aboutYouPage.clickRemoveOccupationLink(false);
            aboutYouPage.clickRemoveOccupationButton();
        }

        // validate prior or current address content
        AppStore.Home.Field field = sessionStorageData.getHome().getAddressForm().getFields().get(0);
        aboutYouPage.validateContentOfPriorOrCurrentAddress(fsa, field);
        fsa.assertAll("Content validation - About You page - Condo lob.");
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,LA,MA,MS,MT,NC,TX,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_ABOUT_YOU_PAGE})
    public void validateErrorMessagesAboutYouPageCondoLob(ApplicantAceHome applicantAceHome) throws Exception {
        AceHRCAboutYouBasePage aboutYouPageAceHome = new AceCondoNavigationHelper().navigateToAceCondoAboutYouPage(applicantAceHome);

    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        //attempting to skip field entering
        aboutYouPageAceHome.waitAboutYouPageToRender();
        aboutYouPageAceHome.fillOutApplicantFormWithNoInput();
        aboutYouPageAceHome.validateErrorMessageForNoInput(true, applicantAceHome, fsa);

        // validate error message for incorrect input
        aboutYouPageAceHome.fillOutApplicantFormWithIncorrectInput(true);
        aboutYouPageAceHome.validateErrorMessageForInvalidInput(true, applicantAceHome, fsa);

        // validate is age<=15 and age>=99 & Date of Birth is a valid entry
        aboutYouPageAceHome.validateInvalidErrorMessagesForAgeLimitAndDob(fsa, applicantAceHome, true);
        driver().navigate().refresh();
        aboutYouPageAceHome.waitAboutYouPageToRender();

        //validate First/Last name char limit - 15 char and 20 char max respectively
        aboutYouPageAceHome.fillOutApplicantFormWithValues("MoreThanFifteenChars","MoreThanTwentyCharacters", "09/09/1600" );
        aboutYouPageAceHome.validateCharacterLimitForFirstNameLastName(fsa);
        driver().navigate().refresh();
        aboutYouPageAceHome.waitAboutYouPageToRender();

        //Not allowed special chars and numeric chars in First name and last name field
        aboutYouPageAceHome.validateNotAllowedSpecialCharsInFirstLastName(fsa);
        driver().navigate().refresh();
        aboutYouPageAceHome.waitAboutYouPageToRender();
        aboutYouPageAceHome.validateNotAllowedNumericInFirstLastName(fsa);

        //Not allowed special chars in DOB and spouse's DOB field
        aboutYouPageAceHome.validateNotAllowedSpecialCharInDOB(fsa);


        // check the spouse checkbox in order to validate errors in spouse section
        aboutYouPageAceHome.clickOnMarriedOrInDomesticRelationCheckbox();
        aboutYouPageAceHome.fillOutApplicantFormWithValues(applicantAceHome.getFirstName(), applicantAceHome.getLastName(), applicantAceHome.getDateOfBirth());
        aboutYouPageAceHome.selectGender(applicantAceHome);

        // validate error messages when no input is provided
        aboutYouPageAceHome.fillOutApplicantFormWithNoInput();
        aboutYouPageAceHome.validateErrorMessageForNoInput(false, applicantAceHome, fsa);

        aboutYouPageAceHome.fillOutApplicantFormWithIncorrectInput(false);
        aboutYouPageAceHome.validateErrorMessageForInvalidInput(false, applicantAceHome, fsa);

        //validate First/Last name char limit - 15 char and 20 char max respectively
        aboutYouPageAceHome.fillOutSpouseApplicantFormWithValues("MoreThanFifteenChars","MoreThanTwentyCharacters", "09/09/1600" );
        aboutYouPageAceHome.validateCharLimitFirstLastNameSpouse(fsa);

        // invalidate condition is age<=15 and age>=99 & Date of Birth is a valid entry
        aboutYouPageAceHome.validateInvalidErrorMessagesForAgeLimitAndDob(fsa, applicantAceHome, false);

        //basePageAboutYouAceHome.clickOnMarriedOrInDomesticRelationCheckbox();
        //Not allowed special chars and numeric chars in Spouse's First name and Spouse's last name field
        aboutYouPageAceHome.validateNotAllowedSpecialCharsInFirstLastNameSpouse(fsa);
        driver().navigate().refresh();
        aboutYouPageAceHome.waitAboutYouPageToRender();
        aboutYouPageAceHome.isSpouseFirstNameInputBoxDisplayed();
        aboutYouPageAceHome.validateNotAllowedNumericInFirstLastNameSpouse(fsa);

        //Not allowed special chars in DOB and spouse's DOB field
        aboutYouPageAceHome.validateNotAllowedSpecialCharInDOBSpouse(fsa);

        // validate error message if prior or current address available
        AppStore sessionStorageData = aboutYouPageAceHome.getSessionStorageAppStore();
        if(sessionStorageData.getHome().getAddressForm().getFields().get(0).getIsNewHome().equals("Y")){
            aboutYouPageAceHome.fillOutApplicantFormWithNoInput();
            aboutYouPageAceHome.validateErrorForNoInputInCurrentOrPriorAddressFields(fsa);

            aboutYouPageAceHome.fillOutCurrentOrPriorAddressFieldWithInValidData();
            aboutYouPageAceHome.clickContinueButton();
            aboutYouPageAceHome.validateErrorForInvalidInputInCurrentOrPriorAddressFields(fsa);

            aboutYouPageAceHome.validateNotAllowedSpecialCharInCity(fsa);
            aboutYouPageAceHome.fillOutUnitNumberWithInValidData();
            fsa.assertTrue(aboutYouPageAceHome.isInvalidUnitErrorDisplayed(), "Invalid unit# is not displayed");
        }
        fsa.assertAll();
    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,LA,MA,MS,MT,NC,TX,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ABOUT_YOU_PAGE})
    public void enteredDetailsRetainedWhenNavigatedBackAndForthAboutYouPageCondoLob(ApplicantAceHome applicant) throws Exception {

        AceHRCAboutYouBasePage aboutYouPage = new AceCondoNavigationHelper().navigateToAceCondoAboutYouPage(applicant);

    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "Navigated to About You page - Condo.");
        aboutYouPage.navigateBack();

        AceCondoAdditionalInfoPage additionalInfoPage = new AceCondoAdditionalInfoPage();
        Assert.assertTrue(additionalInfoPage.isOnAdditionalInfoPage(), "Navigated to Additional Info page - Condo.");
        additionalInfoPage.validateAdditionalInfoSelections(applicant, fsa);
        additionalInfoPage.clickContinueButton();

        Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "Navigated to About You page - Condo.");
        aboutYouPage.fillOutTheDataInAboutYouPage(applicant, true);
        AceCondoContactInfoPage contactInfoPage = new AceCondoContactInfoPage();
        Assert.assertTrue(contactInfoPage.isOnContactInfoPage(true), "Navigated to Contact Info page - Condo.");
        contactInfoPage.navigateBack();

        aboutYouPage = new AceHRCAboutYouBasePage();
        Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "Navigated to About You page - Condo.");
        aboutYouPage.validateAboutYouSelections(applicant, false, fsa);

        fsa.assertAll("About You page - Data is saved when navigated back and forth from the page.");

    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,LA,MA,MS,MT,NC,TX,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ABOUT_YOU_PAGE})
    public void testDataNotSavedWhenNavigatedBackAboutYouPageCondoLob(ApplicantAceHome applicant) throws Exception {
        AceHRCAboutYouBasePage aboutYouPageAceHome = new AceCondoNavigationHelper().navigateToAceCondoAboutYouPage(applicant);

    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
        Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "About You page is reached");
        aboutYouPage.fillOutTheDataInAboutYouPage(applicant, false);
        aboutYouPageAceHome.navigateBack();

        AceHRCAdditionalInfoBasePage additionalInfoPage = new AceHRCAdditionalInfoBasePage();
        Assert.assertTrue(additionalInfoPage.isOnAdditionalInfoPage(), "Additional Info page is reached");
        additionalInfoPage.clickContinueButton();

        aboutYouPage = new AceHRCAboutYouBasePage();
        Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "About You page is reached");
        aboutYouPageAceHome.validateDataNotSaved(applicant, fsa);
        fsa.assertAll("About You page - Data not saved when navigated back from the page.");

    }

    @Skip
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ,OH,OR,LA,MA,MS,MT,NC,TX,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_ABOUT_YOU_PAGE})
    public void validateFieldsNotEditableWhenQuoteIsRatedAboutYouPageCondoLob(ApplicantAceHome applicant) throws Exception {

        AceHRCAboutYouBasePage aboutYouPageAceHome = new AceHRCAboutYouBasePage();
        AceCondoReviewQuotePage reviewQuotePage = new AceCondoNavigationHelper().navigateToAceCondoReviewQuotePage(applicant);
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        reviewQuotePage.navigateBack(3);
        Assert.assertTrue(aboutYouPageAceHome.isOnAboutYouPage(true), "About You page is reached after quote is rated.");
        aboutYouPageAceHome = new AceHRCAboutYouBasePage();
        aboutYouPageAceHome.validateAboutYouSelections(applicant,true, fsa);
        fsa.assertAll("About You page - Data is not editable when quote is rated");
    }

    private void validateEligibleOccupation(ApplicantAceHome applicant, FarmersSoftAssert fsa, AceHRCAboutYouBasePage aboutYouPageAceHome,
                                            String stateCode, String occupation, boolean isPrimaryApplicant) throws Exception {
        // validate content of eligible occupation button, title, side sheet
        // Add occupation as per applicant, validate added occupation, remove occupation, validate content of remove occupation pop up
        if (!stateCode.equals(TN)) {
            aboutYouPageAceHome.validateContentForEligibleOccupationButtonAndTitle(fsa, isPrimaryApplicant);
            aboutYouPageAceHome.validateContentOfEligibleOccupationSideSheet(fsa, stateCode, isPrimaryApplicant);
            aboutYouPageAceHome.clickEligibleOccupationButton(isPrimaryApplicant);
            if (!applicant.getOccupation().isBlank()) {
                aboutYouPageAceHome.selectOccupationRadioButtonAndValidateSelectedOccupation(fsa, occupation);
                aboutYouPageAceHome.clickRemoveOccupationLink(isPrimaryApplicant);
                aboutYouPageAceHome.validateRemoveOccupationHeaderAndQuestion(fsa);
                aboutYouPageAceHome.clickKeepOccupationButton();
                aboutYouPageAceHome.clickRemoveOccupationLink(isPrimaryApplicant);
                aboutYouPageAceHome.clickRemoveOccupationButton();
                aboutYouPageAceHome.clickEligibleOccupationButton(isPrimaryApplicant);
                aboutYouPageAceHome.selectOccupationRadioButton(occupation);
                aboutYouPageAceHome.clickAddButton();
            }
            else{
                aboutYouPageAceHome.clickCancelButton();
            }
        } else {
            aboutYouPageAceHome.clickCloseIcon();
        }
    }
}
