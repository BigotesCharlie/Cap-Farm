package com.farmers.ffq.auto;

import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.Property;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static com.farmers.ffq.utils.GlobalVariables.FILTER;

public class KnockoutLeadFormTest extends AutomationFramework {

	@Test(groups = {FFQ_ONEUI, KNOCKOUT_LEAD_FORM}, enabled = false)
	public void validateKnockoutLeadFormPage() throws Exception {
		if (Property.getUri().contains("ffqautouiqa2")) {
			new LandingPage().enterLandingPageData(LOB_AUTO, "85051");
			KnockoutLeadFormPage knockoutLeadFormPage = new KnockoutLeadFormPage();
			FarmersSoftAssert fsa = new FarmersSoftAssert();
			// validate page content
			knockoutLeadFormPage.validatePageContent(fsa);
			// validate error messages
			knockoutLeadFormPage.validateErrorMessages(fsa);
			fsa.assertAll();
		}
	}

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MI}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, KNOCKOUT_LEAD_FORM})
	public void validateKnockoutLeadFormFlow(AutoApplicant applicant) throws Exception {
        LeadFormThankYouPage leadFormThankYouPage = new LeadFormThankYouPage();
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
		if (Property.getUri().contains("ffqautouiuat")) {
            applicant.setZipCode("48009");
            aceAutoNavigationHelper.navigateToAutoEnterAddressPage(applicant);
            ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
            if (continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()) {
                //FL always displays BW dialog, so click on Continue to BW and resume normal flow
                continueWithBristolWestPage.continueWithBWPage(true);
                continueWithBristolWestPage.waitForSpinnerToBeGone();
            }
            applicant.setResidentAddress("1201 Lillian Dr, Flint MI 48505");
			AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
			autoEnterAddressPage.changeZipcode("48505");
			autoEnterAddressPage.approveZipChangeIfPresent();
			KnockoutLeadFormPage knockoutLeadFormPage = new KnockoutLeadFormPage();
			FarmersSoftAssert fsa = new FarmersSoftAssert();
			knockoutLeadFormPage.validatePageContent(fsa);
            knockoutLeadFormPage.enterAddressContactInfoAndSubmit(applicant);
			leadFormThankYouPage.validateLeadFormThankYouPageContent(fsa, knockoutLeadFormPage.isUseMobileViewEnabled());
			fsa.assertAll();
		}

        if (Property.getUri().contains("ffqautouiqa2")) {
            new LandingPage().enterLandingPageData(LOB_AUTO, "85051");
            applicant.setResidentAddress("3126 W Harmont Dr");
            KnockoutLeadFormPage knockoutLeadFormPage = new KnockoutLeadFormPage();

            FarmersSoftAssert fsa = new FarmersSoftAssert();
            knockoutLeadFormPage.enterValuesAndSubmit(applicant);
            leadFormThankYouPage.validateLeadFormThankYouPageContent(fsa, knockoutLeadFormPage.isUseMobileViewEnabled());
            fsa.assertAll();
        }
	}

}
