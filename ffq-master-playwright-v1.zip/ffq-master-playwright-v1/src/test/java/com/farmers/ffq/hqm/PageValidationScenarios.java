package com.farmers.ffq.hqm;


import com.farmers.framework.playwright.compat.*;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.hqm.*;
import com.farmers.ffq.hqm.pages.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.Mailinator;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static com.farmers.ffq.utils.GlobalVariables.*;


/**
 * Farmers Fast Quote (FFQ) - Page Validation Scenarios - Home Quote Modernization (HQM).
 */
public class PageValidationScenarios extends AutomationFramework {

    private static final String PROPERTY_DETAILS_PAGE = "propertyDetailsPage";
	private static final String QUALITY_PAGE = "qualityPage";
	private static final String PROPERTY_PAGE = "propertyPage";
	private static final double quoteDelta = 0.30; // quote price fluctuation delta max (5%) (used when no Postgres connection)

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})
    public void testAddressPage(ApplicantHQM applicant) throws Exception {
        validateAddressPage(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})
    public void testAddressPageMobile(ApplicantHQM applicant) throws Exception {
        validateAddressPage(applicant, MOBILE_BROWSER);
    }

    private void validateAddressPage (ApplicantHQM applicant, String browserType) throws Exception {
//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);

        PageLinksHQM addressPageLinks = new PageLinksHQM("addressPage", applicant, browserType, false);
        addressPage.validatePageLinks(addressPageLinks, quoteNumber, fsa);
        StaticContentHQM staticContent = new ApiHelper().getStaticContentFromJson(quoteNumber);
        addressPage.validatePageTitlesSubtitles(applicant, browserType, fsa, staticContent);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.validatePageFooters(applicant.stateCode, browserType, staticContent);
        addressPage.validatePageErrors(applicant, fsa);
        addressPage.validatePageFieldsLength(fsa);
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        PageLinksHQM propertyPageLinks = new PageLinksHQM(PROPERTY_PAGE, applicant, browserType, false);
        propertyPageLinks.buttonNext = (propertyPage.getYearBuilt().isEmpty() || propertyPage.getSquareFeet().isEmpty()) ? 2 : 3;
        propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);
        propertyPage.clickBack();

        addressPage = new AddressPage();
        addressPage.verifyPageFields(applicant, fsa);
        addressPage.validatePageLinks(addressPageLinks, quoteNumber, fsa);
        addressPage.smallZipChange(applicant);
        addressPageLinks.checkAgentInfo = 0;
        propertyPageLinks.checkAgentInfo = 0;

        propertyPage = new PropertyPage();
        propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);

        propertyPage.clickStepperAddress(browserType);
        addressPage = new AddressPage();
        addressPage.setPolicyStartDateInFuture(applicant);  // because after zip change - Policy Start date resets to today
        addressPage.verifyPageFields(applicant, fsa);

        addressPage.validatePageLinks(addressPageLinks, quoteNumber, fsa);
        addressPage.validatePageTitlesSubtitles(applicant, browserType, fsa, staticContent);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.validatePageFooters(applicant.stateCode, browserType, staticContent);

        //validate Mobile or Manufactured home checkbox
        if (!applicant.agentId.isBlank()) {
            driver().switchTo().newWindow(PWWindowType.TAB);
            addressPage = new AddressPage(applicant, AS, browserType);
            addressPage.populateFields(applicant, fsa);
        }
        addressPage.checkMobileManufacturedHome();
        addressPage.validateNoEmployerGroupSection(fsa);
        addressPage.clickButtonAgree();
        ThankYouRedirectPage thankYouRedirectPage = new ThankYouRedirectPage();
        thankYouRedirectPage.validatePageContent(quoteNumber, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})
    public void testPropertyPage(ApplicantHQM applicant) throws Exception {
        validatePropertyPage(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})
    public void testPropertyPageMobile(ApplicantHQM applicant) throws Exception {
        validatePropertyPage(applicant, MOBILE_BROWSER);
    }

    private void validatePropertyPage(ApplicantHQM applicant, String browserType) throws Exception {
//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        PageLinksHQM propertyPageLinks = new PageLinksHQM(PROPERTY_PAGE, applicant, browserType, false);
        propertyPageLinks.buttonNext = (propertyPage.getYearBuilt().isEmpty() || propertyPage.getSquareFeet().isEmpty()) ? 2 : 3;
        propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        propertyPage.validatePageTitles(fsa, staticContent);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        propertyPage.validatePageFooters(staticContent);
        propertyPage.validatePageErrors(applicant);

        propertyPageLinks.buttonNext = 2;
        propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);
        propertyPage.validateHelpDialogs(applicant, fsa, staticContent);

        if (applicant.stateCode.equals(VA)) {
            propertyPage.clickBack();

            // verify prefill with Square Feet value > 5 digits
            ApplicantHQM applicant1 = applicant.clone();
            applicant.keep360Prefill = true;
            applicant.addressApt = "3950 BATTERY BLVD";
            applicant.city = "WILLIAMSBURG";
            applicant.stateCode = "VA";
            applicant.state = "Virginia";
            applicant.zipCode = "23185";
            addressPage = new AddressPage();
            addressPage.populateFields(applicant, fsa);
            addressPage.clickButtonAgree();

            propertyPage = new PropertyPage();
            Assert.assertTrue(propertyPage.getSquareFeet().isEmpty(),
                    "Property page - Finished Square Feet field is blank, when 360 returns a value with > 5 digits.");
            propertyPage.setYearBuilt("");
            applicant = applicant1;
        }

        propertyPage.setYearBuilt(String.valueOf(applicant.yearBuilt));
        propertyPage.setSquareFeet(applicant.squareFeet);
        propertyPage.clickNext();

        QualityGradePage qualityGradePage = new QualityGradePage();
        qualityGradePage.clickStepperAddress(browserType);
        addressPage = new AddressPage();
        addressPage.setZip(applicant.zipCode);
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

        propertyPage = new PropertyPage();
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        propertyPage.clickNext();

        qualityGradePage = new QualityGradePage();
        PageLinksHQM qualityGradePageLinks = new PageLinksHQM(QUALITY_PAGE, applicant, browserType, false);
        qualityGradePageLinks.buttonNext = qualityGradePage.getSelected().isEmpty() ? 2 : 3;
        if (applicant.agentId.isEmpty()) {
            qualityGradePage.validatePageLinks(qualityGradePageLinks, quoteNumber, fsa);
        }
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityGradePage.clickBack();

        propertyPage = new PropertyPage();
        propertyPageLinks.buttonNext = 3;
        if (applicant.agentId.isEmpty()) {
            propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);
        }
        propertyPage.verifyPageFields(applicant, fsa, propertyData);

        //TC23540
        driver().navigate().refresh();
        propertyPage = new PropertyPage();
        propertyPageLinks.buttonNext = 3;
        if (applicant.agentId.isEmpty()) {
            propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);
        }
        propertyPage.verifyPageFields(applicant, fsa, propertyData);
        propertyPage.validatePageTitles(fsa, staticContent);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        propertyPage.validatePageFooters(staticContent);
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})
    public void testQualityGradePage(ApplicantHQM applicant) throws Exception {
        validateQualityGradePage(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})
    public void testQualityGradePageMobile(ApplicantHQM applicant) throws Exception {
        validateQualityGradePage(applicant, MOBILE_BROWSER);
    }

    private void validateQualityGradePage(ApplicantHQM applicant, String browserType) throws Exception {

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        List<String> discounts = propertyPage.getDiscounts();
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityPage.selectQualityGrade(applicant, propertyData);
        PageLinksHQM qualityPageLinks = new PageLinksHQM(QUALITY_PAGE, applicant, browserType, false);
        qualityPageLinks.buttonNext = qualityPage.getSelected().isEmpty() ? 2 : 3;
        qualityPage.validatePageLinks(qualityPageLinks, quoteNumber, fsa);
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        qualityPage.validateHelpDialogs(fsa);
        qualityPage.validatePageTitles(fsa, staticContent);
        qualityPage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityPage.validatePageFooters(staticContent);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        PageLinksHQM propertyDetailsPageLinks = new PageLinksHQM(PROPERTY_DETAILS_PAGE, applicant, browserType, false);
        propertyDetailsPageLinks.buttonNext = propertyDetailsPage.isNextButtonEnabled(applicant.stateCode) ? 3 : 2;
        propertyDetailsPage.validatePageLinks(propertyDetailsPageLinks, quoteNumber, fsa);
        propertyDetailsPage.clickBack();

        qualityPage = new QualityGradePage();
        qualityPage.verifyPageFields(applicant, propertyData);
        qualityPageLinks.buttonNext = 3;
        qualityPage.validatePageLinks(qualityPageLinks, quoteNumber, fsa);
        qualityPage.validateHelpDialogs(fsa);
        driver().navigate().refresh();
        qualityPage.validatePageLinks(qualityPageLinks, quoteNumber, fsa);
        qualityPage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityPage.clickNext();

        propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPageLinks.buttonNext = propertyDetailsPage.isNextButtonEnabled(applicant.stateCode) ? 3 : 2;
        propertyDetailsPage.validatePageLinks(propertyDetailsPageLinks, quoteNumber, fsa);

        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})
    public void testPropertyDetailsPage(ApplicantHQM applicant) throws Exception {
        validatePropertyDetailsPage(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})
    public void testPropertyDetailsPageMobile(ApplicantHQM applicant) throws Exception {
        validatePropertyDetailsPage(applicant, MOBILE_BROWSER);
    }

    private void validatePropertyDetailsPage(ApplicantHQM applicant, String browserType) throws Exception {

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER +  quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        List<String> discounts = propertyPage.getDiscounts();
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityGradePage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        if ((propertyData != null) && (!propertyData.getExteriorWallConstruction().isEmpty())) {
            applicant.exteriorWallConstruction = propertyData.getExteriorWallConstruction();
        }
        qualityGradePage.selectQualityGrade(applicant, propertyData);
        qualityGradePage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityGradePage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        PageLinksHQM propertyDetailsPageLinks = new PageLinksHQM(PROPERTY_DETAILS_PAGE, applicant, browserType, false);
        propertyDetailsPageLinks.buttonNext = propertyDetailsPage.isNextButtonEnabled(applicant.stateCode) ? 3 : 2;
        propertyDetailsPage.validatePageLinks(propertyDetailsPageLinks, quoteNumber, fsa);
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        propertyDetailsPage.validatePageTitles(applicant, fsa, staticContent);
        propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
        propertyDetailsPage.validateHelpDialogs(fsa, staticContent);
        propertyDetailsPage.validatePageFieldContents(applicant, fsa);
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.verifyPageFieldSelections(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page 1
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        PageLinksHQM customerInfoPageLinks = new PageLinksHQM("customerInfoPage", applicant, browserType, false);
        customerInfoPageLinks.buttonNext = 2;
        customerInfoPage.validatePageLinks(customerInfoPageLinks, quoteNumber, fsa);
        customerInfoPage.clickBack();

//        Property Details Page
        propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPageLinks = new PageLinksHQM(PROPERTY_DETAILS_PAGE, applicant, browserType, false);
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPageLinks.buttonNext = 3;
        propertyDetailsPage.validatePageLinks(propertyDetailsPageLinks, quoteNumber, fsa);
        propertyDetailsPage.validatePageFieldContents(applicant, fsa);
        propertyDetailsPage.clickNext();

//       Customer Info Page 1
        customerInfoPage = new CustomerInfoPage();
        customerInfoPage.clickStepperProperty(browserType);
        propertyPage = new PropertyPage();
        PageLinksHQM propertyPageLinks = new PageLinksHQM(PROPERTY_PAGE, applicant, browserType, false);
        propertyPageLinks.buttonNext = 3;
        propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);
        propertyPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        propertyPage.clickNext();

//        Quality Grade Page
        qualityGradePage = new QualityGradePage();
        PageLinksHQM qualityGradePageLinks = new PageLinksHQM(QUALITY_PAGE, applicant, browserType, false);
        qualityGradePageLinks.buttonNext = 3;
        qualityGradePage.validatePageLinks(qualityGradePageLinks, quoteNumber, fsa);
        qualityGradePage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityGradePage.clickNext();

        propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.validatePageErrors();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.validatePageLinks(propertyDetailsPageLinks, quoteNumber, fsa);
        propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
        propertyDetailsPage.clickNext();

        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})
    public void testCustomerInfoPage(ApplicantHQM applicant) throws Exception {
        validateCustomerInfoPage(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})
    public void testCustomerInfoPageMobile(ApplicantHQM applicant) throws Exception {
        validateCustomerInfoPage(applicant, MOBILE_BROWSER);
    }

    private void validateCustomerInfoPage(ApplicantHQM applicant, String browserType) throws Exception {

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        List<String> discounts = propertyPage.getDiscounts();
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityGradePage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityGradePage.selectQualityGrade(applicant, propertyData);
        qualityGradePage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityGradePage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        PageLinksHQM customerInfoPageLinks = new PageLinksHQM("customerInfoPage", applicant, browserType, false);
        customerInfoPageLinks.buttonNext = 2;
        customerInfoPage.validatePageLinks(customerInfoPageLinks, quoteNumber, fsa);
        customerInfoPage.validatePageFieldContents(applicant, true, fsa);
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        customerInfoPage.validatePageTitles(applicant, fsa, staticContent);
        customerInfoPage.validatePageErrors(fsa);
        customerInfoPage.validatePageFieldsLength(fsa);
        customerInfoPage.setRequiredFields(applicant);
        discounts = customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
        customerInfoPage.validatePageFieldContents(applicant, false, fsa);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.clickBack();
        customerInfoPageLinks.buttonNext = 3;
        customerInfoPage.validatePageLinks(customerInfoPageLinks, quoteNumber, fsa);
        customerInfoPage.validatePageFieldContents(applicant, false, fsa);

        customerInfoPage.clickStepperProperty(browserType);
        propertyPage = new PropertyPage();
        propertyPage.verifyPageFields(applicant, fsa, propertyData);
        propertyPage.clickNext();
        qualityGradePage = new QualityGradePage();
        qualityGradePage.verifyPageFields(applicant, propertyData);
        qualityGradePage.clickNext();
        propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.verifyPageFieldSelections(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();
        sleep(3);
        customerInfoPage = new CustomerInfoPage();
        customerInfoPage.validatePageLinks(customerInfoPageLinks, quoteNumber, fsa);
        customerInfoPage.validatePageFieldContents(applicant, false, fsa);
        driver().navigate().refresh();
        customerInfoPage.validatePageLinks(customerInfoPageLinks, quoteNumber, fsa);
        customerInfoPage.validatePageFieldContents(applicant, false, fsa);
        customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
        customerInfoPage.clickNext();

        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})
    public void testContactInfoPage(ApplicantHQM applicant) throws Exception {
        validateContactInfoPage(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})
    public void testContactInfoPageMobile(ApplicantHQM applicant) throws Exception {
        validateContactInfoPage(applicant, MOBILE_BROWSER);
    }

    private void validateContactInfoPage(ApplicantHQM applicant, String browserType) throws Exception {

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        List<String> discounts = propertyPage.getDiscounts();
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityGradePage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityGradePage.selectQualityGrade(applicant, propertyData);
        qualityGradePage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityGradePage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        discounts = customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        PageLinksHQM contactInfoPageLinks = new PageLinksHQM("contactInfoPage", applicant, browserType, false);
        contactInfoPageLinks.buttonNext = 2;
        contactInfoPage.validatePageLinks(contactInfoPageLinks, quoteNumber, fsa);
        contactInfoPage.validatePageFieldContents(applicant, true, fsa);
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        contactInfoPage.validatePageTitles(applicant, fsa, staticContent);
        contactInfoPage.validatePageFooters(applicant, null, staticContent);
        contactInfoPage.validatePageErrors(fsa);
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPageLinks.buttonNext = 3;
        contactInfoPage.validatePageLinks(contactInfoPageLinks, quoteNumber, fsa);
        contactInfoPage.validatePageFieldContents(applicant, false, fsa);
        contactInfoPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        discounts = discountsPage.getDiscounts();
        discountsPage.clickStepperProperty(browserType);
        propertyPage = new PropertyPage();
        propertyPage.verifyPageFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        propertyPage.clickNext();
        qualityGradePage = new QualityGradePage();
        qualityGradePage.verifyPageFields(applicant, propertyData);
        qualityGradePage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityGradePage.clickNext();
        propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.verifyPageFieldSelections(applicant, fsa, propertyData);
        propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
        propertyDetailsPage.clickNext();
        sleep(3);
        customerInfoPage = new CustomerInfoPage();
        customerInfoPage.validatePageFieldContents(applicant, false, fsa);
        customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
        customerInfoPage.clickNext();
        driver().navigate().refresh();
        contactInfoPage = new ContactInfoPage();
        contactInfoPage.validatePageLinks(contactInfoPageLinks, quoteNumber, fsa);
        contactInfoPage.validatePageFieldContents(applicant,false, fsa);
        contactInfoPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        contactInfoPage.clickAgreeSubmitButton();
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})
    public void testDiscountsPage(ApplicantHQM applicant) throws Exception {
        validateDiscountsPage(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})
    public void testDiscountsPageMobile(ApplicantHQM applicant) throws Exception {
        validateDiscountsPage(applicant, MOBILE_BROWSER);
    }

    private void validateDiscountsPage(ApplicantHQM applicant, String browserType) throws Exception {

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        List<String> discounts = propertyPage.getDiscounts();
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityGradePage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityGradePage.selectQualityGrade(applicant, propertyData);
        qualityGradePage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityGradePage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        discounts = customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        PageLinksHQM discountsPageLinks = new PageLinksHQM("discountsPage", applicant, browserType, false);
        discountsPage.validatePageLinks(discountsPageLinks, quoteNumber, fsa);
        List<String> discountsBeforeRate = apiHelper.getDiscountsFromJsonBeforeRate(quoteNumber);
        discountsPage.validatePageFieldContents(applicant, true, fsa, discountsBeforeRate);
        discountsPage.validatePreappliedDiscountsBeforeRate(applicant, discountsBeforeRate, fsa);
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        discountsPage.validatePageTitles(!discountsBeforeRate.isEmpty(), fsa, staticContent);
        discountsPage.validatePageSubtitles(applicant, !discountsBeforeRate.isEmpty(), staticContent);
        discountsPage.validateHelpDialogs(applicant, !discountsBeforeRate.isEmpty(), fsa, staticContent);
        discountsPage.validatePageErrors(applicant, fsa);
        discountsPage.setRequiredFields(applicant);
        discountsPage.validatePageFieldContents(applicant, false, fsa, null);
        discountsPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
//       Quote Page
            QuotePage quotePage = new QuotePage();
            Log.info("Quote Summary page, quote number: " + quoteNumber,true);
            discounts = quotePage.getDiscounts();
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            quotePage.clickBack();

//       Discounts Page
            discountsPage = new DiscountsPage();
            discountsPageLinks = new PageLinksHQM("discountsPage", applicant, browserType, true);
            discountsPage.validatePageLinks(discountsPageLinks, quoteNumber, fsa);
            discountsPage.validatePageFieldContents(applicant, false, fsa, null);
            discountsPage.validatePreappliedDiscountsAfterRate(applicant, quoteRate);
            discountsPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
            discountsPage.clickStepperProperty(browserType);

//       Property Basics Page
            propertyPage = new PropertyPage();
            PageLinksHQM propertyPageLinks = new PageLinksHQM("propertyPage", applicant, browserType, true);
            propertyPageLinks.buttonNext = 3;
            propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);
            propertyPage.verifyPageFields(applicant, fsa, propertyData);
            propertyPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
            propertyPage.clickNext();

//        Quality Grade Page
            qualityGradePage = new QualityGradePage();
            PageLinksHQM qualityGradePageLinks = new PageLinksHQM("qualityPage", applicant, browserType, true);
            qualityGradePageLinks.buttonNext = 3;
            qualityGradePage.validatePageLinks(qualityGradePageLinks, quoteNumber, fsa);
            qualityGradePage.verifyPageFields(applicant, propertyData);
            qualityGradePage.validateSubtitlesDiscountJourney(discounts, fsa);
            qualityGradePage.clickNext();

//        Property Details Page
            propertyDetailsPage = new PropertyDetailsPage();
            PageLinksHQM propertyDetailsPageLinks = new PageLinksHQM("propertyDetailsPage", applicant, browserType, true);
            propertyDetailsPageLinks.buttonNext = 3;
            propertyDetailsPage.validatePageLinks(propertyDetailsPageLinks, quoteNumber, fsa);
            propertyDetailsPage.verifyPageFieldSelections(applicant, fsa, propertyData);
            propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
            propertyDetailsPage.clickNext();

//        Customer Info Page
            customerInfoPage = new CustomerInfoPage();
            PageLinksHQM customerInfoPageLinks = new PageLinksHQM("customerInfoPage", applicant, browserType, true);
            customerInfoPageLinks.buttonNext = 3;
            customerInfoPage.validatePageLinks(customerInfoPageLinks, quoteNumber, fsa);
            customerInfoPage.validatePageFieldContents(applicant, false, fsa);
            customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
            customerInfoPage.clickNext();

//           Contact Info Page
            contactInfoPage = new ContactInfoPage();
            PageLinksHQM contactInfoPageLinks = new PageLinksHQM("contactInfoPage", applicant, browserType, true);
            contactInfoPageLinks.buttonNext = 3;
            contactInfoPage.validatePageLinks(contactInfoPageLinks, quoteNumber, fsa);
            contactInfoPage.validatePageFieldContents(applicant, false, fsa);
            contactInfoPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
            contactInfoPage.clickAgreeSubmitButton();

//           Discounts Page
            driver().navigate().refresh();
            discountsPage = new DiscountsPage();
            discountsPage.validatePageLinks(discountsPageLinks, quoteNumber, fsa);
            discountsPage.validatePageFieldContents(applicant, false, fsa, null);
            discountsPage.verifyPageFieldsNotReadonly();
            discountsPage.validatePreappliedDiscountsAfterRate(applicant, quoteRate);
            discountsPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            Log.info("Knockout page, quote number: " + quoteNumber,true);
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})
    public void testQuotePage(ApplicantHQM applicant) throws Exception {
        validateQuotePage(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})
    public void testQuotePageMobile(ApplicantHQM applicant) throws Exception {
        validateQuotePage(applicant, MOBILE_BROWSER);
    }

    private void validateQuotePage(ApplicantHQM applicant, String browserType) throws Exception {

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.validateSubtitlesDiscountJourney(fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        List<String> discounts = propertyPage.getDiscounts();
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityGradePage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityGradePage.selectQualityGrade(applicant, propertyData);
        qualityGradePage.validateSubtitlesDiscountJourney(discounts, fsa);
        qualityGradePage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        discounts = customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        discountsPage.setRequiredFields(applicant);
        discountsPage.validateSubtitlesDiscountJourney(null, applicant.stateCode, fsa);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
//           Quote Page
            QuotePage quotePage = new QuotePage();
            Log.info("Quote Summary page, quote number: " + quoteNumber,true);
            PageLinksHQM quotePageLinks = new PageLinksHQM("quotePage", applicant, browserType, true);
            quotePage.validatePageLinks(quotePageLinks, quoteNumber, fsa);
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            quotePage.validatePageTitles(quoteRate, fsa, staticContent);
            quotePage.validatePageFooters(applicant, staticContent);
            quotePage.validatePolicyPerks(applicant);
//            quotePage.validatePolicyFloAd(applicant, source);
            quotePage.validatePageCardTitles(applicant, quoteRate, true, browserType, fsa);
            quotePage.validateSendEmail(applicant, fsa);
            quotePage.validateQuoteDiscounts(applicant, fsa, quoteRate);
            quotePage.validateQuotePremiums(applicant, quoteRate, quoteDelta, fsa);
            discounts = quotePage.getDiscounts();
            quotePage.validateSubtitlesDiscountJourney(fsa);
            quotePage.clickBack();

//           Discounts Page
            discountsPage = new DiscountsPage();
            PageLinksHQM discountsPageLinks = new PageLinksHQM("discountsPage", applicant, browserType, true);
            discountsPage.validatePageLinks(discountsPageLinks, quoteNumber, fsa);
            discountsPage.validatePageFieldContents(applicant, false, fsa, null);
            discountsPage.validatePreappliedDiscountsAfterRate(applicant, quoteRate);
            discountsPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
            discountsPage.clickStepperAddress(browserType);

//           Address Page
            addressPage = new AddressPage();
            PageLinksHQM addressPageLinks = new PageLinksHQM("addressPage", applicant, browserType, true);
            addressPage.validatePageLinks(addressPageLinks, quoteNumber, fsa);
            addressPage.verifyPageFields(applicant, fsa);
            addressPage.verifyPageFieldsReadonly(fsa);
            addressPage.validateSubtitlesDiscountJourney(fsa);
            addressPage.clickButtonAgree();

//           Property Page
            propertyPage = new PropertyPage();
            PageLinksHQM propertyPageLinks = new PageLinksHQM("propertyPage", applicant, browserType, true);
            propertyPageLinks.buttonNext = 3;
            propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);
            propertyPage.verifyPageFields(applicant, fsa, propertyData);
            propertyPage.verifyPageFieldsNotReadonly(fsa);
            propertyPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
            propertyPage.clickNext();

//           Quality Grade Page
            qualityGradePage = new QualityGradePage();
            PageLinksHQM qualityPageLinks = new PageLinksHQM("qualityPage", applicant, browserType, true);
            qualityPageLinks.buttonNext = 3;
            qualityGradePage.validatePageLinks(qualityPageLinks, quoteNumber, fsa);
            qualityGradePage.verifyPageFields(applicant, propertyData);
            qualityGradePage.verifyPageFieldsNotReadonly(fsa);
            qualityGradePage.validateSubtitlesDiscountJourney(discounts, fsa);
            qualityGradePage.clickNext();

//           Property Details Page
            propertyDetailsPage = new PropertyDetailsPage();
            PageLinksHQM propertyDetailsPageLinks = new PageLinksHQM("propertyDetailsPage", applicant, browserType, true);
            propertyDetailsPageLinks.buttonNext = 3;
            propertyDetailsPage.validatePageLinks(propertyDetailsPageLinks, quoteNumber, fsa);
            propertyDetailsPage.verifyPageFieldSelections(applicant, fsa, propertyData);
            propertyDetailsPage.verifyPageFieldsNotReadonly(fsa);
            propertyDetailsPage.validateSubtitlesDiscountJourney(discounts, fsa);
            propertyDetailsPage.clickNext();

//           Customer Info Page
            customerInfoPage = new CustomerInfoPage();
            PageLinksHQM customerInfoPageLinks = new PageLinksHQM("customerInfoPage", applicant, browserType, true);
            customerInfoPageLinks.buttonNext = 3;
            customerInfoPage.validatePageLinks(customerInfoPageLinks, quoteNumber, fsa);
            customerInfoPage.validatePageFieldContents(applicant, false, fsa);
            customerInfoPage.verifyPageFieldsReadonly(applicant, false, fsa );
            customerInfoPage.validateSubtitlesDiscountJourney(discounts, fsa);
            customerInfoPage.clickNext();

//           Contact Info Page
            contactInfoPage = new ContactInfoPage();
            PageLinksHQM contactInfoPageLinks = new PageLinksHQM("contactInfoPage", applicant, browserType, true);
            contactInfoPageLinks.buttonNext = 3;
            contactInfoPage.validatePageLinks(contactInfoPageLinks, quoteNumber, fsa);
            contactInfoPage.validatePageFieldContents(applicant, false, fsa);
            contactInfoPage.verifyPageFieldsReadonly(fsa);
            contactInfoPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
            contactInfoPage.clickAgreeSubmitButton();

//           Discounts Page
            discountsPage = new DiscountsPage();
            discountsPage.validatePageLinks(discountsPageLinks, quoteNumber, fsa);
            discountsPage.validatePageFieldContents(applicant, false, fsa, null);
            discountsPage.validatePreappliedDiscountsAfterRate(applicant, quoteRate);
            discountsPage.verifyPageFieldsNotReadonly();
            discountsPage.validateSubtitlesDiscountJourney(discounts, applicant.stateCode, fsa);
            discountsPage.clickNext();

//           Quote Page
            quotePage = new QuotePage();
            quotePage.validatePageTitles(quoteRate,fsa, staticContent);
            driver().navigate().refresh();
            quotePage = new QuotePage();
            quotePage.validatePageLinks(quotePageLinks, quoteNumber, fsa);
            quotePage.validatePageTitles(quoteRate, fsa, staticContent);
            quotePage.validatePageFooters(applicant, staticContent);
            quotePage.validatePolicyPerks(applicant);
//            quotePage.validatePolicyFloAd(applicant, source);
            quotePage.validatePageCardTitles(applicant, quoteRate, true, browserType, fsa);
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                quotePage.validateEmailIconState(false, fsa);
                applicant.quoteRate = quotePage.getQuotePremiumMonthly();
            }
            quotePage.validateQuoteDiscounts(applicant, fsa, quoteRate);
            quotePage.validateQuotePremiums(applicant, quoteRate, quoteDelta, fsa);
            quotePage.validateSubtitlesDiscountJourney(fsa);
            quotePage.clickNext();

//           Thank You Page
            ThankYouPage thankYouPage = new ThankYouPage();
            thankYouPage.validatePageValues(applicant, applicant.quoteRate, fsa, quoteRate);

            if (applicant.emailCheck && !thankYouPage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                Mailinator.validateHqmEmails(applicant, null, false);
            }
        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            Log.info("Knockout page, quote number: " + quoteNumber,true);
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})
    public void testPrintPage(ApplicantHQM applicant) throws Exception {
        validatePrintPage(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})
    public void testPrintPageMobile(ApplicantHQM applicant) throws Exception {
        validatePrintPage(applicant, MOBILE_BROWSER);
    }

    private void validatePrintPage(ApplicantHQM applicant, String browserType) throws Exception {

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityGradePage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityGradePage.selectQualityGrade(applicant, propertyData);
        qualityGradePage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        discountsPage.setRequiredFields(applicant);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
//           Quote Page
            QuotePage quotePage = new QuotePage();
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            String quotePremiumYearly = quotePage.getQuotePremiumYearly(applicant.stateCode);
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                applicant.quoteRate = quotePage.getQuotePremiumMonthly();
                quotePage.validateSendEmail(applicant, fsa);
            }
            quotePage.clickPrint();
            quotePage.switchToNewTab();

//           Print Page
            PrintPage printPage = new PrintPage();
            PrintInfoHQM printInfo = apiHelper.getPrintInfoFromJson(quoteNumber);
            printPage.validatePageTitles(applicant, browserType, fsa, printInfo);
            printPage.validatePageFooters(applicant, staticContent);
            printPage.validateQuotePremiums(applicant, quotePremiumYearly, fsa, quoteRate);
            printPage.validateQuoteCoverages(fsa, quoteRate);
            printPage.validateQuoteDeductibles(applicant, fsa, quoteRate);
            printPage.validateQuoteLiabilities(fsa, quoteRate);
            printPage.validateQuoteDiscounts(applicant.stateCode, quoteRate);
            printPage.validatePolicyPerks(applicant);
            driver().close();
            quotePage.switchToMainTab();

//           Quote Page
            quotePage = new QuotePage();
            quotePage.clickQuoteDetails();
            quotePage.clickDismissSurveyPopup();

//           Quote Details Page
            QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
            quoteDetailsPage.updateSlidersRecalculate(applicant, fsa);
            QuoteRateHQM customRate = apiHelper.getQuoteRateFromJson(quoteNumber, "custom");
            quoteDetailsPage.verifyPremiums(applicant, fsa, customRate, null, null);
            quoteDetailsPage.clickCloseModal();

//           Quote Page
            quotePage = new QuotePage();
            String monthlyPremium = "";
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                quotePage.validateEmailIconState(true, fsa);
                monthlyPremium = quotePage.getQuotePremiumMonthly();
                quotePage.validateSendEmail(applicant, fsa);
            }
            quotePremiumYearly = quotePage.getQuotePremiumYearly(applicant.stateCode);
            quotePage.clickPrint();
            quotePage.switchToNewTab();

//           Print Page
            printPage = new PrintPage();
            Log.info("Print page, quote number: " + quoteNumber,true);
            printPage.validatePageTitles(applicant, browserType, fsa, printInfo);
            printPage.validatePageFooters(applicant, staticContent);
            printPage.validateQuotePremiums(applicant, quotePremiumYearly, fsa, customRate);
            printPage.validateQuoteCoverages(fsa, customRate);
            printPage.validateQuoteDeductibles(applicant, fsa, customRate);
            printPage.validateQuoteLiabilities(fsa, customRate);
            printPage.validateQuoteDiscounts(applicant.stateCode, customRate);
            printPage.validatePolicyPerks(applicant);

            driver().close();
            quotePage.switchToMainTab();

            if (applicant.emailCheck && !quotePage.isHqmDigitalMonetizationState((applicant.stateCode))) {
                Mailinator.validateHqmEmails(applicant, Arrays.asList(monthlyPremium,quotePremiumYearly), false);
            }
        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            Log.info("Knockout page, quote number: " + quoteNumber,true);
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})
    public void testQuoteDetailsPage1(ApplicantHQM applicant) throws Exception {
        validateQuoteDetailsPage1(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})
    public void testQuoteDetailsPage1Mobile(ApplicantHQM applicant) throws Exception {
        validateQuoteDetailsPage1(applicant, MOBILE_BROWSER);
    }

    private void validateQuoteDetailsPage1(ApplicantHQM applicant, String browserType) throws Exception {

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityGradePage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityGradePage.selectQualityGrade(applicant, propertyData);
        qualityGradePage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        discountsPage.setRequiredFields(applicant);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
            List<String> quoteValues = new ArrayList<>();
//           Quote Page
            QuotePage quotePage = new QuotePage();
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            String quotePremiumYearly = quotePage.getQuotePremiumYearly(applicant.stateCode);
            String reconstructionCost = quotePage.getQuoteReconstructionCost();
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                applicant.quoteRate = quotePage.getQuotePremiumMonthly();
                quotePage.validateSendEmail(applicant, fsa);
            }
            quotePage.clickQuoteDetails();

            QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
            Log.info("Quote Details page, quote number: " + quoteNumber,true);
            quoteDetailsPage.validatePageTitlesSubtitles(applicant, fsa, quoteRate, quoteDelta, quotePremiumYearly, staticContent);
            quoteDetailsPage.validateStandardPackageSliders(applicant, quoteRate, reconstructionCost, fsa);
            quoteDetailsPage.validatePageErrors(applicant, fsa);
            quoteDetailsPage.updateSlidersRecalculate(applicant, fsa);
            QuoteRateHQM customRate = apiHelper.getQuoteRateFromJson(quoteNumber, "custom");
            quoteDetailsPage.verifyPremiums(applicant, fsa, customRate, null, null);
            quoteDetailsPage.clickCloseModal();

//           Validate Quote Page after Custom Rate
            quotePage = new QuotePage();
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                quotePage.validateEmailIconState(true, fsa);
                quoteValues.add(quotePage.getQuotePremiumMonthly());
                quotePage.validateSendEmail(applicant, fsa);
            }
            quotePage.validatePageTitles(quoteRate, fsa, staticContent);
//            quotePage.validatePageFooters(applicant, staticContent);
            quotePage.validatePolicyPerks(applicant);
//            quotePage.validatePolicyFloAd(applicant, source);
            quotePage.validatePageCardTitles(applicant, customRate, false, browserType, fsa);
            quotePage.validateQuoteDiscounts(applicant, fsa, customRate);
            quotePage.validateQuotePremiums(applicant, customRate, quoteDelta, fsa);

//           Validate Quote Details Page after Reset Rate
            quotePage.clickQuoteDetails();
            quoteDetailsPage = new QuoteDetailsPage();
            quoteDetailsPage.clickReset();
            quoteDetailsPage.validatePageTitlesSubtitles(applicant, fsa, quoteRate, quoteDelta, quotePremiumYearly, staticContent);
            quoteDetailsPage.validateStandardPackageSliders(applicant, quoteRate, reconstructionCost, fsa);
            String monthlyPremium = quoteDetailsPage.getMonthlyPremium();
            quoteDetailsPage.clickCloseModal();

            quotePage = new QuotePage();
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                quotePage.validateEmailIconState(false, fsa);
            }
            quotePage.clickNext();

//           Thank You Page
            ThankYouPage thankYouPage = new ThankYouPage();
            thankYouPage.validatePageValues(applicant, monthlyPremium, fsa, quoteRate);

            if (applicant.emailCheck && !thankYouPage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                Mailinator.validateHqmEmails(applicant, quoteValues, false);
            }
        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            Log.info("Knockout page, quote number: " + quoteNumber,true);
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})
    public void testQuoteDetailsPage2(ApplicantHQM applicant) throws Exception {
        validateQuoteDetailsPage2(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})
    public void testQuoteDetailsPage2Mobile(ApplicantHQM applicant) throws Exception {
        validateQuoteDetailsPage2(applicant, MOBILE_BROWSER);
    }

    private void validateQuoteDetailsPage2(ApplicantHQM applicant, String browserType) throws Exception {

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

        ApiHelper apiHelper = new ApiHelper();
//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityGradePage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityGradePage.selectQualityGrade(applicant, propertyData);
        qualityGradePage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        discountsPage.setRequiredFields(applicant);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
            List<String> quoteValues = new ArrayList<>();
//           Quote Page
            QuotePage quotePage = new QuotePage();
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            String quotePremiumYearly = quotePage.getQuotePremiumYearly(applicant.stateCode);
            String reconstructionCost = quotePage.getQuoteReconstructionCost();
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                applicant.quoteRate = quotePage.getQuotePremiumMonthly();
                quotePage.validateSendEmail(applicant, fsa);
            }
            quotePage.clickQuoteDetails();

            QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
            Log.info("Quote Details page, quote number: " + quoteNumber,true);
            quoteDetailsPage.validatePageTitlesSubtitles(applicant, fsa, quoteRate, quoteDelta, quotePremiumYearly, staticContent);
            quoteDetailsPage.validateStandardPackageSliders(applicant, quoteRate, reconstructionCost, fsa);
            quoteDetailsPage.validatePageErrors(applicant, fsa);
            quoteDetailsPage.updateSlidersRecalculate(applicant, fsa);
            QuoteRateHQM customRate = apiHelper.getQuoteRateFromJson(quoteNumber, "custom");
            quoteDetailsPage.verifyPremiums(applicant, fsa, customRate, null, null);
            quoteDetailsPage.clickCloseModal();

//        Validate Quote Page after Custom Rate
            quotePage = new QuotePage();
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                quotePage.validateEmailIconState(true, fsa);
                quoteValues.add(quotePage.getQuotePremiumMonthly());
                quotePage.validateSendEmail(applicant, fsa);
            }
            quotePage.validatePageTitles(quoteRate, fsa, staticContent);
            quotePage.validatePageFooters(applicant, staticContent);
            quotePage.validatePolicyPerks(applicant);
//            quotePage.validatePolicyFloAd(applicant, source);
            quotePage.validatePageCardTitles(applicant, customRate, false, browserType, fsa);
            quotePage.validateQuoteDiscounts(applicant, fsa, customRate);
            quotePage.validateQuotePremiums(applicant, customRate, quoteDelta, fsa);

//        Validate Quote changes back to Standard, if something is updated on Property Details page
            quotePage.clickBack();
            HqmBasePage basePage = new HqmBasePage();  // Discounts page
            basePage.clickBack();
            basePage = new HqmBasePage(); // Contact Info page
            basePage.clickBack();
            basePage = new HqmBasePage(); // Customer Info page
            basePage.clickBack();
            propertyDetailsPage = new PropertyDetailsPage();
            String numberOfStories = propertyDetailsPage.getSelectedNumberOfStories();
            List<String> listNumberOfStories = propertyDetailsPage.getAvailableNumberOfStories();
            listNumberOfStories.remove(numberOfStories);
            propertyDetailsPage.selectNumberOfStories(listNumberOfStories.get(0));
            propertyDetailsPage.clickNext();

            customerInfoPage = new CustomerInfoPage(); // Customer Info page
            customerInfoPage.clickNext();

            contactInfoPage = new ContactInfoPage(); // Contact Info page
            contactInfoPage.clickAgreeSubmitButton();

            discountsPage = new DiscountsPage(); // Discounts page
            discountsPage.clickNext();

            quotePage = new QuotePage();  // Quote page reverted back to Standard package
            quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            String monthlyPremium = "";
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                quotePage.validateEmailIconState(true, fsa);
                quoteValues.add(quotePage.getQuotePremiumMonthly());
                quotePage.validateSendEmail(applicant, fsa);
                monthlyPremium = quotePage.getQuotePremiumMonthly();
            }
            quotePage.validatePageCardTitles(applicant, quoteRate, true, browserType, fsa);
            quotePage.clickNext();

//       Thank You Page
            ThankYouPage thankYouPage = new ThankYouPage();
            thankYouPage.validatePageValues(applicant, monthlyPremium, fsa, quoteRate);

            if (applicant.emailCheck && !thankYouPage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                Mailinator.validateHqmEmails(applicant, quoteValues, false);
            }
        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            Log.info("Knockout page, quote number: " + quoteNumber,true);
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_REGRESSION, HQM_ALL})
    public void testThankYouPage(ApplicantHQM applicant) throws Exception {
        validateThankYouPage(applicant, DESKTOP_BROWSER);
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, testName = RANDOM_ROW, groups = {HQM_PAGE_MOBILE, HQM_ALL})
    public void testThankYouPageMobile(ApplicantHQM applicant) throws Exception {
        validateThankYouPage(applicant, MOBILE_BROWSER);
    }

    private void validateThankYouPage(ApplicantHQM applicant, String browserType) throws Exception {

//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AS, browserType);
        addressPage.acceptCookies();
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        ApiHelper apiHelper = new ApiHelper();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.clickNext();

//        Quality Grade Page
        QualityGradePage qualityGradePage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        qualityGradePage.selectQualityGrade(applicant, propertyData);
        qualityGradePage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        discountsPage.setRequiredFields(applicant);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
//           Quote Page
            QuotePage quotePage = new QuotePage();
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            String premium = quotePage.isHqmDigitalMonetizationState(applicant.stateCode) ? quotePage.getQuotePremiumYearly(applicant.stateCode) :
                    quotePage.getQuotePremiumMonthly();
            quotePage.clickNext();

//           Thank You Page
            ThankYouPage thankYouPage = new ThankYouPage();
            Log.info("Thank You page, quote number: " + quoteNumber,true);
            PageLinksHQM thankYouPageLinks = new PageLinksHQM("thankYouPage", applicant, browserType, true);
            thankYouPage.validatePageLinks(thankYouPageLinks, quoteNumber, fsa);
            thankYouPage.validatePageValues(applicant, premium, fsa, quoteRate);
            thankYouPage.validatePageTitles(applicant, browserType, fsa, staticContent);
            thankYouPage.validatePageFooters(applicant, browserType, fsa);
            driver().navigate().refresh();
            thankYouPage = new ThankYouPage();
            thankYouPage.validatePageLinks(thankYouPageLinks, quoteNumber, fsa);
            thankYouPage.validatePageValues(applicant, premium, fsa, quoteRate);
            thankYouPage.validatePageTitles(applicant, browserType, fsa, staticContent);
            thankYouPage.validatePageFooters(applicant, browserType, fsa);

        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            Log.info("Knockout page, quote number: " + quoteNumber,true);
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, browserType, fsa);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {HQM_PAGE_REGRESSION, HQM_ALL},
            testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {})})
    public void  testAEMCampaignPhones(ApplicantHQM applicant) throws Exception {
//       Quote Start - Address Page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AddressPage addressPage = new AddressPage(applicant, AEM, DESKTOP_BROWSER);
        String quoteNumber = addressPage.getQuoteNumber();
        applicant.quoteNumber = quoteNumber;
        Log.info(NEW_QUOTE_NUMBER + quoteNumber);
        ApiHelper apiHelper = new ApiHelper();
        String campaignPhoneNumber = apiHelper.getCampaignPhoneNumber(quoteNumber, applicant.campaignId);
        if ((campaignPhoneNumber == null) || (campaignPhoneNumber.isBlank())) {
            Log.warn(">> Campaign ID: " + applicant.campaignId + ", was not found. The AEM phone number: " + campaignPhoneNumber);
            return;
        }
        PageLinksHQM addressPageLinks = new PageLinksHQM("addressPage", applicant, campaignPhoneNumber, false);
        addressPage.validatePageLinks(addressPageLinks, quoteNumber, fsa);
        addressPage.populateFields(applicant, fsa);
        addressPage.clickButtonAgree();

//       Property Basics Page
        PropertyPage propertyPage = new PropertyPage();
        PrefillResponseHQM propertyData = apiHelper.getPropertyData(applicant, quoteNumber, null);
        PageLinksHQM propertyPageLinks = new PageLinksHQM(PROPERTY_PAGE, applicant, campaignPhoneNumber, false);
        propertyPageLinks.buttonNext = (propertyPage.getYearBuilt().isEmpty() || propertyPage.getSquareFeet().isEmpty()) ? 2 : 3;
        propertyPage.validatePageLinks(propertyPageLinks, quoteNumber, fsa);
        propertyPage.setRequiredFields(applicant, fsa, propertyData);
        propertyPage.clickNext();

//       Quality Grade Page
        QualityGradePage qualityPage = new QualityGradePage();
        propertyData = apiHelper.getPropertyData(applicant, quoteNumber, propertyData);
        if (applicant.keep360Prefill) {
            qualityPage.verifyPageFields(applicant, propertyData);
        } else {
            qualityPage.selectQualityGrade(applicant, propertyData);
        }
        PageLinksHQM qualityPageLinks = new PageLinksHQM(QUALITY_PAGE, applicant, campaignPhoneNumber, false);
        qualityPageLinks.buttonNext = qualityPage.getSelected().isEmpty() ? 2 : 3;
        qualityPage.validatePageLinks(qualityPageLinks, quoteNumber, fsa);
        qualityPage.clickNext();

//        Property Details Page
        PropertyDetailsPage propertyDetailsPage = new PropertyDetailsPage();
        PageLinksHQM propertyDetailsPageLinks = new PageLinksHQM(PROPERTY_DETAILS_PAGE, applicant, campaignPhoneNumber, false);
        propertyDetailsPageLinks.buttonNext = propertyDetailsPage.isNextButtonEnabled(applicant.stateCode) ? 3 : 2;
        propertyDetailsPage.validatePageLinks(propertyDetailsPageLinks, quoteNumber, fsa);
        propertyDetailsPage.setRequiredFields(applicant, fsa, propertyData);
        propertyDetailsPage.clickNext();

//       Customer Info Page
        CustomerInfoPage customerInfoPage = new CustomerInfoPage();
        PageLinksHQM customerInfoPageLinks = new PageLinksHQM("customerInfoPage", applicant, campaignPhoneNumber, false);
        customerInfoPageLinks.buttonNext = 2;
        customerInfoPage.validatePageLinks(customerInfoPageLinks, quoteNumber, fsa);
        customerInfoPage.setRequiredFields(applicant);
        customerInfoPage.clickNext();

//       Contact Info Page
        ContactInfoPage contactInfoPage = new ContactInfoPage();
        PageLinksHQM contactInfoPageLinks = new PageLinksHQM("contactInfoPage", applicant, campaignPhoneNumber, false);
        contactInfoPageLinks.buttonNext = 2;
        contactInfoPage.validatePageLinks(contactInfoPageLinks, quoteNumber, fsa);
        contactInfoPage.setRequiredFields(applicant);
        contactInfoPage.clickAgreeSubmitButton();

//       Discounts Page
        DiscountsPage discountsPage = new DiscountsPage();
        StaticContentHQM staticContent = apiHelper.getStaticContentFromJson(quoteNumber);
        PageLinksHQM discountsPageLinks = new PageLinksHQM("discountsPage", applicant, campaignPhoneNumber, false);
        discountsPage.validatePageLinks(discountsPageLinks, quoteNumber, fsa);
        discountsPage.setRequiredFields(applicant);
        discountsPage.clickNext();

        if (!applicant.isKnockOutScenario) {
//           Quote Page
            QuotePage quotePage = new QuotePage();
            Log.info("Quote Summary page, quote number: " + quoteNumber,true);
            PageLinksHQM quotePageLinks = new PageLinksHQM("quotePage", applicant, campaignPhoneNumber, true);
            quotePage.validatePageLinks(quotePageLinks, quoteNumber, fsa);
            QuoteRateHQM quoteRate = apiHelper.getQuoteRateFromJson(quoteNumber, BASIC);
            quotePage.validatePageCardTitles(applicant, quoteRate, true, campaignPhoneNumber, fsa);
            quotePage.validateQuoteDiscounts(applicant, fsa, quoteRate);
            quotePage.validateQuotePremiums(applicant, quoteRate, quoteDelta, fsa);
            String quotePremiumYearly = quotePage.getQuotePremiumYearly(applicant.stateCode);
            String quotePremiumMonthly = "";
            if (!quotePage.isHqmDigitalMonetizationState(applicant.stateCode)) {
                quotePremiumMonthly = quotePage.getQuotePremiumMonthly();
                quotePage.validateSendEmail(applicant, fsa);
            }
            quotePage.clickPrint();
            quotePage.switchToNewTab();

//           Print Page
            PrintPage printPage = new PrintPage();
            PrintInfoHQM printInfo = apiHelper.getPrintInfoFromJson(quoteNumber);
            printPage.validatePageTitles(applicant, campaignPhoneNumber, fsa, printInfo);
            printPage.validatePageFooters(applicant, staticContent);
            printPage.validateQuotePremiums(applicant, quotePremiumYearly, fsa, quoteRate);
            driver().close();
            quotePage.switchToMainTab();

//           Quote Page
            quotePage = new QuotePage();
            quotePage.clickNext();

//           Thank You Page
            ThankYouPage thankYouPage = new ThankYouPage();
            PageLinksHQM thankYouPageLinks = new PageLinksHQM("thankYouPage", applicant, campaignPhoneNumber, true);
            thankYouPage.validatePageLinks(thankYouPageLinks, quoteNumber, fsa);
            thankYouPage.validatePageValues(applicant, quotePremiumMonthly, fsa, quoteRate);
            thankYouPage.validatePageTitles(applicant, campaignPhoneNumber, fsa, staticContent);
            thankYouPage.validatePageFooters(applicant, campaignPhoneNumber, fsa);

        } else {
            KnockOutPage knockOutPage = new KnockOutPage();
            Log.info("Knockout page, quote number: " + quoteNumber,true);
            knockOutPage.validatePageTitles(applicant, fsa, staticContent);
            knockOutPage.validatePageFooters(applicant, campaignPhoneNumber, fsa);
        }
        fsa.assertAll();
    }

    @Test(dataProvider = DataProviders.APPLICANT_HQM_MONETIZATION_DP, dataProviderClass = DataProviders.class,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, groups = {HQM_PAGE_REGRESSION, HQM_ALL})
    public void testHQMMonetizationScenarios(ApplicantHQM applicant) throws Exception {

        LandingPage landingPage = applicant.getAgentId().isBlank() ? new LandingPage() : new LandingPage(applicant);
        landingPage.enterLandingPageDataAndContinue(LOB_HOME, applicant.getZipCode());

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        if (!applicant.getAgentId().isBlank() && Arrays.asList(CA, NV).contains(applicant.stateCode)) {
            AddressPage addressPage = new AddressPage();
            String quoteNumber = addressPage.getQuoteNumber();
            applicant.quoteNumber = quoteNumber;
            Log.info(NEW_QUOTE_NUMBER + quoteNumber);
            fsa.assertFalse(quoteNumber.isBlank(), "Address page - Quote number is not blank.");
        } else if (applicant.getStateCode().equals(CA)) {
            IntermediatePage intermediatePage = new IntermediatePage();
            fsa.assertTrue(intermediatePage.isUnableToProvideQuoteTextExists(), "Intermediate page - Unable to provide online quote text.");
            fsa.assertTrue(intermediatePage.isButtonStartMyQuoteExists(), "Intermediate page - Start My Quote button exists.");
        } else {
            InterstitialPage interstitialPage = new InterstitialPage();
            fsa.assertTrue(interstitialPage.isPageTitleTextExists(), "Interstitial page - page title text found.");
            fsa.assertTrue(interstitialPage.isPageContentsTextExists(), "Interstitial page - page contents text found.");
            fsa.assertTrue(interstitialPage.isButtonContinueToFGIAExists(), "Interstitial page - Continue to FGIA button exists.");
            fsa.assertTrue(interstitialPage.isButtonNoThanksExists(), "Interstitial page - No, thanks, button exists.");

            boolean continueYesNo = (new Random()).nextBoolean();
            if (continueYesNo) {
                Log.info("Going to click on - [Continue to FGIA] button.");
                interstitialPage.clickContinueToFGIA();
                FarmersInsuranceAgencyPage insuranceAgencyPage = new FarmersInsuranceAgencyPage();
                if (insuranceAgencyPage.isCitySelectDisplayed()) {
                    fsa.assertTrue(insuranceAgencyPage.getCitySelectOptions().contains(applicant.getCity()), "Farmers Insurance Agency Page - City is in the list.");
                    fsa.assertEquals(insuranceAgencyPage.getCityStateZip(), applicant.getStateCode() + SPACE
                            + applicant.getZipCode(), "Farmers Insurance Agency Page - State, Zip match.");
                } else {
                    fsa.assertEquals(insuranceAgencyPage.getCityStateZip().toUpperCase(), applicant.getCity() + ", "
                            + applicant.getStateCode() + SPACE + applicant.getZipCode(), "Farmers Insurance Agency Page - City, State, Zip match.");
                }
            } else {
                Log.info("Going to click on - [No, thanks] button.");
                interstitialPage.clickNoThanks();
                IntermediatePage intermediatePage = new IntermediatePage();
                fsa.assertTrue(intermediatePage.isUnableToProvideQuoteTextExists(), "Intermediate page - Unable to provide online quote text.");
                fsa.assertTrue(intermediatePage.isButtonStartMyQuoteExists(), "Intermediate page - Start My Quote button exists.");
            }
        }
        fsa.assertAll("HQM Monetization for state=" + applicant.getStateCode() +
                (applicant.getAgentId().isBlank() ? " Organic traffic quote." : " Agent quote."));
        driver().quit();
    }
}


