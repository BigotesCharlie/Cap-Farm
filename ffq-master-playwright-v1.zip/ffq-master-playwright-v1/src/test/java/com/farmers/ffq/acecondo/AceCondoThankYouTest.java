package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoAdditionalCoveragesPage;
import com.farmers.ffq.ace.condo.AceCondoJustAFewMoreThingsPage;
import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCJustAFewMoreThingsBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCThankYouBasePage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoThankYouTest extends AutomationFramework {
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_THANK_YOU_SCREEN_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_THANK_YOU_PAGE})
    public void validateContentOfThankYouPageCondoLob(ApplicantAceHome applicant) throws Exception {
        AceCondoAdditionalCoveragesPage additionalCoveragesPage = new AceCondoNavigationHelper().navigateToAceCondoAdditionalCoveragesPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AppStore appStore = additionalCoveragesPage.getSessionStorageAppStore();
        AppStore.Home.RateQuoteResponse rateQuoteResponse = appStore.getHome().getQuote().getRateQuoteResponses().get(0);
        boolean isBindDisabled = rateQuoteResponse.getBuyEnableInd().equals("N");
        additionalCoveragesPage.clickOnContinueButton();
        if (isBindDisabled) {
            AceHRCThankYouBasePage aceHRCThankYouBasePage = new AceHRCThankYouBasePage();
            Assert.assertTrue(aceHRCThankYouBasePage.isOnThankYouPage(), "Did not reach Thank You page.");
            aceHRCThankYouBasePage.validateThankYouPage(applicant, fsa, CONDO, true);
        } else {
            AceCondoJustAFewMoreThingsPage jfmtCondoPage = new AceCondoJustAFewMoreThingsPage();
            if (jfmtCondoPage.isOnJFMTPage(true)) {
                jfmtCondoPage.selectMortgageOnThisProperty(false);
                if(applicant.isInEscrow()) {
                    jfmtCondoPage.validateEscrowDetailsOnJFMTPage(fsa, CONDO);
                }
                jfmtCondoPage.fillOutJustFewMoreThingsPageCondo(applicant, true);
            }
            KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
            assert koPage.isOnKnockOutPage();
            // Validate Thank you for choosing farmers insurance KO page
            koPage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, applicant.getQuoteNumber());
        }
        fsa.assertAll("Validated Landed on Thank you page for Condo LOB.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_THANK_YOU_SCREEN_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})},
            groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_THANK_YOU_PAGE})
    public void testValidateThankYouPageCannotGoBindCondoLob(ApplicantAceHome applicant) throws Exception {
        //F91675: FFQ - Tech Feature - Additional checks for bind disabled

        try {
            AceHRCThankYouBasePage thankYouPage = (new AceCondoNavigationHelper()).navigateToAceCondoThankYouPage(applicant);
            thankYouPage.attemptToChangeUrlOnThankYouPage(CONDO);
        } catch (Exception e) {
            if (e.getMessage().equals("Did not reach AceCondoThankYouPage")) {
                AceHRCJustAFewMoreThingsBasePage aceJAFMTPage = new AceHRCJustAFewMoreThingsBasePage();
                Assert.assertTrue(aceJAFMTPage.isOnJFMTPage(false), "Quote reached to Just a few more things page.");
                Log.info(">> Reached Just a few more things page.");
            } else {
                throw e;
            }
        }
    }
}
