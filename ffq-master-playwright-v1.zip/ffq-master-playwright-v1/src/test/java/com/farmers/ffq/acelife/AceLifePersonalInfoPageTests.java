package com.farmers.ffq.acelife;

import com.farmers.ffq.ace.life.AceLifeNavigationHelper;
import com.farmers.ffq.ace.life.AceLifePersonalInfoPage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantLife;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.ACE_LIFE_PERSONAL_INFO_PAGE;
import static com.farmers.ffq.utils.GlobalVariables.AWS_SCENARIOS;
import static com.farmers.ffq.utils.GlobalVariables.FFQ_ACE_LIFE;
import static com.farmers.ffq.utils.GlobalVariables.PEWC;

import java.util.Random;

public class AceLifePersonalInfoPageTests extends AutomationFramework {

	@Test(dataProvider = DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE, ACE_LIFE_PERSONAL_INFO_PAGE})
	public void aceLifePersonalInfoPageContentVerification(ApplicantLife applicant) throws Exception {
		if (new Random().nextBoolean()) {
			applicant.setId(AWS_SCENARIOS);
		}
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		AceLifePersonalInfoPage lifePersonalInfoPage = new AceLifeNavigationHelper().navigateToAceLifePersonalInfoPage(applicant);
		lifePersonalInfoPage.contentValidation(applicant, farmersSoftAssert);
		if (applicant.getId().equals(AWS_SCENARIOS)) {
			lifePersonalInfoPage.validateTFNIsNotDisplayedInAgentFlow(farmersSoftAssert);
		}
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = DataProviders.ACE_LIFE_APPLICANTS_FROM_A_LIST_OF_STATES, dataProviderClass = DataProviders.class, groups = {FFQ_ACE_LIFE, ACE_LIFE_PERSONAL_INFO_PAGE})
	public void aceLifePersonalInfoPageErrorValidation(ApplicantLife applicant) throws Exception {
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		AceLifePersonalInfoPage lifePersonalInfoPage = new AceLifeNavigationHelper().navigateToAceLifePersonalInfoPage(applicant);
		lifePersonalInfoPage.errorMessageValidation(farmersSoftAssert);
		farmersSoftAssert.assertAll();
	}

	@Test(dataProvider = DataProviders.ONE_ACE_LIFE_APPLICANT_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {PEWC})
	public void aceLifePEWCScreen(ApplicantLife applicant) throws Exception {
		FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
		new AceLifeNavigationHelper().navigateToAceLifePersonalInfoPage(applicant);
		farmersSoftAssert.assertAll();
	}

}
