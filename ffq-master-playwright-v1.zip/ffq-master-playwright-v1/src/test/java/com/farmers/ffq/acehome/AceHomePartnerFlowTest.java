package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeContactInfoPage;
import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.home.AceHomeReviewQuotePage;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.common.pages.MediaAlphaPageHome;
import com.farmers.ffq.common.pages.MediaAlphaStartPage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.*;
import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.ADDRESS_PAGE;
import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.CONTACT_INFO;
import static com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage.DID_NOT_REACH;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomePartnerFlowTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})},
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL})
    public void testMediaAlphaEndToEndQuoteHome(ApplicantAceHome applicant) throws Exception {

        MediaAlphaStartPage mediaAlphaStartPage = new MediaAlphaStartPage();
        mediaAlphaStartPage.processMediaAlphaStartPage(applicant.getZipCode(), HOME);

        MediaAlphaPageHome mediaAlphaPageHome = new MediaAlphaPageHome();
        Assert.assertTrue(mediaAlphaPageHome.isOnMediaAlphaPageHome(), "Did not reach Media Alpha Home page.");
        mediaAlphaPageHome.enterHomeApplicantData(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
        Assert.assertTrue(propertyTypePage.isOnPropertyTypePage(), "Did not reach Property type page.");
        propertyTypePage.acceptCookies();
        propertyTypePage.validatePageCards(fsa, MEDIA_ALPHA);
        propertyTypePage.selectPropertyType(HOME);

        AceHRCAddressBasePage addressPage = new AceHRCAddressBasePage();
        Assert.assertTrue(addressPage.isOnAddressPage(true), "Did not reach Address page.");
        addressPage.validatePageTitlesFooters(fsa, applicant, MEDIA_ALPHA);
        addressPage.validateQuoteSourceInd(fsa, applicant, MEDIA_ALPHA, ADDRESS_PAGE);
        addressPage.validateAgentSection(fsa, AceHRCBasePage.ADDRESS_PAGE, EMPTY_STRING, HOME);
        fsa.assertEquals(addressPage.getAddress().toUpperCase(), applicant.getAddress().toUpperCase(), "Address page - Street address match.");
        fsa.assertEquals(addressPage.getCity().toUpperCase(), applicant.getCity().toUpperCase(), "Address page - City match.");
        fsa.assertEquals(addressPage.getZipCode(), applicant.getZipCode(), "Address page - Zip code match.");
        fsa.assertEquals(addressPage.getState(), applicant.getState(), "Address page - State name match.");
        addressPage.enterAvailableFields(applicant);
        addressPage.clickContinueButton();
        addressPage.waitForSpinnerToBeGone();
        AceHRCPropertyBasePage propertyPage = new AceHRCPropertyBasePage();
        boolean isPropertyYearBuiltPage = propertyPage.isOnHRCPropertyBasePage(false);
        if (isPropertyYearBuiltPage) {
            propertyPage.setYearBuiltFieldValue(String.valueOf(applicant.getYearBuilt()));
            propertyPage.setTotalSqFtFieldValue(applicant.getSquareFeet());
            propertyPage.clickContinueButton();
        }
        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        if (qualityGradePage.isQualityGradePageAvailable()) {
            // [Quality grade] page
            Assert.assertTrue(qualityGradePage.isOnQualityGradePage(), "Did not reach Quality grade page.");
            qualityGradePage.validateAgentSection(fsa, AceHRCBasePage.QUALITY_GRADE, EMPTY_STRING, HOME);
            qualityGradePage.clickContinueButton();
        } else {
            // [Property details + Quality grade] page
            Assert.assertTrue(qualityGradePage.isOnPropertyDetailsQualityGradePage(false), "Did not reach Property details + Quality grade page.");
        }
        applicant.setQuoteNumber(qualityGradePage.getAceQuoteNumberInThePage());
        Log.info("New quote number: " + applicant.getQuoteNumber());

        // [Property details] page
        AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
        Assert.assertTrue(propertyDetailsPage.isOnPropertyDetailsPage(), "Did not reach Property details page.");
        propertyDetailsPage.validateAgentSection(fsa, AceHRCBasePage.PROPERTY_DETAILS, EMPTY_STRING, HOME);
        fsa.assertTrue(propertyDetailsPage.isPageTitleDisplayed(), "Property details page title is displayed.");
        propertyDetailsPage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        propertyDetailsPage.enterNotPrefilledPropertyDetails(applicant);
        propertyDetailsPage.clickContinueButton();

        // [Additional info] page
        AceHRCAdditionalInfoBasePage additionalInfo = new AceHRCAdditionalInfoBasePage();
        Assert.assertTrue(additionalInfo.isOnAdditionalInfoPage(), "Did not reach Additional info page.");
        additionalInfo.validateAgentSection(fsa, AceHRCBasePage.ADDITIONAL_INFO, EMPTY_STRING, HOME);
        additionalInfo.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        additionalInfo.fillOutAdditionalInfoPageHomeLob(applicant, true);

        // [About You] page
        AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
        aboutYouPage.waitAboutYouPageToRender();
        Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "Did not reach About you page.");
        aboutYouPage.validateAgentSection(fsa, AceHRCBasePage.ABOUT_YOU, EMPTY_STRING, HOME);
        fsa.assertEquals(aboutYouPage.getFirstName().toLowerCase(), applicant.getFirstName().toLowerCase(), "About You page - PNI First name value.");
        fsa.assertEquals(aboutYouPage.getLastName().toLowerCase(), applicant.getLastName().toLowerCase(), "About You page - PNI Last name value.");
        fsa.assertEquals(aboutYouPage.getDateOfBirth(), applicant.getDateOfBirth(), "About You page - PNI Date of birth.");
        aboutYouPage.fillOutPartialAboutYouPage(applicant, MEDIA_ALPHA);
        aboutYouPage.clickContinueButton();

        // [Contact info] page
        AceHRCContactInfoBasePage contactInfoPage = new AceHRCContactInfoBasePage();
        Assert.assertTrue(contactInfoPage.isOnContactInfoPage(true), "Did not reach Contact info page.");
        contactInfoPage.validateAgentSection(fsa, CONTACT_INFO, EMPTY_STRING, HOME);
        fsa.assertEquals(contactInfoPage.getEmailAddress(), applicant.getEmailAddress(), "Contact Info page - e-mail address.");
        fsa.assertEquals(contactInfoPage.getPhoneNumber(), contactInfoPage.getFormattedPhoneNumber(applicant.getPhoneNumber()), "Contact Info page - phone number.");
        contactInfoPage.enterFireHydrantData(applicant);
        contactInfoPage.fillOutBundleAndSave(applicant, HOME);
        contactInfoPage.clickOnAgreeAndSubmitButton();

        // [JAFMT] page or [Thank you] page
        AceHomeNavigationHelper aceHomeNavigator = new AceHomeNavigationHelper();
        aceHomeNavigator.setResumeFromPage(DWELLING_COVERAGE);
        AceHRCAdditionalCoveragesBasePage additionalCoveragesPage = aceHomeNavigator.navigateToAceHomeAdditionalCoveragesPage(applicant, LOB_HOME, HOME);
        (new AceHRCBasePage()).validateQuoteSourceInd(fsa, applicant, MEDIA_ALPHA, ADDITIONAL_COVERAGES);
        additionalCoveragesPage.validateAgentSection(fsa, AceHRCBasePage.ADDITIONAL_COVERAGES, EMPTY_STRING, HOME);
        additionalCoveragesPage.clickOnContinueButton();
        additionalCoveragesPage.waitForSpinnerToBeGone();
        AceHRCJustAFewMoreThingsBasePage jFMTPage = new AceHRCJustAFewMoreThingsBasePage();
        AceHRCThankYouBasePage thankYouPage = new AceHRCThankYouBasePage();
        Assert.assertTrue(jFMTPage.isOnJFMTPage(false) || thankYouPage.isOnThankYouPage(), "Did not reach Just a few more things or Thank you page.");
        if (jFMTPage.isOnJFMTPage(false)) {
            // Payment page flow
            aceHomeNavigator.setResumeFromPage(JFMT_PAGE);
            jFMTPage.validateAgentSection(fsa, AceHRCBasePage.JFMT_PAGE, EMPTY_STRING, HOME);
            AceHRCPaymentBasePage aceHRCPaymentBasePage = aceHomeNavigator.navigateToPayInFullPaymentPageAceHome(applicant, LOB_HOME, HOME);
            (new AceHRCBasePage()).validateAgentSection(fsa, AceHRCBasePage.PAYMENT_PAGE, EMPTY_STRING, HOME);
            aceHRCPaymentBasePage.clickSetUpPaymentButton();
            aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
            aceHRCPaymentBasePage.waitForSpinnerToBeGone();
            aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        } else {
            // Thank you page flow
            thankYouPage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
            thankYouPage.verifyQuotePresentmentCard(fsa, HOME);
        }
        fsa.assertAll("Ace Home - Media Alpha partner integration flow quote.");
    }


    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AR,AZ,IL,NM,OK,OR,PA,TN,WI})}, groups = {FFQ_ACE_HOME}, enabled = false)
    public void testToggleNonRenewalQuoteHome(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        testToggleNonRenewalQuoteHome(applicant, true, fsa);  // "Source_Indicator":"TN"
        fsa.assertAll("Ace Home - Toggle partner flow (non-renewal) quote.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AR,AZ,IL,NM,OK,OR,PA,TN,WI})}, groups = {FFQ_ACE_HOME}, enabled = false)
    public void testToggleRenewalQuoteHome(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        testToggleNonRenewalQuoteHome(applicant, false, fsa);   // "Source_Indicator":"TO"
        fsa.assertAll("Ace Home - Toggle partner flow (renewal) quote.");
    }

    // F90902 - Toggle Non-Renewal Customer Banner
    private void testToggleNonRenewalQuoteHome(ApplicantAceHome applicant, boolean nonRenewal,FarmersSoftAssert fsa) throws Exception {
        AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
        navigator.processPartnerFlowPage(applicant, LOB_HOME, nonRenewal);
        AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
        Assert.assertTrue(propertyTypePage.isOnPropertyTypePage(), "Did not reach Property type page - Home.");
        if (nonRenewal) {
            fsa.assertTrue(propertyTypePage.isToggleBannerDisplayed(), "Property type page: Toggle partner flow (non-renewal) - Welcome banner is displayed");
        } else {
            fsa.assertFalse(propertyTypePage.isToggleBannerDisplayed(), "Property type page: Toggle partner flow (renewal) - Welcome banner is not displayed");
        }
        navigator.setResumeFromPage(PROPERTY_TYPE);
        AceHRCAddressBasePage addressPage = navigator.navigateToAceHomeAddressPage(applicant, LOB_HOME, HOME);
        addressPage.validatePageTitlesFooters(fsa, applicant, HOME);
        addressPage.validatePageLinksText(fsa, ENTER_INFO);
        addressPage.enterAvailableFields(applicant);
        navigator.setResumeFromPage(ADDRESS_PAGE);
        AceHRCAboutYouBasePage aboutYouPage = navigator.navigateToAceHomeAboutYouPage(applicant, LOB_HOME, HOME);
        fsa.assertEquals(aboutYouPage.getFirstName().toLowerCase(), applicant.getFirstName().toLowerCase(), "About You page - PNI First name value.");
        fsa.assertEquals(aboutYouPage.getLastName().toLowerCase(), applicant.getLastName().toLowerCase(), "About You page - PNI Last name value.");
        fsa.assertEquals(aboutYouPage.getDateOfBirth(), applicant.getDateOfBirth(), "About You page - PNI Date of birth.");
        aboutYouPage.fillOutPartialAboutYouPage(applicant, "Toggle");
        aboutYouPage.clickContinueButton();

        AceHomeContactInfoPage contactInfoPage = new AceHomeContactInfoPage();
        Assert.assertTrue(contactInfoPage.isOnContactInfoPage(true), "Did not reach Contact Info page - Home.");
        navigator.setResumeFromPage(CONTACT_INFO);
        AceHomeReviewQuotePage reviewQuotePage = navigator.navigateToAceHomeReviewQuotePage(applicant, LOB_HOME, HOME);
        Assert.assertTrue(reviewQuotePage.isOnReviewQuotePageHome(true), "Did not reach Review Quote page - Home.");
        navigator.navigateBack(8);
        Assert.assertTrue(propertyTypePage.isOnPropertyTypePage(), "Did not reach Property type page, navigating back - Home.");
        fsa.assertFalse(propertyTypePage.isToggleBannerDisplayed(), "Property type page: Toggle partner flow - Welcome banner should not be displayed.");
    }


    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME}, enabled = false)
    public void testCSSToFFQAceEndToEndQuoteHome(ApplicantAceHome applicant) throws Exception {
    // F95513: FFQ + Mobile App Containment Project
        AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
        navigator.processCSSToFFQFlowPage(applicant, HOME);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        // [Property type] page
        AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
        Assert.assertTrue(propertyTypePage.isOnPropertyTypePage(), DID_NOT_REACH + "Property type page - Home.");
        applicant.setQuoteNumber(propertyTypePage.getSessionStorageAppStore().getData().getQuoteNumber());
        Log.info(NEW_QUOTE_NUMBER + applicant.getQuoteNumber(), true);
        propertyTypePage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, ENTER_INFO, propertyTypePage.getClass().getSimpleName());
        propertyTypePage.selectPropertyType(HOME);

        // [Address] page
        AceHRCAddressBasePage addressPage = new AceHRCAddressBasePage();
        Assert.assertTrue(addressPage.isOnAddressPage(true), DID_NOT_REACH + "Address page - Home.");
        addressPage.validatePageTitlesFooters(fsa, applicant, HOME);
        addressPage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, ENTER_INFO, addressPage.getClass().getSimpleName());
        fsa.assertEquals(addressPage.getAddress().toUpperCase(), applicant.getAddress().toUpperCase(), "Address page - Street address match.");
        fsa.assertEquals(addressPage.getCity().toUpperCase(), applicant.getCity().toUpperCase(), "Address page - City match.");
        fsa.assertEquals(addressPage.getZipCode(), applicant.getZipCode(), "Address page - Zip code match.");
        fsa.assertEquals(addressPage.getState(), applicant.getState(), "Address page - State name match.");
        addressPage.enterAvailableFields(applicant);
        addressPage.clickContinueButton();
        addressPage.waitForSpinnerToBeGone();
        AceHRCPropertyBasePage propertyPage = new AceHRCPropertyBasePage();
        boolean isPropertyYearBuiltPage = propertyPage.isOnHRCPropertyBasePage(false);
        if (isPropertyYearBuiltPage) {
            // [Property year built/sq.ft.] page
            propertyPage.setYearBuiltFieldValue(String.valueOf(applicant.getYearBuilt()));
            propertyPage.setTotalSqFtFieldValue(applicant.getSquareFeet());
            propertyPage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, ENTER_INFO, propertyPage.getClass().getSimpleName());
            propertyPage.clickContinueButton();
        }
        // [Quality grade] page
        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        Assert.assertTrue(qualityGradePage.isOnQualityGradePage(), DID_NOT_REACH + "Quality grade page.");
        qualityGradePage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, ENTER_INFO, qualityGradePage.getClass().getSimpleName());
        qualityGradePage.validateAgentSection(fsa, AceHRCBasePage.QUALITY_GRADE, applicant.getAgentId(), HOME);
        qualityGradePage.fillOutQualityGradePage(applicant, qualityGradePage.getSessionStorageAppStore().getHome().getHomeQualityGradeForm());
        qualityGradePage.clickContinueButton();
        // [Property details] page
        AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
        Assert.assertTrue(propertyDetailsPage.isOnPropertyDetailsPage(), DID_NOT_REACH + "Property details page.");
        propertyDetailsPage.enterPropertyDetails(applicant);
        propertyDetailsPage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, ENTER_INFO, propertyDetailsPage.getClass().getSimpleName());
        propertyDetailsPage.validateAgentSection(fsa, AceHRCBasePage.PROPERTY_DETAILS, applicant.getAgentId(), HOME);
        propertyDetailsPage.clickContinueButton();

        // [Additional info] page
        AceHRCAdditionalInfoBasePage additionalInfo = new AceHRCAdditionalInfoBasePage();
        fsa.assertTrue(additionalInfo.isOnAdditionalInfoPage(), DID_NOT_REACH + "Additional info page.");
        additionalInfo.fillOutAdditionalInfoPageHomeLob(applicant, true);
        additionalInfo.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, ENTER_INFO, additionalInfo.getClass().getSimpleName());
        additionalInfo.validateAgentSection(fsa, AceHRCBasePage.ADDITIONAL_INFO, applicant.getAgentId(), HOME);
        additionalInfo.waitForSpinnerToBeGone();

        // [About You] page
        AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
        fsa.assertTrue(aboutYouPage.isOnAboutYouPage(true), DID_NOT_REACH + "About you page.");
        fsa.assertEquals(aboutYouPage.getFirstName().toLowerCase(), applicant.getFirstName().toLowerCase(), "About You page - PNI First name value.");
        fsa.assertEquals(aboutYouPage.getLastName().toLowerCase(), applicant.getLastName().toLowerCase(), "About You page - PNI Last name value.");
        fsa.assertEquals(aboutYouPage.getDateOfBirth(), applicant.getDateOfBirth(), "About You page - PNI Date of birth.");
        fsa.assertEquals(aboutYouPage.getGenderApplicant(), applicant.getGender(), "About You page - PNI Date of birth.");
        if (applicant.isNewlyOwned()) {
            // enter current or prior address, if needed
            aboutYouPage.enterCurrentOrPriorAddress(applicant);
        }
        aboutYouPage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, ENTER_INFO, aboutYouPage.getClass().getSimpleName());
        aboutYouPage.validateAgentSection(fsa, AceHRCBasePage.ABOUT_YOU, applicant.getAgentId(), HOME);
        aboutYouPage.clickContinueButton();

        // [Contact info] page
        AceHRCContactInfoBasePage contactInfoPage = new AceHRCContactInfoBasePage();
        fsa.assertTrue(contactInfoPage.isOnContactInfoPage(true), DID_NOT_REACH + "Contact info page.");
        fsa.assertEquals(contactInfoPage.getEmailAddress(), applicant.getEmailAddress(), "Contact Info page - e-mail address.");
        fsa.assertEquals(contactInfoPage.getPhoneNumber(), contactInfoPage.getFormattedPhoneNumber(applicant.getPhoneNumber()), "Contact Info page - phone number.");
        contactInfoPage.enterFireHydrantData(applicant);
        contactInfoPage.fillOutBundleAndSave(applicant, HOME);
        contactInfoPage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, ENTER_INFO, contactInfoPage.getClass().getSimpleName());
        contactInfoPage.validateAgentSection(fsa, CONTACT_INFO, applicant.getAgentId(), HOME);
        contactInfoPage.clickOnAgreeAndSubmitButton();

        // [Dwelling coverage] page
        AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceHRCDwellingCoverageBasePage();
        fsa.assertTrue(dwellingCoveragePage.isOnDwellingCoveragePage(), DID_NOT_REACH + "Dwelling coverage page.");
        dwellingCoveragePage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, ENTER_INFO, dwellingCoveragePage.getClass().getSimpleName());
        dwellingCoveragePage.validateAgentSection(fsa, AceHRCBasePage.DWELLING_COVERAGE, applicant.getAgentId(), HOME);
        dwellingCoveragePage.clickContinueButton();
        dwellingCoveragePage.waitForSpinnerToBeGone();

        // [Review quote] page
        AceHomeReviewQuotePage reviewQuotePage = navigator.goToAceHomeReviewQuotePage(applicant);
        reviewQuotePage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, REVIEW_QUOTE, reviewQuotePage.getClass().getSimpleName());
        reviewQuotePage.validateAgentSection(fsa, REVIEW_QUOTE, applicant.getAgentId(), HOME);
        reviewQuotePage.clickOnContinueButton();
        reviewQuotePage.waitForSpinnerToBeGone();

        // [Additional coverages] page
        AceHRCAdditionalCoveragesBasePage additionalCoveragesPage = new AceHRCAdditionalCoveragesBasePage();
        fsa.assertTrue(additionalCoveragesPage.isOnAdditionalCoveragesPage(), DID_NOT_REACH + "Additional coverages page.");
        additionalCoveragesPage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, REVIEW_QUOTE, additionalCoveragesPage.getClass().getSimpleName());
        additionalCoveragesPage.validateAgentSection(fsa, AceHRCBasePage.ADDITIONAL_COVERAGES, applicant.getAgentId(), HOME);
        additionalCoveragesPage.clickOnContinueButton();
        reviewQuotePage.waitForSpinnerToBeGone();

        // [JAFMT] page or [Thank you] page
        AceHRCJustAFewMoreThingsBasePage jFMTPage = new AceHRCJustAFewMoreThingsBasePage();
        AceHRCThankYouBasePage thankYouPage = new AceHRCThankYouBasePage();
        fsa.assertTrue(jFMTPage.isOnJFMTPage(false) || thankYouPage.isOnThankYouPage(), "Did not reach Just a few more things or Thank you page.");
        if (jFMTPage.isOnJFMTPage(false)) {
            // [JMFT] page - Payment flow
            jFMTPage.fillOutJustFewMoreThingsPage(applicant, false);
            jFMTPage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, PURCHASE, jFMTPage.getClass().getSimpleName());
            jFMTPage.validateAgentSection(fsa, AceHRCBasePage.JFMT_PAGE, applicant.getAgentId(), HOME);
            jFMTPage.clickContinueButton();
            jFMTPage.waitForSpinnerToBeGone();

            // [Payment selection] page
            AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
            fsa.assertTrue(aceHRCPaymentSelectionPage.isOnPaymentPage(), DID_NOT_REACH + "Payment selection page.");
            AceHRCBasePage aceHRCBasePage = new AceHRCBasePage();
            aceHRCBasePage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, PURCHASE, aceHRCPaymentSelectionPage.getClass().getSimpleName());
            aceHRCBasePage.validateAgentSection(fsa, AceHRCBasePage.SELECT_PAYMENT, applicant.getAgentId(), HOME);
            (new AceHRCPaymentSelectionPage()).clickSelectAndSetUpPaymentMonthlyPayBank();
            aceHRCPaymentSelectionPage.waitForSpinnerToBeGone();

            AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
            fsa.assertTrue(aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage(), DID_NOT_REACH + "Payment setup page.");
            aceHRCBasePage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, PURCHASE, aceHRCPaymentBasePage.getClass().getSimpleName());
            aceHRCBasePage.validateAgentSection(fsa, AceHRCBasePage.PAYMENT_PAGE, applicant.getAgentId(), HOME);
        } else {
            // [Thank you] page flow
            thankYouPage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
            thankYouPage.verifyQuotePresentmentCard(fsa, HOME);
            thankYouPage.validateHeaderFooterHaveNoFarmersLogoAndLinks(fsa, PURCHASE, thankYouPage.getClass().getSimpleName());
            thankYouPage.validateAgentSection(fsa, THANK_YOU_PAGE, applicant.getAgentId(), HOME);
        }

        fsa.assertAll("Ace Home - CSS to FFQ Ace quote flow.");
    }

}

