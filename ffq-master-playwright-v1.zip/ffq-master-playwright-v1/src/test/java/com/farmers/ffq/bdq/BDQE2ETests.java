package com.farmers.ffq.bdq;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.HeresWhatWeFoundPage;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import com.farmers.ffq.auto.pages.VehiclesDriversInfoPage;
import com.farmers.ffq.auto.pages.bw.BwPaymentSummaryPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.ADPFApplicant;
import com.farmers.ffq.datatransferobjects.AdpfServiceServiceCallEnd;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.*;

import static com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage.MONTHLY_AUTO_PAY_BANK;
import static com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage.MONTHLY_AUTO_PAY_CARD;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.MONTHLY_DIRECT_BILL;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class BDQE2ETests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})
    public void testBDQOrganicFlowE2E_WithRandomPriorInsuranceBrightlineCondition(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        setApplicantPriorBiConditionRandomly(applicant);
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})
    public void testBDQOrganicFlowE2E(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        setApplicantPriorBiConditionRandomly(applicant);
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQOrganicFlowE2E_MultipleVehicleDriver(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        updateApplicantDataToAvoidPossibleBw(applicant);
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQOrganicFlowE2E_MoreThanOneInjury(AutoApplicant applicant) throws Exception {
        applicant.getIncidents().forEach(each -> each.setAnyInjuries(true));
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage("Personal");
            each.setParkInResidentAddress(true);
        });
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQOrganicFlowE2E_LessThan6Month(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        applicant.setContinuosInsurancePeriod("< 6 Months");
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})
    public void testBDQClickToBuyLiteFlowE2E(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        setApplicantPriorBiConditionRandomly(applicant);
        applicant.setTestScenario(BW_CLICK_TO_BUY_LITE_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})
    public void testBDQClickToBuyLiteFlowE2E_WithRandomPriorInsuranceBrightlineCondition(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        setApplicantPriorBiConditionRandomly(applicant);
        applicant.setTestScenario(BW_CLICK_TO_BUY_LITE_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})
    public void testBDQClickToBuyLiteFlowE2E_ForeignDriver(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setFirstAgeForeignDriverLicense(18);
        applicant.setTestScenario(BW_CLICK_TO_BUY_LITE_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQClickToBuyLiteFlowE2E_MultipleVehicleDriver(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(BW_CLICK_TO_BUY_LITE_FLOW + "-> " + applicant.getTestScenario());
        updateApplicantDataToAvoidPossibleBw(applicant);
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQClickToBuyLiteFlowE2E_MoreThanOneInjury(AutoApplicant applicant) throws Exception {
        applicant.getIncidents().forEach(each -> each.setAnyInjuries(true));
        applicant.setTestScenario(BW_CLICK_TO_BUY_LITE_FLOW + "-> " + applicant.getTestScenario());
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage("Personal");
            each.setParkInResidentAddress(true);
        });
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQClickToBuyLiteFlowE2E_LessThan6Month(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.setTestScenario(BW_CLICK_TO_BUY_LITE_FLOW + "-> " + applicant.getTestScenario());
        applicant.setContinuosInsurancePeriod("< 6 Months");
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"),
            @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CT, FL, AZ, CO, GA, IA, ID, IL, KY, MI, MS, MT, NJ, OH, OR, PA, TN, TX, UT, VA, WA})}, groups = {BDQ_TESTS})
    public void testBDQClickToBuyFullFlowE2E(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setTestScenario(BW_CLICK_TO_BUY_FULL_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CT, FL, AZ, CO, GA, IA, ID, IL, KY, MI, MS, MT, NJ, OH, OR, PA, TN, TX, UT, VA, WA})}, groups = {BDQ_TESTS})
    public void testBDQClickToBuyFullFlowE2E_WithRandomPriorInsuranceBrightlineCondition(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        setApplicantPriorBiConditionRandomly(applicant);
        applicant.setTestScenario(BW_CLICK_TO_BUY_FULL_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL}), @CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CT, FL, AZ, CO, GA, IA, ID, IL, KY, MI, MS, MT, NJ, OH, OR, PA, TN, TX, UT, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQClickToBuyFullFlowE2E_ForeignDriver(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setFirstAgeForeignDriverLicense(18);
        applicant.setTestScenario(BW_CLICK_TO_BUY_FULL_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CT, FL, AZ, CO, GA, IA, ID, IL, KY, MI, MS, MT, NJ, OH, OR, PA, TN, TX, UT, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQClickToBuyFullFlowE2E_MultipleVehicleDriver(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(BW_CLICK_TO_BUY_FULL_FLOW + "-> " + applicant.getTestScenario());
        updateApplicantDataToAvoidPossibleBw(applicant);
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CT, FL, AZ, CO, GA, IA, ID, IL, KY, MI, MS, MT, NJ, OH, OR, PA, TN, TX, UT, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQClickToBuyFullFlowE2E_MoreThanOneInjury(AutoApplicant applicant) throws Exception {
        applicant.getIncidents().forEach(each -> each.setAnyInjuries(true));
        applicant.setTestScenario(BW_CLICK_TO_BUY_FULL_FLOW + "-> " + applicant.getTestScenario());
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage("Personal");
            each.setParkInResidentAddress(true);
        });
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CT, FL, AZ, CO, GA, IA, ID, IL, KY, MI, MS, MT, NJ, OH, OR, PA, TN, TX, UT, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQClickToBuyFullFlowE2E_LessThan6Month(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.setTestScenario(BW_CLICK_TO_BUY_FULL_FLOW + "-> " + applicant.getTestScenario());
        applicant.setContinuosInsurancePeriod("< 6 Months");
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})
    public void testBDQMarkettingIdFlowE2E(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setTestScenario(BW_MARKETING_ID_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})
    public void testBDQMarkettingIdFlowE2E_WithRandomPriorInsuranceBrightlineCondition(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        setApplicantPriorBiConditionRandomly(applicant);
        applicant.setTestScenario(BW_MARKETING_ID_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})
    public void testBDQMarkettingIdFlowE2E_ForeignDriver(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setFirstAgeForeignDriverLicense(18);
        applicant.setTestScenario(BW_MARKETING_ID_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQMarkettingIdFlowE2E_MultipleVehicleDriver(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(BW_MARKETING_ID_FLOW + "-> " + applicant.getTestScenario());
        updateApplicantDataToAvoidPossibleBw(applicant);
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQMarkettingIdFlowE2E_MoreThanOneInjury(AutoApplicant applicant) throws Exception {
        applicant.getIncidents().forEach(each -> each.setAnyInjuries(true));
        applicant.setTestScenario(BW_MARKETING_ID_FLOW + "-> " + applicant.getTestScenario());
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage("Personal");
            each.setParkInResidentAddress(true);
        });
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void testBDQMarkettingIdFlowE2E_LessThan6Month(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.setTestScenario(BW_MARKETING_ID_FLOW + "-> " + applicant.getTestScenario());
        applicant.setContinuosInsurancePeriod("< 6 Months");
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})
    public void testBDQ_QuoteCustomizedFlow(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, true);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})
    public void testBDQ_E2E_PAY_IN_FULL(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, PAY_IN_FULL, true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})
    public void testBDQ_E2E_MONTHLY_AUTO_PAY_BANK(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, MONTHLY_AUTO_PAY_BANK, true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})
    public void testBDQ_E2E_MONTHLY_DIRECT_BILL(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, MONTHLY_DIRECT_BILL, true, false);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS})
    public void testBDQ_E2E_MONTHLY_AUTO_PAY_CARD(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        getE2EBwBind(applicant, MONTHLY_AUTO_PAY_CARD, true, false);
    }

    @Test(dataProvider = AutoDataProviders.BIND_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void bdqBindAdpf(ADPFApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper(AceAutoNavigationHelper.quoteFlow.BDQ);
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        HeresWhatWeFoundPage heresWhatWeFoundPage = aceAutoNavigationHelper.navigateToHeresWhatWeFoundPage(applicant);
        String quoteNumber = heresWhatWeFoundPage.getSessionStorageAppStore().getData().getQuoteNumber();
        AdpfServiceServiceCallEnd adpfCallResponsePayload = new ApiHelper().getAdpfCallResponsePayload(quoteNumber);
        int adpfReturnedDriverSize = adpfCallResponsePayload.getADPFResponseBean().getDriver().size();
        int adpfReturnedVehicleSize = adpfCallResponsePayload.getADPFResponseBean().getVehicle().size();
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        int streamLineVehicles = vehiclesDriversInfoPage.getDisplayedVehicles().size();
        int streamLineDrivers = vehiclesDriversInfoPage.getFoundDriversCount();

        int displayedVehicles = Math.max(streamLineVehicles, heresWhatWeFoundPage.getActualListOfDisplayedVehicles().size());
        int displayedDrivers = Math.max(streamLineDrivers, heresWhatWeFoundPage.getNamesOfDisplayedDrivers().size());

        // Validate ADPF is implement in BDQ Ace quote flow and prefill service returned information in Drivers section
        softAssert.assertEquals(adpfReturnedVehicleSize, displayedVehicles, "ADPF returned veh count equals to displayed vehicles");
        softAssert.assertEquals(adpfReturnedDriverSize, displayedDrivers, "ADPF returned driver count equals to displayed driver");
        heresWhatWeFoundPage.checkRandomIncompleteVehicleBox();
        if (heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            vehiclesDriversInfoPage.selectAndEditDefaultAdpfVehicles();
            vehiclesDriversInfoPage.editPNIDriverIfNeededWithAdpfData(applicant);
        } else {
            heresWhatWeFoundPage.addADPFApplicant(Optional.empty(), applicant.getFirstName() + SPACE + applicant.getLastName(), applicant.getGender(), applicant.getDateOfBirth());
        }
        heresWhatWeFoundPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on bw quote page");
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(true);
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        testStepAssert(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User is on the payment selection page ");
        processBwDocuSignAndPayments(MONTHLY_AUTO_PAY_CARD, false);

        softAssert.assertAll();
    }
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE,
            dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"),
            @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS_TESLA})
    public void testBDQOrganicFlowE2E_TeslaSupport(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        setApplicantPriorBiConditionRandomly(applicant);
        applicant.setTestScenario(BW_ORGANIC_FLOW + "-> " + applicant.getTestScenario());
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on bw quote page");
        testStepAssert(quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false),"Successfully navigated to Payment Selection Page");
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")
            , @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS_TESLA})
    public void testBDQClickToBuyLiteFlowE2E_TeslaSupport(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        setApplicantPriorBiConditionRandomly(applicant);
        applicant.setTestScenario(BW_CLICK_TO_BUY_LITE_FLOW + "-> " + applicant.getTestScenario());
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on bw quote page");
        testStepAssert(quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false),"Successfully navigated to Payment Selection Page");
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"),
            @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS_TESLA})
    public void testBDQClickToBuyFullFlowE2E_TeslaSupport(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setTestScenario(BW_CLICK_TO_BUY_FULL_FLOW + "-> " + applicant.getTestScenario());
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on bw quote page");
        testStepAssert(quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false),"Successfully navigated to Payment Selection Page");
        softAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {BDQ_TESTS_TESLA})
    public void testBDQMarkettingIdFlowE2E_TeslaSupport(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setTestScenario(BW_MARKETING_ID_FLOW + "-> " + applicant.getTestScenario());
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on bw quote page");
        testStepAssert(quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false),"Successfully navigated to Payment Selection Page");
        softAssert.assertAll();
    }
}
