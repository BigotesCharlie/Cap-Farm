package com.farmers.ffq.api;

import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.soapui.SoapUI;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;

import static com.farmers.ffq.utils.GlobalVariables.NO_MATCHES_FOUND;
import static com.farmers.ffq.utils.GlobalVariables.SUCCESS;
import static com.farmers.ffq.utils.GlobalVariables.CA;

public class SoapTest extends AutomationFramework {

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public SoapTest() throws Exception {}

	private static final String FFQ_TIME_STAMP_FORMAT  = "yyyy-mm-dd HH:mm:ss.SSSSSS";
	private static final String CHECK_EXISTING_CUSTOMER = "checkExistingCustomer";
	private static final String EVALUATE_PROPERTY_VALUE_TC = "evaluatePropertyValue TestCase";

	private String formatTimeStamp(String timeStampValue) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
		Date date = sdf.parse(timeStampValue);
		sdf.applyPattern(FFQ_TIME_STAMP_FORMAT);
		return sdf.format(date);
	}

    @Skip()
	@Test(groups = "smoke")
	public void existingCustomer() throws Exception {

		SoapUI.setProject("FFQHomeWebServices.xml");
		SoapUI.project().properties().setTestCaseProperty(CHECK_EXISTING_CUSTOMER, "dateOfBirth", "1989-10-12");
		SoapUI.project().properties().setTestCaseProperty(CHECK_EXISTING_CUSTOMER, "firstName", "Bill");
		SoapUI.project().properties().setTestCaseProperty(CHECK_EXISTING_CUSTOMER, "lastName", "Willson");
		SoapUI.project().properties().displayTestCaseProperties();

		JSONObject json = SoapUI.executeTestStep(CHECK_EXISTING_CUSTOMER, "retrieveExistingCustomer");
		JSONObject jsonEnvelop = (JSONObject) json.get("soapenv:Envelope");
		JSONObject jsonBody = (JSONObject) jsonEnvelop.get("soapenv:Body");
		JSONObject existingCustResp = (JSONObject) jsonBody.get("p631:retrieveInsurancePoliciesForPartyResponse");
		JSONObject transactionResponse = (JSONObject) existingCustResp.get("p631:transactionNotification");

		if (transactionResponse.has("p277:remark")) {
			JSONObject messageResponse = (JSONObject) transactionResponse.get("p277:remark");
			String transactionStatus = (String) transactionResponse.get("p277:transactionStatus");
			String messageText = (String) messageResponse.get("p277:messageText");
			System.out.println("Transaction status is : " + transactionStatus + " and respond message is: " + messageText);
			Assert.assertTrue(messageText.equals(NO_MATCHES_FOUND) && transactionStatus.equals(SUCCESS), "Existing Customer call fails. Transaction status is : " + transactionStatus);
		}
	}

	@Skip()
	@Test(groups = "smoke")
	public void propertyRiskAnalysis() throws Exception {

		SoapUI.setProject("FFQHomeWebServices.xml");
		SoapUI.project().properties().setTestCaseProperty(EVALUATE_PROPERTY_VALUE_TC, "address", "21201 KITTRIDGE ST");
		SoapUI.project().properties().setTestCaseProperty(EVALUATE_PROPERTY_VALUE_TC, "city", "WOODLAND HILLS");
		SoapUI.project().properties().setTestCaseProperty(EVALUATE_PROPERTY_VALUE_TC, "zipCode", "91303");
		SoapUI.project().properties().setTestCaseProperty(EVALUATE_PROPERTY_VALUE_TC, "state", CA);
		SoapUI.project().properties().displayTestCaseProperties();

		JSONObject json = SoapUI.executeTestStep(EVALUATE_PROPERTY_VALUE_TC, "evaluatePropertyValue");
		JSONObject jsonBody = (JSONObject) json.get("soapenv:Envelope");
		JSONObject evaluatePropertyValueResponse = (JSONObject) jsonBody.get("soapenv:Body");
		JSONObject propertyValueResponse = (JSONObject) evaluatePropertyValueResponse.get("zsoa:EvaluatePropertyValueResponse");
		JSONObject transactionNotificationResponse = (JSONObject) propertyValueResponse.get("transactionNotificationResponse");
		String transactionStatus = (String) transactionNotificationResponse.get("zsoa2:transactionStatus");
		System.out.println(transactionNotificationResponse.get("zsoa2:transactionStatus"));
		Assert.assertTrue(transactionStatus.equals(SUCCESS), " Property Risk Analysis call fails. Transaction status is : " + transactionNotificationResponse);
	}

    @Skip()
	@Test(groups = "smoke")
	public void agentAssignment() throws Exception {
		SoapUI.setProject("FFQHomeWebServices.xml");
		System.out.println( formatTimeStamp(LocalDate.now().toString()));

	}
}
