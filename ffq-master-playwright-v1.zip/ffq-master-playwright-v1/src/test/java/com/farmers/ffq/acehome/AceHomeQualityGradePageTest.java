package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyInfoBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCQualityGradeBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.QUALITY_GRADE;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeQualityGradePageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES)}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_QUALITY_GRADE_PAGE})
    public void validateContentOfQualityGradePageHomeLob(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
        boolean quoteDisplayed = navigator.isNewFlowEnabledState(applicant.getStateCode());
        AceHRCPropertyInfoBasePage propertyInfoPage = navigator.navigateToAceHomePropertyInfoPage(applicant);
        navigator.setResumeFromPage(PROPERTY_INFO);
        AceHRCQualityGradeBasePage qualityGradePage;
        if (!propertyInfoPage.isQualityGradePageAvailable()) {
            // New flow - F109072: FFQ Home: Suppression of "Your Home Quality Grade" Screen (A/B test)
            qualityGradePage = navigator.navigateToHRCPropertyDetailsQualityGradePage(applicant, LOB_HOME, HOME);

            qualityGradePage.validateHeaderForQualityGradeSection(fsa, HOME);
            qualityGradePage.validateAddressOnQualityGradeSection(fsa, HOME);
        } else {
            // Old flow - Quality grade page is a separate page
            qualityGradePage = navigator.navigateToHRCQualityGradePage(applicant, LOB_HOME, HOME);
            qualityGradePage.validateHeaderAndSubHeaderForQualityGradePage(fsa, HOME);
            qualityGradePage.validateAddressOnQualityGradePage(fsa, HOME);
        }
        AppStore appStore = qualityGradePage.getSessionStorageAppStore();
        qualityGradePage.validateAgentSection(fsa, QUALITY_GRADE, applicant.getAgentId(), HOME);
        qualityGradePage.validateQuoteText(QUALITY_GRADE, applicant.getQuoteNumber(), fsa, quoteDisplayed);
        qualityGradePage.validateErrorOnQualityGradePage(fsa, appStore.getHome().getHomeQualityGradeForm(), HOME);
        qualityGradePage.validateGeneralShapeAndStyleSection(fsa, appStore.getHome(), HOME);
        qualityGradePage.validateExteriorFeaturesAndFinishedSection(fsa, appStore.getHome(), HOME);
        qualityGradePage.validateInteriorFeaturesAndFinishedSection(fsa, appStore.getHome(), HOME);
        qualityGradePage.validateCabinetsAndCounterTopsSection(fsa, appStore.getHome(), HOME);
        qualityGradePage.validateWhyIsThisImportantQuestionSectionValidation(fsa, HOME);
        qualityGradePage.validateDiscounts(QUALITY_GRADE, applicant, HOME, fsa);
        qualityGradePage.fillOutQualityGradePage(applicant, appStore.getHome().getHomeQualityGradeForm());
        qualityGradePage.validateQuoteText(QUALITY_GRADE, applicant.getQuoteNumber(), fsa, quoteDisplayed);
        fsa.assertAll("Ace Home - Quality grade validation");
    }
}
