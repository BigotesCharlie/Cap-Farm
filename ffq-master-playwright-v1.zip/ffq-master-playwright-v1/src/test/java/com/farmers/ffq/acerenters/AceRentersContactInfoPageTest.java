package com.farmers.ffq.acerenters;

import com.farmers.ffq.ace.hrc.common.AceHRCContactInfoBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCFwsInterstitialPage;
import com.farmers.ffq.ace.renters.AceRentersContactInfoPage;
import com.farmers.ffq.ace.renters.AceRentersNavigationHelper;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.CONTACT_INFO;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersContactInfoPageTest extends AutomationFramework {
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE})
    public void validateContactInfoPageRentersLob(ApplicantAceHome applicant) throws Exception {
        AceHRCContactInfoBasePage contactInfoPageAceHome = new AceRentersNavigationHelper().navigateToAceRentersContactInfoPage(applicant);
        AceRentersContactInfoPage aceRentersContactInfoPage = new AceRentersContactInfoPage();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoPageAceHome.validateHeaderAndSubHeaderContactInfoPage(fsa);
        contactInfoPageAceHome.validateContentOfEstimatedClosingOrPolicyStartDate(fsa, RENTERS);
        contactInfoPageAceHome.validateBundleSaveSection(applicant, fsa, RENTERS);
        contactInfoPageAceHome.validateContentOfFireHydrantSection(fsa, RENTERS);
        aceRentersContactInfoPage.validateContentOfStormShutterSection(fsa, RENTERS);
        aceRentersContactInfoPage.validateAgentSection(fsa, CONTACT_INFO, applicant.getAgentId(), RENTERS);
        aceRentersContactInfoPage.saveQuoteSubmit(applicant.getEmailAddress());
        aceRentersContactInfoPage.validateQuoteText(CONTACT_INFO, applicant.getQuoteNumber(), fsa, true);
        aceRentersContactInfoPage.validateContinueButtonText(fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, MT})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CRITICAL, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE})
    public void validateContactInfoPageErrorMessagesRentersLob(ApplicantAceHome applicantAceHome) throws Exception {
        AceHRCContactInfoBasePage contactInfoPageAceHome = new AceRentersNavigationHelper().navigateToAceRentersContactInfoPage(applicantAceHome);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        contactInfoPageAceHome.validateErrorMessages(fsa, applicantAceHome, RENTERS);
        fsa.assertAll();
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL})}, groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE})
    public void validateFloorResidenceLocatedRentersLob(ApplicantAceHome applicantAceHome) throws Exception {
        applicantAceHome.setAddress("26072 Perdido Beach");
        applicantAceHome.setUnit("200E");
        applicantAceHome.setCity("Orange Beach");
        applicantAceHome.setZipCode("36561");
        AceHRCContactInfoBasePage contactInfoPage = new AceRentersNavigationHelper().navigateToAceRentersContactInfoPage(applicantAceHome);
        testStepAssertTrue(contactInfoPage.validateFloorResidenceIsLocatedOnSection(RENTERS), "Floor residence is located section is displayed", true);
        testStep("End Of Test");
    }

    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_BINDABLE_CHOICE, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, AL, ID, IL, IN, MO, NE, NM, OH, OK, SD, TX, TN, WI, WY})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE})
    public void validateFWSInterstitialToBindableChoiceIntegrationRenters(ApplicantAceHome applicantAceHome) throws Exception {

        applicantAceHome.setAgentId(EMPTY_STRING);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceRentersContactInfoPage contactInfoPageAceRenters = new AceRentersNavigationHelper().navigateToAceRentersContactInfoPage(applicantAceHome);
        contactInfoPageAceRenters.fillOutContactInfoPageRenters(applicantAceHome);
        contactInfoPageAceRenters.waitForSpinnerToBeGone();
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        Assert.assertTrue(fwsInterstitialPage.isOnFarmersChoiceInterstitialPage(), "User is not navigated to FWS Interstitial page");
        driver().navigate().refresh(); //F96276
        fwsInterstitialPage.validateFwsFarmersChoicePage(fsa, RENTERS);
        fwsInterstitialPage.clickOnApplyDiscountButton();
        Assert.assertTrue(fwsInterstitialPage.isOnBindableChoicePage(20), "User is not navigated to Bindable Choice page after clicking on Apply Discount button from FWS Interstitial page");
        fwsInterstitialPage.validateSelectedInsuranceType(fsa, RENTERS);
        fsa.assertAll("Validate FWS Interstitial to Bindable Choice Integration from Contact Info page - Renters LOB.");
    }

    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_COLP, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, AL, ID, IL, IN, MO, NE, NM, OH, OK, SD, TX, TN, WI, WY})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE})
    public void validateFWSInterstitialColpPageRenters(ApplicantAceHome applicant) throws Exception {

        applicant.setAgentId(EMPTY_STRING);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceRentersContactInfoPage contactInfoPageAceRenters = new AceRentersNavigationHelper().navigateToAceRentersContactInfoPage(applicant);
        contactInfoPageAceRenters.fillOutContactInfoPageRenters(applicant);
        contactInfoPageAceRenters.waitForSpinnerToBeGone();
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        Assert.assertTrue(fwsInterstitialPage.isOnColpInterstitialPage(), "User is not navigated to FWS Interstitial - Colp page");
        driver().navigate().refresh(); //F96276
        fwsInterstitialPage.validateFwsColpPage(fsa, RENTERS);
        fsa.assertAll("Validate FWS Interstitial COLP page from Contact Info page - Renters LOB.");
    }

    @Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_FWS_INTERSTITIAL_QNB, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, AL, ID, IL, IN, MO, NE, NM, OH, OK, SD, TX, TN, WI, WY})},
            groups = {FFQ_ACE_RENTERS, FFQ_ACE_RENTERS_CONTACT_INFO_PAGE})
    public void validateFWSInterstitialQnBPageRenters(ApplicantAceHome applicant) throws Exception {

        applicant.setAgentId(EMPTY_STRING);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceRentersContactInfoPage contactInfoPageAceRenters = new AceRentersNavigationHelper().navigateToAceRentersContactInfoPage(applicant);
        contactInfoPageAceRenters.fillOutContactInfoPageRenters(applicant);
        contactInfoPageAceRenters.waitForSpinnerToBeGone();
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        Assert.assertTrue(fwsInterstitialPage.isOnQnBInterstitialPage(), "User is not navigated to FWS Interstitial - QnB page");
        driver().navigate().refresh(); //F96276
        fwsInterstitialPage.validateFwsQnBPage(fsa);
        fwsInterstitialPage.clickOnGetMyQuoteButton();
        fwsInterstitialPage.waitForSpinnerToBeGone();
        Assert.assertTrue(fwsInterstitialPage.isOnQnBSite(), "User did not landed on QnB site after clicking on Get My Quote button from FWS Interstitial page - Renters LOB");
        fwsInterstitialPage.validateQnBUrl(fsa);
        fsa.assertAll("Validate FWS Interstitial QnB page content from Contact Info page - Renters LOB.");
    }
}
