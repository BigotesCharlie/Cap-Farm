package com.farmers.ffq.acemobilehome;

import static com.farmers.ffq.utils.GlobalVariables.EXCLUDED_STATES;
import static com.farmers.ffq.utils.GlobalVariables.FFQ_MOBILE_HOME;
import static com.farmers.ffq.utils.GlobalVariables.FOREMOST;
import static com.farmers.ffq.utils.GlobalVariables.MN;
import static com.farmers.ffq.utils.GlobalVariables.PARTTIME;
import static com.farmers.ffq.utils.GlobalVariables.UNOCCUPIED;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.AutomationFramework;

public class ForemostMobileHomePageValidationTests extends AutomationFramework {

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void verifyForemostAddressPageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().verifyAddressPageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void validateForemostAddressPageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().validateAddressPageErrorHandling(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void verifyForemostTellUsMorePageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().verifyTellUsMorePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void validateForemostTellUsMorePageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().validateTellUsMorePageErrorHandling(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void verifyForemostAboutYouPageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().verifyAboutYouPageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void validateForemostAboutYouPageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().validateAboutYouPageErrorHandling(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void verifyForemostLastStepPageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().verifyLastStepPageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.RANDOM_MOBILEHOME_APPLICANT, groups = {FFQ_MOBILE_HOME})
	public void validateForemostLastStepPageErrorHandling(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().validateLastStepPageErrorHandling(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {FFQ_MOBILE_HOME})
	public void verifyForemostQuotePageContent(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {FFQ_MOBILE_HOME})
	public void verifyForemostLandlordMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		//RENT is the default for all applicants
		enableForemostMode(mobilehomeApplicant);
		mobilehomeApplicant.setPrimaryResidence(false);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {FFQ_MOBILE_HOME})
	public void verifyForemostSeasonalSecondaryMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		mobilehomeApplicant.setPrimaryResidence(false);
		mobilehomeApplicant.setReasonWhyNotPrimaryResidence(PARTTIME);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MN})}, groups = {FFQ_MOBILE_HOME})
	public void verifyForemostVacantMobilehomeQuote(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enableForemostMode(mobilehomeApplicant);
		mobilehomeApplicant.setPrimaryResidence(false);
		mobilehomeApplicant.setReasonWhyNotPrimaryResidence(UNOCCUPIED);
		new AceMobileCommonTestHelper().verifyQuotePageContent(mobilehomeApplicant);
	}

	private void enableForemostMode(ApplicantAceHome mobilehomeApplicant) {
		mobilehomeApplicant.setTestCategory(FOREMOST);
	}
}
