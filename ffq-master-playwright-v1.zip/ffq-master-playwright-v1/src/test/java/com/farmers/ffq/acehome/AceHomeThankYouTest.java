package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeContactInfoPage;
import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.common.pages.FGIALandingPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeThankYouTest extends AutomationFramework {
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_THANK_YOU_SCREEN_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_THANK_YOU_PAGE})
    public void validateContentOfThankYouPageHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCAdditionalCoveragesBasePage additionalCoveragesPage = new AceHomeNavigationHelper().navigateToAceHomeAdditionalCoveragesPage(applicant, LOB_HOME, HOME);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AppStore appStore = additionalCoveragesPage.getSessionStorageAppStore();
        AppStore.Home.RateQuoteResponse rateQuoteResponse = appStore.getHome().getQuote().getRateQuoteResponses().get(0);
        boolean isBindDisabled = rateQuoteResponse.getBuyEnableInd().equals("N");
        additionalCoveragesPage.clickOnContinueButton();
        if (isBindDisabled) {
            AceHRCThankYouBasePage aceHomeThankYouPage = new AceHRCThankYouBasePage();
            Assert.assertTrue(aceHomeThankYouPage.isOnThankYouPage(), "Did not reach Thank You page.");
            aceHomeThankYouPage.validateThankYouPage(applicant, fsa, HOME, true);
        } else {
            AceHRCJustAFewMoreThingsBasePage jfmtPage = new AceHRCJustAFewMoreThingsBasePage();
            if(jfmtPage.isOnJFMTPage(true)){
                jfmtPage.selectMortgageOnThisProperty(false);
                if(applicant.isInEscrow()) {
                    jfmtPage.validateEscrowDetailsOnJFMTPage(fsa, HOME);
                }
                jfmtPage.fillOutJustFewMoreThingsPage(applicant, true);
            }
            KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
            assert koPage.isOnKnockOutPage();
            // Validate Thank you for choosing farmers insurance page
            koPage.validateKnockOutOnSelectingQuestionsFromJFMT(fsa, applicant.getQuoteNumber());
            }
        fsa.assertAll("Validated Landed on Thank you page for Home LOB.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_THANK_YOU_PAGE})
    public void validateThankYouPageWhenPropertyTypeDuplexHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCThankYouBasePage aceHomeThankYouPage = new AceHomeNavigationHelper().navigateToAceHomeThankYouPage(applicant, LOB_HOME, DUPLEX);
        // Validate Thank you for choosing farmers insurance page
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        aceHomeThankYouPage.validateThankYouPage(applicant, fsa, HOME, false);
        fsa.assertAll("Validated Landed on Thank you page when propertyType=Duplex for Home LOB.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_THANK_YOU_SCREEN_VALIDATION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_THANK_YOU_PAGE}, enabled = false)
    public void validateThankYouPageWhenAddressIsCAHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHRCAdditionalCoveragesBasePage additionalCoveragesPage = new AceHomeNavigationHelper().navigateToAceHomeAdditionalCoveragesPage(applicant, LOB_HOME, HOME);

        // Validate Thank you for choosing farmers insurance page
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalCoveragesPage.validateDiscounts(AceHRCBasePage.ADDITIONAL_COVERAGES, applicant, HOME, fsa);
        additionalCoveragesPage.clickOnContinueButton();
        AceHRCThankYouBasePage aceHomeThankYouPage = new AceHRCThankYouBasePage();
        Assert.assertTrue(aceHomeThankYouPage.isOnThankYouPage(), "Did not reach Thank You page.");
        aceHomeThankYouPage.validateThankYouPage(applicant, fsa, HOME, false);
        fsa.assertAll("Validated Landed on Thank you page when stateCode=CA for Home LOB.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_RECONSTRUCTION_COST_1_TO_1N_HALF, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_THANK_YOU_PAGE})
    public void testValidateMaxRCTLimitNotToExceed1n5MHomeLob(ApplicantAceHome applicant) throws Exception {
        //F86604: Optimization - Home - Increase Max RCT to $1.5 Million (states excluded from RCT increase: AR, CA, OK, TX)

        final String MAX_RECONSTRUCTION_COST_1_5M = "$1,500,000";
        final String MAX_RECONSTRUCTION_COST_SUBTEXT = "Maximum coverage available";

        AceHomeNavigationHelper navigator = new AceHomeNavigationHelper();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        String maxRctLimitCode;
        String stateCode = applicant.getStateCode();
        AceHRCBasePage basePage = new AceHRCBasePage();
        if (!basePage.isRCTOneMilLimitState(stateCode)) {
            AceHRCDwellingCoverageBasePage dwellingCoveragePage = navigator.navigateToAceHomeDwellingCoveragePage(applicant, LOB_HOME, HOME);

            dwellingCoveragePage.clickOnEditCoverageLink();
            int radiosCount = dwellingCoveragePage.getListOfReconstructionCoverageAmountLabels().size();
            fsa.assertEquals(dwellingCoveragePage.getListOfReconstructionCoverageAmountLabels().get(radiosCount - 1), MAX_RECONSTRUCTION_COST_1_5M,
                    "Reconstruction cost radio button of $1,500,000 is the last option in Dwelling coverage page.");
            fsa.assertEquals(dwellingCoveragePage.getListOfReconstructionCoverageAmountLabelsSubText().get(radiosCount - 1), MAX_RECONSTRUCTION_COST_SUBTEXT,
                    "Reconstruction cost radio button of $1,500,000 has expected subtext in Dwelling coverage page.");
            dwellingCoveragePage.clickOnCloseIconDwellingCoverageSideSheet();
            dwellingCoveragePage.clickContinueButton();
            navigator.setResumeFromPage(REVIEW_QUOTE);
            navigator.goToAceHomeReviewQuotePage(applicant);
            navigator.navigateToAceHomeThankYouPage(applicant, LOB_HOME, HOME);
            maxRctLimitCode = "MAXRCTLMT";
        } else {
            AceHRCContactInfoBasePage contactInfoPage = navigator.navigateToAceHomeContactInfoPage(applicant, LOB_HOME, HOME);
            contactInfoPage.fillOutContactInfoPage(applicant, HOME);
            contactInfoPage.waitForSpinnerToBeGone();
            FGIALandingPage fgiaLandingPage = new FGIALandingPage();
            fgiaLandingPage.validateContentOfFGIAPopUp(fsa, HOME);
            if (fgiaLandingPage.isFgiaNoThanksButtonDisplayed()) {
                fgiaLandingPage.clickNoThanksButtonInFGIAPopUp();
                fgiaLandingPage.weAreNotAbleToCompleteQuotePageValidation(fsa, HOME);
            }
            maxRctLimitCode = "MAXRCTLMT2";
        }
        fsa.assertTrue((new AceHRCBasePage()).getKnockoutErrors().contains(maxRctLimitCode), "Verified that quote gets expected Max RCT Limit KO code.");
        fsa.assertAll("Validated Landed on Thank you page or (KO for excluded states), when max RCT is b/w 1M and 1.5M for Home LOB.");
    }
}

