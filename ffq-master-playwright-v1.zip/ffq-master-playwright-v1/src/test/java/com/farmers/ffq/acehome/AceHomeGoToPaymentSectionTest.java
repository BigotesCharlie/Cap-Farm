package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeGoToPaymentSectionTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})},
            groups = {ACE_STABILITY, FFQ_ACE_HOME_PAYMENT_SELECTION_PAGE})
    public void testQuoteAndBindHomeLob(ApplicantAceHome applicant) throws Exception {
        AceHomeNavigationHelper aceHRCNavigator = new AceHomeNavigationHelper();
        AceHRCPaymentBasePage aceHRCPaymentBasePage = applicant.getStateCode().equals(UT)
                ? aceHRCNavigator.navigateToPayInFullPaymentPageAceHome(applicant, LOB_HOME, HOME)
                : aceHRCNavigator.navigateToMonthlyAutoPayBankPaymentPageAceHome(applicant, LOB_HOME, HOME);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.clickSetUpPaymentButton();
        aceHRCPaymentBasePage.enterBankAccountDetailsAndClickOnAddButton(fsa, HOME);
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();
        aceHRCPaymentBasePage.validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(fsa, HOME);
        aceHRCPaymentBasePage.validateNoServiceChargeWhenUsingBankTransfer(fsa, HOME);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, HOME);
        aceHRCPaymentBasePage.validateCompletePurchase(fsa, HOME);
        fsa.assertAll("Ace Home - Validate quote and bind, end-to-end.");
    }
 }
