package com.farmers.ffq.specialtyDwelling;

import static com.farmers.ffq.utils.GlobalVariables.SPECIALTY_DWELLING;
import static com.farmers.ffq.utils.GlobalVariables.FOREMOST;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.AutomationFramework;

public class ForemostHomeSpecialtyDwellingQuoteScenarioTests extends AutomationFramework {

	@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES,
			attributes = {@CustomAttribute(name = SPECIALTY_DWELLING)}, groups = {SPECIALTY_DWELLING})
	public void verifyForemostExpectedDiscounts(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enableForemostMode(specialtyDwellingApplicant);
		new AceHomeSpecialtyDwellingTestHelper(specialtyDwellingApplicant).verifyDisplayOfExpectedDiscounts(specialtyDwellingApplicant);
		testStep("End Of Test");
	}

	private void enableForemostMode(ApplicantAceHome specialtyDwellingApplicant) {
		specialtyDwellingApplicant.setTestCategory(FOREMOST);
	}
}
