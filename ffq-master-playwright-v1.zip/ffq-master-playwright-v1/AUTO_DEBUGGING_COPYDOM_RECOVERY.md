# FFQ Playwright Java — Copy-DOM, AutoDebugging and Recovery Flow

The diagnostic/recovery strategy is implemented at the shared Playwright framework layer. Individual `@Test` methods do not need bespoke wiring, so the same behavior is available to the complete migrated inventory and the deterministic E2E suite.

## Runtime flow

```text
TestNG @BeforeMethod
  -> TestExecutionContext
  -> lazy PlaywrightSession
  -> Playwright trace starts
  -> action/navigation/select/JS-click
       -> Copy-DOM checkpoint BEFORE
       -> execute transition
       -> detect rendered page state
       -> Copy-DOM checkpoint AFTER when state changed
       -> if unexpected interruption:
            classify state
            persist recovery context
            screenshot + DOM + inner text
            click semantic "Try again"
            maximum 2 attempts
            retry last safe transition only when the rendered fingerprint returned to the pre-transition state
  -> assertion/test completion
  -> on failure:
       failure-current-page.html
       failure-current-page.png
       failure-inner-texts.txt
       failure-metadata.json
       debug-summary.json
       playwright-trace.zip
  -> @AfterMethod closes BrowserContext/Page
```

## Rendered states

`PageStateDetector` uses URL + visible DOM text + visible landmarks. It does not assume that a URL alone identifies the page.

- `NORMAL`
- `TRY_AGAIN`
- `INCONVENIENCE`
- `KNOCKOUT`
- `PURCHASE_SUCCESS`
- `UNKNOWN`

`TRY_AGAIN`, `INCONVENIENCE`, and `KNOCKOUT` are classified as application/environment states first. They are not silently re-labeled as locator failures.

## Bounded Recovery Flow

Default recovery budget:

```text
maxInconvenienceRecovery = 2
```

Recovery is attempted only when a visible semantic **Try again** control exists. The manager:

1. Captures the interruption state.
2. Saves browser storage/context for quote-resume debugging.
3. Clicks the role/button-based `Try again` control.
4. Detects the rendered state again.
5. If the application returned to exactly the previous safe fingerprint, retries only the last safe transition.
6. Stops after the configured maximum attempts.

For E2E tests, an unexpected recoverable interruption that remains after the recovery budget is exhausted raises `RecoveryExhaustedException`, producing deterministic failure evidence rather than continuing in an unknown state.

### Expected Knockout/Inconvenience protection

Negative/functional tests that intentionally validate Knockout or Inconvenience must not be auto-healed. `TestExecutionContext` and `RecoveryManager` protect these scenarios using:

- test class/method naming signals;
- TestNG group signals;
- the active Java call path.

Expected interruptions still produce diagnostic evidence, but Recovery does not change the application state.

## Copy-DOM artifacts

Artifacts are stored per test and execution:

```text
build/artifacts/dom/<ClassName>.<testMethod>/<execution-id>/
```

Typical files:

```text
001-before-<action>.html
001-before-<action>-metadata.json
002-after-<action>.html
002-after-<action>-metadata.json
003-incident-recovery-attempt-1-before.html
003-incident-recovery-attempt-1-before.png
003-incident-recovery-attempt-1-before-inner-texts.txt
recovery-context.json
failure-current-page.html
failure-current-page.png
failure-inner-texts.txt
failure-metadata.json
debug-summary.json
playwright-trace.zip
```

DOM snapshots use Playwright `page.content()` and diagnostic text/token sanitization before files are written.

## `debug-summary.json`

The final failure summary includes:

- test class/method/execution ID;
- E2E flag;
- whether interruption was expected by the test;
- last action / failed action;
- expected state;
- actual rendered state;
- last successful checkpoint;
- recovery attempt count;
- current URL/title;
- detected landmarks;
- failure classification;
- compact sanitized stack information.

Primary classifications include:

- `APPLICATION_ENVIRONMENT_INTERRUPTION`
- `APPLICATION_FUNCTIONAL_KNOCKOUT`
- `AUTOMATION_OR_LOCATOR_FAILURE`
- `UNKNOWN_RENDERED_STATE`
- `TEST_FAILURE`

## Default properties

The strategy is enabled in the project configuration by default:

```properties
autoDebug=true
copyDom=true
recoveryFlow=true
maxInconvenienceRecovery=2
copyDomMaxCheckpoints=200
traceOnFailure=true
recoverKnockout=true
failOnRecoveryExhausted=true
autoDebugSettleMillis=300
```

Any value can be overridden with a JVM `-D` property when a targeted diagnostic run requires different behavior.

Example:

```bash
./gradlew clean e2eTest \
  -Denvironment=regression \
  -Ddriver=chrome \
  -Dheadless=false \
  -DautoDebug=true \
  -DcopyDom=true \
  -DrecoveryFlow=true \
  -DmaxInconvenienceRecovery=2
```

## Manual functional checkpoint

Page flows may optionally add a named checkpoint without implementing their own artifact logic:

```java
copyDomCheckpoint("contact-information-complete");
```

This is optional; central transition/failure capture remains active even when no manual checkpoints are added.
