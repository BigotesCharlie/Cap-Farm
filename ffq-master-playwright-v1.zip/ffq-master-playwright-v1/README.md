# ffq-master-playwright-v1

This is the complete migrated copy of `ffq-test-master (1).zip`. The browser automation runtime is **Java 17 + Playwright Java**. The original TestNG inventory, page objects, data providers, resources, API helpers, Rally integration and end-to-end coverage are preserved.

## Migration integrity

- 2,936 / 2,936 executable `@Test` methods preserved
- 217 / 217 test classes preserved
- 2,942 / 2,942 raw `@Test` annotations preserved
- 0 missing test methods
- 0 unexpected extra test methods
- 132 E2E-signaled methods across 23 classes in the deterministic E2E inventory
- 0 direct references to the removed browser runtime library
- 0 fixed blocking sleep calls
- 0 Python/JavaScript/TypeScript/C# source files

## Runtime

- Java 17
- Playwright Java 1.62.0
- TestNG 7.10.2
- Thread-confined `BrowserContext` and `Page` lifecycle
- Lazy browser creation so API/data-only tests do not open a browser
- Playwright locators, auto-waits, navigation, tabs, frames, dialogs, cookies, keyboard/mouse, JavaScript evaluation and screenshots
- Framework-level Copy-DOM + AutoDebugging + bounded Recovery Flow
- Failure DOM, screenshot, metadata, debug summary and Playwright trace under `build/artifacts/dom/<Class.test>/<execution-id>/`


## Copy-DOM + AutoDebugging + Recovery Flow

Enabled by default for the shared Playwright runtime. The framework captures numbered DOM states around browser transitions, classifies the rendered application state, preserves failure evidence, and performs bounded recovery for unexpected **Try again / Inconvenience / recoverable Knockout** interruptions. Expected Knockout/Inconvenience validation scenarios are protected from auto-recovery.

Default recovery budget is **2 attempts**. See [`AUTO_DEBUGGING_COPYDOM_RECOVERY.md`](AUTO_DEBUGGING_COPYDOM_RECOVERY.md) for architecture, artifacts, configuration and recovery rules.

## First-time setup

```bash
./gradlew playwrightInstall
```

## Run the existing configured regression group

```bash
./gradlew clean test -Denvironment=regression -Ddriver=chrome -Dheadless=false
```

The standard `test` task keeps the project properties for suite/group, package, environment, driver, threads, Rally/Jenkins context and failure re-run behavior.

## Run the exact full migrated inventory

```bash
./gradlew clean allMigratedTests -Denvironment=regression -Ddriver=chrome -Dheadless=false
```

`allMigratedTests` is backed by `migration-reports/all-tests-suite.xml`, which explicitly lists all 2,936 migrated methods.

## Run the exact E2E inventory

```bash
./gradlew clean e2eTest -Denvironment=regression -Ddriver=chrome -Dheadless=false
```

`e2eTest` is backed by `migration-reports/e2e-suite.xml`, which explicitly lists all E2E-signaled methods detected either from an E2E/EndToEnd class/package or from the method name.

## Audit the migration

```bash
./gradlew verifyMigration
```

Evidence is under `migration-reports/`:

- `TEST_INVENTORY.csv`
- `E2E_INVENTORY.csv`
- `ORIGINAL_TEST_INVENTORY.json`
- `VALIDATION_SUMMARY.json`
- `all-tests-suite.xml`
- `e2e-suite.xml`
- `COMPLETE_MIGRATION_REPORT.md`

## Validation boundary

The delivered tree has been statically reconciled against the uploaded source project. This sandbox cannot resolve the external Gradle dependency graph or access protected Farmers QA/UAT applications, so a live 2,936-test PASS claim is intentionally not made here. Run `verifyMigration`, then compile and execute on the approved corporate workstation/CI agent with artifact and environment access.
