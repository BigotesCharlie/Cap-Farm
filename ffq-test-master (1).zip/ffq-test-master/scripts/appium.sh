#!/bin/bash
appium-doctor &> appium-console.log
appium --log-level info &> appium-console.log
