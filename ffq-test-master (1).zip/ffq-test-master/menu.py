#!/usr/bin/env python
import json
import os
import platform

exit = False
max_key_length = 0
os_type = platform.system()
enterNewValue = "enter new value: "

# read input properties into dictionary
test_properties = json.loads(open('properties.json').read())
menu_properties = {}
cap_properties  = {}

# copy input properties to menu properties dictionary
for k,v in test_properties.get("test").items():
    menu_properties[k] = v
    if max_key_length < len(k):
        max_key_length = len(k)

for k,v in test_properties.get("environment").get(menu_properties["environment"]).items():
    menu_properties[k] = v
    if max_key_length < len(k):
        max_key_length = len(k)

# python 2/3 compatibility for input
try: input = raw_input
except NameError: pass


# os launch command
if os_type =="Windows":
    open_file_command = 'start'
else:
    open_file_command = 'open'

def clear_screen():
    if os_type =='Windows':
        os.system('cls')
    else:
        os.system('clear')

def capabilities():
    max_cap_key_length = 0
    exit_menu = False
    driver = menu_properties.get("driver")
    if driver == "apple" or driver == "android":
        driver_type = "mobile"
    else:
        driver_type = "web"

    if len(cap_properties) == 0:
        for key, value in test_properties.get(driver_type).get(driver).get("capabilities").items():
            cap_properties[key] = value
            if max_cap_key_length < len(key):
                max_cap_key_length = len(key)
        try:
            for key, value in test_properties.get(driver_type).get(driver).get("arguments").items():
                cap_properties[key] = value
                if max_cap_key_length < len(key):
                    max_cap_key_length = len(key)
        except AttributeError:
            print ("no arguments in properties.json file for driver:" + driver)
    else:
        for k,v in cap_properties.items():
            if max_cap_key_length < len(k):
                max_cap_key_length = len(k)

    while not exit_menu:
        clear_screen()
        print ("\n %s - capabilities\n" % driver)
        for key, value in sorted(cap_properties.items()):
            print (" %s\t\t%s" % (key.ljust(max_cap_key_length),value))
        print ("\n x     exit")
        selection = input("\n enter option > ")
        if selection == 'x':
            exit_menu = True
        elif selection in cap_properties:
            new_value = input(enterNewValue)
            cap_properties[selection] = new_value
        else:
            input("\n invalid entry: " + selection)

# menu
while not exit:
    clear_screen()
    run_gradle = False
    print("")
    if os_type !="Windows":
        command="./gradlew "
        os.system("echo ${PWD##*/}")
    else:
        command="gradlew.bat "

    os.system("git branch")
    print ("")
    # display properties
    for k,v in sorted(menu_properties.items()):
        print (" %s\t\t%s" % (k.ljust(max_key_length), v))
        command += "-D%s=%s " % (k,v)

    for k,v in sorted(cap_properties.items()):
        command += "-D%s='%s' " % (k,v)

    print ("\n b     select branch")
    print (" c     compile")
    print (" j     javadocs")
    print (" q     quality")
    print (" r     report list")
    print (" rt    test report")
    print (" rc    code coverage report")
    print (" rq    quality reports")
    print (" t     run tests")
    print (" dc    driver capabilities")
    print (" x     exit")
    selection=input("\nenter option > ")

    if selection =='x':
        exit = True
    elif selection in menu_properties:
        if menu_properties[selection].lower() =="true":
            menu_properties[selection] = "false"
        elif menu_properties[selection].lower() =="false":
            menu_properties[selection] = "true"
        elif selection == 'environment':
            newValue = input(enterNewValue)
            try:
                for key, value in test_properties.get("environment").get(newValue).items():
                    menu_properties[key] = value
                    if max_key_length < len(key):
                        max_key_length = len(key)
                menu_properties[selection] = newValue
            except:
                input("invalid environment type: " + newValue)
        elif selection == 'driver':
            newValue = input(enterNewValue)
            menu_properties[selection] = newValue
            cap_properties  = {}
            maxCapKeyLength = 0
        else:
            newValue = input(enterNewValue)
            menu_properties[selection] = newValue
    elif selection =='b':
        newBranch=input("enter branch name: ")
        os.system("git checkout " + newBranch)
        command += "clean compile"
        run_gradle = True
    elif selection =='c':
        command += "clean compile"
        run_gradle = True
    elif selection =='j':
        command += "javadoc"
        run_gradle = True
    elif selection =='q':
        command += "quality"
        run_gradle = True
    elif selection =='dc':
        capabilities()
    elif selection =='rt':
        os.system(open_file_command + " build/reports/tests/test/emailable-report.html")
        os.system(open_file_command + " build/reports/index.html")
    elif selection =='rc':
        os.system(open_file_command + " build/reports/codeCoverage/index.html")
    elif selection =='rq':
        os.system(open_file_command + " build/reports/checkstyle/*.html")
        os.system(open_file_command + " build/reports/findbugs/*.html")
        os.system(open_file_command + " build/reports/pmd/*.html")
    elif selection =='r':
        os.system(open_file_command + " build/reports/buildDashboard/index.html")
    elif selection =='t':
        if menu_properties.get("failures") == 'true':
            command += "test"
        else:
            command += "clean test"
        run_gradle = True
    else:
        print ("invalid input: " + selection)
        input("press any key to continue")

    if run_gradle:
        clear_screen()
        os.system("echo ${PWD##*/}")
        os.system(command)
        input("press any key to continue")
