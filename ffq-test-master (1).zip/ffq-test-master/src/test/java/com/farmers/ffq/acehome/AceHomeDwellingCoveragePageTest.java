package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeContactInfoPage;
import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.common.pages.FGIALandingPage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.DWELLING_COVERAGE;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeDwellingCoveragePageTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDE_NONMONOLINE_HOME_STATES), @CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})},
            groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_DWELLING_COVERAGE_PAGE})
    public void dwellingCoveragePageContentValidationHomeLob(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        AceHRCContactInfoBasePage contactInfoPage = new AceHomeNavigationHelper().navigateToAceHomeContactInfoPage(applicant, LOB_HOME, HOME);
        contactInfoPage.fillOutContactInfoPage(applicant, HOME);
        AceHRCDwellingCoverageBasePage dwellingCoveragePageAceHome = new AceHRCDwellingCoverageBasePage();
        AppStore sessionStorageData = dwellingCoveragePageAceHome.getSessionStorageAppStore();
        String reconstructionCost = sessionStorageData.getHome().getReconstructionCost();
        if (reconstructionCost != null) {
            if (!(Integer.parseInt(reconstructionCost) > ONEMILLION)) {
                dwellingCoveragePageAceHome.validateDwellingCoverageHeaderAndImage(fsa);
                dwellingCoveragePageAceHome.validateQuoteProgressSavedContent(fsa);
                dwellingCoveragePageAceHome.validateQuoteText(DWELLING_COVERAGE, applicant.getQuoteNumber(), fsa, true);
                dwellingCoveragePageAceHome.validateAgentSection(fsa, DWELLING_COVERAGE, applicant.getAgentId(), HOME);
                dwellingCoveragePageAceHome.validateDwellingCoverageInfoSection(fsa);
                dwellingCoveragePageAceHome.validateDwellingCoverageDetailsSection(fsa, sessionStorageData);
                dwellingCoveragePageAceHome.validateEditCoverageAndQualityGradeLinkSectionHomeLob(fsa);
                dwellingCoveragePageAceHome.clickOnLearnMoreLink();
                dwellingCoveragePageAceHome.validateContentOfLearnMoreSideSheet(fsa);

                dwellingCoveragePageAceHome.clickOnEditCoverageLink();
                dwellingCoveragePageAceHome.validateContentOfDwellingCoverageAndGradeSideSheet(fsa);
                dwellingCoveragePageAceHome.clickOnCloseIconDwellingCoverageSideSheet();
                dwellingCoveragePageAceHome.validateDwellingCoverageDetailsSection(fsa, sessionStorageData);
                dwellingCoveragePageAceHome.clickOnEditCoverageLink();
                dwellingCoveragePageAceHome.updateReconstructionRadioButtonAndValidateUpdatedCost(fsa);
                dwellingCoveragePageAceHome.validateBrowserForwardButtonIsDisableAfterUpdatingCustomCoveragePage(fsa, HOME);
                // validate save quote side sheet
                dwellingCoveragePageAceHome.validateSaveQuoteModal(true);

                // Navigate back to validate quote details (i.e., Quote no. & Save Quote link / Quote progress is saved! text on previous pages
                dwellingCoveragePageAceHome.navigateBack();
                contactInfoPage = new AceHomeContactInfoPage();
                Assert.assertTrue(contactInfoPage.isOnContactInfoPage(true), "Failed to navigate back to Contact Info page from Dwelling Coverage page.");
                contactInfoPage.validateQuoteText(AceHRCBasePage.CONTACT_INFO, applicant.getQuoteNumber(), fsa, true);
                contactInfoPage.updatePolicyStartDate(applicant);
                contactInfoPage.validateSaveQuoteModal(true);
                contactInfoPage.navigateBack();
                if (!contactInfoPage.isNewFlowEnabledState(applicant.getStateCode())) {
                    AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
                    Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "Failed to navigate back to About You page from Contact Info page.");
                    aboutYouPage.validateQuoteText(AceHRCBasePage.ABOUT_YOU, applicant.getQuoteNumber(), fsa, true);
                    aboutYouPage.navigateBack();
                }
                AceHRCAdditionalInfoBasePage additionalInfoPage = new AceHRCAdditionalInfoBasePage();
                Assert.assertTrue(additionalInfoPage.isOnAdditionalInfoPage(), "Failed to navigate back to Additional Info page from About you page.");
                additionalInfoPage.validateQuoteText(AceHRCBasePage.ADDITIONAL_INFO, applicant.getQuoteNumber(), fsa, true);
                additionalInfoPage.navigateBack();
                AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
                Assert.assertTrue(propertyDetailsPage.isOnPropertyDetailsPage(), "Failed to navigate back to Property details page from Additional Info page.");
                propertyDetailsPage.validateQuoteText(AceHRCBasePage.PROPERTY_DETAILS, applicant.getQuoteNumber(), fsa, true);
                AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
                if (!qualityGradePage.isOnPropertyDetailsQualityGradePage(false)) {
                    propertyDetailsPage.navigateBack();
                }
                qualityGradePage.validateQuoteText(AceHRCBasePage.QUALITY_GRADE, applicant.getQuoteNumber(), fsa, true);
            } else { //F99042 - FGIA Redirection
                FGIALandingPage fgiLandingPage = new FGIALandingPage();
                fgiLandingPage.validateContentOfFGIAPopUp(fsa, HOME);
            }
            fsa.assertAll();
        }
    }
}
