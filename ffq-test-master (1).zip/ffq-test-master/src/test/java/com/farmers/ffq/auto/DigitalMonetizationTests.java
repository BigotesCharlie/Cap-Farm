package com.farmers.ffq.auto;

import static com.farmers.ffq.utils.GlobalVariables.AWS_SCENARIOS;
import static com.farmers.ffq.utils.GlobalVariables.DIGITAL_MONETIZATION;
import static com.farmers.ffq.utils.GlobalVariables.MONETIZED_STATES;
import static com.farmers.ffq.utils.GlobalVariables.REGRESSION;
import static com.farmers.ffq.utils.GlobalVariables.CA;
import static com.farmers.ffq.utils.GlobalVariables.CT;
import static com.farmers.ffq.utils.GlobalVariables.FL;
import static com.farmers.ffq.utils.GlobalVariables.GA;
import static com.farmers.ffq.utils.GlobalVariables.KY;
import static com.farmers.ffq.utils.GlobalVariables.LA;
import static com.farmers.ffq.utils.GlobalVariables.MA;
import static com.farmers.ffq.utils.GlobalVariables.MS;
import static com.farmers.ffq.utils.GlobalVariables.NC;
import static com.farmers.ffq.utils.GlobalVariables.NJ;
import static com.farmers.ffq.utils.GlobalVariables.NV;
import static com.farmers.ffq.utils.GlobalVariables.NY;

import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.common.pages.LegacyNonOfferingPage;
import com.farmers.ffq.dataproviders.SqlDataProviders;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.datatransferobjects.SqlRepresentative;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;

public class DigitalMonetizationTests {
	private static final String NOBW = "NOBW";
	private static final String FGIA = "FGIA";
	private static final String DIGITAL_MONETIZATION_PAGE_DISPLAYED = " \"Unable to provide quote page\" displayed";

	@Skip
	@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, 
	attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CA, GA, NY})}, groups = {REGRESSION, DIGITAL_MONETIZATION})
	public void testDirectToDMPage(SqlApplicant applicant) throws Exception {
		checkIfMonetizationScreenDisplayed(applicant, true);
	}	

	@Skip
	@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, 
	attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {NC, NV})}, groups = {REGRESSION, DIGITAL_MONETIZATION})
	public void testAutoFGIANoThanks(SqlApplicant applicant) throws Exception {
		checkIfMonetizationScreenDisplayed(applicant, true);
	}	

	@Skip
	@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, 
	attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CT, KY, LA, MS, NJ})}, groups = {REGRESSION, DIGITAL_MONETIZATION})
	public void testAutoApplicantCurrentlyInsured(SqlApplicant applicant) throws Exception {
		applicant.setCurrentlyHaveAutoInsurance(true);
		checkIfMonetizationScreenDisplayed(applicant, true);
	}

	@Skip
	@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, 
	attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CT, KY, LA, MS, NJ})}, groups = {REGRESSION, DIGITAL_MONETIZATION})
	public void testAutoApplicantCurrentlyNotInsuredDontUseBristolWest(SqlApplicant applicant) throws Exception {
		applicant.setCurrentlyHaveAutoInsurance(false);
		applicant.setCurrentlyInsuredStatus(NOBW);
		checkIfMonetizationScreenDisplayed(applicant, true);
	}

	@Skip
	@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, 
	attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CT, KY, LA, MS, NJ})}, groups = {REGRESSION, DIGITAL_MONETIZATION})
	public void testAutoApplicantCurrentlyNotInsuredUseBristolWest(SqlApplicant applicant) throws Exception {
		applicant.setCurrentlyHaveAutoInsurance(false);
		applicant.setCurrentlyInsuredStatus("Insured");
		checkIfMonetizationScreenDisplayed(applicant, false);
	}	

	@Skip
	@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, 
	attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {NC, NV})}, groups = {REGRESSION, DIGITAL_MONETIZATION})
	public void testAutoContinueToFGIA(SqlApplicant applicant) throws Exception {
		applicant.setPhoneExtentionNumber(FGIA);
		checkIfMonetizationScreenDisplayed(applicant, false);
	}	

	@Skip
	@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, 
	attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CT, KY, MA})}, groups = {REGRESSION, DIGITAL_MONETIZATION})
	public void testAutoCurrentlyInsuredContinueToFGIA(SqlApplicant applicant) throws Exception {
		applicant.setPhoneExtentionNumber(FGIA);
		applicant.setCurrentlyHaveAutoInsurance(true);
		checkIfMonetizationScreenDisplayed(applicant, false);
	}	

	@Skip
	@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, 
	attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CT, KY, MA})}, groups = {REGRESSION, DIGITAL_MONETIZATION})
	public void testAutoCurrentlyNotInsuredContinueToFGIA(SqlApplicant applicant) throws Exception {
		applicant.setPhoneExtentionNumber(FGIA);
		applicant.setCurrentlyHaveAutoInsurance(false);
		applicant.setCurrentlyInsuredStatus(NOBW);
		checkIfMonetizationScreenDisplayed(applicant, false);
	}	

	@Skip
	@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, 
	attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {FL})}, groups = {REGRESSION, DIGITAL_MONETIZATION})
	public void testAutoApplicantDontUseBristolWest(SqlApplicant applicant) throws Exception {
		applicant.setCurrentlyInsuredStatus(NOBW);
		checkIfMonetizationScreenDisplayed(applicant, true);
	}

	@Skip
	@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_COMMON_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, 
	attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {FL})}, groups = {REGRESSION, DIGITAL_MONETIZATION})
	public void testAutoApplicantUseBristolWest(SqlApplicant applicant) throws Exception {
		applicant.setCurrentlyInsuredStatus("Insured");
		checkIfMonetizationScreenDisplayed(applicant, false);
	}	

	@Skip
	@Test(dataProvider = SqlDataProviders.ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER, dataProviderClass = SqlDataProviders.class, 
	attributes = {@CustomAttribute(name = MONETIZED_STATES, values = {CA, CT, FL, GA, KY, MA, MS, NC, NJ, NV, NY})}, groups = {REGRESSION, DIGITAL_MONETIZATION})
	public void testAutoUsingAWS(SqlApplicant applicant) throws Exception {
		String applicantStateCode = applicant.getStateCode();
		applicant.setCurrentlyHaveAutoInsurance(false);
		applicant.setCurrentlyInsuredStatus("Insured");
		applicant.setTestCategory(AWS_SCENARIOS);
		SqlRepresentative representative = applicant.getRepresentative();
		representative.setStateCode(applicantStateCode);
		switch (applicantStateCode) {
		case CT:
			representative.setAor("82197F");
			representative.setZipCode("06105");
			break;
		case FL:
			representative.setAor("411998");
			representative.setZipCode("32225");
			break;
		case NJ:
			representative.setAor("845143");
			representative.setZipCode("07065");
			break;
		}
		applicant.setRepresentative(representative);
		checkIfMonetizationScreenDisplayed(applicant, false);
	}

	private void checkIfMonetizationScreenDisplayed(SqlApplicant applicant, boolean expectMonetizationScreen) throws Exception {
		try {
			QuoteScenarios quotes = new QuoteScenarios();
			quotes.createAutoQuote(applicant, false);
		} catch (IllegalStateException ise) {
			// This exception type is thrown when monetized testing to stop quote process and check.
			Log.info(ise.getMessage());
		} catch (TimeoutException te) {
			// The FGIA popup was not found
			Log.info(te.getMessage());
		} catch (AssertionError ae) {
			//Not really interested in any validation errors when creating the quote
			Log.info(ae.getMessage());
		} catch (Exception e) {
			Log.info("Generic exception: " + e.toString());
		} finally {
			LegacyNonOfferingPage legacyNonOfferingPage = new LegacyNonOfferingPage();
			if (expectMonetizationScreen) {
				Assert.assertTrue(legacyNonOfferingPage.quotingUnavailableTextExists(), applicant.getStateName() + DIGITAL_MONETIZATION_PAGE_DISPLAYED);
			} else {
				Assert.assertFalse(legacyNonOfferingPage.quotingUnavailableTextExists(), applicant.getStateName() + DIGITAL_MONETIZATION_PAGE_DISPLAYED);
				if (applicant.getPhoneExtentionNumber().equals(FGIA)) {
					Assert.assertTrue(AutomationFramework.driver().getCurrentUrl().contains("farmersgeneralinsuranceagency"), "Farmers General Insurance Agency website displayed when quoting from " + applicant.getStateName());
				}
			}
		}
	}

}
