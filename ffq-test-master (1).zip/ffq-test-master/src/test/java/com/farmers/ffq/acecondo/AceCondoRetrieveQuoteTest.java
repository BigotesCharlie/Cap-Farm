package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.*;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.PROPERTY_DETAILS;
import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.QUALITY_GRADE;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoRetrieveQuoteTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_RETRIEVE_FLOW})
    public void testRetrieveNonRatedQuoteCondo(ApplicantAceHome applicant) throws Exception {
        AceCondoCustomCoveragePage customCoveragePage = new AceCondoNavigationHelper().navigateToAceCondoCustomCoveragePage(applicant);
        String personalPropertyValue = customCoveragePage.getPersonalPropertyValue();
        String buildingInteriorValue = customCoveragePage.getBuildingInteriorValue();
        List<String> discountsBeforeRetrieve = customCoveragePage.getDiscounts();
        Collections.sort(discountsBeforeRetrieve);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);

        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        if (qualityGradePage.isQualityGradePageAlone()) {
            // [Quality grade] page
            Assert.assertTrue(qualityGradePage.isOnQualityGradePage(), "Did not reach Quality grade page.");
            qualityGradePage.validateHeaderAndSubHeaderForQualityGradePage(fsa, CONDO);
            qualityGradePage.validateAddressOnQualityGradePage(fsa, CONDO);
            qualityGradePage.verifyDisplayedFeatures(fsa, applicant);
            qualityGradePage.validateDiscounts(QUALITY_GRADE, discountsBeforeRetrieve, fsa);
            qualityGradePage.clickContinueButton();
        } else {
            // [Property details + Quality grade] page
            Assert.assertTrue(qualityGradePage.isOnPropertyDetailsQualityGradePage(true), "Did not reach Property details + Quality grade page.");
            qualityGradePage.validateHeaderForQualityGradeSection(fsa, CONDO);
            qualityGradePage.validateAddressOnQualityGradeSection(fsa, CONDO);
            qualityGradePage.verifyDisplayedFeatures(fsa, applicant);
        }

        // Validate [Property details] page
        AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
        Assert.assertTrue(propertyDetailsPage.isOnPropertyDetailsPage(), "Did not reach Property details page.");
        fsa.assertTrue(propertyDetailsPage.isPageTitleDisplayed(), "Property details page title is displayed.");
        propertyDetailsPage.validatePropertyDetails(applicant, CONDO, fsa);
        propertyDetailsPage.validateDiscounts(PROPERTY_DETAILS, discountsBeforeRetrieve, fsa);
        propertyDetailsPage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        propertyDetailsPage.clickContinueButton();

        // Validate [Additional info] page
        AceCondoAdditionalInfoPage additionalInfoPage = new AceCondoAdditionalInfoPage();
        Assert.assertTrue(additionalInfoPage.isOnAdditionalInfoPage(), "Did not reach Additional info page.");
        additionalInfoPage.validateAdditionalInfoSelections(applicant, fsa);
        additionalInfoPage.clickContinueButton();
        additionalInfoPage.waitForSpinnerToBeGone();

        // Validate [About You] page
        if (!additionalInfoPage.isNewFlowEnabledState(applicant.getStateCode())) {
            AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
            Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "Did not reach About you page.");
            aboutYouPage.validateAboutYouSelections(applicant, false, fsa);
            aboutYouPage.clickContinueButton();
        }

        // Validate [Contact info] page
        AceCondoContactInfoPage contactInfoPage = new AceCondoContactInfoPage();
        Assert.assertTrue(contactInfoPage.isOnContactInfoPage(true), "Did not reach Contact info page - Condo.");
        contactInfoPage.validateContactInfoSelections(applicant, false, CONDO, fsa);
        contactInfoPage.clickOnAgreeAndSubmitButton();

        // Validate [Custom coverage] page
        customCoveragePage = new AceCondoCustomCoveragePage();
        Assert.assertTrue(customCoveragePage.isOnCustomCoveragePageAceCondo(), "Did not reach Custom coverage page.");
        fsa.assertEquals(customCoveragePage.getPersonalPropertyValue(), personalPropertyValue,
                "Custom coverage page - personal property value.");
        fsa.assertEquals(customCoveragePage.getBuildingInteriorValue(), buildingInteriorValue,
                "Custom coverage page - building interior value.");
        List<String> discountsAfterRetrieve = contactInfoPage.getDiscounts();
        Collections.sort(discountsAfterRetrieve);
        fsa.assertEquals(discountsAfterRetrieve, discountsBeforeRetrieve, "Custom coverage page - discounts.");
        fsa.assertEquals(customCoveragePage.getAceQuoteNumberInThePage(), applicant.getQuoteNumber(),
                "Custom coverage page - custom coverage page quote number.");

        fsa.assertAll("Ace Condo - Retrieve non-rated quote.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_RETRIEVE_FLOW})
    public void testRetrieveRatedQuoteCondo(ApplicantAceHome applicant) throws Exception {
        AceCondoCustomCoveragePage customCoveragePage = new AceCondoNavigationHelper().navigateToAceCondoCustomCoveragePage(applicant);
        String personalPropertyValue = customCoveragePage.getPersonalPropertyValue();
        String buildingInteriorValue = customCoveragePage.getBuildingInteriorValue();
        customCoveragePage.clickContinueButton();

        AceCondoReviewQuotePage reviewQuotePage = new AceCondoNavigationHelper().goToAceCondoReviewQuotePage(applicant);
        String quotePrice = reviewQuotePage.getQuotePriceOnCard();
        List<String> discountsBeforeRetrieve = reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList());

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);

        // Validate [Review quote] page
        reviewQuotePage = new AceCondoReviewQuotePage();
        fsa.assertTrue(reviewQuotePage.isSnackBarMessageDisplayed("Welcome back " + applicant.getFirstName()), "Welcome back snack bar message is displayed.");
        reviewQuotePage = new AceCondoNavigationHelper().goToAceCondoReviewQuotePage(applicant);
        fsa.assertEquals(reviewQuotePage.getQuotePriceOnCard() ,quotePrice, "Review quote page - quote premium after retrieval match.");
        reviewQuotePage.verifyQuotePresentmentCard(fsa);
        reviewQuotePage.clickPriceAlternative();
        reviewQuotePage.validateQuoteText(REVIEW_QUOTE, applicant.getQuoteNumber(), fsa, true);
        reviewQuotePage.validateAgentSection(fsa, REVIEW_QUOTE, applicant.getAgentId(), CONDO);
        fsa.assertEquals(reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList()), discountsBeforeRetrieve,
                "Review quote page - quote discounts after retrieval match.");
        reviewQuotePage.selectStepper(ENTER_INFO);  // move back to the Quality page, using stepper

        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        if (qualityGradePage.isQualityGradePageAlone()) {
            // [Quality grade] page
            Assert.assertTrue(qualityGradePage.isOnQualityGradePage(), "Did not reach Quality grade page.");
            qualityGradePage.validateHeaderAndSubHeaderForQualityGradePage(fsa, CONDO);
            qualityGradePage.validateAddressOnQualityGradePage(fsa, CONDO);
            qualityGradePage.verifyDisplayedFeatures(fsa, applicant);
            qualityGradePage.validateDiscounts(QUALITY_GRADE, discountsBeforeRetrieve, fsa);
            qualityGradePage.clickContinueButton();
        } else {
            // [Property details + Quality grade] page
            Assert.assertTrue(qualityGradePage.isOnPropertyDetailsQualityGradePage(true), "Did not reach Property details + Quality grade page.");
            qualityGradePage.validateHeaderForQualityGradeSection(fsa, CONDO);
            qualityGradePage.validateAddressOnQualityGradeSection(fsa, CONDO);
            qualityGradePage.verifyDisplayedFeatures(fsa, applicant);
        }

        // Validate [Property details] page
        AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
        Assert.assertTrue(propertyDetailsPage.isOnPropertyDetailsPage(), "Did not reach Property details page.");
        fsa.assertTrue(propertyDetailsPage.isPageTitleDisplayed(), "Property details page title is displayed.");
        propertyDetailsPage.validatePropertyDetails(applicant, CONDO, fsa);
        propertyDetailsPage.validateDiscounts(PROPERTY_DETAILS, discountsBeforeRetrieve, fsa);
        propertyDetailsPage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        propertyDetailsPage.clickContinueButton();

        // Validate [Additional info] page
        AceCondoAdditionalInfoPage additionalInfoPage = new AceCondoAdditionalInfoPage();
        Assert.assertTrue(additionalInfoPage.isOnAdditionalInfoPage(), "Did not reach Additional info page.");
        additionalInfoPage.validateAdditionalInfoSelections(applicant, fsa);
        additionalInfoPage.clickContinueButton();

        // Validate [About You] page
        if (!additionalInfoPage.isNewFlowEnabledState(applicant.getStateCode())) {
            AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
            Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "Did not reach About you page.");
            aboutYouPage.validateAboutYouSelections(applicant, true, fsa);
            aboutYouPage.clickContinueButton();
        }

        // Validate [Contact info] page
        AceHRCContactInfoBasePage contactInfoPage = new AceHRCContactInfoBasePage();
        Assert.assertTrue(contactInfoPage.isOnContactInfoPage(true), "Did not reach Contact info page - Condo.");
        contactInfoPage.validateContactInfoSelections(applicant, true, CONDO, fsa);
        contactInfoPage.clickOnAgreeAndSubmitButton();

        // Validate [Custom coverage] page
        Assert.assertTrue(customCoveragePage.isOnCustomCoveragePageAceCondo(), "Did not reach Custom coverage page.");
        fsa.assertEquals(customCoveragePage.getPersonalPropertyValue(), personalPropertyValue,
                "Custom coverage page - personal property value.");
        fsa.assertEquals(customCoveragePage.getBuildingInteriorValue(), buildingInteriorValue,
                "Custom coverage page - building interior value.");
        List<String> discountsAfterRetrieve = contactInfoPage.getDiscounts();
        Collections.sort(discountsAfterRetrieve);
        fsa.assertEquals(discountsAfterRetrieve, discountsBeforeRetrieve, "Custom coverage page - discounts.");
        fsa.assertEquals(customCoveragePage.getAceQuoteNumberInThePage(), applicant.getQuoteNumber(),
                "Custom coverage page - custom coverage page quote number.");
        customCoveragePage.clickContinueButton();

        // Validate [Review quote] page
        reviewQuotePage = new AceCondoNavigationHelper().goToAceCondoReviewQuotePage(applicant);
        reviewQuotePage.verifyQuotePresentmentCard(fsa);
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        reviewQuotePage.validateDiscounts(REVIEW_QUOTE, applicant, CONDO, fsa);

        fsa.assertAll("Ace Condo - Retrieve rated quote.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_RETRIEVE_FLOW})
    public void testRetrieveRatedQuoteFromJFMTPageCondo(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceCondoReviewQuotePage reviewQuoteBasePage = new AceCondoNavigationHelper().navigateToAceCondoReviewQuotePage(applicant);
        List<String> discountsBeforeRetrieve = reviewQuoteBasePage.getDiscounts().stream().sorted().collect(Collectors.toList());
        String quotePrice = reviewQuoteBasePage.getQuotePriceOnCard();
        reviewQuoteBasePage.clickOnContinueButton();
        AceCondoAdditionalCoveragesPage additionalCoveragesPage = new AceCondoAdditionalCoveragesPage();
        fsa.assertTrue(additionalCoveragesPage.isOnAdditionalCoveragesPageAceCondo(),"Did not reach additional coverage page");
        additionalCoveragesPage.clickContinueButton();
        AceCondoJustAFewMoreThingsPage justAFewMoreThingsPage = new AceCondoJustAFewMoreThingsPage();
        fsa.assertTrue(justAFewMoreThingsPage.isOnJFMTPage(true),"Did not reach JFMT page");
        justAFewMoreThingsPage.fillOutJustFewMoreThingsPageCondo(applicant,true);

        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);
        AceCondoReviewQuotePage reviewQuotePage = new AceCondoReviewQuotePage();
        fsa.assertTrue(reviewQuotePage.isSnackBarMessageDisplayed("Welcome back " + applicant.getFirstName()), "Welcome back snack bar message is displayed.");
        reviewQuotePage = new AceCondoNavigationHelper().goToAceCondoReviewQuotePage(applicant);
        fsa.assertEquals(reviewQuotePage.getQuotePriceOnCard(), quotePrice, "Review quote page - quote premium after retrieval match.");
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        fsa.assertEquals(reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList()), discountsBeforeRetrieve,
                "Review quote page - quote discounts after retrieval match.");
        reviewQuotePage.clickOnContinueButton();
        AceCondoAdditionalCoveragesPage additionalCoveragePage = new AceCondoAdditionalCoveragesPage();
        Assert.assertTrue(additionalCoveragePage.isOnAdditionalCoveragesPage(), "Did not reach Additional coverage page.");
        if (applicant.getStateCode().equals(CA)) {
            additionalCoveragePage.validateEarthquakeSection(fsa);
        }
        additionalCoveragePage.clickContinueButton();
        Assert.assertTrue(justAFewMoreThingsPage.isOnJFMTPage(true), "Did not reach JFMT page.");
        justAFewMoreThingsPage.validateJFMTPageSelectionsCondo(applicant.getDogsOnPremises(),applicant,fsa, false);
        fsa.assertAll("Ace Condo - Retrieve rated quote left from payment page");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_RETRIEVE_FLOW})
    public void testRetrieveRatedQuoteFromPaymentPageCondoLob(ApplicantAceHome applicant) throws Exception {
        AceCondoReviewQuotePage aceCondoReviewQuoteBasePage = new AceCondoNavigationHelper().navigateToAceCondoReviewQuotePage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        String quotePrice = aceCondoReviewQuoteBasePage.getQuotePriceOnCard();
        List<String> discountsBeforeRetrieve = aceCondoReviewQuoteBasePage.getDiscounts().stream().sorted().collect(Collectors.toList());
        aceCondoReviewQuoteBasePage.clickOnContinueButton();
        AceHRCAdditionalCoveragesBasePage coveragesBasePage = new AceHRCAdditionalCoveragesBasePage();
        Assert.assertTrue(coveragesBasePage.isOnAdditionalCoveragesPage()  ,"Did not reach additional coverage page");
        coveragesBasePage.clickOnContinueButton();
        AceHRCJustAFewMoreThingsBasePage justAFewMoreThingsBasePage = new AceHRCJustAFewMoreThingsBasePage();
        Assert.assertTrue(justAFewMoreThingsBasePage.isOnJFMTPage(true),"Did not reach JFMT page");
        justAFewMoreThingsBasePage.fillOutJustFewMoreThingsPage(applicant,true);
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        Assert.assertTrue(aceHRCPaymentBasePage.isOnContinueToPaymentPage(),"Did not reach to Payment page");
        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);

        // F76803 - Validate RC2 screen is not displayed in retrieval flow.
        fsa.assertFalse(new AceCondoCustomCoveragePage().isOnRC2LoadingPage(2), "RC2 loading page is displayed after retrieving rated quote - " + CONDO);
        fsa.assertTrue(aceCondoReviewQuoteBasePage.isSnackBarMessageDisplayed("Welcome back " + applicant.getFirstName()), "Welcome back snack bar message is displayed.");
        aceCondoReviewQuoteBasePage = new AceCondoNavigationHelper().goToAceCondoReviewQuotePage(applicant);
        fsa.assertEquals(aceCondoReviewQuoteBasePage.getQuotePriceOnCard(), quotePrice, "Review quote page - quote premium after retrieval match.");
        aceCondoReviewQuoteBasePage.verifyQuotePresentmentCard(fsa);
        aceCondoReviewQuoteBasePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        fsa.assertEquals(aceCondoReviewQuoteBasePage.getDiscounts().stream().sorted().collect(Collectors.toList()), discountsBeforeRetrieve,
                "Review quote page - quote discounts after retrieval is not matching.");
        aceCondoReviewQuoteBasePage.clickOnContinueButton();
        Assert.assertTrue(coveragesBasePage.isOnAdditionalCoveragesPage(), "Did not reach Additional coverage page.");
        coveragesBasePage.clickOnContinueButton();
        Assert.assertTrue(justAFewMoreThingsBasePage.isOnJFMTPage(true), "Did not reach JFMT page.");
        justAFewMoreThingsBasePage.validateJFMTPageSelectionsCondo(applicant.getDogsOnPremises(),applicant,fsa, false);
        justAFewMoreThingsBasePage.clickContinueButton();
        // F76803 - Validate RC3 screen in retrieval flow.
        justAFewMoreThingsBasePage.validateRC3LoadingScreen(fsa);
        Assert.assertTrue(aceHRCPaymentBasePage.isOnContinueToPaymentPage(),"Verify rate failure, Retrieved quote did not reach to Payment page");

        // Moving to Quality Grade page using stepper
        aceCondoReviewQuoteBasePage.selectStepper(ENTER_INFO);
        AceHRCPropertyInfoBasePage propertyInfoPage = new AceHRCPropertyInfoBasePage();
        Assert.assertTrue(propertyInfoPage.isOnPropertyInfoPage(false), "Did not reach Property info page.");
        propertyInfoPage.clickContinueButton();

        //Steppers are disabled after making any change on Quality Grade pag
        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        Assert.assertTrue(qualityGradePage.isOnQualityGradeOrPropertyDetailsAndQualityCombined(false), "Did not reach Property Details and/or Quality grade page.");
        qualityGradePage.updateExteriorValidateReviewQuoteAndPurchaseStepper(fsa);
        fsa.assertAll("Ace Condo - Retrieve rated quote left on Payment page");
    }
}
