package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.annotation.Skip;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;
import org.openqa.selenium.WebElement;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AgentDetailsTests extends BaseTest {


    @Skip //retired as part of F75792
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AGENT_DETAILS})
    public void agentDetailsLabelAndErrorTests(AutoApplicant applicant) throws Exception {
        new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant).returnToWhoShouldWeInsurePage();

        AgentDetails agentDetails = new AgentDetails();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(agentDetails.isYourAgentLabelDisplayed(), "Your agent label displayed");
        fsa.assertTrue(agentDetails.isAgentNamePresent(), "Agent name present");
        fsa.assertTrue(agentDetails.isContactMeLinkDisplayed(), "Contact agent link displayed");
        String agentName = agentDetails.getAssignedAgentName();
        String quoteNumber = agentDetails.getQuoteNumber();
        agentDetails.clickAgentContactMeButton();
        fsa.assertEquals(agentDetails.getSidePanelAssignedAgentName(), agentName, "Agent names match");
        fsa.assertTrue(agentDetails.validateSidePanelLabels(), "Contact Agent side panel content correct");
        fsa.assertEquals(agentDetails.getSidePanelQuoteNumber(), quoteNumber, "Quote numbers match");
        fsa.assertEquals(agentDetails.getSidePanelCustomerFirstName().toLowerCase(), applicant.getFirstName().toLowerCase(), "First names match");
        fsa.assertEquals(agentDetails.getSidePanelCustomerLastName().toLowerCase(), applicant.getLastName().toLowerCase(), "Last names match");
        testStep("Agent contact me side panel prefilled values are validated");
        agentDetails.validateSidePanelErrorMessages(fsa);
        agentDetails.validateDateField(fsa);

        agentDetails.validateAgentContactDetailsAndLinks(fsa);
        agentDetails.validateContactReasonFieldMaxChar(fsa);
        fsa.assertAll();
    }

    @Skip //retired as part of F75792
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ})}, groups = {FFQ_ONEUI, PROD_ENVIRONMENT, AGENT_DETAILS})
    public void agentDetailsUsageTest(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        randomizeApplicantPersonalData(applicant);
        String phoneNumber = aceAutoNavigationHelper.isProdEnvironment() ? "(484) 345-4344" : "(484)345-4344";
        applicant.setPhoneNumber(phoneNumber);
        if (aceAutoNavigationHelper.isProdEnvironment()) {
            updatePersonalInfoForProd(applicant);
        }
        aceAutoNavigationHelper.navigateToVehicleReviewPage(applicant).returnToWhoShouldWeInsurePage();

        // Check request submitted data
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AgentDetails agentDetails = new AgentDetails();
        LocalDate aWeekFromToday = LocalDate.now().plusWeeks(1);
        String aWeekFromNow = aWeekFromToday.format(DateTimeFormatter.ofPattern(MM_DD_YYYY));
        String aWeekFromNowAlternate = aWeekFromToday.format(DateTimeFormatter.ofPattern("EEE MMM d, yyyy"));
        int randomTimeslot = ThreadLocalRandom.current().nextInt(0, 7);
        agentDetails.clickAgentContactMeButton();
        agentDetails.fillOutContactMeForm(applicant, aWeekFromNow, randomTimeslot);
        String agentName = agentDetails.getSidePanelAssignedAgentName();
        agentDetails.clickAgreeAndSubmitButton();

        agentDetails.validateAppointmentRequestSubmittedLabels(fsa);
        fsa.assertEquals(agentDetails.getAppointmentRequestSubmittedAgentName(), agentName, "Agent names match");
        fsa.assertEquals(agentDetails.getAppointmentRequestSubmittedDate(), aWeekFromNowAlternate, "Appointment dates match");
        fsa.assertTrue(verifyAppointmentTimeslots(agentDetails.getAppointmentRequestSubmittedTimeslots(), randomTimeslot), "Selected timeslots check passed");
        agentDetails.clickRequestSubmittedDoneButton();
        // validate after submission and reopen prefill
        agentDetails.clickAgentContactMeButton();
        fsa.assertEquals(agentDetails.getSidePanelCustomerPhoneNumber().toLowerCase(), applicant.getPhoneNumber(), "Customer phone number is not correctly prefilled");
        fsa.assertEquals(agentDetails.getSidePanelCustomerEmailId().toLowerCase(), applicant.getEmail().toLowerCase(), "Customer email id is not correctly prefilled");
        // Validate the EmailID phone number entered in AOR is not editable
        fsa.assertFalse(agentDetails.sidePanelCustomerEmailEntryField.isEnabled(), "Side panel Customer email should not be enabled after reopen of the contact me side sheet");
        fsa.assertFalse(agentDetails.sidePanelCustomerPhoneNumberEntryField.isEnabled(), "Side panel Customer phone number should not be enabled after reopen of the contact me side sheet");
        testStep("validate after submission and reopen prefill");
        sleep(1);
        agentDetails.clickRequestSubmittedDoneButton();

        fsa.assertAll();
    }

    @Skip //retired as part of F75792
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AGENT_DETAILS})
    public void validateNoDateNoTimeSlotScenarioAndSingleOneOfThem(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant).returnToWhoShouldWeInsurePage();
        applicant.setPhoneNumber("(484)345-4344");
        AgentDetails agentDetails = new AgentDetails();

        //validate user is shown valid error when only date or time is added
        agentDetails.validateUserIsShownValidErrorWhenOnlyDateOrTimeIsAdded(applicant, fsa);
        testStep("validate user is shown valid error when only date or time is added");
        // Validate user is able to save with date and time
        // Validate only the agent name is displayed in the request submitted page if user doesn’t select the any date and time
        agentDetails.validateNoDateOrTimeSlotScenario(applicant, fsa);
        testStep("Validate user is able to save with date and time");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MA, NC, FL, WA, LA, CA, MS}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AGENT_DETAILS})
    public void validateAgentIsDisplayedInAllPages(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper(quoteFlow.AGENT).navigateToNameAndDobPage(applicant);
        testStepAssert(nameAndDobPage.isOnNameAndDobPage(), "User is on the name and dob page", true);
        nameAndDobPage.validateTFNIsNotDisplayedInAgentFlow(fsa);
        nameAndDobPage.noSaveQuoteLinkAndQuoteNumber(fsa);
        nameAndDobPage.validateAssignedAgentSection(nameAndDobPage, fsa);
        nameAndDobPage.filloutApplicantForm(applicant);

        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        testStepAssert(autoEnterAddressPage.isOnEnterAddressPage(), "User is on the address page", true);
        autoEnterAddressPage.validateAssignedAgentSection(autoEnterAddressPage, fsa);
        autoEnterAddressPage.noSaveQuoteLinkAndQuoteNumber(fsa);
        autoEnterAddressPage.fillOutAddressPage(applicant);
        InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
        if (interstitialBundlePage.isOnInterstitialBundlePage()) {
            interstitialBundlePage.continueWithAutoMonoLine();
        }

        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        boolean isStreamlineFlow = whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());

        if (!isStreamlineFlow) {
            whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.validateAssignedAgentSection(whoShouldWeInsurePage, fsa);
            testStep("validateAssignedAgentSection for " + whoShouldWeInsurePage.getClass().getSimpleName());
            whoShouldWeInsurePage.clickContinueButton();
        } else {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
            vehiclesDriversInfoPage.validateAssignedAgentSection(vehiclesDriversInfoPage, fsa);
            testStep("validateAssignedAgentSection for " + vehiclesDriversInfoPage.getClass().getSimpleName());
            vehiclesDriversInfoPage.clickContinueButton();
        }

        AgentDetails agentDetails = new AgentDetails();
        if (!agentDetails.isAgentNamePresent()) {
            testStep("Agent is not present, thus aborting this test", true);
            return;
        }
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        if (!isStreamlineFlow) {
            VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
            vehicleReviewPage.isOnVehiclesReviewPage();
            vehicleReviewPage.addVehicleDetails(applicant);
            vehicleReviewPage.validateAssignedAgentSection(vehicleReviewPage, fsa);
            testStep("validateAssignedAgentSection for " + vehicleReviewPage.getClass().getSimpleName());
            vehicleReviewPage.clickOnContinueButton();
            driverReviewPage.isOnDriverReviewPage();
            driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
            driverReviewPage.validateAssignedAgentSection(driverReviewPage, fsa);
            testStep("validateAssignedAgentSection for " + driverReviewPage.getClass().getSimpleName());
            driverReviewPage.clickContinueButton();
        }

        if (!driverReviewPage.isSignalDiscountDisabledState(applicant.getStateCode())) {
            SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
            signalPageOneUI.isOnSignalPage();
            signalPageOneUI.validateAssignedAgentSection(signalPageOneUI, fsa);
            signalPageOneUI.processSignalPage(RandomUtils.nextBoolean());
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.isOnContactInfoAutoPage();
        contactInfoAutoPage.validateAssignedAgentSection(contactInfoAutoPage, fsa);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            vehicleDriverAssignmentPage.validateAssignedAgentSection(vehicleDriverAssignmentPage, fsa);
            if (applicant.getStateCode().equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
        }

        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if (bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            bwFarmersQuotePresentmentPage.continueWithFarmers();
        }

        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is successfully on the quote page", true);
        quoteSummaryAutoPage.validateAssignedAgentSection(quoteSummaryAutoPage, fsa);
        testStep("validateAssignedAgentSection for " + quoteSummaryAutoPage.getClass().getSimpleName());
        quoteSummaryAutoPage.clickOnStartCheckoutButton();
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage();
        additionalInfoPolicyStartDateOneUI.validateAssignedAgentSection(additionalInfoPolicyStartDateOneUI, fsa);
        testStep("validateAssignedAgentSection for " + additionalInfoPolicyStartDateOneUI.getClass().getSimpleName());
        fsa.assertAll();
    }

    @Skip //retired as part of F75792
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL}), @CustomAttribute(name = FILTER, values = "applicantId=1")},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AGENT_DETAILS})
    public void validateCustomerEmailIdAndPhoneNumberIsPrefilledInContactInfoPageIfEnteredInContactAgentSection(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setPhoneNumber("(484)541-5210");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AgentDetails agentDetails = new AgentDetails();
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper(quoteFlow.AGENT).navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
        whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
        whoShouldWeInsurePage.clickAgentContactMeButton();
        int randomTimeslot = ThreadLocalRandom.current().nextInt(0, 7);
        LocalDate aWeekFromToday = LocalDate.now().plusWeeks(1);
        String aWeekFromNow = aWeekFromToday.format(DateTimeFormatter.ofPattern(MM_DD_YYYY));
        agentDetails.fillOutContactMeForm(applicant, aWeekFromNow, randomTimeslot);
        testStep("Agent contact me side sheet is filled out");
        agentDetails.clickAgreeAndSubmitButton();
        agentDetails.clickRequestSubmittedDoneButton();
        whoShouldWeInsurePage.clickContinueButton();
        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        vehicleReviewPage.isOnVehiclesReviewPage();
        vehicleReviewPage.addVehicleDetails(applicant);
        vehicleReviewPage.clickOnContinueButton();
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
        driverReviewPage.clickContinueButton();
        if (!driverReviewPage.isSignalDiscountDisabledState(applicant.getStateCode())) {
            SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
            signalPageOneUI.isOnSignalPage();
            signalPageOneUI.processSignalPage(RandomUtils.nextBoolean());
        }

        // validate provided contact info are prefilled in the contact info page
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        fsa.assertEquals(contactInfoAutoPage.getElementValue(contactInfoAutoPage.getEmailAddressInput(), "element value:"), applicant.getEmail(), "Email is prefilled on the contact info page");
        WebElement phoneNumberInput = contactInfoAutoPage.getPhoneNumberInput();
        fsa.assertEquals(contactInfoAutoPage.getElementValue(phoneNumberInput, "element value:"), applicant.getPhoneNumber(), "Phone number is prefilled on the contact info page");
        testStep("Validate if contact info details on Contact Info Page are prefilled when provided in Agent contact me section");

        // reset contact info and validate if agent contact me sections picks that info up
        String randomPhoneNumber = "(484)675-" + RandomStringUtils.randomNumeric(4);
        String randomEmail = "random_email@yopmail.com";
        contactInfoAutoPage.enterEmailId(randomEmail);
        contactInfoAutoPage.clearOutInputField(phoneNumberInput);
        contactInfoAutoPage.fillOutPhoneInputFieldOneByOne(randomPhoneNumber);
        fsa.assertEquals(contactInfoAutoPage.getElementValue(contactInfoAutoPage.getEmailAddressInput(), "element value:"), randomEmail, "Email is changed successfully on the contact info page");
        fsa.assertEquals(contactInfoAutoPage.getElementValue(phoneNumberInput, "element value:").replace(SPACE, EMPTY_STRING), randomPhoneNumber, "Phone number is changed successfull on the contact info page");
        contactInfoAutoPage.sendTab(phoneNumberInput);
        sleep(2);
        contactInfoAutoPage.fillOutPrimaryResidenceInsuranceSection(applicant.getStateCode().equals(MA));
        contactInfoAutoPage.clickContactInfoPageCTAButton();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User was able to land on the quote summary page");
        quoteSummaryAutoPage.clickAgentContactMeButton();
        fsa.assertEquals(agentDetails.getSidePanelCustomerEmailId(), randomEmail, "Email id is updated");
        fsa.assertEquals(agentDetails.getSidePanelCustomerPhoneNumber().replace(SPACE, EMPTY_STRING), randomPhoneNumber, "Phone number is updated");

        testStep("Validate that agent contact me section customer contact details are updated after changed in contact info page");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AL, FL, MI, NJ, CO, OR}), @CustomAttribute(name = FILTER, values = "applicantId=1")},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AGENT_DETAILS})
    public void validatePEWCChangesAgentSectionAtBottom(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AgentDetails agentDetails = new AgentDetails();
        new AceAutoNavigationHelper(quoteFlow.AGENT).navigateToVehicleReviewPage(applicant);
        driver().navigate().back();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        whoShouldWeInsurePage.isOnWhoShouldWeInsurePage();
        if (!agentDetails.isAgentNamePresent()) {
            testStep("Agent is not present, thus aborting this test", true);
            return;
        }
        agentDetails.validateAgentSectionAtBottom(fsa, true);
        testStep("Validate that agent contact me section customer contact details are updated after changed in contact info page");
        fsa.assertAll();
    }

    private boolean verifyAppointmentTimeslots(List<String> appointmentRequestSubmittedTimeslots, int randomTimeslot) {
        switch (randomTimeslot) {
            case 0:
                return appointmentRequestSubmittedTimeslots.contains(MORNING) && appointmentRequestSubmittedTimeslots.size() == 1;
            case 1:
                return appointmentRequestSubmittedTimeslots.contains(AFTERNOON) && appointmentRequestSubmittedTimeslots.size() == 1;
            case 2:
                return appointmentRequestSubmittedTimeslots.contains(EVENING) && appointmentRequestSubmittedTimeslots.size() == 1;
            case 3:
                return appointmentRequestSubmittedTimeslots.containsAll(Arrays.asList(MORNING, AFTERNOON)) && appointmentRequestSubmittedTimeslots.size() == 2;
            case 4:
                return appointmentRequestSubmittedTimeslots.containsAll(Arrays.asList(MORNING, EVENING)) && appointmentRequestSubmittedTimeslots.size() == 2;
            case 5:
                return appointmentRequestSubmittedTimeslots.containsAll(Arrays.asList(AFTERNOON, EVENING)) && appointmentRequestSubmittedTimeslots.size() == 2;
            case 6:
                return appointmentRequestSubmittedTimeslots.containsAll(Arrays.asList(MORNING, AFTERNOON, EVENING)) && appointmentRequestSubmittedTimeslots.size() == 3;
            default:
                throw new IllegalArgumentException("Unknown timeslot " + randomTimeslot);
        }
    }

}
