package com.farmers.ffq.auto.e2e;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class UnionPlusE2ETests2 extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES,
    		dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = {"applicantId=1"}),}, groups = {FFQ_ONEUI, QUOTE_E2E})
    public void testUnionPlusE2E(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        setApplicantPriorBiConditionRandomly(applicant);
        applicant.setTestScenario(UNIONPLUS);
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }
}
