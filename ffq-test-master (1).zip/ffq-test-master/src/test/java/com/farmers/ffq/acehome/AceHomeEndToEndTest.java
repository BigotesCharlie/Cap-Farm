package com.farmers.ffq.acehome;

import com.farmers.ffq.ace.home.AceHomeContactInfoPage;
import com.farmers.ffq.ace.home.AceHomeNavigationHelper;
import com.farmers.ffq.ace.home.AceHomeReviewQuotePage;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeEndToEndTest extends AutomationFramework {
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {})}, groups = {})
    public void testReviewQuotePagePresentmentCardHome(ApplicantAceHome applicant) throws Exception {
        applicant.setFirstName(PRODUCTION_APPLICANT_FIRST_NAME);
        applicant.setLastName(PRODUCTION_APPLICANT_LAST_NAME);
        applicant.setEmailAddress(PRODUCTION_APPLICANT_EMAIL);
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().navigateToAceHomeReviewQuotePage(applicant, LOB_HOME, HOME);

        String dwellingCoverage = reviewQuotePage.getSessionStorageAppStore().getHome().getDwellingCoverage();
        String quoteNumber = reviewQuotePage.getSessionStorageAppStore().getHome().getQuote().getQuoteNumber();

        reviewQuotePage.validatePageTitleSubtitle(fsa, CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(dwellingCoverage));
        reviewQuotePage.verifyQuotePresentmentCard(applicant.getStateCode(), fsa);
        reviewQuotePage.validateEmailThisQuoteLink(applicant, fsa);
        reviewQuotePage.validateQuoteSavedText(quoteNumber, fsa);

        fsa.assertAll("Validate Ace Home Review Quote page - Quote Presentment Card.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {ACE_HOME_SMOKE, ACE_HOME_ADA_SUITE, ADA_SUITE})
    public void testSmokeReviewQuotePagePresentmentCardHome(ApplicantAceHome applicant) throws Exception {
    	FarmersSoftAssert fsa = new FarmersSoftAssert();

        AceHRCAdditionalCoveragesBasePage additionalCoveragesPage = new AceHomeNavigationHelper().navigateToAceHomeAdditionalCoveragesPage(applicant, LOB_HOME, HOME);

        additionalCoveragesPage.validatePageTitleSubtitle(fsa);
        additionalCoveragesPage.verifyQuotePresentmentCard(fsa);
        additionalCoveragesPage.validateEmailThisQuoteLink(applicant, fsa);
        additionalCoveragesPage.validateDiscounts(ADDITIONAL_COVERAGES, applicant, HOME, fsa);

        fsa.assertAll("Smoke test - Validate Ace Home Additional coverages page - Quote Presentment Card.");
    }

    @Test(dataProvider = AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,TX})}, groups = {PRODUCTION_VALIDATION}) // FFQ_ACE_HOME
    public void testProdRetrieveRatedQuoteAceHome(ApplicantAceHome applicant) throws Exception {
        String propertyType = HOME;
        (new AceHRCBasePage()).updateApplicantForProdValidation(applicant);
        AceHRCDwellingCoverageBasePage dwellingCoveragePage = new AceHomeNavigationHelper().navigateToAceHomeDwellingCoveragePage(applicant, LOB_HOME, propertyType);
        String dwellingCoverageAmount = dwellingCoveragePage.getDwellingCoverageAmount();
        String dwellingCoverageQualityGrade = dwellingCoveragePage.getDwellingCoverageQualityGrade();
        dwellingCoveragePage.clickContinueButton();
        AceHomeReviewQuotePage reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        List<String> discountsBeforeRetrieve = reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList());

    	FarmersSoftAssert fsa = new FarmersSoftAssert();
        reviewQuotePage.validatePageLinksText(fsa, REVIEW_QUOTE);
        reviewQuotePage.validatePageLinksNavigationTitles(fsa);
        testStep("Verified quote rating and page links work on Review quote page.", true);

        // Validate quote re-rate
        reviewQuotePage.clickChangeCoverage();
        dwellingCoveragePage = new AceHRCDwellingCoverageBasePage();
        dwellingCoveragePage.changeDwellingCoverage();
        reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        String quotePrice = reviewQuotePage.getQuotePriceOnCard();
        Log.info("Default package quote premium before retrieval: " + quotePrice);
        testStep("Verified quote is rated and re-rated on Review quote page.", true);

        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);

        // Validate [Review quote] page
        reviewQuotePage = new AceHomeReviewQuotePage();
        fsa.assertTrue(reviewQuotePage.isSnackBarMessageDisplayed("Welcome back " + applicant.getFirstName()), "Welcome back snack bar message is displayed.");
        reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        testStep("Verified rated quote is retrieved on Review quote page.", true);

        fsa.assertEquals(reviewQuotePage.getQuotePriceOnCard(), quotePrice, "Review quote page - quote premium after retrieval match.");
        reviewQuotePage.verifyQuotePresentmentCard(applicant.getStateCode(), fsa);
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        fsa.assertEquals(reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList()), discountsBeforeRetrieve,
                "Review quote page - quote discounts after retrieval match.");
        reviewQuotePage.selectStepper(ENTER_INFO);  // move back to the Property details page, using stepper

        AceHRCPropertyInfoBasePage propertyInfoPage = new AceHRCPropertyInfoBasePage();
        Assert.assertTrue(propertyInfoPage.isOnPropertyInfoPage(false), "Did not reach Property info page after clicking on Enter Info stepper - " + propertyType);
        propertyInfoPage.clickContinueButton();

        // Validate [Quality grade] page
        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        if (qualityGradePage.isQualityGradePageAlone()) {
            Assert.assertTrue(qualityGradePage.isOnQualityGradePage(), "Did not reach Quality grade page.");
            qualityGradePage.validateHeaderAndSubHeaderForQualityGradePage(fsa, propertyType);
            qualityGradePage.validateAddressOnQualityGradePage(fsa, propertyType);
            qualityGradePage.verifyDisplayedFeatures(fsa, applicant);
            qualityGradePage.validateDiscounts(QUALITY_GRADE, discountsBeforeRetrieve, fsa);
            qualityGradePage.clickContinueButton();
        } else {
            // [Property details + Quality grade] page
            Assert.assertTrue(qualityGradePage.isOnPropertyDetailsQualityGradePage(true), "Did not reach Property details + Quality grade page.");
            qualityGradePage.validateHeaderForQualityGradeSection(fsa, HOME);
            qualityGradePage.validateAddressOnQualityGradeSection(fsa, HOME);
            qualityGradePage.verifyDisplayedFeatures(fsa, applicant);
        }

        // Validate [Property details] page
        AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
        Assert.assertTrue(propertyDetailsPage.isOnPropertyDetailsPage(), "Did not reach Property details page.");
        fsa.assertEquals(propertyDetailsPage.getPageTitle(), "Here's what we have so far", "Property details page title after quote retrieval.");
        propertyDetailsPage.validatePropertyDetails(applicant, propertyType, fsa);
        propertyDetailsPage.validateDiscounts(PROPERTY_DETAILS, discountsBeforeRetrieve, fsa);
        propertyDetailsPage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        propertyDetailsPage.clickContinueButton();

        // Validate [Additional info] page
        AceHRCAdditionalInfoBasePage additionalInfo = new AceHRCAdditionalInfoBasePage();
        Assert.assertTrue(additionalInfo.isOnAdditionalInfoPage(), "Did not reach Additional info page.");
        additionalInfo.validateAdditionalInfoSelections(applicant, fsa);
        additionalInfo.clickContinueButton();

        // Validate [About You] page
        if (!additionalInfo.isNewFlowEnabledState(applicant.getStateCode())) {
            AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
            Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "Did not reach About you page.");
            aboutYouPage.validateAboutYouSelections(applicant, true, fsa);
            additionalInfo.clickContinueButton();
        }

        // Validate [Contact info] page
        AceHomeContactInfoPage contactInfoPage = new AceHomeContactInfoPage();
        Assert.assertTrue(contactInfoPage.isOnContactInfoPage(true), "Did not reach Contact info page.");
        contactInfoPage.validateContactInfoSelections(applicant, true, HOME, fsa);
        contactInfoPage.clickOnAgreeAndSubmitButton();

        // Validate [Dwelling coverage] page
        AceHRCDwellingCoverageBasePage dwellingCoverageBasePage = new AceHRCDwellingCoverageBasePage();
        Assert.assertTrue(dwellingCoverageBasePage.isOnDwellingCoveragePage(), "Did not reach Dwelling coverage page.");
        fsa.assertEquals(dwellingCoveragePage.getDwellingCoverageAmount(), dwellingCoverageAmount,
                "Dwelling coverage page - dwelling coverage amount.");
        fsa.assertEquals(dwellingCoveragePage.getDwellingCoverageQualityGrade(), dwellingCoverageQualityGrade,
                "Dwelling coverage page - dwelling coverage quality grade.");
        List<String> discountsAfterRetrieve = dwellingCoveragePage.getDiscounts();
        Collections.sort(discountsAfterRetrieve);
        fsa.assertEquals(discountsAfterRetrieve, discountsBeforeRetrieve, "Dwelling coverage page - discounts.");
        fsa.assertEquals(dwellingCoveragePage.getAceQuoteNumberInThePage(), applicant.getQuoteNumber(),
                "Dwelling coverage page - dwelling coverage page quote number.");
        dwellingCoverageBasePage.clickContinueButton();

        // Validate [Review quote] page
        reviewQuotePage = new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        reviewQuotePage.verifyQuotePresentmentCard(applicant.getStateCode(), fsa);
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        reviewQuotePage.validateDiscounts(REVIEW_QUOTE, applicant, propertyType, fsa);
        testStep("Verified quote retrieval and navigation back to Enter Info and forth to Review quote page.", true);

        // Validate Bind flow
        reviewQuotePage.clickOnContinueButton();
        AceHRCAdditionalCoveragesBasePage aceHRCAdditionalCoveragesBasePage = new AceHRCAdditionalCoveragesBasePage();
        aceHRCAdditionalCoveragesBasePage.clickOnContinueButton();
        AceHRCJustAFewMoreThingsBasePage aceHRCJustAFewMoreThingsBasePage = new AceHRCJustAFewMoreThingsBasePage();
        aceHRCJustAFewMoreThingsBasePage.fillOutJustFewMoreThingsPage(applicant,true);

        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
        Assert.assertTrue(aceHRCPaymentSelectionPage.isOnPaymentPage(), "Did not reach Payment page: " + HOME);
        aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentPayInFullCard(HOME);

        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        fsa.assertTrue(aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage(), "Reached to the Payment page.");
        testStep("Verified quote bind flow up to Ace Home Payment page.", true);

        fsa.assertAll("Ace Home - Prod Retrieve rated quote.");
    }

}

