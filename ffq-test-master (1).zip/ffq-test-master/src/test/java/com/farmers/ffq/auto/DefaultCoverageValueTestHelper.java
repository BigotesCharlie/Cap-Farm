package com.farmers.ffq.auto;

import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import static com.farmers.ffq.auto.pages.DriverReviewPage.IS_A_RIDE_SHARE_XPATH;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class DefaultCoverageValueTestHelper extends AutoBasePage {

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public DefaultCoverageValueTestHelper() throws Exception {
    }

    public void testDefaultCoverages(AutoApplicant applicant, String filter, String testCategory, boolean isBW) throws Exception {
        AutoDataProviders adp = new AutoDataProviders();
        String stateCode = applicant.getStateCode();
        List<DefaultCoverages> listOfDefaultCoverages = adp.listOfCoveragesAndLiabilities(isBW ? "BW_" + stateCode : stateCode, filter + "&stateCode=" + stateCode);
        if (listOfDefaultCoverages.isEmpty()) {
            Assert.fail("No data exist for Default Coverages of " + filter);
        }
        applicant.setTestScenario(isBW ? "BW ->" + testCategory : testCategory);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        Iterator<DefaultCoverages> listOfDefaultCoveragesIterator = listOfDefaultCoverages.iterator();
        boolean isFirstTime = true;
        while (listOfDefaultCoveragesIterator.hasNext()) {
            DefaultCoverages defaultCoverageValues = listOfDefaultCoveragesIterator.next();
            if (defaultCoverageValues.getUsedForRideshare().equals(YES) && isBW) {
                continue;
            }
            String rideshareCoverage = defaultCoverageValues.getUsedForRideshare().equals(NO) ? "_NORIDE" : "_YESRIDE";
            String umbrellaCoverage = defaultCoverageValues.getUmbrella().equals(NO) ? "_NOUMB_" : "_YESUMB_";
            applicant.setTestScenario(SPACE + DEFAULT_COVERAGE_VALIDATION + SPACE + defaultCoverageValues.getOwnership().toUpperCase() + rideshareCoverage + umbrellaCoverage);
            String testScenario = applicant.getTestScenario();
            applicant.setTestScenario(isBW && !testScenario.contains("BW") ? "BW" + testScenario : testScenario);
            applicant = setTestDataForApplicant(applicant, defaultCoverageValues);
            if (defaultCoverageValues.getUmbrella().equals(YES)) {
                applicant = setUmbrellaApplicant(applicant);
            }
            QuoteSummaryAutoPage quoteSummaryAutoPage = navigateToQuoteSummaryPage(isFirstTime, applicant);
            isFirstTime = false;
            if (quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
                Log.info("Capture Quote Summary Page details" + NEWLINE, testScenario + "QuoteSummary");
                quoteSummaryAutoPage.closeQualtricsPopUp();
                quoteSummaryAutoPage.validateExpectedCoveragesAndLiabilities(defaultCoverageValues, fsa, applicant.getTestScenario());
            } else {
                Assert.fail(NEWLINE + "Did not reach Quote Summary Page" + NEWLINE);
            }
        }
        fsa.assertAll();
    }

    public void testDefaultCoverages(ADPFApplicant applicant, String filter, String testCategory, boolean isBW) throws Exception {
        AutoDataProviders adp = new AutoDataProviders();
        String stateCode = applicant.getStateCode();
        testCategory = DEFAULT_COVERAGE_VALIDATION + SPACE + testCategory;
        List<DefaultCoverages> listOfDefaultCoverages = adp.listOfCoveragesAndLiabilities(isBW ? "BW_" + stateCode : stateCode, filter + "&stateCode=" + stateCode);
        if (listOfDefaultCoverages.isEmpty()) {
            Assert.fail("No data exist for Default Coverages of " + filter);
        }

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        Iterator<DefaultCoverages> listOfDefaultCoveragesIterator = listOfDefaultCoverages.iterator();
        boolean isFirstTime = true;
        while (listOfDefaultCoveragesIterator.hasNext()) {
            String testCase = isBW ? "BW : " + testCategory : testCategory;
            DefaultCoverages defaultCoverageValues = listOfDefaultCoveragesIterator.next();
            if (defaultCoverageValues.getUsedForRideshare().equals(YES) && isBW) {
                continue;
            }
            QuoteSummaryAutoPage quoteSummaryAutoPage = navigateToQuoteSummaryPage(defaultCoverageValues, isFirstTime, applicant);
            testCase = testCase + defaultCoverageValues.getOwnership();
            isFirstTime = false;
            if (quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
                Log.info("Capture Quote Summary Page details" + NEWLINE, true);
                quoteSummaryAutoPage.validateExpectedCoveragesAndLiabilities(defaultCoverageValues, fsa, testCase);
            } else {
                Assert.fail(NEWLINE + "Did not reach Quote Summary Page" + NEWLINE);
            }
        }
        fsa.assertAll();
    }

    private AutoApplicant setUmbrellaApplicant(AutoApplicant applicant) throws Exception {
        AutoDataProviders adp = new AutoDataProviders();
        //This applicant has umbrella policy
        ApplicantWithUmbrellaPolicy applicantWithUmbrellaPolicy = adp.randomApplicantWithUmbrellaPolicy(applicant.getStateCode());
        applicant.setFirstName(applicantWithUmbrellaPolicy.getFirstName());
        applicant.setLastName(applicantWithUmbrellaPolicy.getLastName());
        applicant.setDateOfBirth(applicantWithUmbrellaPolicy.getDateOfBirth());
        applicant.setAge(LocalDate.now().getYear() - Integer.valueOf(applicantWithUmbrellaPolicy.getDateOfBirth().substring(4)));
        applicant.setResidentAddress(applicantWithUmbrellaPolicy.getResidentAddress());
        applicant.setCity(applicantWithUmbrellaPolicy.getCity());
        applicant.setZipCode(applicantWithUmbrellaPolicy.getZipCode());
        return applicant;
    }

    private AutoApplicant setTestDataForApplicant(AutoApplicant applicant, DefaultCoverages defaultCoverages) {
        switch (defaultCoverages.getCoverageAmount()) {
            case "None/Unk":
                applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
            case "PIPPD_Only":
                applicant.setCurrentBodilyInjuryLimit("No BI- PIP/PD only");
                break;
            case "10/20":
                applicant.setCurrentBodilyInjuryLimit("$10,000/$20,000");
                break;
            case "15/30":
                applicant.setCurrentBodilyInjuryLimit("$15,000/$30,000");
                break;
            case "20/40":
                applicant.setCurrentBodilyInjuryLimit("$20,000/$40,000");
                break;
            case "25/50":
                applicant.setCurrentBodilyInjuryLimit("$25,000/$50,000");
                break;
            case "25/65":
                applicant.setCurrentBodilyInjuryLimit("$25,000/$65,000");
                break;
            case "30/60":
                applicant.setCurrentBodilyInjuryLimit("$30,000/$60,000");
                break;
            case "30/65":
                applicant.setCurrentBodilyInjuryLimit("$30,000/$65,000");
                break;
            case "35/70":
                applicant.setCurrentBodilyInjuryLimit("$35,000/$70,000");
                break;
            case "35/80":
                applicant.setCurrentBodilyInjuryLimit("$35,000/$80,000");
                break;
            case "50/100":
                applicant.setCurrentBodilyInjuryLimit("$50,000/$100,000");
                break;
            case "100/200":
                applicant.setCurrentBodilyInjuryLimit("$100,000/$200,000");
                break;
            case "100/300":
                applicant.setCurrentBodilyInjuryLimit("$100,000/$300,000");
                break;
            case "150/300":
                applicant.setCurrentBodilyInjuryLimit("$150,000/$300,000");
                break;
            case "250/500":
                applicant.setCurrentBodilyInjuryLimit("$250,000/$500,000");
                break;
            case "300/300":
                applicant.setCurrentBodilyInjuryLimit("$300,000/$300,000");
                break;
            case "500/500":
                applicant.setCurrentBodilyInjuryLimit(_500K_AND_500K);
                break;
            case "500/1000":
                applicant.setCurrentBodilyInjuryLimit("$500,000/$1,000,000");
                break;
            case "1000/1000":
                applicant.setCurrentBodilyInjuryLimit("$1,000,000/$1,000,000");
                break;
            case "35":
                applicant.setCurrentBodilyInjuryLimit("$35,000");
                break;
            case "45":
                applicant.setCurrentBodilyInjuryLimit("$45,000");
                break;
            case "50":
                applicant.setCurrentBodilyInjuryLimit("$50,000");
                break;
            case "60":
                applicant.setCurrentBodilyInjuryLimit("$60,000");
                break;
            case "75":
                applicant.setCurrentBodilyInjuryLimit("$75,000");
                break;
            case "85":
                applicant.setCurrentBodilyInjuryLimit("$85,000");
                break;
            case "100":
                applicant.setCurrentBodilyInjuryLimit("$100,000");
                break;
            case "200":
                applicant.setCurrentBodilyInjuryLimit("$200,000");
                break;
            case "300":
                applicant.setCurrentBodilyInjuryLimit("$300,000");
                break;
            case "500":
                applicant.setCurrentBodilyInjuryLimit("$" + defaultCoverages.getCoverageAmount() + ",000");
                break;
            case "1000":
                applicant.setCurrentBodilyInjuryLimit("$1,000,000");
                break;
            default:
                applicant.setCurrentBodilyInjuryLimit(defaultCoverages.getCoverageAmount());
        }

        applicant.setDateOfBirth("10031980");
        applicant.setAge(LocalDate.now().getYear() - Integer.valueOf(applicant.getDateOfBirth().substring(4)));
        applicant.setCompletedDriversSafetyCourse(false);
        Iterator<Vehicle> vehiclesIterator = applicant.getVehicles().iterator();
        List<Vehicle> udpatedApplicantVehicleList = new ArrayList<>();
        while (vehiclesIterator.hasNext()) {
            Vehicle vehicleToUpdate = vehiclesIterator.next();
            vehicleToUpdate.setOwnership(defaultCoverages.getOwnership());
            if (vehicleToUpdate.getVehicleType().equals("Convertibles")) {
                vehicleToUpdate.setVehicleType("Sedan");
            }
            if (defaultCoverages.getUsedForRideshare().equals(YES)) {
                vehicleToUpdate.setVehicleUsage("Rideshare");
                vehicleToUpdate.setRidesharing(true);
            } else {
                vehicleToUpdate.setVehicleUsage("Personal");
            }
            udpatedApplicantVehicleList.add(vehicleToUpdate);
        }
        applicant.setVehicles(udpatedApplicantVehicleList);
        List<SqlIncident> noIncidents = new ArrayList<>();
        applicant.setIncidents(noIncidents);
        List<SqlAdditionalDriver> noAdditionalDrivers = new ArrayList<>();
        applicant.setAdditionalDrivers(noAdditionalDrivers);
        Iterator<SqlDiscount> discountsIterator = applicant.getDiscounts().iterator();
        List<SqlDiscount> udpatedApplicantDiscountsList = new ArrayList<>();
        while (discountsIterator.hasNext()) {
            SqlDiscount discountToUpdate = discountsIterator.next();
            discountToUpdate.setUmbrellaInsurance(defaultCoverages.getUmbrella().equals(YES));
            discountToUpdate.setSignalSignup(false);
            udpatedApplicantDiscountsList.add(discountToUpdate);
        }
        applicant.setDiscounts(udpatedApplicantDiscountsList);
        return applicant;
    }

    private QuoteSummaryAutoPage navigateToQuoteSummaryPage(boolean isFirstTime, AutoApplicant applicant) throws Exception {
        if (isFirstTime) {
            return new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        } else {
            // assumption is that we are in quote summary page, we have to go back to input the values from the updated applicant
            // then return the updated quote summary page.
            QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
            if (quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
                HeaderAndFooter pageHeaderAndFooter = new HeaderAndFooter();
                WhoShouldWeInsurePage wswiPage = pageHeaderAndFooter.selectNavigationStep(ENTER_INFO);
                wswiPage.clickOnContinueButton();
                if (wswiPage.quickIsOnWhoShouldWeInsurePage()) {
                    wswiPage.clickOnContinueButton();
                }
                VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
                if (vehiclesDriversInfoPage.isOnVehiclesDriversInfoPage()) {
                    vehiclesDriversInfoPage.clickContinueButton();
                }
                VehicleReviewPage vrPage = new VehicleReviewPage();
                if (vrPage.isOnVehiclesReviewPage()) {
                    vrPage.addVehicleDetails(applicant);
                    vrPage.clickOnContinueButton();
                }
                DriverReviewPage drp = new DriverReviewPage();
                drp.clickContinueButton();
                SignalPageOneUI sPage = new SignalPageOneUI();
                if (sPage.isOnSignalPage()) {
                    sPage.processSignalPage(false);
                    sPage.waitForSpinnerToBeGone();
                }
                ContactInfoAutoPage ciPage = new ContactInfoAutoPage();
                ciPage.fillOutPrimaryResidenceInsuranceSection(applicant.getStateCode().equals(MA));
                ciPage.clickContactInfoPageCTAButton();
                BristolWestAdditionalDiscountsPage bwAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
                if (bwAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                    quoteSummaryAutoPage = bwAdditionalDiscountsPage.clickContinue();
                }
                SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
                if (selectAQuoteToReviewPage.checkIsOnSelectAQuoteToReviewPage(true)) {
                    quoteSummaryAutoPage = selectAQuoteToReviewPage.clickContinueMyQuote();
                }

                AutoRentersBundleOfferingPage autoRentersBundleOfferingPage = new AutoRentersBundleOfferingPage();
                if (autoRentersBundleOfferingPage.isOnAutoRentersBundleOfferingPage()) {
                    autoRentersBundleOfferingPage.processRentersBundleOfferingPage(false);
                }

                quoteSummaryAutoPage.waitForPageTitleAppear();
            } else {
                Assert.fail("Was not in Quote Summary Page");
            }
            return quoteSummaryAutoPage;
        }
    }

    private QuoteSummaryAutoPage navigateToQuoteSummaryPage(DefaultCoverages defaultCoverages, boolean isFirstTime, ADPFApplicant applicant) throws Exception {
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();

        if (isFirstTime) {
            heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
            String fullName = applicant.getFirstName() + SPACE + applicant.getLastName();
            heresWhatWeFoundPage.addADPFApplicant(Optional.empty(), fullName, applicant.getGender(), applicant.getDateOfBirth());
            heresWhatWeFoundPage.clickOnDoneAddingDriversButton();
            String driverCheckboxXpath = "//mat-checkbox[contains(@id,'driver__checkbox%s')]//input";
            //uncheck only one driver
            int totalDriverCount = driver().findElements(By.xpath("//mat-checkbox[contains(@id,'driver__checkbox')]")).size();
            int tryCount = 3;
            for (int i = 2; i <= totalDriverCount; i++) {
                WebElement element = driver().findElement(By.xpath(String.format(driverCheckboxXpath, i)));

                while (isButtonSelected(element) && tryCount > 0) {
                    waitAndClickElement(element);
                    element = driver().findElement(By.xpath(String.format(driverCheckboxXpath, i)));
                    sleep(1);
                }
                tryCount--;
            }

            //check only one vehicle
            List<String> displayedCompleteVehicles = heresWhatWeFoundPage.getDisplayedCompleteVehicles();

            if (displayedCompleteVehicles.size() > 1) {
                heresWhatWeFoundPage.uncheckVehiclesOnlyForOne();
            }

            if (displayedCompleteVehicles.isEmpty()) {
                heresWhatWeFoundPage.addRandomNewVehicle(getRandomVinNumber(3));
            }

            heresWhatWeFoundPage.clickContinueButton();
        } else if (quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            HeaderAndFooter pageHeaderAndFooter = new HeaderAndFooter();
            pageHeaderAndFooter.selectNavigationStep(ENTER_INFO);
            heresWhatWeFoundPage.clickOnContinueButton();
            if (heresWhatWeFoundPage.quickIsOnWhoShouldWeInsurePage()) {
                heresWhatWeFoundPage.clickOnContinueButton();
            }
        }

        VehicleReviewPage vrPage = new VehicleReviewPage();
        if (vrPage.isOnVehiclesReviewPage()) {
            vrPage.setVehicleOwnership(defaultCoverages.getOwnership(), 1);
            vrPage.setVehicleUsagesToPersonal();
            if (defaultCoverages.getRideshareCoverage().equals(YES)) {
                vrPage.clickOnRideShareRadioButton(1);
            }
            Log.info("Capture vehicle details", true);
            vrPage.clickContinueButton();
        }

        DriverReviewPage drp = new DriverReviewPage();
        if (drp.isOnDriverReviewPage()) {
            if (isFirstTime) {
                List<String> displayedDrivers = drp.getDisplayedDrivers();
                for (String displayedDriver : displayedDrivers) {
                    drp.enterDriverLicenseAge_CA(displayedDriver, 16);
                }
                //drp.enterDriverLicenseAge_CA(applicant.getFirstName() + SPACE + applicant.getLastName(), 16);
            }
            if (defaultCoverages.getUsedForRideshare().equals(YES)) {
                WebElement isRideShareDriverCheckbox = driver().findElement(By.xpath(drp.getDriverCardXpathByFullName(applicant.getFirstName() + SPACE + applicant.getLastName())
                        + IS_A_RIDE_SHARE_XPATH + "//input"));

                if (!isRideShareDriverCheckbox.isSelected()) {
                    drp.clickIsRideShareDriverCheckbox(applicant.getFirstName() + SPACE + applicant.getLastName());
                }
            }
            drp.selectNoForCurrentOrFormerProfessionalToggle();

            Log.info("Capture driver details", true);

            drp.clickContinueButton();
        }

        SignalPageOneUI sPage = new SignalPageOneUI();
        if (!sPage.isSignalDiscountDisabledState(applicant.getStateCode()) && sPage.isOnSignalPage()) {
            sPage.processSignalPage(false);
            sPage.waitForSpinnerToBeGone();
        }
        ContactInfoAutoPage ciPage = new ContactInfoAutoPage();
        if (isFirstTime) {
            if (ciPage.isContactInfoSectionPresent()) {
                ciPage.enterEmailId("adpfApplicant_" + applicant.getHouseholdNumber() + "@farmers.testinator.com");
                ciPage.enterPhoneNumber("4848589687");
            }
        }
        ciPage.clickContactInfoPageCTAButton();
        if (quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            quoteSummaryAutoPage.waitForPageTitleAppear();
            quoteSummaryAutoPage.closeQualtricsPopUp();
            return quoteSummaryAutoPage;
        }
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            vehicleDriverAssignmentPage.processVehiclesDriversAssignmentPageIfNeeded();
        }
        BristolWestAdditionalDiscountsPage bwAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
        if (bwAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            quoteSummaryAutoPage = bwAdditionalDiscountsPage.clickContinue();
        }
        SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
        if (selectAQuoteToReviewPage.checkIsOnSelectAQuoteToReviewPage(true)) {
            quoteSummaryAutoPage = selectAQuoteToReviewPage.clickContinueMyQuote();
        }
        quoteSummaryAutoPage.waitForPageTitleAppear();
        quoteSummaryAutoPage.closeQualtricsPopUp();
        return quoteSummaryAutoPage;

    }

}
