package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.*;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoEndToEndTest extends AutomationFramework {
    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {})
    public void testReviewQuotePagePresentmentCardCondo(ApplicantAceHome applicant) throws Exception {
        applicant.setFirstName(PRODUCTION_APPLICANT_FIRST_NAME);
        applicant.setLastName(PRODUCTION_APPLICANT_LAST_NAME);
        applicant.setEmailAddress(PRODUCTION_APPLICANT_EMAIL);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceCondoReviewQuotePage reviewQuotePage = new AceCondoNavigationHelper().navigateToAceCondoReviewQuotePage(applicant);

        String personalPropertyValue = reviewQuotePage.getSessionStorageAppStore().getHome().getCoverageForPackage("C", "EFT").getCvgInfoForCvgDesc("Personal property").getCvgAmt();
        String quoteNumber = reviewQuotePage.getSessionStorageAppStore().getHome().getQuote().getQuoteNumber();
        fsa.assertEquals(reviewQuotePage.getPageSubtitle(), reviewQuotePage.getPageSubtitle(personalPropertyValue),"Property Details page - Subtitle is displayed.");

        reviewQuotePage.verifyQuotePresentmentCard(fsa);
        reviewQuotePage.validateEmailThisQuoteLink(applicant, fsa);
        reviewQuotePage.validateQuoteSavedText(quoteNumber, fsa);

        fsa.assertAll("Validate Ace Condo Review Quote page - Quote Presentment Card.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {ACE_HOME_SMOKE, ACE_CONDO_ADA_SUITE, ADA_SUITE})
    public void testSmokeReviewQuotePagePresentmentCardCondo(ApplicantAceHome applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceCondoAdditionalCoveragesPage additionalCoveragesPage = new AceCondoNavigationHelper().navigateToAceCondoAdditionalCoveragesPage(applicant);

        additionalCoveragesPage.validatePageTitleSubtitle(fsa);
        additionalCoveragesPage.verifyQuotePresentmentCard(fsa);
        additionalCoveragesPage.validateEmailThisQuoteLink(applicant, fsa);
        additionalCoveragesPage.validateDiscounts(ADDITIONAL_COVERAGES, applicant, CONDO, fsa);

        fsa.assertAll("Smoke test - Validate Ace Condo Additional coverages page - Quote Presentment Card.");
    }

    @Test(dataProvider = AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class,
            suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,TX})}, groups = {PRODUCTION_VALIDATION})
    public void testProdRetrieveRatedQuoteAceCondo(ApplicantAceHome applicant) throws Exception {
        (new AceHRCBasePage()).updateApplicantForProdValidation(applicant);
        AceCondoCustomCoveragePage customCoveragePage = new AceCondoNavigationHelper().navigateToAceCondoCustomCoveragePage(applicant);
        String personalPropertyValue = customCoveragePage.getPersonalPropertyValue();
        String buildingInteriorValue = customCoveragePage.getBuildingInteriorValue();
        customCoveragePage.clickContinueButton();

        AceCondoReviewQuotePage reviewQuotePage = new AceCondoNavigationHelper().goToAceCondoReviewQuotePage(applicant);
        List<String> discountsBeforeRetrieve = reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList());

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        reviewQuotePage.validatePageLinksText(fsa, REVIEW_QUOTE);
        reviewQuotePage.validatePageLinksNavigationTitles(fsa);
        testStep("Verified quote rating and page links work on Review quote page.", true);

        // Validate quote re-rate
        reviewQuotePage.clickChangeCoverage();
        customCoveragePage = new AceCondoCustomCoveragePage();
        customCoveragePage.changeCustomCoverage();
        reviewQuotePage = new AceCondoNavigationHelper().goToAceCondoReviewQuotePage(applicant);
        String quotePrice = reviewQuotePage.getQuotePriceOnCard();
        Log.info("Default package quote premium before retrieval: " + quotePrice);
        testStep("Verified quote is rated and re-rated on Review quote page.", true);

        new AceHRCNavigationHelperBasePage().retrieveQuoteByQuoteNumber(applicant);

        // Validate [Review quote] page
        reviewQuotePage = new AceCondoReviewQuotePage();
        fsa.assertTrue(reviewQuotePage.isSnackBarMessageDisplayed("Welcome back " + applicant.getFirstName()), "Welcome back snack bar message is displayed.");
        reviewQuotePage = new AceCondoNavigationHelper().goToAceCondoReviewQuotePage(applicant);
        testStep("Verified rated quote is retrieved on Review quote page.", true);

        fsa.assertEquals(reviewQuotePage.getQuotePriceOnCard(), quotePrice, "Review quote page - quote premium after retrieval match.");
        reviewQuotePage.verifyQuotePresentmentCard(fsa);
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        fsa.assertEquals(reviewQuotePage.getDiscounts().stream().sorted().collect(Collectors.toList()), discountsBeforeRetrieve,
                "Review quote page - quote discounts after retrieval match.");
        reviewQuotePage.selectStepper(ENTER_INFO);  // move back to the Quality page, using stepper

        // Validate [Quality grade] page
        AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
        if (qualityGradePage.isQualityGradePageAlone()) {
            Assert.assertTrue(qualityGradePage.isOnQualityGradePage(), "Did not reach Quality grade page.");
            qualityGradePage.validateHeaderAndSubHeaderForQualityGradePage(fsa, CONDO);
            qualityGradePage.validateAddressOnQualityGradePage(fsa, CONDO);
            qualityGradePage.verifyDisplayedFeatures(fsa, applicant);
            qualityGradePage.validateDiscounts(QUALITY_GRADE, discountsBeforeRetrieve, fsa);
            qualityGradePage.clickContinueButton();
        } else {
            // [Property details + Quality grade] page
            Assert.assertTrue(qualityGradePage.isOnPropertyDetailsQualityGradePage(true), "Did not reach Property details + Quality grade page.");
            qualityGradePage.validateHeaderForQualityGradeSection(fsa, CONDO);
            qualityGradePage.validateAddressOnQualityGradeSection(fsa, CONDO);
            qualityGradePage.verifyDisplayedFeatures(fsa, applicant);
        }

        // Validate [Property details] page
        AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
        Assert.assertTrue(propertyDetailsPage.isOnPropertyDetailsPage(), "Did not reach Property details page.");
        fsa.assertTrue(propertyDetailsPage.isPageTitleDisplayed(), "Property details page title is displayed.");
        propertyDetailsPage.validatePropertyDetails(applicant, CONDO, fsa);
        propertyDetailsPage.validateDiscounts(PROPERTY_DETAILS, discountsBeforeRetrieve, fsa);
        propertyDetailsPage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        propertyDetailsPage.clickContinueButton();

        // Validate [Additional info] page
        AceCondoAdditionalInfoPage additionalInfoPage = new AceCondoAdditionalInfoPage();
        Assert.assertTrue(additionalInfoPage.isOnAdditionalInfoPage(), "Did not reach Additional info page.");
        additionalInfoPage.validateAdditionalInfoSelections(applicant, fsa);
        additionalInfoPage.clickContinueButton();

        // Validate [About You] page
        if (!additionalInfoPage.isNewFlowEnabledState(applicant.getStateCode())) {
            AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
            Assert.assertTrue(aboutYouPage.isOnAboutYouPage(true), "Did not reach About you page.");
            aboutYouPage.validateAboutYouSelections(applicant, true, fsa);
            aboutYouPage.clickContinueButton();
        }

        // Validate [Contact info] page
        AceCondoContactInfoPage contactInfoPage = new AceCondoContactInfoPage();
        Assert.assertTrue(contactInfoPage.isOnContactInfoPage(true), "Did not reach Contact info page - Condo.");
        contactInfoPage.validateContactInfoSelections(applicant, true, CONDO, fsa);
        contactInfoPage.clickOnAgreeAndSubmitButton();

        // Validate [Custom coverage] page
        customCoveragePage = new AceCondoCustomCoveragePage();
        Assert.assertTrue(customCoveragePage.isOnCustomCoveragePageAceCondo(), "Did not reach Custom coverage page.");
        fsa.assertEquals(customCoveragePage.getPersonalPropertyValue(), personalPropertyValue,
                "Custom coverage page - personal property value.");
        fsa.assertEquals(customCoveragePage.getBuildingInteriorValue(), buildingInteriorValue,
                "Custom coverage page - building interior value.");
        List<String> discountsAfterRetrieve = contactInfoPage.getDiscounts();
        Collections.sort(discountsAfterRetrieve);
        fsa.assertEquals(discountsAfterRetrieve, discountsBeforeRetrieve, "Custom coverage page - discounts.");
        fsa.assertEquals(customCoveragePage.getAceQuoteNumberInThePage(), applicant.getQuoteNumber(),
                "Custom coverage page - custom coverage page quote number.");
        customCoveragePage.clickContinueButton();

        // Validate [Review quote] page
        reviewQuotePage = new AceCondoNavigationHelper().goToAceCondoReviewQuotePage(applicant);
        reviewQuotePage.verifyQuotePresentmentCard(fsa);
        reviewQuotePage.validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        reviewQuotePage.validateDiscounts(REVIEW_QUOTE, applicant, CONDO, fsa);
        testStep("Verified quote retrieval and navigation back to Enter Info and forth to Review quote page.", true);

        // Validate Bind flow
        reviewQuotePage.clickOnContinueButton();
        AceHRCAdditionalCoveragesBasePage aceHRCAdditionalCoveragesBasePage = new AceHRCAdditionalCoveragesBasePage();
        aceHRCAdditionalCoveragesBasePage.clickOnContinueButton();

        AceCondoJustAFewMoreThingsPage jFMTPageCondoLob = new AceCondoJustAFewMoreThingsPage();
        jFMTPageCondoLob.fillOutJustFewMoreThingsPageCondo(applicant, true);

        AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = new AceHRCPaymentSelectionPage();
        Assert.assertTrue(aceHRCPaymentSelectionPage.isOnPaymentPage(), "Did not reach Payment selection page: " + CONDO);
        aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentMonthlyPayCard();

        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        fsa.assertTrue(aceHRCPaymentBasePage.isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage(), "Reached to the Payment page.");
        testStep("Verified quote bind flow up to Ace Condo Payment page.", true);

        fsa.assertAll("Ace Condo - Prod Retrieve rated quote.");
    }
}
