package com.farmers.ffq.acecondo;

import com.farmers.ffq.ace.condo.AceCondoNavigationHelper;
import com.farmers.ffq.ace.condo.AceCondoPropertyDetailsPage;
import com.farmers.ffq.ace.hrc.common.AceHRCQualityGradeBasePage;
import com.farmers.ffq.dataproviders.AceHomeDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.stream.Stream;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.PROPERTY_DETAILS;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoPropertyDetailsPageValidationTest extends AutomationFramework {

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PROPERTY_DETAILS_PAGE})
    public void testPropertyDetailsPageLobCondo(ApplicantAceHome applicant) throws Exception {

        AceHRCQualityGradeBasePage qualityGradePage = new AceCondoNavigationHelper().navigateToHRCQualityGradePage(applicant,LOB_HOME, CONDO);
        if (qualityGradePage.isQualityGradePageAlone()) {
            qualityGradePage.clickContinueButton();
            qualityGradePage.waitForSpinnerToBeGone();
        }
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceCondoPropertyDetailsPage propertyDetailsPage = new AceCondoPropertyDetailsPage();
        fsa.assertTrue(propertyDetailsPage.isPageTitleDisplayed(), "Property Details page - Title is displayed");
        fsa.assertTrue(propertyDetailsPage.isPageSubtitleDisplayed(), "Property Details page - Subtitle is displayed.");

        propertyDetailsPage.validatePropertyAddress(fsa);
        propertyDetailsPage.validatePageLinksText(fsa, ENTER_INFO);

        AppStore.Home homeData = propertyDetailsPage.getSessionStorageAppStore().getHome();
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue("Year built"),
                homeData.getPropertyForm().getFields().get(0).getYearBuilt(), "Property Details page - Year built.");
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue("Total finished sq. ft").replaceAll("\\D", EMPTY_STRING),
                homeData.getPropertyForm().getFields().get(0).getSqFeet(), "Property Details page - Total finished square footage.");
        String stories = homeData.getPropertyDetailsForm().getFieldValueByName("numberOfStories");
        stories = (stories.matches("^\\d.*") ? stories.split(SPACE)[0] : stories);
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue("Stories"), stories, "Property Details page - Number of Stories.");
        String bathrooms = homeData.getPropertyDetailsForm().getFieldValueByName("numberOfBathroom");
        if (bathrooms.contains(COMMA)) {
            bathrooms = Integer.toString(Stream.of(bathrooms.split(COMMA)).map(String::strip).mapToInt(Integer::parseInt).sum());
        }
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue("Bathrooms"), bathrooms, "Property Details page - Number of Bathrooms.");
        String firePlaces = homeData.getPropertyDetailsForm().getFieldValueByName("firePlaces");
        firePlaces = (firePlaces == null) ? "None" : firePlaces;
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue("Fireplace"), firePlaces, "Property Details page - Fireplace.");
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue("Floors"),
                homeData.getPropertyDetailsForm().getFieldValueByName("floorCoverings"), "Property Details page - Floors.");
        fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue("Garage style"),
                homeData.getPropertyDetailsForm().getFieldValueByName("garageStyle"), "Property Details page - Garage style.");
        if (propertyDetailsPage.isPropertyDetailsFieldDisplayed("Garage / carport")) {
            String garageCarport = homeData.getPropertyDetailsForm().getFieldValueByName("garageCarport");
            garageCarport = (garageCarport == null) ? "---" : garageCarport;
            if (Integer.parseInt(garageCarport.substring(0,1)) > 3) {
                garageCarport = "4 or more cars";
            }
            fsa.assertEquals(propertyDetailsPage.getPropertyDetailsFieldValue("Garage / carport"), garageCarport, "Property Details page - Garage / carport.");
        }

        propertyDetailsPage.validateDiscounts(PROPERTY_DETAILS, applicant, CONDO, fsa);
        boolean quoteDisplayed = propertyDetailsPage.isNewFlowEnabledState(applicant.getStateCode());
        propertyDetailsPage.validateQuoteText(PROPERTY_DETAILS, applicant.getQuoteNumber(), fsa, quoteDisplayed);
        propertyDetailsPage.validateAgentSection(fsa, PROPERTY_DETAILS, applicant.getAgentId(), CONDO);

        fsa.assertAll("Validate Ace Condo Property Details Page.");
    }

    @Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PROPERTY_DETAILS_PAGE})
    public void testPropertyDetailsPageEditModalLobCondo(ApplicantAceHome applicant) throws Exception {
        (new AceCondoNavigationHelper()).navigateToHRCPropertyDetailsQualityGradePage(applicant,LOB_CONDO, CONDO);
        AceCondoPropertyDetailsPage propertyDetailsPage = new AceCondoPropertyDetailsPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(propertyDetailsPage.isPageTitleDisplayed(), "Property Details page - Title is displayed");
        fsa.assertTrue(propertyDetailsPage.isPageSubtitleDisplayed(), "Property Details page - Subtitle is displayed.");
        propertyDetailsPage.validatePropertyAddress(fsa);
        propertyDetailsPage.validatePageLinksText(fsa, ENTER_INFO);
        propertyDetailsPage.clickEditDetailsButton();
        AppStore.Home homeData = propertyDetailsPage.getSessionStorageAppStore().getHome();
        applicant.setYearBuilt(Integer.parseInt(homeData.getPropertyForm().getFields().get(0).getYearBuilt()));
        applicant.setSquareFeet(homeData.getPropertyForm().getFields().get(0).getSqFeet());

        fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue("Year built"),
                homeData.getPropertyForm().getFields().get(0).getYearBuilt(), "Property Details page - Edit Modal - Year built.");
        fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue("Total finished sq. ft"),
                homeData.getPropertyForm().getFields().get(0).getSqFeet(), "Property Details page - Edit Modal - Total finished square footage.");

        fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue("Stories"),
                homeData.getPropertyDetailsForm().getFieldValueByName("numberOfStories"), "Property Details page - Edit Modal - Number of Stories.");
        String bathrooms = homeData.getPropertyDetailsForm().getFieldValueByName("numberOfBathroom");
        if (bathrooms.contains(COMMA)) {
            bathrooms = Integer.toString(Stream.of(bathrooms.split(COMMA)).map(String::strip).mapToInt(Integer::parseInt).sum());
        }
        fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue("Bathrooms"), bathrooms, "Property Details page - Edit Modal - Number of Bathrooms.");
        String fireplaces = homeData.getPropertyDetailsForm().getFieldValueByName("firePlaces");
        fireplaces = (fireplaces == null) ? "None" : fireplaces;
        fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue("Fireplace"), fireplaces, "Property Details page - Edit Modal - Fireplace.");
        fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue("Floors"),
                homeData.getPropertyDetailsForm().getFieldValueByName("floorCoverings"), "Property Details page - Edit Modal - Floors.");
        String garageStyle = homeData.getPropertyDetailsForm().getFieldValueByName("garageStyle");
        fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue("Garage style"), garageStyle, "Property Details page - Edit Modal - Garage style.");
        String garageCarport = homeData.getPropertyDetailsForm().getFieldValueByName("garageCarport");
        if (propertyDetailsPage.isPropertyDetailsFieldDisplayed("Garage / carport")) {
            garageCarport = (garageCarport == null) ? EMPTY_STRING : garageCarport;
            if (Integer.parseInt(garageCarport.substring(0,1)) > 3) {
                garageCarport = "4 or more cars";
            }
            if (garageStyle.equals("No garage")) {
                fsa.assertFalse(propertyDetailsPage.isEditModalPropertyDetailsFieldDisplayed("Garage / carport"), "Property Details page - Edit Modal - Garage carport is not displayed.");
            } else {
                fsa.assertEquals(propertyDetailsPage.getEditModalPropertyDetailsFieldValue("Garage / carport"), garageCarport, "Property Details page - Edit Modal - Garage carport.");
            }
        }
        propertyDetailsPage.validateEditYearBuilt(String.valueOf(homeData.getPropertyForm().getFields().get(0).getYearBuilt()), fsa);
        propertyDetailsPage.validateEditTotalSquareFoot(homeData.getPropertyForm().getFields().get(0).getSqFeet(), fsa);
        propertyDetailsPage.validateEditNumberOfStories(homeData.getPropertyDetailsForm().getFieldValueByName("numberOfStories"), fsa);
        propertyDetailsPage.validateEditBathrooms(homeData.getPropertyDetailsForm().getFieldValueByName("numberOfBathroom"),fsa);
        propertyDetailsPage.validateEditFireplace(homeData.getPropertyDetailsForm().getFieldValueByName("firePlaces"), fsa);
        propertyDetailsPage.validateEditFloors(homeData.getPropertyDetailsForm().getFieldValueByName("floorCoverings"), fsa, applicant.getStateCode());
        propertyDetailsPage.validateEditGarageStyle(garageStyle, fsa);
        if (!garageStyle.equals("No garage")) {
            propertyDetailsPage.validateEditGarageCarport(garageCarport, fsa);
        }
        propertyDetailsPage.closeSideSheetByEscKey(fsa);
        fsa.assertAll("Validate Ace Condo Property Details page - Edit Property details modal fields.");
    }

}

