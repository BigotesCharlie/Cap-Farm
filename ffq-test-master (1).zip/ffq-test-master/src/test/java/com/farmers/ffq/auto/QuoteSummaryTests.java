package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.ace.hrc.common.AceHRCFwsInterstitialPage;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.auto.pages.bindpages.ConsolidatedPaymentPage;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;
import com.farmers.framework.Property;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import net.datafaker.Faker;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.auto.pages.VehicleReviewPage.*;
import static com.farmers.ffq.common.enums.AutoDiscounts.AUTO_BUSINESS;
import static com.farmers.ffq.common.enums.AutoDiscounts.EMPLOYMENT;
import static com.farmers.ffq.common.pages.BasePage.getFormattedForPolicyStartDate;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class QuoteSummaryTests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {WA, FL})}, groups = {QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI})
    public void testAutoQuoteSummaryLiabilityCoverageSectionContent(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant)
                // validate general page Content
                .validatePageTitle().validatePageSubTitleRegardingCustomizing()
                // open side dialog and validate Liability Coverage section on side dialog
                .validateAllLiabilityCoverageSectionContent();

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, ID, KS, ND, UT})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void testAutoQuoteSummaryLiabilityAndVehicleTable(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant)
                // validate general page Content
                .validatePageTitle().validatePageSubTitleRegardingCustomizing()
                //validate Liability Coverage Table
                .validateLiabilityCoverageTableTitle()
                //validate Vehicle Coverage Table
                .validateVehicleCoverageTableTitle();

        DefaultCoverages defaultCoverage = quoteSummaryAutoPage.getLiabilityAndVehicleCoverageDefaultCoverages(applicant);
        quoteSummaryAutoPage.validateExpectedCoveragesAndLiabilities(defaultCoverage, fsa, "testAutoQuoteSummaryLiabilityAndVehicleTable");
        fsa.assertAll();
    }

    /**
     * Validate Leased /Financed vehicle , Comp & collision Coverage is mandatory : F89263/US974547
     */

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MI}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateLeasedOrFinancedVehicleCompCollisionMandatory(AutoApplicant applicant) throws Exception {
        String vehicleOwnership = RandomUtils.nextBoolean() ? "Leased" : "Financed";
        applicant.getVehicles().forEach(each -> each.setOwnership(vehicleOwnership));
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        Log.info("Vehicle ownership is selected: " + vehicleOwnership);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnFarmers(), "User is on the quote summary page and on Farmers", true);
        quoteSummaryAutoPage.validateColAndCompMandatoryWithLeaseOrFinanceVeh(fsa);
        fsa.assertAll("Validate Leased / Financed vehicle , Comp & collision Coverage is mandatory : F89263/US974547");

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI, BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {NJ, FL, WA})})
    public void testAutoQuoteSummaryPageEmailConfirmation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper(switchTestToBDQIfNeeded(applicant) ? quoteFlow.BDQ : quoteFlow.DEFAULT).navigateToEitherQuoteSummaryPage(applicant).validatePageTitle();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(quoteSummaryAutoPage.isQuotePresentmentCardDisplayed(), "Quote presentment card is displayed");
        quoteSummaryAutoPage.clickOnEmailLink();
        fsa.assertTrue(quoteSummaryAutoPage.isEmailConfirmationDisplayed(applicant.getEmail()), " Email confirmation text displayed");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void testAutoQuoteSummaryVehicleCoverageSectionContent(AutoApplicant applicant) throws Exception {
        new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant)
                // validate general page Content
                .validatePageTitle().validatePageSubTitleRegardingCustomizing()
                // open side dialog and validate Liability Coverage section on side dialog
                .validateAllVehicleCoverageSectionContents();
    }

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_AND_VEHICLES)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void validateOrderOfVehiclesInQuoteReviewPage_ADPFDATA(ADPFApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        HeresWhatWeFoundPage heresWhatWeFoundPage = aceAutoNavigationHelper.navigateToHeresWhatWeFoundPage(applicant);
        List<String> displayedCompleteVehiclesOnHeresWhatWeFoundPage = heresWhatWeFoundPage.getDisplayedCompleteVehicles();
        testStep("List of complete vehicles captured from Here's What we found page", true);
        String fullName = applicant.getFirstName() + SPACE + applicant.getLastName();
        heresWhatWeFoundPage.addADPFApplicant(Optional.empty(), fullName, applicant.getGender(), applicant.getDateOfBirth());
        heresWhatWeFoundPage.clickContinueButton();
        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is successfully landed on the Vehicle Review page");

        List<String> displayedVehiclesOnVehiclesPage = vehicleReviewPage.getDescriptionsOfDisplayedVehicles();
        testStep("List of vehicles displayed on the Vehicles review page is captured", true);
        Log.info("List of vehicles displayed on here's what we have found page: " + displayedCompleteVehiclesOnHeresWhatWeFoundPage);
        Log.info("List of vehicles displayed on Vehicle Review page: " + displayedVehiclesOnVehiclesPage);

        testStepAssert(displayedCompleteVehiclesOnHeresWhatWeFoundPage.equals(displayedVehiclesOnVehiclesPage), "Vehicles order is matching between Here is What we found page And Vehicles Review Page", true);
        aceAutoNavigationHelper.navigateFromVehicleReviewToQuoteSummaryPage(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
        List<String> descriptionOfDisplayedVehiclesOnQuotePage = quoteSummaryAutoPage.getDescriptionOfDisplayedVehicles();
        Log.info("List of vehicles displayed on quote page: " + descriptionOfDisplayedVehiclesOnQuotePage);
        testStepAssert(descriptionOfDisplayedVehiclesOnQuotePage.equals(displayedCompleteVehiclesOnHeresWhatWeFoundPage), "Vehicles listed on the quote summary page are same and in the same order as Here's what we found page");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=9"}), @CustomAttribute(name = EXCLUDED_STATES, values = {WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})
    public void validateOrderOfVehiclesInQuoteReviewPage_Non_ADPFDATA(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.getVehicles().forEach(each -> each.setVehicleUsage(PERSONAL));
        AutoBasePage autoBasePage = aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        boolean isStreamLinedFlow = aceAutoNavigationHelper.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        List<String> displayedCompleteVehiclesOnHeresWhatWeFoundPage = new ArrayList<>();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        if (autoBasePage instanceof WhoShouldWeInsurePage) {
            if (isStreamLinedFlow) {
                VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
                vehiclesDriversInfoPage.addVehiclesWhenNoneAreFound(applicant);
                vehiclesDriversInfoPage.addDriversWhenNoneAreFound(applicant);
                displayedCompleteVehiclesOnHeresWhatWeFoundPage = vehiclesDriversInfoPage.getDisplayedVehicles();
                testStep("List of complete vehicles captured from " + vehiclesDriversInfoPage.getClass().getSimpleName() + " page", true);
                vehiclesDriversInfoPage.clickContinueButton();
                vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
            } else {
                WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
                whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
                whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
                displayedCompleteVehiclesOnHeresWhatWeFoundPage = whoShouldWeInsurePage.getDisplayedCompleteVehicles();
                testStep("List of complete vehicles captured from " + whoShouldWeInsurePage.getClass().getSimpleName() + " page", true);

                whoShouldWeInsurePage.clickContinueButton();
                VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
                testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is successfully landed on the Vehicle Review page");
                List<String> displayedVehiclesOnVehiclesPage = vehicleReviewPage.getDescriptionsOfDisplayedVehicles();
                testStep("List of vehicles displayed on the Vehicles review page is captured", true);
                testStepAssert(displayedCompleteVehiclesOnHeresWhatWeFoundPage.equals(displayedVehiclesOnVehiclesPage), "Vehicles order is matching between Here is Who Should We Insure page And Vehicles Review Page", true);
                aceAutoNavigationHelper.setResumeFromPage(vehicleReviewPage.getClass().getSimpleName());
                aceAutoNavigationHelper.navigateToQuoteSummaryAutoPage(applicant);
            }
        }

        List<String> descriptionOfDisplayedVehiclesOnQuotePage = quoteSummaryAutoPage.getDescriptionOfDisplayedVehicles();
        testStep("List of vehicles displayed on quote page: " + descriptionOfDisplayedVehiclesOnQuotePage);
        testStepAssert(descriptionOfDisplayedVehiclesOnQuotePage.equals(displayedCompleteVehiclesOnHeresWhatWeFoundPage), "Vehicles listed on the quote summary page are same and in the same order as Who Should we Insure page");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void testDiscountRulesAndDiscountCountOnQuoteSummaryCard(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        if(!quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            testStepAssertTrue(true, "Quote summary page is not displayed for the given applicant. Skipping the test as discount validation is not applicable.");
            return;
        }
        // Retrieve Expected discounts from local storage
        List<String> expectedDiscounts = new ArrayList<>();
        AppStore.Auto.Quote quote = quoteSummaryAutoPage.getSessionStorageAppStore().getAuto().getQuote();
        try {
            expectedDiscounts = quote.getEft().getRateQuoteResponse().getPersAutoPolicy().getDiscount().stream().map(AppStore.Auto.Quote.Discount::getName).collect(Collectors.toList());
        } catch (Exception e) {
            expectedDiscounts = quote.getPif().getRateQuoteResponse().getPersAutoPolicy().getDiscount().stream().map(AppStore.Auto.Quote.Discount::getName).collect(Collectors.toList());
        }
        List<String> actualDiscounts = quoteSummaryAutoPage.getDisplayedDiscounts();
        Collections.sort(actualDiscounts);
        Collections.sort(expectedDiscounts);
        testStepAssert(expectedDiscounts.size() == actualDiscounts.size(), "Discount count is matching. ActualDiscounts:  " + actualDiscounts + ". Expected discounts: " + expectedDiscounts);
        testStepAssert(actualDiscounts.toString(), expectedDiscounts.toString(), "Discounts are matching ");
        quoteSummaryAutoPage.validateDiscountCountOrTotalDiscountOnTheQuoteSummaryCart(applicant);

    }

    @Skip //Keeping this test case in case needed for future
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MA, NC, NV, MS, KY, LA, OR, FL, MT, CA, CT, AL, AZ, IL, OK}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateVehicleReplacementPlusCoverage_US819667(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.getVehicles().forEach(each -> {
            each.setOwnership("Owned");
            // each.setVehicleYear(String.valueOf(DateTime.now().getYear() - 17));
        });
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        quoteSummaryAutoPage.validateVehicleReplacementPlusCoverage_US819667(applicant, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA})})
    public void testIfLiabilityAndVehicleCoverageQuotePriceGeneratedRealistic(AutoApplicant applicant) throws Exception {

        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setTestScenario(SPECIAL_BI_LIMIT_IS_NEEDED + SPACE + applicant.getTestScenario());
        // update vehicles to get comp and coll by default
        applicant.getVehicles().forEach(vehicle -> vehicle.setOwnership("Financed"));
        // Navigate to Quote Summary Auto Page
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote Summary Page has been reached");
        // Get and check the Total Liability Coverage price
        double liabilityPriceValue = quoteSummaryAutoPage.getTotalLiabilityCoveragePrice();
        testStepAssert(liabilityPriceValue >= 20.00 && liabilityPriceValue <= 1000.00, "Liability Coverage price is not within the expected range.");

        // Get and check the Total Vehicle Coverage price
        double vehiclePriceValue = quoteSummaryAutoPage.getTotalVehicleCoveragePrice();
        testStepAssert(vehiclePriceValue >= 20.00 && vehiclePriceValue <= 1000.00, "Vehicle Coverage price is not within the expected range.");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, MS}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void testInfoPersistenceOnNavigationAndRefresh(AutoApplicant applicant) throws Exception {
        Log.info("Starting test to validate info persistence on navigation and refresh.");
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.getVehicles().forEach(vehicle -> vehicle.setVehicleUsage("Personal"));
        // Navigate to the Quote Summary page and update some information
        AdditionalInfoPolicyStartDateOneUI additionalInformationPage = new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        testStepAssert(additionalInformationPage.isOnAdditionalInfoPage(), "Additional Info page has been reached");
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        quoteSummaryAutoPage.goToQuoteSummaryAutoPageByClickingBrowserBackButton();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote summary page has been reached after clicking navigating back from Additional info page");

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        // verify if page content retained
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on Quote Summary Auto Page.");
        fsa.assertTrue(quoteSummaryAutoPage.isQuotePresentmentCardDisplayed(), "Quote Presentment card is displayed.");

        DefaultCoverages defaultCoverage = quoteSummaryAutoPage.getLiabilityAndVehicleCoverageDefaultCoverages(applicant);
        quoteSummaryAutoPage.validateExpectedCoveragesAndLiabilities(defaultCoverage, fsa, "testAutoQuoteSummaryLiabilityAndVehicleTable");

        quoteSummaryAutoPage.refreshThePage();

        // verify if page content retained
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on Quote Summary Auto Page after page refresh.");
        testStepAssert(quoteSummaryAutoPage.isQuotePresentmentCardDisplayed(), "Quote Presentment card is displayed after refresh.");
        quoteSummaryAutoPage.validateExpectedCoveragesAndLiabilities(defaultCoverage, fsa, "testAutoQuoteSummaryLiabilityAndVehicleTable");
        fsa.assertAll();

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, NC})}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void testLiabilityAndVehicleCoverageSelectedByDefault(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        quoteSummaryAutoPage.areLiabilityCoverageLimitsSelectedByDefault();
        quoteSummaryAutoPage.areVehicleCoverageLimitsSelectedByDefault();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL,NC})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void testMultipleReRatingPremiumAndCoverageDisplay(AutoApplicant applicant) throws Exception {
        Log.info("Starting test to verify premium, discounts, and coverages display on multiple re-rating.");
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateApplicantDataToAvoidPossibleBw(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Auto Quote Summary page has been reached");
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();

        if (quoteSummaryAutoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            testStepAssert(vehiclesDriversInfoPage.isOnVehiclesDriversInfoPage(), "vehiclesDriversInfoPage page is reached after clicking Enter Info navigation bar stepper");
            vehiclesDriversInfoPage.updateUsCALicensedStatus(applicant.getFirstName() + SPACE + applicant.getLastName(), applicant.getFirstAgeForeignDriverLicense() == 18);
            vehiclesDriversInfoPage.clickContinueButton();
        } else {
            WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
            testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "Enter info navigation bar is clicked, and user landed on the Who Should we Insure page");
            whoShouldWeInsurePage.clickEditButtonWithDriverFullName(String.join(SPACE, applicant.getFirstName(), applicant.getLastName()));
            whoShouldWeInsurePage.selectUsOrCanadaLicensedRadioButton(applicant.getFirstAgeForeignDriverLicense() == 18 ? NO : YES);
            whoShouldWeInsurePage.clickOnSaveButton();
            whoShouldWeInsurePage.clickOnContinueButton();
        }

        new VehicleReviewPage().clickOnContinueButton();
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        String applicantFullName = driverReviewPage.getApplicantFullName(applicant);
        driverReviewPage.enterDriverLicenseAge(applicant, applicantFullName, applicant.getFirstAgeUnitedStatesDriverLicense());
        driverReviewPage.enterDriverLicenseAge_CA(applicantFullName, 16);
        driverReviewPage.addDriverLicenseNumber(applicant, applicantFullName);
        for (SqlAdditionalDriver additionalDriver : applicant.getAdditionalDrivers()) {
            String fullNameAdditionaDriver = additionalDriver.getFirstName() + SPACE + additionalDriver.getLastName();
            driverReviewPage.enterDriverLicenseAge(applicant, fullNameAdditionaDriver, additionalDriver.getFirstAgeUnitedStatesDriverLicense());
            driverReviewPage.addDriverLicenseNumber(applicant, fullNameAdditionaDriver);
        }

        driverReviewPage.clickContinueButton();
        if (!driverReviewPage.isSignalDiscountDisabledState(applicant.getStateCode())) {
            new SignalPageOneUI().processSignalPage(false);
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.fillOutPrimaryResidenceInsuranceSection(applicant.getStateCode().equals(MA));
        contactInfoAutoPage.clickContactInfoPageCTAButton();
        if (!quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
            if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
            SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
            if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
                selectAQuoteToReviewPage.clickContinueMyQuote();
            }
        }

        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote page after rerate");

        // premiumAmount is only visible when PerformRateQuote API is successful
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        String premiumAmount = quoteSummaryAutoPage.getPresentedPremiumAmount();
        if (quoteSummaryAutoPage.getSessionStorageAppStore().getAuto().getQuote().getPaymentMode().equals("PIF")) {
            //TODO: add later the format for PIF
        } else {
            fsa.assertTrue(premiumAmount.startsWith("$") && premiumAmount.endsWith("/mo"), "Premium amount formatted corectly.");
        }

        // verify if page content retained
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on Quote Summary Auto Page.");
        fsa.assertTrue(quoteSummaryAutoPage.isQuotePresentmentCardDisplayed(), "Quote Presentment card is displayed.");

        DefaultCoverages defaultCoverage = quoteSummaryAutoPage.getLiabilityAndVehicleCoverageDefaultCoverages(applicant);
        quoteSummaryAutoPage.validateExpectedCoveragesAndLiabilities(defaultCoverage, fsa, "testAutoQuoteSummaryLiabilityAndVehicleTable");

        // Alternative Payment Link is only clickable when second PerformRateQuote API is called
        quoteSummaryAutoPage.clickOnAlternativePaymentLink();
        quoteSummaryAutoPage.waitForSpinnerToBeGone();
        sleep(1);
        // Retrieve and check the response status of PerformRate API
        List<String> expectedDiscounts = quoteSummaryAutoPage.getSessionStorageAppStore().getAuto().getQuote().getPif().getRateQuoteResponse().getPersAutoPolicy().getDiscount().stream().map(AppStore.Auto.Quote.Discount::getName).collect(Collectors.toList());
        List<String> displayedDiscounts = quoteSummaryAutoPage.getDisplayedDiscounts();
        Collections.sort(expectedDiscounts);
        Collections.sort(displayedDiscounts);
        fsa.assertEquals(displayedDiscounts, expectedDiscounts, "Discounts verification");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {LA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})
    public void testPerformRateQuoteAPI(AutoApplicant applicant) throws Exception {
        Log.info("Starting test to verify PerformRate Quote API.");
        updateApplicantDataToAvoidPossibleBw(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote summary page is reached");

        // premiumAmount is only visible when PerformRateQuote API is successful
        String premiumAmount = quoteSummaryAutoPage.getPresentedPremiumAmount();
        testStepAssert(premiumAmount.startsWith("$") && applicant.getStateCode().equals(LA) || premiumAmount.endsWith("/mo"), "Premium amount format is incorrect.");

        // Alternative Payment Link is only clickable when second PerformRateQuote API is called
        quoteSummaryAutoPage.clickOnAlternativePaymentLink();

        // Retrieve and check the response status of PerformRate API
        String responseStatusOfPerformRateApi = quoteSummaryAutoPage.getSessionStorageAppStore().getServiceControlData().getPerformRate();
        testStepAssert(responseStatusOfPerformRateApi, "success", "PerformRate API did not return success status.");

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateCAQuotesOnlyOfferPayInFullAndMonthlyAmount(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Navigate to Quote summary page");
        testStepAssertTrue(quoteSummaryAutoPage.isAmountPresentedAsAMonthlyValue(), "Premium amount is presented in a monthly value.");
        // as part of the following US, now we are expecting Monthly pay option: US818100
        testStepAssertTrue(quoteSummaryAutoPage.isMonthlyOrFullPriceToggleLinkVisible(), "Link to toggle Monthly to Full price is present.");
        testStep("End of Test");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void testSignalDiscountIsGiven(AutoApplicant applicant) throws Exception {
        applicant.getVehicles().forEach(vehicle -> vehicle.setUseVIN(true));
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        List<SqlDiscount> listOfDiscounts = applicant.getDiscounts();
        SqlDiscount discounts = listOfDiscounts.get(0);
        discounts.setSignalSignup(true);
        listOfDiscounts.add(discounts);
        applicant.setDiscounts(listOfDiscounts);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        boolean isDiscountAvailableForState = true;
        if (aceAutoNavigationHelper.isSignalDiscountDisabledState(applicant.getStateCode())) {
            Log.info("Signal discount is not available for the given state -> " + applicant.getStateCode());
            isDiscountAvailableForState = false;
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToQuoteSummaryAutoPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote Summary Page has been reached");
        String modifier = isDiscountAvailableForState ? SPACE : " not ";

        testStepAssert(isDiscountAvailableForState == quoteSummaryAutoPage.isDiscountPresentInTheSideSheet("Signal"), "Signal discount" + modifier + "displayed in discount section");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {AL, AK, CA, CT, DC, DE, FL, HI, ME, MT, NH, NJ, NY, OH, RI, SC, VT, WV})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void testSignalDiscountIsNotGiven(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        List<SqlDiscount> listOfDiscounts = applicant.getDiscounts();
        SqlDiscount discounts = listOfDiscounts.get(0);
        discounts.setSignalSignup(false);
        listOfDiscounts.add(discounts);
        applicant.setDiscounts(listOfDiscounts);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote Summary Page has been reached");
        testStepAssert(!quoteSummaryAutoPage.isDiscountPresentInTheSideSheet("Signal"), "Signal discount not displayed in discount section");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {WA, FL, CA})}, dataProviderClass = AutoDataProviders.class, groups = {QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI})
    public void testQuoteSummaryAutoPageFullPriceAndMonthlyPrice(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant).validatePageTitle();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        double monthlyTotalPremium = Double.parseDouble(quoteSummaryAutoPage.getFullMonthlyPayAmount());
        double pifTotalPremium = Double.parseDouble(quoteSummaryAutoPage.getPifFullAmount());

        Log.info("Monthly total premium: " + monthlyTotalPremium);
        Log.info("Pif total premium: " + pifTotalPremium);
        fsa.assertTrue(monthlyTotalPremium > pifTotalPremium, "Monthly total price should be higher than the pif total price");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI})
    public void testQuoteSummaryAutoPageRecalculateLiabilityCoveragePrice(AutoApplicant applicant) throws Exception {

        updateApplicantDataToAvoidPossibleBw(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant).validatePageTitle();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(quoteSummaryAutoPage.validateRecalculationOfLiabilityCoveragePriceWithNewSelection(), "Recalculate liability coverage price");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, groups = {QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI})
    public void testQuoteSummaryAutoPageRecalculateVehicleCoveragePrice(AutoApplicant applicant) throws Exception {

        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant).validatePageTitle();

        FarmersSoftAssert fsa = new FarmersSoftAssert();

        DefaultCoverages defaultCoverage = quoteSummaryAutoPage.getLiabilityAndVehicleCoverageDefaultCoverages(applicant);
        quoteSummaryAutoPage.validateExpectedCoveragesAndLiabilities(defaultCoverage, fsa, "testAutoQuoteSummaryLiabilityAndVehicleTable");

        fsa.assertTrue(quoteSummaryAutoPage.validateRecalculationOfVehicleCoveragePriceWithNewSelection(), "Recalculate vehicle coverage price");

        // premiumAmount is only visible when PerformRateQuote API is successful
        String premiumAmount = quoteSummaryAutoPage.getPresentedPremiumAmount();
        testStepAssert(premiumAmount.startsWith("$") && premiumAmount.endsWith("/mo"), "Premium amount format is correct.");

        // verify if page content retained
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on Quote Summary Auto Page.");
        fsa.assertTrue(quoteSummaryAutoPage.isQuotePresentmentCardDisplayed(), "Quote Presentment card is displayed.");

        // Retrieve and check the response status of PerformRate API
        List<String> expectedDiscounts = quoteSummaryAutoPage.getSessionStorageAppStore().getAuto().getQuote().getEft().getRateQuoteResponse().getPersAutoPolicy().getDiscount().stream().map(AppStore.Auto.Quote.Discount::getName).collect(Collectors.toList());
        Collections.sort(expectedDiscounts);
        List<String> actualDiscounts = quoteSummaryAutoPage.getDisplayedDiscounts();
        fsa.assertEquals(expectedDiscounts, actualDiscounts, "Discounts are not matching");
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void testStartCheckoutButtonRedirectsToJustFewMoreThings(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        if (applicant.getStateCode().equals(WA)) {
            applicant.setLastName("Wilson");
        }
        Log.info("Starting test to verify if clicking 'Start checkout' button redirects to 'Just few more things' screen.");

        // Navigate to the Quote Summary Auto Page
        AdditionalInfoPolicyStartDateOneUI additionalInformationPage = new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);

        testStepAssert(additionalInformationPage.isOnAdditionalInfoPage(), "User is not redirected to 'Just few more things' screen after clicking 'Start checkout' button.");

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {WA, MA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void testTotalSumOfLiabilityVehicleCoverageQuoteSum(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        Log.info("Starting test to verify if Liability and Vehicle Coverage quote prices sum is correct.");
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        // Compare the rounded values directly
        testStepAssert(quoteSummaryAutoPage.isRoundedPresentedPremiumSumOfLiabilityAndVehicleCoveragePremium(), "Premium amount mismatch.");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})
    public void validateQuoteFlowWithEmploymentNotSelected(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setOccupation(StringUtils.EMPTY);
        applicant.getAdditionalDrivers().forEach(each -> each.setOccupation(StringUtils.EMPTY));
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        List<String> discountNames = quoteSummaryAutoPage.getDisplayedDiscounts();
        testStepAssert(!quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(EMPLOYMENT.getName()), "Discounts should not include " + EMPLOYMENT.getName() + ", as the employement is not selected. Included discounts ==> " + discountNames);
    }

    // removing streamline states from this test as driver review pages are not available in streamline flow along with FL, KY, LA, MA, MS, NC
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}),
            @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA, FL, KY, LA, MA, MS, NC})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})
    public void validateQuoteFlowWithEmploymentSelected(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        String stateCode = applicant.getStateCode();
        boolean occupationDiscountIsSelected = true;

        applicant.setOccupation(occupationDiscountIsSelected ? "Accountant" : EMPTY_STRING);

        for (SqlAdditionalDriver additionalDriver : applicant.getAdditionalDrivers()) {
            additionalDriver.setOccupation(occupationDiscountIsSelected ? "Educator" : EMPTY_STRING);
        }

        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        DriverReviewPage driverReviewPage = aceAutoNavigationHelper.navigateToDriverReviewPage(applicant);
        AppStore.Auto.Dropdowns.Driver.DropDownResponseBean.DropDownValue occupation = driverReviewPage.getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("occupation")).findFirst().get().getDropDownValues().stream().collect(Collectors.toList()).stream().findFirst().get();
        if (occupation.getParentValue() != null && occupation.getParentValue().equals("Military Personnel")) {
            applicant.setOccupation("Military Personnel");
        } else {
            applicant.setOccupation(occupation.getWebDesc());
        }

        testStepAssert(driverReviewPage.isOnDriverReviewPage(), "User landed on the Driver Review Page");
        if (DriverReviewPage.isEmploymentDisabledState(stateCode)) {
            testStepAssert(driver().findElements(driverReviewPage.seeEligibleOccupationList).isEmpty(), "See eligible occupation should not be visible for the given state: " + stateCode);
            testStep(TEST_PASSED);
            return;
        }
        driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
        driverReviewPage.clickContinueButton();
        driverReviewPage.proceedToQuoteSummaryPage(applicant);

        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User has reached quoteSummaryAutoPage " + quoteSummaryAutoPage.getClass().getSimpleName());

        List<String> discountNames = quoteSummaryAutoPage.getDisplayedDiscounts();

        String modifier = occupationDiscountIsSelected ? SPACE : "not";
        testStepAssert(quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(EMPLOYMENT.getName()) == occupationDiscountIsSelected, "Discounts should " + modifier + " include " + EMPLOYMENT.getName() + ", as eligible profession was " + modifier + " selected on the Driver Review page. Included discounts ==> " + discountNames);

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateDiscountsAndCoveragesPersistViaForthAndBack(AutoApplicant applicant) throws Exception {
        testStep("#86: Validate if same premium, disocunts, coverages are displaying in Quote screen when user navigates past quote screen (to bind flow) but navigates back to Review quote screen via browser back arrow or stepper.");
        updateApplicantDataToAvoidPossibleBw(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        new QuoteSummaryAutoPage().validateDiscountAndCoveragePersistAfterForthBack(applicant, fsa);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CA, TX})}, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateBackAndForthNavigationAndRerate(AutoApplicant applicant) throws Exception {
        testStep("Start navigation test");
        updateApplicantDataToAvoidPossibleBw(applicant);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if (aceAutoNavigationHelper.isProdEnvironment()) {
            updatePersonalInfoForProd(applicant);
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page successfully", true);
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the who should we insure page after clicking Info navbar on the quote summary page", true);
        whoShouldWeInsurePage.clickReviewQuoteNavigationBarStepper();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page successfully after clicking review quote navbar from who should we insure page", true);
        quoteSummaryAutoPage.clickOnStartCheckoutButton();
        AdditionalInfoPolicyStartDateOneUI additionalInformationPage = new AdditionalInfoPolicyStartDateOneUI();
        testStepAssert(additionalInformationPage.isOnAdditionalInfoPage(), "User is on the additional info page after clicking Start checkout", true);
        additionalInformationPage.fillOutAdditionalInfoPage(false);
        additionalInformationPage.clickReviewQuoteNavigationBarStepper();

        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page after clicking review quote stepper from JAFMT page", true);
        quoteSummaryAutoPage.clickPurchaseNavigationBarStepper();
        testStepAssert(additionalInformationPage.isOnAdditionalInfoPage(), "User is on the JAFMT page after clicking Purchase stepper from Quote page", true);
        additionalInformationPage.clickEnterInfoNavigationBarStepper();
        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the Who Should We Insure page after clicking Enter info stepper from JAFMT page", true);

        testStep("Add a new vehicle and rerate the quote");

        boolean streamLineFlow = whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        if (streamLineFlow) {
            new VehiclesDriversInfoPage().addRandomNewVehicle();
        } else {
            whoShouldWeInsurePage.addRandomAdditionalVehicle();
        }
        testStep("new vehicle added", true);

        whoShouldWeInsurePage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();

        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote page after rerate with new vehicle", true);

        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();

        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is back on the who should we insure page after clicking enter info navbar", true);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, TX})}, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})
    public void validateQuoteCustomization(AutoApplicant applicant) throws Exception {
        testStep("Start navigation test");
        updateApplicantDataToAvoidPossibleBw(applicant);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if (aceAutoNavigationHelper.isProdEnvironment()) {
            updatePersonalInfoForProd(applicant);
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page successfully", true);
        quoteSummaryAutoPage.updateLiabilityAndCustomize();
        quoteSummaryAutoPage.updateVehicleCoverageAndCustomize();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})
    public void validateCustomizationAfterRetrieval(AutoApplicant applicant) throws Exception {
        testStep("94 - Validate user able to customize the coverage after retrieval");
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.getVehicles().forEach(each -> each.setOwnership("Owned"));
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page successfully", true);
        //wait 10 seconds and then retrieve
        sleep(10);
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, quoteSummaryAutoPage.getSessionStorageAppStore().getData().getQuoteNumber());
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page successfully after retrieval", true);
        // customize the quote after retrieval
        quoteSummaryAutoPage.updateVehicleCoverageAndCustomize();

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=6"}), @CustomAttribute(name = VA)}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})
    public void testValidateSafeDriverDiscountForVAState_QuoteSummaryTests(AutoApplicant applicant) throws Exception {
        // ride share is true for this applicant so to avoid KO, setting rideshare as false
        // applicant has to be at least 23 years old to get the safe driver discount
        applicant.getVehicles().forEach(i -> i.setRidesharing(false));
        applicant.setAge(23);
        applicant.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(23));

        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        testStepAssertFalse(quoteSummaryAutoPage.isDiscountPresentInTheSideSheet("Safe driver"), "Safe driver discount should not be displayed in quote page");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA}), @CustomAttribute(name = FILTER, values = "applicantId=9")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateMultipleVehicleWithSameYMMScenario(AutoApplicant applicant) throws Exception {

        testStep("Auto - Validate multiple vehicles scenario with same YEAR, MAKE & MODEL");
        applicant.getVehicles().forEach(each -> {
            each.setUseVIN(false);
            each.setVehicleYear("2023");
            each.setVehicleMake("HONDA");
            each.setVehicleModel("ACCORD 4D");
            each.setVehicleType("Sedan");
            each.setParkInResidentAddress(true);
        });
        updateApplicantDataToAvoidPossibleBw(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page", true);
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, NJ, CT, MT, AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA}), @CustomAttribute(name = FILTER, values = "applicantId=10")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateDiscountsE2E(AutoApplicant applicant) throws Exception {

        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setFirstName(new Faker().name().firstName());
        //applicant.setLastName("Brown");

        // update applicant age and DoB
        applicant.setAge(56);
        applicant.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(56));

        //Limit the vehicle count to 2
        List<Vehicle> vehicles = applicant.getVehicles();
        Collections.shuffle(vehicles);
        applicant.setVehicles(Arrays.asList(vehicles.get(0), vehicles.get(1)));

        applicant.getVehicles().forEach(each -> {
            each.setVehicleYear("2025");
            each.setVehicleMake("HONDA");
            each.setVehicleModel("CIVIC 4D EX");
            each.setVehicleType("Sedan");
            each.setUseVIN(false);
        });

        // have only one additional driver with young age 22
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        SqlAdditionalDriver youngDriver = additionalDrivers.stream().filter(each -> each.getAge() < 25).collect(Collectors.toList()).stream().findFirst().get();

        applicant.setAdditionalDrivers(Arrays.asList(youngDriver));

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        new QuoteSummaryAutoPage().validateDiscountsE2E(applicant, fsa);
        fsa.assertAll();

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MN, WA, OH, MD, IA, IN, MT, KS, NV, FL, NJ, LA, MS, MA, NC, KY}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateBusinessDiscount(AutoApplicant applicant) throws Exception {
        applicant.getVehicles().forEach(each -> each.setUseVIN(true));
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setFirstName(new Faker().name().firstName());
        updatePersonalInfoForProd(applicant);
        SqlDiscount sqlDiscount = applicant.getDiscounts().get(0);
        sqlDiscount.setBusinessInsurance(true);
        sqlDiscount.setCondoInsurance(false);
        sqlDiscount.setValueTermLifeInsurance(false);
        sqlDiscount.setMotorcycleInsurance(false);
        sqlDiscount.setRecreationalBoatWatercraftInsurance(false);
        sqlDiscount.setRentersInsurance(false);
        sqlDiscount.setUmbrellaInsurance(false);

        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        List<String> displayedDiscounts = quoteSummaryAutoPage.getDisplayedDiscounts();

        farmersSoftAssert.assertTrue(displayedDiscounts.contains(AUTO_BUSINESS.getName()), "Business discount should be displayed when business insurance discount is true in DB. Displayed discounts: " + displayedDiscounts);

        farmersSoftAssert.assertAll();

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=34")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateRideShareCoverage_CA_State(AutoApplicant applicant) throws Exception {
        boolean randomRideShare = RandomUtils.nextBoolean();
        if (randomRideShare) {
            applicant.getVehicles().forEach(each -> each.setRidesharing(true));
        }
        VehicleReviewPage vehicleReviewPage = new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant);
        testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on the Vehicles review page", true);
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        Log.info("Vehicle is set to ride share : " + randomRideShare);
        if (randomRideShare) {
            vehicleReviewPage.clickOnRideshareCheckbox_VehicleReviewPage(1);
            vehicleReviewPage.validateRideShareCard(fsa, 1);
        } else {
            fsa.assertTrue(driver().findElements(By.xpath("//div[@id='vehicleSection1']//div[contains(@class,'rideShareCard')]")).isEmpty(), "If ridesahre not selected we don't show this rideshare info section");
        }
        vehicleReviewPage.clickOnContinueButton();
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        testStepAssert(driverReviewPage.isOnDriverReviewPage(), "User is on the driver review page", true);
        driverReviewPage.validateIsRideShareDriverCheckbox(fsa, randomRideShare);
        driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
        driverReviewPage.clickContinueButton();
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.setValuesAndContinue(applicant);
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the Quote Summary Page", true);
        quoteSummaryAutoPage.validateRideShareCoverage_CA_State(fsa, randomRideShare);
        fsa.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX, PA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateUMBILimitDontExceedBiLimitFarmers(AutoApplicant applicant) throws Exception {
        // Exclude FL and NM (UMBI not applicable)
        updateApplicantDataToAvoidPossibleBw(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnFarmers(), "User is on the quote summary page", true);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        quoteSummaryAutoPage.validateUMBILimitDontExceedBiLimitFarmers(fsa);
        fsa.assertAll();
    }

    /*
        BW: Validate UMBI limit cannot be higher than the BI limit on quote review screen.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})
    public void validateUMBILimitDontExceedBiLimitBW(AutoApplicant applicant) throws Exception {
        // Exclude FL and NM (UMBI not applicable)
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the quote summary page", true);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        quoteSummaryAutoPage.validateUMBILimitDontExceedBiLimitBW(fsa);
        fsa.assertAll();
    }

    /*
        BW: "Validate for Prior insurance - When user customize the coverages or lowerdown the coverages then Verify should be success without any error
Steps to reproduce:

A user selects Prior Insurance and chooses ""Bodily Injury (BI) limits $250,000/$500,000""
On Quote Presentment page attempts to reduce BI/UIM limits and clicks the ""Recalculate"" button."
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, NM, WI}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})
    public void validateUserCanReduceBI(AutoApplicant applicant) throws Exception {
        // Exclude FL and NM (UMBI not applicable)
        bwSpecificDataSetUp(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.setContinuosInsurancePeriod("< 6 Months");
        applicant.setTestScenario(SPECIAL_BI_LIMIT_IS_NEEDED);
        applicant.setCurrentBodilyInjuryLimit(_250K_AND_500K);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the quote summary page", true);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        quoteSummaryAutoPage.validateUserCanSelectLowerBILimit(fsa);
        fsa.assertAll();
    }

    /*
     *Validate comprehensive coverage is required when Limited collision is select on Quote review screen.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})
    public void validateCompIsRequiredWithLimitedColl(AutoApplicant applicant) throws Exception {

        // Exclude FL and NM (UMBI not applicable)
        bwSpecificDataSetUp(applicant);
        applicant.getVehicles().get(0).setOwnership("Owned");
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper(quoteFlow.DEFAULT).navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the quote summary page", true);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        quoteSummaryAutoPage.validateCompIsRequiredWithLimitedColl(fsa);
        fsa.assertAll();
    }

    /*
     * Validate the Bristol West promo card section on the review-quote page.
     * Validates: BW logo, info icon accessibility, promo header, content text,
     * phone number link, and tooltip expansion on info icon click.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")},
            dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})
    public void validateBwPromoCardSectionOnReviewQuotePage(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(),
                "User should be on the Bristol West quote summary page");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        quoteSummaryAutoPage.validateBwPromoCardSection(fsa);
        fsa.assertAll();
    }


    /**
     * F82381: Auto FGIA option - make permanent
     *
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX, PA, MD, TN, MI, AZ, IL, OH, MO, OK, VA, AR, CO, OR, AL, WI, MN}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void testAutoFGIAOptionChanges(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
        if (quoteSummaryAutoPage.isOnBristolWest()) {
            testStep("Test ended early. User should be on the Farmers Quote page to test this feature");
            return;
        }
        quoteSummaryAutoPage.validatePriceTooHighSection(fsa);
        fsa.assertAll();
    }

    /**
     * US976212: Validate BW flow and BDQ flow for WA Auto quotes after the BI/PD restrictions removal - Regression
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void testWAStateBI_PD_Restrictions_BW(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        bwSpecificDataSetUp(applicant);
        applicant.getDiscounts().get(0).setSignalSignup(false);
        //applicant.setLastName("Wilson");
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        quoteSummaryAutoPage.validateWAState_Bi_PD_Combinations_Restriction(fsa);
        fsa.assertAll();
    }

    /**
     * US976212: Validate BW flow and BDQ flow for WA Auto quotes after the BI/PD restrictions removal - Regression
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BDQ_TESTS})
    public void testWAStateBI_PD_Restrictions_BDQ(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicant.setTestScenario("BW" + SPACE + getRandomBdqFlow(applicant.getStateCode()) + SPACE + applicant.getTestScenario());
        applicant.setContinuosInsurancePeriod("12 - 23 Months");
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        quoteSummaryAutoPage.validateWAState_Bi_PD_Combinations_Restriction(fsa);
        fsa.assertAll();
    }

    /**
     * F89263/US924806: Validate MA state rate with zipcode associated with two town ( 11 Greenfield St, Lawrence, MA 01843)
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validate_MA_State_Vehicle_Garage_parketAtResidentAddress(AutoApplicant applicant) throws Exception {
        applicant.setResidentAddress("11 Greenfield St");
        applicant.setZipCode("01843");
        applicant.getVehicles().get(0).setParkInResidentAddress(true);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the Quote summary page in MA state with Garage address");
    }

    /**
     * F89263/US924806: Validate MA state rate with zipcode associated with two town ( 11 Greenfield St, Lawrence, MA 01843)
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validate_MA_State_Vehicle_Garage_is_Not_parketAtResidentAddress(AutoApplicant applicant) throws Exception {
        applicant.setResidentAddress("11 Greenfield St");
        applicant.setZipCode("01843");
        applicant.getVehicles().get(0).setParkInResidentAddress(false);
        applicant.setGaragingAddress("169 Rumney Road");
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the Quote summary page in MA state with Garage address");
    }

    /**
     * F90438: PIP Coverage handling in the state of MA (BW & Farmers)
     * this one is for Farmers
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validate_PIP_CoverageHandling_MA_State_Farmers(AutoApplicant applicant) throws Exception {
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper(quoteFlow.AGENT).navigateToEitherQuoteSummaryPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        quoteSummaryAutoPage.validatePIPHandling_MA_State(fsa, false);
        fsa.assertAll();
    }

    /**
     * F90438: PIP Coverage handling in the state of MA (BW & Farmers)
     * this one is for BW
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})
    public void validate_PIP_CoverageHandling_MA_State_BW(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper(quoteFlow.DEFAULT).navigateToEitherQuoteSummaryPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        quoteSummaryAutoPage.validatePIPHandling_MA_State(fsa, true);
        fsa.assertAll();

    }

    /*
    Validate that [CA State] Negative : AWS (or) EA Agent : Online bind should not be enabled - Thank you pag
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateAgentFlowBindIsNotEnabledForCA(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper(quoteFlow.AGENT).navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
        AutoRateQuoteResponseBean autoRateQuote = new ApiHelper().getAutoRateQuote(quoteSummaryAutoPage.getSessionStorageAppStore().getData().getQuoteNumber());
        AutoRateQuoteResponseBean.AutoRateQuoteResponseBean__1.RateQuoteResponse rateQuoteResponse = autoRateQuote.getAutoRateQuoteResponseBean().getRateQuoteResponses().get(0);
        boolean bindEnabled = rateQuoteResponse.getBuyEnableInd().equals("N");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(bindEnabled, "Bind should be 'N'");
        quoteSummaryAutoPage.clickOnStartCheckoutButton();
        ThankYouPageAce thankYouPageAce = new ThankYouPageAce();
        fsa.assertTrue(thankYouPageAce.isOnThankYouPage(), "User should land on the thank you page with agent url");
        fsa.assertAll();

    }

    /*
    Validate that FFQ (CA) - Auto - Not to offer the $15K for PD coverage option if  Rideshare coverage is selected
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validatePDDoesNotOffer15K_with_rideshare(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage("Rideshare");
            each.setRidesharing(true);
        });

        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        quoteSummaryAutoPage.validatePDDoesNotOffer15KWithRideshare(fsa);
        fsa.assertAll();

    }

    /**
     * Create auto Quote with rideshare & check if PD allows minimum limit as 50K & Edit coverage side sheet should not show limits below 50K for property damage
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {IN}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateRideShareDoesNotAllowLessThan50k_IN_State(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage("Rideshare");
            each.setRidesharing(true);
        });
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        List<String> availablePdOptionsFromSideSheet = quoteSummaryAutoPage.getAvailablePdOptionsFromSideSheet();
        for (String option : availablePdOptionsFromSideSheet) {
            // Remove $ and commas, then parse to integer
            int value = Integer.parseInt(option.replace("$", "").replace(",", ""));
            fsa.assertTrue(value >= 50000, "Found value less than $50,000: " + option);
        }
        fsa.assertAll();

    }

    /**
     * Create auto Quote without  rideshare & customize the quote with limit as 25K for PD,BI. Update the quote to include Rideshare & rate the quote. Check if BI & PD limits ae reset to 50K
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {IN}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateWithoutRideshareAndUpdateTheQuoteWithRideShare(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.getVehicles().forEach(each -> each.setVehicleUsage(PERSONAL));
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        quoteSummaryAutoPage.validateStartWithNoRideShareAndAdd(applicant, fsa);
        fsa.assertAll();

    }

    /**
     * Create auto Quote without  rideshare & customize the quote with limit as 25K for PD,BI. Update the quote to include Rideshare & rate the quote. Check if BI & PD limits ae reset to 50K
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, NC}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS, BDQ_TESTS})
    public void validateRideShareMinLiabilityLimitsForBW(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        applicant.setLastName("Threeoabaa");
        if (applicant.getStateCode().equals(MD)) {
            applicant.setTestScenario(SPECIAL_BI_LIMIT_IS_NEEDED + SPACE + applicant.getTestScenario());
            applicant.setCurrentBodilyInjuryLimit(_50K_AND_100K);
        }
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage("Rideshare");
            each.setRidesharing(true);
        });
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        quoteSummaryAutoPage.validateRideShareMinLiabilityLimits(applicant, fsa);
        fsa.assertAll();
    }

    /**
     * BW: Validate upon selecting two or more "Ride Share" checkbox is selected in vehicle review screen the quote should get KO.
     */

    // Two vehicles with rideshare and business use should go to KO
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, KS, MI, MN, MO, NM, OK, TN, TX, VA, WA}), @CustomAttribute(name = FILTER, values = {"applicantId=36"})}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})
    public void validateTwoVehiclesRideshareWithBusinessUseGoesToKO(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus("Never Insured");
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage(BUSINESS);
            each.setRidesharing(true);
        });
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        if (applicant.getStateCode().equals(NC)) {
            fsa.assertTrue(knockoutInconveniencePage.isOnKnockOutPage(), "User should be on the KO page with two or more vehicles are rideshare usage");
            fsa.assertAll();
            return;
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
        }
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            if (applicant.getStateCode().equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
        }
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
        }

        BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
        if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            bristolWestAdditionalDiscountsPage.clickContinue();
        }
        continueWithBristolWestPage.closeQualtricsPopUp();
        fsa.assertTrue(knockoutInconveniencePage.isOnKnockOutPage(), "User should be on the KO page with two or more vehicles are rideshare usage");
        fsa.assertAll();

    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, KS, MI, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})
    public void validateThreeRideShareVehicleGoesToKO(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus("Never Insured");
        applicant.setAdditionalDrivers(Collections.emptyList());
        applicant.setMaritalStatus(SINGLE);
        applicant.getVehicles().forEach(each -> {
            each.setRidesharing(true);
            each.setUseVIN(true);
            each.setVehicleUsage(BUSINESS);
        });
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        if (applicant.getStateCode().equals(NC)) {
            fsa.assertTrue(knockoutInconveniencePage.isOnKnockOutPage(), "User should be on the KO page with two or more vehicles are rideshare usage");
            fsa.assertAll();
            return;
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
        }
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            if (applicant.getStateCode().equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
        }
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
        }

        BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
        if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            bristolWestAdditionalDiscountsPage.clickContinue();
        }
        continueWithBristolWestPage.closeQualtricsPopUp();
        fsa.assertTrue(knockoutInconveniencePage.isOnKnockOutPage(), "User should be on the KO page with two or more vehicles are rideshare usage");
        fsa.assertAll();

    }

    /**
     * BDQ: Verify the accuracy of the prices in Vehicle Coverage table (for every vehicle added) in Quote screen (i.e.) Manually add each price and verify if the total price is calculated correctly.
     * BDQ: Verify the accuracy of the prices in Liability Coverage table in Quote screen (i.e.) Manually add each price and verify if the total price is calculated correctly.
     * Verify if the Overall premium displaying in Quote summary card is sum of both Liability and Vehicle coverages premium.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {QUOTE_SUMMARY, BDQ_TESTS})
    public void validateLiabilityAndVehicleCoverageTotalIsMatching(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        applicant.getVehicles().forEach(each -> each.setOwnership("Financed"));
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper(switchTestToBDQIfNeeded(applicant) ? quoteFlow.BDQ : quoteFlow.DEFAULT).navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "USer is on the quote summary page");

        // Verify if user can view both Monthly or PIF premiums and coverages/prices by switching b/w Monthly and PIF via "Pay in Monthly/Full" link in Quote summary card.
        String presentedPremiumAmount = quoteSummaryAutoPage.getPresentedPremiumAmount();
        fsa.assertTrue(presentedPremiumAmount.contains("/mo"), "User should be able to see monthly premium amount");
        sleep(4);
        fsa.assertTrue(quoteSummaryAutoPage.getAlternativePaymentLinkText().contains("View pay-in-full price"), "Pay in full price link text");
        quoteSummaryAutoPage.clickOnAlternativePaymentLink();
        sleep(1);
        presentedPremiumAmount = quoteSummaryAutoPage.getPresentedPremiumAmount();
        fsa.assertTrue(quoteSummaryAutoPage.getAlternativePaymentLinkText().contains("View monthly pricing"), "Monthly price link text");
        fsa.assertFalse(presentedPremiumAmount.contains("/mo"), "User should be able to see PIF premium amount");


        quoteSummaryAutoPage.clickOnAlternativePaymentLink();
        sleep(1);
        presentedPremiumAmount = quoteSummaryAutoPage.getPresentedPremiumAmount();
        // validate total premium
        double vehicleTotalPrice = quoteSummaryAutoPage.validateEachVehicleTotalPrice(fsa);
        double liabilityTotalPrice = quoteSummaryAutoPage.validateLiabilityTotalPrice(fsa);

        double expectedTotal = vehicleTotalPrice + liabilityTotalPrice;
        double actualTotal = Double.parseDouble(presentedPremiumAmount.replace("$", "").replace(",", "").replace("/mo", "").trim());

        // Round expected total to 2 decimal places
        BigDecimal expectedTotalRounded = BigDecimal.valueOf(expectedTotal).setScale(2, RoundingMode.HALF_UP);
        BigDecimal actualTotalRounded = BigDecimal.valueOf(actualTotal).setScale(2, RoundingMode.HALF_UP);

        if (applicant.getStateCode().equals(MI)) {
            // Calculate the absolute difference
            BigDecimal difference = expectedTotalRounded.subtract(actualTotalRounded).abs();

            // Check if the difference is between 15 and 17
            fsa.assertTrue(difference.compareTo(BigDecimal.valueOf(15)) > 0 && difference.compareTo(BigDecimal.valueOf(17)) < 0, "Expected total: $" + expectedTotalRounded + ", but found: $" + actualTotalRounded + ". Difference: $" + difference + " is not between $15 and $17.");

        } else {
            //TODO: Currenlty there is some once cent discrepancy
            // Calculate the absolute difference
            BigDecimal difference = expectedTotalRounded.subtract(actualTotalRounded).abs();

            // Allow a difference of up to $0.01
            fsa.assertTrue(difference.compareTo(BigDecimal.valueOf(0.1)) <= 0, "Expected total: $" + expectedTotalRounded + ", but found: $" + actualTotalRounded + ". Difference: $" + difference + " exceeds allowed tolerance of $0.01.");

        }
        fsa.assertAll();
    }

    /**
     * F90008 : Validate side pannels for all screens when we click on esc button side panne must dismiss
     */

    // removing streamline states from this test as driver review pages are not available in streamline flow
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, GA, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, WI})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateSidePanelClosedWithEscapeKey_ADA(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        quoteSummaryAutoPage.validateSidePanelsClosedWithEscapeKey(fsa, applicant);
        fsa.assertAll();
    }

    /**
     * F90692 : Validate for GA State Auto quotes if there is no toggle button displaying for 'Accidental Death or Disabling Injury' coverage in UI (Side sheet)
     * F90692 : Validate for GA State Auto quotes if can successfully modify the limits pertaining to 'Accidental Death or Disabling Injury' coverage and the quote should be custom rated successfully.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {GA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateGAStateAccidentDeathCoverageCustomization(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName());
        quoteSummaryAutoPage.validateCustomizeAccidentDeathAndDisabilityInjury(fsa);
        fsa.assertAll();
    }

    /**
     * scenario 538 and 539
     * F75028
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {IL, OR, AZ, CA, CO, FL, ID, KS, MA, MO, NM, OK, PA, NJ, NV})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateComboDiscount(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        randomizeApplicantPersonalData(applicant);
        applicant.setLastName("Brown");
        if (applicant.getStateCode().equals(NC)) {
            applicant.getVehicles().forEach(each -> each.setUseVIN(true));
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName());
        quoteSummaryAutoPage.validateComboCoverage(fsa);
        completePurchase(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, fsa);
        fsa.assertAll();
    }

    /**
     * scenario 540
     * F75028
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {IL, OR, AZ, CA, CO, FL, ID, KS, MA, MO, NM, OK, PA, NJ, NV})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateComboDiscountRetrieval(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        randomizeApplicantPersonalData(applicant);
        applicant.setLastName("Brown");
        if (applicant.getStateCode().equals(NC)) {
            applicant.getVehicles().forEach(each -> each.setUseVIN(true));
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName());
        quoteSummaryAutoPage.validateComboCoverage(fsa);
        List<String> statesEligibleForComboCoverage = new ArrayList<>(Arrays.asList(AR, CO, ID, IL, MI, ND, NE, NM, GA, OK, OR, PA, SD, TN, TX, WI, WY, AZ, VA, MO, AL, CT, UT));
        AppStore.Data data = quoteSummaryAutoPage.getSessionStorageAppStore().getData();
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, data.getQuoteNumber());
        boolean isCoverageComboDiscountExpected = statesEligibleForComboCoverage.contains(data.getLandingStateCode());

        // testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
        // fsa.assertTrue(isCoverageComboDiscountExpected == quoteSummaryAutoPage.isDiscountPresentInTheSideSheet("Coverage Combo"), "Coverage combo discount should" + (isCoverageComboDiscountExpected ? "" : SPACE + NOT) + " be present on the side sheet on the " + quoteSummaryAutoPage.getClass().getSimpleName());
        // quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        // NOTE: retrieval is landing on the payment page if the quote was dropped from payment page

        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        fsa.assertTrue(isCoverageComboDiscountExpected == consolidatedPaymentPage.getDiscountNames().contains("Coverage Combo"), "Coverage combo discount should" + (isCoverageComboDiscountExpected ? "" : SPACE + NOT) + " be present on the side sheet on the " + consolidatedPaymentPage.getClass().getSimpleName());
        fsa.assertAll();
    }

    /**
     * scenario 605, 606
     * TC2023160,
     * TC2023161,
     * TC2022821
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {NJ})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validateBI_UIM_MinimumLimits_NJ(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicant.setTestScenario(SPECIAL_BI_LIMIT_IS_NEEDED + SPACE + applicant.getTestScenario());
        randomizeApplicantPersonalData(applicant);
        // set special BI limit to trigger UIM minimum limits validation
        applicant.setCurrentBodilyInjuryLimit("$50,000/$100,000");

        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);

        // make sure policy start date is in 2026
        contactInfoAutoPage.sendKeysToPolicyStartDateInputField(getFormattedForPolicyStartDate(LocalDate.now().plusDays(45)));

        contactInfoAutoPage.clickContactInfoPageCTAButton();

        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();

        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName());

        quoteSummaryAutoPage.validateUIM_MinimumLimits_NJ_State(fsa);

    }

    /*
        BW_AUTO_ACE 155
        Validate UMPD covergae should be displayed correctly, upon customizing
        Steps to reproduce:
        Step 1: Start creating a BDQ/FFQ quote with last name as BWTESTH.
        Step 2: Navigate till quote page.
        Step 3: Click on ""Edit Libility coverage"" and update UMPD value greater than Property Damage value.
        Step 4: Click on Recalculate button. - POP is displayed ""UMPD cannot exceed PD"" but still we are able to rate a quote with UMPD exceeded value.
        Step 5: Close the popup.
        Actual: User is able to rate the quote successfully even when UMPD exceeds Property Damage Liability.
E       xpected: Selected UMPD coverage should not exceed Property Damage Liability."
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {OR})}, groups = {QUOTE_SUMMARY, BDQ_TESTS, BW_ACE_TESTS})
    public void validateUMPDIsNotHigherThanPD_OR(AutoApplicant applicant) throws Exception {
        applicant.setFinancialFiling(SR_22);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper(switchTestToBDQIfNeeded(applicant) ? quoteFlow.BDQ : quoteFlow.DEFAULT).navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName() + " with BW");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        quoteSummaryAutoPage.validateUMPDIsNotHigherThanPD_OR_State(fsa);
        fsa.assertAll();
    }

    /*
          BW_AUTO_ACE 157
          "Validate When consumer has a financed/leased vehicle which is being used for Rideshare, the UI validation, user should allow a consumer to reduce their PD coverage
          Expected Result:
          User should be able to reduce PD to as low as 30 when Rideshare is selected
          Actual Result:
          User is not able to reduce PD from 50 to 30 as UI displayed the message that 50 is required for Rideshare, which is not the case"
       */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MA})}, groups = {QUOTE_SUMMARY, BW_ACE_TESTS, BDQ_TESTS})
    public void validateUserIsAbleToUpdatePDTo_30_MA(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper(quoteFlow.DEFAULT);
        applicant.getVehicles().forEach(each -> {
            each.setOwnership(RandomUtils.nextBoolean() ? "Financed" : "Leased");
            each.setVehicleUsage("Rideshare");
            each.setRidesharing(true);
        });
        updateLastNameForBristolWest(applicant);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);

        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName() + " with BW");
        quoteSummaryAutoPage.validateUserIsAbleToSelectAndRecalculatePD(fsa);
        fsa.assertAll();
    }

    /*
          BW_AUTO_ACE 158
          "Validate BW quotes should not get fail when the user is with Rideshare checbox selected and in quote page, deselecting UM/UIM option after selecting it, for TN state quotes.

           Expected Result:
            whenever the user is deselecting UM/UIM option after selecting it, there should be a validation message.

           Actual Result:
            whenever the user is deselecting UM/UIM option after selecting it, there is no validation message."
   */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {TN})}, groups = {QUOTE_SUMMARY, BW_ACE_TESTS, BDQ_TESTS})
    public void validateUmUimSelectionAfterDeselection_TN_State(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper(quoteFlow.DEFAULT);
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage(RIDESHARE);
            each.setRidesharing(true);
        });
        applicant.setLastName("Threeoabaa");
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);

        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName() + " with BW");
        quoteSummaryAutoPage.validateUmUimSelectionAfterDeselection(fsa);
        fsa.assertAll();
    }

    /*
     * BDQ ace auto 183 / F91388
     * Verify 50/100/25 liability limits are automatically enforced when single Rideshare vehicle is added to new policy
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT, IL})}, groups = {BDQ_TESTS})
    public void validate50_100_25_LimitsAreEnforcedWithSingleRideShareVeh(AutoApplicant applicant) throws Exception {
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage(RIDESHARE);
            each.setRidesharing(true);
        });
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper(quoteFlow.BDQ).navigateToEitherQuoteSummaryPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName() + " with BW");
        quoteSummaryAutoPage.validateMinLiabilityLimitsAreEnforced(fsa);
        fsa.assertAll();
    }

    // DE299519: [RA11][PROD] Safety Course - Mature Driver Discount Drops Off with RC1
    @Skip // will be needed for defect validation
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {TX,MO,NE,OK,FL,GA,PA,OR,NJ,IA, CA,MT,IN,KY,KS,LA,NV,AR,CO,TN,NM,IL,UT,MS,MN,MI,AZ,VA,MD,ID,MA,WA,OH})}, groups = {FFQ_ONEUI})
    public void validateMatureDriverDiscount(AutoApplicant applicant) throws Exception {
        applicant.setCompletedDriversSafetyCourse(true);
        applicant.setAge(80);
        applicant.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(applicant.getAge()));
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        boolean prodEnvironment = aceAutoNavigationHelper.isProdEnvironment();
        if(prodEnvironment) {
            updatePersonalInfoForProd(applicant);
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        List<String> displayedDiscounts = quoteSummaryAutoPage.getDisplayedDiscounts();
        Log.info("Displayed discounts: " + displayedDiscounts);
        testStepAssert(displayedDiscounts.contains("Mature driver") || displayedDiscounts.contains("Safe driver") || displayedDiscounts.contains("Defensive driver") || displayedDiscounts.contains("Mature Driver") || displayedDiscounts.contains("Driver Improvement"), "Mature Driver discount should be displayed for applicant age 80 with completed driver's safety course");
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void validateIfSignalDiscountGetsRemovedInQuoteReviewPage(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicant.getVehicles().forEach(vehicle -> vehicle.setUseVIN(true));
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        String state = applicant.getStateCode();
        if (state.equals(OR)) {
            QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToQuoteSummaryAutoPage(applicant);
            testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote Summary Page has been reached");
            quoteSummaryAutoPage.removeSignalDiscountAndCheck(applicant, fsa);
        }
        List<SqlDiscount> listOfDiscounts = applicant.getDiscounts();
        SqlDiscount discounts = listOfDiscounts.get(0);
        discounts.setSignalSignup(true);
        listOfDiscounts.add(discounts);
        applicant.setDiscounts(listOfDiscounts);
        if (aceAutoNavigationHelper.isSignalDiscountDisabledState(applicant.getStateCode())) {
            Log.info("Signal discount is not available for the given state -> " + applicant.getStateCode());
            return;
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToQuoteSummaryAutoPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote Summary Page has been reached");
        quoteSummaryAutoPage.removeSignalDiscountAndCheck(applicant, fsa);
        fsa.assertAll();
    }

    /**
     * Auto Quote and Bind sheet
     * Scenario 710: Validate that CO State Auto Monoline quote user-customized values of Comp and Collision are retained after retrieval
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {CA, CO})})
    public void validateCustomizedCompCollCoveragesAreRetainedWithRetrieval(AutoApplicant applicant) throws Exception {
        new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        quoteSummaryAutoPage.validateCustomizedCompAndCollCoveragesAreRetainedAfterRetrieval(applicant);
    }

    /**
     * Auto Quote and Bind sheet
     * Scenario 620:CA-State Validate if user is able to Verify rate the quote successfully after updating ‘Permissive user limit of liability’ to ‘Limited’
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {CA})})
    public void validateQuoteRatingAfterPermissiveUserLimitOfLiabilityUpdateToLimited(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        quoteSummaryAutoPage.validatePermissiveUserLimitOfLiabilityUpdateToLimited("Limited",fsa);
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        fsa.assertAll();

    }

    /**
     * Auto Quote and Bind sheet
     * Scenario 669:Validate for CA State Auto quotes, if the customized coverage values are displaying correctly on retrieval.
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {CA})})
    public void verifyCustomizedCoverageValuesForCAAutoQuoteOnRetrieval(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        quoteSummaryAutoPage.validatePermissiveUserLimitOfLiabilityUpdateToLimited("Limited", fsa);
        quoteSummaryAutoPage.updateVehicleCoverageAndCustomize();
        quoteSummaryAutoPage.validateUpdatedPermissiveUserLimitValueCompAndCollAreRetainedAfterRetrieval(applicant, fsa);
        fsa.assertAll();
    }

    /**
     * Auto Quote and Bind sheet
     * Scenario 726:Verify that when the user receives the first premium on the quote page and modifies any coverage, a Reset Original Offer button is displayed, and clicking it resets all coverages back to Farmers’ original offer.
     * Scenario 727:Verify that once all coverages are reset to the original Farmers offer, the "Reset to Original Premium" button becomes disabled and remains disabled until the user changes a coverage again.
     * @param applicant
     * @throws Exception
     */

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void testVerifyResetButtonDisablesAfterRevertingAllCoveragesToOriginal(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        quoteSummaryAutoPage.validateResetButtonDisappearAfterRevertingCoverages(fsa);
        fsa.assertAll();
    }

    /**
     * Auto Quote & Bind Sheet: S.No: 745
     * Validate whether new pop up content is displayed when user launches FFQ using TL source code.
     * URL: https://ffqautouiuat.farmers.com/quote/?LOB=A&ZIP=85032&SRC=TL_8392473LWEOW&Source_Indicator=TL
     * Steps.
     * 1. Initiate above URL with mentioned ZIP codes.
     * 2. Enter all auto related data and navigate untill Quote screen.
     * 3. one time POP up should be displayed once user lands on rate screen and it should not be displayed again even when user reloads page or browser back or retrieveal.
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI, BW_ACE_TESTS}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, AZ, AR, GA, ID, KY, OH, OK, OR, SD, WA, WY}), @CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void validateTheTlSourceCodeFunctionality(AutoApplicant applicant) throws Exception {
        if(Property.getTestProperty("suite").contains(BW_ACE_TESTS)) {
            bwSpecificDataSetUp(applicant);
        }
        // Start the TL flow with the URL
        String url = String.format("%s?LOB=A&ZIP=%s&SRC=TL_8392473LWEOW&Source_Indicator=TL", Property.getUri(), applicant.getZipCode());
        driver().get(url);
        Log.info("Navigated to URL with TL source code: " + url);

        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()) {
            //FL always displays BW dialog, so click on Continue to BW and resume normal flow
            continueWithBristolWestPage.continueWithBWPage(true);
            continueWithBristolWestPage.waitForSpinnerToBeGone();
        }

        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        testStepAssert(nameAndDobPage.isOnNameAndDobPage(), "User should land on Name and DOB page");

        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        quoteSummaryAutoPage.validateTlSourceCodeFunctionality(applicant, fsa);
        fsa.assertAll();
    }

    /**
     * Auto Quote & Bind Sheet: S.No: 746
     * Validate whether new pop up content is displayed when user launches FFQ using MLB source code.
     * URL: https://ffqautouiuat.farmers.com/fastquote/?Lob=Auto&Zip_Code=98226&source_indicator=ML&source_id=MLB0001
     * Steps.
     * 1. Initiate above URL with mentioned ZIP codes.
     * 2. Enter all auto related data and navigate untill Quote screen.
     * 3. one time POP up should be displayed once user lands on rate screen and it should not be displayed again even when user reloads page or browser back or retrieveal.
     * Included states: OR, WA
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI, BW_ACE_TESTS}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {OR, WA,AL, AR, CA, CO, CT, FL, IL, IN, IA, KS, KY, LA, MD, MI, MS, MO, NV, NM, OH, OK, TX, TN, VA, WI,MT,ID}), @CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void validateTheMLBSourceCodeFunctionality(AutoApplicant applicant) throws Exception {
        if(Property.getTestProperty("suite").contains(BW_ACE_TESTS)) {
            bwSpecificDataSetUp(applicant);
        }
        String stateCode = applicant.getStateCode();
        if (stateCode.equals(TX)) {
            //F104174
            applicant.setFirstName("Woods");
            applicant.setLastName("Don");
            applicant.setResidentAddress("31131 PINE ROSE DR");
            applicant.setZipCode("77386");
        }
        // Start the MLB flow with the URL
        String url = String.format("%s?Lob=Auto&Zip_Code=%s&source_indicator=ML&source_id=MLB0001", Property.getUri(), applicant.getZipCode());
        driver().get(url);
        Log.info("Navigated to URL with MLB source code: " + url);

        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()) {
            //FL always displays BW dialog, so click on Continue to BW and resume normal flow
            continueWithBristolWestPage.continueWithBWPage(true);
            continueWithBristolWestPage.waitForSpinnerToBeGone();
        }


        InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
        if (interstitialBundlePage.isOnInterstitialBundlePage()) {
            interstitialBundlePage.continueWithAutoMonoLine();
        }
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        testStepAssert(nameAndDobPage.isOnNameAndDobPage(), "User should land on Name and DOB page");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        if (stateCode.equals(TX)) {
            // validate fws interstitial page should not present
            AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
            fsa.assertFalse(fwsInterstitialPage.isOnFarmersChoiceInterstitialPage(), "User should not navigate to FWS Interstitial - Farmers choice page");
        }
        quoteSummaryAutoPage.validate_MLB_SourceCodeFunctionality(applicant, fsa);
        fsa.assertAll();
    }

    /**
     * Auto Quote & Bind Sheet: S.No: 749
     * Validate whether when user clicks on browser back button from signal page and proceeds further no exceptions are occured.
     * Steps.
     * 1. Start a Auto  flow
     * 2. Submits the Contact Info page
     * 3. Uses the browser Back button
     * 4. Lands on the Signal page
     * 5. Resubmits Signal + Contact Info
     * 6. Now proceed further and rate and verify quote no exceptions should be triggered and land on appropriate page.
     * 7. Browser back on different screens and proceed further no issues should be observed.
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
    		groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void validateNoExceptionOnBrowserBackNavigationFromSignalPage(AutoApplicant applicant) throws Exception {
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
    	AceAutoNavigationHelper autoNavigationHelper = new AceAutoNavigationHelper();
    	autoNavigationHelper.navigateToContactInfoAutoPage(applicant);
    	driver().navigate().back();
    	SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
    	testStepAssert(signalPageOneUI.isOnSignalPage(), "User should land on Signal page after navigating back");
    	// This method reads the page source and checks for no exceptions
    	assertNoExceptionOnPage(fsa);
    	autoNavigationHelper.setResumeFromPage(signalPageOneUI.getClass().getSimpleName());
    	autoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
    	WhoShouldWeInsurePage whoShouldWeInsurePage = autoNavigationHelper.navigateBackToWhoShouldWeInsurePage();
    	assertNoExceptionOnPage(fsa);
    	whoShouldWeInsurePage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
    	assertNoExceptionOnPage(fsa);
    	fsa.assertAll();
    }

    /**
     *    Validate for Auto quotes created with ADPF data, if the ADPF flag is passing in the rate request since ADPF is ordered for the quote. Also, check if 'adpfordered' is 'True' in the Quote XML.
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {CO})})
    public void validateADPFOrderedFlagInQuoteXML(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        //Set applicant data
        applicant.setFirstName("Markco");
        applicant.setLastName("Johnsonco");
        applicant.setDateOfBirth("12/29/1984");
        applicant.setCity("Berthoud");
        applicant.setZipCode("80513");
        applicant.setStateCode(CO);
        applicant.setResidentAddress("10510 Obrien Creek Rd");
        AceAutoNavigationHelper autoNavigationHelper = new AceAutoNavigationHelper();
        QuoteSummaryAutoPage quoteSummaryAutoPage = autoNavigationHelper.navigateToQuoteSummaryAutoPage(applicant);
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName());
        quoteSummaryAutoPage.validateADPFOrderedFlagInQuoteXML(fsa);
        fsa.assertAll();
    }

    /**
     * "Validate for Auto quotes created with non-ADPF data, if the ADPF flag is NOT passing in the rate request since ADPF is Not ordered for the quote. Also, check if 'adpfordered' is 'False' in the Quote XML.
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA})})
    public void validateADPFNotOrderedFlagInQuoteXML_NonAdpf_Data(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        randomizeApplicantPersonalData(applicant);
        AceAutoNavigationHelper autoNavigationHelper = new AceAutoNavigationHelper();
        QuoteSummaryAutoPage quoteSummaryAutoPage = autoNavigationHelper.navigateToQuoteSummaryAutoPage(applicant);
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName());
        quoteSummaryAutoPage.validateADPFNotOrderedFlagInQuoteXML(fsa);
        fsa.assertAll();
    }

    /**
     * Validate for CA State Auto quotes that are FWS [COLP/Group Quote] eligible that the following navigation and UI changes occur:
     * a. The FWS Interstitial page should not be displayed upon submission of the Address screen and user should be allowed with regular quoting flow.
     * b. A Payroll Deduction banner should be displayed at the top of the Review Quote screen with the following content:
     * “Thanks for shopping with Farmers!
     * You may be eligible to enroll in payroll deduction and other benefits through your employment at SIEMENS CORPORATION. A representative can discuss all your options and check for additional discounts.
     * To buy, please call us at 855-503-1928.”
     * c. The Stepper should not be displayed on the Review Quote screen.
     * d. The “Email this quote” link should not be displayed below the Quote Presentment card.
     * e. Bind should be disabled and the “Continue” CTA button should not be displayed. Instead, the CTA should display “Call 855-503-1928.”
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void verifyPayRollDeductionForNonAWSFlow(AutoApplicant applicant) throws Exception {
        String stateCode = applicant.getStateCode();
        if (stateCode.equals(CA)) {
            applicant.setFirstName("Roger");
            applicant.setLastName("Mumm");
            applicant.setCity("Redding");
            applicant.setResidentAddress("20868 Ramsdale Ln");
            applicant.setZipCode("96003");
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        // validate fws interstitial page should not present
        fsa.assertTrue(!knockoutInconveniencePage.isOnKnockOutPage(), "User should not navigate to FWS Interstitial - Colp page");
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User did not navigate to Quote Summary page");
        //validate pay Roll banner displayed
        Assert.assertTrue(quoteSummaryAutoPage.isPayrollDeductionBannerDisplayed(), "Pay Roll Banner content is not displayed");
        //validate pay roll deduction content.
        quoteSummaryAutoPage.validatePayRollBannerContentForCAState(fsa);
        //validate navigation stepper bar should not displayed.
        fsa.assertFalse(quoteSummaryAutoPage.isStepperDisplayed(), "Stepper should not display on Review Quote page");
        //validate email this quote should not displayed.
        fsa.assertFalse(quoteSummaryAutoPage.isEmailThisQuoteLinkDisplayed(), "Email this quote link should not displayed");
        fsa.assertAll();
    }

    /**
     * Validate that the FWS flow is not eligible for CA State Auto quotes that are FWS [COLP/Group Quote] eligible but created using an AWS URL / EA assignment (i.e., the quote should be rated successfully). In this scenario, the standard quoting experience should apply, and the following behaviors should be validated:
     * a. The FWS Interstitial page should not be displayed upon submission of the Address screen, and the user should be allowed to proceed through the regular quoting flow.
     * b. The Payroll Deduction banner should not be displayed at the top of the Review Quote screen.
     * c. The Stepper should be displayed on the Review Quote screen.
     * d. The “Email this quote” link should be displayed below the Quote Presentment card.
     * e. Bind should be enabled, and the “Continue” CTA button should be displayed.
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void verifyPayRollDeductionForAWSFlow(AutoApplicant applicant) throws Exception {
        String stateCode = applicant.getStateCode();
        if (stateCode.equals(CA)) {
            applicant.setFirstName("Roger");
            applicant.setLastName("Mumm");
            applicant.setCity("Redding");
            applicant.setResidentAddress("20868 Ramsdale Ln");
            applicant.setZipCode("96003");
        }
        String AWSurl = String.format("%s?Source_Indicator=AP&Agent_Code=974551&State_Code=CA&Lob=A&Zip_Code=%s&_gl=1*euqnlg*_ga*MjExMDMzODk5NC4xNzY1MzUyMDU2*_ga_6H7TLKVS38*czE3NjUzNTIwNTUkbzEkZzEkdDE3NjUzNTI0OTQkajYwJGwwJGgw&addressline=%s", Property.getUri(), applicant.getZipCode(),applicant.getZipCode());
        driver().get(AWSurl);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceHRCFwsInterstitialPage fwsInterstitialPage = new AceHRCFwsInterstitialPage();
        // validate fws interstitial page should not present
        fsa.assertTrue(!fwsInterstitialPage.isOnColpInterstitialPage(), "User should not navigate to FWS Interstitial - Colp page");
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User did not navigate to Quote Summary page");
        //validate pay Roll banner displayed
        fsa.assertFalse(quoteSummaryAutoPage.isPayrollDeductionBannerDisplayed(), "Pay Roll Banner content is displayed");
        //validate navigation stepper bar should be displayed
        fsa.assertTrue(quoteSummaryAutoPage.isStepperDisplayed(), "Stepper should  display on Review Quote page");
        //validate email this quote link displayed
        fsa.assertTrue(quoteSummaryAutoPage.isEmailThisQuoteLinkDisplayed(), "Email this quote link should  display on Review Quote page");
        fsa.assertAll();
    }

    /**
     * Auto Quote & Bind Sheet: S.No: 774
     * US1231265/F104175 Validate whether Mariners Pop up on review quote screen is displayed when source code is MR
     * Steps:
     * 1. Launch URl with mentioned states.
     * URL: https://ffqautouiuat.farmers.com/quote/?LOB=A&ZIP=83401&SRC=MR_8392473LWEOW&Source_Indicator=MR
     * 2. Enter all mandatory details and land on review quote screen.
     * 3. pop up should be displayed.
     *
     * @param applicant
     * @throws Exception
     */

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {ID, MT, OR, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void validateMarinersPopUpOnReviewQuoteScreen(AutoApplicant applicant) throws Exception {
        String MRurl = String.format("%s?LOB=A&ZIP=%s&SRC=MR_8392473LWEOW&Source_Indicator=MR", Property.getUri(), applicant.getZipCode());
        driver().get(MRurl);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.setResumeFromPage(NameAndDobPage.class.getSimpleName());
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName());
        quoteSummaryAutoPage.validateMarinePopUpDisplayedContents(fsa);
        fsa.assertAll();
    }


    private void assertNoExceptionOnPage(FarmersSoftAssert fsa) throws Exception {
    	String source = driver().getPageSource();
    	fsa.assertTrue(!source.contains("Exception"), "Page does not contain Exception");
    }
}
