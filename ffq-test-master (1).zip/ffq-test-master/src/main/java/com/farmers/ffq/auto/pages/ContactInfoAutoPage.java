package com.farmers.ffq.auto.pages;

import com.farmers.ffq.common.enums.FfqBundleOptions;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.SqlDiscount;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;

import lombok.Getter;
import lombok.SneakyThrows;
import net.datafaker.Faker;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter
public class ContactInfoAutoPage extends AutoBasePage {

    static final String EXPECTED_HEADER_1 = "Last step before your quote";
    static final String EXPECTED_HEADER_2 = "Other auto policy details";
    static final String EXPECTED_HEADER_NOTE_1 = "Just a few more questions before we calculate your quote on the next page.";
    static final String EXPECTED_HEADER_NOTE_2 = "This helps us calculate more accurate pricing for you.";
    static final String EXPECTED_POLICY_START_DATE_TITLE_1 = "When would you like your policy to begin?";
    static final String EXPECTED_POLICY_START_DATE_TITLE_2 = "When would you like your auto policy to begin?";
    static final String EXPECTED_DATE_PICKER_AREA_LABEL = "Policy start date";
    static final String CTA_ERROR_MESSAGE = "One or more required fields are incomplete or incorrect. Please Review.";
    static final String ONE_MOMENT_PLEASE = "One moment, please";
    static final String RC2_PAGE_SUBTITLE = "Based on the information you provided and your current coverage, we're ...";

    static final String EXPECTED_EARLY_SHOPPER_INFO_TITLE = "Early shopping discount";
    static final String EXPECTED_EARLY_SHOPPER_INFO_DESCRIPTION = "If your policy start date is 7 or more days from today, you get an early shopping discount. You can start your policy up to 60 days in the future.";
    static final String EXPECTED_BUNDLE_AND_SAVE_INFO_TITLE = "Bundle and save";
    static final String EXPECTED__BUNDLE_AND_SAVE_INFO_DESCRIPTION = "A bundle discount will be applied to your auto quote today. You will have to purchase the policies you select to retain the discount. A Farmers\u00AE representative will reach out to you to help you through the process.";
    static final String EXPECTED_EARLY_SHOPPER_CONGRATS_MESSAGE = "Congratulations \u2014 You get the early shopper discount!";

    static final String EXPECTED_PERSONAL_INFO_LABEL = "Contact information";
    static final String EXPECTED_MAILING_ADDRESS_LABEL = "Mailing address";
    static final String EXPECTED_EMAIL_ADDRESS_FIELD_LABEL = "Email address";
    static final String EXPECTED_MOBILE_PHONE_FIELD_LABEL = "Mobile phone";
    static final String CHOOSE_FARMERS_INSURANCE_GROUP_BRANDS = "Choose Farmers Insurance Group\u00ae brands to select the scope of your consent.";
    static final String EXPECTED_DISCOUNT_BANNER_HEADER="You qualify for an Early Shopper discount";
    static final String EXPECTED_DISCOUNT_BANNER_DESCRIPTION="Quote your policy at least 7 days before the start date to enjoy savings. Shop early and save more!";
    static final String EXPECTED_WARN_BANNER_HEADER="You don't qualify for an Early Shopper discount";
    static final String EXPECTED_WARN_BANNER_DESCRIPTION="The selected start date is outside the early shopper discount window. To qualify for the discount, please select a start date at least 7 days from today.";

    @FindBy(xpath = "//h1[contains(@class,'tui-h1')]")
    private WebElement pageHeader;

    @FindBy(xpath = "//div[contains(@class,'contact-info-heading-note')]")
    private WebElement pageHeaderNote;

    @FindBy(xpath = "//div[contains(@class,'tooltip-section')]//p")
    private WebElement policyStartDateTitle;

    @FindBy(xpath = "//div[contains(@class,'discount-banner')]")
    private WebElement earlyShoppingBanner;

    @FindBy(xpath = "//div[contains(@class,'discount-banner')]//p[@class='tui-field-label']")
    private WebElement earlyShoppingBannerHeader;

    @FindBy(xpath = "//div[contains(@class,'discount-banner')]//p[@class='body']")
    private WebElement earlyShoppingBannerDesc;

    @FindBy(xpath = "//div[@id='policyStartDateDiv']//mat-icon")
    private WebElement mobileEarlyDiscountInfoIcon;

    @FindBy(xpath = "//div[@id='saveBundleDiv']//mat-icon[contains(@class,'info-box-icon')]")
    private WebElement bundleAndSaveInfoIcon;

    @FindBy(xpath = "//app-model-info-box//h1")
    private WebElement mobileEarlyDiscountInfoTitle;

    @FindBy(xpath = "//app-model-info-box//p")
    private WebElement mobileEarlyDiscountInfoDescription;

    @FindBy(xpath = "//mat-dialog-container//mat-icon[@aria-label='Close']")
    private WebElement closeInfoDialogIcon;

    @FindBy(css = "div[class='discount-info']>div")
    private WebElement earlyDiscountInfoTitle;

    @FindBy(css = "div[class='discount-info']>p")
    private WebElement earlyDiscountInfoDescription;

    @FindBy(xpath = "//div[@id='saveBundleDiv']//div[contains(@class,'tui-info-box')]//div[contains(@class,'info-box-header')]")
    private WebElement bundleSaveHelpInfoHeader;

    @FindBy(xpath = "//div[@id='saveBundleDiv']//div[contains(@class,'tui-info-box')]//p")
    private WebElement bundleSaveHelpInfoDescription;

    @FindBy(xpath = "//app-date-picker//mat-label")
    private WebElement datePickerFieldLabel;

    @FindBy(xpath = "//mat-form-field[@id='policyStartDate']//input[@matinput and not(@hidden)]")
    private WebElement policyStartDateInputField;

    @FindBy(xpath = "//app-date-picker[@id='policyStartDateDiv_policyStartDate']//mat-label")
    private WebElement policyStartDateInputFieldPlaceHolderText;

    @FindBy(xpath = "//div[@id='policyStartDateDiv']//mat-error")
    private WebElement policyStartDateError;

    @FindBy(css = "#auto-contact-info-early-shopper-message-container>div")
    private WebElement earlyDiscountCongratulationMessage;

    @FindBy(xpath = "//mat-datepicker-toggle")
    private WebElement datePickerToggle;

    @FindBy(xpath = "//mat-datepicker-toggle//button")
    private WebElement datePickerButton;

    @FindBy(css = "button[class='mat-focus-indicator mat-calendar-period-button mat-button mat-button-base']")
    private WebElement defaultPeriodButton;

    @FindBy(css = "div[class='mat-calendar-body-cell-content mat-focus-indicator mat-calendar-body-selected mat-calendar-body-today']")
    private WebElement defaultSelectedYear;

    @FindBy(css = "button[class='mat-focus-indicator mat-calendar-previous-button mat-icon-button mat-button-base']")
    private WebElement previousMonthButton;

    @FindBy(css = "button[class='mat-focus-indicator mat-calendar-previous-button mat-icon-button mat-button-base mat-button-disabled']")
    private WebElement disabledPreviousMonth;

    @FindBy(css = "button[class='mat-focus-indicator mat-calendar-next-button mat-icon-button mat-button-base']")
    private WebElement nextMonthButton;

    @FindBy(xpath = "//button[@class='mat-calendar-body-cell mat-calendar-body-disabled']//div[contains(@class,'mat-focus-indicator')]")
    private List<WebElement> disabledDaysOfMonth;

    @FindBy(xpath = "//button[@class='mat-calendar-body-cell']//div[contains(@class,'indicator')]")
    private List<WebElement> selectableDaysOfMonth;

    @FindBy(xpath = "//button[@class='mat-calendar-body-cell mat-calendar-body-active']//div[contains(@class,'indicator')]")
    private WebElement selectedDayOfMonth;

    @FindBy(xpath = "//div[@class='auto-driver-review-save-bundle-side-sheet-title']//h2")
    private WebElement bundleSaveHeading;

    @FindBy(className = "save-bundle-info-heading-note")
    private WebElement bundleSaveHeadingNote;

    private final String bundleCheckboxesXpath = "//div[contains(@class,'auto-driver-review-save-bundle-items')]";
    @FindBy(xpath = "//div[contains(@class,'auto-driver-review-save-bundle-items')]//label/span")
    private List<WebElement> saveBundleCheckboxes;

    @FindBy(xpath = "//fieldset[@class='save-bundle-discount-sheet']//mat-checkbox//input")
    private List<WebElement> saveBundleInputs;

    @FindBy(xpath = "//div[@class='save-bundle-discount-sheet']//mat-checkbox")
    private List<WebElement> checkedBundleOptions;

    private final String VIEW_ADDITIONAL_PRODUCTS_XPATH = "//div[@id='view-additional-products']//a";
    @FindBy(xpath = VIEW_ADDITIONAL_PRODUCTS_XPATH)
    private WebElement viewAdditionProductsLink;

    private static final String BUNDLE_CONRATS_MESSAGE_XPATH = "//p[contains(@class,'auto-driver-review-save-bundle-congratulations-message')]";

    @FindBy(xpath = BUNDLE_CONRATS_MESSAGE_XPATH)
    private WebElement saveBundleCongratulationMessage;

    @FindBy(xpath = "//mat-radio-button[contains(@id,'RADIO_BUTTON_FOR_PRIMARY_RESIDENCE')]//input")
    private List<WebElement> primaryResidenceInsuranceRadioButtons;

    @FindBy(xpath = "//div[contains(@class,'contact_info_primary_residence')]//mat-radio-group")
    WebElement primaryResidenceInsuranceRadioButtonGroup;

    @FindBy(css = "#mailingAddressDiv>div>h2")
    private WebElement mailingAddressLabel;

    @FindBy(xpath = "//mat-radio-button[1]")
    private WebElement defaultMailingAddressRadioButton;

    @FindBy(xpath = "//mat-radio-button[@id='mailingAddressDiv_1']//label")
    private WebElement defaultMailingAddressRadioButtonLabel;

    private static final String OTHER_MAILING_ADDRESS_RADIO_BUTTON_XPATH = "//div[@id='mailingAddressDiv_mailingAddress']//mat-radio-button[2]//input";
    @FindBy(xpath = OTHER_MAILING_ADDRESS_RADIO_BUTTON_XPATH)
    private WebElement otherMailingAddressRadioButton;

    @FindBy(xpath = "//mat-radio-button[contains(.,'Other mailing address')]")
    private WebElement otherMailingAddressRadioButtonLabel;

    @FindBy(css = "input[aria-label='Mailing Address']")
    private WebElement mailingAddressInputField;

    @FindBy(xpath = "//div[@id='formField_address']//mat-label")
    private WebElement mailingAddressInputLabel;

    @FindBy(xpath = "//div[@id='formField_address']//mat-error")
    private WebElement mailingAddressError;

    @FindBy(css = "input[aria-label='Apartment number (optional)']")
    private WebElement apartmentNumberInputField;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_apartment']//mat-label")
    private WebElement apartmentInputLabel;

    @FindBy(css = "input[aria-label='City']")
    private WebElement cityInputField;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_city']//mat-label")
    private WebElement cityInputLabel;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_city']//mat-error")
    private WebElement cityError;

    @FindBy(css = "mat-select[aria-label='State']")
    private WebElement stateDropDown;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-label")
    private WebElement stateDropDownLabel;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-error/div")
    private WebElement stateError;

    @FindBy(css = "input[aria-label='Zip code']")
    private WebElement zipCodeInputField;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//mat-label")
    private WebElement zipCodeInputLabel;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//mat-error/div")
    private WebElement zipCodeError;

    @FindBy(css = "p[class='tui-field-label-text mb-2']")
    private WebElement primaryNamedInsured;

    @FindBy(xpath = "//div[@class='auto-personal-info__fields-section']//li")
    private WebElement pniFullName;

    @FindBy(xpath = "//p[contains(.,'Contact information')]")
    private WebElement contactInformation;

    @FindBy(xpath = "//div[@id='flex-field-emailAddress_contactInfo']/p")
    private WebElement personalInfoLabel;

    @FindBy(xpath = "//div[@class='email-address']//label")
    private WebElement emailAddressFieldLabel;

    private static final String EMAIL_ADDRESS_INPUT_FIELD_XPATH = "//div[@id='flex-field-emailAddress_contactInfo']//input";
    @FindBy(xpath = EMAIL_ADDRESS_INPUT_FIELD_XPATH)
    private WebElement emailAddressInput;

    @FindBy(xpath = "//div[@id='flex-field-emailAddress_contactInfo']//mat-error")
    private WebElement emailAddressError;

    @FindBy(xpath = "//div[@id='flex-field-phoneNumber_contactInfo']//label")
    private WebElement mobilePhoneFieldLabel;

    @FindBy(xpath = "//div[@id='flex-field-phoneNumber_contactInfo']//input")
    private WebElement phoneNumberInput;

    @FindBy(xpath = "//div[@id='flex-field-phoneNumber_contactInfo']//mat-error")
    private WebElement phoneNumberError;

    @FindBy(xpath = "//a[contains(.,'ESIGN')]")
    private WebElement esignTermsAndConditionsLink;

    @FindBy(css = "div[class='brand-selection']>p[class='tui-field-label']")
    private WebElement chooseFromInsuranceCompaniesTitle;

    @FindBy(xpath = "//mat-checkbox[contains(@class,'mat-checkbox tui-stacking')]")
    private WebElement selectAllCheckbox;

    @FindBy(xpath = "//mat-label[contains(@class,'tui-field-label brand-label tui-stacking')]")
    private WebElement selectAllCheckboxLabel;

    @FindBy(css = "div[class='brand-selection']>p[class='tui-small-text checkbox-description']")
    private WebElement chooseThemIndividuallyBelow;

    @FindBy(xpath = "//div[@class='tui-stacking-top-sm ms-8 ng-star-inserted']//mat-checkbox")
    private List<WebElement> brandCheckboxes;

    @FindBy(xpath = "//div[@class='tui-stacking-top-sm ms-8 ng-star-inserted']//mat-label")
    private List<WebElement> brandCheckboxLabels;

    @FindBy(xpath = "//div[@class='tui-stacking-top-sm ms-8 ng-star-inserted']//p")
    private List<WebElement> brandCheckboxLabelDescriptions;

    @FindBy(xpath = "//span[contains(.,'Text me a link')]")
    private WebElement textMeALinkCheckboxLabel;

    @FindBy(xpath = "//mat-checkbox/following-sibling::p")
    private WebElement textAuthorization;

    @FindBy(xpath = "//p[contains(.,'terms')]/a")
    private WebElement termsConditionLink;

    @FindBy(xpath = "//div[contains(@class,'contact-info-cta-validation')]")
    private WebElement pageErrorMessage;

    @FindBy(css = "span[class='contactEsignDisclaimer']")
    private WebElement contactEsignDisclaimer;

    @FindBy(css = "p:has(span[class='contactInfoDisclaimer'])")
    private WebElement contactInfoDisclaimer;

    @FindBy(xpath = "//a[contains(.,'associated')]")
    private WebElement associatedEntititesLink;

    @FindBy(xpath = "//p[contains(@class,'consent-disclaimer disclaimer-mobile-view-Margin')]/span[1]")
    private WebElement mobileDisclaimerAddition;

    @FindBy(xpath = "//button[contains(@class,'tui-btn tui-btn-primary submit-button')]")
    private WebElement agreeAndSubmitButton;

    @FindBy(xpath = "//span[contains(.,'forget to make your selection(s).')]")
    private WebElement dontForgetMakeYourSelection;

    @FindBy(xpath = "//button[contains(@class,'tui-btn tui-btn-primary continue-button')]")
    private WebElement continueButton;

    @FindBy(css = "button[class='auto-agent-details__save-link tui-link-button']")
    private WebElement saveQuoteButton;

    @FindBy(xpath = "//div[contains(@class,'save-in-progress-section')]/p")
    private WebElement progressSavedSection;

    @FindBy(xpath = "//img[@alt='Bristol West logo' and contains(@src,'svg')]")
    private WebElement bristolWestLogoImage;

    @FindBy(xpath = "//app-rc2-loading//h1")
    private WebElement rc2Screen_MainHeading;

    @FindBy(xpath = "//app-rc2-loading//div[contains(.,'Based on the information')]")
    private WebElement rc2SubHeading;

    @FindBy(xpath = "//*[contains(text(), 'reviewing your auto details now, then getting questions ready for your property policy.')]")
    private WebElement rc2SubHeading1ForBundle;

    @FindBy(xpath = "//*[contains(text(), 'Based on the information you provided and your current coverage,')]")
    private WebElement rc2SubHeading2ForBundle;

    @FindBy(xpath = "//app-rc3-loading//h1")
    private WebElement rc3ScreenPageTitle;

    //div//span[contains(text(),' Checking eligibility ')]/preceding-sibling::span/mat-icon[contains(text(), 'done')]

    public boolean isOnRC2LoadingPage() {
        return isElementVisible(rc2Screen_MainHeading, 15);
    }

    public void setValuesAndContinue(AutoApplicant applicant) throws Exception {
        setValues(applicant);
        clickContactInfoPageCTAButton();
    }

    public void setValues(AutoApplicant applicant) throws Exception {
        isOnContactInfoAutoPage();
        if(applicant.getStateCode().equals(NJ)) {
            sendKeysToElement(policyStartDateInputField, getFormattedForPolicyStartDate(LocalDate.now().plusDays(30)));
        }
        if(applicant.getStateCode().equals(VA)) {
            sendKeysToElement(policyStartDateInputField, getFormattedForPolicyStartDate(LocalDate.now().plusDays(50)));
        }
        if (applicant.isMailingAddressDifferent()) {
            scrollAndClickOnElement(otherMailingAddressRadioButton);
            enterValueInField(applicant.getGaragingAddress(), waitElementBeVisible(mailingAddressInputField), "Entering applicant's mailing address");
            enterValueInField(applicant.getCity(), waitElementBeVisible(cityInputField), "Entering applicant's city");
            selectValueInDropDown(waitElementBeVisible(stateDropDown), applicant.getStateCode());
            enterValueInField(applicant.getZipCode(), waitElementBeVisible(zipCodeInputField), "Entering applicant's zip code");
        }
        fillOutPrimaryResidenceInsuranceSection(applicant.getStateCode().equals(MA));
        fillOutBundleAndSave(applicant);
        if (applicant.getTestScenario().contains("_YESUMB_")) {
            Log.info("Capture umbrella bundle status" + NEWLINE, applicant.getTestScenario() + "UmbrellaStatus");
        }
        enterEmailAndPhoneNumber(applicant.getEmail(), applicant.getPhoneNumber());

        processConsentSelection("Farmers");
    }

    public void enterValuesForBundleAutoQuoteAndContinue(AutoApplicant applicant) throws Exception {
    	if (!isSignalDiscountDisabledState(applicant.getStateCode())) {
            sendKeysToPolicyStartDateInputField(applicant.getCurrentInsuranceExpirationDate());
    	}
        if (applicant.isMailingAddressDifferent()) {
            scrollAndClickOnElement(otherMailingAddressRadioButton);
            enterValueInField(applicant.getGaragingAddress(), waitElementBeVisible(mailingAddressInputField), "Entering applicant's mailing address");
            enterValueInField(applicant.getCity(), waitElementBeVisible(cityInputField), "Entering applicant's city");
            selectValueInDropDown(waitElementBeVisible(stateDropDown), applicant.getStateCode());
            enterValueInField(applicant.getZipCode(), waitElementBeVisible(zipCodeInputField), "Entering applicant's zip code");
        }
        fillOutPrimaryResidenceInsuranceSection(applicant.getStateCode().equals(MA));
        enterEmailAndPhoneNumber(applicant.getEmail(), applicant.getPhoneNumber());
        processConsentSelection("Farmers");
        if (isElementDisplayed(policyStartDateInputField, 2)) {
        	String policyStartDate =  getAutoPolicyStartDateValue();
        	if (!policyStartDate.equals(EMPTY_STRING)) {
        		applicant.setCurrentInsuranceExpirationDate(policyStartDate.replaceAll("[^0-9]", EMPTY_STRING));
        	}
        }
        clickContactInfoPageCTAButton();
    }

    public void setValuesAndContinue() throws Exception {
        isOnContactInfoAutoPage();
        if(getSessionStorageAppStore().getData().getLandingStateCode().equals(VA)) {
            sendKeysToElement(policyStartDateInputField, getFormattedForPolicyStartDate(LocalDate.now().plusDays(50)));
        }
        fillOutPrimaryResidenceInsuranceSection(getSessionStorageAppStore().getData().getLandingStateCode().equals(MA));
        String phoneNumber = new Faker().phoneNumber().phoneNumber().replaceAll("\\D", "");
        enterEmailAndPhoneNumber(generateEmailAddress(), phoneNumber);
        clickContactInfoPageCTAButton();
    }

    public void fillOutPrimaryResidenceInsuranceSection(boolean sectionExpected) throws Exception {
        if (sectionExpected) {
            WebElement randomPrimaryResidenceRadioButton = primaryResidenceInsuranceRadioButtons.get(new Random().nextInt(primaryResidenceInsuranceRadioButtons.size()));
            scrollAndClickOnHiddenElement(randomPrimaryResidenceRadioButton);
        }
    }

    public boolean doesPrimaryResidenceSelectionGivesError() {
        return getAttributeData(primaryResidenceInsuranceRadioButtonGroup, CLASS).contains("invalid");
    }

    public void enterEmailAndPhoneNumber(String emailId, String phoneNumber) {
        scrollElementToMiddle(otherMailingAddressRadioButton);
        if (isElementVisible(emailAddressInput, 1)) {
            scrollElementToMiddle(emailAddressInput);
            enterEmailId(emailId);
            enterPhoneNumber(phoneNumber);
        }
    }

    public void enterPhoneNumber(String phoneNumber) {
        isOnContactInfoAutoPage();
        scrollElementToMiddle(phoneNumberInput);
        enterValueInField(phoneNumber, phoneNumberInput, "Entering customer phone number");
        sendKeysToElement(phoneNumberInput, Keys.TAB);
    }

    public boolean isContactInfoSectionPresent() {
        return isElementVisible(emailAddressInput, 1);
    }

    public void fillOutPhoneInputFieldOneByOne(String phoneNumber) {
        sendKeysOneByOne(phoneNumberInput, phoneNumber, true);
    }

    public void clearOutInputField(WebElement element) {
        while (!getAttributeData(element, VALUE).equals(EMPTY_STRING)) {
            sendKeysToElement(element, Keys.BACK_SPACE);
        }
    }

    public void enterEmailId(String emailId) {
        scrollAndClickOnElement(emailAddressInput);
        sendKeysToElement(emailAddressInput, emailId);
    }

    @SneakyThrows
    public void fillOutBundleAndSave(AutoApplicant applicant) {
        if (isBDQFlowEnabled()) {
            return;
        }
        List<SqlDiscount> discounts = applicant.getDiscounts();
        if (!discounts.isEmpty()) {
            if (isElementDisplayed(By.xpath(VIEW_ADDITIONAL_PRODUCTS_XPATH))) {
                waitAndClickElement(viewAdditionProductsLink);
            }
            // Skip in case of default coverage testing
            if (!applicant.getTestScenario().contains("UMB") && !Property.getTestProperty("suite").contains(AUTO_COVERAGE_VALIDATION)) {
                SqlDiscount discount = discounts.stream().findFirst().get();
                selectBundle(discount.isBusinessInsurance(), "Business");
                selectBundle(discount.isCondoInsurance(), "Condo");
                selectBundle(discount.isHomeInsurance(), "Home");
                selectBundle(discount.isValueTermLifeInsurance(), "Life");
                selectBundle(discount.isMotorcycleInsurance(), "Motorcycle");
                selectBundle(discount.isRecreationalBoatWatercraftInsurance(), "Recreational Boat/Watercraft");
                if (!isHomeowner(applicant)) {
                    selectBundle(discount.isRentersInsurance(), "Renters");
                }
                selectBundle(discount.isUmbrellaInsurance(), "Umbrella");
            }
        }
    }

    public void clickContactInfoPageCTAButton() throws Exception {
        scrollToBottomOfPage();
        if (isElementVisible(continueButton, 3)) {
            scrollElementToMiddle(continueButton);
            waitAndClickElement(continueButton);
        } else {
            scrollElementToMiddle(agreeAndSubmitButton);
            clickElement(agreeAndSubmitButton);
        }
    }

    /**
     * Constructor.
     *
     * @throws Exception
     */

    public ContactInfoAutoPage() throws Exception {
    }

    public void validateErrorMessages(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        //validate policy start date field error messages
        if (!applicant.getStateCode().equals(CA)) {
            // policy start date is not applicable for CA state
            validatePolicyStartDateErrorMessages(fsa);
        }
        //required field error messages validation
        validateRequiredFieldErrorMessages(fsa);
        //validate invalid entries
        validateInvalidEntriesErrorMessages(fsa);
    }

    public void validateRequiredFieldErrorMessages(FarmersSoftAssert fsa) throws Exception {
        driver().navigate().refresh();
        final String PLEASE_ENTER_YOUR = "Please enter your ";
        scrollAndClickOnElement(otherMailingAddressRadioButton);
        clickContactInfoPageCTAButton();
        if (isContactInfoSectionPresent()) {
            fsa.assertEquals(getTextFromElement(emailAddressError), PLEASE_ENTER_YOUR + "email address.", "Email address error message");
            fsa.assertEquals(getTextFromElement(phoneNumberError), PLEASE_ENTER_YOUR + "phone number.", "Phone number error message");
        }
        fsa.assertEquals(getTextFromElement(pageErrorMessage), CTA_ERROR_MESSAGE, "CTA error message");
        fsa.assertEquals(getTextFromElement(cityError), PLEASE_ENTER_YOUR + "city.", "City error message");
        fsa.assertEquals(getTextFromElement(stateError), PLEASE_ENTER_YOUR + "state.", "State error message");
        fsa.assertEquals(getTextFromElement(zipCodeError), PLEASE_ENTER_YOUR + "ZIP code.", "Zip code error message");
    }

    private void validateInvalidEntriesErrorMessages(FarmersSoftAssert fsa) throws Exception {
        driver().navigate().refresh();
        final String IS_NOT_VALID_ENTRY = "is not a valid entry.";

        if (isContactInfoSectionPresent()) {
            //invalid email format
            waitAndClickElement(emailAddressInput);
            sendKeysToElement(emailAddressInput, "invalidEmail@");
            emailAddressInput.sendKeys(Keys.TAB);
            final String EXPECTED_INVALID_EMAIL_ADDRESS_ERROR = "Email address entered is invalid";
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(emailAddressError)), EXPECTED_INVALID_EMAIL_ADDRESS_ERROR, "Invalid email format");

            //invalid domain --validate email call should fail
            waitAndClickElement(emailAddressInput);
            sendKeysToElement(emailAddressInput, "invalidemail_123@yopmael.com");
            waitAndClickElement(phoneNumberInput);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(emailAddressError)), EXPECTED_INVALID_EMAIL_ADDRESS_ERROR, "Invalid email domain");

            //invalid phone number
            String invalidPhone = "(123) 456-6796";
            sendKeysToElement(phoneNumberInput, invalidPhone);
            phoneNumberInput.sendKeys(Keys.TAB);
            fsa.assertEquals(getTextFromElement(phoneNumberError), String.format("%s %s", invalidPhone, IS_NOT_VALID_ENTRY), "Invalid phone number");
        }

        scrollAndClickOnElement(otherMailingAddressRadioButton);

        //invalid zipcode entry
        sendKeysToElement(zipCodeInputField, "1234" + Keys.ESCAPE);
        cityInputField.sendKeys(Keys.TAB);
        fsa.assertEquals(getTextFromElement(zipCodeError), "Please enter a 5 digit ZIP Code.", "Incomplete zip code");

    }

    public void validatePageContent(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        validatePageHeaderAndHeaderNote(fsa);
        validatePolicyStartDateSection(fsa);
        validateSaveBundleInfoSection(fsa);
        validateMailingAddressSection(applicant, fsa);
        validateEmailPhoneNumberSection(fsa);
        validateDisclaimers(fsa);
        validateOtherMailingAddressSection(fsa);
        //validatePrimaryNameInsuredSection(fsa);
        validateLinks(fsa);
        validate_RC2LoadingScreen(fsa);
    }

    public void validateDisclaimers(FarmersSoftAssert fsa) throws Exception {
        if (isElementVisible(emailAddressInput, 2)) {
            fsa.assertEquals(getTextFromElement(contactEsignDisclaimer), EXPECTED_ESIGN_DISCLAIMER, "ESign disclaimer content");
            fsa.assertEquals(getTextFromElement(contactInfoDisclaimer), EXPECTED_CTA_DISCLAIMER, "Contact info disclaimer content");
        } else {
            fsa.assertEquals(getTextFromElement(continueButton), "Continue", "Continue button label");
        }
    }

    private void validateMailingAddressSection(AutoApplicant applicant, FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(mailingAddressLabel)), EXPECTED_MAILING_ADDRESS_LABEL, "Mailing address label validation");

        String streetNumber = applicant.getResidentAddress().split(" ")[0];
        fsa.assertTrue(getTextFromElement(defaultMailingAddressRadioButtonLabel).contains(streetNumber), "Mailing address street number validation");
        fsa.assertEquals(getAttributeData(waitElementBeVisible(otherMailingAddressRadioButtonLabel), "innerText").strip(), "Other mailing address", "Other mailing addres label");
    }

    private void validateOtherMailingAddressSection(FarmersSoftAssert fsa) {
        //validate labels and fields under other mailing address
        scrollAndClickOnElement(otherMailingAddressRadioButton);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(mailingAddressInputLabel)), "Mailing Address", "Other mailing address: Mailing address label validation");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(apartmentInputLabel)), "Unit #", "Unit number label");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(cityInputLabel)), "City", "City label");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(stateDropDownLabel)), "State", "State label");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(zipCodeInputLabel)), "ZIP", "Zip code label");
    }

    private void validateFarmersInsuranceGroupSection(FarmersSoftAssert fsa) throws Exception {
        if (!isElementVisible(contactInformation, 2)) {
            return;
        }
        fsa.assertEquals(getTextFromElement(chooseFromInsuranceCompaniesTitle), CHOOSE_FARMERS_INSURANCE_GROUP_BRANDS, "Farmers group section title validation");
        fsa.assertEquals(getTextFromElement(selectAllCheckboxLabel), "Select all parties, or ...");
        fsa.assertEquals(getTextFromElement(chooseThemIndividuallyBelow), "Choose them individually below:");
        fsa.assertTrue(selectAllCheckbox.isDisplayed() && selectAllCheckbox.isEnabled(), "Validate select all checkbox is displayed and enabled");

        List<String> expectedGroupNames = Arrays.asList("Farmers\u00ae", "Bristol West\u00ae");
        List<String> expectedGroupDescriptions = Arrays.asList("Auto, property, umbrella, business, financial services, and more", "Commercial and non-standard auto");

        Log.info("Expected group labels: " + expectedGroupNames);
        Log.info("Expected group descriptions: " + expectedGroupDescriptions);
        for (WebElement brandCheckbox : brandCheckboxes) {
            fsa.assertTrue(brandCheckbox.isDisplayed() && brandCheckbox.isEnabled(), "Validate each brand checkbox is displayed and enabled");
        }
        List<String> displayedGroupNames = brandCheckboxLabels.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> displayedGroupDescriptions = brandCheckboxLabelDescriptions.stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(displayedGroupNames, expectedGroupNames, "Group names validation");
        fsa.assertEquals(displayedGroupDescriptions, expectedGroupDescriptions, "Group description validation");
    }

    private void validateLinks(FarmersSoftAssert fsa) throws Exception {
        if (isElementVisible(contactInformation, 2)) {
            fsa.assertTrue(associatedEntititesLink.isDisplayed() && associatedEntititesLink.isEnabled(), "Assosiciated entities link is displayed and enabled");
            fsa.assertTrue(esignTermsAndConditionsLink.isDisplayed() && esignTermsAndConditionsLink.isEnabled(), "Esign terms and conditions link is displayed and enabled");
            verifyLinkNavigation(fsa, esignTermsAndConditionsLink, "Electronic Terms & Conditions : Farmers Insurance");
            verifyLinkNavigation(fsa, associatedEntititesLink, "Our Companies : About Farmers : Farmers Insurance");
        }
    }

    private String verifyLinkNavigation(FarmersSoftAssert fsa, WebElement linkToVerify, String expectedTitle) throws Exception {
        waitAndClickElement(linkToVerify);
        wait.until(ExpectedConditions.numberOfWindowsToBe(2));
        Set<String> windowHandles = driver().getWindowHandles();
        String currentWindowHandle = driver().getWindowHandle();
        // Switch to the next tab (second tab)
        for (String handle : windowHandles) {
            if (!handle.equals(currentWindowHandle)) {
                driver().switchTo().window(handle);
                break;
            }
        }
        wait.until(ExpectedConditions.titleContains("Farmers Insurance"));
        fsa.assertTrue(driver().getTitle().equals(expectedTitle), expectedTitle + " page opened");
        driver().close();
        driver().switchTo().window(currentWindowHandle);
        return currentWindowHandle;
    }

    private void validatePrimaryNameInsuredSection(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(primaryNamedInsured), "Primary named insured", "Primary named insured label validated");
        AppStore.Data.CustomerData customerData = getSessionStorageAppStore().getData().getCustomerData();
        String pniFullName = customerData.getFirstName() + SPACE + customerData.getLastName();
        fsa.assertEquals(getTextFromElement(this.pniFullName), pniFullName, "Pni full name is validated");
    }

    private void validateSaveBundleInfoSection(FarmersSoftAssert fsa) throws Exception {
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(bundleAndSaveInfoIcon);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(mobileEarlyDiscountInfoTitle)), "How it works", "Bundle discount title mobile");
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(mobileEarlyDiscountInfoDescription)), isOnBristolWest() ? EXPECTED__BUNDLE_AND_SAVE_INFO_DESCRIPTION.replace("You will have to ", "You will have 45 days to ") : EXPECTED__BUNDLE_AND_SAVE_INFO_DESCRIPTION, "Bundle discount message mobile break point");
            waitAndClickElement(closeInfoDialogIcon);
        } else {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleSaveHelpInfoHeader)), EXPECTED_BUNDLE_AND_SAVE_INFO_TITLE, "Bundle discount title browser");
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleSaveHelpInfoDescription)), isOnBristolWest() ? EXPECTED__BUNDLE_AND_SAVE_INFO_DESCRIPTION.replace("You will have to ", "You will have 45 days to ") : EXPECTED__BUNDLE_AND_SAVE_INFO_DESCRIPTION, "Bundle discount message browser");
        }
    }

    private void validatePageHeaderAndHeaderNote(FarmersSoftAssert fsa) {
        String actualPageHeader = getTextFromElement(waitElementBeVisible(pageHeader));
        String actualPageHeaderNote = getTextFromElement(pageHeaderNote);
        fsa.assertTrue(actualPageHeader.equals(EXPECTED_HEADER_1) || actualPageHeader.equals(EXPECTED_HEADER_2), "Contact info page header should be either of the following: " + EXPECTED_HEADER_1 + " or " + EXPECTED_HEADER_2);
        fsa.assertTrue(actualPageHeaderNote.equals(EXPECTED_HEADER_NOTE_1) || actualPageHeaderNote.equals(EXPECTED_HEADER_NOTE_2), "Contact info page header note should be either of the following: " + EXPECTED_HEADER_NOTE_1 + " or " + EXPECTED_HEADER_NOTE_2);
   }

    private void validatePolicyStartDateSection(FarmersSoftAssert fsa) throws Exception {
        if (getSessionStorageAppStore().getData().getLandingStateCode().equals(CA)) {
            return;
        }
        String actualText = getTextFromElement(policyStartDateTitle);

        fsa.assertTrue(actualText.equals(EXPECTED_POLICY_START_DATE_TITLE_1) || actualText.equals(EXPECTED_POLICY_START_DATE_TITLE_2), "Policy effective date header should be either of the following two: " + EXPECTED_POLICY_START_DATE_TITLE_1 + " or " + EXPECTED_POLICY_START_DATE_TITLE_2 + " but found: " + actualText);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(datePickerFieldLabel)), EXPECTED_DATE_PICKER_AREA_LABEL);

        validateHelpInfoSectionForEarlyShopper(fsa);

        LocalDate now = LocalDate.now();
        sendKeysToElement(policyStartDateInputField, getFormattedForPolicyStartDate(now.plusDays(3)));
        sleep(1);
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        if (!landingStateCode.equals(FL)) {
            if(isElementDisplayed(earlyShoppingBanner,2)){

                fsa.assertEquals(getTextFromElement(earlyShoppingBannerHeader), EXPECTED_WARN_BANNER_HEADER, "Early shopping banner Header validation");
                fsa.assertEquals(getTextFromElement(earlyShoppingBannerDesc), EXPECTED_WARN_BANNER_DESCRIPTION, "Early shopping banner description validation");
            }
            else {
                fsa.assertTrue(isSnackBarMessageDisplayed("arly shopping discount"), "Early shopping discount snackbar removal message is displayed");
            }
        }
        sendKeysToPolicyStartDateInputField(getFormattedForPolicyStartDate(now.plusDays(7)));
        sendTab(policyStartDateInputField);
        if (!landingStateCode.equals(FL)) {
            if (isElementDisplayed(earlyShoppingBanner, 2)) {

                fsa.assertEquals(getTextFromElement(earlyShoppingBannerHeader), EXPECTED_DISCOUNT_BANNER_HEADER, "Early shopping banner Header validation");
                fsa.assertEquals(getTextFromElement(earlyShoppingBannerDesc), EXPECTED_DISCOUNT_BANNER_DESCRIPTION, "Early shopping banner description validation");
            } else {
                fsa.assertTrue(isSnackBarMessageDisplayed("arly shopping discount"), "Early shopping discount snackbar addition message is displayed");
            }
        }
    }

    public void sendKeysToPolicyStartDateInputField(String date) {
        scrollElementToMiddle(policyStartDateInputField);
        sendKeysToElement(policyStartDateInputField, date);
    }

    private void validateEmailPhoneNumberSection(FarmersSoftAssert fsa) {
        if (isElementDisplayed(personalInfoLabel, 3)) {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(personalInfoLabel)), EXPECTED_PERSONAL_INFO_LABEL);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(emailAddressFieldLabel)), "Email address");
            scrollToElement(waitElementBeVisible(mobilePhoneFieldLabel));
            fsa.assertEquals(getTextFromElement(mobilePhoneFieldLabel), "Mobile phone");
            scrollToElement(agreeAndSubmitButton);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(agreeAndSubmitButton)), "Agree and submit");

        } else {
            fsa.assertEquals(getTextFromElement(continueButton), "Continue", "CTA button should have proper text");
        }
    }

    private void validateHelpInfoSectionForEarlyShopper(FarmersSoftAssert fsa) throws Exception {
        boolean isFLState = getSessionStorageAppStore().getData().getLandingStateCode().equals(FL);
        if (isOnBristolWest()) {
            Log.info("Early shopper discount is not applicable for Bristol West brand");
            return;
        }
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(mobileEarlyDiscountInfoIcon);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(mobileEarlyDiscountInfoTitle)), EXPECTED_EARLY_SHOPPER_INFO_TITLE);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(mobileEarlyDiscountInfoDescription)), EXPECTED_EARLY_SHOPPER_INFO_DESCRIPTION, "Early shopper discount message mobile break point");
            waitAndClickElement(closeInfoDialogIcon);
        } else {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountInfoTitle)), EXPECTED_EARLY_SHOPPER_INFO_TITLE);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountInfoDescription)), EXPECTED_EARLY_SHOPPER_INFO_DESCRIPTION, "Early shopper discount message browser");
        }
    }

    public void validateEarlyShopperDiscount(FarmersSoftAssert fsa) throws Exception {
        if (getSessionStorageAppStore().getData().getLandingStateCode().equals(CA)) {
            return;
        }
        LocalDate today = LocalDate.now(); //today
        //Today, invalid policy start date
        String formattedToday = getFormattedForPolicyStartDate(today);
        sendKeysToElement(waitElementBeVisible(policyStartDateInputField), formattedToday);
        waitAndClickElement(policyStartDateTitle);
        String pleaseSelectYourPolicy = "Please select your policy effective date between ";
        String expectedPolicyStartDateError = pleaseSelectYourPolicy + getFormattedForPolicyStartDate(today.plusDays(1)) + " and " + getFormattedForPolicyStartDate(today.plusDays(59)) + PERIOD;
        fsa.assertEquals(getTextFromElement(policyStartDateError), expectedPolicyStartDateError, "Invalid policy start date error");
        sleep(3);
        // From tomorrow, seven days later to 30 days, eligible for discounts
        LocalDate sevenDaysLater = todayPlus8Days();
        String formattedSevenDaysLater = getFormattedForPolicyStartDate(sevenDaysLater);
        sendKeysToElement(policyStartDateInputField, formattedSevenDaysLater);
        waitAndClickElement(pageHeaderNote);
        validateHelpInfoSectionForEarlyShopper(fsa);
        if(isElementDisplayed(earlyShoppingBanner,2)){

            fsa.assertEquals(getTextFromElement(earlyShoppingBannerHeader), EXPECTED_DISCOUNT_BANNER_HEADER, "Early shopping banner Header validation");
            fsa.assertEquals(getTextFromElement(earlyShoppingBannerDesc), EXPECTED_DISCOUNT_BANNER_DESCRIPTION, "Early shopping banner description validation");
        }
        else {
            fsa.assertTrue(isSnackBarMessageDisplayed("arly shopping discount"), "7 - 60 days eligible for discount");
        }
        sleep(3);
        // six days later (before seven days), no early shopping discount
        LocalDate sixDaysLater = todayPlus6Days();
        String formattedSixDaysLater = getFormattedForPolicyStartDate(sixDaysLater);
        sendKeysToElement(policyStartDateInputField, formattedSixDaysLater);
        waitAndClickElement(pageHeaderNote);
        if(isElementDisplayed(earlyShoppingBanner,2)){

            fsa.assertEquals(getTextFromElement(earlyShoppingBannerHeader), EXPECTED_WARN_BANNER_HEADER, "Early shopping banner Header validation");
            fsa.assertEquals(getTextFromElement(earlyShoppingBannerDesc), EXPECTED_WARN_BANNER_DESCRIPTION, "Early shopping banner description validation");
        }
        else {
            fsa.assertTrue(isSnackBarMessageDisplayed("remove"), "7 - 60 days eligible for discount");
        }
        sleep(3);
        fsa.assertTrue(driver().findElements(By.xpath("//div[@id='policyStartDateDiv']//mat-icon[contains(@class,'tui-info-box')]")).isEmpty(), "Policy start date info box icon should not appear");
        sleep(3);
        // From tomorrow, seven days later to 30 days, eligible for discounts
        LocalDate fiftyNineDays = todayPlus59Days();
        String formattedFiftyNineDays = getFormattedForPolicyStartDate(fiftyNineDays);
        sendKeysToElement(policyStartDateInputField, formattedFiftyNineDays);
        waitAndClickElement(pageHeader);
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(mobileEarlyDiscountInfoIcon);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(mobileEarlyDiscountInfoTitle)), EXPECTED_EARLY_SHOPPER_INFO_TITLE, "Early shopper discount message mobile break point");
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(mobileEarlyDiscountInfoDescription)), EXPECTED_EARLY_SHOPPER_INFO_DESCRIPTION, "Early shopper discount message mobile break point");
            waitAndClickElement(closeInfoDialogIcon);
        } else {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountInfoTitle)), EXPECTED_EARLY_SHOPPER_INFO_TITLE, "Early shopper discount message Browser");
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountInfoDescription)), EXPECTED_EARLY_SHOPPER_INFO_DESCRIPTION, "Early shopper discount message Browser");
            if(isElementDisplayed(earlyShoppingBanner,2)){

                fsa.assertEquals(getTextFromElement(earlyShoppingBannerHeader), EXPECTED_DISCOUNT_BANNER_HEADER, "Early shopping banner Header validation");
                fsa.assertEquals(getTextFromElement(earlyShoppingBannerDesc), EXPECTED_DISCOUNT_BANNER_DESCRIPTION, "Early shopping banner description validation");
            }
            else
            {
                fsa.assertTrue(isSnackBarMessageDisplayed("arly shopping discount"), "Early shopping discount snackbar message");
            }


        }
    }

    public void validatePolicyStartDateErrorMessages(FarmersSoftAssert fsa) throws Exception {
        LocalDate today = LocalDate.now();
        //Today, invalid policy start date
        String formattedToday = getFormattedForPolicyStartDate(today);
        sendKeysToElement(waitElementBeVisible(policyStartDateInputField), formattedToday);
        policyStartDateInputField.sendKeys(Keys.TAB);
        String expectedPolicyStartDateError = "Please select your policy effective date between " + getFormattedForPolicyStartDate(today.plusDays(1)) + " and " + getFormattedForPolicyStartDate(today.plusDays(59)) + PERIOD;
        fsa.assertEquals(getTextFromElement(policyStartDateError), expectedPolicyStartDateError);
        sleep(1);
        String formatted60DaysLater = getFormattedForPolicyStartDate(today.plusDays(60));
        sendKeysToElement(policyStartDateInputField, formatted60DaysLater);
        policyStartDateInputField.sendKeys(Keys.TAB);
        fsa.assertEquals(getTextFromElement(policyStartDateError), expectedPolicyStartDateError);

        sendKeysToElement(policyStartDateInputField, getFormattedForPolicyStartDate(today.plusDays(1)));

    }

    public void validateBundleSaveSection(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String expectedHeader = "Save more when you bundle";
        String expectedHeaderNote = "Select which eligible Farmers products you would like to bundle with:";
        String expectedSingularCongratulationMessage = "Nice! You are eligible for a discount when you bundle";
        String expectedPluralCongratulationMessage = "Nice! You are eligible for a discounts when you bundle";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleSaveHeading)), expectedHeader, "Bundle Save section header");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleSaveHeadingNote)), expectedHeaderNote, "Bundle Save section header note is not as expected");

        // validate bundle discount message is not displayed when user does not select any bundle
        fsa.assertFalse(isElementPresent(By.xpath(BUNDLE_CONRATS_MESSAGE_XPATH)), "'" + expectedPluralCongratulationMessage + "' text should not be displayed before selecting bundle item");

        if (viewAdditionProductsLink.isDisplayed()) {
            waitAndClickElement(viewAdditionProductsLink);
        }

        // validate the list of the checkboxes
        if(!isOnBristolWest()) { // this validation is only applicable for Farmers brand, not Bristol West
            List<String> expectedBundleOptions = FfqBundleOptions.getBundleOptions(applicant, isHomeowner(applicant));
            if (applicant.getStateCode().equals(MS)) {
                expectedBundleOptions.remove(FfqBundleOptions.UMBRELLA.getBundleLob());
                expectedBundleOptions.remove(FfqBundleOptions.BUSINESS.getBundleLob());
            }
            if(applicant.getStateCode().equals(CA)) {
                expectedBundleOptions.remove(FfqBundleOptions.CONDO.getBundleLob());
            }

            List<String> actualBundleOptions = saveBundleCheckboxes.stream().map(each -> getAttributeData(each, "innerText").strip()).collect(Collectors.toList());
            fsa.assertTrue(actualBundleOptions.containsAll(expectedBundleOptions) && expectedBundleOptions.containsAll(actualBundleOptions), String.format("List of actual value - %s are not same as List of expected - %s", actualBundleOptions, expectedBundleOptions));
        }

        // validate that bundle checkboxes clickable and singular congratulation message
    	int numberOfElements = saveBundleInputs.size();
        for (int i =0; i < numberOfElements; i++){
            WebElement saveBundleInput = saveBundleInputs.get(i);
            scrollAndClickOnElement(saveBundleInput);
            sleep(1);
            fsa.assertTrue(isSnackBarMessageDisplayed("add"), "Bundle and save snackbar discount addition message displayed");
            fsa.assertTrue(isCheckboxSelected(saveBundleInput), "Checkbox should be checked after clicking on it");
            clickElement(saveBundleInput);
            sleep(1);
            fsa.assertTrue(isSnackBarMessageDisplayed("removed"), "Bundle and save snackbar discount addition message removed");
            fsa.assertTrue(isCheckboxNotSelected(saveBundleInput), "Checkbox should not be checked after clicking on it the second time");
        }

        // validate plural congratulation message
        if (numberOfElements >1) {
        	WebElement firstInputElement = saveBundleInputs.get(0);
        	WebElement secondInputElement = saveBundleInputs.get(1);
        	scrollAndClickOnElement(firstInputElement);
        	scrollAndClickOnElement(secondInputElement);
        	fsa.assertTrue(isSnackBarMessageDisplayed("add"));
        	fsa.assertTrue(isCheckboxSelected(firstInputElement), "Checkbox should be checked after clicking on it");
        	fsa.assertTrue(isCheckboxSelected(secondInputElement), "Checkbox should be checked after clicking on it");
        	// unclick one item
        	clickElement(secondInputElement);
            sleep(1);
            fsa.assertTrue(isSnackBarMessageDisplayed("removed"), "Bundle and save snackbar discount addition message removed");
            fsa.assertTrue(isCheckboxNotSelected(secondInputElement), "Checkbox should not be checked after clicking on it the second time");
        }
    }

    public void validatePrefilledValuesAndContinue(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(pageHeader), EXPECTED_HEADER_1, "Contact Info page - Page Header.");
        if (!getSessionStorageAppStore().getData().getLandingStateCode().equals(CA)) {
            String policyStartDateTitleActual = getTextFromElement(policyStartDateTitle);
            fsa.assertTrue(policyStartDateTitleActual.equals(EXPECTED_POLICY_START_DATE_TITLE_1) || policyStartDateTitleActual.equals(EXPECTED_POLICY_START_DATE_TITLE_2), "Policy start date title is not matching. Displayed: " + policyStartDateTitleActual);
            fsa.assertEquals(getTextFromElement(datePickerFieldLabel), EXPECTED_DATE_PICKER_AREA_LABEL, "Contact Info page - Date picker area label.");
            fsa.assertEquals(getElementValue(policyStartDateInputField, "element value: ").trim(), getFormattedForPolicyStartDate(LocalDate.now().plusDays(14)),
                    "Contact Info page - Policy start date.");
        }
        if (isHomeowner(applicant)) {
            WebElement homeBundleCheck = driver().findElement(By.xpath(bundleCheckboxesXpath + "[contains(.,'Home')]//mat-checkbox"));
            fsa.assertTrue(isElementPresent(By.xpath(bundleCheckboxesXpath + "[contains(.,'Condo')]//mat-checkbox")), "Condo checkbox should be displayed for homeowner");
            String homeBundleCheckboxClass = getAttributeData(homeBundleCheck, CLASS);
            fsa.assertTrue(homeBundleCheckboxClass.contains(MAT_CHECKBOX_CHECKED), "Contact Info page - Home Bundle checkbox is checked.");
            fsa.assertTrue(homeBundleCheckboxClass.contains(MAT_CHECKBOX_DISABLED), "Contact Info page - Home Bundle checkbox is disabled.");
        }
        String streetNumber = applicant.getResidentAddress().split(SPACE)[0].strip();
        fsa.assertTrue(getTextFromElement(defaultMailingAddressRadioButtonLabel).startsWith(streetNumber),
                "Contact Info page - Residence address starts with expected street number: " + streetNumber);
        final String EXPECTED_OTHER_MAILING_ADDRESS_LABEL = "Other mailing address";
        fsa.assertEquals(getAttributeData(otherMailingAddressRadioButtonLabel, "innerText").strip(), EXPECTED_OTHER_MAILING_ADDRESS_LABEL, "Contact Info page - Other mailing address label.");

        fsa.assertEquals(getTextFromElement(contactInformation), EXPECTED_PERSONAL_INFO_LABEL, "Contact Info page - Expected Personal Info label.");
        fsa.assertEquals(getTextFromElement(emailAddressFieldLabel), EXPECTED_EMAIL_ADDRESS_FIELD_LABEL, "Contact Info page - Email address label.");
        fsa.assertEquals(getElementValue(emailAddressInput, "element value: ").trim(), applicant.getEmail(), "Contact Info page - Email address.");
        fsa.assertEquals(getTextFromElement(mobilePhoneFieldLabel), EXPECTED_MOBILE_PHONE_FIELD_LABEL, "Contact Info page - Mobile phone label.");
        fsa.assertEquals(getElementValue(phoneNumberInput, "element value: ").trim(), getFormattedPhoneNumber(applicant.getPhoneNumber()),
                "Contact Info page - Phone number.");
        if (isHomeowner(applicant)) {
            fsa.assertFalse(emailAddressInput.isEnabled(), "Contact Info page - Email address field is disabled.");
            fsa.assertFalse(phoneNumberInput.isEnabled(), "Contact Info page - Mobile phone field is disabled.");
        } else {
            fsa.assertTrue(emailAddressInput.isEnabled(), "Contact Info page - Email address field is enabled.");
            fsa.assertTrue(phoneNumberInput.isEnabled(), "Contact Info page - Mobile phone field is enabled.");
        }

        // validate disclaimers
        fsa.assertEquals(getTextFromElement(contactInfoDisclaimer), EXPECTED_CTA_DISCLAIMER, "Contact Info page - Page disclaimer/footer.");
        final String EXPECTED_CTA_TEXT = "Agree and submit";
        fsa.assertEquals(getTextFromElement(agreeAndSubmitButton), EXPECTED_CTA_TEXT, "Contact Info page - Agree and submit button label.");
        String EXPECTED_QUOTE_PROGESS_SAVED = "Auto quote progress is saved";
        fsa.assertEquals(getTextFromElement(progressSavedSection), EXPECTED_QUOTE_PROGESS_SAVED, "Contact Info page - Auto quote progress is saved.");
        fillOutPrimaryResidenceInsuranceSection(applicant.getStateCode().equals(MA));
        // continue
        clickContactInfoPageCTAButton();
    }

    public void enterDefaultEmailAndPhoneNumberAndContinue() throws Exception {
        isOnContactInfoAutoPage();
        if (isContactInfoSectionPresent()) {
            waitAndClickElement(emailAddressInput);
            enterValueInField(generateEmailAddress(), emailAddressInput, "Enter generated email address");
            enterValueInField("3105550000", phoneNumberInput, "Enter dummy phone number");
            sendKeysToElement(phoneNumberInput, Keys.TAB);
            //processConsentSelection("Farmers");
        }
        clickContactInfoPageCTAButton();
    }

    public boolean isOnContactInfoAutoPage() {
        return isElementVisible(pageHeaderNote, 25);
    }

    public boolean isOnBundlePolicyStartDatePage() {
        return isElementVisible(policyStartDateTitle, 15);
    }

    public boolean isOnOtherAutoPolicyDetailsPage() {
    	return isElementPresent(By.xpath(OTHER_MAILING_ADDRESS_RADIO_BUTTON_XPATH), 5);
    }

    public boolean isBwLogoImageDisplayed() {
        return isElementDisplayed(bristolWestLogoImage, 1);
    }

    public void validateADA_ContactInfoAutoPage() throws Exception {
        if (!isADATestingEnabled()) return;
        isOnContactInfoAutoPage();
        waitAndClickElement(viewAdditionProductsLink);
        scrollAndClickOnElement(otherMailingAddressRadioButton);
        waitAndClickElement(agreeAndSubmitButton);
        performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
        driver().navigate().refresh();
        isOnContactInfoAutoPage();
    }

    public void validatePrefillValues(AutoApplicant applicant) {
        if (isElementVisible(emailAddressInput, 1)) { // if element is not present it means this section is provided in some other places due to A/B testing
            testStepAssert(getElementValue(emailAddressInput, EXPECTED_EMAIL_ADDRESS_FIELD_LABEL), applicant.getEmail(), "Email input is matching");
            testStepAssert(getElementValue(phoneNumberInput, "Phone number").replaceAll("[^0-9]", EMPTY_STRING), applicant.getPhoneNumber().replaceAll("[^0-9]", EMPTY_STRING).substring(0, 10), "Phone number is matching");
        }
    }

    public void validateGroupSelectionFunctionality(FarmersSoftAssert fsa) throws Exception {

        if (!isElementVisible(contactInformation, 2)) {
            return;
        }
        // click select all and validate all is checked
        waitAndClickElement(selectAllCheckbox);
        sleep(1);
        for (WebElement brandCheckbox : brandCheckboxes) {
            fsa.assertTrue(wait.until(ExpectedConditions.attributeContains(brandCheckbox, CLASS, CHECKED)), "Validate each group is selected when select all is clicked for the first time");
        }

        int randomIndex = new Random().nextInt(brandCheckboxes.size());
        WebElement randomCheckbox = brandCheckboxes.get(randomIndex);
        waitAndClickElement(randomCheckbox);
        sleep(1);
        fsa.assertFalse(randomCheckbox.isSelected(), "Checkbox is selected");

        fsa.assertFalse(selectAllCheckbox.isSelected(), "Select all checkbox should be selected");

        waitAndClickElement(selectAllCheckbox);
        sleep(1);
        for (WebElement brandCheckbox : brandCheckboxes) {
            fsa.assertTrue(wait.until(ExpectedConditions.attributeContains(brandCheckbox, CLASS, CHECKED)), "Validate each group is selected when select all is clicked for the second time");
        }
        waitAndClickElement(selectAllCheckbox);
        sleep(1);
        for (WebElement brandCheckbox : brandCheckboxes) {
            fsa.assertFalse(brandCheckbox.isSelected(), "Validate each group is selected when select all is clicked");
        }

        brandCheckboxes.forEach(this::waitAndClickElement);
        sleep(1);
        fsa.assertTrue(wait.until(ExpectedConditions.attributeContains(selectAllCheckbox, CLASS, CHECKED)), "Select all should be selected when all indivuadually seelected");

    }

    public void validateConsentBrandSelection(AutoApplicant applicant) throws Exception {
        if (!isElementVisible(contactInformation, 2)) {
            //if consent is taken before this page, test is not valid
            return;
        }
        clickContactInfoPageCTAButton();
        testStepAssert(getTextFromElement(waitElementBeVisible(brandSelectionErrorMessage)), EXPECTED_BRAND_SELECTION_ERROR_MESSAGE, "Error message is thrown for not selecting brand");
        driver().navigate().refresh();
        isOnContactInfoAutoPage();
        fillOutPrimaryResidenceInsuranceSection(applicant.getStateCode().equals(MA));
        fillOutBundleAndSave(applicant);
        enterEmailAndPhoneNumber(applicant.getEmail(), applicant.getPhoneNumber());
        clickContactInfoPageCTAButton();
        testStepAssert(getTextFromElement(waitElementBeVisible(brandSelectionErrorMessage)), EXPECTED_BRAND_SELECTION_ERROR_MESSAGE, "Error message is thrown for not selecting brand");
        testStepAssert(getTextFromElement(waitElementBeVisible(pageErrorMessage)), CTA_ERROR_MESSAGE, "CTA error message for not selecting brand");
    }

    public void verifyAutoHRCBundlePageContent(FarmersSoftAssert fsa, String stateCode) throws Exception {
    	String observedHeader = getTextFromElement(pageHeader);
        fsa.assertTrue(List.of("Other auto policy details", "Auto policy start date").contains(observedHeader), "Bundle auto policy start date page title verification");
        if(!stateCode.equals(CA)){
            fsa.assertEquals(getTextFromElement(policyStartDateTitle), "When would you like your auto policy to begin?", "Bundle auto policy start date field label verification");
            fsa.assertEquals(getTextFromElement(policyStartDateInputFieldPlaceHolderText), "Auto policy start date", "Bundle auto policy start date field place holder text verification");
        }
        fsa.assertTrue(saveBundleCheckboxes.isEmpty(), "Bundle LOBs section is not displayed");
    }

    public void validate_RC2LoadingScreen(FarmersSoftAssert fsa) throws Exception {

        driver().navigate().refresh();
        isOnContactInfoAutoPage();
        setValuesAndContinue();
        fsa.assertTrue(isOnRC2LoadingPage(), "User is on the RC2 Loading page");

        //validating Page content
        fsa.assertEquals(getTextFromElement(rc2Screen_MainHeading), ONE_MOMENT_PLEASE, "RC2 Loading page main heading is not displayed");
        fsa.assertEquals(getTextFromElement(rc2SubHeading), RC2_PAGE_SUBTITLE, "RC2 Loading page sub heading is not displayed");
        validateRC2ScreenGreenCheckMark(fsa);
    }
    public void validateRC2ScreenBundle(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isOnRC2LoadingPage(), "User is on the RC2 Loading page");
        fsa.assertEquals(getTextFromElement(rc2Screen_MainHeading), ONE_MOMENT_PLEASE, "RC2 Loading page main heading validation");
        fsa.assertEquals(rc2SubHeading1ForBundle.isDisplayed(), true, "RC2 Loading page bundle sub heading 1 validation");
        fsa.assertEquals(rc2SubHeading2ForBundle.isDisplayed(), true, "RC2 Loading page bundle sub heading 2 validation");
        validateRC2ScreenGreenCheckMark(fsa);
        testStep("RC2 - Bundle loading page content is validated");
    }

    public void validateRC2ScreenGreenCheckMark(FarmersSoftAssert fsa) throws Exception {
        String checkingEligibility = "Checking eligibility";
        String calculatingYourRate = "Calculating your rate";
        String finishingUp = "Finishing up";
        String rc2PageLabelsXpath = "//span[@class='rc2_loading_screen_label_text' and contains(.,'%s')]";
        fsa.assertTrue(isElementDisplayed(By.xpath(String.format(rc2PageLabelsXpath, checkingEligibility))), checkingEligibility + " text validation");
        fsa.assertTrue(isElementDisplayed(By.xpath(String.format(rc2PageLabelsXpath, calculatingYourRate))), calculatingYourRate + " text validation");
        fsa.assertTrue(isElementDisplayed(By.xpath(String.format(rc2PageLabelsXpath, finishingUp))), finishingUp + " text validation");
    }
    public void waitForRC2ScreenToFinish() {
        if (isOnRC2LoadingPage()) {
            longWaitForElementToBeGoneByXpath("//app-rc2-loading");
        } else {
        	if (isElementVisibleAndClickable(rc3ScreenPageTitle, 3)) {
                longWaitForElementToBeGoneByXpath("//app-rc3-loading");
        	}
        }
    }

    public void validateDefaultBundleOption_MDMdata(AutoApplicant applicant) throws Exception {
        testStepAssert(isOnContactInfoAutoPage(), "User successfully landed on ContactInfoPage");
        List<WebElement> bundleOptions = checkedBundleOptions;
        for (WebElement bundle : bundleOptions) {
            if (getAttributeData(bundle, CLASS).contains(CHECKED)) {
                testStep("Bundle option selected defaultly");
                Thread.sleep(3000);
                WebElement bundleName = driver().findElement(By.xpath("//div[@class='save-bundle-discount-sheet']//div/span[contains(text(),'Umbrella')]"));
                Log.info(getTextFromElement(bundleName) + " bundle option selected default with MDM data");
            }
        }
    }

    public void validateBDQSpecificRule(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {

        fsa.assertTrue(isOnContactInfoAutoPage(), "user is on the Contact Info Auto page");
        //US879588: BDQ Ace - Policy Start Date
        fsa.assertTrue(isOnBristolWest(), "User should be on the BW");
        //fsa.assertEquals(getTextFromElement(policyStartDateInputField), getFormattedForPolicyStartDate(LocalDate.now()), "Policy start date should default to today");

        // validate bundle and save section is not visible for BDQ
        fsa.assertFalse(isElementPresent(By.xpath("//app-save-bundle-sheet"), 1), "Save Bundle section should not be available for BDQ");

        // validate today should be enabled for policy start date
        scrollAndClickOnElement(datePickerButton);
        LocalDate now = LocalDate.now();
        String displayMonthName = now.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
        int dayOfMonth = now.getDayOfMonth();
        String previousMonthXpath = "//button[@aria-label='Previous month' and not(contains(@class,'disabled'))]";
        if (isElementPresent(By.xpath(previousMonthXpath), 2)) {
            WebElement previousMonth = driver().findElement(By.xpath(previousMonthXpath));
            waitAndClickElement(previousMonth);
            sleep(1);
        }
        WebElement todayDateFromDatePicker = driver().findElement(By.xpath(String.format("//td//button[contains(@aria-label,'%s %s,')]", displayMonthName, dayOfMonth)));
        fsa.assertTrue(!getAttributeData(todayDateFromDatePicker, CLASS).contains("disabled"), "Today should be enabled for policy start date in BDQ flow");
        waitAndClickElement(todayDateFromDatePicker);

        // validate early shopper and help info not displayed for bdq
        if (isUseMobileViewEnabled()) {
            fsa.assertFalse(isElementVisible(mobileEarlyDiscountInfoIcon, 1), "Early shopper help info is not present");
        } else {
            fsa.assertFalse(isElementVisible(earlyDiscountInfoTitle, 1), "Early shopper help info is not present");
        }

        // Validate Disclaimer contents, Quote number and save quote button should be present in the Contact Info page.
        fsa.assertTrue(quoteNumber.isDisplayed(), "Quote number displayed on the " + this.getClass().getSimpleName());
        fsa.assertTrue(saveQuoteButton.isDisplayed(), "Save quote button displayed on the " + this.getClass().getSimpleName());

        validateValidateAndFooterForBDQ(fsa, applicant, this);

        fsa.assertFalse(isDiscountSectionDisplayed(), "Discount section should not be displayed on " + this.getClass().getSimpleName());

        validateAgentSectionBDQ(fsa, applicant);

    }

    public QuoteSummaryAutoPage navigateFromContactInfoPageToQuotePage(boolean continueWithFarmers) throws Exception {
        clickContactInfoPageCTAButton();
        waitForSpinnerToBeGone();
        SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
        if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
            selectAQuoteToReviewPage.clickContinueMyQuote();
        }
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if (bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            if (continueWithFarmers) {
                bwFarmersQuotePresentmentPage.continueWithFarmers();
            } else {
                bwFarmersQuotePresentmentPage.continueWithBw();
            }
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
        }
        AutoRentersBundleOfferingPage  autoRentersBundleOfferingPage = new AutoRentersBundleOfferingPage();
        if (autoRentersBundleOfferingPage.isOnAutoRentersBundleOfferingPage()) {
            autoRentersBundleOfferingPage.processRentersBundleOfferingPage(false);
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User was not able to land on the quote page");
        return quoteSummaryAutoPage;
    }

    public boolean qualifiesForAdditionalDiscountsPagePresent() {
    	return isElementPresent(By.xpath("//div[contains(@class, 'additional-discounts_container')]"), 3);
    }

    public String getAutoPolicyStartDateValue() {
        return getElementValue(policyStartDateInputField, "Policy start date").trim();
    }

    public void uncheckAllTheBundleCheckbox(){
        int numberOfElements = saveBundleInputs.size();
        for (int i =0; i < numberOfElements; i++){
            WebElement saveBundleInput = saveBundleInputs.get(i);
            if(isButtonSelected(saveBundleInput)) {
                scrollAndClickOnElement(waitElementBeVisible(saveBundleInput));
            }
        }
    }
}
