package com.farmers.ffq.ace.mobilehome;

import static com.farmers.ffq.utils.GlobalVariables.AWS_SCENARIOS;
import static com.farmers.ffq.utils.GlobalVariables.EMPTY_STRING;
import static com.farmers.ffq.utils.GlobalVariables.FFQ_MOBILE_HOME;
import static com.farmers.ffq.utils.GlobalVariables.FOREMOST;
import static com.farmers.ffq.utils.GlobalVariables.HOME;
import static com.farmers.ffq.utils.GlobalVariables.LARGE;
import static com.farmers.ffq.utils.GlobalVariables.LOB_MOBILE_HOME;
import static com.farmers.ffq.utils.GlobalVariables.MARKETING_IT;
import static com.farmers.ffq.utils.GlobalVariables.MEDIA_ALPHA;
import static com.farmers.ffq.utils.GlobalVariables.MOBILE_MANUFACTURED_HOME;
import static com.farmers.ffq.utils.GlobalVariables.NEWLINE;
import static com.farmers.ffq.utils.GlobalVariables.SPACE;
import static com.farmers.ffq.utils.GlobalVariables.USAA;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.SkipException;

import com.farmers.ffq.ace.hrc.common.AceHRCPropertyTypeBasePage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.common.pages.MediaAlphaPageHome;
import com.farmers.ffq.common.pages.MediaAlphaStartPage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class AceMobileHomeNavigationHelper extends BasePage {
	private static final String ACE_MOBILE_HOME = "Mobile Home - ";
	private static final String DID_NOT_REACH = "Did not reach ";
	private static final String FOR_QUOTE = " for quote ";

	private String mobileHomeQuoteNumber = EMPTY_STRING;
	private String resumeFromPage = EMPTY_STRING;
	@FindBy(xpath = "//tui-oneui-footer")
	private WebElement footer;


	public AceMobileHomeNavigationHelper() throws Exception {
		super();
	}

	public AceMobileQuoteReviewPage navigateToQuotePage(ApplicantAceHome mobilehomeApplicant) throws Exception {
		AceMobileQuoteReviewPage quoteReviewPage = new AceMobileQuoteReviewPage(mobilehomeApplicant);
		if (getResumeFromPage().equals(quoteReviewPage.getClass().getSimpleName())) {
			return quoteReviewPage;
		} else {
			AceMobileHomeLastStepPage lastStepPage = navigateToLastStepPage(mobilehomeApplicant);
			lastStepPage.fillOutLastStepPageAndContinue(mobilehomeApplicant);
		}
		if (quoteReviewPage.isOnMobileHomeQuotePage()) {
			Reporter.pass("Navigated to Mobile Home quote review page");
			writeRatedQuoteInformationToFile(ACE_MOBILE_HOME + getMobileHomeQuoteNumber() + SPACE + mobilehomeApplicant);
			if (isADATestingEnabled()) {
				performADATesting(quoteReviewPage.getClass().getSimpleName(), MARKETING_IT, FFQ_MOBILE_HOME);
				screenCapture(footer, quoteReviewPage.getClass().getSimpleName(), LARGE, false);
			}
			return quoteReviewPage;
		} else {
			throw new NavigationException(quoteReviewPage.getClass().getSimpleName(), mobilehomeApplicant);
		}
	}

	public AceMobileHomeLastStepPage navigateToLastStepPage(ApplicantAceHome mobilehomeApplicant) throws Exception {
		AceMobileHomeLastStepPage lastStepPage = new AceMobileHomeLastStepPage();
		if (getResumeFromPage().equals(lastStepPage.getClass().getSimpleName())) {
			return lastStepPage;
		} else {
			AceMobileHomeAboutYouPage aboutYouPage = navigateToAboutYouPage(mobilehomeApplicant);
			aboutYouPage.fillOutApplicantFormWithValues(mobilehomeApplicant.getFirstName(), mobilehomeApplicant.getLastName(), mobilehomeApplicant.getDateOfBirth());
			try {
				waitForSpinnerToBeGone();
			} catch (TimeoutException te) {
				//Sometimes this page gets stuck, try it again
				driver().navigate().refresh();
				aboutYouPage.fillOutApplicantFormWithValues(mobilehomeApplicant.getFirstName(), mobilehomeApplicant.getLastName(), mobilehomeApplicant.getDateOfBirth());
				waitForSpinnerToBeGone();
			}
		}
		if (lastStepPage.isOnContactInfoPage(false)) {
			Reporter.pass("Navigated to Mobile Home Last step page");
			if (isADATestingEnabled()) {
				lastStepPage.scrollAndClickOnContinueButton();
				performADATesting(lastStepPage.getClass().getSimpleName(), MARKETING_IT, FFQ_MOBILE_HOME);
				screenCapture(footer, lastStepPage.getClass().getSimpleName(), LARGE, false);
			}
			return lastStepPage;
		} else {
			throw new NavigationException(lastStepPage.getClass().getSimpleName(), mobilehomeApplicant);
		}
	}

	public AceMobileHomeAboutYouPage navigateToAboutYouPage(ApplicantAceHome mobilehomeApplicant) throws Exception {
		AceMobileHomeAboutYouPage aboutYouPage = new AceMobileHomeAboutYouPage();
		if (getResumeFromPage().equals(aboutYouPage.getClass().getSimpleName())) {
			return aboutYouPage;
		} else {
			AceMobileHomeTellUsMorePage tellUsMorePagePage = navigateToTellUsMorePage(mobilehomeApplicant);
			tellUsMorePagePage.fillOutPageAndContinue(mobilehomeApplicant);
		}
		if (aboutYouPage.isOnAboutYouPage(false)) {
			Reporter.pass("Navigated to Mobile Home About you page");
			if (isADATestingEnabled()) {
				aboutYouPage.scrollAndClickOnContinueButton();
				performADATesting(aboutYouPage.getClass().getSimpleName(), MARKETING_IT, FFQ_MOBILE_HOME);
				screenCapture(footer, aboutYouPage.getClass().getSimpleName(), LARGE, false);
			}
			return aboutYouPage;
		} else {
			throw new NavigationException(aboutYouPage.getClass().getSimpleName(), mobilehomeApplicant);
		}
	}

	public AceMobileHomeTellUsMorePage navigateToTellUsMorePage(ApplicantAceHome mobilehomeApplicant) throws Exception {
		AceMobileHomeTellUsMorePage tellUsMorePage = new AceMobileHomeTellUsMorePage();
		if (getResumeFromPage().equals(tellUsMorePage.getClass().getSimpleName())) {
			return tellUsMorePage;
		} else {
			AceMobileHomeAddressPage addressPage = navigateToAddressPage(mobilehomeApplicant);
			addressPage.fillOutPageAndContinue(mobilehomeApplicant);
		}
		if (tellUsMorePage.isOnTellUsMorePage()) {
			Reporter.pass("Navigated to Mobile Home Tell us more page");
			if (isADATestingEnabled()) {
				tellUsMorePage.scrollAndClickOnContinueButton();
				performADATesting(tellUsMorePage.getClass().getSimpleName(), MARKETING_IT, FFQ_MOBILE_HOME);
				screenCapture(footer, tellUsMorePage.getClass().getSimpleName(), LARGE, false);
			}
			return tellUsMorePage;
		} else {
			throw new NavigationException(tellUsMorePage.getClass().getSimpleName(), mobilehomeApplicant);
		}
	}

	public AceMobileHomeAddressPage navigateToAddressPage(ApplicantAceHome mobilehomeApplicant) throws Exception {
		launchApplication(mobilehomeApplicant);
		setMobileHomeQuoteNumber(getQuoteNumberFromStorage());
		mobilehomeApplicant.setQuoteNumber(getMobileHomeQuoteNumber());
		AceMobileHomeAddressPage addressPage = new AceMobileHomeAddressPage();
		if (addressPage.isOnAddressPage()) {
			writeCreatedQuoteInformationToFile(ACE_MOBILE_HOME + getMobileHomeQuoteNumber() + SPACE + mobilehomeApplicant);
			Reporter.pass("Navigated to Mobile Home address page for quote "+  getMobileHomeQuoteNumber());
			if (isADATestingEnabled()) {
				addressPage.clickContinueButton();
				performADATesting(addressPage.getClass().getSimpleName(), MARKETING_IT, FFQ_MOBILE_HOME);
				screenCapture(footer, addressPage.getClass().getSimpleName(), LARGE, false);
			}
			return addressPage;
		} else {
			throw new NavigationException(addressPage.getClass().getSimpleName(), mobilehomeApplicant);
		}
	}

	private void launchApplication(ApplicantAceHome mobilehomeApplicant) throws Exception {
		String launchMode = mobilehomeApplicant.getTestCategory();
		if (launchMode.equals(MEDIA_ALPHA)) {
			new MediaAlphaStartPage().processMediaAlphaStartPage(mobilehomeApplicant.getZipCode(), HOME);
			MediaAlphaPageHome mediaAlphaPageHome = new MediaAlphaPageHome();
			if (mediaAlphaPageHome.isOnMediaAlphaPageHome()) {
				Reporter.pass("Application launched in Media Alpha mode");
				mediaAlphaPageHome.enterHomeApplicantData(mobilehomeApplicant);
				AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
				propertyTypePage.waitForSpinnerToBeGone();
				if (propertyTypePage.isOnPropertyTypePage()) {
					propertyTypePage.acceptCookies();
					propertyTypePage.selectPropertyType(MOBILE_MANUFACTURED_HOME);
					propertyTypePage.clickAgreeAndSubmitButton();
					propertyTypePage.waitForSpinnerToBeGone();
				} else {
					throw new NavigationException(propertyTypePage.getClass().getSimpleName(), mobilehomeApplicant);
				}
			} else {
				throw new NavigationException("Media Alpha Home Page", mobilehomeApplicant);
			}
		} else {
			boolean useForemost = launchMode.equals(FOREMOST);
			boolean useUSAA = launchMode.equals(USAA);
			boolean useAWS = launchMode.equals(AWS_SCENARIOS);
			LandingPage landingPage = useAWS || useForemost || useUSAA? new LandingPage(mobilehomeApplicant) : new LandingPage(isUseMobileViewEnabled(), true);
			if (useForemost) {
				Reporter.pass("Application launched in Foremost");
				new AceMobileHomeAddressPage().waitForQuoteLoaderToBeGone();
			} else {
				landingPage.enterLandingPageDataAndContinue(LOB_MOBILE_HOME, mobilehomeApplicant.getZipCode());
				if (useAWS) {
					Reporter.pass("Application launched in AWS mode");
				} else if (useUSAA) {
					Reporter.pass("Application launched in USAA mode");
				}
			}
		}
	}

	public boolean retrieveMobilehomeQuote(ApplicantAceHome mobilehomeApplicant, String quoteNumber) throws Exception {
		boolean quoteRetrieved = false;
		LandingPage ffqLandingPage = new LandingPage(isUseMobileViewEnabled());
		ffqLandingPage.retrieveQuoteFromLandingPage(mobilehomeApplicant.getLastName(), mobilehomeApplicant.getDateOfBirth(), quoteNumber, mobilehomeApplicant.getZipCode());
		if (!ffqLandingPage.isQuoteNotFoundPopUpPresent()) {
			Reporter.pass("Retrieved quote " + quoteNumber);
			quoteRetrieved = true;
		}
		return quoteRetrieved;
	}

	private String getQuoteNumberFromStorage() throws Exception {
		String quoteNumber = EMPTY_STRING;
		if (getItemFromSessionStorage("appStore") != null) {
			quoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
		}
		if (quoteNumber==null) {
			quoteNumber = EMPTY_STRING;
		}
		return quoteNumber;
	}

	private class NavigationException extends Exception {
		private static final long serialVersionUID = 1L;

		public NavigationException(String originatingPage, ApplicantAceHome mobilehomeApplicant) throws Exception {
			String message = DID_NOT_REACH + originatingPage + FOR_QUOTE + getMobileHomeQuoteNumber() + NEWLINE;
			try {
				ObjectMapper mapper = new ObjectMapper();
				mapper.enable(SerializationFeature.INDENT_OUTPUT);
				String json = mapper.writeValueAsString(getSessionStorageAppStore());
				writeDataToQuoteLogFile(message + " : " + json);
			} catch (Exception e) {
				Log.warn("EXCEPTION while beautifying appstore");
				writeDataToQuoteLogFile(message + " Exception - : " + getSessionStorageAppStore());
			}
			StringBuilder errorMessageString = new StringBuilder();
			AppStore.Home home = getSessionStorageAppStore().getHome();
			if (home != null) {
				if (home.getQuote()!= null && home.getQuote().getRateQuoteResponses() !=null && home.getQuote().getRateQuoteResponses().get(0).getKnockOutBeanList() != null) {
					errorMessageString.append(home.getQuote().getRateQuoteResponses().get(0).getKnockOutBeanList().get(0).toString() + SPACE);
				} else  {
					getErrorInformation(errorMessageString);
				}
			} else {
				getErrorInformation(errorMessageString);
			}
			if (!errorMessageString.toString().isEmpty()) {
				message =  message + " -- Knocked out reason: " +  errorMessageString.toString();
			}
			writeDataToKnockoutLogFile(ACE_MOBILE_HOME + getMobileHomeQuoteNumber() + SPACE + mobilehomeApplicant + " - " + message);
			//Special case when this condition is present
			if (message.contains("Wind Hail Exclusion") && new KnockoutInconveniencePage().isOnForemostKnockoutPage()) {
				throw new SkipException("Wind Hail Exclusion returned, quote knocked out");
			}
			throw new IllegalStateException(message);
		}

		private void getErrorInformation(StringBuilder errorMessageString) throws Exception {
			AppStore.Error error = getSessionStorageAppStore().getError();
			if (error != null && error.getErrorInfo() != null  && error.getErrorInfo().getErrorCode() != null) {
				String errorMessage = error.getErrorInfo().getErrorMessage() != null ? error.getErrorInfo().getErrorMessage() :
					error.getMessage() != null? error.getMessage() : EMPTY_STRING;
				errorMessageString.append(error.getErrorInfo().getErrorCode() + ": " + errorMessage);
			}
		}
	}

}
