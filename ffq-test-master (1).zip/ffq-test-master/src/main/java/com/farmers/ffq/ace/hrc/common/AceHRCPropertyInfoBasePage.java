package com.farmers.ffq.ace.hrc.common;

import com.farmers.ffq.common.pages.FGIALandingPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.farmers.ffq.common.pages.FfqAceBasePage.NOT_ALLOWED_SPECIAL_AND_ALPHABETIC_CHARACTERS;
import static com.farmers.ffq.common.pages.FfqAceBasePage.NOT_ALLOWED_SPECIAL_CHARACTERS;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCPropertyInfoBasePage extends AceHRCBasePage {

	@FindBy(xpath = "//app-home-property-info//div[contains(@class,'home-property-info__container')]//h1")
    protected WebElement propertyInfoPageTitle;
    protected static final String PAGE_TITLE = "Tell us more about your home";

    @FindBy(xpath = "//app-home-property-info//label[@id='homeTypeLabel']")
    protected WebElement homeTypeLabel;

    @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_DETACHED']")
    protected WebElement matRadioButtonSingleFamilyHome;
    @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_DETACHED']//input")
    protected WebElement inputSingleFamilyHome;

    @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_TOWNHOME']")
    protected WebElement matRadioButtonTownhome;
    @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_TOWNHOME']//input")
    protected WebElement inputButtonTownhome;

    @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_DUPLEX']")
    protected WebElement matRadioButtonDuplex;
    @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_TYPE_DUPLEX']//input")
    protected WebElement inputButtonDuplex;

    @FindBy(xpath = "//app-home-property-info//mat-radio-button[contains(@id,'HOME_TYPE')]")
    protected List<WebElement> propertyTypeMatRadioButtons;

    @FindBy(xpath = "//app-home-property-info//mat-radio-button[contains(@id,'HOME_TYPE')]//label")
    protected List<WebElement> propertyTypeLabels;

    @FindBy(xpath = "//app-home-property-info//mat-radio-button[contains(@id,'HOME_TYPE')]//label/span")
    protected List<WebElement> propertyTypeLabelDescriptions;

    @FindBy(xpath = "//app-home-property-info//label[@id='homeDurationLabel']")
    protected WebElement ownershipLengthLabel;

    @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_ONE']")
    protected WebElement matRadioButtonYearOrMore;
    @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_ONE']//input")
    protected WebElement inputYearOrMore;

    @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_ZERO']")
    protected WebElement matRadioButtonUnderOneYear;
    @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_ZERO']//input")
    protected WebElement inputUnderOneYear;

    @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_PENDING']")
    protected WebElement matRadioButtonPendingEscrow;
    @FindBy(xpath = "//app-home-property-info//mat-radio-button[@id='RADIO_BUTTON_FOR_HOME_DURATION_PENDING']//input")
    protected WebElement inputPendingEscrow;

    @FindBy(xpath = "//app-home-property-info//mat-radio-button[contains(@id,'HOME_DURATION')]")
    protected List<WebElement> ownershipLengths;

    @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//h2")
    protected WebElement claimsSubTitle;

    @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'None')]")
    protected WebElement matButtonToggleLossOfPropertyNone;
    @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'None')]/button")
    protected WebElement buttonToggleLossOfPropertyNone;

    @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'One')]")
    protected WebElement matButtonToggleLossOfPropertyOne;
    @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'One')]/button")
    protected WebElement buttonToggleLossOfPropertyOne;

    @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'Two or more')]")
    protected WebElement matButtonToggleLossOfPropertyTwoOrMore;
    @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle[contains(.,'Two or more')]/button")
    protected WebElement buttonToggleLossOfPropertyTwoOrMore;

    @FindBy(xpath = "//app-home-property-info//div[@id='lossOfProperty']//mat-button-toggle")
    protected List<WebElement> claimsCount;

    private static final String PRIOR_ADDRESS_LABEL_TEXT = "Please enter your previous home address";
    private static final String CURRENT_ADDRESS_LABEL_TEXT = "Please enter your current home address.";

    @FindBy(xpath = "//div[@id='priorCurrentAddress']/mat-card[contains(@class,'home-address-card')]")
    protected WebElement priorCurrentAddressCard;

    @FindBy(xpath = "//div[@id='priorCurrentAddress']/mat-card[contains(@class,'home-address-card')]//p[contains(@class,'tui-field-label-text')]")
    protected WebElement priorCurrentAddressLabel;

    @FindBy(xpath = "//div[@id='priorCurrentAddress']/mat-card[contains(@class,'home-address-card')]//input[contains(@class,'address-autocomplete-input')]")
    protected WebElement priorCurrentAddressInput;

    private static final List<String> PROPERTY_TYPES = List.of("Single-family home", "Townhome", "Duplex");
    private static final List<String> OWNERSHIP_LENGTH = List.of("A year or more", "Under one year", "Purchase pending (currently in escrow)");
    private static final List<String> CLAIMS_OPTIONS = List.of(NONE, "One", "Two or more");

    private static final String ADDRESS_FIELD_PLACEHOLDER_TEXT = "Home address";
    @FindBy(xpath = "//mat-label[contains(text(), '" + ADDRESS_FIELD_PLACEHOLDER_TEXT + "')]")
    private WebElement addressFieldPlaceHolderText;
    @FindBy(xpath = "//address-autocomplete-input//input")
    private WebElement priorOrCurrentAddressInputBox;

    @FindBy(xpath = "//mat-form-field[@id='auto-contact-info-city__input-field']//input")
    private WebElement priorOrCurrentAddressCityInputBox;
    @FindBy(xpath = "//mat-form-field[@id='state']//mat-select")
    private WebElement priorOrCurrentAddressStateSelect;
    @FindBy(xpath = "//mat-form-field[@id='auto-contact-info-zipCode__input-field']//input")
    private WebElement priorOrCurrentAddressZipInputBox;

    //address-autocomplete-input//mat-icon
    @FindBy(xpath = "//address-autocomplete-input//mat-icon")
    private WebElement closeIconInAddressInputBox;

    @FindBy(xpath = "//mat-form-field[@name='home-personal-info-apartment__input-field']//input")
    private WebElement unitInputBox;
    private static final String UNIT_NUMBER_PLACEHOLDER_TEXT = "Unit #";
    @FindBy(xpath = "//mat-label[contains(text(),'" + UNIT_NUMBER_PLACEHOLDER_TEXT + "')]")
    private WebElement unitNumberPlaceholderText;

    private static final String CITY_PLACEHOLDER_TEXT = "City";
    @FindBy(xpath = "//mat-label[contains(text(),'" + CITY_PLACEHOLDER_TEXT + "')]")
    private WebElement cityPlaceholderText;

    private static final String STATE_PLACEHOLDER_TEXT = "State";
    @FindBy(xpath = "//mat-label[contains(text(),'" + STATE_PLACEHOLDER_TEXT + "')]")
    private WebElement statePlaceholderText;

    private static final String ZIP_PLACEHOLDER_TEXT = "ZIP";
    @FindBy(xpath = "//mat-label[contains(text(),'" + ZIP_PLACEHOLDER_TEXT + "')]")
    private WebElement zipPlaceholderText;

    private static final String OPTIONAL_UNIT_NUMBER_HINT = "Optional";
    @FindBy(xpath = "//mat-hint[contains(text(),'" + OPTIONAL_UNIT_NUMBER_HINT + "')]")
    private WebElement optionalUnitNumberHint;

    private static final String PLEASE_ENTER_STREET_NUMBER_AND_NAME = "Please enter street number and name.";
    private static final String PLEASE_PROVIDE_YOUR_CITY_ERROR = "Please enter your city.";
    private static final String PLEASE_PROVIDE_YOUR_STATE_ERROR = "Please enter your state.";
    private static final String PLEASE_PROVIDE_YOUR_ZIP_ERROR = "Please enter your ZIP code.";
    private static final String PLEASE_PROVIDE_FIVE_DIGIT_ZIP_ERROR = "Please enter a 5 digit ZIP Code.";
    @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_ENTER_STREET_NUMBER_AND_NAME + "')]")
    private WebElement pleaseEnterYourStreetNumberAndNameError;
    @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_PROVIDE_YOUR_CITY_ERROR + "')]")
    private WebElement pleaseProvideYourCityError;
    @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_PROVIDE_YOUR_STATE_ERROR + "')]")
    private WebElement pleaseProvideYourStateError;
    @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_PROVIDE_YOUR_ZIP_ERROR + "')]")
    private WebElement pleaseProvideYourZipError;
    @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_PROVIDE_FIVE_DIGIT_ZIP_ERROR + "')]")
    private WebElement invalidInputZipError;
    @FindBy(xpath = "//address-autocomplete-input[@id='prior-address-autocomplete']//mat-error")
    private WebElement invalidInputAddressError;

    private static final String PLEASE_SELECT_ADDRESS_FROM_LIST_ERROR = "Please select an address from the list.";
    @FindBy(xpath = "//mat-error[contains(text(),'" + PLEASE_SELECT_ADDRESS_FROM_LIST_ERROR + "')]")
    private WebElement pleaseSelectAddressFromListError;
    private static final String SELECT_ADDRESS_FROM_LIST_ERROR = "Please select an address from the list.";
    @FindBy(xpath = "//mat-error[contains(text(),'" + SELECT_ADDRESS_FROM_LIST_ERROR + "')]")
    private WebElement selectAddressFromListError;
    @FindBy(xpath = "//mat-form-field[@name='home-personal-info-apartment__input-field']//mat-error[contains(text(),'" + INVALID_ENTRY + "')]")
    private WebElement unitNumberNotValidEntryError;
    /**
     * Default Constructor
     */
    public AceHRCPropertyInfoBasePage() throws Exception {
    }

    public boolean isOnPropertyInfoPage(boolean longWait) throws Exception {
        int timeout = longWait ? Property.PAGELOADTIMEOUT : 5;
        return isElementDisplayed(matButtonToggleLossOfPropertyNone, timeout);
    }

    public boolean isNewHomeSelected() {
        return getAttributeData(matRadioButtonUnderOneYear, CLASS).contains(CHECKED);
    }

    public boolean isNotNewHomeSelected() {
    	return getAttributeData(matRadioButtonYearOrMore, CLASS).contains(CHECKED);
    }

    public void selectNewHome(ApplicantAceHome applicant) throws Exception {
        if (applicant.isNewlyOwned()) {
            if (!isNewHomeSelected()) {
                clickElement(inputUnderOneYear);
                enterCurrentOrPriorAddress(applicant);
            }
        } else {
            if (!isNotNewHomeSelected()) {
                clickElement(inputYearOrMore);
            }
        }
    }

    public boolean isInEscrowSelected() {
        return getAttributeData(matRadioButtonPendingEscrow, CLASS).contains(CHECKED);
    }

    public void selectInEscrow(ApplicantAceHome applicant) throws Exception {
        if (!isInEscrowSelected()) {
            scrollAndClickOnHiddenElement(inputPendingEscrow);
            enterCurrentOrPriorAddress(applicant);
        }
    }

    public void selectOwnershipLength(int length) {
        scrollAndClickOnElement(ownershipLengths.get(length));
    }

    public void fillOutPropertyInfo(ApplicantAceHome applicant) throws Exception {
        if (applicant.isNewlyOwned() != isNewHomeSelected()) {
            selectNewHome(applicant);
        }
        if (applicant.isInEscrow()) {
            selectInEscrow(applicant);
        }
        clickContinueButton();
        waitForSpinnerToBeGone();
        if (isOnPropertyInfoPage(false)) {
            clickContinueButton();
        }
    }

    public boolean isPageTitleDisplayed() {
        return getTextFromElement(propertyInfoPageTitle).equals(PAGE_TITLE);
    }

    public boolean isPageTitleInViewport() throws Exception {
        return isElementInViewport(propertyInfoPageTitle);
    }

    public List<String> getPropertyTypes() {
        return propertyTypeLabels.stream().map(this::getNodeText).collect(Collectors.toList());
    }

    public List<String> getPropertyTypesInfo() {
        return propertyTypeLabelDescriptions.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    private String getSelectedOptionText(List<WebElement> options, String selectedClassToken, Function<WebElement, String> textExtractor) {
        return options.stream()
                .filter(option -> getAttributeData(option, CLASS).contains(selectedClassToken))
                .map(textExtractor)
                .findFirst()
                .orElse(EMPTY_STRING);
    }

    public String getSelectedPropertyType() {
        String selectedOption = getSelectedOptionText(propertyTypeMatRadioButtons, RADIO_BUTTON_CHECKED, this::getTextFromElement);
        if (!selectedOption.equals(EMPTY_STRING)) {
            List<String> displayedPropertyTypes = getPropertyTypes();
            for (int i = 0; i < PROPERTY_TYPES.size() && i < displayedPropertyTypes.size(); i++) {
                if (selectedOption.startsWith(PROPERTY_TYPES.get(i))) {
                    selectedOption = displayedPropertyTypes.get(i);
                    break;
                }
            }
        }
        return selectedOption;
    }

    public List<String> getOwnershipLengths() {
        return ownershipLengths.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public String getSelectedOwnershipLength() {
        return getSelectedOptionText(ownershipLengths, RADIO_BUTTON_CHECKED, this::getTextFromElement);
    }

    public List<String> getClaimsCount() {
        return claimsCount.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public String getSelectedClaimsNumber() {
        return getSelectedOptionText(claimsCount, TOGGLE_CHECKED, this::getTextFromElement);
    }

    public void validateContentOfPriorOrCurrentAddress(FarmersSoftAssert fsa) {
        try {
            AppStore.Home.AddlCustomerDetails customerDetails = getSessionStorageAppStore().getHome().getAddlCustomerDetails();
            String priorAddressStreetAppStore = customerDetails.getPriorOrCurrentAddress().getUserStrtAdd().strip();
            String priorAddressCityAppStore = customerDetails.getPriorOrCurrentAddress().getCity().strip();
            String priorAddressStateAppStore = customerDetails.getPriorOrCurrentAddress().getState().strip();
            String priorAddressZipAppStore = customerDetails.getPriorOrCurrentAddress().getZip().strip();

            String priorCurrentAddress = getValueFromWebElement(waitElementBeVisible(priorHomeAddressInputField, 2));
            fsa.assertEquals(priorCurrentAddress, priorAddressStreetAppStore, "Property info page - Current or prior address street.");
            String priorCurrentCity = getValueFromWebElement(waitElementBeVisible(priorHomeCityInputField, 2));
            fsa.assertEquals(priorCurrentCity, priorAddressCityAppStore, "Property info page - Current or prior address city.");
            String priorCurrentState = getTextFromElement(waitElementBeVisible(priorHomeStateSelectField, 2));
            fsa.assertEquals(priorCurrentState, priorAddressStateAppStore, "Property info page - Current or prior address state.");
            String priorCurrentZip = getValueFromWebElement(waitElementBeVisible(priorHomeZipInputField, 2));
            fsa.assertEquals(priorCurrentZip, priorAddressZipAppStore, "Property info page - Current or prior address zip.");
        } catch (Exception e) {
            String msg = "Unable to read prior/current address from appStore additional customer details: " + e.getMessage();
            Log.error(msg);
            fsa.fail(msg);
        }
    }

    public void validatePageFormFields(FarmersSoftAssert fsa, String propertyType) throws Exception {
        String PROPERTY_TYPE_SUBTITLE = "What kind of home is it?";
        List<String> PROPERTY_TYPE_INFO = List.of("Most common.", "Multi-story home attached to similar homes by shared walls.", "I own the entire structure, but only reside in one unit.");
        String OWNERSHIP_LENGTH_SUBTITLE = "How long have you owned this home?";
        String CLAIMS_SUBTITLE = "How many property claims have you filed in the last 3 years (at any address)?";

        if (propertyType.equals(HOME)) {
            fsa.assertEquals(getTextFromElement(homeTypeLabel), PROPERTY_TYPE_SUBTITLE, "Property info page - Property type label");
            fsa.assertEquals(getPropertyTypes(), PROPERTY_TYPES, "Property info page - Property info - radio buttons");
            fsa.assertEquals(getPropertyTypesInfo(), PROPERTY_TYPE_INFO, "Property info page - Property info - radio buttons information");
            fsa.assertEquals(getSelectedPropertyType(), PROPERTY_TYPES.get(0), "Property info page - Property info - selected button");
        }
        fsa.assertEquals(getTextFromElement(ownershipLengthLabel), OWNERSHIP_LENGTH_SUBTITLE, "Property info page - Ownership length label");
        fsa.assertEquals(getOwnershipLengths(), OWNERSHIP_LENGTH, "Property info page - Ownership length radio buttons");
        fsa.assertEquals(getSelectedOwnershipLength(), OWNERSHIP_LENGTH.get(0), "Property info page - Ownership length 'A year or more' selected radio button");

        fsa.assertEquals(getTextFromElement(claimsSubTitle), CLAIMS_SUBTITLE, "Property info page - Number of claims label");
        fsa.assertEquals(getClaimsCount(), CLAIMS_OPTIONS, "Property info page - Claims number toggle buttons");
        fsa.assertEquals(getSelectedClaimsNumber(), NONE, "Property info page - Claims number selected toggle button");

        selectOwnershipLength(1);
        fsa.assertEquals(getSelectedOwnershipLength(), OWNERSHIP_LENGTH.get(1), "Property info page - Ownership 'Under one year' selected");
        fsa.assertEquals(getTextFromElement(priorCurrentAddressLabel), PRIOR_ADDRESS_LABEL_TEXT, "Property info page - Prior address label text");
        validatePriorOrCurrentAddressFields(fsa);

        selectOwnershipLength(2);
        fsa.assertEquals(getSelectedOwnershipLength(), OWNERSHIP_LENGTH.get(2), "Property info page - Ownership 'Purchase pending (currently in escrow)' selected");
        fsa.assertEquals(getTextFromElement(priorCurrentAddressLabel), CURRENT_ADDRESS_LABEL_TEXT, "Property info page - Current address label text");
        validatePriorOrCurrentAddressFields(fsa);
        selectOwnershipLength(0);
    }

    public void checkSelectedValues(FarmersSoftAssert fsa, ApplicantAceHome applicant, String propertyType) {
        if (HOME.equals(propertyType)) {
            fsa.assertEquals(getSelectedPropertyType(), PROPERTY_TYPES.get(0), "Property info page - Selected property type match");
        }
        String ownershipLength = applicant.isNewlyOwned() ? OWNERSHIP_LENGTH.get(1) : OWNERSHIP_LENGTH.get(0);
        ownershipLength = applicant.isInEscrow() ? OWNERSHIP_LENGTH.get(2) : ownershipLength;
        fsa.assertEquals(getSelectedOwnershipLength(), ownershipLength, "Property info page - Ownership length match");
        if (applicant.isNewlyOwned() || applicant.isInEscrow()) {
            validateContentOfPriorOrCurrentAddress(fsa);
        }
        fsa.assertEquals(getSelectedClaimsNumber(), CLAIMS_OPTIONS.get(0), "Property info page - Claims count match");
    }

    public void validateTwoOrMorePropertyClaims(FarmersSoftAssert fsa, ApplicantAceHome applicant, String lobType) throws Exception {
//        selectNumberOfPropertyLosses("Two or more");
        clickContinueButton();
        if (!lobType.equals(HOME)) {
            KnockoutInconveniencePage knockoutPage = new KnockoutInconveniencePage();
            if (applicant.getAgentId().isBlank()) {
                knockoutPage.verifyMonetizationKnockout(fsa);
            } else {
                knockoutPage.verifyUnableToCompleteOnlineKnockout(applicant, fsa);
            }
        } else { // F99042: FFQ Home KO Redirect To FGIA (No KO, but forwarding to FGIA instead)
            FGIALandingPage fgiaLandingPage = new FGIALandingPage();
            fgiaLandingPage.validateContentOfFGIAPopUp(fsa, HOME);
            if (fgiaLandingPage.isFgiaNoThanksButtonDisplayed()) {
                fgiaLandingPage.clickNoThanksButtonInFGIAPopUp();
                fgiaLandingPage.weAreNotAbleToCompleteQuotePageValidation(fsa, HOME);
            }
        }
    }

    private boolean areNotAllowedCharactersNotAccepted(WebElement element, String notAllowedChars) {
        scrollAndClickOnElement(element);
        sendKeysToElement(element, notAllowedChars);
        return getValueFromWebElement(element).isBlank();
    }

    public boolean notAllowedSpecialCharsNotAcceptedOnCityField() {
        return areNotAllowedCharactersNotAccepted(priorOrCurrentAddressCityInputBox, NOT_ALLOWED_SPECIAL_CHARACTERS);
    }

    public boolean isAddressRequiredErrorDisplayed() {
        return isExpectedTextDisplayed(pleaseEnterYourStreetNumberAndNameError, PLEASE_ENTER_STREET_NUMBER_AND_NAME);
    }

    public boolean isCityRequiredErrorDisplayed() {
        return isExpectedTextDisplayed(pleaseProvideYourCityError, PLEASE_PROVIDE_YOUR_CITY_ERROR);
    }

    public boolean isStateRequiredErrorDisplayed() {
        return isExpectedTextDisplayed(pleaseProvideYourStateError, PLEASE_PROVIDE_YOUR_STATE_ERROR);
    }

    public boolean isZipRequiredErrorDisplayed() {
        return isExpectedTextDisplayed(pleaseProvideYourZipError, PLEASE_PROVIDE_YOUR_ZIP_ERROR);
    }

    public boolean isInvalidAddressErrorDisplayed() {
        waitElementBeVisible(invalidInputAddressError);
        return isExpectedTextDisplayed(invalidInputAddressError, String.format("%s is not a valid entry.", getElementValue(priorOrCurrentAddressInputBox, "Current or Prior Address")));
    }

    public boolean isInvalidZipErrorDisplayed() {
        waitElementBeVisible(invalidInputZipError);
        return isExpectedTextDisplayed(invalidInputZipError, PLEASE_PROVIDE_FIVE_DIGIT_ZIP_ERROR);
    }

    public void fillOutCurrentOrPriorAddressFieldWithInValidData() throws Exception {
        waitAndClickElement(priorOrCurrentAddressInputBox);
        sendKeysOneByOne(priorOrCurrentAddressInputBox, NOT_ALLOWED_SPECIAL_CHARACTERS);
        sendKeysToElement(priorOrCurrentAddressZipInputBox, NOT_ALLOWED_SPECIAL_AND_ALPHABETIC_CHARACTERS);
    }

    public void fillOutUnitNumberWithInValidData() {
        sendKeysOneByOne(unitInputBox, "@@@");
    }

    public boolean isInvalidUnitErrorDisplayed() {
        waitElementBeVisible(unitNumberNotValidEntryError);
        String inValidUnitNumberInputValue = getAttributeData(unitInputBox, VALUE);
        return isExpectedTextDisplayed(unitNumberNotValidEntryError, inValidUnitNumberInputValue + INVALID_ENTRY);
    }

    public boolean isPriorOrCurrentHomeAddressInputBoxDisplayed() {
        return priorOrCurrentAddressInputBox.isDisplayed();
    }

    public boolean isPriorOrCurrentHomeAddressPlaceHolderTextDisplayed() {
        return isElementDisplayed(addressFieldPlaceHolderText, 3);
    }

    public boolean isCloseIconInsideAddressInputBoxDisplayedAndClickable() {
        return closeIconInAddressInputBox.isDisplayed() && closeIconInAddressInputBox.isEnabled();
    }

    public boolean isUnitNumberInputBoxDisplayed() {
        return unitInputBox.isDisplayed();
    }

    public boolean isUnitNumberPlaceHolderTextDisplayed() {
        return isExpectedTextDisplayed(unitNumberPlaceholderText, UNIT_NUMBER_PLACEHOLDER_TEXT);
    }

    public boolean isUnitNumberOptionalHintDisplayed() {
        return isExpectedTextDisplayed(optionalUnitNumberHint, OPTIONAL_UNIT_NUMBER_HINT);
    }

    public void validateErrorForNoInputInCurrentOrPriorAddressFields(FarmersSoftAssert fsa) {
        fsa.assertTrue(isAddressRequiredErrorDisplayed(), "Address required error displayed");
        fsa.assertTrue(isCityRequiredErrorDisplayed(), "City required error displayed");
        fsa.assertTrue(isStateRequiredErrorDisplayed(), "State required error displayed");
        fsa.assertTrue(isZipRequiredErrorDisplayed(), "Zip required error displayed");
    }

    public void validateErrorForInvalidInputInCurrentOrPriorAddressFields(FarmersSoftAssert fsa) {
        fsa.assertTrue(isInvalidAddressErrorDisplayed(), "Current or Prior Address invalid input error displayed");
        fsa.assertTrue(isInvalidZipErrorDisplayed(), "Current or Prior Zip code invalid input error displayed");
    }

    public void validateNotAllowedSpecialCharInCity(FarmersSoftAssert fsa) {
        fsa.assertTrue(notAllowedSpecialCharsNotAcceptedOnCityField(), "Special chars are not allowed in City field");
    }

    public void validatePriorOrCurrentAddressFields(FarmersSoftAssert fsa) {
        fsa.assertTrue(isPriorOrCurrentHomeAddressInputBoxDisplayed(), "Address input box displayed");
        fsa.assertTrue(isElementVisible(priorHomeCityInputField, 2), "City input box displayed");
        fsa.assertTrue(isElementVisible(cityPlaceholderText, 2), "City place holder text displayed");
        fsa.assertTrue(isElementVisible(priorHomeStateSelectField, 2), "State input box displayed");
        fsa.assertTrue(isElementVisible(statePlaceholderText, 2), "State place holder text displayed");
        fsa.assertTrue(isElementVisible(priorHomeZipInputField, 2), "Zip input box displayed");
        fsa.assertTrue(isElementVisible(zipPlaceholderText, 2), "Zip place holder text displayed");
        fsa.assertTrue(isUnitNumberInputBoxDisplayed(), "Unit # input box displayed");
        fsa.assertTrue(isUnitNumberPlaceHolderTextDisplayed(), "Unit # place holder text displayed");
        fsa.assertTrue(isUnitNumberOptionalHintDisplayed(), "Unit # optional hint displayed");
        fsa.assertTrue(isCloseIconInsideAddressInputBoxDisplayedAndClickable(), "Close Icon inside address input box displayed and clickable");
        fsa.assertTrue(isPriorOrCurrentHomeAddressPlaceHolderTextDisplayed(), "Prior or current home address place holder text displayed");
    }

    // validate error message if prior or current address available
    public void validateCurrentOrPriorHomeAddressErrorMessage(FarmersSoftAssert fsa) throws Exception {

        // validate error message for Prior home address fields
        selectOwnershipLength(1);
        clickContinueButton();
        validateErrorForNoInputInCurrentOrPriorAddressFields(fsa);

        fillOutCurrentOrPriorAddressFieldWithInValidData();
        clickContinueButton();
        validateErrorForInvalidInputInCurrentOrPriorAddressFields(fsa);

        validateNotAllowedSpecialCharInCity(fsa);
        fillOutUnitNumberWithInValidData();

        // validate error message for current home address fields
        driver().navigate().refresh();
        waitForPageToBeReady();
        selectOwnershipLength(2);
        clickContinueButton();
        validateErrorForNoInputInCurrentOrPriorAddressFields(fsa);

        fillOutCurrentOrPriorAddressFieldWithInValidData();
        clickContinueButton();
        validateErrorForInvalidInputInCurrentOrPriorAddressFields(fsa);

        validateNotAllowedSpecialCharInCity(fsa);
        fillOutUnitNumberWithInValidData();
        fsa.assertTrue(isInvalidUnitErrorDisplayed(), "Invalid unit# is not displayed");
    }

}
