package com.farmers.ffq.auto.pages;

import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AutoCallForQuotePage extends AutoBasePage {


    @FindAll({
            @FindBy(xpath = "//span[@class='h1-alt1']"),
            @FindBy(xpath = "//span[@class='h1-alt2']"),
            @FindBy(css = "h1[id='main-content1']")
    })
    private WebElement callForAQuotePageTitle;
    @FindBy(xpath = "//span[contains(.,'get started')]")
    private WebElement letsGetStartedText;
    @FindAll({
            @FindBy(css = "span[class='p-style']"),
            @FindBy(xpath = "//div[@class='productgrid__heading rich-text']//p"),
            @FindBy(css = "p[class='pb-3']")
    })
    private WebElement pageDescription;
    @FindBy(xpath = "//a[@data-gtm='Check_ call_colp' and contains(@class,'mobile mobile button-cta')]")
    private WebElement mobileCallNowButton;
    @FindBy(xpath = "//a[@data-gtm='Check_ call_colp' and contains(@class,'desktop desktop button-cta')]")
    private WebElement desktopCallNowButton;
    @FindBy(xpath = "//span[@class='font-blue']//span[@class='h4-alt1']")
    private WebElement quickAndEasy;
    @FindBy(xpath = "//img[contains(@src,'auto-landing')]")
    private WebElement farmersImage;
    @FindBy(xpath = "//div[contains(@class,'tile tile--one-col col-12 mt-3 mb-1')]//img")
    private List<WebElement> tileSectionImages;
    @FindBy(xpath = "//div[contains(@class,'tile tile--one-col col-12 mt-3 mb-1')]//section")
    private List<WebElement> tileSectionTexts;
    @FindBy(xpath = "//p[contains(.,'NOTE')]")
    private WebElement noteSectionText;
    @FindBy(xpath = "//span[contains(.,'*')]")
    private WebElement savingPercentageNote;
    @FindBy(xpath = "//div[@class='footernav__notes-section row pt-3 pb-5']")
    private WebElement disclaimers;

    public AutoCallForQuotePage() throws Exception {
    }

    public boolean isOnCallForQuotePage() {
        return isElementVisible(callForAQuotePageTitle, 10);
    }

    public void validateCallForAQuotePage(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(callForAQuotePageTitle)), "Call for your quote", "FWS page title validated");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageDescription)), "Let's get started! If you'd like to continue your quote and see how much you could save, please give us a call.", "Page description text validated");
        fsa.assertTrue(getTextFromElement(isUseMobileViewEnabled() ? mobileCallNowButton : desktopCallNowButton).contains("Call Now"), "Call now button text validated");
    }
}
