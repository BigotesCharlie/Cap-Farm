package com.farmers.ffq.auto.pages.bindpages;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Auto.Driver;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.LicenseFormatByState;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import net.datafaker.Faker;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AdditionalInfoDriverSectionOneUI extends AutoBasePage {

    private static String DRIVER_SECTION_XPATH = "//p[contains(.,'%s')]/../../..";
    private static String DRIVER_SECTION_LICENSENUMBER_INPUT_XPATH = "//input[@aria-label='License']";

    @FindBy(xpath = "//h3[contains(text(), 'license info')]")
    private WebElement driverLabel;

    //private static final String DRIVER_SIDEBAR_QUESTION = "Why do you need my driver’s license number?";
    @FindBy(xpath = "//p[contains(text(), 'Why do you need my driver')]")
    private WebElement whyNeedDriverLicenseQuestion;

    @FindBy(xpath = "//h1[contains(text(), 'Why do you need my driver')]")
    private WebElement whyNeedDriverLicenseQuestionMB;

    private static final String DRIVER_SIDEBAR_ANSWER = "This is required to check your driving history and motor vehicle report.";
    @FindBy(xpath = "//p[contains(text(), 'This is required to check your driving history')]")
    private WebElement whyNeedDriverLicenseExplanation;

    @FindBy(xpath = "//div[contains(@class,'additional-info-driver-section')]//div[contains(@class,'additional_info_tips_section_medium')]//mat-icon")
    private List<WebElement> getWhyNeedDriverLicenseQuestionTipMB;
    @FindBy(xpath = "//div[@formarrayname ='drivers']")
    private WebElement parentNodeForDriverList;

    @FindBy(xpath = "//input[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicense_text']")
    public List<WebElement> driverLicenseNumberInputTextBoxes;

    @FindBy(xpath = "//mat-select[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicenseState_text']")
    private List<WebElement> driverLicenseStateDropDownWebElementList;

    private final String RACE_TOGGLE_GROUP_XPATH = "//mat-button-toggle-group[@formcontrolname='customerrnogConsent']";

    @FindBy(xpath = "//mat-label[contains(text(),'State')]")
    private List<WebElement> test;

    private final String DRIVER_LICENSE_PLACEHOLDER_TEXT = "Driver's license #";
    @FindBy(xpath = "//mat-label[contains(text(),\"Driver's license #\")]")
    private List<WebElement> driverLicenseNumberInputPlaceHolders;

    private final String ENTER_DRIVER_LICENSE_ERROR = "Please enter license number.";
    @FindBy(xpath = "//mat-error[contains(text(),'license number')]")
    private List<WebElement> enterDriverLicenseNumberErrors;

    @FindBy(xpath = "//span[@class='mat-option-text']")
    private List<WebElement> listOfAllTheStatesInLicenseStateDropdown;

    @FindBy(xpath = "//mat-error[contains(text(),'License # not valid for this state.')]")
    private WebElement invalidLicenseError;

    private final String COMPLETED_MATURE_DRIVER_SAFETY_COURSE_LAST_3_YEARS = "Completed a mature driver safety course in the last 3 years";
    @FindBy(xpath = "//span[contains(text(),'" + COMPLETED_MATURE_DRIVER_SAFETY_COURSE_LAST_3_YEARS + "')]")
    private List<WebElement> completedMatureDriverSafetyCourseLastThreeYears;

    @FindBy(xpath = "//mat-slide-toggle[@formcontrolname='mddCourseToggle']//input[@aria-checked='false']")
    private List<WebElement> disabledMatureSafetyCourseToggleButton;

    @FindBy(xpath = "//mat-slide-toggle[@formcontrolname='mddCourseToggle']//input[@aria-checked='true']")
    private List<WebElement> enabledMatureSafetyCourseToggleButton;

    @FindBy(xpath = "//input[@formcontrolname='mddSafetyCourseDate']")
    private List<WebElement> mddSafetyCourseDateInputBox;

    private final String PROVIDE_COMPLETION_DATE_TOGGLE_OFF_HINT = "Provide completion date, or toggle off completed course";
    @FindBy(xpath = "//mat-hint[contains(text(),'" + PROVIDE_COMPLETION_DATE_TOGGLE_OFF_HINT + "')]")
    private List<WebElement> provideCompletionDateOrToggleOffHint;

    private final String PROVIDE_COMPLETION_DATE_CHECK_CHECKBOX_HINT = "Provide completion date, or check the box below";
    @FindBy(xpath = "//mat-hint[contains(text(),'" + PROVIDE_COMPLETION_DATE_CHECK_CHECKBOX_HINT + "')]")
    private List<WebElement> provideCompletionDateOrCheckCheckboxHint;

    @FindBy(xpath = "//mat-checkbox[@formcontrolname='mddSafetyCourseDateIDoNotKnow']//label//input[@type='checkbox']")
    private List<WebElement> mddSafetyCourseDateIDoNotKnowCheckbox;

    @FindBy(xpath = "//mat-checkbox[@formcontrolname='mddSafetyCourseDateIDoNotKnow']//label//span[@class='mat-checkbox-label']")
    private List<WebElement> mddSafetyCourseDateIDoNotKnowLabel;

    //The date must be between
    @FindBy(xpath = "//mat-error[contains(text(),'The date must be between')]")
    private List<WebElement> mddSafetyCourseDateRangeError;

    private final String MDD_MUST_BE_MMYYYY_FORMAT = "Date must be in mm/yyyy format";
    @FindBy(xpath = "//mat-error[contains(text(),'" + MDD_MUST_BE_MMYYYY_FORMAT + "')]")
    private List<WebElement> mddMustBeInMMYYYYFormatError;

    @FindBy(css = "mat-select[formcontrolname='licenseCountry']")
    private List<WebElement> countryDropDowns;

    @FindBy(css = "input[formcontrolname='countryLicenseNumber']")
    private List<WebElement> foreignDlInputField;

    @FindBy(xpath = "//input[contains(@aria-label,'Select license start')]")
    private List<WebElement> fdlStartDateInputFields;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AdditionalInfoDriverSectionOneUI() throws Exception {
    }


    public void verifyDriverSection(AppStore retrieveQuoteResponseSessionStorage, FarmersSoftAssert fsa) throws Exception {
        removeQualtricsPopUp();
        List<Driver> listOfDriverWithEmptyLicenseNumber = checkIfDriverSectionAvailable();
          if(!listOfDriverWithEmptyLicenseNumber.isEmpty()){
              removeQualtricsPopUp();
              validateDriverSectionLabelsAndTexts(fsa);
              validateDriversNameAndDriverLicenseTextBox(retrieveQuoteResponseSessionStorage, listOfDriverWithEmptyLicenseNumber, fsa);
              validateEditDriverLicense(listOfDriverWithEmptyLicenseNumber, fsa);
              validateStatesInDriverLicenseStateDropdown(fsa);
              validateMatureDriverSafetyDates(retrieveQuoteResponseSessionStorage, fsa);
          }

          validateDriverInfoRaceSectionIfAvailable(fsa);

    }

    private void validateDriverInfoRaceSectionIfAvailable(FarmersSoftAssert softAssert) throws Exception {

        if(!getSessionStorageAppStore().getData().getLandingStateCode().equals(CA)) {
            return; // this test is only applicable for CA
        }
        List<WebElement> driverInfoRaceQuestions = driver().findElements(By.xpath(RACE_TOGGLE_GROUP_XPATH));

        softAssert.assertFalse(driverInfoRaceQuestions.isEmpty(), "RNOG, race section should not be empty, it should be visible at least for PNI");
        // validate labels
        String expectedQuestion = "Do you wish to provide the Department of Insurance with information regarding your race, national origin and gender?";
        int numberOfQuestions = driverInfoRaceQuestions.size();
        for (int i = 0; i < numberOfQuestions; i++) {
            List<WebElement> questions = driver().findElements(By.xpath(RACE_TOGGLE_GROUP_XPATH + "/../..//label[contains(.,'Department')]"));
            softAssert.assertEquals(getTextFromElement(questions.get(i)), expectedQuestion);

            // validate error message
            clickContinueButton();
            WebElement errorMessages = driver().findElement(By.xpath(RACE_TOGGLE_GROUP_XPATH + "/..//mat-error"));
            softAssert.assertEquals(getTextFromElement(errorMessages), "Must choose a selection");

            // validate no drop down selected error message
            WebElement yesToggle = driver().findElements(By.xpath("//mat-button-toggle-group[@formcontrolname='customerrnogConsent']//mat-button-toggle[contains(.,'Yes')]")).get(i);
            waitAndClickElement(yesToggle);

            clickContinueButton();
            softAssert.assertTrue(isElementPresent(By.xpath("//mat-error[contains(.,'Please select race or national origin')]"), 1));

        }

    }

    public List<AppStore.Auto.Driver> checkIfDriverSectionAvailable() throws Exception {
        List<AppStore.Auto.Driver> listOfDriverWithEmptyLicenseNumber = getSessionStorageAppStore().getAuto().getDrivers().stream().filter(item-> item.getLicNumber() == null && item.isHasDriverLicense()).collect(Collectors.toList());
        return listOfDriverWithEmptyLicenseNumber;
    }

    public void validateDriverSectionLabelsAndTexts(FarmersSoftAssert fsa) throws Exception {
        if(isUseMobileViewEnabled()) {
            waitAndClickElement(getWhyNeedDriverLicenseQuestionTipMB.get(0));
            fsa.assertTrue(whyNeedDriverLicenseQuestionMB.isDisplayed(), "Why Need Driver License Question MB displayed");
            waitAndClickElement(closeIconMB);
        } else {
            fsa.assertTrue(whyNeedDriverLicenseQuestion.isDisplayed(), "Why Need Driver License Question displayed");
            fsa.assertEquals(getTextFromElement(whyNeedDriverLicenseExplanation), DRIVER_SIDEBAR_ANSWER, "Why Need Driver License Question content verification");
        }

    }

    // validate full name and landing state code of drivers in Driver license info section
    public void validateDriversNameAndDriverLicenseTextBox(AppStore quoteResponseSessionStorage, List<Driver> driverList, FarmersSoftAssert fsa) throws Exception {
    	int numberOfDrivers = driverList.size();
        for(int i = 0; i < numberOfDrivers; i++){
            String driverFullNameXpath = "//p[text()=' " + driverList.get(i).getFirstName()+ " " + driverList.get(i).getLastName()+ " ']";
            WebElement driverElement = driver().findElement(By.xpath(driverFullNameXpath));
            fsa.assertTrue(driverElement.isDisplayed(), "Driver" + i +" In Drivers License Section displayed");
            fsa.assertEquals(getTextFromElement(driverLicenseStateDropDownWebElementList.get(i)), quoteResponseSessionStorage.getData().getLandingStateCode(), "Landing State Code In License State Dropdown for" +
                    " Driver" + i +" verification");
            fsa.assertTrue(driverLicenseNumberInputTextBoxes.get(i).isDisplayed(), "Driver License Number Input TextBox displayed for Driver" + i);
            waitElementBeVisible(driverLicenseNumberInputPlaceHolders.get(i));
            fsa.assertEquals(getTextFromElement(driverLicenseNumberInputPlaceHolders.get(i)), DRIVER_LICENSE_PLACEHOLDER_TEXT, "Driver License Number Input TextBox Placeholder Text Is Not Available For Driver" + i);
           // scrollToElementWithOffset(driverLicenseNumberInputTextBoxes.get(i), 30);

            waitAndClickElement(driverLicenseNumberInputTextBoxes.get(i));
            //driverLicenseNumberInputTextBoxes.get(i).click();
            driverLicenseNumberInputTextBoxes.get(i).sendKeys(Keys.chord(Keys.TAB));
        }
        fsa.assertEquals(enterDriverLicenseNumberErrors.size(), driverList.size(), "Enter Driver License Error Is Not Displayed On Empty Driver License Input Box.");
    }

    public void validateEditDriverLicense(List<Driver> driverList, FarmersSoftAssert fsa) throws Exception {
    	int numberOfDrivers = driverList.size();
    	for (int i = 0; i < numberOfDrivers; i++) {

            int randomIndex = new Random().nextInt(listOfAllStates().size());
            String randomState = listOfAllStates().get(randomIndex);
            String randomlySelectedStateLicenseNumber = LicenseFormatByState.getLicenseNumberByState(randomState);

            String licenseNumber = LicenseFormatByState.getLicenseNumberByState(getTextFromElement(driverLicenseStateDropDownWebElementList.get(i)));

            // landing state code - invalid driver license number
            sendKeysOneByOne(driverLicenseNumberInputTextBoxes.get(i), licenseNumber + "AB");
            driverLicenseNumberInputTextBoxes.get(i).sendKeys(Keys.chord(Keys.TAB));
            waitElementBeVisible(invalidLicenseError);
            fsa.assertEquals(invalidLicenseError.isDisplayed(), true, "Driver License Number Is Valid for driver " + i);

            // landing state code - valid driver license number
            waitAndClickElement(driverLicenseNumberInputTextBoxes.get(i));
//            driverLicenseNumberInputTextBoxes.get(i).click();
            sendKeysOneByOne(driverLicenseNumberInputTextBoxes.get(i), licenseNumber);
            driverLicenseNumberInputTextBoxes.get(i).sendKeys(Keys.chord(Keys.TAB));

            // randomly select state in drop down - valid license number
            clickOnHiddenElement(driverLicenseStateDropDownWebElementList.get(i));
            //driverLicenseStateDropDownWebElementList.get(i).click();
            List<WebElement> stateDropDownElements = driver().findElements(By.xpath("//span[@class='mat-option-text']"));
            WebElement randomlySelectedState = stateDropDownElements.get(randomIndex);
            scrollAndClickOnHiddenElement(randomlySelectedState);
            sendKeysOneByOne(driverLicenseNumberInputTextBoxes.get(i), randomlySelectedStateLicenseNumber);
            driverLicenseNumberInputTextBoxes.get(i).sendKeys(Keys.chord(Keys.TAB));

            // randomly select state in drop down - invalid license number
            sendKeysOneByOne(driverLicenseNumberInputTextBoxes.get(i), randomlySelectedStateLicenseNumber + "AB");
            driverLicenseNumberInputTextBoxes.get(i).sendKeys(Keys.chord(Keys.TAB));
            waitElementBeVisible(invalidLicenseError);
            fsa.assertEquals(invalidLicenseError.isDisplayed(), true, "Driver License Number Is Valid for driver " + i);

            // back to randomly select state in drop down - valid license number
            sendKeysOneByOne(driverLicenseNumberInputTextBoxes.get(i), randomlySelectedStateLicenseNumber);
            driverLicenseNumberInputTextBoxes.get(i).sendKeys(Keys.chord(Keys.TAB));
        }
    }

    public void validateStatesInDriverLicenseStateDropdown(FarmersSoftAssert fsa) throws Exception {
        Actions builder = new Actions(driver());
        List<String> expectedAllStateAbbreviation = listOfAllStates();
    	int numberOfElements = driverLicenseStateDropDownWebElementList.size();
        for(int i =0; i< numberOfElements; i++){
            clickOnHiddenElement(driverLicenseStateDropDownWebElementList.get(i));
            sleep(4);
            List<String> foundAllStateAbbreviation =  listOfAllTheStatesInLicenseStateDropdown.stream().map(this::getTextFromElement).collect(Collectors.toList());
            fsa.assertEquals(foundAllStateAbbreviation, expectedAllStateAbbreviation, "All The States Are Not Available In State DropDown for driver " + i + "." );
            sleep(3);
            builder.moveToElement(driverLicenseStateDropDownWebElementList.get(i), 100, 100).click().build().perform();
        }
    }

    public void enterDriverLicenseNumber(AppStore retrieveQuoteResponseSessionStorage) throws Exception {
        closeQualtricsPopUp();
    	int numberOfElements = driverLicenseStateDropDownWebElementList.size();
        for (int i = 0; i < numberOfElements; i++) {
            // enter driving license number
            String licenseNumber = LicenseFormatByState.getLicenseNumberByState(getTextFromElement(driverLicenseStateDropDownWebElementList.get(i)));
            WebElement dlInputElement = driverLicenseNumberInputTextBoxes.get(i);
            scrollElementToMiddle(dlInputElement);
            waitAndClickElement(dlInputElement);
            sendKeysOneByOne(dlInputElement, licenseNumber);
            dlInputElement.sendKeys(Keys.TAB);
            waitForSpinnerToBeGone();
            Log.info("Entering US dl number: " + licenseNumber);
        }
        enterForeignDriverLicenseDetails();
    }

    public void fillOutDriverInfoSectionForRace() throws Exception {
        closeQualtricsPopUp();
        List<WebElement> raceQuestions = driver().findElements(By.xpath(RACE_TOGGLE_GROUP_XPATH));
    	int numberOfElements = raceQuestions.size();
        for (int i = 0; i < numberOfElements; i++) {
            // randomly select Yes or No
            String yesOrNo = YES;
            WebElement toggleElement = driver().findElements(By.xpath(String.format("//mat-button-toggle-group[@formcontrolname='customerrnogConsent']//mat-button-toggle[contains(.,'%s')]", yesOrNo))).get(i);
            waitAndClickElement(toggleElement);
            Log.info(String.format("User selected %s for the race question", yesOrNo));
            if (yesOrNo.equals(YES)) {
                sleep(1);
                WebElement raceDropDown = driver().findElements(By.cssSelector("mat-select[formcontrolname='raceEthinicity']")).get(i);
                waitAndClickElement(raceDropDown);
                sleep(1);
                List<WebElement> listOfAvailableRaces = driver().findElements(By.xpath("//mat-option[contains(.,'African')]/..//mat-option"));
                waitAndClickElement(listOfAvailableRaces.get(new Random().nextInt(listOfAvailableRaces.size()- 1)));
            }
        }
    }

    public void enterDriverLicenseNumber(String stateCode) throws Exception {
        closeQualtricsPopUp();
    	int numberOfElements = driverLicenseStateDropDownWebElementList.size();
        for(int i =0; i< numberOfElements; i++){
            // enter driving license number
            String licenseNumber = LicenseFormatByState.getLicenseNumberByState(stateCode);
            waitAndClickElement(driverLicenseStateDropDownWebElementList.get(i));
            WebElement desiredState = driver().findElement(By.xpath(String.format("//mat-option[contains(.,'%s')]", stateCode)));
            waitAndClickElement(desiredState);
            WebElement dlInputElement = driverLicenseNumberInputTextBoxes.get(i);
            scrollElementToMiddle(dlInputElement);
            waitAndClickElement(dlInputElement);
            sendKeysOneByOne(dlInputElement, licenseNumber);
            dlInputElement.sendKeys(Keys.TAB);
            waitForSpinnerToBeGone();
            Log.info("Entering US dl number: " + licenseNumber);
        }
        enterForeignDriverLicenseDetails();
    }

    // validate mature driver safety course section
    public void validateMatureDriverSafetyDates(AppStore retrieveQuoteResponseSessionStorage, FarmersSoftAssert fsa) throws Exception {
        // mature driver discount
        String landingStateCode = retrieveQuoteResponseSessionStorage.getData().getLandingStateCode();
        List<Driver> listOfDriversEligibleMatureSafetyCourse = null;
        List<Driver> listOfOriginalDrivers = retrieveQuoteResponseSessionStorage.getAuto().getDrivers();

        if (isMatureDriverSafetyCourseMandatory(landingStateCode)) {
            if (landingStateCode.equals(KS)) {
                listOfDriversEligibleMatureSafetyCourse = filterDriverListByAge(0, listOfOriginalDrivers);
            } else {
                listOfDriversEligibleMatureSafetyCourse = filterDriverListByAge(55, listOfOriginalDrivers);
            }
            checkMatureDriverDiscount(listOfDriversEligibleMatureSafetyCourse, true, fsa);
        }
//        else{
//            listOfDriversEligibleMatureSafetyCourse = filterDriverListByAge(55, listOfOriginalDrivers);
//            checkMatureDriverDiscount(listOfDriversEligibleMatureSafetyCourse, false, sa);
//        }
    }

    // filter driver list by age for mature driver safety course date validation
    public List<Driver> filterDriverListByAge(int age, List<Driver> listOfOriginalDrivers){
        List<Driver> filteredDriverListBasedOnAge = listOfOriginalDrivers.stream().filter(i -> i.getAge() >= age).collect(Collectors.toList());
        return filteredDriverListBasedOnAge;
    }

    // Validate content, errors and format for mature driver safety course
    public void checkMatureDriverDiscount(List<Driver> listOfDriversEligibleMatureSafetyCourse, boolean isMatureSafetyCourseDateMandatory, FarmersSoftAssert fsa) throws Exception {
        List<Driver> listOfDriversWithoutMatureSafetyCourse = listOfDriversEligibleMatureSafetyCourse.stream().filter(i -> i.getSafetyCourseCompleted().equals("N")).collect(Collectors.toList());
        List<Driver> listOfDriversWithMatureSafetyCourse = listOfDriversEligibleMatureSafetyCourse.stream().filter(i -> i.getSafetyCourseCompleted().equals("Y")).collect(Collectors.toList());

        // Mdd input fields/toggle buttons/labels/Hits validation on initial load
        fsa.assertEquals(disabledMatureSafetyCourseToggleButton.size(), listOfDriversWithoutMatureSafetyCourse.size(), "Disabled mature driver safety toggle buttons are not matching.");
        fsa.assertEquals(enabledMatureSafetyCourseToggleButton.size(), listOfDriversWithMatureSafetyCourse.size(),"Enabled mature driver safety toggle buttons are not matching.");
        fsa.assertEquals(mddSafetyCourseDateInputBox.size(), listOfDriversWithMatureSafetyCourse.size(),"Mdd safety course date input box are not matching.");
        if(!isMatureSafetyCourseDateMandatory){
            fsa.assertEquals(mddSafetyCourseDateIDoNotKnowCheckbox.size(), listOfDriversWithMatureSafetyCourse.size(),"Mdd safety course date check box are not matching.");
            fsa.assertEquals(mddSafetyCourseDateIDoNotKnowLabel.size(), listOfDriversWithMatureSafetyCourse.size(), "Mdd safety course date I do not know labels are not matching.");
            fsa.assertEquals(provideCompletionDateOrCheckCheckboxHint.size(), listOfDriversWithMatureSafetyCourse.size(),"Provide completion date or check checkbox hints are not matching.");
        }else{
            fsa.assertEquals(provideCompletionDateOrToggleOffHint.size(), listOfDriversWithMatureSafetyCourse.size(),"Provide completion date or toggle off hints are not matching.");
            fsa.assertEquals(mddSafetyCourseDateInputBox.size(), listOfDriversWithMatureSafetyCourse.size(),"Mdd safety course date input box are not matching.");
        }

        // enable all the MDD toggle button for validations
        disabledMatureSafetyCourseToggleButton.forEach(i -> waitAndClickElement(i));
        String todayDateInMMYYYY = todayDateInMMYYYY();

        if(isMatureSafetyCourseDateMandatory){
            // validate if mdd input fields are matching after enabling all the fields
            fsa.assertEquals(mddSafetyCourseDateInputBox.size(), listOfDriversEligibleMatureSafetyCourse.size(),"Mdd safety course date input box are not matching.");

            // click continue to payment button in order to validate errors for mdd
            AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
            additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();

            // Validate mdd date range error
            fsa.assertEquals(mddSafetyCourseDateRangeError.size(), listOfDriversEligibleMatureSafetyCourse.size(),"Mdd date range errors are not matching");

            // Validate mdd date range error contains valid range
            String mddDateRange = mddValidRange();
            fsa.assertEquals(mddSafetyCourseDateRangeError.stream().filter(i -> getTextFromElement(i).contains(mddDateRange)).collect(Collectors.toList()).size(), listOfDriversEligibleMatureSafetyCourse.size(),
                    "Mdd date range errors do not contains valid date range "+ mddDateRange);
            // Enter valid date in mdd input box
            mddSafetyCourseDateInputBox.forEach(i -> sendKeysOneByOne(i, todayDateInMMYYYY));
        }else{
            // Add valid mdd dates and  Clear out input box, validate date format mm/yyyy error
            mddSafetyCourseDateInputBox.forEach(i -> i.sendKeys(todayDateInMMYYYY));
            mddSafetyCourseDateInputBox.forEach(i -> clearOutFieldUsingBackSpace(i));
            fsa.assertEquals(mddMustBeInMMYYYYFormatError.size(), listOfDriversEligibleMatureSafetyCourse.size(), "Mdd date must be mm/yyyy errors are not matching.");

            // Check I do not know checkbox in order to validate disabled and empty input box
            mddSafetyCourseDateInputBox.forEach(i -> i.sendKeys(todayDateInMMYYYY));
            mddSafetyCourseDateIDoNotKnowCheckbox.forEach(i -> waitAndClickElement(i));
            fsa.assertEquals(mddSafetyCourseDateInputBox.stream().filter( i -> !i.isEnabled()).collect(Collectors.toList()).size(), listOfDriversEligibleMatureSafetyCourse.size(),
                    "Mdd date input boxes are not disabled");
            fsa.assertEquals(mddSafetyCourseDateInputBox.stream().filter(i -> getAttributeData(i, VALUE).equals(EMPTY_STRING)).collect(Collectors.toList()).size(), listOfDriversEligibleMatureSafetyCourse.size(),
                    "Mdd date input box values are not empty");

            // Uncheck I do not know checkbox in order to validate enable input box
            mddSafetyCourseDateIDoNotKnowCheckbox.forEach(i -> waitAndClickElement(i));
            fsa.assertEquals(mddSafetyCourseDateInputBox.stream().filter( i -> i.isEnabled()).collect(Collectors.toList()).size(), listOfDriversEligibleMatureSafetyCourse.size(),
                    "Mdd date input box are not enable");

            // Enter mdd dates
            mddSafetyCourseDateInputBox.forEach(i -> i.sendKeys(todayDateInMMYYYY()));
        }
    }

    public String mddValidRange(){
        LocalDate startDate = LocalDate.now().plusMonths(-34);
        String endDate = todayDateInMMYYYY();
        return startDate.getMonthValue() + "/" + startDate.getYear() + " - " + endDate;
    }

    public String todayDateInMMYYYY(){
        Format f = new SimpleDateFormat("MM/yyyy");
        String endDate = f.format(new Date());
        return endDate;
    }

    // Enter only mature driver safety course date if required
    public void enterForeignDriverLicenseDetails() throws Exception {
    	int numberOfElements = countryDropDowns.size();
        for (int i =0; i< numberOfElements; i++){
            // select countries
            waitAndClickElement(countryDropDowns.get(i));
            selectValueInDropDown(countryDropDowns.get(i), "Turkey");
            Log.info("Selecting Turkey as country for foreign driver license");
            // enter dl number
            sendKeysToElement(foreignDlInputField.get(i), RandomStringUtils.randomNumeric(6));

            // enter license start date
            LocalDate now = LocalDate.now();
            sendKeysToElement(fdlStartDateInputFields.get(i), "0101" + now.getYear());
            Log.info("Entering license start date for foreign driver license: 0101" + now.getYear());

        }
    }

    // Enter foreign country dl details
    public void enterMatureDriverSafetyCourseDate(String landingStateCode){
        if(isMatureDriverSafetyCourseMandatory(landingStateCode)){
            disabledMatureSafetyCourseToggleButton.forEach(i -> waitAndClickElement(i));
            String todayDateInMMYYYY = todayDateInMMYYYY();
            sleep(2);
            mddSafetyCourseDateInputBox.forEach(i -> sendKeysOneByOne(i, todayDateInMMYYYY));
        }
    }

    public void fillOutDriverSection(AutoApplicant applicant) throws Exception {
        String applicantFullName = getTheFullNameWithFirstLetterInCaps(applicant.getFirstName() + SPACE + applicant.getLastName());
        String applicantDriverSectionXpath = String.format(DRIVER_SECTION_XPATH, applicantFullName);
        fillOutDriverLicenseInputField(applicant, applicantDriverSectionXpath);
    }

    public void fillOutDriverLicenseInputField(AutoApplicant applicant, String driverXpath) throws Exception {
        WebElement dlInputField = driver().findElement(By.xpath(driverXpath + DRIVER_SECTION_LICENSENUMBER_INPUT_XPATH));
        scrollToElement(dlInputField);
        sendKeysToElement(dlInputField, new Faker().drivingLicense().drivingLicense(applicant.getStateCode()));
        sendKeysToElement(dlInputField, Keys.TAB);
        waitForSpinnerToBeGone();
        sleep(2);
    }

    public void fillOutInvalidDriverLicenseInputField(AutoApplicant applicant) throws Exception {
        String applicantFullName = getTheFullNameWithFirstLetterInCaps(applicant.getFirstName() + SPACE + applicant.getLastName());
        String applicantDriverSectionXpath = String.format(DRIVER_SECTION_XPATH, applicantFullName);
        WebElement dlInputField = driver().findElement(By.xpath(applicantDriverSectionXpath + DRIVER_SECTION_LICENSENUMBER_INPUT_XPATH));
        scrollToElement(dlInputField);
        sendKeysToElement(dlInputField, "123456ST01");
        sendKeysToElement(dlInputField, Keys.TAB);
    }

    public void fillOutSuspended_RevokedDriverLicenseInputField(AutoApplicant applicant) throws Exception {

        String applicantFullName = getTheFullNameWithFirstLetterInCaps(applicant.getFirstName() + SPACE + applicant.getLastName());
        String applicantDriverSectionXpath = String.format(DRIVER_SECTION_XPATH, applicantFullName);
        List<WebElement> dlInputFields = driver().findElements(By.xpath(applicantDriverSectionXpath + DRIVER_SECTION_LICENSENUMBER_INPUT_XPATH));
        WebElement dlInputField = null;
        if(dlInputFields.isEmpty()) {
            return;
        } else {
            dlInputField = dlInputFields.get(0);
            scrollToElement(dlInputField);
        }
        //Sending Suspended and Revoked Drivers License for below states to get Reverse-brightlined
        String dlNumber = "";
        switch(applicant.getStateCode()){
            case IL :
                dlNumber = "E53692369305";
                break;
            case NM :
                dlNumber = "888338159";
                break;
        }
        ((JavascriptExecutor) driver()).executeScript("arguments[0].value = '';", dlInputField);
        sleep(1);
        sendKeysToElement(dlInputField, dlNumber);
        sendKeysToElement(dlInputField, Keys.TAB);
    }

    public void fillOutHealthInsuranceSection(String pipProvider, String pipPolicyNumber) throws Exception {
        if(isElementPresent(By.xpath("//div[@formarrayname='healthInsurance']"))) {
            fillOutCurrentInsuranceProvider(pipProvider);
            fillOutHealthInsurancePolicyNumber(pipPolicyNumber);
        }
    }

    private void fillOutHealthInsurancePolicyNumber(String policyNumber) throws Exception {
        WebElement policyNumberInputField = driver().findElement(By.xpath("//input[@formcontrolname='healthPolicyNum']"));
        sendKeysToElement(policyNumberInputField, policyNumber);

    }

    private void fillOutCurrentInsuranceProvider(String currentInsuranceProvider) throws Exception {
        WebElement currentInsuranceProviderInput = driver().findElement(By.xpath("//input[@formcontrolname='healthInsProvider']"));
        sendKeysToElement(currentInsuranceProviderInput, currentInsuranceProvider);
    }

}
