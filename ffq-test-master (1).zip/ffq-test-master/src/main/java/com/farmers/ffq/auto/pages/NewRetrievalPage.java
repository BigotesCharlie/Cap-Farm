package com.farmers.ffq.auto.pages;

import com.farmers.framework.report.Log;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class NewRetrievalPage extends AutoBasePage {

    /* ==========================
     * Page Elements
     * ========================== */

    @FindBy(xpath = "//h1[contains(text(),'Welcome back')]")
    private WebElement lblWelcomeBack;

    @FindBy(xpath = "//input[@aria-label='Last name']")
    private WebElement txtLastName;

    @FindBy(xpath = "//input[contains(@aria-label,'Date of birth')]")
    private WebElement txtDateOfBirth;

    @FindBy(xpath = "//button[@aria-label='Retrieve my quote button']")
    private WebElement btnRetrieveMyQuote;

    @FindBy(xpath = "//a[contains(normalize-space(),'Start a new quote instead')]")
    private WebElement lnkStartNewQuote;

    /**
     * Constructor.
     */
    public NewRetrievalPage() throws Exception {
        super();
    }

    /* ==========================
     * Page Verification
     * ========================== */

    public boolean isOnNewRetrievalPage() {
        return isElementVisible(lblWelcomeBack, 10);
    }

    /* ==========================
     * Form Entry
     * ========================== */

    public void enterLastName(String lastName) {
        sendKeysToElement(waitElementBeVisible(txtLastName), lastName);
        Log.info("Last name is entered: " + lastName);
    }

    public void enterDateOfBirth(String dateOfBirth) {
        sendKeysToElement(waitElementBeVisible(txtDateOfBirth), dateOfBirth);
        Log.info("Date of Birth is entered: " + dateOfBirth);
    }

    public void enterRetrievalInformation(String lastName, String dateOfBirth) {
        enterLastName(lastName);
        enterDateOfBirth(dateOfBirth);
    }

    /* ==========================
     * CTA Actions
     * ========================== */

    public void clickRetrieveMyQuote() {
        waitAndClickElement(btnRetrieveMyQuote);
        Log.info("Clicked on Retrieve My Quote button");
    }

    public void clickStartNewQuoteInstead() {
        waitAndClickElement(lnkStartNewQuote);
        Log.info("Clicked on Start a New Quote Instead link");
    }

    /* ==========================
     * Business Actions
     * ========================== */

    public void retrieveSavedQuote(String lastName, String dateOfBirth) {
        enterRetrievalInformation(lastName, dateOfBirth);
        clickRetrieveMyQuote();
        waitForSpinnerToBeGone();
    }
}