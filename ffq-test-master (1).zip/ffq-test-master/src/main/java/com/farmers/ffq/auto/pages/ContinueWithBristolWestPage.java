package com.farmers.ffq.auto.pages;

import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;

import com.farmers.framework.report.Log;
import lombok.SneakyThrows;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ContinueWithBristolWestPage extends AutoBasePage {
    public static final String YOU_RE_STILL_ON_YOUR_WAY_TO_NEW_COVERAGE = "You're still on your way to new coverage.";
    @FindBy (id = "TUI_FARMERS_LOGO")
	private WebElement farmersLogoImage;

	@FindBy (id = "TUI_ARROW_LOGO")
	private WebElement arrowImage;

	@FindBy (xpath = "//img[@alt='Bristol West logo' and contains(@src,'svg')]")
	private WebElement bristolWestLogoImage;

	@FindBy (xpath="//app-brightline-bw-popup")
	private WebElement continueToBWDialog;
    @FindBy(xpath = "//div[contains(@class,'branding-brightline-to-bw-page-container')]")
    private WebElement continueToBWDialogRebranding;
    @FindBy (css="div[class='fgia-rebrand-cta-section mt-10']>button")
	private WebElement continueToFGIAButton;
	@FindBy (id = "bwHeaderTitle")
	private WebElement continueToBWDialogTitleElement;
	@FindBy (xpath = "//div[contains(@class, 'brightline-to-bw-page-body')]")
	private WebElement continueToBWDialogTextElement;

	@FindBy (className = "brightline-to-bw-page__header")
	private WebElement bwPageHeaderText;

    @FindAll({
            @FindBy(xpath = "//div[contains(@class,'brightline-to-bw-page__subheading')] | //div[@class='brightline-to-bw-page-body'] | //h4[contains(@class,'tui-subtitle-text')]"),
            @FindBy(xpath = "//h2[@class='tui-h2 mt-10']")
    })
	private WebElement bwPageSubheadingText;
	@FindAll({
            @FindBy(xpath = "//div[@class='row']/h4"),
            @FindBy(xpath = "//h2[@class='tui-h2 mt-10']"), // order is important here
            @FindBy(xpath = "//h4[@class='tui-h4']")

    })
	private WebElement bwAlternatePageSubheadingText;
    @FindBy(xpath = "//p[contains(@class,'disclaimer-text')][1]")
    private WebElement firstParagraphOfDisclaimerText;
    @FindAll({
            @FindBy(xpath = "//h4[@class='tui-h4 mt-10']"),
            @FindBy(xpath = "//p[contains(.,'We think')]")
    })
    private WebElement cantOfferText;
    @FindAll({
            @FindBy(xpath = "//p[@class='tui-body-bold mb-6']"),
            @FindBy(xpath = "//p[contains(@class,'tui-body-bold mt-6')]")
    })
    private WebElement goodNewsText;
    @FindAll({
            @FindBy(xpath = "//h4[contains(.,'Sound good?')]"),
            @FindBy(xpath = "//span[contains(.,'Sound good?')]")
    })
    private WebElement soundsGood;
    @FindBy(xpath = "//p[contains(@class,'disclaimer-text')][2]")
    private WebElement secondParagraphOfDisclaimerText;
	@FindBy(xpath = "//p[@data-test-id='DSCL_TEXT']")
	private WebElement bwPageContentText;

	@FindBy(xpath = "//div[contains(@class, 'brightline-to-bw-page__continue-button')]//p")
	private WebElement bwPageAgreeToTermsText;

	@FindBy(xpath = "//button[@data-test-id='BTN_TEXT']")
	private WebElement bwPageContinueButton;
	@FindBy(xpath = "//div/button[contains(text(),'Continue')]")
	private WebElement bwAlternatePageContinueButton;
	@FindBy(className = "brightline-to-bw-page__scroll-content")
	private WebElement bwPageScrollboxText;

	@FindBy (xpath="//app-thank-you-brightline-bw-popup")
	private WebElement thanksForChoosingBWDialog;
	@FindBy(xpath = "//div[contains(@aria-labelledby, 'thankYouBW')]//button")
	private WebElement thanksForChoosingBWDialogCloseButton;

	// links in page
	@FindBy(xpath = "//div[@class='brightline-to-bw-page__scroll-content']/p[1]/a")
	private WebElement bwContactAnAgentLink;
	@FindBy(xpath = "//div[@class='brightline-to-bw-page__scroll-content']/p[2]/a[2]")
	private WebElement bwConsumerDisclosureLink;
	@FindBy(xpath = "//div[@class='brightline-to-bw-page__scroll-content']/p[3]/a")
	private WebElement bwPrivacyNoticeLink;
	@FindBy(xpath = "//div[@class='brightline-to-bw-page__scroll-content']/p[4]/a")
	private WebElement bwSummaryOfRightsLink;
	@FindAll({
            @FindBy(id = "bwHeaderTitle"),
            @FindBy(xpath = "//h4[@class='tui-h4']")
    })
	private WebElement bwDialogTitle;
	@FindBy(xpath = "//div[@class='brightline-to-bw-page-container']/h1")
	private WebElement bwAlternatePageDialogTitle;
	@FindBy(className = "brightline-to-bw-page-body")
	private WebElement bwDialogBodyContent;
	@FindBy(xpath = "//div[@class='brightline-to-bw-page-container']//div/p[1]")
	private WebElement bwDialogBodyContentpara1;
	@FindBy(xpath = "//div[@class='brightline-to-bw-page-container']//div/p[2]")
	private WebElement bwDialogBodyContentpara2;
	@FindBy(xpath = "//div[contains(@class, 'blbw__actions-cancel-button')]")
	private WebElement bwDialogCancelButton;
    @FindAll({
            @FindBy(xpath = "//div/a[contains(text(),'No, thanks')]"),
            @FindBy(xpath = "//div[@class='branding-CTA-section']//button[contains(@class,'no-thanks')]")
    })
    private WebElement bwDialogAlternatePageCancelButton;
	private static final String THANK_YOU_FOR_INTEREST = "Thank you for your interest in Farmers auto insurance.";
	private static final String BASED_ON_THE_INFORMATION = "Based on the information you provided, Farmers is unable to offer you a quote.";
	private static final String BASED_ON_THE_INFORMATION_ALTERNATE = "Based on the information you provided, we may be able to offer you a quote through Bristol West, which is part of Farmers";
	private static final String DUE_TO_PRIOR_INSURANCE_REQUIREMENTS = "Due to prior insurance requirements, including length of continuous coverage and/or prior liability limits ";
	private static final String INSURANCE_REQUIREMENTS_BEGIN_ALTERNATE = THANK_YOU_FOR_INTEREST + SPACE + DUE_TO_PRIOR_INSURANCE_REQUIREMENTS;
	private static final String INSURANCE_REQUIREMENTS_END = " does not meet Farmers underwriting requirements and we are unable to offer you a quote.";
	private static final String ABLE_TO_OFFER_YOU_A_QUOTE = "We may be able to offer you a quote through Bristol West, which is part of Farmers";
	private static final String driverAdjustment = Property.getTestProperty("driver").equals(SAFARI) ? EMPTY_STRING : SPACE;

	private static final String CONTINUE_YOUR_QUOTE_REQUEST_HEADER = "Continue your quote request with Bristol West®, a part of the Farmers Insurance Group®";
	private static final String GET_A_QUOTE_WITH_FARMERS_AFFILIATE_HEADER = "Get a quote with Farmers\u00AE affiliate Bristol West\u00AE";
	private static final String CONTINUE_YOUR_QUOTE_HEADER = "Continue your quote with Farmers\u00AE affiliate Bristol West\u00AE";
	private static final String ITS_NOT_YOU_ITS_US = "It's not you. It's us.";
	private static final String BW_DIALOG_SUBHEADER_TEXT = "We are unable to offer you an online quote for a Farmers-branded policy at this time. We may be able to offer you a quote through Bristol West\u00ae, " +
			"which is part of the Farmers organization, or you can contact a Farmers agent in your area.";
	private static final String BW_DIALOG_ALTERNATEPAGE_SUBHEADER_TEXT = THANK_YOU_FOR_INTEREST + SPACE + BASED_ON_THE_INFORMATION + SPACE + ABLE_TO_OFFER_YOU_A_QUOTE;
	private static final String BW_DIALOG_ALTERNATE_HEADER_TEXT = "Continue your quote request with Farmers\u00ae affiliate Bristol West\u00ae";
	private static final String BW_DIALOG_ALTERNATE_SUBHEADER_TEXT = BASED_ON_THE_INFORMATION + "* " + ABLE_TO_OFFER_YOU_A_QUOTE;
	private static final String BW_DIALOG_DISCLAIMER_TEXT = "By continuing this quote process, you are agreeing to receive a quote provided by a company that is part of the Bristol West Insurance Group\u00ae. " +
			"You also agree that in connection with your quote for insurance, a Bristol West carrier affiliate may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. " +
			"The Bristol West carrier affiliate may use a third party with the development of your insurance score." + driverAdjustment + "If available, a Bristol West Insurance Group entity may access from a third party a driving score based on vehicle data such as hard braking, acceleration, and speeds above 80 mph. " +
			"Bristol West may use this driving data in connection with the rating and underwriting of your auto insurance policy. Your driving history data may be shared with third parties only in connection with a lawful request by a regulatory body. " +
			"Bristol West will archive this data indefinitely for compliance auditing purposes. By proceeding, you authorize a Bristol West Insurance Group entity to obtain and use this data. " +
			"Upon your request, Bristol West will inform you of the name and address of the consumer reporting agency that will furnish this score. " +
			"Under the Fair Credit Reporting Act, you have the right to obtain a free copy of your report from LexisNexis Consumer Center, P.O. Box 105108, Atlanta, GA 30348-5108, 1-800-456-6004 " +
			"Consumer Disclosure. This request must be made no later than 60 days after you receive this notice. In addition, if you find any inaccurate or incomplete information in the report, you may dispute the report with the consumer reporting agency. " +
			"Please note the consumer reporting agency provided the report but did not make any decision regarding your eligibility and would not be able to provide an explanation of the reasons for our action.If you have any questions, please contact Farmers Insurance\u00ae. " +
			"Privacy Notice" + driverAdjustment + "You may also contact a representative if you have any questions.";
	private static final String BW_DIALOG_DISCLAIMER_TEXT2 = "*Under the Fair Credit Reporting Act, you have the right to obtain a free copy of your report from LexisNexis Consumer Center, P.O."+
			" Box 105108, Atlanta, GA 30348-5108 1-800-456-6004 consumer disclosure. This request must be made no later than 60 days after you receive this notice."+
			" In addition, if you find any inaccurate or incomplete information in the report, you may dispute the report with the consumer reporting agency."+
			" Please note the consumer reporting agency provided the report but did not make any decision regarding your eligibility and would not be able to provide an explanation of the reasons for our action. If you have any questions, please contact Farmers Insurance.";
	private static final String BW_ALTERNATE_PAGE_SUBHEADER_TEXT = THANK_YOU_FOR_INTEREST + SPACE + BASED_ON_THE_INFORMATION  + " We may be able to offer you a quote through Bristol West, which is part of Farmers";
	private static final String BW_PAGE_CONTENT_TEXT = "By continuing this quote process, you are agreeing to receive a quote provided by one of the member companies of the Bristol West Insurance Group. " +
			"You also agree that in connection with your quote for insurance, a Bristol West affiliate may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. " +
			"The Bristol West affiliate may use a third party with the development of your insurance score.";
	private static final String BW_PAGE_SCROLLBOX_TEXT_BEGIN = "You may also contact a representative if you have any questions. ";
	private static final String BW_PAGE_SCROLLBOX_TEXT_END = "*Under the Fair Credit Reporting Act, you have the right to obtain a free copy of your report from LexisNexis Consumer Center, P.O. Box 105108, Atlanta, GA 30348-5108 1-800-456-6004 consumer disclosure. " +
			"This request must be made no later than 60 days after you receive this notice. In addition, if you find any inaccurate or incomplete information in the report, you may dispute the report with the consumer reporting agency. " +
			"Please note the consumer reporting agency provided the report but did not make any decision regarding your eligibility and would not be able to provide an explanation of the reasons for our action. " +
			"If you have any questions, please contact Farmers Insurance";
	private static final String BW_PAGE_SCROLLBOX_TEXT_END_WITH_DOT = "*Under the Fair Credit Reporting Act, you have the right to obtain a free copy of your report from LexisNexis Consumer Center, P.O. Box 105108, Atlanta, GA 30348-5108 1-800-456-6004 consumer disclosure. " +
			"This request must be made no later than 60 days after you receive this notice. In addition, if you find any inaccurate or incomplete information in the report, you may dispute the report with the consumer reporting agency. " +
			"Please note the consumer reporting agency provided the report but did not make any decision regarding your eligibility and would not be able to provide an explanation of the reasons for our action. " +
			"If you have any questions, please contact Farmers Insurance.";
	private static final String BW_PAGE_SCROLLBOX_TEXT = BW_PAGE_SCROLLBOX_TEXT_BEGIN + BW_PAGE_SCROLLBOX_TEXT_END;
	private static final String BW_PAGE_SCROLLBOX_ALTERNATE_TEXT = BW_PAGE_SCROLLBOX_TEXT_BEGIN + "Privacy Notice " + BW_PAGE_SCROLLBOX_TEXT_END;
	public ContinueWithBristolWestPage() throws Exception {
	}

	public void validatePageContent(FarmersSoftAssert fsa) {
		final String disclaimerContains = "Disclaimer content contains: ";
		fsa.assertEquals(getTextFromElement(bwPageHeaderText), BW_DIALOG_ALTERNATE_HEADER_TEXT, "Page header content matches: " + BW_DIALOG_ALTERNATE_HEADER_TEXT);
		fsa.assertTrue(testExpectedTextContentContainsForElement(bwPageSubheadingText, BW_ALTERNATE_PAGE_SUBHEADER_TEXT), "Page subheader contains: " + BW_ALTERNATE_PAGE_SUBHEADER_TEXT);
		fsa.assertTrue(testExpectedTextContentContainsForElement(bwPageSubheadingText, BW_PAGE_CONTENT_TEXT), disclaimerContains + BW_PAGE_CONTENT_TEXT);
		fsa.assertTrue(testExpectedTextContentContainsForElement(bwPageSubheadingText, BW_PAGE_SCROLLBOX_TEXT), disclaimerContains + BW_PAGE_SCROLLBOX_TEXT);
		fsa.assertTrue(isBristolWestDialogTextContentCorrect(), disclaimerContains + BW_DIALOG_SUBHEADER_TEXT);
	}

	public void validateDialogContent(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		validatePageHeader(fsa);
		final String subeheaderContains = "Dialog subheader contains: ";
		final String disclaimerContains = "Disclaimer content contains: ";
		if (Arrays.asList(AL, AR, CO, CT, GA, IA, ID, IN, KY, LA, MA, MD, MI, MS, NE, NM, OH, SD, TN, UT, WA, WY, WI).contains(applicant.getStateCode())) {
			if (applicant.getStateCode().equals(GA)) {
				fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, BASED_ON_THE_INFORMATION_ALTERNATE), subeheaderContains + BASED_ON_THE_INFORMATION_ALTERNATE);
			} else {
				fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, BW_DIALOG_ALTERNATE_SUBHEADER_TEXT), subeheaderContains + BW_DIALOG_ALTERNATE_SUBHEADER_TEXT);
			}
		} else if(applicant.getStateCode().equalsIgnoreCase(OR)) {
			fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, THANK_YOU_FOR_INTEREST + " Unfortunately, this quote request does not meet our underwriting requirements for the following reasons: Insureds who require financial responsibility filings are not eligible for coverage with Farmers"),
					subeheaderContains + THANK_YOU_FOR_INTEREST + " Unfortunately, this quote request does not meet our underwriting requirements for the following reasons: Insureds who require financial responsibility filings are not eligible for coverage with Farmers");

		} else {
			fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, INSURANCE_REQUIREMENTS_BEGIN_ALTERNATE + getTheFullNameWithFirstLetterInCaps(applicant.getFirstName() + SPACE + applicant.getLastName()) + INSURANCE_REQUIREMENTS_END),
					subeheaderContains + INSURANCE_REQUIREMENTS_BEGIN_ALTERNATE + getTheFullNameWithFirstLetterInCaps(applicant.getFirstName() + SPACE + applicant.getLastName()) + INSURANCE_REQUIREMENTS_END);
		}
		fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, BW_PAGE_CONTENT_TEXT), disclaimerContains + BW_PAGE_CONTENT_TEXT);
		if (applicant.getStateCode().equals(GA)) {
			fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, BW_PAGE_SCROLLBOX_ALTERNATE_TEXT), disclaimerContains + BW_PAGE_SCROLLBOX_ALTERNATE_TEXT);
		} else {
			fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, BW_PAGE_SCROLLBOX_TEXT), disclaimerContains + BW_PAGE_SCROLLBOX_TEXT);
		}
	}

	public void validatePageHeader(FarmersSoftAssert fsa) throws Exception {
		String validationMessage = "BW switch header validation";
		fsa.assertEquals(getTextFromElement(bwDialogTitle), YOU_RE_STILL_ON_YOUR_WAY_TO_NEW_COVERAGE, validationMessage);
	}



	public void validatePageContentForNJ(FarmersSoftAssert fsa) {
		final String disclaimerContains = "Disclaimer content contains: ";
		fsa.assertEquals(getTextFromElement(waitElementBeVisible(bwPageHeaderText)), GET_A_QUOTE_WITH_FARMERS_AFFILIATE_HEADER, "Page header content matches: " + GET_A_QUOTE_WITH_FARMERS_AFFILIATE_HEADER);
		fsa.assertTrue(testExpectedTextContentContainsForElement(waitElementBeVisible(bwPageSubheadingText), BW_ALTERNATE_PAGE_SUBHEADER_TEXT), "Page subheader contains: " + BW_ALTERNATE_PAGE_SUBHEADER_TEXT);
		fsa.assertTrue(testExpectedTextContentContainsForElement(waitElementBeVisible(firstParagraphOfDisclaimerText), BW_PAGE_CONTENT_TEXT), disclaimerContains + BW_PAGE_CONTENT_TEXT);
		fsa.assertTrue(testExpectedTextContentContainsForElement(waitElementBeVisible(secondParagraphOfDisclaimerText), BW_PAGE_SCROLLBOX_TEXT_END_WITH_DOT), disclaimerContains + BW_PAGE_SCROLLBOX_TEXT_END_WITH_DOT);
	}

	public boolean isBwLogoImageDisplayed() {
		return bristolWestLogoImage.isDisplayed();
	}

	public boolean isBwPageHeaderTextMatching() {
		return isExpectedTextContainedInElement(bwPageHeaderText, CONTINUE_YOUR_QUOTE_REQUEST_HEADER);
	}

	public boolean isOnContinueWithBristolWestPage() {
		return isOnContinueWithBristolWestPage(25);
	}

	public boolean isOnContinueWithBristolWestPage(int secondsToWait) {
		waitForSpinnerToBeGone();
		return isElementVisible(bwPageContinueButton, secondsToWait);
	}

	public boolean isOnGetAQuoteFromBristolWestPage() {
		waitForSpinnerToBeGone();
		return isElementVisible(bwDialogTitle, 4) && List.of(ITS_NOT_YOU_ITS_US, CONTINUE_YOUR_QUOTE_HEADER, GET_A_QUOTE_WITH_FARMERS_AFFILIATE_HEADER).contains(getTextFromElement(bwDialogTitle));
	}

	public QuoteSummaryAutoPage continueWithBwPopUp() throws Exception {
		scrollAndClickOnElement(bwPageContinueButton);
		waitForSpinnerToBeGone();
        Log.info("User chose to continue with BW from pop up", true);
		return new QuoteSummaryAutoPage();
	}

	public void continueWithBWPage(boolean continueWithBW) throws Exception {
		if (continueWithBW) {
			clickElement(bwAlternatePageContinueButton);
		} else {
            clickElement(bwDialogAlternatePageCancelButton);
		}
	}

	public boolean isOnThanksForChoosingBristolWestDialog() {
		return isElementVisible(thanksForChoosingBWDialog, 5);
	}

	public boolean isThanksForChoosingBristolWestDialogContentCorrect() {
		return getTextFromElement(thanksForChoosingBWDialog).equals(
				"Bristol West is a Farmers affiliate and can offer competitive rates for your auto insurance. " +
				"Bristol West coverage options may be different from the ones you reviewed for the Farmers auto quote, but you’ll be able to re-review all the coverages and limits and edit them as you wish. " +
				"The bundle discount for your Farmers property policy may also change, so we’re recalculating both quotes for your review. " +
				"Thank you for your patience as we recalculate your quotes. We’ll load them shortly (about 30 seconds). )");
	}

	public void closeThanksForChoosingBristolWestDialog() {
		scrollAndClickOnElement(thanksForChoosingBWDialogCloseButton);
		waitForSpinnerToBeGone();
	}

	@SneakyThrows
	public void navigateBack() {
		driver().navigate().back();
	}

	public boolean isBristolWestAlternatePageDialogTitleCorrect(String stateCode) throws Exception {
		waitElementBeVisible(bwDialogTitle, 3);
		return List.of("Get a quote with Farmers\u00AE affiliate Bristol West\u00AE", CONTINUE_YOUR_QUOTE_HEADER, ITS_NOT_YOU_ITS_US).contains(getTextFromElement(bwDialogTitle));
    }

	public boolean isBristolWestDialogTextContentCorrect() {
		return isExpectedTextContainedInElement(bwDialogBodyContent, BW_DIALOG_SUBHEADER_TEXT);
	}

	public boolean isBristolWestAlternatePageDialogTextContentCorrect() {
		waitElementBeVisible(bwAlternatePageSubheadingText, 3);
		return isExpectedTextContainedInElement(bwAlternatePageSubheadingText, BW_DIALOG_ALTERNATEPAGE_SUBHEADER_TEXT);
	}

    public void validatePageContentForFarmersToBwReBrandPage(FarmersSoftAssert farmersSoftAssert) throws Exception {

        // validate page unbold texts
        List<WebElement> pageContentElements = driver().findElements(By.xpath("//p[contains(@class,'tui-body-text')]"));
        List<String> expectedPageContent = List.of(
                "Why? It could be your location. It could be risk related. It could be something out of our hands.",
                "Bristol West® — part of the Farmers family — thinks you're a catch. We can connect you in a click so you can explore more coverage options.",
                "Tap below now to continue.",
                "By clicking \"Continue\" you agree to terms below."
        );

        farmersSoftAssert.assertEquals(pageContentElements.size(), expectedPageContent.size(), "Page content element count validation");
        for (int i = 0; i < Math.min(pageContentElements.size(), expectedPageContent.size()); i++) {
            String actualText = getTextFromElement(pageContentElements.get(i));
            String expectedText = expectedPageContent.get(i);
            farmersSoftAssert.assertEquals(actualText, expectedText, "Page content validation for element " + (i + 1));
        }

    }

    public void validatePageSubheaderForFarmersToBwReBrandPage(FarmersSoftAssert farmersSoftAssert) throws Exception {
        farmersSoftAssert.assertEquals(getTextFromElement(bwAlternatePageSubheadingText), YOU_RE_STILL_ON_YOUR_WAY_TO_NEW_COVERAGE, "Page subheader validation");
    }

    public void validatePageCantOfferTextForFarmersToBwReBrandPage(FarmersSoftAssert farmersSoftAssert) throws Exception {
        farmersSoftAssert.assertEquals(getTextFromElement(cantOfferText), "We think you're great. We just can't offer you a Farmers® quote right now.", "Page cant offer text validation");
    }

    public void validatePageGoodNewsTextForFarmersToBwReBrandPage(FarmersSoftAssert farmersSoftAssert) throws Exception {
        farmersSoftAssert.assertEquals(getTextFromElement(goodNewsText), "The good news is that we can still help you find coverage today.", "Page subheader validation");
    }

    public void validatePageSoundsGoodTextForFarmersToBwReBrandPage(FarmersSoftAssert farmersSoftAssert) throws Exception {
        farmersSoftAssert.assertEquals(getTextFromElement(soundsGood), "Sound good?", "Page subheader validation");
    }

    public void validatePageDisclosuresForFarmersToBwReBrandPage(FarmersSoftAssert fsa) throws Exception {
        List<WebElement> disclosureElements = driver().findElements(By.xpath("//p[contains(@class,'tui-small-text disclosure_content')]"));
        List<String> expectedDisclosures = List.of("Our legal disclosure is here to make sure the next steps are clear. No, Legal won't let us shorten it.",
                "By continuing this quote process, you are agreeing to receive a quote provided by one of the member companies of the Bristol West Insurance Group. You also agree that in connection with your quote for insurance, a Bristol West affiliate may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. The Bristol West affiliate may use a third party with the development of your insurance score.",
                "Under the Fair Credit Reporting Act, you have the right to obtain a free copy of your report from LexisNexis Consumer Center, P.O. Box 105108, Atlanta, GA 30348-5108 1-855-789-5755consumer-disclosure.",
                "This request must be made no later than 60 days after you receive this notice. In addition, if you find any inaccurate or incomplete information in the report, you may dispute the report with the consumer reporting agency. Please note the consumer reporting agency provided the report but did not make any decision regarding your eligibility and would not be able to provide an explanation of the reasons for our action. If you have any questions, please contact Farmers Insurance."
        );

        fsa.assertEquals(disclosureElements.size(), expectedDisclosures.size(), "Disclosure element count validation");
        for (int i = 0; i < Math.min(disclosureElements.size(), expectedDisclosures.size()); i++) {
            String actualText = getTextFromElement(disclosureElements.get(i));
            String expectedText = expectedDisclosures.get(i);
            fsa.assertEquals(actualText, expectedText, "Disclosure content validation for element " + (i + 1));
        }
    }
    public void validatePageDisclosuresForFarmersToBwReBrandPopUp(FarmersSoftAssert fsa) throws Exception {
        List<WebElement> disclosureElements = driver().findElements(By.xpath("//p[@class='tui-body-text mt-6']"));
        List<String> expectedDisclosures = List.of("Our legal disclosure is here to make sure the next steps are clear. No, Legal won’t let us shorten it.",
                "By continuing this quote process, you are agreeing to receive a quote provided by one of the member companies of the Bristol West Insurance Group. You also agree that in connection with your quote for insurance, a Bristol West affiliate may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. The Bristol West affiliate may use a third party with the development of your insurance quote."
        );

        fsa.assertEquals(disclosureElements.size(), expectedDisclosures.size(), "Disclosure element count validation");
        for (int i = 0; i < Math.min(disclosureElements.size(), expectedDisclosures.size()); i++) {
            String actualText = disclosureElements.get(i).getText();
            String expectedText = expectedDisclosures.get(i);
            fsa.assertEquals(actualText, expectedText, "Disclosure content validation for element " + (i + 1));
        }
    }

    public boolean isBristolWestAlternatePageForFL_DialogDisclaimerCorrect() {
        String disclaimerAdjustment = Property.getTestProperty("driver").equals(SAFARI) ? BW_DIALOG_SUBHEADER_TEXT : EMPTY_STRING;
        waitElementBeVisible(bwDialogBodyContentpara1, 3);
        waitElementBeVisible(bwDialogBodyContentpara2, 3);
        return isExpectedTextContainedInElement(bwDialogBodyContentpara1, disclaimerAdjustment + BW_PAGE_CONTENT_TEXT) && isExpectedTextContainedInElement(bwDialogBodyContentpara2, disclaimerAdjustment + BW_DIALOG_DISCLAIMER_TEXT2);
    }

	public boolean isBristolWestAlternatePageDialogDisclaimerCorrect() {
		waitElementBeVisible(bwDialogBodyContentpara2,3);
		return isExpectedTextContainedInElement(bwDialogBodyContentpara2, BW_DIALOG_DISCLAIMER_TEXT2);
	}

	public boolean areBristolWestAlternatePageDialogButtonsCorrect() {
		waitElementBeVisible(bwDialogAlternatePageCancelButton,3);
		return isExpectedTextDisplayed(bwDialogAlternatePageCancelButton, "No, thanks") && isExpectedTextDisplayed(bwAlternatePageContinueButton, "Continue");
	}

	public void validateADA_ContinueWitBristoWestPage() {
		if(isADATestingEnabled()) {
			performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
		}
	}

	public void clickNoThanksButton() {
			waitAndClickElement(bwDialogCancelButton);
	}

    public void clickContinueButtonForFGIA() {
        waitAndClickElement(continueToFGIAButton);
    }

	public boolean isContinueWithBristolWestDialogDisplayed() {
		waitForSpinnerToBeGone();
		return (isElementDisplayed(continueToBWDialog, 3));
	}

    public boolean isContinueWithBristolWestDialogDisplayedForRebranding() {
        waitForSpinnerToBeGone();
        return (isElementVisible(continueToBWDialogRebranding, 3));
    }

    public void validateRedirectionToBwInterstitialPage(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert sa = new FarmersSoftAssert();
        sa.assertTrue(wait.until(ExpectedConditions.urlContains("interstitial")), "User is not redirected to Bristol West interstitial page");
        sa.assertEquals(getTextFromElement(continueToBWDialogTitleElement), "It's not you. It's us.", "Dialog title is not as expected");
        sa.assertEquals(getTextFromElement(bwPageSubheadingText),  "You're still on your way to new coverage.", "Bw Interstitial page subheader text is not as expected");
        sa.assertTrue(isElementVisible(bwDialogAlternatePageCancelButton,1), "No, thanks button is not visible on BW interstitial page");
        continueWithBWPage(true);
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        sa.assertTrue(nameAndDobPage.isOnNameAndDobPage(), "User is not navigated to Name and DOB page after clicking continue on BW dialog");
        sa.assertTrue(nameAndDobPage.isOnBristolWest(), "User is not navigated to Bristol West page after clicking continue on BW dialog");
        nameAndDobPage.filloutApplicantForm(applicant);
        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        sa.assertTrue(autoEnterAddressPage.isOnEnterAddressPage(), "User is on the Enter Address page after filling out name and dob page");
        sa.assertAll();
    }
}
