package com.farmers.ffq.hqm.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class IntermediatePage extends HqmBasePage {

    @FindBy(xpath = "//*[@id='quote_unavailable-content']//h2")
    private WebElement pageTitle;

    @FindBy(xpath = "//button[contains(text(),'Start my quote')]")
    private WebElement buttonStartMyQuote;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public IntermediatePage() throws Exception {
        super();
        wait.until(ExpectedConditions.urlContains("/fastquote/intermediatepage"));
    }

    public boolean isUnableToProvideQuoteTextExists() throws Exception {
        return driver().getPageSource().contains("We're sorry, but we are unable to provide an online quote at this time.");
    }

    public boolean isButtonStartMyQuoteExists() throws Exception {
        driverWait(10).until(ExpectedConditions.elementToBeClickable(buttonStartMyQuote));
		return buttonStartMyQuote.isDisplayed();
    }
}
