package com.farmers.ffq.ace.hrc.common;


import com.farmers.ffq.auto.pages.bindpages.EcheckoutSuccessfulPageOneUI;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.PolicyBankPayment;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Data.CustomerData;
import com.farmers.ffq.datatransferobjects.AppStore.Home.VerifyResponse;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import lombok.SneakyThrows;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCBasePage.PAYMENT_PAGE;
import static com.farmers.ffq.utils.CurrencyFormat.convertDoubleToCurrencyString;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCPaymentBasePage extends PolicyPaymentBasePage {
    PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
    PolicyBankPayment policyBankPayment = new PolicyBankPayment();
    PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();

    protected static final String POLICY_PAYMENT = "policy payment";
    @FindBy(xpath = "//h1[contains(text(), '" + POLICY_PAYMENT + "')]")
    protected WebElement policyPaymentHeader;

    @FindBy(xpath = "//span[contains(text(), '12-month term')]")
    private WebElement twelveTermPriceSubHeader;
    protected static final String TWELVE_MONTH_TERM_PAYMENT_LABEL = "12-month term payment";
    @FindBy(xpath = "//span[contains(text(), '" + TWELVE_MONTH_TERM_PAYMENT_LABEL + "')]")
    private WebElement twelveMonthTermPaymentLabel;
    @FindBy(xpath = "//section[contains(@class,'autopay-details')]//*[contains(text(),'Due today')]/following-sibling::*")
    private WebElement dueTodayAmountWebElement;
    @FindBy(xpath = "//div[contains(@class,'autopay-details-bottom-row') and contains(.,'Amount to be billed')]//span[2]")
    private WebElement dueTodayAmountWithAmountToBeBilledWebElement;

    @FindBy(xpath = "//app-model-info-box-bind//h1")
    private WebElement feesLabelModal;
    @FindBy(xpath = "//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][2]/p[1]")
    protected WebElement oneTimeFeesOrExpenseConstantLabel;
    @FindBy(xpath = "//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][2]/span[1]")
    protected WebElement feesLabel;
    @FindBy(xpath = "//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][2]/p[2]")
    protected WebElement oneTimeFeesOrExpenseConstantAmount;
    @FindBy(xpath = "//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][2]/span[2]")
    protected WebElement feesAmount;
    @FindBy(xpath = "//section[contains(@class, 'autopay-details')]//*[contains(@class,'autopay-fees-row')][3]/span[2]")
    protected WebElement taxesAndSurchargesAmountPayInFull;
    @FindBy(xpath = "//div[@class='pif-autopay-fees']//span[text()='Taxes and surcharges']")
    protected WebElement taxesAndSurchargesLabelPayInFull;
    private static final String TAXES_AND_SURCHARGES_LABEL_MONTHLY_PAY_XPATH = "//div[contains(@class,'monthly-autopay-fees')]//p[text()='Taxes and surcharges']";
    @FindBy(xpath = TAXES_AND_SURCHARGES_LABEL_MONTHLY_PAY_XPATH)
    protected WebElement taxesAndSurchargesLabelMonthlyPay;
    @FindBy(xpath = TAXES_AND_SURCHARGES_LABEL_MONTHLY_PAY_XPATH + "//following-sibling::p")
    protected WebElement taxesAndSurchargesAmountMonthlyPay;

    protected static final String TAXES_AND_SURCHARGES_TEXT = "Taxes and surcharges";
    protected static final String FEES_HEADER_LABEL = "Fees";
    protected static final String ONE_TIME_FEES_HEADER_LABEL = "One-time fee";
    protected static final String EXPENSE_CONSTANT_HEADER_LABEL = "Expense Constant";

    protected static final String POLICY_FEES_DESCRIPTION = "A policy fee is applied for each new policy. No fee is applied for additional coverage.";
    protected static final String MEMBERSHIP_FEES_DESCRIPTION = "A membership fee is applied for each new policy. No fee is applied for additional coverage.";
    protected static final String EXPENSE_CONSTANT_FEES_DESCRIPTION = "A fee is applied for each new policy. No fee is applied for additional coverage.";
    protected static final String FAIR_PLAN_RECOUPMENT_FEES_DESCRIPTION = "Includes a one-time policy fee and a recurring";
    protected static final String FAIR_PLAN_RECOUPMENT_FEES_DESCRIPTION_CO = "Per state requirements: a $2 CO Natural Disaster Mitigation fee, and " +
            "a FAIR Plan Assessment recoupment fee have also been included.";
    protected static final String APPLICABLE_TAXES_APPLIED_MN = " Applicable MN taxes applied.";
    protected static final String APPLICABLE_TAXES_APPLIED_KY = " Applicable KY taxes applied.";
    protected static final String APPLICABLE_SURCHARGE_CT = " There is a $12 CT Healthy home surcharge.";

    @FindBy(xpath = "//p[contains(text(), '" + POLICY_FEES_DESCRIPTION + "')]")
    private WebElement policyFeesDescriptionDesktop;
    @FindBy(xpath = "//mat-dialog-container//p[contains(text(), '" + POLICY_FEES_DESCRIPTION + "')]")
    private WebElement policyFeesDescriptionMobile;
    @FindBy(xpath = "//mat-dialog-container//p[contains(text(), '" + EXPENSE_CONSTANT_FEES_DESCRIPTION + "')]")
    private WebElement expenseConstantDescriptionMobile;

    @FindBy(xpath = "//p[contains(@class,'tui-info-box-content')]")
    private WebElement memberShipFeesDescriptionDesktop;

    @FindBy(xpath = "//p/span[contains(text(),'No fee is applied')]")
    private WebElement memberShipFeesDescriptionCODesktop;

    @FindBy(xpath = "//mat-dialog-container//*[contains(@class,'model-caption-text')]")
    private WebElement memberShipFeesDescriptionMobile;

    @FindBy(xpath = "//p[contains(@class,'tui-info-box-content')]")
    private WebElement expenseConstantDescriptionDesktop;

    public static final String MONTHLY_AUTO_PAY_BANK_PARENTHESIS = "Monthly autopay (bank)";
    public static final String MONTHLY_AUTO_PAY_BANK = "Monthly autopay - bank";
    @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_BANK + "')]")
    private WebElement monthlyAutoPayBankHeader;

    public static final String MONTHLY_AUTO_PAY_CARD_WITH_PARENTHESIS = "Monthly autopay (card)";
    public static final String MONTHLY_AUTO_PAY_CARD = "Monthly autopay - card";
    @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_CARD + "')]")
    private WebElement monthlyAutoPayCardHeader;

    @FindBy(xpath = "//div[contains(@class,'pif-autopay-main-payment-row')]//h2")
    private WebElement billedToMortgageeHeader;
    @FindBy(xpath = "//div[contains(@class,'pif-autopay-main-payment-row')]//h2")
    private WebElement newPolicyHeader;
    private static final String AMOUNT_TO_BE_BILLED = "Amount to be billed";
    @FindBy(xpath = "//span[contains(text(), '" + AMOUNT_TO_BE_BILLED + "')]")
    private WebElement amountToBeBilledLabel;
    private static final String AUTHORIZE_PAYMENTS_BY_LENDER_HEADER = "Authorize all payments by your lender";
    @FindBy(xpath = "//p[contains(text(), '" + AUTHORIZE_PAYMENTS_BY_LENDER_HEADER + "')]")
    private WebElement authorizeAllPaymentsByYourLenderHeader;
    private static final String YOUR_PAYMENTS_INCLUDED_IN_MORTGAGE = "Your payments are included in your mortgage.";
    @FindBy(xpath = "//p[contains(text(), '" + YOUR_PAYMENTS_INCLUDED_IN_MORTGAGE + "')]")
    private WebElement yourPaymentIncludedInMortgageText;

    private static final String PAPERLESS_BILLING_IS_NOT_APPLICABLE_FOR_LENDER = "I understand that paperless billing is not applicable for lender paid payment option";
    @FindBy(xpath = "//span[contains(text(), '" + PAPERLESS_BILLING_IS_NOT_APPLICABLE_FOR_LENDER + "')]")
    private WebElement paperlessBillingNotApplicableForLenderBulletPoint;
    private static final String FUTURE_PAYMENTS = "Future payments";
    @FindBy(xpath = "//p[contains(text(), '" + FUTURE_PAYMENTS + "')]")
    private WebElement futurePaymentsHeader;
    private static final String MORTGAGE_COMPANY_START_PAYING_AFTER_FIRST_YEAR = "Your mortgage company will start paying after the first year.";
    @FindBy(xpath = "//p[contains(text(), '" + MORTGAGE_COMPANY_START_PAYING_AFTER_FIRST_YEAR + "')]")
    private WebElement mortgageCompanyWillStartPayingAfterFirstYearText;

    private static final String CONTACT_AGENT_OR_FARMERS_SALES_PARAGRAPH = "If you do not agree with the Terms and Conditions above and/or have any questions," +
            " please contact your agent or Farmers Direct Sales Center to complete this transaction. You can always change your Paperless and Automatic " +
            "Payment settings for future transactions by logging in to your Farmers.com account.";
    @FindBy(xpath = "//section[contains(@class,'disclaimers-text')]//p[contains(@class,'disclaimers-final-text')]")
    private WebElement contactAgentOrFarmersDirectSalesParagraphDisclaimers;

    @FindBy(xpath = "//p[@class='monthly-autopay-disclaimers-charge-text']")
    private WebElement bankPaymentServiceChargeText;

    @FindBy(xpath = "//section//mat-icon[contains(text(),'info')]")
    private WebElement feesInfoIconMobile;
    @FindBy(xpath = "//mat-dialog-container//mat-icon[contains(text(),'close')]")
    private WebElement feesInfoDialogCloseButton;

    @FindBy(xpath = "//div[contains(@class,'autopay-disclaimers-header')]//span")
    private WebElement paymentMethodAddedText;
    private static final String CREDIT_CARD_ADDED_TEXT = "Credit card added.";
    private static final String DEBIT_CARD_ADDED_TEXT = "Debit card added.";
    private static final String BANK_PAYMENT_ADDED_TEXT = "Bank payment account added.";

    private static final String CHANGE_LINK = "Change";
    @FindBy(xpath = "//a[contains(text(), '" + CHANGE_LINK + "')]")
    private WebElement changeLink;

    private static final String DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE = "Debit / Credit card";
    @FindBy(xpath = "//span[contains(text(),'" + DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE + "')]")
    private WebElement debitCreditCardToggleButton;

    private static final String BANK_PAYMENT_TOGGLE_BUTTON_TITLE = "Bank payment";
    @FindBy(xpath = "//span[contains(text(),'" + BANK_PAYMENT_TOGGLE_BUTTON_TITLE + "')]/parent::button")
    private WebElement bankToggleButton;
    @FindBy(xpath = "//div[@id='paymentDialogHeading']//h2")
    private WebElement useSamePaymentMethodQuestion;
    @FindBy(xpath = "//p[@id='paymentDialogConfirmation']")
    private WebElement paymentDialogConfirmation;
    @FindBy(xpath = "//div[@id='paymentDialogInfo']//p")
    private WebElement savedAutoPolicyPaymentMethodLabel;
    @FindBy(xpath = "//div[contains(@class,'payment-dialog-details')]//img")
    private WebElement savedAutoPolicyPaymentCardSymbol;
    @FindBy(xpath = "//div[contains(@class,'payment-dialog-details')]//i")
    private WebElement savedAutoPolicyPaymentBankSymbol;
    @FindBy(xpath = "//span[contains(@class,'payment-dialog-account-numbers')]//small")
    private WebElement savedAutoPolicyPaymentBankAccountNumber;
    @FindBy(xpath = "//div[contains(@class,'payment-dialog-details')]//small")
    private WebElement savedAutoPolicyPaymentDetails;
    @FindBy(xpath = "//button[@id='sameButton']")
    private WebElement sameButton;
    @FindBy(xpath = "//button[@id='differentButton']")
    private WebElement differentButton;
    @FindBy(xpath = "//div[contains(@class, 'popup-close-hit-area')]//mat-icon")
    private WebElement closeIconSamePaymentMethodModal;
    @FindBy(xpath = "//app-payment-reuse-popup")
    private WebElement reusePaymentPopUp;
    @FindBy(xpath = "//mat-dialog-container")
    private WebElement paymentSideSheet;

    protected static final String CHANGE_YOUR_COVERAGE_OPTIONS = "change your coverage options";
    @FindBy(xpath = "//a[contains(text(), '" + CHANGE_YOUR_COVERAGE_OPTIONS + "')]")
    protected WebElement linkChangeCoverageOptions;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceHRCPaymentBasePage() throws Exception {
    }

    public boolean isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPage() {
        return isElementVisible(setUpPaymentMethodButton, Property.PAGELOADTIMEOUT);
    }

    public boolean isOnPaymentPageWithLenderInfo() {
        return isElementVisible(policyPaymentHeader, Property.PAGELOADTIMEOUT);
    }

    public boolean isOnPaymentPayInFullOrMonthlyPayBankOrCardHRCPageRenters() {
        return isElementVisible(completePurchaseButton, Property.PAGELOADTIMEOUT);
    }

    public void validateContentOfPayInFullPageOnLanding(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome, String lobType, String payPlanDescription) throws Exception {
        String stateCode = applicantAceHome.getStateCode();
        validatePolicyPaymentHeader(fsa, lobType);
        validatePayInFullHeader(fsa, lobType);
        validateTwelveMonthTermPriceTopLineAceHRC(fsa, stateCode, ONE_PAY, lobType);
        validateTwelveMonthTermPaymentAceHRC(fsa, lobType, ONE_PAY);
        validateFeesOrOneTimeFeesOrExpenseConstantLabelAndAmountHC(fsa, stateCode, ONE_PAY, lobType);
        if (isExcludedFeeState(stateCode)) { // F91172, F98974/US1101544,US1104962
            validateTaxesAndSurchargesLabelAndAmountHRC(fsa, lobType, payPlanDescription);
        }
        validateDueTodayLabelAndAmount(fsa, ONE_PAY, lobType, stateCode);
        validateFeesSideBarHeaderAndDescription(fsa, ONE_PAY, applicantAceHome, lobType);
        validateAddPreferredPaymentMethodContentValidationAceHRC(fsa, lobType);
        AceHRCBasePage basePage = new AceHRCBasePage();
        basePage.validateQuoteText(PAYMENT_PAGE, applicantAceHome.getQuoteNumber(), fsa, true);
        basePage.validateAgentSection(fsa, PAYMENT_PAGE, applicantAceHome.getAgentId(), lobType);
    }

    public void validateContentOfMonthlyPayBankOrCardPageOnLanding(FarmersSoftAssert fsa, String payPlanDescription, ApplicantAceHome applicantAceHome, String lobType) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        String stateCode = applicantAceHome.getStateCode();
        validatePolicyPaymentHeader(fsa, lobType);
        if (payPlanDescription.equals(MONTHLY_EFT)) {
            validateMonthlyAutoPayBankHeader(fsa, lobType);
        } else {
            validateMonthlyAutoPayCardHeader(fsa, lobType);
        }
        validateTwelveMonthTermPriceTopLineAceHRC(fsa, stateCode, payPlanDescription, lobType);
        validateFirstMonthlyHeaderAndAmount(fsa, appStore, payPlanDescription, lobType);
        validateFeesOrOneTimeFeesOrExpenseConstantLabelAndAmountHC(fsa, stateCode, MONTHLY_EFT, lobType);
        if (isExcludedFeeState(stateCode)) { // F91172, F98974/US1101544,US1104962
            validateTaxesAndSurchargesLabelAndAmountHRC(fsa, lobType, payPlanDescription);
        }
        validateDueTodayLabelAndAmount(fsa, payPlanDescription, lobType, stateCode);
        validateFeesSideBarHeaderAndDescription(fsa, MONTHLY_EFT, applicantAceHome, lobType);
        validateSelectYourPreferredPaymentMethodContentValidationAceHRC(fsa, appStore, lobType);
    }

    public void validateContentOfPayInFullPageWithMortgageeInfoOnLanding(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome, String lobType) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        String stateCode = applicantAceHome.getStateCode();
        Assert.assertTrue(isOnPaymentPageWithLenderInfo(), "Did not reach to Payment page with lender info - " + lobType);
        validatePolicyPaymentHeader(fsa, lobType);
        validateFeesSideBarHeaderAndDescription(fsa, ONE_PAY, applicantAceHome, lobType);
        validateTwelveMonthTermPriceTopLineAceHRC(fsa, stateCode, ONE_PAY, lobType);
        validateTwelveMonthTermPaymentAceHRC(fsa, lobType, ONE_PAY);
        validateFeesOrOneTimeFeesOrExpenseConstantLabelAndAmountHC(fsa, stateCode, ONE_PAY, lobType);
        if (isExcludedFeeState(stateCode)) { // F91172, F98974/US1101544,US1104962
            validateTaxesAndSurchargesLabelAndAmountHRC(fsa, lobType, ONE_PAY);
        }
        if (applicantAceHome.getImpoundAccountSelection().equals(NEW_POLICY_AND_RENEWAL)) {
            validateBilledToMortgageeHeader(fsa, lobType);
            validateAmountToBeBilledLabelAndAmount(fsa, appStore, ONE_PAY, lobType, stateCode);
            validateAuthorizePaymentsByYourLenderSection(fsa, appStore, lobType);
        } else {
            validateDueTodayLabelAndAmount(fsa, ONE_PAY, lobType, stateCode);
            validateAddPreferredPaymentMethodContentValidationAceHRC(fsa, lobType);
        }
        validateTwoBulletPointsAtTheBottomOfThePaymentPageWithPaperless(fsa, HOME);
    }

    public void validateContentOfPayInFullPageWithNewPolicyOnLanding(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome, String lobType, String stateCode) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        Assert.assertTrue(isOnPaymentPageWithLenderInfo(), "Did not reach to Payment page with lender info - " + lobType);
        validatePolicyPaymentHeader(fsa, lobType);
        validateFeesSideBarHeaderAndDescription(fsa, ONE_PAY, applicantAceHome, lobType);
        if (isExcludedFeeState(stateCode)) { // F91172, F98974/US1101544,US1104962
            validateTaxesAndSurchargesLabelAndAmountHRC(fsa, lobType, ONE_PAY);
        }
        validateTwelveMonthTermPriceTopLineAceHRC(fsa, stateCode, ONE_PAY, lobType);
        validateTwelveMonthTermPaymentAceHRC(fsa, lobType, ONE_PAY);
        validateFeesLabelAndPriceWithSpanWebElementAceHRC(fsa, lobType, stateCode);
        validateDueTodayLabelAndAmount(fsa, ONE_PAY, lobType, stateCode);
        if (applicantAceHome.getImpoundAccountSelection().equals(RENEWAL)) {
            validateFuturePaymentsSection(fsa, appStore, lobType);
        }
        validateAddPreferredPaymentMethodContentValidationAceHRC(fsa, lobType);
    }

    public boolean isPolicyPaymentHeaderCorrect(String lobType) {
        return isExpectedTextDisplayed(waitElementBeVisible(policyPaymentHeader), lobType + " " + POLICY_PAYMENT);
    }

    public boolean isTwelveTermPriceSubHeaderDisplayed() {
        return checkIfElementIsDisplayed(twelveTermPriceSubHeader);
    }

    public boolean isTwelveMonthTermPriceAmountDisplayed(String payPlanDescription, VerifyResponse verifyResponse, String lobType, String stateCode) throws Exception {
        VerifyResponse.PaymentSchedule payPlanSchedule = filterListOfPaymentScheduleByPayPlanHRC(verifyResponse.getPaymentSchedules(), payPlanDescription).get(0);
        String fullTermPremium = payPlanSchedule.getFullTermPremium();
        String expectedSixMonthTotalPremium;
        Double feeSurcharge = 0.0;
        double sixMonthTermPriceAmount = 0.0;
        Double doublePolicyFees = doublePolicyFeeAmount(verifyResponse.getPolicyFee().getAmount());
        if (payPlanDescription.equals(ONE_PAY)) {
            if (isExcludedFeeState(stateCode)) { // F91172, F98974/US1101544,US1104962
                double taxAmount = new AceHRCConsolidatedPaymentPage().getTaxAmountHRC(verifyResponse, payPlanDescription);
                double municipalTaxes = new AceHRCConsolidatedPaymentPage().getMunicipalTaxAmountHRC(verifyResponse, payPlanDescription);
                feeSurcharge = stateCode.equals(KY) ?  taxAmount + municipalTaxes : taxAmount;
            } else if (isFairPlanFeeState(stateCode)) {
                feeSurcharge = new AceHRCConsolidatedPaymentPage().getFeeSurchargeAmountFromAppStore(verifyResponse);
            }
            sixMonthTermPriceAmount = Double.parseDouble(fullTermPremium) + doublePolicyFees + feeSurcharge;
            expectedSixMonthTotalPremium = String.format("$%,.2f for 12-month term price", sixMonthTermPriceAmount);
        }  else {
            expectedSixMonthTotalPremium = String.format("$%,.2f for 12-month term payment", Double.parseDouble(fullTermPremium));
        }
        return getTextFromElement(twelveTermPriceSubHeader).equals(expectedSixMonthTotalPremium);
    }

    public boolean isTwelveMonthTermPaymentLabelDisplayed() {
        return waitElementBeVisible(twelveMonthTermPaymentLabel).isDisplayed();
    }

    public boolean isTermPaymentAmountDisplayed(String payPlanDescription, String htmlElement) throws Exception {
        String downPayment = getDownPaymentHRC(payPlanDescription);
        WebElement sixTermPaymentAmount = listOfFullAmountWebElements(downPayment, htmlElement, true).get(0);
        return checkIfElementIsDisplayed(sixTermPaymentAmount);
    }

    public double getDueTodayAmountAceHRC(String payPlanDescription, String stateCode) throws Exception {
        VerifyResponse verifyResponse = getVerifyResponseFromAppStoreHRC();
        String policyFee = getVerifyResponseFromAppStoreHRC().getPolicyFee().getAmount();
        String onePayDownPayment = getDownPaymentHRC(payPlanDescription);
        Double feeSurcharge = 0.0;
        //  F86786 & F89139: PL - Home FFQ & eCheckout - TX and CO Farmers FAIR Plan Recoupment Fee
        if (isFairPlanFeeState(stateCode)) {
            feeSurcharge = new AceHRCConsolidatedPaymentPage().getFeeSurchargeAmountFromAppStore(verifyResponse);
            return Double.parseDouble(policyFee) + Double.parseDouble(onePayDownPayment) + feeSurcharge;
        } else if (isExcludedFeeState(stateCode)) { // F91172, F98974/US1101544,US1104962
            feeSurcharge = new AceHRCConsolidatedPaymentPage().getTaxAmountHRC(verifyResponse, payPlanDescription);
            if (stateCode.equals(KY)) {
                double municipalTaxes = new AceHRCConsolidatedPaymentPage().getMunicipalTaxAmountHRC(verifyResponse, payPlanDescription);
                return Double.parseDouble(policyFee) + Double.parseDouble(onePayDownPayment) + feeSurcharge + municipalTaxes;
            } else {
                return Double.parseDouble(policyFee) + Double.parseDouble(onePayDownPayment) + feeSurcharge;
            }
        } else {
            return Double.parseDouble(policyFee) + Double.parseDouble(onePayDownPayment);
        }
    }

    public boolean isFeesLabelDisplayed() {
	    return checkIfElementIsDisplayed(feesLabel);
    }

    public void validateFeesOrOneTimeFeesOrExpenseConstantLabelAndAmountHC(FarmersSoftAssert fsa, String stateCode, String payPlan, String lobType) throws Exception {
        String expectedFeesAmount = findFeesOneTimeFeesOrExpenseConstantAmountFromAppStore(stateCode, payPlan);
        String foundFeesAmount;
        WebElement feeLabel = payPlan.equals(MONTHLY_EFT)? oneTimeFeesOrExpenseConstantLabel : feesLabel;
        WebElement feeAmount = payPlan.equals(MONTHLY_EFT)? oneTimeFeesOrExpenseConstantAmount : feesAmount;
        if (stateCode.equals(MD)) {
            fsa.assertEquals(getTextFromElement(feeLabel), EXPENSE_CONSTANT_HEADER_LABEL, EXPENSE_CONSTANT_HEADER_LABEL +
                    " header text verification on main page - " + lobType);
            foundFeesAmount = getTextFromElement(feeAmount);
        } else if (isFairPlanFeeState(stateCode)) { //  F86786 & F89139: PL - Home FFQ & eCheckout - TX and CO Farmers FAIR Plan Recoupment Fee
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(feeLabel, 5)), FEES_HEADER_LABEL, FEES_HEADER_LABEL +
                    " header text verification on main page - " + lobType);
            foundFeesAmount = getTextFromElement(waitElementBeVisible(feeAmount, 5));
        } else if (payPlan.equals(MONTHLY_EFT)){
            fsa.assertEquals(getTextFromElement(feeLabel), ONE_TIME_FEES_HEADER_LABEL, ONE_TIME_FEES_HEADER_LABEL +
                    " header text verification on main page - " + lobType);
            foundFeesAmount = getTextFromElement(feeAmount);
        } else {
            fsa.assertEquals(getTextFromElement(feeLabel), FEES_HEADER_LABEL, FEES_HEADER_LABEL +
                    " header text verification on main page - " + lobType);
            foundFeesAmount = getTextFromElement(feeAmount);
        }
        fsa.assertTrue(foundFeesAmount.contains(expectedFeesAmount), "Fees amount verification on main screen - " + lobType);
    }

    // F91172 - FFQ Payment Screen Enhancement for Fees and Surcharges - KY state changes
    public void validateTaxesAndSurchargesLabelAndAmountHRC(FarmersSoftAssert fsa, String lobType, String payPlanDescription) throws Exception {
        VerifyResponse verifyResponse = getVerifyResponseFromAppStoreHRC();
        String expectedFeesAmount = convertDoubleToCurrencyString(new AceHRCConsolidatedPaymentPage().getTaxAmountHRC(verifyResponse, payPlanDescription));
        WebElement taxesAndSurchargesLabel = List.of(MONTHLY_EFT, MONTHLY_DEBIT_CREDIT_CARD).contains(payPlanDescription) ? taxesAndSurchargesLabelMonthlyPay : taxesAndSurchargesLabelPayInFull;
        WebElement taxesAndSurchargesAmount = List.of(MONTHLY_EFT, MONTHLY_DEBIT_CREDIT_CARD).contains(payPlanDescription) ? taxesAndSurchargesAmountMonthlyPay : taxesAndSurchargesAmountPayInFull;
        fsa.assertTrue(isElementVisible(taxesAndSurchargesLabel, 3), "Taxes and surcharges label is visible - " + lobType);
        fsa.assertEquals(getTextFromElement(taxesAndSurchargesLabel), TAXES_AND_SURCHARGES_TEXT, TAXES_AND_SURCHARGES_TEXT +
                " header text verification on main page - " + lobType);
        String foundFeesAmount = getTextFromElement(taxesAndSurchargesAmount);
        fsa.assertTrue(foundFeesAmount.contains(expectedFeesAmount), "Taxes and Surcharges amount verification on payment details page - " + lobType);
    }

    public boolean isMonthlyAutoPayBankHeaderDisplayed() {
        return checkIfElementIsDisplayed(monthlyAutoPayBankHeader);
    }

    public boolean isMonthlyAutoPayCardHeaderDisplayed() {
        return checkIfElementIsDisplayed(monthlyAutoPayCardHeader);
    }

    private boolean checkIfElementIsDisplayed(WebElement elementToCheck) {
        try {
            return waitElementBeVisible(elementToCheck).isDisplayed();
        } catch (TimeoutException te) {
            return false;
        }
    }

    public void validatePolicyPaymentHeader(FarmersSoftAssert fsa, String lobType) throws Exception {
        scrollToTopOfPage();
        fsa.assertTrue(isElementInViewport(policyPaymentHeader),  lobType + "Payment page - " + lobType + " page title is in Viewport");
        fsa.assertTrue(isPolicyPaymentHeaderCorrect(lobType),  lobType + "Policy payment header verification - " + lobType);
    }

    public void validatePayInFullHeader(FarmersSoftAssert fsa, String lobType){
        fsa.assertTrue(isPayInFullHeaderCorrect(), "Pay in full header verification - " + lobType);
    }

    public void validateTwelveMonthTermPriceTopLineAceHRC(FarmersSoftAssert fsa, String stateCode, String payPlanDesc, String lobType) throws Exception {
        fsa.assertTrue(isTwelveTermPriceSubHeaderDisplayed(), "12-month term price sub header verification - " + lobType);
        fsa.assertTrue(isTwelveMonthTermPriceAmountDisplayed(payPlanDesc, getVerifyResponseFromAppStoreHRC(), lobType, stateCode), "12-month term price verification - " + lobType);
    }

    public void validateTwelveMonthTermPaymentAceHRC(FarmersSoftAssert fsa, String lobType, String payPlan) throws Exception {
        fsa.assertTrue(isTwelveMonthTermPaymentLabelDisplayed(), TWELVE_MONTH_TERM_PAYMENT_LABEL + " displayed - " + lobType);
        fsa.assertTrue(isTermPaymentAmountDisplayed(payPlan, "span"), TWELVE_MONTH_TERM_PAYMENT_LABEL + " displayed - " + lobType);
    }

    public void validateFeesLabelAndPriceWithSpanWebElementAceHRC(FarmersSoftAssert fsa, String lobType, String stateCode) throws Exception {
        fsa.assertTrue(isFeesLabelDisplayed(), "Fees label displayed - span web element - " + lobType);
        fsa.assertTrue(isPolicyFeeAmountDisplayedHRC(stateCode, "span"), "Fees amount verification - " + lobType);
    }

    public String findFeesOneTimeFeesOrExpenseConstantAmountFromAppStore(String stateCode, String payPlan) throws Exception {
        VerifyResponse verifyResponse = getVerifyResponseFromAppStoreHRC();
        String policyFee = getVerifyResponseFromAppStoreHRC().getPolicyFee().getAmount();
        Double policyFeesAmount = CurrencyFormat.convertCurrencyStringToDouble(policyFee);

        //  F86786 & F89139: PL - Home FFQ & eCheckout - TX & CO Farmers FAIR Plan Recoupment Fee
        if (isFairPlanFeeState(stateCode)){
            Double feeSurcharge = new AceHRCConsolidatedPaymentPage().getFeeSurchargeAmountFromAppStore(verifyResponse);
            return CurrencyFormat.convertDoubleToCurrencyString(policyFeesAmount + feeSurcharge);
        } else if (stateCode.equals(KY)) {
            Double municipalTaxes = new AceHRCConsolidatedPaymentPage().getMunicipalTaxAmountHRC(verifyResponse, payPlan);
            return CurrencyFormat.convertDoubleToCurrencyString(policyFeesAmount + municipalTaxes);
        } else {
            return CurrencyFormat.convertStringIntoCurrencyFormat(policyFee);
        }
    }

    public void validateDueTodayLabelAndAmount(FarmersSoftAssert fsa, String payPlanDescription, String lobType, String stateCode) throws Exception {
        fsa.assertTrue(isDueTodayCorrect(), "Due today label verification - " + lobType);
        fsa.assertEquals(getTextFromElement(dueTodayAmountWebElement), String.format("$%,.2f", getDueTodayAmountAceHRC(payPlanDescription, stateCode)), "Due today amount verification for " + payPlanDescription);
    }

    public void validateAmountToBeBilledLabelAndAmount(FarmersSoftAssert fsa, AppStore appStore, String payPlanDescription, String lobType, String stateCode) throws Exception {
        fsa.assertTrue(amountToBeBilledLabel.isDisplayed(), amountToBeBilledLabel + " label verification - " + lobType);
        fsa.assertEquals(getTextFromElement(dueTodayAmountWithAmountToBeBilledWebElement), String.format("$%,.2f", getDueTodayAmountAceHRC(payPlanDescription, stateCode)), "Due today amount with mortgagee info verification for " + payPlanDescription);
    }

    public void validateFeesSideBarHeaderAndDescription(FarmersSoftAssert fsa, String payPlan, ApplicantAceHome applicantAceHome, String lobType){
        String stateCode = applicantAceHome.getStateCode();

        if(!stateCode.equals(KS)) {
            String MEMBERSHIP_FEES_TAXES_KY = MEMBERSHIP_FEES_DESCRIPTION + APPLICABLE_TAXES_APPLIED_KY;
            String MEMBERSHIP_FEES_TAXES_MN = MEMBERSHIP_FEES_DESCRIPTION + APPLICABLE_TAXES_APPLIED_MN;
            String MEMBERSHIP_FEES_TAXES_CO = MEMBERSHIP_FEES_DESCRIPTION + SPACE + FAIR_PLAN_RECOUPMENT_FEES_DESCRIPTION_CO;
            String MEMBERSHIP_FEES_TAXES_CT = MEMBERSHIP_FEES_DESCRIPTION + APPLICABLE_SURCHARGE_CT;
            String MEMBERSHIP_FEES_TAXES_CA = FAIR_PLAN_RECOUPMENT_FEES_DESCRIPTION + SPACE + "temporary supplemental fee.";
            String FAIR_PLAN_RECOUPMENT_DESCRIPTION = FAIR_PLAN_RECOUPMENT_FEES_DESCRIPTION + SPACE + "FAIR Plan Assessment recoupment.";
            if (isUseMobileViewEnabled()) {
                waitAndClickElement(feesInfoIconMobile);
                fsa.assertTrue(isElementDisplayed(feesLabelModal, 3), "Fees side-sheet title displayed - " + lobType);
                if (stateCode.equals(MD)) {
                    fsa.assertEquals(getTextFromElement(feesLabelModal), EXPENSE_CONSTANT_HEADER_LABEL, EXPENSE_CONSTANT_HEADER_LABEL + " verification in modal box mobile view  - " + lobType);
                    fsa.assertEquals(getTextFromElement(expenseConstantDescriptionMobile), EXPENSE_CONSTANT_FEES_DESCRIPTION, "Expense constant description in modal box mobile view displayed - " + lobType);
                } else if (stateCode.equals(KY)) {
                    fsa.assertEquals(getTextFromElement(feesLabelModal), FEES_HEADER_LABEL, FEES_HEADER_LABEL + " verification in in modal box mobile view  - " + lobType);
                    fsa.assertEquals(getTextFromElement(memberShipFeesDescriptionMobile), MEMBERSHIP_FEES_TAXES_KY, "Membership fees description in modal box mobile view displayed - " + lobType);
                } //  F86786: PL - Home FFQ & eCheckout - TX Farmers FAIR Plan Recoupment Fee
                else if (isFairPlanFeeState(stateCode)) {
                    String membershipFeesDescription;
                    fsa.assertEquals(getTextFromElement(feesLabelModal), FEES_HEADER_LABEL, FEES_HEADER_LABEL + " verification in in modal box mobile view  - " + lobType);
                    if(stateCode.equals(CA)) {
                        membershipFeesDescription = MEMBERSHIP_FEES_TAXES_CA;
                    } else if (stateCode.equals(CO)) {
                        membershipFeesDescription = MEMBERSHIP_FEES_TAXES_CO;
                    } else {
                        membershipFeesDescription = FAIR_PLAN_RECOUPMENT_DESCRIPTION;
                    }
                    fsa.assertEquals(getTextFromElement(memberShipFeesDescriptionMobile), membershipFeesDescription, "FAIR Plan Recoupment fees description in side bar displayed - " + lobType);
                } else {
                    fsa.assertEquals(getTextFromElement(feesLabelModal), FEES_HEADER_LABEL, FEES_HEADER_LABEL + " verification in in modal box mobile view  - " + lobType);
                    String MEMBERSHIP_FEES_DESC = stateCode.equals(CT) ? MEMBERSHIP_FEES_TAXES_CT : MEMBERSHIP_FEES_DESCRIPTION;
                    if (lobType.equals(HOME)) {
                        if (Arrays.asList(AZ, CA, IA, ID, IL, IN, MA, MN, MT, NC, NY, OH, OK, OR, WA).contains(stateCode)) {
                            fsa.assertEquals(getTextFromElement(policyFeesDescriptionMobile), POLICY_FEES_DESCRIPTION, "Policy fees description in side bar displayed - " + lobType);
                        } else {
                            fsa.assertEquals(getTextFromElement(memberShipFeesDescriptionMobile), MEMBERSHIP_FEES_DESC, "Membership fees description in side bar displayed - " + lobType);
                        }
                    } else {
                        if (Arrays.asList(AL, IL, ID, MA, MT, NC, NY).contains(stateCode)) {
                            fsa.assertEquals(getTextFromElement(policyFeesDescriptionMobile), POLICY_FEES_DESCRIPTION, "Policy fees description in side bar displayed - " + lobType);
                        } else if (stateCode.equals(MN)) {
                            fsa.assertEquals(getTextFromElement(memberShipFeesDescriptionMobile), MEMBERSHIP_FEES_TAXES_MN, "Membership fees description in side bar displayed - " + lobType);
                        } else {
                            fsa.assertEquals(getTextFromElement(memberShipFeesDescriptionMobile), MEMBERSHIP_FEES_DESC, "Membership fees description in side bar displayed - " + lobType);
                        }
                    }
                }
                waitAndClickElement(feesInfoDialogCloseButton);
            } else {
                if (stateCode.equals(MD)) {
                    fsa.assertEquals(getTextFromElement(feeSideBarHeader), EXPENSE_CONSTANT_HEADER_LABEL, EXPENSE_CONSTANT_HEADER_LABEL + " label verification in side bar - " + lobType);
                    fsa.assertEquals(getTextFromElement(expenseConstantDescriptionDesktop), EXPENSE_CONSTANT_FEES_DESCRIPTION, "Expense constant fees description in side bar displayed - " + lobType);
                } else if (stateCode.equals(KY)) {
                    fsa.assertEquals(getTextFromElement(feeSideBarHeader), FEES_HEADER_LABEL, FEES_HEADER_LABEL + " label verification in side bar - " + lobType);
                    fsa.assertEquals(getTextFromElement(memberShipFeesDescriptionDesktop), MEMBERSHIP_FEES_TAXES_KY, "Membership fees description in side bar displayed - " + lobType);
                } //  F86786: PL - Home FFQ & eCheckout - TX Farmers FAIR Plan Recoupment Fee
                else if (isFairPlanFeeState(stateCode)) {
                    fsa.assertEquals(getTextFromElement(feeSideBarHeader), FEES_HEADER_LABEL, FEES_HEADER_LABEL + " verification in side bar - " + lobType);
                    WebElement membershipFeesDescription = payPlan.equals(ONE_PAY) && stateCode.equals(CO) ? memberShipFeesDescriptionCODesktop : memberShipFeesDescriptionDesktop;
                    String membershipFeesDescriptionText;
                    fsa.assertEquals(getTextFromElement(feeSideBarHeader), FEES_HEADER_LABEL, FEES_HEADER_LABEL + " verification in in modal box mobile view  - " + lobType);
                    if(stateCode.equals(CA)) {
                        membershipFeesDescriptionText = MEMBERSHIP_FEES_TAXES_CA;
                    } else if (stateCode.equals(CO)) {
                        membershipFeesDescriptionText = MEMBERSHIP_FEES_TAXES_CO;
                    } else {
                        membershipFeesDescriptionText = FAIR_PLAN_RECOUPMENT_DESCRIPTION;
                    }
                    fsa.assertEquals(getTextFromElement(membershipFeesDescription), membershipFeesDescriptionText, "FAIR Plan Recoupment fees description in side bar displayed - " + lobType);
                } else {
                    fsa.assertEquals(getTextFromElement(feeSideBarHeader), FEES_HEADER_LABEL, FEES_HEADER_LABEL + " verification in side bar  - " + lobType);
                    String MEMBERSHIP_FEES_DESC = stateCode.equals(CT) ? MEMBERSHIP_FEES_TAXES_CT : MEMBERSHIP_FEES_DESCRIPTION;
                    if (lobType.equals(HOME)) {
                        if (Arrays.asList(AZ, CA, IA, ID, IL, IN, MA, MN, MT, NC, NY, OH, OK, OR, WA).contains(stateCode)) {
                            fsa.assertEquals(getTextFromElement(policyFeesDescriptionDesktop), POLICY_FEES_DESCRIPTION, "Policy fees description in side bar displayed - " + lobType);
                        } else {
                            fsa.assertEquals(getTextFromElement(memberShipFeesDescriptionDesktop), MEMBERSHIP_FEES_DESC, "Membership fees description in side bar displayed - " + lobType);
                        }
                    } else {
                        if (Arrays.asList(AL, IL, ID, MA, MT, NC, NY).contains(stateCode)) {
                            fsa.assertEquals(getTextFromElement(policyFeesDescriptionDesktop), POLICY_FEES_DESCRIPTION, "Policy fees description in side bar displayed - " + lobType);
                        } else if (stateCode.equals(MN)) {
                            fsa.assertEquals(getTextFromElement(memberShipFeesDescriptionDesktop), MEMBERSHIP_FEES_TAXES_MN, "Membership fees description in side bar displayed - " + lobType);
                        } else {
                            fsa.assertEquals(getTextFromElement(memberShipFeesDescriptionDesktop), MEMBERSHIP_FEES_DESC, "Membership fees description in side bar displayed - " + lobType);
                        }
                    }
                }
            }
        }
    }

    public void validateAddPreferredPaymentMethodContentValidationAceHRC(FarmersSoftAssert fsa, String lobType){
        fsa.assertTrue(isSelectPreferredPaymentCorrect(), "Select preferred payment method header verification - " + lobType);
        fsa.assertTrue(isBankDebitCreditPaymentCorrect(), "Use bank/debit card/credit card line text verification - " + lobType);
        fsa.assertTrue(isNoServiceChargeCorrect(), "No service charge when pay in full line text verification - " + lobType);
        fsa.assertTrue(isSetUpPaymentMethodCorrect(), "Set up payment method button displayed - " + lobType);
    }

    public void validateMonthlyAutoPayBankHeader(FarmersSoftAssert fsa, String lobType){
        fsa.assertTrue(isMonthlyAutoPayBankHeaderDisplayed(), "Monthly autopay - bank header verification - " + lobType);
    }

    public void validateFirstMonthlyHeaderAndAmount(FarmersSoftAssert fsa, AppStore appStore, String payPlanDescription, String lobType) throws Exception {
        fsa.assertTrue(isFirstMonthlyPaymentLabelCorrect(), "First monthly payment label text verification - " + lobType);
        fsa.assertTrue(isFirstMonthTermPaymentAmountDisplayedHRC(payPlanDescription, "p", appStore), "First monthly payment amount verification - " + lobType);
    }

    public void validateSelectYourPreferredPaymentMethodContentValidationAceHRC(FarmersSoftAssert fsa, AppStore appStore, String lobType){
        // re-assigning session storage
        List<VerifyResponse.PaymentSchedule> paymentSchedules = getVerifyResponseFromAppStoreHRC().getPaymentSchedules();

        fsa.assertTrue(isSelectPreferredPaymentLabelCorrect(), "Select your preferred payment method label verification - " + lobType);

        // Bank payment label and service charge content validation
        fsa.assertTrue(isBankPaymentRadioButtonDisplayedAlternative(), "Bank payment radio button is displayed");
        fsa.assertTrue(isBankPaymentLabelCorrect("Bank payment"), "Bank payment label text verification - " + lobType);
        String administrativeChargeForBankAccount = paymentSchedules.stream().filter(p -> p.getPayPlanDescription().equals(MONTHLY_EFT)).findFirst().get().getAdministrativeCharges().getCurrencyAmount();
        String expectedBankAccountServiceChargeLabel = String.format("$%d in service charges", Math.round(Double.parseDouble(administrativeChargeForBankAccount)));
        isBankAccountServiceChargesAmountCorrect(expectedBankAccountServiceChargeLabel, fsa);

        // Card payment label and debit/credit service charge content validation
        fsa.assertTrue(isCardPaymentRadioButtonDisplayedAlternative(), "Card radio button is displayed - " + lobType);
        fsa.assertTrue(isCardPaymentLabelCorrect("Card"), "Card payment label text verification - " + lobType);
        fsa.assertTrue(isFutureMonthlyChargesLabelCorrect(), errorMessage("Future monthly service charges"));
        String administrativeChargeForDebitCard = paymentSchedules.stream().filter(p -> p.getPayPlanDescription().equals(MONTHLY_DEBIT_CARD_DESCRIPTION)).findFirst().get().getAdministrativeCharges().getCurrencyAmount();
        String administrativeChargeForCreditCard = paymentSchedules.stream().filter(p -> p.getPayPlanDescription().equals(MONTHLY_DEBIT_CREDIT_CARD)).findFirst().get().getAdministrativeCharges().getCurrencyAmount();
        String expectedDebitCardServiceChargeLabel = String.format("$%d: Debit card", Math.round(Double.parseDouble(administrativeChargeForDebitCard)));
        String expectedCreditCardServiceChargeLabel = String.format("$%d: Credit card", Math.round(Double.parseDouble(administrativeChargeForCreditCard)));
        isDebitCardAdministrativeFeeLabelCorrect(expectedDebitCardServiceChargeLabel, fsa);
        isCreditCardAdministrativeFeeLabelCorrect(expectedCreditCardServiceChargeLabel, fsa);
        logInfoMessage(appStore.getData().getQuoteNumber());
    }

    public void validateMonthlyAutoPayCardHeader(FarmersSoftAssert fsa, String lobType){
        fsa.assertTrue(isMonthlyAutoPayCardHeaderDisplayed(), "Monthly autopay - card header verification - " + lobType);
    }

    public void validateBilledToMortgageeHeader(FarmersSoftAssert fsa, String lobType){
        String BILLED_TO_MORTGAGEE = "Billed to mortgagee";
        fsa.assertEquals(getTextFromElement(billedToMortgageeHeader), BILLED_TO_MORTGAGEE, BILLED_TO_MORTGAGEE + " text verification - " + lobType);
    }

    public void validateNewPolicyHeader(FarmersSoftAssert fsa, String lobType){
        String BILLED_TO_MORTGAGEE = "New Policy";
        fsa.assertEquals(getTextFromElement(billedToMortgageeHeader), BILLED_TO_MORTGAGEE, BILLED_TO_MORTGAGEE + " text verification - " + lobType);
    }

    public void validateAuthorizePaymentsByYourLenderSection(FarmersSoftAssert fsa, AppStore appStore, String lobType) throws Exception {
        fsa.assertTrue(authorizeAllPaymentsByYourLenderHeader.isDisplayed(), AUTHORIZE_PAYMENTS_BY_LENDER_HEADER + " header text verification - " + lobType);
        String lenderNameFromAppStore = appStore.getHome().getAdditionalHome().getLenderName();
        WebElement lenderNameWebElement = driver().findElement(By.xpath("//p[contains(text(), '" + lenderNameFromAppStore + "')]"));
        fsa.assertTrue(lenderNameWebElement.isDisplayed(), "Lender name - " + lenderNameFromAppStore + " displayed - " + lobType);
        fsa.assertTrue(yourPaymentIncludedInMortgageText.isDisplayed(), YOUR_PAYMENTS_INCLUDED_IN_MORTGAGE + " text verification - " + lobType);
    }

    public void validateFuturePaymentsSection(FarmersSoftAssert fsa, AppStore appStore, String lobType) throws Exception {
        fsa.assertTrue(futurePaymentsHeader.isDisplayed(), FUTURE_PAYMENTS + " header text verification - " + lobType);
        String lenderNameFromAppStore = appStore.getHome().getAdditionalHome().getLenderName();
        WebElement lenderNameWebElement = driver().findElement(By.xpath("//p[contains(text(), '" + lenderNameFromAppStore + "')]"));
        fsa.assertTrue(lenderNameWebElement.isDisplayed(), "Lender name - " + lenderNameFromAppStore + " displayed - " + lobType);
        fsa.assertTrue(mortgageCompanyWillStartPayingAfterFirstYearText.isDisplayed(), MORTGAGE_COMPANY_START_PAYING_AFTER_FIRST_YEAR + " text verification - " + lobType);
    }

    public void validateTwoBulletPointsAtTheBottomOfThePaymentPageWithPaperless(FarmersSoftAssert fsa, String lobType){
        if (isElementDisplayed(completePurchaseButton, 3)) {
            fsa.assertTrue(policyPaymentBasePage.isByClickingCompletePurchaseLabelCorrect(), "By clicking complete purchase button displayed - " + lobType);
            fsa.assertTrue(policyPaymentBasePage.isReadAndAgreedBulletPointOneCorrect(), "Read and agree bullet point one text verification - " + lobType);
            fsa.assertTrue(paperlessBillingNotApplicableForLenderBulletPoint.isDisplayed(), "Paperless billing not applicable for lender option text verification - " + lobType);
            fsa.assertTrue(policyPaymentBasePage.isIfDoNotAgreeWithTermsAndConditionLabelCorrect(), "If do not agree terms and conditions label text verification - " + lobType);
        }
    }

    public void validateThreeBulletPointsAtTheBottomOfThePaymentPageWithPaperless(FarmersSoftAssert fsa, String lobType){
        if (isElementDisplayed(completePurchaseButton, 3)) {
            fsa.assertTrue(policyPaymentBasePage.isByClickingCompletePurchaseLabelCorrect(), "By clicking complete purchase button displayed - " + lobType);
            fsa.assertTrue(policyPaymentBasePage.isReadAndAgreedBulletPointOneCorrect(), "Read and agree bullet point one text verification - " + lobType);
            fsa.assertTrue(policyPaymentBasePage.isReadAndAgreedBulletPointTwoCorrect(), "Read and agree bullet point two text verification - " + lobType);
            fsa.assertTrue(paperlessBillingNotApplicableForLenderBulletPoint.isDisplayed(), "Paperless billing not applicable for lender option text verification - " + lobType);
            fsa.assertTrue(policyPaymentBasePage.isIfDoNotAgreeWithTermsAndConditionLabelCorrect(), "If do not agree terms and conditions label text verification - " + lobType);
        }
    }

    public void validateTwoBulletPointsAtTheBottomOfThePaymentPagePayInFull(FarmersSoftAssert fsa, String lobType){
        if (isElementDisplayed(completePurchaseButton,3)) {
            fsa.assertTrue(policyPaymentBasePage.isByClickingCompletePurchaseLabelCorrect(), "By clicking complete purchase button displayed - " + lobType);
            fsa.assertTrue(policyPaymentBasePage.isReadAndAgreedBulletPointOneCorrect(), "Read and agree bullet point one text verification - " + lobType);
            fsa.assertTrue(policyPaymentBasePage.isReadAndAgreedBulletPointTwoCorrect(), "Read and agree bullet point two text verification - " + lobType);
        }
    }

    public void validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(FarmersSoftAssert fsa, String lobType){
        if (isElementDisplayed(completePurchaseButton,3)) {
            fsa.assertTrue(policyPaymentBasePage.isByClickingCompletePurchaseLabelCorrect(), "By clicking complete purchase button displayed - " + lobType);
            fsa.assertTrue(policyPaymentBasePage.isReadAndAgreedBulletPointOneCorrect(), "Read and agree bullet point one text verification - " + lobType);
            fsa.assertTrue(policyPaymentBasePage.isReadAndAgreedBulletPointTwoMonthlyPayCorrect(), "Read and agree bullet point two text for monthly auto pay verification - " + lobType);
        }
    }

    public void validateFinishDocumentsSection(FarmersSoftAssert fsa, String lobType){
        fsa.assertTrue(isFinishDocumentsButtonTextMatching(), "'Finish documents' button displayed - " + lobType);
        fsa.assertEquals(getTextFromElement(finishDocumentsSection), FINISH_DOCUMENTS_SECTION_TEXT, "Finish documents section text matches - " + lobType);
    }

    public void validateCompletePurchase(FarmersSoftAssert fsa, String lobType) throws Exception {
        if (isElementDisplayed(completePurchaseButton,3)) {
            Log.info("'Complete purchase' button is displayed.");
            clickCompletePurchaseButton();
            validateECheckOutPage(fsa, lobType);
        } else if (isElementDisplayed(finishDocumentsButton,3)) {
            Log.info("'Finish documents' button is displayed.");
            validateFinishDocumentsSection(fsa, lobType);
        } else {
            fsa.fail("Did not find 'Complete purchase' or 'Finish documents' buttons.");
        }
    }

    public void validateOneTimePaymentRecurringRadioButtonText(FarmersSoftAssert fsa, String lobType){
        fsa.assertTrue(policyDebitCreditPayment.isAutomaticRecurringTextCorrect(),"Automatic recurring radio button text verification - " + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isOneTimePaymentTextCorrect(),"One time payment radio button text verification - " + lobType);
    }

    public void validateOpeningLinksIntoNewTabsOnPaymentPage(FarmersSoftAssert fsa, String lobType) throws Exception {
        fsa.assertTrue(policyPaymentBasePage.validateOpeningLinksInNewTab(),"Title verification for one or more opened tab - " + lobType);
    }

    public void validateECheckOutPage(FarmersSoftAssert fsa, String lobType) throws Exception {
        EcheckoutSuccessfulPageOneUI echeckoutSuccessfulPageOneUI = new EcheckoutSuccessfulPageOneUI();
        echeckoutSuccessfulPageOneUI.waitForSpinnerToBeGone();

        if(echeckoutSuccessfulPageOneUI.isSignElectronicallyPresent()) {
            fsa.assertTrue(echeckoutSuccessfulPageOneUI.isSignElectronicallyPresent(), "Sign electronically is not present - " + lobType);
            driver().findElement(By.xpath("//button[contains(.,' Start signing ')]")).click();
            sleep(3);
        } else if (new KnockoutInconveniencePage().isInconvenienceTitlePresent()){
            Log.info("User landed on the inconvenience page as the bind call was not successful, please check the db logs to see the failure details - " + lobType);
        } else {
            fsa.assertTrue(echeckoutSuccessfulPageOneUI.isPaymentSuccessfulMessageCorrect(),"User landed on the Payment(s) successful page - " + lobType);
        }
    }

    public void validateContentOfBankPaymentInIFrame(FarmersSoftAssert fsa, AppStore.Data.CustomerData customerData, String lobType) throws Exception {
        fsa.assertTrue(policyPaymentBasePage.isAddPaymentMethodLabelCorrect(), "Add payment method label verification - " + lobType);
        fsa.assertTrue(policyPaymentBasePage.isBankPaymentButtonTextCorrect(), "Bank payment button text verification - " + lobType);
        fsa.assertTrue(policyPaymentBasePage.isDebitCreditCardButtonTextCorrect(), "Debit credit card button text verification - " + lobType);
        policyPaymentBasePage.switchToPaymentUsIframe();
        fsa.assertTrue(policyBankPayment.isBankAccountTypeHeaderCorrect(), "Bank account type header verification - " + lobType);
        fsa.assertTrue(policyBankPayment.isCheckingRadioButtonSelected(), "Checking radio button is not selected by default - " + lobType);
        fsa.assertTrue(policyBankPayment.isCheckingLabelCorrect(), "Checking label is not correct - " + lobType);
        fsa.assertTrue(policyBankPayment.isSavingsRadioButtonEnabled(), "Savings radio button displayed - " + lobType);
        fsa.assertTrue(policyBankPayment.isSavingsLabelCorrect(), "Savings label displayed - " + lobType);
        fsa.assertTrue(policyBankPayment.isBusinessCheckingRadioButtonEnabled(), "Business checking radio button displayed");
        fsa.assertTrue(policyBankPayment.isBusinessCheckingLabelCorrect(), "Business checking label displayed - " + lobType);
        fsa.assertTrue(policyBankPayment.isAccountHolderNameLabelCorrect(), "Account holder name placeholder displayed - " + lobType);
        fsa.assertTrue(policyBankPayment.isAccountHolderNameMatching(policyPaymentBasePage.fullNameFromCustomerData(customerData)),
                "Account holder name verification - " + lobType);
        fsa.assertTrue(policyBankPayment.isBankRoutingNumberLabelCorrect(), "Bank routing number label place holder text displayed - " + lobType);
        fsa.assertTrue(policyBankPayment.isAccountNumberLabelCorrect(), "Account number place holder text displayed - " + lobType);
        fsa.assertTrue(policyBankPayment.isConfirmAccountNumberLabelCorrect(), "Confirm account number place holder text displayed - " + lobType);
        fsa.assertTrue(policyPaymentBasePage.isAddButtonTextCorrect(), "Add button text verification - " + lobType);
    }

    public void validateBankPaymentErrorsInIFrame(FarmersSoftAssert fsa, String lobType) throws Exception {
        policyBankPayment.clearOutAccountHolderInputField();
        policyPaymentBasePage.clickAddButton();
        fsa.assertTrue(policyBankPayment.isEnterValidAccountHolderNameErrorCorrect(), "Enter valid account holder name error message displayed - " + lobType);
        fsa.assertTrue(policyBankPayment.isEnterValidRoutingNumberErrorCorrect(), "Enter valid routing number error displayed - " + lobType);
        fsa.assertTrue(policyBankPayment.isEnterValidBankAccountNumberErrorCorrect(), "Enter valid account number error displayed - " + lobType);
        fsa.assertTrue(policyBankPayment.isBankAccountNumbersNotMatchingErrorCorrect(), "Bank account numbers are not matching error displayed - " + lobType);

        policyBankPayment.enterRoutingNumber(DIGITS);
        fsa.assertTrue(policyBankPayment.isEnterValidRoutingNumberErrorCorrect(), "Enter valid routing number error displayed - " + lobType);

        policyBankPayment.enterAccountNumber(DIGITS.substring(5));
        fsa.assertTrue(policyBankPayment.isEnterValidBankAccountNumberErrorCorrect(), "Enter valid account number error displayed - " + lobType);

        policyBankPayment.enterConfirmAccountNumber(DIGITS.substring(4));
        fsa.assertTrue(policyBankPayment.isBankAccountNumbersNotMatchingErrorCorrect(), "Bank account numbers are not matching error displayed - " + lobType);

    }

    public void validateContentOfDebitCreditCardPaymentInIframe(FarmersSoftAssert fsa, CustomerData customerData, String lobType) throws Exception {
        policyPaymentBasePage.switchToParentWindow();
        policyPaymentBasePage.clickDebitCreditCardButton();
        policyPaymentBasePage.switchToPaymentUsIframe();
        fsa.assertTrue(policyDebitCreditPayment.isNameOnCardLabelCorrect(), "Name on card label text verification - " + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isNameOnCardMatching(policyPaymentBasePage.fullNameFromCustomerData(customerData)), "Name on card text verification - " + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isCardNumberLabelCorrect(), "Card number label text verification - " + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isExpirationDateCorrect(), "Exp date label text verification - " + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isCardSecurityCodeLabelCorrect(), "Card security label text verification - " + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isBillingZipCodeLabelCorrect(), "Billing zip code label text verification - " + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isVisaCardIconInRowDisplayed(), "Visa card icon in row displayed - "  + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isMasterCardIconInRowDisplayed(), "Master card icon in row displayed - "  + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isDiscoverCardIconInRowDisplayed(), "Discover card icon in row displayed - "  + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isAmexCardIconInRowDisplayed(), "Amex card icon in row displayed - "  + lobType);
        fsa.assertTrue(policyPaymentBasePage.isAddButtonTextCorrect(), "Add button text verification - " + lobType);
    }

    public void validateDebitCreditCardPaymentErrorsInIFrame(FarmersSoftAssert fsa, String lobType) throws Exception {
        policyDebitCreditPayment.clearOutCardHolderNameInputField();
        policyPaymentBasePage.clickAddButton();

        fsa.assertTrue(policyDebitCreditPayment.isEnterYourNameErrorCorrect(), "Enter your name error text verification - " + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isEnterCardNumberErrorCorrect(), "Enter Card number error text verification - " + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isEnterEXPDateNumberErrorCorrect(), "Enter exp date error text verification - " + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isEnterCVVNumberErrorCorrect(), "Enter CVV number error text verification - " + lobType);
        fsa.assertTrue(policyDebitCreditPayment.isEnterBillingZipCodeErrorCorrect(), "Enter billing zip error text verification - " + lobType);

        policyDebitCreditPayment.enterCardNumber(DIGITS);
        fsa.assertTrue(policyDebitCreditPayment.isEnterCardNumberErrorCorrect(), "Enter Card number error text verification - " + lobType);

        policyDebitCreditPayment.enterExpDate("12/12");
        fsa.assertTrue(policyDebitCreditPayment.isEnterEXPDateNumberErrorCorrect(), "Enter exp date error text verification - " + lobType);

        policyDebitCreditPayment.enterCVVNumber("@@@");
        fsa.assertTrue(policyDebitCreditPayment.isEnterCVVNumberErrorCorrect(), "Enter CVV number error text verification - " + lobType);

        policyDebitCreditPayment.enterBillingZipCode("1111!");
        fsa.assertTrue(policyDebitCreditPayment.isEnterBillingZipCodeErrorCorrect(), "Enter billing zip error text verification - " + lobType);
    }

    public void enterBankAccountDetailsAndClickOnAddButton(FarmersSoftAssert fsa, String lobType) throws Exception {
        waitForSpinnerToBeGone();
        PolicyBankPayment policyBankPayment = new PolicyBankPayment();
        String accountNumber = RandomStringUtils.randomNumeric(10);

        // Checking payment setup validation
        switchToPaymentUsIframe();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER + Keys.TAB);
        sleep(1);
        fsa.assertTrue(policyBankPayment.isBOFABankNameLabelCorrect(), "BOFA bank label verification - " + lobType);

        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        clickAddButton();
    }

    public void validateAddedBankAccountDetailsOnPaymentPagePayInFull(FarmersSoftAssert fsa, String lobType) throws Exception {
        waitForSpinnerToBeGone();
        fsa.assertTrue(policyBankPayment.isBankPaymentAccountAddedMsgCorrect(), "Bank account added messages text check - " + lobType);
        fsa.assertTrue(policyBankPayment.isBankIconDisplayed(), "Bank icon displayed - " + lobType);
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountPayInFullTextCorrect(null), errorMessage("Hidden account number"));
    }

    public void validateAddedBankAccountDetailsOnPaymentPageMonthlyPay(FarmersSoftAssert fsa, String lobType) throws Exception {
        waitForSpinnerToBeGone();
        driver().switchTo().defaultContent();
        fsa.assertEquals(getTextFromElement(paymentMethodAddedText), BANK_PAYMENT_ADDED_TEXT, "Bank account added messages text check - " + lobType);
        fsa.assertTrue(policyBankPayment.isBankIconDisplayed(), "Bank icon displayed - " + lobType);
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountMonthlyPayTextCorrect(null), errorMessage("Hidden account number"));
    }

    public void enterCreditOrDebitCardInfoAndClickAddButton(String cardName) throws Exception {
        fillPaymentusDialog(cardName, true);
    }

    private void fillPaymentusDialog(String cardName, boolean retryIfErrorsFound) throws Exception {
    	switchToPaymentUsIframe();
    	if (!isElementDisplayed(paymentusCardNumberInput, 3)) {
    		waitAndClickElement(paymentusDebitCreditCardToggleButton);
    	}
    	policyDebitCreditPayment.enterCardNumber(cardName);
    	policyDebitCreditPayment.enterExpDate(EXP_DATE);
    	policyDebitCreditPayment.enterCVVNumber(CVV_NUMBER);
    	policyDebitCreditPayment.enterBillingZipCode(ZIP_CODE);
    	clickAddButton();
    	if (retryIfErrorsFound && isElementPresent(By.xpath("//input[contains(@class, 'error')][not(@type='hidden')]"), 3)) {
    		fillPaymentusDialog(cardName, false);
    	}
    	switchToParentWindow();
    }

    public void validateAddedCreditOrDebitCardDetailsOnPaymentPagePayInFull(FarmersSoftAssert fsa, String cardName, String cardTypeName, boolean isCreditCard, String lobType) throws Exception {
        policyDebitCreditPayment.waitForCompletePurchaseButtonToBeClickable();
        fsa.assertTrue(policyDebitCreditPayment.isHiddenCardNumberAndExpDatePayInfFullCorrect(cardName, EXP_DATE, cardTypeName),"Hidden card number and exp date text verification - " + lobType);
        if(isCreditCard){
            fsa.assertEquals(getTextFromElement(paymentMethodAddedText), CREDIT_CARD_ADDED_TEXT, "Credit card added message displayed - " + lobType);
        }else{
            fsa.assertEquals(getTextFromElement(paymentMethodAddedText), DEBIT_CARD_ADDED_TEXT, "Debit card added message displayed - " + lobType);
        }
    }

    public void validateAddedCreditOrDebitCardDetailsOnPaymentPageMonthlyPay(FarmersSoftAssert fsa, String cardName, String cardTypeName, boolean isCreditCard, String lobType) throws Exception {
        policyDebitCreditPayment.waitForCompletePurchaseButtonToBeClickable();
        fsa.assertTrue(policyDebitCreditPayment.isHiddenCardNumberAndExpDateMonthlyPayCorrect(cardName, EXP_DATE, cardTypeName),"Hidden card number and exp date text verification - " + lobType);
        if(isCreditCard){
            fsa.assertEquals(getTextFromElement(paymentMethodAddedText), CREDIT_CARD_ADDED_TEXT, "Credit card added message displayed - " + lobType);
        }else{
            fsa.assertEquals(getTextFromElement(paymentMethodAddedText), DEBIT_CARD_ADDED_TEXT, "Debit card added message displayed - " + lobType);
        }
    }

    public void validateNoServiceChargeWhenPayInFull(FarmersSoftAssert fsa, String lobType){
        fsa.assertTrue(policyDebitCreditPayment.isNoServiceChargeWhenPayInFullMsgCorrect(lobType), "No service charge when pay in full message verification - " + lobType);
    }

    public void validateContactAgentOrFarmersDirectSalesParagraphPayInFull(FarmersSoftAssert fsa, String lobType) throws Exception {
        waitForPageToBeReady();
        if (lobType.equals(RENTERS)) {
            contactAgentOrFarmersDirectSalesParagraphDisclaimers = driver().findElement(By.xpath("//section[contains(@class, 'disclaimers-text')]//button//following::p[1]"));
            fsa.assertTrue(completePurchaseButton.getLocation().getY() < contactAgentOrFarmersDirectSalesParagraphDisclaimers.getLocation().getY() , "Complete purchase button placed higher than final disclaimer");
        }
        switchToParentWindow();
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(contactAgentOrFarmersDirectSalesParagraphDisclaimers,10)), CONTACT_AGENT_OR_FARMERS_SALES_PARAGRAPH,
                "Contact agent or Farmers direct sales paragraph text for pay in full verification - " + lobType);
    }

    public void validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(FarmersSoftAssert fsa, String lobType) throws Exception {
        waitForPageToBeReady();
        if (lobType.equals(RENTERS)) {
            contactAgentOrFarmersDirectSalesParagraphDisclaimers = driver().findElement(By.xpath("//section[contains(@class,'disclaimers-text')]//p[contains(@class, 'stacking')]"));
            fsa.assertTrue(completePurchaseButton.getLocation().getY() < contactAgentOrFarmersDirectSalesParagraphDisclaimers.getLocation().getY() , "Complete purchase button placed higher than final disclaimer");
        }
        switchToParentWindow();
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(contactAgentOrFarmersDirectSalesParagraphDisclaimers,10)), CONTACT_AGENT_OR_FARMERS_SALES_PARAGRAPH,
                "Contact agent or Farmers direct sales paragraph text for monthly auto pay verification - " + lobType);
  }

    public boolean isServiceChargeWhenUsingBankMsgCorrect(){
        return isExpectedTextDisplayed(bankPaymentServiceChargeText, "$2 in service charges");
    }

    public void validateNoServiceChargeWhenUsingBankTransfer(FarmersSoftAssert fsa, String lobType) throws Exception {
        if (getStateCodeFromAppStore().equals(AL)) {
            fsa.assertTrue(isServiceChargeWhenUsingBankMsgCorrect(), "$2 service charge when using bank transfer text verification - " + lobType);
        } else {
            fsa.assertTrue(policyBankPayment.isNoServiceChargeWhenUsingBankMsgCorrect(), "No service charge when using bank transfer text verification - " + lobType);
        }
    }

    public void validateFutureCreditDebitCardServiceCharges(FarmersSoftAssert fsa, boolean isCreditCard, String lobType) {
        if (isCreditCard) {
            waitForPageToBeReady();
            fsa.assertTrue(policyDebitCreditPayment.isFutureCardServiceChargesTextMatching(),  "Future credit card service charge text verification - " + lobType);
        }
    }

    public void validateIfCompletePurchaseButtonIsEnabled(FarmersSoftAssert fsa, String lobType){
        fsa.assertTrue(completePurchaseButton.isEnabled(), "Complete purchase button is not enable for " + lobType + " .");
    }

    public void clickChangeLink(){
        scrollAndClickOnElement(changeLink);
    }

    public void clickDebitCreditCardToggleButton(){
        waitAndClickElement(paymentusDebitCreditCardToggleButton);
    }

    public List<VerifyResponse.PaymentSchedule> filterListOfPaymentScheduleByPayPlanHRC(List<VerifyResponse.PaymentSchedule> paymentSchedules, String payPlanDescription){
        System.out.println("Payment schedules " + paymentSchedules);
        return  paymentSchedules.stream().filter(c -> c.getPayPlanDescription().equals(payPlanDescription)).collect(Collectors.toList());
    }

    public int getAdministrativeFeeForGivenPayPlanDescriptionHRC(List<VerifyResponse.PaymentSchedule> paymentSchedules, String payPlanDescription) throws Exception {
        VerifyResponse.PaymentSchedule paymentSchedule = new AceHRCPaymentBasePage().filterListOfPaymentScheduleByPayPlanHRC(paymentSchedules, payPlanDescription).stream().findFirst().get();
        String currencyAmount = paymentSchedule.getAdministrativeCharges().getCurrencyAmount();
        return (int) Double.parseDouble(currencyAmount);
    }

    @SneakyThrows
    public VerifyResponse getVerifyResponseFromAppStoreHRC(){
        return getSessionStorageAppStore().getHome().getVerifyResponse();
    }
    public String getDownPaymentHRC(String payPlanDescription){
        List<VerifyResponse.PaymentSchedule> monthlyEffectivePayPlan = filterListOfPaymentScheduleByPayPlanHRC(getVerifyResponseFromAppStoreHRC().getPaymentSchedules(), payPlanDescription);
        return monthlyEffectivePayPlan.get(0).getDownPayment().getAmount().getAmount();
    }

    protected String getInstallmentAmountFarmersHRC(String paymentMethod) throws Exception {
        if (paymentMethod.equals(PAY_IN_FULL)) {
            return getFullTermPremiumAmountFarmersHRC(paymentMethod);
        }
        List<VerifyResponse.PaymentSchedule> paymentSchedules = getVerifyResponseFromAppStoreHRC().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPayPlanCode().equals(convertPaymentMethodToPayPlanCodeFarmers(paymentMethod))).findFirst().get().getInstallments().get(0).getCurrencyAmount();
    }
    protected String getFullTermPremiumAmountFarmersHRC(String paymentMethod) throws Exception {
        List<VerifyResponse.PaymentSchedule> paymentSchedules = getVerifyResponseFromAppStoreHRC().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPaymentMethod().equals(convertPaymentMethodToPayPlanCodeFarmers(paymentMethod))).findFirst().get().getFullTermPremium();
    }

    public boolean isFirstMonthTermPaymentAmountDisplayedHRC(String payPlanDescription, String htmlElement, AppStore retrieveQuoteResponseSessionStorage) throws Exception {
        String downPayment = getDownPaymentHRC(payPlanDescription);
        WebElement sixTermPaymentAmount = listOfFullAmountWebElements(downPayment, htmlElement, true).get(0);
        return sixTermPaymentAmount.isDisplayed();
    }

    public boolean isPolicyFeeAmountDisplayedHRC(String stateCode, String htmlElement) throws Exception {
        String policyFee = getVerifyResponseFromAppStoreHRC().getPolicyFee().getAmount();
        //  F86786 & F89139: PL - Home FFQ & eCheckout - TX & CO Farmers FAIR Plan Recoupment Fee
        if (isFairPlanFeeState(stateCode)) {
            Double feeSurcharge = new AceHRCConsolidatedPaymentPage().getFeeSurchargeAmountFromAppStore(getVerifyResponseFromAppStoreHRC());
            policyFee = String.valueOf(Double.parseDouble(policyFee) + feeSurcharge);
        }
        WebElement administrativeFeeAmount = listOfFullAmountWebElements(policyFee, htmlElement, true).get(0);
        return administrativeFeeAmount.isDisplayed();
    }

    public void verifyContentOfUseSamePaymentMethodPopUP(FarmersSoftAssert fsa, String payPlan) {
        String commonMessage = " - same payment method modal";
        if (isSamePaymentModalDisplayed()) {
        	String expectedUseSamePaymentMethodQuestionText = "Use the same payment method?";
        	fsa.assertTrue(useSamePaymentMethodQuestion.isDisplayed(), expectedUseSamePaymentMethodQuestionText + " question is displayed" + commonMessage);
        	fsa.assertEquals(getTextFromElement(useSamePaymentMethodQuestion), expectedUseSamePaymentMethodQuestionText, expectedUseSamePaymentMethodQuestionText + " question text content" + commonMessage);

        	String expectedPaymentDialogConfirmationText = "Do you want to use the same payment method for this policy, or a different one?";
        	fsa.assertEquals(getTextFromElement(paymentDialogConfirmation), expectedPaymentDialogConfirmationText, "Payment dialog confirmation text validation" + commonMessage);

        	String expectedSavedAutoPolicyPaymentMethodText = "Saved auto policy payment method";
        	fsa.assertEquals(getTextFromElement(savedAutoPolicyPaymentMethodLabel), expectedSavedAutoPolicyPaymentMethodText, expectedSavedAutoPolicyPaymentMethodText + " label text validation" + commonMessage);

        	fsa.assertTrue(sameButton.isDisplayed(), "Same button displayed" + commonMessage);
        	fsa.assertEquals(getTextFromElement(sameButton), "Same", "Same button text validation" + commonMessage);

        	fsa.assertTrue(differentButton.isDisplayed(), "Different button displayed" + commonMessage);
        	fsa.assertEquals(getTextFromElement(differentButton), "Different", "Different button text validation" + commonMessage);

        	fsa.assertTrue(closeIconSamePaymentMethodModal.isDisplayed(), "Close icon displayed in "+ commonMessage);
        } else {
        	fsa.assertTrue(false, "Use same payment dialog shown");
        }
        if(payPlan.equals(MONTHLY_DEBIT_CREDIT_CARD)){
            fsa.assertTrue(savedAutoPolicyPaymentCardSymbol.isDisplayed(), "Saved payment card icon displayed" + commonMessage);
            String lastFourDigitOfCardNumber = policyDebitCreditPayment.getLastFourDigitOfCard(MASTER_CARD);

            fsa.assertTrue(getTextFromElement(savedAutoPolicyPaymentDetails).contains(lastFourDigitOfCardNumber), "Last four digit of card displayed" + commonMessage);
            //DE260536 is added
           // fsa.assertTrue(getTextFromElement(savedAutoPolicyPaymentDetails).contains(EXP_DATE), "Card exp date is displayed" + commonMessage);
        }else{
            fsa.assertTrue(savedAutoPolicyPaymentBankSymbol.isDisplayed(), "Saved payment bank icon displayed" + commonMessage);
            fsa.assertTrue(savedAutoPolicyPaymentBankAccountNumber.isDisplayed(), "Saved payment bank account number is displayed" + commonMessage);
        }
    }

    public boolean isSamePaymentModalDisplayed() {
    	return isElementDisplayed(sameButton, 10);
    }

    public void clickSameButtonSamePaymentModal(){
        clickElement(sameButton);
        waitForSpinnerToBeGone();
    }

    public void clickDifferentButtonSamePaymentModal(){
        clickElement(differentButton);
    }

    public void waitForReuseSamePaymentPopUPInvisible(){
        waitElementBeInvisible(reusePaymentPopUp);
    }

    public boolean isFairPlanFeeState(String stateCode) {
        return List.of(CO, TX, CA).contains(stateCode); // US1151111 -  CA Fair Plan Recoupment Fee
    }

    public boolean isExcludedFeeState(String stateCode) {
        return List.of(KY, MN).contains(stateCode);
    }
}
