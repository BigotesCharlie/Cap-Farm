package com.farmers.ffq.hqm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.farmers.ffq.utils.FarmersSoftAssert;

public class CallForQuotePage extends HqmBasePage {

    @FindBy(xpath = "//*[@id='farmers-landing-v2']//span[contains(@class,'h1-alt2')]")
    private WebElement pageTitle;

    private static final String TEXT_PAGE_TITLE = "Thanks for starting your quote online with Farmers GroupSelectSM";

    @FindBy(xpath = "//*[@id='farmers-landing-v2']//div[contains(@class,'aem-GridColumn--offset--default--2')]/section[@data-swiftype-index]//p")
    private WebElement pageSubTitle;
    private static final String TEXT_PAGE_SUBTITLE = "Speaking with one of our knowledgeable representatives is the best way to ensure " +
            "you\u2019re getting all the auto and home insurance savings and discounts you\u2019re eligible for.\nJust call 8";

    @FindBy(xpath = "//*[@id='farmers-landing-v2']//div//h2/span[contains(@class,'h4-alt1')]")
    private WebElement pageSubHeader;
    private static final String TEXT_PAGE_SUBHEADER = "Farmers GroupSelect\u00ae";

    @FindBy(xpath = "//*[@id='farmers-landing-v2']//div/p//span[contains(@class,'h4-alt1')]")
    private WebElement pageSubHeader3;
    private static final String TEXT_PAGE_SUBHEADER_H3 = "It's quick and easy to start saving today.";

    @FindBy(xpath = "//*[@id='farmers-landing-v2']//div[contains(@class,'button')]//a[@data-gtm='Farmers_COLPGS_CallLink_Header']")
    private WebElement buttonToCall;

    private static final String CONTINUE_FARMERS_QUOTE_ONLINE_TEXT = "I'd rather quote with Farmers Insurance\u00ae online";
    @FindBy(linkText = CONTINUE_FARMERS_QUOTE_ONLINE_TEXT)
    private WebElement linkToContinueFarmersQuoteOnline;


    private static final String XPATH_LOGO = "//*[@id='farmers-landing-v2']//section[@data-swiftype-index]//img[@aria-label='Farmers Insurance Logo']";
    @FindBy(xpath = XPATH_LOGO)
    private WebElement farmersLogo;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public CallForQuotePage() throws Exception {
        super();
        waitElementBeVisible(pageTitle);
    }

    public void verifyPageElements(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(pageTitle), TEXT_PAGE_TITLE, "Call For Quote page - Page Title");
        fsa.assertTrue(getTextFromElement(pageSubTitle).startsWith(TEXT_PAGE_SUBTITLE), "Call For Quote page - Page Subtitle");
        fsa.assertEquals(getTextFromElement(pageSubHeader), TEXT_PAGE_SUBHEADER, "Call For Quote page - Page Sub-Header");
        fsa.assertEquals(getTextFromElement(pageSubHeader3), TEXT_PAGE_SUBHEADER_H3, "Call For Quote page - Page Section Sub-Header h3");
        String btnToCall = getAttributeData(buttonToCall, "text");
        System.out.println(" Button To Call Text >> " + btnToCall);
        fsa.assertTrue(btnToCall.startsWith("CALL 8") && btnToCall.endsWith(" NOW"), "Call For Quote page - Button To Call Text");
        fsa.assertTrue(isElementDisplayed(By.linkText(CONTINUE_FARMERS_QUOTE_ONLINE_TEXT)), "Call For Quote page - Link back to Farmers quote is displayed.");
        fsa.assertTrue(isElementDisplayed(By.xpath(XPATH_LOGO)), "Call For Quote page - Farmers Insurance Logo is displayed");
    }

    public void goBackToFarmersQuote() {
        waitAndClickElement(linkToContinueFarmersQuoteOnline);
    }
}
