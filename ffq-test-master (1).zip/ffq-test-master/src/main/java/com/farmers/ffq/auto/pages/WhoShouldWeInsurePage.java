package com.farmers.ffq.auto.pages;

import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoVehicleSectionOneUI;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import lombok.SneakyThrows;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.farmers.ffq.utils.GlobalVariables.*;


public class WhoShouldWeInsurePage extends AutoBasePage {

    private static final String ACTUAL_LIST_OF_DRIVERS_WITH_AGES_CSS_SELECTOR = "ul>li";
    private static final String FIRST_NAME = "First name ";
    private static final String LAST_NAME = "Last name ";

    private static final String PAGE_DESCRIPTION_XPATH =
            "//div[contains(.,'Include all the vehicles and drivers you would like to insure, up to a maximum of 5.') " +
                    "or contains(.,\"We'll need some details on the vehicles and drivers you want to insure\")" +
                    "]";

    private static final String REQUIRED_FIELD_ERROR_MESSAGE = "One or more required fields is incomplete or incorrect. Please review.";
    private static final String SAVE_CHANGES = " Save Changes";
    private static final String SECTION_DESCRIPTION_XPATH = "//../p";
    public static final String VIN_HELPER_IMAGE_ONE = "//div[@title='Vin Helper Image 1']";
    public static final String VIN_HELPER_IMAGE_THREE = "//div[@title='Vin Helper Image 3']";
    public static final String VIN_HELPER_IMAGE_TWO = "//div[@title='Vin Helper Image 2']";
    private static final String XPATH_FOR_FLEX_EMAIL_ENTRY_FIELD = "//div[@id='flex-field-emailAddress_vehiclesDriversReview' and not(contains(@class, 'hidden'))]//input";
    private static final String XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_DROP_DOWN_FIELDS = "//mat-form-field[contains(.,'%s')]//mat-select";
    private static final String XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_INPUT_FIELDS = "//mat-form-field[.//mat-label[contains(text(),'%s')]]//input[not(@hidden)]";
    private static final String addDriverDialogXpath = "//app-add-driver";
    private static final String driverCheckboxXpath = "//mat-checkbox[contains(@class,'tui-disabled-checkbox-only')]//*[contains(text(),'%s')]/..//input";
    protected static final String ADPF_DRIVERS_FOUND_XPATH = "//ul[@class='auto-vehicles-drivers-review__drivers-list-section']";
    protected static final String ADPF_VEHICLES_FOUND_XPATH = "//div[@class='auto-vehicles-drivers-review__vehicles-list-section']";
    protected static final String MATCHECKBOX_XPATH = "//mat-checkbox";
    protected static final String INPUT_XPATH = "//input";
    protected static final String EDIT_BUTTON = "//div/a";
    protected static final String CHECKED_VEHICLES_XPATH = ADPF_VEHICLES_FOUND_XPATH + MATCHECKBOX_XPATH + INPUT_XPATH + "[contains(@class,'mdc-checkbox--selected')]";
    protected static final String CURRENT_INSURANCE_COMPANY = "Current insurance company";
    protected static final String PRIOR_INSURANCE_COMPANY = "Prior insurance company";
    protected static final String CURRENT_BI_LIMITS = "Current Bodily Injury (BI) limits";
    protected static final String PRIOR_BI_LIMITS = "Prior Bodily Injury (BI) limits";
    protected static final String POLICY_EXP_DATE = "Policy expiration date";
    protected static final String LENGTH_OF_CURRENT_INSURANCE = "Length of current insurance";
    protected static final String LENGTH_OF_PRIOR_INSURANCE = "Length of prior insurance";
    protected static final String MY_INSURANCE_EXPIRED = "My insurance expired";
    protected static final String CONTINUOUSLY_INSURED_QUESTION = "Have you been continuously insured for the past 6 months with any auto insurance company(s)?";

    @FindBy(css = ACTUAL_LIST_OF_DRIVERS_WITH_AGES_CSS_SELECTOR)
    private List<WebElement> actualLisOfDriversWithAges;

    private static final String LIST_OF_VEHICLES_ADDED_XPATH = "//label[contains(@for,'vehicle__checkbox')]";
    private final String VEHICLE_VIN_ERROR_MESSAGE_XPATH = "//p[@class='auto-vehicles-drivers-review-vin-error-message tui-body-text-2']";

    @FindBy(xpath = "//ul[contains(@class,'auto-vehicles-drivers-review__drivers-list-section')]/li//label[@class='mdc-label']")
    private List<WebElement> lblDriversList;

    @FindBy(css = "div.auto-vehicles-drivers-review__vehicles-list-details label.mdc-label")
    private List<WebElement> actualListOfVehicleInfo;

    @FindBy(xpath = "//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-section')]/div//label[@class='mdc-label']")
    public List<WebElement> lblVehiclesList;

    private String lblVehiclesName = "//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-section')]/div[%d]//label[@class='mdc-label']";

    @FindBy(css = "li.auto-add-vehicle-vin-tips__list-rules")
    private List<WebElement> actualListOfVinTips;
    @FindBy(xpath = "//button[contains(@class,'tui-btn tui-btn-cta add-vehicle-button')]")
    private WebElement addAnotherVehicleButton;
    @FindBy(css = ".auto-vehicles-drivers-review__multi-vehicle-add-link")
    private WebElement addAnotherVehicleButtonFromMainScreen;
    @FindBy(xpath = "//button[contains(.,'Add another vehicle')]")
    private WebElement addAnotherVehicleButtonFromMainScreen2;
    @FindBy(id = "auto-add-driver__dialog-close-icon")
    private WebElement addDriverCloseIcon;
    @FindBy(css = "h2[id='addVehicleHeading']")
    protected WebElement addVehicleDialogHeader;
    @FindBy(className = "tui-vin-modal-header")
    private WebElement howToFindVinHeader;
    @FindBy(css = "div.auto-vehicles-drivers-review__drivers-list-details-section>a")
    private WebElement editDriverLink;
    @FindBy(css = "div.auto-vehicles-drivers-review__drivers-list-details-section>a")
    protected WebElement ctaErrorMessageForVehicleEditSideSheet;
    @FindBy(id = "addDriverHeading")
    private WebElement addDriverDialogHeader;
    @FindAll({
            @FindBy(css = "h2.auto-add-vehicle-heading"),
            @FindBy(xpath = "//app-vehicle-form//h1")
    })
    private WebElement addEditVehicleDialogHeader;
    @FindBy(css = "h4[id='addMoreDriversHeading']")
    private WebElement addMoreDriverDialogHeader;
    @FindBy(xpath = "//h4[text()='Do you have more vehicles? ']")
    private WebElement addMoreVehiclesHeading;
    @FindBy(id = "addVehiclesDriversButton")
    protected WebElement addVehicleAndDriversButton;
    @FindAll(
            {@FindBy(css = "button[class='tui-btn tui-btn-primary ng-star-inserted']"),
                    @FindBy(xpath = "//*[@id='addVehicleButton' or @class='tui-btn tui-btn-primary auto-add-vehicle-submit__button']")
            })
    private WebElement addAVehicleButton;
    @FindBy(id = "multiVehicleAddLink")
    private WebElement addAnotherVehicleLink;
    @FindBy(id = "addAnotherVehicleLink")
    private WebElement addAnotherVehicleLinkAlternative;
    @FindBy(xpath = "//button[contains(@class, 'add-button') and contains(., 'another vehicle')]")
    private WebElement addAnotherVehicleLinkAlternative2;
    @FindBy(xpath = "//button[@class='tui-btn tui-btn-primary auto-add-vehicle-submit__button'] | //button[contains(@class,'add-button')][contains(.,'Add another vehicle')]")
    private WebElement addVehicleButton;
    @FindBy(css = "p.auto-add-vehicle-start__subtitle")
    private WebElement addVehicleSideDialogSubtitle;
    @FindBy(xpath = "//button[text()='Add a vehicle']")
    private WebElement addVehiclesButton;
    @FindAll({
            @FindBy(css = "button.tui-vin-back-to-vin-button"),
            @FindBy(xpath = "//button[@id='back-button']//mat-icon")
    })
    private WebElement backToVinButton;
    @FindBy(xpath = "//div[contains(@class,'auto-add-vehicle-submit')]//a")
    private WebElement cancelAddVehicleLink;
    @FindBy(xpath = "//button[contains(@class, 'auto-vehicles-drivers-review__continue-button')]")
    private WebElement continueButton;
    private WebElement dashboardOnTheDriverSideDriverSideDoorJamb;
    @FindBy(xpath = "//mat-form-field//input[contains(@aria-label, 'Date of birth')] | //mat-form-field[contains(.,'Date of birth')]//input")
    private WebElement dateOfBirthEntryField;

    @FindBy(css = "mat-checkbox[class='mat-checkbox auto-vehicles-drivers-review__vehicles-list-details-checkbox mat-accent mat-checkbox-checked']")
    private List<WebElement> checkedVehicles;

    private By disabledCheckBoxLabel = By.xpath("//mat-checkbox[contains(@class,'mat-mdc-checkbox-disabled')]//label");
    @FindBy(css = "button.close-button")
    private WebElement doneAddingVehiclesButton;

    @FindBy(id = "addDriverButton")
    private WebElement addDriverButton;

    @FindBy(xpath = "//a[contains(@id,'addAnotherDriverLink')]")
    protected WebElement addAnotherDriverButton;

    @FindBy(xpath = "//p[contains(@class,'auto-add-driver__error-message')]")
    private WebElement saveDriverCTAErrorMessage;

    @FindBy(css = "button[class='tui-btn tui-btn-cta add-drivers-button']")
    protected WebElement addAnotherDriverButtonSideSheet;

    @FindBy(xpath = "//div[contains(@class,'auto-add-more-drivers-done__button')]//button")
    private WebElement doneAddingDriversButton;

    @FindBy(xpath = "//app-transition-sidesheet//button[text()='Done adding drivers']")
    private WebElement doneAddingDriversButtonAlternative;

    @FindBy(css = "div.auto-vehicles-drivers-review__drivers")
    private WebElement driverSection;
    @FindAll({
            @FindBy(xpath = VIN_HELPER_IMAGE_ONE + SECTION_DESCRIPTION_XPATH),
            @FindBy(xpath = "//div[@class='tui-vin-section tui-stacking-bottom-md'][1]//p")
    })
    private WebElement driverSideDoorText;

    public final String DROP_DOWN_OPTIONS_XPATH = "//div[@role][.//mat-option]";

    @FindBy(xpath = DROP_DOWN_OPTIONS_XPATH)
    public WebElement dropDownOptions;
    @FindAll({
            @FindBy(css = "p[class*='error-message']") ,
            @FindBy(css = "div[class='error-message pb-4 ng-star-inserted']")
    })

    private WebElement errorMessageForVehicleAndDriverSelection;
    @FindBy(css = "mat-error.mat-mdc-form-field-error")
    public WebElement fieldErrorMessage;
    @FindBy(xpath = XPATH_FOR_FLEX_EMAIL_ENTRY_FIELD)
    private WebElement flexEmailAddressEntryField;
    @FindBy(xpath = "//div[@id='flex-field-phoneNumber_vehiclesDriversReview']//input")
    private WebElement flexMobilePhoneEntryField;
    @FindBy(xpath = "//label[not(contains(@for,'flex-field'))]/mat-label")
    private List<WebElement> formFieldLabels;
    private final String GENDER_SECTION_XPATH = "//*[@id='formField_label_gender' or @aria-label='Please select your gender' or @id='formField_gender']";
    @FindBy(xpath = GENDER_SECTION_XPATH)
    private WebElement genderSelectForm;
    @FindBy(id = "formField_currentlyInsured")
    private WebElement insuredSelectForm;
    @FindBy(id = "//div[contains(@id,'currentlyInsured')]//input[contains(@value,'Yes')]")
    private WebElement currentlyInsuredYes;
    @FindBy(id = "//div[contains(@id,'currentlyInsured')]//input[contains(@value,'NN')]")
    private WebElement currentlyInsuredNo;

    @FindBy(css = "mat-dialog-container button.tui-btn-primary")
    private WebElement keepBothButton;
    @FindBy(id = "formField_licenseIssued")
    private WebElement licenseSelectForm;
    @FindBy(xpath = "//div[@class='auto-vehicles-drivers-review__non-adpf__subheading row']//span")
    private WebElement nonAdpfPageSubTitle;
    @FindBy(xpath = "//h1[contains(@class,'auto-vehicles-drivers-review__non-adpf-heading tui-h1')]")
    protected WebElement nonAdpfPageTitle;
    @FindBy(xpath = "//mat-form-field[@id='currentlyUninsuredReason']//mat-select")
    private WebElement notInsuredReasonDropdownField;
    @FindBy(xpath = "//mat-form-field[@id='priorInsuranceExpiredInfo']//mat-select")
    private WebElement priorInsuranceExpiredDropdownField;
    @FindBy(xpath = "//p[text()][./span[text()='Quote number']]")
    private WebElement quoteNumberText;
    @FindBy(css = "mat-dialog-actions button.tui-btn-link")
    private WebElement removeBothButton;
    @FindBy(css = "p.auto-add-vehicle-ymm__multiple-fields-missing")
    private WebElement requiredFieldErrorMessage;
    @FindBy(xpath = "//button[contains(text(),'Save changes')]")
    private WebElement vehicleSaveChangesButton;

    @FindBy(xpath = "//button[contains(text(),'Save changes')]")
    private WebElement driverSaveChangesButton;
    @FindBy(xpath = "//button[text()=' Save']")
    private WebElement saveDriverInfoButton;
    @FindBy(xpath = "//a[text()='Save quote']")
    private WebElement saveQuoteLink;
    @FindBy(id = "spouseSelectContent")
    private WebElement spouseSelectPopUpContext;
    @FindBy(css = "h1.spouse-select__title")
    private WebElement spouseSelectPopUpHeader;
    @FindBy(css = "p.auto-add-vehicle-ymm__disclaimer-text")
    private WebElement subNote;
    @FindBy(css = ".auto-add-vehicle-make__input input:not([disabled])")
    private WebElement vehicleMakeEntryField;
    @FindBy(xpath = "//div[contains(@class, 'auto-add-vehicle-make__input')]//input")
    private WebElement vehicleMakeEntryFieldAlternate;
    @FindBy(css = ".auto-add-vehicle-model__input input:not([disabled])")
    private WebElement vehicleModelEntryField;
    @FindBy(id = "//div[contains(@class, 'auto-add-vehicle-model__input')]//input")
    private WebElement vehicleModelEntryFieldAlternate;
    @FindBy(css = "div.auto-vehicles-drivers-review__vehicles")
    private WebElement vehicleSection;
    @FindBy(css = "div.auto-vehicles-drivers-review__vehicles-list-details-section>a")
    private List<WebElement> editVehicleLink;

    private final String EDIT_LINK_XPATH_FOR_VIN_PROVIDED_VEHICLES = "//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-details row') and contains(.,'VIN: •••')]//a";
    @FindBy(xpath = EDIT_LINK_XPATH_FOR_VIN_PROVIDED_VEHICLES)
    private List<WebElement> editVehicleLinksForVinVehicle;


    @FindBy(xpath = "//*[@aria-label='VIN ending with 341']")
    private WebElement vehicleVinLabel;

    @FindBy(id = "auto-add-vehicle-vehicleType__input-section")
    private WebElement vehicleTypeDropdown;
    @FindBy(xpath = "(//span[starts-with(@class,'mat-mdc-select-min-line')])[2]")
    private WebElement vehicleTypeDropdownValue;
    @FindBy(xpath = "//mat-button-toggle[@value='vin']/button")
    private WebElement vehicleVINButton;
    @FindBy(xpath = "//input[@id='auto-add-vehicle-vin__input-section' or @formcontrolname='vin']")
    public WebElement vehicleVINEntryField;
    @FindBy(xpath = "//mat-button-toggle[@value='ymm']/button")
    private WebElement vehicleYMMButton;
    @FindBy(css = ".auto-add-vehicle-year__input mat-select[aria-disabled='false']")
    protected WebElement vehicleYearDropdown;
    @FindBy(xpath = "//div[contains(@class, 'auto-add-vehicle-year__input')]//mat-select")
    protected WebElement vehicleYearDropdownAlternate;
    @FindBy(xpath = "(//span[starts-with(@class,'mat-mdc-select-min-line')])[1]")
    private WebElement vehicleYearDropdownValue;
    @FindBy(xpath = VIN_HELPER_IMAGE_ONE)
    private WebElement vinHelperImageOne;
    @FindBy(xpath = VIN_HELPER_IMAGE_THREE)
    private WebElement vinHelperImageThree;
    @FindBy(xpath = VIN_HELPER_IMAGE_TWO)
    private WebElement vinHelperImageTwo;
    @FindBy(xpath = "//p[@class='tui-body-text-1']")
    private WebElement vinHelperModalContent;
    // Vin Model Helper locators
    @FindAll({
            @FindBy(css = ".tui-subtitle"),
            @FindBy(id = "baseSidesheetHeader")
    })
    private WebElement vinHelperModalHeader;
    @FindBy(xpath = "//p[contains(@class,'tui-field-label-text auto-vin-helper__body')]")
    private WebElement vinLocations;
    @FindBy(xpath = "//ol//li")
    private List<WebElement> vinLocationsList;
    @FindBy(xpath = "//a[text()=' Where can I find this?']")
    public WebElement whereCanIFindThisLink;
    @FindBy(xpath = PAGE_DESCRIPTION_XPATH)
    private WebElement whoShouldWeInsurePageContent;
    @FindBy(xpath = "//h1[contains(text(), 'Who should we insure?')]")
    private WebElement whoShouldWeInsureTitle;
    @FindBy(xpath = "//div[@class='auto-add-vehicle-heading__div row']//div[./mat-icon]")
    private WebElement xButton;
    @FindBy(xpath = "//mat-label[contains(normalize-space(text()),'VIN')]/ancestor::div[1]/input[1]")
    private WebElement txtVINUnmasked;

    @FindBy(xpath = "//div[contains(@class,'vehicle-desc')]/div")
    private WebElement lblVINDescription;

    @FindBy(css = "button[class='tui-btn tui-btn-primary auto-add-driver-save__button']")
    public WebElement saveButton;

    @FindBy(css = "p[class='auto-vehicles-drivers-review__error-message tui-body-text-2 ng-star-inserted']")
    public WebElement pageCTAErrorMessage;

    @FindBy(xpath = CHECKED_VEHICLES_XPATH)
    protected List<WebElement> listOfCheckedVehicles;
    @FindBy(xpath = CHECKED_VEHICLES_XPATH + "//ancestor::mat-checkbox/.." + EDIT_BUTTON)
    protected List<WebElement> listOfEditButtonsOfCheckedVehicles;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public WhoShouldWeInsurePage() throws Exception {
    }

    @SneakyThrows
    private static WebElement getEditDriverButtonForDriver(String fullName) {
        return driver().findElement(By.xpath(String.format("//li[contains(.,'%s')]//a[contains(.,'Edit')] | //app-driver-card[contains(.,'%s')]//a", fullName, fullName)));
    }

    //Vin may contain unicode chars we want to keep
    public String getVehicleVinLabelText() {
        return vehicleVinLabel.getText().trim();
    }


    public void validateVehicleVinLabel(String vehicleVinText, FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getVehicleVinLabelText(), vehicleVinText, "Vehicle has a valid VIN");
    }

    public void clickAddDriverButton() {
        waitElementBeVisible(addDriverButton);
        clickElement(addDriverButton);
    }

    public void addADPFDriverDetails(Optional<AutoApplicant> applicantOptional, String gender, String dob) throws Exception {
        waitElementBeVisible(dateOfBirthEntryField);
        if (getAttributeData(dateOfBirthEntryField, "readonly").equals(EMPTY_STRING)) {
            enterDateOfBirth(dob);
        }
        selectGenderTabButton(gender);
        boolean isApplicantPresent = applicantOptional.isPresent();
        AutoApplicant applicant = null;
        if (isApplicantPresent) {
            applicant = applicantOptional.get();
        }
        String applicantCurrentlyInsured = isApplicantPresent && !applicant.getCurrentlyInsuredStatus().equals("Insured") ? NO : YES;
        selectUsOrCanadaLicensedRadioButton(isApplicantPresent && applicant.getFirstAgeForeignDriverLicense() == 18 ? NO : YES);
        List<WebElement> currentlyInsuredSectionActive = driver().findElements(By.xpath("//div[contains(@id,'currentlyInsured') and @hidden]"));
        if (currentlyInsuredSectionActive.isEmpty() && !isElementPresent(By.xpath("//div[contains(@id,'currentlyInsured')]//mat-radio-button[contains(@class,'checked')]")) ) {
        	WebElement currentlyInsuredSelection = driver().findElement(By.xpath(String.format("//div[contains(@id,'currentlyInsured')]//mat-radio-button[.//*[contains(text(),'%s')]]", applicantCurrentlyInsured)));
        	scrollAndClickOnElement(currentlyInsuredSelection);
        	int retry = 3;
        	while (!getAttributeData(currentlyInsuredSelection, CLASS).contains(MAT_MDC_RADIO_CHECKED) && retry>0) {
                clickElement(currentlyInsuredSelection);
                sleep(2);
        		retry--;
        	}

        }

        if (applicantCurrentlyInsured.equals(NO) && isElementVisible(notInsuredReasonDropdownField,1)) {
            switch (applicant.getCurrentlyInsuredStatus()) {
                case NEVER_INSURED:
                    selectValueInDropDown(notInsuredReasonDropdownField, "I never had insurance");
                    break;
                case EXPIRED:
                    selectValueInDropDown(notInsuredReasonDropdownField, MY_INSURANCE_EXPIRED);
                    selectValueInDropdown("Before", priorInsuranceExpiredDropdownField, dateOfBirthEntryField);
                    if(applicant.getStateCode().equals(OR)) {
                        enterPriorInsuranceCompany(applicant.getCurrentInsuranceCompany().toUpperCase());
                        selectPriorBodilyInjuryLimits(applicant.getCurrentBodilyInjuryLimit());
                        // update length from available options
                        List<String> availableLengths = getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("lapseInCvgYes")).map(each -> each.getDropDownValues().get(0).getWebDesc()).collect(Collectors.toList());
                        Collections.shuffle(availableLengths);
                        String length = availableLengths.get(0);
                        selectLengthOfPriorInsurance(length);
                    }
                    selectContinuouslyInsuredForPastSixMonthsRadioButtonIfExists(applicant.getContinuosInsurancePeriod().equals("< 6 Months") ? NO : YES);
                    selectMilitaryDeploymentQuestionIfExists();
                    break;
                case NOT_REQUIRED:
                    selectValueInDropDown(notInsuredReasonDropdownField, "I was not required to have insurance");
                    break;
                case DEPLOYED:
                    selectValueInDropDown(notInsuredReasonDropdownField, "I was in the military and deployed overseas");
                    break;
                default:
                    Log.warn("Unrecognized insured status: " + applicant.getCurrentlyInsuredStatus());
                    break;
            }
        }
        if (isElementDisplayed(By.xpath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_INPUT_FIELDS, CURRENT_INSURANCE_COMPANY)))) {
            enterCurrentInsuranceCompany("AAA");
        }

        if (isElementDisplayed(By.xpath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_DROP_DOWN_FIELDS, CURRENT_BI_LIMITS)))) {
            selectCurrentBodilyInjuryLimits("$50,000/$100,000");
        }

        if (isElementDisplayed(By.xpath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_INPUT_FIELDS, POLICY_EXP_DATE)))) {
            String policyExpirationDate = LocalDate.now().plusDays(30).format(DateTimeFormatter.ofPattern(MM_DD_YYYY));
            enterPolicyExpirationDate(policyExpirationDate);
        }

        if (isElementDisplayed(By.xpath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_DROP_DOWN_FIELDS, LENGTH_OF_CURRENT_INSURANCE)))) {
            List<String> availableLengths = getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("lapseInCvgYes")).map(each -> each.getDropDownValues().get(0).getWebDesc()).collect(Collectors.toList());
            Collections.shuffle(availableLengths);
            String length = availableLengths.get(0);
//            if (isApplicantPresent) {
//                updateApplicantCurrentInsuranceDuration(applicant);
//                length = applicant.getContinuosInsurancePeriod();
//            }
            selectLengthOfCurrentInsurance(length);

            if (length.equals("< 6 Months")) {
                selectContinuouslyInsuredForPastSixMonthsRadioButtonIfExists(NO);
                selectMilitaryDeploymentQuestionIfExists();
            }
        }

        selectContinuouslyInsuredForPastSixMonthsRadioButtonIfExists(isApplicantPresent ? (applicant.getContinuosInsurancePeriod().equals("< 6 Months") ? NO : YES) : YES);

        if(isElementVisible(saveButton, 1)) {
            waitAndClickElement(saveButton);
        } else {
            clickOnButtonWithLabel(SAVE_CHANGES);
        }
        if (isElementVisible(doneAddingDriversButton, 1)) {
            waitAndClickElement(doneAddingVehiclesButton);
        }
    }

    public WhoShouldWeInsurePage addAllDriversWithMoreThan4AdditionalDriversWhenNonFound(AutoApplicant applicant) throws Exception {
        addAllDriversWithMoreThan4AdditionalDrivers(applicant);
        return this;
    }

    public void addDisplayedDrivers(AutoApplicant applicant) throws Exception {
        addMainDriver(applicant);
        clickOnDoneAddingDriversButton();
        longWaitForElementToBeGoneByXpath(addDriverDialogXpath);
        if (applicant.getMaritalStatus().equals(MARRIED)) {
            SqlAdditionalDriver sniDriver = applicant.getAdditionalDrivers().get(0);
            WebElement sniDriverWe = driver().findElement(By.xpath(String.format(driverCheckboxXpath, sniDriver.getFirstName() +
                    SPACE + sniDriver.getLastName())));
            waitAndClickElement(sniDriverWe);
            addAdditionalSniDriver(sniDriver);
            waitAndClickElement(driverSaveChangesButton);
            waitAndClickElement(doneAddingVehiclesButton);
            longWaitForElementToBeGoneByXpath(addDriverDialogXpath);
        }
    }

    //allowing more that 4 additional driver to be inputed
    public WhoShouldWeInsurePage addDriversWhenNoneAreFound(AutoApplicant applicant) throws Exception {
        addAllDrivers(applicant);
        return this;
    }

    public WhoShouldWeInsurePage addVehicles(AutoApplicant applicant) throws Exception {
        if (!isElementVisible(addEditVehicleDialogHeader, 3)) {
            waitAndClickElement(addVehiclesButton);
        }
        addAllVehiclesInList(applicant, applicant.getStateCode());
        return this;
    }

    public WhoShouldWeInsurePage addVehiclesWhenNoneAreFound(AutoApplicant applicant) throws Exception {
        int foundVehicles = getActualListOfDisplayedVehicles().size(); // number of the vehicles that are already on the page
        List<Vehicle> vehicles = applicant.getVehicles();

        if (foundVehicles > 0 && foundVehicles < vehicles.size()) {
            for (int i = 0; i < foundVehicles; i++) {
                vehicles.remove(vehicles.size() - 1); // remove from end
            }
        }

        if(applicant.getTestScenario().contains("BW") && !editVehicleLinksForVinVehicle.isEmpty()) {
            uncheckAllCheckedVehicleCheckboxes();
            updateVinsForVehicles(getRandomVinNumber(3));
        }

        clickOnAddVehiclesAndDriversButton();
        addAllVehiclesInList(applicant, applicant.getStateCode());

        return this;
    }

    public void addADPFApplicant(Optional<AutoApplicant> applicantOptional, String applicantFullName, String gender, String dob) throws Exception {
        List<WebElement> checkboxInputForAdpfApplicants = getDriverEditCheckboxesInputButtonByFullName(applicantFullName);

        WebElement editButtonForAdpfApplicant = getEditDriverButtonForDriver(applicantFullName);
        if (checkboxInputForAdpfApplicants.isEmpty()) {
            if(!isDriverSideDialogOpen()) {
                clickAddDriverButton();
                waitElementBeVisible(addDriverDialogHeader);
            }
            addADPFDriverDetails(applicantOptional, gender, dob);
        } else {
            // add PNI details if not already checked
            WebElement checkboxInputForAdpfApplicant = getDriverEditCheckboxInputButtonByFullName(applicantFullName);
            if (getAttributeData(checkboxInputForAdpfApplicant, CLASS).contains(MDC_CHECKBOX_SELECTED)) {
                // if the checkbox is already selected, we can return
                return;
            }

            if(!isDriverSideDialogOpen() && !checkboxInputForAdpfApplicant.isSelected() && isCheckboxNotSelected(checkboxInputForAdpfApplicant)) {
            	if (checkboxInputForAdpfApplicant.isEnabled()) {
                    scrollAndClickOnElement(checkboxInputForAdpfApplicant);
                } else {
                    scrollAndClickOnElement(editButtonForAdpfApplicant);
                }
            }
            addADPFDriverDetails(applicantOptional, gender, dob);
        }
        waitForSpinnerToBeGone();
    }

    public void clickOnAddVehiclesAndDriversButton() throws Exception {
        if (isElementVisible(addAnotherVehicleLink, 3) || isElementVisible(addAnotherVehicleLinkAlternative, 3)) {
            clickAddAnotherVehicleButton();
        } else {
            clickOnAddVehicleAndDriversButton();
        }
    }

    public void addVehiclesWhenOthersAreFound(AutoApplicant applicant) throws Exception {
        addAllVehiclesInList(applicant, applicant.getStateCode());
    }

    public boolean areAddedListOfDriversWithAgesDisplayed(AutoApplicant applicant) throws Exception {

        // adding main driver to the Map
        Map<String, String> expectedDriversWithAges = new HashMap<>();
        Map<String, String> actualDriversWithAges = new HashMap<>();
        expectedDriversWithAges.put(getApplicantFullName(applicant), String.valueOf(applicant.getAge()));

        // adding additional drivers to the Map
        applicant.getAdditionalDrivers().forEach(additionalDriver -> expectedDriversWithAges.put(getAdditionalDriverFullName(additionalDriver), String.valueOf(additionalDriver.getAge())));
        Log.info("expected values: " + expectedDriversWithAges);

        if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            new VehiclesDriversInfoPage().getDriverNamesAndAgesAsList().forEach(driverNameAndAge -> {
                String[] split = driverNameAndAge.split(",");
                String name = split[0].trim();
                String age = split[1].trim();
                actualDriversWithAges.put(name, age);
                expectedDriversWithAges.remove(name, age);
            });
        } else {

            List<String> names = driver()
                    .findElements(By.xpath("//li[@class='auto-vehicles-drivers-review__drivers-list-details ng-star-inserted']//label"))
                    .stream()
                    .map(this::getTextFromElement)
                    .collect(Collectors.toList());

            List<String> ages = driver()
                    .findElements(By.xpath("//li[@class='auto-vehicles-drivers-review__drivers-list-details ng-star-inserted']//span"))
                    .stream()
                    .map(this::getTextFromElement)
                    .map(text -> text.replaceAll("\\D", "")) // keep only digits
                    .filter(text -> !text.isEmpty())          // optional: remove empty results
                    .collect(Collectors.toList());
            for (int i = 0; i < names.size(); i++) {
                actualDriversWithAges.put(names.get(i), ages.get(i));
                expectedDriversWithAges.remove(names.get(i), ages.get(i));
            }


        }

        Log.info("actual values: " + actualDriversWithAges);

//        lblDriversList.forEach(driverInfo -> {
//            String driverToBeInsured = getTextFromElement(driverInfo.findElements(By.xpath("//ul[contains(@class,'drivers-list-section')]/li//span[@class='mat-checkbox-label']")));//lblDriversName
//            String ageOfDriverToBeInsured = getTextFromElement(driverInfo.findElements(By.xpath("//ul[contains(@class,'drivers-list-section')]/li//span[contains(@class,'age')]")));//lblDriversAge
//            expectedDriversWithAges.remove(driverToBeInsured, ageOfDriverToBeInsured.substring(ageOfDriverToBeInsured.length() - 2));
//        });
        return expectedDriversWithAges.isEmpty();
    }

    public boolean areAllFirstNameLastNameAndDobFieldsEditable() throws Exception {
        // re-using existing methods and locators from HeresWhatWeFoundPage...
        return new HeresWhatWeFoundPage().areAllFirstNameLastNameAndDobFieldsEditable();
    }

    public boolean areListOfAddedVehiclesDisplayed(AutoApplicant applicant) throws Exception {
        List<String> expectedListOfVehiclesDisplayed = new ArrayList<>();
        for (Vehicle vehicleInfo : applicant.getVehicles()) {
            String vehicleMake = vehicleInfo.getVehicleMake();
            String vehicleModel = vehicleInfo.getVehicleModel();
            String vehicleYear = vehicleInfo.getVehicleYear();
            String expectedVehicleName = vehicleYear + SPACE + vehicleMake + SPACE + vehicleModel;
            ;
            if (vehicleInfo.isUseVIN()) {
                List<AppStore.Auto.AppStoreVehicle> vehicles = this.getSessionStorageAppStore().getAuto().getVehicles();
                List<AppStore.Auto.AppStoreVehicle> filteredVehicles = vehicles.stream().filter(each -> {
                            String vin = null;
                            try {
                                vin = each.getVin();
                            } catch (Exception e) {
                                Log.error(e.getMessage());
                            }
                            if (!StringUtils.isEmpty(vin)) {
                                return vin.equals(vehicleInfo.getVehicleVIN());

                            } else {
                                return false;
                            }
                        }
                ).collect(Collectors.toList());

                if (!filteredVehicles.isEmpty()) {
                    AppStore.Auto.AppStoreVehicle vehicle = filteredVehicles.get(0);
                    vehicleMake = vehicle.getMakeDesc();
                    vehicleYear = vehicle.getYear();
                    vehicleModel = vehicle.getModelDesc();
                } else {
                    vehicleMake = vehicleInfo.getVehicleMake();
                    vehicleModel = vehicleInfo.getVehicleModel();
                    vehicleYear = vehicleInfo.getVehicleYear();
                }
                vehicleModel = vehicleInfo.getVehicleModel().contains("QUATTRO") ? "QUAT" : vehicleModel;
                expectedVehicleName = vehicleYear + SPACE + vehicleMake + SPACE + vehicleModel;
            }
            expectedListOfVehiclesDisplayed.add(expectedVehicleName);

        }
        Collections.sort(expectedListOfVehiclesDisplayed);
        int intVehiclesCount = getEleCount(lblVehiclesList, 5);
        List<String> actualListOfVehiclesDisplayed = new ArrayList<>();
        for (int i = 1; i <= intVehiclesCount; i++) {
            actualListOfVehiclesDisplayed.add(getTextFromElement(generateXpath(lblVehiclesName, "%d", Integer.toString(i))));
        }
        Collections.sort(actualListOfVehiclesDisplayed);
        Log.info("Actual vehicle list  : " + actualListOfVehiclesDisplayed);
        Log.info("Expected vehicle list: " + expectedListOfVehiclesDisplayed);
        return actualListOfVehiclesDisplayed.containsAll(actualListOfVehiclesDisplayed) && actualListOfVehiclesDisplayed.containsAll(actualListOfVehiclesDisplayed);
    }

    public void checkAllUnCheckedVehicleCheckboxes() throws Exception {
        List<WebElement> uncheckedVehicles = driver().findElements(By.xpath("//mat-checkbox[@class='mat-mdc-checkbox auto-vehicles-drivers-review__vehicles-list-details-checkbox mat-accent']"));
        for (WebElement uncheckedVehicle : uncheckedVehicles) {
            scrollAndClickOnElement(uncheckedVehicle);
            String textFromElement = getTextFromElement(uncheckedVehicle);
            Log.info("Checked vehicle: " + textFromElement);
        }
    }

    @SneakyThrows
    public void clickEditButtonWithDriverFullName(String fullName) throws Exception {
        // Bristol West has a different definition for this object
        if (isElementPresent(By.xpath(String.format("//button[contains(@aria-label,'%s')]", fullName)), 5)) {
            clickElement(driver().findElement(By.xpath(String.format("//button[contains(@aria-label,'%s')]", fullName))));
        } else {
            waitAndClickElement(getEditDriverButtonForDriver(fullName));
        }
    }

    public void clickOnAddAnotherVehicleButton() {
        waitAndClickElement(addAnotherVehicleButtonFromMainScreen);
    }

    public WhoShouldWeInsurePage clickOnAddVehicleAndDriversButton() {
        scrollToElement(addVehicleAndDriversButton);
        waitElementBeVisible(addVehicleAndDriversButton);
        clickElement(addVehicleAndDriversButton);
        return this;
    }

    public WhoShouldWeInsurePage clickOnAddVehicleButtonAndWaitForSpinner() {
        clickOnAddVehicleButton();
        waitForSpinnerToBeGone();
        return this;
    }

    public WhoShouldWeInsurePage clickOnAddVehicleButton() {
        waitElementBeVisibleClickable(addAVehicleButton);
        scrollAndClickOnElement(waitElementBeVisible(addVehicleButton));
        return this;
    }

    public void clickOnBackToVinButton() {
        waitAndClickElement(backToVinButton);
    }

    public void clickOnContinueButton() {
        scrollAndClickOnElement(continueButton);
        waitForSpinnerToBeGone();
    }

    public void clickOnDoneAddingVehiclesButton() {
        scrollAndClickOnElement(waitElementBeVisible(doneAddingVehiclesButton));
        waitForSpinnerToBeGone();
    }

    @SneakyThrows
    public void clickOnDriverDialogCloseIcon() {
        waitAndClickElement(addDriverCloseIcon);
    }

    public void clickOnSaveButton() throws Exception {
        WebElement element = driver().findElement(By.cssSelector("button[class='tui-btn tui-btn-primary auto-add-driver-save__button']"));
        scrollAndClickOnElement(element);
        waitForSpinnerToBeGone();
    }

    public WhoShouldWeInsurePage clickOnVehicleAdditionCancelButton() {
        waitAndClickElement(cancelAddVehicleLink);
        return this;
    }

    public WhoShouldWeInsurePage clickOnVinButton() {
        waitAndClickElement(vehicleVINButton);
        return this;
    }

    public WhoShouldWeInsurePage clickOnWhereCanIFindThisLink() {
        waitAndClickElement(whereCanIFindThisLink);
        waitElementBeVisible(vinHelperModalHeader);
        return this;
    }

    public WhoShouldWeInsurePage clickOnYMMButton() {
        waitElementBeVisible(vehicleYMMButton);
        clickElement(vehicleYMMButton);
        return this;
    }

    public void clickFirstVehicleEditLink() {
        waitAndClickElement(editVehicleLink.get(0));
    }

    public WhoShouldWeInsurePage updateVinsForVehicles(String vin) throws Exception {
        waitAndClickElement(editVehicleLink.get(0));
        clickOnVinButton();
        waitElementBeVisible(vehicleVINEntryField).clear();
        fillOutVinField(vin);
        waitForSpinnerToBeGone();
        waitAndClickElement(addVehicleButton);
        sleep(1);
        while (isElementDisplayed(By.xpath("//mat-error[contains(.,'This VIN is already added for a vehicle.')]"))) {
            fillOutVinField(vin);
            waitForSpinnerToBeGone();
            waitAndClickElement(addVehicleButton);
            waitForSpinnerToBeGone();
        }
        sleep(1);

        if(isElementVisible(doneAddingVehiclesButton, 1)) {
            waitAndClickElement(doneAddingVehiclesButton);
        }
        return this;
    }

    public WhoShouldWeInsurePage clickOnEditDriverLink() {
        waitAndClickElement(editDriverLink);
        return this;
    }

    public void enterEmailAndPhoneNumber(AutoApplicant applicant) {
        if (isElementPresentByXPath(XPATH_FOR_FLEX_EMAIL_ENTRY_FIELD)) {
            enterValueInField(applicant.getEmail(), flexEmailAddressEntryField, "Enter email address");
            enterValueInField(applicant.getPhoneNumber(), flexMobilePhoneEntryField, "Enter phone number");
        }

    }

    public WhoShouldWeInsurePage enterVehicleMake(Vehicle vehicleInfo) throws Exception {
        enterVehicleMake(vehicleInfo.getVehicleMake());
        return this;
    }

    public WhoShouldWeInsurePage enterVehicleMake(String vehicleMake) throws Exception {
        WebElement makeEntryField = isMA61Environment() ? vehicleMakeEntryFieldAlternate : vehicleMakeEntryField;
        waitElementBeVisibleClickable(makeEntryField);
        sendKeysToElement(makeEntryField, vehicleMake);
        wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath(DROP_DOWN_OPTIONS_XPATH), 0));
        selectValueInDropDown(makeEntryField, vehicleMake);
        waitElementBeInvisible(dropDownOptions);
        Log.info("Selected vehicle make: " + vehicleMake);
        return this;
    }

    public WhoShouldWeInsurePage enterVehicleModelAndTrim(String vehicleModel) throws Exception {
        waitElementBeVisibleClickable(vehicleModelEntryField);
        try {
            selectValueInDropDown(vehicleModelEntryField, vehicleModel);
        } catch (Exception e) {
            if (vehicleModel.contains("QUATTRO")) {
                vehicleModel = vehicleModel.replace("QUATTRO", "QUAT");
                selectValueInDropDown(vehicleModelEntryField, vehicleModel);
            }
        }
        Log.info("Selected vehicle model: " + vehicleModel);
        return this;
    }

    public void fillOutVehicleYearModelMakeFields(Vehicle vehicleInfo) throws Exception {
        clickOnYMMButton();
        selectVehicleYear(vehicleInfo);
        enterVehicleMake(vehicleInfo);
        enterVehicleModelAndTrim(vehicleInfo);
        selectVehicleType(vehicleInfo.getVehicleType());
    }

    public WhoShouldWeInsurePage fillOutVinField(String vehicleVIN) {
        enterValueInField(vehicleVIN, waitElementBeVisible(vehicleVINEntryField), "Entering VIN: ");
        waitForSpinnerToBeGone();
        Log.info("Entering vin : " + vehicleVIN);
        if (getAttributeData(vehicleVINEntryField, CLASS).contains("ng-invalid")) {
            sendKeysToElement(vehicleVINEntryField, vehicleVIN);
        }
        waitForSpinnerToBeGone();

        return this;
    }

    public List<String> getActualListOfDisplayedVehicles() {
        return actualListOfVehicleInfo.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public String getDashboardOnTheDriverSideDriverSideDoorJambText() {
        return getTextFromElement(dashboardOnTheDriverSideDriverSideDoorJamb);
    }

    public String getDriverSideDriverSideText() {
        return getTextFromElement(driverSideDoorText);
    }

    public String getErrorMessageForVehicleAndDriverSelection() {

        return getTextFromElement(errorMessageForVehicleAndDriverSelection);
    }

    public String getKeepBothButtonText() {
        return getTextFromElement(keepBothButton);
    }

    public String getPniRemovalNotificationText() throws Exception {
        return new HeresWhatWeFoundPage().getPniDriverRemovalNotificationText();
    }

    public String getRemoveBothButtonText() {
        return getTextFromElement(removeBothButton);
    }

    public String getSniRemovalNotificationText() throws Exception {
        return new HeresWhatWeFoundPage().getSniDriverRemovalNotificationText();
    }

    public String getSpouseSelectPopUpContextText() {
        return getTextFromElement(spouseSelectPopUpContext);
    }

    public String getSpouseSelectPopUpHeaderText() {
        return getTextFromElement(spouseSelectPopUpHeader);
    }

    public String getSubTitle() {
        return getTextFromElement(waitElementBeVisible(nonAdpfPageSubTitle));
    }

    public String getTitle() {
        return getTextFromElement(waitElementBeVisible(nonAdpfPageTitle));
    }

    public String getVinHelperModalHeader() {
        return getTextFromElement(waitElementBeVisible(vinHelperModalHeader));
    }

    public List<String> getVinTipsDisplayed() {
        if(isElementVisible(howToFindVinHeader, 1)) {
            waitAndClickElement(whereCanIFindThisLink);
            sleep(1);
        }
        List<String> vinTips = actualListOfVinTips.stream().map(this::getTextFromElement).collect(Collectors.toList());
        return new ArrayList<>(vinTips);

    }

    public boolean isDriverSectionDisplayed() {
        return isElementVisible(driverSection, 3);
    }

    public boolean isOnWhoShouldWeInsurePage() {
        return isElementVisible(nonAdpfPageTitle, 25);
    }

    public boolean isOnWhoShouldWeInsurePageShort() {
        return isElementVisible(nonAdpfPageTitle, 2);
    }

    public boolean isVehicleSectionDisplayed() {
        return isElementVisible(vehicleSection, 3);
    }

    public boolean isVinHelperImageOneVisible() {
        return isElementVisible(vinHelperImageOne, 3);
    }

    public boolean isVinHelperImageThreeVisible() {
        return isElementVisible(vinHelperImageThree, 3);
    }

    public boolean isVinHelperImageTwoVisible() {
        return isElementVisible(vinHelperImageTwo, 3);
    }

    @SneakyThrows
    public void navigateBackToPreviousPage() {
        driver().navigate().back();
        waitUntilAngular5Ready();
    }

    public boolean quickIsOnWhoShouldWeInsurePage() {
        return isElementVisible(whoShouldWeInsureTitle, 5);
    }

    public void refreshPage() throws Exception {
        driver().navigate().refresh();
        waitUntilAngular5Ready();
    }

    public WhoShouldWeInsurePage selectUsOrCanadaLicensedRadioButton(String yesOrNo) throws Exception {
        if (yesOrNo.equals("Yes, but lives away from home")) {
            // reassigning to yes, as this is not supported in One UI
            yesOrNo = "Yes";
        }
        waitElementBeVisible(genderSelectForm);
        WebElement webElement = driver().findElement(By.xpath(String.format("//div[contains(@id,'licenseIssued') or contains(@aria-label,'license issued by')]//input[contains(@value,'%s')]", yesOrNo)));
        scrollAndClickOnElement(webElement);
        Log.info("US or CA Driver License selection: " + yesOrNo);
        return this;
    }

    public void selectVehicleType(String vehicleType) throws Exception {
        waitForSpinnerToBeGone();
        String dropdownDisabled = getAttributeData(vehicleTypeDropdown, ARIA_DISABLED);
        boolean vehicleTypeIsNotFilled = getAttributeData(vehicleTypeDropdown, CLASS).contains("mat-select-empty");
        if (vehicleTypeIsNotFilled || dropdownDisabled == null || !dropdownDisabled.equals("true")) {
            selectValueInDropdown(vehicleType, vehicleTypeDropdown, addVehicleSideDialogSubtitle);
//    		selectValueInDropDown(vehicleTypeDropdown, vehicleInfo.getVehicleType());
        }
        Log.info("Selected vehicle type: " + vehicleType);
    }

    public WhoShouldWeInsurePage selectVehicleYear(Vehicle vehicleInfo) throws Exception {
        String vehicleYear = vehicleInfo.getVehicleYear();
        WebElement yearDropdown = isMA61Environment() ? vehicleYearDropdownAlternate : vehicleYearDropdown;
        waitElementBeVisibleClickable(yearDropdown);
        selectValueInDropdown(vehicleYear, yearDropdown, addVehicleSideDialogSubtitle);
        waitElementBeInvisible(dropDownOptions);
        Log.info("Selected vehicle year: " + vehicleYear);
        return this;
    }

    public WhoShouldWeInsurePage selectVehicleYear(String vehicleYear) throws Exception {
        selectValueInDropdown(vehicleYear, vehicleYearDropdown, addVehicleSideDialogSubtitle);
        waitElementBeInvisible(dropDownOptions);
        return this;
    }

    public void uncheckAllCheckedDriverCheckboxes() throws Exception {
        List<WebElement> checkedDrivers = driver().findElements(By.xpath("//li[contains(@class,'auto-vehicles-drivers-review__drivers-list-details ng-star-inserted')]//mat-checkbox[contains(@class,'mat-mdc-checkbox-checked')]"));
        for (WebElement checkedDriver : checkedDrivers) {
            clickElement(checkedDriver);
        }
    }

    public void uncheckAllCheckedVehicleCheckboxes() throws Exception {
        List<WebElement> checkedVehicles = driver().findElements(By.xpath("//mat-checkbox[@class='mat-mdc-checkbox auto-vehicles-drivers-review__vehicles-list-details-checkbox mat-accent mat-mdc-checkbox-checked']"));
        for (WebElement checkedVehicle : checkedVehicles) {
            clickElement(checkedVehicle);
        }
    }

    public void uncheckRandomAdditionalDriverCheckbox() throws Exception {
        new HeresWhatWeFoundPage().uncheckRandomAdditionalDriverCheckbox();
    }

    public Vehicle updateApplicantRandomVehicleYear() throws Exception {
        Vehicle vehicleInfo = new Vehicle();

        waitElementBeVisible(vehicleYearDropdown);

        // update new year
        String existingVehicleYear = getTextFromElement(vehicleYearDropdownValue);
        int updatedVehicleYear = Integer.parseInt(existingVehicleYear);
        vehicleInfo.setVehicleYear(String.valueOf(updatedVehicleYear + 1));

        // update Vehicle Make
        String existingVehicleMake = getInputFieldValue(vehicleMakeEntryField);
        vehicleInfo.setVehicleMake(existingVehicleMake);

        // update Vehicle Model
        String existingVehicleModel = getInputFieldValue(vehicleModelEntryField);
        vehicleInfo.setVehicleModel(existingVehicleModel);

        // update Vehicle Type
        String existingVehicleType = getTextFromElement(vehicleTypeDropdownValue);
        vehicleInfo.setVehicleType(existingVehicleType);

        fillOutVehicleYearModelMakeFields(vehicleInfo);
        clickOnAddVehicleButtonAndWaitForSpinner();

        return vehicleInfo;
    }

    public void validateAddVehicleAndDriversButton() {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertEquals(getTextFromElement(addVehicleAndDriversButton), "Add vehicles and drivers");
        fsa.assertTrue(addVehicleAndDriversButton.isDisplayed(), "Add Vehicle and Drivers button is visible");
        clickOnAddVehicleAndDriversButton();
        fsa.assertAll();

    }

    public void validateDisplayedListOfDriversWithAges(AutoApplicant applicant) throws Exception {
//        Assert.assertTrue(areAddedListOfDriversWithAgesDisplayed(applicant), "Added drivers are displayed on the page");
        testStepAssert(areAddedListOfDriversWithAgesDisplayed(applicant), "Expected:Added drivers should be displayed on who should we insure page.Actual:Added drivers is displayed on who should we insure page");
    }

    public WhoShouldWeInsurePage validateDisplayedListOfVehicles(FarmersSoftAssert softAssert, AutoApplicant applicant) throws Exception {
//        List<String> displayedVehicleListings = actualListOfVehicleInfo.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> expectedVehicleListings = new ArrayList<>();

        for (Vehicle vehicleInfo : applicant.getVehicles()) {
            String vehicleMake = vehicleInfo.getVehicleMake();
            String vehicleModel = vehicleInfo.getVehicleModel();
            String vehicleYear = vehicleInfo.getVehicleYear();
            if (vehicleInfo.isUseVIN()) {
                AppStore.Auto.AppStoreVehicle vehicle = this.getSessionStorageAppStore().getAuto().getVehicles().stream().filter(each -> {
                    String vin = "";
                    boolean result = false;
                    try {
                        vin = each.getVin();
                        result = vin.equals(vehicleInfo.getVehicleVIN());
                    } catch (NullPointerException npe) {
                        Log.info("Vin is not provided for this vehicle");
                    }
                    return result;
                }).collect(Collectors.toList()).get(0);
                vehicleMake = vehicle.getMakeDesc();
                vehicleYear = vehicle.getYear();
                vehicleModel = vehicle.getModelDesc();
            }
            vehicleModel = vehicleInfo.getVehicleModel().contains("QUATTRO") ? "QUAT" : vehicleModel;

            String expectedVehicleName = vehicleYear + SPACE + vehicleMake + SPACE + vehicleModel;
            expectedVehicleListings.add(expectedVehicleName);
        }

        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();


        List<String> actualListOfVehiclesDisplayed = new ArrayList<>();
        if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            actualListOfVehiclesDisplayed = vehiclesDriversInfoPage.getDisplayedVehicles();
            Collections.sort(actualListOfVehiclesDisplayed);
            Log.info("Actual vehicle list  : " + actualListOfVehiclesDisplayed);
            Log.info("Expected vehicle list: " + expectedVehicleListings);
            softAssert.assertTrue(actualListOfVehiclesDisplayed.containsAll(expectedVehicleListings) && expectedVehicleListings.containsAll(actualListOfVehiclesDisplayed), "Expected: Vehicles (" + expectedVehicleListings + ") should be displayed in who should we insure page.Actual: Vehicles (" + actualListOfVehiclesDisplayed + ") is displayed in Who should we insure page");
        } else {
            int intVehiclesCount = getEleCount(lblVehiclesList, 5);
            for (int i = 1; i <= intVehiclesCount; i++) {
                actualListOfVehiclesDisplayed.add(getTextFromElement(generateXpath(lblVehiclesName, "%d", Integer.toString(i))));
            }
        }
        testStepAssert(areTwoListEqual(actualListOfVehiclesDisplayed, expectedVehicleListings), "Expected:Vehicles (" + expectedVehicleListings + ") should be displayed in who should we insure page.Actual: Vehicles (" + actualListOfVehiclesDisplayed + ") is displayed in Who should we insure page");

        return this;
    }

    public WhoShouldWeInsurePage validateHeader() {
        sleep(2);
        validateIfTextExist(addEditVehicleDialogHeader, "Header is not displayed");
        return this;
    }

    public WhoShouldWeInsurePage validateInfoText() {
        validateIfTextExist(addVehicleSideDialogSubtitle, "Info text is not displayed");
        return this;
    }

    public WhoShouldWeInsurePage validatePageContent() {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(whoShouldWeInsurePageContent.isDisplayed(), "Who should we insure page message is visible");
        fsa.assertAll();
        return this;
    }

    public WhoShouldWeInsurePage validatePageTitle() {
        waitElementBeVisible(whoShouldWeInsureTitle);
        return this;
    }

    public void validatePniAndSniStatus(AutoApplicant applicant) throws Exception {
        sleep(2);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        List<String> actualPniAndSniNames = driver().findElements(disabledCheckBoxLabel).stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> expectedPniAndSniNames = List.of(getApplicantFullName(applicant), getAdditionalDriverFullName(getSni(applicant)));
        fsa.assertEquals(actualPniAndSniNames, expectedPniAndSniNames, "Validate PNI and SNI status");
        fsa.assertAll();
    }

    public WhoShouldWeInsurePage validateRequiredFieldErrorMessage(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(requiredFieldErrorMessage)), REQUIRED_FIELD_ERROR_MESSAGE, "Validate required field error");
        return this;
    }

    public WhoShouldWeInsurePage validateSubNote() {
        validateIfTextExist(subNote, "Sub note is not displayed");
        return this;
    }

    public void validateVINAndYMMFormFields(FarmersSoftAssert fsa) {
        Function<List<WebElement>, List<String>> function = labels -> labels.stream().map(this::getTextFromElement).collect(Collectors.toList());
        clickOnYMMButton();
        List<String> listOfActualFieldLabels = function.apply(formFieldLabels);
        clickOnVinButton();
        listOfActualFieldLabels.addAll(function.apply(formFieldLabels));
        listOfActualFieldLabels.removeIf(String::isEmpty);
        listOfActualFieldLabels = listOfActualFieldLabels.stream().distinct().collect(Collectors.toList());
        List<String> listOfExpectedFieldLabels = Stream.of("Year", "VIN", "Search make", "Search model, trim", "Select vehicle type").collect(Collectors.toList());
        Collections.sort(listOfActualFieldLabels);
        Collections.sort(listOfExpectedFieldLabels);
        fsa.assertEquals(listOfActualFieldLabels, listOfExpectedFieldLabels, "Validate VIN and YMM form fields");
    }

    public WhoShouldWeInsurePage validateVehicleMakeFieldErrorMessage(FarmersSoftAssert fsa) {
        softAssertFormFieldErrorMessage("Please provide make.", fsa);
        return this;
    }

    public WhoShouldWeInsurePage validateVehicleModelAndTrimFieldErrorMessage(FarmersSoftAssert fsa) {
        softAssertFormFieldErrorMessage("Please provide model, trim.", fsa);
        return this;
    }

    public WhoShouldWeInsurePage validateVehicleTypeFieldErrorMessage(FarmersSoftAssert fsa) {
        softAssertFormFieldErrorMessage("Please provide vehicle type.", fsa);
        return this;
    }

    public WhoShouldWeInsurePage validateVehicleVINFieldErrorMessage(FarmersSoftAssert fsa) {
        softAssertFormFieldErrorMessage("Enter VIN or select Year, make and model.", fsa);
        return this;
    }

    public WhoShouldWeInsurePage validateVehicleYearFieldErrorMessage(FarmersSoftAssert fsa) {
        softAssertFormFieldErrorMessage("Please provide year.", fsa);
        return this;
    }

    public void validateWhereCanIFindThis() {
        validateIfTextExist(whereCanIFindThisLink, "Where can I find this link is not displayed");
    }

    public boolean doesVINFieldHaveFocus() {
        waitElementBeVisible(addVehicleDialogHeader);
        return doesElementHaveFocus(waitElementBeVisible(vehicleVINEntryField));
    }

    public boolean isVehicleAdditionSideSheetVisible() {
        return isElementVisible(addVehicleDialogHeader, 1);
    }

    public boolean doesDriverFirstNameFieldHaveFocus() throws Exception {
        waitElementBeVisible(addDriverDialogHeader);
        return doesElementHaveFocus(waitElementBeVisible(getFormInputFieldWebElement(FIRST_NAME)));
    }

    public void enterAdditionalDriverData(AutoApplicant applicant, SqlAdditionalDriver driver) throws Exception {
        enterFirstName(driver.getFirstName());
        enterLastName(driver.getLastName());
        enterDateOfBirth(driver.getDateOfBirth());
        selectGenderTabButton(driver.getGender());
        selectUsOrCanadaLicensedRadioButton(driver.getLicenseToDriveInUSA());
        selectDoYouCommuteToNYIfApplicable(applicant);
    }

    private void addAdditionalSniDriver(SqlAdditionalDriver driver) throws Exception {
        selectGenderTabButton(driver.getGender());
        selectUsOrCanadaLicensedRadioButton(driver.getLicenseToDriveInUSA());
    }

    private void addAllDrivers(AutoApplicant applicant) throws Exception {
        addMainDriver(applicant);
        addAdditionalDrivers(applicant);
        clickOnDoneAddingDriversButton();
    }

    public void addMainDriver(AutoApplicant applicant) throws Exception {
        if(!isElementVisible(addDriverDialogHeader,2)) {
            AppStore.Data.CustomerData customerData = getSessionStorageAppStore().getData().getCustomerData();
            String pniFullName = customerData.getFirstName() + SPACE + customerData.getLastName();
            clickEditButtonWithDriverFullName(pniFullName);
        }
        selectGenderTabButton(applicant.getGender());
        String hasUSLicense = applicant.getFirstAgeForeignDriverLicense() == 18 ? NO : YES;
        selectUsOrCanadaLicensedRadioButton(hasUSLicense);
        selectDoYouCommuteToNYIfApplicable(applicant);
        selectCurrentlyInsuredRadioButton(applicant);
        clickOnSaveButton();
    }

    public void addAdditionalDrivers(AutoApplicant applicant) throws Exception {
        List<SqlAdditionalDriver> listOfAdditionalDrivers = applicant.getAdditionalDrivers();
        int numberOfAdditionalDrivers = Math.min(listOfAdditionalDrivers.size(), MAX_NUMBER_OF_ADDITIONALDRIVERS);
        for (int d = 0; d < numberOfAdditionalDrivers; d++) {
            SqlAdditionalDriver additionalDriver = listOfAdditionalDrivers.get(d);
            clickOnAddAnotherDriverButtonSideSheet();
            waitElementBeVisible(addDriverDialogHeader);
            enterAdditionalDriverData(applicant, additionalDriver);
            clickOnSaveButton();
        }
    }

    private void addAllDriversWithMoreThan4AdditionalDrivers(AutoApplicant applicant) throws Exception {
        addMainDriver(applicant);

        List<SqlAdditionalDriver> listOfAdditionalDrivers = applicant.getAdditionalDrivers();
        for (SqlAdditionalDriver additionalDriver : listOfAdditionalDrivers) {
            clickOnAddAnotherDriverButtonSideSheet();
            waitElementBeVisible(addDriverDialogHeader);
            enterAdditionalDriverData(applicant, additionalDriver);
            clickOnSaveButton();

            // Unchecking couple additional drivers from the list
            List<WebElement> listOfCheckedDrivers = new HeresWhatWeFoundPage().getCheckedDriverNames();
            if (listOfCheckedDrivers.size() == 4) {
                waitAndClickElement(listOfCheckedDrivers.get(1));
            }
        }
        clickOnDoneAddingDriversButton();
        checkAllUncheckedDriverCheckboxes();
    }

    private void addAllVehiclesInList(AutoApplicant applicant, String stateCode) throws Exception {
        List<Vehicle> listOfVehicles = applicant.getVehicles();
        int numberOfVehicles = limitVehicleCountToMaxAllowed(stateCode, listOfVehicles.size());
        isElementPresent(By.cssSelector("h4[id='addVehicleHeading']"), 2);
        for (int v = 0; v < numberOfVehicles; v++) {

            Vehicle vehicleInfo = listOfVehicles.get(v);

            if (vehicleInfo.isUseVIN()) {
                try {
                    fillOutVinField(vehicleInfo.getVehicleVIN());
                    int retry = 3;
                    while (isElementPresent(By.xpath("//mat-error")) && retry > 0) {
                        vehicleInfo.setVehicleVIN(getRandomVinNumber(3));
                        fillOutVinField(vehicleInfo.getVehicleVIN());
                        retry--;
                        if (retry == 0) {
                            Log.error("Fetching random vin from Randomvin.com was not successful");
                        }
                    }
                    String strTempVINDesc = getTextFromElement(lblVINDescription);
                    String[] arrVINDesc = strTempVINDesc.split(":");
                    String strVINDesc = arrVINDesc[1].trim();
                    vehicleInfo.setVinDescription(strVINDesc);
                    fillOutVehicleTypeIfNeeded(vehicleInfo.getVehicleType());
                } catch (Exception e) {
                    Log.debug(e.getMessage());
                    //vehicleInfo.setVehicleVIN(getRandomVinNumber(3));
                }

            } else {
                vehicleInfo.setUseVIN(false);
                fillOutVehicleYearModelMakeFields(vehicleInfo);
            }
            clickOnAddVehicleButtonAndWaitForSpinner();
            if (v != numberOfVehicles - 1) {
                clickOnAddAnotherVehicleButtonSideSheet();
            }
        }

        for (int v = 0; v < numberOfVehicles; v++) {
            Vehicle vehicleInfo = listOfVehicles.get(v);
            if (vehicleInfo.isUseVIN()) {
                List<AppStore.Auto.AppStoreVehicle> vehicles = getSessionStorageAppStore().getAuto().getVehicles();
                if(!vehicles.isEmpty()) {
                    AppStore.Auto.AppStoreVehicle appStoreVehicle = vehicles.get(v);
                    updateVehicleObjectWithNewlyAddedVehicleByVIN(appStoreVehicle, vehicleInfo);
                }
            }
        }
        if (isElementPresent(By.cssSelector("button.close-button"), 2)) {
        	clickOnDoneAddingVehiclesButton();
        }
    }

    // update the vehicle object with newly added vehicle details from AppStore by VIN
    public void updateVehicleObjectWithNewlyAddedVehicleByVIN(AppStore.Auto.AppStoreVehicle appStoreVehicle, Vehicle vehicle) {
        vehicle.setVehicleMake(appStoreVehicle.getMakeDesc());
        vehicle.setVehicleModel(appStoreVehicle.getModelDesc());
        vehicle.setVehicleYear(appStoreVehicle.getYear());
        vehicle.setVehicleType(appStoreVehicle.getVehicleType());
    }

    public void clickOnAddAnotherVehicleButtonSideSheet() throws Exception {
    	if (isElementPresent(By.xpath("//button[contains(@class, 'tui-btn tui-btn-cta add-vehicle-button')]"), 2)) {
    		waitAndClickElement(addAnotherVehicleButton);
    	} else {
    		clickAddAnotherVehicleButton();
    	}
    }

    public void fillOutVehicleTypeIfNeeded(String vehicleType) throws Exception {
        if (getAttributeData(vehicleTypeDropdown, CLASS).contains("ng-invalid")) {
            selectVehicleType(vehicleType);
        }
    }

    private void checkAllUncheckedDriverCheckboxes() throws Exception {

        int numberOfCheckBoxes = new HeresWhatWeFoundPage().getNumberOfUncheckedDrivers();
        for (int i = 0; i < numberOfCheckBoxes; i++) {
            waitUntilAngular5Ready();
            WebElement checkbox = driver().findElements(By.xpath(new HeresWhatWeFoundPage().getUnCheckedDriverNamesXpath())).get(0);
            waitAndClickElement(checkbox);
        }
    }

    public void clickAddAnotherVehicleButton() throws Exception {
        if (isElementVisible(addAnotherVehicleLink, 3)) {
        	scrollAndClickOnElement(addAnotherVehicleLink);
        } else if (isElementVisible(addVehicleAndDriversButton,1)) {
        	scrollAndClickOnElement(addVehicleAndDriversButton);
        } else if (isElementVisible(addAnotherVehicleLinkAlternative,1)) {
        	scrollAndClickOnElement(addAnotherVehicleLinkAlternative);
        } else if (isElementVisible(addAnotherVehicleLinkAlternative2, 1)) {
            clickElement(addAnotherVehicleLinkAlternative2);
        }
    }


    public void clickAddAnotherDriverButton() throws Exception {
        waitAndClickElement(addAnotherDriverButton);
    }

    protected void clickOnAddAnotherDriverButtonSideSheet() throws Exception {
        waitAndClickElement(addAnotherDriverButtonSideSheet);
    }

    private void clickOnButtonWithLabel(String label) throws Exception {
        WebElement webElement = driver().findElement(By.xpath(String.format("//button[contains(text(),'%s')]", label)));
        scrollAndClickOnElement(webElement);
    }

    public void clickOnDoneAddingDriversButton() {
        if (isElementVisible(doneAddingDriversButton, 5)) {
            waitAndClickElement(doneAddingDriversButton);
        } else {
            if (isElementVisible(doneAddingDriversButtonAlternative, 3)) {
                waitAndClickElement(doneAddingDriversButtonAlternative);
            }
        }
        waitForSpinnerToBeGone();
    }

    @SneakyThrows
    private void closeTheSideDialog() {
        driver().navigate().refresh();
        waitElementBeInvisible(xButton);
    }

    private WhoShouldWeInsurePage enterCurrentInsuranceCompany(String currentInsuranceCompany) throws Exception {
        if (!isElementDisplayed(By.xpath("//mat-form-field[.//mat-label[contains(text(),'" + CURRENT_INSURANCE_COMPANY + "')]]//input[not(@hidden)]"))) {
            return this;
        }
        WebElement currentPolicyDropdown = getFormInputFieldWebElement(CURRENT_INSURANCE_COMPANY);
        String currentPolicy = currentInsuranceCompany.toUpperCase();
        enterValueInField(currentPolicy, currentPolicyDropdown, "entering driver`s current insurance company");
        if (!selectValueInDropdown(currentPolicy, currentPolicyDropdown, genderSelectForm)) {
            scrollToElement(currentPolicyDropdown);
            sendKeysToElement(currentPolicyDropdown, "OTHERS");
            sleep(1);
            sendKeysToElement(currentPolicyDropdown, Keys.DOWN);
            sendKeysToElement(currentPolicyDropdown, Keys.ENTER);
        }
        return this;
    }

    private WhoShouldWeInsurePage enterDateOfBirth(String dateOfBirth) {
        enterValueInField(dateOfBirth, dateOfBirthEntryField, "Entering driver`s date of birth");
        return this;
    }

    private WhoShouldWeInsurePage enterFirstName(String firstName) throws Exception {
        WebElement firstNameInputField = getFormInputFieldWebElement(FIRST_NAME);
        enterValueInField(firstName, firstNameInputField, "Entering driver`s first name");
        if (getAttributeData(firstNameInputField, CLASS).contains("ng-invalid")) {
            sendKeysToElement(firstNameInputField, firstName);
        }
        return this;
    }

    private WhoShouldWeInsurePage enterLastName(String lastName) throws Exception {
        enterValueInField(lastName, getFormInputFieldWebElement(LAST_NAME), "Entering driver`s last name");
        return this;
    }

    private WhoShouldWeInsurePage enterPolicyExpirationDate(String policyExpirationDate) throws Exception {

        List<WebElement> policyExpirationDates = driver().findElements(By.xpath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_INPUT_FIELDS, POLICY_EXP_DATE)));

        if (policyExpirationDates.isEmpty()) {
            return this;
        }
        enterValueInField(policyExpirationDate, policyExpirationDates.get(0), "entering driver`s policy expiration date");

        Log.info("Set prior policy exp date to : " + policyExpirationDate);
        return this;
    }

    private WhoShouldWeInsurePage enterPriorInsuranceCompany(String priorInsuranceCompany) throws Exception {
        WebElement priorPolicyDropdown = getFormInputFieldWebElement("Prior insurance company");
        enterValueInField(priorInsuranceCompany, priorPolicyDropdown, "entering driver`s prior insurance company");
        selectValueInDropDown(priorPolicyDropdown, priorInsuranceCompany);
        return this;
    }

    private void enterVehicleModelAndTrim(Vehicle vehicleInfo) throws Exception {
        enterVehicleModelAndTrim(vehicleInfo.getVehicleModel());
    }

    private String getAdditionalDriverFullName(SqlAdditionalDriver additionalDriver) {
        return String.join(" ", additionalDriver.getFirstName(), additionalDriver.getLastName());
    }

    private String getApplicantFullName(AutoApplicant applicant) {
        return String.join(" ", applicant.getFirstName(), applicant.getLastName());
    }

    private WebElement getDropDownWebElement(String label) throws Exception {
        return driver().findElement(By.xpath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_DROP_DOWN_FIELDS, label)));
    }

    private WebElement getFormInputFieldWebElement(String label) throws Exception {
        WebElement webElement = driver().findElement(By.xpath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_INPUT_FIELDS, label)));
        waitElementBeVisible(webElement);
        return webElement;
    }

    private SqlAdditionalDriver getSni(AutoApplicant applicant) throws Exception {
        return new DriverReviewPage().getSni(applicant);
    }

    private void selectContinuouslyInsuredForPastSixMonthsRadioButtonIfExists(String yesOrNo) throws Exception {
        By lastSixMonthInsuredInfo = By.xpath(String.format("//div[contains(@id,'formField_lastSixMonthsInsuredInfo')]//mat-radio-group[contains(@class,'auto-add-driver-last-sixmonths-insured-info__radio-buttons')]//mat-radio-button[contains(.,'%s')]", yesOrNo));
        if (isElementDisplayed(lastSixMonthInsuredInfo)) {
            WebElement webElement = driver().findElement(lastSixMonthInsuredInfo);
            waitAndClickElement(webElement);
        }
    }

    private void selectMilitaryDeploymentQuestionIfExists() throws Exception {
        String yesOrNo = RandomUtils.nextBoolean() ? "Yes" : "No";
        By militaryDeploymentQuestionByObject = By.xpath(String.format("//div[contains(@id,'militaryDeploymentInfo')]//mat-radio-button[.//span[contains(text(),'%s')]]", yesOrNo));
        if (isElementDisplayed(militaryDeploymentQuestionByObject)) {
            WebElement webElement = driver().findElement(militaryDeploymentQuestionByObject);
            waitAndClickElement(webElement);
        }
    }

    public WhoShouldWeInsurePage selectCurrentBodilyInjuryLimits(String biLimit) throws Exception {
        if (!isElementDisplayed(By.xpath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_DROP_DOWN_FIELDS, CURRENT_BI_LIMITS)))) {
            return this;
        }

        WebElement currentBodilyInjuryLimitDropdown = getDropDownWebElement(CURRENT_BI_LIMITS);
        selectValueInDropdown(biLimit, currentBodilyInjuryLimitDropdown, genderSelectForm);
        Log.info("Set current BI limit to : " + biLimit);
        return this;
    }

    public void selectPipProtectionIfApplicable(AutoApplicant applicant) throws Exception {
        if(!applicant.getStateCode().equals(NJ)) {
            return;
        }
        WebElement currentPIPLimits = getDropDownWebElement("Current Principal Personal Injury Protection (PIP) limits");
        List<String> availablePipValues = getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("prinicipalPip")).findFirst().get().getDropDownValues().stream().map(AppStore.Auto.Dropdowns.Driver.DropDownResponseBean.DropDownValue::getWebDesc).collect(Collectors.toList());
        Collections.shuffle(availablePipValues);
        String selection = availablePipValues.get(0);
        selectValueInDropdown(selection, currentPIPLimits, genderSelectForm);
        Log.info("User selected PIP value as : " + selection);
    }

    public WhoShouldWeInsurePage selectCurrentlyInsuredRadioButton(AutoApplicant applicant) throws Exception {
        if (applicant.getStateCode().equals(CA)) {
            // CA does not ask about prior insurance
            return this;
        }
        waitElementBeVisible(insuredSelectForm);
        String hasBeenContinuallyInsuredForLastSixMonths = applicant.getContinuosInsurancePeriod().equals("< 6 Months") ? NO : YES;
        String applicantCurrentlyInsured = applicant.getCurrentlyInsuredStatus().equals("Insured") ? YES : NO;
        WebElement currentlyInsuredSelection = driver().findElement(By.xpath(String.format("//div[contains(@id,'formField_currentlyInsured')]//mat-radio-button[contains(.,'%s')]", applicantCurrentlyInsured)));
        scrollAndClickOnElement(currentlyInsuredSelection);
        int retry = 3;
        while (!getAttributeData(currentlyInsuredSelection, CLASS).contains(MAT_MDC_RADIO_CHECKED) && retry > 0) {
            clickElement(currentlyInsuredSelection);
            sleep(1);
            retry--;
        }
        if (applicantCurrentlyInsured.equals(YES)) {
            if(applicant.getStateCode().equals(NV) && !applicant.getTestScenario().contains(SPECIAL_BI_LIMIT_IS_NEEDED)) {
                applicant.setContinuosInsurancePeriod(">12 Months");
            }
            enterCurrentInsuranceCompany(applicant.getCurrentInsuranceCompany());
            updateApplicantCurrentInsuranceBiLimit(applicant);
            selectCurrentBodilyInjuryLimits(applicant.getCurrentBodilyInjuryLimit());
            selectPipProtectionIfApplicable(applicant);
            enterPolicyExpirationDate(applicant.getCurrentInsuranceExpirationDate());
            updateApplicantCurrentInsuranceDuration(applicant);
            selectLengthOfCurrentInsurance(applicant.getContinuosInsurancePeriod());
            selectContinuouslyInsuredForPastSixMonthsRadioButtonIfExists(hasBeenContinuallyInsuredForLastSixMonths);
            selectMilitaryDeploymentQuestionIfExists();
            if (applicant.getTestScenario().contains("UMB")) {
                Log.info("BI Limit set to " + applicant.getCurrentBodilyInjuryLimit() + NEWLINE, applicant.getTestScenario() + "BILimit");
            }
        } else {
            waitElementBeVisible(notInsuredReasonDropdownField);
            switch (applicant.getCurrentlyInsuredStatus()) {
                case NEVER_INSURED:
                    selectValueInDropDown(waitElementBeVisible(notInsuredReasonDropdownField), "I never had insurance");
                    break;
                case EXPIRED:
                    selectValueInDropDown(notInsuredReasonDropdownField, MY_INSURANCE_EXPIRED);
                    selectValueInDropdown("Before", priorInsuranceExpiredDropdownField, currentlyInsuredSelection);
                    if(applicant.getStateCode().equals(OR)) {
                        enterPriorInsuranceCompany(applicant.getCurrentInsuranceCompany().toUpperCase());
                        selectPriorBodilyInjuryLimits(applicant.getCurrentBodilyInjuryLimit());
                        // update length from available options
                        List<String> availableLengths = getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("lapseInCvgYes")).map(each -> each.getDropDownValues().get(0).getWebDesc()).collect(Collectors.toList());
                        Collections.shuffle(availableLengths);
                        String length = availableLengths.get(0);
                        selectLengthOfPriorInsurance(length);
                    }
                    selectContinuouslyInsuredForPastSixMonthsRadioButtonIfExists(hasBeenContinuallyInsuredForLastSixMonths);
                    selectMilitaryDeploymentQuestionIfExists();
                    break;
                case NOT_REQUIRED:
                    selectValueInDropDown(notInsuredReasonDropdownField, "I was not required to have insurance");
                    break;
                case DEPLOYED:
                    selectValueInDropDown(notInsuredReasonDropdownField, "I was in the military and deployed overseas");
                    break;
                default:
                    Log.warn("Unrecognized insured status: " + applicant.getCurrentlyInsuredStatus());
                    break;
            }
        }
        return this;
    }

    public void selectDoYouCommuteToNYIfApplicable(AutoApplicant applicant) throws Exception {
        if(!getSessionStorageAppStore().getData().getLandingStateCode().equals(NJ)) {
            return; // only applicable for NJ
        }
        String commutes = applicant.getTestScenario().contains(NEW_YORK_COMMUTER) ? "Yes" : "No";
        WebElement commutesElement = driver().findElement(By.xpath(String.format("//div[contains(@id,'commuteToNYNJ')]//mat-radio-button[contains(.,'%s')]", commutes)));
        waitAndClickElement(commutesElement);
        Log.info("For 'Do you commute to NY?' question User selected " + commutes, true);
    }


    public void updateApplicantCurrentInsuranceBiLimit(AutoApplicant applicant) throws Exception {
        if(applicant.getTestScenario().contains(DEFAULT_COVERAGE_VALIDATION) || applicant.getTestScenario().contains(SPECIAL_BI_LIMIT_IS_NEEDED)) {
            return;
        }
        List<String> availableBiLimits = getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("currentPolicyLimits")).findFirst().get().getDropDownValues().stream().map(each -> each.getWebDesc()).collect(Collectors.toList());
        // removing state minimums
        availableBiLimits.remove(_10K_AND_20K);
        availableBiLimits.remove(_15K_AND_30K);
        availableBiLimits.remove(_20K_AND_40K);
        availableBiLimits.remove(_25K_AND_50K);
        availableBiLimits.remove(_30K_AND_60K);
        if(getSessionStorageAppStore().getData().getLandingStateCode().equals(CT) && applicant.getTestScenario().contains("BW")) {
            availableBiLimits.remove(_100K_AND_300K);
        }
        Collections.shuffle(availableBiLimits);
        if(availableBiLimits.isEmpty()) {
            return;
        }
        String updatedBiLImit = availableBiLimits.get(0);
        applicant.setCurrentBodilyInjuryLimit(updatedBiLImit);
        Log.info("Applicant prior bi limit is updated to : " + updatedBiLImit);
    }

    public void updateApplicantCurrentInsuranceDuration(AutoApplicant applicant) throws Exception {
        if (applicant.getContinuosInsurancePeriod().equals("< 6 Months") || applicant.getStateCode().equals(WA)) {
            return; //return if less than 6 month is desired
        }
        List<String> availableLength = getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("lapseInCvgYes")).findFirst().get().getDropDownValues().stream().map(AppStore.Auto.Dropdowns.Driver.DropDownResponseBean.DropDownValue::getWebDesc).collect(Collectors.toList());
        availableLength.removeIf(each -> each.contains("6 Months") || each.contains("6 - 11 Months"));
        Collections.shuffle(availableLength);
        applicant.setContinuosInsurancePeriod(availableLength.get(0));
    }

    public WhoShouldWeInsurePage selectGenderTabButton(String gender) throws Exception {
        waitElementBeVisible(genderSelectForm);
        WebElement webElement = driver().findElement(By.xpath(String.format(GENDER_SECTION_XPATH + "//button[.//span[contains(text(),'%s')]]", gender.substring(0, 1))));
        scrollAndClickOnElement(webElement);
        return this;
    }

    private WhoShouldWeInsurePage selectLengthOfCurrentInsurance(String lengthOfCurrentInsurance) throws Exception {
        if (!isElementDisplayed(By.xpath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_DROP_DOWN_FIELDS, LENGTH_OF_CURRENT_INSURANCE)))) {
            return this;
        }
        WebElement element = getDropDownWebElement(LENGTH_OF_CURRENT_INSURANCE);
        selectValueInDropDown(element, lengthOfCurrentInsurance);
        Log.info("Set the length of the current insurance to : " + lengthOfCurrentInsurance);
        return this;
    }

    private WhoShouldWeInsurePage selectLengthOfPriorInsurance(String lengthOfPriorInsurance) throws Exception {
        WebElement element = getDropDownWebElement("Length of prior insurance");
        selectValueInDropDown(element, lengthOfPriorInsurance);
        return this;
    }

    private WhoShouldWeInsurePage selectPriorBodilyInjuryLimits(String biLimit) throws Exception {
        WebElement webElement = getDropDownWebElement("Prior Bodily Injury (BI) limits");
        selectValueInDropDown(webElement, biLimit);
        return this;
    }

    private void softAssertFormFieldErrorMessage(String expectedErrorMessage, FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(fieldErrorMessage)), expectedErrorMessage, "Verifying " + expectedErrorMessage);
    }

    private void validateIfTextExist(WebElement webElement, String message) {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(webElement.isDisplayed(), message);
        fsa.assertAll();
    }

    public void validateValidVIN_WhoShouldWeInsurePage() throws Exception {
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        if (isElementDisplayed(addVehicleAndDriversButton, 5)) {
            clickOnAddVehicleAndDriversButton();
        }
        String[] arrayOfValidVINs = {"3GCEK23319G222136", "2G1FP32K622106243", "WAUFFAFLXCA100747", "2C4RDGCG0DR534656"};
        for (String validVIN : arrayOfValidVINs) {
            enterValueInField(validVIN, txtVINUnmasked, "Entering VIN: ");
            waitForSpinnerToBeGone();
            String errorMessage = getErrorMessagesFromAllFields();
            String logMessage = setLogMessage(errorMessage);
            testStepAssert(errorMessage.equals(EMPTY_STRING), "Expected:No error message should be displayed for valid vin (" + validVIN + "). Actual:" + logMessage + " displayed for valid vin");
            if (isElementDisplayed(additionalInfoVehicleSectionOneUI.vinIsCorrectLink, 5)) {
                clickElement(additionalInfoVehicleSectionOneUI.vinIsCorrectLink);
            }
        }

    }

    public void validateInvalidVIN_WhoShouldWeInsurePage() throws Exception {
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        String stateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        boolean isStreamLine = isVehiclesDriversConsolidationImpl(stateCode);
        if (isElementDisplayed(addVehicleAndDriversButton, 5)) {
            clickOnAddVehicleAndDriversButton();
        }
        String[] arrayOfInvalidVINs = {"WP0ZZZ99ZTS392124", "3GCEI23319G222136", "3GCEQ23319G222136", "11111111111111111"};
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();

        if (!isStreamLine) {
            waitElementBeVisibleClickable(vehicleVINEntryField);
        }
        for (String invalidVIN : arrayOfInvalidVINs) {
            if (!isStreamLine) {
                enterValueInField(invalidVIN, vehicleVINEntryField, "Entering VIN: ");
                waitForSpinnerToBeGone();
                sendTab(vehicleVINEntryField);
            } else {
                vehiclesDriversInfoPage.sendKeysToVinInputField(invalidVIN);
                waitForSpinnerToBeGone();
            }
            String errorMessage = getErrorMessagesFromAllFields();
            String logMessage = setLogMessage(errorMessage);
            testStepAssert(!errorMessage.equals(EMPTY_STRING), "Expected:Error message should be displayed for invalid vin (" + invalidVIN + "). Actual:" + logMessage + " displayed for invalid vin");

            if (isElementDisplayed(additionalInfoVehicleSectionOneUI.vinIsCorrectLink, 5)) {
                waitAndClickElement(additionalInfoVehicleSectionOneUI.vinIsCorrectLink);
            }
        }
    }

    public void validateReplaceValidWithInvalidVIN_WhoShouldWeInsurePage() throws Exception {
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        if (isElementDisplayed(addVehicleAndDriversButton, 5)) {
            clickOnAddVehicleAndDriversButton();
        }
        enterValueInField("5GZCZ43D13S812715", txtVINUnmasked, "Entering Valid VIN: ");
        waitForSpinnerToBeGone();
        String errorMessage = getErrorMessagesFromAllFields();
        String logMessage = setLogMessage(errorMessage);
        testStepAssert(errorMessage.equals(EMPTY_STRING), "Expected:No error message should be displayed for valid vin (5GZCZ43D13S812715). Actual:" + logMessage + " displayed for valid vin");
        if (isElementDisplayed(additionalInfoVehicleSectionOneUI.vinIsCorrectLink, 5)) {
            waitAndClickElement(additionalInfoVehicleSectionOneUI.vinIsCorrectLink);
        }
        enterValueInField("SGZCZ43D13S812715", txtVINUnmasked, "Entering Invalid VIN: ");
        waitForSpinnerToBeGone();
        sleep(1);
        errorMessage = getErrorMessagesFromAllFields();
        logMessage = setLogMessage(errorMessage);
        testStepAssert(!getErrorMessagesFromAllFields().equals(""), "Expected:Error message should be displayed for replaced invalid vin (SGZCZ43D13S812715).Actual: " + logMessage + " displayed for replaced invalid vin");
        if (isElementDisplayed(additionalInfoVehicleSectionOneUI.vinIsCorrectLink, 5)) {
            waitAndClickElement(additionalInfoVehicleSectionOneUI.vinIsCorrectLink);
        }
    }

    private String setLogMessage(String errorMessage) {
    	return errorMessage.equals(EMPTY_STRING)? "No error": "Error message (" + errorMessage + ")";
    }

    public void validateCaHasNoPriorInsuranceQuestionAsked(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        testStep("Validate \"no prior insurance information is not applicable\" in the PNI details for CA State");
        addVehiclesWhenNoneAreFound(applicant);
        selectGenderTabButton(applicant.getGender());
        String hasUSLicense = applicant.getFirstAgeForeignDriverLicense() == 18 ? NO : YES;
        selectUsOrCanadaLicensedRadioButton(hasUSLicense);
        fsa.assertFalse(isElementVisible(insuredSelectForm, 2), "Prior insurance section should not be displayed for CA");
    }

    public void validateNoPriorInCurrentInsurnaceCompanyField_WhoShouldWeInsurePage(AutoApplicant applicant) throws Exception {
        addVehiclesWhenNoneAreFound(applicant);
        selectGenderTabButton(applicant.getGender());
        String hasUSLicense = applicant.getFirstAgeForeignDriverLicense() == 18 ? NO : YES;
        selectUsOrCanadaLicensedRadioButton(hasUSLicense);
        if (applicant.getStateCode().equals(CA)) {
            // CA does not ask about prior insurance
            return;
        }

        WebElement webElement = null;
        waitElementBeVisible(insuredSelectForm);
        webElement = driver().findElement(By.xpath("//div[contains(@id,'currentlyInsured')]//input[contains(@value,'Yes')]"));
        scrollAndClickOnHiddenElement(webElement);
        WebDriverWait wait = new WebDriverWait(driver(), Duration.ofSeconds(5));
        WebElement inputBox = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[contains(text(),'What is your current policy information')]/following::input[1]")));
        // Values to validate
        List<String> valuesToCheck = new ArrayList<>(Arrays.asList("NO PRIOR CARRIER", "NO PRIOR - MILITARY", "NO PRIOR - FIRST CAR", "NO PRIOR - CAR IN STORAGE", "NO PRIOR - ALL OTHER"));
        // Flag to check if all values are not present
        sendKeysToElement(inputBox, "NO PRIOR");
        wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.tagName("mat-option"), 0));
        testStep("Prior insurance companies starting with NO PRIOR", true);
        List<String> valuesShownToUser = driver().findElements(By.xpath("//mat-option/span")).stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> actual = valuesShownToUser.stream()
                .map(s -> s.replace('\u00A0', ' ').trim())
                .collect(Collectors.toList());
        List<String> expected = valuesToCheck.stream()
                .map(s -> s.replace('\u00A0', ' ').trim())
                .collect(Collectors.toList());
        testStepAssert(actual.containsAll(expected), "Prior Insurance company list should contain only valid values. " + expected + ". Full list starting with NO: " + valuesShownToUser);

    }

    public void validateADA_whoShouldWeInsurePage() throws Exception {
        if (!isADATestingEnabled()) return;

        // ada validate on the vehicle addition side sheet
        isOnWhoShouldWeInsurePage();
        waitAndClickElement(addVehicleAndDriversButton);
        waitAndClickElement(addVehicleButton);
        performADATesting(this.getClass().getSimpleName() + "_AddVehicleSideSheetVINToggle", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(whereCanIFindThisLink);
        performADATesting(this.getClass().getSimpleName() + "_AddVehicleSideSheetVinFinderHelper", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(backToVinButton);
        waitAndClickElement(vehicleYMMButton);
        performADATesting(this.getClass().getSimpleName() + "_AddVehicleSideSheetYMMToggle", MARKETING_IT, ACE_AUTO);
        // add mock vehicle to move forward with the flow
        waitAndClickElement(vehicleVINButton);
        fillOutVinField("2T1KR32E14C245975");
        waitAndClickElement(addVehicleButton);
        waitForSpinnerToBeGone();
        waitAndClickElement(doneAddingVehiclesButton);
        waitForSpinnerToBeGone();
        isElementVisible(addDriverDialogHeader, 2);
        scrollAndClickOnHiddenElement(currentlyInsuredYes);
        waitAndClickElement(driverSaveChangesButton);
        waitForPageToBeReady();
        performADATesting(this.getClass().getSimpleName() + "_AddApplicantSideSheetWithCurrentInsuranceYes", MARKETING_IT, ACE_AUTO);
        scrollAndClickOnHiddenElement(currentlyInsuredNo);
        if (isElementVisible(notInsuredReasonDropdownField, 1)) {
            selectValueInDropDown(notInsuredReasonDropdownField, MY_INSURANCE_EXPIRED);
        }
        waitAndClickElement(driverSaveChangesButton);
        waitForPageToBeReady();
        performADATesting(this.getClass().getSimpleName() + "_AddApplicantSideSheetWithCurrentInsuranceNo", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(closeIconMB);
        waitAndClickElement(checkedVehicles.get(0));
        driver().navigate().refresh();
        isOnWhoShouldWeInsurePage();
    }

    public void clickVehicleSaveChangesButton() {
        scrollAndClickOnElement(vehicleSaveChangesButton);
    }

    public void clickDriverSaveChangesButton() {
        scrollAndClickOnElement(driverSaveChangesButton);
    }

    public void addRandomAdditionalVehicle() throws Exception {
        clickAddAnotherVehicleButton();
        sendKeysToElement(waitElementBeVisible(vehicleVINEntryField), "1FTRF17283NB29646");
        waitForSpinnerToBeGone();
        scrollAndClickOnElement(addVehicleButton);
        if (isElementVisible(doneAddingVehiclesButton, 1)) {
            clickOnDoneAddingVehiclesButton();
        }
    }

    public void addRandomNewVehicle(String vinNumber) throws Exception {
        if(!isElementVisible(addVehicleDialogHeader,2)) {
        	clickAddAnotherVehicleButton();
        }
        sendKeysToElement(waitElementBeVisible(vehicleVINEntryField), vinNumber);
        waitForSpinnerToBeGone();
        fillOutVehicleTypeIfNeeded("Sedan");
        waitAndClickElement(addVehicleButton);
        if(isElementVisible(doneAddingVehiclesButton, 1)) {
            clickOnDoneAddingVehiclesButton();
        }
    }


    public void clickOnAddAVehicleButton() {
        scrollAndClickOnElement(addAVehicleButton);
    }

    public List<String> getNamesOfDisplayedDrivers() throws Exception {
        return driver().findElements(By.xpath("//ul[@class='auto-vehicles-drivers-review__drivers-list-section']//span[@class='mat-checkbox-label']")).stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    protected boolean isSaveDriverCtaIsPresent() {
        return isElementVisible(saveDriverCTAErrorMessage, 2);
    }

    public QuoteSummaryAutoPage navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults() throws Exception {
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        boolean isStreamlineExpected = isVehiclesDriversConsolidationImpl(getStateCodeFromAppStore());
        if (isStreamlineExpected) {
            new VehiclesDriversInfoPage().clickContinueButton();
            waitForSpinnerToBeGone();
        } else {
            clickOnContinueButton();
            VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
            testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on the vehicle review page", true);
            vehicleReviewPage.clickContinueButton();
            testStepAssert(driverReviewPage.isOnDriverReviewPage(), "User is on the driver review page", true);

            AppStore.Auto.Driver driver = getSessionStorageAppStore().getAuto().getDrivers().get(0);
            if (driver.getMaritalStatus().equals("M")) {
                WebElement maritalCheckbox = driverReviewPage.getMaritalCheckbox(driver.getFirstName() + SPACE + driver.getLastName());
                if (isCheckboxNotSelected(maritalCheckbox)) {
                    Log.error("Marital status of the driver is married but the checkbox is not checked, which is expected");
                } else {
                    Log.info("Marital status of the driver is married but the checkbox is checked, which is expected");
                }
            }
            driverReviewPage.fillOutDriverLicenseAges();
            driverReviewPage.fillOutDriverLicenseNumbers();
            driverReviewPage.fillOutOccupationAffinitySection();
            driverReviewPage.clickContinueButton();
        }
        SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
        if (signalPageOneUI.isOnSignalPage()) {
            signalPageOneUI.processSignalPage(true);
            Log.info("User has chosen to add Signal to the policy");
        }

        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        testStepAssert(contactInfoAutoPage.isOnContactInfoAutoPage(), "User is on the Contact info page", true);
        contactInfoAutoPage.setValuesAndContinue();
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
            BristolWestAdditionalDiscountsPage additionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
            if (additionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                additionalDiscountsPage.clickContinueButton();
            }
        }
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        vehicleDriverAssignmentPage.processVehiclesDriversAssignmentPageIfNeeded();

        AutoRentersBundleOfferingPage autoRentersBundleOfferingPage = new AutoRentersBundleOfferingPage();

        if (autoRentersBundleOfferingPage.isOnAutoRentersBundleOfferingPage()) {
            autoRentersBundleOfferingPage.processRentersBundleOfferingPage(false);
        }

        BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
        if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            bristolWestAdditionalDiscountsPage.clickContinueButton();
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote page", true);
        return quoteSummaryAutoPage;
    }

    public List<String> getDisplayedCompleteVehicles() throws Exception {
        List<String> completeVehiclesDisplayed = new ArrayList<>();
        List<WebElement> listOfVehiclesAdded = driver().findElements(By.xpath(LIST_OF_VEHICLES_ADDED_XPATH));
        for (WebElement vehicle : listOfVehiclesAdded) {
            String vehicleDescription = getTextFromElement(vehicle);
            completeVehiclesDisplayed.add(vehicleDescription);
        }
        return completeVehiclesDisplayed;
    }

    public List<String> getDisplayedCompleteDrivers() throws Exception {
        List<String> completeDisplayedDrivers = new ArrayList<>();
        for (WebElement driver : lblDriversList) {
            String driverDescription = getTextFromElement(driver);
            completeDisplayedDrivers.add(driverDescription);
        }
        return completeDisplayedDrivers;
    }

    public void excludeDriversEqualOrLessThan15() throws Exception {
        List<String> displayedCompleteDrivers = getDisplayedCompleteDrivers();
        for (String displayedDriver : displayedCompleteDrivers) {
        	//Driver names might have an apostrophe in them
            int age = getAgeOfDisplayedDriverByName(displayedDriver);
            if (age <= 15) {
                WebElement radioCheckbox = driver().findElement(By.xpath(String.format(driverCheckboxXpath, displayedDriver)));
                if (isButtonSelected(radioCheckbox)) {
                    // exclude the driver whose age is less than 15
                    clickElement(radioCheckbox);
                }
            }

        }
    }

    public int getAgeOfDisplayedDriverByName(String displayedDriver) throws Exception {
        WebElement ageSection = driver().findElement(By.xpath(String.format("//li[contains(@class,'drivers-list') and contains(.,\"%s\")]//span[contains(.,'Age')]", displayedDriver)));
        int age = Integer.parseInt(getTextFromElement(ageSection).replaceAll("\\D", ""));
        return age;
    }


    public void validateOrderOfBi_Limits() throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        WebElement currentBodilyInjuryLimitDropdown = getDropDownWebElement(CURRENT_BI_LIMITS);
        currentBodilyInjuryLimitDropdown.click();
        String HALF_FORMAT = "^\\$([\\d,]+)(\\.\\d+)?/\\$([\\d,]+)(\\.\\d+)?$";
        String SINGLE_FORMAT = "^\\$([\\d,]+)(\\.\\d+)?$";
        Pattern halfPattern = Pattern.compile(HALF_FORMAT);
        Pattern singlePattern = Pattern.compile(SINGLE_FORMAT);
        List<String> HALF_BI = new ArrayList<>();
        List<String> Single_BI = new ArrayList<>();
        List<WebElement> ActualBI_Limits = driver().findElements(By.xpath("//div[@role='listbox']//span[@class='mat-option-text']"));
        for (WebElement actualBILimit : ActualBI_Limits) {
            String BI_Limit = getTextFromElement(actualBILimit);
            if (halfPattern.matcher(BI_Limit).matches()) {
                BI_Limit = BI_Limit.replace("$", "").replace(",", "");
                HALF_BI.add(BI_Limit);
            } else if (singlePattern.matcher(BI_Limit).matches()) {
                BI_Limit = BI_Limit.replace("$", "").replace(",", "");
                Single_BI.add(BI_Limit);
            } else {
                Log.info(BI_Limit + "BI_Limit is not in the pattern");
            }
        }

        Log.info("Single Bi Limits: " + Single_BI);
        Log.info("Half Bi Limits: " + HALF_BI);
        for (int i = 0; i < HALF_BI.size() - 1; i++) {
            int FirstValue_FirstPart = Integer.parseInt(HALF_BI.get(i).split("/")[0]);
            int FirstValue_SecondPart = Integer.parseInt(HALF_BI.get(i).split("/")[1]);
            int NextValue_FirstPart = Integer.parseInt(HALF_BI.get(i + 1).split("/")[0]);
            int NextValue_SecondPart = Integer.parseInt(HALF_BI.get(i + 1).split("/")[1]);

            fsa.assertTrue(FirstValue_FirstPart <= NextValue_FirstPart, "HalfBI_value is not in Order");
            if(FirstValue_FirstPart == NextValue_FirstPart) {
                fsa.assertTrue(FirstValue_SecondPart < NextValue_SecondPart, "If first values are some, second value should be higher");
            }
        }
        for (int i = 0; i < Single_BI.size() - 1; i++) {
            int singleBIFirstValue = Integer.parseInt(Single_BI.get(i));
            int singleBISecondValue = Integer.parseInt(Single_BI.get(i + 1));
            fsa.assertTrue((singleBIFirstValue < singleBISecondValue), "Single BI_values are not in Order");
        }
        fsa.assertAll();
    }

    protected boolean isDriverSideDialogOpen() {
        return isElementVisible(addDriverDialogHeader, 1);
    }

    public List<WebElement> getListOfCheckedVehicles() {
        return listOfCheckedVehicles;
    }

    public List<WebElement> getDriverEditCheckboxesInputButtonByFullName(String fullName) throws Exception {
        String[] arrays = fullName.split(SPACE);
        StringBuilder capitalizedFullName = new StringBuilder();
        for (String string : arrays) {
            if(string.isEmpty()) {
                continue;
            }
            String adjusted = string.substring(0,1).toUpperCase() + string.substring(1).toLowerCase();
            capitalizedFullName.append(adjusted).append(SPACE);
        }
        String cappedFullName = capitalizedFullName.toString().strip();
        return driver().findElements(By.xpath(String.format("//mat-checkbox[contains(.,'%s')]//input | //app-driver-card[contains(.,'%s')]//mat-checkbox", cappedFullName, cappedFullName)));
    }

    public WebElement getDriverEditCheckboxInputButtonByFullName(String fullName) throws Exception {
        String[] arrays = fullName.split(SPACE);
        StringBuilder capitalizedFullName = new StringBuilder();
        for (String string : arrays) {
            if(string.isEmpty()) {
                continue;
            }
            String adjusted = string.substring(0,1).toUpperCase() + string.substring(1).toLowerCase();
            capitalizedFullName.append(adjusted).append(SPACE);
        }
        String cappedFullName = capitalizedFullName.toString().strip();
        return driver().findElement(By.xpath(String.format("//mat-checkbox[contains(.,'%s')]//input | //app-driver-card[contains(.,'%s')]//mat-checkbox//input", cappedFullName, cappedFullName)));
    }


    public void updateVehiclesAndDrivers(AutoApplicant applicant) throws Exception {
    	if (!getRandomVinNumber(1).isEmpty()) {
    		// add a new vehicle
    		addRandomNewVehicle(getRandomVinNumber(3));
    		// edit an existing vehicle
    		updateVinsForVehicles(getRandomVinNumber(3));
    	}

        // update an existing driver
        SqlAdditionalDriver sqlAdditionalDriver = applicant.getAdditionalDrivers().get(applicant.getAdditionalDrivers().size() - 1);
        WebElement driverEditCheckboxInputButtonByFullName = getEditDriverButtonForDriver(sqlAdditionalDriver.getFirstName() + SPACE + sqlAdditionalDriver.getLastName());
        waitAndClickElement(driverEditCheckboxInputButtonByFullName);
        selectGenderTabButton("Male");
        waitAndClickElement(saveButton);
        waitForSkeletonToBeGone();

        // add a new random driver
        clickAddAnotherDriverButton();
        enterAdditionalDriverData(applicant, getRandomAdditionalDriver());
        clickOnSaveButton();
        clickOnDoneAddingDriversButton();

    }

    public boolean isAddVehicleAndDriversButtonPresent() {
        return isElementVisible(addVehicleAndDriversButton, 2);
    }

    public boolean isAddVehiclesDriversButtonPresent() {
        try {
            wait.until(ExpectedConditions.visibilityOf(addVehicleAndDriversButton));
        } catch (TimeoutException te) {
            return false;
        }
        return isElementVisibleAndClickable(addVehicleAndDriversButton, 2);
    }

    public String getVehicleCardXpathWithVehicleDescription(String vehicleDesc) {
        return String.format("//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-details row') and contains(.,'%s')]", vehicleDesc);
    }

    public boolean isVehicleErrorMessageDisplayed(String vehicleDesc) throws Exception {
        return isElementPresent(By.xpath(getVehicleCardXpathWithVehicleDescription(vehicleDesc) + VEHICLE_VIN_ERROR_MESSAGE_XPATH), 1);
    }

    public void validateVinErrorMessage(String vehicleDesc, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(getVehicleCardXpathWithVehicleDescription(vehicleDesc) + VEHICLE_VIN_ERROR_MESSAGE_XPATH))), "We are unable to locate details for this vehicle. Please provide the VIN and try again.", "Expected VIN error message is displayed for vehicle: " + vehicleDesc);
    }

    public void uncheckVehicleCheckbox(Vehicle vehicle) throws Exception {
        String vehicleDescriptionFromVehicle = getVehicleDescriptionFromVehicle(vehicle);
        Log.info("User is unchecking the Vehicle checkbox: " + vehicleDescriptionFromVehicle);
        String vehicleCard = getVehicleCardXpathWithVehicleDescription(vehicleDescriptionFromVehicle);
        WebElement checkboxForVehicle = driver().findElement(By.xpath(vehicleCard + "//input"));
        scrollElementToMiddle(checkboxForVehicle);
        clickElement(checkboxForVehicle);
        wait.until(ExpectedConditions.attributeToBe(checkboxForVehicle, CLASS, "mdc-checkbox__native-control"));
    }

    public String getVehicleDescriptionFromVehicle(Vehicle vehicle) throws Exception {
        return vehicle.getVehicleYear() + SPACE + vehicle.getVehicleMake() + SPACE + vehicle.getVehicleModel();
    }

    public void validateVinErrorAndAddValidVin(FarmersSoftAssert fsa, Vehicle vehicle) throws Exception {
        String vehicleDesc = getVehicleDescriptionFromVehicle(vehicle);
        fsa.assertTrue(isOnWhoShouldWeInsurePage(), "User is on who should we insure page with Bw rate failure with VIN");
        validateVinErrorMessage(vehicleDesc, fsa);
        fsa.assertTrue(isVehicleErrorMessageDisplayed(vehicleDesc), "We are unable to locate details for this vehicle. Please provide the VIN and try again. error message is displayed for first vehicle");

        // validate error message for CTA button
        clickContinueButton();
        // validate CTA error message
        fsa.assertEquals(getTextFromElement(pageCTAErrorMessage), "One or more fields required.", "Expected CTA error message is displayed on who should we insure page with Bw rate failure with VIN");

        String vehicleCard = getVehicleCardXpathWithVehicleDescription(vehicleDesc);

        // locate and click edit button for the vehicle
        WebElement vehicleEditButton = driver().findElement(By.xpath(vehicleCard + "//a[contains(.,'Edit')]"));
        scrollToElement(vehicleEditButton);
        waitAndClickElement(vehicleEditButton);

        // update vehicle data
        String randomVin = getRandomVinNumber(3);
        vehicle.setUseVIN(true);
        vehicle.setVehicleVIN(randomVin);

        // click Vin toggle
        clickOnVinButton();
        // fill out vin field
        fillOutVinField(randomVin);
        waitForSpinnerToBeGone();
        //click add vehicle button
        clickOnAddAVehicleButton();
        sleep(1);
        while (isElementDisplayed(By.xpath("//mat-error[contains(.,'This VIN is already added for a vehicle.')]"))) {
            String newRandomVin = getRandomVinNumber(3);
            vehicle.setVehicleVIN(newRandomVin);
            fillOutVinField(newRandomVin);
            waitForSpinnerToBeGone();
            waitAndClickElement(addVehicleButton);
            waitForSpinnerToBeGone();
        }
        sleep(1);
        if(isElementVisible(doneAddingVehiclesButton, 1)) {
            waitAndClickElement(doneAddingVehiclesButton);
        }
    }

    public void addAnotherVehicleUsingVin(String vin) throws Exception {
        clickOnAddVehiclesAndDriversButton();
        if (isVehicleAdditionSideSheetVisible()) {
            fillOutVinField(vin);
            clickOnAddVehicleButton();
        }
    }

    public void addAnotherDriverUsingRetrievedDriverDetails(Map<String, String> driverDetails) throws Exception {
        fillOutDriverDetailsUsingRetrievedDetails(driverDetails);
        WebElement element = driver().findElement(By.cssSelector("button[class='tui-btn tui-btn-primary auto-add-driver-save__button']"));
        scrollAndClickOnElement(element);
    }

    public int getDriversCount() {
        return getEleCount(lblDriversList, 3);
    }

    public void fillOutDriverDetailsUsingRetrievedDetails(Map<String, String> driverDetails) throws Exception {
        clickAddAnotherDriverButton();
        testStepAssertTrue(isDriverSideDialogOpen(), "Add driver side dialog is open");
        enterFirstName(driverDetails.get("firstName"));
        enterLastName(driverDetails.get("lastName"));
        enterDateOfBirth(driverDetails.get("dob"));
        selectGenderTabButton(driverDetails.get("gender"));
        selectUsOrCanadaLicensedRadioButton(driverDetails.get("isLicenseIssuedInUS"));
    }

    public void addVehicleDetailsWith2027YMM(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        VehiclesDriversInfoPage vehiclesDriversInfoPage=new VehiclesDriversInfoPage();
        boolean isStreamlinedState = vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        if (!isStreamlinedState) {
            clickOnYMMButton();
        }
        vehiclesDriversInfoPage.check2027YearDetailsUsingYMM(applicant, fsa);
        vehiclesDriversInfoPage.clickOnAddAVehicleButton();
    }
}
