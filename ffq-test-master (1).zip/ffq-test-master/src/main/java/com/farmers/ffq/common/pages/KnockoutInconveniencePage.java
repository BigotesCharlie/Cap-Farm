package com.farmers.ffq.common.pages;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.AppStore.KnockOut;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import lombok.Getter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter
public class KnockoutInconveniencePage extends AutoBasePage {

    public static final String EXPECTED_SPECIAL_ATTENTION_TITLE = "We apologize, but we can't finish your quote online at this time";
    private static final String EXPECTED_THANK_YOU_FOR_CHOOSING_FARMERS_INSURANCE_TITLE = "Thank you for choosing Farmers Insurance!";
    private static final String JUST_FEW_QUESTIONS_LEFT_DESCRIPTION = "We just have a few questions left for you to answer. Please contact us and an agent will work with you to get those questions answered and finish your purchase.";
    private static final String WE_ARE_SORRY = "We’re sorry!";
    private static final String ITS_NOT_YOU = "It's us, not you. You can try again or jot down your quote number and come back later to";
    private static final String UNABLE_TO_QUOTE_AT_THIS_TIME = "We are unable to complete your quote online at this time. Please contact us to see if you qualify.";
    private static final String INCONVENIENCE_PAGE_TITLE_XPATH = "//h1[contains(@class, 'inconvenience__title')]";
    private static final String KO_FOUNDATION_TYPE = "We are unable to complete your request at this time.";
    private static final String KO_FOUNDATION_TYPE_DESCRIPTION = "We're sorry, but we can't finish your quote online at this time. The property has a foundation type that isn't eligible for coverage. Please contact us to complete your quote (we may still be able to offer you coverage).";
    private static final String WE_NOT_ABLE_TO_COMPLETE_YOUR_QUOTE = "We aren't able to complete your quote at this time.";
    private static final String WE_APOLOGIZE_FOR_INCONVENIENCE = "We apologize for the inconvenience. The following company (companies) may be able to provide you with an online quote.";
    private static final String HOME_NOT_OFFERED_DESCRIPTION = "You need an insurance product for your home that we do not offer online at this time. " +
            "Please contact us to complete your quote.";

    @FindBy (xpath = "//app-knockout-lead-form")
    private WebElement thankYouForYourInterestPage;

    @FindBy(css = "h1[class='tui-h1 inconvenience__title']")
    private WebElement inconvenienceTitle;

    @FindBy(id = "inconvenience_header-title")
    private WebElement inconvenienceHeaderTitle;

    @FindBy(css = "div[id='quote_unavailable_header-title']>h1")
    private WebElement quoteUnavailablePageTitle;

    @FindAll({
            @FindBy(id = "knockout_title"),
            @FindBy(id = "heading-rebrand")
    })
    private WebElement knockoutTitle;

    @FindBy (xpath = "//*[contains(@class, 'mobilehome-knockout__title')]")
    private WebElement foremostKnockoutPageTitle;
    @FindBy (xpath = "//*[contains(@class, 'mobilehome-knockout__message')]")
    private WebElement foremostKnockoutMessage;
    @FindBy (xpath = "//*[contains(@class, 'mobilehome-knockout__quote-reference')]")
    private WebElement foremostKnockoutQuoteReferenceMessage;
    @FindBy (xpath = "//*[contains(@class, 'mobilehome-knockout__closing')]")
    private WebElement foremostKnockoutClosingMessage;

    @FindBy(css = "p[class='tui-body']")
    private WebElement knockoutDescription;

    @FindBy(xpath = "//app-fgia-knockout//p[contains(@class,'tui-stacking-top')]")
    private WebElement FGIAknockoutDescription;

    @FindBy(css = "span[class='tui-body']")
    private WebElement inconvenienceDescription;

    @FindBy(css = "button[class='tui-btn tui-btn-primary continue-cta']")
    private WebElement continueToFGIAButton;

    @FindBy(css = "button[data-test-id='AGREE_AND_CONTINUE_BRANDING_BUTTON']")
    private WebElement agreeAndContinueButtonFGIA;

    @FindBy(id = "pg_intro_title")
    private WebElement fgiaPageHeader;

    @FindBy(xpath = "//a[.='Farmers.com']")
    private WebElement farmersLink;

    private static final String REFERENCE_QUOTE_NUMBER = "Please reference your quote number:";
    @FindBy(xpath = "//div[contains(@class,'knockout__quote-number')]//span[1]")
    private WebElement koQuoteNumberReference;

    @FindBy(xpath = "//div[contains(@class,'quote-details')]//p")
    private WebElement koQuoteNumberReference_fgia;

    @FindBy(xpath = "//div[contains(@class,'knockout__quote-number')]")
    private WebElement quoteNumberReference;

    @FindBy(css = "button[class='mav-partner__button']")
    private List<WebElement> monetizationButtons;

    @FindBy(xpath = "//div[contains(@class,'inconvenience__quote-number')]//span[@class='tui-body']")
    private WebElement quoteReferenceText;

    @FindBy(xpath = "//div[contains(@class,'quote-number')]//span[@class='tui-body-bold']")
    private WebElement quoteNumberInKO;

    @FindBy(xpath = "//div/div[contains(.,'Need more help?')]")
    private WebElement needMoreHelp;

    @FindBy(xpath = "//div/div[contains(.,'You can call customer service at')]")
    private WebElement youCanCallCustomerService;

    @FindBy(xpath = "//div/div[2][contains(@class, 'knockout__no-agent-text')]")
    private WebElement youCanLabelElement;

    @FindBy(xpath = "//div[contains(@class,'inconvenience__cta')]")
    private WebElement tryAgain;

    @FindBy(css = "div[class='existingCustomer__cta ng-star-inserted']>button")
    private WebElement existingCustomerCTA;

    private static final String YOUR_AGENT = "Your agent";
    @FindBy(xpath = "//div[contains(text(),'" + YOUR_AGENT + "')]")
    private WebElement yourAgent;

    @FindBy(xpath = "div[class='yext-agents-title-text tui-body-text-bold']")
    private WebElement agentsTitle;

    @FindBy(xpath = "//div[@class='yext-agents-content-container']//div[contains(@class,'auto-agent-details')]")
    private List<WebElement> agentList;

    @FindBy(xpath = "//button[contains(.,'Contact')]")
    private List<WebElement> agentContactButtons;

    @FindBy(css = "div[class='tui-body-bold']")
    private WebElement agentName;

    @FindBy(css = "button[class='tui-link-button yext-agent-contact-text']")
    private List<WebElement> agentsContactButtons;

    @FindBy(css = "button[class='tui-link-button']")
    private WebElement contactMeButton;

    @FindBy(css = "div[class='tui-h3 knockout__toll-free-number ng-star-inserted']")
    private WebElement tollFreeNumber;

    @FindBy(xpath = "//div[contains(@class,'agent-details-container')]//a[starts-with(@aria-label,'Contact farmers representative at')]")
    private WebElement tollFreeNumber2;

    private static final String BIT_MORE_INFO_ABOUT_VEHICLE = "We need a bit more information about your vehicle(s). Please contact us to complete your quote.";
    @FindBy(xpath = "//p[contains(text(), '" + BIT_MORE_INFO_ABOUT_VEHICLE + "')]")
    private WebElement bitMoreInfoAboutVehicleKOMessage;

    @FindBy(xpath = "//img[@class='agent-image']")
    private WebElement agentsImage;
    @FindBy(xpath = "//div[contains(@class,'agent-details')]/div[2]/div/div[2]")
    private WebElement agentFullNameWebElement;

    private static final String LEASE_LOAN_KNOCKOUT_MSG = "We are unable to complete your policy purchase online. Please contact us with your loan or leasing company information so we may finish.";
    @FindBy(xpath = "//p[contains(text(), '" + LEASE_LOAN_KNOCKOUT_MSG + "')]")
    private WebElement leasLoanKnockOutMessage;
    @FindBy(xpath = "//app-knockout//form//div[@id='mediaAlpha']//div[contains(@class,'mav-partner__buttons')]")
    private List<WebElement> startMyQuoteButtonsOnMonetizationKOPage;

    @FindBy(css = "div[id='quote_unavailable_body_farmers']>a")
    private WebElement doesntOfferBusinessTollNumberDesktop;

    @FindBy(css = "a[id='quote_unavailable_body_farmers-mobile']")
    private WebElement doesntOfferBusinessTollNumberMobile;

    @FindBy(xpath = "//a[text()='Find a Farmers Agent']")
    private WebElement findFarmersAgent;

    @FindBy(xpath = "//div[@class='knock-out_header-title']")
    private WebElement koTitleText;

    @FindBy(xpath = "//div[@class='knock-out_body_knock_message']")
    private WebElement koDescriptionText;

    @FindBy(xpath = "//img[contains(@class,'knock-out_agent-image')]")
    private WebElement agentImage;

    @FindBy(xpath = "//div[contains(@class,'knock-out_agent-detail-name')]")
    private WebElement agentNameKOPage;

    @FindBy(xpath = "//div[contains(@class,'knock-out_agent-detail-text')]")
    private WebElement agentDetailsText;

    @FindBy(xpath = "//a[contains(@class,'agent-email-link')]//div[contains(@class,'knock-out_agent-detail-email')]")
    private WebElement agentEmail;

    @FindBy(xpath = "//div[contains(@class,'knock-out_desktop')]//div[contains(@class,'knock-out_agent-detail-phone')]")
    private WebElement agentPhoneDesktop;

    @FindBy(xpath = "//div[contains(@class,'knock-out_mobile')]//div[contains(@class,'knock-out_agent-detail-phone')]")
    private WebElement agentPhoneMobile;

    @FindBy(xpath = "//div[contains(@class,'schedule-appointment-content')]")
    private WebElement scheduleAppointment;

    @FindBy(xpath = "//a[contains(@class,'agent-adress-link')]//span")
    private WebElement agentAddress;

    @FindBy(xpath = "//div[@id='knock-out_body_noagent']")
    private WebElement needMoreHelpDigitalMonetization;

    @FindBy(xpath = "//div[@id='knock-out_body_call-custome']")
    private WebElement callCustomerServiceDigitalMonetization;

    @FindBy(xpath = "//span[contains(@class,'knock-out_desktop')]//a[@id='default-phone']")
    private WebElement tollFreeDigitalMonetization;

    // FGIA Knockout elements
    @FindBy(xpath = "//h2[@class='tui-h2 mt-10']")
    private WebElement fgiaSubtitle;
    @FindBy(xpath = "//h4[@class='tui-h4 mt-10']")
    private WebElement fgiaCantOfferText;
    @FindBy(xpath = "//p[@class='tui-body tui-stacking-top-md col-11']")
    private List<WebElement> fgiaPageContents;
    @FindBy(xpath = "//h4[@class='tui-h4']")
    private WebElement fgiaSoundGoodText;
    @FindBy(xpath = "//p[@class='tui-body tui-stacking-top-xs']")
    private WebElement fgiaTabBelowToContinueText;
    @FindBy(xpath = "//div[contains(@class,'quote-details')]//span[@class='tui-body']")
    private WebElement fgiaReferenceYourQuoteText;
    @FindBy(xpath = "//div[contains(@class,'quote-details')]//span[@class='tui-body-bold']")
    private WebElement quoteNumberInKO_FGIA;


    /**
     * Constructor.
     *
     * @throws Exception
     */
    public KnockoutInconveniencePage() throws Exception {
    }

    public boolean isOnInconveniencePage() {
        closeQualtricsPopUp();
        return isElementVisible(inconvenienceTitle, 30);
    }

    public boolean isQuoteKnockedOut() {
        return isElementVisible(inconvenienceTitle, 3) || isElementVisible(knockoutTitle, 3);
    }

    public boolean isOnKnockOutPage() throws Exception {
        return isElementVisible(tollFreeNumber, 15) || isElementVisible(knockoutTitle, 10) || isElementVisible(thankYouForYourInterestPage, 20);
    }

    public boolean isUnableToCompleteOnlineQuoteKnockOutPage() {
        return isElementVisible(inconvenienceHeaderTitle, 3);
    }

    public boolean isOnDigitalMonetizationKOPage() throws Exception {
        return isElementVisible(koTitleText, 5);
    }

    public boolean isQualtricsSurveyPopUpDisplayed() {
        return super.isQualtricsSurveyFormDisplayed();
    }

    public boolean isOnMonetizedMediaAlphaPage() {
        return !startMyQuoteButtonsOnMonetizationKOPage.isEmpty();
    }

    public boolean isOnForemostKnockoutPage() {
    	return isElementVisible(foremostKnockoutPageTitle, 5) || isElementVisible(FGIAknockoutDescription, 5);
    }

    public void verifyForemostKnockoutPageContent(FarmersSoftAssert fsa, boolean isQuoteNumberExpected) {
        fsa.assertEquals(getTextFromElement(foremostKnockoutPageTitle), "Thank you for your interest in Foremost", "Foremost Knockout page title check");
        fsa.assertEquals(getTextFromElement(foremostKnockoutMessage), "We're sorry, but we can't complete your quote online at this time. " +
        		"To continue, please call us at 888-902-1896 from 8:00 a.m. to 10:00 p.m. EST, Monday through Friday, or 9:00 a.m. to 5:00 p.m. EST Saturday.", "Foremost Knockout page message check");
        if (isQuoteNumberExpected) {
        	fsa.assertTrue(getTextFromElement(foremostKnockoutQuoteReferenceMessage).contains("Please reference your quote number: "), "Foremost Knockout page quote reference message check");
        }
        fsa.assertEquals(getTextFromElement(foremostKnockoutClosingMessage), "Thank you for your patience; we look forward to hearing from you!", "Foremost Knockout page closing message check");
    }


    public boolean verifyExistingCustomerKnockout() throws Exception {
        final String EXPECTED_EXISTING_CUSTOMER_KNOCKOUT_TITLE = "Our records indicate you have an existing Farmers Auto Policy.";
        waitElementBeVisible(knockoutTitle);
        boolean testPassed = testExpectedTextContentForElement(waitElementBeVisible(knockoutTitle), EXPECTED_EXISTING_CUSTOMER_KNOCKOUT_TITLE);
        final String EXPECTED_EXISTING_CUSTOMER_DESCRIPTION = "As an existing customer, you can manage your policy online at Farmers.com or contact your agent if you'd like to make changes to your policy.";
        final String EXPECTED_EXISTING_CUSTOMER_DESCRIPTION_ALTERNATE = "If you'd like to make changes to your existing auto policy, please contact your agent.";
        String actualDescription = getTextFromElement(knockoutDescription);
        testPassed &= (actualDescription.equals(EXPECTED_EXISTING_CUSTOMER_DESCRIPTION) || actualDescription.equals(EXPECTED_EXISTING_CUSTOMER_DESCRIPTION_ALTERNATE));
        final String EXPECTED_EXISTING_CUSTOMER_CTA_TEXT = "Login or Create Account";
        if(isElementVisible(existingCustomerCTA,2)) {
            testPassed &= testExpectedTextContentForElement(existingCustomerCTA, EXPECTED_EXISTING_CUSTOMER_CTA_TEXT);
            waitAndClickElement(existingCustomerCTA);
            waitForSpinnerToBeGone();
            sleep(2);
            testPassed &=waitElementBeVisible(driver().findElement(By.cssSelector("div[class='login-heading']"))).isDisplayed();
            driver().navigate().back();
        }
        return testPassed;
    }

    public boolean verifyStateTurnedOffInconvenience(){
        boolean testResult = testExpectedTextContentForElement(waitElementBeVisible(inconvenienceTitle), WE_ARE_SORRY);
        testResult &= testExpectedTextContentForElement(waitElementBeVisible(inconvenienceDescription), ITS_NOT_YOU);
        return testResult;
    }

    public boolean verifySpecialAttentionKOFromAddressPage_EG005() {
        boolean testPassed = testExpectedTextContentForElement(waitElementBeVisible(knockoutTitle), "Thank you for your interest in Farmers Insurance\u00ae");
        testPassed &= koQuoteNumberReference.isDisplayed();
        testPassed &= needMoreHelp.isDisplayed();
        testPassed &= testExpectedTextContentForElement(waitElementBeVisible(tollFreeNumber), CALL_FARMERS);
        testPassed &= quoteNumberInKO.isDisplayed();
        Log.info("verifySpecialAttentionKOFromAddressPage_EG005", true);
        return testPassed;
    }

    public boolean verifyZipCodeRestricted_EG013() throws Exception{
        driver().manage().window().maximize();
        boolean testPassed = testExpectedTextContentForElement(waitElementBeVisible(inconvenienceTitle), WE_ARE_SORRY);
        testPassed &= testExpectedTextContentForElement(waitElementBeVisible(inconvenienceDescription), ITS_NOT_YOU );
        testPassed &= farmersLink.isDisplayed();
        return testPassed;
    }

    public void verifySpecialAttentionKOFromDriverReviewPage_EK32(String quoteNumber, String realAgentName, boolean isRealAgentAssigned, FarmersSoftAssert fsa) throws Exception {
        isOnKnockOutPage();
        fsa.assertEquals(getTextFromElement(driver().findElement(By.id("knockout_title"))), YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION, "Knockout title check");
        final String EXPECTED_DESCRIPTION = "Your Farmers agent will contact you to complete your quote.";
        fsa.assertTrue(waitElementBeVisible(koQuoteNumberReference).isDisplayed(), "KO quote reference message displayed");
        fsa.assertTrue(waitElementBeVisible(quoteNumberInKO).isDisplayed(), "KO quote numeber displayed");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(quoteNumberInKO)), quoteNumber, "Quote number matches");
        if (isRealAgentAssigned) {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutDescription)), EXPECTED_DESCRIPTION, "Knockout page description check");
            fsa.assertEquals(getAssignedRealAgentName(), realAgentName, "Assigned real agent name check");

        } else {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(tollFreeNumber)), CALL_FARMERS, "KO desktop toll number check");
        	int numberOfElements = agentList.size();
            for (int i = 0; i< numberOfElements; i++) {
                fsa.assertTrue(agentList.get(i).isDisplayed(), "Agent " + (i+1) + " is displayed");
            }
        }
        Log.info("verifySpecialAttentionKOFromDriverReviewPage_EK32", true);
    }


    public void verifySpecialAttentionKOFromVehiclePage_VEH007(String quoteNumber, boolean isRealAgentAssigned, String realAgentName, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutTitle)), EXPECTED_SPECIAL_ATTENTION_TITLE, "Expected ko title check");
        fsa.assertTrue(waitElementBeVisible(koQuoteNumberReference).isDisplayed(), "KO quote number reference message displayed");
        fsa.assertTrue(quoteNumberInKO.isDisplayed(),"Quote number displayed");
        fsa.assertEquals(getTextFromElement(quoteNumberInKO), quoteNumber);
        if(isRealAgentAssigned) {
            fsa.assertEquals(this.getAssignedRealAgentName(), realAgentName, "Assigned real agent name check");
        } else {
            fsa.assertTrue(needMoreHelp.isDisplayed(), "Need more help displayed");
            fsa.assertTrue(youCanCallCustomerService.isDisplayed(), "You can call customer service message displayed");
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(tollFreeNumber)), CALL_FARMERS, "Toll number check");
        }
        Log.info("verifySpecialAttentionKOFromVehiclePage_VEH007", true);
    }

    public boolean validateFarmersDoesNotOfferBusinessKO_EG004() throws Exception {
        final String EXPECTED_KNOCKOUT_TITLE = "Sorry, we don't offer insurance in your area.";
        boolean testPassed = testExpectedTextContentForElement(waitElementBeVisible(quoteUnavailablePageTitle), EXPECTED_KNOCKOUT_TITLE);

        final String EXPECTED_KNOCKOUT_DESCRIPTION = "Click at least 2 to 3 companies below to find the best rate!";
        WebElement description = driver().findElement(By.cssSelector("div[id='quote_unavailable_body_message']"));
        testPassed &= testExpectedTextContentForElement(waitElementBeVisible(description), EXPECTED_KNOCKOUT_DESCRIPTION);

        sleep(3);
    	int numberOfElements = monetizationButtons.size();
        for (int i = 0; i< numberOfElements; i++){
            WebElement monetizationButton = monetizationButtons.get(i);
            testPassed &= monetizationButton.isEnabled();
            testPassed &= testExpectedTextContentForElement(waitElementBeVisible(monetizationButton), "Start My Quote");
            String farmersWindow = driver().getWindowHandle();
            waitAndClickElement(monetizationButton);
            Set<String> windowHandles = driver().getWindowHandles();
            windowHandles.remove(farmersWindow);
            String partnerTap = windowHandles.stream().findFirst().get();
            driver().switchTo().window(partnerTap);
            sleep(2);
            driver().close();
            driver().switchTo().window(farmersWindow);
        }

        testPassed &= needMoreHelp.isDisplayed();
        testPassed &= youCanCallCustomerService.isDisplayed();

        if (isUseMobileViewEnabled()) {
            testPassed &= testExpectedTextContentForElement(waitElementBeVisible(doesntOfferBusinessTollNumberMobile), "1-800-420-9008");

        } else {
            testPassed &= testExpectedTextContentForElement(waitElementBeVisible(doesntOfferBusinessTollNumberDesktop), "1-800-206-9469");

        }
        Log.info("validateFarmersDoesNotOfferBusinessKO_EG004", true);
        return testPassed;
    }

    public void verifyGeneralInfoOnBindKnockOut(AppStore.Data.AgentData agentData, FarmersSoftAssert fsa) throws Exception {
        isOnKnockOutPage();
        String agentFullName = agentData.getFirstName() + " " + agentData.getLastName();
        fsa.assertTrue(koQuoteNumberReference.isDisplayed(), "koQuoteNumberReference.isDisplayed()");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(koQuoteNumberReference)), REFERENCE_QUOTE_NUMBER, "Reference quote number text check");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(agentFullNameWebElement)), agentFullName, "Agent name check");
    }

    public boolean verifyLenderKnockOutMessage(){
        return testExpectedTextContentForElement(waitElementBeVisible(leasLoanKnockOutMessage), LEASE_LOAN_KNOCKOUT_MSG);
    }

    public void validateFinancialFilingInAnotherState(FarmersSoftAssert fsa, String quoteNumber, boolean isAgentAssigned) throws Exception {
        isOnKnockOutPage();
        fsa.assertTrue(isElementPresentByID(knockoutTitle), "KO page title displayed");
        fsa.assertTrue(waitElementBeVisible(knockoutDescription).isDisplayed(), "KO page description displayed");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(quoteNumberInKO)), quoteNumber, "Quote Number in KO page check");

        if(!isAgentAssigned) {
            fsa.assertTrue(needMoreHelp.isDisplayed(), "Need more help displayed");
            fsa.assertTrue(youCanCallCustomerService.isDisplayed(), "'You can call customer service at' message displayed");
        } else {
            fsa.assertTrue(yourAgent.isDisplayed(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(agentsImage.isDisplayed(), "Agent image displayed");
            fsa.assertTrue(agentName.isDisplayed(), "Agent name displayed");
        }

        Log.info("validateFinancialFilingInAnotherState", true);
    }

    public List<String> getAllKnockOutErrorCodes() throws Exception {
        List<String> errorCodes = getSessionStorageAppStore().getKnockouts().stream().map(KnockOut::getErrorCode).collect(Collectors.toList());
        Log.info("Knockout error codes: " + errorCodes);
        return errorCodes;
    }

    public void validateHRCKnockOuts(FarmersSoftAssert fsa) throws Exception {
        List<AppStore.KnockOut> knockOuts = getSessionStorageAppStore().getKnockouts();
        if (knockOuts.isEmpty()) {
            fsa.assertTrue(false, "Knockouts list is not empty in the session appStore.");
        } else {
        	String koTitle = knockOuts.get(0).getKnockoutTitle();
        	String koDescription = knockOuts.get(0).getKnockoutUIDesc().replace(" or click below for other options", EMPTY_STRING);

        	fsa.assertEquals(getTextFromElement(knockoutTitle), koTitle, "KO page - page title check");
        	fsa.assertEquals(getTextFromElement(knockoutDescription), koDescription, "KO page - KO description check");
        	fsa.assertTrue(koQuoteNumberReference.isDisplayed(), "KO quote reference number displayed");
        	fsa.assertEquals(getTextFromElement(koQuoteNumberReference), REFERENCE_QUOTE_NUMBER, REFERENCE_QUOTE_NUMBER + " check");

        	if (isElementVisible(tollFreeNumber, 2)) {
        		fsa.assertTrue(needMoreHelp.isDisplayed(), "Knock-out page - Need more help text displayed.");
        		fsa.assertTrue(youCanCallCustomerService.isDisplayed(), "Knock-out page - You can call customer service text displayed.");
        		fsa.assertEquals(getTextFromElement(tollFreeNumber), CALL_FARMERS, "Knock-out page - TFN check");
        	} else if (isElementVisible(tollFreeNumber2, 2)) {
        		fsa.assertTrue(yourAgent.isDisplayed(), "'Your agent' text is displayed on the KO page.");
        		fsa.assertTrue(agentsImage.isDisplayed(), "Agent image displayed");
        		fsa.assertTrue(agentName.isDisplayed(), "Agent name displayed");
        	} else if (isElementVisible(contactMeButton, 2)) {
        		fsa.assertTrue(yourAgent.isDisplayed(), "'Your agent' text is displayed on the KO page for real agent assigned case");
        		fsa.assertTrue(contactMeButton.isDisplayed(), "Contact me button for the agent displayed");
        		fsa.assertTrue(agentsImage.isDisplayed(), "Agent image displayed");
        		fsa.assertTrue(agentName.isDisplayed(), "Agent name displayed");
        	} else {
        		fsa.fail("Did not find toll-free number or 'Contact me' agent link on Knock-out (non-offering)  page.");
        	}
        }
    }

    public void validateKnockOutOnSelectingQuestionsFromJFMT(FarmersSoftAssert fsa, String quoteNumber){
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutTitle)), EXPECTED_THANK_YOU_FOR_CHOOSING_FARMERS_INSURANCE_TITLE, "Knock Out Page title check");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutDescription)), JUST_FEW_QUESTIONS_LEFT_DESCRIPTION, "Knock out page description check");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(koQuoteNumberReference)), REFERENCE_QUOTE_NUMBER, "Quote number reference description in knockout page check");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(quoteNumberInKO)), quoteNumber, "Quote number in knockout page check");
        if (isElementVisible(contactMeButton, 2)) {
            fsa.assertTrue(yourAgent.isDisplayed(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(contactMeButton.isDisplayed(), "Contact me button for the agent is displayed");
            fsa.assertTrue(agentsImage.isDisplayed(), "Agent image is displayed");
            fsa.assertTrue(agentName.isDisplayed(), "Agent name is displayed");
        }
    }


    public void validateKnockOutForNotOffering(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isOnKnockOutPage(), "Knock-out page - On KO page.");
        fsa.assertEquals(getPageTitle(), YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION, "Knock-out page - Page title.");
        fsa.assertEquals(getPageDescription(), HOME_NOT_OFFERED_DESCRIPTION, "Knock-out page - Page description.");
        if (isElementVisible(tollFreeNumber, 2)) {
            fsa.assertTrue(needMoreHelp.isDisplayed(), "Knock-out page - Need more help text is displayed.");
            fsa.assertTrue(youCanCallCustomerService.isDisplayed(), "Knock-out page - You can call customer service text is displayed.");
            fsa.assertEquals(getTextFromElement(tollFreeNumber), CALL_FARMERS, "Knock-out page - TFN is displayed.");
        } else if (isElementVisible(contactMeButton, 2)) {
            fsa.assertTrue(yourAgent.isDisplayed(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(contactMeButton.isDisplayed(), "Contact me button for the agent is displayed");
            fsa.assertTrue(agentsImage.isDisplayed(), "Agent image is displayed");
            fsa.assertTrue(agentName.isDisplayed(), "Agent name is displayed");
        } else if (isElementVisible(yourAgent, 2)) {
            fsa.assertTrue(yourAgent.isDisplayed(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(agentsImage.isDisplayed(), "Agent image is displayed");
            fsa.assertTrue(agentName.isDisplayed(), "Agent name is displayed");
        } else {
            fsa.fail("Did not find toll-free number or 'Contact me' agent link on Knock-out (non-offering)  page.");
        }
    }

    public void validateNYCommuterForNJCustomer() throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(isOnKnockOutPage(), "Knock-out page - On KO page.");
        fsa.assertEquals(getPageTitle(), EXPECTED_SPECIAL_ATTENTION_TITLE, "Knock-out page - Page title.");
        fsa.assertEquals(getPageDescription(), "Unfortunately we need to collect additional information from you. Please contact us at the number below to continue your quote.", "Knock-out page - Page description.");
        fsa.assertEquals(getTextFromElement(koQuoteNumberReference) + SPACE + getQuoteNumber(), String.format("Please reference your quote number: %s", getSessionStorageAppStore().getData().getQuoteNumber()));
        fsa.assertAll();
    }

    public void verifyUnableToCompleteOnlineKnockout(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        waitElementBeVisible(knockoutTitle);
        final String EXPECTED_MONETIZATION_KNOCKOUT_TITLE = "We are unable to complete your request at this time.";
        fsa.assertEquals(getTextFromElement(knockoutTitle), EXPECTED_MONETIZATION_KNOCKOUT_TITLE, "KO page - Page title is not displayed as expected.");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(koQuoteNumberReference)), REFERENCE_QUOTE_NUMBER, "Quote number reference description in knockout page not displayed");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(quoteNumberInKO)), applicant.getQuoteNumber(), "Quote number in knockout page not displayed/Not Matched");
        validateAssignedAgentSection(this, fsa);
    }

    public void verifyMonetizationKnockout(FarmersSoftAssert fsa) {
        waitElementBeVisible(knockoutTitle);
        final String EXPECTED_MONETIZATION_KNOCKOUT_TITLE = "We are unable to complete your request at this time.";
        final String EXPECTED_MONETIZATION_KNOCKOUT_DESCRIPTION = "We're sorry, but we can't finish your quote online at this time. Your property is ineligible based on previous " +
                "losses. Please contact us to complete your quote (we may still be able to offer you coverage) or click below for other options.";
        fsa.assertEquals(getTextFromElement(knockoutTitle), EXPECTED_MONETIZATION_KNOCKOUT_TITLE, "Monetization KO page title check");
        fsa.assertEquals(getTextFromElement(knockoutDescription), EXPECTED_MONETIZATION_KNOCKOUT_DESCRIPTION, "Monetization KO page description check");

        final String NEED_MORE_HELP = "Need more help?";
        final String YOU_CAN_CALL = "You can call customer service at";
        fsa.assertEquals(getTextFromElement(needMoreHelp), NEED_MORE_HELP, "Monetization KO page - Need more help check");
        fsa.assertEquals(getTextFromElement(youCanCallCustomerService), YOU_CAN_CALL, "Monetization KO page - You can call customer service at check");
        fsa.assertEquals(getTextFromElement(tollFreeNumber), CALL_FARMERS, "Monetization KO page - toll free number check");
        fsa.assertEquals(!startMyQuoteButtonsOnMonetizationKOPage.isEmpty(), true, "Monetization KO page - at least one start my quote button from competitors displayed.");
    }

    public void validateUnacceptableRoofKO(FarmersSoftAssert fsa){
        waitElementBeVisible(knockoutTitle);
        final String EXPECTED_MONETIZATION_KNOCKOUT_TITLE = "We are unable to complete your request at this time.";
        final String EXPECTED_MONETIZATION_KNOCKOUT_DESCRIPTION = "We are unable to complete your quote online at this time. Click below for other options.";
        fsa.assertEquals(getTextFromElement(knockoutTitle), EXPECTED_MONETIZATION_KNOCKOUT_TITLE, "KO page title is not displayed as expected.");
        fsa.assertEquals(getTextFromElement(knockoutDescription), EXPECTED_MONETIZATION_KNOCKOUT_DESCRIPTION, "KO page description is not displayed as expected.");

        final String NEED_MORE_HELP = "Need more help?";
        final String YOU_CAN_CALL = "You can call customer service at";
        fsa.assertEquals(getTextFromElement(needMoreHelp), NEED_MORE_HELP, "KO page - Need more help is not displayed as expected.");
        fsa.assertEquals(getTextFromElement(youCanCallCustomerService), YOU_CAN_CALL, "KO page - You can call customer service at is not displayed as expected.");
//        fsa.assertEquals(getTextFromElement(tollFreeNumber), QUOTE_KNOCKOUT_DESKTOP_TOLL_NUMBER, "KO page - toll free number is not displayed as expected.");
    }

    public void validateKnockOutOnSelectingFoundationTypeDeepPilings(FarmersSoftAssert fsa) throws Exception {
        List<KnockOut> knockouts = getSessionStorageAppStore().getKnockouts();
        boolean hasExpectedKnockoutCode = knockouts != null
                && knockouts.stream().anyMatch(k -> "DWCONS009".equals(k.getKnockoutCode()));
        fsa.assertTrue(hasExpectedKnockoutCode, "Knock out code DWCONS009 not present for foundation type - deep pilings");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutTitle)), KO_FOUNDATION_TYPE, "Not Landed on Knock Out Page");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutDescription)), KO_FOUNDATION_TYPE_DESCRIPTION, "Knock out page description not matched");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(koQuoteNumberReference)), REFERENCE_QUOTE_NUMBER, "Quote number reference description in knockout page not displayed");
        if (isElementVisible(contactMeButton, 2)) {
            fsa.assertTrue(yourAgent.isDisplayed(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(contactMeButton.isDisplayed(), "Contact me button for the agent is displayed");
            fsa.assertTrue(agentsImage.isDisplayed(), "Agent image is displayed");
            fsa.assertTrue(agentName.isDisplayed(), "Agent name is displayed");
        }
    }

    public String getPageTitle() {
        return getTextFromElement(waitElementBeVisible(knockoutTitle));
    }

    public String getInconvenienceHeaderTitle() {
        return getTextFromElement(inconvenienceHeaderTitle);
    }

    public String getPageDescription() {
        return getTextFromElement(waitElementBeVisible(knockoutDescription));
    }

    private String getQuoteNumber() {
        return getTextFromElement(quoteNumberInKO);
    }

    public boolean isInconvenienceTitlePresent() throws Exception {
        return isElementPresent(By.xpath(INCONVENIENCE_PAGE_TITLE_XPATH));
    }

    public void validateIidBehavior_SC_KO(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isOnKnockOutPage(), "User is on the KO page");
        waitElementBeVisible(knockoutTitle);
        fsa.assertEquals(getTextFromElement(knockoutTitle), WE_NOT_ABLE_TO_COMPLETE_YOUR_QUOTE, "SC KO page title validation");
        fsa.assertEquals(getTextFromElement(knockoutDescription), WE_APOLOGIZE_FOR_INCONVENIENCE, "SC KO page description validation");
        fsa.assertFalse(monetizationButtons.isEmpty(), "Monetization buttons are not provided");
    }

    public void verifyBundleKnockoutPageContent(String scenario, FarmersSoftAssert fsa) {
    	String knockoutTitleText = "Thank you for choosing Farmers Insurance\u00ae";
    	String scenarioText = "Our team is happy to help if you have any questions or want to explore other options.";
    	String contactText = "You can speak with a representative at";
    	if (scenario.equals(QUOTE_KNOCKOUT)) {
    		knockoutTitleText = "Your quote requires special attention";
    		scenarioText = HOME_NOT_OFFERED_DESCRIPTION;
    		contactText = "You can call customer service at";
    	} else if (scenario.equals(PROPERTY_KNOCKOUT)) {
    		knockoutTitleText = "We are unable to complete your request at this time.";
    		scenarioText = "Your property is ineligible based on previous losses. Please contact us to complete your quote";
    		contactText = "You can call customer service at";
    	}
    	fsa.assertEquals(getTextFromElement(knockoutTitle), knockoutTitleText, "Bundle knockout page title verification");
		fsa.assertTrue(isExpectedTextContainedInElement(knockoutDescription, scenarioText), "Bundle knockout page description verification");
		if (isElementDisplayed(yourAgent, 1)) {
            fsa.assertTrue(yourAgent.isDisplayed(), "'Your agent' text displayed");
            fsa.assertTrue(agentsImage.isDisplayed(), "Agent image displayed");
            fsa.assertTrue(agentName.isDisplayed(), "Agent name displayed");

		} else {
			fsa.assertTrue(isElementDisplayed(needMoreHelp, 3), "Need more help label verification");
			fsa.assertEquals(getTextFromElement(youCanLabelElement), contactText, "Whom to contact label verification");
			fsa.assertEquals(getTextFromElement(tollFreeNumber), CALL_FARMERS, "Toll free number verification.");
		}
    }

    public void validateFGIA_KO_Page(FarmersSoftAssert fsa) throws Exception {
        isOnKnockOutPage();
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutTitle)), "It's not you. It's us.", "KO page header validation");
        fsa.assertEquals(getTextFromElement(fgiaSubtitle), "You're still on your way to new coverage.", "KO page sub-header validation");
        fsa.assertEquals(getTextFromElement(fgiaCantOfferText), "We think you're great. We just can't offer you a Farmers® quote right now.", "KO page sub-header validation");
        List<String> actualContent = fgiaPageContents.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> expectedContent = Arrays.asList(
                "Why? It could be your location. It could be risk related. It could be something out of our hands. The good news is that we can still help you find coverage today.",
                "Let us introduce you to another member of the Farmers family: Farmers General Insurance Agency. Call them today and get multiple quotes and prices from other insurance brands."
        );
        fsa.assertEquals(actualContent, expectedContent, "KO page content validation");
        fsa.assertEquals(getTextFromElement(fgiaSoundGoodText), "Sound good?", "Sound good text validation");
        fsa.assertEquals(getTextFromElement(fgiaTabBelowToContinueText), "Tap below now to continue.", "Tap below to continue text validation");
        fsa.assertEquals(getTextFromElement(fgiaReferenceYourQuoteText), "Please reference your quote number:", "Quote reference text validation");
        fsa.assertEquals(getTextFromElement(quoteNumberInKO_FGIA), getSessionStorageAppStore().getData().getQuoteNumber(), "Quote number validation");
        fsa.assertEquals(getTextFromElement(continueToFGIAButton), "Continue", "Continue button text validation");
        waitAndClickElement(continueToFGIAButton);
        waitAndClickElement(agreeAndContinueButtonFGIA);
        waitForSpinnerToBeGone();
        sleep(5);
        String title = driver().getTitle();
        fsa.assertTrue(title.contains("Farmers Insurance Choice | Select insurance type") || title.contains("Farmers General Insurance Agency, Inc. | Select insurance type"));
    }

    public void validateQuoteNotAvailableKO() throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(isOnKnockOutPage(), "User should be on the KO page");
        fsa.assertEquals(getTextFromElement(knockoutTitle), YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION, "Knockout page title check");
        fsa.assertEquals(getTextFromElement(knockoutDescription), "Online quotes are not available at this time. Please contact your agent for a quote.", "Knockout page description check");
        fsa.assertAll();
    }

    public void digitalMonetizationKOAgentValidation(FarmersSoftAssert fsa, String agentId) throws Exception {
        fsa.assertTrue(isOnDigitalMonetizationKOPage(), "Knock-out page - On KO page.");
        fsa.assertEquals(getTextFromElement(koTitleText), YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION, "Knock-out page - Page title.");
        fsa.assertEquals(getTextFromElement(koDescriptionText), "Online quotes are not available at this time. Please contact your agent for a quote.", "Knockout page description check");
        boolean isAWSFlow = !agentId.isEmpty();
        if (isAWSFlow) {
            fsa.assertTrue(isElementDisplayed(agentImage, 5), "Agent image is displayed");
            fsa.assertTrue(isElementDisplayed(agentNameKOPage, 5), "Agent name is displayed");
            fsa.assertTrue(isElementDisplayed(agentDetailsText, 5), "Agent details text is displayed");
            fsa.assertTrue(isElementDisplayed(agentEmail, 5), "Agent email is displayed");
            if (isUseMobileViewEnabled()) {
                fsa.assertTrue(isElementDisplayed(agentPhoneMobile, 5), "Agent phone number is displayed on mobile view");
            } else {
                fsa.assertTrue(isElementDisplayed(agentPhoneDesktop, 5), "Agent phone number is displayed on desktop view");
            }
            fsa.assertTrue(isElementDisplayed(scheduleAppointment, 5), "Schedule appointment text is displayed");
        } else {
            fsa.assertTrue(isElementDisplayed(needMoreHelpDigitalMonetization, 5), "Knock-out page - Need more help text is displayed.");
            fsa.assertTrue(callCustomerServiceDigitalMonetization.isDisplayed(), "Knock-out page - You can call customer service text is displayed.");
            fsa.assertEquals(getTextFromElement(tollFreeDigitalMonetization), CALL_FARMERS, "Knock-out page - TFN is displayed.");
        }
    }

    public void policyExclusionKOValidation(FarmersSoftAssert fsa) throws Exception {
        String actualKnockoutTitle = getTextFromElement(knockoutTitle);
        fsa.assertTrue(actualKnockoutTitle.equals(YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION) ||
                actualKnockoutTitle.equals(YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION + PERIOD), "Knock-out page - Page title.");
        fsa.assertEquals(getTextFromElement(knockoutDescription), UNABLE_TO_QUOTE_AT_THIS_TIME, "Knockout page description check");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(koQuoteNumberReference)), REFERENCE_QUOTE_NUMBER, "Quote number reference description in knockout page validation");
        String sessionStorageQuoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
        fsa.assertEquals(getQuoteNumber(), sessionStorageQuoteNumber, "Quote Number check");
        if (isElementVisible(tollFreeNumber, 2)) {
            fsa.assertTrue(needMoreHelp.isDisplayed(), "Knock-out page - Need more help text is displayed.");
            fsa.assertTrue(youCanCallCustomerService.isDisplayed(), "Knock-out page - You can call customer service text is displayed.");
            fsa.assertEquals(getTextFromElement(tollFreeNumber), CALL_FARMERS, "Knock-out page - TFN is displayed.");
        } else if (isElementVisible(contactMeButton, 2)) {
            fsa.assertTrue(yourAgent.isDisplayed(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(contactMeButton.isDisplayed(), "Contact me button for the agent is displayed");
            fsa.assertTrue(agentsImage.isDisplayed(), "Agent image is displayed");
            fsa.assertTrue(agentName.isDisplayed(), "Agent name is displayed");
        } else if (isElementVisible(yourAgent, 2)) {
            fsa.assertTrue(yourAgent.isDisplayed(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(agentsImage.isDisplayed(), "Agent image is displayed");
            fsa.assertTrue(agentName.isDisplayed(), "Agent name is displayed");
        } else {
            fsa.fail("Did not find toll-free number or 'Contact me' agent link on Knock-out (non-offering)  page.");
        }
    }

    public void validateMapIsNotPresentInAutoKO(FarmersSoftAssert softAssert) throws Exception {
        isOnKnockOutPage();
        softAssert.assertTrue(agentList.isEmpty(), "Agent list should be empty for auto KO page");
    }

}