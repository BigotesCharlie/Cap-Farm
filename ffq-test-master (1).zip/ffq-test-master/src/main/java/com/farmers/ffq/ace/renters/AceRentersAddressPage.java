package com.farmers.ffq.ace.renters;

import com.farmers.ffq.ace.hrc.common.AceHRCAddressBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.invisibilityOfElementLocated;

public class AceRentersAddressPage extends AceHRCAddressBasePage {

    private static final String ADDRESS_INPUT_FIELD_XPATH = "//app-personal-info//input[@id='auto-manual-street__input-section']";
    @FindBy(xpath = ADDRESS_INPUT_FIELD_XPATH)
    protected WebElement formFieldAddressInput;
    @FindBy(xpath = "//app-personal-info//div[@id='formField_apartment']//input")
    protected WebElement unitNumberInput;
    @FindBy(xpath = "//app-personal-info//div[@id='formField_apartment']//mat-label")
    protected WebElement unitNumberInputLabel;
    @FindBy(xpath = "//app-personal-info//div[@id='formField_apartment']//mat-hint")
    protected WebElement optionalHintText;
    public AceRentersAddressPage() throws Exception {
        super();
    }

    public boolean isOnAddressPageRenters(boolean longWait) {
        int timeout = longWait ? Property.PAGELOADTIMEOUT : 5;
        return isElementDisplayed(formFieldAddressInput, timeout);
    }

    public void validateRentersPageFormFields(FarmersSoftAssert fsa, ApplicantAceHome applicant) {
        final String ADDRESS_FIELD_TEXT = "Home Address (No Post Office Boxes)";
        fsa.assertEquals(getAttributeData(formFieldAddressInput, ARIA_LABEL), ADDRESS_FIELD_TEXT, "Address page - Address placeholder text.");
        fsa.assertEquals(getTextFromElement(formFieldAddressInput), EMPTY_STRING, "Address page - Address field is blank.");

        fsa.assertEquals(unitNumberInput.isDisplayed(), true, "Unit number input field");
        fsa.assertEquals(getTextFromElement(unitNumberInputLabel), "Unit #", "Address page - unit field place holder text.");

        fsa.assertEquals(optionalHintText.isDisplayed(), true, "Optional hint validation");
        fsa.assertEquals(getTextFromElement(optionalHintText), "Optional", "Optional hint validation");
    }

    public void validateAddressPageErrorsRenters(FarmersSoftAssert sa, ApplicantAceHome applicant) throws Exception {
        final String ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR = "Please enter street number and name.";
        final String PAGE_ALERT = "One or more required fields are incomplete or incorrect. Please review.";
        clickContinueButton();
        waitForSpinnerToBeGone();
        sa.assertTrue(getPageErrors().contains(ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR), ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR + ERROR_FOUND);
        sa.assertTrue(getPageAlerts().contains(PAGE_ALERT), "Expected page alert(s) found.");
        waitAndClickElement(formFieldAddressInput);
        sendKeysToElement(formFieldAddressInput, SPECIALCHARS);
        clickContinueButton();
        sa.assertTrue(getPageErrors().contains(ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR), ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR + ERROR_FOUND);
        sa.assertTrue(getPageAlerts().contains(PAGE_ALERT), "Expected page alert(s) found.");
        driver().navigate().refresh();
        enterGoogleAddress(formFieldAddressInput, applicant.getAddress(), applicant.getCity());
        wait.until(invisibilityOfElementLocated(By.xpath("//mat-error")));
        sa.assertTrue(getPageErrors().isEmpty(), "Page error(s) should not be found.");
        sa.assertTrue(getPageAlerts().isEmpty(), "Page alert(s) should not be found.");
    }

}
