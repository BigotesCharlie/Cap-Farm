package com.farmers.ffq.hqm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import java.util.List;
import java.util.stream.Collectors;

public class FarmersInsuranceAgencyPage extends HqmBasePage {

    @FindBy(xpath = "//header//div[contains(@class,'call-in')]")
    private WebElement speakWithAgent;

    @FindBy(xpath = "//header//div[contains(@class,'logo')]/a[contains(@class,'partner-logo')]")
    private WebElement farmersLogo;

    private static final String CITY_STATE_ZIP_XPATH = "//section//input[@name='address_city']/../p[@class='address']";
    @FindBy(xpath = CITY_STATE_ZIP_XPATH)
    private WebElement cityStateZip;

    private static final String MULTI_CITY_STATE_ZIP_XPATH = "//section//p[@class='multi-city-address']";
    @FindBy(xpath = MULTI_CITY_STATE_ZIP_XPATH)
    private WebElement multiCityStateZip;

    private static final String CITY_SELECT_XPATH = "//section//select[@id='address_city']";
    @FindBy(xpath = CITY_SELECT_XPATH)
    private WebElement citySelect;


    /**
     * Constructor.
     *
     * @throws Exception
     */
    public FarmersInsuranceAgencyPage() throws Exception {
        super();
        wait.until(ExpectedConditions.urlContains("farmersgeneralinsuranceagency.com/quote?zipcode="));
    }

    public String getCityStateZip() throws Exception {
        String stateZip = "";
        if (isElementDisplayed(By.xpath(CITY_STATE_ZIP_XPATH))) {
            stateZip = getTextFromElement(cityStateZip).stripLeading().stripTrailing();
        } else if (isElementDisplayed(By.xpath(CITY_SELECT_XPATH))) {
            stateZip = getTextFromElement(multiCityStateZip).stripLeading().stripTrailing();
        }
        return stateZip;
    }

    public boolean isCitySelectDisplayed() throws Exception {
        return isElementDisplayed(By.xpath(CITY_SELECT_XPATH));
    }

    public List<String> getCitySelectOptions () {
        Select selCity = new Select(citySelect);
        return selCity.getOptions().stream().map(this::getTextFromElement)
                .map(String::toUpperCase).collect(Collectors.toList());
    }

}
