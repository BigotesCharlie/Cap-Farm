package com.farmers.ffq.ace.home;

import static com.farmers.ffq.utils.GlobalVariables.ARIA_LABEL;
import static com.farmers.ffq.utils.GlobalVariables.AWS_SCENARIOS;
import static com.farmers.ffq.utils.GlobalVariables.AZ;
import static com.farmers.ffq.utils.GlobalVariables.CLASS;
import static com.farmers.ffq.utils.GlobalVariables.EMPTY_STRING;
import static com.farmers.ffq.utils.GlobalVariables.FIRST_AVAILABLE_OPTION;
import static com.farmers.ffq.utils.GlobalVariables.FOREMOST;
import static com.farmers.ffq.utils.GlobalVariables.OTHER;
import static com.farmers.ffq.utils.GlobalVariables.PARTTIME;
import static com.farmers.ffq.utils.GlobalVariables.RENT;
import static com.farmers.ffq.utils.GlobalVariables.RETRIEVED;
import static com.farmers.ffq.utils.GlobalVariables.SECONDARY;
import static com.farmers.ffq.utils.GlobalVariables.SPACE;
import static com.farmers.ffq.utils.GlobalVariables.TX;
import static com.farmers.ffq.utils.GlobalVariables.UNOCCUPIED;
import static java.util.Map.entry;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.common.enums.CoveragesNameVsDescriptionInfoSideSheetAceHome.CoverageInfoDetails;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Home;
import com.farmers.ffq.datatransferobjects.AppStore.Home.Coverage;
import com.farmers.ffq.datatransferobjects.AppStore.Home.Discounts;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class AceSpecialtyDwellingQuoteReviewPage extends AceHRCBasePage {

	private static final String WIND_AND_HAIL = "Wind and Hail";
	private static final String PERSONAL_EFFECTS = "Personal effects";
	private static final String MEDICAL_PAYMENTS_TO_OTHERS = "Medical payments to others";
	private static final String PERSONAL_LOWERCASEPROPERTY = "Personal property";
	private static final String PREMISES_LOWERCASELIABILITY = "Premises liability";
	private static final String REPLACEMENT_COST = "Replacement cost";
	private static final String MEDICAL_PAYMENTS = "Medical payments";
	private static final String PERSONAL_LIABILITY = "Personal Liability";
	private static final String PERSONAL_LOWERCASELIABILITY = "Personal liability";
	private static final String ADDITIONAL_LIVING_EXPENSES = "Additional living expenses";
	private static final String PREMISES_LIABILITY = "Premises Liability";
	private static final String EXTENDED_REPLACEMENT_COST = "Extended replacement cost";
	private static final String PERSONAL_PROPERTY = PERSONAL_LOWERCASEPROPERTY;
	private static final String DWELLING = "Dwelling";
	private static final String PERSONAL_PROPERTY_ACV = "Personal property (Actual cash value)";
	private static final String PERSONAL_EFFECTS_ACV = "Personal effects (Actual cash value)";

	@FindBy(xpath = "//app-mobilehome-review-page//h1")
	private WebElement quoteReviewPageTitle;

	@FindBy (xpath = "//mat-card//div[contains(@class, 'call-agent-icon')]/img")
	private WebElement quoteReviewPageAgentIcon;
	@FindBy (xpath = "//mat-card/div[contains(@class, 'call-agent-content')]")
	private WebElement quoteReviewPageSubtitle;

	private static final String POLICY_DEDUCTIBLES_XPATH = "//app-mobilehome-coverage//h2[contains(@class, 'bold')]";
	@FindBy (xpath = POLICY_DEDUCTIBLES_XPATH)
	private WebElement policyDeductiblesSectionHeader;
	@FindBy (xpath = POLICY_DEDUCTIBLES_XPATH + "/following-sibling::p")
	private WebElement policyDeductiblesSectionDescription;
	@FindBy (xpath = "//div[contains (@class, 'deductible-item')]//div/span[not(contains(@class, 'bold'))]")
	private List<WebElement> listOfPolicyDeductibles;
	@FindBy (xpath = "//div[contains (@class, 'deductible-item')]//div/span[contains(@class, 'bold')]")
	private List<WebElement> listOfPolicyDeductibleAmounts;

	private static final String COVERAGES_XPATH = "//div[contains(@class, 'mobilehome-card-body')]";
	private static final String PRIMARY_COVERAGES_CARD_XPATH = COVERAGES_XPATH + "[1]";
	private static final String PRIMARY_COVERAGE_CONTENT_XPATH = PRIMARY_COVERAGES_CARD_XPATH + "//div[contains(@class, 'py-3')]";

	@FindBy (xpath = "//div[contains(@class, 'card-header mobilehome-header')]")
	private WebElement ratedAmountInCard;
	@FindBy (xpath = PRIMARY_COVERAGES_CARD_XPATH + "//div[contains(@class, 'py-2')]")
	private WebElement primaryCoveragesSectionHeader;
	@FindBy (xpath = PRIMARY_COVERAGE_CONTENT_XPATH + "//div[contains(@class, 'coverage-desktop')]")
	private List<WebElement> desktopListOfPrimaryCoverageLabels;
	@FindBy (xpath = PRIMARY_COVERAGE_CONTENT_XPATH + "//div[contains(@class, 'coverage-mobile')]")
	private List<WebElement> mobilelistOfPrimaryCoverageLabels;
	@FindBy (xpath = PRIMARY_COVERAGE_CONTENT_XPATH + "//span[contains(@class, 'bold')]")
	private List<WebElement> listOfPrimaryCoverageAmounts;
	@FindBy (xpath = "//button[contains(@class, 'mobilehome-info-icon-button')]")
	private List<WebElement> listOfCoverageHelpLinks;

	private static final String ADDITIONAL_COVERAGES_CARD_XPATH = COVERAGES_XPATH + "[2]";
	@FindBy (xpath = ADDITIONAL_COVERAGES_CARD_XPATH + "//div[contains(@class, 'tui-body')]")
	private List<WebElement> listOfAdditionalCoverageLabels;
	@FindBy (xpath = ADDITIONAL_COVERAGES_CARD_XPATH + "//div[contains(@class, 'py-3')]//span[contains(@class, 'bold')]")
	private List<WebElement> listOfAdditionalCoverageAmounts;

	@FindBy(xpath = "//div[@class='heading-area']//*[contains(@class, 'tui-subtitle-text')]")
	private WebElement infoSideSheetTitle;
	@FindBy(className = "intro-section")
	private WebElement infoSideSheetSubtitle;
	@FindBy(xpath = "//app-mobilehome-coverage-descriptions-dialog//button[@aria-label='Close']")
	private WebElement closeInfoSideSheetButton;
	@FindBy(xpath = "//mat-panel-title//div")
	private List<WebElement> listOfCoverageTitlesInSideSheet;
	@FindBy(xpath = "//mat-expansion-panel[contains(@class, 'mat-expanded')]//mat-panel-title")
	private List<WebElement> listOfCoverageTitlesWithExpandedHelpSections;
	@FindBy (xpath = "//mat-expansion-panel[contains(@class, 'mat-expanded')]//div[contains(@class,'mat-expansion-panel-body')]")
	private List<WebElement> listOfCoverageDescriptionsWithExpandedHelpSections;

	@FindBy (xpath = "//div[contains(@class, 'mobilehome-policy-banner')]//h2")
	private WebElement includedInPolicyHeader;
	@FindBy (xpath = "//div[contains(@class,'mobilehome-policy-banner_list-card')]//*[self::mat-icon or self::i]")
	private List<WebElement> listOfCoverageIcons;
	@FindBy (className = "mobilehome-policy-banner_description")
	private List<WebElement> listOfCoverageDescriptions;

	private static final String DISCLAIMER_CARD_XPATH = "//div[contains(@class, 'disclaimer')]//mat-card";
	@FindBy (xpath = DISCLAIMER_CARD_XPATH + "//h2")
	private WebElement disclaimerCardHeader;
	@FindBy (xpath = DISCLAIMER_CARD_XPATH + "//p")
	private List<WebElement> listOfDisclaimerCardContent;

	private static final String DESKTOP_QUOTE_SUMMARY_CARD_XPATH = "//app-mobilehome-review-page//mat-card[contains(@class,'tui-quote-presentment-desktop')]";
	private static final String MOBILE_QUOTE_SUMMARY_CARD_XPATH = "//app-mobilehome-review-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]";
	private static final String TERM_LABEL_XPATH = "//div[contains(@class, 'price-description')]";
	private static final String CARD_QUOTE_AMOUNT_XPATH = "//tui-price";

	@FindBy (xpath = "//*[contains(@class,'discounts-included')]")
	private WebElement discountIncludedLabel;
	@FindBy (xpath = "//mat-list//mat-icon")
	private WebElement discountIncludedCheckmarkIcon;
	@FindBy (xpath = "//app-home-discount//p[contains(@class, 'subtitle')]")
	private WebElement discountsAppliedLabel;
	@FindBy (xpath = "//app-home-discount//p[contains(@class, 'link')]")
	private WebElement reviewDiscountsLink;
	@FindBy(xpath = "//app-home-discount-sidesheet//button[@aria-label='Close']")
	private WebElement closeDiscountsAppliedSidesheetButton;

	boolean isForemostQuote;
	boolean isApplicantLandlord;
	boolean isDwellingVacant;
	boolean isSecondaryOrSeasonalResidence;
	boolean retrievedQuote = false;

	public AceSpecialtyDwellingQuoteReviewPage(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		super();
		boolean notMyPrimaryResidence = !specialtyDwellingApplicant.isPrimaryResidence();
		String reasonWhy = specialtyDwellingApplicant.getReasonWhyNotPrimaryResidence();
		isForemostQuote = specialtyDwellingApplicant.getTestCategory().equals(FOREMOST);
		isApplicantLandlord = notMyPrimaryResidence && reasonWhy.contains(RENT);
		isDwellingVacant = notMyPrimaryResidence && List.of(UNOCCUPIED, OTHER).contains(reasonWhy);
		isSecondaryOrSeasonalResidence = notMyPrimaryResidence && List.of(PARTTIME, SECONDARY).contains(reasonWhy);
	}

	public boolean isOnSpecialtyDwellingQuotePage() {
		return isElementVisible(quoteReviewPageSubtitle, 5);
	}

	public void setRetrievedQuoteFlag() {
		retrievedQuote = true;
	}

	public void verifyPageContent(ApplicantAceHome specialtyDwellingApplicant, FarmersSoftAssert fsa) throws Exception {
		String testCategory = specialtyDwellingApplicant.getTestCategory();
		String activeStep = getActiveStep(testCategory);
		String separator = isSafariBrowser()? EMPTY_STRING : SPACE;
        String phoneNumber = isForemostQuote? "855-497-0352": "888-902-1896";
		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.enable(SerializationFeature.INDENT_OUTPUT);
			String json = mapper.writeValueAsString(getSessionStorageAppStore());
			writeDataToQuoteLogFile("App store content: " + json);
		} catch (Exception e) {
			Log.warn("EXCEPTION while beautifying appstore");
			writeDataToQuoteLogFile("Exception - App store content: " + getSessionStorageAppStore());
		}
		if (!isForemostQuote) {
			verifySpecialtyDwellingCommonHeader(fsa);
		}
		fsa.assertEquals(getTextFromElement(quoteReviewPageTitle), "Initial estimate", "Quote Page title verification.");
		fsa.assertTrue(isElementDisplayed(quoteReviewPageAgentIcon, 2), "Customer service icon is present");
		fsa.assertEquals(getTextFromElement(quoteReviewPageSubtitle), "Thank you!" + separator + "We've put together a quote based on our most popular coverages. " +
				"Give us a call to discuss more coverage options, to see more ways to save, and to buy your policy! " +
				"Call " + phoneNumber + " to get started.", "Quote page subtitle verification.");
		fsa.assertEquals(getTextFromElement(policyDeductiblesSectionHeader), "Policy deductibles", "Policy deductibles section header verification.");
		fsa.assertEquals(getTextFromElement(policyDeductiblesSectionDescription), "Your out-of-pocket cost for a covered loss.", "Policy deductibles section description verification.");
		List<String> listOfObservedPolicyDeductibles = listOfPolicyDeductibles.stream().map(this::getTextFromElement).collect(Collectors.toList());
		List<String> listOfObservedPolicyDeductibleAmounts = listOfPolicyDeductibleAmounts.stream().map(this::getTextFromElement).collect(Collectors.toList());
		List<String> listOfAppstorePolicyDeductibles = getListOfPolicyDeductiblesFromAppstore();
		List<String> listOfExpectedPolicyDeductibles = getExpectedPolicyDeductiblesList(specialtyDwellingApplicant);
		List<String> listOfExpectedPolicyDeductibleAmounts = new ArrayList<>();
		listOfAppstorePolicyDeductibles.forEach(deductible -> {
			try {
				listOfExpectedPolicyDeductibleAmounts.add(getAmountForStringDeductibleFromAppstore(deductible) + " deductible");
			} catch (Exception e) {
				Log.warn("Unable to get expected policy amounts from appstore");
			}
		});
		fsa.assertEquals(listOfObservedPolicyDeductibles, listOfAppstorePolicyDeductibles, "Policy deductibles on screen match appstore");
		// Wind and Hail may be constrained to specific zip codes, so just flag if not found
		boolean foundExpected = listOfExpectedPolicyDeductibles.contains(WIND_AND_HAIL);
		boolean foundObserved = listOfObservedPolicyDeductibles.contains(WIND_AND_HAIL);
		if ((!foundExpected && foundObserved) || (foundExpected && !foundObserved)) {
			Log.warn(String.format("Wind and Hail deductible %s, removing it for deductible verification", (foundExpected? "expected but not observed" : "observed but not expected")));
			listOfExpectedPolicyDeductibles.remove(WIND_AND_HAIL);
			listOfObservedPolicyDeductibles.remove(WIND_AND_HAIL);
		}
		fsa.assertEquals(listOfObservedPolicyDeductibles, listOfExpectedPolicyDeductibles, "Policy deductibles on screen match expected list");
		fsa.assertEquals(listOfObservedPolicyDeductibleAmounts, listOfExpectedPolicyDeductibleAmounts, "Policy deductible amounts verification");
		fsa.assertEquals(getTextFromElement(ratedAmountInCard), CurrencyFormat.convertStringIntoCurrencyFormat(getCoverageObject().getTotalPremium()), "Rated amount verification");
		fsa.assertEquals(getTextFromElement(primaryCoveragesSectionHeader), "Primary coverages", "Coverages table section headers verification");
		List<WebElement> listOfDisplayedCoverageLabelElements = isUseMobileViewEnabled()? mobilelistOfPrimaryCoverageLabels: desktopListOfPrimaryCoverageLabels;
		List<String> listOfObservedCoverageLabels = listOfDisplayedCoverageLabelElements.stream().map(this::getTextFromElement).collect(Collectors.toList());
		listOfObservedCoverageLabels.addAll(listOfAdditionalCoverageLabels.stream().map(this::getTextFromElement).collect(Collectors.toList()));
		List<String> listOfAppstoreCoverageLabels = getListOfCoveragesFromAppstore();
		fsa.assertEquals(getSortedList(listOfObservedCoverageLabels), getSortedList(getExpectedCoveragesList(specialtyDwellingApplicant)), "Coverages labels on screen match expected list");
		fsa.assertEquals(listOfObservedCoverageLabels, listOfAppstoreCoverageLabels, "Coverages labels on screen match appstore");
		List<String> listOfObservedCoverageAmounts = listOfPrimaryCoverageAmounts.stream().map(this::getTextFromElement).collect(Collectors.toList());
		listOfObservedCoverageAmounts.addAll(listOfAdditionalCoverageAmounts.stream().map(this::getTextFromElement).collect(Collectors.toList()));
		List<String> listOfExpectedCoverageAmounts = getListOfCoverageAmountsFromAppstore(listOfAppstoreCoverageLabels);
		listOfExpectedCoverageAmounts.replaceAll(amount -> amount==null || amount.isBlank() || !amount.matches(".*\\d.*")? amount : CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(amount));
		fsa.assertEquals(listOfObservedCoverageAmounts, listOfExpectedCoverageAmounts, "Coverages amounts on screen match appstore");
		validateCoverageHelpLinks(specialtyDwellingApplicant, fsa);
		fsa.assertEquals(getTextFromElement(includedInPolicyHeader), "You get all this in your dwelling policy with Foremost", "Policy inclusion card header verification");
		List<String> listOfExpectedYouGetAllThisIcons = List.of("verified_user", "dollar", "security", "lock");
		List<String> listOfObservedYouGetAllThisIcons = new ArrayList<>();
		listOfCoverageIcons.forEach(iconElement -> {
			String iconClass = getAttributeData(iconElement, CLASS);
			if (iconClass.contains("mobilehome-policy")) {
				iconClass = getTextFromElement(iconElement);
			}
			listOfObservedYouGetAllThisIcons.add(iconClass);
		});
		for (int index = 0; index < listOfExpectedYouGetAllThisIcons.size() && index < listOfObservedYouGetAllThisIcons.size(); index++) {
			fsa.assertTrue(listOfObservedYouGetAllThisIcons.get(index).contains(listOfExpectedYouGetAllThisIcons.get(index)), "Verifying the " + listOfExpectedYouGetAllThisIcons.get(index) + " icon is present.");
		}
		List<String> listOfObservedCoverageDescriptions = listOfCoverageDescriptions.stream().map(this::getTextFromElement).collect(Collectors.toList());
		List<String> listOfExpectedCoverageDescriptions = new ArrayList<>(Arrays.asList("Broad eligibility" + separator + "Unlike other carriers, Foremost can often insure older or high-value homes, and owners with prior losses or credit struggles.",
				"Comprehensive coverage" + separator + "Covers most direct, abrupt, and accidental physical losses (unless specifically excluded).",
				"Liability coverage" + separator + "Covers medical bills, lost wages, property damage, pain and suffering to others for accidents in your home for which you're liable.",
				"Protection when vacant" + separator + "Rest assured, even when your property is vacant between your visits, tenant transitions. and remodels."));
		if (isApplicantLandlord) {
			listOfExpectedCoverageDescriptions.add("Tenant screening" + separator + "Get access to discounted tenant screening services and get a discount when you screen your tenants.");
		}
		fsa.assertEquals(listOfObservedCoverageDescriptions, listOfExpectedCoverageDescriptions, "Verifying You get all this coverage descriptions");
		fsa.assertEquals(getTextFromElement(disclaimerCardHeader), "Other options are available", "Other options card header verification");
		List<String> listOfObservedDisclaimerCardDescriptions = listOfDisclaimerCardContent.stream().map(this::getTextFromElement).collect(Collectors.toList());
		String replacementCostHeaderString = "Personal property replacement cost";
		if (specialtyDwellingApplicant.getStateCode().equals(TX)) {
				replacementCostHeaderString = "Personal effects replacement cost";
		}
		List<String> listOfExpectedDisclaimerCardDescriptions = new ArrayList<>(Arrays.asList("Custom packages",
				"We've quoted our most common policy package for you. Get in touch with a representative to get the coverage you want. Call us at "+ phoneNumber,
				"Extended replacement cost",
				"In most states, you could receive up to an additional 25% of the amount insured for the dwelling. (This optional coverage is included in the quote above.)",
				replacementCostHeaderString,
				"We won't deduct for depreciation when determining the amount we may pay to repair or replace your personal property. (The quote above currently pays on the Actual cash value basis, which does deduct for depreciation.)",
				"Agreed loss settlement with actual cash value",
				"Receive the full insured amount (minus applicable deductibles) if your home is destroyed by an insured loss. No hassles. (This is a lower-cost option.)"));
		fsa.assertEquals(listOfObservedDisclaimerCardDescriptions, listOfExpectedDisclaimerCardDescriptions, "Verifying Other options card content");
		discountElementsPresentCheck(fsa, !isDwellingVacant);
		if (isElementDisplayed(discountsAppliedLabel, 3)) {
    		List<Discounts> listOfDiscountsForQuote = getListOfDiscountsFromAppstore();
    		int numberOfDiscounts = listOfDiscountsForQuote.size();
    		String discountNumberExpectedLabel = numberOfDiscounts == 1? "1 discount applied" : numberOfDiscounts + " discounts applied";
    		fsa.assertEquals(getTextFromElement(discountsAppliedLabel), discountNumberExpectedLabel, "Discounts applied verification.");
    		scrollAndClickOnElement(reviewDiscountsLink);
    		waitElementBeVisible(closeDiscountsAppliedSidesheetButton, 4);
    		List<String> listOfObservedDiscounts = driver().findElements(By.xpath(DISCOUNT_NAMES_XPATH)).stream().map(this::getTextFromElement).sorted().collect(Collectors.toList());
    		List<String> listOfExpectedDiscounts = listOfDiscountsForQuote.stream().map(AppStore.Home.Discounts::getName).collect(Collectors.toList());
    		listOfExpectedDiscounts.replaceAll(discount -> discount.contains("&")? "Multi-policy" : discount);
    		fsa.assertEquals(listOfObservedDiscounts, getSortedList(listOfExpectedDiscounts), "Verifying discounts given");
    		clickElement(closeDiscountsAppliedSidesheetButton);
    		waitElementBeInvisible(closeDiscountsAppliedSidesheetButton);
    		fsa.assertTrue(getTextFromElement(discountIncludedCheckmarkIcon).equals("check_circle"), "Green checked circle icon displayed.");
    		discountNumberExpectedLabel = numberOfDiscounts == 1? "1 discount included" : numberOfDiscounts + " discounts included";
    		fsa.assertEquals(getTextFromElement(discountIncludedLabel), discountNumberExpectedLabel, "Summary card discounts included verification.");
		} else if (!isDwellingVacant) {
			fsa.fail("Discounts included information is missing.");
		}
		String summaryCardXpath = isUseMobileViewEnabled()? MOBILE_QUOTE_SUMMARY_CARD_XPATH: DESKTOP_QUOTE_SUMMARY_CARD_XPATH;
		try {
			fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(summaryCardXpath+TERM_LABEL_XPATH))), "12-month term starting at", "Term label verification");
			fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(summaryCardXpath+CARD_QUOTE_AMOUNT_XPATH))), getRateFromAppstore(), "Rated amount in summary card verification");
			fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(summaryCardXpath+"//a[contains(@class, 'mobilehome-quote-start-checkout-button')]"))), "Call to personalize", "Call label in summary card verification");
		} catch (Exception e) {
			Log.warn("Unable to completely verify summary card due to exception: " + e);
		}
		String expectedStepState = activeStep;
		if (retrievedQuote) {
			expectedStepState = expectedStepState + RETRIEVED;
		}
		validatePageLinksText(fsa, expectedStepState);
		validatePageLinksNavigationTitles(fsa);
		if (!isForemostQuote) {
			validateAgentSectionContent(fsa, testCategory.equals(AWS_SCENARIOS), testCategory);
		}
	}

	public void discountElementsPresentCheck(FarmersSoftAssert fsa, boolean elementsExpected) {
		String isIsnotExpected = elementsExpected? " displayed" : " is not displayed";
		fsa.assertEquals(isElementDisplayed(discountsAppliedLabel, 2), elementsExpected, "discountsAppliedLabel" + isIsnotExpected);
		fsa.assertEquals(isElementDisplayed(reviewDiscountsLink, 2), elementsExpected, "reviewDiscountsLink" + isIsnotExpected);
		fsa.assertEquals(isElementDisplayed(discountIncludedCheckmarkIcon, 2), elementsExpected, "discountIncludedCheckmarkIcon" + isIsnotExpected);
		fsa.assertEquals(isElementDisplayed(discountIncludedLabel,2), elementsExpected, "discountIncludedLabel" + isIsnotExpected);
	}

	public List<Discounts> getListOfDiscountsFromAppstore() throws Exception {
		return getSessionStorageAppStore().getHome().getDiscounts().stream().distinct().collect(Collectors.toList());
	}

	private List<String> getListOfCoveragesFromAppstore() throws Exception {
		List<String> listOfCoverages = new ArrayList<>(getCoverageObject().getCvgInfo().stream().map(AppStore.Home.CvgInfo::getCvgDesc).collect(Collectors.toList()));
		return listOfCoverages;
	}

	private List<String> getListOfCoverageAmountsFromAppstore(List<String> listOfCoverages) throws Exception {
		return getCoverageObject().getCvgInfo().stream().filter(i -> listOfCoverages.contains(i.getCvgDesc())).map(AppStore.Home.CvgInfo::getCvgAmt).collect(Collectors.toList());
	}

	private List<String> getListOfPolicyDeductiblesFromAppstore() throws Exception {
		return getCoverageObject().getDedInfo().stream().map(AppStore.Home.DedInfo::getDesc).collect(Collectors.toList());
	}

	private String getAmountForStringDeductibleFromAppstore(String deductible) throws Exception {
		return CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(getCoverageObject().getDedInfo().stream().filter(i -> deductible.equals(i.getDesc())).map(AppStore.Home.DedInfo::getAmt)
				.findFirst().orElse(EMPTY_STRING));
	}

	private Coverage getCoverageObject() throws Exception {
		Home home = getSessionStorageAppStore().getHome();
		AppStore.Home.Quote quote = home.getQuote();
		return home.getCoverageForPackage(quote.getSelectedPackageCode(), quote.getSelectedPaymentMode());
	}

	private String getRateFromAppstore() throws Exception {
		return CurrencyFormat.convertStringIntoCurrencyFormat(getCoverageObject().getTotalPremium());
	}

	private List<String> getExpectedCoveragesList(ApplicantAceHome specialtyDwellingApplicant) {
		boolean isTexas = specialtyDwellingApplicant.getStateCode().equals(TX);
		boolean isArizona = specialtyDwellingApplicant.getStateCode().equals(AZ);
		if (isDwellingVacant && !isTexas) {
			return new ArrayList<>(Arrays.asList(DWELLING, MEDICAL_PAYMENTS, PREMISES_LIABILITY, REPLACEMENT_COST));
		} else if (isApplicantLandlord || isSecondaryOrSeasonalResidence) {
			return new ArrayList<>(Arrays.asList(DWELLING, MEDICAL_PAYMENTS, PERSONAL_LOWERCASELIABILITY,
					isTexas || isArizona? PERSONAL_PROPERTY_ACV : PERSONAL_PROPERTY, REPLACEMENT_COST));
		} else {
			return new ArrayList<>(Arrays.asList(DWELLING, REPLACEMENT_COST));
		}
	}

	private List<String> getExpectedPolicyDeductiblesList(ApplicantAceHome specialtyDwellingApplicant) {
		if (isApplicantLandlord || isSecondaryOrSeasonalResidence) {
			return new ArrayList<>(Arrays.asList(DWELLING, PERSONAL_PROPERTY));
		} else {
			return new ArrayList<>(Arrays.asList(DWELLING));
		}
	}

	private void validateCoverageHelpLinks(ApplicantAceHome specialtyDwellingApplicant,  FarmersSoftAssert fsa) throws Exception {
		if (listOfCoverageHelpLinks.isEmpty()) {
			fsa.fail("No help links found in the Quote summary page");
		} else {
	        String phoneNumber = isForemostQuote? "855-497-0352": "888-902-1896";
			Map<String, String> helpTitleAndContentsMap = getHelpMap();
			int helpLinksOnPage = listOfCoverageHelpLinks.size();
			List<String> expectedCoverageHeadersInInfoSideSheet = getListOfHelpHeaders(specialtyDwellingApplicant);
			fsa.assertEquals(helpLinksOnPage, expectedCoverageHeadersInInfoSideSheet.size(), "Coverage help links found and expected match");
			waitAndClickElement(listOfCoverageHelpLinks.get(0));
			waitElementBeVisible(infoSideSheetTitle);
			fsa.assertEquals(getTextFromElement(infoSideSheetTitle), "Coverage descriptions", "Help sidesheet title verification.");
			fsa.assertEquals(getTextFromElement(infoSideSheetSubtitle), "We can help you customize your coverage, and learn about other coverage options and more ways you could save. " +
					"Call us at " + phoneNumber + " so you can select the insurance you want.", "Help sidesheet subtitle verification.");
			List<String> foundCoverageHeadersInInfoSideSheet = listOfCoverageTitlesInSideSheet.stream().map(this::getTextFromElement).collect(Collectors.toList());
			fsa.assertEquals(getSortedList(foundCoverageHeadersInInfoSideSheet), getSortedList(expectedCoverageHeadersInInfoSideSheet), "Coverage descriptions found in info side sheet match available coverages");
			clickElement(closeInfoSideSheetButton);
			waitElementBeInvisible(closeInfoSideSheetButton);
			for (int i = 0; i < helpLinksOnPage; i++){
				scrollAndClickOnElement(listOfCoverageHelpLinks.get(i));
				String expectedHelpHeaderForItem = getExpectedHelpHeader(listOfCoverageHelpLinks.get(i));
				waitElementBeVisible(infoSideSheetTitle);
				List<String> listOfHelpTitlesWithExpandedSections = getTextFromListOfWebElementsAndDescendents(listOfCoverageTitlesWithExpandedHelpSections);
				if (listOfHelpTitlesWithExpandedSections.isEmpty()) {
					fsa.fail("No expanded help section found for " + expectedHelpHeaderForItem);
				} else {
					fsa.assertEquals(listOfHelpTitlesWithExpandedSections.size(), 1, "Verify only one expanded help section");
					fsa.assertEquals(listOfHelpTitlesWithExpandedSections.get(FIRST_AVAILABLE_OPTION), expectedHelpHeaderForItem, "Expanded section title verification for " + expectedHelpHeaderForItem);
					boolean replaceExpectedHelpContentForItem = expectedHelpHeaderForItem.equals(PERSONAL_PROPERTY) && isSecondaryOrSeasonalResidence && specialtyDwellingApplicant.getStateCode().equals(TX);
					String expectedHelpContentForItem = replaceExpectedHelpContentForItem? CoverageInfoDetails.PERSONAL_EFFECTS_MOBILE_HOME_DESCRIPTION :
						helpTitleAndContentsMap.get(expectedHelpHeaderForItem);
					fsa.assertEquals(getTextFromElement(listOfCoverageDescriptionsWithExpandedHelpSections.get(FIRST_AVAILABLE_OPTION)), expectedHelpContentForItem, "Verify content of expanded help section for " + expectedHelpHeaderForItem);
				}
				clickElement(closeInfoSideSheetButton);
				waitElementBeInvisible(closeInfoSideSheetButton);
			}
		}
	}

	private String getExpectedHelpHeader(WebElement helpLink) {
		return headerTextCorrection(getAttributeData(helpLink, ARIA_LABEL).replace("Information about ", EMPTY_STRING));
	}

	private List<String> getListOfHelpHeaders(ApplicantAceHome specialtyDwellingApplicant) {
		List<String> listOfHelpHeaders = getExpectedCoveragesList(specialtyDwellingApplicant);
		//Corrections to match the headers in the info side sheet
		listOfHelpHeaders.replaceAll(header -> {
			return headerTextCorrection(header);
		});
		return listOfHelpHeaders;
	}

	private String headerTextCorrection(String header) {
		if (header.equals(PERSONAL_LIABILITY)) {
			return PERSONAL_LOWERCASELIABILITY;
		} else if (header.equals(PREMISES_LIABILITY)) {
			return PREMISES_LOWERCASELIABILITY;
		} else if (header.equals(PERSONAL_PROPERTY_ACV)) {
			return PERSONAL_LOWERCASEPROPERTY;
		} else if (header.equals(PERSONAL_EFFECTS_ACV)) {
			return PERSONAL_EFFECTS;
		} else if (header.equals(MEDICAL_PAYMENTS)) {
			return MEDICAL_PAYMENTS_TO_OTHERS;
		}
		return header;
	}

	private Map<String, String> getHelpMap() {
		String liabilityDescription = "This coverage can pay damages an insured becomes legally obligated to pay because of bodily injury or property damage to others.";
		Map<String, String> helpMap = Map.ofEntries(
			    entry(DWELLING, CoverageInfoDetails.DWELLING_COST_DESCRIPTION),
			    entry(PERSONAL_EFFECTS, CoverageInfoDetails.PERSONAL_EFFECTS_MOBILE_HOME_DESCRIPTION),
			    entry(PERSONAL_PROPERTY, CoverageInfoDetails.PERSONAL_PROPERTY_MOBILE_HOME_DESCRIPTION),
			    entry(ADDITIONAL_LIVING_EXPENSES, CoverageInfoDetails.ADDITIONAL_LIVING_EXPENSES_MOBILE_HOME_DESCRIPTION),
			    entry(PREMISES_LOWERCASELIABILITY, liabilityDescription),
			    entry(PERSONAL_LOWERCASELIABILITY, liabilityDescription),
			    entry(EXTENDED_REPLACEMENT_COST, CoverageInfoDetails.EXTENDED_REPLACEMENT_COST),
			    entry(REPLACEMENT_COST, "Coverage for your home and get a settlement that reflects the cost to replace the damaged items with new property of comparable material and quality, without any deduction for depreciation."),
			    entry(MEDICAL_PAYMENTS_TO_OTHERS, "This coverage can pay medical costs, up to the limit selected by you, for guests who are injured at your residence, regardless of your legal liability."));
		return helpMap;
	}

}