package com.farmers.ffq.auto.pages;

import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class DriverMismatchPage extends PolicyPaymentBasePage {

	@FindBy(className = "driver-mismatch-page-header")
	private WebElement driverMismatchPageTitle;

	@FindBy(className = "driver-mismatch-page-subheading")
	private WebElement driverMismatchPageSubtitle;

	@FindBy(xpath = "//div[@class='auto-driver-review-info-header-content']/div")
	private WebElement driverMismatchPageHelpTitle;

	@FindBy(xpath = "//div[@class='auto-driver-review-info-header-content']//p[1]")
	private WebElement driverMismatchPageHelpTextParagraphOne;

	@FindBy(xpath = "//div[@class='auto-driver-review-info-header-content']//p[2]")
	private WebElement driverMismatchPageHelpTextParagraphTwo;

	@FindBy(xpath = "//button[@data-test-id='CONTINUE_BTN']")
	private WebElement continueButton;

	@FindBy(xpath = "//div[@class='driver-mismatch-page-subheading']//a")
	private WebElement returnToDriverSelectionLink;

	private final String REJECT_REASONS_XPATH = "//mat-radio-group[@formcontrolname='rejectReasonFormValue']";
	@FindBy(xpath = REJECT_REASONS_XPATH)
	private List<WebElement> rejectReasons;

	private static final String NAME_OF_NON_LISTED_DRIVERS_XPATH = "//div[contains(@class, 'driver-name')]";
	@FindBy(xpath = NAME_OF_NON_LISTED_DRIVERS_XPATH)
	private List<WebElement> listOfNamesOfDriversNotIncluded;

	@FindBy(xpath = NAME_OF_NON_LISTED_DRIVERS_XPATH + "/../div[contains(text(), 'Age')]")
	private List<WebElement> listOfAgesOfDriversNotIncluded;

	@FindBy (xpath = "//mat-radio-button[contains(.,'know this person')]//input")
	private List<WebElement> listOfUnknownDriverRadioButtons;

	@FindBy (xpath = "//mat-radio-button[contains(.,'know this person') and not(contains(@class,'checked'))]//input")
	private List<WebElement> uncheckedListOfUnknownDriverRadioButtons;

	@FindBy(xpath = "//mat-error")
	private List<WebElement> listOfErrorsInPage;

    @FindBy(xpath = "//mat-radio-group[@formcontrolname='rejectReasonFormValue']//mat-radio-button[contains(.,'Exclude')]")
    private List<WebElement> excludeThisPersonFromMyInsuranceRadioButtons;

	public DriverMismatchPage() throws Exception {
	}

	public HeresWhatWeFoundPage returnToDriverSelectionPage() throws Exception {
		waitAndClickElement(returnToDriverSelectionLink);
		waitForSpinnerToBeGone();
		return new HeresWhatWeFoundPage();
	}

	public boolean validateDriversMismatchPageTitle() {
		return isExpectedTextDisplayed(driverMismatchPageTitle, "Drivers not included");
	}

	public boolean validateDriversMismatchErrorHandling() throws Exception {
		scrollAndClickOnElement(continueButton);
		if (listOfNamesOfDriversNotIncluded.isEmpty()) {
			return true;
		} else {
			//Should have an error for each driver
			int numberOfDriverRelatedErrors = listOfErrorsInPage.size()-1;
			boolean retValue = listOfNamesOfDriversNotIncluded.size() == numberOfDriverRelatedErrors;
			for (int i=0; i < numberOfDriverRelatedErrors-1; i++) {
				retValue &= isExpectedTextDisplayed(listOfErrorsInPage.get(i), "This field is required.");
			}
			retValue &= isExpectedTextDisplayed(listOfErrorsInPage.get(numberOfDriverRelatedErrors), "One or more required fields is incomplete or incorrect. Please review.");
			return retValue;
		}
	}

	public boolean validateDriversMismatchPageDescription() {
		return isExpectedTextDisplayed(driverMismatchPageSubtitle, "We noticed you didn't include some drivers. Everyone who lives in your household needs to be listed on the policy, even if they have their own insurance. Return to the driver selection page to add drivers if this is incorrect.");
	}

	public boolean validateDriversMismatchPageHelp() {
		boolean retValue = isExpectedTextContainedInElement(driverMismatchPageHelpTitle, "Excluded driver(s)");
		retValue &= isExpectedTextContainedInElement(driverMismatchPageHelpTextParagraphOne, "Select \"Not living in my household\" if this person is no longer living in your home and does not have regular access to your vehicle(s). For example: an ex-spouse now living separately, or an adult child with their own home.");
		retValue &= isExpectedTextContainedInElement(driverMismatchPageHelpTextParagraphTwo, "Select \"Exclude this person from my insurance\" if this person lives in your home, but will never drive any vehicle listed on your policy. There will be no coverage for damage to any vehicle driven by this person, and they will have no coverage if they drive any vehicle under your policy.");
		return retValue;
	}

	public void validateDriversListed(FarmersSoftAssert fsa) throws Exception {
        List<WebElement> notIncludedDrivers = driver().findElements(By.xpath("//div[@class='driver-name ng-star-inserted']//h2"));
        int numberOfElements = rejectReasons.size();
        fsa.assertEquals(numberOfElements, notIncludedDrivers.size(), "Reject reasons radio button groups should be the same size with the excluded driver count");

        for (int i = 0; i < numberOfElements; i++) {
            String fullName = getTextFromElement(notIncludedDrivers.get(i));
            fsa.assertTrue(isElementDisplayed(By.xpath(String.format("//div[@class='driver-name ng-star-inserted' and contains(.,'%s')]", fullName))), "Driver should be displayed on the screen");
            List<WebElement> rejectReasonsForEachDriver = driver().findElements(By.xpath(String.format(REJECT_REASONS_XPATH + "[%s]//mat-radio-button", i + 1)));
            List<String> radioButtonsDisplayed = rejectReasonsForEachDriver.stream().map(this::getTextFromElement).collect(Collectors.toList());
            Collections.sort(radioButtonsDisplayed);
            List<String> radioButtonExpected = Arrays.asList("I dont know this person", "Not living in my household", "Exclude this person from my insurance", "Already added to this quote");
            List<String> radioButtonExpectedAlt = Arrays.asList("I don't know this person", "Not living in my household", "Exclude this person from my insurance", "Already added to this quote");
            Collections.sort(radioButtonExpected);
            Collections.sort(radioButtonExpectedAlt);
            fsa.assertTrue(radioButtonsDisplayed.equals(radioButtonExpected) || radioButtonsDisplayed.equals(radioButtonExpectedAlt), "Reject reason radio buttons label validation for each");
		}
	}

	public boolean validateDriversListed(LinkedHashMap<String, String> mapOfDriversFound) {
		// Compare drivers listed in this page to the ones in "Here's what we found" page
		LinkedHashMap<String, String> namesAndAgesInMismatchPage = new LinkedHashMap<>();
		int namesOfDriversNotIncludedSize = listOfNamesOfDriversNotIncluded.size();
		int agesOfDriversNotIncludedSize = listOfAgesOfDriversNotIncluded.size();
		for (int index=0; index < namesOfDriversNotIncludedSize && index < agesOfDriversNotIncludedSize; index++) {
			namesAndAgesInMismatchPage.put(getTextFromElement(listOfNamesOfDriversNotIncluded.get(index)).toLowerCase(Locale.US).replace("info",  EMPTY_STRING), getTextFromElement(listOfAgesOfDriversNotIncluded.get(index)).replace("info",EMPTY_STRING));
		}
		// Now add those entries without age
		for (int index=agesOfDriversNotIncludedSize; index < namesOfDriversNotIncludedSize; index++) {
			namesAndAgesInMismatchPage.put(getTextFromElement(listOfNamesOfDriversNotIncluded.get(index)).toLowerCase(Locale.US).replace("info",  EMPTY_STRING), EMPTY_STRING);
		}
		// For debugging when maps are not equal.
		boolean success = mapOfDriversFound.equals(namesAndAgesInMismatchPage);
		if (!success) {
			Log.warn("Drivers Found map: " + mapOfDriversFound);
			Log.warn("Mismatched drivers map: " + namesAndAgesInMismatchPage);
		}
		return success;
	}

	public void dontIncludeAnyMismatchedDriversInQuote() throws Exception {
		listOfUnknownDriverRadioButtons.forEach(radioButton -> scrollAndClickOnElement(radioButton));
		uncheckedListOfUnknownDriverRadioButtons.forEach(radioButton -> scrollAndClickOnElement(radioButton));
		scrollAndClickOnElement(continueButton);
		waitForSpinnerToBeGone();
	}

	public void randomlySelectReasonForNonInclusion() throws Exception {
		LocalDate twentyYearsAgo = LocalDate.now().minusYears(20);
		String inputDoB = "05/05" + twentyYearsAgo.getYear();
    	int numberOfElements = rejectReasons.size();
        for (int i = 0; i < numberOfElements; i++) {
            String attribute = getAttributeData(rejectReasons.get(i), ARIA_LABEL);
            String nonIncludedDriver = attribute.replace("Select a reason for not including ", EMPTY_STRING);
            List<String> availableOptions = Arrays.asList("I dont know this person", "Not living in my household", "Exclude this person from my insurance");
            Collections.shuffle(availableOptions);
            String selectedOption = availableOptions.get(0);
            String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
            if (landingStateCode.equals(NJ)) {
                selectedOption = "I dont know this person";
            }
            WebElement selectedRadioButton;
            if (selectedOption.equals("I dont know this person")) {
                selectedRadioButton = driver().findElement(By.xpath(
                        String.format(REJECT_REASONS_XPATH + "[%d]//mat-radio-button[contains(.,'%s') or contains(.,'know this person')]//input", (i + 1), selectedOption)));
            } else {
                selectedRadioButton = driver().findElement(By.xpath(
                        String.format(REJECT_REASONS_XPATH + "[%d]//mat-radio-button[contains(.,'%s')]//input", (i + 1), selectedOption)));
            }
            scrollAndClickOnElement(selectedRadioButton);
            if (selectedOption.equals("Exclude this person from my insurance")) {
                //Date of Birth
                List<WebElement> dateOfBirthInputs = driver().findElements(By.xpath(REJECT_REASONS_XPATH + "[" + (i + 1) + "]//mat-form-field[@id='dateOfBirth' and contains(@class,'invalid')]//input[@aria-label='Date of birth']"));
                if (!dateOfBirthInputs.isEmpty()) {
                    sendKeysToElement(dateOfBirthInputs.get(0), inputDoB);
                }
                //Gender
                List<WebElement> genders = driver().findElements(By.xpath(REJECT_REASONS_XPATH + "[" + (i + 1) + "]//mat-button-toggle-group[contains(@class,'invalid') and not(ancestor::*[@hidden or contains(@style,'display:none') or contains(@style,'visibility:hidden')])]//mat-button-toggle"));
                if (!genders.isEmpty()) {
                    Collections.shuffle(genders);
                    waitAndClickElement(genders.get(0));
                }

                Log.info("User selected relationship", false);
            }
            // fillout marital if need be
            List<WebElement> maritalMatSelects = driver().findElements(By.xpath("//mat-form-field[contains(.,'Marital')]//mat-select"));
            if (!maritalMatSelects.isEmpty()) {
                WebElement lastMaritalMatSelect = maritalMatSelects.get(maritalMatSelects.size() - 1);
                if (isElementVisible(maritalMatSelects.get(maritalMatSelects.size() - 1), 1) && !getAttributeData(lastMaritalMatSelect, CLASS).contains("ng-valid")) {
                    waitAndClickElement(lastMaritalMatSelect);
                    List<WebElement> matOptions = driver().findElements(By.tagName("mat-option"));
                    Collections.shuffle(matOptions);
                    waitAndClickElement(matOptions.get(0));
                }
            }
            // fillout relations if need be
            List<WebElement> relations = driver().findElements(By.xpath("//mat-form-field[contains(.,'Relation')]//mat-select"));
            if (!relations.isEmpty()) {
                WebElement lastRelationMatCheckbox = relations.get(relations.size() - 1);
                if (isElementVisible(lastRelationMatCheckbox, 1) || !getAttributeData(lastRelationMatCheckbox, CLASS).contains("ng-valid")) {
                    waitAndClickElement(lastRelationMatCheckbox);
                    List<WebElement> matOptions = driver().findElements(By.tagName("mat-option"));
                    Collections.shuffle(matOptions);
                    waitAndClickElement(matOptions.get(0));
                }


            }

            Log.info(String.format("User selected '%s' for person named '%s'", selectedOption, nonIncludedDriver), false);
        }

		List<WebElement> dobInputFields = driver().findElements(By.xpath("//mat-form-field[@id='dateOfBirth' and contains(@class,'invalid')]//input[@aria-label='Date of birth']"));
    	numberOfElements = dobInputFields.size();
        for (int i = 0; i < numberOfElements; i++) {
            if(isElementVisible(dobInputFields.get(i),1)) {
                sendKeysOneByOne(dobInputFields.get(i), inputDoB);
            }
		}
	}

    public void updateOneSelectionToAlreadyIncluded() throws Exception {
        WebElement alreadyAdded = driver().findElements(By.xpath("//mat-radio-group[@formcontrolname='rejectReasonFormValue']//mat-radio-button[contains(.,'Already')]")).get(0);
        scrollElementToMiddle(alreadyAdded);
        waitAndClickElement(alreadyAdded);
        sleep(1);
        if(!getAttributeData(alreadyAdded, CLASS).contains(CHECKED)) {
            waitAndClickElement(alreadyAdded);
        }
        WebElement includedName = driver().findElements(By.xpath(String.format("//mat-radio-button[contains(.,'%s')]", getSessionStorageAppStore().getData().getCustomerData().getFirstName()))).get(0);
        waitAndClickElement(includedName);
    }

	public boolean isOnDriverMismatchPage() {
		return isElementVisible(returnToDriverSelectionLink, 5);
	}

	public String saveQuote(String emailAddress) throws Exception {
		if (isElementPresentByXPath("//button[contains(.,'Save quote')]")) {
	        enterEmailInSaveQuoteModal(emailAddress);
		}
        return getAceQuoteNumberInThePage();
	}

	public void validateADA_DriverMismatchPage() {
		if (isOnDriverMismatchPage() &&  isADATestingEnabled()) {
			performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
		}
	}

	public void validateDriverMismatchPageForBW_US754967(FarmersSoftAssert fsa) throws Exception {
		fsa.assertTrue(validateDriversMismatchPageTitle(), "Driver mismatch page header validation");
		fsa.assertTrue(validateDriversMismatchPageDescription(), "Driver mismatch page page description validation");
		fsa.assertTrue(validateDriversMismatchPageHelp(), "Driver mismatch help text validation");
		validateDriversListed(fsa);
	}

	public void validateBDQSpecificRequirements(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		fsa.assertFalse(isDiscountSectionDisplayed(), "Discount section should NOT be displayed on " + this.getClass().getSimpleName());
		validateValidateAndFooterForBDQ(fsa, applicant, this);
		validateAgentSectionBDQ(fsa, applicant);
	}

    public void validateDriverNamesAreMasked(FarmersSoftAssert fsa){
		// If there are drivers not included, validate that their names are masked
		if(!listOfNamesOfDriversNotIncluded.isEmpty()){
			for (WebElement driverNameElement : listOfNamesOfDriversNotIncluded) {
				String driverNameText = getTextFromElement(driverNameElement);
				fsa.assertTrue(driverNameText.matches("^[A-Z]\\*+ [A-Z]\\*+$"), "Driver names should be masked on driver mismatch page for " + driverNameText);
			}
		}
	}

    public void validateRelationsToApplicantOptions(FarmersSoftAssert farmersSoftAssert) throws Exception {
        WebElement radioButton = excludeThisPersonFromMyInsuranceRadioButtons.get(0);
        scrollAndClickOnElement(radioButton);
        WebElement relationshipToApplicantMatSelect = radioButton.findElement(By.xpath("//mat-form-field[contains(.,'Relationship to applicant')]"));
        scrollAndClickOnElement(relationshipToApplicantMatSelect);
        List<WebElement> relationshipOptions = driver().findElements(By.tagName("mat-option"));
        List<String> displayedOptions = relationshipOptions.stream().map(this::getTextFromElement).collect(Collectors.toList());
        farmersSoftAssert.assertFalse(displayedOptions.contains("Spouse"), "Spouse should not be an option for relationship to applicant for driver mismatch page");
        // validate the options include Daughter, Grandchild, In-law, Other, Parent, Relative, Son
        List<String> expectedOptions = Arrays.asList("Daughter", "Grandchild", "In-law", "Other", "Parent", "Relative", "Son");
        for (String expectedOption : expectedOptions) {
            farmersSoftAssert.assertTrue(displayedOptions.contains(expectedOption), expectedOption + " should be an option for relationship to applicant for driver mismatch page");
        }

        // validate is user selects any (randomly) of expectedOptions, user can continue with the flow
        Collections.shuffle(expectedOptions);
        String randomOption = expectedOptions.get(0);
        WebElement randomOptionElement = driver().findElement(By.xpath("//mat-option[contains(.,'" + randomOption + "')]"));
        scrollAndClickOnElement(randomOptionElement);
        //Date of Birth
        List<WebElement> dateOfBirthInputs = driver().findElements(By.xpath(REJECT_REASONS_XPATH + "[" + (1) + "]//mat-form-field[@id='dateOfBirth' and contains(@class,'invalid')]//input[@aria-label='Date of birth']"));
        if (!dateOfBirthInputs.isEmpty()) {
            sendKeysToElement(dateOfBirthInputs.get(0), "01/01/1990");
        }
        //Gender
        List<WebElement> genders = driver().findElements(By.xpath(REJECT_REASONS_XPATH + "[" + (1) + "]//mat-button-toggle-group[contains(@class,'invalid') and not(ancestor::*[@hidden or contains(@style,'display:none') or contains(@style,'visibility:hidden')])]//mat-button-toggle"));
        if (!genders.isEmpty()) {
            Collections.shuffle(genders);
            waitAndClickElement(genders.get(0));
        }

        Log.info("User selected relationship", false);

        // fillout marital if need be
        List<WebElement> maritalMatSelects = driver().findElements(By.xpath("//mat-form-field[contains(.,'Marital')]//mat-select"));
        if (!maritalMatSelects.isEmpty()) {
            WebElement lastMaritalMatSelect = maritalMatSelects.get(maritalMatSelects.size() - 1);
            if (isElementVisible(maritalMatSelects.get(maritalMatSelects.size() - 1), 1) && !getAttributeData(lastMaritalMatSelect, CLASS).contains("ng-valid")) {
                waitAndClickElement(lastMaritalMatSelect);
                List<WebElement> matOptions = driver().findElements(By.tagName("mat-option"));
                Collections.shuffle(matOptions);
                waitAndClickElement(matOptions.get(0));
            }
        }
        scrollAndClickOnElement(continueButton);
        waitForSpinnerToBeGone();

        // validate that is user is navigated to the next page (AdditionalInfoPage)
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        farmersSoftAssert.assertTrue(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User should be navigated to Additional Info page after selecting a relationship to applicant option and clicking continue");
    }

}
