package com.farmers.ffq.hqm.pages;

import com.farmers.ffq.datatransferobjects.hqm.AgentInfoHQM;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.ArrayList;

import static com.farmers.ffq.utils.GlobalVariables.CALL_FARMERS_MOBILE_MANUFACTURED_HOME;
import static com.farmers.ffq.utils.GlobalVariables.SPACE;
import static com.farmers.ffq.utils.GlobalVariables.SRC;

/**
 * Farmers Fast Quote (FFQ) - Thank You Page - Home Quote Modernization (HQM).
 */

public class ThankYouRedirectPage extends HqmBasePage {

    @FindBy(xpath = "//farmers-home-quote-thank-you//a/img[@alt='Farmers Insurance Logo']")
    private WebElement linkFarmersLogo;

    @FindBy(xpath = "//farmers-home-quote-thank-you//h2")
    private WebElement pageTitle;

    @FindBy(xpath = "//farmers-home-quote-thank-you//p[contains(@class,'card-agent-subtitle')]")
    private WebElement pageSubTitle;

    @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'need-help-agent')]")
    private WebElement pageFooter;

    @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'PoliticalAgent')]//a[@id='phoneIcon']")
    private WebElement linkCallFarmersPA;

    @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'tui-subtitle-text-1')]")
    private WebElement pageFooterRedirect;

    @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'agents-Info')]//span[contains(@class,'quote-agent-name')]")
    private WebElement agentNameFooter;

    @FindBy(xpath = "//farmers-home-quote-thank-you//span[contains(@class,'quote-agent-p')]")
    private WebElement agentInfoFooter;

    @FindBy(xpath = "//farmers-home-quote-thank-you//img[contains(@class,'agent-img')]")
    private WebElement agentImage;

    @FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='emailTagId']//div/mat-icon[text()='email']/../.." +
            "/div[contains(@class,'body-two')]")
    private WebElement agentEmailAddress;

    @FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='phnTagId']//div/mat-icon[text()='phone']/../.." +
            "/div/span[contains(@class,'body-two')]")
    private WebElement agentPhoneNumber;

    @FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='locTagId']//div/mat-icon[text()='place']/../.." +
            "/div/span[contains(@class,'body-two')]")
    private WebElement agentAddress;

    private static final String PAGE_TITLE_TEXT = "Online quotes are not available for mobile or manufactured homes";

    private static final String PAGE_SUBTITLE_TEXT_PA = "Please consider contacting our affiliate Foremost Insurance\u00ae";

    private static final String PAGE_SUBTITLE_TEXT_EA = "Please contact your agent to request a quote.";

    private static final String PAGE_FOOTER_TEXT = "Need more help?\nYou can call customer service at\n";

    private static final String AGENT_INFO_FOOTER_TEXT = "Your local Farmers Insurance\u00ae Agent is available if you have any questions.";

    private static final String FIND_AGENT_BUTTON_XPATH = "//farmers-home-quote-thank-you//button[text()='Find an agent']";
    @FindBy(xpath = FIND_AGENT_BUTTON_XPATH)
    private WebElement buttonFindAgent;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public ThankYouRedirectPage() throws Exception {
        super();
        waitForPageToBeReady();
        wait.until(ExpectedConditions.urlContains("/thank-you"));
    }

    public void validatePageContent(String quoteNumber, FarmersSoftAssert fsa) throws Exception {
        Log.info("<< Thank You Redirect Page: >>");
        waitElementBeVisible(linkFarmersLogo);
        fsa.assertEquals(getAttributeData(linkFarmersLogo, "alt"), "Farmers Insurance Logo", "Thank You page - Farmers Insurance Logo.");
        fsa.assertEquals(getTextFromElement(pageTitle), PAGE_TITLE_TEXT, "Thank You Redirect page - page Title h2");
        fsa.assertFalse(isButtonBackDisplayed(), "Thank You Redirect page - No Back button is displayed.");
        fsa.assertFalse(isButtonNextDisplayed(), "Thank You Redirect page - No Next button is displayed.");
        fsa.assertFalse(sideDrawer.isDisplayed(), "Thank You Redirect page - No Side Drawer is displayed.");
        AgentInfoHQM agentInfo = getAgentInfo(quoteNumber);
        if ((agentInfo == null) || (agentInfo.getAgent().getLastName() == null)) {
            fsa.assertEquals(getTextFromElement(pageSubTitle), PAGE_SUBTITLE_TEXT_PA, "Thank You Redirect page - page SubTitle Political Agent (PA).");
            fsa.assertTrue(buttonFindAgent.isEnabled(), "Thank You Redirect page - button to Find an agent is available.");
            final String AFFILIATE_SITE_NAME = "www.foremost.com";
            waitAndClickElement(buttonFindAgent);
            waitForPageToBeReady();
            ArrayList<String> tabs = new ArrayList<>(driver().getWindowHandles());
            driver().switchTo().window(tabs.get(1));
            fsa.assertTrue(driver().getCurrentUrl().contains(AFFILIATE_SITE_NAME),
                    "Thank You Redirect page - Find an agent button navigates to Foremost.com");
            driver().close();
            driver().switchTo().window(tabs.get(0));
            fsa.assertEquals(getTextFromElement(pageFooter), PAGE_FOOTER_TEXT + CALL_FARMERS_MOBILE_MANUFACTURED_HOME,
                    "Thank You Redirect page - Customer service contact info.");
        } else {
            fsa.assertEquals(getTextFromElement(pageSubTitle), PAGE_SUBTITLE_TEXT_EA, "Thank You page - page SubTitle Exclusive Agent (EA).");
            fsa.assertFalse(isElementDisplayed(By.xpath(FIND_AGENT_BUTTON_XPATH)), "Thank You Redirect page - button to Find an agent is not available.");
            if ((agentInfo.getAgent().getAgentImageUrl() != null) && (!agentInfo.getAgent().getAgentImageUrl().isEmpty())) {
                fsa.assertEquals(getAttributeData(agentImage, SRC), agentInfo.getAgent().getAgentImageUrl(),
                        "Validate Thank You Redirect page - Agent Image Url in the footer.");
            }
            fsa.assertEquals(getTextFromElement(agentNameFooter), agentInfo.getAgent().getFirstName() + SPACE + agentInfo.getAgent().getLastName(),
                    "Thank You Redirect page - Agent Name footer.");
            fsa.assertEquals(getTextFromElement(agentInfoFooter), AGENT_INFO_FOOTER_TEXT, "Validate Thank You Redirect page - Agent Info footer.");
            fsa.assertEquals(getTextFromElement(agentEmailAddress), agentInfo.getAgentEmailAddress(), "Validate Thank You Redirect page - Agent Email Address.");
            fsa.assertEquals(getTextFromElement(agentPhoneNumber), agentInfo.getAgentPhoneNumber(), "Validate Thank You Redirect page - Agent Phone Number.");
            if (!agentInfo.getAgent().getAddress().getCity().isEmpty()) {
                fsa.assertEquals(getTextFromElement(agentAddress), agentInfo.getAgentFullAddress(), "Validate Thank You Redirect page - Agent Address.");
            }
        }
    }

}
