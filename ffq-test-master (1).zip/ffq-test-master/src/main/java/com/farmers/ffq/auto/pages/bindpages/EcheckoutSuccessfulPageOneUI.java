package com.farmers.ffq.auto.pages.bindpages;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.auto.pages.bw.BwDocuSignPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class EcheckoutSuccessfulPageOneUI extends AutoBasePage {

    private static final String PAYMENT_SUCCESSFUL = "Payment successful";
    @FindBy(xpath = "//div[contains(text()," + PAYMENT_SUCCESSFUL + ")]")
    private WebElement paymentSuccessfulMessage;

    private static final String WELCOME_TO_FARMERS = "Welcome to Farmers";
    private final String WELCOME_TO_FARMERS_XPATH = String.format("//h1[contains(.,'%s')]", WELCOME_TO_FARMERS);
    @FindBy(xpath = "//h1[contains(text()," + WELCOME_TO_FARMERS + ")]")
    private WebElement welcomeToFarmersMessage;

    private static final String SIGN_ELECTRONICALLY_XPATH = "//h1[contains(.,'Sign electronically')]";
    @FindBy(xpath = SIGN_ELECTRONICALLY_XPATH)
    private WebElement signElectronicallyMessage;

    private static final String JOINING_POLICY_HOLDER_MESSAGE = "Thank you for joining us as a policyholder!";
    @FindBy(xpath = "//h1[contains(text()," + JOINING_POLICY_HOLDER_MESSAGE + ")]")
    private WebElement joiningAsAPolicyHolderMessage;

    @FindBy (xpath = "//button[contains(@class, 'cta-sign')]")
    private WebElement startSigningButton;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public EcheckoutSuccessfulPageOneUI() throws Exception {
    }

    public boolean isPaymentSuccessfulMessageCorrect() {
        String PAYMENT_SUCCESSFUL_MESSAGE = "Payment successful";
        String PAYMENT_SUCCESSFUL_MESSAGE_BUNDLE = "Your  policy payments were successful!";
        try {
            waitForSpinnerToBeGone();
            wait.until(ExpectedConditions.or(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(text(),'" + PAYMENT_SUCCESSFUL_MESSAGE + "')]")),
                    ExpectedConditions.presenceOfElementLocated(By.xpath("//p[contains(text(),'" + PAYMENT_SUCCESSFUL_MESSAGE_BUNDLE + "')]")),
                    		ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'Choose a Password')]"))));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isWelcomeToFarmersPresent() {
       return isElementPresent(By.xpath(WELCOME_TO_FARMERS_XPATH), 15);
    }

    public boolean isSignElectronicallyPresent() {
       return isElementPresent(By.xpath(SIGN_ELECTRONICALLY_XPATH) , 15);
    }

    public void signDocuments() throws Exception {
    	clickElement(startSigningButton);
    	waitElementBeInvisible(startSigningButton);
    	new BwDocuSignPage().signDocuments();
    }
}
