package com.farmers.ffq.auto.pages;

import com.farmers.ffq.utils.FarmersSoftAssert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class InterstitialBundlePage extends AutoBasePage {

    @FindBy(id = "bundlePageHeaderTitle")
    private WebElement pageHeader;
    @FindBy(css = "div[class='bundle-page-title-savings bundle-page-title-font']")
    private WebElement pageSubTitle;
    @FindBy(css = "img[class='auto-home-group-image']")
    private WebElement bundleImage;
    @FindBy(css = "div[class='bundle-page-promo-trust']>span")
    private WebElement savingMessageUnderImage;
    @FindBy(css = "div[class='bundle-page-title-savings bundle-page-title-savings-font']>span")
    private WebElement savingSubMessageUnderImage;
    @FindBy(xpath = "//div[@class='bundle-page__bundle-continue-button']//button")
    private WebElement continueWithBundleDiscountButton;
    @FindBy(css = "button[data-tui-tracking-id='auto__continue-button-cta']")
    private WebElement continueWithAutoOnlyButton;
    @FindBy(xpath = "//div[contains(@class,'bundle-page-disclaimer-section')]/span")
    private WebElement pageDisclaimer;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public InterstitialBundlePage() throws Exception {
    }

    public boolean isOnInterstitialBundlePage() {
        return isElementVisible(pageHeader, 5);
    }

    public void continueWithAutoMonoLine() {
        waitAndClickElement(continueWithAutoOnlyButton);
        waitForSpinnerToBeGone();
    }

    public void continueWithBundle() {
        waitAndClickElement(continueWithBundleDiscountButton);
    }

    public void validatePageHeader(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(pageHeader), "Bundle and save", "Interstitial Page header is not as expected");
    }

    public void validateSubHeader(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(pageSubTitle), "You could save up to $1232* when you bundle auto and home with Farmers®", "Interstitial Page sub header is not as expected");
    }

    public void validateImagePresent(FarmersSoftAssert softAssert) {
        softAssert.assertTrue(bundleImage.isDisplayed(), "Bundle image is not displayed on interstitial page");
        softAssert.assertFalse(getAttributeData(bundleImage, "src").isEmpty(), "Bundle image src attribute is empty");
    }

    public void validateSavingMessageUnderImage(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(savingMessageUnderImage), "Unlock substantial savings with quality coverage from a brand you can trust.", "Saving message under image is not as expected");
    }

    public void validateSavingSubMessageUnderImage(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(savingSubMessageUnderImage), "Ready to see how much you could save?", "Saving sub message under image is not as expected");
    }

    public void validateCtaTextForBundle(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(continueWithBundleDiscountButton), "Continue with bundle discount", "CTA text for continue with bundle discount button is not as expected");
    }

    public void validateCtaTextForAutoOnly(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(continueWithAutoOnlyButton), "Continue with auto only", "CTA text for continue with auto only button is not as expected");
    }

    public void validatePageDisclaimer(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(pageDisclaimer), "* Based on average nationwide annual savings of new customers surveyed, excluding HI, SC & Farmers GroupSelect\u00ae, from 9/1/24 to 8/31/25 who switched their Home and Auto insurance policies to Farmers\u00ae branded policies, responded to the survey, and realized savings. Potential savings vary by customer and may vary by state and product.", "Page disclaimer text is not as expected");
    }

    public void validatePageContent(FarmersSoftAssert softAssert) {
        validatePageHeader(softAssert);
        validateSubHeader(softAssert);
        validateImagePresent(softAssert);
        validateSavingMessageUnderImage(softAssert);
        validateSavingSubMessageUnderImage(softAssert);
        validateCtaTextForBundle(softAssert);
        validateCtaTextForAutoOnly(softAssert);
        validatePageDisclaimer(softAssert);
    }
}
