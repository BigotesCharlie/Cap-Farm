package com.farmers.ffq.auto.pages;

import org.mortbay.log.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.farmers.ffq.utils.FarmersSoftAssert;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class FarmersGroupSelectPage extends AutoBasePage {

    @FindBy(xpath = "//div[@class='fws-page-container']//h1")
    private WebElement farmersGroupSelectPageTitle;

    @FindBy(className = "landing-text")
    private WebElement farmersGroupSelectPageDescription;

    @FindBy(xpath = "//div[@class='container']//p/span[@class='small-text']")
    private WebElement farmersGroupSelectPageDisclaimer;

    @FindBy(xpath = "//p/a[contains(@href,'tel:')]")
    private WebElement headerPhoneNumberLink;

    @FindBy(xpath = "//a[contains(@class, 'button-cta--desktop')][contains(@href,'tel:')]")
    private WebElement callNowButton;

    @FindBy(xpath = "//a[contains(@class, 'button-cta--desktop')][@data-gtm='Farmers_COLPGS_FFQLINK_Header']")
    private WebElement quoteWithFarmersOnlineLink;

    @FindBy(id = "employerdiv")
    private WebElement employerGroupAffinity;

    @FindBy(xpath = "//div[@class='tui-info-box-content mt-8']//p")
    private WebElement pageContent;
    //TODO: camelCase

    @FindBy(id = "fws-page-employer-img-container")
    private WebElement imageContainer;

    @FindBy(id = "whereYouWork")
    private WebElement whereYouWorkContext;

    @FindBy(xpath = "//input[@id='mat-input-fwsField']")
    private WebElement employerSelectDropdown;

    @FindBy(id = "cardMessage")
    private WebElement cardMessage;

    @FindBy(id = "cardErrorMessage")
    private WebElement cardErrorMessage;

    @FindBy(id = "cardSuccessMessage")
    private WebElement cardSuccessMessage;

    @FindBy(xpath = "//div[@class='fgs_employer-card-success_title tui-body-bold']")
    private WebElement farmersGroupSelectBenefitsTitle;

    @FindBy(xpath = "//span[@class='fgs_employer-card-success_desc']//li")
    private List<WebElement> discountDescriptions;


    @FindBy(xpath = "//span[@id='disclaimer']")
    private WebElement disclaimerContent;

    @FindBy(xpath = "//button[contains(text(),'Continue')]")
    private WebElement continueWithDiscountButton;

    @FindBy(xpath = "//a[contains(text(),' Skip this discount ')]")
    private WebElement skipThisDiscountButton;

    @FindBy(xpath = "//span[@class='selected-indicator']/preceding-sibling::span")
    private WebElement selectedInsuranceType;

    public static final String DROPDOWN_OPTIONS_XPATH = "//mat-option//span";


    private static final String DROPDOWN_DESCRIPTION = "Save money based on where you work, or the groups you belong to.";

    private static final String PAGE_CONTENT = "Affiliated employers, memberships, and credit unions may qualify for a discount through Farmers GroupSelect\u00AE.";
    private static final String VALID_EMPLOYEE_GROUP = "BANK OF AMERICA";

    private static final String INVALID_EMPLOYEE_GROUP = "DFAAR";

    private static final String DISCLAIMER_CONTENT = "*Savings based on average nationwide annual savings in 2022 reported by new customers who called the Farmers GroupSelect call center, switched to Farmers\u00AE branded auto insurance policies issued by Farmers GroupSelect's program, and realized savings. Potential savings vary by customer and may vary by state and product. Statistics don't reflect products sold on Agent360â„ .";

    public FarmersGroupSelectPage() throws Exception {
    }

    public boolean isOnFarmersGroupSelectSideSheet() {
        return isElementVisible(headerPhoneNumberLink, 5);
    }

    public boolean isOnFarmersGroupSelectPage() {
        return isElementVisible(farmersGroupSelectPageTitle, 5);
    }

    public boolean quoteWithFarmersInsuranceOnline() {
        if (isOnFarmersGroupSelectSideSheet()) {
            scrollAndClickOnElement(quoteWithFarmersOnlineLink);
            return true;
        } else {
            return false;
        }
    }

    public void validateFWSPage(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isOnFarmersGroupSelectPage(), "User is on " + this.getClass().getSimpleName());
        fsa.assertEquals(getTextFromElement(farmersGroupSelectPageTitle), "Let's check for a discount", "Red States FGS page header validation ");
        fsa.assertEquals(getTextFromElement(employerGroupAffinity), "Employer/group affinity", "Red States FGS page employer group affinity text validation ");
        fsa.assertEquals(getTextFromElement(pageContent), PAGE_CONTENT, "Red States FGS page description validation ");
        fsa.assertTrue(isElementDisplayed(imageContainer, 10), "FGS Page Content Image is displayed");
        fsa.assertEquals(getTextFromElement(whereYouWorkContext), DROPDOWN_DESCRIPTION, "Asking User to Enter the Employer/Group name ");
        fsa.assertTrue(isElementDisplayed(employerSelectDropdown, 10), "Employer/Group Dropdown Validation");

        // validate invalid group employer
        sendKeysToElement(employerSelectDropdown, "DF");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(cardErrorMessage)), "Members of this group are not eligible for our affinity discounts. Try another employer or group, or continue your quote and we'll look for other discounts for you.", "Invalid employer group message");

        // valid employer validation
        selectByValueWithGivenText(employerSelectDropdown, DROPDOWN_OPTIONS_XPATH, VALID_EMPLOYEE_GROUP);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(cardSuccessMessage)), "Good news! Discounts are available for members of this group. We'll ask you to verify your eligibility in a bit.", "Employer group selection success message validation");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(farmersGroupSelectBenefitsTitle)), "Farmers GroupSelect benefits", "Employer group selection benefits title validation");

        List<String> expectedBenefitsDescriptions = Arrays.asList("Others have saved 23%* on average by switching their auto insurance", "By bundling policies, you could save even more", "Get special employee or association member discounts");
        List<String> actualBenefits = discountDescriptions.stream().map(this::getTextFromElement).collect(Collectors.toList());

        Collections.sort(expectedBenefitsDescriptions);
        Collections.sort(actualBenefits);
        Log.info("actual benefits" + actualBenefits);
        Log.info("expected benefits" + expectedBenefitsDescriptions);
        fsa.assertEquals(actualBenefits, expectedBenefitsDescriptions, "Benefits description validation  " + this.getClass().getSimpleName());

        fsa.assertTrue(continueWithDiscountButton.isEnabled() && continueWithDiscountButton.isDisplayed(), "'Continue' button is displayed and enabled");
        fsa.assertTrue(skipThisDiscountButton.isEnabled() && skipThisDiscountButton.isDisplayed(), "'Skip this Discount' button is displayed and enabled");
    }

    public void processFarmersGroupSelectPage(boolean continueWithDiscount) {
        if (continueWithDiscount) {
            selectByValueWithGivenText(employerSelectDropdown, DROPDOWN_OPTIONS_XPATH, "bank of bluffs");
            sleep(1);
            waitAndClickElement(continueWithDiscountButton);
            waitForSpinnerToBeGone();
        } else {
            waitAndClickElement(skipThisDiscountButton);
        }
    }

    public void invalidEmployeeGroup() {
        sleep(10);
        sendKeysToElement(employerSelectDropdown, INVALID_EMPLOYEE_GROUP);
        sleep(10);
        waitAndClickElement(continueWithDiscountButton);

    }

    protected void selectByValueWithGivenText(WebElement dropdown, String xpath, String value) {
        sendKeysToElement(dropdown, value.substring(0, value.length() - 1));
        wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath(xpath), 1));
        sendKeysToElement(dropdown, Keys.ARROW_DOWN);
        sendKeysToElement(dropdown, Keys.ENTER);
    }

    public void validateSelectedInsuranceType(FarmersSoftAssert fsa) throws Exception {
        String currentUrl = driver().getCurrentUrl();
        String EXPECTED_DOMAIN = "farmersinsurancechoice.com";
        fsa.assertTrue(currentUrl.contains(EXPECTED_DOMAIN), "Current URL does not contain expected domain. Current URL: " + currentUrl);
        fsa.assertEquals(getTextFromElement(selectedInsuranceType), "Auto", "Selected insurance type is not as expected on bindable choice page.");
    }

}
