package com.farmers.ffq.home.pages;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.ApplicantHome;
import com.farmers.ffq.datatransferobjects.ApplicantRetQuote;
import com.farmers.ffq.datatransferobjects.SqlAddress;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import org.testng.Assert;

import java.util.*;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.*;

/**
 * Farmers Fast Quote (FFQ) - Property Page - Home.
 *
 * @author Valentins Kukjans
 *
 */

public class PropertyPage extends BasePage {

	private static final int OLDEST_HOME = 1492;
	private static final String COPPER = "Copper";
	private static final String RECONSTRUCTION_COST_SCENARIO = "Reconstruction";
	private static final String CANT_FIND = "Can't find ";
	private static final String NAVIGATION_BAR_ITEM_NO_MATCH_MSG = "Navigation bar item doesn't match ";
	private static final String PLEASE_SELECT = "Please select";
	private static final String ESTIMATED_RECONSTRUCTION_COST_STATIC_TEXT = "Your home's estimated reconstruction cost requires that you speak to an agent directly. "
			+ "For further details, Contact Your Farmers Agent or call 1-800-206-9469.";


	@FindBy(id = "AddHome:propRoofType")
	protected WebElement homeTypeOfRoof;

	@FindBy(id = "AddHome:noOfAdult")
	private WebElement numberOfAdultsInHousehold;

	@FindBy(id = "AddHome:propLosses")
	public WebElement propertyLossesInTheLastFiveYearsDropDown;

	@FindBy(xpath = "//*[@id='AddHome:exteriorWallType']")
	private WebElement homeExteriorWallType;

	@FindBy(xpath = "//*[@id='AddHome:phone']")
	private WebElement phoneNumber;

	@FindBy(id = "AddHome:propYearBuilt")
	public WebElement whenYourHomeWasOriginallyBuilt;

	@FindBy(id = "AddHome:propSqrFootage")
	public WebElement squareFootage;

	@FindBy(id = "AddHome:propUnits")
	private WebElement numberOfSeparateLivingUnitsDropDown;

	@FindBy(id = "SCF")
	private WebElement stuccoOnFrameElement;

	@FindBy(id = "BKV")
	private WebElement brickVeneerElement;

	@FindBy(id = "WSD")
	private WebElement woodSidingElement;

	@FindBy(id = "CFS")
	private WebElement cementFiberSidingElement;

	@FindBy(xpath = "//*[@id='imagesContent']/button[2]")
	private WebElement nextButtonWall;

	@FindBy(id = "VNL")
	private WebElement vinylSidingElement;

	@FindBy(id = "STV")
	private WebElement stoneVeneerElement;

	@FindBy(id = "CLW")
	private WebElement clapboardWoodElement;

	@FindBy(id = "SCM")
	private WebElement stuccoOnMasonryElement;

	@FindBy(id = "ALS")
	private WebElement aluminiumSidingElement;

	@FindBy(id = "SDB")
	private WebElement solidBrickElement;

	@FindBy(id = "WSH")
	private WebElement woodShakesElement;

	@FindBy(id = "CMT")
	private WebElement cementShinglesElement;

	@FindBy(id = "STS")
	private WebElement steelSidingElement;

	@FindBy(id = "SDS")
	private WebElement solidStoneElement;

	@FindBy(id = "SDL")
	private WebElement solidWoodElement;

	@FindBy(id = "LVS")
	private WebElement logVeneerSidingElement;

	@FindBy(id = "CLR")
	private WebElement clapboardRedwoodElement;

	@FindBy(id = "ADB")
	private WebElement adobeElement;

	@FindBy(id = "AddHome:propDwellingtype")
	public WebElement dwellingStyleDropDown;

	@FindBy(id = "AddHome:propNoOfFullBaths")
	private WebElement propNoOfFullBathsDropDown;

	@FindBy(id = "AddHome:propNoOfHalfBaths")
	private WebElement propNoOfHalfBathsDropDown;

	@FindBy(id = "1")
	private WebElement asphaltShingle;

	@FindBy(id = "C")
	private WebElement fiberglassDimensionalAsphalt;

	@FindBy(id = "5")
	private WebElement spanishTileClay;

	@FindBy(id = "6")
	private WebElement concreteCementFiberTile;

	@FindBy(id = "3")
	private WebElement steelTileOrShingle;

	@FindBy(id = "8")
	private WebElement rockTarGravel;

	@FindBy(id = "2")
	private WebElement woodShingleShake;

	@FindBy(id = "B")
	private WebElement sheetMetalPanel;

	@FindBy(id = "M")
	private WebElement singlePlyMembraneSystems;

	@FindBy(id = "O")
	private WebElement aluminum;

	@FindBy(id = "A")
	private WebElement rolledAsphaltFlat;

	@FindBy(id = "4")
	private WebElement syntheticShingleOrTile;

	@FindBy(id = "7")
	private WebElement slate;

	@FindBy(id = "9")
	private WebElement copper;

	@FindBy(id = "AddHome:propAgeOfRoof")
	private WebElement howOldIsYourRoofDropDown;

	@FindBy(id = "AddHome:propGarageType")
	public WebElement typeOfGarageDropDown;

	@FindBy(id = "AddHome:propDeck:0")
	private WebElement haveAnyDecksYesRadioButton;

	@FindBy(id = "AddHome:propDeck:1")
	private WebElement haveAnyDecksNoRadioButton;

	@FindBy(id = "AddHome:propPool:0")
	private WebElement havePoolYesRadioButton;

	@FindBy(id = "AddHome:propPool:1")
	private WebElement havePoolNoRadioButton;

	@FindBy(id = "AddHome:propBasement:0")
	private WebElement haveBasementYesRadioButton;

	@FindBy(id = "AddHome:propBasement:1")
	private WebElement haveBasementNoRadioButton;

	@FindBy(id = "AddHome:homePlumb:0")
	private WebElement hasPlumbingSystemYesRadioButton;

	@FindBy(id = "AddHome:homePlumb:1")
	private WebElement hasPlumbingSystemNoRadioButton;

	@FindBy(id = "AddHome:priHeatingSys")
	private WebElement typeOfHeatingDropDown;

	@FindBy(id = "AddHome:Email")
	private WebElement emailAddressTextBox;

	@FindBy(id = "AddHome:nextDiscount")
	private WebElement agreeAndContinueButton;

	@FindBy(xpath = "//*[@id='roofsImagesContent']/button[2]")
	private WebElement nextButtonRoof;

	@FindBy(id = "AddHome:lastpropLoss")
	private WebElement lastPropertyClaim;

	@FindBy(id = "AddHome:propNoOfStories")
	private WebElement numberOfStoriesDropDown;

	@FindBy(xpath = "//label[@for='AddHome:stormShutters:0']")
	private WebElement stormShuttersYesRadioButton;

	@FindBy(xpath = "//label[@for='AddHome:stormShutters:1']")
	private WebElement stormShuttersNoRadioButton;

	@FindBy(xpath = "//*[@id='AddHome:propPoolPnl']/div")
	private WebElement retrieveHavePoolErrorMessage;

	@FindBy(xpath = "//*[@id='AddHome:entirehomePlumb']/div")
	private WebElement retrieveSystemReplacedLastTwentyYearsErrorMessage;

	@FindBy(className = "TT")
	public WebElement toolTip;

	@FindBy(xpath = "//*[@id='propLossesError']")
	public WebElement propertyLossesKnockOutMessage;

	@FindBy(className = "TT")
	public List<WebElement> toolTips;

	@FindBy(className = "middle")
	public List<WebElement> toolTipsText;

	@FindBy(xpath = "//*[@id='additionalInfomation']/div[13]")
	public WebElement retrieveHaveBasementErrorMsg;

	@FindBy(css = ".wallImages>label")
	public List<WebElement> typeOfRoofTitles;

	@FindBy(css = ".wallImages>label")
	public List<WebElement> wallTypeTitles;

	@FindBy(xpath = "//*[@id='AddHome:progress:0:addhome']/span[contains(text(), 'Your Info')]")
	public WebElement yourInfoTabButton;

	@FindBy(id = "PVError")
	public WebElement estReconstCostMsg;

	@FindBy(id = "AddHome:tcpaTxtDisLbl")
	public WebElement footerStaticText;

	@FindBy(id = "renterSave")
	private WebElement saveAndFinishLaterBtn;

	@FindBy(id = "saveRetrieveLaterForm:farmersRedirectLink")
	private WebElement visitFcomBtn;

	@FindBy(id = "saveRetrieveLaterForm:savetbuttonid")
	private WebElement quoteHasBeenSavedOKButton;

	@FindBy(xpath = "//div[@class='AgentLanding']")
	private WebElement weApologizeForInconvenienceText;

	@FindBy(css = ".slick-next.slick-arrow")
	private List<WebElement> arrowNextBtn;

	@FindBy(xpath = "//*[@id='AgentIntro']/h1")
	private WebElement yourQuoteReqSpecAttentTitle;

	@FindBy(xpath = "//*[@id='AddHome:vivintSmartHome']/tbody/tr/td[1]/label")
	private WebElement haveConnectedYesRadioButton;

	@FindBy(xpath = "//*[@id='AddHome:vivintSmartHome']/tbody/tr/td[2]/label")
	private WebElement haveConnectedNoRadioButton;

	@FindBy(id = "AddHome:propLossesLbl")
	private WebElement propLossesLbl;

	@FindBy(id = "AddHome:propDwellingtypeLbl")
	private WebElement propDwellingtypeLbl;

	@FindBy(id = "AddHome:propYearBuiltLbl")
	private WebElement propYearBuiltLbl;

	@FindBy(id = "AddHome:propSqrFootageLbl")
	private WebElement propSqrFootageLbl;

	@FindBy(id = "AddHome:exteriorWallTypeLbl")
	private WebElement exteriorWallTypeLbl;

	@FindBy(id = "AddHome:propGarageTypeLbl")
	private WebElement propGarageTypeLbl;

	@FindBy(id = "AddHome:priHeatingSysLbl")
	private WebElement priHeatingSysLbl;

	@FindBy(id = "AddHome:propNoOfFullBathsLbl")
	private WebElement propNoOfFullBathsLbl;

	@FindBy(id = "AddHome:propNoOfHalfBathsLbl")
	private WebElement propNoOfHalfBathsLbl;

	@FindBy(id = "AddHome:propRoofTypeLbl")
	private WebElement propRoofTypeLbl;

	@FindBy(id = "AddHome:propAgeOfRoofLbl")
	private WebElement propAgeOfRoofLbl;

	@FindBy(id = "AddHome:propDeckPnl")
	private WebElement propertyDeckQuestionSection;

	@FindBy(id = "AddHome:propDeckLbl")
	private WebElement propDeckLbl;

	@FindBy(id = "AddHome:propPoolLbl")
	private WebElement propPoolLbl;

	@FindBy(id = "AddHome:propBasementLbl")
	private WebElement propBasementLbl;

	@FindBy(id = "AddHome:entirehomePlumbLbl")
	private WebElement entirehomePlumbLbl;

	@FindBy(id = "AddHome:phoneLbl")
	private WebElement phoneLbl;

	@FindBy(id = "AddHome:emailLbl")
	private WebElement emailLbl;

	@FindBy(id = "AddHome:lastProplossLbl")
	private WebElement lastProplossLbl;

	@FindBy(id = "AddHome:vivintSmartHomeLbl")
	private WebElement vivintSmartHomeLbl;

	@FindBy(id = "AddHome:stormShuttersLbl")
	private WebElement stormShuttersLbl;

	@FindBy(id = "agentName")
	private WebElement agentNameLbl;

	@FindBy(id = "agentAddress")
	private WebElement agentAddressLbl;

	@FindBy(id = "lastpropLossError")
	private WebElement lastpropLossError;

	@FindBy(id = "propLossesError")
	private WebElement propLossesError;

	@FindBy(id = "propDwellingtypeError")
	private WebElement propDwellingtypeError;

	@FindBy(id = "propYearBuiltError")
	private WebElement propYearBuiltError;

	@FindBy(id = "propSqrFootageError")
	private WebElement propSqrFootageError;

	@FindBy(id = "exteriorWallTypeError")
	private WebElement exteriorWallTypeError;

	@FindBy(id = "propGarageTypeError")
	private WebElement propGarageTypeError;

	@FindBy(id = "priHeatingSysError")
	private WebElement priHeatingSysError;

	@FindBy(id = "propNoOfFullBathsError")
	private WebElement propNoOfFullBathsError;

	@FindBy(id = "propNoOfHalfBathsError")
	private WebElement propNoOfHalfBathsError;

	@FindBy(id = "propRoofTypeError")
	private WebElement propRoofTypeError;

	@FindBy(id = "propAgeOfRoofError")
	private WebElement propAgeOfRoofError;

	@FindBy(id = "propBasementError")
	private WebElement propBasementError;

	@FindBy(id = "phoneError")
	private WebElement phoneError;

	@FindBy(id = "emailError")
	private WebElement emailError;

	@FindBy(id = "entirehomePlumbError")
	private WebElement entirehomePlumbError;

	@FindBy(id = "AddHome:propBasement")
	private WebElement propBasementContainer;

	@FindBy(id = "SqrFootageTT")
	private WebElement sqrFootageTT;

	@FindBy(xpath = "//*[@id='SqrFootagePopup']/p")
	private WebElement sqrFootageTTText;

	@FindBy(xpath = "//*[@id='SqrFootagePopup']/input")
	private WebElement sqrFootageTTClodeBtn;

	@FindBy(id = "extWallTypeTT")
	private WebElement extWallTypeTT;

	@FindBy(css = "#extWallTypePopup>p")
	private WebElement extWallTypeTTText;

	@FindBy(xpath = "//*[@id='extWallTypePopup']/input")
	private WebElement extWallTypeTTCloseBtn;

	@FindBy(id = "roofTypeTT")
	private WebElement roofTypeTT;

	@FindBy(xpath = "//*[@id='roofTypePopup']/p")
	private WebElement roofTypeTTText;

	@FindBy(xpath = "//*[@id='roofTypePopup']/input")
	private WebElement roofTypeTTCloseBtnt;

	@FindBy(id = "phoneTT")
	private WebElement phoneTT;

	@FindBy(xpath = "//*[@id='phonePopup']/p")
	private WebElement phoneTTText;

	@FindBy(xpath = "//*[@id='phonePopup']/input")
	private WebElement phoneTTCloseBtn;

	@FindBy(id = "emailTT")
	private WebElement emailTT;

	@FindBy(xpath = "//*[@id='emailPopup']/p")
	private WebElement emailTTText;

	@FindBy(xpath = "//*[@id='emailPopup']/input")
	private WebElement emailTTCloseBtn;

	@FindBy(xpath = "//*[@id='AddHome:progress:0:addhome']/span[2]")
	private WebElement yourInfoNavBarText;

	@FindBy(xpath = "//*[@id='AddHome:progress:1:addhome']/span[2]")
	private WebElement propertyNavBarText;

	@FindBy(xpath = "//*[@id='AddHome:progress:2:addhome']/span[2]")
	private WebElement coverageNavBarText;

	@FindBy(xpath = "//*[@id='AddHome:progress:3:addhome']/span[2]")
	protected WebElement quoteNavBarText;

	@FindBy(id = "pbMenuPlaceHolder")
	private WebElement blueNavBar;

	@FindBy(id = "HeaderLogo")
	private WebElement homeHeaderLogo;

	@FindBy(xpath = "//*[@id='HomeIntro']/p")
	private WebElement completeThisInformationSubHeaderText;

	@FindBy(id = "AgentIntro")
	private WebElement quoteRequiresSpecialAttentionText;

	@FindBy(id = "saveRetrieveLaterForm:Email")
	private WebElement addEmailToRetrieveQuote;

	@FindBy(id = "saveRetrieveLaterForm:savetbuttonid")
	private WebElement continueSavingQuote;

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public PropertyPage() throws Exception {
		super();
	}

	/**
	 *
	 * @return Map<String,WebElement>
	 */
	private Map<String,WebElement> getExteriorWallTypes() {
		Map<String, WebElement> wallTypes = new HashMap<>();
		wallTypes.put("Stucco on Frame", stuccoOnFrameElement);
		wallTypes.put("Aluminium Siding", aluminiumSidingElement);
		wallTypes.put("Solid Brick", solidBrickElement);
		wallTypes.put("Brick Veneer", brickVeneerElement);
		wallTypes.put("Adobe", adobeElement);
		wallTypes.put("Cement Fiber Siding", cementFiberSidingElement);
		wallTypes.put("Wood Siding", woodSidingElement);
		wallTypes.put("Vinyl Siding", vinylSidingElement);
		wallTypes.put("Stone Veneer", stoneVeneerElement);
		wallTypes.put("Clapboard Wood", clapboardWoodElement);
		wallTypes.put("Stucco on Masonry", stuccoOnMasonryElement);
		wallTypes.put("Wood Shakes", woodShakesElement);
		wallTypes.put("Cement Shingles", cementShinglesElement);
		wallTypes.put("Steel Siding", steelSidingElement);
		wallTypes.put("Solid Stone", solidStoneElement);
		wallTypes.put("Solid Wood", solidWoodElement);
		wallTypes.put("Log Veneer Siding", logVeneerSidingElement);
		wallTypes.put("Clapboard Redwood", clapboardRedwoodElement);
		return wallTypes;
	}

	/**
	 *
	 * @return Map<String,WebElement>
	 */
	private Map<String,WebElement> getTypesOfRoof() {
		Map<String, WebElement> typesOfRoof = new HashMap<>();
		typesOfRoof.put("Asphalt Shingle", asphaltShingle);
		typesOfRoof.put("Fiberglass / Dimensional Asphalt", fiberglassDimensionalAsphalt);
		typesOfRoof.put("Spanish Tile (Clay)", spanishTileClay);
		typesOfRoof.put("Concrete/Cement -Fiber Tile", concreteCementFiberTile);
		typesOfRoof.put("Steel (Tile or Shingle)", steelTileOrShingle);
		typesOfRoof.put("Rock/Tar Gravel", rockTarGravel);
		typesOfRoof.put("Wood Shingle/Shake", woodShingleShake);
		typesOfRoof.put("Sheet Metal Panel", sheetMetalPanel);
		typesOfRoof.put("Single Ply Membrane Systems", singlePlyMembraneSystems);
		typesOfRoof.put("Aluminum", aluminum);
		typesOfRoof.put("Rolled Asphalt - Flat", rolledAsphaltFlat);
		typesOfRoof.put("Synthetic Shingle or Tile", syntheticShingleOrTile);
		typesOfRoof.put("Slate", slate);
		typesOfRoof.put("Copper", copper);
		return typesOfRoof;
	}

	/**
	 * Select Exterior Wall Type.
	 *
	 * @param wallType
	 * @throws IllegalArgumentException
	 */
	private void selectExteriorWallType(String wallType) {
		Log.info("Selecting Exterior Wall Type: " + wallType);
		clickElement(homeExteriorWallType);
		WebElement desiredWallType = getExteriorWallTypes().get(wallType);
		if (desiredWallType != null) {
			if (!arrowNextBtn.isEmpty()) {
				while (nextButtonWall.isEnabled()) {
					for (WebElement title : wallTypeTitles) {
						if (getTextFromElement(title).equals(wallType) && desiredWallType.isEnabled()) {
							clickElement(desiredWallType);
							return;
						}
					}
					if (nextButtonWall.isDisplayed()) {
						clickElement(nextButtonWall);
					} else {
						throw new IllegalArgumentException(CANT_FIND + wallType + " after scrolling through all types.");
					}
				}
			} else if (!wallTypeTitles.isEmpty()) {
				for (WebElement title : wallTypeTitles) {
					if (getHiddenText(title).equals(wallType)) {
						clickElement(desiredWallType);
						return;
					}
				}
				throw new IllegalArgumentException(CANT_FIND + wallType + " within all listed types");
			} else {
				throw new NullPointerException("wallTypeTitles array is empty " + wallType.isEmpty());
			}
		} else {
			throw new IllegalArgumentException(CANT_FIND + wallType + " in the wallType map.");
		}
	}

	/**
	 * Enter phone number.
	 *
	 * @param number
	 */
	private void enterPhoneNumber(String number) {
		Log.info("Entering Phone Number: " + number);
		if (this.getPhoneNumber().equals(EMPTY_STRING)) {
			enterDataOnTextField(phoneNumber, number);
		}
	}

	private String getPhoneNumber() {
		return getElementValue(phoneNumber, "Phone number: ");
	}

	/**
	 * Enter When Your Home Was Originally Built.
	 *
	 * @param year
	 */
	protected void enterWhenYourHomeWasOriginallyBuilt(int year) {
		Log.info("Selecting When Your Home Was Originally Built: " + year);
		enterDataOnTextField(whenYourHomeWasOriginallyBuilt, String.valueOf(year));
	}

	/**
	 * Enter Square Footage.
	 *
	 * @param square
	 */
	protected void enterSquareFootage(String square) {
		Log.info("Entering Square Footage: " + square);
		enterDataOnTextField(squareFootage, square);
	}

	/**
	 * Select Dwelling Style.
	 *
	 * @param style
	 */
	protected void selectDwellingStyle(String style) {
		Log.info("Selecting Dwelling Style: " + style);
		selectOptionInDropDownField(dwellingStyleDropDown, style);
	}

	/**
	 * Select Number Of Full Bathrooms.
	 *
	 * @param numberOfBath
	 * @throws Exception
	 */
	private void selectNumberOfFullBathrooms(String numberOfBath) {
		Log.info("Selecting Number Of Full Bathrooms: " + numberOfBath);
		selectOptionInDropDownField(propNoOfFullBathsDropDown, numberOfBath);
	}

	/**
	 * Select Number Of Half Bathrooms.
	 *
	 * @param numberOfHalfBath
	 * @throws Exception
	 */
	private void selectNumberOfHalfBathrooms(String numberOfHalfBath)  {
		Log.info("Selecting Number Of Half Bathrooms: " + numberOfHalfBath);
		selectOptionInDropDownField(propNoOfHalfBathsDropDown, numberOfHalfBath);
	}

	/**
	 * Select Type Of Roof.
	 *
	 * @param typeOfRoof
	 * @throws IllegalArgumentException
	 */
	private void selectTypeOfRoof(String typeOfRoof) {
		Log.info("Selecting Type Of Roof: " + typeOfRoof);
		clickElement(homeTypeOfRoof);
		WebElement desiredTypeOfRoof = getTypesOfRoof().get(typeOfRoof);
		if (desiredTypeOfRoof != null) {
			if (!arrowNextBtn.isEmpty()) {
				while (nextButtonRoof.isEnabled()) {
					for (WebElement title : typeOfRoofTitles) {
						if (getTextFromElement(title).equals(typeOfRoof) && desiredTypeOfRoof.isEnabled()) {
							clickElement(desiredTypeOfRoof);
							return;
						}
					}
					if (nextButtonRoof.isDisplayed()) {
						clickElement(nextButtonRoof);
					} else {
						throw new IllegalArgumentException(CANT_FIND + typeOfRoof);
					}
				}
			} else if (!typeOfRoofTitles.isEmpty()) {
				for (WebElement title : wallTypeTitles) {
					if (getHiddenText(title).equals(typeOfRoof)) {
						clickElement(desiredTypeOfRoof);
						return;
					}
				}
				throw new IllegalArgumentException(CANT_FIND + typeOfRoof);
			} else {
				throw new NullPointerException("typeOfRoofTitles array is empty " + typeOfRoof.isEmpty());
			}
		} else {
			throw new IllegalArgumentException(CANT_FIND + typeOfRoof);
		}
	}

	/**
	 * Select How Old Is Your Roof.
	 *
	 * @param howOld
	 */
	private void selectHowOldIsYourRoof(String howOld) {
		Log.info("Selecting How Old Is Your Roof: " + howOld);
		selectOptionInDropDownField(howOldIsYourRoofDropDown, howOld);
	}

	/**
	 * Select Type Of Garage.
	 *
	 * @param typeOfGarage
	 */
	private void selectTypeOfGarage(String typeOfGarage) {
		Log.info("Selecting Type Of Garage: " + typeOfGarage);
		selectOptionInDropDownField(typeOfGarageDropDown, typeOfGarage);
	}

	/**
	 * Select Does Your Home Have Any Decks.
	 *
	 * @param anyDecks
	 */
	private void doesYourHomeHaveAnyDecks(boolean anyDecks) {
		Log.info("Selecting Does Your Home Have Any Decks: " + anyDecks);
		clickOnYesOrNoRadioButton(haveAnyDecksYesRadioButton, haveAnyDecksNoRadioButton, anyDecks);
	}

	/**
	 * Select Does Your Home Have Pool.
	 *
	 * @param havePool
	 */
	private void doesYourHomeHavePool(boolean havePool) {
		Log.info("Selecting Does Your Home Have A Pool: " + havePool);
		clickOnYesOrNoRadioButton(havePoolYesRadioButton, havePoolNoRadioButton, havePool);
	}

	/**
	 * Select Does Your Home Have A Basement.
	 *
	 * @param haveBasement
	 * @throws Exception
	 */
	private void doesYourHomeHaveBasement(boolean haveBasement) {
		Log.info("Selecting Does Your Home Have A Basement: " + haveBasement);
		scrollToElement(haveBasementYesRadioButton);
		clickOnYesOrNoRadioButton(haveBasementYesRadioButton, haveBasementNoRadioButton, haveBasement);
	}

	/**
	 * Select Does Your Home Have A Basement.
	 *
	 * @param haveConnected
	 */
	private void isYourHomeConnected(boolean haveConnected) {
		Log.info("Selecting Do you have a connected home?: " + haveConnected);
		clickOnYesOrNoRadioButton(haveConnectedYesRadioButton, haveConnectedNoRadioButton, haveConnected);
	}

	/**
	 * Select Permanent Storm Shutters.
	 *
	 * @param stormShutters
	 */
	private void selectPermanentStormShutters(boolean stormShutters) {
		Log.info("Selecting Permanent Storm Shutters: " + stormShutters);
		clickOnYesOrNoRadioButton(stormShuttersYesRadioButton, stormShuttersNoRadioButton, stormShutters);
	}

	/**
	 * Select What type of heating system is being currently used at your home.
	 *
	 * @param typeOfHeating
	 */
	protected void selectTypeOfHeatingSystemIsBeingCurrentlyUsed(String typeOfHeating) {
		Log.info("Selecting What type of heating system is being currently used at your home: " + typeOfHeating);
		selectOptionInDropDownField(typeOfHeatingDropDown, typeOfHeating);
	}

	/**
	 * Enter Email Address.
	 *
	 * @param email
	 */
	private void enterEmailAddress(String email) {
		Log.info("Entering Email Address: " + email);
		if (this.getEmailAddress().equals(EMPTY_STRING)) {
			enterDataOnTextField(emailAddressTextBox, email);
		}
	}

	private String getEmailAddress() {
		return getElementValue(emailAddressTextBox, "email address: ");
	}

	/**
	 * Select How Long Ago Was Your Last Property Claim.
	 *
	 * @param claim
	 */
	private void selectHowLongAgoWasYourLastPropertyClaim(String claim) {
		Log.info("Selecting How Long Ago Was Your Last Property Claim: " + claim);
		selectOptionInDropDownField(lastPropertyClaim, claim);
	}

	/**
	 * Click Continue Button.
	 *
	 */
	private void enterDataOnTextField(WebElement textEntryField, String data) {
		waitElementBeVisible(textEntryField);
		sendKeysToElement(textEntryField, data);
	}

	private void selectOptionInDropDownField(WebElement dropDown, String option) {
		waitElementBeVisible(dropDown);
		try {
			if (needToScrollElementIntoView()) {
				scrollToElement(dropDown);
			}
		} catch (Exception e) {
			Log.info ("Unable to scroll " + dropDown.toString() + " into view");
		}
		selectFromDropDown(dropDown, option);
	}

	private void clickOnYesOrNoRadioButton(WebElement yesRadioButton, WebElement noRadioButton, boolean clickOnYesButton) {
		if (clickOnYesButton) {
			waitAndClickElement(yesRadioButton);
		} else {
			waitAndClickElement(noRadioButton);
		}
	}

	private void clickAgreeAndContinueButton() {
		scrollAndClickOnElement(agreeAndContinueButton);
	}

	/**
	 * Get Map where Key is text box element and Value is error message associated with this text box.
	 * @return Map<WebElement,String>
	 *
	 */
	private LinkedHashMap<WebElement,List<String>> getMapWithErrorMessages() {
		Log.info("Getting Map with error messages");
		LinkedHashMap<WebElement, List<String>> errorMessages = new LinkedHashMap<>();
		errorMessages.put(lastPropertyClaim, new ArrayList<>(Collections.singletonList("How long ago was your last property claim? is a required field.")));
		errorMessages.put(whenYourHomeWasOriginallyBuilt, new ArrayList<>(Collections.singletonList("What year was your home originally built? is a required field.")));
		errorMessages.put(squareFootage, new ArrayList<>(Arrays.asList("Square Footage is a required field.","The square footage must be at least 100 square feet.")));
		errorMessages.put(homeExteriorWallType, new ArrayList<>(Collections.singletonList("Home Exterior Wall type is a required field.")));
		errorMessages.put(dwellingStyleDropDown, new ArrayList<>(Collections.singletonList("Dwelling style is a required field.")));
		errorMessages.put(typeOfGarageDropDown, new ArrayList<>(Collections.singletonList("Type of garage is a required field.")));
		errorMessages.put(typeOfHeatingDropDown,new ArrayList<>(Collections.singletonList("What type of heating system is being currently used at your home? is a required field.")));
		errorMessages.put(propNoOfFullBathsDropDown, new ArrayList<>(Collections.singletonList("Number of full bathrooms is a required field.")));
		errorMessages.put(propNoOfHalfBathsDropDown,new ArrayList<>(Collections.singletonList("Number of half bathrooms is a required field.")));
		errorMessages.put(howOldIsYourRoofDropDown, new ArrayList<>(Collections.singletonList("How old is your roof? is a required field.")));
		errorMessages.put(phoneNumber,new ArrayList<>(Arrays.asList("Phone number is a required field"," is not a valid entry.")));
		errorMessages.put(emailAddressTextBox, new ArrayList<>(Arrays.asList("Email address is a required field","Email address entered is invalid")));
		return errorMessages;
	}

	/**
	 * Get List with Property Page Elements.
	 * @return List<WebElement>
	 *
	 */
	private LinkedHashMap<WebElement, WebElement> getMapWithPropertyPageElements() {
		Log.info("Getting List with Property Page Elements");
		LinkedHashMap<WebElement, WebElement> elements = new LinkedHashMap<>();
		elements.put(lastPropertyClaim,lastpropLossError);
		elements.put(whenYourHomeWasOriginallyBuilt, propYearBuiltError);
		elements.put(squareFootage, propSqrFootageError);
		elements.put(homeExteriorWallType, exteriorWallTypeError);
		elements.put(dwellingStyleDropDown, propDwellingtypeError);
		elements.put(typeOfGarageDropDown, propGarageTypeError);
		elements.put(typeOfHeatingDropDown, priHeatingSysError);
		elements.put(propNoOfFullBathsDropDown, propNoOfFullBathsError);
		elements.put(propNoOfHalfBathsDropDown, propNoOfHalfBathsError);
		elements.put(howOldIsYourRoofDropDown, propAgeOfRoofError);
		elements.put(phoneNumber, phoneError);
		elements.put(emailAddressTextBox, emailError);
		return elements;
	}

	/**
	 * Clear What year was your home originally built? field.
	 *
	 */
	private void clearHomeOriginallyBuiltField() {
		Log.info("Clearing What year was your home originally built? field");
		whenYourHomeWasOriginallyBuilt.clear();
	}

	/**
	 * Clear Square Footage field.
	 *
	 */
	private void clearSquareFootageField() {
		Log.info("Clearing Square Footage field");
		squareFootage.clear();
	}

	/**
	 * Clear Drop Downs to "Please Select" option.
	 *
	 */
	private void clearDropDowns() throws Exception {
		Log.info("Clearing Drop Downs to Please Select option");
		setAttribute(homeTypeOfRoof,"value","Please Select");
		setAttribute(homeExteriorWallType,"value", "Please Select");
		selectFromDropDownByValue(dwellingStyleDropDown,EMPTY_STRING);
		selectFromDropDownByValue(propNoOfFullBathsDropDown,EMPTY_STRING);
		selectFromDropDownByValue(propNoOfHalfBathsDropDown,EMPTY_STRING);
		selectFromDropDownByValue(howOldIsYourRoofDropDown,EMPTY_STRING);
		selectFromDropDownByValue(typeOfGarageDropDown,EMPTY_STRING);
	}

	/**
	 * Get Map where Key is drop down element and Value is List of values associated with this drop down.
	 * @return Map<WebElement,List<String>>
	 *
	 */
	private Map<WebElement,List<String>> getMapWithDropDownsValues() {
		Log.info("Getting Map with drop downs values");
		Map<WebElement, List<String>> dropDownValues = new HashMap<>();
		dropDownValues.put(lastPropertyClaim, new ArrayList<>(Arrays.asList(PLEASE_SELECT,"None","Less than 3 years","3-5 years","More than 5 years")));
		dropDownValues.put(dwellingStyleDropDown, new ArrayList<>(Arrays.asList(PLEASE_SELECT,"1 Story","1 1/2 Stories","2 Story","2 1/2 Stories","3 Story","Bi-Level/Raised Ranch","Split Level")));
		dropDownValues.put(propNoOfFullBathsDropDown, new ArrayList<>(Arrays.asList(PLEASE_SELECT,"0","1","2","3","4","5","6","6+")));
		dropDownValues.put(propNoOfHalfBathsDropDown, new ArrayList<>(Arrays.asList(PLEASE_SELECT,"0","1","2","3","4","5","6","6+")));
		dropDownValues.put(howOldIsYourRoofDropDown,
				new ArrayList<>(Arrays.asList(PLEASE_SELECT,"0 Year","1 Year","2 Years","3 Years","4 Years","5 Years","6 Years","7 Years","8 Years","9 Years","10 Years","11 Years","12 Years","13 Years","14 Years"
						,"15 Years","16 Years","17 Years","18 Years","19 Years","20 Years","21 Years","22 Years","23 Years","24 Years","25 Years","26 Years","27 Years","28 Years","29 Years","30 or more Years", "I dont know")));
		dropDownValues.put(typeOfGarageDropDown, new ArrayList<>(Arrays.asList(PLEASE_SELECT,"1 Car Attached/Built-in","1 Car Carport","1 Car attached with Living Area Above","2 Car Attached/Built-in","2 Car Carport ","2 Car attached with Living Area Above","3 Car Attached/Built-in","3 Car Carport ","3 Car attached with Living Area Above","4 Car Attached/Built-in","4 Car Carport ","Detached","None")));
		dropDownValues.put(typeOfHeatingDropDown, new ArrayList<>(Arrays.asList(PLEASE_SELECT,"Coal","Electric","Gas","Kerosene","Oil","Other/Unknown","Wood")));
		return dropDownValues;
	}

	/**
	 * Get List with Property Page Drop Downs Elements.
	 * @return List<WebElement>
	 *
	 */
	private List<WebElement> getListWithPropertyPageDropDownsElements() {
		Log.info("Getting List with Property Page Drop Downs Elements");
		List<WebElement> elements = new ArrayList<>();
		elements.add(lastPropertyClaim);
		elements.add(dwellingStyleDropDown);
		elements.add(propNoOfFullBathsDropDown);
		elements.add(propNoOfHalfBathsDropDown);
		elements.add(howOldIsYourRoofDropDown);
		elements.add(typeOfGarageDropDown);
		elements.add(typeOfHeatingDropDown);
		return elements;
	}

	/**
	 * Get Map with Your Info Tool Tips Elements.
	 * @return Map<WebElement,WebElement>
	 *
	 */
	private Map<WebElement,WebElement> getMapWithPropertyPageToolTipsElements() {
		Log.info("Getting Map with Your Info Tool Tips Elements");
		Map<WebElement,WebElement> elements = new LinkedHashMap<>();
		elements.put(sqrFootageTT, sqrFootageTTClodeBtn);
		elements.put(extWallTypeTT, extWallTypeTTCloseBtn);
		elements.put(roofTypeTT, roofTypeTTCloseBtnt);
		elements.put(phoneTT, phoneTTCloseBtn);
		elements.put(emailTT, emailTTCloseBtn);
		return elements;
	}

	/**
	 * Get Map with Your Info Tool Tips Text.
	 * @return Map<WebElement,String>
	 *
	 */
	private Map<WebElement,LinkedHashMap<WebElement,String>> getMapWithToolTipsText() {
		Log.info("Getting Map with Your Info Page Tool Tips text");
		Map<WebElement, LinkedHashMap<WebElement,String>> mapToolTipsText = new LinkedHashMap<>();

		LinkedHashMap<WebElement, String> map1 = new LinkedHashMap<>();
		map1.put(sqrFootageTTText, "Total square footage of your residence.");

		LinkedHashMap<WebElement, String> map2 = new LinkedHashMap<>();
		map2.put(extWallTypeTTText, "Please select the type of material your home made from.");

		LinkedHashMap<WebElement, String> map3 = new LinkedHashMap<>();
		map3.put(roofTypeTTText, "Please select the primary type of material your roof is made from.");

		LinkedHashMap<WebElement, String> map4 = new LinkedHashMap<>();
		map4.put(phoneTTText, "Providing your phone number makes it easier for us to connect you with your personal agent, file any claim, or resolve an issue.");

		LinkedHashMap<WebElement, String> map5 = new LinkedHashMap<>();
		map5.put(emailTTText, "We'll email you your quote when it's complete, or you can use your email address to retrieve your quote during the process. We never share or sell your email address, and it will never be spammed.");

		mapToolTipsText.put(sqrFootageTT, map1);
		mapToolTipsText.put(extWallTypeTT, map2);
		mapToolTipsText.put(roofTypeTT, map3);
		mapToolTipsText.put(phoneTT, map4);
		mapToolTipsText.put(emailTT, map5);

		return mapToolTipsText;
	}

	private void verifyAgentSection(ApplicantHome applicant) throws Exception {
		Log.info("Asserting agent info is not displayed for political agent flow");
		List<WebElement> agentInfo = driver().findElements(By.id("agentName"));
		if (!agentInfo.isEmpty()) {
			Assert.assertFalse(agentNameLbl.isDisplayed(), "Agent name shouldn't be displayed if political agent flow is : " + applicant.isPoliticalFlowScenario());
		}
		agentInfo = driver().findElements(By.id("agentAddress"));
		if (!agentInfo.isEmpty()) {
			Assert.assertFalse(agentAddressLbl.isDisplayed(), "Agent address shouldn't be displayed if political agent flow is : " + applicant.isPoliticalFlowScenario());
		}
	}

	private void verifyNavBarTitle() {
		Log.info("Asserting navigation bar item title...");
		Assert.assertEquals(getTextFromElement(yourInfoNavBarText), "YOUR INFO", NAVIGATION_BAR_ITEM_NO_MATCH_MSG);
		Assert.assertEquals(getTextFromElement(propertyNavBarText), "PROPERTY", NAVIGATION_BAR_ITEM_NO_MATCH_MSG);
		Assert.assertEquals(getTextFromElement(coverageNavBarText), "COVERAGE", NAVIGATION_BAR_ITEM_NO_MATCH_MSG);
		Assert.assertEquals(getTextFromElement(quoteNavBarText), "QUOTE", NAVIGATION_BAR_ITEM_NO_MATCH_MSG);
		Assert.assertTrue(blueNavBar.isDisplayed(),"Blue navigation bar doesn't displayed ");
		Assert.assertTrue(homeHeaderLogo.isDisplayed(),"Header logo doesn't displayed ");
		Assert.assertEquals(getTextFromElement(completeThisInformationSubHeaderText), "Please complete this information about the property you want to insure \u2014 and verify its accuracy.", "Sub header text doesn't match ");
	}

	public ChooseYourCoveragePage propertyPageErrorValidationHome(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		clearHomeOriginallyBuiltField();
		clearSquareFootageField();
		clearDropDowns();
		clickAgreeAndContinueButton();
		verifyIsMissingFieldsErrorMessagesVisible(getMapWithErrorMessages(), getMapWithPropertyPageElements(), applicant);
		return enterPropertyInfo(applicant, fsa);
	}

	public void propertyPageValidationHome(FarmersSoftAssert fsa) throws Exception {
		waitElementBeVisible(lastPropertyClaim);
		verifyNavBarTitle();
		verifyHomeHelpLinks(getListWithHomeLOBFooterLinks(), getListWithHomeLOBFooterURLDestinationsTitle());
		verifyDropDownListValues(getListWithPropertyPageDropDownsElements(), getMapWithDropDownsValues(), fsa);
		verifyAllToolTipsInPage(getMapWithPropertyPageToolTipsElements(), getMapWithToolTipsText());
		checkAllURLsAndImages(findAllURLsAndImages());
	}

	public List<WebElement> getListWithPropertyPageElementsForInvalidInput() {
		Log.info("Getting List with property page page Elements");
		List<WebElement> elements = new ArrayList<>();
		elements.add(numberOfAdultsInHousehold);
		elements.add(whenYourHomeWasOriginallyBuilt);
		elements.add(squareFootage);
		elements.add(phoneNumber);
		elements.add(emailAddressTextBox);
		return elements;
	}

	private void verifyFooterStaticText() {
		String homePropertyStaticText = "By clicking \"Agree and submit\", you agree to these ESIGN terms and conditions and to receive marketing calls and texts as detailed below.";
		scrollToElement(footerStaticText);
		String footerText = getTextFromElement(footerStaticText);
		Log.info("Asserting footer static text:\n" + footerText);
		Assert.assertEquals(footerText, homePropertyStaticText, "Footer static text doesn't match");
	}

	protected void clickSaveFinishLaterButton() {
		Log.info("Clicking save finish later button");
		clickElement(saveAndFinishLaterBtn);
		clickVisitFcomButton();
	}

	private void clickVisitFcomButton() {
		Log.info("Clicking visit Farmers.com button");
		if (isElementPresentByID(visitFcomBtn)) {
			clickElement(visitFcomBtn);
		} else {
			clickElement(quoteHasBeenSavedOKButton);
		}
	}

	protected static synchronized void saveApplicantFinishLater(ApplicantHome applicant, String leftOnPage, String quoteNumber) {
		ApplicantRetQuote applicantRetQuote = new ApplicantRetQuote();
		applicantRetQuote.setLastName(applicant.getLastName());
		applicantRetQuote.setAge(applicant.getAge());
		applicantRetQuote.setZipCode(applicant.getZipCode());
		applicantRetQuote.setEmailAddress(applicant.getEmailAddress());
		applicantRetQuote.setQuoteNumber(quoteNumber);
		applicantRetQuote.setPageLeftOn(leftOnPage);
		returningQuoteConcurrentHashMap.put(applicant.getLastName() + applicant.getZipCode(), applicantRetQuote);
		Log.info("Successfully saved home quote for later in " + leftOnPage);
	}

	private List<WebElement> getListWithLabels(String applicantState) {
		Log.info("Getting List with labels elements");
		List<WebElement> labelElements = new ArrayList<>();
		labelElements.add(lastProplossLbl);
		labelElements.add(propDwellingtypeLbl);
		labelElements.add(propYearBuiltLbl);
		labelElements.add(propSqrFootageLbl);
		labelElements.add(exteriorWallTypeLbl);
		labelElements.add(propGarageTypeLbl);
		labelElements.add(priHeatingSysLbl);
		labelElements.add(propNoOfFullBathsLbl);
		labelElements.add(propNoOfHalfBathsLbl);
		labelElements.add(propRoofTypeLbl);
		labelElements.add(propAgeOfRoofLbl);
		if (hasDeckQuestion()) {
			labelElements.add(propDeckLbl);
			labelElements.add(propPoolLbl);
		}
		labelElements.add(propBasementLbl);
		labelElements.add(vivintSmartHomeLbl);
		if (isStormShutterState(applicantState)) {
			labelElements.add(stormShuttersLbl);
		}
		return labelElements;
	}

	/**
	 * Get Map where Key is text box element and Value is error message associated with this text box.
	 * @return Map<WebElement,String>
	 *
	 */
	private Map<WebElement,String> getMapWithExpLabels(String applicantState) {
		Log.info("Getting Map with expected labels");
		Map<WebElement,String> expLabelMap = new HashMap<>();

		expLabelMap.put(lastProplossLbl, "How long ago was your last property claim?");
		expLabelMap.put(propDwellingtypeLbl, "Dwelling style:");
		expLabelMap.put(propYearBuiltLbl, "What year was your home originally built?");
		expLabelMap.put(propSqrFootageLbl, "Square Footage:");
		expLabelMap.put(exteriorWallTypeLbl, "Home Exterior Wall type:");
		expLabelMap.put(propGarageTypeLbl, "Type of garage:");
		expLabelMap.put(priHeatingSysLbl, "What type of heating system is being currently used at your home?");
		expLabelMap.put(propNoOfFullBathsLbl, "Number of full bathrooms:");
		expLabelMap.put(propNoOfHalfBathsLbl, "Number of half bathrooms:");
		expLabelMap.put(propRoofTypeLbl, "Type of roof:");
		expLabelMap.put(propAgeOfRoofLbl, "How old is your roof?");
		if (hasDeckQuestion()) {
			expLabelMap.put(propDeckLbl, "Does your home have any decks?");
			expLabelMap.put(propPoolLbl, "Does your home have a pool?");
		}
		expLabelMap.put(propBasementLbl, "Does your home have a basement?");
		expLabelMap.put(vivintSmartHomeLbl, "Do you have a connected home?");
		if (isStormShutterState(applicantState)) {
			expLabelMap.put(stormShuttersLbl, "Permanent Storm Shutters");
		}
		return expLabelMap;
	}

	public boolean onPropertyPage() {
		waitForLegacySpinnerToBeGone();
		return isElementPresentByID(whenYourHomeWasOriginallyBuilt);
	}

	/**
	 * Add Applicant "Property Info" section. Handles every
	 * option and questions based on State.
	 *
	 * @param applicant
	 * @param fsa TODO
	 * @return DiscountsPageHome
	 * @throws Exception
	 */
	public ChooseYourCoveragePage enterPropertyInfo(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		screenCapture(homeHeaderLogo, "Home_PropertyPage", EMPTY_STRING, true);
		String homeQuoteNumber = getLegacyQuoteNumber();
		writeCreatedQuoteInformationToFile("HOME - " + homeQuoteNumber + SPACE + applicant.getFirstName() + SPACE + applicant.getLastName() + SPACE + applicant.getAddressApt() + SPACE + applicant.getCity() + SPACE + applicant.getStateCode() + SPACE + applicant.getZipCode() + NEWLINE);
		String applicantState = applicant.getState();
		verifyElementExpectedContent(getListWithLabels(applicantState), getMapWithExpLabels(applicantState), fsa);
		if (applicant.isDidNavBack()) {
			enterWhenYourHomeWasOriginallyBuilt(2018);
			enterSquareFootage("1000");
			selectNumberOfFullBathrooms("2");
			clickAgreeAndContinueButton();
			return new ChooseYourCoveragePage();
		}
		selectHowLongAgoWasYourLastPropertyClaim(applicant.getHowLongAgoWasYourLastPropertyClaim());
		if (applicant.isPoliticalFlowScenario()) {
			verifyAgentSection(applicant);
		}
		selectTypeOfHeatingSystemIsBeingCurrentlyUsed(applicant.getHeatingSystemIsBeingUsed());
		if (!applicant.isKeep360Prefill()) {
			selectDwellingStyle(applicant.getDwellingStyle());
			enterWhenYourHomeWasOriginallyBuilt(applicant.getWhenYourHomeWasOriginallyBuilt());
			enterSquareFootage(applicant.getSquareFootage());
			selectExteriorWallType(applicant.getHomeExteriorWallType());
			selectTypeOfGarage(applicant.getTypeOfGarage());
			selectNumberOfFullBathrooms(applicant.getNumberOfFullBathsRooms());
			selectTypeOfRoof(applicant.getTypeOfRoof());
			selectHowOldIsYourRoof(applicant.getHowOldIsYourRoof());
			doesYourHomeHaveBasement(applicant.isYourHomeHaveBasement());
			if (hasDeckQuestion()) {
				doesYourHomeHaveAnyDecks(applicant.isYourHomeHaveAnyDecks());
			}
		}
		selectNumberOfHalfBathrooms(applicant.getNumberOfHalfBathsRooms());
		if (expectPoolQuestion(applicant.getStateCode())) {
			doesYourHomeHavePool(applicant.isYourHomeHavePool());
		}
		isYourHomeConnected(applicant.isYourHomeConnected());
		if (isStormShutterState(applicantState)) {
			selectPermanentStormShutters(applicant.isPermanentStormShutters());
		}
		enterPhoneNumber(applicant.getPhoneNumber());
		enterEmailAddress(applicant.getEmailAddress());
		verifyFooterStaticText();
		if (applicant.isSaveAndRetrievePropPage() && findInCallStack(SAVE_AND_RETRIEVE_HOME_QUOTE)) {
			saveApplicantFinishLater(applicant, PROPERTY_PAGE_HOME, getLegacyQuoteNumber());
			clickSaveFinishLaterButton();
			waitElementBeVisible(addEmailToRetrieveQuote);
			addEmailToRetrieveQuote.sendKeys(applicant.getEmailAddress());
			clickElement(continueSavingQuote);
			return null;
		}
		clickAgreeAndContinueButton();
		waitForLegacySpinnerToBeGone();
		if (isLegacyQuoteKnockout()) {
			if (applicant.getTypeOfRoof().equals(COPPER) && applicantState.equals(NEW_YORK)) {
				waitElementBeVisible(yourQuoteReqSpecAttentTitle);
				Log.info(String.format("Asserting that if roof type is: %s and state is %s system should display \"Your quote requires special attention\" page", applicant.getTypeOfRoof(), applicantState));
				fsa.assertTrue(driver().getPageSource().contains(YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION), "Page doesn't contain: " + YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION + " text");
			} else if (applicant.getWhenYourHomeWasOriginallyBuilt() == OLDEST_HOME) {
				Log.info("Asserting oldest home: " + applicant.getWhenYourHomeWasOriginallyBuilt());
				waitElementBeVisible(weApologizeForInconvenienceText);
				fsa.assertTrue(getTextFromElement(weApologizeForInconvenienceText).contains(WE_APOLOGIZE_FOR_THE_INCONVENIENCE), WE_APOLOGIZE_FOR_THE_INCONVENIENCE + " text doesn't match");
			} else {
				fsa.fail("-- Home quote " + homeQuoteNumber + " for " + applicant + " stopped after property page because QUOTE KNOCKED OUT --");
			}
			return null;
		} else if (applicant.getLastName().contains(RECONSTRUCTION_COST_SCENARIO)) {
			if (isElementPresentByID(estReconstCostMsg)) {
				fsa.assertEquals(getTextFromElement(estReconstCostMsg), ESTIMATED_RECONSTRUCTION_COST_STATIC_TEXT, "Estimated reconstruction cost text doesn't match");
			} else {
				fsa.fail("Did not find Estimated reconstruction cost error message for " + applicant.getAddressApt() +  " in " + applicantState);
			}
			return null;
		}
		if (isElementVisible(estReconstCostMsg, 10)) {
			Log.warn("++ Home quote " + homeQuoteNumber + " for " + applicant + " stopped after property page because of reconstruction value ++");
			return null;
		}
		return new ChooseYourCoveragePage();
	}

	public void enterPropertyInfo(SqlAddress address) throws Exception {
		selectHowLongAgoWasYourLastPropertyClaim(NONE);
		if (address.getPropertyType().equalsIgnoreCase(HOUSE)) {
			selectDwellingStyle("2 Story");
		} else {
			selectDwellingStyle("Townhouse - Center Unit");
		}
		enterWhenYourHomeWasOriginallyBuilt(2014);
		enterSquareFootage("1000");
		selectExteriorWallType("Adobe");
		selectTypeOfGarage("1 Car Carport");
		selectTypeOfHeatingSystemIsBeingCurrentlyUsed("Gas");
		selectNumberOfFullBathrooms("1");
		selectNumberOfHalfBathrooms("1");
		selectTypeOfRoof("Slate");
		selectHowOldIsYourRoof("3 Years");
		if (hasDeckQuestion()) {
			doesYourHomeHaveAnyDecks(false);
		}
		if (expectPoolQuestion(address.getStateCode())) {
			doesYourHomeHavePool(false);
		}
		doesYourHomeHaveBasement(false);
		isYourHomeConnected(false);
		if (isStormShutterState(address.getStateName())) {
			selectPermanentStormShutters(false);
		}
		enterPhoneNumber("8189376643");
		enterEmailAddress("farmerstest2017@gmail.com");
		clickAgreeAndContinueButton();
		try {
			waitForLegacySpinnerToBeGone();
			wait.until(invisibilityOfElementLocated(By.id(getAttributeData(agreeAndContinueButton, LOWERCASE_ID))));
		} catch (NoSuchElementException nse) {
			Log.info("Should no longer be in Property page");
		}
		if (isLegacyQuoteKnockout()) {
			Assert.fail("-- Home quote knocked out after property page --");
		} else {
			ChooseYourCoveragePage coveragePage = new ChooseYourCoveragePage();
			clickElement(coveragePage.propertyNavBarText);
			waitForLegacySpinnerToBeGone();
			clickElement(yourInfoNavBarText);
		}
	}

	public ChooseYourCoveragePage validatePropertyPageHomeAndContinue(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		fsa.assertEquals(getLegacyQuoteNumber(), applicant.getApplicantRetQuote().getQuoteNumber(), "Quote number");
		return enterPropertyInfo(applicant, fsa);
	}

	private boolean isStormShutterState(String state) {
		List<String> stormShutterStates = new ArrayList<>(Arrays.asList(GEORGIA, NEW_JERSEY));
		return stormShutterStates.contains(state);
	}

	private boolean hasDeckQuestion() {
		return isElementPresentByID(propertyDeckQuestionSection);
	}

	private boolean expectPoolQuestion(String stateCode) {
		return stateCode.equals(NJ);
	}

	private boolean needToScrollElementIntoView() {
		return (Property.getDriver().equals(EDGE) || isSafariBrowser());
	}
}
