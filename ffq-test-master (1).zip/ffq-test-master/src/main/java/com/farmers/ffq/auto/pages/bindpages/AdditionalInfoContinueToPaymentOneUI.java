package com.farmers.ffq.auto.pages.bindpages;

import com.farmers.ffq.auto.pages.HeaderAndFooter;
import com.farmers.ffq.common.pages.PaymentSelectionBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.VerifyResponse.PaymentSchedule;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AdditionalInfoContinueToPaymentOneUI extends PaymentSelectionBasePage {
    private static final String CONTINUE_TO_PAYMENT_BUTTON = "Continue";

    // Pay in full xpath
    private static final String CARD_HEADER_XPATH = "//h2[@class='presentment-card-header-title tui-subtitle']";
    private static final String CARD_HEADER_DESCRIPTION_XPATH = "//p[@class='presentment-card-header-description tui-body-text-1']";
    private static final String CARD_INSTALLMENT_COUNT_XPATH = "//p[@class='tui-small-text tui-text-secondary']";
    private static final String CARD_DOLLAR_SIGN_TOP_XPATH = "//div[@class='tui-payplan']/div[1]";
    private static final String CARD_DOLLAR_AMOUNT_TOP_XPATH = "//div[@class='tui-payplan']/div[2]";
    private static final String CARD_CENT_AMOUNT_TOP_XPATH = "//div[@class='tui-payplan']/div[3]";
    private static final String CARD_GREEN_CHECK_XPATH = "//mat-icon[@class='mat-icon notranslate payment-overview-green-mark material-icons mat-icon-no-color']";
    private static final String CARD_SAVING_MESSAGE_XPATH = "//p[@class='tui-small-text payment-overview-icon-padding']";
    private static final String CARD_PAY_IN_FULL_SERVICE_CHARGE_XPATH = "//p[@class='tui-body-text-1 payment-overview-text ng-star-inserted']";
    private static final String CARD_SIX_MONTH_TERM_TOTAL_COST_XPATH = "//div[@class='tui-card-content-section']/p[1]";
    private static final String CARD_INCLUDES_ALL_FEES_XPATH = "//div[@class='tui-card-content-section']/p[2]";
    private static final String CARD_PAYMENT_METHOD_BOTTOM_XPATH = "//div[@class='tui-card-content-section']/p[3]";
    private static final String CARD_DOLLAR_SIGN_BOTTOM_XPATH = "//div[@class='tui-payplan payment-overview-card-subpremium-block ng-star-inserted']//span[1]";
    private static final String CARD_DOLLAR_AMOUNT_BOTTOM_XPATH = "//div[@class='tui-payplan payment-overview-card-subpremium-block ng-star-inserted']//span[2]";
    private static final String CARD_CENT_AMOUNT_BOTTOM_XPATH = "//div[@class='tui-payplan payment-overview-card-subpremium-block ng-star-inserted']//span[3]";
    private static final String VIEW_ALTERNATIVE_PAYMENT_PRICE_LINK = "//a[@id='viewCreditCardPrice']";


    @FindBy(xpath = "//div[contains(@class,'additional-info-submit-button')]//button")
    private WebElement continueToPaymentButton;

    @FindBy(xpath = "//a[contains(text(), 'change your coverage options')]/parent::*")
    private WebElement baseOnThirdPartyInfo;

    @FindBy(xpath = "//div[contains(@class, 'payment-overview-discount-name')]//span")
    private List<WebElement> paymentDiscountList;

    private static final String DISCOUNTS_INCLUDED = "discounts applied";
    @FindBy(xpath = "//p[contains(text(), '" + DISCOUNTS_INCLUDED + "')]")
    private WebElement discountsIncludedHeader;

    @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_BANK_HEADER + "')]")
    private List<WebElement> payInMonthlyPayBankHeader;

    @FindBy(xpath = "//mat-tab-header//div[contains(text(),'Monthly - bank')]")
    private WebElement monthlyBankPaymentTabHeader;

    @FindBy(xpath = "//mat-tab-header//div[contains(text(),'Monthly - card')]")
    private WebElement monthlyCardPaymentTabHeader;


    @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_CARD_HEADER + "')]")
    private List<WebElement> payInMonthlyPayCardHeader;

    // 6-month term total cost
    private static final String SIX_MONTH_TERM_TOTAL_COST = "6-month term total cost";
    @FindBy(xpath = "//p[contains(text(), '" + SIX_MONTH_TERM_TOTAL_COST + "')]")
    private List<WebElement> sixMonthTermTotalCost;

    @FindBy(xpath = "//h2[contains(text(), 'Pay in full')]")
    private WebElement payInFullH2WebElement;

    @FindBy(xpath = "//div[@class='row pif-autopay-main-payment-row']//h2")
    private WebElement paymentPageSubheader;

    @FindBy(xpath = "//div[@class='row pif-autopay-main-payment-row']//h2")
    private WebElement paymentPageAlternatePaymentMethodLink;

    @FindBy(xpath = "//div[contains(@class,'pif-autopay-details-bottom')]//span[2]")
    private WebElement paymentPageDueTodayAmount;

    @FindBy(css = "button[class='tui-btn tui-btn-primary ng-star-inserted']")
    private WebElement setUpPaymentMethod;

    @FindBy(xpath = "//app-price-update-dialog//h1")
    private WebElement priceUpdateContainerHeader;

    @FindBy(xpath = "//mat-dialog-content[@class='mat-dialog-content updated-price-content']/p[1]")
    private WebElement updatedPriceContentPaymentMethodText;

    @FindBy(xpath = "//mat-dialog-content[@class='mat-dialog-content updated-price-content']/ul")
    private WebElement updatedPriceContentPaymentMethod;

    @FindBy(xpath = "//mat-dialog-content[@class='mat-dialog-content updated-price-content']/p[2]")
    private WebElement updatePriceContainerReviewDisclaimer;

    @FindBy(xpath = "//mat-dialog-content[@class='mat-dialog-content updated-price-content']/p[3]")
    private WebElement updatePriceContainerEditDisclaimer;

    @FindBy(xpath = "//app-price-update-dialog//button")
    private WebElement updatePriceContainerOkButton;

    private static final String CHANGE_YOUR_COVERAGE_OPTION = "change your coverage options";
    private static final String CHANGE_YOUR_COVERAGE_XPATH = "//a[text() = '" + CHANGE_YOUR_COVERAGE_OPTION + "']";
    @FindBy(xpath = CHANGE_YOUR_COVERAGE_XPATH)
    private WebElement changeYourCoverageLink;

    private static final String CONVENIENT = "Convenient";
    @FindBy(xpath = "//p[contains(text(), '" + CONVENIENT + "')]")
    private WebElement convenientHeader;


    private static final String MONTHLY_AUTOPAY_HEADER = "Monthly Autopay";
    @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTOPAY_HEADER + "')]")
    private List<WebElement> monthlyAutoPayHeader;

    private static final String SIX_MONTHLY_PAYMENT = "6 monthly payments";
    @FindBy(xpath = "//p[contains(text(), '" + SIX_MONTHLY_PAYMENT + "')]")
    private WebElement sizMonthlyPayments;


    private static final String AUTO_PAY_SAVINGS = "Autopay savings";
    @FindBy(xpath = "//p[contains(text(), '" + AUTO_PAY_SAVINGS + "')]")
    private WebElement autoPaySavings;

    @FindBy(xpath = "//p[contains(.,'Bank payment') and contains(.,'$')]")
    private List<WebElement> bankPaymentAdministrationFee;

    @FindBy(xpath = "//p[contains(.,'Credit card')]")
    private List<WebElement> creditCardAdministrationFee;

    @FindBy(xpath = "//p[contains(.,'Debit card')]")
    private List<WebElement> debitCardAdministrationFee;

    @FindBy(xpath = "//li[@class='payment-overview-list-icon']//p[contains(text(),'Bank payment')]")
    private List<WebElement> bankPayment;


    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AdditionalInfoContinueToPaymentOneUI() throws Exception {
    }

    public void validatePurchasePage(FarmersSoftAssert fsa) throws Exception {
        //validateContinueToPaymentButton(sa);
        validateHeadersAndTextPurchaseSection(fsa);
        AppStore storageSessionOnPurchasePage = this.getSessionStorageAppStore();
        validatePurchaseDiscounts(storageSessionOnPurchasePage, fsa);

        //validate pay in full section
        validatePayInFullCardHeaderTextValidation(fsa);
        validatePayInFullAmountSection(storageSessionOnPurchasePage, fsa);
        clickSelectAndSetUpPayment(getSelectAndSetUpPaymentButtonForGivenPayMethod(PAY_IN_FULL), payInFullHeader, fsa);

        if(getSessionStorageAppStore().getData().getLandingStateCode().equals(NV)) {
            return;
        }
        // validate monthly pay - bank section
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(monthlyBankPaymentTabHeader);
        }
        validateMonthlyAutoPayBankTextsSection(storageSessionOnPurchasePage, fsa);
        validateAmountsInMonthlyAutoPayBank(storageSessionOnPurchasePage, fsa);
        clickSelectAndSetUpPayment(getSelectAndSetUpPaymentButtonForGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER), payInMonthlyPayBankHeader, fsa);

        // validate monthly pay - card section
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(monthlyCardPaymentTabHeader);
        }
        validateMonthlyAutoPayCardTextsSection(storageSessionOnPurchasePage, fsa);
        validateAmountsInMonthlyAutoPayCard(storageSessionOnPurchasePage, fsa);
        clickSelectAndSetUpPayment(getSelectAndSetUpPaymentButtonForGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER), payInMonthlyPayCardHeader, fsa);

        // validate down payments vs total
        validateTotalPremiumAmountAgainstInstallmentAmounts(storageSessionOnPurchasePage, fsa);

    }

    public void validatePreferredPaymentPlanChanges(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isOnContinueToPaymentPage(), "User successfully landed on the Payment page");
        String payInFullBankDebitCardXpath = getMatCardXpathByPaymentMethod(PAY_IN_FULL_BANK_DEBIT);

        // validate pay in full card with default bank or debit card payment
        WebElement payCardHeader = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_HEADER_XPATH));
        fsa.assertEquals(getTextFromElement(payCardHeader), PAY_IN_FULL_BANK_DEBIT, "Default bank and debit card header for " + PAY_IN_FULL_BANK_DEBIT);
        WebElement payCardHeaderDescription = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_HEADER_DESCRIPTION_XPATH));
        fsa.assertEquals(getTextFromElement(payCardHeaderDescription), BEST_VALUE_SUBHEADER, "Best value subheader for " + PAY_IN_FULL_BANK_DEBIT);
        WebElement installmentCount = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_INSTALLMENT_COUNT_XPATH));
        fsa.assertEquals(getTextFromElement(installmentCount), ONE_TIME_PAYMENT, "One time payment validation for " + PAY_IN_FULL_BANK_DEBIT);

        WebElement dollarSighTop = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_DOLLAR_SIGN_TOP_XPATH));
        WebElement dollarAmountTop = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_DOLLAR_AMOUNT_TOP_XPATH));
        WebElement centAmountTop = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_CENT_AMOUNT_TOP_XPATH));

        //TODO ask how to get the price diff for credit card
        AppStore.VerifyResponse verifyResponse = getAutoVerifyRateResponse();
        PaymentSchedule onePay = verifyResponse.getPaymentSchedules().stream().filter(each -> each.getPayPlan().equals("A1")).findFirst().get();
        double fullTermPremium = Double.parseDouble(onePay.getFullTermPremium());
        double policyFee = Double.parseDouble(verifyResponse.getPolicyFee().getAmount());

        String expectedDownPayment = String.format("$%s", getFormattedDecimal(fullTermPremium + policyFee));
        fsa.assertEquals(getTextFromElement(dollarSighTop) + getTextFromElement(dollarAmountTop) + getTextFromElement(centAmountTop), expectedDownPayment, "Top down payment amount for " + PAY_IN_FULL_BANK_DEBIT);
        WebElement selectAndSetUp = getSelectAndSetUpPaymentButtonForGivenPayMethod(PAY_IN_FULL_BANK_DEBIT);
        fsa.assertEquals(getTextFromElement(selectAndSetUp), SELECT_SETUP_PAYMENT, "Select and set up payment text validation for " + PAY_IN_FULL_BANK_DEBIT);
        WebElement greenCheckIcon = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_GREEN_CHECK_XPATH));
        fsa.assertTrue(greenCheckIcon.isDisplayed(), "Green check is displayed for " + PAY_IN_FULL_BANK_DEBIT);
        WebElement savingMessage = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_SAVING_MESSAGE_XPATH));
        fsa.assertEquals(getTextFromElement(savingMessage), PREFERRED_PAYMENT_PLAN_SAVINGS, PREFERRED_PAYMENT_PLAN_SAVINGS + " validation for " + PAY_IN_FULL_BANK_DEBIT);
        WebElement noServiceChargePayInFull = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_PAY_IN_FULL_SERVICE_CHARGE_XPATH));
        fsa.assertEquals(getTextFromElement(noServiceChargePayInFull), NO_SERVICE_CHARGE, NO_SERVICE_CHARGE + " validation for " + PAY_IN_FULL_BANK_DEBIT);
        WebElement sixMonthTermTotalCost = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_SIX_MONTH_TERM_TOTAL_COST_XPATH));
        fsa.assertEquals(getTextFromElement(sixMonthTermTotalCost), SIX_MONTH_TERM_TOTAL_COST, SIX_MONTH_TERM_TOTAL_COST + " validation for " + PAY_IN_FULL_BANK_DEBIT);
        WebElement includeAllFees = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_INCLUDES_ALL_FEES_XPATH));
        fsa.assertEquals(getTextFromElement(includeAllFees), INCLUDES_ALL_FEES, INCLUDES_ALL_FEES + " validation for " + PAY_IN_FULL_BANK_DEBIT);
        WebElement paymentMethod = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_PAYMENT_METHOD_BOTTOM_XPATH));
        fsa.assertEquals(getTextFromElement(paymentMethod), "Bank payment or debit card", "Payment method at the bottom of the card for " + PAY_IN_FULL_BANK_DEBIT);
        WebElement dollarSignBottom = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_DOLLAR_SIGN_BOTTOM_XPATH));
        WebElement dollarAmountBottom = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_DOLLAR_AMOUNT_BOTTOM_XPATH));
        WebElement centAmountBottom = driver().findElement(By.xpath(payInFullBankDebitCardXpath + CARD_CENT_AMOUNT_BOTTOM_XPATH));
        fsa.assertEquals(getTextFromElement(dollarSignBottom) + getTextFromElement(dollarAmountBottom) + getTextFromElement(centAmountBottom), expectedDownPayment, "Bottom full amount for " + PAY_IN_FULL_BANK_DEBIT);
        WebElement viewCreditPriceLink = driver().findElement(By.xpath(payInFullBankDebitCardXpath + VIEW_ALTERNATIVE_PAYMENT_PRICE_LINK));
        fsa.assertEquals(getTextFromElement(viewCreditPriceLink), VIEW_CREDIT_CARD_PRICE, "Alternative payment option link text for " + PAY_IN_FULL_BANK_DEBIT);

        waitAndClickElement(selectAndSetUp);

        fsa.assertEquals(getTextFromElement(waitElementBeVisible(paymentPageSubheader)), PAY_IN_FULL_BANK_DEBIT, "Page subheader after clicking select and set payment button for " + PAY_IN_FULL_BANK_DEBIT);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(paymentPageAlternatePaymentMethodLink)), VIEW_CREDIT_CARD_PRICE, "Page subheader after clicking select and set payment button for " + PAY_IN_FULL_BANK_DEBIT);
        fsa.assertEquals(getTextFromElement(paymentPageDueTodayAmount), expectedDownPayment, "Due today amount in the payment page for " + PAY_IN_FULL_BANK_DEBIT);
        waitAndClickElement(setUpPaymentMethod);
        fsa.assertTrue(getAttributeData(paymentusBankPaymentToggle, ARIA_SELECTED).equals(LOWERCASE_TRUE), "Bank toggle on the payment side sheet should be selected by default " + PAY_IN_FULL_BANK_DEBIT);
        addCheckingAccountPaymentMethod(PaymentMethods.BANK_ACCOUNT_1.getAccountNumber(), "12345");

        // changing to debit card, but we are not expecting price update pop up
        waitAndClickElement(changePaymentMethodLink);
        waitAndClickElement(paymentusDebitCreditCardToggleButton);
        String landingZipCode = getSessionStorageAppStore().getData().getLandingZipCode();
        addCardPaymentMethod(PaymentMethods.VISA_DEBIT_CARD_2.getAccountNumber(), landingZipCode);

        waitAndClickElement(changePaymentMethodLink);
        waitAndClickElement(paymentusDebitCreditCardToggleButton);
        addCardPaymentMethod(PaymentMethods.AMEX_CREDIT_CARD_1.getAccountNumber(), landingZipCode);

        //validate price update content(from Bank or Debit to Credit card)

        fsa.assertEquals(getTextFromElement(waitElementBeVisible(priceUpdateContainerHeader)), TOTAL_PRICE_UPDATED, "Price updated container header validation");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(updatedPriceContentPaymentMethodText)), PAYMENT_METHOD, "Payment method text validation");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(updatedPriceContentPaymentMethod)), CREDIT_CARD, "Credit card text validation");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(updatePriceContainerReviewDisclaimer)), "Please review and confirm your updated pricing as this method increases the total cost.", "Price updated container review disclaimer validation");

        fsa.assertEquals(getTextFromElement(waitElementBeVisible(updatePriceContainerEditDisclaimer)), "You can also edit your payment method to a bank payment or debit card for a lower total cost.", "Price updated container edit disclaimer validation");

        fsa.assertEquals(getTextFromElement(updatePriceContainerOkButton), "OK", "Ok button text validation for updated price pop up");
        waitAndClickElement(updatePriceContainerOkButton);


        //change back to debit validate the price update content
        waitAndClickElement(changePaymentMethodLink);
        addCardPaymentMethod(PaymentMethods.VISA_DEBIT_CARD_1.getAccountNumber(), landingZipCode);
        fsa.assertEquals(getTextFromElement(priceUpdateContainerHeader), TOTAL_PRICE_UPDATED, TOTAL_PRICE_UPDATED + " text validation");
        fsa.assertEquals(getTextFromElement(updatedPriceContentPaymentMethodText), PAYMENT_METHOD, PAYMENT_METHOD + " text validation");
        fsa.assertEquals(getTextFromElement(updatedPriceContentPaymentMethod), DEBIT_CARD, DEBIT_CARD + " text validation");
        fsa.assertEquals(getTextFromElement(updatePriceContainerReviewDisclaimer), "Great news! This method decreases your total cost", "Price decrease validation for changing to debit text validation");

    }

    public void validatePurchasePageHome(FarmersSoftAssert fsa, String lobType) throws Exception {
        validateHeadersAndTextPurchaseSection(fsa);
        AppStore storageSessionOnPurchasePage = this.getSessionStorageAppStore();
//        validatePurchaseDiscounts(storageSessionOnPurchasePage, sa);

        //validate pay in full section
        validatePayInFullCardHeaderTextValidation(fsa);
        validatePayInFullAmountSection(storageSessionOnPurchasePage, fsa);
        clickSelectAndSetUpPayment(getSelectAndSetUpPaymentButtonForGivenPayMethod(PAY_IN_FULL), payInFullHeader, fsa);

        // validate monthly pay - bank section
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(monthlyBankPaymentTabHeader);
        }
        validateMonthlyAutoPayBankTextsSection(storageSessionOnPurchasePage, fsa);
        validateAmountsInMonthlyAutoPayBank(storageSessionOnPurchasePage, fsa);
        clickSelectAndSetUpPayment(getSelectAndSetUpPaymentButtonForGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER), payInMonthlyPayBankHeader, fsa);

        // validate monthly pay - card section
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(monthlyCardPaymentTabHeader);
        }
        validateMonthlyAutoPayCardTextsSection(storageSessionOnPurchasePage, fsa);
        validateAmountsInMonthlyAutoPayCard(storageSessionOnPurchasePage, fsa);
        clickSelectAndSetUpPayment(getSelectAndSetUpPaymentButtonForGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER), payInMonthlyPayCardHeader, fsa);
//
//        // validate down payments vs total
//        validateTotalPremiumAmountAgainstInstallmentAmounts(storageSessionOnPurchasePage, sa);

    }


    private void validateTotalPremiumAmountAgainstInstallmentAmounts(AppStore storageSessionOnPurchasePage, FarmersSoftAssert fsa) throws Exception {
        validateFullTermPremiumAgainstInstallmentsForGivenPayPlan(storageSessionOnPurchasePage, MONTHLY_EFT, fsa);
        validateFullTermPremiumAgainstInstallmentsForGivenPayPlan(storageSessionOnPurchasePage, MONTHLY_DEBIT_CREDIT_CARD, fsa);
        validateFullTermPremiumAgainstInstallmentsForGivenPayPlan(storageSessionOnPurchasePage, MONTHLY_DEBIT_CARD_DESCRIPTION, fsa);
    }

    private void validateFullTermPremiumAgainstInstallmentsForGivenPayPlan(AppStore storageSessionOnPurchasePage, String payPlan, FarmersSoftAssert fsa) throws Exception {
        PaymentSchedule paymentScheduleForGivenPaymentPlan = filterListOfPaymentScheduleByPayPlan(getAutoVerifyRateResponse().getPaymentSchedules(), payPlan).get(0);
        double actualFullTermPremium = Double.parseDouble(paymentScheduleForGivenPaymentPlan.getFullTermPremium());
        double downPaymentForGivenPaymentPlan = Double.parseDouble(paymentScheduleForGivenPaymentPlan.getDownPayment().getAmount().getAmount());
        double totalInstallmentAmountsForGivenPaymentPlan = paymentScheduleForGivenPaymentPlan.getInstallments().stream().mapToDouble(installments -> Double.parseDouble(installments.getCurrencyAmount())).sum();
        double expectedTotalPremium = downPaymentForGivenPaymentPlan + totalInstallmentAmountsForGivenPaymentPlan;
        fsa.assertTrue(Math.abs(actualFullTermPremium - expectedTotalPremium) < 1, "Total premium amount vs installment calculations for " + payPlan + "Actual total premium => " + actualFullTermPremium + ", Expected calculated premium amount => " + expectedTotalPremium);
    }

    public void validateContinueToPaymentButton(FarmersSoftAssert fsa) {
        wait.until(ExpectedConditions.elementToBeClickable(continueToPaymentButton));
        fsa.assertTrue(continueToPaymentButton.isDisplayed(), "Continue To Payment Button displayed.");
        fsa.assertTrue(continueToPaymentButton.isEnabled(), "Continue To Payment Button enabled.");
        fsa.assertEquals(getTextFromElement(continueToPaymentButton), CONTINUE_TO_PAYMENT_BUTTON, "Continue To Payment button text verification");
        waitAndClickElement(continueToPaymentButton);
    }

    public void validateHeadersAndTextPurchaseSection(FarmersSoftAssert fsa) throws Exception {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(CHANGE_YOUR_COVERAGE_XPATH)));
        fsa.assertEquals(getTextFromElement(howWouldYouLikeToPay), HOW_WOULD_YOU_LIKE_TO_PAY, "How Would You Like To Play Header verification.");
        HeaderAndFooter pageHeaderAndFooter = new HeaderAndFooter();
        fsa.assertTrue(pageHeaderAndFooter.isPhoneNumberCorrectOnBindPages(), "Proper phone number present");
        //TODO: check  requirments for this
        //fsa.assertTrue(baseOnThirdPartyInfo.isDisplayed()," Based On Third Party Message Displayed.");
        //fsa.assertTrue(getTextFromElement(baseOnThirdPartyInfo).contains(BASE_ON_THIRD_PARTY_INFORMATION)," Based On Third Party Message verification.");
    }

    // validate purchase discounts
    public void validatePurchaseDiscounts(AppStore storageSessionOnPurchasePage, FarmersSoftAssert fsa) throws Exception {
        List<AppStore.VerifyResponse.Discount> discounts = getAutoVerifyRateResponse().getDiscounts();
        discounts = discounts.stream().filter(discount -> !discount.getName().contains("Vehicle History Factor")).collect(Collectors.toList());
        List<String> expectedDiscountNames = discounts.stream().map(each -> each.getName().replace("discount", EMPTY_STRING)).collect(Collectors.toList());

        List<String> displayedDiscountNames = getDisplayedDiscounts();
        String expectedDiscountsLabel = String.format(discounts.size() + SPACE + DISCOUNTS_INCLUDED.trim());
        fsa.assertEquals(getTextFromElement(discountsIncludedHeader), expectedDiscountsLabel, "Discount Included header verification");
        fsa.assertEquals(displayedDiscountNames, expectedDiscountNames, "Purchase discounts verification");
    }

    // validate Pay In Full Card header and text validation
    public void validatePayInFullCardHeaderTextValidation(FarmersSoftAssert fsa) throws Exception {
        WebElement selectAndSetUpPaymentButtonForGivenPayMethodForPayInFull = getSelectAndSetUpPaymentButtonForGivenPayMethod(PAY_IN_FULL);
        int index = isUseMobileViewEnabled() ? 0 : 1;
        fsa.assertEquals(getTextFromElement(payInFullHeader.get(index)), PAY_IN_FULL, "Pay In Full Header Text verification");
        fsa.assertEquals(getTextFromElement(bestValueSubHeader.get(index)), BEST_VALUE_SUBHEADER, "Best Value Sub Header Text verification");
        fsa.assertEquals(getTextFromElement(oneTimePaymentSubHeader.get(index)), ONE_TIME_PAYMENT, "One Time Payment Sub Header Text verification");
        fsa.assertEquals(getTextFromElement(preferredPayPlanSavings.get(index)), PREFERRED_PAYMENT_PLAN_SAVINGS, "Preferred Pay Plan Savings Text verification");
        fsa.assertEquals(getTextFromElement(noServiceChargeWhenPayInFull.get(index)), NO_SERVICE_CHARGE, "No Service Charge Text verification");
        fsa.assertEquals(getTextFromElement(bankDebitCreditCardPayment.get(index)), BANK_DEBIT_CREDIT_PAYMENT, "Bank Debit Credit Card Text verification");
        fsa.assertTrue(selectAndSetUpPaymentButtonForGivenPayMethodForPayInFull.isEnabled(), "Select And Set Up Payment Button Enabled for " + PAY_IN_FULL);
        fsa.assertEquals(getTextFromElement(selectAndSetUpPaymentButtonForGivenPayMethodForPayInFull), SELECT_SETUP_PAYMENT, "Select And Set Up Payment button text verification");
    }

    // validate amount in pay in full card validation
    public void validatePayInFullAmountSection(AppStore storageSessionOnPurchasePage, FarmersSoftAssert fsa) throws Exception {
        String downPayment = getDownPayment(storageSessionOnPurchasePage, ONE_PAY);
        Double doublePolicyFees = doublePolicyFeeAmount(getAutoVerifyRateResponse().getPolicyFee().getAmount());

        Double payInFullAmountAbovePart = doublePolicyFees + Double.parseDouble(downPayment);
        List<String> splitAmountByDecimalPoint = splitAmountByDecimalPoint(payInFullAmountAbovePart.toString());

        // Pay In Full One Time Payment Validation above part
        List<WebElement> listOfFullAmountWebElementsByDiv = listOfFullAmountWebElements(splitAmountByDecimalPoint.get(0), "div", false);
        isElementListSizeGreaterThanZero(listOfFullAmountWebElementsByDiv, "One Pay Full Amount Is Not Displayed.", fsa);

        // Pay In Full One Time Payment Validation below part
        List<WebElement> listOfFullAmountWebElementsBySpan = listOfFullAmountWebElements(splitAmountByDecimalPoint.get(0), "span", false);
        isElementListSizeGreaterThanZero(listOfFullAmountWebElementsBySpan, "One Pay Full Amount Below Is Not Displayed.", fsa);


        if (splitAmountByDecimalPoint.size() == 2) {
            List<WebElement> listOfDecimalOnePayWebElementByDiv = listOfFullAmountWebElements(splitAmountByDecimalPoint.get(1), "span", false);
            isElementListSizeGreaterThanZero(listOfDecimalOnePayWebElementByDiv, "One Pay Decimal Amount Is Not Displayed.", fsa);

            List<WebElement> listOfDecimalOnePayWebElementBySpan = listOfFullAmountWebElements(splitAmountByDecimalPoint.get(1), "span", false);
            isElementListSizeGreaterThanZero(listOfDecimalOnePayWebElementBySpan, "One Pay Decimal Amount Below Is Not Displayed.", fsa);
        }
    }

    public void clickSelectAndSetUpPayment(WebElement selectAndSetUpPayment, List<WebElement> elementToValidate, FarmersSoftAssert fsa) throws Exception {
        scrollToElement(selectAndSetUpPayment);
        waitAndClickElement(selectAndSetUpPayment);
        waitForSpinnerToBeGone();
        waitElementBeVisible(elementToValidate.get(0));
        isElementListSizeGreaterThanZero(elementToValidate, "Payment Card Element Is Not Displayed.", fsa);
        driver().navigate().back();
        isOnContinueToPaymentPage();
    }

    public void validateMonthlyAutoPayBankTextsSection(AppStore storageSessionOnPurchasePage, FarmersSoftAssert fsa) throws Exception {
        List<AppStore.VerifyResponse.Discount> discountNameLists = getAutoVerifyRateResponse().getDiscounts().stream().filter(c -> c.getReferenceCode().equals("PAAutoPayDiscount_Ext")).collect(Collectors.toList());
        if (discountNameLists.size() == 1) {
            fsa.assertEquals(getTextFromElement(getSavingsElementByGivenPayMethodCard(MONTHLY_AUTO_PAY_BANK_HEADER)), AUTO_PAY_SAVINGS, "Auto Pay Savings Text verification");
        }
        fsa.assertEquals(getTextFromElement(payInMonthlyPayBankHeader.get(0)), "Monthly autopay - bank", "Monthly pay bank card header verification");
        fsa.assertEquals(getTextFromElement(getPaymentCardSubHeaderByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER)), CONVENIENT, "Monthly pay bank card header subtitle validation");
        fsa.assertTrue(isElementPresent(By.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + "//p[contains(text(),'" + SIX_MONTHLY_PAYMENT + "')]")), SIX_MONTHLY_PAYMENT + " text present in monthly bank pay section");
        int administrativeFeeForGivenPayPlanDescription = getAdministrativeFeeForGivenPayPlanDescription(getAutoVerifyRateResponse().getPaymentSchedules(), MONTHLY_EFT);
        if (administrativeFeeForGivenPayPlanDescription == 0) {
            fsa.assertTrue(isElementPresent(By.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + "//p[contains(.,'" + NO_SERVICE_CHARGE + "')]")), NO_SERVICE_CHARGE + " text present in Monthly pay bank section");
        } else {
            String expectedFeeForBankPayment = String.format("$%d  monthly service charge", administrativeFeeForGivenPayPlanDescription);
            fsa.assertTrue(isElementPresent(By.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + "//p[contains(.,'" + expectedFeeForBankPayment + "')]")), expectedFeeForBankPayment + " text present for Monthly pay bank section");
        }
        fsa.assertTrue(isElementPresent(By.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + "//p[contains(text(), '" + SIX_MONTH_TERM_TOTAL_COST + "')]")), SIX_MONTH_TERM_TOTAL_COST + " text present in monthly pay bank section");
        // Getting the expected administrative fee amounts from performAutoVerify response
        fsa.assertTrue(isElementPresent(By.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + "//p[contains(text(),'" + BANK_PAYMENT + "')]")), "Bank payment text present in monthly bank pay section");
    }

    public void validateMonthlyAutoPayCardTextsSection(AppStore storageSessionOnPurchasePage, FarmersSoftAssert fsa) throws Exception {
        List<AppStore.VerifyResponse.Discount> discountNameLists = getAutoVerifyRateResponse().getDiscounts().stream().filter(c -> c.getReferenceCode().equals("PAAutoPayDiscount_Ext")).collect(Collectors.toList());
        if (discountNameLists.size() == 1) {
            fsa.assertEquals(getTextFromElement(getSavingsElementByGivenPayMethodCard(MONTHLY_AUTO_PAY_CARD_HEADER)), AUTO_PAY_SAVINGS, "Auto Pay Savings Text verification");
        }
        fsa.assertEquals(getTextFromElement(payInMonthlyPayCardHeader.get(0)), MONTHLY_AUTO_PAY_CARD_HEADER, "Monthly pay card card header verification");
        fsa.assertEquals(getTextFromElement(getPaymentCardSubHeaderByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER)), CONVENIENT, "Monthly pay card card header subtitle verification");
        String monthlyAutoPayCardSectionXpath = getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER);
        fsa.assertTrue(isElementPresent(By.xpath(monthlyAutoPayCardSectionXpath + "//p[contains(text(), '" + SIX_MONTH_TERM_TOTAL_COST + "')]")), SIX_MONTH_TERM_TOTAL_COST + " text present in monthly pay bank section");
        // Getting the expected administrative fee amounts from performAutoVerify response
        List<PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();

        int expectedMonthlyPayDebitCardAdministrativeFee = getAdministrativeFeeForGivenPayPlanDescription(paymentSchedules, MONTHLY_DEBIT_CARD_DESCRIPTION);
        int expectedMonthlyPayCreditCardAdministrativeFee = getAdministrativeFeeForGivenPayPlanDescription(paymentSchedules, MONTHLY_DEBIT_CREDIT_CARD);
        fsa.assertTrue(isElementPresent(By.xpath(monthlyAutoPayCardSectionXpath + "//p[contains(.,'" + MONTHLY_SERVICE_CHARGE + "')]")), MONTHLY_SERVICE_CHARGE + " text present in Monthly auto pay card section");
        String expectedMonthlyPayDebitCardAdministrativeFeeLabel = String.format("$%d:  Debit card", expectedMonthlyPayDebitCardAdministrativeFee);
        String expectedMonthlyPayCreditCardAdministrativeFeeLabel = String.format("$%d:  Credit card", expectedMonthlyPayCreditCardAdministrativeFee);

        fsa.assertTrue(isElementPresent(By.xpath(monthlyAutoPayCardSectionXpath + "//p[contains(.,'" + expectedMonthlyPayDebitCardAdministrativeFeeLabel + "')]")), "Monthly Debit Card Administrative/Service Fee amount: " + expectedMonthlyPayDebitCardAdministrativeFeeLabel);
        fsa.assertTrue(isElementPresent(By.xpath(monthlyAutoPayCardSectionXpath + "//p[contains(.,'" + expectedMonthlyPayCreditCardAdministrativeFeeLabel + "')]")), "Monthly Credit Card Administrative/Service Fee amount: " + expectedMonthlyPayCreditCardAdministrativeFeeLabel);
        fsa.assertTrue(isElementPresent(By.xpath(monthlyAutoPayCardSectionXpath + "//p[contains(text(), '" + SIX_MONTH_TERM_TOTAL_COST + "')]")), SIX_MONTH_TERM_TOTAL_COST + " text present in monthly pay bank section");
        fsa.assertTrue(isElementPresent(By.xpath(monthlyAutoPayCardSectionXpath + "//p[.='Debit card or Credit card ']")), "Debit card or Credit card text -at the bottom of the page- present in monthly bank pay section");

    }

    public void validateAmountsInMonthlyAutoPayBank(AppStore storageSessionOnPurchasePage, FarmersSoftAssert fsa) throws Exception {
        Double doublePolicyFees = doublePolicyFeeAmount(getAutoVerifyRateResponse().getPolicyFee().getAmount());
        String monthlyBankDownPayment = String.format("$%,.2f", Double.parseDouble(getDownPayment(storageSessionOnPurchasePage, MONTHLY_EFT)));
        List<PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        String fullTermPremium = paymentSchedules.stream().filter(paymentSchedule -> paymentSchedule.getPayPlanDescription().equals(MONTHLY_EFT)).collect(Collectors.toList()).stream().findFirst().get().getFullTermPremium();
        int administrativeFeeForGivenPayPlanDescription = getAdministrativeFeeForGivenPayPlanDescription(paymentSchedules, MONTHLY_EFT);
        String totalMonthlyBankPaymentAmount = String.format("$%,.2f", Double.parseDouble(fullTermPremium) + doublePolicyFees + (administrativeFeeForGivenPayPlanDescription * 5)).replace(SPACE, EMPTY_STRING);
        WebElement monthlyBankDownPaymentElement = driver().findElement(By.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + DOWN_PAYMENT_XPATH));
        fsa.assertEquals(getTextFromElement(monthlyBankDownPaymentElement).replace(SPACE, EMPTY_STRING), monthlyBankDownPayment, MONTHLY_AUTO_PAY_BANK_HEADER + " down payment amount validation");
        WebElement monthlyBankTotalAmountElement = driver().findElement(By.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER) + TOTAL_PAYMENT_OVERVIEW_CARD_PREMIUM_XPATH));
        fsa.assertEquals(getTextFromElement(monthlyBankTotalAmountElement).replace(SPACE, EMPTY_STRING), totalMonthlyBankPaymentAmount, MONTHLY_AUTO_PAY_BANK_HEADER + " total amount validation");
    }

    public void validateAmountsInMonthlyAutoPayCard(AppStore storageSessionOnPurchasePage, FarmersSoftAssert fsa) throws Exception {
        Double doublePolicyFees = doublePolicyFeeAmount(getAutoVerifyRateResponse().getPolicyFee().getAmount());
        String monthlyCardDownPayment = String.format("$%,.2f", Double.parseDouble(getDownPayment(storageSessionOnPurchasePage, MONTHLY_DEBIT_CARD_DESCRIPTION)));
        PaymentSchedule debitCardPaymentSchedule = getAutoVerifyRateResponse().getPaymentSchedules().stream().filter(paymentSchedule -> paymentSchedule.getPayPlanDescription().equals(MONTHLY_DEBIT_CARD_DESCRIPTION)).collect(Collectors.toList()).stream().findFirst().get();
        PaymentSchedule creditCardPaymentSchedule = getAutoVerifyRateResponse().getPaymentSchedules().stream().filter(paymentSchedule -> paymentSchedule.getPayPlanDescription().equals(MONTHLY_DEBIT_CREDIT_CARD)).collect(Collectors.toList()).stream().findFirst().get();
        String fullTermPremiumForDebitCard = debitCardPaymentSchedule.getFullTermPremium();
        String fullTermPremiumForCreditCard = creditCardPaymentSchedule.getFullTermPremium();
        Double totalMonthlyBankPaymentAmountForDebitCardDouble = Double.parseDouble(fullTermPremiumForDebitCard) + doublePolicyFees + (5 * Double.parseDouble(debitCardPaymentSchedule.getAdministrativeCharges().getCurrencyAmount()));
        Double totalMonthlyBankPaymentAmountForCreditCardDouble = Double.parseDouble(fullTermPremiumForCreditCard) + doublePolicyFees + (5 * Double.parseDouble(creditCardPaymentSchedule.getAdministrativeCharges().getCurrencyAmount()));
        ;

        String totalMonthlyBankPaymentAmountForDebitCard = String.format("$%,.2f", totalMonthlyBankPaymentAmountForDebitCardDouble);
        String totalMonthlyBankPaymentAmountForCreditCard = String.format("$%,.2f", totalMonthlyBankPaymentAmountForCreditCardDouble);
        WebElement monthlyBankDownPaymentElement = driver().findElement(By.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + DOWN_PAYMENT_XPATH));
        fsa.assertEquals(getTextFromElement(monthlyBankDownPaymentElement).replace(SPACE, EMPTY_STRING), monthlyCardDownPayment, MONTHLY_AUTO_PAY_CARD_HEADER + " down payment amount validation");
        WebElement monthlyCardTotalAmountElement = driver().findElement(By.xpath(getPaymentCardXPathByGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER) + TOTAL_PAYMENT_OVERVIEW_CARD_PREMIUM_XPATH));
        fsa.assertEquals(getTextFromElement(monthlyCardTotalAmountElement).replace(SPACE, EMPTY_STRING), totalMonthlyBankPaymentAmountForDebitCard, MONTHLY_AUTO_PAY_CARD_HEADER + " debit total amount validation");
        WebElement creditCardTotalElement = driver().findElement(By.xpath("//p[contains(@class,'tui-caption-text payment-overview-payment-debit-tex')]"));
        fsa.assertEquals(getTextFromElement(creditCardTotalElement).replace(SPACE, EMPTY_STRING).replace("Creditcard:", "Credit card: "), String.format("Credit card: %s", totalMonthlyBankPaymentAmountForCreditCard), MONTHLY_AUTO_PAY_CARD_HEADER + " credit card total amount validation");

    }

    public Double doubleFullTermPremium(PaymentSchedule monthlyEffPaymentSchedule) {
        String fullTermPremium = monthlyEffPaymentSchedule.getFullTermPremium();
        Double doubleFullTermPremium = 0.0;
        if (!fullTermPremium.equals("")) {
            doubleFullTermPremium = Double.parseDouble(fullTermPremium);
        }
        return doubleFullTermPremium;
    }

    public double calculateCreditDebitCardAmount(AppStore storageSessionOnPurchasePage, String payPlanDescription, Double doublePolicyFees) throws Exception {
        PaymentSchedule paymentSchedule = filterListOfPaymentScheduleByPayPlan(getAutoVerifyRateResponse().getPaymentSchedules(), payPlanDescription).get(0);
        Double fullTermPremiumCreditCard = doubleFullTermPremium(paymentSchedule);
        Double administrativeChargesCreditCard = Double.parseDouble(paymentSchedule.getAdministrativeCharges().getCurrencyAmount());
        return fullTermPremiumCreditCard + doublePolicyFees + 5 * administrativeChargesCreditCard;
    }

    public double calculateBankPaymentAmount(AppStore storageSessionOnPurchasePage, Double doublePolicyFees) throws Exception {
        PaymentSchedule monthlyEffPayPlanSchedule = filterListOfPaymentScheduleByPayPlan(getAutoVerifyRateResponse().getPaymentSchedules(), MONTHLY_EFT).get(0);
        Double doubleFullTermPremium = doubleFullTermPremium(monthlyEffPayPlanSchedule);
        Double administrativeFeeForFiveMonth = Double.parseDouble(monthlyEffPayPlanSchedule.getAdministrativeCharges().getCurrencyAmount()) * 5;
        return doubleFullTermPremium + doublePolicyFees + administrativeFeeForFiveMonth;
    }

    public void clickSelectAndSetUpPaymentPayInFull() throws Exception {
        if (isOnContinueToPaymentPage()) {
            clickElement(getSelectAndSetUpPaymentButtonForGivenPayMethod(PAY_IN_FULL));
        } else {
            throw new IllegalStateException("Quote not in Continue To Payment Page");
        }
    }

    public void clickSelectAndSetUpPaymentOption(String paymentOption) throws Exception {

        switch (paymentOption) {
            case PAY_IN_FULL:
                clickSelectAndSetUpPaymentPayInFull();
                break;
            case MONTHLY_AUTO_PAY_BANK_HEADER:
                clickSelectAndSetUpPaymentMonthlyPayBank();
                break;
            case MONTHLY_AUTO_PAY_CARD_HEADER:
                clickSelectAndSetUpPaymentMonthlyPayCard();
                break;
            default:
                Log.error("Please provide acceptable payment plan option");
        }
    }

    public boolean isOnContinueToPaymentPage() {
        return isElementVisible(consolidatedPaymentPageHeader, 45) || isElementVisible(consolidatedPaymentPageHeaderBw, 45);
    }

    public void clickSelectAndSetUpPaymentMonthlyPayBank() throws Exception {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(CHANGE_YOUR_COVERAGE_XPATH)));
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(monthlyBankPaymentTabHeader);
        }
        WebElement selectButtonForMonthlyBankPayment = getSelectAndSetUpPaymentButtonForGivenPayMethod(MONTHLY_AUTO_PAY_BANK_HEADER);
        scrollAndClickOnHiddenElement(selectButtonForMonthlyBankPayment);
        waitForSpinnerToBeGone();
    }

    public void clickSelectAndSetUpPaymentMonthlyPayCard() throws Exception {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(CHANGE_YOUR_COVERAGE_XPATH)));
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(monthlyCardPaymentTabHeader);
        }
        WebElement selectButtonForMonthlyCardPayment = getSelectAndSetUpPaymentButtonForGivenPayMethod(MONTHLY_AUTO_PAY_CARD_HEADER);
        scrollToElement(selectButtonForMonthlyCardPayment);
        waitAndClickElement(selectButtonForMonthlyCardPayment);
    }

    public void clickContinueToPaymentButton() throws Exception {
        sleep(5);
        scrollAndClickOnElement(continueToPaymentButton);
        waitForSpinnerToBeGone();
        if (isElementVisible(continueToPaymentButton, 5)){
        	scrollAndClickOnElement(continueToPaymentButton);
            waitForSpinnerToBeGone();
        }
    }

    public void waitForChangeYorCoverageXpathToBeClickable() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(CHANGE_YOUR_COVERAGE_XPATH)));
    }

    public boolean goToPaymentSummaryByClickingContinueButton() {
        waitAndClickElement(continueToPaymentButton);
        waitElementBeVisible(howWouldYouLikeToPay);
        return isExpectedTextDisplayed(howWouldYouLikeToPay, HOW_WOULD_YOU_LIKE_TO_PAY);
    }

    public boolean goToPaymentSummaryByClickingBackButton() throws Exception {
        driver().navigate().back();
        return isExpectedTextDisplayed(waitElementBeVisible(howWouldYouLikeToPay), HOW_WOULD_YOU_LIKE_TO_PAY);
    }

    public WebElement getSelectAndSetUpPaymentButtonForGivenPayMethod(String payMethod) throws Exception {
        By byObject = By.xpath(getMatCardXpathByPaymentMethod(payMethod) + "//button[contains(text(), 'Select & set up payment')]");
        return driver().findElement(byObject);
    }

    public WebElement getSavingsElementByGivenPayMethodCard(String payMethod) throws Exception {
        return driver().findElement(By.xpath(getPaymentCardXPathByGivenPayMethod(payMethod) + "//p[contains(@class, 'tui-small-text payment-overview-icon-padding')]"));

    }

    public String getMatCardXpathByPaymentMethod(String paymentMethod) {
    	return String.format("//div[contains(@class,'presentment-card-header d-none d-md-inline-flex')]//mat-card[contains(.,'%s')]", paymentMethod);
    }

    public void validateADA_PaymentSummaryPage() {
        isOnContinueToPaymentPage();
        if (isADATestingEnabled()) {
            performADATesting("PaymentSummaryPage", MARKETING_IT, ACE_AUTO);
        }
    }
}
