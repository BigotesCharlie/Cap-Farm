package com.farmers.ffq.auto.pages.bindpages;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Auto;
import com.farmers.ffq.datatransferobjects.AppStore.Auto.AppStoreVehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.RandomUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AdditionalInfoVehicleSectionOneUI extends AutoBasePage {

    public static String VEHICLE_SECTION_XPATH = "//div[contains(.,'%s') and contains(.,'%s') and contains(.,'%s')]";
    public final static String VEHICLE_VIN_INPUT_XPATH = "//input[@formcontrolname='vin']";
    public final static String LEASE_COMPANY_INPUT_XPATH = "//span[contains(.,'Enter leasing company')]/..//input";
    public final static String FINANCE_COMPANY_INPUT_XPATH = "//span[contains(.,'Enter loan company')]/..//input";

    @FindBy(xpath = "//p[contains(text(), 'When did you get this vehicle?')]")
    private List<WebElement> whenDidYouGetThisVehicleQuestion;

    @FindBy(xpath = "//mat-button-toggle[@value='lessThanTwo']")
    private List<WebElement> lessThanTwoYearsButton;

    @FindBy(xpath = "//mat-button-toggle[@value='twoToFive']")
    private List<WebElement> twoToFiveYearsAgoButton;

    @FindBy(xpath = "//mat-button-toggle[@value='aboveFive']")
    private List<WebElement> aboveFiveYearsButton;

    @FindBy(xpath = "//mat-label[contains(text(),'Enter loan company')]")
    List<WebElement> loanCompanyParentTextBoxElementList;


    private static final String ENTER_LOAN_COMPANY_ERROR = "Please enter loan company.";
    @FindBy(xpath = "//mat-error[contains(text(), 'Please enter loan company.')]")
    List<WebElement> enterLoanCompanyErrorElementList;

    private static final String ENTER_VALID_LOAN_COMPANY_ERROR = "Please select a valid loan company.";
    @FindBy(xpath = "//mat-error[contains(text(), 'Please select a valid loan company.')]")
    List<WebElement> enterValidLoanCompanyErrorElementList;

    @FindBy(xpath = "//mat-label[contains(text(),'Enter leasing company')]/ancestor::mat-form-field")
    List<WebElement> leasingCompanyParentTextBoxElementList;


    private static final String ENTER_LEASING_COMPANY_ERROR = "Please enter leasing company.";
    @FindBy(xpath = "//mat-error[contains(text(), 'Please enter leasing company.')]")
    List<WebElement> enterLeasingCompanyErrorElementList;

    private static final String ENTER_VALID_LEASING_COMPANY_ERROR = "Please select a valid leasing company.";
    @FindBy(xpath = "//mat-error[contains(text(), 'Please select a valid leasing company.')]")
    List<WebElement> enterValidLeasingCompanyErrorElementList;

    @FindBy(xpath = "//input[@aria-label='Vehicle Identification Number']")
    public List<WebElement> vinNumberTextBoxElementList;

    private static final String ENTER_VIN_NUMBER_ERROR = "Please enter the VIN.";
    @FindBy(xpath = "//mat-error[contains(text(), 'Please enter the VIN.')]")
    WebElement enterVinNumberErrorElement;


    private static final String PLEASE_ENTER_VALID_VIN = "Please enter a valid VIN.";
    @FindBy(xpath = "//mat-error[contains(text(), 'Please enter a valid VIN.')]")
    WebElement enterValidVinErrorElement;

    @FindBy(xpath = "//mat-error[contains(text(), 'formatted correctly.')]")
    WebElement vinIsNotFormattedCorrectly;

    private static final String WHY_DO_YOU_NEED_FINANCE_COMPANY_INFO = "Why do you need my finance company info?";
    @FindBy(xpath = "//p[contains(text(), 'Why do you need my finance company info?')]")
    List<WebElement> whyDoYouNeedMyFinanceCompanyInfo;

    @FindBy(xpath = "//h1[contains(text(), 'Why do you need my finance company info?')]")
    WebElement whyDoYouNeedMyFinanceCompanyInfoMB;

    private static final String WHY_DO_YOU_NEED_FINANCE_COMPANY_INFO_EXPLANATION = "Leasing and lending companies require us to list them on your policy, so they know you have the insurance they require.";
    @FindBy(xpath = "//p[contains(text(), 'Leasing and lending companies require us to list')]")
    List<WebElement> whyDoYouNeedMyFinanceCompanyInfoExplanation;

    private static final String WHERE_CAN_I_FIND_THE_VIN = "Where can I find the VIN?";
    @FindBy(xpath = "//p[contains(text(),'" + WHERE_CAN_I_FIND_THE_VIN + "')]")
    WebElement whereCanIFindTheVin;

    private static final String USE_THIS_GUIDE = "Use this guide";
    @FindBy(xpath = "//a[contains(text(),'" + USE_THIS_GUIDE + "')]")
    WebElement useThisGuide;

    private static final String USE_THIS_GUIDE_TEXT = "Use this guide to find your VIN (Vehicle Identification Number).";
    @FindBy(xpath = "//a[contains(text(),'" + USE_THIS_GUIDE + "')]/parent::p")
    WebElement useThisGuideText;
    private static final String HOW_TO_FIND_THE_VIN = "How to find the VIN";
    @FindBy(xpath = "//p[contains(text(), '" + HOW_TO_FIND_THE_VIN + "')]")
    WebElement howToFindVINLabel;

    private static final String USE_DRIVER_SIDE_DOOR = "Driver side door";
    @FindBy(xpath = "//p[contains(text(), '" + USE_DRIVER_SIDE_DOOR + "')]")
    WebElement driverSideDoorLabel;

    private static final String DASHBOARD_ON_DRIVER_SIDE_LABEL = "Dashboard on the driver side";
    @FindBy(xpath = "//p[contains(text(), '" + DASHBOARD_ON_DRIVER_SIDE_LABEL + "')]")
    WebElement dashboardOnDriverSideDoor;

    private static final String VIN_HELPER_IMG_1 = "Vin Helper Image 1";
    @FindBy(xpath = "//div[@title = '" + VIN_HELPER_IMG_1 + "']")
    WebElement vinHelperImg1;

    private static final String VIN_HELPER_IMG_2 = "Vin Helper Image 2";
    @FindBy(xpath = "//div[@title = '" + VIN_HELPER_IMG_2 + "']")
    WebElement vinHelperImg2;

    private static final String VIN_HELPER_IMG_3 = "Vin Helper Image 3";
    @FindBy(xpath = "//div[@title = '" + VIN_HELPER_IMG_3 + "']")
    WebElement vinHelperImg3;

    private static final String BACK_TO_VIN = "Back to VIN";
    @FindBy(xpath = "//button[contains(text(), '" + BACK_TO_VIN + "')]")
    WebElement backToVINButton;

    private static final String BACK_ARROW = "chevron_left";
    @FindBy(xpath = "//mat-icon[contains(text(), '" + BACK_ARROW + "')]")
    WebElement backArrowIconVINPopUp;

    private static final String CLOSE = "Close";
    @FindBy(xpath = "//button[contains(text(),'" + CLOSE + "')]")
    WebElement closeButton;

    @FindBy(xpath = "//mat-icon[contains(text(),'close')]")
    WebElement matIconCloseButton;

    @FindBy(xpath = "//button[contains(text(), 'Continue')]")
    private WebElement continueToPaymentButton;

    private static final String CONFIRM_YOUR_VIN = "Confirm your VIN";
    @FindBy(xpath = "//span[contains(text(),'" + CONFIRM_YOUR_VIN + "')]")
    WebElement confirmYourVINLabel;

    private static final String INITIALLY_QUOTED_VEHICLE_LABEL = "The vehicle initially quoted was specified as a:";
    @FindBy(xpath = "//span[contains(text(),'" + INITIALLY_QUOTED_VEHICLE_LABEL + "')]")
    WebElement initiallyQuotedVehicleLabel;

    private static final String NEWLY_ENTERED_VEHICLE_LABEL = "However, the VIN entered";
    @FindBy(xpath = "//p[contains(text(),'" + NEWLY_ENTERED_VEHICLE_LABEL + "')]")
    WebElement newlyEnteredVehicleLabel;

    private static final String PLEASE_SELECT_LABEL = "Please select:";
    @FindBy(xpath = "//span[contains(text(),'" + PLEASE_SELECT_LABEL + "')]")
    WebElement pleaseSelectLabel;

    @FindBy(xpath = "//li[contains(text(),'wrong, or')]")
    WebElement editVINIfItIsWrong;

    @FindBy(xpath = "//li[contains(text(),'update your quote')]")
    WebElement vINIsCorrect;

    private static final String EDIT_VIN_LINK = "Edit VIN";
    @FindBy(xpath = "//a[contains(text(),'" + EDIT_VIN_LINK + "')]")
    WebElement editVINLink;

    private static final String VIN_IS_CORRECT_LINK = "VIN is correct";
    @FindBy(xpath = "//a[contains(text(),'" + VIN_IS_CORRECT_LINK + "')]")
    public WebElement vinIsCorrectLink;

    @FindBy(xpath = "//div[contains(@class,'additional-info-vehicle-info-section') and contains(.,'VIN')]//mat-error")
    public List<WebElement> vinErrorMessage;

    private static final String ENTER_CORRECT_VIN = "Please enter the correct VIN for this vehicle.";
    @FindBy(xpath = "//mat-error[contains(text(),'" + ENTER_CORRECT_VIN + "')]")
    WebElement enterCorrectVINError;

    private static final String NINTH_DIGIT_NUM_OR_X = "The 9th digit must be a number or X only.";
    @FindBy(xpath = "//mat-error[contains(text(),'" + NINTH_DIGIT_NUM_OR_X + "')]")
    WebElement ninthDigitNumberOrTextError;

    @FindBy(xpath = "//div[contains(@class,'additional-info-vehicle-info-section')]//div[@class='col' and contains(.,'company')]//mat-icon")
    List<WebElement> vehicleLeaseOrFinanceMobileInfoIcons;

    @FindBy(xpath = "//div[contains(@class,'additional-info-vehicle-info-section')]//div[@class='col' and contains(.,'VIN')]//mat-icon")
    List<WebElement> vehicleVinMobileInfoIcons;

    @FindBy(xpath = "//mat-form-field[contains(.,'company')]//input")
    List<WebElement> leanOrLeaseInputFields;

    @FindBy(css = "input[formcontrolname='vin']")
    List<WebElement> vinInputFields;

    @FindBy(css = "mat-select[formcontrolname='registeredOwner']")
    List<WebElement> registeredOwnerDropDowns;

    @FindBy(xpath = "//mat-form-field[contains(.,'Current odometer')]//input")
    List<WebElement> currentOdometerFields;

    @FindBy(xpath = "//mat-form-field[contains(.,'Odometer reading date')]//input[not(contains(@class,'picker'))]")
    List<WebElement> odometerReadingDateInputFields;

    @FindBy(xpath = "//div[contains(@class,'odometer') and contains(.,'Current odometer')]//mat-error")
    WebElement currentOdometerErrorMessage;

    @FindBy(xpath = "//div[contains(@class,'odometer') and contains(.,'Odometer reading')]//mat-error")
    WebElement odometerDateErrorMessage;

    @FindBy(xpath = "//div[contains(@class,'odometer')]//mat-icon")
    List<WebElement> odometerMobileInfoIcon;

    @FindBy(xpath = "//p[contains(.,'What is an odometer?')]")
    List<WebElement> odometerInfoHeaderLabel;

    @FindBy(xpath = "//p[contains(.,'An odometer is a device')]")
    List<WebElement> odometerInfoHeaderDescription;

    @FindBy(css = "h1[class='model-caption-head']")
    WebElement mobileInfoModalHeader;

    @FindBy(css = "p[class='model-caption-text']")
    WebElement mobileInfoModalDesc;

    List<String> vinNumberList = Arrays.asList("JH4DC4450SS003654", "1C3EL55R16N152273", "JH4DB1650NS000627", "1GTFG15X891117544", "4T1BG22KXXU495725");

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AdditionalInfoVehicleSectionOneUI() throws Exception {
    }

    public void verifyVehicleSection(AppStore retrieveQuoteResponseSessionStorage, boolean enterValuesOnly, FarmersSoftAssert fsa) throws Exception {
        removeQualtricsPopUp();
        List<Auto.AppStoreVehicle> originalVehicleList = retrieveQuoteResponseSessionStorage.getAuto().getVehicles();
        List<Auto.AppStoreVehicle> vehicleListWithShowVehicleTrue = retrieveQuoteResponseSessionStorage.getAuto().getVehicles().stream().filter(s -> s.isShowVehicle()).collect(Collectors.toList());

        if (!vehicleListWithShowVehicleTrue.isEmpty()) {
            closeQualtricsPopUp();
            waitElementBeVisible(continueToPaymentButton, 10);
            List<Auto.AppStoreVehicle> listOfLoanVehicles = getListOfLoanVehicles(originalVehicleList);
            if (!listOfLoanVehicles.isEmpty()) {
                if (enterValuesOnly) {
                    enterLoanCompanyInformation(listOfLoanVehicles);
                } else {
                    verifyLoanCompanySection(listOfLoanVehicles, fsa);
                }
            }

            List<Auto.AppStoreVehicle> listOfLeasedVehicles = getListOfLeasedVehicles(originalVehicleList);
            if (!listOfLeasedVehicles.isEmpty()) {
                if (enterValuesOnly) {
                    enterLeasingCompanyInformation(listOfLeasedVehicles);
                } else {
                    verifyLeasingCompanySection(listOfLeasedVehicles, fsa);
                }
            }

            List<Auto.AppStoreVehicle> vehicleListWithoutVinNumber = getListOfVehicleWithoutVINNumber(originalVehicleList);
            if (!vehicleListWithoutVinNumber.isEmpty()) {
                if (enterValuesOnly) {
                    enterVINNumber(vehicleListWithoutVinNumber, fsa);
                } else {
                    verifyWhereCanIFindThisVinAndUseGuide(fsa);
                    verifyVinNumberSection(vehicleListWithoutVinNumber, fsa);
                }
             }
        }

        validateOdometerSection(fsa);
    }

    private void validateOdometerSection(FarmersSoftAssert fsa) {
    	int numberOfElements = currentOdometerFields.size();
        for (int i =0; i< numberOfElements; i++){
            WebElement currentOdometerInputField = currentOdometerFields.get(0);
            WebElement currentOdometerReadingDateField = odometerReadingDateInputFields.get(0);

            validateHelpInfoSectionForOdometer(fsa);

            //Validate error messages for Odometer reading input
            String emptyReadingErrorMessage = "Current odometer reading is required.";
            String invalidReadingErrorMessage = "Odometer should be between 1 and 999,999.";

            sendKeysToElement(currentOdometerInputField, "0");
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(currentOdometerErrorMessage)), invalidReadingErrorMessage, "Invalid odomoeter value check");

            // empty odometer reading field
            clearOutFieldUsingBackSpace(currentOdometerInputField);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(currentOdometerErrorMessage)), emptyReadingErrorMessage, "No odometer value check");

            String acceptableLowerEdge = currentDate.minusDays(365).format(dateTimeFormatter);
            String formattedToday = currentDate.format(dateTimeFormatter);

            // validate date field
            String invalidDateEntryErrorMessage = String.format("Date must be between %s and %s.", acceptableLowerEdge, formattedToday);
            String emptyFieldErrorMessage = "Odometer reading date is required.";
            clearOutFieldUsingBackSpace(currentOdometerReadingDateField);

            // one day before earlier acceptable date
            sendKeysToElement(currentOdometerReadingDateField, "12/31" + currentDate.minusYears(2).getYear());
            sendKeysToElement(currentOdometerReadingDateField, Keys.TAB);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(odometerDateErrorMessage)), invalidDateEntryErrorMessage, "One day before earliest acceptable date check");


            // tomorrow invalid
            sendKeysToElement(currentOdometerReadingDateField, currentDate.plusDays(1).format(dateTimeFormatter));
            sendKeysToElement(currentOdometerReadingDateField, Keys.TAB);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(odometerDateErrorMessage)), invalidDateEntryErrorMessage, "Using tomorrow check");

            //no entry error message
            clearOutFieldUsingBackSpace(currentOdometerReadingDateField);
            sendKeysToElement(currentOdometerReadingDateField, Keys.TAB);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(odometerDateErrorMessage)), emptyFieldErrorMessage, "Empty date field check");

            sendKeysToElement(currentOdometerInputField, "10000");
            sendKeysToElement(currentOdometerReadingDateField, formattedToday);

        }
    }

    private void validateHelpInfoSectionForOdometer(FarmersSoftAssert fsa) {
        String expectedInfoHeader = "What is an odometer?";
        String expectedInfoDesc = "An odometer is a device located on a vehicle's dashboard that displays a numerical value of the total distance the vehicle has traveled.";

    	int numberOfElements = odometerInfoHeaderLabel.size();
        for (int i =0; i< numberOfElements; i++){
            if (isUseMobileViewEnabled()) {
                waitAndClickElement(odometerMobileInfoIcon.get(i));
                fsa.assertEquals(getTextFromElement(mobileInfoModalHeader), expectedInfoHeader, "Odometer help title check for vehicle " + (i+1));
                fsa.assertEquals(getTextFromElement(mobileInfoModalDesc), expectedInfoDesc, "Odometer help content check for vehicle " + (i+1));
                waitAndClickElement(closeIconMB);
            } else {
                fsa.assertEquals(getTextFromElement(odometerInfoHeaderLabel.get(i)), expectedInfoHeader, "Odometer help title check for vehicle " + (i+1));
                fsa.assertEquals(getTextFromElement(odometerInfoHeaderDescription.get(i)), expectedInfoDesc, "Odometer help content check for vehicle " + (i+1));
            }
        }

    }

    public void fillOutVehicleSection_InvalidDetails() {
    	int numberOfElements = vinInputFields.size();
        for (int i =0; i< numberOfElements; i++){
            WebElement vinInputField = vinInputFields.get(i);
            scrollElementToMiddle(vinInputField);
            sendKeysToElement(vinInputField, "1111736373700");
            sendKeysToElement(vinInputField, Keys.TAB);
            waitForSpinnerToBeGone();
        }
    	numberOfElements = leanOrLeaseInputFields.size();
        for (int i =0; i< numberOfElements; i++){
            WebElement leasedOrLoanInputField = leanOrLeaseInputFields.get(i);
            scrollElementToMiddle(leasedOrLoanInputField);
            sendKeysToElement(leasedOrLoanInputField, "OOO");
            sleep(2);
        }
    }

    public void fillOutVehicleSectionAlternative() throws Exception {
        int numberOfElements = vinInputFields.size();
        for (int i = 0; i < numberOfElements; i++) {
            WebElement vinInputField = vinInputFields.get(i);
            scrollElementToMiddle(vinInputField);
            String randomVinNumber = getRandomVinNumber(5);
            if (!randomVinNumber.isEmpty()) {
                sendKeysToElement(vinInputField, randomVinNumber);
                sendKeysToElement(vinInputField, Keys.TAB);
                sleep(1);
                int retry = 3;
                while (!vinErrorMessage.isEmpty() && retry > 0) {
                    randomVinNumber = getRandomVinNumber(5);
                    sendKeysToElement(vinInputField, randomVinNumber);
                    sendKeysToElement(vinInputField, Keys.TAB);
                    retry--;
                }
                Log.info("Random Vin Number is entered on Additional Info Page: " + randomVinNumber);
                waitForSpinnerToBeGone();
                if (isElementVisible(vinIsCorrectLink, 10)) {
                    waitAndClickElement(vinIsCorrectLink);
                    waitForSpinnerToBeGone();
                    waitElementBeInvisible(vinIsCorrectLink);
                }
            }
        }

    	numberOfElements = leanOrLeaseInputFields.size();
        for (int i =0; i< numberOfElements; i++){
            WebElement leasedOrLoanInputField = leanOrLeaseInputFields.get(i);
            scrollElementToMiddle(leasedOrLoanInputField);
            sendKeysOneByOne(leasedOrLoanInputField, "SAAB");
            List<WebElement> loanOptions = driver().findElements(By.xpath("//mat-option[contains(.,'SAAB')]"));
            int tryCount = 0;
            if(loanOptions.isEmpty()) {
                leasedOrLoanInputField.clear();
                sendKeysOneByOne(leasedOrLoanInputField, "GM");
                loanOptions = driver().findElements(By.xpath("//mat-option[contains(.,'GM')]"));
                while (loanOptions.isEmpty() && tryCount < 4 ) {
                    List<String> bcdef = Arrays.asList("B", "C", "D", "E", "F");
                    loanOptions = driver().findElements(By.xpath(String.format("//mat-option[contains(.,'%s')]", bcdef.get(tryCount))));
                    tryCount++;
                }
            }
            waitAndClickElement(loanOptions.get(new Random().nextInt(loanOptions.size())));
            waitForSpinnerToBeGone();
            sleep(1);
        }

        // fill out registered owner section
    	numberOfElements = registeredOwnerDropDowns.size();
        for (int i =0; i< numberOfElements; i++){
            WebElement registeredOwnerDropDown = registeredOwnerDropDowns.get(i);
            String lastName = getSessionStorageAppStore().getData().getCustomerData().getLastName();
            selectValueInDropDown(registeredOwnerDropDown, lastName);
        }

        // fill out the when did you purchase section
        if (!whenDidYouGetThisVehicleQuestion.isEmpty()) {
            List<WebElement> toggleOptions = driver().findElements(By.xpath("//span[@class='additional-info-vehicle-purchase-date-options']/ancestor::mat-button-toggle"));
            if (!toggleOptions.isEmpty()) {
                WebElement randomToggleOption = toggleOptions.get(new Random().nextInt(toggleOptions.size()));
                scrollElementToMiddle(randomToggleOption);
                clickElement(randomToggleOption);
            }
        }

        if (getSessionStorageAppStore().getData().getLandingStateCode().equals(CA)) {
        	numberOfElements = currentOdometerFields.size();
            for (int x =0; x< numberOfElements; x++){
                int randomOdometer = RandomUtils.nextInt(10_00, 200_001);
                scrollAndClickOnElement(currentOdometerFields.get(x));
                sendKeysToElement(currentOdometerFields.get(x), randomOdometer);
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                String formattedDate = currentDate.minusDays(1).format(formatter);
                scrollToElement(odometerReadingDateInputFields.get(x));
                sendKeysToElement(odometerReadingDateInputFields.get(x), formattedDate);
            }
        }

    }

    List<Auto.AppStoreVehicle> getListOfVehicleWithoutPurchaseDate(List<Auto.AppStoreVehicle> vehicleList) {
        List<AppStoreVehicle> listOfVehicleWithoutPurchaseDate = vehicleList.stream().filter(item -> item.getPurchaseDate() == "").collect(Collectors.toList());
        return listOfVehicleWithoutPurchaseDate;
    }

    List<AppStoreVehicle> getListOfVehicleGreaterThanThree(List<Auto.AppStoreVehicle> vehicleList) {
        int currentYear = LocalDate.now().getYear();
        List<Auto.AppStoreVehicle> listOfVehicleGreaterThanThree = vehicleList.stream().filter(item -> currentYear - Integer.parseInt(item.getYear()) > 3).collect(Collectors.toList());
        return listOfVehicleGreaterThanThree;
    }

    List<Auto.AppStoreVehicle> getListOfLeasedVehicles(List<Auto.AppStoreVehicle> originalVehicleList) {
        List<Auto.AppStoreVehicle> listOfLeasedVehicles = originalVehicleList.stream().filter(item -> item.getLnLrCompany() == null && item.getVehicleIsOn().equals("LR")).collect(Collectors.toList());
        return listOfLeasedVehicles;
    }

    List<Auto.AppStoreVehicle> getListOfLoanVehicles(List<Auto.AppStoreVehicle> originalVehicleList) {
        List<AppStoreVehicle> listOfLoanVehicles = originalVehicleList.stream().filter(item -> item.getLnLrCompany() == null && item.getVehicleIsOn().equals("LN")).collect(Collectors.toList());
        return listOfLoanVehicles;
    }

    List<Auto.AppStoreVehicle> getListOfVehicleWithoutVINNumber(List<Auto.AppStoreVehicle> originalVehicleList) {
        List<Auto.AppStoreVehicle> listOfVehicleWithoutVIN = originalVehicleList.stream().filter(item -> item.getVin().equals(EMPTY_STRING)).collect(Collectors.toList());
        return listOfVehicleWithoutVIN;
    }

    private void verifyLoanCompanySection(List<AppStoreVehicle> listOfLoanVehicles, FarmersSoftAssert fsa) throws Exception {
        int numberOfElements = Math.min(loanCompanyParentTextBoxElementList.size(), listOfLoanVehicles.size());
        for (int i = 0; i < numberOfElements; i++) {
            verifyWhyDoYouNeedMyFinanceCompanyInfo(fsa);
            WebElement loanInputBox = loanInputBoxWebElement(i);
            scrollOffsetClickOnElement(loanInputBox);

            // just tab out of loan company input box and validate error
            loanInputBox.sendKeys(Keys.chord(Keys.TAB));
            waitElementBeVisible(enterLoanCompanyErrorElementList.get(i));
            fsa.assertEquals(getTextFromElement(enterLoanCompanyErrorElementList.get(i)), ENTER_LOAN_COMPANY_ERROR, "Loan Company Error check");

            // enter the random value in loan company input box and validate error
            waitAndClickElement(loanInputBox);
            sendKeysOneByOne(loanInputBox, "ABC");
            loanInputBox.sendKeys(Keys.chord(Keys.TAB));
            waitElementBeVisible(enterValidLoanCompanyErrorElementList.get(i));
            fsa.assertEquals(getTextFromElement(enterValidLoanCompanyErrorElementList.get(i)), ENTER_VALID_LOAN_COMPANY_ERROR, "Valid Loan Company Error check");

            // select the option from loan company name dropdown values
            scrollAndClickOnHiddenElement(loanInputBox);
            loanInputBox.clear();
            sendKeysOneByOne(loanInputBox, "S");
            List<WebElement> loanOptionsFromDropDown = loanOrLeasedDropDownOptions();
            waitElementBeVisible(loanOptionsFromDropDown.get(0));
            clickElement(loanOptionsFromDropDown.get(0));
            removeQualtricsPopUp();
        }
    }


    private void verifyLeasingCompanySection(List<Auto.AppStoreVehicle> listOfLoanVehicles, FarmersSoftAssert fsa) throws Exception {
        for (int i = 0; i < listOfLoanVehicles.size(); i++) {
            verifyWhyDoYouNeedMyFinanceCompanyInfo(fsa);
            WebElement leasedInputBox = leasingInputBoxWebElement(i);
            scrollOffsetClickOnElement(leasedInputBox);

            // just tab out of leasing company input box and validate error
            leasedInputBox.sendKeys(Keys.chord(Keys.TAB));
            waitElementBeVisible(enterLeasingCompanyErrorElementList.get(i));
            fsa.assertEquals(getTextFromElement(enterLeasingCompanyErrorElementList.get(i)), ENTER_LEASING_COMPANY_ERROR, "Enter Leasing Company Error check");

            // enter the random value in leasing company input box and validate error
            leasedInputBox.click();
            sendKeysOneByOne(leasedInputBox, "ABC");
            leasedInputBox.sendKeys(Keys.chord(Keys.TAB));
            waitElementBeVisible(enterValidLeasingCompanyErrorElementList.get(i));
            fsa.assertEquals(getTextFromElement(enterValidLeasingCompanyErrorElementList.get(i)), ENTER_VALID_LEASING_COMPANY_ERROR, "Valid Leased Company Error check");

            // select the option from leasing company name dropdown values
            leasedInputBox.click();
            leasedInputBox.clear();
            sendKeysOneByOne(leasedInputBox, "S");
            List<WebElement> loanOptionsFromDropDown = loanOrLeasedDropDownOptions();
            loanOptionsFromDropDown.get(0).click();
        }
    }

    private void verifyVinNumberSection(List<Auto.AppStoreVehicle> vehicleListWithoutVinNumber, FarmersSoftAssert fsa) throws Exception {
        for (int i = 0; i < vehicleListWithoutVinNumber.size(); i++) {

            //  tab out from VIN number section and validate error
            scrollOffsetClickOnElement(vinNumberTextBoxElementList.get(i));
            waitAndClickElement(vinNumberTextBoxElementList.get(i));
//            vinNumberTextBoxElementList.get(i).click();
            vinNumberTextBoxElementList.get(i).sendKeys(Keys.chord(Keys.TAB));
            fsa.assertEquals(getTextFromElement(enterVinNumberErrorElement), ENTER_VIN_NUMBER_ERROR, "Enter VIN Number Error check");

            // enter random value and validate error
            waitAndClickElement(vinNumberTextBoxElementList.get(i));
            //vinNumberTextBoxElementList.get(i).click();
            sendKeysOneByOne(vinNumberTextBoxElementList.get(i), "AB");
            vinNumberTextBoxElementList.get(i).sendKeys(Keys.chord(Keys.TAB));
            fsa.assertEquals(getTextFromElement(enterValidVinErrorElement), PLEASE_ENTER_VALID_VIN, "Enter VIN Number Error check");

//            vinNumberTextBoxElementList.get(i).click();
            waitAndClickElement(vinNumberTextBoxElementList.get(i));
            vinNumberTextBoxElementList.get(i).sendKeys(Keys.chord(Keys.BACK_SPACE, Keys.BACK_SPACE));

            // enter invalid format VIN and validate the error
            sendKeysOneByOne(vinNumberTextBoxElementList.get(i), "Ah689765ty45re4rt");
            vinNumberTextBoxElementList.get(i).sendKeys(Keys.chord(Keys.TAB));
            fsa.assertTrue(vinIsNotFormattedCorrectly.isDisplayed(), "VIN is not formatted correctly message displayed");

//            fsa.assertEquals(getTextFromElement(vinIsNotFormattedCorrectly), VIN_IS_NOT_FORMATTED_CORRECTLY, "VIN is not formatted correctly message check");

            // enter the valid VIN number
            clearVinNumberInputBox(vinNumberTextBoxElementList.get(i));

            // get the random VIN and enter in VIN number field
            String randomVinNumber = "WDBTK56F07T078334";
            sendKeysOneByOne(vinNumberTextBoxElementList.get(i), randomVinNumber != null ? randomVinNumber : "2HNYD18222H543555");
            vinNumberTextBoxElementList.get(i).sendKeys(Keys.chord(Keys.TAB));
            validateEditVINNumberPopUp(vehicleListWithoutVinNumber.get(i), EDIT_VIN_LINK, fsa);
            fsa.assertEquals(getTextFromElement(enterCorrectVINError), ENTER_CORRECT_VIN, "Enter Correct VIN Error Text check");

            clearVinNumberInputBox(vinNumberTextBoxElementList.get(i));
            // randomVinNumber = getRandomVinNumber();
            sendKeysOneByOne(vinNumberTextBoxElementList.get(i), vinNumberList.get(i));
            vinNumberTextBoxElementList.get(i).sendKeys(Keys.chord(Keys.TAB));
            validateEditVINNumberPopUp(vehicleListWithoutVinNumber.get(i), VIN_IS_CORRECT_LINK, fsa);
            removeQualtricsPopUp();
        }
    }

    private void verifyWhyDoYouNeedMyFinanceCompanyInfo(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(whyDoYouNeedMyFinanceCompanyInfo.get(0)), WHY_DO_YOU_NEED_FINANCE_COMPANY_INFO, "Why Do You Need My Finance Company Info Question check");
        fsa.assertEquals(getTextFromElement(whyDoYouNeedMyFinanceCompanyInfoExplanation.get(0)), WHY_DO_YOU_NEED_FINANCE_COMPANY_INFO_EXPLANATION, "Why Do You Need My Finance Company Info Question check");

        // test the mobile break point
        if (isUseMobileViewEnabled()) {
            vehicleLeaseOrFinanceMobileInfoIcons.get(0).click();
            fsa.assertEquals(getTextFromElement(whyDoYouNeedMyFinanceCompanyInfoMB), WHY_DO_YOU_NEED_FINANCE_COMPANY_INFO, "Why Do You Need My Finance Company Info Question check");
            fsa.assertEquals(getTextFromElement(whyDoYouNeedMyFinanceCompanyInfoExplanation.get(1)), WHY_DO_YOU_NEED_FINANCE_COMPANY_INFO_EXPLANATION, "Why Do You Need My Finance Company Info Question in Mobile break point");
            closeIconMB.click();
        }
    }

    private void verifyWhereCanIFindThisVinAndUseGuide(FarmersSoftAssert fsa) {
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(vehicleVinMobileInfoIcons.get(0));
        } else {
            fsa.assertTrue(getTextFromElement(whereCanIFindTheVin).equals(WHERE_CAN_I_FIND_THE_VIN), "Where can I find the VIN is not available");
            fsa.assertTrue(useThisGuide.isDisplayed(), "Use this guide link is not displayed");
            fsa.assertTrue(getTextFromElement(useThisGuideText).equals(USE_THIS_GUIDE_TEXT), "Use this guide text is not matching");
            waitAndClickElement(useThisGuide);
        }
        // validate content of How to find VIN pop up modal box
        fsa.assertTrue(getTextFromElement(howToFindVINLabel).equals(HOW_TO_FIND_THE_VIN), "How to find VIN label text is not matching");
        fsa.assertTrue(backArrowIconVINPopUp.isDisplayed(), "Back arrow icon is not displayed");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(driverSideDoorLabel)), USE_DRIVER_SIDE_DOOR, "Driver side door label text is not matching");
        fsa.assertTrue(isExpectedTextContainedInElement(waitElementBeVisible(dashboardOnDriverSideDoor), DASHBOARD_ON_DRIVER_SIDE_LABEL), "Dashboard on driver side door label text is not matching");
        fsa.assertTrue(vinHelperImg1.isDisplayed(), "Vin helper image 1 is not displayed");
        fsa.assertTrue(vinHelperImg2.isDisplayed(), "Vin helper image 2 is not displayed");
        fsa.assertTrue(vinHelperImg3.isDisplayed(), "Vin helper image 3 is not displayed");
        fsa.assertTrue(getTextFromElement(backToVINButton).contains(BACK_TO_VIN), "Back to VIN button text is not matching");
        waitAndClickElement(backToVINButton);
    }

    private void validateEditVINNumberPopUp(Auto.AppStoreVehicle vehicle, String buttonText, FarmersSoftAssert fsa) throws Exception {
        waitElementBeVisible(confirmYourVINLabel);
        fsa.assertTrue(getTextFromElement(confirmYourVINLabel).contains(CONFIRM_YOUR_VIN), "Confirm Your VIN Label Is Not Correct");

        fsa.assertTrue(getTextFromElement(initiallyQuotedVehicleLabel).contains(INITIALLY_QUOTED_VEHICLE_LABEL), "Initially Quoted Vehicle Label Text Is Not Matching");
        String existingVehicleDescription = vehicle.getVehicleSelected();
        String existingVehicleXpath = "//li[contains(text(),'" + existingVehicleDescription + "')]";
        WebElement existingVehicleWebElement = driver().findElement(By.xpath(existingVehicleXpath));
        fsa.assertTrue(existingVehicleWebElement.isDisplayed(), "Existing Vehicle Description Is Not Matching");
        fsa.assertTrue(getTextFromElement(newlyEnteredVehicleLabel).contains(NEWLY_ENTERED_VEHICLE_LABEL), "Newly Entered Vehicle Label Text Is Not Matching");

        AppStore retrieveQuoteResponseSessionStorage = getSessionStorageAppStore();
        Auto.VinLookUpResp vinLookUpResp = retrieveQuoteResponseSessionStorage.getAuto().getVinLookUpResp();
        String newlyAddedVehicleVIN = vinLookUpResp.getVin();
        String newVehicleXpath = String.format("//li[contains(text(),'%s') and contains(text(),'%s') and contains(text(),'%s')]", vinLookUpResp.getYear(), vinLookUpResp.getModelDesc(), vinLookUpResp.getMakeDesc());
        WebElement newVehicleWebElement = driver().findElement(By.xpath(newVehicleXpath));
        waitElementBeVisible(newVehicleWebElement);
        fsa.assertTrue(newVehicleWebElement.isDisplayed(), "New Vehicle Description Is Not Matching");
        fsa.assertTrue(getTextFromElement(newlyEnteredVehicleLabel).contains(newlyAddedVehicleVIN), "Newly Added VIN Is Missing In The Text");

        fsa.assertTrue(getTextFromElement(pleaseSelectLabel).equals(PLEASE_SELECT_LABEL), "Please Select Label Is Not Matching");
        fsa.assertTrue(editVINIfItIsWrong.isDisplayed(), "Edit VIN If It Is Wrong Label Text Is Not Displayed");
        fsa.assertTrue(vINIsCorrect.isDisplayed(), "Vin Is Correct Label Text Is Not Displayed");
        fsa.assertTrue(getTextFromElement(editVINLink).equals(EDIT_VIN_LINK), "Edit VIN Link Text Is Not Matching");
        fsa.assertTrue(getTextFromElement(vinIsCorrectLink).equals(VIN_IS_CORRECT_LINK), "VIN Is Not Correct Link Text Is Not Matching");

        if (buttonText.equals(VIN_IS_CORRECT_LINK)) {
            waitAndClickElement(vinIsCorrectLink);
        } else {
            waitAndClickElement(editVINLink);
        }
    }

    private void clearVinNumberInputBox(WebElement vinNumberInputBox) {
        while (!getAttributeData(vinNumberInputBox, VALUE).equals(EMPTY_STRING)) {
            vinNumberInputBox.sendKeys(Keys.chord(Keys.BACK_SPACE));
        }
    }

    private void enterLoanCompanyInformation(List<Auto.AppStoreVehicle> listOfLoanVehicles) throws Exception {
        for (int i = 0; i < listOfLoanVehicles.size(); i++) {
            WebElement loanInputBox = loanInputBoxWebElement(i);
            scrollOffsetClickOnElement(loanInputBox);
            sleep(3);
            sendKeysOneByOne(loanInputBox, "S");
            List<WebElement> loanOptionsFromDropDown = loanOrLeasedDropDownOptions();
            waitElementBeVisible(loanOptionsFromDropDown.get(0));
            clickElement(loanOptionsFromDropDown.get(0));
            removeQualtricsPopUp();
        }
    }

    private void enterLeasingCompanyInformation(List<Auto.AppStoreVehicle> listOfLeasedVehicles) throws Exception {
        for (int i = 0; i < listOfLeasedVehicles.size(); i++) {
            WebElement leasingInputBox = leasingInputBoxWebElement(i);
            scrollOffsetClickOnElement(leasingInputBox);
            sleep(3);
            sendKeysOneByOne(leasingInputBox, "S");
            sleep(3);
            List<WebElement> leaseOptionsFromDropDown = loanOrLeasedDropDownOptions();
            waitAndClickElement(leaseOptionsFromDropDown.get(0));
            removeQualtricsPopUp();
        }
    }

    public void enterVINNumber(List<Auto.AppStoreVehicle> vehicleListWithoutVinNumber, FarmersSoftAssert fsa) throws Exception {
        for (int i = 0; i < vehicleListWithoutVinNumber.size(); i++) {
            WebElement vinInputElement = vinNumberTextBoxElementList.get(i);
            scrollOffsetClickOnElement(vinInputElement);
            while (getAttributeData(vinInputElement, CLASS).contains("ng-invalid")) {
                waitAndClickElement(vinInputElement);
                vinInputElement.sendKeys(getRandomVinNumber(10));
                vinInputElement.sendKeys(Keys.chord(Keys.TAB));
                sleep(1);
            }
            validateEditVINNumberPopUp(vehicleListWithoutVinNumber.get(i), VIN_IS_CORRECT_LINK, fsa);
            removeQualtricsPopUp();
        }
    }

    public void enterVinNumber(WebElement element, String vinNumber) {
        scrollOffsetClickOnElement(element);
        waitAndClickElement(element);
        element.sendKeys(vinNumber);
        element.sendKeys(Keys.chord(Keys.TAB));
        waitAndClickElement(vinIsCorrectLink);
        waitForSpinnerToBeGone();
    }

    private WebElement loanInputBoxWebElement(int index) {
        return loanCompanyParentTextBoxElementList.get(index).findElement(By.xpath("//input"));
    }

    private WebElement leasingInputBoxWebElement(int index) {
        return leasingCompanyParentTextBoxElementList.get(index).findElement(By.xpath("//input"));
    }

    private List<WebElement> loanOrLeasedDropDownOptions() throws Exception {
    	By xpathToOptions = By.xpath("//span[@class='mdc-list-item__primary-text']");
    	waitForElements("//span[@class='mdc-list-item__primary-text']");
        return driver().findElements(xpathToOptions);
    }

    public void enterOthersInLoanCompanyInputElement() throws Exception {
        sendKeysToElement(driver().findElement(By.xpath("//mat-label[contains(text(),'Enter loan company')]/../..//input")), "Others");
    }

    public void validateADA_AdditionalInfoPageVehicleSection() {
        if (!isADATestingEnabled()) {
            return;
        }
        scrollAndClickOnElement(waitElementBeVisible(useThisGuide));
        performADATesting("AdditionalInfoPage_UseThisGuide_HelpSideSheet", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(backArrowIconVINPopUp);
        sendKeysToElement(vinNumberTextBoxElementList.get(0), "3GCUKREC0EG426454");
        waitForSpinnerToBeGone();
        waitElementBeVisible(confirmYourVINLabel);
        performADATesting("AdditionalInfoPage_ConfirmYourVinPopUp", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(editVINLink);
        waitElementBeVisible(vinNumberTextBoxElementList.get(0)).clear();
    }


    public void validateInvalidVIN_AdditionalInfoPage(FarmersSoftAssert fsa) throws Exception {
        int numberOfElements = vinInputFields.size();
        for (int i = 0; i < numberOfElements; i++) {
            WebElement vinInputField = vinInputFields.get(i);
            scrollElementToMiddle(vinInputField);
            sendKeysToElement(vinInputField, "1111736373700");
            sendKeysToElement(vinInputField, Keys.TAB);
            waitForSpinnerToBeGone();
            String vinErrorMessageXpath = "//div[contains(@class,'additional-info-vehicle-info-section')]//mat-error";
            waitElementPresent(By.xpath(vinErrorMessageXpath), 2);
            List<WebElement> vinErrorMessages = driver().findElements(By.xpath(vinErrorMessageXpath));

            vinErrorMessages.forEach(each -> {
                fsa.assertEquals(getTextFromElement(each), PLEASE_ENTER_VALID_VIN, "Please enter valid VIN error message check");
            });
        }
    }
}
