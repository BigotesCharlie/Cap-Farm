package com.farmers.ffq.utils;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.framework.report.Log;
import org.openqa.selenium.WebElement;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static com.farmers.framework.AutomationFramework.driver;

public class ImageComparisonHelper {


    //lob from Global variables
    public void takeAndSaveWholePageScreenShot(Class<? extends BasePage> page, String lob) throws Exception {
        BufferedImage wholePageImage = takeWholePageScreenShot();
        ImageIO.write(wholePageImage, "png", new File(getImageLocation(page.getSimpleName(), lob)));
    }

    public void takeAndSaveWebElementScreenShot(WebElement webElement, String lob, String imageName) throws Exception {
        BufferedImage webElementImage = takeWebElementScreenShot(webElement);
        ImageIO.write(webElementImage, "png", new File(getImageLocation(imageName, lob)));
    }

    public BufferedImage takeWholePageScreenShot() throws Exception {
        return new AShot().takeScreenshot(driver()).getImage();
    }

    public BufferedImage takeWebElementScreenShot(WebElement webElement) throws Exception {
        return new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver(), webElement).getImage();
    }

    public boolean compareImages(BufferedImage expectedImage, BufferedImage actualImage, String expectedImageName) throws IOException {
        File diffImageLocation = new File("src/test/resources/screenshots/auto/difference/" + expectedImageName + ".png");
        ImageDiffer imageDiffer = new ImageDiffer();
        ImageDiff imageDiff = imageDiffer.makeDiff(expectedImage, actualImage);
        if (imageDiff.hasDiff()) {
            Log.error(expectedImageName + "image has difference with actual image");
            ImageIO.write(imageDiff.getMarkedImage(), "png", diffImageLocation);
        } else {
            Log.info(expectedImageName + "image has no difference with actual image");
        }
        return !imageDiff.hasDiff();
    }

    public BufferedImage getExpectedImage(String image, String lob) throws IOException {
        return ImageIO.read(new File(getImageLocation(image, lob)));
    }

    public BufferedImage getExpectedWholePageImage(Class<? extends BasePage> page, String lob) throws IOException {
        return ImageIO.read(new File(getImageLocation(page.getSimpleName(), lob)));
    }

    private String getImageLocation(String image, String lob) {
        String imageLocation = null;
        switch (lob) {
            case AUTO:
                imageLocation = "src/test/resources/screenshots/auto/" + image + ".png";
                break;
            case HOME:
            case CONDO:
            case RENTERS:
            case LIFE:
            default:
                Log.info("Location for other lobs not yet set");
                break;
        }
        return imageLocation;
    }

}
