package com.farmers.ffq.home.pages;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.framework.report.Log;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import static org.openqa.selenium.support.ui.ExpectedConditions.*;

public class ThankYouPageFL extends BasePage {

	@FindBy(id = "FFQHome_ThankYou_heading")
	private WebElement thankYouHeadingTitleText;

	@FindBy(id = "FFQHome_ThankYou_quoteNumberWrap")
	private WebElement quoteNumberText;

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public ThankYouPageFL() throws Exception {}

	public void verifyThankYouPageFL() {
		Log.info("Verifying thank you page FL...");
		wait.until(visibilityOf(thankYouHeadingTitleText));
		Assert.assertTrue(getTextFromElement(thankYouHeadingTitleText).contains("An agent in your area will contact you soon."), "Header title text doesn't match");
		Assert.assertTrue(getTextFromElement(quoteNumberText).contains("Your Quote Request Number is"), "Quote number text doesn't match");
	}
}
