package com.farmers.ffq.ace.condo;

import com.farmers.ffq.ace.hrc.common.AceHRCPropertyDetailsBasePage;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoPropertyDetailsPage extends AceHRCPropertyDetailsBasePage {

    /**
     * Default Constructor
     */
    public AceCondoPropertyDetailsPage() throws Exception {
    }

    public void validateEditTotalSquareFoot(String squareFeet, FarmersSoftAssert fsa) throws Exception {
        final String TOTAL_SQUARE_FOOTAGE_INPUT_LABEL = "Total finished sq. ft";
        final String TOTAL_SQUARE_FOOTAGE_TEXT = "Finished square feet includes area in attic, additions, and all living space (including closets and stairwells)" +
                " that is heated and/or cooled, has finished walls and ceilings, and has floor covering.";
        final String TOTAL_SQUARE_FOOTAGE_LOWER_TEXT = "IMPORTANT: Finished square feet does not include all garage areas, basement areas (finished and unfinished)," +
                " finished living space partially below grade (including spilt level foundations), and attached and detached structures like decks, balconies, patios, porches and carport.";
        final String ENTER_SQUARE_FEET_ERROR = "Please enter the total sq. ft of your house.";
        final String ENTER_SQUARE_FEET_100_ERROR = "Total sq. ft must be at least 100.";
        final String ENTER_SQUARE_FEET_99999_ERROR = "Total sq. ft cannot exceed 99999.";
        clickEditModalPropertyDetailsFieldEditButton(TOTAL_SQ_FT);
        fsa.assertEquals(getTextFromElement(editPropertyModalTitle), TOTAL_SQ_FT, "Property Details Modal - Edit Total square footage title.");
        fsa.assertEquals(getTextFromElement(editPropertyModalText), TOTAL_SQUARE_FOOTAGE_TEXT, "Property Details Modal - Edit Total square footage text.");
        String squareFeetValue = getValueFromWebElement(editPropertyModalInput);
        fsa.assertEquals(squareFeetValue, squareFeet, "Property Details Modal - Edit Total square footage input value.");
        fsa.assertEquals(getTextFromElement(editPropertyModalLabel), TOTAL_SQUARE_FOOTAGE_INPUT_LABEL, "Property Details Modal - Edit Total square footage input label.");
        fsa.assertEquals(getTextFromElement(editPropertyModalLightBulbText), TOTAL_SQUARE_FOOTAGE_LOWER_TEXT, "Property Details Modal - Edit Total square footage lower text.");

        if (!Property.getDriver().equals(FIREFOX)) { // in Saucelabs these error messages are not consistent in FF browser
            waitAndClickElement(editPropertyModalInput);
            clearInputFieldModal();
            waitElementBeVisible(errorMessage, 2);
            fsa.assertTrue(getPageErrors().contains(ENTER_SQUARE_FEET_ERROR), PROPERTY_DETAILS_PAGE + ENTER_SQUARE_FEET_ERROR + ERROR_FOUND);
            waitAndClickElement(editPropertyModalInput);
            sendKeysToElement(editPropertyModalInput, "99" + Keys.TAB);
            waitElementBeVisible(errorMessage, 2);
            fsa.assertTrue(getPageErrors().contains(ENTER_SQUARE_FEET_100_ERROR), PROPERTY_DETAILS_PAGE + ENTER_SQUARE_FEET_100_ERROR + ERROR_FOUND);
            waitAndClickElement(editPropertyModalInput);
            sendKeysToElement(editPropertyModalInput, "123456" + Keys.TAB);
            waitElementBeVisible(errorMessage, 2);
            fsa.assertTrue(getPageErrors().contains(ENTER_SQUARE_FEET_99999_ERROR), PROPERTY_DETAILS_PAGE + ENTER_SQUARE_FEET_99999_ERROR + ERROR_FOUND);
        }
        waitAndClickElement(editPropertyModalInput);
        sendKeysToElement(editPropertyModalInput, squareFeetValue + Keys.TAB);
        waitAndClickElement(closeEditPropertyModal);
    }

    public void validateEditFloors(String floors, FarmersSoftAssert fsa, String stateCode) throws Exception {
        final String FLOORS_TEXT = "All flooring materials found in your home.";
        String floorOptionVinyl = List.of(NY, NJ, MT).contains(stateCode)? "Vinyl" : "Vinyl Plank";
        final String[] FLOORS_CHECKBOXES = {"Carpet", "Hardwood", "Laminate", floorOptionVinyl, "Linoleum", "Stone & tile"};
        final String TOTAL_FLOORS_LOWER_TEXT = "For specialty or high-value flooring, please contact Farmers\u00ae representative this may impact the estimated " +
                "replacement cost of your home.";

        clickEditModalPropertyDetailsFieldEditButton(FLOORS);
        fsa.assertEquals(getTextFromElement(editPropertyModalTitle), FLOORS, "Property Details Modal - Edit Floors title.");
        fsa.assertEquals(getTextFromElement(editPropertyModalText), FLOORS_TEXT, "Property Details Modal - Edit Floors text.");
        Object[] checkboxes = driver().findElements(By.xpath(EDIT_MODAL_CHECKBOX_XPATH)).stream().map(this::getTextFromElement).toArray();
        fsa.assertEquals(checkboxes, FLOORS_CHECKBOXES, "Property Details Modal - Edit Floors checkboxes.");

        // commenting out this line as we have open defect US910502 in backlog
       // sa.assertEquals(getTextFromElement(editPropertyModalCaption), TOTAL_FLOORS_LOWER_TEXT, "Property Details Modal - Edit Floors lower text.");

        Object[] checkboxSelected = driver().findElements(By.xpath(EDIT_MODAL_CHECKBOX_XPATH + EDIT_MODAL_CHECKBOX_CHECKED_XPATH)).stream()
                .map(this::getTextFromElement).toArray();
        Log.info("Floors from UI: " + Arrays.toString(checkboxSelected));
        if (!floors.equals(NONE)) {
            Object[] listFloors = Stream.of(floors.split(COMMA)).map(String::strip).toArray();
            Log.info("Floors from appStore: " + Arrays.toString(listFloors));
            fsa.assertEqualsNoOrder(checkboxSelected, listFloors, "Property Details Modal - Edit Floors selected values.");
        } else {
            fsa.assertTrue(checkboxSelected.length==0, "Property Details Modal - Edit Floors does not have any selected values" +
                    " (no property details in the appStore).");
        }
        waitAndClickElement(closeEditPropertyModal);
    }

}
