package com.farmers.ffq.common.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.openqa.selenium.By;

import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;

/**
 * Farmers Fast Quote (FFQ) - Non Offering States Page - Legacy version.
 * 
 */
public class LegacyNonOfferingPage extends BasePage {
	private WebDriverWait wait;
	
	private static final String MAIN_AREA_ID = "farmers-landing-v2";
	@FindBy(id = MAIN_AREA_ID)
	private WebElement mainArea;
	
	private static final String BOX_AREA_ID = "BoxArea";
	@FindBy(id = BOX_AREA_ID)
	private WebElement intro;

	private static final String NOT_OFFERED_HEADER_ID = "quote_unavailable_header-title";
	@FindBy(id = NOT_OFFERED_HEADER_ID)
	private WebElement notOfferedHeader;

	private static final String FARMERS_DIRECT_PAGE_ID = "root";
	@FindBy(id = FARMERS_DIRECT_PAGE_ID)
	private WebElement farmersDirectPage;

	private static final String MEDIA_ALPHA_HEADER_ID = "MediaAlphaHead";
	@FindBy(id = MEDIA_ALPHA_HEADER_ID)
	private WebElement mediaAlphaHeader;
	
	private static final String QUOTE_UNAVAILABLE_CONTENT_ID = "quote_unavailable-content";
	@FindBy(id = QUOTE_UNAVAILABLE_CONTENT_ID)
	private WebElement quotingUnavailableText;
	
	private static final String QUOTES_TEMPORARILY_UNAVAILABLE_ID = "no-auto-quote_header-title";
	@FindBy (id = QUOTES_TEMPORARILY_UNAVAILABLE_ID)
	private WebElement quotingTemporarilyUnavailableHeader;
	
	private static final String DONT_OFFER_INSURANCE = "Sorry, we don't offer insurance in your area.";

	/**
	 * Constructor.
	 * 
	 * @throws Exception 
	 */
	public LegacyNonOfferingPage() throws Exception {
		WebDriver webDriver = driver();
		PageFactory.initElements(webDriver, this);
		wait = driverWait(60);
	}

	public boolean isNonOfferingTextExist() {
		if (isElementPresent(By.id(NOT_OFFERED_HEADER_ID), 5)) {
			return (getTextFromElement(notOfferedHeader).contains(DONT_OFFER_INSURANCE));
		} else if (isElementPresent(By.id(BOX_AREA_ID), 5)) {
			return getTextFromElement(intro).contains(DONT_OFFER_INSURANCE);
		} else {
			return false;
		}
	}
	
	public boolean isNewNonOfferingPage() throws Exception {
		if (isElementPresent(By.id(MAIN_AREA_ID), 5)) {
			return driver().getPageSource().contains("Thanks for starting your quote online");
		} else {
			return false;
		}
	}
	
	public void verifyBristolWestNonOfferingPage() {
		waitElementBeVisible(intro);
		Assert.assertTrue(getTextFromElement(mediaAlphaHeader).contains("We're sorry - Farmers doesn't currently offer"), "BRISTOL WEST message (first line) is not visible!");
		Assert.assertTrue(getTextFromElement(mediaAlphaHeader).contains("online quoting in your area."), "BRISTOL WEST message (second line) is not visible!");
		Assert.assertTrue(getTextFromElement(mediaAlphaHeader).contains("Please call 1-800-206-9469 to complete this quote."), "BRISTOL WEST call center number is not visible!");
	}
	
	public boolean farmersInsuranceHawaiiState() throws Exception {
		wait.until(presenceOfElementLocated(By.cssSelector("li.slogan")));
		return driver().getPageSource().contains("Farmers Hawaii");
	}
	
	public boolean quotingUnavailableTextExists() {
		if (isElementPresent(By.id(QUOTE_UNAVAILABLE_CONTENT_ID), 3)) {
			return getTextFromElement(quotingUnavailableText).contains("We're sorry, but we are unable to provide an online quote at this time.");
		} else if (isElementPresent(By.id(QUOTES_TEMPORARILY_UNAVAILABLE_ID), 3)) {
			return getTextFromElement(quotingTemporarilyUnavailableHeader).contains("Quotes Temporarily Unavailable");
		} else {
			return false;
		}
	}

	public boolean verifySouthCarolinaOfferingPage() throws Exception {
		if (isElementPresent(By.id(FARMERS_DIRECT_PAGE_ID), 5)) {
			return driver().getCurrentUrl().contains("farmersdirect");
		} else {
			return false;
		}
	}
	
}
