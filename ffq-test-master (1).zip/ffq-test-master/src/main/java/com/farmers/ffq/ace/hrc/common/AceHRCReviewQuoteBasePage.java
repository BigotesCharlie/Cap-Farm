package com.farmers.ffq.ace.hrc.common;

import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Home.Dropdowns.Quote.CoverageValue;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.CurrencyFormat.convertCurrencyStringToDouble;
import static com.farmers.ffq.utils.GlobalVariables.*;


public class AceHRCReviewQuoteBasePage extends AceHRCBasePage {

    //Static variables
    public static final String DEDUCTIBLES = "Deductibles";
    public static final String ALL_PERILS_COVERAGE_CODE = "A";

    private static final String PAGE_TITLE1 = "Here are your quotes";
    private static final String PAGE_TITLE2 = "Here is your quote";
    protected static final String EXPECTED_EDIT_DEDUCTIBLES_LINK_TEXT = "Edit deductibles";

    protected static final String EXPECTED_RECALCULATE_BUTTON_TEXT = "Recalculate";
    protected static final String EXPECTED_RESET_CHANGES_LINK_TEXT = "Reset changes";

    public static final String SCHEDULED_PAYMENT = "Scheduled payment";
    public static final String REPLACEMENT_COST = "Replacement cost";

    private static final String SEPARATING_STRING = Property.getTestProperty("driver").equals(SAFARI)? EMPTY_STRING : SPACE;
    protected static final String EXPECTED_PERSONAL_PROPERTY_DESCRIPTION = "This coverage, also known as Coverage C, can help replace your possessions " +
            "owned or used by an insured anywhere in the world subject to the policy provisions and special limits for things like jewelry, watches, " +
            "furs, firearms and computers. For a complete list, please check with your Farmers\u00ae representative." + SEPARATING_STRING +
            "Actual cash value (ACV) - The amount we may pay for repair or replacement is reduced to account for depreciation." + SEPARATING_STRING +
            "Replacement cost value (RCV) - The amount we may pay for repair or replacement does not deduct for depreciation.";
    protected static final String EXPECTED_PERSONAL_PROPERTY_DESCRIPTION_VA = "This coverage can help replace possessions owned or used by an insured " +
            "anywhere in the world, subject to the policy provisions and special limits for things like jewelry, watches, furs, firearms and computers. " +
            "For a complete list, please check with your Farmers\u00ae representative. Coverage for personal property is settled at Replacement Cost Value (RCV). " +
            "Farmers also offers settlement at Actual Cash Value, please contact your Farmers® representative for additional details on these options prior to purchase.";
    private static final String PAGE_TITLE_XPATH = "//app-home-quote-review//h1[text()=('" + PAGE_TITLE1 + "' or '" + PAGE_TITLE2 + "')]";
    @FindBy(xpath = PAGE_TITLE_XPATH)
    private WebElement quoteSummaryHeading;

    @FindBy(xpath = "//app-home-quote-review//div[contains(@class,'tui-stacking-top-xl')]/div[contains(@class,'tui-stacking-top-md')]")
    private WebElement quoteSummarySubheading;

    private static final String CHANGE_COVERAGE_XPATH = "//a[contains(text(),'coverage')]";
    @FindBy(xpath = CHANGE_COVERAGE_XPATH)
    private WebElement linkChangeCoverage;

    @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tui-price")
    private WebElement quotePriceOnCardDesktop;
    @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//tui-price")
    private WebElement quotePriceOnCardMobile;

    @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[contains(text(),'Continue')]")
    protected WebElement buttonContinueDesktop;
    @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[contains(text(),'Continue')]")
    protected WebElement buttonContinueMobile;

    @FindBy(xpath = "//div[contains(@class,'quote-mobile-display')]//button[contains(text(),'Continue')]")
    protected WebElement buttonContinueMobileAtPageBottom;

    private static final String PRIMARY_COVERAGES_XPATH = "//tr/td[starts-with(text(),'Primary coverages')]/following-sibling::td";
    @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + PRIMARY_COVERAGES_XPATH)
    private WebElement primaryCoveragesPriceOnCardDesktop;
    @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + PRIMARY_COVERAGES_XPATH)
    private WebElement primaryCoveragesPriceOnCardMobile;

    private static final String OPTIONAL_COVERAGES_XPATH = "//tr/td[starts-with(text(),'Optional coverages')]/following-sibling::td";
    @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + OPTIONAL_COVERAGES_XPATH)
    private WebElement quoteOptionalCoveragesPriceOnCardDesktop;
    @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + OPTIONAL_COVERAGES_XPATH)
    private WebElement quoteOptionalCoveragesPriceOnCardMobile;

    @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div")
    private WebElement quoteDiscountsOnCardDesktop;
    @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//mat-list-item//div")
    private WebElement quoteDiscountsOnCardMobile;

    private static final String VIEW_MONTHLY_PRICING_LINK_DESKTOP_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[text()='View monthly pricing']";
    @FindBy(xpath = VIEW_MONTHLY_PRICING_LINK_DESKTOP_XPATH)
    private WebElement linkViewMonthlyPricingDesktop;
    private static final String VIEW_MONTHLY_PRICING_LINK_MOBILE_XPATH = QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[text()='View monthly pricing']";
    @FindBy(xpath = VIEW_MONTHLY_PRICING_LINK_MOBILE_XPATH)
    private WebElement linkViewMonthlyPricingMobile;

    @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//mat-icon[@aria-label='expand quote card']")
    protected WebElement expandQuoteCard;
    @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + "//mat-icon[@aria-label='minimize quote card']")
    protected WebElement minimizeQuoteCard;

    @FindBy(xpath = "//mat-dialog-container//button[text()='OK']")
    private WebElement dialogButtonOk;

    private static final String PRESENTMENT_CARD_PRICE_HEADER_XPATH = "//div[contains(@class,'price-description')]";
    @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + PRESENTMENT_CARD_PRICE_HEADER_XPATH)
    private WebElement presentmentCardPriceHeaderDesktop;
    @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + PRESENTMENT_CARD_PRICE_HEADER_XPATH)
    private WebElement presentmentCardPriceHeaderMobile;

    protected static final String RECALCULATE_BUTTON_DESKTOP_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[text()='Recalculate']";
    @FindBy(xpath = RECALCULATE_BUTTON_DESKTOP_XPATH)
    protected WebElement recalculateButtonDesktop;
    protected static final String RECALCULATE_BUTTON_MOBILE_XPATH = QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[text()='Recalculate']";
    @FindBy(xpath = RECALCULATE_BUTTON_MOBILE_XPATH)
    protected WebElement recalculateButtonMobile;

    private static final String VIEW_PAY_IN_FULL_PRICING_LINK_DESKTOP_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//div[starts-with(text(),'View pay-in-full pricing')]";
    @FindBy(xpath = VIEW_PAY_IN_FULL_PRICING_LINK_DESKTOP_XPATH)
    private WebElement linkViewPayInFullPricingDesktop;
    private static final String VIEW_PAY_IN_FULL_PRICING_LINK_MOBILE_XPATH = QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[starts-with(text(),'View pay-in-full pricing')]";
    @FindBy(xpath = VIEW_PAY_IN_FULL_PRICING_LINK_MOBILE_XPATH)
    private WebElement linkViewPayInFullPricingMobile;

    private static final String PRESENTMENT_CARD_PRICE_HEADER = "12-month plan starting at";

    @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + PRESENTMENT_CARD_PRICE_HEADER_XPATH)
    private WebElement presentmentCardPriceHeader;

    private static final String VIEW_MONTHLY_PRICING_LINK_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//div[text()='View monthly pricing']";
    @FindBy(xpath = VIEW_MONTHLY_PRICING_LINK_XPATH)
    private WebElement linkViewMonthlyPricing;

    private static final String VIEW_PAY_IN_FULL_PRICING_LINK_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//div[starts-with(text(),'View pay-in-full pricing')]";
    @FindBy(xpath = VIEW_PAY_IN_FULL_PRICING_LINK_XPATH)
    private WebElement linkViewPayInFullPricing;

    @FindBy(xpath = "//button[@data-test-id='PRICE-ALTERNATIVE-BUTTON']")
    private WebElement linkPriceAlternative;

    @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[starts-with(text(),'Included coverages')]/following-sibling::td")
    private WebElement quotePackagePriceOnCard;

    @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[text()='Optional coverages']/following-sibling::td")
    private WebElement quoteAllOtherCoveragesPriceOnCard;

    @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div")
    private WebElement quoteDiscountsOnCard;
    @FindBy(xpath = "//div[contains(@class,'main-content')]/div[1]")
    private WebElement policyDeductibleHeader;
    @FindBy(xpath = "//div[contains(@class,'main-content')]/div[contains(@class,'tui-stacking-top-sm')]")
    protected WebElement outOfPocketLossForCoveredLoss;
    @FindBy(xpath = "//div[contains(@class,'deductible-label')]")
    private List<WebElement> deductibleLabels;
    @FindBy(xpath = "//div[contains(@class,'deductible-amount')]")
    private List<WebElement> deductibleAmount;
    @FindBy(xpath = "//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_A']")
    private WebElement allPerilsDeductibleInfoIcon;
    @FindBy(xpath = "//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_W']")
    private WebElement windAndHailDeductibleInfoIcon;
    @FindBy(xpath = "//div[contains(@class,'deductibles')]//mat-divider")
    private List<WebElement> deductibleMatDividers;
    @FindBy(xpath = "//button[contains(@class,'edit-deductibles-button')]//mat-icon")
    protected WebElement editDeductibleIcon;
    @FindBy(xpath = "//button[contains(@class,'edit-deductibles-button')]//span")
    protected WebElement editDeductibleText;
    @FindBy(xpath = "//button[contains(@class,'edit-deductibles-button')]")
    protected WebElement editDeductibleButton;
    @FindBy(xpath = "//app-home-coverages-and-deductibles-info-dialog//h1")
    private WebElement policyDeductibleHeaderInSideSheet;
    @FindBy(xpath = "//app-home-coverages-and-deductibles-info-dialog//button[@aria-label='Close']")
    private WebElement closeIconPolicyDeductibleSideSheet;
    @FindBy(xpath = "//mat-panel-title//div")
    private List<WebElement> policyDeductibleTitlesInSideSheet;
    @FindBy(xpath = "//div[contains(@class,'mat-expansion-panel-body')]//p[contains(@class,'tui-caption-text')][1]")
    private List<WebElement> policyDeductibleExplanationInSideSheet;
    @FindBy(xpath = "//mat-accordion//mat-divider")
    private List<WebElement> policyDeductibleSideSheetDividers;
    @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//h1")
    private WebElement deductibleHeader;
    @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//button//mat-icon")
    private WebElement closeIconInDeductibleSideSheet;
    @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//h2[1]")
    private WebElement allPerilLossesHeader;
    @FindBy(xpath = "//div[contains(@class,'tui-caption-text')][1]")
    private WebElement allPerilLossesDescription;
    @FindBy(xpath = "//mat-radio-group[@name='allPerilsCoverageSelection']//mat-radio-button")
    private List<WebElement> allPerilLossesRadioButtons;
    @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//h2[2]")
    private WebElement windAndHailLossesHeader;
    @FindBy(xpath = "//div[contains(@class,'tui-caption-text')][2]")
    private WebElement windAndHailLossesDescription;
    @FindBy(xpath = "//mat-radio-group[@name='windAndHailCoverageSelection']//mat-radio-button")
    private List<WebElement> windAndHailLossesRadioButtons;
    @FindBy(xpath = "//app-edit-home-deductibles-side-sheet//mat-divider")
    private WebElement matDividerInDeductiblesSideSheet;
    protected static final String RECALCULATE_BUTTON_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[text()='Recalculate']";
    @FindBy(xpath = "//button[@data-test-id='RECALCULATE_BUTTON']")
    private WebElement recalculateButtonHomeLobSideSheet;

    @FindBy(xpath = "//button[@data-test-id='OPEN_CONFIRM_RESET_DIALOG_BUTTON']")
    private WebElement resetChangesButton;
    @FindBy(xpath = "//button[contains(@class,'edit-coverage-dialog-submit-button')]")
    private WebElement recalculateButtonRentersCondoInSideSheet;
    @FindBy(xpath = "//div[contains(@class,'coverages-docked-buttons')]//button[2]")
    private WebElement resetChangesButtonRentersCondoInSideSheet;

    @FindBy(xpath = "//h2[contains(@class,'reset-changes-heading')]")
    private WebElement resetChangesHeader;
    @FindBy(xpath = "//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-content")
    private WebElement areYouSureYouWantToResetChangesQuestion;
    @FindBy(xpath = "//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[1]")
    private WebElement keepEditingButton;
    @FindBy(xpath = "//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[2]")
    private WebElement resetButton;
    @FindBy(xpath = "//mat-error[contains(@class,'home-quote-deductible__error-label')]")
    private WebElement windAndHailDeductibleCannotBeLowerThanAllPerilError;
    @FindBy(xpath = "//app-home-coverages-and-deductibles-info-dialog//button[@aria-label='Close']")
    private WebElement closeIconInPolicyDeductibleSideSheet;
    @FindBy(xpath = "//div[@aria-label='Standard package']")
    private WebElement standardPackageButton;
    @FindBy(xpath = "//div[@aria-label='Enhanced package']")
    private WebElement enhancedPackageButton;
    @FindBy(xpath = "//div[@aria-label='Premier package']")
    private WebElement premierPackageButton;
    @FindBy(xpath = "//div[contains(@class,'package-body-content')]/div[1]")
    private WebElement packageNameHeader;
    @FindBy(xpath = "//div[contains(@class,'package-body-content')]/div[2]")
    private WebElement packageSubTotalHeader;
    @FindBy(xpath = "//div[contains(@class,'package-body-content')]/div[3]")
    private WebElement packagePremiumAmount;
    @FindBy(xpath = "//div[contains(@class,'package-body-content')]/div[4]")
    private WebElement reducedCoverageForReducedPriceLabel;
    @FindBy(xpath = "//button[contains(@class,'compare-button')]//mat-icon")
    private WebElement comparePackageDoubleArrowIcon;
    @FindBy(xpath = "//button[contains(@class,'compare-button')]")
    private WebElement comparePackageButton;
    @FindBy(xpath = "//div[contains(@class,'coverage-section-label')]")
    private List<WebElement> coverageTypeLabels;
    @FindBy(xpath = "//div[contains(text(),'Coverages')]")
    private List<WebElement> coveragesLabels;
    @FindBy(xpath = "//div[contains(text(),'Limits')]")
    private List<WebElement> limitLabels;
    @FindBy(xpath = "//div[contains(@class,'coverage-description')]")
    private List<WebElement> coverageNames;
    @FindBy(xpath = "//button[@id='specialLimitsButton']//span")
    private WebElement showSpecialLimitsLinkButton;
    @FindBy(xpath = "//button[@id='specialLimitsButton']//mat-icon[text()='add' or text()='keyboard_arrow_down']")
    private WebElement showSpecialLimitsLinkPlusIcon;
    @FindBy(xpath = "//div[contains(@class,'coverage-amount')]")
    private List<WebElement> coverageAmountValues;

    @FindBy(xpath = "//div[@id='editCoverageDialogHeading']")
    private WebElement coveragesHeader;
    @FindBy(xpath = "//div[contains(@class,'edit-coverage-dialog-heading')]//mat-icon")
    private WebElement closeIconOnCoveragesSideSheet;
    @FindBy(xpath = "//div[contains(@class,'quote-coverages-slide-toggle__container')]/label")
    private WebElement allPerilsHeaderInCoverageSideSheet;

    @FindBy(xpath = "//div[contains(@class,'quote-coverage__description')]")
    private WebElement allPerilExplanation;
    @FindBy(xpath = "//mat-radio-group[@id='__A__radio']//mat-radio-button")
    private List<WebElement> allPerilMatRadioButtonInCoverageSideSheet;

    @FindBy(xpath = "//mat-radio-group[@id='__A__radio']//mat-radio-button[not(contains(@class,'checked'))]")
    private List<WebElement> uncheckedPerilMatRadioButtonInCoverageSideSheet;

    protected static final String EXPECTED_ALL_PERILS_HEADER_TEXT = "All perils";
    private static final String PACKAGE_TABS_XPATH = "//mat-tab-group//div[@role='tab' and @aria-label]";
    protected static final String EXPECTED_OUT_OF_POCKET_COST_FOR_COVERED_LOSS = "Your out-of-pocket cost for a covered loss.";
    protected static final String EXPECTED_ALL_PERILS_EXPLANATION_TEXT = "This deductible applies to all causes of loss, unless a separate deductible for a certain cause of loss is shown and selected.";

    @FindBy(xpath = "//div[contains(@class,'save-in-progress')]/p")
    private WebElement saveInProgressFooter;

    @FindBy(xpath = "//div[contains(@class,'save-quote')]")
    private WebElement quoteNumberText;

    @FindBy(xpath = "//button[contains(@class,'tui-quote-presentment-minimized-button')] | //tui-quote-presentment//button")
    private WebElement continueButtonMobile;

    @FindBy(xpath = "//tui-quote-presentment//button[not(contains(@class, 'inserted'))]")
    private WebElement continueButtonDesktop;

    @FindBy(xpath = "//div[contains(@class,'condo-renters-quote-coverages')]//p[1]")
    private WebElement coveragesLabel;
    @FindBy(xpath = "//div[contains(@class,'condo-renters-quote-coverages')]//p[2]")
    private WebElement limitsLabel;
    @FindBy(xpath = "//div[contains(@class,'condo-renters-quote-coverages')]//div[contains(@class,'row')]/div[contains(@class,'tui-body') and not(contains(@class,'coverage-price-column'))]")
    protected List<WebElement> condoRentersCoveragesNamesOnReviewQuotePage;
    @FindBy(xpath = "//div[contains(@class,'condo-renters-quote-coverages')]//div[contains(@class,'row')]/div[contains(@class,'tui-body') and contains(@class,'coverage-price-column')]")
    protected List<WebElement> condoRentersCoveragesAmountOnReviewQuotePage;
    @FindBy(xpath = "//button[@id='editCoverageLink' and contains(text(),'Add/edit coverages')]")
    protected WebElement condoRentersAddEditCoverageLink;
    @FindBy(xpath = "//div[@id='editCoverageDialogHeading']")
    protected WebElement condoRentersCoverageSideSheetHeader;
    @FindBy(xpath = "//app-edit-coverage//div[contains(@class,'tui-caption-text') and contains(@class,'mt-3')]")
    protected WebElement coverageHintEditCoverageSideSheet;
    protected static final String COVERAGE_DESCRIPTION_XPATH = "/ancestor::coverage-data-card//div[contains(@class,'quote-coverage__description')]";
    protected static final String PERSONAL_PROPERTY = "Personal property";
    protected static final String PERSONAL_PROPERTY_LABEL_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + PERSONAL_PROPERTY +"')]";
    @FindBy(xpath = PERSONAL_PROPERTY_LABEL_XPATH)
    protected WebElement personalPropertyLabelInEditCoverageSideSheet;
    @FindBy(xpath = PERSONAL_PROPERTY_LABEL_XPATH + COVERAGE_DESCRIPTION_XPATH)
    protected WebElement personalPropertyDescriptionWebElement;
    protected static final String UNIT_OWNER_BUILDING_PROPERTY = "Unit owner's building property";
    protected static final String UNIT_OWNER_BUILDING_PROPERTY_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), 'building property')]";
    @FindBy(xpath = UNIT_OWNER_BUILDING_PROPERTY_XPATH)
    protected WebElement unitOwnerBuildingPropertyLabelInEditCoverageSideSheet;
    @FindBy(xpath = UNIT_OWNER_BUILDING_PROPERTY_XPATH + COVERAGE_DESCRIPTION_XPATH)
    protected WebElement unitOwnerBuildingPropertyDescriptionWebElement;

    protected static final String LOSS_OF_USE_TEXT = "Loss of use";
    protected static final String LOSS_OF_USE = LOSS_OF_USE_TEXT + " (Additional living expense term)";
    protected static final String LOSS_OF_USE_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + LOSS_OF_USE_TEXT + "')]";
    @FindBy(xpath = LOSS_OF_USE_XPATH)
    protected WebElement lossOfUseLabelInEditCoverageSideSheet;
    @FindBy(xpath = LOSS_OF_USE_XPATH + COVERAGE_DESCRIPTION_XPATH)
    protected WebElement lossOfUseDescriptionWebElement;
    @FindBy(xpath = LOSS_OF_USE_XPATH + "/ancestor::coverage-data-card//mat-select")
    protected WebElement lossOfUseDropDownWebElement;
    @FindBy(xpath = LOSS_OF_USE_XPATH + "/ancestor::coverage-data-card//mat-label")
    protected WebElement lossOfUseDropDownPlaceHolder;
    @FindBy(xpath = "//mat-option")
    protected List<WebElement> lossOfUseDropDownOptions;
    @FindBy(xpath = "//mat-option")
    protected WebElement lossOfUseDropDownOption;
    @FindBy(xpath = "//mat-option[contains(@class,'item--selected')]")
    protected WebElement selectedLossOfUseOptionWebElement;

    protected static final String PERSONAL_LIABILITY = "Personal liability";
    protected static final String PERSONAL_LIABILITY_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + PERSONAL_LIABILITY + "')]";
    @FindBy(xpath = PERSONAL_LIABILITY_XPATH)
    protected WebElement personalLiabilityLabelInEditCoverageSideSheet;
    @FindBy(xpath = PERSONAL_LIABILITY_XPATH + COVERAGE_DESCRIPTION_XPATH)
    protected WebElement personalLiabilityDescriptionWebElement;
    @FindBy(xpath = PERSONAL_LIABILITY_XPATH + "//ancestor::coverage-data-card//mat-radio-button")
    protected List<WebElement> personalLiabilityRadioButtonElements;
    @FindBy(xpath = PERSONAL_LIABILITY_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]")
    protected WebElement selectedPersonalLiabilityRadioButtonElement;

    protected static final String MEDICAL_PAYMENT_TO_OTHERS = "Medical payments to others";
    protected static final String MEDICAL_PAYMENT_TO_OTHERS_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + MEDICAL_PAYMENT_TO_OTHERS + "')]";
    @FindBy(xpath = MEDICAL_PAYMENT_TO_OTHERS_XPATH)
    protected WebElement medicalPaymentToOthersLabelInEditCoverageSideSheet;
    @FindBy(xpath = MEDICAL_PAYMENT_TO_OTHERS_XPATH + COVERAGE_DESCRIPTION_XPATH)
    protected WebElement medicalPaymentToOthersDescriptionWebElement;
    @FindBy(xpath = MEDICAL_PAYMENT_TO_OTHERS_XPATH + "//ancestor::coverage-data-card//mat-radio-button")
    protected List<WebElement> medicalPaymentToOthersRadioButtonElements;
    @FindBy(xpath = MEDICAL_PAYMENT_TO_OTHERS_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]")
    protected WebElement selectedMedicalPaymentToOthersRadioButtonElement;
    @FindBy(xpath = MEDICAL_PAYMENT_TO_OTHERS_XPATH + "//ancestor::coverage-data-card//mat-radio-button[not(contains(@class,'" + RADIO_BUTTON_CHECKED + "'))]//input")
    protected WebElement unselectedMedicalPaymentToOthersRadioButtonElement;

    public static final String LIMITED_MOLD = "Limited mold";
    protected static final String LIMITED_MOLD_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//span[contains(text(), '" + LIMITED_MOLD + "')]";
    @FindBy(xpath = LIMITED_MOLD_XPATH + "//ancestor::mat-slide-toggle")
    protected WebElement limitedMoldToggleButtonInEditCoverageSideSheet;
    @FindBy(xpath = LIMITED_MOLD_XPATH)
    protected WebElement limitedMoldLabelInEditCoverageSideSheet;
    @FindBy(xpath = LIMITED_MOLD_XPATH + COVERAGE_DESCRIPTION_XPATH)
    protected WebElement limitedMoldDescriptionWebElement;
    @FindBy(xpath = LIMITED_MOLD_XPATH + "//ancestor::coverage-data-card//mat-radio-button")
    protected List<WebElement> limitedMoldRadioButtonElements;
    @FindBy(xpath = LIMITED_MOLD_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'mat-radio-checked')]")
    protected WebElement selectedLimitedMoldRadioButtonElement;

    protected static final String MINE_SUBSIDENCE = "Mine subsidence";
    protected static final String MINE_SUBSIDENCE_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + MINE_SUBSIDENCE + "')]";
    @FindBy(xpath = MINE_SUBSIDENCE_XPATH)
    protected WebElement mineSubsidenceLabelInEditCoverageSideSheet;
    @FindBy(xpath = MINE_SUBSIDENCE_XPATH + COVERAGE_DESCRIPTION_XPATH)
    protected WebElement mineSubsidenceDescriptionWebElement;
    @FindBy(xpath = MINE_SUBSIDENCE_XPATH + COVERAGE_DESCRIPTION_XPATH + "//following::div[1]")
    protected WebElement mineSubsidenceCoveredValueWebElement;

    protected static final String INCREASE_LOSS_ASSESSMENT = "Increase of loss assessment";
    protected static final String INCREASE_LOSS_ASSESSMENT_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//span[contains(text(), '" + INCREASE_LOSS_ASSESSMENT + "')]";
    @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH + "//ancestor::mat-slide-toggle")
    protected WebElement increaseLossAssessmentToggleButtonInEditCoverageSideSheet;
    @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH)
    protected WebElement increaseLossAssessmentLabelInEditCoverageSideSheet;
    @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH + COVERAGE_DESCRIPTION_XPATH)
    protected WebElement increaseLossAssessmentDescriptionWebElement;
    @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH + "/ancestor::coverage-data-card//p[contains(@class,'quote-coverage-limit')]")
    protected WebElement increaseLossAssessmentCoverageLimitWebElement;
    @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH + "//ancestor::coverage-data-card//mat-radio-button")
    protected List<WebElement> increaseLossAssessmentRadioButtonElements;
    @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]")
    protected WebElement selectedIncreaseLossAssessmentRadioButtonElement;

    @FindBy(xpath = INCREASE_LOSS_ASSESSMENT_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]//p[1]")
    protected WebElement selectedDollarIncreaseLossAssessmentValue;
    protected static final String BUILDING_ORDINANCE = "Building ordinance or law";
    protected static final String BUILDING_ORDINANCE_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//span[contains(text(), '" + BUILDING_ORDINANCE + "')]";
    @FindBy(xpath = BUILDING_ORDINANCE_XPATH + "//ancestor::mat-slide-toggle")
    protected WebElement buildingOrdinanceToggleButtonInEditCoverageSideSheet;
    @FindBy(xpath = BUILDING_ORDINANCE_XPATH)
    protected WebElement buildingOrdinanceLabelInEditCoverageSideSheet;
    @FindBy(xpath = BUILDING_ORDINANCE_XPATH + COVERAGE_DESCRIPTION_XPATH)
    protected WebElement buildingOrdinanceDescriptionWebElement;
    @FindBy(xpath = BUILDING_ORDINANCE_XPATH + "//ancestor::coverage-data-card//mat-radio-button")
    protected List<WebElement> buildingOrdinanceRadioButtonElements;
    @FindBy(xpath = BUILDING_ORDINANCE_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]")
    protected WebElement selectedBuildingOrdinanceRadioButtonElement;

    @FindBy(xpath = BUILDING_ORDINANCE_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]//p[1]")
    protected WebElement selectedDollarBuildingOrdinanceValue;


    protected static final String HOME_SHARING = "Home sharing business";
    protected static final String HOME_SHARING_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + HOME_SHARING + "')]";
    @FindBy(xpath = HOME_SHARING_XPATH)
    protected WebElement homeSharingLabelInEditCoverageSideSheet;
    @FindBy(xpath = HOME_SHARING_XPATH + COVERAGE_DESCRIPTION_XPATH)
    protected WebElement homeSharingDescriptionWebElement;
    @FindBy(xpath = HOME_SHARING_XPATH + COVERAGE_DESCRIPTION_XPATH + "//following::div[1]")
    protected WebElement homeShariongCoveredValueWebElement;

    @FindBy(xpath = "//app-home-policy-banner//mat-card/p[1]")
    private WebElement youGetAllTheseWithYourHomePolicyTitle;
    private static final String DEDUCTIBLES_SECTION_BASE = "//app-home-policy-banner//mat-card//div[contains(@class,'home-policy-banner_list-card')][1]";
    @FindBy(xpath = DEDUCTIBLES_SECTION_BASE + "//img")
    private WebElement decliningDeductiblesIcon;
    @FindBy(xpath = DEDUCTIBLES_SECTION_BASE + "//span")
    private WebElement decliningDeductiblesTitle;
    @FindBy(xpath = DEDUCTIBLES_SECTION_BASE + "//p[2]")
    private WebElement decliningDeductiblesDescription;
    private static final String CLAIM_FORGIVENESS_SECTION_BASE = "//app-home-policy-banner//mat-card//div[contains(@class,'home-policy-banner_list-card')][2]";
    private static final String CLAIM_FORGIVENESS_SECTION_BASE_RENTERS = "//app-home-policy-banner//mat-card//div[contains(@class,'home-policy-banner_list-card')][1]";

    //    @FindBy(xpath = CLAIM_FORGIVENESS_SECTION_BASE + "//mat-icon")
    private WebElement claimForgivenessIcon;
    @FindBy(xpath = CLAIM_FORGIVENESS_SECTION_BASE + "//div//p[1]")
    private WebElement claimForgivenessTitle;
    @FindBy(xpath = CLAIM_FORGIVENESS_SECTION_BASE + "//div//p[2]")
    private WebElement claimForgivenessDescription;
    private static final String CLAIM_FREE_SECTION_BASE = "//app-home-policy-banner//mat-card//div[contains(@class,'home-policy-banner_list-card')][3]";
    private static final String CLAIM_FREE_SECTION_BASE_RENTERS = "//app-home-policy-banner//mat-card//div[contains(@class,'home-policy-banner_list-card')][2]";

    @FindBy(xpath = CLAIM_FREE_SECTION_BASE + "//i")
    private WebElement claimFreeDiscountIcon;
    @FindBy(xpath = CLAIM_FREE_SECTION_BASE + "//p[1]")
    private WebElement claimFreeDiscountTitle;
    @FindBy(xpath = CLAIM_FREE_SECTION_BASE + "//p[2]")
    private WebElement claimFreeDiscountDescription;
    @FindBy(xpath = "//button[@aria-label='ACV']")
    protected WebElement acvToggleButtonUnderPersonalProperty;
    @FindBy(xpath = "//button[@aria-label='RCV']")
    protected WebElement rcvToggleButtonUnderPersonalProperty;

    private static final String XPATH_TO_BUNDLE_PAGE_HEADER = "//h1";
    @FindBy(xpath = XPATH_TO_BUNDLE_PAGE_HEADER)
    private WebElement bundlePropertyQuoteReviewPageTitle;

    @FindBy(xpath = XPATH_TO_BUNDLE_PAGE_HEADER + "/following-sibling::*[contains(@class, 'tui-stacking')]")
    private WebElement bundlePropertyQuoteReviewPageSubtitle;
    protected static final String PERSONAL_PROPERTY_KEY_WITH_RCV = PERSONAL_PROPERTY + " (Replacement cost value)";
    protected static final String PERSONAL_PROPERTY_KEY_WITH_ACV = PERSONAL_PROPERTY + " (Actual cost value)";
    @FindBy (xpath = "//button[contains(text(),'Next: Review more')]")
    protected WebElement nextMorePropertyCoveragesButton;
    @FindBy (css = "button[class='tui-btn tui-btn-primary home-quote-start-checkout-button']")
    protected WebElement reviewMoreRentersCoveragesButton;
    protected static final String MONTHLY_AMOUNT_TEXT_XPATH = "//div[contains(text(),'" + MONTHLY_AMOUNT_TEXT + "')]";
    @FindBy (xpath = "//div[contains(text(),'*The amount shown applies when premium is paid automatically')]")
    protected WebElement monthlyAmountText;

    protected static final String MONTHLY_AMOUNT_TEXT_2_XPATH = "//div[contains(text(),'" + MONTHLY_AMOUNT_TEXT_PART2 + "')]";
    @FindBy (xpath = "//div[contains(text(),'is for insurance coverage you select')]")
    protected WebElement monthlyAmount2Text;
    @FindBy (xpath = "//button[@id='priceAlternativeButton']")
    protected WebElement viewPricingLink;

    protected static final String PERSONAL_PROPERTY_LIMIT = "Limit";

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceHRCReviewQuoteBasePage() throws Exception {
    }

    public boolean isOnReviewQuotePage(boolean longWait) {
        waitForSkeletonToBeGone();
        if (longWait) {
            try {
                wait.until(ExpectedConditions.or(
                        ExpectedConditions.visibilityOf(linkChangeCoverage),
                        ExpectedConditions.visibilityOf(tryAgainButton)));
            } catch (TimeoutException te) {
                return false;
            }
        }
        return isElementVisible(linkChangeCoverage, 3);
    }

    public boolean isOnBundlePropertyReviewQuotePage() throws Exception {
        try {
            driverWait(5);
            wait.until(ExpectedConditions.or(
                    ExpectedConditions.visibilityOf(linkChangeCoverage),
                    ExpectedConditions.visibilityOf(editDeductibleButton)));
        } catch (TimeoutException te) {
            return false;
        }
        return true;
    }

    public String getQuotePriceOnCard() {
        if (isUseMobileViewEnabled()) {
            waitElementBeVisible(quotePriceOnCardMobile);
            return getTextFromElement(quotePriceOnCardMobile);
        } else {
            waitElementBeVisible(quotePriceOnCardDesktop);
            return getTextFromElement(quotePriceOnCardDesktop);
        }
    }

    public void clickOnContinueButton() {
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(buttonContinueMobile);
        } else {
            waitAndClickElement(buttonContinueDesktop);
        }
    }

    public void clickContinueToMoreCoveragesButton() {
        scrollToBottomOfPage();
        clickElement(nextMorePropertyCoveragesButton);
    }

    public void clickReviewMoreRentersCoveragesButton() {
        scrollToBottomOfPage();
        clickElement(reviewMoreRentersCoveragesButton);
    }

    public String getPrimaryCoveragesOnCard() {
        try {
            if (isUseMobileViewEnabled()) {
                if (isElementDisplayed(expandQuoteCard, 2)) {
                    waitAndClickElement(expandQuoteCard);
                }
                waitElementBeVisible(primaryCoveragesPriceOnCardMobile);
            } else {
                waitElementBeVisible(primaryCoveragesPriceOnCardDesktop);
            }
        } catch (StaleElementReferenceException e) {
            sleep(3);
        }
        if (isUseMobileViewEnabled()) {
            return getTextFromElement(primaryCoveragesPriceOnCardMobile);
        } else {
            return getTextFromElement(primaryCoveragesPriceOnCardDesktop);
        }
    }

    public String getAllOtherCoveragesPriceOnCard() {
        try {
            if (isUseMobileViewEnabled()) {
                if (isElementDisplayed(expandQuoteCard, 2)) {
                    waitAndClickElement(expandQuoteCard);
                }
                waitElementBeVisible(quoteOptionalCoveragesPriceOnCardMobile);
            } else {
                waitElementBeVisible(quoteOptionalCoveragesPriceOnCardDesktop);
            }
        } catch (StaleElementReferenceException e) {
            sleep(2);
        }
        if (isUseMobileViewEnabled()) {
            return getTextFromElement(quoteOptionalCoveragesPriceOnCardMobile);
        } else {
            return getTextFromElement(quoteOptionalCoveragesPriceOnCardDesktop);
        }
    }

    public String getDiscountsOnCard() {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard,2)) {
                waitAndClickElement(expandQuoteCard);
            }
            waitElementBeVisible(quoteDiscountsOnCardMobile);
            return getTextFromElement(quoteDiscountsOnCardMobile);
        } else {
            waitElementBeVisible(quoteDiscountsOnCardDesktop);
            return getTextFromElement(quoteDiscountsOnCardDesktop);
        }
    }

    public void clickViewMonthlyPricing() {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard,2)) {
                waitAndClickElement(expandQuoteCard);
            }
            waitAndClickElement(linkViewMonthlyPricingMobile);
        } else {
            waitAndClickElement(linkViewMonthlyPricingDesktop);
        }
    }

    public void clickPriceAlternative() {
        clickElement(linkPriceAlternative);
    }

    public boolean isViewMonthlyPricingLink() throws Exception {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard,2)) {
                waitAndClickElement(expandQuoteCard);
            }
            return isElementPresent(By.xpath(VIEW_MONTHLY_PRICING_LINK_MOBILE_XPATH));
        } else {
            return isElementPresent(By.xpath(VIEW_MONTHLY_PRICING_LINK_DESKTOP_XPATH));
        }
    }

    public boolean isViewPayInFullPricingLink() throws Exception {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard,2)) {
                waitAndClickElement(expandQuoteCard);
            }
            return isElementPresent(By.xpath(VIEW_PAY_IN_FULL_PRICING_LINK_MOBILE_XPATH));
        } else {
            return isElementPresent(By.xpath(VIEW_PAY_IN_FULL_PRICING_LINK_DESKTOP_XPATH));
        }
    }

    public void clickViewPayInFullPricing() {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard,2)) {
                waitAndClickElement(expandQuoteCard);
            }
            waitAndClickElement(linkViewPayInFullPricingMobile);
        } else {
            waitAndClickElement(linkViewPayInFullPricingDesktop);
        }
    }

    public boolean isPresentmentCardPriceHeader() {
        if (isUseMobileViewEnabled()) {
            return getTextFromElement(presentmentCardPriceHeaderMobile).equals(PRESENTMENT_CARD_PRICE_HEADER);
        } else {
            return getTextFromElement(presentmentCardPriceHeaderDesktop).equals(PRESENTMENT_CARD_PRICE_HEADER);
        }
    }

    public void waitContinueButtonVisibleClickable() {
        if (isUseMobileViewEnabled()) {
            waitElementBeVisibleClickable(buttonContinueMobile);
        } else {
            waitElementBeVisibleClickable(buttonContinueDesktop);
        }
    }

    public boolean isViewMonthlyPricingLinkPresent() throws Exception {
        return isElementPresent(By.xpath(VIEW_MONTHLY_PRICING_LINK_XPATH));
    }

    public void selectRatePackage(String ratePackage) throws Exception {
        WebElement we = driver().findElement(By.xpath(PACKAGE_TABS_XPATH + "[.='" + ratePackage + "']"));
        waitAndClickElement(we);
    }

    public void clickEditDeductiblesLink() {
        Log.info("Clicking on edit deductible button");
        waitAndClickElement(editDeductibleButton);
    }

    public void clickOnCloseIconInPolicyDeductibleSideSheet() {
        waitAndClickElement(closeIconPolicyDeductibleSideSheet);
    }

    public int getNumberOfPackageTabs() throws Exception {
        return driver().findElements(By.xpath(PACKAGE_TABS_XPATH)).size();
    }

    public String getSelectedPackage() throws Exception {
        List<WebElement> packageTabs = driver().findElements(By.xpath(PACKAGE_TABS_XPATH));
        for (WebElement tab : packageTabs) {
            if (getAttributeData(tab, ARIA_SELECTED).equals(LOWERCASE_TRUE)) {
                return getTextFromElement(tab);
            }
        }
        return null;
    }

    public void clickRecalculateButtonHomeLobInSideSheet() {
        waitAndClickElement(recalculateButtonHomeLobSideSheet);
        Log.info("Clicked recalculate button in the side sheet.");
        waitForPageToBeReady();
        if (isTryAgainPagePresent() && !wasTryAgainSuccessful()) {
            waitAndClickElement(tryAgainButton);
        }
    }
    public void clickRecalculateButtonCondoRentersInSideSheet() {
        waitAndClickElement(recalculateButtonRentersCondoInSideSheet);
        Log.info("Clicked recalculate button in side sheet.");
        waitForPageToBeReady();
        if (isTryAgainPagePresent() && !wasTryAgainSuccessful()) {
            waitAndClickElement(tryAgainButton);
        }
    }

    public void clickResetChangesButtonCondoRentersInSideSheet() {
        waitAndClickElement(resetChangesButtonRentersCondoInSideSheet);
        Log.info("Clicking reset changes button in side sheet.");
    }



    public void clickResetChangesButtonHomeLob() {
        waitAndClickElement(resetChangesButton);
    }

    public void clickKeepEditingButton() {
        waitAndClickElement(keepEditingButton);
        Log.info("Clicking keep editing button in reset changes pop up.");
    }

    public void clickResetValueButton() {
        waitAndClickElement(resetButton);
        Log.info("Clicking reset button in reset changes pop up.");
    }

    public void clickCloseIconOnDeductibleSideSheet() {
        waitAndClickElement(closeIconInDeductibleSideSheet);
    }

    public void clickOnStandardPackage() {
        waitAndClickElement(standardPackageButton);
    }
    public void clickOnEnhancedPackage() {
        waitAndClickElement(enhancedPackageButton);
    }
    public void clickOnPremierPackage() {
        waitAndClickElement(premierPackageButton);
    }

    public void changeBundleQuotePricing(String pricing) {
        if (isElementDisplayed(bundleQuoteContainer, 3)) {
            String breakpoint = isUseMobileViewEnabled() || isMobileApplication() ? "mobile" : "desktop";
            try {
                WebElement fullPriceForPropertyLink = bundleQuoteContainer.findElement(By.xpath(String.format(CARD_XPATH_STRING + "//a", breakpoint)));
                if (getTextFromElement(fullPriceForPropertyLink).contains(pricing.toLowerCase())) {
                    clickElement(fullPriceForPropertyLink);
                }
            } catch (Exception e) {
                Log.info("findElement exception, continue");
            }
        }
    }

    public void showOrHideSpecialLimitsSection(boolean showSection) {
        if (isElementDisplayed(showSpecialLimitsLinkPlusIcon, 2) == showSection) {
            scrollAndClickOnElement(showSpecialLimitsLinkButton);
        }
    }

    public void clickOnLossOfUseDropDown(){
        waitAndClickElement(lossOfUseDropDownWebElement);
    }

    protected WebElement getCheckedAllPerilLossesCoverageValue(List<WebElement> allPerilLossesRadioButtons) {
        List<WebElement> checkedCoverageElement = allPerilLossesRadioButtons.stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).collect(Collectors.toList());
        return checkedCoverageElement.get(0);
    }

    protected List<String> expectedCoveragesValue(String coverageCode, String lobType) throws Exception {
        AppStore.Home appStore = getSessionStorageAppStore().getHome();
        List<CoverageValue> coverageValues = appStore.getDropdowns().getQuote().getCoverageValues().stream().filter(i -> i.getCoverageCode().equals(coverageCode)).collect(Collectors.toList());
        List<String> expectedCoverageValues = coverageValues.get(0).getValues().stream().map(CoverageValue.Value::getAmount).collect(Collectors.toList());
        if(lobType.equals(CONDO) || lobType.equals(RENTERS)){
            expectedCoverageValues.sort(Comparator.comparing(Integer::parseInt));
        }

        String valueToSet;
        int dwellingCoverageValue = 0;
        if (appStore.getDwellingCoverage() != null) {
            dwellingCoverageValue = Integer.parseInt(appStore.getDwellingCoverage());
        }
        int numberOfExpectedValues = expectedCoverageValues.size();
        for (int i = 0; i < numberOfExpectedValues; i++) {
            String expectedCoverageValuesInPercentage = expectedCoverageValues.get(i);
            if (expectedCoverageValuesInPercentage.contains("%")) {
                String stringMultiplier = expectedCoverageValuesInPercentage.replaceAll("[%]", EMPTY_STRING);
                double multiplier = Double.valueOf(stringMultiplier);

                // convert 1.0% into 1% etc
                if(expectedCoverageValuesInPercentage.length() >= 3){
                    expectedCoverageValuesInPercentage = expectedCoverageValuesInPercentage.replaceAll("\\.0", EMPTY_STRING);
                }

                valueToSet = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf((multiplier * dwellingCoverageValue) / 100)) +
                        SPACE + "(" + expectedCoverageValuesInPercentage + " of Dwelling limit)";

                expectedCoverageValues.set(i, valueToSet);
            } else {
                valueToSet = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(expectedCoverageValues.get(i));
                expectedCoverageValues.set(i, valueToSet);
            }
        }
        return expectedCoverageValues.stream()
                .sorted(Comparator.comparingDouble(s -> Double.parseDouble(s.split(SPACE)[0].replaceAll("[^\\d.]", EMPTY_STRING))))
                .collect(Collectors.toList());
    }

    public void validateContentOfResetChangesPopUp(FarmersSoftAssert sa) {
        String expectedResetChangesHeader = "Reset changes";
        sa.assertEquals(getTextFromElement(resetChangesHeader), expectedResetChangesHeader, "Reset changes header check in reset changes pop up.");

        String expectedAreYouSureYouWantToResetValuesQuestion = "Are you sure you want to reset all to default values?";
        sa.assertEquals(getTextFromElement(areYouSureYouWantToResetChangesQuestion), expectedAreYouSureYouWantToResetValuesQuestion, "Are you sure you want to reset all to default values? question text check");

        String expectedKeepEditingText = "Keep editing";
        sa.assertEquals(getTextFromElement(keepEditingButton), expectedKeepEditingText, "Keep editing button text check");

        String expectedResetValueText = "Reset value";
        sa.assertEquals(getTextFromElement(resetButton), expectedResetValueText, "Reset value text check");
    }

    public void validateQuoteSavedText(String quoteNumber, FarmersSoftAssert sa) {
        final String EXPECTED_QUOTE_PROGRESS_SAVED = "Quote progress is saved!";
        sa.assertEquals(getTextFromElement(saveInProgressFooter), EXPECTED_QUOTE_PROGRESS_SAVED, "Quote progress text is verified.");
        String quoteNumberDisplayed = getTextFromElement(quoteNumberText).replaceAll("\\D", EMPTY_STRING);
        sa.assertEquals(quoteNumberDisplayed, quoteNumber, "Quote number and Quote progress is saved text are displayed.");
    }

    public void clickCloseIconOnCoveragesSideSheet() {
        waitAndClickElement(closeIconOnCoveragesSideSheet);
    }

    public void clickOnLimitedMoldToggleButton(){
        scrollToElement(limitedMoldToggleButtonInEditCoverageSideSheet);
        waitAndClickElement(limitedMoldToggleButtonInEditCoverageSideSheet);
    }
    public void clickOnIncreaseLossAssessmentToggleButton(){
        scrollToElement(increaseLossAssessmentToggleButtonInEditCoverageSideSheet);
        waitAndClickElement(increaseLossAssessmentToggleButtonInEditCoverageSideSheet);
    }
    public void clickOnBuildingOrdinanceToggleButton(){
        scrollToElement(buildingOrdinanceToggleButtonInEditCoverageSideSheet);
        waitAndClickElement(buildingOrdinanceToggleButtonInEditCoverageSideSheet);
    }


    public void validateContentOfDeductiblesSideSheet(FarmersSoftAssert fsa, String lobType) throws Exception {
        fsa.assertEquals(getTextFromElement(coveragesHeader), DEDUCTIBLES, "Coverages header text check - " + lobType + " lob.");
        waitElementBeVisible(closeIconOnCoveragesSideSheet);
        fsa.assertTrue(closeIconOnCoveragesSideSheet.isDisplayed(), "Close icon displayed in coverage side sheet - " + lobType + " lob.");

        fsa.assertEquals(getTextFromElement(allPerilsHeaderInCoverageSideSheet), EXPECTED_ALL_PERILS_HEADER_TEXT, "All peril header inside condo coverage side sheet check - " + lobType + " lob.");
        fsa.assertEquals(getTextFromElement(allPerilExplanation), EXPECTED_ALL_PERILS_EXPLANATION_TEXT, "All peril explanation inside condo coverage side sheet check - " + lobType + " lob.");
        Log.info("Validating deductibles header, close icon, all perils header, all peril description in deductible side sheet for " + lobType);

        List<String> foundCoverageValuesForAllPerilLosses = allPerilMatRadioButtonInCoverageSideSheet.stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(getSortedList(foundCoverageValuesForAllPerilLosses), getSortedList(expectedCoveragesValue(ALL_PERILS_COVERAGE_CODE, lobType)), "All peril losses coverage values matching - " + lobType + " lob.");
        Log.info("Validating all peril loss radio button options are displayed as expected in deductible side sheet for " + lobType);

        // select first unchecked radio button
        WebElement firstUncheckedMatRadioButton = uncheckedPerilMatRadioButtonInCoverageSideSheet.get(0);

        String firstToBeSelectedRadioButtonText = getTextFromElement(firstUncheckedMatRadioButton);
        waitAndClickElement(firstUncheckedMatRadioButton);
        if(!getAttributeData(firstUncheckedMatRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED)) {
            waitAndClickElement(firstUncheckedMatRadioButton);
        }
        Log.info("Selecting all peril loss button in side sheet to " + firstToBeSelectedRadioButtonText + " in order to validate recalculate and reset text in deductible side sheet.");
        validateRecalculateResetButtonTextInSideSheet(fsa, lobType);

        clickResetChangesButtonCondoRentersInSideSheet();
        validateContentOfResetChangesPopUp(fsa);
        clickKeepEditingButton();
        clickResetChangesButtonCondoRentersInSideSheet();
        clickResetValueButton();
        firstUncheckedMatRadioButton = uncheckedPerilMatRadioButtonInCoverageSideSheet.get(0);
        waitAndClickElement(firstUncheckedMatRadioButton);
        if(!getAttributeData(firstUncheckedMatRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED)) {
            waitAndClickElement(firstUncheckedMatRadioButton);
        }
        Log.info("Selecting all peril loss button in side sheet to " + firstToBeSelectedRadioButtonText + " in order to validate the updated deductible value in main review quote page.");
        sleep(5);
        clickRecalculateButtonCondoRentersInSideSheet();
        waitForSpinnerToBeGone();
        sleep(3);
        String deductibleAmountValue = getAllPerilDeductible();
        fsa.assertEquals(deductibleAmountValue, firstToBeSelectedRadioButtonText, "Default all peril losses selection check - " + lobType + " lob.");
    }


    public void validateRecalculateResetButtonTextInSideSheet(FarmersSoftAssert sa, String lobType){
        sa.assertTrue(recalculateButtonRentersCondoInSideSheet.isDisplayed(), "Recalculate button displayed - " + lobType + " lob.");
        sa.assertTrue(resetChangesButtonRentersCondoInSideSheet.isDisplayed(), "Reset changes button displayed - " + lobType + " lob.");
        sa.assertEquals(getTextFromElement(recalculateButtonRentersCondoInSideSheet), EXPECTED_RECALCULATE_BUTTON_TEXT, "Recalculate button text check - " + lobType + " lob.");
        sa.assertEquals(getTextFromElement(resetChangesButtonRentersCondoInSideSheet), EXPECTED_RESET_CHANGES_LINK_TEXT, "Reset changes button text check - " + lobType + " lob.");
    }

    public String editDeductiblesSideSheet() {
        String allPeril = getTextFromElement(waitElementBeVisible(deductibleAmount.get(1)));

        clickEditDeductiblesLink();
        WebElement we = allPerilMatRadioButtonInCoverageSideSheet.stream().filter(el -> !getTextFromElement(el).equals(allPeril)).findAny().get();
        Log.info("Randomly selecting All perils deductible value: " + getTextFromElement(we));
        waitAndClickElement(we);
        waitAndClickElement(we);
        clickRecalculateButtonCondoRentersInSideSheet();
        waitForSpinnerToBeGone();
        sleep(2);
        return getAllPerilDeductible();
    }

    public String getAllPerilDeductible() {
        return getTextFromElement(deductibleAmount.get(1));
    }

    public String getPersonalPropertyValue() throws Exception {
        return getSessionStorageAppStore().getHome().getCoverageForPackage("C", "EFT").getCvgInfoForCvgDesc(PERSONAL_PROPERTY).getCvgAmt();
    }

    @Override
    public void clickContinueButton() {
        if (isUseMobileViewEnabled()) {
            scrollAndClickOnElement(continueButtonMobile);
            if (this.isOnReviewQuotePage(false)) {
                waitAndClickElement(continueButtonMobile);
            }
        } else {
        	scrollAndClickOnElement(continueButtonDesktop);
            if (this.isOnReviewQuotePage(false)) {
                waitAndClickElement(continueButtonDesktop);
            }
        }
        waitForSpinnerToBeGone();
        testStep("Clicked continue button on Review quote page");
    }

    public void clickOnAddEditCoverageLinkButton(){
        waitAndClickElement(condoRentersAddEditCoverageLink);
        Log.info("Clicking add edit coverage link for Condo/Renters lob.");
    }

    public List<String> getCoverageValuesByCoverageDescription(String coverageDescription) throws Exception {
        List<CoverageValue> coverageValues = getSessionStorageAppStore().getHome().getDropdowns().getQuote().getCoverageValues();
        CoverageValue coverageValueByDescription = coverageValues.stream().filter(i -> i.getCoverageDescription().equalsIgnoreCase(coverageDescription)).collect(Collectors.toList()).get(0);
        List<String> coverageValueAmount = coverageValueByDescription.getValues().stream().map(i -> i.getAmount()).collect(Collectors.toList());
        List<String> coverageValueAmountNoCoverageAmount = coverageValueAmount.stream().filter(i -> !i.equals("No Coverage")).collect(Collectors.toList());
        return coverageValueAmountNoCoverageAmount;
    }

    public void validateCommonContentFromEditCoverageSideSheetCondoRentersLob(FarmersSoftAssert sa, String lobType, String expectedRentersCoveragesHeader){
        waitElementBeVisible(condoRentersCoverageSideSheetHeader);
        sa.assertEquals(getTextFromElement(condoRentersCoverageSideSheetHeader), expectedRentersCoveragesHeader, lobType + " coverages header check - " + lobType);
        //        sa.assertTrue(closeIconInCondoRentersCoverageSideSheet.isDisplayed(), "Close icon is not visible in condo edit coverage side sheet - " + lobType);

        String expectedCoveragesHintInEditCoverageSideSheet = "The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
        sa.assertEquals(getTextFromElement(coverageHintEditCoverageSideSheet), expectedCoveragesHintInEditCoverageSideSheet, lobType + " coverages hint text check - " + lobType);

        Log.info("Validating condo/renters header and description in Renters/Condo side sheet");
    }
    protected String getCoveragePriceByNameFromScreen (String coverageName) throws Exception {
        String COVERAGE_VALUE_XPATH = "//div[contains(@class,'tui-body') and contains(text(),'" + coverageName + "')]/following-sibling::div[contains(@class,'coverage-price-column')]";
        return getTextFromElement(driver().findElement(By.xpath(COVERAGE_VALUE_XPATH)));
    }

    public void validateLossOfUseSection(FarmersSoftAssert sa, Map<String, String> coverageAmountKeyValuePair, String stateCode, String lobType) throws Exception {
        String LOSS_OF_USE = getLossOfUseCoverageName(stateCode);
        sa.assertTrue(lossOfUseLabelInEditCoverageSideSheet.isDisplayed(), LOSS_OF_USE + " label displayed in edit coverage side sheet - " + lobType);
        String lossOfUseDescription = "This coverage, also known as Coverage D, may pay you for an increase in living expenses (housing, food, etc.) " +
                "you incur while your residence is being repaired as a result of a covered loss up to the number of months selected.";
        String lossOfUseDescription_CT = "Loss of use coverage, also known as Coverage D, can pay you for an increase in living expenses (housing, food, etc.) " +
                "you incur while your residence is being repaired as a result of a covered loss up to the number of months allowed in Additional living expenses.";
        lossOfUseDescription = stateCode.equals(CT) ? lossOfUseDescription_CT : lossOfUseDescription;
        sa.assertEquals(getTextFromElement(lossOfUseDescriptionWebElement), lossOfUseDescription, LOSS_OF_USE + " description check - " + lobType);

        sa.assertTrue(lossOfUseDropDownWebElement.isDisplayed(), LOSS_OF_USE + " drop down element is not present in side sheet - " + lobType);

        String expectedLossOfUsePlaceHolderText = stateCode.equals(CT) ? "Loss of use" : "Loss of use / additional living expenses";
        sa.assertEquals(getTextFromElement(lossOfUseDropDownPlaceHolder), expectedLossOfUsePlaceHolderText, LOSS_OF_USE + " drop down element place holder text check in side sheet - " + lobType);

        clickOnLossOfUseDropDown();

        if (lobType.equals(RENTERS)) {
            validateLossOfUseDropdownValue(sa, stateCode);
        }
        List<String> foundLossOfUseDropDownOptions = lossOfUseDropDownOptions.stream().map(this::getTextFromElement).collect(Collectors.toList());
        String lossOfUseCoverageValue = coverageAmountKeyValuePair.get(LOSS_OF_USE);
        List<String> lossOfUseDropDownOptionsWithCurrencyFormat = getFormattedDropDownOptionsForLossOfUse(stateCode);
        sa.assertEquals(lossOfUseDropDownOptionsWithCurrencyFormat,foundLossOfUseDropDownOptions, LOSS_OF_USE + " drop down values are not matching - " + lobType);
        sa.assertEquals(getTextFromElement(selectedLossOfUseOptionWebElement).replace("/ ", EMPTY_STRING), lossOfUseCoverageValue.replaceAll("[()]", EMPTY_STRING),
                LOSS_OF_USE + " drop down selected values are not matching - " + lobType);
        waitAndClickElement(selectedLossOfUseOptionWebElement);
    }

    public List<String> getFormattedDropDownOptionsForLossOfUse(String stateCode) throws Exception {
        List<String> lossOfUseAmountWithoutNoCoverageAmount = getCoverageValuesByCoverageDescription(getLossOfUseCoverageName(stateCode));
        List<String> lossOfUseAmountWithoutDollarSign = lossOfUseAmountWithoutNoCoverageAmount.stream().map(i -> i.replace("$", "")).collect(Collectors.toList());
        List<Integer> lossOfUseAmountInNumericForm = lossOfUseAmountWithoutDollarSign.stream().map(Integer::parseInt).collect(Collectors.toList());

        int personalPropertyValue = getPersonalPropertyValueFromAppStore();

        List<String> lossOfUseDropDownOptionsWithCurrencyFormat = new ArrayList<>();
        if(stateCode.equals(VA)){
            for (int i = 0; i < lossOfUseAmountInNumericForm.size(); i++){
            int lossOfUseCoverageAmount = personalPropertyValue*lossOfUseAmountInNumericForm.get(i)/100;
            String currencyFormatAmount = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(lossOfUseCoverageAmount));
            lossOfUseDropDownOptionsWithCurrencyFormat.add(currencyFormatAmount);
            }
        }else{
            List<String> lossOfUseTerms = stateCode.equals(CO) ? Arrays.asList("24 months") : Arrays.asList("12 months", "24 months");
            for (int i = 0; i < lossOfUseTerms.size(); i++){
            for (int j = 0; j < lossOfUseAmountInNumericForm.size(); j++){
                int lossOfUseCoverageAmount = personalPropertyValue*lossOfUseAmountInNumericForm.get(j)/100;
                String currencyFormatAmount = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(lossOfUseCoverageAmount));
                lossOfUseDropDownOptionsWithCurrencyFormat.add(currencyFormatAmount + " / " + lossOfUseTerms.get(i));
            }
            }
        }
        return lossOfUseDropDownOptionsWithCurrencyFormat;
    }

    public void validatePersonalLiabilitySection(FarmersSoftAssert sa, Map<String, String> coverageAmountKeyValuePair, String lobType) throws Exception {
        sa.assertTrue(personalLiabilityLabelInEditCoverageSideSheet.isDisplayed(), PERSONAL_LIABILITY + " label displayed in edit coverage side sheet - " + lobType );
        String personalLiabilityDescription = "As set forth in your policy, this coverage, also known as Coverage E, " +
            "can pay damages an insured becomes legally obligated to pay because of bodily injury or property damage to others that results from an occurrence.";
        sa.assertEquals(getTextFromElement(personalLiabilityDescriptionWebElement), personalLiabilityDescription, PERSONAL_LIABILITY + " description check - " + lobType);
        String personalLiabilityCoverageValue = coverageAmountKeyValuePair.get(PERSONAL_LIABILITY);

        List<String> foundPersonalLiabilityRadioOptions = personalLiabilityRadioButtonElements.stream().map(this::getTextFromElement).collect(Collectors.toList());

        List<String> personalLiabilityCoverageValueAmountFromAppStore = getCoverageValuesByCoverageDescription(PERSONAL_LIABILITY);
        sa.assertEquals(personalLiabilityCoverageValueAmountFromAppStore, foundPersonalLiabilityRadioOptions, PERSONAL_LIABILITY + " coverage amount options are not matching in the radio selection group - " + lobType);
        sa.assertEquals(getTextFromElement(selectedPersonalLiabilityRadioButtonElement), personalLiabilityCoverageValue, PERSONAL_LIABILITY + " selected coverage amount radio button is not checked - " + lobType);
        Log.info("Validating " + PERSONAL_LIABILITY + " coverage header/description, available coverages radio button options and selected radio button value on coverages side sheet.");
    }

    public void validateMedicalPaymentToOthersSection(FarmersSoftAssert sa, Map<String, String> coverageAmountKeyValuePair, String lobType) throws Exception {
        sa.assertTrue(medicalPaymentToOthersLabelInEditCoverageSideSheet.isDisplayed(), MEDICAL_PAYMENT_TO_OTHERS + " label displayed in edit coverage side sheet - " + lobType );
        String medicalPaymentToOthersDescription = "This coverage, also known as Coverage F, can pay medical costs, " +
            "up to the limit selected by you, for guests who are injured at your residence, regardless of your legal liability.";
        sa.assertEquals(getTextFromElement(medicalPaymentToOthersDescriptionWebElement), medicalPaymentToOthersDescription, MEDICAL_PAYMENT_TO_OTHERS + " description check - " + lobType);
        String medicalPaymentToOthersCoverageValue = coverageAmountKeyValuePair.get(MEDICAL_PAYMENT_TO_OTHERS);

        List<String> foundMedicalPaymentToOthersRadioOptions = medicalPaymentToOthersRadioButtonElements.stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());

        List<String> medicalPaymentToOthersCoverageValueAmountFromAppStore = getCoverageValuesByCoverageDescription(MEDICAL_PAYMENT_TO_OTHERS);

        sa.assertEquals(medicalPaymentToOthersCoverageValueAmountFromAppStore, foundMedicalPaymentToOthersRadioOptions, MEDICAL_PAYMENT_TO_OTHERS + " coverage amount options are not matching in the radio selection group - " + lobType);
        sa.assertEquals(getTextFromElement(selectedMedicalPaymentToOthersRadioButtonElement), medicalPaymentToOthersCoverageValue, MEDICAL_PAYMENT_TO_OTHERS + " selected coverage amount radio button is not checked - " + lobType);
        Log.info("Validating " + MEDICAL_PAYMENT_TO_OTHERS + " coverage header/description, available coverages radio button options and selected radio button value on coverages side sheet.");
    }

    public String randomlySelectLossOfUseFromDropDown(){
        scrollAndClickOnElement(lossOfUseDropDownWebElement);
        waitElementBeVisible(lossOfUseDropDownOption);
        Random random = new Random();
        int index = random.nextInt(lossOfUseDropDownOptions.size());
        waitAndClickElement(lossOfUseDropDownOptions.get(index));
        return getTextFromElement(lossOfUseDropDownWebElement).replace(" /", EMPTY_STRING);
    }

    public String randomlySelectPersonalLiabilityRadioButton(){
        scrollToElement(personalLiabilityDescriptionWebElement);
        Random random = new Random();
        int index = random.nextInt(personalLiabilityRadioButtonElements.size());
        waitAndClickElement(personalLiabilityRadioButtonElements.get(index));
        return getTextFromElement(selectedPersonalLiabilityRadioButtonElement);
    }

    public String randomlySelectMedicalPaymentRadioButton(){
        scrollToElement(medicalPaymentToOthersLabelInEditCoverageSideSheet);
        Random random = new Random();
        int index = random.nextInt(medicalPaymentToOthersRadioButtonElements.size());
        waitAndClickElement(medicalPaymentToOthersRadioButtonElements.get(index));
        return getTextFromElement(selectedMedicalPaymentToOthersRadioButtonElement);
    }

    public void validateEditedCoverageValueUpdatedOnMainScreen(FarmersSoftAssert sa, Map<String, String> coverageAmountKeyValuePair, String lobType){
        List<String> foundPrimaryCoverageName = getCondoRentersCoveragesNamesOnReviewQuotePage(lobType);
        List<String> foundPrimaryCoverageAmount = getCondoRentersCoveragesAmountOnReviewQuotePage();
        if (lobType.equals(CONDO)){
            foundPrimaryCoverageAmount.set(2, foundPrimaryCoverageAmount.get(2).replaceAll("[()]", ""));
        } else {
            for (int i = 0; i < foundPrimaryCoverageAmount.size(); i++) {
                if (foundPrimaryCoverageAmount.get(i).contains("(") || foundPrimaryCoverageAmount.get(i).contains(")")) {
                    foundPrimaryCoverageAmount.set(i, foundPrimaryCoverageAmount.get(i).replaceAll("[()]", EMPTY_STRING));
                    break;
                }
            }
        }
        List<String> expectedCoverageNames = getSortedList(new ArrayList<>(coverageAmountKeyValuePair.keySet()));
        sa.assertEquals(foundPrimaryCoverageName, expectedCoverageNames, "Coverage names after edited from side sheet - " + lobType);
        sa.assertEquals(getSortedList(foundPrimaryCoverageAmount), getSortedList(new ArrayList<>(coverageAmountKeyValuePair.values())), "Coverage amount values after edited from side sheet - " + lobType);
        Log.info("Validate if edited coverages value and coverage names on main review quote page are matching on click of recalculate button in edit coverage side sheet.");
    }

    public List<String> getCondoRentersCoveragesAmountOnReviewQuotePage(){
        Log.info("Preparing the list of found coverages on main review quote page from the xpath.");
        return condoRentersCoveragesAmountOnReviewQuotePage.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public List<String> getCondoRentersCoveragesNamesOnReviewQuotePage(String lobType){
        Log.info("Preparing the list of found coverages amount on main review quote page from the xpath.");
        List<String> coverageNames = getCondoRentersCoverageNamesFromCovNameWebElements();
        if (coverageNames.contains(PERSONAL_PROPERTY + " (Replacement cost value)")) {
            coverageNames.remove(PERSONAL_PROPERTY + " (Replacement cost value)");
            coverageNames.add(PERSONAL_PROPERTY);
        }
        if (lobType.equals(RENTERS) && coverageNames.contains("Limit")) {
            coverageNames.add(coverageNames.indexOf("Limit"), PERSONAL_PROPERTY);
            coverageNames.remove("Limit");
        }
        return getSortedList(coverageNames);
    }

    public List<String> getCondoRentersCoverageNamesFromCovNameWebElements(){
        return condoRentersCoveragesNamesOnReviewQuotePage.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public void validateYouGetAllTheseWithYourPolicySection(FarmersSoftAssert sa, String lobType) throws Exception {
        String expectedYouGetAllTheseWithYourHomePolicyTitle = "";
        String expectedDecliningDeductiblesDescription = "";
        String expectedClaimForgivenessTitle = "Claim Forgiveness";
        String expectedClaimForgivenessDescription = "We won't raise your premium because of a claim once you've gone claim-free with Farmers for five years.";
        String expectedClaimFreeDiscountTitle = "Claim Free Discount";
        String expectedClaimFreeDiscountDescription = "";
        if (lobType.equals(HOME) || lobType.equals(CONDO)) {
            String expectedClaimFreeYears = isHomeFlexState(getStateCodeFromAppStore()) && lobType.equals(HOME) ? "one year" : "three years";  // F96137/US1071553
            expectedClaimFreeDiscountDescription = String.format("You will receive a discount on your %s insurance if you've been claim-free for %s.", lobType, expectedClaimFreeYears);
            lobType = lobType.toLowerCase();
            expectedYouGetAllTheseWithYourHomePolicyTitle = "You get all this with your " + lobType + " policy";
            String expectedDecliningDeductibleTitle = "Declining Deductibles\u00ae";
            sa.assertEquals(decliningDeductiblesIcon.isDisplayed(), true, expectedDecliningDeductibleTitle + " icon displayed - " + lobType);
            sa.assertEquals(getTextFromElement(decliningDeductiblesTitle), expectedDecliningDeductibleTitle, expectedDecliningDeductibleTitle + " header check - " + lobType);
            expectedDecliningDeductiblesDescription = "Earn $50 toward your " + lobType + " deductible each year your "+ lobType.toLowerCase() + " policy is in force.";
            sa.assertEquals(getTextFromElement(decliningDeductiblesDescription), expectedDecliningDeductiblesDescription,
                    "Earn $50 toward description check - " + lobType);

            claimForgivenessIcon = driver().findElement(By.xpath(CLAIM_FORGIVENESS_SECTION_BASE + "//img"));
            claimForgivenessTitle = driver().findElement(By.xpath(CLAIM_FORGIVENESS_SECTION_BASE + "//div//p[1]"));
            claimForgivenessDescription = driver().findElement(By.xpath(CLAIM_FORGIVENESS_SECTION_BASE + "//div//p[2]"));

            claimFreeDiscountIcon = driver().findElement(By.xpath(CLAIM_FREE_SECTION_BASE + "//img"));
            claimFreeDiscountTitle = driver().findElement(By.xpath(CLAIM_FREE_SECTION_BASE + "//p[1]"));
            claimFreeDiscountDescription = driver().findElement(By.xpath(CLAIM_FREE_SECTION_BASE + "//p[2]"));

        } else {
            expectedClaimFreeDiscountDescription = "You will receive a discount on your Home insurance if you've been claim-free for three years.";
            expectedYouGetAllTheseWithYourHomePolicyTitle = "You get all this with your renters policy";
            claimForgivenessIcon = driver().findElement(By.xpath(CLAIM_FORGIVENESS_SECTION_BASE_RENTERS + "//img"));
            claimForgivenessTitle = driver().findElement(By.xpath(CLAIM_FORGIVENESS_SECTION_BASE_RENTERS + "//div//p[1]"));
            claimForgivenessDescription = driver().findElement(By.xpath(CLAIM_FORGIVENESS_SECTION_BASE_RENTERS + "//div//p[2]"));

            claimFreeDiscountIcon = driver().findElement(By.xpath(CLAIM_FREE_SECTION_BASE_RENTERS + "//img"));
            claimFreeDiscountTitle = driver().findElement(By.xpath(CLAIM_FREE_SECTION_BASE_RENTERS + "//p[1]"));
            claimFreeDiscountDescription = driver().findElement(By.xpath(CLAIM_FREE_SECTION_BASE_RENTERS + "//p[2]"));
        }

        sa.assertEquals(getTextFromElement(youGetAllTheseWithYourHomePolicyTitle), expectedYouGetAllTheseWithYourHomePolicyTitle,
                "You get all these with your home policy title check - " + lobType);
        sa.assertEquals(claimForgivenessIcon.isDisplayed(), true, expectedClaimForgivenessTitle + " icon displayed - " + lobType);
        sa.assertEquals(getTextFromElement(claimForgivenessTitle), expectedClaimForgivenessTitle, expectedClaimForgivenessTitle + " header check - " + lobType);
        sa.assertEquals(getTextFromElement(claimForgivenessDescription), expectedClaimForgivenessDescription,
                expectedClaimForgivenessTitle + " description check - " + lobType);


        sa.assertEquals(claimFreeDiscountIcon.isDisplayed(), true, expectedClaimFreeDiscountTitle + " icon displayed - " + lobType);
        sa.assertEquals(getTextFromElement(claimFreeDiscountTitle), expectedClaimFreeDiscountTitle, expectedClaimFreeDiscountTitle + " header check - " + lobType);
        sa.assertEquals(getTextFromElement(claimFreeDiscountDescription), expectedClaimFreeDiscountDescription,
                expectedClaimFreeDiscountTitle + " description check - " + lobType);
    }

    public int getDwellingCoverageInInt(AppStore appStore) {
        return Integer.parseInt(appStore.getHome().getDwellingCoverage());
    }

    public String getSelectedPackage(AppStore appStore){
        return appStore.getHome().getQuote().getSelectedPackageCode();
    }

    public void verifyBundlePropertyQuoteReviewPage(String propertyType, FarmersSoftAssert fsa) {
        String expectedPageTitle = propertyType + " coverages";
        fsa.assertEquals(getTextFromElement(bundlePropertyQuoteReviewPageTitle), expectedPageTitle, propertyType + " quote review page title verification");
        //DE258998 - Renters no longer has a subtitle
        if (propertyType.equals(HOME)) {
            String subtitleContent = getTextFromElement(bundlePropertyQuoteReviewPageSubtitle);
            fsa.assertTrue(subtitleContent.contains("Coverages are based on your selected dwelling coverage of") || subtitleContent.contains("Quote is based on your selected dwelling coverage of")
                    , propertyType + " quote review page subtitle content verification");
        } else {
            fsa.assertTrue(!isElementVisible(bundlePropertyQuoteReviewPageSubtitle, 2), "Renters quote review page does not have a subtitle");
        }
        String expectedContinueToMoreCoveragesButtonText = propertyType.equals(HOME) ? "Next: Review more home coverages" : "Next: Review more renters coverages";
        fsa.assertEquals(getTextFromElement(nextMorePropertyCoveragesButton), expectedContinueToMoreCoveragesButtonText, expectedContinueToMoreCoveragesButtonText + " button text validation");

        verifyBundleQuoteLedgerComponent(propertyType, propertyType, fsa);
    }

    protected String getPersonalPropertyKey(){
        boolean personalPropertyContainsRCV = getCondoRentersCoverageNamesFromCovNameWebElements().contains(PERSONAL_PROPERTY_KEY_WITH_RCV);
        boolean personalPropertyContainsACV = getCondoRentersCoverageNamesFromCovNameWebElements().contains(PERSONAL_PROPERTY_KEY_WITH_ACV);
        if(personalPropertyContainsRCV){
            return PERSONAL_PROPERTY_KEY_WITH_RCV;
        }else if(personalPropertyContainsACV){
            return PERSONAL_PROPERTY_KEY_WITH_ACV;
        }else{
            return PERSONAL_PROPERTY;
        }
    }
    public List<AppStore.Home.CvgInfo> getCovInfoFromAppStore(AppStore appStore, String selectedPaymentMode, String stateCode){
        AppStore.Home.RateQuoteResponse rateQuoteResponse = appStore.getHome().getQuote().getRateQuoteResponses().stream().filter(i -> i.getPaymentMode().equals(selectedPaymentMode)).collect(Collectors.toList()).get(0);
        List<AppStore.Home.CvgInfo> cvgInfo = rateQuoteResponse.getPersHomePolicy().getPersHomeCoverage().getCustomCoverages().getCvgInfo();
        List<AppStore.Home.CvgInfo> listOfPrimaryCoverageFromAppStore = cvgInfo.stream().filter(i -> i.getCvgSection().equals("Primary")).collect(Collectors.toList());
        // KS state personal liability and building additional and alteration index is different from other states
        if(stateCode.equals(KS)){
            Collections.swap(listOfPrimaryCoverageFromAppStore, 3, 4);
        }
        return listOfPrimaryCoverageFromAppStore;
    }
    public int getPersonalPropertyValueFromAppStore() throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        List<AppStore.Home.CvgInfo> covInfoFromAppStore = getCovInfoFromAppStore(appStore, getSelectedPaymentMode(), appStore.getData().getLandingStateCode());
        AppStore.Home.CvgInfo personalPropertyCvg = covInfoFromAppStore.stream().filter(i -> i.getCvgDesc().equals(PERSONAL_PROPERTY)).collect(Collectors.toList()).get(0);
        return getIntCurrencyValueFromStringCurrencyValue(personalPropertyCvg.getCvgAmt());
    }

    public String getOptionalCoverageSumFromAppStore() throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        String selectedPaymentMode = getSelectedPaymentMode();
        String selectedPackage = getSelectedPackage(appStore);
        List<AppStore.Home.CvgInfo> optionalCoverages = appStore.getHome().getCoverageForPackage(selectedPackage, selectedPaymentMode).getCvgInfo().stream()
                .filter(i -> i.getCvgSection().equals("Optional")).collect(Collectors.toList());
        double optionalCoverageSum = 0.0;
        for (AppStore.Home.CvgInfo coverage : optionalCoverages) {
            if ((coverage.getPremiumAmt() != null) && (coverage.getDisplayPremium() != null)) {
                optionalCoverageSum += Double.parseDouble(coverage.getPremiumAmt());
            }
        }
        if (selectedPaymentMode.equals("EFT")) {
            optionalCoverageSum = optionalCoverageSum / 12;
        }
        return CurrencyFormat.convertDoubleToCurrencyStringNoDecimals(optionalCoverageSum);
    }

    public void validateContinueButtonAtPageBottom(FarmersSoftAssert fsa) {
        if (isUseMobileViewEnabled()) {
            fsa.assertTrue(isElementVisibleAndClickable(buttonContinueMobileAtPageBottom,2), "Review quote page - Continue button is displayed at page bottom in mobile view.");
        } else {
            fsa.assertFalse(isElementVisibleAndClickable(buttonContinueMobileAtPageBottom,2), "Review quote page - Continue button is displayed at page bottom in desktop view.");
        }
    }
    public List<AppStore.Home.RateQuoteResponse> getPackageFromRateResponse(String packageCode) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        AppStore.Home.Quote quote = appStore.getHome().getQuote();
        List<AppStore.Home.RateQuoteResponse> rateQuoteResponses = quote.getRateQuoteResponses();
        List<AppStore.Home.RateQuoteResponse> rateQuoteResponsesWithoutKnockOut = rateQuoteResponses.stream().filter(i -> i.getKnockOutBeanList() == null).collect(Collectors.toList());
        return rateQuoteResponsesWithoutKnockOut.stream().filter(i -> i.getRatePackage().equals(packageCode.toUpperCase())).collect(Collectors.toList());
    }

    public void validateFooterTextOnReviewQuotePage(FarmersSoftAssert fsa){
        waitElementBeVisible(monthlyAmountText);
        fsa.assertEquals(getTextFromElement(monthlyAmountText).equals(MONTHLY_AMOUNT_TEXT), true, "Monthly amount text validation");
        fsa.assertEquals(getTextFromElement(monthlyAmount2Text).equals(MONTHLY_AMOUNT_TEXT_PART2), true, "Monthly amount text 2 validation");

    }

    public void clickOnViewPricingLink(){
        clickElement(viewPricingLink);
    }

    public String getLossOfUseCoverageName(String stateCode) {
        return stateCode.equals(CT) ? LOSS_OF_USE_TEXT : LOSS_OF_USE;
    }

    // F89863 - validate that the difference between dropdown values is consistent to 10% of coverage limit
    public void validateLossOfUseDropdownValue(FarmersSoftAssert fsa, String stateCode) throws Exception {
        List<Double> lossOfUseOptions = new ArrayList<>();
        for (WebElement option : lossOfUseDropDownOptions) {
            String text = getTextFromElement(option).replaceAll(" .*$", EMPTY_STRING);
            lossOfUseOptions.add(convertCurrencyStringToDouble(text));
        }
        // Values can be duplicated for different month options (ex. 10% can be for 12 months and 24 months), so we need to get distinct values only.
        List<Double> uniqueOptions = lossOfUseOptions.stream().distinct().collect(Collectors.toList());
        Log.info("List of unique Loss of Use dropdown options values: " + uniqueOptions);
        double coverageLimit =  convertCurrencyStringToDouble(getCoveragePriceByNameFromScreen(PERSONAL_PROPERTY_LIMIT));
        int step = (int) (coverageLimit * 0.1); // 10%-100% in 10% increments
        double initialPercentage = isTwentyPerLossOfUseStateRenters(stateCode) ? 0.2 : 0.1;
        double expectedValue = coverageLimit * initialPercentage;
        for(double option : uniqueOptions){
            double expectedRounded = Math.round(expectedValue / 100.0) * 100.0; // to round to the nearest hundred
            fsa.assertEquals(option, expectedRounded, "Validating Loss of Use dropdown option value. Expected: " + expectedValue + ", Actual: " + option);
            expectedValue += step;
        }
    }

    public boolean isTwentyPerLossOfUseStateRenters(String stateCode) {
        return List.of(VA, CT, NC).contains(stateCode);
    }

}
