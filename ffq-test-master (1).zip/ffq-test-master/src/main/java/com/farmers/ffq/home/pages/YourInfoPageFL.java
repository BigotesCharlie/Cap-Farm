package com.farmers.ffq.home.pages;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.ApplicantHome;
import com.farmers.framework.report.Log;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import static org.openqa.selenium.support.ui.ExpectedConditions.*;

public class YourInfoPageFL extends BasePage {


	@FindBy(id = "FFQHome_Yourinfo_firstName")
	private WebElement firstNameTextBox;

	@FindBy(id = "FFQHome_Yourinfo_lastName")
	private WebElement lastNameTextBox;

	@FindBy(xpath = "//input[contains(@id, 'FFQHome_Yourinfo_Dob') and contains(@class, 'ng-isolate-scope')]")
	private WebElement dateOfBirthTextBox;

	@FindBy(xpath = "//*[@id='FFQHome_Yourinfo_genderWrap']/label")
	private WebElement maleRadioButton;

	@FindBy(xpath = "//*[@id='FFQHome_Yourinfo_gender1Wrap']/label")
	private WebElement femaleRadioButton;

	@FindBy(id = "FFQHome_Yourinfo_ResedentialAddress")
	private WebElement resedentialAddressTexBox;

	@FindBy(id = "FFQHome_Yourinfo_Apartment")
	private WebElement resedentialAppartmentTexBox;

	@FindBy(id = "FFQHome_Yourinfo_City")
	private WebElement resedentialCityTexBox;

	@FindBy(id = "FFQHome_Yourinfo_Zipcode")
	private WebElement zipCodeTexBox;

	@FindBy(id = "FFQHome_Yourinfo_phoneNumber")
	private WebElement phoneTextBox;

	@FindBy(id = "FFQHome_Yourinfo_email")
	private WebElement emailTextBox;

	@FindBy(xpath = "//*[@id='FFQHome_Yourinfo_questionWrap']/label")
	private WebElement hasAutoInsuranceYesRadioBtn;

	@FindBy(xpath = "//*[@id='FFQHome_Yourinfo_question1Wrap']/label")
	private WebElement hasAutoInsuranceNoRadioBtn;

	@FindBy(id = "FFQHome_Yourinfo_startQuoteBtn")
	private WebElement submitButton;

	@FindBy(id = "FFQHome_Review_ConsentNoBtn")
	private WebElement consumeReportPopUpNoButton;

	@FindBy(id = "FFQHome_Review_ConsentYesBtn")
	private WebElement consumeReportPopUpYesButton;

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public YourInfoPageFL() throws Exception {
		super();
	}

	/**
	 * Enter first name.
	 *
	 * @param name
	 */
	private void enterFirstName(String name) {
		Log.info("Entering First Name: " + name);
		wait.until(visibilityOf(firstNameTextBox));
		sendKeysToElement(firstNameTextBox, name);
	}

	/**
	 * Enter last name.
	 *
	 * @param lastName
	 */
	private void enterLastName(String lastName) {
		Log.info("Entering Last Name: " + lastName);
		wait.until(visibilityOf(lastNameTextBox));
		sendKeysToElement(lastNameTextBox, lastName);
	}

	/**
	 * Enter Date of Birth.
	 *
	 * @param age
	 */
	private void enterDateOfBirth(int age,WebElement dateOfBirthTextField) {
		Log.info("Entering Date of Birth: " + age);
		wait.until(visibilityOf(dateOfBirthTextField));
		sendKeysToElement(dateOfBirthTextField, calculateDateOfBirthFromAge(age));
	}

	/**
	 * Select Gender.
	 *
	 * @param g
	 */
	private void selectGender(String g) {
		Log.info("Selecting Gender: " + g);
		switch(g) {
		case "Male":
			wait.until(visibilityOf(maleRadioButton));
			clickElement(maleRadioButton);
			break;
		case "Female":
			wait.until(visibilityOf(femaleRadioButton));
			clickElement(femaleRadioButton);
			break;
		default: throw new IllegalArgumentException("Wrong gender argument " + g);
		}
	}

	/**
	 * Enter Residential Address.
	 *
	 * @param address
	 */
	private void enterResidentialAddress(String address) {
		Log.info("Entering Residential Address: " + address);
		wait.until(visibilityOf(resedentialAddressTexBox));
		sendKeysToElement(resedentialAddressTexBox, address);
	}

	/**
	 * Enter City.
	 *
	 * @param city
	 */
	private void enterCityName(String city) {
		Log.info("Entering City: " + city);
		wait.until(visibilityOf(resedentialCityTexBox));
		sendKeysToElement(resedentialCityTexBox, city);
	}

	/**
	 * Enter phone number.
	 *
	 * @param number
	 */
	private void enterPhoneNumber(String number) {
		Log.info("Entering Phone Number: " + number);
		wait.until(visibilityOf(phoneTextBox));
		sendKeysToElement(phoneTextBox, number);
	}

	/**
	 * Enter Email Address.
	 *
	 * @param email
	 */
	private void enterEmailAddress(String email) {
		Log.info("Entering Email Address: " + email);
		wait.until(visibilityOf(emailTextBox));
		sendKeysToElement(emailTextBox, email);
	}

	private void doYouHaveAutoPolicy(boolean hasAutoPolicy) {
		if (hasAutoPolicy) {
			clickElement(hasAutoInsuranceYesRadioBtn);
		} else {
			clickElement(hasAutoInsuranceNoRadioBtn);
		}
	}

	/**
	 * Click Submit Button.
	 *
	 */
	public void clickSubmitButton() {
		Log.info("Clicking Submit Button" );
		clickElement(submitButton);
	}

	/**
	 * Select May we use the consumer report information?
	 * @param share
	 */
	public void selectShareConsumerReportInformationNotification(boolean share) {
		Log.info("Selecting May we use the consumer report information?: " + share);
		wait.until(visibilityOf(consumeReportPopUpNoButton));
		if (share) {
			clickElement(consumeReportPopUpYesButton);
		} else {
			clickElement(consumeReportPopUpNoButton);
		}
	}

	/**
	 * Check if Share Consume Report Information Notification Shown?
	 *
	 */
	private boolean isShareConsumerReportInformationNotificationShown() {
		Log.info("Checking if Share Consume Report Information Notification Shown");
		return isElementPresent(By.id("FFQHome_Modal_ReviewConsentHeader"), 3);
	}

	public ThankYouPageFL enterYourInfoPageFL(ApplicantHome applicant) throws Exception {
		waitForSpinnerToBeGone();
		enterFirstName(applicant.getFirstName());
		enterLastName(applicant.getLastName());
		enterDateOfBirth(applicant.getAge(), dateOfBirthTextBox);
		selectGender(applicant.getGender());
		enterResidentialAddress(applicant.getAddressApt());
		enterCityName(applicant.getCity());
		enterPhoneNumber(applicant.getPhoneNumber());
		enterEmailAddress(applicant.getEmailAddress());
		doYouHaveAutoPolicy(applicant.isHasAutoPolicy());
		clickSubmitButton();
		Assert.assertEquals(isShareConsumerReportInformationNotificationShown(), true, "Share consumer report information notification displayed on quotes for " + applicant.getState());
		selectShareConsumerReportInformationNotification(applicant.isShareConsumeReport());
		return new ThankYouPageFL();
	}
}
