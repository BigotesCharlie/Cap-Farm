package com.farmers.ffq.hqm.pages;

import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.LeadTypeHQM;
import com.farmers.ffq.datatransferobjects.hqm.StaticContentHQM;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Home Quote Modernization (HQM) - Quote Address Page.
 */

public class AddressPage extends HqmBasePage {

	private static final String ADDRESS_PAGE_FOUND_ALL_EXPECTED_ERRORS = "Address page - Found all expected errors.";

	@FindBy(xpath = "//div/ui-farmers-input[@id='address']//input")
	private WebElement inputAddress;

	private static final String INPUT_CITY_XPATH = "//div/ui-farmers-input[@fieldlabel='City']//input";
	@FindBy(xpath = INPUT_CITY_XPATH)
	private WebElement inputCity;

    @FindBy(xpath = "//mat-select[@id='city']")
    private WebElement selectCity;

    private static final String DROPDOWN_OPTIONS = "//div[contains(@class,'mat-select-panel-wrap')]//mat-option[contains(.,'%s')]";

	@FindBy(xpath = "//ui-farmers-input[@fieldlabel='ZIP Code']//input")
	private WebElement inputZip;

    private static final String DIALOG_ZIP_CHANGE_XPATH = "//farmers-home-quote-address-dialog/h4";
    private final By dialogZipChangeTitleBy = By.xpath(DIALOG_ZIP_CHANGE_XPATH);
    @FindBy(xpath = DIALOG_ZIP_CHANGE_XPATH)
    private WebElement dialogZipChangeTitle;

	@FindBy(xpath = "//ui-farmers-input[@fieldlabel='State']//input")
	private WebElement inputState;

	private static final String BUTTON_CHANGE_XPATH = "//farmers-home-quote-address-dialog//button[.='CHANGE']";
	private final By buttonChangeBy = By.xpath(BUTTON_CHANGE_XPATH);
	@FindBy(xpath = BUTTON_CHANGE_XPATH)
	private WebElement buttonChange;

    private static final String BUTTON_CANCEL_XPATH = "//farmers-home-quote-address-dialog//button[.='CANCEL']";
    private final By buttonCancelBy = By.xpath(BUTTON_CANCEL_XPATH);
    @FindBy(xpath = BUTTON_CANCEL_XPATH)
	private WebElement buttonCancel;

    private static final String BUTTON_OK_XPATH = "//farmers-home-quote-address-dialog//button[.='OK']";
    private final By buttonOkBy = By.xpath(BUTTON_OK_XPATH);
    @FindBy(xpath = BUTTON_OK_XPATH)
    private WebElement buttonOk;

    @FindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Policy start date']//input[@matinput]")
    private WebElement inputStartDate;

    @FindBy(xpath = "//farmers-home-quote-address//mat-checkbox//input")
    private WebElement inputCheckboxMobileManufactured;

    @FindBy(xpath = "//farmers-home-quote-address//mat-checkbox//label")
    private WebElement labelCheckboxMobileManufactured;

    @FindBy(xpath = "//farmers-home-quote-address//h1")
    private WebElement textPageTitle;

    private static final String COUNTY_XPATH = "//mat-select[@id='county']";
    @FindBy(xpath = COUNTY_XPATH)
    private WebElement selectCounty;

    private static final String STR_PAGE_TITLE = "LET'S START WITH YOUR ADDRESS";
    private static final String STR_PAGE_TITLE_AEM = "LET'S START WITH\nYOUR ADDRESS";

    @FindBy(xpath = "//farmers-home-quote-address//div[h1]//span[contains(@class,'tui-subtitle-text-1')]")
    private WebElement textPageSubTitle;

    @FindBy(xpath = "//farmers-home-quote-address//div[contains(@class,'bottom-text')]/span[contains(@class,'tui-subtitle-text-1')]")
    private WebElement textPageSubTitle2;

    @FindBy(xpath = "//farmers-home-quote-address//farmers-home-quote-discount-journey//img[@id='lock-img']/../p")
    private WebElement discountSubTitleLock;

    private static final String TEXT_DISCOUNT_LOCK = "We will never sell your information.";

    @FindBy(xpath = "//farmers-home-quote-address//span[contains(@class,'caption')]")
    private WebElement textPageEarlyShopping;

	private static final String SUBHEADER_GROUP_SELECT_XPATH = "//farmers-home-quote-address//mat-card//h5";
    @FindBy(xpath = SUBHEADER_GROUP_SELECT_XPATH)
    private WebElement subHeaderGroupSelect;
    private static final String TEXT_SUBHEADER_GROUP_SELECT = "Save money based on where you work or the groups you belong to";

    @FindBy(xpath = "//farmers-home-quote-address//h5/../../div/span[@class='sub-title-one']")
    private WebElement subtitleHeaderGroupSelect;
    private static final String TEXT_SUBTITLE_HEADER_GROUP_SELECT = "Check for group discounts with Farmers GroupSelectSM based on " +
            "your relationship with a qualifying:";

    private static final String SUBTITLE_GROUPS_XPATH = "//farmers-home-quote-address//h5/../../div//li[contains(@class,'sub-title-one')]";
    private final List<String> listSubtitleHeaderGroups = Arrays.asList("Employer",
            "Affinity group, association, credit or trade union, or more");

	private static final String INPUT_EMPLOYER_GROUP_XPATH = "//farmers-home-quote-address//ui-farmers-auto-complete-typeahead//input";
    @FindBy(xpath = INPUT_EMPLOYER_GROUP_XPATH)
    private WebElement inputEmployerGroup;

    private static final String EMPLOYER_GROUP_LIST_XPATH = "//div[contains(@class,'mat-autocomplete')]/mat-option";
    @FindBy(xpath = EMPLOYER_GROUP_LIST_XPATH)
    private WebElement employerOption;

    private static final String AGENT_RADIOBUTTON_XPATH = "//mat-radio-group[@id='metlife-selection-option']//input";
    @FindBy(xpath = AGENT_RADIOBUTTON_XPATH)
    private WebElement radioButtonAgent;

    private static final String LABEL_EMPLOYER_GROUP_XPATH = "//farmers-home-quote-address//ui-farmers-auto-complete-typeahead//mat-label";
    @FindBy(xpath = LABEL_EMPLOYER_GROUP_XPATH)
    private WebElement labelEmployerGroup;
    private static final String TEXT_LABEL_EMPLOYER_GROUP = "Type Your Employer or Group (optional)";

    private static final String EMPLOYER_GROUP_TYPEAHEAD_XPATH = "//ui-farmers-auto-complete[@data-dtm='FFQ_Home_Address_Employer_Typeahead']";

    private static final String STR_PAGE_SUBTITLE = "Where is the house you'd like to insure?";
    private static final String STR_PAGE_SUBTITLE_AEM = "Where is the house you\u2019d like to insure?";

    private static final String STR_PAGE_SUBTITLE_QQC = "Congratulations! You're on your way to having your new home insured. " +
            "We may already have some of your information from Rocket Mortgage\u00ae. Please ensure the information prefilled " +
            "below is accurate and complete.";
    private static final String STR_PAGE_SUBTITLE_QQNC = "Congratulations, you\u2019re on your way to having your new home insured. " +
            "Please complete the form below to start your quote.";

    private static final String STR_PAGE_SUBTITLE2 = "When would you like your new policy to start?";
    private static final String STR_PAGE_EARLY_SHOPPING = "Picking a policy start date 7 or more days from today may result in a better price. " +
            "Pick a policy start date that is immediately after any current policy ends, so there will be no gap in coverage.";

    private final By pageFooters = By.xpath("//farmers-home-quote-address//p[contains(@class,'caption')]");

    private static final String FOOTER0_TEXT = "To review your rights under the Alabama Homeowners Bill of Rights Act, please click\nhere\n.";

    private static final String FOOTER1_TEXT1 = "In connection with this application for insurance, Farmers will review your and your spouse\u2019s " +
            "credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. We will use " +
            "third parties in connection with the development of your insurance scores based on data from traditional credit bureaus and the National " +
            "Consumer Telecom & Utilities Exchange database.";

    private static final String FOOTER1_TEXT2 = "In connection with this application for insurance, Farmers may review your and your spouse's " +
            "credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. We may use " +
            "third parties in connection with the development of your insurance scores based on data from traditional credit bureaus.";

    private static final String FOOTER1_TEXT_NC = "In connection with this application for insurance, Farmers may review your and your spouse's " +
            "credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. We may use third " +
            "parties in connection with the development of your insurance scores based on data from traditional credit bureaus. In addition to a $3 " +
            "installment fee, we also may charge a $15 late fee, a $20 returned payment charge, or a $25 reinstatement fee. This policy is " +
            "also subject to a policy fee of $25.";

    private static final String FOOTER1_TEXT = "In connection with a quote for homeowners insurance, we may review your credit report or obtain or use a " +
            "credit-based insurance score based on the information contained in that credit report. We may use a third party in connection " +
            "with the development of your insurance score.";

    private static final String FOOTER1_TEXT_MN1 = " The insurer may elect to cancel coverage at any time during the first 59 days following issuance of the coverage for any reason which is not " +
            "specifically prohibited by statute.";

    private static final String FOOTER1_TEXT_MN2 = "Your state also requires us to tell you that we may obtain consumer reports or personal or " +
            "privileged information from third parties. This information as well as other personal or privileged information subsequently " +
            "collected by us or your agent may be used for underwriting or rating and in certain circumstances may be disclosed to third " +
            "parties without authorization, as permitted by law. You have the right of access and correction with respect to all personal " +
            "information collected. At your request, we will provide you with more detailed information regarding our collection, use and " +
            "disclosure of personal information, and your rights to access and correct such information. By continuing, you authorize us " +
            "and your agent to collect and disclose your personal and privileged information. This authorization will remain valid for " +
            "as long as you are continually insured with us.";

    private static final String FOOTER1_TEXT_KS = " We provide an internal appeal process whereby you may ask us to review an adverse action based on your credit information.";

    private static final String FOOTER1_TEXT_TX = "We will obtain and use credit information, from traditional credit bureaus and " +
            "the National Consumer Telecom & Utilities Exchange database, on you and your spouse as a part of the insurance credit scoring process.";

    private static final String FOOTER1_TEXT_FLEX = "In connection with this application for insurance, Farmers may review your and your spouse\u2019s " +
            "credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. We may use " +
            "third parties in connection with the development of your insurance scores based on data from traditional credit bureaus and " +
            "the National Consumer Telecom & Utilities Exchange database.";

    private static final String FOOTER1_TEXT_CA = "Farmers entities may use any consumer report information their affiliates might currently have " +
            "for you for this transaction. Farmers Privacy Notice gives you the choice to opt out of allowing Farmers affiliates to share your consumer " +
            "report information among Farmers entities. Farmers entities may use any consumer report information their affiliates might currently have " +
            "for you for this specific transaction. You can still opt out of future sharing.";

    private static final String FOOTER1_TEXT_IL = "In connection with this application for insurance, Farmers may review your and your spouse\u2019s credit " +
            "report or obtain or use a credit-based insurance score based on the information contained in that credit report. We may use third parties " +
            "in connection with the development of your insurance scores based on data from traditional credit bureaus and the National Consumer Telecom & " +
            "Utilities Exchange database. If you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, " +
            "in writing, that we provide reasonable exceptions to our underwriting and/or rating practices. Please contact a Farmers\u00ae agent for details " +
            "on qualifying circumstances and how to request an exception.";

    private static final String FOOTER1_TEXT_MT = "In connection with this application for insurance, Farmers may review your and your spouse\u2019s credit " +
            "report or obtain or use a credit-based insurance score based on the information contained in that credit report. We may use third parties in " +
            "connection with the development of your insurance scores based on data from traditional credit bureaus. If you believe an extraordinary life " +
            "circumstance has negatively impacted your credit information, you may request, in writing, that we provide reasonable exceptions to our " +
            "underwriting and/or rating practices. Please contact a Farmers\u00ae representative for details on qualifying circumstances and how to request an exception.";

    private static final String FOOTER1_TEXT_GA = "In connection with a quote for Auto or Home (includes Condo and Renters) insurance, we may review your " +
            "or your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. " +
            "In addition to traditional credit-based insurance scores, we may also use a third-party score based on the National Consumer Telecom & Utilities " +
            "Exchange (NCTUE) database. We do not review or obtain credit reports for Life quotes.";

    private static final String FOOTER2_TEXT8 = "When you purchase a policy, we will be sending you a Privacy Notice that gives you the choice to " +
            "opt out from Farmers sharing your consumer report information, such as your credit based insurance score or loss history, " +
            "among our affiliates. In the interim, if applicable, may we use the consumer report information we currently have on file " +
            "for you for this specific transaction? You will still be able to opt out of any future sharing.";

    private static final String FOOTER2_TEXT_FLEX = "Also, Farmers entities may use any consumer report information their affiliates " +
            "might currently have for you for this transaction.";

    private static final String FOOTER2_TEXT_GA = "We will be sending you a Privacy Notice that gives you the choice to opt out from Farmers sharing " +
            "your consumer report information, such as your credit based insurance score or loss history, among our affiliates. In the interim, " +
            "if applicable, may we use the consumer report information we currently have on file for you for this specific transaction? " +
            "You will still be able to opt out of any future sharing.";

    private static final String FOOTER2_TEXT_VA = "Farmers Privacy Notice gives you the choice to opt out of allowing Farmers affiliates to share " +
            "your consumer report information among Farmers entities. Farmers entities will use any consumer report information their affiliates might " +
            "currently have for you for this specific transaction. You can still opt out of future sharing.";

    private static final String FOOTER2_TEXT_MORE = "Farmers entities may use any consumer report information their affiliates might currently have for you " +
            "for your quote request. Our Privacy Notice gives you the choice to opt out of allowing Farmers affiliates to share your consumer report information " +
            "among Farmers entities. You can still opt out of future sharing.";

    private static final String FOOTER3_TEXT2 = "By clicking NEXT, I acknowledge that I have read and agree to the\nPrivacy Policy\nand the use of " +
            "consumer report information described above.";

    private static final String FOOTER3_TEXT3 = "By clicking NEXT, you acknowledge that you have read and agree to the\nPrivacy Policy\n" +
            "and agree to the use of consumer report information described above. Otherwise, you can contact a Farmers agent to get a quote.";

    private static final String FOOTER3_TEXT4 = "By clicking NEXT, you acknowledge that you have read and agree to the \nPrivacy Policy\n " +
            "and agree to the use of consumer report information described above. Otherwise, you can contact a Farmers agent to get a quote.";

    private static final String FOOTER3_TEXT5 = "By clicking NEXT, I acknowledge that I have read and agree to the\nPrivacy Policies\n" +
            "and the use of consumer report information described above, or alternatively, you can contact a Farmers agent to get a quote.";

    private static final String FOOTER3_TEXT_FLEX = "By clicking \u201cNEXT,\u201d you acknowledge that you have read and agree to the\nPrivacy Policy\n " +
            "and agree to the use of consumer report information described above. Otherwise, you can contact a Farmers\u00ae agent to discuss your options.";

    private static final String FOOTER3_TEXT_CA = "By clicking \u201cNEXT\u201d, you acknowledge that you have read and agree to the " +
            "\nPrivacy Policy\n.Otherwise, you can contact a Farmers\u00ae agent to discuss your options.";

    private static final String FOOTER3_TEXT_TX = "By clicking \u201cNEXT,\u201d you acknowledge that you have read and agree to the\nPrivacy Policy\n" +
            "and agree to the use of consumer report information described above. Otherwise, you can contact a Farmers\u00ae agent to discuss your options.";

    private static final String FOOTER3_TEXT_VA = "By clicking \"Agree\", you acknowledge that you've read & agree to the\nPrivacy Policy\nand the above consumer " +
            "report information provisions. Otherwise contact a Farmers\u00ae representative to discuss options.";

    private static final String FOOTER3_TEXT_GA = "By clicking NEXT, I acknowledge that I have read and agree to the\nPrivacy Policy\nand the use " +
            "of consumer report information described above, or alternatively, you can contact a Farmers agent to get a quote.";

    private static final String FOOTERTEXT_MOBILE = "Please review our Personal information use.";

    private static final List<String> errorsAddressPage = Arrays.asList("Please enter your street number and name", "Please enter your city", "Please enter ZIP Code");

    private static final String ERROR_ADDRESS_PAGE_CITY_SELECT = "Please select your city";

    private static final String ERROR_ADDRESS_PAGE_POLICY_START_DATE = "Please enter your policy start date";
    private static final String ERROR_ADDRESS_PAGE_POLICY_START_DATE1 = "Policy start date can not be greater than 60 days from today's date";
    private static final String ERROR_ADDRESS_PAGE_POLICY_START_DATE2 = "Date can not be less than today's date";

    private static final String learnMoreLinkXpath = "//farmers-home-quote-address//strong/a[@id='learn-more-inline']";
    @FindBy (xpath=learnMoreLinkXpath)
    private WebElement learnMoreLink;

    private static final String showLessLinkXpath = "//farmers-home-quote-address//strong/a[text()='Show less']";
    @FindBy (xpath=showLessLinkXpath)
    private WebElement showLessLink;

    @FindBy (xpath = "//button[contains(.,'Agree')]")
    private  WebElement buttonAgree;

    /**
     * Constructor.
     * @throws Exception
     */
    public AddressPage(ApplicantHQM applicant, String source, String browserType) throws Exception {
        super();
        new LandingPage(applicant.zipCode, new LeadTypeHQM(applicant, source), browserType);
        wait.until(ExpectedConditions.visibilityOf(inputZip));
    }

    public AddressPage() throws Exception {
        super();
        waitElementBeVisible(inputZip);
    }

    public void setRequiredFields(ApplicantHQM applicant) throws Exception {
        if (!getZipCode().equals(applicant.zipCode)) {
            setZip(applicant.zipCode);
            if (zipChangeDialog(true)) {
                setAddress(applicant.addressApt);
                setCity(applicant.city);
            }
        } else {
            setAddress(applicant.addressApt);
            setCity(applicant.city);
        }
        if (isElementPresentByXPath(COUNTY_XPATH) && !applicant.county.isEmpty()) {
            this.selectCounty(applicant.county);
        }
    }

    public void setAddress(String propAddress) {
        scrollAndClickOnElement(inputAddress);
        sendKeysToElement(inputAddress, "0"+Keys.BACK_SPACE);
		sendKeysToElement(inputAddress, propAddress);
		sendKeysToElement(inputAddress, Keys.TAB);
    }

    public void setCity(String propCity) throws Exception {
        if (isElementDisplayed(By.xpath(INPUT_CITY_XPATH))) {
            waitAndClickElement(inputCity);
            sendKeysToElement(inputCity, propCity);
        } else {
            waitAndClickElement(selectCity);
            WebElement optionWe = driver().findElement(By.xpath(String.format(DROPDOWN_OPTIONS, propCity.toUpperCase())));
            waitAndClickElement(optionWe);
        }
    }

    public void setZip(String propZip) throws Exception {
        try {
            waitAndClickElement(inputZip);
            sendKeysToElement(inputZip, propZip);
            zipChangeDialog(true);
        } catch (ElementClickInterceptedException e) {
            zipChangeDialog(true);
            sendKeysToElement(inputZip, propZip);
        }
    }

    public void setState(String propState) {
    	waitAndClickElement(inputState);
		sendKeysToElement(inputState, propState);
    }

    public boolean zipChangeDialog(boolean bChange) throws Exception {
        boolean bDialog = true;
        sleep(1);
        if (isElementDisplayed(dialogZipChangeTitleBy)) {
            if (bChange) {
                if (isElementDisplayed(buttonChangeBy)) {
                    waitAndClickElement(buttonChange);
                    sleep(1);
                    if (isElementDisplayed(dialogZipChangeTitleBy)) {
                        waitAndClickElement(buttonChange);
                    }
                } else if (isElementDisplayed(buttonOkBy)) {
                    waitAndClickElement(buttonOk);
                }
            } else {
                if (isElementDisplayed(buttonCancelBy)) {
                    waitAndClickElement(buttonCancel);
                } else if (isElementDisplayed(buttonOkBy)) {
                    waitAndClickElement(buttonOk);
                }
                bDialog = false;
            }
        }
        return bDialog;
    }

    public void setPolicyStartDate(String startDate) {
        waitAndClickElement(inputStartDate);
        sleep(1);
        Log.info("Entering Policy Start Date: " + startDate);
        sendKeysOneByOne(inputStartDate, startDate);
        sendKeysToElement(inputStartDate, Keys.TAB);
        if (!getPolicyStartDate().equals(startDate)) {
            waitAndClickElement(inputStartDate);
            sendKeysOneByOne(inputStartDate, startDate);
            sendKeysToElement(inputStartDate, Keys.TAB);
        }
    }

    public String getPolicyStartDate() {
        return getElementValue(inputStartDate, "Policy Start Date: ");
    }

    public void selectCounty(String countyName) throws Exception {
        waitAndClickElement(selectCounty);
        WebElement optionWe = driver().findElement(By.xpath(String.format(DROPDOWN_OPTIONS, countyName)));
        waitAndClickElement(optionWe);
    }

    public void pickAddress(ApplicantHQM applicant) throws Exception {
		waitAndClickElement(inputAddress);
		if (!getTextFromElement(inputAddress).isEmpty()) {
            sendKeysToElement(inputAddress, "0"+Keys.BACK_SPACE);
        }
		sleep(1);
		String fullAddress = applicant.addressApt + SPACE + applicant.city + SPACE + applicant.stateCode + SPACE + applicant.zipCode;
		int maxLength = (fullAddress.length() < 42) ? fullAddress.length() : 41;
		sendKeysToElement(inputAddress, fullAddress.substring(0, maxLength));
		sleep(2);
		sendKeysToElement(inputAddress, Keys.ARROW_DOWN);
		sendKeysToElement(inputAddress, Keys.ENTER);
		sleep(1);
        if (!getZipCode().equals(applicant.zipCode)) {
            zipChangeDialog(false);
            setRequiredFields(applicant);
        }
		zipChangeDialog(true);
    }

	public void verifyPageFields(ApplicantHQM applicant, FarmersSoftAssert fsa) throws Exception {
        if (applicant.keep360Prefill) {
            String partialAddress = applicant.addressApt.toUpperCase();
            fsa.assertEquals(getAddress().split(SPACE)[0], partialAddress.split(SPACE)[0], "Street Address number match");
        } else {
            fsa.assertEquals(getAddress().toUpperCase(), applicant.addressApt.toUpperCase(), "Street Address match");
        }
        fsa.assertEquals(getCity().toUpperCase(), applicant.city.toUpperCase(), "City match");
        fsa.assertEquals(getZipCode(), applicant.zipCode, "Zip Code match");
        fsa.assertEquals(getState().toUpperCase(), applicant.state.toUpperCase(), "State match");
        // validate early shopping factor fields
        if (isEarlyShoppingFactorState(applicant.stateCode)) {
            // TODO: remove this visibility check when the field is always displayed again
            if (applicant.earlyShoppingFactor.isBlank() ||
                    (!applicant.earlyShoppingFactor.isBlank() && isElementVisible(inputStartDate,3))) {
                if (applicant.earlyShoppingFactor.isBlank()) {
                    fsa.assertEquals(getPolicyStartDate(), LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)),
                            "Address page - Policy Start Date is today+1");
                } else if (applicant.earlyShoppingFactor.equalsIgnoreCase(TRUE)) {
                    fsa.assertEquals(getPolicyStartDate(), LocalDate.now().plusDays(7).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)),
                            "Address page - Policy Start Date is 7 days from today");
                } else {
                    fsa.assertEquals(getPolicyStartDate(), applicant.earlyShoppingFactor,
                            "Address page - Policy Start Date matches to data provider");
                }
            }
        }
 	}

    public String getAddress() {
        return getElementValue(inputAddress, "Street Address: ");
    }

    public String getCity() throws Exception {
        if (isElementDisplayed(By.xpath(INPUT_CITY_XPATH))) {
            return getElementValue(inputCity, "City: ");
        } else {
            return getTextFromElement(selectCity);
        }
    }

    private String getZipCode() {
        return getElementValue(inputZip, "Zip Code: ");
    }

    private String getState() {
        return getElementValue(inputState, "State: ");
    }

    public void setPolicyStartDateInFuture(ApplicantHQM applicant) {
        if (isEarlyShoppingFactorState(applicant.stateCode)) {
            // TODO: remove this visibility check when the field is always displayed again
            if (applicant.earlyShoppingFactor.isBlank() ||
                    (!applicant.earlyShoppingFactor.isBlank() && isElementVisible(inputStartDate, 3))) {
                if (applicant.earlyShoppingFactor.equalsIgnoreCase(TRUE)) {
                    setPolicyStartDate(LocalDate.now().plusDays(7).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)));
                } else if (!StringUtils.isBlank(applicant.earlyShoppingFactor)) {
                    setPolicyStartDate(applicant.earlyShoppingFactor);
                }
            }
        }
    }

    public void setEmployerGroup(String empGroup) throws Exception {
        waitAndClickElement(inputEmployerGroup);
        Log.info("Employer Group: " + empGroup);
        sendKeysToElement(inputEmployerGroup, empGroup);
        sleep(2);
        waitElementBeVisibleClickable(employerOption);
        String empGroup1 = empGroup.substring(0,1).toUpperCase() + empGroup.substring(1).toLowerCase();
        WebElement selection = driver().findElement(By.xpath(EMPLOYER_GROUP_LIST_XPATH + "[starts-with(.,'" + empGroup + "') or " +
                "starts-with(.,'" + empGroup1 + "')]"));
        waitAndClickElement(selection);
    }

    public void setFarmersAgent(String agentYesNo) throws Exception {
        WebElement selection = driver().findElement(By.xpath(AGENT_RADIOBUTTON_XPATH+ "[@value='" + agentYesNo + "']/.."));
        waitAndClickElement(selection);
    }

    public boolean isEmployerGroupInputDisplayed() throws Exception {
        return isElementDisplayed(By.xpath(EMPLOYER_GROUP_TYPEAHEAD_XPATH));
    }

    public void populateFields(ApplicantHQM applicant, FarmersSoftAssert fsa) throws Exception {
        if (applicant.keep360Prefill) {
            pickAddress(applicant);
            try {
                verifyPageFields(applicant, fsa);
            } catch (AssertionError e) {
                Log.warn("Address page pickAddress() did not fill out the address fields, going to type it in (perhaps Google pre-fill is not working).");
                setRequiredFields(applicant);
            }
        } else {
            setRequiredFields(applicant);
        }
        this.setPolicyStartDateInFuture(applicant);
    }

    public void smallZipChange(ApplicantHQM applicant) throws Exception {
        this.setAddress(applicant.addressApt);
        this.setCity(applicant.city);
        String modifiedZip = getZipCode();
        int zipCode = Integer.parseInt(modifiedZip);
        String addressPage = driver().getCurrentUrl();
        for (int i=1; i < 10; i++) {
            modifiedZip = modifiedZip.startsWith("0") ? "0" + (zipCode + i) : (zipCode + i) + "";
            Log.info("Trying to change zip code to: " + modifiedZip);
            this.setZip(modifiedZip); // small zip code modification
            this.zipChangeDialog(true);
            sleep(5);
            if (!driver().getCurrentUrl().endsWith("farmers.com/property") &&
                 !driver().getCurrentUrl().endsWith("farmers.com/address")) {
                driver().navigate().to(addressPage);
                zipCode = zipCode - (i + 2);
                continue;
            }
            this.setAddress(applicant.addressApt);
            this.setCity(applicant.city);
            try {
                sleep(1);
                this.clickButtonAgree();
                break;
            } catch (AssertionError e){
                sleep(2);
            }
        }
    }

    public void checkMobileManufacturedHome() {
        final String MOBILE_MANUFACTURED_HOME_LABEL = "This is a mobile or manufactured home";
        Assert.assertEquals(getTextFromElement(labelCheckboxMobileManufactured), MOBILE_MANUFACTURED_HOME_LABEL,
        		"Address page - Mobile or manufactured home checkbox label.");
        if (!isCheckedMobileManufacturedHome()) {
            waitAndClickElement(inputCheckboxMobileManufactured);
        }
    }

    public boolean isCheckedMobileManufacturedHome() {
        waitElementBeVisibleClickable(inputCheckboxMobileManufactured);
        return inputCheckboxMobileManufactured.isSelected();
    }

    public void validateNoEmployerGroupSection (FarmersSoftAssert fsa) {
        fsa.assertFalse(isElementPresentByXPath(SUBHEADER_GROUP_SELECT_XPATH), "Address page - No Metlife subHeader is present for Mobile/Manufactured home.");
        fsa.assertFalse(isElementPresentByXPath(INPUT_EMPLOYER_GROUP_XPATH), "Address page - No Employer/Group input field is displayed for Mobile/Manufactured home.");
    }

    public void validatePageErrors(ApplicantHQM applicant, FarmersSoftAssert fsa) throws Exception {
        this.setZip("1"+Keys.BACK_SPACE);
        this.clickButtonAgree();

        List<String> expectedErrors = new ArrayList<>(errorsAddressPage);

        List<String> pageErrors = this.getPageErrors();
        Log.info("Found page errors 1: " + pageErrors);
        if (applicant.stateCode.equals(MN)) {
            expectedErrors.remove(1);
            expectedErrors.add(1, ERROR_ADDRESS_PAGE_CITY_SELECT);
        }
        fsa.assertEquals(pageErrors, expectedErrors, ADDRESS_PAGE_FOUND_ALL_EXPECTED_ERRORS);

        this.setAddress(applicant.addressApt);
        this.clickButtonAgree();

        pageErrors = this.getPageErrors();
        Log.info("Found page errors 2: " + pageErrors);
        fsa.assertEquals(pageErrors, expectedErrors.subList(1,3), ADDRESS_PAGE_FOUND_ALL_EXPECTED_ERRORS);

        this.setCity(applicant.city);
        this.clickButtonAgree();

        pageErrors = this.getPageErrors();
        Log.info("Found page errors 2: " + pageErrors);
        fsa.assertEquals(pageErrors, expectedErrors.subList(2,3), ADDRESS_PAGE_FOUND_ALL_EXPECTED_ERRORS);

        // validate early shopping factor fields
        if (isEarlyShoppingFactorState(applicant.stateCode)) {
            // TODO: remove this visibility check when the field is always displayed again
            if (applicant.earlyShoppingFactor.isBlank() ||
                    (!applicant.earlyShoppingFactor.isBlank() && isElementVisible(inputStartDate, 3))) {
                String policyStartDate = getPolicyStartDate();
                fsa.assertEquals(policyStartDate, LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)),
                        "Address page - Policy start date is today+1.");

                this.populateFields(applicant, fsa);
                this.setPolicyStartDate("");
                pageErrors = this.getPageErrors();
                expectedErrors.clear();
                expectedErrors.add(ERROR_ADDRESS_PAGE_POLICY_START_DATE);
                fsa.assertEquals(pageErrors, expectedErrors, "Address page - Found Early Shopping Factor expected errors 1.");

                this.setPolicyStartDate(LocalDate.now().plusDays(61).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)));
                sendKeysToElement(inputStartDate, Keys.TAB);
                pageErrors = this.getPageErrors();
                expectedErrors.clear();
                expectedErrors.add(ERROR_ADDRESS_PAGE_POLICY_START_DATE1);
                fsa.assertEquals(pageErrors, expectedErrors, "Address page - Found Policy Start Date > 60 days expected error.");
                fsa.assertFalse(isButtonNextDisabled(), "Address page - Button NEXT should still be enabled.");

                this.setPolicyStartDate(LocalDate.now().minusDays(1).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)));
                sendKeysToElement(inputStartDate, Keys.TAB);
                pageErrors = this.getPageErrors();
                expectedErrors.clear();
                expectedErrors.add(ERROR_ADDRESS_PAGE_POLICY_START_DATE2);
                fsa.assertEquals(pageErrors, expectedErrors, "Address page - Policy start date cannot be less than today's date expected error.");

                setPolicyStartDate(LocalDate.now().format(DateTimeFormatter.ofPattern(MM_DD_YYYY)));
                pageErrors = this.getPageErrors();
                fsa.assertTrue(pageErrors.isEmpty(), "Address page - Policy start date can be set to today.");
                setPolicyStartDate(policyStartDate);
            }
        }
    }

    public void validatePageFieldsLength(FarmersSoftAssert fsa) throws Exception {
        String addressText = "abcdefghijklmnopqrstuvwxyz-abcdefghijklmnopq";
        String cityText = "abcdefghijklmnopqrstuv";
        scrollToElementBottom(textPageSubTitle);
        waitAndClickElement(inputAddress);
        sendKeysToElement(inputAddress, addressText);
        if (!getAddress().startsWith(addressText)) {
            waitAndClickElement(inputAddress);
            sendKeysToElement(inputAddress, Keys.chord(Keys.CONTROL, "a"));
            sendKeysToElement(inputAddress, addressText);
        }
        if (isElementPresentByXPath(INPUT_CITY_XPATH)) {
            sendKeysToElement(inputCity, cityText);
        }
        fsa.assertEquals(getAddress(), addressText.substring(0, 40), "Address page - Address field accepts only up to 40 chars");
        if (isElementPresentByXPath(INPUT_CITY_XPATH)) {
            fsa.assertEquals(getCity(), cityText.substring(0, 20), "Address page - City field accepts only up to 20 chars");
        }
    }

    private void validatePageTitles(String subtitle, FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) {
        fsa.assertEquals(getTextFromElement(textPageTitle), STR_PAGE_TITLE, "Address page - page Title");
        fsa.assertEquals(getTextFromElement(textPageSubTitle), subtitle, "Address page - page Sub-Title");
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getAddressTitle(), STR_PAGE_TITLE_AEM, "Address page - page Title (AEM)");
            fsa.assertEquals(staticContent.getAddressCaption(), STR_PAGE_SUBTITLE_AEM, "Address page - page Sub-Title (AEM)");
        }
    }

    public void validatePageTitlesSubtitles(ApplicantHQM applicant, String quoteType, FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) {
        if (quoteType.equalsIgnoreCase("quickenConsent")) {
            validatePageTitles(STR_PAGE_SUBTITLE_QQC, fsa, null);
        } else if (quoteType.equalsIgnoreCase("quickenNoConsent")) {
            validatePageTitles(STR_PAGE_SUBTITLE_QQNC, fsa, null);
        } else {
            validatePageTitles(STR_PAGE_SUBTITLE, fsa, staticContent);
        }
        // validate early shopping factor fields
        if (isEarlyShoppingFactorState(applicant.stateCode)) {
            // TODO: remove this visibility check when the field is always displayed again
            if (applicant.earlyShoppingFactor.isBlank() ||
                    (!applicant.earlyShoppingFactor.isBlank() && isElementVisible(inputStartDate, 3))) {
                fsa.assertEquals(getTextFromElement(textPageSubTitle2), STR_PAGE_SUBTITLE2, "Address page - Early Shopping Factor Sub-Title");
                fsa.assertEquals(getTextFromElement(textPageEarlyShopping), STR_PAGE_EARLY_SHOPPING, "Address page - Early Shopping Factor description.");
            }
        }
    }

    public void validateSubtitlesDiscountJourney(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(discountSubTitleLock), TEXT_DISCOUNT_LOCK,
                "Address page - Discount Journey Subtitle Lock image.");
    }

    public void validatePageMetlifeTitles(ApplicantHQM applicant, FarmersSoftAssert fsa) throws Exception {
        if (isPLAState(applicant.stateCode)) {
            fsa.assertFalse(isElementPresentByXPath(SUBHEADER_GROUP_SELECT_XPATH), "Address page - No Employer/Group subHeader present for PLA states.");
            fsa.assertFalse(isElementPresentByXPath(INPUT_EMPLOYER_GROUP_XPATH), "Address page - No Employer/Group input field is displayed for PLA states.");
        } else {
            fsa.assertTrue(isElementPresentByXPath(SUBHEADER_GROUP_SELECT_XPATH), "Address page - Employer/Group subHeader present.");
            fsa.assertTrue(isElementPresentByXPath(INPUT_EMPLOYER_GROUP_XPATH), "Address page - Employer/Group input field is displayed.");
            fsa.assertTrue(isElementPresentByXPath(LABEL_EMPLOYER_GROUP_XPATH), "Address page - Employer/Group input field Label is displayed.");
            try {
                fsa.assertEquals(getTextFromElement(subHeaderGroupSelect), TEXT_SUBHEADER_GROUP_SELECT,
                        "Address page - Metlife Employer/Group header.");
                fsa.assertEquals(getTextFromElement(subtitleHeaderGroupSelect), TEXT_SUBTITLE_HEADER_GROUP_SELECT,
                        "Address page - Metlife Employer/Group Subtitle.");
                List<String> subtitleHeaderGroups = driver().findElements(By.xpath(SUBTITLE_GROUPS_XPATH)).stream()
                        .map(this::getTextFromElement).collect(Collectors.toList());
                fsa.assertEquals(subtitleHeaderGroups, listSubtitleHeaderGroups,
                        "Address page - Metlife Employer/Group Subtitle (Employer, Affinity Group).");
                fsa.assertTrue(isElementPresentByXPath(INPUT_EMPLOYER_GROUP_XPATH), "Address page - Employer/Group input field is displayed.");
                fsa.assertEquals(getTextFromElement(labelEmployerGroup), TEXT_LABEL_EMPLOYER_GROUP,
                        "Address page - Employer/Group Input field Label is displayed.");
            } catch (NoSuchElementException e){
                Log.error("Expected page element not found.");
            }
        }
    }

    public void validatePageFooters(String stateCode, @Nonnull String source, @Nullable StaticContentHQM staticContent) throws Exception {
        if (isElementDisplayed(By.xpath(learnMoreLinkXpath))) {
            waitAndClickElement(learnMoreLink);
        }
        List<String> listPageFooters = driver().findElements(pageFooters).stream().map(this::getTextFromElement).map(String::strip)
                .filter(el-> !el.isEmpty()).collect(Collectors.toList());
        if (isElementDisplayed(By.xpath(showLessLinkXpath))) {
            waitAndClickElement(showLessLink);
        }
        List<String> footersList = new ArrayList<>();
        switch (stateCode) {
            case VA:
                footersList.add(FOOTER1_TEXT1);
                footersList.add(FOOTER2_TEXT_VA);
                footersList.add(FOOTER3_TEXT3);
                break;
            case AL:
            case CT:
            case IN:
            case MO:
            case OH:
            case MA:
            case UT:
            case WA:
                if (stateCode.equals(AL)) {
                    footersList.add(FOOTER0_TEXT);
                }
                footersList.add(FOOTER1_TEXT2);
                footersList.add(FOOTER2_TEXT_FLEX);
                footersList.add(FOOTER2_TEXT_MORE);
                footersList.add(FOOTER3_TEXT_VA);
                break;
            case IA:
            case MT:
            case KY:
            case MS:
            case LA:
                if (stateCode.equals(KY)) {
                    footersList.add(FOOTER1_TEXT_MT.replace(" and your spouse\u2019s",""));
                } else {
                    footersList.add(FOOTER1_TEXT_MT);
                }
                footersList.add(FOOTER2_TEXT_MORE);
                footersList.add(FOOTER3_TEXT_VA);
                break;
            case NV:
            case KS:
                footersList.add(FOOTER1_TEXT_MT);
                if (stateCode.equals(KS)) {
                    footersList.add(FOOTER1_TEXT_KS);
                }
                footersList.add(FOOTER2_TEXT_MORE);
                footersList.add(FOOTER3_TEXT_VA);
                break;
            case CA:
                footersList.add(FOOTER1_TEXT_CA);
                footersList.add(FOOTER3_TEXT_CA);
                break;
            case MN:
                footersList.add(FOOTER1_TEXT_MT);
                footersList.add(FOOTER1_TEXT_MN1);
                footersList.add(FOOTER1_TEXT_MN2);
                footersList.add(FOOTER2_TEXT_FLEX);
                footersList.add(FOOTER2_TEXT_MORE);
                footersList.add(FOOTER3_TEXT_VA);
                break;
            case MD:
                footersList.add(FOOTER2_TEXT8);
                footersList.add(FOOTER3_TEXT5);
                break;
            case TX:
                footersList.add(FOOTER1_TEXT_TX);
                footersList.add(FOOTER2_TEXT_FLEX);
                footersList.add(FOOTER2_TEXT_MORE);
                footersList.add(FOOTER3_TEXT_TX);
                break;
            case AR:
            case AZ:
            case OK:
            case PA:
            case ID:
            case IL:
            case MI:
            case OR:
            case NM:
            case NE:
            case TN:
            case WI:
            case WY:
                if (Arrays.asList(IL,MI).contains(stateCode)) {
                    footersList.add(FOOTER1_TEXT_IL);
                } else {
                    footersList.add(FOOTER1_TEXT_FLEX);
                }
                footersList.add(FOOTER2_TEXT_FLEX);
                footersList.add(FOOTER2_TEXT_MORE);
                footersList.add(FOOTER3_TEXT_FLEX);
                break;
            case CO:
                footersList.add(FOOTER1_TEXT_FLEX);
                footersList.add(FOOTER2_TEXT_MORE.replace(". You can still opt out", ".  You can still opt out"));
                footersList.add(FOOTER3_TEXT3);
                break;
            case ND:
            case SD:
                footersList.add(FOOTER1_TEXT_FLEX);
                if (stateCode.equals(SD)) {
                    footersList.add(FOOTER2_TEXT_MORE.replace(". You can still opt out", ".  You can still opt out"));
                    footersList.add(FOOTER3_TEXT4);
                } else {
                    footersList.add(FOOTER2_TEXT_MORE);
                    footersList.add(FOOTER3_TEXT3);
                }
                break;
            case NC:
                footersList.add(FOOTER1_TEXT_NC);
                footersList.add(FOOTER2_TEXT_FLEX);
                footersList.add(FOOTER2_TEXT_MORE);
                footersList.add(FOOTER3_TEXT_VA);
                break;
            case GA:
                footersList.add(FOOTER1_TEXT_GA);
                footersList.add(FOOTER2_TEXT_GA);
                footersList.add(FOOTER3_TEXT_GA);
                break;
            default:
                footersList.add(FOOTER1_TEXT);
                footersList.add(FOOTER3_TEXT2);
                break;
        }
        Log.info("Found Address page footers: " + listPageFooters);
        if (source.equals(MOBILE_BROWSER)) {
            footersList.add(0, FOOTERTEXT_MOBILE + (stateCode.equals(CA) ? "" : "\n"));
        }

        String footersString = String.join("", footersList);
        if (!listPageFooters.isEmpty()) {
            String tempListPageFooters = String.join("", listPageFooters).replace("\n","");
            Assert.assertEquals(tempListPageFooters, footersString.replace("\n",""), "Address page - Validate page footers.");
            if ((staticContent != null) && (staticContent.getAddressDisclaimer() != null)) {
                String disclaimer = staticContent.getAddressDisclaimer();
                if (disclaimer.toLowerCase().contains("[phone_number")) {
                    if (source.equals(QQ)) {
                        disclaimer = disclaimer.replace("[PHONE_NUMBER_EE]", CALL_FARMERS_QUICKEN);
                        disclaimer = disclaimer.replace("[Phone_Number]", CALL_FARMERS_QUICKEN);
                    } else {
                        disclaimer = disclaimer.replace("[PHONE_NUMBER_EE]", CALL_FARMERS_EE);
                        disclaimer = disclaimer.replace("[Phone_Number]", CALL_FARMERS_EE);
                    }
                }
                if (stateCode.equals(AL)) {
                    disclaimer = disclaimer.replace(" [Alabama_Here]", "\nhere\n");
                }
                if (Arrays.asList(MD).contains(stateCode)) {
                    disclaimer = disclaimer.replace("Privacy Policy", "Privacy Policies");
                }
                if (stateCode.equals(CA)) {
                    disclaimer = disclaimer.replace("Privacy Policy", "Privacy Policy.");
                }
                if (List.of(ND, VA).contains(stateCode)) {
                    disclaimer = disclaimer.replace(".  You can still opt out", ". You can still opt out");
                }
                if (source.equals(MOBILE_BROWSER)) {
                    footersList.remove(0);
                }
                if (stateCode.equals(AZ)) {
                    footersString = String.join("\n", footersList);
                    disclaimer = disclaimer.replace("\nBy clicking NEXT", "By clicking NEXT");
                } else {
                    footersString = String.join("\n\n", footersList);
                }
                disclaimer = disclaimer.replace("[CTA button name]","Agree");
                Assert.assertEquals(disclaimer.replace("\n",""), footersString.replace("\n",""),
                        "Address page - Validate Address page footers (AEM).");
            }
        } else {
            Assert.assertTrue(footersList.isEmpty(), "Address page - Validate it does not have any footers.");
            if (staticContent != null) {
                Assert.assertNull(staticContent.getAddressDisclaimer(), "Address page - Validate it has no footers (AEM).");
            }
        }
    }

    public void verifyPageFieldsReadonly(FarmersSoftAssert fsa) {
        fsa.assertEquals(getAttributeData(inputAddress, READONLY), LOWERCASE_TRUE, "Address page - Street address is ready-only");
        fsa.assertEquals(getAttributeData(inputCity, READONLY), LOWERCASE_TRUE, "Address page - City is ready-only");
        fsa.assertEquals(getAttributeData(inputZip, READONLY), LOWERCASE_TRUE, "Address page - Zip Code is read-only");
        fsa.assertEquals(getAttributeData(inputState, READONLY), LOWERCASE_TRUE, "Address page - State is read-only");
    }

    public void clickButtonAgree() throws Exception {
        waitAndClickElement(buttonAgree);
    }
}

