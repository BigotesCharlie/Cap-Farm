package com.farmers.ffq.hqm.pages;

import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.StaticContentHQM;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import javax.annotation.Nullable;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Home Quote Modernization (HQM) - Personal Info Page 2.
 */

public class ContactInfoPage extends HqmBasePage {

	private static final String CONTACT_INFO_PAGE_TITLE = "PLEASE LET US\nKNOW HOW TO\nCONTACT YOU.";
	@FindBy(xpath = "//ui-farmers-input[@type='email']//input")
	private WebElement inputEmail;

	@FindBy(xpath = "//ui-farmers-input[contains(@fieldlabel,'Email address')]//mat-label")
	private WebElement labelEmail;

	@FindBy(xpath = "//input[@formcontrolname='phoneNumber']")
	private WebElement inputPhoneNumber;

	@FindBy(xpath = "//mat-form-field//label[contains(.,'Phone number')]")
	private WebElement labelPhoneNumber;

	@FindBy(xpath = "//farmers-home-quote-contact-info//h1[@aria-label='PLEASE LET US KNOW HOW TO CONTACT YOU.'" +
			           " or @aria-label='PLEASE LET US\nKNOW HOW TO\nCONTACT YOU.']")
	private WebElement textPageTitle;

	@FindBy(xpath = "//farmers-home-quote-contact-info//div[@class='tui-subtitle-text-1']")
	private WebElement textPageSubTitle;

	private final By pageFooters = By.xpath("//farmers-home-quote-contact-info//span[@id='conactInfoDisclaimer']");

	@FindBy(xpath = "//mat-dialog-actions//button[.='CLOSE']")
	private WebElement buttonCloseDialog;

	@FindBy(xpath = "//farmers-home-quote-contact-info//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__image')]/../p")
	private WebElement discountSubTitleLock;

	private static final String DISCOUNT_LOCK_TEXT = "This information is needed to send your quote to you.\nWe will never sell your information.";

	@FindBy(xpath = "//farmers-home-quote-contact-info//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__potential')]/../p")
	private WebElement discountSubTitlePiggy;

	private static final String DISCOUNT_PIGGY_TEXT = "otential savings/discounts.";

	@FindBy(xpath ="//farmers-home-quote-contact-info//div[@class='discount-journey-card']//mat-icon[text()='info']")
	private WebElement discountHelpButtonPiggy;

	@FindBy(xpath = "//farmers-home-quote-discount-journey-dialog//h4")
	private WebElement discountHelpDialogTitle;

	private static final String DISCOUNT_HELP_DIALOG_TITLE = "Potential savings/discounts ($)";

	private static final String CONTENT_XPATH = "//farmers-home-quote-discount-journey-dialog//li";
	@FindBy(xpath = CONTENT_XPATH)
	private WebElement discountHelpDialogContent;

	@FindBy(xpath = "//farmers-home-quote-contact-info//mat-card//div[@class='djm-discount-check']/../p")
	private WebElement discountCheck;

	private String textDiscountCheck = "Thanks! You can also get our Paperless Discount.";

	private final List<String> footersContactInfoPage = List.of("By clicking \u201cAgree and submit\u201d, you agree to these ESIGN terms " +
					"and conditions and to receive marketing calls and texts as detailed below.",
			        "We call and/or text consumers with information about products and services. By clicking " +
					"\u201cAgree and submit\u201d, you consent to receive marketing calls and texts on behalf of Farmers\u00ae, " +
					"Foremost\u00ae, Bristol West\u00ae, and Farmers Life\u00ae associated entities and their representatives " +
					"using an automated telephone dialing system, AI-generated and artificial or pre-recorded voice, even for " +
					"numbers listed on national, state, or business do-not-call registries. Consent is not a condition of purchase. " +
					"Go to Farmers.com for alternative contact options. Message and data rates may apply.");

	private final List<String> errorsContactInfoPage = new LinkedList<>(Arrays.asList("Please enter your email address",
			"Please enter your phone number"));

	private final List<String> errorsEmailField = new LinkedList<>(Collections.singletonList("Please enter a valid email address"));
	private final List<String> errorsPhoneNumberField = new LinkedList<>(Arrays.asList("Phone number cannot start with 1 or 0",
			"Please enter 10 numbers", "Please enter a valid phone number"));

	private static final String PAGE_SUBTITLE_TEXT = "Ready to see your quote?\n\nPlease provide a preferred email address and " +
			"phone number \u2014 an agent will follow up soon.";

	private static final String PAGE_SUBTITLE_TEXT_KY = "Ready to see your quote?\n\nPlease provide a preferred email address and " +
			"phone number.";

	private static final String CONTACT_INFO_PAGE_FOOTER_KY = "Alternatively, you can speak with a Farmers representative to get a quote by calling %s";

	/**
     * Constructor.
     *
     * @throws Exception
     */
    public ContactInfoPage() throws Exception {
        super();
		waitElementBeVisibleClickable(inputEmail);
    }

    public void setEmail(String email) {
    	waitElementBeVisibleClickable(inputEmail);
    	Log.info("Email Address: " + email);
    	for (int i = 0; i < 10; i++) {
    		sendKeysOneByOne(inputEmail, email);
    		sleep(2);
    		sendKeysToElement(inputEmail, Keys.TAB);
    		sleep(2);
    		if (getEmailText().equals(email)) {
    			break;
    		}
    	}
    }

    public String getEmailText() {
    	String email = getAttributeData(inputEmail, VALUE);
    	Log.info("Email address: " + email);
    	return email;
    }

	public String getEmailLabel() {
		return getTextFromElement(labelEmail);
	}

    public void setPhoneNumber(String phoneNumber) throws Exception {
		driverWait(Property.PAGELOADTIMEOUT).until(ExpectedConditions.elementToBeClickable(inputPhoneNumber));
    	waitAndClickElement(inputPhoneNumber);
		sendKeysToElement(inputPhoneNumber, phoneNumber);
    }

	public String getPhoneNumber() {
		String phoneNumber = getAttributeData(inputPhoneNumber, VALUE);
		Log.info("Phone number: " + phoneNumber);
		return phoneNumber;
	}

	public String getPhoneNumberLabel() {
		return getTextFromElement(labelPhoneNumber);
	}

	public void setRequiredFields(ApplicantHQM applicant) throws Exception {
		screenCapture(inputEmail, "HQM_ContactInfoPage", EMPTY_STRING, false);
		this.setEmail(applicant.emailAddress);
		this.setPhoneNumber(applicant.phoneNumber);
	}

	public String setRequiredFieldsRandom(ApplicantHQM applicant) throws Exception {
		String emailAddress = applicant.emailAddress.split("@")[0] + "-" + RandomStringUtils.randomAlphabetic(3) +
				"@" + applicant.emailAddress.split("@")[1];
		this.setEmail(emailAddress);
		this.setPhoneNumber(applicant.phoneNumber);
		return emailAddress;
	}

	public void validatePageFieldContents(ApplicantHQM applicant, boolean bNew, FarmersSoftAssert fsa) {
		if (bNew) {
			fsa.assertTrue(this.getEmailText().isEmpty(), "Email address is empty");
			fsa.assertEquals(this.getEmailLabel(), "Email address", "Email address is requested");
			fsa.assertTrue(this.getPhoneNumber().isEmpty(), "Phone number is empty");
			fsa.assertEquals(this.getPhoneNumberLabel(), "Phone number", "Phone number is requested");
		} else {
			fsa.assertEquals(this.getEmailText(), applicant.emailAddress, "Email address validation");
			fsa.assertEquals(this.getPhoneNumber().replace("-",""), applicant.phoneNumber, "Phone number validation");
		}
	}

	public void validatePageErrors(FarmersSoftAssert fsa) throws Exception {
    	sendKeysToElement(inputEmail, Keys.TAB);
		List<String> pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		fsa.assertEquals(pageErrors, errorsContactInfoPage.subList(0,1), "Contact Info page - Found first error.");

		waitAndClickElement(inputPhoneNumber);
		sendKeysToElement(inputPhoneNumber, Keys.TAB);
		pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		fsa.assertEquals(pageErrors, errorsContactInfoPage, "Contact Info page - Found all expected errors.");

		this.setEmail("abcdef@abc2.com");
		pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		List<String> expectedErrors1 = new ArrayList<>();
		expectedErrors1.addAll(errorsEmailField);
		expectedErrors1.addAll(errorsContactInfoPage.subList(1,2));
		fsa.assertEquals(pageErrors, expectedErrors1, "Contact Info page - Email field expected errors.");

		this.setPhoneNumber("1");
		pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		expectedErrors1.remove(1);
		expectedErrors1.addAll(errorsPhoneNumberField.subList(0,1));
		fsa.assertEquals(pageErrors, expectedErrors1, "Contact Info page - Phone number field expected errors 1.");

		this.setPhoneNumber("2");
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		expectedErrors1.remove(1);
		pageErrors = this.getPageErrors();
		expectedErrors1.addAll(errorsPhoneNumberField.subList(1,2));
		fsa.assertEquals(pageErrors, expectedErrors1, "Contact Info page - Phone number field expected errors 2.");

		this.setPhoneNumber("9999999999");
		pageErrors = this.getPageErrors();
		Log.info(FOUND_PAGE_ERRORS + pageErrors);
		expectedErrors1.remove(1);
		expectedErrors1.addAll(errorsPhoneNumberField.subList(2,3));
		fsa.assertEquals(pageErrors, expectedErrors1, "Contact Info page - Phone number field expected errors 3.");
	}

	public void validatePageTitles(ApplicantHQM applicant, FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) {
		fsa.assertEquals(getTextFromElement(textPageTitle), CONTACT_INFO_PAGE_TITLE, "Contact Info page - page Title");
		String subtitle = isEasternExpansionState(applicant.stateCode) ? PAGE_SUBTITLE_TEXT_KY : PAGE_SUBTITLE_TEXT;
		fsa.assertEquals(getAttributeData(textPageSubTitle, "textContent").trim().replace("\n ","\n"), subtitle,
				"Contact Info page - page Sub-Title");
		if (staticContent != null) {
			fsa.assertEquals(staticContent.getContactInfoTitle(), CONTACT_INFO_PAGE_TITLE, "Contact Info page - page Title (AEM).");
			fsa.assertEquals(staticContent.getContactInfoCaption(), subtitle, "Contact Info page - page Sub-Title (AEM).");
		}
	}

	public void validateSubtitlesDiscountJourney(List<String> discounts, String stateCode, FarmersSoftAssert fsa) throws Exception {
		fsa.assertEquals(getTextFromElement(discountSubTitleLock), DISCOUNT_LOCK_TEXT,
				"Contact Info page - Discount Journey Subtitle Clock image.");
		int discountCount = discounts.size();
		List<String> discountsAvailable = new ArrayList<>(discounts);
		if (!getEmailText().isEmpty() && !isEasternExpansionState(stateCode) && !stateCode.equals(CA) && !isFlexState(stateCode)) {
			if (!discounts.contains("Paperless")) {
				discountsAvailable.add("Paperless");
				discountCount++;
			}
			Log.info("Contact Info page - Email is provided, so expecting Paperless discount.");
		}
		String textDiscount = discountCount > 0? discountCount + " p" : "P";
		fsa.assertEquals(getTextFromElement(discountSubTitlePiggy), textDiscount + DISCOUNT_PIGGY_TEXT,
				                                         "Contact Info page - Discount Journey Subtitle Lock image.");
		if (discountCount > 0) {
			waitAndClickElement(discountHelpButtonPiggy);
			waitElementBeVisible(discountHelpDialogTitle);
			fsa.assertEquals(getTextFromElement(discountHelpDialogTitle), DISCOUNT_HELP_DIALOG_TITLE.replace("($)", "(" + discountCount + ")"),
					"Contact Info - Discount Journey Help Dialog Title.");
			List<String> listDiscounts = driver().findElements(By.xpath(CONTENT_XPATH)).stream().map(this::getTextFromElement)
					.map(String::toLowerCase).sorted(Comparator.naturalOrder()).collect(Collectors.toList());
			discountsAvailable = discountsAvailable.stream().map(String::toLowerCase)
					.sorted(Comparator.naturalOrder()).collect(Collectors.toList());
			fsa.assertEquals(listDiscounts, discountsAvailable, "Contact Info page - Discount Journey Help Dialog Content.");
			waitAndClickElement(buttonCloseDialog);
			if (!isEasternExpansionState(stateCode) && !stateCode.equals(CA) && !isFlexState(stateCode)) {
				fsa.assertEquals(getTextFromElement(discountCheck), textDiscountCheck, "Contact Info page - Discount Journey, Discount Check.");
			}
		}
	}

	public void validatePageFooters(ApplicantHQM applicant, @Nullable String source, @Nullable StaticContentHQM staticContent) throws Exception {
		List<String> listPageFooters = driver().findElements(pageFooters).stream().map(this::getTextFromElement)
				.filter(el -> !el.isEmpty()).collect(Collectors.toList());
		Log.info("Found Contact Info page footers:" + listPageFooters);
		List<String> footers= new ArrayList<>(footersContactInfoPage);
		if (isEasternExpansionState(applicant.stateCode)) {
			if (source == null) {
				footers.add(String.format(CONTACT_INFO_PAGE_FOOTER_KY, CALL_FARMERS_EE));
			} else if (source.equals(QQ)) {
				footers.add(String.format(CONTACT_INFO_PAGE_FOOTER_KY, CALL_FARMERS_QUICKEN));
			}
		} else if (Arrays.asList(AR,AZ).contains(applicant.stateCode)){
			// compensate for extra space in the last sentence for several states
			String footers1 = footersContactInfoPage.get(footersContactInfoPage.size() - 1)
					.replace("Your consent is not a condition of purchase.", " Your consent is not a condition of purchase.");
			footers.clear();
			footers.add(footers1);
		}
		Assert.assertEquals(listPageFooters, footers, "Validate Contact Info page footers.");
		// Commented out the AEM comparison as these new disclaimers/footers are unavailable in the static AEM response.
//		if (staticContent != null) {
//			List<String> disclaimers = new ArrayList<>();
//			for (String disclaimer : staticContent.getContactInfoDisclaimer()) {
//				if (disclaimer.toLowerCase().contains("[phone_num")) {
//					if (source == null) {
//						disclaimer = disclaimer.replace("[PHONE_NUMBER_EE]", CALL_FARMERS_EE)
//								.replace("[Phone_Num_EE].", CALL_FARMERS_EE);
//					} else if (source.equals(QQ)) {
//						disclaimer = disclaimer.replace("[PHONE_NUMBER_EE]", CALL_FARMERS_QUICKEN)
//								.replace("[Phone_Num_EE].", CALL_FARMERS_QUICKEN);
//					}
//				}
//				disclaimers.add(disclaimer);
//			}
//			Assert.assertEquals(disclaimers, footers, "Validate Contact Info page footers (AEM).");
//		}
	}

	public void verifyPageFieldsReadonly(FarmersSoftAssert fsa) {
		fsa.assertEquals(getAttributeData(inputEmail, READONLY), LOWERCASE_TRUE, "Contact Info page - Email address is read-only");
		fsa.assertEquals(getAttributeData(inputPhoneNumber, READONLY), LOWERCASE_TRUE, "Contact Info page - Phone number is read-only");
	}

	public String getEmailTextInSaveAndFinishLaterDialog() {
		String email = getAttributeData(inputEmailSaveFinishLaterDialog, VALUE);
		Log.info("Email address: {} " + email);
		return email;
	}

	public void enterEmailInSaveAndFinishLaterDialog (String email) {
		waitElementBeVisibleClickable(inputEmailSaveFinishLaterDialog);
		Log.info("Email Address for Save & Finish Later dialog: {}" + email);
		for (int i = 0; i < 10; i++) {
			sendKeysOneByOne(inputEmailSaveFinishLaterDialog, email);
			sleep(1);
			sendKeysToElement(inputEmailSaveFinishLaterDialog, Keys.TAB);
			sleep(1);
			if (getEmailTextInSaveAndFinishLaterDialog().equals(email)) {
				break;
			}
		}
	}

	public void clickAgreeSubmitButton() {
		waitAndClickElement(buttonAgreeAndSubmit);
	}

}
