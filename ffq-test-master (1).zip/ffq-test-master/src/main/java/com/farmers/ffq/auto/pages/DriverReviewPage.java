package com.farmers.ffq.auto.pages;


import com.farmers.ffq.common.enums.*;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;

import net.datafaker.Faker;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.common.enums.AutoDiscounts.DEFENSIVE_DRIVER;

import static com.farmers.ffq.common.enums.AutoDiscounts.MATURE_DRIVER;
import static com.farmers.ffq.utils.GlobalVariables.*;
public class DriverReviewPage extends AutoBasePage {

    public static final String NG_VALID = "ng-valid";
    private static final String MARITAL_CHECKBOX_INPUT_XPATH = "//app-marriage-option//input[@type='checkbox']";
    private static final String MARITAL_CHECKBOX_XPATH = "//div[@class='auto-driver-review-question-married']//mat-checkbox";
    private static final String FINANCIAL_RESPONSIBILITY_CHECKBOX_XPATH = "//div[contains(@id,'ordered-field-placeholder_requiredFinancialResponsiblity')]//input[@type='checkbox']";
    private static final String FINANCIAL_FILING_ANOTHER_STATE_BUTTON_XPATH = "//mat-radio-button[contains(.,'Another state')]//input";
    private static final String ACCIDENT_OR_VIOLATION_DROPDOWN_XPATH = "//mat-select[@formcontrolname='incidentDescription']";
    private static final String ACCIDENT_OR_VIOLATION_DATE_INPUT_FIELD_XPATH = "//input[@formcontrolname='incidentDate']";
    private static final String ACCIDENT_TOGGLES_XPATH = "//button[contains(@aria-label,'Accident')]";
    private static final String VIOLATION_TOGGLE_XPATH = "//button[contains(@aria-label,'Violation')]";
    private static final String ADDITIONAL_INCIDENT_FORM_XPATH = "//app-incident//form[contains(@class,'ng-invalid')]";
    private static final String HAD_THEIR_DRIVER_LICENSE_CHECKBOX = "//mat-checkbox[@formcontrolname='hadDriveLicense']//input";
    private static final String DRIVER_AGE_XPATH_END = "//div[@class='auto-driver-review-age-display']/span";
    private static final String SAFETY_COURSE_SUBTEXT_XPATH_END = "//p[contains(@class, 'auto-driver-discount-safety-course-subinfo')]";
    private static final String CTA_ERROR_MESSAGE = "One or more required fields are incomplete or incorrect. Please Review.";
    public static final String IS_A_RIDE_SHARE_XPATH = "//mat-checkbox[contains(.,'rideshare')]";
    private static final String LIST_OF_DRIVERS_XPATH = "//div[@class='auto-driver-review-driver-card']//h2/..";

    private static final String COMMUTES_TO_DC_XPATH = "//mat-checkbox[contains(.,'Commutes to DC')]";
    private static final String OCCUPATION_RADIO_BUTTON_XPATH = "//mat-radio-button[contains(.,'%s')]//input";

    private static final String LICENSE_AGE_INPUT_FIELD_XPATH = "//input[@formcontrolname='ageFirstLicensed']";

    private static final String LICENSE_AGE_INPUT_TOGGLE_YES = "//div[contains(@class,'licensing-Info-head')]//mat-button-toggle[contains(.,'Yes')]";

    private static final String LICENSE_AGE_INPUT_TOGGLE_NO = "//div[contains(@class,'licensing-Info-head')]//mat-button-toggle[contains(.,'No')]";

    private static final String ACTIVE_MILITARY_RADIO_BUTTON_XPATH = "//div[contains(@class,'auto-driver-review-active-military-duty')]//input";
    private static final String DRIVER_LICENSE_NUMBER_INPUT_XPATH = "//div[@class='auto-driver-license-state-fields']//input";

    private static final String LICENSING_INFO_HEADER_XPATH = "//div[@class='licensing-Info-head']//p[@class='tui-info-box-header tui-field-label-text']";
    private static final String LICENSING_INFO_SUB_HEADER_XPATH = "//div[@class='licensing-info ng-star-inserted']//label[@class='tui-field-label-text']";
    private static final String LICENSING_INFO_US_YES_TOGGLE_XPATH = "//label[contains(.,'Canadian')]/..//mat-button-toggle[contains(.,'Yes')]";
    private static final String LICENSING_INFO_US_NO_TOGGLE_XPATH = "//label[contains(.,'Canadian')]/..//mat-button-toggle[contains(.,'No')]";
    private static final String LICENSING_INFO_US_DL_AGE_INPUT_XPATH = "//input[@formcontrolname='ageFirstLicencedInUS']";
    private static final String LICENSING_INFO_US_DL_AGE_INPUT_LABEL_XPATH = "//input[@formcontrolname='ageFirstLicencedInUS']/..//label";
    private static final String LICENSING_INFO_US_DL_AGE_INPUT_HINT_XPATH = "//input[@formcontrolname='ageFirstLicencedInUS']/ancestor::mat-form-field//strong";
    private static final String LICENSING_INFO_US_DL_AGE_INPUT_ERROR_MESSAGE_XPATH = "//input[@formcontrolname='ageFirstLicencedInUS']/ancestor::mat-form-field//mat-error";
    private static final String LICENSING_INFO_US_DL_DATE_INPUT_XPATH = "//mat-form-field[contains(.,'Date licensed')]//input";
    private static final String LICENSING_INFO_US_DL_DATE_INPUT_LABEL_XPATH = "//mat-form-field[contains(@id,'dateFirstLicensedInUS')]//label";
    private static final String LICENSING_INFO_US_DL_DATE_INPUT_ERROR_MESSAGE_XPATH = "//mat-form-field[contains(@id,'dateFirstLicensedInUS')]//mat-error";
    private static final String LICENSING_INFO_US_DL_DATE_INPUT_DATE_PICKER_XPATH = "//mat-form-field[contains(@id,'dateFirstLicensedInUS')]//mat-datepicker";
    private static final String LICENSING_INFO_US_DL_DATE_INPUT_HINT_XPATH = "//mat-form-field[contains(.,'Date licensed in U.S')]//mat-hint";
    private static final String LICENSING_FOREIGN_DL_QUESTION_CHECKBOX_XPATH = "//mat-checkbox[@formcontrolname='licensedToDriveInForeignCB']//input";
    private static final String LICENSING_FOREIGN_DL_QUESTION_CHECKBOX_LABEL_XPATH = "//mat-checkbox[@formcontrolname='licensedToDriveInForeignCB']//label";
    private static final String LICENSING_FOREIGN_DL_QUESTION_HEADER_XPATH = "//label[contains(.,'4 years ago')]/..//label";
    private static final String LICENSING_INFO_FOREIGN_YES_TOGGLE_XPATH = "//label[contains(.,'4 years ago')]/..//button[contains(.,'Yes')]";
    private static final String LICENSING_INFO_FOREIGN_NO_TOGGLE_XPATH = "//label[contains(.,'4 years ago')]/..//button[contains(.,'No')]";
    private static final String LICENSING_INFO_FOREIGN_DL_AGE_INPUT_XPATH = "//input[@formcontrolname='ageFirstLicencedInForeign' and not(@hidden)]";
    private static final String LICENSING_INFO_FOREIGN_DL_AGE_INPUT_LABEL_XPATH = "//input[@formcontrolname='ageFirstLicencedInForeign']/..//label";
    private static final String LICENSING_INFO_FOREIGN_DL_AGE_INPUT_HINT_XPATH = "//mat-form-field[contains(.,'Age licensed in another')]//strong";
    private static final String LICENSING_INFO_FOREIGN_DL_AGE_INPUT_ERROR_MESSAGE_XPATH = "//mat-form-field[contains(.,'Age licensed in another')]//mat-error";
    private static final String LICENSING_INFO_FOREIGN_DL_DATE_INPUT_XPATH = "//input[contains(@aria-label,'Date of Foreign')]";
    private static final String LICENSING_INFO_FOREIGN_DL_DATE_INPUT_LABEL_XPATH = "//mat-form-field[contains(.,'Date licensed in another')]//label";
    private static final String LICENSING_INFO_FOREIGN_DL_DATE_INPUT_DATE_PICKER = "//mat-form-field[contains(.,'Date licensed in another')]//mat-datepicker-toggle";
    private static final String LICENSING_INFO_FOREIGN_DL_DATE_INPUT_HINT_XPATH = "//mat-form-field[contains(.,'Date licensed in another')]//mat-hint";
    private static final String LICENSING_INFO_FOREIGN_DL_DATE_INPUT_ERROR_MESSAGE_XPATH = "//mat-form-field[contains(.,'Date licensed in another')]//mat-error";
    private static final String PLEASE_ENTER_VALID_AGE = "Please enter valid age";
    private static final String PLEASE_PROVIDE_AGE = "Please provide age";
    private static final String PLEASE_PROVIDE_VALID_DATE = "Please provide a valid date";
    private static final String ENTER_VALID_CASE_NUMBER = "Enter a valid 9-digit case number";
    private static final String DL_LICENSE_NUMBER_INPUT_FIELD_XPATH = "//input[@formcontrolname='licenseNumber']";
    @FindBy(id = "auto-driver-review-header")
    private WebElement driverReviewPageHeader;

    @FindBy(xpath = "//div[@class='auto-driver-review-heading-note']//p[@class='tui-field-label-text']")
    private WebElement driverReviewPageDescription;

    private static final String REVISE_WHICH_DRIVERS_TO_INCLUDE_LINK = "Revise which drivers to include";
    @FindBy(xpath = "//*[@data-tui-tracking-id='auto-drivers-review__drivers-overview-hyperlink']")
    private WebElement driversRevisionHyperlink;

    @FindBy(css = "mat-icon[data-tui-tracking-id='auto-drivers-review__additional-info']")
    private WebElement additionalDriverInfoIcon;

    @FindBy(css = "mat-icon[data-tui-tracking-id='auto-drivers-review__pni-info']")
    private WebElement pniInfoIcon;

    @FindBy(css = "mat-icon[data-tui-tracking-id='auto-drivers-review__sni-info']")
    private WebElement sniInfoIcon;

    @FindBy(xpath = "//h1[@class='model-caption-head']")
    private WebElement infoBoxHeader;

    @FindBy(xpath = "//p[contains(@class,'model-caption-text')]")
    private WebElement infoBoxContent;

    @FindBy(xpath = "//mat-icon[.='close']")
    private WebElement infoBoxCloseButton;

    private static final String EDIT_DRIVER_BUTTON_XPATH = "//button[contains(@class,'auto-driver-_drivers-list-details-edit')]";

    @FindBy(xpath = EDIT_DRIVER_BUTTON_XPATH)
    private List<WebElement> editDriverButtons;

    @FindBy(xpath = "//mat-dialog-container")
    private WebElement editDriverDialog;

    @FindBy(className = "mat-button-toggle-label-content")
    private WebElement genderToggleLabels;

    private static final String SECOND_DIALOG_XPATH = "//div[@class='cdk-global-overlay-wrapper'][2]";
    private static final String OR_OPERATOR = " | ";

    private static final String DIALOG_CLOSE_LINK_XPATH = "//div[contains(@class,'auto-add-driver-heading__div')]//mat-icon/ancestor::a";
    @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_CLOSE_LINK_XPATH + OR_OPERATOR + DIALOG_CLOSE_LINK_XPATH)
    private WebElement editDriverDialogCloseLink;

    @FindBy(id = "addDriverHeading")
    private WebElement addDriverHeading;

    @FindBy(xpath = "//label[contains(@class,'auto-add-driver-license__label')]")
    private WebElement driverLicenseQuestionLabel;

    @FindBy(xpath = "//label[contains(@class,'auto-add-driver-currently-insured__label')]")
    private WebElement currentlyInsuredQuestionLabel;

    @FindBy(xpath = "//div[contains(@class,'auto-add-driver-submit')]//button")
    private WebElement saveChangesButton;
    @FindBy(partialLinkText = "Cancel")
    private WebElement editDriverCancelButton;

    @FindBy(xpath = "//mat-dialog-actions//button[contains(.,'Cancel')]")
    private WebElement occupationSidePanelCancelButton;

    private static final String DIALOG_FIRST_NAME_FIELD_XPATH = "//input[@aria-label='First name']";
    private static final String TABINDEX_XPATH = "[string-length(@tabindex)>0]";
    @FindBy(xpath = "//mat-form-field[contains(.,'First name')]")
    private List<WebElement> listOfFirstNameFields;

    private static final String DIALOG_FIRST_NAME_ERROR_LABEL_XPATH = "//div[@id='formField_firstName']//mat-error";
    @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_FIRST_NAME_ERROR_LABEL_XPATH + OR_OPERATOR + DIALOG_FIRST_NAME_ERROR_LABEL_XPATH)
    private WebElement firstNameErrorMessage;

    private static final String DIALOG_LAST_NAME_FIELD_XPATH = "//input[@aria-label='Last name']";
    @FindBy(xpath = "//mat-form-field[contains(.,'Last name')]")
    private List<WebElement> listOfLastNameFields;

    private static final String DIALOG_LAST_NAME_ERROR_LABEL_XPATH = "//div[@id='formField_lastName']//mat-error";
    @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_LAST_NAME_ERROR_LABEL_XPATH + OR_OPERATOR + DIALOG_LAST_NAME_ERROR_LABEL_XPATH)
    private WebElement lastNameErrorMessage;

    private static final String DIALOG_DATE_OF_BIRTH_ERROR_LABEL_XPATH = "//div[@id='formField_dateOfBirth']//mat-error";
    @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_DATE_OF_BIRTH_ERROR_LABEL_XPATH + OR_OPERATOR + DIALOG_DATE_OF_BIRTH_ERROR_LABEL_XPATH)
    private WebElement dateOfBirthErrorMessage;

    private static final String DIALOG_DATE_OF_BIRTH_FIELD_XPATH = "//input[@aria-label='Date of birth']";
    @FindBy(xpath = "//mat-form-field[contains(.,'Date of birth')]")
    private List<WebElement> listOfDateOfBirthFields;

    private static final String DIALOG_GENDER_BUTTONS_XPATH = "//div[@id='gender']//button/span[contains(text(),'Female')]";
    @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_GENDER_BUTTONS_XPATH + OR_OPERATOR + "//div[@id='gender']//button[string-length(@tabindex)>0]/span[contains(text(),'Female')]")
    private List<WebElement> listOfFemaleGenderButtons;

    private static final String DIALOG_GENDER_ERROR_LABEL_XPATH = "//div[@id='formField_gender']//mat-error";
    @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_GENDER_ERROR_LABEL_XPATH + OR_OPERATOR + DIALOG_GENDER_ERROR_LABEL_XPATH)
    private WebElement genderErrorMessage;

    @FindBy(xpath = "//div[contains(@class,'licenseToggleQuestion')]//mat-error")
    private WebElement drivingSpouseErrorMessage;

    @FindBy(xpath = "//div[@id='formField_licenseIssued']//mat-error[not(contains(@aria-hidden,'true'))]")
    private WebElement licenseErrorMessageForDrivingSpouse;

    private static final String DIALOG_LICENSED_IN_USA_RADIO_BUTTONS_XPATH = "//div[contains(@id,'licenseIssued')]//mat-radio-button[contains(.,'%s')]";

    private String SPOUSE_DRIVING_VEHICLE_XPATH = "//div[@id='formField_licenseIssued']//mat-button-toggle-group//mat-button-toggle[contains(.,'%s')]";

    @FindBy(xpath = "//div[@id='formField_licenseIssued']//mat-error")
    private List<WebElement> licenseIssuedErrorMessages;

    @FindBy(xpath = "//p[contains(@class,'auto-add-driver__error-message')]")
    private WebElement editDriverModalErrorMessage;

    private static final String DIALOG_SAVE_BUTTON_XPATH = "//div[contains(@class,'auto-add-driver-submit')]//button";
    @FindBy(xpath = SECOND_DIALOG_XPATH + DIALOG_SAVE_BUTTON_XPATH + OR_OPERATOR + DIALOG_SAVE_BUTTON_XPATH)
    private List<WebElement> listOfSaveButtons;

    @FindBy(id = "changeStatusHeading")
    private WebElement changeStatusHeading;

    @FindBy(id = "changeStatusContent")
    private WebElement changeStatusContent;

    private static final String REMOVE_STATUS_XPATH = "//button[@class='tui-btn tui-btn-primary tui-button-text action-button']";

    @FindBy(xpath = "//div[@class='auto-driver-review-question-married']//p")
    private List<WebElement> maritalCheckboxSubtexts;

    @FindBy(xpath = REMOVE_STATUS_XPATH)
    private WebElement removeStatusButton;

    @FindBy(css = "button[class='tui-btn tui-btn-secondary tui-button-text']")
    private WebElement keepAsIsButton;

    @FindBy(xpath = "//div[contains(@id,'hadAccidentOrViolation')]//mat-checkbox//input[contains(@aria-label,'Had an accident')]")
    private List<WebElement> accidentCheckboxes;

    @FindBy(xpath = "//div[contains(@id,'ordered-field-placeholder_hadAccidentOrViolation')]//label[@class='mdc-label']")
    private List<WebElement> accidentQuestions;

    @FindBy(xpath = "//mat-checkbox[@formcontrolname='isEmployed']//input")
    private List<WebElement> employedCheckboxes;

    @FindBy(xpath = "//occupation-typeahead//input")
    private WebElement occupationInputField;

    @FindBy(xpath = "//occupation-typeahead//mat-label")
    private WebElement occupationInputFieldLabel;

    @FindBy(xpath = "//occupation-typeahead//mat-hint")
    private WebElement occupationInputFieldHint;

    @FindBy(xpath = "//div[contains(@class,'auto-occupation-selected-message')]")
    private WebElement employmentDiscountQualification;

    @FindBy(css = "div[class='auto-occupation-not-found-message tui-body-text-1 ng-star-inserted']")
    private WebElement employmentDiscountNotEligible;

    @FindBy(css = "div[class='auto-driver-review-question-min-age-section']")
    private WebElement minAgeSection;

    @FindBy(xpath = "//*[contains(@id,'ordered-field-placeholder_hadAccidentOrViolation')]//p")
    private List<WebElement> accidentSubTexts;

    @FindBy(xpath = "//div[@class='col auto-driver-discount-save-bundle-checkbox ng-star-inserted']//input")
    private WebElement bundleCheckbox;

    @FindBy(xpath = "//mat-checkbox[@attr.aria-label=\"Farmers Bundle and Save Discount\"]//span[@class='mat-checkbox-label']")
    private WebElement bundleCheckboxLabel;

    @FindBy(xpath = "//div[contains(@class,'auto-driver-review-cta-validation-text-holder')]//span")
    private WebElement ctaErrorMessage;

    @FindBy(id = "auto-driver-review-cta-continue")
    private WebElement continueButton;

    @FindBy(xpath = "//div[contains(@class,'auto-driver-review-cta-button-container')]//div")
    private WebElement ctaDescription;

    @FindBy(xpath = "//a[contains(@class, 'auto-drivers-review__save-bundle-link')]")
    private WebElement addAdditionalFarmersProductsLink;

    @FindBy(css = "p[class='tui-body-text-bold auto-driver-review-save-bundle-text']")
    private WebElement bundleCardHeader;

    @FindBy(xpath = "//div[contains(@class,'auto-driver-review-save-bundle-content')]/p[2]")
    private WebElement bundleCardContent;

    @FindBy(css = "a[class='auto-drivers-review__save-bundle-link tui-anchor']")
    private WebElement bundleLink;

    @FindBy(css = "a[class='auto-drivers-review__save-bundle-link tui-anchor']")
    private WebElement bundleLinkText;

    @FindBy(css = "div[class='auto-driver-review-save-bundle-info-icon']>mat-icon")
    private WebElement bundleInfoIcon;

    @FindBy(css = "div[class='auto-driver-review-save-bundle-info-header-content']>h5")
    private WebElement bundleInfoHeader;

    @FindBy(css = "div[class='auto-driver-review-save-bundle-info-header-content']>p")
    private WebElement bundleInfoContent;

    @FindBy(xpath = "//div[@class='auto-driver-review-save-bundle-side-sheet-title']//h4")
    private WebElement bundleModalHeader;

    @FindBy(css = "div[class='auto-driver-review-cancel-button']>button")
    private WebElement bundleCancelLink;

    @FindBy(xpath = "//div[contains(@class,'auto-driver-review-save-bundle-items')]//span[@class='mat-checkbox-label']")
    private List<WebElement> saveBundleItems;

    @FindBy(xpath = "//div[contains(@class,'auto-driver-review-save-bundle-items')]//mat-checkbox")
    private List<WebElement> bundleCheckboxes;

    @FindBy(xpath = "//span[contains(text(),'Please select a product to be eligible for discount.')]")
    private WebElement saveBundleErrorMessage;

    @FindBy(css = "button[class='tui-btn tui-btn-primary auto-save-bundle-sheet-add-button']")
    private WebElement saveAndBundleAddButton;

    @FindBy(css = "span[class='auto-driver-discount-save-bundle-selected-item']")
    private WebElement saveBundleSelectedItem;

    @FindBy(xpath = "//app-remove-bundle//h5")
    private WebElement removeBundleHeader;

    @FindBy(id = "remove-bundle-content")
    private WebElement removeBundleContent;

    @FindBy(xpath = "//button[contains(@class,'tui-btn tui-btn-link tui-button-text')]")
    private WebElement removeBundleKeepItButton;

    @FindBy(css = "div[class='col remove-action-button']")
    private WebElement removeBundleButton;

    @FindBy(css = "div[class='col auto-driver-discount-save-bundle-add-edit-link']")
    private WebElement addEditAdditionalPolicies;

    @FindBy(css = "p[class='auto-driver-review-save-bundle-congratulations-message']")
    private WebElement bundleCongratsMessage;

    @FindBy(xpath = "//app-save-bundle-sheet//mat-icon")
    private WebElement bundleDialogueCloseIcon;

    @FindBy(xpath = "//div[contains(@class,'auto-driver-discount-full-time')]//div[contains(@class,'auto-driver-review-student-container')]")
    private List<WebElement> studentDiscountCheckboxLabels;

    private final String OCCUPATION_SIDE_PANEL_HEADER_XPATH = "//app-occupation-list//h1";
    @FindBy(xpath = OCCUPATION_SIDE_PANEL_HEADER_XPATH)
    private WebElement eligibleOccupationModalHeader;
    @FindBy(xpath = "//div[contains(@class,'row occupation-retired-checkbox')]//p")
    private WebElement employedOrRetiredTitle;

    @FindBy(xpath = "//p[contains(.,'Select from the list of eligible occupation(s). Verification of occupation will be required.')]")
    private WebElement selectEligibleOccupationsTitle;

    private final String DISCOUNT_UNAVAILABLE_MESSAGE_XPATH = "//div[contains(@class,'discount-unavailable')]//p";
    @FindBy(xpath = DISCOUNT_UNAVAILABLE_MESSAGE_XPATH)
    private WebElement discountUnavailableMessage;

    private final String OCCUPATION_SIDE_PANEL_ERROR_MESSAGE_XPATH = "//div[contains(@class,'auto-occupation')]//mat-error";
    @FindBy(xpath = OCCUPATION_SIDE_PANEL_ERROR_MESSAGE_XPATH)
    private WebElement occupationSidePanelErrorMessage;

    private final String SEE_ELIGIBLE_OCCUPATIONS_XPATH = "//div[contains(@class,'auto-driver-discount-employed')]//button";

    final String occupationRadioButtonsXpath = "//div[@class='auto-occupation-list-container']//mat-radio-button";

    @FindBy(xpath = "//div[contains(@class,'row occupation-retired-checkbox')]//mat-button-toggle")
    private List<WebElement> occupationsSidePanelToggles;

    @FindBy(xpath = "//mat-button-toggle[contains(.,'Employed')]")
    private WebElement employedToggle;

    @FindBy(xpath = "//mat-button-toggle[contains(.,'Retired')]")
    private WebElement retiredToggle;

    @FindBy(xpath = "//div[contains(@class,'discount-unavailable')]")
    private WebElement discountUnavailable;

    @FindBy(xpath = occupationRadioButtonsXpath)
    private List<WebElement> occupationRadioButtons;

    private final String OCCUPATION_ADDED_CONFIRMATION_XPATH = "//div[contains(@class,'auto-drivers-review-occupation-added tui-body-text')]";
    @FindBy(xpath = OCCUPATION_ADDED_CONFIRMATION_XPATH)
    private WebElement occupationAddedConfirmation;

    @FindAll({
            @FindBy(partialLinkText = "Remove occupation"),
            @FindBy(xpath = "//a[@class='auto-drivers-review-occupation-remove tui-link-footer offset-1 text-decoration-none']")
    })
    private WebElement removeOccupationButton;
    @FindBy(xpath = "//h1[contains(@class,'remove-occupation-title')]")
    private WebElement removeOccupationPanelHeader;

    @FindBy(xpath = "//button[contains(@class,'keep-it-action-button')]")
    private WebElement keepOccupation;

    @FindBy(xpath = "//div[contains(@class,'remove-action-button')]//button")
    private WebElement removeButton;


    public By seeEligibleOccupationList = By.xpath(SEE_ELIGIBLE_OCCUPATIONS_XPATH);

    private static final String ADD_BUTTON_CSS = "button[class='tui-btn tui-btn-primary tui-button-text action-button']";
    @FindBy(css = ADD_BUTTON_CSS)
    private WebElement closeOrSaveButtonOccupationSideSheet;

    private final String OCCUPATION_SECTION_XPATH = "//div[contains(@class,'occupation-ab-section-card') or contains(@class,'auto-driver-review-occupation-heading')]";

    @FindAll({
            @FindBy(xpath = "//div[contains(@class,'occupation-ab-section-card') or contains(@class,'auto-driver-review-occupation-heading')]//p"),
            @FindBy(id = "occupationLabel")
    })
    List<WebElement> occupationHeaders;

    @FindAll({
            @FindBy(xpath = "//div[contains(@class,'occupation-ab-section-card') or contains(@class,'auto-driver-review-occupation-heading')]//p[2]"),
            @FindBy(id = "occupationDesc")
    })
    List<WebElement> occupationSubtexts;

    @FindBy(xpath = "//div[contains(@class,'license-info')]//p[@class='tui-info-box-header tui-field-label-text']")
    private List<WebElement> driverLicenseNumberInfoBoxHeaderBrowser;

    @FindBy(xpath = "//div[contains(@class,'license-info')]//p[@class='tui-info-box-content']")
    private List<WebElement> driverLicenseNumberInfoBoxTextBrowser;

    @FindBy(xpath = "//mat-icon[@data-tui-tracking-id='auto-drivers-review__driver-license']")
    private List<WebElement> driverLicenseNumberInfoBoxMobileIcon;

    @FindBy(xpath = "//mat-icon[@data-tui-tracking-id='auto-drivers-review__driver-license']")
    private List<WebElement> driverLicenseNumberInfoBoxHeaderMobile;

    @FindBy(xpath = "//div[contains(@class,'auto-driver-review-age-licensed')]//div[@class='auto-driver-review-info-header-content']//p[1]")
    private List<WebElement> driverLicenseAgeInfoHeaderBrowser;

    @FindBy(xpath = "//div[contains(@class,'licensing-Info')]//p[@class='tui-info-box-header tui-field-label-text']")
    private List<WebElement> driverLicenseInfoInfoHeaderBrowser;

    @FindBy(xpath = "//div[contains(@class,'auto-driver-review-age-licensed')]//div[@class='auto-driver-review-info-header-content']//p[2]")
    private List<WebElement> driverLicenseAtWhatAgeBrowser;

    @FindBy(xpath = "//div[contains(@class,'auto-driver-review-age-licensed')]//div[@class='auto-driver-review-info-header-content']//p[3]")
    private List<WebElement> driverLicenseGapBrowser;

    @FindBy(xpath = "//div[contains(@class,'licensing-Info')]//p[@class='tui-info-box-content']")
    private List<WebElement> licensingInfoHelpContent;

    @FindBy(xpath = "//mat-icon[contains(@class,'mat-icon notranslate auto-driver-review-age-licensed-info tui-info-box-icon mobile-info-icon')]")
    private List<WebElement> driverLicenseAgeMobileHelpIcon;

    @FindBy(xpath = "//mat-icon[@data-tui-tracking-id='auto-drivers-review__licensing-info']")
    private List<WebElement> driverLicensingInfoMobileHelpIcon;

    private final String DRIVER_LICENSE_NUMBER_INPUT_ERROR_XPATH = "//div[@class='auto-driver-license-state-fields']//mat-error";
    @FindBy(xpath = DRIVER_LICENSE_NUMBER_INPUT_ERROR_XPATH)
    private List<WebElement> driverLicenseNumberInputError;

    @FindBy(xpath = "//mat-error[contains(@class,'age-license-eror') and not(@hidden)]")
    private List<WebElement> driverLicenseAgeError;

    public static final String GPA_OVER_3_CHECKBOX_XPATH = "//div[normalize-space(text())='Has a GPA over 3.0']";
    @FindBy(xpath = GPA_OVER_3_CHECKBOX_XPATH)
    private WebElement lblGPAOver30;
    public static final String GPA_OVER_3_INPUT_XPATH = "//div[normalize-space(text())='Has a GPA over 3.0']//input";
    @FindBy(xpath = GPA_OVER_3_INPUT_XPATH)
    private WebElement chkGPAOver30;

    public static final String DISTANT_STUDENT_CHECKBOX_INPUT_XPATH = "//div[normalize-space(text())='Attends school more than 100 miles away from home without custody of a car']//input";

    @FindBy(xpath = DISTANT_STUDENT_CHECKBOX_INPUT_XPATH)
    private WebElement chkAttendsSchoolMoreThan300Miles;

    private final String MUST_BE_A_FULL_TIME_STUDENT_LABEL_XPATH = "//p[normalize-space(text())='Must be a full-time student']";
    @FindBy(xpath = MUST_BE_A_FULL_TIME_STUDENT_LABEL_XPATH)
    private WebElement lblMustBeAFullTimeStudent;

    private final String MUST_BE_A_FULL_TIME_STUDENT_AND_LICENSED_LESS_THAN_10_YEARS_XPATH = "//p[normalize-space(text())='Must be a full-time student and licensed for less than 10 years']";

    @FindBy(xpath = MUST_BE_A_FULL_TIME_STUDENT_AND_LICENSED_LESS_THAN_10_YEARS_XPATH)
    private WebElement lblMustBeAFullTimeStudentAndLicensedForLessThan10Yrs;

    private final String DISTANT_STUDENT_XPATH = "//div[normalize-space(text())='Attends school more than 100 miles away from home without custody of a car']";
    @FindBy(xpath = DISTANT_STUDENT_XPATH)
    private WebElement lblAttendsSchoolMoreThan100Miles;

    @FindBy(xpath = "//div[normalize-space(text())='Shares vehicle usage in household']")
    private WebElement lblSharesVehicleUsage;

    private final String DISTANT_STUDENT_SUBTEXT_XPATH = "//div[contains(@id,'fullTimeAwayatSchool')]//p";
    @FindBy(xpath = DISTANT_STUDENT_SUBTEXT_XPATH)
    private WebElement lblMustBeAFullTimeStudentAndChildOfPNI;

    @FindBy(xpath = "//div[normalize-space(text())='Shares vehicle usage in household']//input")
    private WebElement chkSharesVehicleUsage;

    @FindBy(xpath = "//mat-button-toggle-group[contains(@class,'occupation-affinity-toggle')]//button[@aria-label='No']")
    List<WebElement> noOccupationToggleOptions;

    private final String SPECIAL_DEFENSIVE_DRIVER_SUBHEADER_TEXT = "Special defensive driver course designed for drivers over 55 years old";
    private final String KS_DEFENSIVE_DRIVER_COURSE_SUBHEADER_TEXT = "Completed an approved driving safety or defensive driving course";
    private final String CT_DEFENSIVE_DRIVER_SUBHEADER_TEXT = "Special defensive driver course designed for drivers over 60 years old";
    private final String MA_DEFENSIVE_DRIVER_SUBHEADER_TEXT = "Special defensive driver course designed for drivers over 65 years old";

    private final String SAFETY_COURSE_CHECKBOX_XPATH = "//mat-checkbox[@formcontrolname='safetyCourseCompleted']";

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public DriverReviewPage() throws Exception {
    }

    public boolean isOnDriverReviewPage() throws Exception {
        scrollToTopOfPage();
        return isElementVisible(driverReviewPageHeader, 30);
    }

    public boolean isOnDriverReviewPageQuickCheck() throws Exception {
        scrollToTopOfPage();
        return isElementVisible(driverReviewPageHeader, 3);
    }

    public void reviewAllDrivers(AutoApplicant applicant, Optional<FarmersSoftAssert> fsa) throws Exception {
        reviewApplicant(applicant, fsa);
        if (!applicant.getAdditionalDrivers().isEmpty() || getSessionStorageAppStore().getAuto().getDrivers().size() > 1) {
            reviewAdditionalDriver(applicant, fsa);
        }
        if (applicant.getIncidents().isEmpty() && !applicant.isHaveAccidentOrViolations() && fsa.isPresent() && !isBDQFlowEnabled()) {
            sleep(1);
            fsa.get().assertTrue(isDiscountPresentInTheSideSheet("Accident free"), "Additional Discounts should include 'Accident free'");
        }
        if (applicant.getTestScenario().contains("UMB")) {
            sleep(1);
            Log.info("Capture driver details" + NEWLINE, applicant.getTestScenario() + "Driver Details");
        }
        // enter driver license age for CA
        if (applicant.getStateCode().equals(CA)) {
            List<String> displayedDrivers = getDisplayedDrivers();
            for (String displayedDriver : displayedDrivers) {
                enterDriverLicenseAge_CA(displayedDriver, 16);
                if(!getApplicantFullName(applicant).equals(displayedDriver)){
                    addEmployment(displayedDriver, applicant.getOccupation());
                }
            }
        }

        // handle not provided age fields
        List<WebElement> notHandledAgeFields = driver().findElements(By.xpath("//input[@formcontrolname='ageFirstLicensed' and contains(@class,'invalid')]"));
    	int numberOfElements = notHandledAgeFields.size();
        for (int i = 0; i< numberOfElements; i++){
            WebElement licenseAgeInputField = notHandledAgeFields.get(i);
            scrollElementToMiddle(licenseAgeInputField);
            waitAndClickElement(licenseAgeInputField);
            sendKeysToElement(licenseAgeInputField, "15");
            sendKeysToElement(licenseAgeInputField, Keys.TAB);
            wait.until(ExpectedConditions.attributeContains(licenseAgeInputField, CLASS, NG_VALID));

        }

        // handle not provided dl fields
        List<WebElement> notHandledDlInputFields = driver().findElements(By.xpath("//input[@formcontrolname='licenseNumber' and contains(@class,'invalid')]"));
    	numberOfElements = notHandledDlInputFields.size();
        for (int i = 0; i< numberOfElements; i++){
            WebElement dlInputField = notHandledDlInputFields.get(i);
            scrollElementToMiddle(dlInputField);
            waitAndClickElement(dlInputField);
            String licenseNumber = LicenseFormatByState.getLicenseNumberByState(applicant.getStateCode());
            sendKeysToElement(dlInputField, licenseNumber);
            sendKeysToElement(dlInputField, Keys.TAB);
            waitForSpinnerToBeGone();
            wait.until(ExpectedConditions.attributeContains(dlInputField, CLASS, NG_VALID));
        }
    }

    public void fillOutOccupationAffinitySection() {
        for (WebElement noOccupationToggleOption : noOccupationToggleOptions) {
            scrollAndClickOnElement(noOccupationToggleOption);
        }
    }

    public void validateBDQSpecificRequirements(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        fsa.assertTrue(isOnDriverReviewPage(), "User on the driver review page");

        // validate bw logo present
        fsa.assertTrue(isOnBristolWest() && !isOnFarmers(), "Bristol west logo present");

        // validate Occupation section is not visible for PNI
        AppStore.Data.CustomerData customerData = getSessionStorageAppStore().getData().getCustomerData();
        String pniFullName = customerData.getFirstName() + SPACE + customerData.getLastName();
        String eligibileOccupationLink = getDriverCardXpathByFullName(pniFullName) + SEE_ELIGIBLE_OCCUPATIONS_XPATH;
        fsa.assertTrue(!isElementPresent(By.xpath(eligibileOccupationLink), 1), "'See eligible occupation' link should not be present in bdq flow");
        validateValidateAndFooterForBDQ(fsa, applicant, this);
        fsa.assertTrue(!isDiscountSectionDisplayed(), "Discount section should not be displayed on " + this.getClass().getSimpleName());
        validateAgentSectionBDQ(fsa, applicant);
    }

    private void reviewApplicant(AutoApplicant applicant, Optional<FarmersSoftAssert> fsaOptional) throws Exception {
        FarmersSoftAssert fsa = null;
        String stateCode = applicant.getStateCode();
        if (fsaOptional.isPresent()) {
            fsa = fsaOptional.get();
        }
        boolean operationResult = false;
        String pniFullName = getApplicantFullName(applicant);
        // add marital status for pni
        if (applicant.getMaritalStatus().equals(MARRIED)) {
            scrollToElement(driverReviewPageHeader);
            String sniFullName = getSniFullName(applicant);
            operationResult = setMaritalRelationship(pniFullName, sniFullName);
            if (fsaOptional.isPresent()) {
                fsa.assertTrue(operationResult, "Marital Relation Set up");
            }
        }
        int age = applicant.getAge();

        // enter drivers license number if applicable
        addDriverLicenseNumber(applicant, pniFullName);

        // driver license age
        if (isAskingDriverLicenseAgeState(applicant.getStateCode())) {
            enterDriverLicenseAge(applicant, pniFullName, applicant.getFirstAgeUnitedStatesDriverLicense());
        } else if (age <= MAX_YOUNG_AGE && (age - applicant.getFirstAgeUnitedStatesDriverLicense() < 3)) {
            operationResult = addHadDriversLicense(pniFullName, applicant.getFirstAgeUnitedStatesDriverLicense());
            if (fsaOptional.isPresent()) {
                fsa.assertTrue(operationResult, "Driver License Age Validation");
            }
        }
        // add financial filing
        String financialFiling = applicant.getFinancialFiling();
        if (financialFiling.contains(SR_22)) {
        	operationResult = addFinancialFiling(applicant, pniFullName);
            if (fsaOptional.isPresent()) {
                fsa.assertTrue(operationResult, "Financial Filing Addition");
            }
        }
        // add accident or violation
        if (applicant.isHaveAccidentOrViolations() || !applicant.getIncidents().isEmpty()) {
            List<SqlIncident> applicantIncidents = applicant.getIncidents().stream().filter(incident -> incident.getAdditionalDriverId() == 0).collect(Collectors.toList());
            updateIncidentsWithSessionStorageData(applicantIncidents);
            operationResult = addIncidents(pniFullName, applicantIncidents);
            if (fsaOptional.isPresent()) {
                fsa.assertTrue(operationResult, "Incident Addition Addition");
            }
        }

        // add safety course
        if (isSafetyCourseExpected(applicant, age) && applicant.isCompletedDriversSafetyCourse()) {
            operationResult = addSafetyCourse(pniFullName);
            if (fsaOptional.isPresent()) {
                fsa.assertTrue(operationResult, "Safety course Addition");
                sleep(1);
                String expectedDiscountName = isDefensiveDriverDiscountEnabledOnDriverReview(stateCode) ? DEFENSIVE_DRIVER.getName() : MATURE_DRIVER.getName();
                fsa.assertTrue(isDiscountPresentInTheSideSheet(expectedDiscountName), expectedDiscountName + " listed in Additional Discounts");
            }
        }

        //On active military duty is only applicable for PNI
        if (stateCode.equals(LA)) {
            WebElement activeMilitaryElement = driver().findElement(By.xpath(getDriverCardXpathByFullName(pniFullName) + ACTIVE_MILITARY_RADIO_BUTTON_XPATH));
            addActiveMilitaryDuty(activeMilitaryElement);
        }
        // add employment
        if (!isMA61Environment() && !isEmploymentDisabledState(stateCode)) {
        	operationResult = addEmployment(getApplicantFullName(applicant), applicant.getOccupation());
            if (fsaOptional.isPresent()) {
                fsa.assertTrue(operationResult, "Employment Addition");
            }
        }

        // add Commutes to DC if applicable randomly
        boolean addCommuteToDC = RandomUtils.nextBoolean();
        if (addCommuteToDC) {
            addCommutesToDC(applicant, pniFullName);
        }

        //click on rideshare checkbox if applicable
        if (isElementDisplayed(By.xpath(IS_A_RIDE_SHARE_XPATH))) {
            clickIsRideShareDriverCheckbox(pniFullName);
            Log.info("Rideshare checkbox is clicked for PNI when rideshare veh is provided");
        }

        // add full time student discount if applicable
        addFullTimeStudent(Optional.empty(), applicant);


    }

    public void addDriverLicenseNumber(AutoApplicant applicant, String fullName) throws Exception {
        if (isAskingForDriverLicenseNumber(applicant)) {
            if(Arrays.asList(CA, MA).contains(applicant.getStateCode()) && applicant.getFirstAgeForeignDriverLicense() == 18) {
                return;
            }
            String stateCode = applicant.getStateCode();
            LicenseFormatByState.getLicenseNumberByState(stateCode);
            String driverLicenseNumber = LicenseFormatByState.getLicenseNumberByState(stateCode);
            scrollToElement(driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName))));
            List<WebElement> driversLicenseInputs = driver().findElements(By.xpath(getDriverCardXpathByFullName(fullName) + DRIVER_LICENSE_NUMBER_INPUT_XPATH));
            if(driversLicenseInputs.isEmpty()) {
                return;
            }
            WebElement driversLicenseInput = driversLicenseInputs.get(0);
            scrollAndClickOnHiddenElement(driversLicenseInput);
            sendKeysToElement(driversLicenseInput, driverLicenseNumber);
            sendKeysToElement(driversLicenseInput, Keys.TAB);
            waitForSpinnerToBeGone();
//            wait.until(ExpectedConditions.attributeToBe(driversLicenseInput, ARIA_INVALID, LOWERCASE_FALSE));
        }
    }

    private boolean isAskingForDriverLicenseNumber(AutoApplicant applicant) {
        return Arrays.asList(MA).contains(applicant.getStateCode());
    }

    public void clickOccupationLink() throws Exception {
        waitAndClickElement(driver().findElements(seeEligibleOccupationList).get(0));
    }

    public boolean isAskingDriverLicenseAgeState(String applicantStateCode) {
        return Arrays.asList(CA, KY, LA, MA).contains(applicantStateCode);
    }

    public static boolean isEmploymentDisabledState(String stateCode) {
        return Arrays.asList(FL, KY, LA, MA, MS, NC).contains(stateCode);
    }

    private void addCommutesToDC(AutoApplicant applicant, String fullName) throws Exception {
        if (!applicant.getStateCode().equals(MD)) {
            return;
        }
        WebElement commutesToDcCheckbox = driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + COMMUTES_TO_DC_XPATH));
        waitAndClickElement(commutesToDcCheckbox);
    }

    private boolean isSafetyCourseExpected(AutoApplicant applicant, int age) {
        String stateCode = applicant.getStateCode();
        boolean isSafetyCourse = isBDQFlowEnabled() ? isSafetyCourseExpectedStateBDQ(applicant.getStateCode()) : isSafetyCourseExpectedState(stateCode);
        if (isBDQFlowEnabled()) {
            if ((age >= MIN_OLD_AGE_ONE_UI || List.of(NJ, KS).contains(stateCode)) && isSafetyCourse) {
                return true;
            } else {
                return false;
            }
        }

        return isSafetyCourseExpectedState(stateCode) && (age >= MIN_OLD_AGE_ONE_UI || List.of(NJ, KS).contains(stateCode));
    }

    public void reviewAdditionalDriver(AutoApplicant applicant, Optional<FarmersSoftAssert> fsaOptional) throws Exception {
        FarmersSoftAssert fsa = null;
        if (fsaOptional.isPresent()) {
            fsa = fsaOptional.get();
        }
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        int additionalDriversSize = java.lang.Math.min(MAX_NUMBER_OF_ADDITIONALDRIVERS, additionalDrivers.size());
        List<SqlIncident> incidents = applicant.getIncidents();
        int additionalDriverId = 1;
        boolean operationResult = false;
        for (int i = 0; i < additionalDriversSize; i++) {
            SqlAdditionalDriver currentDriver = additionalDrivers.get(i);
            String currentDriverFullName = getDriverFullName(currentDriver);
            // validate accident/violation
            int finalAdditionalDriverId = additionalDriverId;
            List<SqlIncident> currentDriverIncidents = incidents.stream().filter(incident -> incident.getAdditionalDriverId() == finalAdditionalDriverId).collect(Collectors.toList());
            additionalDriverId++;
            if (!currentDriverIncidents.isEmpty()) {
                updateIncidentsWithSessionStorageData(currentDriverIncidents);
                operationResult = addIncidents(currentDriverFullName, currentDriverIncidents);
                if (fsaOptional.isPresent()) {
                    fsa.assertTrue(operationResult, "Incidents added for additional driver " + (i+1));
                }
            }
            // add safety course
            String stateCode = applicant.getStateCode();
            if (currentDriver.isCompletedDriversSafetyCourse() && !stateCode.equals(NE) && ((currentDriver.getAge() >= MIN_OLD_AGE_ONE_UI) || stateCode.equals(KS))) {
                operationResult = addSafetyCourse(currentDriverFullName);
                if (fsaOptional.isPresent()) {
                    fsa.assertTrue(operationResult, "Safety course added for additional driver " + (i+1));
                }
            }
            // adding drivers license if applicable
            addDriverLicenseNumber(applicant, currentDriverFullName);

            //  add/validate Has had driver's license for less than 3 years
            if (isAskingDriverLicenseAgeState(applicant.getStateCode())) {
                enterDriverLicenseAge(applicant, currentDriverFullName, 16);
            } else if (currentDriver.getAge() <= MAX_YOUNG_AGE && currentDriver.getAge() - currentDriver.getFirstAgeUnitedStatesDriverLicense() < 3) {
            	operationResult = addHadDriversLicense(currentDriverFullName, applicant.getFirstAgeUnitedStatesDriverLicense());
                if (fsaOptional.isPresent()) {
                    fsa.assertTrue(operationResult, "Driver License Age added for additional driver " + (i+1));
                }
            }
            // add financial filing
            if (currentDriver.getFinancialFiling().contains(SR_22)) {
            	operationResult = addFinancialFiling(applicant, currentDriverFullName);
                if (fsaOptional.isPresent()) {
                    fsa.assertTrue(operationResult, "Financial filing added for additional driver " + (i+1));
                }
            }
            // add SNI occupation
            if (currentDriver.getRelationshipToApplicant().equals(SPOUSE) && !isEmploymentDisabledState(stateCode)) {
            	operationResult = addEmployment(getDriverFullName(currentDriver), currentDriver.getOccupation());
                if (fsaOptional.isPresent()) {
                    fsa.assertTrue(operationResult, "Employment added for additional driver " + (i+1));
                }
            }

            // add Commutes to DC if applicable randomly
            boolean addCommuteToDC = RandomUtils.nextBoolean();
            if (addCommuteToDC) {
                addCommutesToDC(applicant, currentDriverFullName);
            }
            // add full time student discount if applicable
            addFullTimeStudent(Optional.of(currentDriver), applicant);

        }
        List<String> additionalDriversFromData = applicant.getAdditionalDrivers().stream().map(each -> getDriverFullName(each)).collect(Collectors.toList());
        List<String> displayedDrivers = getDisplayedDrivers();
        List<String> notProcessedDrivers = displayedDrivers.stream()
                .filter(item -> !additionalDriversFromData.contains(item))
                .collect(Collectors.toList());

        for (String notProcessedDriver : notProcessedDrivers) {
            addDriverLicenseNumber(applicant, notProcessedDriver);
            enterDriverLicenseAge(applicant, notProcessedDriver, 15);
        }

    }

    private void addActiveMilitaryDuty(WebElement activeMilitaryElement) {
        if (RandomUtils.nextBoolean() && RandomUtils.nextBoolean()) {
            // add randomly
            clickElement(activeMilitaryElement);
        }
    }

    public boolean validateDriversReviewPageTitle() {
        waitElementBeVisible(driverReviewPageHeader);
        final String expectedDriversReviewPageHeaderText = "Drivers";
        return testExpectedTextContentForElement(driverReviewPageHeader, expectedDriversReviewPageHeaderText);
    }

    public boolean validateDriversReviewPageDescription() {
        waitElementBeVisible(driverReviewPageDescription);
        final String expectedDriversReviewPageDescription = "Please make sure everyone in the household who will be driving is included.";
        return getTextFromElement(driverReviewPageDescription).replace(REVISE_WHICH_DRIVERS_TO_INCLUDE_LINK, "").trim().equals(expectedDriversReviewPageDescription);
    }

    public void validatePageHeaderAndDescription() {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(validateDriversReviewPageTitle(), "Drivers Review Page Page Title");
        fsa.assertTrue(validateDriversReviewPageDescription(), "Drivers Review Page Description");
        fsa.assertAll();
    }

    public void validateDisplayedCheckboxes(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String stateCode = applicant.getStateCode();
        if (stateCode.equals(CA)) {
            // CA has a separate test case for this check
            return;
        }
        String expectedSafetyCourseSubtext = stateCode.equals(KS) ? KS_DEFENSIVE_DRIVER_COURSE_SUBHEADER_TEXT : SPECIAL_DEFENSIVE_DRIVER_SUBHEADER_TEXT;
        //validate safety course checkboxes for KS state, as it is different from previously added states
        if (stateCode.equals(KS)) {
            List<WebElement> safetyCheckboxesSubTexts = getDriverSafetyCourseSubTextWebElements();
            for (WebElement safetyCheckboxesSubText : safetyCheckboxesSubTexts) {
                fsa.assertEquals(getTextFromElement(safetyCheckboxesSubText), expectedSafetyCourseSubtext, "Safety course subtext verification");
            }
        }
        // validate marital checkbox subtext
    	int numberOfElements = maritalCheckboxSubtexts.size();
        for (int i = 0; i< numberOfElements; i++) {
            fsa.assertEquals(getTextFromElement(maritalCheckboxSubtexts.get(i)), "Check to add your spouse or partner (do not check if you are separated, widowed, or divorced)", "Marital subtext verification "+ (i+1));
        }

        int applicantAge = applicant.getAge();
        String applicantFullName = getApplicantFullName(applicant);
        List<String> expectedMiddleAgePniOrSniCheckboxes = DriverReviewPageCheckboxes.getMiddleAgePniOrSniCheckboxes(applicant.getStateName());
        Map<String, Integer> pniSni = new HashMap<>();
        pniSni.put(applicantFullName, applicantAge);
        boolean isMarried = applicant.getMaritalStatus().equals(MARRIED);
        if (isMarried) {
            SqlAdditionalDriver sni = getSni(applicant);
            String sniFullName = getSniFullName(applicant);
            int sniAge = sni.getAge();
            pniSni.put(sniFullName, sniAge);
            setMaritalRelationship(applicantFullName, sniFullName);
        }
        int count = 0;
        for (String s : pniSni.keySet()) {
            int age = pniSni.get(s);
            List<String> actualCheckboxes = getCheckboxesTextsForGivenDriver(s);
            boolean isActiveMilitaryExpected = s.equals(applicantFullName) && stateCode.equals(LA);
            final String activeMilitaryDuty = "On active military duty";
			if (age > MAX_YOUNG_AGE && age < MIN_OLD_AGE_ONE_UI && !stateCode.equals(KS)) {
                if (isActiveMilitaryExpected) {
                    expectedMiddleAgePniOrSniCheckboxes.add(activeMilitaryDuty);
                } else {
                    expectedMiddleAgePniOrSniCheckboxes.remove(activeMilitaryDuty);
                }
                fsa.assertEquals(actualCheckboxes, expectedMiddleAgePniOrSniCheckboxes, "expectedMiddleAgePniOrSniCheckboxes verification");
            }
            if (isSafetyCourseExpected(applicant, age) && !stateCode.equals(KS)) {
                List<String> expectedValues = DriverReviewPageCheckboxes.getOldAgePniOrSniCheckboxes(applicant.getStateName());
                if (isActiveMilitaryExpected) {
                    expectedValues.add(activeMilitaryDuty);
                } else {
                    expectedValues.remove(activeMilitaryDuty);
                }
                fsa.assertEquals(actualCheckboxes, expectedValues, "Displayed checkboxes verification");
                String safetyCourseXpath = getDriverCardXpathByFullName(s) + SAFETY_COURSE_SUBTEXT_XPATH_END;
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(driver().findElement(By.xpath(safetyCourseXpath)))), expectedSafetyCourseSubtext, "Expected safety course subtext for " + s);
            }
            if (age <= MAX_YOUNG_AGE) {
                List<String> youngAgePniOrSniCheckboxes = DriverReviewPageCheckboxes.getYoungAgePniOrSniCheckboxes(applicant.getStateName());
                if (isActiveMilitaryExpected) {
                    youngAgePniOrSniCheckboxes.add(activeMilitaryDuty);
                } else {
                    youngAgePniOrSniCheckboxes.remove(activeMilitaryDuty);
                }
                if (isCheckboxSelected(getMaritalCheckbox(getApplicantFullName(applicant))) && count == 0) {
                    youngAgePniOrSniCheckboxes.remove(DriverReviewPageCheckboxes.STUDENT.getCheckBoxText());
                }
                fsa.assertEquals(actualCheckboxes, youngAgePniOrSniCheckboxes, "youngAgePniOrSniCheckboxes verification");
            }
            if (isMarried && count == 1) {
                removeMaritalRelation(getMaritalCheckbox(applicantFullName));
            }
            count++;
            validateCheckboxesForGivenDriver(applicant, s);
        }
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        int additionalDriversSize = Math.min(MAX_NUMBER_OF_ADDITIONALDRIVERS, additionalDrivers.size());
        for (int i = 0; i < additionalDriversSize; i++) {
            SqlAdditionalDriver currentDriver = additionalDrivers.get(i);
            if (currentDriver.getMaritalStatus().equals(MARRIED)) {
                continue;
            }
            String currentDriverName = getDriverFullName(currentDriver);
            String safetyCourseXpath = getDriverCardXpathByFullName(currentDriverName) + SAFETY_COURSE_SUBTEXT_XPATH_END;

            int driverAge = currentDriver.getAge();
            List<String> checkboxes = getCheckboxesTextsForGivenDriver(currentDriverName);
            validateCheckboxesForGivenDriver(applicant, currentDriverName);
            if (driverAge <= MAX_YOUNG_AGE && !currentDriver.getMaritalStatus().equals(MARRIED)) {
                boolean isPniOrSniOver30 = (applicant.getAge() >= MIN_DISTANT_STUDENT_PARENT_AGE) || (isMarried && getSni(applicant).getAge() >= MIN_DISTANT_STUDENT_PARENT_AGE);
                List<String> expectedStudentCheckboxes = DriverReviewPageCheckboxes.getStudentAdditionalDriverCheckboxes(applicant.getStateName());
                fsa.assertEquals(checkboxes, expectedStudentCheckboxes, "expectedStudentCheckboxes verification");
                waitAndClickElement(getFullTimeStudentCheckbox(currentDriverName));
                waitElementBeVisible(studentDiscountCheckboxLabels.get(0));
                List<String> actualStudentDiscountCheckboxes = studentDiscountCheckboxLabels.stream().map(this::getTextFromElement).collect(Collectors.toList());
                List<String> expectedStudentDiscountCheckboxes = DriverReviewPageCheckboxes.getStudentDiscountCheckboxes(applicant, isPniOrSniOver30);
                fsa.assertEquals(actualStudentDiscountCheckboxes, expectedStudentDiscountCheckboxes, "expectedStudentDiscountCheckboxes verification");
            } else if (driverAge >= MIN_OLD_AGE_ONE_UI) {
                List<String> expectedOldAgeAdditionalDriverCheckboxes = DriverReviewPageCheckboxes.getOldAgeAdditionalDriverCheckboxes(applicant.getStateName());
                if (!isSafetyCourseExpected(applicant, driverAge)) {
                    expectedOldAgeAdditionalDriverCheckboxes.remove(DriverReviewPageCheckboxes.SAFETY_COURSE.getCheckBoxText());
                } else {
                    if (!stateCode.equals(LA)) {
                        fsa.assertEquals(getTextFromElement(waitElementBeVisible(driver().findElement(By.xpath(safetyCourseXpath)))), expectedSafetyCourseSubtext, "Safety course subtext for " + currentDriverName);
                    }
                }
                fsa.assertEquals(checkboxes, expectedOldAgeAdditionalDriverCheckboxes, "xpectedOldAgeAdditionalDriverCheckboxes verification ");
            } else if (driverAge > MAX_YOUNG_AGE && driverAge < MIN_OLD_AGE_ONE_UI) {
                List<String> expectedMiddleAgeAdditionalDriverCheckboxes = DriverReviewPageCheckboxes.getMiddleAgeAdditionalDriverCheckboxes(applicant.getStateName());
                fsa.assertEquals(checkboxes, expectedMiddleAgeAdditionalDriverCheckboxes, "expectedMiddleAgeAdditionalDriverCheckboxes verification");

            } else {
                List<String> expectedYoungAgeAdditionalDriverCheckboxes = DriverReviewPageCheckboxes.getYoungAgeAdditionalDriverCheckboxes(applicant.getStateName());
                fsa.assertEquals(checkboxes, expectedYoungAgeAdditionalDriverCheckboxes, "expectedYoungAgeAdditionalDriverCheckboxes verification");
            }
        }

    }

    public void validateSaveAndBundleModal(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {

        fsa.assertTrue(validateSaveBundleCard(), "Save Bundle Card validation");
        fsa.assertTrue(validateSaveBundleInfoIcon(), "Save Bundle Info Icon validation");

        scrollAndClickOnElement(bundleLink);
        //validate bundle modal header
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleModalHeader)), "Bundle and Save", "bundleModalHeader verification");
        sleep(1);
        String selectedBundleItem = isHomeowner(applicant) ? "Home" : "Renters";
        WebElement bundleItem = driver().findElement(By.xpath(String.format("//mat-checkbox[contains(.,'%s')]//input", selectedBundleItem)));
        scrollAndClickOnElement(bundleItem);
        fsa.assertTrue(isCheckboxSelected(bundleItem), "Bundle save checkbox selection");

        fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleCongratsMessage)), "Nice! You are eligible for a discount when you bundle", "bundleCongratsMessage verification");

        scrollAndClickOnElement(waitElementBeVisible(saveAndBundleAddButton));
        fsa.assertTrue(isDiscountPresentInTheSideSheet("Bundled savings"), "Additional Discounts should contain 'Bundled savings'");

        final String EXPECTED_BUNDLE_TEXT = "Farmers bundle and save discount";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleCheckboxLabel)), EXPECTED_BUNDLE_TEXT, "bundleCheckboxLabel verification");
        fsa.assertEquals(getTextFromElement(saveBundleSelectedItem), selectedBundleItem, "Selected Save Bundle Item");

        waitAndClickElement(addEditAdditionalPolicies);
        waitAndClickElement(bundleDialogueCloseIcon);
        fsa.assertTrue(validateRemoveBundle(), "Validate remove Bundle failed");
        List<String> expectedBundleItems = FfqBundleOptions.getBundleOptions(applicant, isHomeowner(applicant));
        scrollAndClickOnElement(bundleLink);
        sleep(1);
        scrollAndClickOnElement(saveAndBundleAddButton);
        sleep(1);
        //validate bundle modal error message
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(saveBundleErrorMessage)), "Please select a product to be eligible for discount.", "saveBundleErrorMessage verification");
        //validate save bundle Cancel and Add buttons texts
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(saveAndBundleAddButton)), "Add", "saveAndBundleAddButton verification");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleCancelLink)), "Cancel", "bundleCancelLink verification");
        List<String> actualBundleItemsBeforeRefreshed = saveBundleItems.stream().map(this::getTextFromElement).collect(Collectors.toList());
        // validate bundle checkboxes texts are expected
        if (!Property.getDriver().equals("safari")) {
            fsa.assertEquals(actualBundleItemsBeforeRefreshed, expectedBundleItems, "Validate bundle checkboxes texts");
        }
        fsa.assertTrue(bundleCancelLink.isEnabled(), "Bundle Dialog cancel link enabled");
        scrollAndClickOnElement(waitElementBeVisible(bundleDialogueCloseIcon));
    }

    private boolean validateRemoveBundle() {
        boolean validated = true;
        final String REMOVE_BUNDLE_HEADER = "Remove bundle?";
        final String REMOVE_BUNDLE_CONTENT = "Are you sure you want to remove the Farmers Bundle and Save Discounts.";
        final String KEEP_IT = "Keep it";
        final String REMOVE_BUNDLE = "Remove bundle";
        waitAndClickElement(bundleCheckbox);
        validated &= testExpectedTextContentForElement(waitElementBeVisible(removeBundleHeader), REMOVE_BUNDLE_HEADER);
        validated &= testExpectedTextContentForElement(waitElementBeVisible(removeBundleContent), REMOVE_BUNDLE_CONTENT);
        validated &= testExpectedTextContentForElement(waitElementBeVisible(removeBundleKeepItButton), KEEP_IT);
        validated &= testExpectedTextContentForElement(waitElementBeVisible(removeBundleButton), REMOVE_BUNDLE);
        waitAndClickElement(removeBundleKeepItButton);
        removeSaveBundle();
        return validated;
    }

    public void removeSaveBundle() {
        waitAndClickElement(bundleCheckbox);
        waitAndClickElement(removeBundleButton);
    }

    private boolean validateSaveBundleCard() {

        boolean validated = true;
        final String EXPECTED_HEADER = "Save more when you bundle";
        final String EXPECTED_CONTENT = "Save money by bundling your Farmers Auto policy with another qualifying Farmers product.";
        final String EXPECTED_LINK_TEXT = "+ Add additional Farmers products (optional)";

        validated &= testExpectedTextContentForElement(bundleCardHeader, EXPECTED_HEADER);
        validated &= testExpectedTextContentForElement(bundleCardContent, EXPECTED_CONTENT);
        validated &= testExpectedTextContentForElement(bundleLinkText, EXPECTED_LINK_TEXT);
        return validated;
    }

    private boolean validateSaveBundleInfoIcon() {

        boolean validated = true;
        final String EXPECTED_HEADER = "How it works";
        final String EXPECTED_CONTENT = "A bundle discount will be applied to your auto quote today. You will have 45 days to purchase the policies you select to retain the discount. A Farmers agent will reach out to you to help you through the process.";
        validated &= testExpectedTextContentForElement(bundleInfoHeader, EXPECTED_HEADER);
        validated &= testExpectedTextContentForElement(bundleInfoContent, EXPECTED_CONTENT);
        return validated;
    }

    public boolean validateGoingBackToADPFScreen() throws Exception {
        boolean validationResult = true;
        waitElementBeVisible(driversRevisionHyperlink);
        validationResult &= getTextFromElement(driversRevisionHyperlink).contains(REVISE_WHICH_DRIVERS_TO_INCLUDE_LINK);
        waitAndClickElement(driversRevisionHyperlink);
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        validationResult &= whoShouldWeInsurePage.isOnWhoShouldWeInsurePage() || new HeresWhatWeFoundPage().isOnHeresWhatWeFoundPage();
        return validationResult;
    }

    public void validateDriversAges(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        isOnDriverReviewPage();

        String applicantFullName = getApplicantFullName(applicant);

        int applicantAge = applicant.getAge();
        WebElement ageWebElement = waitElementBeVisible(driver().findElement(By.xpath(getDriverCardXpathByFullName(applicantFullName) + DRIVER_AGE_XPATH_END)));
        fsa.assertEquals(getTextFromElement(ageWebElement), "Age " + applicantAge, "Applicant age element verification");
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        int additionalDriversSize = Math.min(additionalDrivers.size(), MAX_NUMBER_OF_ADDITIONALDRIVERS);
        for (int i = 0; i < additionalDriversSize; i++) {
            SqlAdditionalDriver currentDriver = additionalDrivers.get(i);
            String driverFullName = getDriverFullName(currentDriver);
            int driverAge = currentDriver.getAge();
            WebElement driverAgeElement = waitElementBeVisible(driver().findElement(By.xpath(getDriverCardXpathByFullName(driverFullName) + DRIVER_AGE_XPATH_END)));
            fsa.assertEquals(getTextFromElement(driverAgeElement), "Age " + driverAge, "Additional driver age element verification");
        }
    }

    public void validateInfoBoxes(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String additionalDriverContent = "Drivers have the same coverage, but limited access to your insurance account. They can get ID cards, pay bills and get insurance documents. But they cannot make any changes to your coverage.";
        String additionalDriverHeader = "Additional driver(s)";
        String pniContent = "The applicant and main point of contact for the insurance policy. They will be responsible for signing all documents upon purchase.";
        String pniHeader = "Primary named insured";
        String sniContent = "The spouse or domestic partner of the applicant will be added as a \"secondary named insured\" and will have the same rights to sign documents and make changes to the policy.";
        String sniHeader = "Secondary named insured";
        String pniFullName = getApplicantFullName(applicant);
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        int additionalDriversSize = Math.min(MAX_NUMBER_OF_ADDITIONALDRIVERS, additionalDrivers.size());
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(pniInfoIcon);
            validateInfoDialogMobileView(pniHeader, pniContent, fsa);
            if (!additionalDrivers.isEmpty()) {
                for (int i = 0; i < additionalDriversSize; i++) {
                    SqlAdditionalDriver additionalDriver = additionalDrivers.get(i);
                    String additionalDriverFullName = getDriverFullName(additionalDriver);
                    if (additionalDriver.getMaritalStatus().equals(MARRIED)) {
                        setMaritalRelationship(pniFullName, additionalDriverFullName);
                        waitAndClickElement(sniInfoIcon);
                        validateInfoDialogMobileView(sniHeader, sniContent, fsa);
                        removeMaritalRelation(getMaritalCheckbox(pniFullName));
                    } else {
                        waitAndClickElement(additionalDriverInfoIcon);
                        validateInfoDialogMobileView(additionalDriverHeader, additionalDriverContent, fsa);
                    }
                }
            }
        } else {
            validateDriverInfoNonMobileView(pniFullName, pniHeader, pniContent, fsa);
            if (!additionalDrivers.isEmpty()) {
                for (int i = 0; i < additionalDriversSize; i++) {
                    SqlAdditionalDriver additionalDriver = additionalDrivers.get(i);
                    String additionalDriverFullName = getDriverFullName(additionalDriver);
                    if (additionalDriver.getMaritalStatus().equals(MARRIED)) {
                        setMaritalRelationship(pniFullName, additionalDriverFullName);
                        validateDriverInfoNonMobileView(additionalDriverFullName, sniHeader, sniContent, fsa);
                        removeMaritalRelation(getMaritalCheckbox(pniFullName));
                    } else {
                        validateDriverInfoNonMobileView(additionalDriverFullName, additionalDriverHeader, additionalDriverContent, fsa);
                    }
                }
            }
        }

    }

    private void validateDriverInfoNonMobileView(String fullName, String expectedHeader, String expectedContent, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(getInfoHeader(fullName))), expectedHeader, "Browser Info Helper Header");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(getInfoContent(fullName))), expectedContent, "Browser Info Helper Content");
    }

    private WebElement getInfoHeader(String fullName) throws Exception {
        String infoBoxHeaderXpath = "//div[contains(@class, 'auto-driver-review-info-icon-container')]//p[contains(@class, 'tui-info-box-header')]";
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + infoBoxHeaderXpath));
    }

    private WebElement getInfoContent(String fullName) throws Exception {
        String infoBoxContentXpath = "//div[contains(@class, 'auto-driver-review-info-icon-container')]//p[contains(@class, 'tui-info-box-content')]";
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + infoBoxContentXpath));
    }

    private void validateInfoDialogMobileView(String expectedHeader, String expectedContent, FarmersSoftAssert fsa) throws Exception {
        waitElementBeVisible(infoBoxHeader);
        waitElementBeVisible(infoBoxContent);
        fsa.assertEquals(getTextFromElement(infoBoxHeader), expectedHeader, "Mobile view Help Info Header");
        fsa.assertEquals(getTextFromElement(infoBoxContent), expectedContent, "Mobile view Help Info Content");
        clickOnHiddenElement(infoBoxCloseButton);
    }

    public SqlAdditionalDriver getSni(AutoApplicant applicant) {
        return applicant.getAdditionalDrivers().stream().filter(driver -> driver.getRelationshipToApplicant().equals(SPOUSE)).findFirst().get();
    }

    private String getSniFullName(AutoApplicant applicant) {
        SqlAdditionalDriver sni = getSni(applicant);
        return getDriverFullName(sni);
    }

    public void validateEditDriverSections(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        WebElement applicantEditDriverButton = driver().findElement(By.xpath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + EDIT_DRIVER_BUTTON_XPATH));
        String stateCode = applicant.getStateCode();
        validateEditDriverSection(applicantEditDriverButton, fsa, true, stateCode);
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        for (int i = 0; i < Math.min(additionalDrivers.size(), MAX_NUMBER_OF_ADDITIONALDRIVERS); i++) {
            SqlAdditionalDriver sqlAdditionalDriver = additionalDrivers.get(i);
            WebElement driverEditButton = driver().findElement(By.xpath(getDriverCardXpathByFullName(getDriverFullName(sqlAdditionalDriver)) + EDIT_DRIVER_BUTTON_XPATH));
            validateEditDriverSection(driverEditButton, fsa, false, stateCode);
        }
    }

    public void clickEditDriverButton(String fullName) throws Exception {
        waitAndClickElement(getEditDriverButton(fullName));
    }

    public WebElement getEditDriverButton(String fullName) throws Exception {
       return driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + EDIT_DRIVER_BUTTON_XPATH));
    }

    private void validateEditDriverSection(WebElement editButton, FarmersSoftAssert fsa, Boolean isApplicant, String stateCode) throws Exception {
        scrollElementToMiddle(editButton);
        waitAndClickElement(editButton);
        waitElementBeVisible(editDriverDialog);
        fsa.assertEquals(getTextFromElement(addDriverHeading), "Edit driver", "Edit driver dialog header");

        // validate gender selection toggles
        List<String> expectedGenderSelections = new ArrayList<>(Arrays.asList("Male", "Female"));
        List<WebElement> genderToggleLabels = driver().findElements(By.xpath("//div[contains(@class,'auto-add-driver-gender')]//span[@class='mat-button-toggle-label-content']"));
        List<String> genderLabelsActualTexts = genderToggleLabels.stream().map(this::getTextFromElement).collect(Collectors.toList());
        if (isNonBinaryGenderDisplayExpected(stateCode)) {
            expectedGenderSelections.add("Nonbinary");
        }
        if (stateCode.equals(CA)) {
            expectedGenderSelections.add("Not Specified");
        }
        Collections.sort(genderLabelsActualTexts);
        Collections.sort(expectedGenderSelections);
        fsa.assertEquals(genderLabelsActualTexts, expectedGenderSelections, "genderLabels verification");

        fsa.assertEquals(getTextFromElement(driverLicenseQuestionLabel), "Is this driver's license issued by a U.S. state, U.S. territory, or Canadian province?", "Driver License question text should be as expected");

        fsa.assertTrue(isElementPresent(By.xpath("//div[contains(@id,'formField_licenseIssued')]")), "Driver’s license question should be visible for both applicant and additional drivers");

        if (isApplicant) {
            fsa.assertTrue(isElementPresent(By.xpath("//div[@id='currentlyInsured']")), "Currently insured question should be visible for applicant");
            fsa.assertEquals(getTextFromElement(currentlyInsuredQuestionLabel), "Are you currently insured?", "Currently insured question label text");
        }
        fsa.assertEquals(getTextFromElement(saveChangesButton), "Save Changes", "Save changes button label text");
        fsa.assertEquals(getTextFromElement(editDriverCancelButton), "Cancel", "Cancel button label text");
        clickOnHiddenElement(editDriverCancelButton);

    }

    public boolean isEditDriverSideSheetOpen() {
        return isElementVisible(addDriverHeading, 1);
    }

    public boolean isOccupationSideSheetOpen() {
        return isElementVisible(eligibleOccupationModalHeader, 1);
    }

    public boolean validateMaritalToSomeoneNotListed(AutoApplicant applicant, boolean foreignDl) throws Exception {
        boolean validationResult = true;
        WebElement maritalCheckbox = getMaritalCheckbox(getApplicantFullName(applicant));
        scrollAndClickOnElement(maritalCheckbox);
        clickOnSpouseToIfExist(applicant);
        validateAddSpouseModalContent();
        validationResult &= validateDriverModalErrorMessages();
        enterSpouseInformation(applicant, true, foreignDl);
        waitForSpinnerToBeGone();
        AppStore.Auto.Driver sni = getSessionStorageAppStore().getAuto().getDrivers().stream().filter(each -> each.getPni().equals("X")).collect(Collectors.toList()).get(0);
        String sniFullName = sni.getFirstName() + SPACE + sni.getLastName();
        // validate marital checkbox is disabled for newly added sni
        validationResult &= isMaritalCheckboxDisabled(sniFullName);
        return validationResult;
    }

    private void validateAddSpouseModalContent() throws Exception {
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();

        if (!landingStateCode.equals(CA)) {
            if(Arrays.asList(TX, MI, IL, AZ, PA, WA, OR, OH, MO, OK).contains(landingStateCode)) {
                String xpathForDrivingVehicle = String.format(SPOUSE_DRIVING_VEHICLE_XPATH, YES);
                waitAndClickElement(driver().findElement(By.xpath(xpathForDrivingVehicle)));
                sleep(1);
            }
            WebElement licenseQuestion = driver().findElement(By.id("formField_label_licenseIssued"));
            testExpectedTextContentForElement(licenseQuestion, "Is this driver's license issued by a U.S. state, U.S. territory, or Canadian province?");
        }
        testExpectedTextContentForElement(addDriverHeading, "Add a spouse");
        // These are not text labels, they are field identifying texts inside the fields
        Assert.assertEquals(getTextFromElement(driver().findElement(By.xpath("//mat-form-field[contains(.,'First name')]//div[contains(@class,'text-field')]"))), "First name", "First name field label should be as expected");
        Assert.assertEquals(getTextFromElement(driver().findElement(By.xpath("//mat-form-field[contains(.,'Last name')]//div[contains(@class,'text-field')]"))), "Last name", "Last name field label should be as expected");
        Assert.assertEquals(getTextFromElement(driver().findElement(By.xpath("//mat-form-field[contains(.,'Date of birth')]//div[contains(@class,'text-field')]"))), "Date of birth", "Last name field label should be as expected");
        testExpectedTextContentForElement(listOfSaveButtons.get(0), "Save");
    }

    private boolean validateDriverModalErrorMessages() throws Exception {
        boolean validated = true;
        String pleaseProvideYour = "Please provide your ";
        String thisIsRequired = "This is required.";
        String formIncomplete = "One or more required fields are incomplete or incorrect. Please review.";
        waitElementBeVisible(addDriverHeading);
        for (WebElement firstNameField : listOfFirstNameFields) {
            waitAndClickElement(firstNameField);
        }
        for (WebElement saveButton : listOfSaveButtons) {
            waitAndClickElement(saveButton);
        }
        validated &= testExpectedTextContentForElement(waitElementBeVisible(firstNameErrorMessage), pleaseProvideYour + "first name.");
        validated &= testExpectedTextContentForElement(waitElementBeVisible(lastNameErrorMessage), pleaseProvideYour + "last name.");
        validated &= testExpectedTextContentForElement(waitElementBeVisible(dateOfBirthErrorMessage), pleaseProvideYour + "date of birth.");
        validated &= testExpectedTextContentForElement(waitElementBeVisible(genderErrorMessage), thisIsRequired);

        int index = 0;
        if(Arrays.asList(AZ, IL, TX, MI, PA, WA, OR, OH, MO, OK).contains(getSessionStorageAppStore().getData().getLandingStateCode())) {
            index = 1;
        }
        validated &= testExpectedTextContentForElement(waitElementBeVisible(licenseIssuedErrorMessages.get(index)), thisIsRequired);
        validated &= testExpectedTextContentForElement(waitElementBeVisible(editDriverModalErrorMessage), formIncomplete);
        return validated;
    }

    public void setMaritalRelationToSomeOneNotListed(AutoApplicant applicant, boolean willBeDriving, boolean foreignDl) throws Exception {
        clickElement(getMaritalCheckbox(getApplicantFullName(applicant)));
        clickOnSpouseToIfExist(applicant);
        enterSpouseInformation(applicant, willBeDriving, foreignDl);
        waitForSpinnerToBeGone();
    }

    private void clickOnSpouseToIfExist(AutoApplicant applicant) throws Exception {
        if (!applicant.getAdditionalDrivers().isEmpty()) {
            getAndClickSpouseTo("someone not listed here");
        }
    }

    private void enterSpouseInformation(AutoApplicant applicant, boolean willBeDriving, boolean foreignDl) throws Exception {
        waitElementBeVisible(addDriverHeading);
        for (WebElement firstNameField : driver().findElements(By.xpath("//mat-form-field[contains(.,'First name')]//input"))) {
            sendKeysToElement(firstNameField, new Faker().name().firstName());
        }
        for (WebElement lastNameField : driver().findElements(By.xpath("//mat-form-field[contains(.,'Last name')]//input"))) {
            sendKeysToElement(lastNameField, applicant.getLastName());
        }
        for (WebElement dateOfBirthField : driver().findElements(By.xpath("//mat-form-field[contains(.,'Date of birth')]//input"))) {
            sendKeysToElement(dateOfBirthField, "01/01/1990");
        }
        for (WebElement femaleGenderButton : listOfFemaleGenderButtons) {
            clickElement(femaleGenderButton);
        }

        String willBeDrivingToggle = willBeDriving ? YES : NO;
        String xpathForDrivingVehicle = String.format(SPOUSE_DRIVING_VEHICLE_XPATH, willBeDrivingToggle);
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();

        if (Arrays.asList(CA, AZ, IL, TX, MI, PA, WA, OR, OH, MO, OK).contains(landingStateCode)) {
            waitAndClickElement(driver().findElement(By.xpath(xpathForDrivingVehicle)));
        }

        if (willBeDrivingToggle.equals(YES)) {
            String US_CA_Dl_RadioButtons_xpath = foreignDl ? NO : YES;
            waitAndClickElement(driver().findElement(By.xpath(String.format(DIALOG_LICENSED_IN_USA_RADIO_BUTTONS_XPATH, US_CA_Dl_RadioButtons_xpath))));
        }

        for (WebElement saveButton : listOfSaveButtons) {
            waitAndClickElement(saveButton);
        }
        if (isElementVisible(editDriverDialogCloseLink, 1)) {
            clickElement(editDriverDialogCloseLink);
        }

    }

    private void getAndClickSpouseTo(String spouse) throws Exception {
        WebElement someoneNotListedHere = getSpouseToButton(spouse).get(0);
        scrollAndClickOnElement(someoneNotListedHere);
    }

    private boolean isMaritalCheckboxDisabled(String sniFullName) throws Exception {
        return getAttributeData(waitElementBeVisible(driver().findElement(By.xpath(getDriverCardXpathByFullName(sniFullName) + MARITAL_CHECKBOX_XPATH))), CLASS).contains(DISABLED);
    }

    public void validateMaritalRelationRemoval(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        final String MARITAL_REMOVAL_HEADER = "Change Status?";
        final String MARITAL_REMOVAL_CONTENT = "This driver is currently selected as the spouse to other driver. Unchecking this option will remove the status for both drivers.";
        if (applicant.getMaritalStatus().equals(MARRIED)) {
            String pniFullName = getApplicantFullName(applicant);
            setMaritalRelationship(pniFullName, getSniFullName(applicant));
            WebElement pniMaritalCheckbox = getMaritalCheckbox(pniFullName);
            clickElement(pniMaritalCheckbox);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(changeStatusHeading)), MARITAL_REMOVAL_HEADER, "Change status header");
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(changeStatusContent)), MARITAL_REMOVAL_CONTENT, "Change status text check");
            waitAndClickElement(keepAsIsButton);
            removeMaritalRelation(pniMaritalCheckbox);
        }
    }

    private boolean removeMaritalRelation(WebElement pniMaritalCheckbox) {
        boolean passed = true;
        clickElement(pniMaritalCheckbox);
        clickElement(removeStatusButton);
        wait.until(ExpectedConditions.invisibilityOfElementWithText(By.xpath(REMOVE_STATUS_XPATH), "Remove Status"));
        passed &= !isCheckboxSelected(pniMaritalCheckbox);
        return passed;
    }

    public void validateValidateAccidentCheckbox(FarmersSoftAssert fsa) throws Exception {
    	int numberOfElements = accidentCheckboxes.size();
        for (int i = 0; i < numberOfElements; i++){
            // validate marital checkboxes are clickable
            WebElement accidentQuestion = driver().findElement(By.xpath(String.format("//div[@id='ordered-field-placeholder_hadAccidentOrViolation_%s']//input", i + 1)));
            scrollAndClickOnHiddenElement(accidentQuestion);
            fsa.assertTrue(accidentQuestion.isSelected(), "Accident checkbox is selected");
            if (!accidentQuestion.isSelected()) {
                scrollAndClickOnHiddenElement(accidentQuestion);
            }
            // validate texts of checkbox
            boolean isCaState = getSessionStorageAppStore().getData().getLandingStateCode().equals(CA);
            String years = isCaState ? "10" : "5";
            fsa.assertEquals(getTextFromElement(accidentQuestions.get(i)), "Had an accident or violation in last " + years + " years", "Accident checkbox label validation");
            //validate subtexts of checkbox
            fsa.assertEquals(getTextFromElement(accidentSubTexts.get(i)), "At fault or no fault accident or moving violations only", "Accident checkbox subtext label validation");
            if (i == 0) {
                validateIncidentErrorMessages(fsa);
            }
            accidentQuestion = driver().findElement((By.xpath(String.format("//div[@id='ordered-field-placeholder_hadAccidentOrViolation_%s']//input[contains(@class,'mdc-checkbox--selected')]", i + 1))));
            scrollElementToMiddle(accidentQuestion);
            clickElement(accidentQuestion);
        }
    }

    private void validateIncidentErrorMessages(FarmersSoftAssert fsa) throws Exception {
        String pleaseProvide = "Please provide ";
        waitAndClickElement(continueButton);
        waitForSpinnerToBeGone();
        fsa.assertTrue(testExpectedTextContentForElement(getIncidentFormErrorWithIndex(1), pleaseProvide + "accident type"), "Accident type error message for no input");
        fsa.assertTrue(testExpectedTextContentForElement(getIncidentFormErrorWithIndex(2), pleaseProvide + "date of accident"), "Date of accident error message for no input");
        driver().navigate().refresh();
        isOnDriverReviewPage();
        AppStore.Data.CustomerData customerData = getSessionStorageAppStore().getData().getCustomerData();
        String fullName = customerData.getFirstName() + SPACE + customerData.getLastName();
        clickElement(getAccidentAndViolationCheckbox(fullName));
        sleep(1);
        WebElement violationToggle = driver().findElement(By.xpath(VIOLATION_TOGGLE_XPATH));
        scrollAndClickOnHiddenElement(waitElementBeVisible(violationToggle));
        fsa.assertTrue(isButtonSelected(violationToggle), "Violation toggle press was successful");
        waitAndClickElement(continueButton);
        fsa.assertTrue(testExpectedTextContentForElement(getIncidentFormErrorWithIndex(1), pleaseProvide + "violation type"), "Violation type error message for no input");
        fsa.assertTrue(testExpectedTextContentForElement(getIncidentFormErrorWithIndex(2), pleaseProvide + "date of violation"), "Date of violation no input error messsage");
        scrollElementToMiddle(ctaErrorMessage);
    }

    private WebElement getIncidentFormErrorWithIndex(int index) throws Exception {
        String indexString = String.valueOf(index);
        String xpath = String.format("//app-incident//mat-form-field[%s]//mat-error", indexString);
        return waitElementBeVisible(driver().findElement(By.xpath(xpath)));
    }

    public void validateHadTheirDriverLicenseAgeCondition(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {

        if (isAskingDriverLicenseAgeState(applicant.getStateCode())) {
            return;
        }

        String applicantFullName = getApplicantFullName(applicant);
        int applicantAge = applicant.getAge();
        if (applicantAge <= MAX_YOUNG_AGE) {
            fsa.assertTrue(isElementPresent(By.xpath(getDriverCardXpathByFullName(applicantFullName) + HAD_THEIR_DRIVER_LICENSE_CHECKBOX)), "Driver License question should be visible for applicant age " + applicantAge);
        }

        // validate upper and lower limit for age input field
        if (applicantAge - applicant.getFirstAgeUnitedStatesDriverLicense() < 3) {
            validateLimitsForAgeInputField(fsa, applicantFullName, applicantAge);
        }
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        int additionalDriversSize = Math.min(MAX_NUMBER_OF_ADDITIONALDRIVERS, additionalDrivers.size());
        for (int i = 0; i < additionalDriversSize; i++) {
            SqlAdditionalDriver currentDriver = additionalDrivers.get(i);
            String driverFullName = getDriverFullName(currentDriver);
            int currentDriverAge = currentDriver.getAge();

            if (currentDriver.getAge() <= MAX_YOUNG_AGE) {
                if (!isAskingDriverLicenseAgeState(applicant.getStateCode())) {
                    WebElement driverLicenseAgeCheckbox = driver().findElement(By.xpath(getDriverCardXpathByFullName(driverFullName) + "//mat-checkbox[@formcontrolname='hadDriveLicense']"));
                    scrollElementToMiddle(driverLicenseAgeCheckbox);
                    fsa.assertTrue(isElementVisible(driverLicenseAgeCheckbox, 2), "Driver License question should be visible for additional driver age and name " + currentDriver.getAge() + COMMA + SPACE + driverFullName);
                }
            }
            if (currentDriverAge - currentDriver.getFirstAgeUnitedStatesDriverLicense() < 3) {
                validateLimitsForAgeInputField(fsa, driverFullName, currentDriverAge);
            }
        }

    }

    private void validateLimitsForAgeInputField(FarmersSoftAssert fsa, String fullName, int age) throws Exception {
        WebElement driversLicenseCheckbox = getHadDriversLicenseCheckbox(fullName);
        waitAndClickElement(driversLicenseCheckbox);
        WebElement driverLicenceAgeInputField = getDriverLicenceAgeInputField(fullName);
        fsa.assertTrue(doesElementHaveFocus(driverLicenceAgeInputField), "Driver License Age input field should have focus when the checkbox is selected");
        driverLicenceAgeInputField.sendKeys("14" + Keys.TAB);
        sleep(1);
        String ageConditionError = getTextFromElement(getDriverLicenseAgeConditionError(fullName));
        fsa.assertTrue(isElementDisplayed(getDriverLicenseAgeConditionError(fullName), 1), "Driver License age condition error message should be displayed when input age is below minimum");
        fsa.assertTrue(ageConditionError.contains("Minimum age is 15"), "Driver License age condition error message should indicate minimum age requirement");
        driverLicenceAgeInputField.clear();
        driverLicenceAgeInputField.sendKeys("" + (age + 1));
        waitAndClickElement(minAgeSection);
        fsa.assertTrue(isElementDisplayed(getDriverLicenseAgeConditionError(fullName), 1), "Driver License age condition error message should be displayed when input age is above maximum");
        ageConditionError = getTextFromElement(getDriverLicenseAgeConditionError(fullName));
        fsa.assertTrue(ageConditionError.contains("Invalid age"), "Driver License age condition error message should indicate invalid age for above maximum input");
        waitAndClickElement(driversLicenseCheckbox);
    }

    public void validateOccupationSidePanel(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        if (isEmploymentDisabledState(applicant.getStateCode())) {
            fsa.assertTrue(!isElementPresent(seeEligibleOccupationList), "Eligible occupations not displayed");
        }
        List<WebElement> seeEligibleOccupationsLinks = driver().findElements(seeEligibleOccupationList);
    	int numberOfElements = seeEligibleOccupationsLinks.size();
        for (int i = 0; i< numberOfElements; i++){
            // link  text
            List<String> expectedLinkTexts = Arrays.asList("Let's find my occupation", "See eligible occupations", "Check for discount");
            String actualTitle = getTextFromElement(seeEligibleOccupationsLinks.get(i));
            fsa.assertTrue(expectedLinkTexts.contains(actualTitle), "Occupation link text validated");
            // validate occupation section title and subheader
            String occupationSectionHeader = getTextFromElement(occupationHeaders.get(i));
            List<String> expectedOccupationHeaders = Arrays.asList("Do you qualify for an Occupational Discount?", "Current or former employed professional (optional)", "You could save up to 15%");
            fsa.assertTrue(expectedOccupationHeaders.contains(occupationSectionHeader), "Occupation section header validated");

            String occupationSectionSubHeader = getTextFromElement(occupationSubtexts.get(i));
            List<String> expectedOccupationSubHeaders = Arrays.asList("If your occupation is on this list, you can qualify for additional savings", "Depending on your occupation, you may qualify for a discount.", "You may qualify for an occupational discount, even if this driver is retired");

            fsa.assertTrue(expectedOccupationSubHeaders.contains(occupationSectionSubHeader), "Occupation section sub header validated");
        }

        String expectedOccupationSidePanelHeader = "Eligible occupations";
        String expectedEmployedOrRetiredTitle = "Are you currently employed or retired?";

        if (isElementPresent(seeEligibleOccupationList)) {

            List<WebElement> seeEligibleOccupations = seeEligibleOccupationsLinks;
        	numberOfElements = seeEligibleOccupations.size();
            for (int i = 0; i< numberOfElements; i++){
                WebElement seeEligibleOccupationsForOneDriver = seeEligibleOccupations.get(i);
                scrollAndClickOnElement(seeEligibleOccupationsForOneDriver);
                if (!isElementVisible(eligibleOccupationModalHeader, 2)) {
                    waitAndClickElement(seeEligibleOccupationsForOneDriver);
                }
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(eligibleOccupationModalHeader)), expectedOccupationSidePanelHeader, "eligibleOccupationModalHeader verification");
                fsa.assertEquals(getTextFromElement(employedOrRetiredTitle), expectedEmployedOrRetiredTitle, "employedOrRetiredTitle verification");
                List<String> actualEmployedAndRetiredToggles = occupationsSidePanelToggles.stream().map(this::getTextFromElement).collect(Collectors.toList());
                List<String> expectedEmployedAndRetiredToggles = new ArrayList<>(Arrays.asList("Employed", "Retired"));
                fsa.assertEquals(actualEmployedAndRetiredToggles, expectedEmployedAndRetiredToggles, "Occupation Side Panel Employed Retired toggle labels");
                fsa.assertTrue(selectEligibleOccupationsTitle.isDisplayed(), "'Select from the list of eligible occupation(s). Verification of occupation will be required.' text should be available");
                fsa.assertEquals(getTextFromElement(discountUnavailableMessage), "If you don't see your occupation on the list, you may not be eligible for this discount.", "discountUnavailableMessage verification");
                scrollAndClickOnHiddenElement(closeOrSaveButtonOccupationSideSheet);
                sleep(1);
                fsa.assertTrue(!isElementDisplayed(By.xpath(OCCUPATION_SIDE_PANEL_HEADER_XPATH)), "Occupation side panel should be not be displayed after closing the side panel");
                // add occupation and validated it is selected
                waitForElements(SEE_ELIGIBLE_OCCUPATIONS_XPATH);
                waitAndClickElement(driver().findElements(By.xpath(SEE_ELIGIBLE_OCCUPATIONS_XPATH)).get(i));
                waitElementBeVisible(eligibleOccupationModalHeader);
                scrollAndClickOnElement(driver().findElement(By.xpath("//mat-radio-button[1]//input")));
                fsa.assertFalse(isElementDisplayed(By.xpath(DISCOUNT_UNAVAILABLE_MESSAGE_XPATH)), "\"If you don't see your occupation on the list, you may not be eligible for this discount.\" message should not be displayed after making selection");
                scrollAndClickOnElement(closeOrSaveButtonOccupationSideSheet);
                if (isElementPresent(By.xpath("//app-occupation-list//mat-error"), 1)) {
                    WebElement additionalRadioButtonSelection = driver().findElements(By.xpath("//mat-radio-button[not(contains(@class,'checked'))]//input")).get(0);
                    scrollAndClickOnElement(additionalRadioButtonSelection);
                    scrollAndClickOnElement(closeOrSaveButtonOccupationSideSheet);
                }
                fsa.assertTrue(waitElementBeVisible(occupationAddedConfirmation).isDisplayed(), "Occupation added confirmation successful");

                // validate remove functionality
                waitAndClickElement(removeOccupationButton);
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(removeOccupationPanelHeader)), "Remove occupation", "removeOccupationPanelHeader verification");
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(removeButton)), "Remove", "removeButton verification");
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(keepOccupation)), "Keep occupation", "keepOccupation verification");
                waitAndClickElement(keepOccupation);
                sleep(1);
                fsa.assertTrue(occupationAddedConfirmation.isDisplayed(), "After clicking on Keep occupation, occupation should not be removed");
                removeOccupation();
                fsa.assertTrue(!isElementDisplayed(By.xpath(OCCUPATION_ADDED_CONFIRMATION_XPATH)), "After removing occupation, occupation added confirmaiton should not be displayed");
            }
        }
    }

    private void removeOccupation() throws Exception {
        scrollAndClickOnElement(waitElementBeVisible(removeOccupationButton));
        scrollAndClickOnElement(waitElementBeVisible(removeButton));
        validateSnackbarAndDiscountFooterSection("remove", "Drivers-review Page");
    }

    private void validateSnackbarAndDiscountFooterSection(String discount, String pagename) throws Exception {
        isSnackBarMessageDisplayed(discount);
        reviewDiscountSection(pagename);
    }

    public void validateOccupation(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(employmentDiscountQualification), applicant.getOccupation().isBlank() ? OTHER : applicant.getOccupation(), "Applicant Occupation verification.");
    }

    public void validateMaritalStatus(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String applicantFullName = getApplicantFullName(applicant);
        if (applicant.getMaritalStatus().equals(MARRIED)) {
            fsa.assertTrue(isCheckboxSelected(getMaritalCheckbox(applicantFullName)), "PNI Marital checkbox is checked.");
            fsa.assertTrue(isMaritalCheckboxDisabled(applicantFullName), "PNI Marital checkbox is disabled.");
            fsa.assertTrue(isCheckboxSelected(getMaritalCheckbox(getDriverFullName(applicant.getAdditionalDrivers().get(0)))), "SNI Marital checkbox is checked.");
            fsa.assertTrue(isMaritalCheckboxDisabled(getDriverFullName(applicant.getAdditionalDrivers().get(0))), "SNI Marital checkbox is disabled.");
            fsa.assertTrue(getTextFromElement(driver().findElement(By.xpath(getDriverCardXpathByFullName(applicantFullName) + "//p[contains(@aria-label,'Spouse to')]"))).contains(getDriverFullName(applicant.getAdditionalDrivers().get(0))), "PNI Driver has reference to spouse.");
            fsa.assertTrue(getTextFromElement(driver().findElement(By.xpath(getDriverCardXpathByFullName(getDriverFullName(applicant.getAdditionalDrivers().get(0))) + "//p[contains(@aria-label,'Spouse to')]"))).contains(applicantFullName), "SNI Driver has reference to PNI.");
        } else {
            fsa.assertTrue(!isCheckboxSelected(getMaritalCheckbox(applicantFullName)), "PNI Marital checkbox is unchecked.");
            fsa.assertTrue(isMaritalCheckboxDisabled(applicantFullName), "PNI Marital checkbox disabled.");
        }
    }

    public boolean validateIncidentRemoval(AutoApplicant applicant) throws Exception {
        boolean passed = true;
        if (applicant.isHaveAccidentOrViolations() && applicant.getIncidents().stream().map(incident -> incident.getAdditionalDriverId() == 0).count() > 1) {
            String applicantFullName = getApplicantFullName(applicant);
            passed &= addIncidents(applicantFullName, applicant.getIncidents());
            int initialIncidentCount = getIncidentsAppsForGivenDriver(applicantFullName).size();
            // delete first incident
            sleep(1);
            waitAndClickElement(getIncidentRemovalElement(applicantFullName).get(0));
            int countOfIncidentsAfterRemoval = getIncidentsAppsForGivenDriver(applicantFullName).size();
            passed &= initialIncidentCount - countOfIncidentsAfterRemoval == 1;
        }
        return passed;
    }

    public boolean validateDriverReviewPageCTA(AutoApplicant applicant) throws Exception {
        return validateCTADescription();
    }

    private boolean validateCTADescription() throws Exception {
        boolean passed = true;
        String expectedCtaDescription = "Just one more step until your quote!";
        scrollToElement(ctaDescription);
        passed &= testExpectedTextContentForElement(ctaDescription, expectedCtaDescription);
        return passed;
    }

    public void clickContinueButton() throws Exception {
        scrollAndClickOnElement(continueButton);
        waitForSpinnerToBeGone();
        if (isElementVisible(continueButton, 3)) {
            scrollAndClickOnElement(continueButton);
            waitForSpinnerToBeGone();
        }
        longWaitForElementToBeGoneByID("auto-driver-review-cta-continue");
    }

    public boolean addSafetyCourse(String fullName) throws Exception {
        boolean passed = true;

        // based on the current status of the checkbox, we can return if it is already selected or not. If it is not selected, we will select it and validate if the selection was successful.
        if (isCheckboxChecked(getSafetyCourseCheckbox(fullName))) {
            Log.info("Safety course checkbox is already checked for: " + fullName);
            return passed;
        }

        WebElement safetyCourseCheckbox = getSafetyCourseCheckbox(fullName);
        scrollElementToMiddle(safetyCourseCheckbox);
        waitAndClickElement(safetyCourseCheckbox);
        passed &= wait.until(ExpectedConditions.attributeContains(safetyCourseCheckbox, CLASS, MDC_CHECKBOX_CHECKED));

        if (!passed) {
            Log.error("\n Safety course checkbox selection failed ");
        } else {
            Log.info("Safety course addition successful for: " + fullName);
        }
        return passed;
    }

    private boolean addIncidents(String fullName, List<SqlIncident> incidents) throws Exception {
        boolean passed = true;
        boolean isAdditionalIncident = false;
        for (int i = 0; i < incidents.size(); i++) {
            SqlIncident currentIncident = incidents.get(i);
            isAdditionalIncident = i > 0;
            String incidentType = currentIncident.getIncidentType();
            if (incidentType.equals(ACCIDENT)) {
                passed &= addAccident(fullName, currentIncident, isAdditionalIncident);
            } else if (incidentType.equals(CITATION)) {
                try {
                    passed &= addViolation(fullName, currentIncident, isAdditionalIncident);
                } catch (Exception e) {
                    Log.error(e.getMessage());
                    driver().navigate().refresh();
                    passed &= addViolation(fullName, currentIncident, isAdditionalIncident);
                }

            } else {
                Log.warn("Please check the incident type as it does not adhere to known incident types");
            }
        }
        return passed;
    }

    private boolean addAccident(String fullName, SqlIncident accident, boolean isAdditionalIncident) throws Exception {
        boolean accidentAdditionPassed = true;
        String driverForm = getDriverCardXpathByFullName(fullName);
        accidentAdditionPassed &= clickForAdditionalIncident(fullName, isAdditionalIncident);
        fillOutIncidentDetails(isAdditionalIncident, driverForm, accident);
        if (accident.isAnyInjuries()) {
            clickElement(getLocalInjuryButton());
        }
        if (!accidentAdditionPassed) {
            Log.error("\nAccident addition failed");
        }
        return accidentAdditionPassed;
    }

    private boolean addViolation(String fullName, SqlIncident violation, boolean isAdditionalIncident) throws Exception {
        boolean violationAdditionPassed = true;
        String driverForm = getDriverCardXpathByFullName(fullName);
        violationAdditionPassed &= clickForAdditionalIncident(fullName, isAdditionalIncident);
        String localViolationToggleXpath = isAdditionalIncident ? driverForm + ADDITIONAL_INCIDENT_FORM_XPATH + VIOLATION_TOGGLE_XPATH : driverForm + VIOLATION_TOGGLE_XPATH;
        WebElement violationToggle = driver().findElement(By.xpath(localViolationToggleXpath));
        scrollToElement(violationToggle);
        waitAndClickElement(violationToggle);
        violationAdditionPassed &= isButtonSelected(violationToggle);
        fillOutIncidentDetails(isAdditionalIncident, driverForm, violation);
        if (!violationAdditionPassed) {
            Log.error("\nViolation addition failed");
        }
        return violationAdditionPassed;
    }

    private boolean clickForAdditionalIncident(String fullName, boolean isAdditionalIncident) throws Exception {
        boolean passed = true;
        WebElement accidentOrViolationCheckbox;
        if (isAdditionalIncident) {
            scrollAndClickOnElement(waitElementBeVisible(getAddAnotherIncidentLink(fullName)));
        } else {
            accidentOrViolationCheckbox = getAccidentAndViolationCheckbox(fullName);
            clickElement(accidentOrViolationCheckbox);
            passed &= isCheckboxSelected(accidentOrViolationCheckbox);
        }
        return passed;
    }

    public void fillOutIncidentDetails(boolean isAdditionalIncident, String driverForm, SqlIncident incident) throws Exception {
        String localDropDownXpath = getLocalDropDownXpathForIncident(isAdditionalIncident);
        String localDateInputField = getLocalDateInputField(isAdditionalIncident);
        WebElement dateInputField = waitAndClickElement(driver().findElement(By.xpath(driverForm + localDateInputField)));
        if (doesElementHaveFocus(dateInputField)) {
            Log.info("Accident/Violation date input field has focus");
        } else {
            Log.error("Accident/Violation date input field does not have focus", true);
        }
        WebElement dropDown = null;
        // using loop and try/catch as this is throwing stale element exception occasionally
        for (int i = 0; i <= 2; i++) {
            try {
                dropDown = driver().findElement(By.xpath(driverForm + localDropDownXpath));
                break;
            } catch (Exception e) {
                Log.info(e.getMessage());
            }
        }
        selectValueInDropDown(dropDown, incident.getDescription());
        dateInputField.sendKeys(incident.getDateOccured());
    }

    private boolean addFinancialFiling(AutoApplicant applicant, String fullName) throws Exception {
        boolean result = true;
        //Only perform these actions where Financial filing question is applicable
        if (!isFinancialFilingQuestionDisabled(applicant.getStateCode())) {
        	WebElement financialFilingCheckbox = getFinancialFilingCheckbox(fullName);
        	scrollAndClickOnElement(financialFilingCheckbox);
        	result = isCheckboxSelected(financialFilingCheckbox);
        	if (!result) {
        		jsClickElement(financialFilingCheckbox);
            	result = isCheckboxSelected(financialFilingCheckbox);
        	}
        	if (applicant.getFinancialFiling().equals(SR_22_ANOTHER_STATE)) {
        		WebElement anotherStateButton = getAnotherStateButton(fullName);
        		clickElement(anotherStateButton);
        	} else if (applicant.getStateCode().equals(FL)) {
        		// Florida has a button and a case file field
        		WebElement floridaButton = driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + "//button[contains(., 'Florida')]"));
        		clickElement(floridaButton);
        		WebElement floridaCaseInputField = driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//input[not(@type)]"));
        		Faker faker = new Faker();
        		enterValueInField(faker.expression("#{numerify '#########'}"), floridaCaseInputField, "Case number");
        	}
        }
        return result;
    }

    public WebElement getFinancialFilingCheckbox(String fullName) throws Exception {
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + FINANCIAL_RESPONSIBILITY_CHECKBOX_XPATH));
    }

    public void clickOnFinancialFilingAnotherStateButton(String fullName) throws Exception {
        WebElement financialFilingCheckbox = getFinancialFilingCheckbox(fullName);
        scrollAndClickOnElement(financialFilingCheckbox);
        wait.until(d-> isButtonSelected(financialFilingCheckbox));
        WebElement anotherState = getAnotherStateButton(fullName);
        waitAndClickElement(anotherState);
    }

    public boolean addHadDriversLicense(String fullName, int ageLicensedAcquired) throws Exception {
        boolean result = true;
        WebElement hadDriversLicenseCheckbox = getHadDriversLicenseCheckbox(fullName);
        if (!isCheckboxSelected(hadDriversLicenseCheckbox)) {
            clickElement(hadDriversLicenseCheckbox);
        }
        WebElement driverLicenceAgeInputField = getDriverLicenceAgeInputField(fullName);
        sendKeysToElement(driverLicenceAgeInputField, String.valueOf(ageLicensedAcquired));
        sendKeysToElement(driverLicenceAgeInputField, Keys.TAB);
        if (!result) {
            Log.error("\nError in Has Had Driver License in less than 3 years checkbox");
        }
        return result;
    }

    public boolean addEmployment(String fullName, String occupation) throws Exception {
        if (isBDQFlowEnabled()) {
            return true;
        }

        if (StringUtils.isEmpty(occupation) || !isElementPresent(By.xpath(SEE_ELIGIBLE_OCCUPATIONS_XPATH))) {
            Log.info(StringUtils.isEmpty(occupation) ? "No occupation to add" : "'Let's find my occupation' link is not present.");
            selectEmploymentToggle(fullName, "No");
            return true;
        }

        selectEmploymentToggle(fullName, "Yes");

        By occupationLinkBy = By.xpath(getDriverCardXpathByFullName(fullName) + SEE_ELIGIBLE_OCCUPATIONS_XPATH);
        if(isElementDisplayed(occupationLinkBy)) {
            WebElement occupationLink = driver().findElement(occupationLinkBy);
            scrollAndClickOnElement(occupationLink);
            ensureOccupationSideSheetOpen(occupationLink);
        }

        if (selectOccupation(occupation)) {
            scrollAndClickOnElement(closeOrSaveButtonOccupationSideSheet);
            handleAdditionalSelectionIfError();
        } else {
            closeOccupationSideSheet();
        }

        return true;
    }

    private void selectEmploymentToggle(String fullName, String option) throws Exception {
        String toggleXpath = String.format(getDriverCardXpathByFullName(fullName) + "//div[contains(@class,'discount-employed')]//mat-button-toggle[contains(.,'%s')]", option);
        if (isElementDisplayed(By.xpath(toggleXpath))) {
            WebElement toggleElement = driver().findElement(By.xpath(toggleXpath));
            scrollAndClickOnElement(toggleElement);
        }
    }

    private void ensureOccupationSideSheetOpen(WebElement occupationLink) throws Exception {
        if (!isOccupationSideSheetOpen()) {
            scrollAndClickOnElement(occupationLink);
        }
    }

    private boolean selectOccupation(String occupation) throws Exception {
        String occupationXpath = String.format("//mat-radio-button[contains(.,'%s')]", occupation);
        if (isElementDisplayed(By.xpath(occupationXpath))) {
            WebElement occupationElement = driver().findElement(By.xpath(occupationXpath));
            scrollAndClickOnElement(occupationElement);
            return getAttributeData(occupationElement, CLASS).contains(CHECKED);
        }
        return false;
    }

    private void handleAdditionalSelectionIfError() throws Exception {
        if (isElementPresent(By.xpath("//app-occupation-list//mat-error"), 1)) {
            WebElement additionalOption = driver().findElements(By.xpath("//mat-radio-button[not(contains(@class,'checked'))]//input")).get(0);
            scrollAndClickOnElement(additionalOption);
            scrollAndClickOnElement(closeOrSaveButtonOccupationSideSheet);
        }
    }

    private void closeOccupationSideSheet() throws Exception {
        if(isElementVisible(closeIcon, 1)) {
            waitAndClickElement(closeIcon);
        }
    }


    private boolean addFullTimeStudent(Optional<SqlAdditionalDriver> driverOptional, AutoApplicant applicant) throws Exception {
        boolean validated = true;

        //student checkbox is disabled for below state(s)
        if (Arrays.asList(FL, IA, MA).contains(applicant.getStateCode())) {
            return validated;
        }

        if (!applicant.getMaritalStatus().equals(MARRIED) && applicant.getAge() < MAX_YOUNG_AGE) {
            String applicantFullName = getApplicantFullName(applicant);
            WebElement fullTimeStudentCheckbox = getFullTimeStudentCheckbox(applicantFullName);
            scrollToElement(fullTimeStudentCheckbox);
            clickElement(fullTimeStudentCheckbox);
//            if (applicant.isFullTimeStudentWithHighGPA()) {
//                WebElement gpaCheckbox = getGPACheckbox(applicantFullName);
//                waitAndClickElement(gpaCheckbox);
//                validated &= isCheckboxChecked(gpaCheckbox);
//                validated &= isDiscountPresentInTheSideSheet("Good student");
//            }
        }

        if (driverOptional.isPresent() && driverOptional.get().getAge() <= MAX_YOUNG_AGE) {
            SqlAdditionalDriver driver = driverOptional.get();

            String fullName = getDriverFullName(driver);
            if(!driver.getRelationshipToApplicant().equals("Spouse")){
                WebElement fullTimeStudentCheckbox = getFullTimeStudentCheckbox(fullName);
                scrollAndClickOnElement(fullTimeStudentCheckbox);
                validated &= isCheckboxSelected(fullTimeStudentCheckbox);
            }

            // add distant student if applicable
            if (driver.isAttendsDistantSchool() && applicant.getAge() >= MAX_YOUNG_AGE && isFlexState(applicant.getStateCode())) {
                WebElement distantStudentCheckbox = getDistantStudentCheckbox(fullName);
                clickElement(distantStudentCheckbox);
                validated &= isCheckboxSelected(distantStudentCheckbox);
                if(!isOnBristolWest()) {
                    validated &= isDiscountPresentInTheSideSheet("Distant student");
                }
            }
        }
        if (!validated) {
            Log.error("\nError in addFullTimeStudent");
        }
        return validated;
    }

    public boolean setMaritalRelationship(String spouseOneFullName, String spouseTwoFullName) throws Exception {
        boolean validationResult = true;
        // click marital checkbox
        WebElement pniMaritalCheckbox = getMaritalCheckbox(spouseOneFullName);
        scrollAndClickOnElement(pniMaritalCheckbox);
        validationResult &= isCheckboxSelected(pniMaritalCheckbox);

        //choose sni from the married to options
        if(!getSpouseToButton(spouseTwoFullName).isEmpty()) {
            WebElement spouseToButton = getSpouseToButton(spouseTwoFullName).get(0);
            scrollAndClickOnElement(spouseToButton);
        }

        // validate marital checkbox is disabled for sni
        validationResult &= isMaritalCheckboxDisabled(spouseTwoFullName);
        sleep(1);
        // validate sni spouse to points to pni
        validationResult &= getTextFromElement(waitElementBeVisible(driver().findElement(By.xpath(getDriverCardXpathByFullName(spouseOneFullName) + "//div[contains(@id,'ordered-field-placeholder_maritalStatus')]//p")))).contains(spouseTwoFullName);
        if (!validationResult) {
            Log.error("Marital relationship setting was not successful between " + spouseOneFullName + " and" + spouseTwoFullName);
        }
        return validationResult;
    }

    public WebElement getMaritalCheckbox(String pniFullName) throws Exception {
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(pniFullName) + MARITAL_CHECKBOX_INPUT_XPATH));
    }

    private WebElement getAccidentAndViolationCheckbox(String fullName) throws Exception {
        final String HAD_ACCIDENT_VIOLATION_CHECKBOX_XPATH = "//input[contains(@aria-label,'Had an accident')]";
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + HAD_ACCIDENT_VIOLATION_CHECKBOX_XPATH));
    }

    private WebElement getAddAnotherIncidentLink(String fullName) throws Exception {
        final String ADD_ANOTHER_INCIDENT_XPATH = "//a[contains(@id,'addMoreIncident')]";
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + ADD_ANOTHER_INCIDENT_XPATH));
    }

    private List<WebElement> getIncidentRemovalElement(String fullName) throws Exception {
        final String INCIDENT_REMOVAL_XPATH = "//app-incident//a[.='Remove']";
        return driver().findElements(By.xpath(getDriverCardXpathByFullName(fullName) + INCIDENT_REMOVAL_XPATH));
    }

    private List<WebElement> getIncidentsAppsForGivenDriver(String fullName) throws Exception {
        return driver().findElements(By.xpath(getDriverCardXpathByFullName(fullName) + "//app-incident"));
    }

    private WebElement getEmployedCheckbox(String fullName) throws Exception {
        final String EMPLOYED_CHECKBOX_XPATH = "//mat-checkbox[@formcontrolname='isEmployed']//input";
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + EMPLOYED_CHECKBOX_XPATH));
    }

    private WebElement getOccupationInputField(String fullName) throws Exception {
        final String OCCUPATION_INPUT_FIELD_XPATH = "//occupation-typeahead//input";
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + OCCUPATION_INPUT_FIELD_XPATH));
    }

    private WebElement getSafetyCourseCheckbox(String fullName) throws Exception {
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + SAFETY_COURSE_CHECKBOX_XPATH));
    }

    private WebElement getFullTimeStudentCheckbox(String fullName) throws Exception {
        String studentCheckboxXpath = "//div[contains(@id,'fullTimeStudentGPA')]//input";
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + studentCheckboxXpath));
    }

    private WebElement getGPACheckbox(String fullName) throws Exception {
        final String GPA_CHECKBOX_XPATH = "//div[contains(@id,'fullTimeStudentGPA')]//input";
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + GPA_CHECKBOX_XPATH));

    }

    private WebElement getDistantStudentCheckbox(String fullName) throws Exception {
        final String DISTANT_STUDENT_XPATH = "//div[contains(text(),'Attends school more than 100 miles')]//input";
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + DISTANT_STUDENT_XPATH));
    }

    public String getDriverCardXpathByFullName(String fullName) throws Exception {
        return String.format("//h2[contains(.,\"%s\")]/ancestor::app-driver-review-card", fullName);
    }

    public List<String> getCheckboxesTextsForGivenDriver(String fullName) throws Exception {
        List<WebElement> checkboxes = getCheckboxElementsForGivenDriver(fullName);
        return checkboxes.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    private List<WebElement> getCheckboxElementsForGivenDriver(String fullName) throws Exception {
        final String CHECKBOXES = "//div[contains(@class,'safety-course-checkbox')]//label";
        List<WebElement> checkboxes = driver().findElements(By.xpath(getDriverCardXpathByFullName(fullName) + CHECKBOXES));
        waitElementBeVisible(checkboxes.get(0));
        return checkboxes;
    }

    private void validateCheckboxesForGivenDriver(AutoApplicant applicant, String fullName) throws Exception {
        List<WebElement> checkboxElementsForGivenDriver = getCheckboxElementsForGivenDriver(fullName);
    	int numberOfElements = checkboxElementsForGivenDriver.size();
        for (int i = 0; i< numberOfElements; i++){
            try {
                WebElement currentCheckboxElement = checkboxElementsForGivenDriver.get(i);
                if (getTextFromElement(currentCheckboxElement).contains(MARRIED) && applicant.getMaritalStatus().equals(MARRIED)) {
                    continue;
                }
                waitAndClickElement(currentCheckboxElement);
                if (applicant.getAdditionalDrivers().isEmpty() && getTextFromElement(currentCheckboxElement).contains(DriverReviewPageCheckboxes.MARITAL.getCheckBoxText())) {
                    waitAndClickElement(editDriverDialogCloseLink);
                } else {
                    waitAndClickElement(currentCheckboxElement);
                }
            } catch (Exception e) {
                Log.error(e.getMessage());
            }
        }
    }

    public WebElement getEditButtonByDriverFullName(String fullName) throws Exception {
        return waitElementBeVisible(driver().findElement(By.cssSelector("[aria-label='" + fullName + " Edit opens in modal dialog box']")));
    }

    private String getLocalDropDownXpathForIncident(boolean isAdditionalIncident) {
        return !isAdditionalIncident ? ACCIDENT_OR_VIOLATION_DROPDOWN_XPATH : ADDITIONAL_INCIDENT_FORM_XPATH + ACCIDENT_OR_VIOLATION_DROPDOWN_XPATH;
    }

    private WebElement getLocalInjuryButton() throws Exception {
        List<WebElement> injuryElements = driver().findElements(By.xpath("//div[contains(@class,'injuries')]//input"));
        sleep(1);
        return injuryElements.get(injuryElements.size() - 1);
    }

    private String getLocalDateInputField(boolean isAdditionalIncident) {
        return isAdditionalIncident ? ADDITIONAL_INCIDENT_FORM_XPATH + ACCIDENT_OR_VIOLATION_DATE_INPUT_FIELD_XPATH : ACCIDENT_OR_VIOLATION_DATE_INPUT_FIELD_XPATH;
    }

    public String getApplicantFullName(AutoApplicant applicant) {
        return getTheFullNameWithFirstLetterInCaps(applicant.getFirstName() + SPACE + applicant.getLastName());
    }

    public String getDriverFullName(SqlAdditionalDriver driver) {
        return getTheFullNameWithFirstLetterInCaps(driver.getFirstName() + SPACE + driver.getLastName());
    }

    private List<WebElement> getSpouseToButton(String fullName) throws Exception {
        return driver().findElements(By.xpath(String.format("//app-spouse-option[contains(.,'%s')]//input", fullName)));
    }

    private WebElement getHadDriversLicenseCheckbox(String fullName) throws Exception {
        WebElement driverLicenseAgeCheckbox = driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + HAD_THEIR_DRIVER_LICENSE_CHECKBOX));
        scrollElementToMiddle(driverLicenseAgeCheckbox);
        return driverLicenseAgeCheckbox;
    }

    private WebElement getDriverLicenceAgeInputField(String fullName) throws Exception {
        boolean askingDriverLicenseAgeState = isAskingDriverLicenseAgeState(getSessionStorageAppStore().getData().getLandingStateCode());

        final String AGE_INPUT_FIELD_XPATH = askingDriverLicenseAgeState ? "//input[@formcontrolname='ageFirstLicensed']" : "//input[@formcontrolname='minAgeLicense']";
        return waitElementBeVisible(driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + AGE_INPUT_FIELD_XPATH)));
    }

    private WebElement getDriverLicenseAgeConditionError(String fullName) throws Exception {
        final String AGE_ERROR_XPATH = "//mat-error[contains(@class,'age-license')]";
        return waitElementBeVisible(driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + AGE_ERROR_XPATH)));
    }

    public void selectGender(String gender) throws Exception {
        waitAndClickElement(driver().findElement(By.xpath(String.format("//span[contains(.,'%s')]//ancestor::button", gender))));
    }

    public void selectIsLicensedInUSAOrInCanadaOption(String yesOrNo) throws Exception {
        waitAndClickElement(driver().findElement(By.xpath(String.format("//div[contains(@id,'licenseIssued')]//mat-radio-button[.//span[contains(text(),'%s')]]", yesOrNo))));
    }

    public DriverReviewPage selectSpouseAsSecondaryNameInsured(AutoApplicant applicant) throws Exception {
        String pniFullName = getApplicantFullName(applicant);
        String sniFullName = getSniFullName(applicant);
        setMaritalRelationship(pniFullName, sniFullName);
        return this;
    }

    public void selectRandomAdditionalDriverAndAssignToRandomSpouse(AutoApplicant applicant) throws Exception {
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers().stream().filter(additionalDriver -> !additionalDriver.getRelationshipToApplicant().equals(SPOUSE)).collect(Collectors.toList());
        Collections.shuffle(additionalDrivers);
        String spouseOne = additionalDrivers.get(0).getFirstName() + SPACE + additionalDrivers.get(0).getLastName();
        String spouseTwo = additionalDrivers.get(1).getFirstName() + SPACE + additionalDrivers.get(1).getLastName();

        setMaritalRelationship(spouseOne, spouseTwo);
    }

    public void clickOnDriversRevisionHyperlink() {
        waitAndClickElement(driversRevisionHyperlink);
    }

    public void saveQuote(AutoApplicant applicant) throws Exception {
        if (isAutoSaveDisabled()) {
            clickOnSaveQuoteButton();
            enterEmailInSaveQuoteModal(applicant.getEmail());
            isEmailConfirmationDisplayed(applicant.getEmail());
        }
    }

    private WebElement getAnotherStateButton(String fullName) throws Exception {
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        String xpathAnotherState = FINANCIAL_FILING_ANOTHER_STATE_BUTTON_XPATH;
        if(landingStateCode.equals(FL)) {
            xpathAnotherState = "//button[contains(.,'Another state')]";
        }
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + xpathAnotherState));
    }

    public void validateDisplayedOccupations(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        // returning if no available occupation is expected.
        String stateCode = applicant.getStateCode();
        if (isEmploymentDiscountDisabledState(stateCode)) {
            testStep("Skipping this test for the given state as occupation discount is not applicable for the state of " + applicant.getStateCode());
            return;
        }
        new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        isOnDriverReviewPage();
        WebElement eligibleOccupations = driver().findElement(By.xpath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + SEE_ELIGIBLE_OCCUPATIONS_XPATH));
        waitAndClickElement(eligibleOccupations);
        waitElementBeVisible(eligibleOccupationModalHeader);
        sleep(1);
        List<String> expectedEmployedOccupations = AceAutoSupportedOccupationByState.valueOf(stateCode).getSupportedEmployedOccupations().stream().map(Occupations::getOccupationName).collect(Collectors.toList());
        List<String> expectedRetiredOccupations = AceAutoSupportedOccupationByState.valueOf(stateCode).getSupportedRetiredOccupations().stream().map(Occupations::getOccupationName).collect(Collectors.toList());

        if (expectedEmployedOccupations.contains(MILITARY_PERSONNEL)) {
            clickOnHiddenElement(driver().findElement(By.xpath(String.format(OCCUPATION_RADIO_BUTTON_XPATH, Occupations.MILITARY_PERSONNEL.getOccupationName()))));
        }

        List<String> displayedEmployedOccupations = occupationRadioButtons.stream().map(this::getTextFromElement).collect(Collectors.toList());
        Collections.sort(displayedEmployedOccupations);
        Collections.sort(expectedEmployedOccupations);

        waitAndClickElement(retiredToggle);
        if (expectedEmployedOccupations.contains(MILITARY_PERSONNEL)) {
            clickOnHiddenElement(driver().findElement(By.xpath(String.format(OCCUPATION_RADIO_BUTTON_XPATH, Occupations.MILITARY_PERSONNEL.getOccupationName()))));
        }
        Collections.sort(expectedRetiredOccupations);

        if (expectedEmployedOccupations.isEmpty()) {
            fsa.assertEquals(getTextFromElement(discountUnavailable), "We're sorry, but no professional discounts for retirees are currently available.", "discountUnavailable verification");
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(REMOVE_STATUS_XPATH))), "Close", "Close button verification");
        }

        List<String> displayedRetiredOccupations = occupationRadioButtons.stream().map(this::getTextFromElement).collect(Collectors.toList());
        Collections.sort(displayedRetiredOccupations);
        fsa.assertEquals(displayedEmployedOccupations, expectedEmployedOccupations, "List of Employed Occupations verification");
        fsa.assertEquals(displayedRetiredOccupations, expectedRetiredOccupations, "List of Retired Occupations verification");
    }

    public void validateOccupationCodes(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String stateCode = applicant.getStateCode();

        // returning if no available occupation is expected.
        if (isEmploymentDiscountDisabledState(stateCode)) {
            testStep("Skipping this test for the given state as occupation discount is not applicable for the state of " + applicant.getStateCode());
            return;
        }
        new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        isOnDriverReviewPage();
        WebElement eligibleOccupations;
        sleep(1);

        List<Occupations> supportedEmployedOccupations = AceAutoSupportedOccupationByState.valueOf(stateCode).getSupportedEmployedOccupations();
        supportedEmployedOccupations = !stateCode.equals(MI) ? supportedEmployedOccupations.stream().filter(occupation -> !occupation.equals(Occupations.MILITARY_PERSONNEL)).collect(Collectors.toList()) : supportedEmployedOccupations;

        // validate occupation codes for employed toggle
        for (int i = 0; i < supportedEmployedOccupations.size(); i++) {
            Occupations occupation = supportedEmployedOccupations.get(i);
            eligibleOccupations = driver().findElement(By.xpath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + SEE_ELIGIBLE_OCCUPATIONS_XPATH));
            waitAndClickElement(eligibleOccupations);
            waitElementBeVisible(eligibleOccupationModalHeader);
            String expectedEmployedDescription = occupation.getOccupationName().strip();
            if (clickMilitaryPersonnelIfNeeded(occupation)) {
                if(expectedEmployedDescription.equals(TWENTYFIRST_CENTURY)){
                    expectedEmployedDescription = "21st  Century Employees";
                }
                scrollAndClickOnElement(driver().findElement(By.xpath(String.format(OCCUPATION_RADIO_BUTTON_XPATH, expectedEmployedDescription))));
            }
            scrollAndClickOnElement(waitElementBeVisible(closeOrSaveButtonOccupationSideSheet));
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(OCCUPATION_SIDE_PANEL_HEADER_XPATH)));
            // driver license age
            enterDriverLicenseAge(applicant, getApplicantFullName(applicant), applicant.getFirstAgeUnitedStatesDriverLicense());
            enterDriverLicenseAge_CA(getApplicantFullName(applicant), 16);
            addDriverLicenseNumber(applicant, getApplicantFullName(applicant));
            clickContinueButton();
            waitForSpinnerToBeGone();
            if (isSignalDiscountDisabledState(applicant.getStateCode())) {
                new ContactInfoAutoPage().isOnContactInfoAutoPage();
            } else {
                new SignalPageOneUI().isOnSignalPage();
            }
            AppStore.Auto.Driver driver = getSessionStorageAppStore().getAuto().getDrivers().get(0);
            String actualOccupationCode = driver.getFfqOccupationCode().strip();
            String actualOccupationName = driver.getFfqOccupationDescription().strip();
            String expectedEmployedCode = occupation.getEmployedCode();
            if (Arrays.asList(AZ, NM, OR, WI).contains(stateCode)) {
                if (expectedEmployedDescription.equals(EDUCATOR)) {
                    expectedEmployedCode = "HB";
                }
                if (expectedEmployedDescription.equals(FIREFIGHTER)) {
                    expectedEmployedCode = "HF";
                }
                if (expectedEmployedDescription.equals(NURSE)) {
                    expectedEmployedCode = "HI";
                }
                if (expectedEmployedDescription.equals(PHYSICIAN_SURGEON)) {
                    expectedEmployedCode = "HD";
                }
            }

            if (stateCode.equals(MI)) {
                if (expectedEmployedDescription.equals(DENTIST)) {
                    expectedEmployedCode = "DE";
                }
                if (expectedEmployedDescription.equals(EDUCATOR)) {
                    expectedEmployedCode = "FA";
                }
                if (expectedEmployedDescription.equals(ENGINEER)) {
                    expectedEmployedCode = "CC";
                }
                if (expectedEmployedDescription.equals(FARMERS_ZURICH_EMPLOYEE)) {
                    expectedEmployedCode = "G0";
                }
                if (expectedEmployedDescription.equals(NURSE)) {
                    expectedEmployedCode = "EA";
                }
                if (expectedEmployedDescription.equals(PHYSICIAN_SURGEON)) {
                    expectedEmployedCode = "DA";
                }
                if (expectedEmployedDescription.equals(MILITARY_PERSONNEL)) {
                    expectedEmployedCode = "IF";
                }
                if (expectedEmployedDescription.equals(ACCOUNTANT)) {
                    expectedEmployedCode = "AA";
                }


            }

            fsa.assertEquals(actualOccupationCode, expectedEmployedCode, "Occupation code in the DB verification");
            fsa.assertEquals(actualOccupationName, expectedEmployedDescription, "Occupation name in the DB verification");
            driver().navigate().back();
            isOnDriverReviewPage();
            removeOccupation();
            isOnDriverReviewPage();
        }

        // validate occupation codes for retired toggle
        List<Occupations> supportedRetiredOccupations = AceAutoSupportedOccupationByState.valueOf(applicant.getStateCode()).getSupportedRetiredOccupations();
        //TODO: this need to be updated for MI state
        supportedRetiredOccupations = !stateCode.equals(MI) ? supportedRetiredOccupations.stream().filter(occupation -> !occupation.equals(Occupations.MILITARY_PERSONNEL)).collect(Collectors.toList()) : supportedRetiredOccupations;
        for (int i = 0; i < supportedRetiredOccupations.size(); i++) {
            Occupations occupation = supportedRetiredOccupations.get(i);
            eligibleOccupations = driver().findElement(By.xpath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + SEE_ELIGIBLE_OCCUPATIONS_XPATH));
            waitAndClickElement(eligibleOccupations);
            waitElementBeVisible(eligibleOccupationModalHeader);
            scrollAndClickOnElement(retiredToggle);
            if (clickMilitaryPersonnelIfNeeded(occupation)) {
                scrollAndClickOnElement(driver().findElement(By.xpath(String.format(OCCUPATION_RADIO_BUTTON_XPATH, occupation.getOccupationName()))));
            }
            waitAndClickElement(closeOrSaveButtonOccupationSideSheet);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(OCCUPATION_SIDE_PANEL_HEADER_XPATH)));
            clickContinueButton();
            waitForSpinnerToBeGone();
            new SignalPageOneUI().isOnSignalPage();
            AppStore.Auto.Driver driver = getSessionStorageAppStore().getAuto().getDrivers().get(0);
            String actualOccupationCode = driver.getFfqOccupationCode().strip();
            String actualOccupationName = driver.getFfqOccupationDescription().strip();
            String expectedRetiredCode = occupation.getRetiredCode();
            if (stateCode.equals(MI)) {
                if (actualOccupationName.equals(DENTIST)) {
                    expectedRetiredCode = "DE";
                }
                if (actualOccupationName.equals(EDUCATOR)) {
                    expectedRetiredCode = "FA";
                }
                if (actualOccupationName.equals(ENGINEER)) {
                    expectedRetiredCode = "CC";
                }
                if (actualOccupationName.equals(FARMERS_ZURICH_EMPLOYEE)) {
                    expectedRetiredCode = "R0";
                }
                if (actualOccupationName.equals(NURSE)) {
                    expectedRetiredCode = "EA";
                }
                if (actualOccupationName.equals(MILITARY_PERSONNEL)) {
                    expectedRetiredCode = "R9";
                }
                if (actualOccupationName.equals(PHYSICIAN_SURGEON)) {
                    expectedRetiredCode = "DA";
                }
            }
            fsa.assertEquals(actualOccupationCode, expectedRetiredCode, "Retired occupation code in the DB fverification");
            fsa.assertEquals(actualOccupationName, occupation.getOccupationName(), "Retired Occupation name in the DB verification");
            driver().navigate().back();
            isOnDriverReviewPage();
            removeOccupation();
            isOnDriverReviewPage();
        }

    }

    public void enterDriverLicenseAge(AutoApplicant applicant, String fullName, int firstAgeUnitedStatesDriverLicense) throws Exception {
        String stateCode = applicant.getStateCode();
        if(stateCode.equals(CA)) {
            return;
        }
        if (isAskingDriverLicenseAgeState(stateCode)) {
            By inputBy = By.xpath(getDriverCardXpathByFullName(fullName) + LICENSE_AGE_INPUT_FIELD_XPATH);
            if(!isElementPresent(inputBy, 2)) {
                return;
            }
            WebElement licenseAgeInputField = driver().findElement(inputBy);
            scrollElementToMiddle(licenseAgeInputField);
            waitAndClickElement(licenseAgeInputField);
            sendKeysToElement(licenseAgeInputField, firstAgeUnitedStatesDriverLicense);
            sendKeysToElement(licenseAgeInputField, Keys.TAB);
            Log.info("Entered dl age for " + fullName + ". Dl age: " + firstAgeUnitedStatesDriverLicense);
        }
    }

    public void enterDriverLicenseAge_CA(String fullName, int licensedAge) throws Exception {
        if(!getSessionStorageAppStore().getData().getLandingStateCode().equals(CA)) {
            return;
        }
        String driverCardXpathByFullName = getDriverCardXpathByFullName(fullName);
        WebElement ageElementForGivenDriver = driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + DRIVER_AGE_XPATH_END));
        int driverAge = Integer.parseInt(getTextFromElement(ageElementForGivenDriver).replaceAll("[^\\d]", EMPTY_STRING));
        String localToggleXpath;
        String localInputFieldXpath;
        String keyToSend = EMPTY_STRING + licensedAge;
        if (driverAge - 16 < 4) {
            localToggleXpath = LICENSING_INFO_US_NO_TOGGLE_XPATH;
            LocalDate now = LocalDate.now();
            LocalDate oneMonthAgo = now.minusMonths(1);
            localInputFieldXpath = LICENSING_INFO_US_DL_DATE_INPUT_XPATH;
            keyToSend = oneMonthAgo.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

        } else {
            localInputFieldXpath = LICENSING_INFO_US_DL_AGE_INPUT_XPATH;
            localToggleXpath = LICENSING_INFO_US_YES_TOGGLE_XPATH;
        }

        By toggleBy = By.xpath(driverCardXpathByFullName + localToggleXpath + "//button");
        if (!isElementPresent(toggleBy, 1)) {
            return; // for given driver licensing info is not available
        }
        WebElement toggle = driver().findElement(toggleBy);
        clickElement(toggle);
        try {
            wait.until(d -> isButtonSelected(toggle));
        } catch (TimeoutException toe) {
            Log.warn(toe.getMessage());
            clickElement(toggle);
        }

        ((JavascriptExecutor) driver()).executeScript("arguments[0].dispatchEvent(new Event('change'));", toggle);
        By inputBy = By.xpath(driverCardXpathByFullName + localInputFieldXpath);
        wait.until(ExpectedConditions.visibilityOfElementLocated(inputBy));
        WebElement inputField = driver().findElement(inputBy);
        scrollElementToMiddle(inputField);
        ((JavascriptExecutor) driver()).executeScript(String.format("arguments[0].value = '%s';", keyToSend), inputField);
        ((JavascriptExecutor) driver()).executeScript("arguments[0].dispatchEvent(new Event('input'));", inputField);
        ((JavascriptExecutor) driver()).executeScript("arguments[0].dispatchEvent(new Event('change'));", inputField);
        wait.until(ExpectedConditions.attributeContains(inputField, CLASS, "ng-valid"));
        Log.info("Entered dl age for " + fullName + ". Dl age: " + keyToSend);
    }

    private boolean clickMilitaryPersonnelIfNeeded(Occupations occupation) throws Exception {
        boolean militaryJob = AceAutoSupportedOccupationByState.Constants.ONLY_MILITARY_PERSONNEL.contains(occupation);
        if (militaryJob) {
            clickOnHiddenElement(driver().findElement(By.xpath("//mat-radio-button[contains(.,'Military Personnel')]//input")));
            if (!occupation.equals(Occupations.MILITARY_PERSONNEL)) {
                scrollAndClickOnElement(driver().findElement(By.xpath(String.format(OCCUPATION_RADIO_BUTTON_XPATH, occupation.getOccupationName()))));
            }
        }
        return !militaryJob;
    }


    private boolean isNonBinaryGenderDisplayExpected(String stateCode) {
        //TODO: Update the list with all states that require Nonbinary as a gender option
        List<String> genderNonBinaryExpectedStates = new ArrayList<>(Arrays.asList(AR, AZ, CO, CT, GA, ID, IL, MI, MO, ND, NE, NJ, NM, OK, OR, PA, SD, TN, UT, TX, VA, WI, WY));
        return genderNonBinaryExpectedStates.contains(stateCode);
    }

    public void validateDriverLicenseAgeSection(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        List<String> displayedDriversFullNames = getDisplayedDrivers();

        for (String displayedDriversFullName : displayedDriversFullNames) {
            if (isADATestingEnabled()) {
                waitAndClickElement(continueButton);
                performADATesting(this.getClass().getSimpleName() + "_DriversAgeExposed", MARKETING_IT, ACE_AUTO);
                testStep("Driver Review page drivers age section exposed for ADA testing");
                return;
            }
            String currentDriverFullName = displayedDriversFullName;
            if (applicant.getStateCode().equals(CA)) {
                validateLicensingInfoSection(applicant, currentDriverFullName, fsa);
                return;
            }
            validateHelpInfoContentForDriverAgeSection(fsa);

            WebElement currentDriverAgeInputField = getDriverLicenceAgeInputField(currentDriverFullName);
            scrollToElement(currentDriverAgeInputField);
            WebElement notPermitMessage = driver().findElement(By.xpath("//strong[contains(.,'First full license')]"));

            // make sure message for valid entry is displayed
            waitAndClickElement(currentDriverAgeInputField);
            sendKeysToElement(currentDriverAgeInputField, 15);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(notPermitMessage)), "First full license, not learner's permit", "notPermitMessage verification");

            // validate error message if user enter less than 15
            sendKeysToElement(currentDriverAgeInputField, 14);
            scrollAndClickOnElement(continueButton);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(driverLicenseAgeError.get(0))), PLEASE_ENTER_VALID_AGE, "age<15 driverLicenseAgeError verification");

            // validate error message if user enters higher than their age
            WebElement ageElementForCurrentDriver = driver().findElement(By.xpath(getDriverCardXpathByFullName(currentDriverFullName) + DRIVER_AGE_XPATH_END));
            int invalidHighAge = Integer.parseInt(getTextFromElement(ageElementForCurrentDriver).replaceAll("[^\\d.]", "")) + 1;
            scrollToElement(currentDriverAgeInputField);
            sendKeysToElement(waitElementBeVisible(currentDriverAgeInputField), invalidHighAge);
            waitAndClickElement(continueButton);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(driverLicenseAgeError.get(0))), "Age cannot be more than your current age", "invalid age driverLicenseAgeError verification");
            sendKeysToElement(currentDriverAgeInputField, 15);
            isOnDriverReviewPage();
        }
    }

    private void validateLicensingInfoSection(AutoApplicant applicant, String driverFullName, FarmersSoftAssert fsa) throws Exception {
        // validate the absence of driver licensing info section if user selected No for US/CA driver license on Who Should We Insure Page
        if (applicant.getFirstAgeForeignDriverLicense() == 18) {
            validateAbsenceOfForeignDlSection(getApplicantFullName(applicant), fsa);
        }
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        for (int i = 0; i < additionalDrivers.size(); i++) {
            SqlAdditionalDriver driver = additionalDrivers.get(i);
            if (driver.getLicenseToDriveInUSA().equals(NO)) {
                validateAbsenceOfForeignDlSection(getDriverFullName(driver), fsa);
            }
        }
        validateHelpInfoContentForLicensingInfoSection(applicant, fsa);
        validateLabelsForLicensingInfoSection(applicant, fsa);
        validateLicensingInfoSectionRulesAndErrorMessages(applicant, fsa);
    }

    private void validateAbsenceOfForeignDlSection(String fullName, FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(!isElementPresent(By.xpath(getDriverCardXpathByFullName(fullName) + LICENSING_INFO_HEADER_XPATH), 2), "Driver licensing info section for " + fullName + " should not be visible for a driver with Foreign DL selected on who should insure page");
    }

    public void validateDriverLicenseNumberInputSection(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        List<WebElement> dlInputFields = driver().findElements(By.xpath(DRIVER_LICENSE_NUMBER_INPUT_XPATH));
        int numberOfElements = dlInputFields.size();
        for (int i = 0; i < numberOfElements; i++) {
            String xpathForErrorMessage = getDriverCardXpathByFullName(i == 0 ? getApplicantFullName(applicant) : getDriverFullName(applicant.getAdditionalDrivers().get(0))) + DRIVER_LICENSE_NUMBER_INPUT_ERROR_XPATH;
            String xpathForDlNumberInputField = getDriverCardXpathByFullName(i == 0 ? getApplicantFullName(applicant) : getDriverFullName(applicant.getAdditionalDrivers().get(0))) + DRIVER_LICENSE_NUMBER_INPUT_XPATH;

            if (isADATestingEnabled()) {
                waitAndClickElement(continueButton);
                performADATesting(this.getClass().getSimpleName() + "_DriverLicenseInput", MARKETING_IT, ACE_AUTO);
                testStep("Driver Review page drivers license section exposed for ADA testing");
                return;
            }
            // validate help info section
            validateHelpInfoContentForDriverLicenseSection(fsa);
            WebElement currentDlEntryField = driver().findElement(By.xpath(xpathForDlNumberInputField));
            scrollToElement(currentDlEntryField);

            // validate no entry error message
            currentDlEntryField.clear();
            scrollAndClickOnElement(continueButton);
            String expectedNoInputErrorMessage = "License # not valid for this state.";
            String expectedNoInputErrorMessage2 = "Please enter license number.";
            isElementPresent(By.xpath(xpathForErrorMessage), 2);
            String actualErrorMessage = getTextFromElement(driver().findElement(By.xpath(xpathForErrorMessage)));
            fsa.assertTrue(Arrays.asList(expectedNoInputErrorMessage, expectedNoInputErrorMessage2).contains(actualErrorMessage),"driverLicenseNumberInputError no entry verification. Actual error message: " + actualErrorMessage + ". Expected error messages: " + expectedNoInputErrorMessage + " or " + expectedNoInputErrorMessage2);

            // validate invalid entry error message
            String expectedInvalidEntryErrorMessage = "License # not valid for this state.";
            String expectedInvalidEntryErrorMessage2 = "Please enter license number.";
            Faker faker = new Faker();
            String stateCode = applicant.getStateCode();
            String validDl = faker.drivingLicense().drivingLicense(stateCode);
            String invalidDl = validDl + "ABS";
            scrollElementToMiddle(currentDlEntryField);
            waitAndClickElement(currentDlEntryField);
            sendKeysToElement(currentDlEntryField, invalidDl);
            waitForSpinnerToBeGone();
            scrollAndClickOnElement(continueButton);
            waitForSpinnerToBeGone();
            isElementPresent(By.xpath(xpathForErrorMessage), 2);
            fsa.assertTrue(Arrays.asList(expectedInvalidEntryErrorMessage2, expectedInvalidEntryErrorMessage).contains(actualErrorMessage), "driverLicenseNumberInput Error no entry verification. Actual error message: " + actualErrorMessage + ". Expected error messages: " + expectedInvalidEntryErrorMessage2 + " or " + expectedInvalidEntryErrorMessage);

            // validate valid entry
            scrollElementToTop(currentDlEntryField);
            sendKeysToElement(currentDlEntryField, validDl);
            waitForSpinnerToBeGone();
            scrollAndClickOnElement(continueButton);
            waitForSpinnerToBeGone();
            fsa.assertTrue(wait.until(ExpectedConditions.attributeContains(currentDlEntryField, CLASS, NG_VALID)), "Make sure input field is valid for DL number");
        }

        validateDuplicateErrorMessageIsDisappearedWhenCorrected(applicant, fsa);

        validateDuplicateErrorMessageIsNotImpactingOtherFields(applicant, fsa);

    }

    private void validateDuplicateErrorMessageIsDisappearedWhenCorrected(AutoApplicant applicant, FarmersSoftAssert softAssert) throws Exception {
        driver().navigate().refresh();
        WebElement pniDlInputField = driver().findElement(By.xpath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + DL_LICENSE_NUMBER_INPUT_FIELD_XPATH));
        WebElement sniDlInputField = driver().findElement(By.xpath(getDriverCardXpathByFullName(getDriverFullName(applicant.getAdditionalDrivers().get(0))) + DL_LICENSE_NUMBER_INPUT_FIELD_XPATH));
        String duplicateDl = "M12343423";
        scrollElementToTop(pniDlInputField);
        sendKeysToElement(pniDlInputField, duplicateDl);
        waitForSpinnerToBeGone();
        sendKeysToElement(sniDlInputField, duplicateDl);
        waitForSpinnerToBeGone();
        scrollAndClickOnElement(continueButton);
        waitForSpinnerToBeGone();
        //reclick in case one click is not registered due to any reason to make sure error message is displayed
        scrollAndClickOnElement(continueButton);
        waitForSpinnerToBeGone();

        // validate duplicate error message
        String sniErrorMessageXpath = getDriverCardXpathByFullName(getDriverFullName(applicant.getAdditionalDrivers().get(0))) + DRIVER_LICENSE_NUMBER_INPUT_ERROR_XPATH;
        String pniErrorMessageXpath = getDriverCardXpathByFullName(getApplicantFullName(applicant)) + DRIVER_LICENSE_NUMBER_INPUT_ERROR_XPATH;
        String expectedDuplicateErrorMessage = "Duplicate license number entered.";
        softAssert.assertTrue(isElementPresent(By.xpath(sniErrorMessageXpath), 2), "Duplicate license number error message should be displayed for SNI when duplicate DL number is entered");
        softAssert.assertTrue(isElementPresent(By.xpath(pniErrorMessageXpath), 2), "Duplicate license number error message should be displayed for PNI when duplicate DL number is entered");
        softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(sniErrorMessageXpath))), expectedDuplicateErrorMessage, "Duplicate license number error message should be displayed for SNI when duplicate DL number is entered");
        softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(pniErrorMessageXpath))), expectedDuplicateErrorMessage, "Duplicate license number error message should be displayed for PNI when duplicate DL number is entered");

        // validate error message is disappeared when corrected
        scrollElementToTop(sniDlInputField);
        sendKeysToElement(sniDlInputField, "M12343424");
        waitForSpinnerToBeGone();
        scrollAndClickOnElement(continueButton);
        softAssert.assertTrue(driverLicenseNumberInputError.isEmpty(), "Duplicate license number error message should be disappeared once corrected");

    }

    private void validateDuplicateErrorMessageIsNotImpactingOtherFields(AutoApplicant applicant, FarmersSoftAssert softAssert) throws Exception {
        // enter dl ages to avoid error messages related to missing dl age and validate only duplicate error message is displayed when duplicate DL numbers are entered
        enterDriverLicenseAge(applicant, getApplicantFullName(applicant), applicant.getFirstAgeUnitedStatesDriverLicense());
        SqlAdditionalDriver sqlAdditionalDriver = applicant.getAdditionalDrivers().get(0);
        enterDriverLicenseAge(applicant, getDriverFullName(sqlAdditionalDriver), sqlAdditionalDriver.getFirstAgeUnitedStatesDriverLicense());
        WebElement pniDlInputField = driver().findElement(By.xpath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + DL_LICENSE_NUMBER_INPUT_FIELD_XPATH));
        WebElement sniDlInputField = driver().findElement(By.xpath(getDriverCardXpathByFullName(getDriverFullName(sqlAdditionalDriver)) + DL_LICENSE_NUMBER_INPUT_FIELD_XPATH));
        String duplicateDl = "M12343423";
        scrollElementToTop(pniDlInputField);
        sendKeysToElement(pniDlInputField, duplicateDl);
        sendKeysToElement(sniDlInputField, duplicateDl);
        scrollAndClickOnElement(continueButton);
        List<WebElement> pageErrorMessages = driver().findElements(By.tagName("mat-error"));

        // validate page only shows duplicate error message and no other error message is displayed
        pageErrorMessages.forEach(each -> {
            String expectedDuplicateErrorMessage = "Duplicate license number entered.";
            softAssert.assertEquals(getTextFromElement(each), expectedDuplicateErrorMessage, "Only duplicate error message should be displayed when duplicate DL numbers are entered");
        });

        // correct duplicate error and validate user can proceed to next step without any issue
        sendKeysToElement(sniDlInputField, "M12343424");
        scrollAndClickOnElement(continueButton);
        pageErrorMessages = driver().findElements(By.tagName("mat-error")); // relocate as the error is corrected
        softAssert.assertTrue(pageErrorMessages.isEmpty(), "No error message should be displayed once duplicate DL error is corrected");
        if (isSignalDiscountDisabledState(applicant.getStateCode())) {
            new ContactInfoAutoPage().isOnContactInfoAutoPage();
        } else {
            new SignalPageOneUI().isOnSignalPage();
        }
    }

    private void validateHelpInfoContentForDriverAgeSection(FarmersSoftAssert fsa) {
        String expectedHelpInfoHeader = "Driver's license age";
        String expectedAtWhatAgeText = "At what age was this driver first licensed to drive, whether in the United States or in a foreign country?";
        String expectedGapText = "If there has been a gap in licensing, please provide the age this driver first held a license to drive. This includes only a full driver's license, not a learner's permit.";
    	int numberOfElements = driverLicenseAgeInfoHeaderBrowser.size();
        for (int i = 0; i< numberOfElements; i++){
            if (isUseMobileViewEnabled()) {
                scrollToElement(driverLicenseAgeMobileHelpIcon.get(i));
                waitAndClickElement(driverLicenseAgeMobileHelpIcon.get(i));
                fsa.assertEquals(getTextFromElement(infoBoxHeader), expectedHelpInfoHeader, "infoBoxHeader verification");
                fsa.assertEquals(getTextFromElement(infoBoxContent), expectedAtWhatAgeText + SPACE + expectedGapText, "infoBoxContent verification");
                waitAndClickElement(infoBoxCloseButton);
            } else {
                scrollToElement(driverLicenseAgeInfoHeaderBrowser.get(i));
                fsa.assertEquals(getTextFromElement(driverLicenseAgeInfoHeaderBrowser.get(i)), expectedHelpInfoHeader, "driverLicenseAgeInfoHeaderBrowser verification");
                fsa.assertEquals(getTextFromElement(driverLicenseAtWhatAgeBrowser.get(i)), expectedAtWhatAgeText, "driverLicenseAtWhatAgeBrowser verification");
                fsa.assertEquals(getTextFromElement(driverLicenseGapBrowser.get(i)), expectedGapText, "driverLicenseGapBrowser verification");
            }
        }

    }

    private void validateHelpInfoContentForLicensingInfoSection(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String expectedHelpInfoHeader = "Licensing Info";
        String expectedAtWhatAgeText = "When was this driver first licensed to drive, both in the U.S. or Canada, and in a foreign country? (This includes a full driver's license, not a learner's permit.)";
        String expectedInYourStateText = "In your state, time licensed in the U.S. or Canada and in a foreign country are important for determining eligibility and rating for the policy.";
        String expectedDiscountText = "Drivers may also be eligible for certain discounts.";
        List<SqlAdditionalDriver> listOfAdditionalDriversWithUSOrCanada = applicant.getAdditionalDrivers().stream().filter(each -> each.getLicenseToDriveInUSA().equals(YES)).collect(Collectors.toList());
        boolean applicantLicensedInUsa = applicant.getFirstAgeForeignDriverLicense() != 18;
        int iteratorCount = listOfAdditionalDriversWithUSOrCanada.size() + (applicantLicensedInUsa ? 1 : 0);
        for (int i = 0; i < iteratorCount; i++) {
            if (isUseMobileViewEnabled()) {
                testStep("Validate \"Licensing info\" field info information mobile breakpoint");
                scrollToElement(driverLicensingInfoMobileHelpIcon.get(i));
                waitAndClickElement(driverLicensingInfoMobileHelpIcon.get(i));
                fsa.assertEquals(getTextFromElement(infoBoxHeader), expectedHelpInfoHeader, "Help info header validation mobile");
                fsa.assertEquals(getTextFromElement(infoBoxContent), expectedAtWhatAgeText + SPACE + expectedInYourStateText + SPACE + expectedDiscountText, "infoBoxContent verification");
                waitAndClickElement(infoBoxCloseButton);
            } else {
                testStep("Validate \"Licensing info\" field info information desktop breakpoint");
                scrollToElement(driverLicenseInfoInfoHeaderBrowser.get(i));
                fsa.assertEquals(getTextFromElement(driverLicenseInfoInfoHeaderBrowser.get(i)), expectedHelpInfoHeader, "Help info header validation");
                String helpInfoContent = getTextFromElement(licensingInfoHelpContent.get(i));
                fsa.assertTrue(helpInfoContent.contains(expectedAtWhatAgeText), expectedAtWhatAgeText + " : contained in the help info content");
                fsa.assertTrue(helpInfoContent.contains(expectedInYourStateText), expectedInYourStateText + " : contained in the help info content");
                fsa.assertTrue(helpInfoContent.contains(expectedDiscountText), expectedDiscountText + " : contained in the help info content");
            }
        }

    }

    private void validateLabelsForLicensingInfoSection(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String expectedLicensingInfoSectionHeader = "Licensing Info";
        String expectedLicensingInfoFirstQuestion = "Has this driver been licensed in a U.S. state, U.S. territory, or Canadian province for over 4 years?";
        String expectedLicensingInfoSecondCheckbox = "This driver is (or was) licensed to drive in a foreign country";
        String expectedLicensingInfoSecondQuestion = "Was this driver licensed in another country more than 4 years ago?";
        String dateLicensedInUsOrCaLabel = "Date licensed in U.S or Canada";
        String ageLicensedInUsOrCaLabel = "Age licensed in U.S or Canada";
        String ageLicensedInAnotherCountryLabel = "Age licensed in another country";
        String dateLicensedInAnotherCountryLabel = "Date licensed in another country";
        String fullLicenseNotPermitMessage = "First full license, not learner's permit";
        List<SqlAdditionalDriver> listOfAdditionalDriversWithUSOrCanada = applicant.getAdditionalDrivers().stream().filter(each -> each.getLicenseToDriveInUSA().equals(YES)).collect(Collectors.toList());
        boolean applicantLicensedInUsa = applicant.getFirstAgeForeignDriverLicense() != 18;
        int iteratorCount = listOfAdditionalDriversWithUSOrCanada.size() + (applicantLicensedInUsa ? 1 : 0);
        for (int i = 0; i < iteratorCount; i++) {
            List<String> usCaLicensedDrivers = listOfAdditionalDriversWithUSOrCanada.stream().map(each -> getDriverFullName(each)).collect(Collectors.toList());
            if (applicantLicensedInUsa) {
                usCaLicensedDrivers.add(getApplicantFullName(applicant));
            }
            String currentDriverFullName = usCaLicensedDrivers.get(i);
            String driverCardXpathByFullName = getDriverCardXpathByFullName(currentDriverFullName);
            // validate section header
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_HEADER_XPATH))), expectedLicensingInfoSectionHeader, "Licensing info section header validation");
            // validate section first question /subheader
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_SUB_HEADER_XPATH))), expectedLicensingInfoFirstQuestion, "Licensing info section first question validation");
            WebElement usCaYesToggle = driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_US_YES_TOGGLE_XPATH));
            //validate Yes and No toggles texts
            fsa.assertEquals(getTextFromElement(usCaYesToggle), "Yes", "Licensing info section Yes toggle text validation");
            WebElement usCaNoToggle = driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_US_NO_TOGGLE_XPATH));
            fsa.assertEquals(getTextFromElement(usCaNoToggle), "No", "Licensing info section No toggle text validation");
            waitAndClickElement(usCaYesToggle);
            wait.until(ExpectedConditions.attributeContains(usCaYesToggle, CLASS, "checked"));
            // validate Yes toggle section input label and hint validation
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_US_DL_AGE_INPUT_LABEL_XPATH))), ageLicensedInUsOrCaLabel, "Licensing info section age input label text validation");
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_US_DL_AGE_INPUT_HINT_XPATH))), fullLicenseNotPermitMessage, "Licensing info section age input sub message text validation");
            waitAndClickElement(usCaNoToggle);
            // validate No toggle section input label and hint validation
            wait.until(ExpectedConditions.attributeContains(usCaNoToggle, CLASS, "checked"));
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_US_DL_DATE_INPUT_LABEL_XPATH))), dateLicensedInUsOrCaLabel, "Licensing info section date input label text validation");
            fsa.assertTrue(isElementPresent(By.xpath(driverCardXpathByFullName + LICENSING_INFO_US_DL_DATE_INPUT_DATE_PICKER_XPATH)), "Date picker for US/CA date input section");
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_US_DL_DATE_INPUT_HINT_XPATH))), fullLicenseNotPermitMessage, "Licensing info section age input sub message text validation");
            // Foreign dl question and checkbox text validation
            WebElement foreignDlCheckbox = driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_FOREIGN_DL_QUESTION_CHECKBOX_XPATH));
            clickElement(foreignDlCheckbox);
            wait.until(d -> getAttributeData(foreignDlCheckbox, CLASS).contains(MDC_CHECKBOX_SELECTED));
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_FOREIGN_DL_QUESTION_CHECKBOX_LABEL_XPATH))), expectedLicensingInfoSecondCheckbox, "Licensing info section foreign dl checkbox label message text validation");
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_FOREIGN_DL_QUESTION_HEADER_XPATH))), expectedLicensingInfoSecondQuestion, "Licensing info section foreign dl question text validation");
            WebElement fldYesToggle = driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_YES_TOGGLE_XPATH));
            WebElement fldNoToggle = driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_NO_TOGGLE_XPATH));
            fsa.assertEquals(getTextFromElement(fldYesToggle), "Yes", "Licensing info section foreign dl Yes toggle text validation");
            fsa.assertEquals(getTextFromElement(fldNoToggle), "No", "Licensing info section foreign dl No toggle text validation");
            waitAndClickElement(fldYesToggle);
            wait.until(d -> isButtonSelected(fldYesToggle));
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_DL_AGE_INPUT_LABEL_XPATH))), ageLicensedInAnotherCountryLabel, "Licensing info section foreign dl age input label  text validation");
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_DL_AGE_INPUT_HINT_XPATH))), fullLicenseNotPermitMessage, "Licensing info section foreign dl age input sub messsage text validation");
            waitAndClickElement(fldNoToggle);
            wait.until(d -> isButtonSelected(fldNoToggle));
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_LABEL_XPATH))), dateLicensedInAnotherCountryLabel, "Licensing info section foreign dl date input label validation");
            fsa.assertTrue(isElementDisplayed(By.xpath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_DATE_PICKER)), "Date picker is displayed for foreign dl date input field");
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_HINT_XPATH))), fullLicenseNotPermitMessage, "Licensing info section foreign dl date input sub message validation");

        }

    }

    private void validateLicensingInfoSectionRulesAndErrorMessages(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {

        List<SqlAdditionalDriver> listOfAdditionalDriversWithUSOrCanada = applicant.getAdditionalDrivers().stream().filter(each -> each.getLicenseToDriveInUSA().equals(YES)).collect(Collectors.toList());
        boolean applicantLicensedInUsa = applicant.getFirstAgeForeignDriverLicense() != 18;
        int iteratorCount = listOfAdditionalDriversWithUSOrCanada.size() + (applicantLicensedInUsa ? 1 : 0);
        for (int i = 0; i < iteratorCount; i++) {
            List<String> usCaLicensedDrivers = listOfAdditionalDriversWithUSOrCanada.stream().map(each -> getDriverFullName(each)).collect(Collectors.toList());
            if (applicantLicensedInUsa) {
                usCaLicensedDrivers.add(getApplicantFullName(applicant));
            }
            String currentDriverFullName = usCaLicensedDrivers.get(i);
            String driverCardXpathByFullName = getDriverCardXpathByFullName(currentDriverFullName);
            int driverAge = Integer.parseInt(getTextFromElement(driver().findElement(By.xpath(driverCardXpathByFullName + DRIVER_AGE_XPATH_END))).replaceAll("\\D+", EMPTY_STRING));

            driver().navigate().refresh();
            isOnDriverReviewPage();
            // validate user is not able to move on without making selection
            waitAndClickElement(continueButton);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(ctaErrorMessage)), CTA_ERROR_MESSAGE, "Cta error message is shown with not providing licensing info");

            validateRuleValidationsForUS_CA_AgeField(driverCardXpathByFullName, driverAge, fsa);
            validateRuleValidationsForUS_CA_DateField(driverCardXpathByFullName, driverAge, fsa);
            validateRuleValidationsForForeign_AgeField(driverCardXpathByFullName, driverAge, fsa);
            validateRuleValidationsForForeign_DateField(driverCardXpathByFullName, driverAge, fsa);

        }

    }

    private void validateRuleValidationsForUS_CA_AgeField(String driverCard, int driverAge, FarmersSoftAssert fsa) throws Exception {

        // US/CA yes toggle rules validation
        WebElement usCaYesToggle = driver().findElement(By.xpath(driverCard + LICENSING_INFO_US_YES_TOGGLE_XPATH));
        waitAndClickElement(usCaYesToggle);
        sleep(1);
        WebElement usCaAgeInputField = driver().findElement(By.xpath(driverCard + LICENSING_INFO_US_DL_AGE_INPUT_XPATH));

        // validate error message for less than 4 years entering 3 years less from driver age
        sendKeysToElement(usCaAgeInputField, (driverAge - 3));
        sendKeysToElement(usCaAgeInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCard + LICENSING_INFO_US_DL_AGE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_ENTER_VALID_AGE, PLEASE_ENTER_VALID_AGE + " : error message should show when user enters less than 4 years ago age");

        //  validate error message should not show for valid age 15 and more (upper end edge case)
        sendKeysToElement(usCaAgeInputField, (driverAge - 4));
        sendKeysToElement(usCaAgeInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(By.xpath(driverCard + LICENSING_INFO_US_DL_AGE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_ENTER_VALID_AGE + " : error messgae should NOT show when user enters   4 or more years age ago ");

        // validate less than 15 shows error
        sendKeysToElement(usCaAgeInputField, 14);
        sendKeysToElement(usCaAgeInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCard + LICENSING_INFO_US_DL_AGE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_ENTER_VALID_AGE, PLEASE_ENTER_VALID_AGE + " : error message should show when user enters less than 4 years ago age");


        // validate error message should not show for valid age 15 and more (lower end edge case)
        sendKeysToElement(usCaAgeInputField, 15);
        sendKeysToElement(usCaAgeInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(By.xpath(driverCard + LICENSING_INFO_US_DL_AGE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_ENTER_VALID_AGE + " : error messgae should NOT show when user enters   4 or more years age ago ");


    }

    private void validateRuleValidationsForUS_CA_DateField(String driverCard, int driverAge, FarmersSoftAssert fsa) throws Exception {
        // US/CA yes toggle rules validation
        driver().navigate().refresh();
        isOnDriverReviewPage();
        WebElement usCaNoToggle = driver().findElement(By.xpath(driverCard + LICENSING_INFO_US_NO_TOGGLE_XPATH));
        waitAndClickElement(usCaNoToggle);
        sleep(1);
        WebElement usCaDateInputField = driver().findElement(By.xpath(driverCard + LICENSING_INFO_US_DL_DATE_INPUT_XPATH));
        LocalDate now = LocalDate.now();

        // upper edge case
        LocalDate fourYearsAgo = now.minusYears(4); // lower edge case
        LocalDate tomorrow = now.plusDays(4); // upper invalid edge case
        LocalDate fourYearsOneDayAgo = fourYearsAgo.minusDays(1); // lower invalid edge case

        // validate valid upper level edge case
        sendKeysToElement(usCaDateInputField, now.format(DateTimeFormatter.ofPattern("MM-dd-yyyy")));
        sendKeysToElement(usCaDateInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(By.xpath(driverCard + LICENSING_INFO_US_DL_DATE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_PROVIDE_VALID_DATE + " : Error message should  NOT show  when valid input for date field");

        // validate upper invalid level
        clearOutFieldUsingBackSpace(usCaDateInputField);
        sendKeysToElement(usCaDateInputField, tomorrow.format(DateTimeFormatter.ofPattern("MM-dd-yyyy")));
        sendKeysToElement(usCaDateInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCard + LICENSING_INFO_US_DL_DATE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_PROVIDE_VALID_DATE, PLEASE_PROVIDE_VALID_DATE + " : Error message should  show when invalid input for date field");

        // validate valid lower edge case
        clearOutFieldUsingBackSpace(usCaDateInputField);
        sendKeysToElement(usCaDateInputField, fourYearsAgo.format(DateTimeFormatter.ofPattern("MM-dd-yyyy")));
        sendKeysToElement(usCaDateInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(By.xpath(driverCard + LICENSING_INFO_US_DL_DATE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_PROVIDE_VALID_DATE + " : Error message should  NOT show when valid input for date field");

        // validate lower invalid level
        clearOutFieldUsingBackSpace(usCaDateInputField);
        sendKeysToElement(usCaDateInputField, fourYearsOneDayAgo.format(DateTimeFormatter.ofPattern("MM-dd-yyyy")));
        sendKeysToElement(usCaDateInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCard + LICENSING_INFO_US_DL_DATE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_PROVIDE_VALID_DATE, PLEASE_PROVIDE_VALID_DATE + " : Error message should show when invalid input for date field");

    }

    private void validateRuleValidationsForForeign_AgeField(String driverCard, int driverAge, FarmersSoftAssert fsa) throws Exception {

        // click foreing dl checkbox
        WebElement foreignDlCheckbox = driver().findElement(By.xpath(driverCard + LICENSING_FOREIGN_DL_QUESTION_CHECKBOX_XPATH));
        scrollAndClickOnElement(foreignDlCheckbox);
        fsa.assertTrue(wait.until(d->isCheckboxSelected(foreignDlCheckbox)), "Validate foreign dl checkbox is checked");

        // Foreign yes toggle rules validation
        WebElement foreignYesToggle = driver().findElement(By.xpath(driverCard + LICENSING_INFO_FOREIGN_YES_TOGGLE_XPATH));
        waitAndClickElement(foreignYesToggle);
        fsa.assertTrue(wait.until(d->isButtonSelected(foreignYesToggle)), "Foreign dl issued at least 4 years ago check");

        WebElement foreingDlAgeInputField = driver().findElement(By.xpath(driverCard + LICENSING_INFO_FOREIGN_DL_AGE_INPUT_XPATH));
        // validate error message for less than 4 years entering 3 years less from driver age
        sendKeysToElement(foreingDlAgeInputField, (driverAge - 3));
        sendKeysToElement(foreingDlAgeInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCard + LICENSING_INFO_FOREIGN_DL_AGE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_ENTER_VALID_AGE, PLEASE_ENTER_VALID_AGE + " : error messgae should show when user enters less than 4 years ago age");

        //  validate error message should not show for valid age 15 and more (upper end edge case)
        sendKeysToElement(foreingDlAgeInputField, (driverAge - 4));
        sendKeysToElement(foreingDlAgeInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(By.xpath(driverCard + LICENSING_INFO_FOREIGN_DL_AGE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_ENTER_VALID_AGE + " : error messgae should NOT show when user enters   4 or more years age ago ");

        // validate less than 15 shows error
        sendKeysToElement(foreingDlAgeInputField, 14);
        sendKeysToElement(foreingDlAgeInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCard + LICENSING_INFO_FOREIGN_DL_AGE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_ENTER_VALID_AGE, PLEASE_ENTER_VALID_AGE + " : error messgae should show when user enters less than 4 years ago age");

        // validate error message should not show for valid age 15 and more (lower end edge case)
        sendKeysToElement(foreignYesToggle, 15);
        sendKeysToElement(foreignYesToggle, Keys.TAB);
        fsa.assertTrue(!isElementPresent(By.xpath(driverCard + LICENSING_INFO_US_DL_AGE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_ENTER_VALID_AGE + " : error messgae should NOT show when user enters  4 or more years age ago ");
    }

    private void validateRuleValidationsForForeign_DateField(String driverCard, int driverAge, FarmersSoftAssert fsa) throws Exception {
        // US/CA yes toggle rules validation
        driver().navigate().refresh();
        isOnDriverReviewPage();

        // click foreing dl checkbox
        WebElement foreignDlCheckbox = driver().findElement(By.xpath(driverCard + LICENSING_FOREIGN_DL_QUESTION_CHECKBOX_XPATH));
        scrollAndClickOnElement(foreignDlCheckbox);
        wait.until(d->isCheckboxSelected(foreignDlCheckbox));
        fsa.assertTrue(isCheckboxSelected(foreignDlCheckbox), "Validate foreign dl checkbox is checked");

        WebElement foreignNoToggle = driver().findElement(By.xpath(driverCard + LICENSING_INFO_FOREIGN_NO_TOGGLE_XPATH));
        scrollAndClickOnElement(foreignNoToggle);
        fsa.assertTrue(wait.until(d -> isCheckboxSelected(foreignDlCheckbox)), "Validate foreign no toggle checkbox is checked");

        WebElement foreignDateInputField = driver().findElement(By.xpath(driverCard + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_XPATH));
        LocalDate now = LocalDate.now();

        // upper edge case
        LocalDate fourYearsAgo = now.minusYears(4); // lower edge case
        LocalDate tomorrow = now.plusDays(4); // upper invalid edge case
        LocalDate fourYearsOneDayAgo = fourYearsAgo.minusDays(1); // lower invalid edge case

        // validate valid upper level edge case
        sendKeysToElement(foreignDateInputField, now.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        sendKeysToElement(foreignDateInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(By.xpath(driverCard + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_PROVIDE_VALID_DATE + " : Error message should  NOT show  when valid input for date field");

        // validate upper invalid level
        clearOutFieldUsingBackSpace(foreignDateInputField);
        sendKeysToElement(foreignDateInputField, tomorrow.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        sendKeysToElement(foreignDateInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCard + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_PROVIDE_VALID_DATE, PLEASE_PROVIDE_VALID_DATE + " : Error message should  show when invalid input for date field");

        // validate valid lower edge case
        clearOutFieldUsingBackSpace(foreignDateInputField);
        sendKeysToElement(foreignDateInputField, fourYearsAgo.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        sendKeysToElement(foreignDateInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(By.xpath(driverCard + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_PROVIDE_VALID_DATE + " : Error message should  NOT show when valid input for date field");

        // validate lower invalid level
        clearOutFieldUsingBackSpace(foreignDateInputField);
        sendKeysToElement(foreignDateInputField, fourYearsOneDayAgo.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        sendKeysToElement(foreignDateInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(driverCard + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_PROVIDE_VALID_DATE, PLEASE_PROVIDE_VALID_DATE + " : Error message should show when invalid input for date field");
    }

    private void validateHelpInfoContentForDriverLicenseSection(FarmersSoftAssert fsa) {
        String expectedHelpInfoHeader = "Why do you need my driver's license number?";
        String expectedInfoText = "This is required to check your driving history and motor vehicle report.";
    	int numberOfElements = driverLicenseNumberInfoBoxHeaderBrowser.size();
        for (int i = 0; i< numberOfElements; i++){
            if (isUseMobileViewEnabled()) {
                testStep("Validate \"Driver's License Input field help icon\" field mobile breakpoint");
                scrollToElement(driverLicenseNumberInfoBoxMobileIcon.get(i));
                waitAndClickElement(driverLicenseNumberInfoBoxMobileIcon.get(i));
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoBoxHeader)), expectedHelpInfoHeader, "HelpInfoContentForDriverLicenseSection header verification");
                fsa.assertEquals(getTextFromElement(infoBoxContent), expectedInfoText, "HelpInfoContentForDriverLicenseSection content verification");
                waitAndClickElement(infoBoxCloseButton);
            } else {
                testStep("Validate \"Driver's License Input field help icon\" field browser breakpoint");
                scrollToElement(driverLicenseNumberInfoBoxHeaderBrowser.get(i));
                fsa.assertEquals(getTextFromElement(driverLicenseNumberInfoBoxHeaderBrowser.get(i)), expectedHelpInfoHeader, "HelpInfoContentForDriverLicenseSection header verification");
                fsa.assertEquals(getTextFromElement(driverLicenseNumberInfoBoxTextBrowser.get(i)), expectedInfoText, "HelpInfoContentForDriverLicenseSection content verification");
            }
        }
    }

    public void validateADA_DriverReviewPage() throws Exception {
        if (!isADATestingEnabled()) return;
        isOnDriverReviewPage();
        List<WebElement> hadTheirDriverLicenseCheckboxes = driver().findElements(By.xpath(HAD_THEIR_DRIVER_LICENSE_CHECKBOX));
        List<WebElement> financialFilingCheckboxes = driver().findElements(By.xpath(FINANCIAL_RESPONSIBILITY_CHECKBOX_XPATH));
        List<WebElement> seeEligibleOccupations = driver().findElements(By.xpath(SEE_ELIGIBLE_OCCUPATIONS_XPATH));

        // expose had their dl in last three years input fields
        for (WebElement hadTheirDriverLicenseCheckbox : hadTheirDriverLicenseCheckboxes) {
            clickElement(hadTheirDriverLicenseCheckbox);
        }

        if (!accidentCheckboxes.isEmpty()) {
        	// validate ada for Violation section and then expose accident section
        	WebElement accidentCheckbox = accidentCheckboxes.get(0);
        	waitAndClickElement(accidentCheckbox);
        	wait.until(ExpectedConditions.attributeContains(accidentCheckbox, "aria-checked", "true"));
        	List<WebElement> violationToggles = driver().findElements(By.xpath(VIOLATION_TOGGLE_XPATH));
        	waitAndClickElement(violationToggles.get(0));
        	scrollAndClickOnElement(continueButton);
        	performADATesting(this.getClass().getSimpleName() + "_ViolationToggleSection", MARKETING_IT, ACE_AUTO);
        	// reset back to accident toggle
        	List<WebElement> accidentToggles = driver().findElements(By.xpath(ACCIDENT_TOGGLES_XPATH));
        	waitAndClickElement(accidentToggles.get(0));
        }

        // expose financial filing checkboxes
        for (WebElement financialFilingCheckbox : financialFilingCheckboxes) {
            waitAndClickElement(financialFilingCheckbox);
        }

        scrollAndClickOnElement(continueButton);
        waitElementBeVisible(ctaErrorMessage);

        // ada validation with page as much as exposed
        performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);

        // set values to the default
        for (WebElement hadTheirDriverLicenseCheckbox : hadTheirDriverLicenseCheckboxes) {
            waitAndClickElement(hadTheirDriverLicenseCheckbox);
        }

        waitAndClickElement(accidentCheckboxes.get(0));


        for (WebElement financialFilingCheckbox : financialFilingCheckboxes) {
            waitAndClickElement(financialFilingCheckbox);
        }

        // validate ADA for occupation sidesheet if present
        if (!seeEligibleOccupations.isEmpty()) {
            waitAndClickElement(seeEligibleOccupations.get(0));
            waitAndClickElement(retiredToggle);
            if (isElementVisible(closeOrSaveButtonOccupationSideSheet, 2)) {
                scrollAndClickOnElement(closeOrSaveButtonOccupationSideSheet);
            }
            performADATesting(this.getClass().getSimpleName() + "_OccupationSideSheetRetiredToggle", MARKETING_IT, ACE_AUTO);
            waitAndClickElement(employedToggle);
            scrollAndClickOnElement(closeOrSaveButtonOccupationSideSheet);
            performADATesting(this.getClass().getSimpleName() + "_OccupationSideSheetEmployedToggle", MARKETING_IT, ACE_AUTO);
            waitAndClickElement(closeIcon);
        }

        // validate ada for add spouse side sheet
        WebElement maritalCheckbox = driver().findElement(By.xpath(MARITAL_CHECKBOX_XPATH + "//input"));
        scrollAndClickOnHiddenElement(maritalCheckbox);
        waitElementBeVisible(addDriverHeading);
        waitAndClickElement(listOfSaveButtons.get(0));
        performADATesting(this.getClass().getSimpleName() + "_AddSpouseSideSheet", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(closeIcon);

        // validate ada for edit button
        WebElement editDriverButton = editDriverButtons.get(0);
        waitAndClickElement(editDriverButton);
        performADATesting(this.getClass().getSimpleName() + "_EditDriverSideSheet", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(closeIcon);


    }

    public void validateGoodStudentOption(AutoApplicant applicant, boolean isDiscountSelected) throws Exception {

        String applicantFullName = getApplicantFullName(applicant);
        String applicantCardXpath = getDriverCardXpathByFullName(applicantFullName);
        String applicantHasGpaCheckboxXpath = applicantCardXpath + GPA_OVER_3_CHECKBOX_XPATH;
        String applicantGPASubTextLblWithLessThan10YearsLicenseXpath = applicantCardXpath + MUST_BE_A_FULL_TIME_STUDENT_AND_LICENSED_LESS_THAN_10_YEARS_XPATH;

        SqlAdditionalDriver sqlAdditionalDriver = applicant.getAdditionalDrivers().get(0);
        String additionalDriverFullName = sqlAdditionalDriver.getFirstName() + SPACE + sqlAdditionalDriver.getLastName();
        String additionalDriverCardXpath = getDriverCardXpathByFullName(additionalDriverFullName);
        String additionalDriverGPACheckboxXpath = additionalDriverCardXpath + GPA_OVER_3_CHECKBOX_XPATH;
        String additionalDriverGPAInputXpath = additionalDriverCardXpath + GPA_OVER_3_INPUT_XPATH;
        String additionalDriverGPASubTextLblXpath = additionalDriverCardXpath + MUST_BE_A_FULL_TIME_STUDENT_LABEL_XPATH;
        String additionalDriverGPASubTextLblWithLessThan10YearsLicenseXpath = additionalDriverCardXpath + MUST_BE_A_FULL_TIME_STUDENT_AND_LICENSED_LESS_THAN_10_YEARS_XPATH;

        String stateCode = applicant.getStateCode();

        testStepAssert(!isElementPresent(By.xpath(applicantHasGpaCheckboxXpath), 1), "Has a GPA over 3.0 checkbox should not displaying for the driver 25 years old or above");

        if (Arrays.asList(NC, MA).contains(stateCode)) {
            if (stateCode.equals(MA)) {
                enterDriverLicenseAge(applicant, applicantFullName, 24);
                enterDriverLicenseAge(applicant, additionalDriverFullName, sqlAdditionalDriver.getFirstAgeUnitedStatesDriverLicense());
                testStepAssert(isElementPresent(By.xpath(applicantGPASubTextLblWithLessThan10YearsLicenseXpath), 1), "Has a GPA over 3.0 subtitle expected");
                testStepAssert(isElementPresent(By.xpath(applicantHasGpaCheckboxXpath), 1), "Has a GPA over 3.0 checkbox should be present when Driver got DL in the last 10 years for the state of MA");
                enterDriverLicenseAge(applicant, applicantFullName, 23);
                testStepAssert(!isElementPresent(By.xpath(applicantGPASubTextLblWithLessThan10YearsLicenseXpath), 1), "Has a GPA over 3.0 subtitle expected");
                testStepAssert(!isElementPresent(By.xpath(applicantHasGpaCheckboxXpath), 1), "Has a GPA over 3.0 checkbox should NOT be present when Driver got DL more or 10 years ago");
            }

            if (stateCode.equals(NC)) {
                addHadDriversLicense(additionalDriverFullName, sqlAdditionalDriver.getFirstAgeUnitedStatesDriverLicense());
            }
            testStepAssert(isElementPresent(By.xpath(additionalDriverGPASubTextLblWithLessThan10YearsLicenseXpath), 1), "Has a GPA over 3.0 subtitle expected");
        } else {
            testStepAssert(isElementPresent(By.xpath(additionalDriverGPASubTextLblXpath), 1), "Has a GPA over 3.0 subtext expected");
        }
        testStepAssert(isElementPresent(By.xpath(additionalDriverGPACheckboxXpath), 1), "Has a GPA over 3.0 checkbox should be displaying for the driver 24 years old or less");

        setMaritalRelationship(applicantFullName, additionalDriverFullName);

        if (!stateCode.equals(MA)) {
            testStepAssert(stateCode.equals(MT) == isElementPresent(By.xpath(additionalDriverGPACheckboxXpath), 1),
                    "Has a GPA over 3.0 checkbox should not be displaying for the married driver regardless of the age except for MT");
        }

        removeMaritalRelation(getMaritalCheckbox(applicantFullName));

        testStepAssert(isElementPresent(By.xpath(additionalDriverGPACheckboxXpath), 1), "Has a GPA over 3.0 checkbox should be displaying for the driver 24 years old or less after removing the marital status");

        if (Arrays.asList(NC, MA).contains(stateCode)) {
            testStepAssert(isElementPresent(By.xpath(additionalDriverGPASubTextLblWithLessThan10YearsLicenseXpath), 1), "Has a GPA over 3.0 subtitle expected");
        } else {
            testStepAssert(isElementPresent(By.xpath(additionalDriverGPASubTextLblXpath), 1), "Has a GPA over 3.0 subtext expected");
        }

        reviewAllDrivers(applicant, Optional.empty());

        // checking the aria checked true/false as reviewAllDrivers is already making selection for good student checkbox
        WebElement gpaCheckBox = driver().findElement(By.xpath(additionalDriverGPAInputXpath));
        if (isDiscountSelected) {
        	if(isCheckboxNotSelected(gpaCheckBox)) {
                scrollAndClickOnHiddenElement(gpaCheckBox);
        	}
        } else {
            if (isCheckboxSelected(gpaCheckBox)) {
                scrollAndClickOnHiddenElement(gpaCheckBox);
            }
        }
        reviewDiscountSection("Drivers-reviewPage");
        scrollAndClickOnHiddenElement(continueButton);
    }

    public void validateDistantStudentOption(AutoApplicant applicant, boolean discountSelected) throws Exception {

        String stateCode = applicant.getStateCode();
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();

        // additional driver one details and xpaths
        SqlAdditionalDriver twentyFourYearOldDriver = additionalDrivers.stream().filter(driver -> driver.getAge() == 24).collect(Collectors.toList()).get(0);
        String fullNameFor24 = twentyFourYearOldDriver.getFirstName() + SPACE + twentyFourYearOldDriver.getLastName();
        String driverCardFor24 = getDriverCardXpathByFullName(fullNameFor24);
        String distantStudentCheckboxXpathFor24 = driverCardFor24 + DISTANT_STUDENT_XPATH;
        String distantStudentSubtextXpathFor24 = driverCardFor24 + DISTANT_STUDENT_SUBTEXT_XPATH;

        //additional driver two details and xpaths
        SqlAdditionalDriver twentyThreeYearOldDriver = additionalDrivers.stream().filter(driver -> driver.getAge() == 23).collect(Collectors.toList()).get(0);
        String fullNameFor23 = twentyThreeYearOldDriver.getFirstName() + SPACE + twentyThreeYearOldDriver.getLastName();
        String driverCardFor23 = getDriverCardXpathByFullName(fullNameFor23);
        String distantStudentCheckboxXpathFor23 = driverCardFor23 + DISTANT_STUDENT_XPATH;
        String distantStudentSubtextXpathFor23 = driverCardFor23 + DISTANT_STUDENT_SUBTEXT_XPATH;

        // additional driver three details and xpaths
        SqlAdditionalDriver twentyTwoYearOldDriver = additionalDrivers.stream().filter(driver -> driver.getAge() == 22).collect(Collectors.toList()).get(0);
        String fullNameFor22 = twentyTwoYearOldDriver.getFirstName() + SPACE + twentyTwoYearOldDriver.getLastName();
        String driverCardFor22 = getDriverCardXpathByFullName(fullNameFor22);
        String distantStudentCheckboxXpathFor22 = driverCardFor22 + DISTANT_STUDENT_XPATH;
        String distantStudentSubtextXpathFor22 = driverCardFor22 + DISTANT_STUDENT_SUBTEXT_XPATH;

        // additional driver four details and xpaths
        SqlAdditionalDriver twentyOneYearOldDriver = additionalDrivers.stream().filter(driver -> driver.getAge() == 21).collect(Collectors.toList()).get(0);
        String fullNameFor21 = twentyOneYearOldDriver.getFirstName() + SPACE + twentyOneYearOldDriver.getLastName();
        String driverCardFor21 = getDriverCardXpathByFullName(fullNameFor21);
        String distantStudentCheckboxXpathFor21 = driverCardFor21 + DISTANT_STUDENT_XPATH;
        String distantStudentSubtextXpathFor21 = driverCardFor21 + DISTANT_STUDENT_SUBTEXT_XPATH;

        String expectedDistantStudentSubtext;

        if (isFlexState(stateCode)) {
            testStepAssert(isElementPresent(By.xpath(distantStudentCheckboxXpathFor24), 1), "Distant Student Checkbox should be present for 24 years old in FFPA-Flex- states, Please check for " + fullNameFor24);
            testStepAssert(isElementPresent(By.xpath(distantStudentCheckboxXpathFor23), 1), "Distant Student Checkbox should be present for 23 years old in FFPA-Flex- states, Please check for " + fullNameFor23);

            //subtext
            expectedDistantStudentSubtext = "Must be a full-time student";
            testStepAssert(getTextFromElement(driver().findElement(By.xpath(distantStudentSubtextXpathFor21))), expectedDistantStudentSubtext, "Flex state distant student subtext validated for " + fullNameFor21);
            testStepAssert(getTextFromElement(driver().findElement(By.xpath(distantStudentSubtextXpathFor22))), expectedDistantStudentSubtext, "Flex state distant student subtext validated for " + fullNameFor22);
            testStepAssert(getTextFromElement(driver().findElement(By.xpath(distantStudentSubtextXpathFor23))), expectedDistantStudentSubtext, "Flex state distant student subtext validated for " + fullNameFor23);
            testStepAssert(getTextFromElement(driver().findElement(By.xpath(distantStudentSubtextXpathFor24))), expectedDistantStudentSubtext, "Flex state distant student subtext validated for " + fullNameFor24);
        } else if (stateCode.equals(CA)) {
            enterDriverLicenseAge(applicant, getApplicantFullName(applicant), applicant.getFirstAgeUnitedStatesDriverLicense());
            enterDriverLicenseAge(applicant, fullNameFor24, 15);
            testStepAssert(!isElementPresent(By.xpath(distantStudentSubtextXpathFor24), 1), "Distant Student checkbox should not be visible when DL obtained 9 or more years ago for " + fullNameFor24);
            enterDriverLicenseAge_CA(fullNameFor23, 15);
            enterDriverLicenseAge_CA(fullNameFor22, 16);
            enterDriverLicenseAge_CA(fullNameFor21, 17);
            testStepAssert(isElementPresent(By.xpath(distantStudentCheckboxXpathFor23), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor23);
            testStepAssert(isElementPresent(By.xpath(distantStudentCheckboxXpathFor22), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor22);
            testStepAssert(isElementPresent(By.xpath(distantStudentCheckboxXpathFor21), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor21);

            // Subtext
            expectedDistantStudentSubtext = "Must be a full-time student and licensed for less than 9 years.";
            testStepAssert(getTextFromElement(driver().findElement(By.xpath(distantStudentSubtextXpathFor21))), expectedDistantStudentSubtext, "CA state distant student subtext validated for " + fullNameFor21);
            testStepAssert(getTextFromElement(driver().findElement(By.xpath(distantStudentSubtextXpathFor22))), expectedDistantStudentSubtext, "CA state distant student subtext validated for " + fullNameFor22);
            testStepAssert(getTextFromElement(driver().findElement(By.xpath(distantStudentSubtextXpathFor23))), expectedDistantStudentSubtext, "CA state distant student subtext validated for " + fullNameFor23);

            setMaritalRelationship(fullNameFor22, fullNameFor21);
            // Distant Student Checkbox should still be visible after marriage as long as
            testStepAssert(isElementPresent(By.xpath(distantStudentCheckboxXpathFor22), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor22);
            testStepAssert(isElementPresent(By.xpath(distantStudentCheckboxXpathFor21), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor21);
            removeMaritalRelation(getMaritalCheckbox(fullNameFor22));

            // for these states distant student discount is not applicaple
        } else if (Arrays.asList(KY, LA, MA, MS, NC, RI).contains(stateCode)) {
            testStepAssert(!isElementPresent(By.xpath(distantStudentCheckboxXpathFor21), 1), "Distant student checkbox should not be visible for the given state: " + stateCode);
            reviewAllDrivers(applicant, Optional.empty());
            clickContinueButton();
            return;
        } else {
            testStepAssert(!isElementPresent(By.xpath(distantStudentCheckboxXpathFor24), 1), "Distant Student Checkbox should NOT be present for 24 years old in FSPA states, Please check for " + fullNameFor24);
            testStepAssert(!isElementPresent(By.xpath(distantStudentCheckboxXpathFor23), 1), "Distant Student Checkbox should NOT be present for 23 years old in FSPA states, Please check for " + fullNameFor23);

            expectedDistantStudentSubtext = String.format("Must be a full-time student and a child of %s (primary named insured)", applicant.getFirstName());
            testStepAssert(getTextFromElement(driver().findElement(By.xpath(distantStudentSubtextXpathFor21))), expectedDistantStudentSubtext, "FSPA state distant student subtext validated for " + fullNameFor21);
            testStepAssert(getTextFromElement(driver().findElement(By.xpath(distantStudentSubtextXpathFor22))), expectedDistantStudentSubtext, "FSPA state distant student subtext validated for " + fullNameFor22);

        }

        //these checks applicable to all states for Distant Student Discount
        testStepAssert(isElementPresent(By.xpath(distantStudentCheckboxXpathFor21), 1), "Distant Student Checkbox should be present for 21 years old. Driver fullName: " + fullNameFor21);
        testStepAssert(isElementPresent(By.xpath(distantStudentCheckboxXpathFor22), 1), "Distant Student Checkbox should be present for 22 years old. Driver fullName: " + fullNameFor22);

        // validate marital condition (Not applicaple for CA)
        if (!stateCode.equals(CA)) {
            setMaritalRelationship(fullNameFor22, fullNameFor21);
            testStepAssert(!isElementPresent(By.xpath(distantStudentCheckboxXpathFor22), 1), "Distant Student checkbox should not be visible when DL obtained 8 or less years ago when married for " + fullNameFor22);
            testStepAssert(!isElementPresent(By.xpath(distantStudentCheckboxXpathFor21), 1), "Distant Student checkbox should not be visible when DL obtained 8 or less years ago when married for " + fullNameFor21);
            removeMaritalRelation(getMaritalCheckbox(fullNameFor22));
            testStepAssert(isElementPresent(By.xpath(distantStudentCheckboxXpathFor22), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor22);
            testStepAssert(isElementPresent(By.xpath(distantStudentCheckboxXpathFor21), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor21);
        }

        if (discountSelected) {
            scrollAndClickOnHiddenElement(driver().findElement(By.xpath(getDriverCardXpathByFullName(fullNameFor21) + DISTANT_STUDENT_CHECKBOX_INPUT_XPATH)));
            reviewDiscountSection("Drivers-reviewPage");
        }

        reviewAllDrivers(applicant, Optional.empty());
        clickContinueButton();

    }

    public void validateSharedFamilyCarOption(boolean optionExpected, boolean optionSelected) throws Exception {
        WebElement driverAgeElement = waitElementBeVisible(driver().findElement(By.xpath("(" + DRIVER_AGE_XPATH_END + ")[2]")));
        String ageText = getTextFromElement(driverAgeElement).trim();
        boolean sharedFamilyCarDisplayed = isElementDisplayed(lblSharesVehicleUsage, 5);
        String expectedModifier = optionExpected ? SPACE : NOT;
        String actualModifier = sharedFamilyCarDisplayed ? SPACE : NOT;
        testStepAssert(sharedFamilyCarDisplayed == optionExpected, "Expected: Shares vehicle usage in household checkbox should" + expectedModifier + "be displayed if driver age<25. Actual: Shares vehicle usage in household checkbox is" + actualModifier + "displayed for driver (" + ageText + ")");
        if (sharedFamilyCarDisplayed && optionSelected) {
            scrollAndClickOnElement(chkSharesVehicleUsage);
        }
    }

    public void enterAgeDriverReceivedTheirLicenseTxt_DriverReviewPage(AutoApplicant applicant) throws Exception {
        if (isAskingDriverLicenseAgeState(applicant.getStateCode())) {
            WebElement driverAgeElement = waitElementBeVisible(driver().findElement(By.xpath("(" + DRIVER_AGE_XPATH_END + ")[1]")));
            String ageTextTmp = getTextFromElement(driverAgeElement).trim();
            String ageText = ageTextTmp.substring(ageTextTmp.length() - 2);
            int ageLicenseTmp = Integer.parseInt(ageText);
            int ageLicense = ageLicenseTmp - 8;
            WebElement licenseAgeInputField = driver().findElement(By.xpath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + LICENSE_AGE_INPUT_FIELD_XPATH));
            sendKeysToElement(licenseAgeInputField, Integer.toString(ageLicense));
            sendKeysToElement(licenseAgeInputField, Keys.TAB);
            waitForSpinnerToBeGone();
        }
    }

    public void enterDriverLicenseInfoTxt_DriverReviewPage(AutoApplicant applicant) throws Exception {
        String pniFullName = getApplicantFullName(applicant);
        addDriverLicenseNumber(applicant, pniFullName);
    }

    public void clickHasDriverLicenseForLessThan3YrsChk_DriverReviewPage(AutoApplicant applicant) throws Exception {
        addHadDriversLicense(getApplicantFullName(applicant), applicant.getFirstAgeUnitedStatesDriverLicense());
    }

    public void proceedToQuoteSummaryPage(AutoApplicant applicant) throws Exception {
        if(!isBDQFlowEnabled() && !isOnBristolWest()){
            SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
            if (signalPageOneUI.isOnSignalPage()) {
                List<SqlDiscount> applicantDiscounts = applicant.getDiscounts();
                if (applicantDiscounts.isEmpty()) {
                    signalPageOneUI.processSignalPage(false);
                } else {
                    signalPageOneUI.processSignalPage(applicantDiscounts.get(0).isSignalSignup());
                }
            }
        }

        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.isOnContactInfoAutoPage();
        contactInfoAutoPage.setValuesAndContinue(applicant);
        contactInfoAutoPage.waitForSpinnerToBeGone();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        if (quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            return;
        }
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            String stateCode = applicant.getStateCode();
            if (stateCode.equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else if (Arrays.asList(CA,NC).contains(stateCode)) {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
        }
        SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
        if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
            selectAQuoteToReviewPage.clickContinueMyQuote();
        }
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if(bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            bwFarmersQuotePresentmentPage.continueWithFarmers();
        }
        if (!quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            throw new IllegalStateException("Did not reach QuoteSummaryAutoPage");
        }
    }

    public void fillOutDriverLicenseAges() throws Exception {
        if (getSessionStorageAppStore().getData().getLandingStateCode().equals(CA)) {
            List<String> displayedDrivers = getDisplayedDrivers();
            for (String displayedDriver : displayedDrivers) {
                enterDriverLicenseAge_CA(displayedDriver, 16);
            }
        }
        List<WebElement> ageInputElements = driver().findElements(By.xpath(LICENSE_AGE_INPUT_FIELD_XPATH));
        for (WebElement ageInputElement : ageInputElements) {
            scrollToElement(ageInputElement);
            sendKeysToElement(ageInputElement, 16);
        }

    }

    public List<String> getDisplayedDrivers() throws Exception {
        List<String> driversList = new ArrayList<>();
        for (WebElement element : driver().findElements(By.xpath(LIST_OF_DRIVERS_XPATH))) {
            driversList.add(getTextFromElement(element));
        }
        return driversList;
    }

    public void validateDisplayedDrivers_ADPFData(ADPFApplicant applicant) throws Exception {
        if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            Log.info("Vehicles Drivers consolidation is implemented for state: " + applicant.getStateCode() + ", skipping ADPF data validation on Drivers page.");
            return;
        }
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        String applicantFullName = applicant.getFirstName() + SPACE + applicant.getLastName();
        heresWhatWeFoundPage.addADPFApplicant(Optional.empty(), applicantFullName, applicant.getGender(), applicant.getDateOfBirth());
        List<String> displayedCompleteDrivers = heresWhatWeFoundPage.getDisplayedCompleteDrivers();
        testStep("The displayed drivers from Here's what we found page is captured", true);
        heresWhatWeFoundPage.clickContinueButton();
        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        vehicleReviewPage.isOnVehiclesReviewPage();
        vehicleReviewPage.clickContinueButton();
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        testStepAssert(isOnDriverReviewPage(), "User is on the driver review page");
        List<String> displayedDriversOnDriversPage = driverReviewPage.getDisplayedDrivers();
        Log.info("List of complete drivers returned from adpf: " + displayedCompleteDrivers);
        Log.info("List of driver review page dispalyed drivers: " + displayedDriversOnDriversPage);
        testStepAssert(displayedCompleteDrivers.equals(displayedDriversOnDriversPage), "Validate multiple Drivers scenario- PNI +Spouse+Additional driver - ADPF(test scenario)", true);
    }

    public void validateDisplayedDrivers_NonAdpf(AutoApplicant applicant) throws Exception {
        applicant.setOccupation(EMPTY_STRING);
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
        whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
        whoShouldWeInsurePage.enterEmailAndPhoneNumber(applicant);
        List<String> displayedCompleteDriversWSWIPage = whoShouldWeInsurePage.getDisplayedCompleteDrivers();
        Log.info("Who Should We Insure page displayed vehicles: " + displayedCompleteDriversWSWIPage);
        testStep("Drivers from Who Should we insure page is captured", true);
        whoShouldWeInsurePage.clickOnContinueButton();
        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        vehicleReviewPage.isOnVehiclesReviewPage();
        vehicleReviewPage.setVehicleUsagesToPersonal();
        vehicleReviewPage.clickContinueButton();
        testStepAssert(isOnDriverReviewPage(), "User is on Driver Review page");
        reviewAllDrivers(applicant, Optional.empty());
        List<String> displayedDriversOnDriverReviewPage = getDisplayedDrivers();
        Log.info("Driver review page displayed vehicles: " + displayedDriversOnDriverReviewPage);
        testStepAssert(displayedCompleteDriversWSWIPage.equals(displayedDriversOnDriverReviewPage), "Validate multiple Drivers scenario- PNI +Spouse+Additional driver - Non- ADPF(test scenario)");

    }

    public void fillOutDriverLicenseNumbers() throws Exception {
        List<WebElement> driverLicenseNumbersInputFields = driver().findElements(By.xpath(DRIVER_LICENSE_NUMBER_INPUT_XPATH));
        for (WebElement inputFields : driverLicenseNumbersInputFields) {
            Faker faker = new Faker();
            scrollToElement(inputFields);
            String driverLicenseNumber = faker.drivingLicense().drivingLicense(getSessionStorageAppStore().getData().getLandingStateCode());
            sendKeysToElement(inputFields, driverLicenseNumber);
            sendKeysToElement(inputFields, Keys.TAB);
            waitForSpinnerToBeGone();
        }
    }

    private void updateIncidentsWithSessionStorageData(List<SqlIncident> incidents) throws Exception {
        List<String> accidentsAvailable = getSessionStorageAppStore().getAuto().getDriverReview().getFetchIncidentCategoryList().getIncidentTypeACC().getDropDownValues().stream().map(each -> each.getWebDesc()).collect(Collectors.toList());
        List<String> violationsAvailable = getSessionStorageAppStore().getAuto().getDriverReview().getFetchIncidentCategoryList().getIncidentTypeUCC().getDropDownValues().stream().map(each -> each.getWebDesc()).collect(Collectors.toList());
        for (SqlIncident incident : incidents) {
            if (incident.getIncidentType().equals(ACCIDENT)) {
                int randomIndex = new Random().nextInt(accidentsAvailable.size());
                String description = accidentsAvailable.get(randomIndex);
                if (description.equals("Accident was not driver's fault")) {
                    description = "Accident was not driver";
                }
                if (description.equals("At-fault accident resulting in Property Damage")) {
                    description = "fault accident resulting in Property Damage";
                }
                incident.setDescription(description);
            } else {
                int randomIndex = new Random().nextInt(violationsAvailable.size());
                incident.setDescription(violationsAvailable.get(randomIndex));
            }
        }
    }


    public void validateNonDriverFunctionality(AutoApplicant applicant, FarmersSoftAssert fsa, boolean randomWillBeDriving, boolean randomForeignDl) throws Exception {
        String stateCode = applicant.getStateCode();
        isOnDriverReviewPage();
        clickElement(getMaritalCheckbox(getApplicantFullName(applicant)));
        if (isElementPresent(By.xpath("//label[contains(.,'someone not listed here')]//ancestor::mat-radio-button//input"), 1)) {
            getAndClickSpouseTo("someone not listed here");
        }

        fsa.assertEquals(getTextFromElement(addDriverHeading), "Add a spouse", "Spouse side sheet header verification");
        enterSpouseInformation(applicant, randomWillBeDriving, randomForeignDl);
        AppStore.Auto.Driver sni = getSessionStorageAppStore().getAuto().getDrivers().stream().filter(each -> each.getPni().equals("X")).collect(Collectors.toList()).get(0);
        String spouseFullName = sni.getFirstName() + SPACE + sni.getLastName();

        fsa.assertTrue(isSnackBarMessageDisplayed("Your spouse has been added to policy."), "Your spouse has been added to policy snackbar showing correclty");
        waitAndClickElement(getEditButtonByDriverFullName(spouseFullName));
        for (WebElement saveButton : listOfSaveButtons) {
            sleep(2);
            waitAndClickElement(saveButton);
        }
        testStep("Snackabr for spouse info adjustment", true);
        wait.until(ExpectedConditions.visibilityOf(snackBar));
        fsa.assertTrue(isSnackBarMessageDisplayed("Your spouse has been updated."), "Your spouse has been updated snackbar showing correctly");
        String nonDriverLabelXpath = "//span[@class='non-driver-label ng-star-inserted']";

        String driverCardXpathByFullName = getDriverCardXpathByFullName(spouseFullName);
        fsa.assertEquals(!randomWillBeDriving, isElementPresent(By.xpath(driverCardXpathByFullName + nonDriverLabelXpath), 2), "Non Driver label presence validation");

        //validate accident checkbox and occupation field is present for the spouse

        fsa.assertEquals(!isEmploymentDisabledState(stateCode) && randomWillBeDriving, isElementPresent(By.xpath(driverCardXpathByFullName + SEE_ELIGIBLE_OCCUPATIONS_XPATH), 1), "See eligible occupation link presence validated");
        int displayedDriverSizeOnDriverReviewPage = getDisplayedDrivers().size();
        fsa.assertEquals(randomWillBeDriving, accidentQuestions.size() == displayedDriverSizeOnDriverReviewPage, "Accident checkbox presence validated");


        if(displayedDriverSizeOnDriverReviewPage > 2) {
            // ad spouse for additional driver
            List<String> displayedDrivers = getDisplayedDrivers();
            displayedDrivers.remove(getApplicantFullName(applicant));
            displayedDrivers.remove(spouseFullName);
            clickElement(getMaritalCheckbox(displayedDrivers.get(0)));
            if (isElementPresent(By.xpath("//label[contains(.,'someone not listed here')]//ancestor::mat-radio-button//input"), 1)) {
                getAndClickSpouseTo("someone not listed here");
            }
            fsa.assertEquals(getTextFromElement(addDriverHeading), "Add a spouse", "Spouse side sheet header validation");
            enterSpouseInformation(applicant, randomWillBeDriving, randomForeignDl);
        }
        displayedDriverSizeOnDriverReviewPage = getDisplayedDrivers().size();

        List<String> drivingDrivers = getDisplayedDrivers().stream().filter(each -> !each.contains("Non-Driver")).collect(Collectors.toList());
        for (String drivingDriver : drivingDrivers) {
            enterDriverLicenseAge_CA(drivingDriver, 16);
        }

        // fill out occupation section if present
        fillOutOccupationAffinitySection();

        clickContinueButton();
        SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
        if (!signalPageOneUI.isSignalDiscountDisabledState(stateCode)) {
            signalPageOneUI.processSignalPage(applicant.getDiscounts().get(0).isSignalSignup());
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.setValuesAndContinue(applicant);

        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            vehicleDriverAssignmentPage.clickOnFirstVehicleMatSelection();
            List<String> displayedDriverList = vehicleDriverAssignmentPage.getAvailableDriverMatOptions().stream().map(this::getTextFromElement).collect(Collectors.toList());
            fsa.assertEquals(randomWillBeDriving, (displayedDriverList.contains(spouseFullName) && displayedDriverList.size() == displayedDriverSizeOnDriverReviewPage), "Is driver spouse listed as an option in the vehicle driver assignment page check");
            driver().navigate().refresh();
            vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
        }
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if (bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            bwFarmersQuotePresentmentPage.continueWithFarmers();
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
        }
    }

    public void validateIsRideShareDriverCheckbox(FarmersSoftAssert fsa, boolean isCheckboxExpected) throws Exception {
        List<String> displayedDrivers = getDisplayedDrivers();
        for (String displayedDriver : displayedDrivers) {
            By currentDriverIsRideShareBy = By.xpath(getDriverCardXpathByFullName(displayedDriver) + IS_A_RIDE_SHARE_XPATH);
            if(isCheckboxExpected) {
                fsa.assertEquals(getTextFromElement(driver().findElement(currentDriverIsRideShareBy)), "Is a rideshare driver", "RideShareDriverCheckbox verification");
                scrollAndClickOnHiddenElement(continueButton);
                fsa.assertEquals(getTextFromElement(ctaErrorMessage), "For Rideshare coverage, at least one driver must be selected as a Rideshare driver", "RideShareDriver error verification");
            } else {
                fsa.assertTrue(!isElementDisplayed(currentDriverIsRideShareBy), "Rideshare driver checkbox should not be displayed");
            }
        }
    }

    public void clickIsRideShareDriverCheckbox(String fullName) throws Exception {
        WebElement isRideShareDriverCheckbox = driver().findElement(By.xpath(getDriverCardXpathByFullName(fullName) + IS_A_RIDE_SHARE_XPATH + "//input"));
        scrollAndClickOnElement(isRideShareDriverCheckbox);
    }

    public void selectNoForCurrentOrFormerProfessionalToggle() throws Exception {
        String noToggleXpath = "//fieldset//button[contains(.,'No')]";
        if (isElementPresent(By.xpath(noToggleXpath))) {
            for (WebElement element : driver().findElements(By.xpath(noToggleXpath))) {
                scrollAndClickOnElement(element);
                wait.until(d -> isButtonSelected(element));
            }
        }
    }

    public void processDriverReviewPageForCrossSellAndPartnerFlow(AutoApplicant applicantAuto) throws Exception {
        String applicantFullName = applicantAuto.getFirstName() + SPACE + applicantAuto.getLastName();
        boolean isMarriedApplicant = applicantAuto.getMaritalStatus().equals(MARRIED);
        String spouseFullName = null;
        SqlAdditionalDriver sqlAdditionalDriver = new SqlAdditionalDriver();
        if (isMarriedApplicant) {
            sqlAdditionalDriver = applicantAuto.getAdditionalDrivers().get(0);
            spouseFullName = sqlAdditionalDriver.getFirstName() + SPACE + sqlAdditionalDriver.getLastName();
        }
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        driverReviewPage.enterDriverLicenseAge(applicantAuto, applicantFullName, applicantAuto.getFirstAgeUnitedStatesDriverLicense());
        driverReviewPage.addDriverLicenseNumber(applicantAuto, applicantFullName);
        if (isMarriedApplicant) {
            driverReviewPage.enterDriverLicenseAge(applicantAuto, spouseFullName, sqlAdditionalDriver.getFirstAgeUnitedStatesDriverLicense());
            driverReviewPage.addDriverLicenseNumber(applicantAuto, spouseFullName);
            testStepAssert(driverReviewPage.getMaritalCheckbox(applicantFullName).isSelected(), "Marital checkbox should be checked for married driver");
            //testStepAssert(!driverReviewPage.getMaritalCheckbox(applicantFullName).isEnabled(), "Marital checkbox should be disabled for married driver");
            testStepAssert(driverReviewPage.getMaritalCheckbox(spouseFullName).isSelected(), "Marital checkbox should be checked for married driver");
            testStepAssert(!driverReviewPage.getMaritalCheckbox(spouseFullName).isEnabled(), "Marital checkbox should be disabled for married driver");
        }
        driverReviewPage.clickContinueButton();
    }

    public void validateFinancialFillingCaseNumberField(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
    	String applicantFullname = getApplicantFullName(applicant);
    	WebElement financialFilingCheckbox = getFinancialFilingCheckbox(applicantFullname);
    	scrollAndClickOnElement(financialFilingCheckbox);
    	boolean isCheckboxChecked = isCheckboxSelected(financialFilingCheckbox);
    	if (!isCheckboxChecked) {
    		waitAndClickElement(financialFilingCheckbox);
    		isCheckboxChecked = isCheckboxSelected(financialFilingCheckbox);
    	}
    	fsa.assertTrue(isCheckboxChecked, "Financial filling checkbox checked");
    	if (isCheckboxChecked) {
    		WebElement floridaButton = driver().findElement(By.xpath(getDriverCardXpathByFullName(applicantFullname) + "//button[contains(., 'Florida')]"));
    		WebElement anotherStateButton = getAnotherStateButton(applicantFullname);
    		fsa.assertTrue(!floridaButton.isSelected() && !anotherStateButton.isSelected(), "None of the two buttons selected by default");
    		//DE273011 - Error not produced when no button selected, so skipping that test since we would continue to next page
//    		clickElement(continueButton);
//    		fsa.assertEquals(getTextFromElement(financialStateSelectionErrorLabel), "Please select which state requires filing", "Error message should show when no button selected");
    		clickElement(floridaButton);
    		clickElement(continueButton);
    		WebElement floridaCaseInputFieldErrorLabel = driver().findElement(By.xpath(getDriverCardXpathByFullName(applicantFullname) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//mat-error"));
    		fsa.assertEquals(getTextFromElement(floridaCaseInputFieldErrorLabel), ENTER_VALID_CASE_NUMBER, "Error message should show when no input for case number");
    		// Use invalid characters
    		clickElement(anotherStateButton);
    		clickElement(floridaButton);
    		WebElement floridaCaseInputField = driver().findElement(By.xpath(getDriverCardXpathByFullName(applicantFullname) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//input[not(@type)]"));
    		enterValueInField("ABC", floridaCaseInputField, "Invalid characters in case number");
    		clickElement(continueButton);
    		fsa.assertEquals(getTextFromElement(floridaCaseInputFieldErrorLabel), ENTER_VALID_CASE_NUMBER, "Error message should show when invalid characters in case number");
    		//Incomplete number
    		clickElement(anotherStateButton);
    		clickElement(floridaButton);
    		floridaCaseInputField = driver().findElement(By.xpath(getDriverCardXpathByFullName(applicantFullname) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//input[not(@type)]"));
    		enterValueInField("1345780", floridaCaseInputField, "Incomplete case number");
    		clickElement(continueButton);
    		fsa.assertEquals(getTextFromElement(floridaCaseInputFieldErrorLabel), ENTER_VALID_CASE_NUMBER, "Error message should show when incomplete input for case number");
    		// Sequential number
    		clickElement(anotherStateButton);
    		clickElement(floridaButton);
    		floridaCaseInputField = driver().findElement(By.xpath(getDriverCardXpathByFullName(applicantFullname) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//input[not(@type)]"));
    		enterValueInField("123456789", floridaCaseInputField, "Invalid case number");
    		clickElement(continueButton);
    		fsa.assertEquals(getTextFromElement(floridaCaseInputFieldErrorLabel), ENTER_VALID_CASE_NUMBER, "Error message should show when invalid input (sequential numbers) for case number");
    		// Repeated digit
    		clickElement(anotherStateButton);
    		clickElement(floridaButton);
    		floridaCaseInputField = driver().findElement(By.xpath(getDriverCardXpathByFullName(applicantFullname) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//input[not(@type)]"));
    		String repeatedDigit = String.valueOf(new Random().nextInt(10)).repeat(9);
    		enterValueInField(repeatedDigit, floridaCaseInputField, "Repeat number");
    		clickElement(continueButton);
    		fsa.assertEquals(getTextFromElement(floridaCaseInputFieldErrorLabel), ENTER_VALID_CASE_NUMBER, "Error message should show when case number is same digit repeated: " + repeatedDigit);
    		// Valid case number
    		clickElement(anotherStateButton);
    		clickElement(floridaButton);
    		floridaCaseInputField = driver().findElement(By.xpath(getDriverCardXpathByFullName(applicantFullname) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//input[not(@type)]"));
    		Faker faker = new Faker();
    		enterValueInField(faker.expression("#{numerify '#########'}"), floridaCaseInputField, "Case number");
    		clickContinueButton();
    	}
    }

    public void clickHasHadDriverLicenseLessThan3YearsCheckbox(String applicantFullName) throws Exception {
        WebElement hasHadDriverLicenseLessThan3YearsCheckbox = getHadDriversLicenseCheckbox(applicantFullName);
        scrollAndClickOnElement(hasHadDriverLicenseLessThan3YearsCheckbox);
    }

    /**
     * Validates that Good Student and Distant Student discounts are NOT removed
     * when the "Has had driver's license for less than 3 years" checkbox is unchecked.
     *
     * Steps:
     * 1. Process all drivers (PNI + young additional driver) - this checks the license checkbox
     *    and the full-time student checkbox for the young additional driver.
     * 2. Ensure the Good Student (GPA > 3.0) checkbox is checked for the young driver.
     * 3. If visible, ensure the Distant Student checkbox is checked for the young driver.
     * 4. Uncheck "Has had driver's license for less than 3 years".
     * 5. Assert both Good Student and Distant Student selections are still present/checked.
     */
    public void validateStudentDiscountsNotRemovedOnLicenseCheckboxUncheck(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        // Process all drivers, which also checks the license checkbox and the full-time student
        // checkbox for the young additional driver (age <= MAX_YOUNG_AGE, license held < 3 years)
        reviewAllDrivers(applicant, Optional.empty());

        SqlAdditionalDriver youngDriver = applicant.getAdditionalDrivers().get(0);
        String youngDriverFullName = getDriverFullName(youngDriver);
        String youngDriverCardXpath = getDriverCardXpathByFullName(youngDriverFullName);
        String gpaCheckboxXpath = youngDriverCardXpath + GPA_OVER_3_CHECKBOX_XPATH;
        String gpaInputXpath = youngDriverCardXpath + GPA_OVER_3_INPUT_XPATH;
        String distantStudentCheckboxXpath = youngDriverCardXpath + DISTANT_STUDENT_XPATH;
        String distantStudentInputXpath = youngDriverCardXpath + DISTANT_STUDENT_CHECKBOX_INPUT_XPATH;

        // Verify Good Student (GPA > 3.0) checkbox is present for the young driver
        fsa.assertTrue(isElementPresent(By.xpath(gpaCheckboxXpath), 2),
                "Good Student (GPA > 3.0) checkbox should be present for the " + youngDriver.getAge() + "-year-old driver");

        // Ensure Good Student checkbox is checked
        WebElement gpaInput = driver().findElement(By.xpath(gpaInputXpath));
        if (isCheckboxNotSelected(gpaInput)) {
            scrollAndClickOnHiddenElement(gpaInput);
        }
        fsa.assertTrue(isCheckboxSelected(driver().findElement(By.xpath(gpaInputXpath))), "Good Student discount should be checked before unchecking license checkbox");

        // Check Distant Student if visible for this driver and state
        boolean isDistantStudentVisible = isElementPresent(By.xpath(distantStudentCheckboxXpath), 2);
        Log.info("Distant Student checkbox visible for state " + applicant.getStateCode() + ": " + isDistantStudentVisible);
        if (isDistantStudentVisible) {
            WebElement distantStudentInput = driver().findElement(By.xpath(distantStudentInputXpath));
            if (isCheckboxNotSelected(distantStudentInput)) {
                scrollAndClickOnHiddenElement(distantStudentInput);
            }
            fsa.assertTrue(isCheckboxSelected(driver().findElement(By.xpath(distantStudentInputXpath))), "Distant Student discount should be checked before unchecking license checkbox");
        }

        // Verify "Has had driver's license for less than 3 years" is currently checked (set by reviewAllDrivers)
        WebElement licenseCheckbox = getHadDriversLicenseCheckbox(youngDriverFullName);
        fsa.assertTrue(isCheckboxSelected(licenseCheckbox),
                "Has had driver's license for less than 3 years checkbox should be checked for driver: " + youngDriverFullName);

        // UNCHECK "Has had driver's license for less than 3 years"
        clickElement(licenseCheckbox);
        fsa.assertFalse(isCheckboxSelected(getHadDriversLicenseCheckbox(youngDriverFullName)),
                "Has had driver's license for less than 3 years checkbox should now be unchecked");

        // === Key assertion: discounts should NOT be removed after unchecking ===
        fsa.assertTrue(isElementPresent(By.xpath(gpaCheckboxXpath), 2),
                "Good Student checkbox should still be visible after unchecking 'Has had driver's license for less than 3 years'");
        fsa.assertTrue(isCheckboxSelected(driver().findElement(By.xpath(gpaInputXpath))),
                "Good Student discount should NOT be removed when 'Has had driver's license for less than 3 years' is unchecked");

        if (isDistantStudentVisible) {
            fsa.assertTrue(isElementPresent(By.xpath(distantStudentCheckboxXpath), 2),
                    "Distant Student checkbox should still be visible after unchecking 'Has had driver's license for less than 3 years'");
            fsa.assertTrue(isCheckboxSelected(driver().findElement(By.xpath(distantStudentInputXpath))),
                    "Distant Student discount should NOT be removed when 'Has had driver's license for less than 3 years' is unchecked");
        }

        clickContinueButton();
    }

    // Validates error messages and navigation behavior for age licensed in a back-and-forth scenario.
    public void validateErrorsForAgeLicensedInBackAndForth(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        if (!isAskingDriverLicenseAgeState(applicant.getStateCode())) {
            clickHasHadDriverLicenseLessThan3YearsCheckbox(getApplicantFullName(applicant));
        }
        waitAndClickElement(continueButton);
        validateAddDriverLicenseAgeErrorMessage(fsa);

        reviewAllDrivers(applicant, Optional.empty());
        addDriverLicenseAgeBasedOnStateAndInputField(applicant);
        waitAndClickElement(continueButton);
        testStepAssert(new SignalPageOneUI().isOnSignalPage(), "User is navigated back to Driver Review page");
        navigateBack();
        testStepAssert(isOnDriverReviewPage(), "User is navigated back to Driver Review page");

        clearDriverLicenseAge(applicant.getStateCode(), getApplicantFullName(applicant));
        waitAndClickElement(continueButton);
        validateAddDriverLicenseAgeErrorMessage(fsa);
    }

    public void addDriverLicenseAgeBasedOnStateAndInputField(AutoApplicant applicant) throws Exception {
        String pniFullName = getApplicantFullName(applicant);
        int age = applicant.getAge();
        if (isAskingDriverLicenseAgeState(applicant.getStateCode())) {
            enterDriverLicenseAge(applicant, pniFullName, applicant.getFirstAgeUnitedStatesDriverLicense());
        } else if (age <= MAX_YOUNG_AGE && (age - applicant.getFirstAgeUnitedStatesDriverLicense() < 3)) {
            addHadDriversLicense(pniFullName, applicant.getFirstAgeUnitedStatesDriverLicense());
        }
    }

    public void clearDriverLicenseAge(String stateCode, String fullName) throws Exception {
        if(stateCode.equals(CA)) {
            return;
        }
        if (isAskingDriverLicenseAgeState(stateCode)) {
            By inputBy = By.xpath(getDriverCardXpathByFullName(fullName) + LICENSE_AGE_INPUT_FIELD_XPATH);
            if(!isElementPresent(inputBy, 2)) {
                return;
            }
            WebElement licenseAgeInputField = driver().findElement(inputBy);
            clearOutFieldUsingBackSpace(licenseAgeInputField);
        } else{
            WebElement driverLicenceAgeInputField = getDriverLicenceAgeInputField(fullName);
            if(!isElementDisplayed(driverLicenceAgeInputField, 2)) {
                return;
            }
            clearOutFieldUsingBackSpace(driverLicenceAgeInputField);
        }
    }

    public void validateAddDriverLicenseAgeErrorMessage(FarmersSoftAssert fsa){
        // CTA no longer shows generic message
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(driverLicenseAgeError.get(0))), PLEASE_PROVIDE_AGE, PLEASE_PROVIDE_AGE + " error message validation");
    }
    public void validateSafetyCourseFunctionality(AutoApplicant applicant, boolean isSafetyCourseExpected, FarmersSoftAssert fsa) throws Exception {
        testStepAssert(isOnDriverReviewPage(), "User is on Driver Review Page", true);
        String applicantFullName = getApplicantFullName(applicant);

        // Validate checkbox presence
        validateSafetyCourseCheckboxPresence(applicant, fsa, isSafetyCourseExpected, applicantFullName);

        if (isSafetyCourseExpected) {
            // Validate subtext and discount functionality
            validateSafetyCourseSubtext(applicant, fsa, applicantFullName);
            validateSafetyCourseDiscountFunctionality(applicantFullName, fsa, applicant.getStateCode());
        }

        reviewAllDrivers(applicant, Optional.empty());
        clickContinueButton();
    }

    public void validateSafetyCourseCheckboxPresence(AutoApplicant applicant, FarmersSoftAssert fsa, boolean isSafetyCourseExpected, String applicantFullName) throws Exception {
        List<String> checkboxesTextsForGivenDriver = getCheckboxesTextsForGivenDriver(applicantFullName);
        String safetyCourseDisplayExpectation = isSafetyCourseExpected ? "should be" : "should not be";

        String actualSafetyCourseCheckboxText = Arrays.asList(CT, WY).contains(applicant.getStateCode())
                ? DriverReviewPageCheckboxes.SAFETY_COURSE_2_YEARS.getCheckBoxText()
                : DriverReviewPageCheckboxes.SAFETY_COURSE.getCheckBoxText();

        fsa.assertEquals(
                checkboxesTextsForGivenDriver.contains(actualSafetyCourseCheckboxText),
                isSafetyCourseExpected,
                String.format("Safety course %s displayed for %s", safetyCourseDisplayExpectation, applicantFullName)
        );
    }

    private void validateSafetyCourseSubtext(AutoApplicant applicant, FarmersSoftAssert fsa, String applicantFullName) throws Exception {
        String stateCode = applicant.getStateCode();
        String expectedSafetyCourseSubtext = getExpectedDefensiveDriverSubHeader(stateCode);

        if (!List.of(GA, KS, NJ, UT).contains(stateCode)) { // These states do not have subtext for the safety course checkbox
            WebElement safetyCheckboxesSubText = getDriverSafetyCourseSubTextWebElementByFullName(applicantFullName);
            fsa.assertEquals(
                    getTextFromElement(safetyCheckboxesSubText),
                    expectedSafetyCourseSubtext,
                    "Safety course subtext verification"
            );
        }
    }

    private void validateSafetyCourseDiscountFunctionality(String applicantFullName, FarmersSoftAssert fsa, String stateCode) throws Exception {

        // if in any case safety course checkbox is already checked, uncheck it to validate both discount addition and removal in the same test execution
        WebElement safetyCourseCheckbox = getSafetyCourseCheckbox(applicantFullName);
        if(safetyCourseCheckbox.getAttribute(CLASS).equals(MDC_CHECKBOX_CHECKED)) {
            clickElement(safetyCourseCheckbox);
            if(waitElementBeVisible(snackBar).isDisplayed()){
                wait.until(ExpectedConditions.invisibilityOf(snackBar));
            }
        }

        // Click safety course checkbox and validate discount added
        addSafetyCourse(applicantFullName);
        sleep(1);
        boolean isDefensiveDiscountEnabled = isDefensiveDriverDiscountEnabledOnDriverReview(stateCode);
        if (stateCode.equals(PA)) {
            validateDriverImprovementDiscountAddedSnackBar(fsa);
            if (!isBDQFlowEnabled()) {
                validateDriverImprovementDiscountPresent(fsa);
            }
        } else {
            validateMatureOrDefensiveDriverDiscountAddedSnackBar(fsa, isDefensiveDiscountEnabled);
            // For BDQ flow, the discount will be added in the backend but won't be displayed on UI, so skipping the validation of discount presence on UI for BDQ flow
            if (!isBDQFlowEnabled()) {
                validateMatureOrDefensiveDriverDiscountPresent(fsa, isDefensiveDiscountEnabled);
            }
        }


        // Click safety course checkbox again and validate discount removed
        waitElementBeInvisible(discountsSidesheetTitle);
        scrollElementToMiddle(safetyCourseCheckbox);
        waitAndClickElement(safetyCourseCheckbox);
        if (stateCode.equals(PA)) {
            validateDriverImprovementDiscountRemovedSnackBar(fsa);
            if (!isBDQFlowEnabled()) {
                validateDriverImprovementDiscountNotPresent(fsa);
            }
        } else {
            validateMatureOrDefensiveDriverDiscountRemovedSnackBar(fsa, isDefensiveDiscountEnabled);
            // For BDQ flow, the discount will be added in the backend but won't be displayed on UI, so skipping the validation of discount presence on UI for BDQ flow
            if (!isBDQFlowEnabled()) {
                validateMatureOrDefensiveDriverDiscountNotPresent(fsa, isDefensiveDiscountEnabled);
            }
        }
    }


    public boolean isDefensiveDriverDiscountEnabledOnDriverReview(String stateCode) throws Exception {
        if(stateCode.equals(AL) && !isBDQFlowEnabled() && !isOnBristolWest()){
            return false;
        }
        return Arrays.asList(AL, GA, KS, KY, MT, NJ).contains(stateCode);
    }

    private String getExpectedDefensiveDriverSubHeader(String stateCode){
        return stateCode.equals(KS) ? KS_DEFENSIVE_DRIVER_COURSE_SUBHEADER_TEXT
                : stateCode.equals(CT) ? CT_DEFENSIVE_DRIVER_SUBHEADER_TEXT
                : stateCode.equals(MA) ? MA_DEFENSIVE_DRIVER_SUBHEADER_TEXT
                : SPECIAL_DEFENSIVE_DRIVER_SUBHEADER_TEXT;
    }

    private WebElement getDriverSafetyCourseSubTextWebElementByFullName(String applicantFullName) throws Exception {
        return driver().findElement(By.xpath(getDriverCardXpathByFullName(applicantFullName) + SAFETY_COURSE_SUBTEXT_XPATH_END));
    }
    private List<WebElement> getDriverSafetyCourseSubTextWebElements() throws Exception {
        return driver().findElements(By.xpath(SAFETY_COURSE_SUBTEXT_XPATH_END));
    }
    public void validateSafetyCourseCheckBoxNotPresent(FarmersSoftAssert fsa, String applicantFullName) throws Exception {
        fsa.assertFalse(isElementPresent(By.xpath(SAFETY_COURSE_CHECKBOX_XPATH)), "Safety course checkbox should not be displayed");
    }
    public void validateNoSnackBarDisplayed(FarmersSoftAssert fsa) throws Exception {
        fsa.assertFalse(isElementPresent(By.xpath("//a[@id='snackbarDesc']")), "mature or defensive driver discount snackbar should not be displayed");
    }

    public void validateSpouseNonDriverStatusDoesNotResetAfterRefresh(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        waitElementPresent(By.xpath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + MARITAL_CHECKBOX_INPUT_XPATH), 3);
        clickElement(getMaritalCheckbox(getApplicantFullName(applicant)));
        clickOnSpouseToIfExist(applicant);
        enterSpouseInformation(applicant, false, false);
        waitForSpinnerToBeGone();
        driver().navigate().refresh();
        waitUntilAngular5Ready();
        AppStore.Auto.Driver sni = getSessionStorageAppStore().getAuto().getDrivers().stream().filter(each -> each.getPni().equals("X")).collect(Collectors.toList()).get(0);
        String spouseFullName = sni.getFirstName() + SPACE + sni.getLastName();
        String driverCardXpathByFullName = getDriverCardXpathByFullName(spouseFullName);
        String nonDriverLabelXpath = "//span[@class='non-driver-label ng-star-inserted']";
        fsa.assertTrue(isElementPresent(By.xpath(driverCardXpathByFullName + nonDriverLabelXpath), 2), "Non Driver label should be present");
        waitAndClickElement(getEditButtonByDriverFullName(spouseFullName));
        WebElement noOptionSelected = driver().findElement(By.xpath(String.format(SPOUSE_DRIVING_VEHICLE_XPATH, NO) + "[contains(@class,'checked')]"));
        fsa.assertTrue(isElementDisplayed(noOptionSelected, 3));
        clickElement(editDriverDialogCloseLink);
    }
}