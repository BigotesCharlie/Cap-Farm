package com.farmers.ffq.auto.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.farmers.framework.report.Log;

public class SaveAndFinishLaterPopup extends AutoBasePage {
	
	@FindBy(id = "FFQAuto_Modal_saveFinishForm")
	private WebElement saveAndFinishLaterForm;
	
	@FindBy(id = "FFQAuto_Modal_saveFinishHeader")
	private WebElement saveAndFinishLaterFormHeader;
		
	@FindBy(id = "FFQAuto_Modal_saveFinishEmailAddress")
	private WebElement emailTextbox;
	
	@FindBy(id = "FFQAuto_Modal_saveFinishOk")
	private WebElement saveAndExitButton;
	
	@FindBy(id = "FFQAuto_Modal_saveFinishClose")
	private WebElement continueWithQuoteButton;
	
	/**
	 * Constructor.
	 * 
	 * @throws Exception
	 */
	public SaveAndFinishLaterPopup() throws Exception {
		super();		
	}
	
	public void enterEmailId() {
		Log.info("Entering EmailId for Retrieving the quote.");
		waitElementBeVisible(emailTextbox);		
	}
	
	public void saveAndExit() {
		Log.info("Selecting SaveAndExit button.");
		waitElementBeVisibleClickable(saveAndExitButton);
		clickElement(saveAndExitButton);
	}
	
	public void continueWithTheQuote() {
		Log.info("Selecting ContinueWithTheQuote button.");
		waitElementBeVisibleClickable(continueWithQuoteButton);
		clickElement(continueWithQuoteButton);
	}
}
