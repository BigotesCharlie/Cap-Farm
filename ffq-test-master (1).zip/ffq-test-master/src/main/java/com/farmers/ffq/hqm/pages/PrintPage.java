package com.farmers.ffq.hqm.pages;

import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.PrintInfoHQM;
import com.farmers.ffq.datatransferobjects.hqm.QuoteRateHQM;
import com.farmers.ffq.datatransferobjects.hqm.StaticContentHQM;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import javax.annotation.Nullable;
import java.text.NumberFormat;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Print Page - Home Quote Modernization (HQM).
 */

public class PrintPage extends HqmBasePage {

	private static final String DWELLING = "Dwelling";

	@FindBy(xpath = "//farmers-print-home//mat-card//img[@alt='Farmers Insurance Logo']")
	private WebElement imgFarmersLogo;

	@FindBy(xpath = "//farmers-print-home//mat-icon[text()='print']")
	private WebElement iconPrint;

	@FindBy(xpath = "//farmers-print-home//p[contains(@class,'tui-subtitle-text-1')]//*[starts-with(text(),'Quote #')]")
	private WebElement textQuoteNumber;

	@FindBy(xpath = "//farmers-print-home//div/h3[text()='Home Insurance']/../div[contains(@class,'insurance-cost-block')]/strong")
	private WebElement textMonthlyPremium;

    @FindBy(xpath = "//farmers-print-home//div/h3[text()='Home Insurance']/../div[contains(@class,'insurance-cost-block')]/span")
    private WebElement textYearlyPremium;

    @FindBy(xpath = "//farmers-print-home//div/h4[text()='Property Coverages']/../div//p[contains(text(),'Dwelling')]/../p[2]")
    private WebElement coverageDwelling;

    @FindBy(xpath = "//farmers-print-home//div/h4[text()='Property Coverages']/../div//p[contains(text(),'Separate Structures')]/../p[2]")
    private WebElement coverageSeparateStructures;

    @FindBy(xpath = "//farmers-print-home//div/h4[text()='Property Coverages']/../div//p[contains(text(),'Personal Property')]/../p[2]")
    private WebElement coveragePersonalProperty;

    @FindBy(xpath = "//farmers-print-home//div/h4[text()='Property Coverages']/../div//p[contains(text(),'Extended Replacement Cost')]/../p[2]")
    private WebElement coverageExtendedReplacementCost;

    @FindBy(xpath = "//farmers-print-home//div/h4[text()='Liability']/../div//p[contains(text(),'Personal Liability')]/../p[2]")
    private WebElement liabilityPersonalLiability;

    @FindBy(xpath = "//farmers-print-home//div/h4[text()='Liability']/../div//p[contains(text(),'Medical Payments to Others')]/../p[2]")
    private WebElement liabilityMedicalPaymentsToOthers;

    @FindBy(xpath = "//farmers-print-home//div/h4[text()='Deductibles']/../div//p[contains(text(),'All Peril Losses') or " +
            "contains(text(),'All Other Peril Losses')]/../p[2]")
    private WebElement deductibleAllPeril;

    @FindBy(xpath = "//farmers-print-home//div/h4[text()='Deductibles']/../div//p[contains(text(),'Wind & Hail Losses')]/../p[2]")
    private WebElement deductibleWindHail;

    @FindBy(xpath = "//farmers-print-home//div/h4[text()='Deductibles']/../div//p[contains(text(),'Hurricane Losses')]/../p[2]")
    private WebElement deductibleHurricane;

    @FindBy(xpath = "//farmers-print-home//div/h4[text()='Deductibles']/../div//p[contains(text(),'Water Losses')]/../p[2]")
    private WebElement deductibleWater;

    private static final String DISCOUNTS_XPATH = "//div/h4[text()='Discounts applied']/../div//p[1]";

    @FindBy(xpath = "//farmers-print-home//h2")
    private WebElement pageTitle;

    @FindBy(xpath = "//farmers-print-home//div[contains(@class,'print-personal-info')]/p[contains(@class,'tui-subtitle-text-1')]")
    private WebElement pageSubTitle;

    @FindBy(xpath = "//farmers-print-home//div[contains(@class,'need-help-caption')]")
    private WebElement textNeedHelp;

    @FindBy(xpath = "//farmers-print-home//div[@class='need-help-caption']/../p[contains(@class,'need-help-paragraph')]")
    private WebElement textNeedHelpSubtitle;

    @FindBy(xpath = "//farmers-print-home//div[@class='need-help-caption']/../div[@class='tui-caption-text']")
    private WebElement textNeedHelpSubtitleAgent;

    @FindBy(xpath = "//farmers-print-home//div[@class='agent-img']/img")
    private WebElement imgAgent;

    @FindBy(xpath = "//farmers-print-home//div[@class='agent-img']/..//div/div[contains(@class,'need-help-caption')]")
    private WebElement fullNameAgent;

    @FindBy(xpath = "//farmers-print-home//mat-icon[text()='email']/../div[contains(@class,'body-two')]")
    private WebElement emailAgent;
    @FindBy(xpath = "//farmers-print-home//mat-icon[text()='email']/../../div[contains(@class,'body-two')]")
    private WebElement emailAgentMobile;

    @FindBy(xpath = "//farmers-print-home//mat-icon[text()='phone']/../span[contains(@class,'body-two')]")
    private WebElement phoneAgent;
    @FindBy(xpath = "//farmers-print-home//mat-icon[text()='phone']/../../span[contains(@class,'body-two')]")
    private WebElement phoneAgentMobile;

    @FindBy(xpath = "//farmers-print-home//mat-icon[text()='place']/../div[contains(@class,'body-two')]")
    private WebElement placeAgent;
    @FindBy(xpath = "//farmers-print-home//mat-icon[text()='place']/../../div[contains(@class,'body-two')]")
    private WebElement placeAgentMobile;

    @FindBy(xpath = "//farmers-print-home//mat-icon[text()='phone']/../../span[contains(@class,'quote-agent-info-label')]")
    private WebElement phoneNumberPA;

    private static final String PAGE_TITLE_TEXT = "Farmers Insurance\nR";

    private static final String PAGE_SUBTITLE_TEXT = "Thank you %s %s for choosing Farmers. Below is a summary of your Home insurance " +
            "quote. Please refer to your Quote #%s to purchase your policy online or with one of our friendly Farmers %s.";

    private static final String AGENT_SUBTITLE_TEXT = "Your local Farmers Insurance\u00ae Agent is available if you have any questions.";

    private static final String SUBTITLE_PA_TEXT = "A Farmers Insurance\u00ae Representative is\n" +
            "available if you have any questions.";

    private static final String DISCLAIMERS_XPATH = "//farmers-print-home//p[@id='disclaimerText']/../p";

    private final List<String> footersPrintPage = Arrays.asList("* Based on paying premium automatically. Service fees and fees " +
            "permitted by state law are not shown. Amounts and service fees differ based on pay plan and automatic payment " +
            "selection. The premium shown may include a Preferred Payment discount. This discount is only available on a " +
            "monthly basis, if you choose the monthly mortgage pay plan.\n\n",
            "* Based on paying premium automatically. Service fees and fees permitted by state law are not shown. Amounts " +
            "and service fees differ based on pay plan and automatic payment selection.\n\n",
            "This is a preliminary rate (\"quote\") for the insurance you selected. This quote is not a policy of insurance " +
            "or application, offer to insure or binder. Certain assumptions may have been made and this quote reflects rates " +
            "in effect the day of the quote and are subject to change. Premium may vary based on additional information, " +
            "coverages and deductibles that you select, underwriting criteria, and any changes to assumptions. Farmers " +
            "reserves the right to accept, reject, or modify this quote after review of an application and other underwriting " +
            "information. Applications are subject to underwriting approval. Farmers online home quotes are available for new " +
            "customers.");

    private static final String PRINT_PAGE_FOOTER_CT = "* Price includes a $12.00 CT Healthy Home Surcharge.\n\n";

    private static final String PRINT_PAGE_FOOTER_KY1 = "Unless you waive in writing, we are required to provide you with mine subsidence " +
            "coverage when you purchase a homeowners insurance policy if your structure is located in one of the following " +
            "counties: Bell, Boyd, Breathitt, Butler, Carter, Christian, Clay, Daviess, Edmonson, Elliott, Floyd, Greenup, " +
            "Hancock, Harlan, Henderson, Hopkins, Jackson, Johnson, Knott, Knox, Laurel, Lawrence, Lee, Leslie, Letcher, " +
            "Martin, McCreary, McLean, Morgan, Muhlenberg, Ohio, Owsley, Perry, Union, Webster, Whitley and Wolfe.\n\n";

    private static final String PRINT_PAGE_FOOTER_KY2 = "* Based on paying premium automatically. Service fees and fees permitted by " +
            "state law are not shown. Amounts and service fees differ based on pay plan and automatic payment selection. " +
            "Additional taxes and fees may apply.\n\n";

    private static final String PRINT_PAGE_FOOTER_KY3 = "This is a preliminary rate (\"quote\") for the insurance you selected. This " +
            "quote is not a policy of insurance or application, offer to insure or binder. Certain assumptions may have " +
            "been made and this quote reflects rates in effect the day of the quote and are subject to change. Premium may " +
            "vary based on additional information, coverages and deductibles that you select, underwriting criteria, and " +
            "any changes to assumptions. In order to purchase a policy, information about your spouse may be necessary. " +
            "Farmers reserves the right to accept, reject, or modify this quote after review of an application and other " +
            "underwriting information. Applications are subject to underwriting approval. Farmers online home quotes are " +
            "available for new customers.";

    private static final String PRINT_PAGE_FOOTER_MALA = "* Based on paying premium automatically from a bank account. Service fees " +
            "and fees permitted by state law are not shown. Amounts and service fees differ based on pay plan and automatic " +
            "payment selection. Additional taxes and fees may apply.\n\n";

    private static final String PRINT_PAGE_FOOTER_LA = "Do you qualify for a discount? Louisiana Law requires insurers to provide " +
            "a discount for insureds who build or retrofit a structure to comply with the State Uniform Construction Code " +
            "and/or install mitigation improvements or retrofit their property using construction techniques demonstrated to " +
            "reduce the amount of loss from a windstorm or hurricane. If you have made these improvements and believe that " +
            "your home qualifies for this discount, please talk to one of our Customer Representatives to find out more.\n\n";

    private static final String PRINT_PAGE_FOOTER_TX = "* Price includes FAIR Plan Assessment Recoupment.\n\n";

    private static final String PRINT_PAGE_FOOTER_NE = "* The amount shown applies when premium is paid automatically on a monthly basis. " +
            "Monthly payment amount may be different if payments are not made automatically. The amount shown does not include monthly " +
            "service fees. Amounts charged for service fees also differ based on billing and pay plan selections. Please see your Farmers " +
            "agent for details.\n\n";

    private List<String> policyPerksDisclaimerList = Arrays.asList("POLICY PERKS\u2120 ARE NOT AVAILABLE IN EVERY STATE.\n\n" +
            "POLICY PERKS ARE AVAILABLE WITH SELECT FARMERS\u00ae BRANDED POLICIES. NOT AVAILABLE WITH ALL FARMERS BRANDED POLICIES. " +
            "CERTAIN POLICY PERKS ARE OPTIONAL COVERAGES AVAILABLE AT ADDITIONAL COST. Subject to terms and conditions. Underwritten " +
            "by Farmers, Truck or Fire Insurance Exchanges or affiliated insurer. Products not available in every state.",
            "DECLINING DEDUCTIBLES\u00ae IS NOT AVAILABLE IN CA & FL.\n\n" +
            "DECLINING DEDUCTIBLES IS AVAILABLE WITH FARMERS\u00ae BRANDED SMART PLAN HOMEOWNERS POLICIES. NOT AVAILABLE WITH ALL FARMERS " +
            "BRANDED POLICIES. Subject to terms and conditions. Underwritten by Farmers, Truck or Fire Insurance Exchanges or affiliated " +
            "insurer. Products not available in every state.",
            "CLAIM FORGIVENESS IS AVAILABLE WITH FARMERS\u00ae BRANDED SMART PLAN HOMEOWNERS POLICIES. NOT AVAILABLE WITH ALL FARMERS " +
            "BRANDED POLICIES. Subject to terms, conditions, and eligibility requirements. Underwritten by Farmers, Truck or Fire " +
            "Insurance Exchanges or affiliated insurer. Products not available in every state.",
            "CLAIM FREE DISCOUNT IS NOT AVAILABLE IN OK. IN FL, 5 CONSECUTIVE YEARS IS REQUIRED TO RECEIVE THE CLAIM FREE DISCOUNT.\n\n" +
            "CLAIM FREE DISCOUNT IS AVAILABLE WITH FARMERS\u00ae BRANDED SMART PLAN HOMEOWNERS POLICIES. NOT AVAILABLE WITH ALL FARMERS " +
            "BRANDED POLICIES. Subject to terms, conditions, and eligibility requirements. Underwritten by Farmers, Truck or Fire " +
            "Insurance Exchanges or affiliated insurer. Products not available in every state.");

    @FindBy(xpath = "//farmers-home-quote-policy-perks//div[contains(@class,'perk-title')]/img")
    private WebElement policyPerksTitle;

    private static final String POLICY_PERKS_HEADER_TEXT =  "Purchase a policy with Farmers\u00ae and you can unlock discounts, save money, " +
            "and get policy benefits \u2014 all with Farmers Policy Perks SM. Learn moreopen_in_new";

    @FindBy(xpath = "//farmers-home-quote-policy-perks//p[contains(@class,'tui-text-prominent')]")
    private WebElement policyPerksHeader;

    private static final String POLICY_PERKS_HEADER_LINK_XPATH = "//farmers-home-quote-policy-perks//p[contains(@class,'tui-text-prominent')]//a[starts-with(@href,'https://www.farmers.com/policy-perks/')]";
    @FindBy(xpath = POLICY_PERKS_HEADER_LINK_XPATH)
    private WebElement policyPerksHeaderLink;

    private static final String POLICY_PERKS_PARAGRAPH_HEADER_XPATH = "//farmers-home-quote-policy-perks//div[contains(@class,'tui-subtitle-text-2')]";
    private static final String POLICY_PERKS_PARAGRAPH_CONTENT_XPATH = "//farmers-home-quote-policy-perks//div[contains(@class,'tui-subtitle-text-2')]/../div[@class='tui-text-prominent']";

    private List<String> textPerksHeaders = Stream.of("Declining Deductibles\u00ae", "Claim Forgiveness", "Claim Free Discount").collect(Collectors.toList());

    private List<String> textPerksContents = Stream.of("Earn $50 toward your home deductible each year your home policy remains in force.",
            "We won\u2019t raise your premium because of a claim, once you\u2019ve gone claim-free with Farmers for five years.",
            "You will receive a discount on your Home insurance if you\u2019ve been claim-free for three years.").collect(Collectors.toList());

    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public PrintPage() throws Exception {
        super();
        waitElementBeVisible(textQuoteNumber);
    }

    public String getQuoteNumberPrint() {
    	waitElementBeVisible(textQuoteNumber);
    	return getTextFromElement(textQuoteNumber).split("#")[1];
    }

    public String getMonthlyPremium() {
    	waitElementBeVisible(textMonthlyPremium);
    	return getTextFromElement(textMonthlyPremium).split("/")[0];
    }

    public String getYearlyPremium() {
        waitElementBeVisible(textYearlyPremium);
        return getTextFromElement(textYearlyPremium).split(SPACE)[1];
    }


    public void validateQuotePremiums(ApplicantHQM applicant, String yearlyPremium,
                                      FarmersSoftAssert fsa, @Nullable QuoteRateHQM quoteRate) throws Exception {
        String quoteNumberPrintPage = this.getQuoteNumberPrint();
        String monthlyPremiumPrintPage = "";
        Double dPremiumMonthly = null;
        String yearlyPremiumPrintPage = "";
        if (!isHqmDigitalMonetizationState(applicant.stateCode)) {
            monthlyPremiumPrintPage = this.getMonthlyPremium();
            yearlyPremiumPrintPage = this.getYearlyPremium();
            dPremiumMonthly = NumberFormat.getCurrencyInstance(Locale.US).parse(monthlyPremiumPrintPage).doubleValue();
        } else {
            yearlyPremiumPrintPage = this.getMonthlyPremium();
        }
        Double dPremiumYearly = NumberFormat.getCurrencyInstance(Locale.US).parse(yearlyPremiumPrintPage).doubleValue();
        Log.info("<< Print Page: >>" );
        fsa.assertEquals(quoteNumberPrintPage, applicant.quoteNumber, "Print page - Quote Number validation.");
        if (quoteRate != null) {
            if (!isHqmDigitalMonetizationState(applicant.stateCode)) {
                fsa.assertEquals(dPremiumMonthly, Double.parseDouble(quoteRate.getMonthlyPremium()),
                        "Print page - Quote Monthly Premium validation vs. Postgres value.");
            }
            fsa.assertEquals(dPremiumYearly, Double.parseDouble(quoteRate.getYearlyPremium()),
                    "Print page - Quote Yearly Premium validation vs. Postgres value.");
        } else {
            if (!isHqmDigitalMonetizationState(applicant.stateCode)) {
                fsa.assertEquals(monthlyPremiumPrintPage, applicant.quoteRate,
                        "Print page - Quote Monthly Premium validation vs. quote page value.");
            }
            fsa.assertEquals(yearlyPremiumPrintPage, yearlyPremium,
                    "Print page - Quote Yearly Premium validation vs. quote page value.");
        }
    }

    public String stringToCurrency(String value) {
        return currencyFormat.format(Double.parseDouble(value));
    }

    public void validateQuoteCoverages(FarmersSoftAssert fsa, @Nullable QuoteRateHQM quoteRate) {
        if (quoteRate != null) {
            currencyFormat.setMaximumFractionDigits(0);
            Double dwellingD = Double.parseDouble(quoteRate.getCoverageAmount(DWELLING));
            fsa.assertEquals(getTextFromElement(coverageDwelling), stringToCurrency(quoteRate.getCoverageAmount(DWELLING)),
                    "Print page - Dwelling coverage.");
            Double separateStructuresD = Double.parseDouble(quoteRate.getCoverageAmount("Separate Structures"));
            fsa.assertEquals(getTextFromElement(coverageSeparateStructures), currencyFormat.format(dwellingD * separateStructuresD / 100),
                    "Print page - Separate Structures coverage.");
            Double personalPropertyD = Double.parseDouble(quoteRate.getCoverageAmount("Personal Property"));
            fsa.assertEquals(getTextFromElement(coveragePersonalProperty), currencyFormat.format(dwellingD * personalPropertyD / 100),
                    "Print page - Personal Property coverage.");
            String extendedReplacementCost = quoteRate.getCoverageAmount("Extended Replacement Cost");
            if (extendedReplacementCost == null) {
                extendedReplacementCost = NONE;
            } else {
                Double extendedReplacementD = Double.parseDouble(extendedReplacementCost);
                extendedReplacementCost = currencyFormat.format(dwellingD * extendedReplacementD / 100);
            }
            fsa.assertEquals(getTextFromElement(coverageExtendedReplacementCost), extendedReplacementCost,
                    "Print page - Extended Replacement Cost coverage.");
        } else {
            Log.warn("Unable to validate quote coverage values - quoteRate is null.");
        }
    }

    private String convertDeductible(Double dwellingD, @NotNull String deductible) {
        if (deductible.startsWith("$")) {
            currencyFormat.setGroupingUsed(true);
            Double deductibleD = Double.parseDouble(deductible.replace("$", ""));
            deductible = currencyFormat.format(deductibleD);
        } else {
            Double deductibleD = Double.parseDouble(deductible.replace("%", ""));
            deductible = currencyFormat.format(dwellingD * deductibleD / 100);
        }
        return  deductible;
    }

    public void validateQuoteDeductibles(ApplicantHQM applicant, FarmersSoftAssert fsa, @Nullable QuoteRateHQM quoteRate) {
        if (quoteRate != null) {
            Double dwellingD = Double.parseDouble(quoteRate.getCoverageAmount(DWELLING));
            String allPeril = quoteRate.getDeductibleValue("All Peril", applicant.stateCode);
            fsa.assertEquals(getTextFromElement(deductibleAllPeril), convertDeductible(dwellingD, allPeril),
                    "Print page - All Peril Deductible.");

            String windHail = quoteRate.getDeductibleValue("Wind & Hail", applicant.stateCode);
            if (windHail != null) {
                fsa.assertEquals(getTextFromElement(deductibleWindHail), convertDeductible(dwellingD, windHail),
                        "Print page - Wind & Hail Deductible.");
            }

            String hurricane = quoteRate.getDeductibleValue("Hurricane", applicant.stateCode);
            if (hurricane != null) {
                fsa.assertEquals(getTextFromElement(deductibleHurricane), convertDeductible(dwellingD, hurricane),
                        "Print page - Hurricane Deductible.");
            }

            String water = quoteRate.getDeductibleValue("Water", applicant.stateCode);
            if (water != null) {
                fsa.assertEquals(getTextFromElement(deductibleWater), convertDeductible(dwellingD, water),
                        "Print page - Water Deductible.");
            }
        } else {
            Log.warn("Unable to validate quote deductible values - quoteRate is null.");
        }
    }

    public void validateQuoteLiabilities(FarmersSoftAssert fsa, @Nullable QuoteRateHQM quoteRate) {
        if (quoteRate != null) {
            fsa.assertEquals(getTextFromElement(liabilityPersonalLiability), stringToCurrency(quoteRate.getCoverageAmount("Personal Liability")),
                    "Print page - Personal Liability.");
            fsa.assertEquals(getTextFromElement(liabilityMedicalPaymentsToOthers),
                    stringToCurrency(quoteRate.getCoverageAmount("Medical Payments to Others")),
                    "Print page - Medical Payments to Others.");
        } else {
            Log.warn("Unable to validate quote liability values - quoteRate is null.");
        }
    }

    public void validateQuoteDiscounts(String stateCode, @Nullable QuoteRateHQM quoteRate) throws Exception {
        if (quoteRate != null) {
            List<String> listPageDiscounts = driver().findElements(By.xpath(DISCOUNTS_XPATH)).stream().
                    map(this::getTextFromElement).map(String::toLowerCase)
                    .sorted(Comparator.naturalOrder()).collect(Collectors.toList());
            List<String> quoteDiscounts = quoteRate.getAppliedDiscounts();
            if (isFlexState(stateCode)) {
                quoteDiscounts.set(quoteDiscounts.indexOf("preferred payment"), "preferred payment plan");
                if (quoteDiscounts.indexOf("welcome discount") > 0 ) {
                    quoteDiscounts.set(quoteDiscounts.indexOf("welcome discount"), "welcome");
                }
            }
            Assert.assertEquals(listPageDiscounts, quoteDiscounts, "Print page discounts validation.");
        } else {
            Log.warn("Unable to validate quote discounts - quoteRate is null.");
        }
    }

    public void validatePageTitles(ApplicantHQM applicant, String quoteSource, FarmersSoftAssert fsa, @Nullable PrintInfoHQM printInfo) throws Exception {
        // @quoteSource param is re-used as AEM campaign phone number, when it's not null and not QQ.
        waitElementBeVisible(imgFarmersLogo);
        fsa.assertEquals(getAttributeData(imgFarmersLogo, "alt"), "Farmers Insurance Logo", "Print page - Farmers Insurance Logo.");
        fsa.assertEquals(getTextFromElement(pageTitle), PAGE_TITLE_TEXT, "Print page - page Title h2");
        String sRen = (isEasternExpansionState(applicant.stateCode)) ? "representatives" : "agents";
        fsa.assertEquals(getTextFromElement(pageSubTitle), String.format(PAGE_SUBTITLE_TEXT, applicant.firstName.toUpperCase(),
                applicant.lastName.toUpperCase(), this.getQuoteNumberPrint(), sRen), "Print page - Page Subtitle");
        if ((printInfo == null) || (printInfo.getAgent().getLastName() == null)) {
            fsa.assertEquals(getTextFromElement(textNeedHelpSubtitle), SUBTITLE_PA_TEXT, "Print page - Political Agent Subtitle.");
            fsa.assertEquals(getAttributeData(phoneNumberPA, "textContent").trim(), getContactUsPhoneNumber(applicant, quoteSource, true),
                    "Print page - Phone number to call (Political Agent).");
        } else {
            fsa.assertEquals(getTextFromElement(textNeedHelpSubtitleAgent), AGENT_SUBTITLE_TEXT, "Print page - Local Agent Subtitle.");
            String agentUrl = printInfo.getAgent().getAgentImageUrl() == null ? "" : printInfo.getAgent().getAgentImageUrl();
            fsa.assertEquals(getAttributeData(imgAgent, SRC), agentUrl, "Print page - Agent image URL.");
            fsa.assertEquals(getTextFromElement(fullNameAgent), printInfo.getAgent().getFirstName() + SPACE +
                    printInfo.getAgent().getLastName(), "Print page - Agent First Name and Last Name.");
            if (quoteSource.equals(MOBILE_BROWSER)) {
                fsa.assertEquals(getTextFromElement(emailAgentMobile), printInfo.getAgentEmailAddress(), "Print page - Agent email address.");
                fsa.assertEquals(getTextFromElement(phoneAgentMobile), printInfo.getAgentPhoneNumber(), "Print page - Agent phone number.");
                fsa.assertEquals(getTextFromElement(placeAgentMobile), printInfo.getAgentFullAddress(), "Print page - Agent location.");
            } else {
                fsa.assertEquals(getTextFromElement(emailAgent), printInfo.getAgentEmailAddress(), "Print page - Agent email address.");
                fsa.assertEquals(getTextFromElement(phoneAgent), printInfo.getAgentPhoneNumber(), "Print page - Agent phone number.");
                fsa.assertEquals(getTextFromElement(placeAgent), printInfo.getAgentFullAddress(), "Print page - Agent location.");
            }
        }
    }

    public void validatePageFooters(ApplicantHQM applicant, @Nullable StaticContentHQM staticContent) throws Exception {
        List<String> disclaimersList = driver().findElements(By.xpath(DISCLAIMERS_XPATH)).stream()
                .map(this::getTextFromElement).filter(((Predicate<String>) String::isEmpty).negate()).collect(Collectors.toList());
        Log.info("Found Print page footers disclaimers: " + disclaimersList);
        List<String> footers = new ArrayList<>();
        switch (applicant.stateCode) {
            case CT:
                footers.add(footersPrintPage.get(0).replace(". The premium", ".The premium")
                        + PRINT_PAGE_FOOTER_CT + footersPrintPage.get(2));
                break;
            case CA:
            case AZ:
            case IL:
                footers.add(footersPrintPage.get(1) + footersPrintPage.get(2));
                break;
            case KY:
                footers.add(PRINT_PAGE_FOOTER_KY1 + PRINT_PAGE_FOOTER_KY2 + PRINT_PAGE_FOOTER_KY3);
                break;
            case OK:
            case ID:
            case NM:
            case OR:
            case WI:
                footers.add(footersPrintPage.get(1).substring(2) + footersPrintPage.get(2)); // new Flex state footers do not start with "*"
                break;
            case MS:
            case NV:
            case MO:
            case CO:
            case IN:
            case KS:
            case MD:
            case MN:
            case OH:
            case WA:
                footers.add(PRINT_PAGE_FOOTER_KY2 + PRINT_PAGE_FOOTER_KY3);
                break;
            case PA:
            case WY:
            case VA:
                footers.add(footersPrintPage.get(1) + footersPrintPage.get(2).replace("Farmers online home quotes are available for new customers.",
                        "Farmers online quotes are available for new customers."));
                break;
            case TX:
                footers.add(PRINT_PAGE_FOOTER_KY2 + PRINT_PAGE_FOOTER_TX + PRINT_PAGE_FOOTER_KY3);
                break;
            case MA:
            case NC:
                footers.add(PRINT_PAGE_FOOTER_MALA + PRINT_PAGE_FOOTER_KY3);
                break;
            case LA:
                footers.add(PRINT_PAGE_FOOTER_MALA + PRINT_PAGE_FOOTER_LA + PRINT_PAGE_FOOTER_KY3);
                break;
            case NE:
            case TN:
            case GA:
                footers.add(PRINT_PAGE_FOOTER_NE + footersPrintPage.get(2)
                        .replace("Farmers online home quotes are available for new customers.",
                                "Farmers online home quotes are available for new home customers."));
                break;
            default:
                footers.add(footersPrintPage.get(0) + footersPrintPage.get(2));
                break;
        }
        Assert.assertEquals(disclaimersList.subList(0,1), footers, "Print page - Validate Print page footers.");

        //Policy Perks footer disclaimers
        /* -- Disabled until further notice
        List<String> policyPerksDisclaimers = new ArrayList<>(policyPerksDisclaimerList);
        if (!isFlexState(applicant.stateCode)) {
            disclaimersList.remove(0);
            if (applicant.stateCode.equals(CA)) {
                policyPerksDisclaimers.removeIf(s -> s.startsWith("DECLINING DEDUCTIBLES")); // CA - no DECLINING DEDUCTIBLES disclaimer
            }
            if (applicant.stateCode.equals(OK)) {
                policyPerksDisclaimers.removeIf(s -> s.startsWith("CLAIM FREE"));            // OK - no CLAIM FREE disclaimer
            }
            Assert.assertEquals(disclaimersList, policyPerksDisclaimers, "Print page - Validate Policy Perks Disclaimers text.");
        } else {
            Assert.assertFalse(disclaimersList.size() > 1, "Print page - No Policy Perks Disclaimers for Flex states.");
        }
        -- Disabled until further notice */
        if (staticContent != null) {
            String footersString = String.join("", footers);
            if (isFlexState(applicant.stateCode)) {
                footersString = footersString.startsWith("* ") ? footersString : "* " + footersString;
            }
            Assert.assertEquals(staticContent.getQuoteDisclaimer(), footersString,
                    "Print page - Validate Quote page footers (AEM).");
            /* -- Disabled until further notice
            if (!isFlexState(applicant.stateCode)) {
                List<String> policyPerksDisclaimersAem = new ArrayList<>();
                policyPerksDisclaimersAem.add(staticContent.getQuoteDisclaimerPolicyPerks());
                if (!applicant.stateCode.equals(CA)) {
                    policyPerksDisclaimersAem.add(staticContent.getQuoteDisclaimerDecliningDeductibles());
                }
                policyPerksDisclaimersAem.add(staticContent.getQuoteDisclaimerClaimForgiveness());
                if (!applicant.stateCode.equals(OK)) {
                    String claimFreeDiscountFooter;
                    try {
                        claimFreeDiscountFooter = staticContent.getRateSummaryDisclaimerClaimFree();
                    } catch (NullPointerException e) {
                        Log.warn("Rate Summary Claim Free disclaimer is not present in AEM response.");
                        claimFreeDiscountFooter = staticContent.getQuoteDisclaimerClaimFree();
                    }
                    policyPerksDisclaimersAem.add(claimFreeDiscountFooter);
                }
                Assert.assertEquals(policyPerksDisclaimersAem, policyPerksDisclaimers,
                        "Print page - Validate Policy Perks Disclaimers (AEM).");
            }
            -- Disabled until further notice */
        }
    }

    public void validatePolicyPerks(ApplicantHQM applicant) throws Exception {
        /* -- Disabled until further notice
        List<String> perksHeaders = driver().findElements(By.xpath(POLICY_PERKS_PARAGRAPH_HEADER_XPATH))
                .stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> perksContents = driver().findElements(By.xpath(POLICY_PERKS_PARAGRAPH_CONTENT_XPATH))
                .stream().map(this::getTextFromElement).collect(Collectors.toList());
        if (!isFlexState(applicant.stateCode)) {
            sa.assertEquals(policyPerksTitle, "alt"), "policy Perks", "Print page - Policy Perks Title.");
            sa.assertEquals(policyPerksHeader.getText(), POLICY_PERKS_HEADER_TEXT, "Print page - Policy Perks Header.");
            sa.assertEquals(policyPerksHeaderLink.getText(), "Learn moreopen_in_new", "Print page - Policy Perks Header Link.");
            if (applicant.stateCode.equals(CA)) {
                textPerksHeaders.removeIf(s -> s.startsWith("Declining Deductibles"));
                textPerksContents.removeIf(s -> s.startsWith("Earn $50"));
            } else if (applicant.stateCode.equals(OK)) {
                textPerksHeaders.removeIf(s -> s.startsWith("Claim Free"));
                textPerksContents.removeIf(s -> s.contains("claim-free for three years"));
            }
            sa.assertEquals(perksHeaders, textPerksHeaders, "Print page - Policy Perks Paragraph Header");
            sa.assertEquals(perksContents, textPerksContents, "Print page - Policy Perks Paragraph Content.");
        } else {
            sa.assertTrue(perksHeaders.isEmpty(), "Print page - No Policy Perks Header for Flex states");
            sa.assertTrue(perksContents.isEmpty(), "Print page - No Policy Perks Content for Flex states");
            sa.assertFalse(isElementPresentByXPath(POLICY_PERKS_HEADER_LINK_XPATH), "Print page - No Policy Perks Link for Flex states.");
        }
        -- Disabled until further notice */
    }
}
