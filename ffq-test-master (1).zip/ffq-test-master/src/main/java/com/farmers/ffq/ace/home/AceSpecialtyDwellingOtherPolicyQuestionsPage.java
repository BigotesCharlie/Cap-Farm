package com.farmers.ffq.ace.home;

import static com.farmers.ffq.utils.GlobalVariables.AUTO;
import static com.farmers.ffq.utils.GlobalVariables.DISABLED;
import static com.farmers.ffq.utils.GlobalVariables.SPECIALTY_DWELLING;
import static com.farmers.ffq.utils.GlobalVariables.FOREMOST;
import static com.farmers.ffq.utils.GlobalVariables.HOME;
import static com.farmers.ffq.utils.GlobalVariables.LIFE;
import static com.farmers.ffq.utils.GlobalVariables.UMBRELLA;

import java.time.LocalDate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.farmers.ffq.ace.hrc.common.AceHRCContactInfoBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;

public class AceSpecialtyDwellingOtherPolicyQuestionsPage extends AceHRCContactInfoBasePage {

	public AceSpecialtyDwellingOtherPolicyQuestionsPage() throws Exception {
		super();
	}

	public void fillOutPageAndContinue(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
        enterPolicyStartDate(specialtyDwellingApplicant);
        fillOutBundleAndSave(specialtyDwellingApplicant, SPECIALTY_DWELLING);
        enterMailingAddress(specialtyDwellingApplicant);
        clickOnAgreeAndSubmitButton();
        waitElementBeInvisible(agreeAndSubmitButton);
        longWaitForElementToBeGoneByXpath("//app-rc2-loading");
		while (isElementPresent(By.xpath("//app-rc2-loading"), 2)) {
			//keep waiting for the RC2 page to be dismissed...
			sleep(2);
		}
	}

	public void verifyPageContent(ApplicantAceHome specialtyDwellingApplicant, FarmersSoftAssert fsa) throws Exception {
        validateHeaderAndSubHeaderContactInfoPage(fsa);
        validatePolicyStartDateSection(fsa);
        validateBundleSaveSection(specialtyDwellingApplicant, fsa, SPECIALTY_DWELLING);
        validateContentOfMailingAndOtherMailingAddress(fsa);
        validatePageLinksText(fsa, specialtyDwellingApplicant.getTestCategory().equals(FOREMOST)? FOREMOST : DISABLED);
        validatePageLinksNavigationTitles(fsa);
	}

	private void validatePolicyStartDateSection(FarmersSoftAssert fsa) throws Exception {
		String policyStartDateOnInitialLoad = getValueFromWebElement(policyStartDateOrEstimatedClosingDateInputField);
		LocalDate policyStartDateFromDatePicker = getFormattedDateFromStringDate(policyStartDateOnInitialLoad);
		// Validate policy start date content
		fsa.assertEquals(policyStartDateOnInitialLoad, getFormattedTomorrowDate(), "Policy start date verification on initial load");
		fsa.assertEquals(getTextFromElement(policyStartDateOrEstimatedClosingDateTitle), "When would you like your property policy to begin?", "Policy start date title verification");
		fsa.assertEquals(getTextFromElement(policyStartDateOrEstimatedClosingDatePlaceHolderText), "Policy start date", "Policy start date placeholder text verification");
		policyStartDateOrEstimatedClosingDateInputField.clear();
		// Validate date picker pop up content
		String formattedTodayDate = getFormattedTodayDate();
		waitAndClickElement(datePickerToggleIcon);
		waitAndClickElement(selectedDateInDatePickerPopUp);
		waitAndClickElement(policyStartDateOrEstimatedClosingDateInputField);
		policyStartDateOrEstimatedClosingDateInputField.clear();
		sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, formattedTodayDate);
		waitAndClickElement(datePickerToggleIcon);
		if (!isEndOfTheMonthDate(formattedTodayDate)) {
			WebElement formattedTodayDateWebElement = driver().findElement(By.xpath("//button[*[contains(@class,'mat-calendar-body-today')]]"));
			fsa.assertTrue(isElementDisabled(formattedTodayDateWebElement), "Today's date is disabled in the DatePicker popup");
			waitAndClickElement(formattedTodayDateWebElement);
		}
		String formattedTomorrowDate = getFormattedTomorrowDate();
		policyStartDateOrEstimatedClosingDateInputField.clear();
		sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, formattedTomorrowDate);
		fsa.assertEquals(datePickerToggleIcon.isDisplayed(), true, "DatePicker Toggle Icon Displayed");
		waitAndClickElement(datePickerToggleIcon);
		fsa.assertEquals(String.valueOf(getFormattedDateFromStringDate(getValueFromWebElement(policyStartDateOrEstimatedClosingDateInputField)).getDayOfMonth()).trim(), getTextFromElement(selectedDateInDatePickerPopUp), "Policy Start Date From SqlApplicant check");
		String selectedMonthAndYear = policyStartDateFromDatePicker.getMonth() + " " + policyStartDateFromDatePicker.getYear();
		fsa.assertEquals(selectedMonthAndYear, getTextFromElement(selectedMonthYearHeaderInDatePickerPopUp), "Selected month and year verification in date picker pop up");
		waitAndClickElement(selectedDateInDatePickerPopUp);
	}

	public void validateSnackbarMessages(FarmersSoftAssert fsa) {
        selectBundle(true, AUTO);
        selectBundle(true, HOME);
        selectBundle(true, LIFE);
        selectBundle(true, UMBRELLA);
        fsa.assertTrue(isSnackBarMessageDisplayed("We added a multi-policy discount!"), "Other policy questions page - Multi-policy discount added snackbar message found.");
        selectBundle(false, AUTO);
        selectBundle(false, HOME);
        selectBundle(false, LIFE);
        selectBundle(false, UMBRELLA);
        sleep(3);
        fsa.assertTrue(isSnackBarMessageDisplayed("Multi-policy discount removed."), "Other policy questions page - Multi-policy discount removed snackbar message found.");
	}
}
