package com.farmers.ffq.auto.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Knock Out Page - When Quote Requires Special Attention. 
 */
public class KnockOutPage extends BasePage  {
	
	@FindBy(xpath = "//*[@id='knock-out_header-title'] | //*[@class='knock-out_header-title']")
	private WebElement knockOutHeader;

	@FindBy(xpath = "//*[@id='knock-out_body_quote_number'] | //*[@class='knock-out_body_quote_number']")
	private WebElement knockOutQuoteNumber;
	
	@FindBy(id = "FFQAuto_Modal_discountOutAgentPhone") 
	private WebElement agentPhoneNumber;
	
	@FindBy(id = "FFQAuto_Modal_discountOutMailBtn")
	private WebElement emailAgentButton;
	
	@FindBy(id = "FFQAuto_Modal_discountOutAgentImg")
	private WebElement agentImage;
	
	@FindBy(id = "FFQAuto_Modal_discountOutGoToFarmersTag")
	private WebElement farmersDotComLink;
	
	@FindBy(id = "knock-out_body_noagent")
	private WebElement needmoreHelp;

	@FindBy(id = "knock-out_body_call-custome")
	private WebElement callCustomerService;

	@FindBy(id = "default-phone")
	private WebElement phoneNumber;
	
	@FindBy(id = "FFQAuto_Commonpage_inconvHeader")
	private WebElement inconvenienceHeader;
	
	@FindBy(xpath = "//*[@class='qteNumber ng-binding']")
	private WebElement inconvenienceQuoteNumber;

	@FindBy(id = "FFQAuto_Commonpage_inconvContent")
	private WebElement inconvenienceCallCustomerService;

	@FindBy(id = "FFQAuto_Commonpage_inconvPhone")
	private WebElement invconveniencePhoneNumber;
	
	@FindBy(id = "FFQAuto_Commonpage_inconvFarmersLink")
	private WebElement inconvenienceFarmersDotComLink;

	@FindBy(id = "knockout_title")
	private WebElement restrictedKO_PageHeader;

	@FindBy(xpath = "//app-knockout/form/p")
	private WebElement restrictedKO_body_content;

	@FindBy(xpath = "//app-agent-details//div/div[contains(@class,'agent-details-container')]/p/a[contains(@aria-label,'Contact farmers representative')]")
	private WebElement restrictedKO_agentPhoneNumber;
	
	/**
	 * Constructor.
	 * @throws Exception 
	 */
	public KnockOutPage(String category) throws Exception {
		super();
		switch (category) {
		case SPECIAL_ATTENTION :
		case KNOCKOUT :
			waitElementBeVisible(knockOutHeader);
			break;
		case INCONVENIENCE :
			waitElementBeVisible(inconvenienceHeader);
			break;
			case AWS_REST_ZIP :
				waitElementBeVisible(restrictedKO_PageHeader);
				break;
		default :
			Log.warn("Unknown knockout category: " + category);
			break;
		}
	}
	
	public boolean isOnKnockOutPage() {
	    return isElementDisplayed(knockOutQuoteNumber, 5);
	}
	
	public boolean isOnInconveniencePage() {
	    return isElementDisplayed(inconvenienceQuoteNumber, 5);
	}
	
	public void verifyKnockoutPage(String category) {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		switch (category) {
		case SPECIAL_ATTENTION :
		case KNOCKOUT :
			fsa.assertTrue(getTextFromElement(knockOutHeader).contains("Your quote requires special attention"), "Knockout page title check");
			fsa.assertTrue(knockOutQuoteNumber.isDisplayed(), "Quote Number displayed");
			fsa.assertTrue(getTextFromElement(needmoreHelp).contains("Need more help?"), "\"Need more help?\" check");
			fsa.assertTrue(getTextFromElement(callCustomerService).contains("Call Customer Service"), "\"Call Customer Service\" check");
			fsa.assertTrue(getTextFromElement(phoneNumber).contains("1-800-206-9469"), "Customer service phone number check");
			break;
		case INCONVENIENCE :
			fsa.assertTrue(getTextFromElement(inconvenienceHeader).contains("We apologize for the inconvenience"), "Inconvenience page title check");
			fsa.assertTrue(inconvenienceQuoteNumber.isDisplayed(), "Quote Number check");
			fsa.assertTrue(getTextFromElement(inconvenienceCallCustomerService).contains("Farmers Fast Quote is currently experiencing connectivity errors. We appreciate your patience as we work to resolve this problem. Please try again later and reference your quote number"), "Call Customer Service text check");
			fsa.assertTrue(getTextFromElement(inconvenienceFarmersDotComLink).contains("Go to Farmers.com"), "\"Go to Farmers.com\" link check");
			fsa.assertTrue(getTextFromElement(invconveniencePhoneNumber).contains("(800) 206-9469"), "Customer service phone number check");
			break;
			case AWS_REST_ZIP :
				fsa.assertEquals(getTextFromElement(restrictedKO_PageHeader), "Your quote requires special attention","User landed On AWSREST_KO page");
				fsa.assertEquals(getTextFromElement(restrictedKO_body_content),"Online quotes are not available at this time. Please contact your agent for a quote.", "Text content cehck");
				fsa.assertEquals(getTextFromElement(restrictedKO_agentPhoneNumber), "(248) 468-0222", "Phone number check");
				break;
		default :
			fsa.fail("Unexpected knockout page reached from category: " + category);
			break;
		}
		fsa.assertAll();
	}
}
