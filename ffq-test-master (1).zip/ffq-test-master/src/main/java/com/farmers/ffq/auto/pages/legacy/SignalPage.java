package com.farmers.ffq.auto.pages.legacy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.utils.FarmersSoftAssert;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SignalPage extends AutoBasePage {

	@FindBy(xpath = "//h3")
	private WebElement signalPageHeader;

	@FindBy(xpath = "//div[@class='auto__signal-maincontent']//p")
	private WebElement signalPageDescription;

	@FindBy(xpath = "//a[@data-gtm='FFQ_Auto_Signal_Discount_Learn_More_Link'")
	private WebElement learnMoreLink;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Signal_Discount_Yes_radio']")
	private WebElement yesSignUpForSignalRadioButton;

	private static final String SIGNAL_NO_THANKS_RADIO_BUTTON_XPATH = "//mat-radio-button[@data-gtm='FFQ_Auto_Signal_Discount_No_radio']";
	@FindBy(xpath = SIGNAL_NO_THANKS_RADIO_BUTTON_XPATH)
	private WebElement noThanksRadioButton;

	@FindBy(className = "auto-module__signal-card-text-disclaimer")
	private WebElement signalPageDisclaimer;

	@FindBy(xpath = "//button[@data-gtm='FFQ_Auto_Signal_Discount_next_button']")
	private WebElement nextToMoreDiscountsButton;

	private static final String FOUND_IN = " found in ---> ";
	private static final String SAVE_5PCT = "Want to save 5% on your auto policy?";
	private static final String SAVE_10PCT = "Looking to save 10% on your auto policy?";
	private static final String SIGNAL_PAGE_DESCRIPTION_FIVEPCT = "It's as easy as downloading and using our Signal\u00ae app! Earn a 5% initial discount today and up to 15% each time your policy renews, based on your safe driving.* You can save an additional 10% when you sign up drivers under 25.**";
	private static final String SIGNAL_PAGE_DISCLAIMER_ONE_INITIAL_FIVEPCT = "* Once you enroll in Signal by Farmers, you will receive an initial 5% discount on your Farmers Insurance auto policy. Only one discount can be applied per policy, regardless of the number of enrolled drivers who complete the qualification requirements. If an enrolled driver does not complete 10 trips with the app within 30 days after completing enrollment, the initial discount will be removed back to the enrollment date. At renewal, the Signal\u00ae discount may increase or decrease based on the percentage of enrolled drivers on your auto policy using the app and their driving scores. Your renewal discount could range from 0.5% to 15%.";
	private static final String SIGNAL_PAGE_DISCLAIMER_TWO_RANGE_ONE_TO_FIVEPCT = "** The youthful driver component of the Signal\u00ae factor could range from 1% to 5% and is not broken out separately from the overall Signal\u00ae factor.";
	private static final String SIGNAL_PAGE_DESCRIPTION_TENPCT = "It's as easy as downloading and using our Signal\u00ae app! Earn a 10% initial discount today and up to 35% each time your policy renews based on your safe driving.* An additional 5% will be incorporated when you sign up drivers under 25.**";
	private static final String SIGNAL_PAGE_DISCLAIMER_ONE_INITIAL_TENPCT = "* Once you enroll in Signal by Farmers, you will receive an initial 10% discount on your Farmers Insurance auto policy. Only one discount can be applied per policy, regardless of the number of enrolled drivers who complete the qualification requirements. If an enrolled driver does not complete 10 trips with the app within 30 days after completing enrollment, the initial discount will be removed back to the enrollment date. At renewal, the Signal\u00ae factor may increase or decrease based on the percentage of enrolled drivers on your auto policy using the app and their driving scores. At renewal, your Signal factor will vary.";
	private static final String SIGNAL_PAGE_DISCLAIMER_TWO_RANGE_TWODOTFIVE_TO_TENPCT = "** The youthful driver component of the Signal\u00ae discount could range from 2.5% to 10%.";
	private static final String SIGNAL_PAGE_DISCLAIMER_THREE = "Restrictions apply. Discounts may vary. Not available in all states. Insurance is underwritten by Farmers Insurance Exchange and other affiliated Insurance entities. Visit farmers.com for a complete listing of entities. Not all insurers are authorized to provide insurance in all states. Coverage is not available in all states.";
	private static final String SIGNAL_PAGE_DISCLAIMER_FOUR = "System Requirements "+ 
			"Signal\u00ae requires specific hardware and sensors for the app to function, such as location, network, an accelerometer, and a gyroscope. If the device does not meet the minimum standards, it cannot be used to participate in this program. In addition, the phone must be able to operate on Android 7.0 or newer or iOS 12.0 or newer.";

	public SignalPage() throws Exception {
		super();
	}

	public boolean onSignalPage() {
		return isElementPresent(By.xpath(SIGNAL_NO_THANKS_RADIO_BUTTON_XPATH),2);
	}

	public void validateSignalPage(String applicantStateCode, FarmersSoftAssert fsa) throws Exception {
	    if (isADATestingEnabled()) {
		performADATesting(getClass().getSimpleName(), MARKETING_IT, "Auto");
		screenCapture(signalPageDisclaimer, getClass().getSimpleName(), LOB_AUTO, false);
	    }
		if (!isSmallScreenUsed()) {
			String disclaimerText = getTextFromElement(signalPageDisclaimer);
			if (isFivePercentInitialDiscountState(applicantStateCode)) {
				fsa.assertEquals(getTextFromElement(signalPageHeader), SAVE_5PCT);
				fsa.assertEquals(getTextFromElement(signalPageDescription), SIGNAL_PAGE_DESCRIPTION_FIVEPCT);
				if (!disclaimerText.isEmpty()) {
					fsa.assertTrue(disclaimerText.contains(SIGNAL_PAGE_DISCLAIMER_ONE_INITIAL_FIVEPCT), SIGNAL_PAGE_DISCLAIMER_ONE_INITIAL_FIVEPCT + FOUND_IN + disclaimerText);
					fsa.assertTrue(disclaimerText.contains(SIGNAL_PAGE_DISCLAIMER_TWO_RANGE_TWODOTFIVE_TO_TENPCT), SIGNAL_PAGE_DISCLAIMER_TWO_RANGE_TWODOTFIVE_TO_TENPCT + FOUND_IN + disclaimerText);
				}
			} else {
				fsa.assertEquals(getTextFromElement(signalPageHeader), SAVE_10PCT);
				fsa.assertEquals(getTextFromElement(signalPageDescription), SIGNAL_PAGE_DESCRIPTION_TENPCT);
				if (!disclaimerText.isEmpty()) {
					fsa.assertTrue(disclaimerText.contains(SIGNAL_PAGE_DISCLAIMER_ONE_INITIAL_TENPCT), SIGNAL_PAGE_DISCLAIMER_ONE_INITIAL_TENPCT + FOUND_IN + disclaimerText);
					fsa.assertTrue(disclaimerText.contains(SIGNAL_PAGE_DISCLAIMER_TWO_RANGE_ONE_TO_FIVEPCT), SIGNAL_PAGE_DISCLAIMER_TWO_RANGE_ONE_TO_FIVEPCT + FOUND_IN + disclaimerText);
				}
			}
			if (!disclaimerText.isEmpty()) {
				fsa.assertTrue(disclaimerText.contains(SIGNAL_PAGE_DISCLAIMER_THREE), SIGNAL_PAGE_DISCLAIMER_THREE + FOUND_IN + disclaimerText);
				fsa.assertTrue(disclaimerText.contains(SIGNAL_PAGE_DISCLAIMER_FOUR), SIGNAL_PAGE_DISCLAIMER_FOUR + FOUND_IN + disclaimerText);
			}
		}
	}

	public void continueToDiscountPage(boolean signUpForSignal) {
		scrollToBottomOfPage();
		if (signUpForSignal) {
			scrollAndClickOnElement(yesSignUpForSignalRadioButton);
		} else {
			scrollAndClickOnElement(noThanksRadioButton);
		}
		scrollAndClickOnElement(nextToMoreDiscountsButton);
		waitForSpinnerToBeGone();
		longWaitForElementToBeGoneByXpath(SIGNAL_NO_THANKS_RADIO_BUTTON_XPATH);
	}

	private boolean isFivePercentInitialDiscountState(String stateCode) {
		List<String> fivePercentStates = new ArrayList<>(Arrays.asList(AZ, IL, IN, KS, MO, MN, NV));
		return fivePercentStates.contains(stateCode);
	}

}
