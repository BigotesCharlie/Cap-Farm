package com.farmers.ffq.auto.pages;

import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class KnockoutLeadFormPage extends AutoBasePage {

    private static final String PAGE_TITLE = "Thank you for your interest in Farmers\u00ae";

    private static final String PAGE_MESSAGE = "We're sorry, we are unable to provide you an online quote at this time. Complete this form and we'll have a representative reach out to you to complete your request.";

    final String EXPECTED_CONTACT_INFO_SECTION_TITLE = "How should we contact you?";

    private final String CTA = "We sometimes reach out to consumers by call and/or text to provide helpful information about our products or services. By clicking \"Agree and submit,\" you agree that marketing calls and/or texts can be made to the phone number(s) provided on behalf of Farmers®, Foremost®, Bristol West®, Farmers Life® and 21st Century® insurance entities or their representatives using an automated telephone dialing system and/or an artificial or pre-recorded voice. Your consent is not a condition of purchase.";

    @FindBy(xpath = "//app-knockout-lead-form//h1")
    private WebElement pageTitle;

    @FindBy(css = "p[class='tui-body quote-info']")
    private WebElement pageMessage;

    @FindBy(xpath = "//p[contains(@class,'tui-body quote-reference-number')]")
    private WebElement quoteInfoBody;

    @FindBy(xpath = "//p[@class='tui-body quote-reference-number ng-star-inserted']//span")
    private WebElement displayedQuoteNumber;

    @FindBy(css = "div[class='auto-knockout-lead__fields-section']>p")
    private WebElement contactInfoTitle;

    @FindBy(xpath = "//div[@class='email-address']//input")
    private WebElement emailAddressInputField;

    @FindBy(xpath = "//div[@class='phone-number']//input")
    private WebElement mobilePhoneNumberInputField;

    @FindBy(xpath = "//div[@class='email-address']//mat-error")
    private WebElement emailAddressErrorMessage;

    @FindBy(xpath = "//div[@class='phone-number']//mat-error")
    private WebElement mobilePhoneNumberErrorMessage;

    @FindBy(xpath = "//p[contains(@class,'ffq-lead-form-disclaimer')]")
    private WebElement disclaimer;

    @FindBy(xpath = "//div[contains(@class,'auto-knockout-cta-validation-text-holder')]//span")
    private WebElement ctaErrorMessage;

    @FindBy(id = "ffq-lead-form-submit-button")
    private WebElement ctaButton;

    public boolean isOnKnockoutLeadFormPage() throws Exception {
    	return isElementVisible(pageTitle,10);
    }

    public void enterValuesAndSubmit(AutoApplicant applicant) throws Exception {
        sleep(15);
        sendKeysToElement(getInputFieldByAriaLabelValue("First name"), applicant.getFirstName());
        sendKeysToElement(getInputFieldByAriaLabelValue("Last name"), applicant.getLastName());
        sendKeysToElement(getInputFieldByAriaLabelValue("Date of birth"), applicant.getDateOfBirth());
        enterAddressInputField(applicant);
        if(!applicant.getApartmentNumber().isEmpty()) {
          sendKeysToElement(getInputFieldByAriaLabelValue("Apt"), applicant.getApartmentNumber());
        }

        sendKeysToElement(getInputFieldByAriaLabelValue("Email address"), applicant.getEmail());
        sendKeysToElement(getInputFieldByAriaLabelValue("Mobile phone"), applicant.getPhoneNumber());

        waitAndClickElement(ctaButton);

    }

    private void enterAddressInputField(AutoApplicant applicant) throws Exception {
        WebElement addressInputField = getInputFieldByAriaLabelValue("Address");
        sendKeysToElement(addressInputField, applicant.getResidentAddress());
        sleep(1);
        sendKeysToElement(addressInputField, Keys.ARROW_DOWN);
        sendKeysToElement(addressInputField, Keys.ENTER);
    }

    public void enterAddressContactInfoAndSubmit(AutoApplicant applicant) throws Exception {
        sleep(5);
        enterAddressInputField(applicant);
        sendKeysToElement(getInputFieldByAriaLabelValue("Email address"), applicant.getEmail());
        sendKeysToElement(getInputFieldByAriaLabelValue("Mobile phone"), applicant.getPhoneNumber());

        waitAndClickElement(ctaButton);
    }

    private WebElement getInputFieldByAriaLabelValue(String ariaLabelValue) throws Exception {
        return waitElementBeVisible(driver().findElement(By.xpath(String.format("//mat-label[contains(text(),'%s')]//ancestor::mat-form-field//input", ariaLabelValue))));
    }

    private WebElement getMatLabelValuesForInputFields(String labelValue) throws Exception {
        return driver().findElement(By.xpath(String.format("//mat-label[contains(text(),'%s')]", labelValue)));
    }

    private WebElement getMatErrorElementByAriaLabelValue(String ariaLabelValue) throws Exception {
        sleep(1);
        return driver().findElement(By.xpath(String.format("//mat-label[contains(text(),'%s')]//ancestor::mat-form-field//mat-error", ariaLabelValue)));
    }

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public KnockoutLeadFormPage() throws Exception {
    }

    public void validatePageContent(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isOnKnockoutLeadFormPage(), "User is on Knockout Lead Form Page");
        validateFieldLabels(fsa);
        validateStaticContent(fsa);
    }

    public void validateFieldLabels(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(waitElementBeVisible(getMatLabelValuesForInputFields("First name")).isDisplayed(), "First name input field label displayed");
        fsa.assertTrue(getMatLabelValuesForInputFields("Last name").isDisplayed(), "Last name input field label displayed");
        fsa.assertTrue(getMatLabelValuesForInputFields("Date of birth (mm/dd/yyyy)").isDisplayed(), "Last name input field label displayed");
        fsa.assertTrue(getMatLabelValuesForInputFields("Address").isDisplayed(), "Address input field label displayed");
        fsa.assertTrue(getMatLabelValuesForInputFields("Unit #").isDisplayed(), "Unit # input field label displayed");
        fsa.assertTrue(getMatLabelValuesForInputFields("Email address").isDisplayed(), "Email address input field label displayed");
        fsa.assertTrue(getMatLabelValuesForInputFields("Mobile phone").isDisplayed(), "Mobile phone input field label displayed");
    }

    private void validateStaticContent(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(pageTitle), PAGE_TITLE, "Page title verification");
        fsa.assertEquals(getTextFromElement(pageMessage), PAGE_MESSAGE, "Correct page subheader content");
        fsa.assertEquals(getTextFromElement(contactInfoTitle), EXPECTED_CONTACT_INFO_SECTION_TITLE, "Contact Info Section title");
        fsa.assertEquals(getTextFromElement(disclaimer), CTA, "Disclaimer text verification");
        fsa.assertEquals(getTextFromElement(ctaButton), "Agree and submit", "Button label verification");
        WebElement optionalHintForApt = driver().findElement(By.xpath("//mat-form-field[contains(@id, 'apartment')]//mat-hint"));
        fsa.assertEquals(getTextFromElement(optionalHintForApt), "Optional", "Optional label verification");
        // Ace Auto and Bind - Validate that Quote Number is removed from lead form page for Auto LOB
        String knockoutLeadFormText = getTextFromElement(driver().findElement(By.tagName("app-knockout-lead-form")));
        fsa.assertFalse(knockoutLeadFormText.toLowerCase().contains("quote number"), "Quote number should not be displayed in the content");
    }

    public void validateErrorMessages(FarmersSoftAssert fsa) throws Exception {
        validateRequiredFieldErrorMessages(fsa);
        validateInvalidEntryErrorMessages(fsa);
    }

    private void validateInvalidEntryErrorMessages(FarmersSoftAssert fsa) throws Exception {
        LocalDate localDate = LocalDate.now();
        LocalDate lessThan15Age = localDate.minusYears(15).plusDays(1);
        LocalDate moreThan99Years = localDate.minusYears(99).minusDays(1);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        String formattedLessThen15Years = formatter.format(lessThan15Age);
        String formattedMoreThan99years = formatter.format(moreThan99Years);

        WebElement dateOfBirthInputField = getInputFieldByAriaLabelValue("Date of birth");
        // validate age less than 15
        sendKeysToElement(dateOfBirthInputField, formattedLessThen15Years);
        WebElement dateOfBirthErrorLabel = getMatErrorElementByAriaLabelValue("Date of birth");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(dateOfBirthErrorLabel)), "Age should be between 15 and 99 years.", "Check age less than 15");

        // validate invalid date format
        sendKeysToElement(dateOfBirthInputField, "030333");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(dateOfBirthErrorLabel)), "Date of Birth is not a valid entry.", "Invalid date entry check");

        //validate age more than 99
        sendKeysToElement(dateOfBirthInputField, formattedMoreThan99years );
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(dateOfBirthErrorLabel)), "Age should be between 15 and 99 years.", "Check age greater than 99");

        // invalid email format
        WebElement emailAddressInputField = getInputFieldByAriaLabelValue("Email address");
        sendKeysToElement(emailAddressInputField, "test@yopmail");
        WebElement emailAddressErrorText = getMatErrorElementByAriaLabelValue("Email address");
        fsa.assertEquals(getTextFromElement(emailAddressErrorText), "Email address entered is invalid.", "Invalid email format error check");

        // validate brite verify error message
        sendKeysToElement(emailAddressInputField, "123dahdoteuwqo@gmail.com");
        sleep(2);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(getMatErrorElementByAriaLabelValue("Email address"))), "Email address entered is invalid.", "Invalid email message check");

        // mobile phone invalid entry
        sendKeysToElement(getInputFieldByAriaLabelValue("Mobile phone"), "(000) 000-0000");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(getMatErrorElementByAriaLabelValue("Mobile phone"))), "(000) 000-0000 is not a valid entry.", "Invalid phone number error text check");
    }

    private void validateRequiredFieldErrorMessages(FarmersSoftAssert fsa) throws Exception {
        waitAndClickElement(ctaButton);
        fsa.assertEquals(getTextFromElement(getMatErrorElementByAriaLabelValue("First name")), "Please enter a valid first name.", "First name error text verification");
        fsa.assertEquals(getTextFromElement(getMatErrorElementByAriaLabelValue("Last name")), "Please enter a valid last name.", "lastt name error text verification");
        fsa.assertEquals(getTextFromElement(getMatErrorElementByAriaLabelValue("Date of birth")), "Please provide your date of birth.", "DOB error text verification");
        fsa.assertEquals(getTextFromElement(getMatErrorElementByAriaLabelValue("Address")), "Please enter your address.", "Addres error text verification");
        fsa.assertEquals(getTextFromElement(getMatErrorElementByAriaLabelValue("Email address")), "Please enter your email address.", "Email address error text verification");
        fsa.assertEquals(getTextFromElement(getMatErrorElementByAriaLabelValue("Mobile phone")), "Please enter your phone number.", "Phone number error text verification");
        fsa.assertEquals(getTextFromElement(ctaErrorMessage), "One or more required fields is incomplete or incorrect. Please Review.", "Page error text verification");
    }

}
