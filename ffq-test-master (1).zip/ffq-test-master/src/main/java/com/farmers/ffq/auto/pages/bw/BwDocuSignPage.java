package com.farmers.ffq.auto.pages.bw;

import com.farmers.ffq.auto.pages.AutoBasePage;
import org.mortbay.log.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;

public class BwDocuSignPage extends AutoBasePage {


    @FindBy(xpath = "//input[contains(@data-qa,'ersd-agree-checkbox')]")
    private WebElement disclosureCheckbox;

    @FindBy(xpath = "//button[@aria-describedby='continue-btn-a11y-desc']")
    private WebElement disclosurePopUpContinueButton;

    @FindBy(css = "button[class='btn btn-primary autoNav-relative']")
    private WebElement startButton;

    @FindBy(css = "button[data-qa='auto-nav-caret']")
    private WebElement startButtonAlternative;

    @FindBy(css = "button[data-qa='action-bar-btn-finish-mobile']")
    private WebElement nextButton;

    @FindBy(css = "button[class='btn btn-primary autoNav-relative btn-caret-right']")
    private WebElement initialButton;

    @FindBy(xpath = "//button[contains(@data-qa,'initials-tab-required') and @aria-invalid='true']")
    private List<WebElement> yellowInitials;

    @FindBy(xpath = "//div[contains(@class,'signature-tab-content')]")
    private List<WebElement> yellowSignature;

    @FindBy(xpath = "//input[contains(@name,'signature-style-radio-buttons')]")
    private WebElement signByRadioButton;

    @FindBy(css = "button[data-qa='adopt-submit']")
    private WebElement adoptAndInitial;

    @FindBy(css = "button[id='action-bar-btn-finish']")
    private WebElement finishButton;

    @FindBy(css = "button[id='action-bar-btn-finish-mobile']")
    private WebElement finishButtonMobile;

    @FindBy(xpath = "//div[@data-qa='butter-bar-countdown-content' and contains(.,'required field left')]")
    private WebElement requiredFieldLeft;


    /**
     * Constructor.
     *
     * @throws Exception
     */
    public BwDocuSignPage() throws Exception {
    }

    public boolean isOnDocuSignPage() {
        return isElementVisible(disclosureCheckbox, 100);
    }

    private void agreeDisclosurePopUpAndContinue() {
        if(isElementVisible(disclosureCheckbox,3)) {
            waitAndClickElement(disclosureCheckbox);
            waitAndClickElement(disclosurePopUpContinueButton);
        }
    }

    public void signDocuments() throws Exception {
        isOnDocuSignPage();
        agreeDisclosurePopUpAndContinue();
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(nextButton);
        } else {
            if(isElementVisible(startButtonAlternative, 2)) {
                waitAndClickElement(startButtonAlternative);
            } else {
                waitAndClickElement(startButton);
            }
        }
        sleep(1);
        fillOutInitials();
        fillOutSignatures();

        if(isElementVisible(requiredFieldLeft, 2)) {
            completeRemainingSignatures();
        }
        clickOnFinishButton();
        testStep("Docusign is signed", true);
    }

    private void fillOutInitials() throws Exception {
        sleep(1);
        List<WebElement> initials = driver().findElements(By.xpath("//button[contains(@data-qa,'initials-tab-required') and @aria-invalid='true']"));
    	int numberOfElements = initials.size();
        for (int i =0; i< numberOfElements; i++){
            scrollElementToMiddle(initials.get(i));
            waitAndClickElement(initials.get(i));
            if(i == 0) {
                fillOutAdoptYourInitial();
            }
            sleep(1);
        }
        completeRemainingInitials();
    }

    private void completeRemainingInitials() throws Exception {
        //sign remaining initials
        List<WebElement> stillInvalidInitials = driver().findElements(By.xpath("//div[contains(@class,'initials-tab owned signing-required has-tab-error')]//button"));
    	int numberOfElements = stillInvalidInitials.size();
        for (int i =0; i< numberOfElements; i++){
            waitAndClickElement(stillInvalidInitials.get(i));
        }
    }
    private void completeRemainingSignatures() throws Exception {
        //sign remaining signatures
        List<WebElement> stillInvalidSignatures = driver().findElements(By.xpath("//div[contains(@class,'signing-required') and contains(@class,'signature') and not(contains(@class,'signed'))]"));
    	int numberOfElements = stillInvalidSignatures.size();
        for (int i =0; i< numberOfElements; i++){
            scrollElementToMiddle(stillInvalidSignatures.get(i));
            waitAndClickElement(stillInvalidSignatures.get(i));
        }
    }


    private void fillOutSignatures() throws Exception {
    	int numberOfElements = yellowSignature.size();
        for (int i =0; i < numberOfElements; i++){
            scrollElementToMiddle(yellowSignature.get(i));
            waitAndClickElement(yellowSignature.get(i));
        }
        if(isElementVisible(requiredFieldLeft, 2)) {
            completeRemainingSignatures();
        }
    }

    private void fillOutAdoptYourInitial() {
        if(!isElementVisible(adoptAndInitial,2)) {
            return;
        }
        if (isElementVisible(signByRadioButton,3)) {
            try {
                waitAndClickElement(signByRadioButton);
            } catch (ElementClickInterceptedException interceptedException) {
                Log.info("Element click intercepted: " + interceptedException.getMessage());
                scrollAndClickOnElement(signByRadioButton);
            }
        }
        waitAndClickElement(adoptAndInitial);
    }

    public void clickOnFinishButton() {
        if(isUseMobileViewEnabled()) {
            scrollElementToMiddle(finishButtonMobile);
            waitAndClickElement(finishButtonMobile);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("button[id='action-bar-btn-finish']")));
        } else {
            scrollElementToMiddle(finishButton);
            waitAndClickElement(finishButton);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("button[id='action-bar-btn-finish']")));

        }
        Log.info("DocuSign Finish Button clicked");
    }

}
