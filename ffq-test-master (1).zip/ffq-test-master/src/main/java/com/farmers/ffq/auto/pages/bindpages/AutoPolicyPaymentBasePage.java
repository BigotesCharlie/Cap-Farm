package com.farmers.ffq.auto.pages.bindpages;

import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.datatransferobjects.AppStore.VerifyResponse.PaymentSchedule;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.ONE_PAY;
import static com.farmers.ffq.utils.GlobalVariables.VALUE;

public class AutoPolicyPaymentBasePage extends PolicyPaymentBasePage {
    protected static final String AUTO_POLICY_PAYMENT_HEADER = "Auto policy payment";
    @FindBy(xpath = "//h1[contains(text(), '" + AUTO_POLICY_PAYMENT_HEADER + "')]")
    protected WebElement autoPolicyPaymentHeader;

    private static final String FEES = "Fees";
    @FindBy(xpath = "//p[contains(text(), '" + FEES + "')]")
    protected WebElement feeSideBarHeader;

    public final String AUTO_MEMBERSHIP_FEE_MESSAGE = "A membership fee per vehicle is applied for new auto policies and new vehicles added to your policy. It covers the administrative costs associated with you becoming a member of the insurance exchange and the issuance of your policy.";
    @FindBy(xpath = "//p[contains(text(), 'A membership fee per vehicle is applied ')]")
    protected WebElement membershipFeeMessageSideBar;

    public static final String POLICY_POLICY_FEE_MESSAGE = "A policy fee per vehicle is applied for new auto policies and new vehicles added to your policy. This is for administrative costs associated with writing your new policy.";
    @FindBy(xpath = "//p[contains(text(), 'A policy fee per vehicle is applied for new auto')]")
    protected WebElement policyFeeMessageSideBar;

    public static final String VEHICLE_FEE_MESSAGE = "A fee per vehicle is applied for new auto policies and new vehicles added to your policy. This is for administrative costs associated with writing your new policy.";
    @FindBy(xpath = "//p[contains(text(), 'A fee per vehicle is applied for new auto')]")
    protected WebElement vehicleFeeMessageSideBar;

    private static final String SIX_MONTH_TERM_PAYMENT = "6-month term payment";
    @FindBy(xpath = "//span[contains(text(),'" + SIX_MONTH_TERM_PAYMENT + "')]")
    protected WebElement sixMonthTermPayment;

    @FindBy(xpath = "//span[contains(text(), '6-month term price')]")
    private WebElement sixTermPriceSubHeader;

    @FindBy(xpath = "//span[contains(text(),'" + FEES + "')]")
    protected WebElement fees;

    private static final String SET_UP_PAYMENT_METHOD = "Set up payment method";
    @FindBy(xpath = "//button[contains(text(),'" + SET_UP_PAYMENT_METHOD + "')]")
    private WebElement setUpPaymentMethodButton;

    @FindBy(xpath = "//mat-icon[contains(text(), 'close')]")
    private WebElement addPaymentMethodContainerCloseIcon;

    @FindBy(xpath = "//mat-dialog-container[@aria-labelledby='addPaymentHeading']")
    private WebElement addPaymentMethodDialogContainer;

    private static final String PAYMENTUS_MANAGE_PAYMENT = "Paymentus Manage Payments";
    @FindBy(xpath = "//iframe[@title = '" + PAYMENTUS_MANAGE_PAYMENT + "']")
    private WebElement paymentUsIframe;

    private static final String ADD_BUTTON = "ADD";
    @FindBy(xpath = "//button[text() = '" + ADD_BUTTON + "']")
    private WebElement addButton;

    private static final String ADD_PAYMENT_METHOD_LABEL = "Add payment method";
    @FindBy(xpath = "//span[text() = '" + ADD_PAYMENT_METHOD_LABEL + "']")
    private WebElement addPaymentMethodLabel;

    private static final String PAPERLESS_TERMS_OF_USE = "Paperless Terms of Use";
    @FindBy(xpath = "//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]")
    private WebElement paperlessTermsOfUseLink;

    private static final String INFORMATION_STORAGE_AUTHORIZATION = "Information Storage Authorization";
    @FindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]")
    private WebElement informationStorageAuthorizationLink;

    private static final String PAYMENT_AUTHORIZATION = "Payment Authorization Terms & Conditions.";
    @FindBy(xpath = "//a[contains(text(), '" + PAYMENT_AUTHORIZATION + "')]")
    private WebElement paymentAuthorizationLink;


    List<WebElement> listOfLinksToClick = Arrays.asList(paperlessTermsOfUseLink, informationStorageAuthorizationLink, paymentAuthorizationLink);
    private static final String TERMS_AND_CONDITIONS_TITLE = "Terms of Use | Farmers Insurance";
    private static final String PAYMENT_AUTHORIZATION_TITLE = "Payment Authorization Terms and Conditions | Farmers Insurance";
    private static final String INFORMATION_STORAGE_AUTHORIZATION_TITLE = "Payment Card Storage Terms & Conditions | Farmers Insurance";

    private static final List<String> listOfTabTitles = Arrays.asList(TERMS_AND_CONDITIONS_TITLE, INFORMATION_STORAGE_AUTHORIZATION_TITLE, PAYMENT_AUTHORIZATION_TITLE);


    private static final String BY_CLICKING_COMPLETER_PURCHASE = "By clicking \"Complete purchase\" below:";
    @FindBy(xpath = "//div[contains(text(), '" + BY_CLICKING_COMPLETER_PURCHASE + "')]")
    private WebElement byClickingCompletePurchaseLabel;

    private static final String READ_AND_AGREED_TO_THE_BULLET_ONE = "I confirm that I have read and agree to the Paperless Terms of Use; and";
    @FindBy(xpath = "//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]/parent::p")
    private WebElement readAndAgreedToTheBulletPointOne;

    public static final String IF_DO_NOT_AGREE_WITH_TERMS = "If you do not agree with the Terms and Conditions above and/or have any questions, please contact your agent or Farmers Direct Sales Center to complete this transaction. You can always change your Paperless and Automatic Payment settings for future transactions by logging in to your Farmers.com account.";
    @FindBy(xpath = "//p[contains(text(), 'If you do not agree with the Terms and Conditions above ')]")
    private WebElement ifDoNotAgreeWithTermsAndConditionLabel;

    private static final String PAYMENT_METHOD_ALREADY_ADDED_ERROR = "You have already saved this payment method. Cannot save duplicate.";
    @FindBy(xpath = "//li[@id='profile']")
    private WebElement paymentMethodAlreadyAdded;

    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO_MONTHLY_PAY = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate One-Time and Automatic Payment processes.";
    @FindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p")
    private WebElement readAndAgreedToTheBulletPointTwoMonthlyPay;

    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate:";
    @FindBy(xpath = "//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p")
    private WebElement readAndAgreedToTheBulletPointTwo;

    private static final String CARD_NUMBER_LABEL = "Card Number";
    @FindBy(xpath = "//label[text() = '" + CARD_NUMBER_LABEL + "']")
    private WebElement cardNumberLabel;

    private static final String EXPIRATION_DATE_LABEL = "Expiration Date";
    @FindBy(xpath = "//label[text() = '" + EXPIRATION_DATE_LABEL + "']")
    private WebElement expirationDateLabel;

    private static final String CARD_SECURITY_CODE_LABEL = "Card Security Code (CVV)";
    @FindBy(xpath = "//label[text() = '" + CARD_SECURITY_CODE_LABEL + "']")
    private WebElement cardSecurityCodeLabel;

    private static final String BILLING_ZIP_CODE_LABEL = "Billing ZIP Code";
    @FindBy(xpath = "//label[text() = '" + BILLING_ZIP_CODE_LABEL + "']")
    private WebElement billingZipCodeLabel;

    @FindBy(xpath = "//div[contains(@class,'methodVisa')]")
    private WebElement visaCardIconInARow;

    @FindBy(xpath = "//div[contains(@class,'methodDiscover')]")
    private WebElement masterCardIconInARow;


    @FindBy(xpath = "//div[contains(@class,'methodDiscover')]")
    private WebElement discoverCardIconInARow;

    @FindBy(xpath = "//div[contains(@class,'methodAmex')]")
    private WebElement amexCardIconInARow;

    private static final String NAME_ON_CARD_LABEL = "Name On Card";
    @FindBy(xpath = "//label[text() = '" + NAME_ON_CARD_LABEL + "']")
    private WebElement nameOnCardLabel;

    @FindBy(xpath = "//input[@id='cardHolderField']")
    private WebElement nameOnCardInPutField;

    private static final String ENTER_YOUR_NAME_ERROR = "Please enter your name exactly as it appears on your card.";
    @FindBy(xpath = "//span[contains(text(),'" + ENTER_YOUR_NAME_ERROR + "')]")
    private WebElement enterYourNameOnCardError;


    private static final String ENTER_VALID_CARD_NUMBER_ERROR = "Please enter a valid card number.";
    @FindBy(xpath = "//span[contains(text(),'" + ENTER_VALID_CARD_NUMBER_ERROR + "')]")
    private WebElement enterValidCardNumberError;

    private static final String ENTER_VALID_EXP_DATE_ERROR = "Please enter a valid expiration date MM/YY.";
    @FindBy(xpath = "//span[contains(text(),'" + ENTER_VALID_EXP_DATE_ERROR + "')]")
    private WebElement enterValidExpDateError;

    private static final String ENTER_VALID_CVV_NUMBER_ERROR = "Please enter a valid CVV.";
    @FindBy(xpath = "//span[contains(text(),'" + ENTER_VALID_CVV_NUMBER_ERROR + "')]")
    private WebElement enterValidCVVNumberError;

    private static final String ENTER_VALID_BILLING_ZIP_ERROR = "Please enter a valid CVV.";
    @FindBy(xpath = "//span[contains(text(),'" + ENTER_VALID_BILLING_ZIP_ERROR + "')]")
    private WebElement enterValidZipNumberError;


    @FindBy(xpath = "//input[@id='cardCVVField']")
    private WebElement cardSecurityCodeInputField;


    @FindBy(xpath = "//input[@id='zipCode']")
    private WebElement billingZipCodeInputField;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AutoPolicyPaymentBasePage() throws Exception {

    }

    public boolean isAutoPolicyPaymentHeaderCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(autoPolicyPaymentHeader), AUTO_POLICY_PAYMENT_HEADER);
    }

    public boolean isSixMonthTermPaymentCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(sixMonthTermPayment), SIX_MONTH_TERM_PAYMENT);
    }

    public boolean isPolicyFeesCorrect() {
        return isExpectedTextDisplayed(fees, FEES);
    }

    public boolean isMembershipFeesSideBarMsgCorrect() {
        return isExpectedTextDisplayed(membershipFeeMessageSideBar, AUTO_MEMBERSHIP_FEE_MESSAGE);
    }

    public boolean isPolicyFeesSideBarMsgCorrect() {
        return isExpectedTextDisplayed(policyFeeMessageSideBar, POLICY_POLICY_FEE_MESSAGE);
    }

    public boolean isVehicleFeesSideBarMsgCorrect() {
        return isExpectedTextDisplayed(vehicleFeeMessageSideBar, VEHICLE_FEE_MESSAGE);
    }

    @Override
    public boolean goBackToHowWouldYouLikeToPayPage() throws Exception {
        driver().navigate().back();
        return isExpectedTextDisplayed(howWouldYouLikeToPay, HOW_WOULD_YOU_LIKE_TO_PAY);
    }

    public boolean isSixTermPriceSubHeaderDisplayed() {
        return waitElementBeVisible(sixTermPriceSubHeader).isDisplayed();
    }

    public boolean isSixMonthTermPriceAmountDisplayed(String payPlanDescription) throws Exception {
        PaymentSchedule payPlanSchedule = filterListOfPaymentScheduleByPayPlan(getAutoVerifyRateResponse().getPaymentSchedules(), payPlanDescription).get(0);
        String fullTermPremium = payPlanSchedule.getFullTermPremium();
        String expectedSixMonthTotalPremium;
        if (payPlanDescription.equals(ONE_PAY)) {
            Double doublePolicyFees = doublePolicyFeeAmount(getAutoVerifyRateResponse().getPolicyFee().getAmount());
            Double sixMonthTermPriceAmount = Double.parseDouble(fullTermPremium) + doublePolicyFees;
            expectedSixMonthTotalPremium = String.format("$%,.2f for 6-month term price", sixMonthTermPriceAmount);
        } else {
            expectedSixMonthTotalPremium = String.format("$%,.2f for 6-month term price", Double.parseDouble(fullTermPremium));
        }

        return getTextFromElement(sixTermPriceSubHeader).equals(expectedSixMonthTotalPremium);
    }

    public boolean isAutoPolicyPaymentPageDisplayed() throws Exception {
        waitElementBeVisible(autoPolicyPaymentHeader);
        return isExpectedTextDisplayed(autoPolicyPaymentHeader, AUTO_POLICY_PAYMENT_HEADER);
    }


    public boolean isCardNumberLabelCorrect() {
        return isExpectedTextDisplayed(cardNumberLabel, CARD_NUMBER_LABEL);
    }

    public boolean isExpirationDateCorrect() {
        return isExpectedTextDisplayed(expirationDateLabel, EXPIRATION_DATE_LABEL);
    }

    public boolean isCardSecurityCodeLabelCorrect() {
        return isExpectedTextDisplayed(cardSecurityCodeLabel, CARD_SECURITY_CODE_LABEL);
    }

    public boolean isBillingZipCodeLabelCorrect() {
        return isExpectedTextDisplayed(billingZipCodeLabel, BILLING_ZIP_CODE_LABEL);
    }

    public boolean isVisaCardIconInRowDisplayed() {
        return visaCardIconInARow.isDisplayed();
    }

    public boolean isMasterCardIconInRowDisplayed() {
        return masterCardIconInARow.isDisplayed();
    }

    public boolean isDiscoverCardIconInRowDisplayed() {
        return discoverCardIconInARow.isDisplayed();
    }

    public boolean isAmexCardIconInRowDisplayed() {
        return amexCardIconInARow.isDisplayed();
    }

    public boolean isNameOnCardLabelCorrect() {
        return isExpectedTextDisplayed(nameOnCardLabel, NAME_ON_CARD_LABEL);
    }

    protected String getValueForFullNamePaymentusFrame() {
        return getAttributeData(nameOnCardInPutField, VALUE);
    }

    public void clearOutCardHolderNameInputField() {
        nameOnCardInPutField.clear();
    }

    public boolean isEnterYourNameErrorCorrect() {
        return isExpectedTextDisplayed(enterYourNameOnCardError, ENTER_YOUR_NAME_ERROR);
    }

    public boolean isEnterCardNumberErrorCorrect() {
        return isExpectedTextDisplayed(enterValidCardNumberError, ENTER_VALID_CARD_NUMBER_ERROR);
    }

    public boolean isEnterEXPDateNumberErrorCorrect() {
        return isExpectedTextDisplayed(enterValidExpDateError, ENTER_VALID_EXP_DATE_ERROR);
    }

    public boolean isEnterCVVNumberErrorCorrect() {
        return isExpectedTextDisplayed(enterValidCVVNumberError, ENTER_VALID_CVV_NUMBER_ERROR);
    }

    public boolean isEnterBillingZipCodeErrorCorrect() {
        return isExpectedTextDisplayed(enterValidZipNumberError, ENTER_VALID_BILLING_ZIP_ERROR);
    }

    public void enterCVVNumber(String cvvNumber) {
        sendKeysOneByOne(cardSecurityCodeInputField, cvvNumber);
    }

    public void enterBillingZipCode(String billingZipCode) {
        sendKeysOneByOne(billingZipCodeInputField, billingZipCode);
    }


    protected void enterNameOnCard(String nameOnCard) {
        sendKeysOneByOne(nameOnCardInPutField, nameOnCard);
    }

    public void validateBDQSpecificRequirements(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isDiscountSectionDisplayed(), "Discount section should be displayed on " + this.getClass().getSimpleName());
        validateValidateAndFooterForBDQ(fsa, applicant, this);
        validateAgentSectionBDQ(fsa, applicant);
    }

    public List<String> getTheListOfEligiblePaymentMethods() throws Exception {
        final String locator = "//span[@class='pov2__plan-title']";
        Log.info("Collecting eligible payment methods. locator=" + locator);
        List<WebElement> candidates = driver().findElements(By.xpath(locator));
        Log.info("Found candidate payment method elements: " + candidates.size());

        List<String> methods = candidates.stream()
                .map(element -> {
                    String rawText = getTextFromElement(element);
                    if (rawText == null) {
                        Log.info("Skipping payment method element because text is null");
                        return "";
                    }
                    String normalized = rawText.replaceAll("[$0-9.]", "").trim();
                    Log.info("Payment method text parsed. raw='" + rawText + "', normalized='" + normalized + "'");
                    return normalized;
                })
                .filter(text -> !text.isBlank())
                .distinct()
                .collect(Collectors.toList());
        Log.info("Eligible payment methods extracted: " + methods);
        return methods;
    }

    public List<String> getTheListOfEligiblePaymentMethodsOldPaymentPage() throws Exception {
        final String locator = "//tui-presentment-card-header//h2";
        Log.info("Collecting eligible payment methods. locator=" + locator);
        List<WebElement> candidates = driver().findElements(By.xpath(locator));
        Log.info("Found candidate payment method elements: " + candidates.size());

        List<String> methods = candidates.stream()
                .map(element -> {
                    String rawText = getTextFromElement(element);
                    if (rawText == null) {
                        Log.info("Skipping payment method element because text is null");
                        return "";
                    }
                    String normalized = rawText.replaceAll("[$0-9.]", "").trim();
                    Log.info("Payment method text parsed. raw='" + rawText + "', normalized='" + normalized + "'");
                    return normalized;
                })
                .filter(text -> !text.isBlank())
                .distinct()
                .collect(Collectors.toList());
        Log.info("Eligible payment methods extracted: " + methods);
        return methods;
    }

}
