package com.farmers.ffq.auto.pages;

import com.farmers.ffq.common.enums.AceAutoSupportedOccupationByState;
import com.farmers.ffq.common.enums.Occupations;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.RandomUtils;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.auto.pages.DriverReviewPage.NG_VALID;
import static com.farmers.ffq.auto.pages.VehicleReviewPage.*;
import static com.farmers.ffq.dataproviders.AutoDataProviders.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class VehiclesDriversInfoPage extends HeresWhatWeFoundPage {

    //Driver checbox texts
    private final String MARRIED_CHECKBOX_TEXT = "Married or in a domestic partnership";
    private final String MARRIED_CHECKBOX_SUB_TEXT = "Check to add your spouse or partner (do not check if you are separated, widowed, or divorced)";
    private final String ACCIDENT_CHECKBOX_TEXT = "Had an accident or violation in last 5 years";
    private final String ACCIDENT_CHECKBOX_SUB_TEXT = "At fault or no fault accident or moving violations only";
    private final String FINANCIAL_RESPONSIBILITY_CHECKBOX_TEXT = "Requires a financial responsibility filing (SR-22/FR-44)";
    private final String SAFETY_COURSE_OR_LABEL = "Has completed a driver safety course in the last 2 years";
    private final String SAFETY_COURSE_CHECKBOX_TEXT = "Has completed a driver safety course in the last 3 years";
    private final String SAFETY_COURSE_CHECKBOX_SUB_TEXT = "Special defensive driver course designed for drivers over 55 years old";
    private final String HAS_A_GPA_OVER_3 = "Has a GPA over 3.0";
    private final String MUST_BE_FULL_TIME = "Must be a full-time student";
    private final String HAS_HAD_DRIVER_LICENSE_IN_LESS_THAN_3_YEARS = "Has had driver's license for less than 3 years";
    private final String DISTANT_STUDENT_CHECKBOX_TEXT = "Attends school more than 100 miles away from home without custody of a car";
    private final String NOT_RELATED_TO_ME = "Not related to me (i.e roommate, friend)";
    private final String DOES_NOT_LIVE_IN_HOUSE = "Does not live in my household";
    private final String IS_DISABLED = "Is disabled";
    private final String LIVES_AWAY_FROM_HOME = "Lives away from home";
    private final String SHARES_VEHICLE_USAGE_IN_HOUSEHOLD = "Shares vehicle usage in household";
    // states specifics
    private static final Set<String> STATES_WITHOUT_FIN_RESP = Set.of(CA, KY, MA, NM);

    //xpaths
    private String DRIVER_CARD_XPATH = "//div[contains(@class,'card auto-drivers-card-item') and contains(.,'%s')]";
    private String VEHICLE_VIN_ERROR_MESSAGE_XPATH = "//p[contains(@class,'auto-vehicles-drivers-review__error-message tui-body-text')]";

    @FindBy(xpath = "//app-vehicles-drivers-main-screen//h1")
    private WebElement vehiclesDriversPageTitle;

    @FindBy(xpath = "//div[contains(@class,'auto-drivers-card') and contains(text(),'Additional driver')]/../../following-sibling::div/div/a[contains(text(),'Edit driver')]")
    private List<WebElement> listOfAllEditButtonOfAdditionalDriverDetails;

    public VehiclesDriversInfoPage() throws Exception {
    }

    public boolean isOnVehiclesDriversInfoPage() {
        return isElementVisible(vehiclesDriversPageTitle, 20);
    }

    @FindBy(xpath = "//div[contains(@class,'highlighted-tooltip-card')]/div")
    private WebElement pageDesc;

    //Locators on the main page
    @FindBy(xpath = "//button[@class='tui-btn tui-btn-cta add-button ng-star-inserted' and contains(.,'Add another driver')]")
    private WebElement addAnotherDriverButton;
    @FindBy(xpath = "//button[@class='tui-btn tui-btn-cta add-button ng-star-inserted' and contains(.,'Add another vehicle')]")
    public WebElement addAnotherVehicleButton;
    @FindBy(xpath = "//app-vehicle-card//div[@class='h6 custom-h6 fw-semibold']")
    public List<WebElement> foundVehicles;
    @FindBy(xpath = "//app-vehicle-card//a[contains(text(),'Edit')]")
    private List<WebElement> editVehicleLinks;
    @FindBy(xpath = "//div[@class='card auto-vehicles-card-item vehicle-selected']//input")
    public List<WebElement> selectedVehiclesCheckboxes;
    @FindBy(xpath = "//div[@class='card auto-vehicles-card-item vehicle-selected']//a")
    private List<WebElement> selectedVehiclesEditReviewButton;
    private final String UNSELECTED_VEHICLE_CARD_XPATH = "//div[@class='card auto-vehicles-card-item vehicle-unselected']";
    @FindBy(xpath = UNSELECTED_VEHICLE_CARD_XPATH + "//input[@type='checkbox']")
    public List<WebElement> uncheckedVehiclesCheckboxes;
    @FindBy(xpath = "//app-driver-card//div[contains(@class,'driver-name-header')]")
    private List<WebElement> foundDrivers;
    @FindBy(xpath = "//div[@class='card auto-drivers-card-item driver-selected']//div[contains(@class,'driver-name-header')]")
    public List<WebElement> selectedDrivers;
    private final String UNSELECTED_DRIVER_CARD_XPATH = "//div[contains(@class,'card auto-drivers-card-item driver-unselected')]";
    @FindBy(xpath = UNSELECTED_DRIVER_CARD_XPATH + "//input[@type='checkbox']")
    private List<WebElement> uncheckedDriversCheckboxes;
    @FindBy(xpath = UNSELECTED_DRIVER_CARD_XPATH + "//div[contains(@class,'driver-name-header')]")
    public List<WebElement> uncheckedDriversNames;
    @FindBy(xpath = "//div[contains(@class,'cta-section')]//button[@class='tui-btn tui-btn-primary']")
    private WebElement continueButton;

    //Side sheets (info or helper) icons header locators like back or close button and header
    @FindBy(xpath = "//div[@class='heading-area']//mat-icon[contains(.,'chevron_left')]")
    private WebElement infoSideSheetBackButton;
    @FindBy(xpath = "//app-occupation-selection//mat-icon[.='chevron_left']")
    private WebElement occupationSelectionModalLeftChevron;
    @FindBy(xpath = "//app-help-text-sidesheet//h1")
    private WebElement infoSideSheetHeader;
    @FindBy(xpath = "//app-help-text-sidesheet//div[@class='heading-area']//button[contains(.,'close')]")
    private WebElement infoSideSheetCloseButton;
    @FindBy(xpath = "//div[contains(@class,'help-text-sidesheet-container')]//h2")
    private List<WebElement> infoSideSheetContentHeaders;
    @FindBy(xpath = "//div[contains(@class,'help-text-sidesheet-container')]//p")
    private List<WebElement> infoSideSheetContents;

    // Locator on Add vehicle side sheet
    @FindBy(xpath = "//app-vehicle-form//h1")
    private WebElement addOrEditVehicleSideSheetHeader;
    @FindBy(css = "input[formcontrolname='vin']")
    private WebElement vinInputField;
    @FindBy(xpath = "//mat-form-field[contains(.,'VIN')]//mat-error")
    private WebElement vinInputFieldErrorMessage;
    @FindBy(xpath = "//mat-form-field[contains(.,'VIN')]//mat-hint")
    private WebElement weWillVerifyYourVinText;
    @FindBy(xpath = "//mat-form-field[contains(.,'Year')]//mat-error")
    private WebElement yearErrorMessage;
    @FindBy(xpath = "//div[@class='section ng-star-inserted' and contains(.,'When did you acquire')]//mat-error")
    private WebElement acquireErrorMessage;
    @FindBy(xpath = "//mat-form-field[contains(.,'First name')]//mat-error")
    private WebElement firstNameErrorMessage;
    @FindBy(xpath = "//mat-form-field[contains(.,'First name')]//input")
    private WebElement firstName;
    @FindBy(xpath = "//mat-form-field[contains(.,'Last name')]//mat-error")
    private WebElement lastNameErrorMessage;
    @FindBy(xpath = "//mat-form-field[contains(.,'Date of birth')]//input")
    private WebElement dobEntryField;
    @FindBy(xpath = "//mat-form-field[contains(.,'Date of birth')]//mat-error")
    private WebElement dobErrorMessage;
    @FindBy(xpath = "//div[@aria-label='Please select your gender']//mat-error")
    private WebElement genderErrorMessage;
    @FindBy(xpath = "//div[@aria-label=\"Please select spouse's gender\"]//mat-error")
    private WebElement spouseGenderErrorMessage;
    @FindBy(xpath = "//div[@aria-label=\"Is this driver’s license issued by a U.S. state, U.S. territory, or Canadian province?\"]//mat-error")
    private WebElement usOrCaErrorMessage;
    @FindBy(xpath = "//div[contains(@aria-label,'be driving')]//mat-error")
    private WebElement willBeDrivingErrorMessage;
    @FindBy(xpath = "//div[@aria-label='Are you currently insured?']//mat-error")
    private WebElement currentlyInsuredErrorMessage;
    @FindBy(id = "close-button")
    private WebElement closeButtonForSpouseNestedSheet;

    // Locators for Vin helper icon and side sheet
    @FindBy(xpath = "//div[@class='row']//mat-icon[contains(.,'info')]")
    private WebElement vinHelperInfoTip;
    @FindBy(css = "div[class='vin-content']")
    private WebElement helperVinContent;
    @FindBy(xpath = "//div[@class='tui-vin-modal ng-star-inserted']//div[2]/p")
    private WebElement driverSideDoorText;
    @FindBy(xpath = "//div[@class='tui-vin-modal ng-star-inserted']//div[2]/div")
    private WebElement driverSideDoorImage;
    @FindBy(xpath = "//div[@class='tui-vin-modal ng-star-inserted']//div[3]/p")
    private WebElement driverSideDashboardText;
    @FindBy(xpath = "//div[@class='tui-vin-modal ng-star-inserted']//div[3]/div")
    private WebElement driverSideDashboardImage;
    @FindBy(xpath = "//div[@class='tui-vin-modal ng-star-inserted']//div[4]/div")
    private WebElement registrationAndInsuranceCardImage;

    //vin description section
    @FindBy(css = "mat-icon[aria-label='VIN information icon']")
    private WebElement vinInfoIcon;
    @FindBy(css = "div[class='vin-description-header']>p")
    private WebElement vinDescHeader;
    @FindBy(css = "div[class='vin-description-header']>svg")
    private WebElement vinDescCarImage;
    @FindBy(xpath = "//div[@class='vin-description-content mt-1']//mat-icon")
    private WebElement vinDescGreenCheck;
    @FindBy(xpath = "//div[@class='vin-description-content mt-1']//p")
    private WebElement vinDescContent;
    @FindBy(css = "button[class*='tui-btn tui-btn-link vin-remove-button']>mat-icon")
    private WebElement vinRemoveButtonDeleteIcon;
    @FindBy(css = "button[class='tui-btn tui-btn-link vin-remove-button']")
    private WebElement vinRemoveButton;

    // Vin tips section
    @FindBy(xpath = "//ul[contains(@class,'tips-list')]/..//p")
    private WebElement vinTipsText;
    @FindBy(xpath = "//ul[contains(@class,'tips-list')]//li")
    private List<WebElement> vinTipsLists;


    @FindBy(css = "mat-select[formcontrolname='year']")
    private WebElement yearDropDown;
    @FindBy(xpath = "//mat-select[@formcontrolname='year']/..//label")
    private WebElement yearDropDownLabel;
    @FindBy(xpath = "//mat-form-field[contains(.,'make')]//input")
    private WebElement makeInputField;
    @FindBy(xpath = "//mat-form-field[contains(.,'make')]//label")
    private WebElement makeInputLabel;
    @FindBy(xpath = "//mat-form-field[contains(.,'model')]//input")
    private WebElement modelInputField;
    @FindBy(xpath = "//mat-form-field[contains(.,'model')]//label")
    private WebElement modelInputLabel;
    @FindBy(css = "mat-select[formcontrolname='type']")
    private WebElement typeDropDown;
    @FindBy(xpath = "//mat-select[@formcontrolname='type']/..//label")
    private WebElement typeDropDownLabel;


    // Vehicle Used for section
    @FindBy(xpath = "//div[@class='section' and contains(.,'Used for')]//div[contains(@class,'section-label')]/div[1]")
    private WebElement usedForSectionLabel;
    @FindBy(xpath = "//div[@class='section' and contains(.,'Used for')]//div[contains(@class,'section-label')]//mat-icon")
    private WebElement usedForSInfoIcon;
    @FindBy(xpath = "//div[@class='section' and contains(.,'Used for')]//button[@aria-pressed='true']")
    private WebElement defaultPressedUsedForButton;
    @FindBy(xpath = "//button[contains(.,'Personal')]")
    private WebElement personalButton;
    @FindBy(xpath = "//button[contains(.,'Business')]")
    private WebElement businessButton;
    @FindBy(xpath = "//mat-checkbox[@formcontrolname='rideshare']//input")
    private WebElement rideshareCheckboxInput;
    @FindBy(xpath = "//mat-checkbox[@formcontrolname='rideshare']//div[@class='column']//div[1]")
    private WebElement rideshareCheckboxText;
    @FindBy(xpath = "//mat-checkbox[@formcontrolname='rideshare']//div[@class='column']//div[2]")
    private WebElement uberLiftParenthesisInfo;

    // Vehicle Ownership section
    @FindBy(xpath = "//div[@class='section' and contains(.,'Ownership')]//div[contains(@class,' label')]")
    private WebElement ownershipSectionHeader;
    @FindBy(xpath = "//div[@class='section' and contains(.,'Ownership')]//div[contains(@class,'section-label')]//mat-icon")
    private WebElement ownershipSectionInfoIcon;
    @FindBy(xpath = "//div[@class='section' and contains(.,'Ownership')]//button[@aria-pressed='true']")
    private WebElement defaultPressedOwnershipToggle;
    @FindBy(xpath = "//button[contains(.,'Owned')]")
    private WebElement ownedToggle;
    @FindBy(xpath = "//button[contains(.,'Leased')]")
    private WebElement leasedToggle;
    @FindBy(xpath = "//button[contains(.,'Financed')]")
    private WebElement financedToggle;

    // vehicle acquire section
    @FindBy(xpath = "//div[@class='section' and contains(.,'When')]//div[contains(@class,' label')]")
    private WebElement acquiredSectionHeader;
    @FindBy(xpath = "//div[@class='section' and contains(.,'When')]//div[contains(@class,'section-label')]//mat-icon")
    private WebElement acquiredSectionMatIcon;
    @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'When')]//input")
    private WebElement acquiredSectionDateInputField;
    @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'When')]//button")
    private WebElement acquiredSectionDatePicker;
    @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'When')]//mat-hint")
    private WebElement acquiredSectionDateInputFieldHint;

    // parked at section
    @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'Where is the vehicle usually parked?')]//div//span")
    private WebElement parkedAtSectionHeader;
    @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'Where is the vehicle usually parked?')]//div//mat-icon")
    private WebElement parkedAtSectionInfoIcon;
    @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'Where is the vehicle usually parked?')]//mat-radio-button[@value='primary']")
    private WebElement parkedAtPrimaryRadioButton;
    @FindBy(xpath = "//div[contains(@class,'section') and contains(.,'Where is the vehicle usually parked?')]//mat-radio-button[@value='other']//input")
    private WebElement parkedAtOtherRadioButton;
    @FindBy(xpath = "//input[@aria-label='Garaging address']")
    private WebElement otherGarageAddressInputField;
    @FindBy(xpath = "//input[@formcontrolname='apartment']")
    private WebElement otherGarageApartmentInputField;
    @FindBy(xpath = "//input[@formcontrolname='city']")
    private WebElement otherGarageCityInputField;
    @FindBy(xpath = "//input[@formcontrolname='state']")
    private WebElement otherGarageStateInputField;
    @FindBy(xpath = "//input[@formcontrolname='zip']")
    private WebElement otherGarageZipInputField;
    @FindBy(css = "mat-checkbox[formcontrolname='theftRecovery']")
    private WebElement theftRecoveryCheckbox;


    // Vehicle side sheet bottom locators
    @FindAll({
            @FindBy(css = "button[class='tui-btn tui-btn-primary ng-star-inserted']"),
            @FindBy(xpath = "//app-vehicle-form//button[contains(.,'Add Vehicle')]")
    })
    private WebElement addVehicleButton;
    @FindBy(css = "button[class='tui-btn tui-btn-link base-cancel-button ng-star-inserted']")
    private WebElement cancelButton;

    @FindBy(xpath = "//app-base-sidesheet//button[contains(@class,'tui-btn tui-btn-cta add-button')]")
    private WebElement addAnotherVehicleButtonSideSheet;
    @FindBy(xpath = "//app-base-sidesheet//button[contains(.,'Done adding vehicles')]")
    private WebElement doneAddingVehiclesSideSheet;
    @FindBy(xpath = "//app-base-sidesheet//button[contains(.,'Continue to drivers')]")
    private WebElement continueToDriversButtonSideSheet;
    @FindBy(xpath = "//app-vehicle-form//button[.='Save changes']")
    private WebElement addVehiclesSaveChangesButton;

    // Locators on the add and edit driver side sheet
    @FindBy(xpath = "//app-driver//h1")
    private WebElement addEditDriverHeader;
    @FindBy(css = "a[id='add-incident-button']")
    private WebElement addAnotherIncident;
    @FindBy(xpath = "//app-base-sidesheet[contains(.,'Add a spouse')]//a[@id='add-incident-button']")
    private WebElement addAnotherIncidentNestedSpouse;
    @FindBy(xpath = "//a[@aria-label='Change Spouse Selection']")
    private WebElement changeSpouseSelectionLink;
    @FindBy(xpath = "//mat-radio-button[contains(.,'not ')]")
    private WebElement someoneNotOnThisQuoteButton;
    @FindBy(xpath = "//app-driver//h1[contains(.,'Add a spouse')]")
    private WebElement addASpouseSideSheetHeader;
    @FindBy(xpath = "//div[contains(@class,'ss-driver-occupation')]//button")
    private WebElement letsFindMyOccupationButton;
    @FindBy(xpath = "//app-base-sidesheet[contains(.,'Add a spouse')]//button[@id='add-occupation-button']")
    private WebElement letsFindMyOccupationButtonSpouse;
    @FindBy(xpath = "//app-occupation-selection//h1")
    private WebElement occupationSideSheetHeader;
    @FindBy(xpath = "//app-occupation-selection//mat-radio-button//label")
    private List<WebElement> displayedOccupations;
    @FindBy(xpath = "//app-driver//button[.='Save']")
    private WebElement driverSaveButton;
    @FindBy(xpath = "//app-occupation-selection//button[.='Save']")
    private WebElement occupationSaveButton;
    @FindBy(xpath = "//app-occupation-selection//button[.='Cancel']")
    private WebElement occupationCancelButton;
    @FindBy(xpath = "//app-driver//button[.='Save changes']")
    private WebElement addDriverSaveChangesButton;
    @FindBy(css = "input[formcontrolname='ageFirstLicensed']")
    private WebElement ageDriverRecievedLicenseInput;
    @FindAll({
            @FindBy(xpath = "//div[@class='button-area']//button[contains(.,'Done adding drivers')]"),
            @FindBy(xpath = "//button[contains(.,'Done adding drivers')]")
    })
    private WebElement doneAddingDriverButton;
    @FindBy(xpath = "//button[@class='tui-btn tui-btn-primary ng-star-inserted' and contains(.,'Add driver')]")
    private WebElement addDriverButton;
    @FindBy(xpath = "//label[contains(.,'When did your prior policy expire?')]/..//mat-select")
    private WebElement priorPolicyExpDateDropDown;
    @FindBy(xpath = "//span[contains(.,'Before')]/parent::mat-option")
    private WebElement priorPolicyExpDateDropDownBeforeOption;
    @FindBy(xpath = "//span[contains(.,'On or after')]/parent::mat-option")
    private WebElement priorPolicyExpDateDropDownOnOrAfterOption;
    @FindBy(xpath = "//span[@class='checkbox-label-inline']")
    private List<WebElement> checkboxLabels;
    @FindBy(xpath = "//mat-form-field[contains(.,'Current Principal Personal Injury')]//mat-select")
    private WebElement currentPrincipalPersonalInjuryDropDown;

    // Financial filing tooltip locators
    @FindBy(css = "mat-icon[aria-label='Financial responsibility filing information icon']")
    private WebElement financialFilingMatIcon;
    @FindBy(xpath = "//app-help-text-sidesheet//h1")
    private WebElement financialFilingTooltipHeader1;
    @FindBy(xpath = "//div[@class='model-info-section']//h2")
    private WebElement financialFilingTooltipHeader2;
    @FindBy(xpath = "//div[@class='model-info-section']//p[1]")
    private WebElement financialFilingTooltipDescription1;
    @FindBy(xpath = "//div[@class='model-info-section']//p[2]")
    private WebElement financialFilingTooltipDescription2;
    @FindBy(xpath = "//app-base-sidesheet//h1[contains(text(), 'Add a vehicle')]")
    private WebElement addVehicleSideSheetHeader;

    @FindAll({
            @FindBy(xpath = "//mat-radio-group[@aria-labelledby='aria-labelledby']//label"),
            @FindBy(xpath = "//label[contains(.,'nsured for the past 6 months with any')]/..//mat-radio-button")

    })
    private List<WebElement> insuredInPast6MonthsRadioButtons;

    //cta error message
    @FindBy(xpath = "//div[contains(@class,'cta-section')]//div[contains(@class,'error')]")
    public WebElement pageCTAErrorMessage;

    public void addVehiclesWhenNoneFound(@NotNull AutoApplicant applicant) throws Exception {
        clickOnAddVehicleAndDriversButton();
        List<Vehicle> vehicles = applicant.getVehicles();
        int maxNumberOfVehicles = limitVehicleCountToMaxAllowed(applicant.getStateCode(), vehicles.size());
        for (int i = 0; i < maxNumberOfVehicles; i++) {
            Vehicle vehicle = vehicles.get(i);
            addVehicleDetails(vehicle);
            waitAndClickElement(addVehicleButton);
            waitForSpinnerToBeGone();

            if (vehicle.isUseVIN() && !getSessionStorageAppStore().getAuto().getVehicles().isEmpty()) {
                AppStore.Auto.AppStoreVehicle appStoreVehicle = getSessionStorageAppStore().getAuto().getVehicles().get(i);
                updateVehicleObjectWithNewlyAddedVehicleByVIN(appStoreVehicle, vehicle);
            }

            if (i + 1 != vehicles.size()) {
                clickElement(addAnotherVehicleButtonSideSheet);
            } else {
                if (isElementVisible(doneAddingVehiclesSideSheet, 2)) {
                    waitAndClickElement(doneAddingVehiclesSideSheet);
                }
                if (isElementVisible(continueToDriversButtonSideSheet, 2)) {
                    clickElement(continueToDriversButtonSideSheet);
                }
            }
        }
    }

    public void addDriversWhenNoneFound(@NotNull AutoApplicant applicant) throws Exception {
        addApplicantDetails(applicant);
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        if (additionalDrivers.isEmpty() && isElementVisible(doneAddingDriverButton, 3)) {
            scrollAndClickOnElement(doneAddingDriverButton);
        }
        for (int i = 0; i < Math.min(additionalDrivers.size(), 4); i++) {
            SqlAdditionalDriver sqlAdditionalDriver = additionalDrivers.get(i);
            int age = sqlAdditionalDriver.getAge();
            if (!sqlAdditionalDriver.getRelationshipToApplicant().equals(SPOUSE)) {
            	if (isElementVisible(addAnotherDriverButtonSideSheet, 2)) {
            		clickOnAddAnotherDriverButtonSideSheet();
				} else {
					clickAddAnotherDriverButton();
				}
            	waitElementBeVisible(addEditDriverHeader);
            	selectGenderButton(sqlAdditionalDriver.getGender());
            	fillOutNamesAndDobFields(sqlAdditionalDriver.getFirstName(), sqlAdditionalDriver.getLastName(), sqlAdditionalDriver.getDateOfBirth());
            	selectUSOrCALicensedButton(sqlAdditionalDriver.getLicenseToDriveInUSA());
            	List<SqlIncident> currentDriverIncidents = applicant.getIncidents().stream().filter(each -> each.getIncidentId() == sqlAdditionalDriver.getIncidentId()).collect(Collectors.toList());
            	currentDriverIncidents = currentDriverIncidents.stream()
            			.filter(incident ->
            			!incident.getIncidentType().equals("Remove") &&
            			!incident.getIncidentType().equals("Edit"))
            			.collect(Collectors.toList());

            	addIncidents(currentDriverIncidents);
            	selectAndFillOutHadDlInLessThan3Years(age, sqlAdditionalDriver.getFirstAgeUnitedStatesDriverLicense());
            	addFinancialResponsibility(sqlAdditionalDriver.getFinancialFiling().contains(SR_22), sqlAdditionalDriver.getFinancialFiling().equals(SR_22_ANOTHER_STATE));
            	String fullName = sqlAdditionalDriver.getFirstName() + SPACE + sqlAdditionalDriver.getLastName();
            	addSafetyCourse(age, sqlAdditionalDriver.isCompletedDriversSafetyCourse(), fullName);
            	addHasGpaOver3(age, sqlAdditionalDriver.isFullTimeStudentWithHighGPA());
            	addDistantStudent(age, sqlAdditionalDriver.isAttendsDistantSchool());
            	clickElement(addDriverButton);
            }
        }
        if (isElementVisible(doneAddingDriverButton, 2)) {
    		clickElement(doneAddingDriverButton);
    	}

        if (applicant.getMaritalStatus().equals(MARRIED)) {
            SqlAdditionalDriver sni = additionalDrivers.stream().filter(driver -> driver.getRelationshipToApplicant().equals(SPOUSE)).collect(Collectors.toList()).stream().findFirst().get();
            String sniFullName = getTheFullNameWithFirstLetterInCaps(sni.getFirstName() + SPACE + sni.getLastName());
            WebElement checkboxForGivenDriver = getCheckboxForGivenDriver(sniFullName);
            if (!getAttributeData(checkboxForGivenDriver, CLASS).contains(MDC_CHECKBOX_SELECTED)) {
                clickEditButtonWithDriverFullName(sni.getFirstName() + SPACE + getTheFullNameWithFirstLetterInCaps(sni.getLastName()));
                addSniDetails(applicant, sni);
                clickSaveChangesDriverSheet();
                if (isElementVisible(doneAddingDriverButton, 2)) {
                    clickElement(doneAddingDriverButton);
                }
            }
        }
    }

    public void addSniDetails(AutoApplicant applicant, SqlAdditionalDriver sni) throws Exception {
        // add incidents
        List<SqlIncident> sniIncidents = applicant.getIncidents().stream().filter(each -> each.getIncidentId() == sni.getIncidentId()).collect(Collectors.toList());
        sniIncidents = sniIncidents.stream().filter(each -> !each.getIncidentType().equals("Edit") && !each.getIncidentType().equals("Remove")).collect(Collectors.toList());
        addIncidents(sniIncidents);

        String sniFullName = sni.getFirstName() + SPACE + sni.getLastName();
        //add safety course
        addSafetyCourse(sni.getAge(), sni.isCompletedDriversSafetyCourse(), sniFullName);

        // add gpa
        if (!sni.getRelationshipToApplicant().equals(SPOUSE)) {
            addHasGpaOver3(sni.getAge(), sni.isFullTimeStudentWithHighGPA());
        }

        //add driver license age
        selectAndFillOutHadDlInLessThan3Years(sni.getAge(), sni.getFirstAgeUnitedStatesDriverLicense());

        // add distant student
        addDistantStudent(sni.getAge(), sni.isAttendsDistantSchool());

        // addFinancialResponsibility
        if (!isFinancialFilingQuestionDisabled(applicant.getStateCode()) && sni.getFinancialFiling().contains(SR_22)) {
            addFinancialResponsibility(sni.getFinancialFiling().contains(SR_22), sni.getFinancialFiling().equals(SR_22_ANOTHER_STATE));
        }
    }

    public void selectAndEditDefaultAdpfVehicles() throws Exception {
        List<String> foundVehicleDescriptions = getDisplayedVehicles();
        Log.info("Adpf return vehicles are : " + foundVehicleDescriptions);
        for (int i = 0; i < Math.min(foundVehicleDescriptions.size(), 4); i++) {
            String vehicleDescription = foundVehicleDescriptions.get(i);
            String vehicleXpath = String.format("//app-vehicle-card[contains(normalize-space(.),'%s')]", vehicleDescription) + "//div[contains(@class,'card auto-vehicles-card-item vehicle')]";
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(vehicleXpath)));
            WebElement vehicleCardItem = driver().findElement(By.xpath(vehicleXpath));
            if (getAttributeData(vehicleCardItem, CLASS).contains("unselected")) {
                WebElement vehicleCheckbox = driver().findElement(By.xpath(vehicleXpath + "//input"));
                scrollAndClickOnElement(vehicleCheckbox);
                wait.until(ExpectedConditions.attributeContains(By.xpath(vehicleXpath), CLASS, "vehicle-selected"));
                Log.info("Vehicle checkbox is selected for " + vehicleDescription);
            } else {
                Log.info("Vehicle checkbox was already selected for " + vehicleDescription);
            }
        }
        if (isElementDisplayed(addVehiclesSaveChangesButton, 2)) {
        	scrollAndClickOnElement(addVehiclesSaveChangesButton);
        }

    }

    public void selectAndEditDefaultAdpfDrivers(List<String> additionalADPFDetails) throws Exception {
        List<String> foundDriversDescriptions = foundDrivers.stream().map(this::getTextFromElement).collect(Collectors.toList());
        Log.info("Adpf return drivers are : " + foundDriversDescriptions);
        for (int i = 0; i < Math.min(foundDriversDescriptions.size(), 4); i++) {
            String driverDescription = foundDriversDescriptions.get(i);
            driverDescription = driverDescription.contains("--") ? driverDescription.split("--")[0].trim() : driverDescription;
            driverDescription = driverDescription.contains("should be selected") ? driverDescription.split(",")[0].trim() : driverDescription;
            String driverXpath = String.format("//app-driver-card[contains(.,'%s')]", driverDescription) + "//div[contains(@class,'card auto-drivers-card-item driver')]";
            WebElement driverCardItem = driver().findElement(By.xpath(driverXpath));
            if (getAttributeData(driverCardItem, CLASS).contains("unselected")) {
                WebElement driverCheckbox = driver().findElement(By.xpath(driverXpath + "//input"));
                scrollAndClickOnElement(driverCheckbox);
                if (isElementVisible(addEditDriverHeader, 2)) {
                    fillOutAdpfDriverDetailsRandomly(additionalADPFDetails);
                }
                wait.until(ExpectedConditions.attributeContains(By.xpath(driverXpath), CLASS, "driver-selected"));
                Log.info("Driver checkbox is selected for " + driverDescription);
            } else {
                Log.info("Driver checkbox was already selected for " + driverDescription);
                if (additionalADPFDetails.contains(MARRIED)) {
                    AppStore.Data.CustomerData customerData = getSessionStorageAppStore().getData().getCustomerData();
                    String customerFullName = customerData.getFirstName() + SPACE + customerData.getLastName();
                    String driverCardXpath = String.format(DRIVER_CARD_XPATH, customerFullName) + "//div[contains(@class,'justify-content-between') and contains(.,'%s')]//span[contains(@class,'driver-info-value')]";
                    testStepAssert(getTextFromElement(driver().findElement(By.xpath(String.format(driverCardXpath, "Marital status")))), additionalADPFDetails.contains(MARRIED) ? "Married" : "Single", "Marital status is (before updating the details) not matching for " + customerFullName);
                }

                if (additionalADPFDetails.contains(LIVES_AWAY_FROM_HOME)) {
                    clickEditButtonWithDriverFullName(driverDescription);
                    clickMarriedButtonForSpouse();
                    clickLivesAwayCheckbox();
                    clickDriverSaveChangesButton();
                }
                String xpathForContinuousInsuranceNoButton = "//div[contains(@class,'tui-radio-button-group') and contains(.,'you been continuously')]//mat-radio-button[contains(.,'No')]";

                if (isElementPresent(By.xpath(xpathForContinuousInsuranceNoButton))) {
                    WebElement continuousInsuranceNoButton = driver().findElement(By.xpath(xpathForContinuousInsuranceNoButton));
                    clickElement(continuousInsuranceNoButton);
                }

            }
        }
    }

    private void fillOutAdpfDriverDetailsRandomly(List<String> additionalADPFDetails) throws Exception {
        // select gender if invalid
        if (isElementDisplayed(By.xpath("//mat-button-toggle-group[contains(.,'Male') and contains(@class,'ng-invalid')]"))) {
            ArrayList<String> genders = new ArrayList<>(Arrays.asList(MALE, FEMALE));
            Collections.shuffle(genders);
            findAndClickButtonWithText(genders.get(0));
        }

        // Enter DOB if not given
        if (isElementPresent(By.xpath("//mat-form-field[contains(normalize-space(.),'Date of birth') and contains(@class,'mat-form-field-invalid')]//input"), 1)) {
            WebElement inputFieldForDoB = getInputFieldForInputLabel("Date of birth");
            LocalDate now = LocalDate.now();
            int currentYear = now.getYear();
            sendKeysToElement(inputFieldForDoB, "01/01/" + (RandomUtils.nextInt(currentYear - 75, currentYear - 16)));
        }
        // Enter past 6 months auto insured or not
        if (isElementPresent(By.xpath("(//div[contains(@class,'consolidated-radio')]//label)[1]"), 1)) {
            if (insuredInPast6MonthsRadioButtons.size() > 0) {
                Collections.shuffle(insuredInPast6MonthsRadioButtons);
                clickElement(insuredInPast6MonthsRadioButtons.get(0));
            }
        }


        // click Yes for currently insured if exist
        if (isElementDisplayed(By.xpath("//div[@class='ng-star-inserted' and contains(.,'currently')]//button[contains(.,'Yes')]"))) {
            if (additionalADPFDetails.contains(NEVER_INSURED)) {
                selectYesOrNoForInsuredStatus(NO);
                selectReasonForNoInsurance(NEVER_INSURED);
            } else {
                selectYesOrNoForInsuredStatus(YES);
                if (isElementDisplayed(By.xpath(String.format("//mat-form-field[contains(.,'%s')]//input", CURRENT_INSURANCE_COMPANY)))) {
                    selectCurrentInsuranceCompany("AAA");
                }
                if (isElementPresent(By.xpath(String.format("//mat-form-field[contains(.,'%s')]", CURRENT_BI_LIMITS)), 3)) {
                    selectCurrentBodilyInjuryLimit("$50,000/$100,000");
                }
                if (isElementPresent(By.xpath(String.format("//mat-form-field[contains(.,'%s')]//input", POLICY_EXP_DATE)), 3)) {
                    Calendar start = Calendar.getInstance();
                    // One month later
                    Calendar end = Calendar.getInstance();
                    end.add(Calendar.MONTH, 1);
                    // Get time in milliseconds
                    long startMillis = start.getTimeInMillis();
                    long endMillis = end.getTimeInMillis();
                    // Generate random time between start and end
                    long randomMillis = startMillis + (long) (Math.random() * (endMillis - startMillis));
                    // Format the date
                    Date randomDate = new Date(randomMillis);
                    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                    String formattedDate = sdf.format(randomDate);
                    fillOutCurrentInsuranceExpDate(formattedDate);
                }
                if (isElementPresent(By.xpath(String.format("//mat-form-field[contains(.,'%s')]", LENGTH_OF_CURRENT_INSURANCE)), 3)) {
                    selectLengthOfCurrentInsurance("60+ Months", true);
                }

                if (isElementPresent(By.xpath("//label[contains(.,'Have you been continuously')]/following-sibling::mat-radio-group//mat-radio-button[contains(.,'No')]"), 1)) {
                    selectHaveYouContinuouslyInsuredQuestion(NO);
                }
            }
        }

        if (isElementPresent(By.xpath("//div[contains(@aria-label,'be driving')]//button[contains(.,'Yes')]"), 1)) {
            selectIsYourSpouseWillBeDriving(YES);
        }

        // click Yes for CA/USA license if exist
        if (isElementDisplayed(By.xpath("//app-driver//app-base-sidesheet[contains(.,'spouse')]//div[@class='ng-star-inserted' and contains(.,'Canadian')]//button[contains(.,'Yes')]"))) {
            selectUSOrCALicensedButton(YES);
        }

        String haveYouBeenContinuouslyQuestionXpath = "//div[@class='row consolidated-radio' and contains(.,'Have you been continuously')]//mat-radio-button[contains(.,'Yes')]//label";
        if (isElementPresent(By.xpath(haveYouBeenContinuouslyQuestionXpath), 1)) {
            selectHaveYouContinuouslyInsuredQuestion(YES);
        }

        addFinancialResponsibility(additionalADPFDetails.contains(SR_22), additionalADPFDetails.contains(SR_22_ANOTHER_STATE));
        //checkIfMarriedCheckboxIsSelectedAndClickIfNot(additionalADPFDetails.contains(MARRIED));

        if (additionalADPFDetails.contains(LIVES_AWAY_FROM_HOME)) {
            clickMarriedButtonForSpouse();
            clickLivesAwayCheckbox();
        }

        clickSaveChangesDriverSheet();
        waitForSpinnerToBeGone();
    }

    private void clickMarriedButtonForSpouse() throws Exception {
        AppStore.Data.CustomerData customerData = getSessionStorageAppStore().getData().getCustomerData();
        String customerFirstName = customerData.getFirstName();
        String customerLastName = customerData.getLastName();
        String pniFullName = customerFirstName + SPACE + customerLastName;
        String filledFirstName = getInputFieldValue(getInputFieldForInputLabel("First name"));
        if(filledFirstName.equals(customerFirstName)) return;
        WebElement marriedCheckbox = driver().findElement(By.xpath(getCheckboxXpathForTheLabel(MARRIED_CHECKBOX_TEXT) + "//input"));
        clickElement(marriedCheckbox);
        sleep(1);
        WebElement pni = driver().findElement(By.xpath(String.format("//mat-radio-button[contains(.,'%s')]", pniFullName)));
        WebElement pniInput = driver().findElement(By.xpath(String.format("//mat-radio-button[contains(@class,'spouse-options') and contains(.,'%s')]//input", pniFullName)));
        scrollAndClickOnHiddenElement(pniInput);
        sleep(1);
        if(!getAttributeData(pni, CLASS).contains(MAT_MDC_RADIO_CHECKED)) {
            jsClickElement(pniInput);
            wait.until(ExpectedConditions.attributeContains(pni, CLASS, MAT_MDC_RADIO_CHECKED));
            Log.info("Married button is selected for spouse and PNI is selected");
        } else {
            Log.warn("Failed to select married button for spouse and PNI");
        }
    }

    private void fillOutNamesAndDobFields(String firstName, String lastName, String dob) throws Exception {
        if (getInputFieldForInputLabel("First name").getAttribute(CLASS).contains(NG_VALID)) {
            return;
        }
        sendKeysToElement(getInputFieldForInputLabel("First name"), firstName);
        sendKeysToElement(getInputFieldForInputLabel("Last name"), lastName);
        sendKeysToElement(getInputFieldForInputLabel("Date of birth"), dob);
    }

    private void fillOutNamesAndDobFieldsSpouse(String firstName, String lastName, String dob) throws Exception {
        WebElement firstNameInputField = driver().findElements(By.xpath("//mat-form-field[contains(.,'First name')]//input")).get(1);
        WebElement lastNameInputField = driver().findElements(By.xpath("//mat-form-field[contains(.,'Last name')]//input")).get(1);
        WebElement dobInputField = driver().findElements(By.xpath("//mat-form-field[contains(.,'Date of birth')]//input")).get(1);
        if (firstNameInputField.getAttribute(CLASS).contains(NG_VALID)) {
            return;
        }
        sendKeysToElement(firstNameInputField, firstName);
        sendKeysToElement(lastNameInputField, lastName);
        sendKeysToElement(dobInputField, dob);
    }

    public void addVehicleDetails(Vehicle vehicle) throws Exception {
        if (vehicle.isUseVIN()) {
            fillOutVinInputField(vehicle.getVehicleVIN());
            if (isElementDisplayed(By.xpath("//mat-select[@formcontrolname='type']"))) {
                fillOutVehicleType(vehicle.getVehicleType());
            }
        } else {
            fillOutYMMDetails(vehicle);
        }
        selectVehicleUsedFor(vehicle);
        selectVehicleOwnership(vehicle);
        fillOutVehiclePurchaseDate(vehicle);
        selectGarageAddress(vehicle);
        selectTheftRecovery(vehicle);
    }

    // fill out the vin, in case of invalid vin, it will retry with another vin for 4 times, if all fails, it will fill out the YMM details. the new vin will be returned
    public String fillOutVinInputField(String vin) throws Exception {
        waitElementBeVisible(vinInputField);
        sendKeysToElement(vinInputField, vin);
        Log.info("Vehicle vin entered: " + vin);
        waitForSpinnerToBeGone();
        // if one vin is not found, reassigning and trying with another vin.
        int retryCount = 4;
        while (isElementPresent(By.xpath("//mat-form-field[contains(.,'VIN (Optional)')]//mat-error"), 3) && retryCount > 0) {
            vin = getRandomVinNumber(2);
            sendKeysToElement(vinInputField, vin);
            Log.info(String.format("%s times  vin entry failed. New Vehicle vin entered: ", retryCount) + vin);
            waitForSpinnerToBeGone();
            retryCount--;
            if (retryCount == 0) {
                Log.info("All attempts to enter vin failed");
                fillOutVehicleYear("2025");
                fillOutVehicleMake("HONDA");
                fillOutVehicleModel("ACCORD 4D EX");
                fillOutVehicleType("Sedan");
            }
        }
        return vin;
    }

    public void sendKeysToVinInputField(String vin) throws Exception {
        waitElementBeVisible(vinInputField);
        sendKeysToElement(vinInputField, vin);
        Log.info("Vehicle vin entered: " + vin);
        waitForSpinnerToBeGone();
    }

    public void clickVinInfoIcon() {
        clickElement(vinInfoIcon);
    }

    public void fillOutYMMDetails(Vehicle vehicle) throws Exception {
        fillOutVehicleYear(vehicle.getVehicleYear());
        fillOutVehicleMake(vehicle.getVehicleMake());
        fillOutVehicleModel(vehicle.getVehicleModel());
        fillOutVehicleType(vehicle.getVehicleType());
    }

    public void fillOutVehicleYear(String year) throws Exception {
        if (!isElementVisible(yearDropDown, 3) && isElementVisible(vinRemoveButtonDeleteIcon, 3)) {
            clickRemoveVinButton();
        }
        waitElementBeVisible(yearDropDown);
        selectValueInDropDown(yearDropDown, year);
        wait.until(ExpectedConditions.invisibilityOf(dropDownOptions));
        Log.info("Vehicle year entered: " + year);
    }

    public String getPrefilledVehicleYear() throws Exception {
        return isElementVisible(yearDropDown, 3) ? getValueFromWebElement(yearDropDown) : extractYearFromVinDescContent();
    }

    public String extractYearFromVinDescContent()
    {
        return getTextFromElement(vinDescContent).split(SPACE)[0];
    }

    public void fillOutVehicleMake(String make) throws Exception {
        waitElementBeVisibleClickable(makeInputField);
        sendKeysToElement(makeInputField, make);
        wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath(DROP_DOWN_OPTIONS_XPATH), 0));
        selectValueInDropDown(makeInputField, make);
        wait.until(ExpectedConditions.invisibilityOf(dropDownOptions));
        Log.info("Vehicle make entered: " + make);
    }

    public void fillOutVehicleModel(String model) throws Exception {
        waitElementBeVisibleClickable(modelInputField);
        sendKeysToElement(modelInputField, model);
        wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath(DROP_DOWN_OPTIONS_XPATH), 0));
        selectValueInDropDown(modelInputField, model);
        wait.until(ExpectedConditions.invisibilityOf(dropDownOptions));
        Log.info("Vehicle model entered: " + model);
    }

    public void fillOutVehicleType(String type) throws Exception {
        sleep(1);
        if (getAttributeData(typeDropDown, VALUE).isEmpty() && getTextFromElement(typeDropDown).isEmpty()) {
            int maxAttempts = 3;
            while (getAttributeData(typeDropDown, ARIA_DISABLED).equals(LOWERCASE_TRUE) && maxAttempts != 0) {
                sleep(maxAttempts);
                maxAttempts--;
            }
            if (getAttributeData(typeDropDown, ARIA_DISABLED).equals(LOWERCASE_FALSE)) {
                selectValueInDropDown(typeDropDown, type);
                wait.until(ExpectedConditions.invisibilityOf(dropDownOptions));
                Log.info("Vehicle type entered: " + type);
            } else {
                Log.warn("Vehicle type field was not enabled");
            }
        }

    }

    public void selectVehicleUsedFor(Vehicle vehicle) throws Exception {
        String vehicleUsage = vehicle.getVehicleUsage();
        if (vehicleUsage.equals("Rideshare")) {
            vehicleUsage = PERSONAL;
        } else if (vehicleUsage.equals("RideshareAndBusiness")) {
            vehicleUsage = BUSINESS;
        }
        findAndClickButtonWithText(vehicleUsage); // select vehicle usage toggle (Personal, Business)
        if (vehicle.isRidesharing()) {
            scrollAndClickOnElement(rideshareCheckboxInput);
        }
        Log.info("Vehicle usage is selected: " + vehicleUsage);
    }

    public void selectVehicleOwnership(Vehicle vehicle) throws Exception {
        String vehicleOwnership = vehicle.getOwnership();
        findAndClickButtonWithText(vehicleOwnership);
        Log.info("Vehicle ownership is selected: " + vehicleOwnership);
    }

    public void fillOutVehiclePurchaseDate(Vehicle vehicle) throws Exception {
        if (isElementVisible(acquiredSectionDateInputField, 3)) {
            // not changing the populated one
            vehicle.setPurchaseDate(getValueFromWebElement(acquiredSectionDateInputField));
            Log.info("Vehicle purchase date is entered: " + vehicle.getPurchaseDate());
        }
    }

    public void selectGarageAddress(Vehicle vehicle) throws Exception {
        if (!vehicle.isParkInResidentAddress()) {
            List<AutoApplicant> autoApplicants = listOfAutoApplicants("applicant", "stateCode=" + getSessionStorageAppStore().getData().getLandingStateCode());
            Collections.shuffle(autoApplicants);
            String garagingAddress = autoApplicants.get(0).getGaragingAddress();
            scrollAndClickOnElement(parkedAtOtherRadioButton);
            wait.until(ExpectedConditions.attributeContains(parkedAtOtherRadioButton, "tabindex", "0"));
            sendKeysToElement(waitElementBeVisible(otherGarageAddressInputField), garagingAddress);
            sleep(2);
            List<WebElement> dropDownOptions = driver().findElements(By.xpath("//mat-option"));
            if (dropDownOptions.isEmpty()) {
                garagingAddress = autoApplicants.get(new Random().nextInt(autoApplicants.size() - 1)).getGaragingAddress();
                sendKeysToElement(otherGarageAddressInputField, garagingAddress);
                sleep(1);
            } else {
                WebElement firstDropDownOption = dropDownOptions.get(0);
                garagingAddress = getTextFromElement(firstDropDownOption);
                clickElement(firstDropDownOption);
                waitForSpinnerToBeGone();
            }
            wait.until(ExpectedConditions.attributeToBe(otherGarageAddressInputField, ARIA_INVALID, LOWERCASE_FALSE));
            Log.info("Garage address is entered: " + garagingAddress);
        } else {
            Log.info("Vehicle is parked at the resident address");
        }
    }

    public void selectTheftRecovery(Vehicle vehicle) throws Exception {
        String landingStateCode = getStateCodeFromAppStore();
        if (isAntiTheftRecoverySystemEnabledState(landingStateCode)) {
            if (vehicle.isAntiTheftDevice()) {
                clickElement(theftRecoveryCheckbox);
            }
        }
    }

    public void selectGenderButton(String gender) throws Exception {
        findAndClickButtonWithText(gender);
        Log.info("Gender selected: " + gender);
    }

    public void selectGenderButtonForSpouse(String gender) throws Exception {
        WebElement genderButton = driver().findElement(By.xpath(String.format("//div[contains(@aria-label,\"Please select spouse's gender\")]//button[contains(.,'%s')]", gender)));
        jsClickElement(genderButton);
        Log.info("Gender selected: " + gender);
    }

    public void selectUSOrCALicensedButton(String yesNo) throws Exception {
        WebElement yesOrNoButton = driver().findElement(By.xpath(String.format("//app-driver//div[contains(@aria-label,'Canadian')]//button[contains(.,'%s')]", yesNo)));
        clickElement(yesOrNoButton);
        wait.until(d -> isButtonSelected(yesOrNoButton));
        Log.info("USA or CA license status selected: " + yesNo);
    }

    public void selectUSOrCALicensedButtonForSpouse(String yesNo) throws Exception {
        List<WebElement> yesOrNoButtons = driver().findElements(By.xpath(String.format("//app-driver[contains(.,'Add a spouse')]//div[contains(@aria-label,'Canadian')]//button[contains(.,'%s')]", yesNo)));
        clickElement(yesOrNoButtons.get(0));
        wait.until(d->isButtonSelected(yesOrNoButtons.get(0)));
        Log.info("USA or CA license status selected: " + yesNo);
    }

    public void selectIsYourSpouseWillBeDriving(String yesNo) throws Exception {
        List<WebElement> yesOrNoButtons = driver().findElements(By.xpath(String.format("//div[contains(@aria-label,'be driving')]//button[contains(.,'%s')]", yesNo)));
        clickElement(yesOrNoButtons.get(0));
        wait.until(d-> isButtonSelected(yesOrNoButtons.get(0)));
        Log.info("Will your spouse be driving a vehicle on this policy filled:  " + yesNo);
    }

    public void clickDriverSaveButton() {
        clickElement(driverSaveButton);
        waitForSpinnerToBeGone();
    }

    public void addApplicantDetails(AutoApplicant applicant) throws Exception {
        if(!isElementVisible(addEditDriverHeader, 3)) {
            WebElement driverEditButton = getDriverEditCheckboxInputButtonByFullName(getPniFullNameFromAutoApplicant(applicant));
            scrollElementToMiddle(driverEditButton);
            clickElement(driverEditButton);
            waitElementBeVisible(addEditDriverHeader);
        }
        selectGenderButton(applicant.getGender());
        selectUSOrCALicensedButton(applicant.getFirstAgeForeignDriverLicense() == 18 ? NO : YES);
        fillOutPriorInsuranceDetails(applicant);
        fillOutAdditionalDetailsPNI(applicant);
        clickSaveChangesDriverSheet();
    }

    public void fillOutPriorInsuranceDetails(AutoApplicant applicant) throws Exception {

        String currentInsuredStat = applicant.getCurrentlyInsuredStatus().equals("Insured") ? YES : NO;
        WebElement currentlyInsuredYesOrNo = driver().findElement(By.xpath(String.format("//div[contains(@aria-label,'currently')]//button[contains(.,'%s')]", YES)));
        if (!getAttributeData(currentlyInsuredYesOrNo, ARIA_CHECKED).equals(LOWERCASE_FALSE) && driver().findElements(By.xpath(String.format("//mat-form-field[contains(.,'%s')]//input", CURRENT_INSURANCE_COMPANY))).isEmpty()) {
            return;
        }
        selectYesOrNoForInsuredStatus(currentInsuredStat);
        Log.info("Current insurance status selection: " + currentInsuredStat);
        if (currentInsuredStat.equals(YES)) {
            selectCurrentInsuranceCompany(applicant.getCurrentInsuranceCompany());
            selectCurrentBodilyInjuryLimit(applicant.getCurrentBodilyInjuryLimit());
            selectPrincipalPersonalInjuryProtectionLimitRandomly();
            fillOutCurrentInsuranceExpDate(applicant.getCurrentInsuranceExpirationDate());
            selectLengthOfCurrentInsurance(applicant.getContinuosInsurancePeriod(), false);
        } else {
            selectReasonForNoInsurance(applicant.getCurrentlyInsuredStatus());
        }
    }

    public void fillOutAdditionalDetailsPNI(AutoApplicant applicant) throws Exception {

        // add accident or incidents
        List<SqlIncident> applicantIncidents = applicant.getIncidents().stream().filter(incident -> incident.getAdditionalDriverId() == 0).collect(Collectors.toList());
        applicantIncidents = applicantIncidents.stream().filter(each -> !each.getIncidentType().equals("Edit") && !each.getIncidentType().equals("Remove")).collect(Collectors.toList());
        addIncidents(applicantIncidents);

        // add marital relations if needed
        addSni(applicant);

        // financial responsibility
        addFinancialResponsibility(applicant.getFinancialFiling().contains(SR_22), applicant.getFinancialFiling().equals(SR_22_ANOTHER_STATE));

        // driver license age for young driver
        selectAndFillOutHadDlInLessThan3Years(applicant.getAge(), applicant.getFirstAgeUnitedStatesDriverLicense());

        // add safety course
        addSafetyCourse(applicant.getAge(), applicant.isCompletedDriversSafetyCourse(), getPniFullNameFromAutoApplicant(applicant));

        // gpa
        addHasGpaOver3(applicant.getAge(), applicant.isFullTimeStudentWithHighGPA());

        // add occupation
        addOccupation(applicant.getOccupation(), false);
    }

    public void addIncidents(List<SqlIncident> incidents) throws Exception {
        int accidentCount = 0;
        int violationCount = 0;
        // remove edit and remove types
        incidents.removeIf(incident -> incident.getIncidentType().equals("Edit") || incident.getIncidentType().equals("Remove"));
        for (int i = 0; i < incidents.size(); i++) {
            SqlIncident incident = incidents.get(i);
            if (i == 0) {
                WebElement accidentCheckbox = driver().findElement(By.xpath(getCheckboxXpathForTheLabel(ACCIDENT_CHECKBOX_TEXT) + "//input"));
                clickElement(accidentCheckbox);
                wait.until(d-> isCheckboxSelected(accidentCheckbox));
            } else {
                if(isElementVisible(addAnotherIncidentNestedSpouse, 3)) {
                    clickElement(addAnotherIncidentNestedSpouse);
                } else {
                    clickElement(addAnotherIncident);
                }
                sleep(1);
            }

            String dropDownLabel;
            String toggleLabel;
            String dateLabel;
            boolean isAccident = incident.getIncidentType().equals(ACCIDENT);
            if (isAccident) {
                dropDownLabel = "Select accident type";
                dateLabel = "Date of Accident";
                toggleLabel = ACCIDENT;
                ++accidentCount;
            } else {
                dropDownLabel = "Select violation type";
                toggleLabel = "Violation";
                dateLabel = "Date of Violation";
                ++violationCount;
            }

            WebElement toggleElement = driver().findElements(By.xpath(String.format("//button[contains(.,'%s')]", toggleLabel))).get(i);
            clickElement(toggleElement);
            WebElement incidentDateInputField = driver().findElements(By.xpath(String.format("//mat-form-field[contains(.,'%s')]//input", dateLabel))).get(isAccident ? accidentCount - 1 : violationCount - 1);
            WebElement incidentTypeDropDown = driver().findElements(By.xpath(String.format("//mat-form-field[contains(.,'%s')]//mat-select", dropDownLabel))).get(isAccident ? accidentCount - 1 : violationCount - 1);
            WebElement selectIncidentTypeDropDown = getDropDownMatSelectForInputLabel(dropDownLabel);
            scrollElementToMiddle(incidentDateInputField);
            clickElement(incidentTypeDropDown);
            List<WebElement> dropDownOptions = driver().findElements(By.xpath(DROPDOWN_OPTIONS_XPATH));
            List<String> incidentTypesAvaialable = dropDownOptions.stream().map(this::getTextFromElement).collect(Collectors.toList());
            if (!incidentTypesAvaialable.contains(incident.getDescription())) {
                Log.info("Updating the accident/violation type from available ones as what we are looking is not in the dropdown");
                Collections.shuffle(dropDownOptions);
                incident.setDescription(getTextFromElement(dropDownOptions.get(0)));
            }

            WebElement selectedDropDown = driver().findElement(By.xpath(String.format("//mat-option[contains(.,\"%s\")]", incident.getDescription())));
            clickElement(selectedDropDown);
            wait.until(ExpectedConditions.attributeToBe(selectIncidentTypeDropDown, ARIA_INVALID, LOWERCASE_FALSE));

            // date of incident
            scrollElementToMiddle(incidentDateInputField);
            sendKeysToElement(incidentDateInputField, incident.getDateOccured());
            Log.info(toggleLabel + " is selected as : " + incident.getDescription());
            Log.info("Incident date is entered as : " + incident.getDateOccured() + " for " + toggleLabel);
        }
    }

    public void addSni(AutoApplicant applicant) throws Exception {
        if (applicant.getMaritalStatus().equals(MARRIED)) {
            WebElement marriedCheckbox = driver().findElement(By.xpath(getCheckboxXpathForTheLabel(MARRIED_CHECKBOX_TEXT) + "//input"));
            scrollToElement(marriedCheckbox);
            if (isCheckboxNotSelected(marriedCheckbox)) {
				clickElement(marriedCheckbox);
			}
            if (foundDrivers.size() > 1) {
            	if (isElementVisible(changeSpouseSelectionLink, 5)) {
            		clickElement(changeSpouseSelectionLink);
            	}
                waitAndClickElement(someoneNotOnThisQuoteButton);
            }
            SqlAdditionalDriver sni = applicant.getAdditionalDrivers().stream().filter(each -> each.getRelationshipToApplicant().equals(SPOUSE)).collect(Collectors.toList()).stream().findFirst().get();
            addSpouseDetails(sni.getOccupation(), sni.getFirstName(), sni.getLastName(), sni.getDateOfBirth(), sni.getGender(), Optional.of(!applicant.getTestScenario().contains(NON_DRIVING_SPOUSE)), sni.getLicenseToDriveInUSA().equals(YES), true);
        }
    }

    public void addFinancialResponsibility(boolean isFinancialFilingPresent, boolean fileInAnotherState) throws Exception {
        if (isFinancialFilingPresent && !isFinancialFilingQuestionDisabled(getSessionStorageAppStore().getData().getLandingStateCode())) {
            WebElement financialFilingCheckbox = driver().findElement(By.xpath(getCheckboxXpathForTheLabel(FINANCIAL_RESPONSIBILITY_CHECKBOX_TEXT) + "//input"));
            scrollAndClickOnElement(financialFilingCheckbox);
            wait.until(d-> isCheckboxSelected(financialFilingCheckbox));
            String toggleForInStateOrNot = fileInAnotherState ? "Another state" : getSessionStorageAppStore().getData().getLandingStateDescription().toUpperCase();
            findAndClickButtonWithText(toggleForInStateOrNot);
            Log.info("Financial filing is added for " + toggleForInStateOrNot);
        }
    }

    public void selectAndFillOutHadDlInLessThan3Years(int driverAge, int licenseAge) throws Exception {
        String checkboxXpathForTheDlAge = getCheckboxXpathForTheLabel(HAS_HAD_DRIVER_LICENSE_IN_LESS_THAN_3_YEARS);
        if ((driverAge - licenseAge) <= 3 && isElementDisplayed(By.xpath(checkboxXpathForTheDlAge))) {
            WebElement checkbox = driver().findElement(By.xpath(checkboxXpathForTheDlAge + "//input"));
            scrollAndClickOnElement(checkbox);
            waitElementBeVisible(ageDriverRecievedLicenseInput);
            if ((driverAge - licenseAge) < 0) {
                licenseAge = 15;
            }
            sendKeysToElement(ageDriverRecievedLicenseInput, licenseAge);
            wait.until(ExpectedConditions.attributeContains(ageDriverRecievedLicenseInput, CLASS, NG_VALID));
            Log.info("Driver license age is entered: " + licenseAge);
        }
    }

    public void addSafetyCourse(int age, boolean completedSafetyCourse, String fullName) throws Exception {
        String landingStateCode = getStateCodeFromAppStore();
        int expectedMinOldAgeForSafetyCourse = getMinAgeForSafetyCourse(landingStateCode);
        if (isSafetyCourseExpectedState(landingStateCode) && age >= expectedMinOldAgeForSafetyCourse && completedSafetyCourse) {
            sleep(1);
            WebElement safetyCourseCheckbox = getDriverSafetyCourseCheckBoxWebElement(age);
            if (getAttributeData(safetyCourseCheckbox, CLASS).contains(MDC_CHECKBOX_SELECTED)) {
                Log.info("Driver safety course checkbox was already selected for " + fullName);
                return;
            }
            scrollElementToMiddle(safetyCourseCheckbox);
            clickElement(safetyCourseCheckbox);
            wait.until(ExpectedConditions.attributeContains(safetyCourseCheckbox, CLASS, MDC_CHECKBOX_SELECTED));
            Log.info("Driver safety course checkbox is selected for " + fullName);
        }
    }

    private void clickLivesAwayCheckbox() throws Exception {
        sleep(1);
        if (isElementDisplayed(By.xpath(getCheckboxXpathForTheLabel(LIVES_AWAY_FROM_HOME) + "//input"))) {
            WebElement livesAwayCheckbox = driver().findElement(By.xpath(getCheckboxXpathForTheLabel(LIVES_AWAY_FROM_HOME) + "//input"));
            scrollElementToMiddle(livesAwayCheckbox);
            clickElement(livesAwayCheckbox);
        }
    }

    private WebElement getDriverSafetyCourseCheckBoxWebElement(int age) throws Exception {
        By xpath = By.xpath(getDriverSafetyCheckBoxXpath(age));
        waitElementPresent(xpath, 2);
        return driver().findElement(xpath);
    }

    public String getDriverSafetyCheckBoxXpath(int age) throws Exception {
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        String safetyCourseXpath;
        if(landingStateCode.equals(OR) && age >= 70) {
            safetyCourseXpath = SAFETY_COURSE_CHECKBOX_TEXT.replace("3","2");
        } else {
            safetyCourseXpath = SAFETY_COURSE_CHECKBOX_TEXT;
        }
        return getCheckboxXpathForTheLabel(safetyCourseXpath) + "//input";
    }

    public void addHasGpaOver3(int age, boolean isGpaOver3) throws Exception {
        if(isOnBristolWest()) {
            Log.info("GPA over 3 checkbox is not available for Bristol West");
            return;
        }
        if (age <= MAX_YOUNG_AGE && isGpaOver3) {
            String hasGpaXpath = getCheckboxXpathForTheLabel(HAS_A_GPA_OVER_3) + "//input";
            By by = By.xpath(hasGpaXpath);
            waitElementPresent(by, 2);
            WebElement hasGpaOver3Element = driver().findElement(by);
            scrollElementToMiddle(hasGpaOver3Element);
            clickElement(hasGpaOver3Element);
            sleep(1);
            if (!getAttributeData(hasGpaOver3Element, CLASS).contains(MDC_CHECKBOX_SELECTED)) {
                jsClickElement(hasGpaOver3Element);
            }
            wait.until(d -> getAttributeData(hasGpaOver3Element, CLASS).contains(MDC_CHECKBOX_SELECTED));
        }
    }

    public void addDistantStudent(int age, boolean isDistantStudent) throws Exception {
        if (age <= MAX_YOUNG_AGE && isDistantStudent) {
            String distantStudentXpath = getCheckboxXpathForTheLabel(DISTANT_STUDENT_CHECKBOX_TEXT) + "//input";
            By by = By.xpath(distantStudentXpath);
            waitElementPresent(by, 2);
            WebElement distantStudentElement = driver().findElement(by);
            scrollAndClickOnElement(distantStudentElement);
            wait.until(d-> isCheckboxSelected(distantStudentElement));
        }
    }

    public void addOccupation(String occupation, boolean isRetired) throws Exception {
        AceAutoSupportedOccupationByState aceAutoSupportedOccupationByState = AceAutoSupportedOccupationByState.valueOf(getSessionStorageAppStore().getData().getLandingStateCode());
        boolean occupationAsPerTheState = (isRetired ? aceAutoSupportedOccupationByState.getSupportedRetiredOccupations().stream().map(Occupations::getOccupationName).collect(Collectors.toList()).contains(occupation)
                : aceAutoSupportedOccupationByState.getSupportedEmployedOccupations().stream().map(Occupations::getOccupationName).collect(Collectors.toList()).contains(occupation));

        if (!isOnBristolWest() && !isBDQFlowEnabled() && !occupation.isEmpty() && occupationAsPerTheState) {
            clickElement(letsFindMyOccupationButton);
            processOccupationSelection(occupation, isRetired);
        }
    }

    public void addOccupationSpouse(String occupation, boolean isRetired) throws Exception {
        if (!isBDQFlowEnabled() && !occupation.isEmpty()) {
            clickElement(letsFindMyOccupationButtonSpouse);
            processOccupationSelection(occupation, isRetired);
        }
    }

    private void processOccupationSelection(String occupation, boolean isRetired) throws Exception {
        waitElementBeVisible(occupationSideSheetHeader);
        if (isRetired) {
            findAndClickButtonWithText("Retired");
        }
        List<String> displayedOccupationsTexts = displayedOccupations.stream().map(this::getTextFromElement).collect(Collectors.toList());
        if (displayedOccupationsTexts.contains(occupation)) {
            WebElement selectedOccupation = driver().findElement(By.xpath(String.format("//mat-radio-button[contains(.,'%s')]", occupation)));
            clickElement(selectedOccupation);
            wait.until(ExpectedConditions.attributeContains(selectedOccupation, CLASS, RADIO_BUTTON_CHECKED));
            clickElement(occupationSaveButton);
            Log.info("Occupation is being selected: " + (isRetired ? "Retired" : "Employed") + SPACE + occupation);
        } else {
            clickElement(occupationSelectionModalLeftChevron);
            Log.info("Occupation is not available : " + (isRetired ? "Retired" : "Employed") + SPACE + occupation);
        }
    }

    private void addSpouseDetails(String occupation, String firstName, String lastName, String dob, String gender, Optional<Boolean> willBeDriving, boolean isLicensedInUSAorCA, boolean clickSaveCta) throws Exception {
        if (willBeDriving.isEmpty()) {
            willBeDriving = Optional.of(true);
        }
        waitElementBeVisible(addASpouseSideSheetHeader);
        selectGenderButtonForSpouse(gender);
        fillOutNamesAndDobFieldsSpouse(firstName, lastName, dob);
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        if (isNonDriverImplementedState(landingStateCode)) {
            selectIsYourSpouseWillBeDriving(willBeDriving.get() ? YES : NO);
        }
        if (willBeDriving.get()) {
            selectUSOrCALicensedButtonForSpouse(isLicensedInUSAorCA ? YES : NO);
            if (!isEmploymentDiscountDisabledState(landingStateCode) && !isOnBristolWest()) {
                addOccupationSpouse(occupation, false);
            }
        }

        if (getSessionStorageAppStore().getData().getLandingStateCode().equals(VA)) {
            String checkboxXpathForTheLabel = getCheckboxXpathForTheLabel(LIVES_AWAY_FROM_HOME);
            if (isElementDisplayed(By.xpath(checkboxXpathForTheLabel))) {
                WebElement livesAwayFromHomeCheckbox = driver().findElement(By.xpath(checkboxXpathForTheLabel + "//input"));
                clickElement(livesAwayFromHomeCheckbox);
                wait.until(d -> getAttributeData(livesAwayFromHomeCheckbox, CLASS).contains(MDC_CHECKBOX_SELECTED));
            }
        }

        if (clickSaveCta) {
            clickDriverSaveButton();
        }
    }

    public void selectYesOrNoForInsuredStatus(String yesOrNo) throws Exception {
        WebElement currentlyInsuredYesOrNo = driver().findElement(By.xpath(String.format("//div[contains(@aria-label,'currently')]//button[contains(.,'%s')]", yesOrNo)));
        waitAndClickElement(currentlyInsuredYesOrNo);
        wait.until(d->isButtonSelected(currentlyInsuredYesOrNo));
    }

    public void selectCurrentInsuranceCompany(String currentInsuranceCompany) throws Exception {
        WebElement dropDownWebElementForCurrentInsuranceCompany = getInputFieldForInputLabel(CURRENT_INSURANCE_COMPANY);
        sendKeysToElement(dropDownWebElementForCurrentInsuranceCompany, currentInsuranceCompany);
        WebElement dropDownOption = driver().findElements(By.xpath("//mat-option")).get(0);
        currentInsuranceCompany = getTextFromElement(dropDownOption);
        clickElement(dropDownOption);
        Log.info("Current insurance company name is selected: " + currentInsuranceCompany);
    }

    public void selectPriorInsuranceCompany(String priorInsuranceCompany) throws Exception {
        WebElement dropDownWebElementForCurrentInsuranceCompany = getInputFieldForInputLabel(PRIOR_INSURANCE_COMPANY);
        sendKeysToElement(dropDownWebElementForCurrentInsuranceCompany, priorInsuranceCompany);
        WebElement dropDownOption = driver().findElements(By.xpath("//mat-option")).get(0);
        priorInsuranceCompany = getTextFromElement(dropDownOption);
        clickElement(dropDownOption);
        Log.info("Current insurance company name is selected: " + priorInsuranceCompany);
    }

    public void selectCurrentBodilyInjuryLimit(String currentBodilyInjuryLimit) throws Exception {
        WebElement dropDownWebElementForCurrentBiLimit = getDropDownMatSelectForInputLabel(CURRENT_BI_LIMITS);
        selectValueInDropDown(dropDownWebElementForCurrentBiLimit, currentBodilyInjuryLimit);
        wait.until(ExpectedConditions.attributeToBe(dropDownWebElementForCurrentBiLimit, ARIA_INVALID, LOWERCASE_FALSE));
        Log.info("Current policy bi limit is selected: " + currentBodilyInjuryLimit);
    }

    public void selectPrincipalPersonalInjuryProtectionLimitRandomly() throws Exception {
        if (isElementVisible(currentPrincipalPersonalInjuryDropDown, 2)) {
            selectValueInDropDown(currentPrincipalPersonalInjuryDropDown, "$15,000/$1,000");
            wait.until(ExpectedConditions.attributeToBe(currentPrincipalPersonalInjuryDropDown, ARIA_INVALID, LOWERCASE_FALSE));
            Log.info("Current Principal Personal Injury Protection is selected: " + currentPrincipalPersonalInjuryDropDown);
        }
    }

    public void selectPriorBodilyInjuryLimit(String currentBodilyInjuryLimit) throws Exception {
        WebElement dropDownWebElementForCurrentBiLimit = getDropDownMatSelectForInputLabel(PRIOR_BI_LIMITS);
        selectValueInDropDown(dropDownWebElementForCurrentBiLimit, currentBodilyInjuryLimit);
        wait.until(ExpectedConditions.attributeToBe(dropDownWebElementForCurrentBiLimit, ARIA_INVALID, LOWERCASE_FALSE));
        Log.info("Current policy bi limit is selected: " + currentBodilyInjuryLimit);
    }

    public void fillOutCurrentInsuranceExpDate(String currentPolicyExpDate) throws Exception {
        WebElement policyExpDateInputElement = getInputFieldForInputLabel(POLICY_EXP_DATE);
        sendKeysToElement(policyExpDateInputElement, currentPolicyExpDate);
        wait.until(ExpectedConditions.attributeToBe(policyExpDateInputElement, ARIA_INVALID, LOWERCASE_FALSE));
        Log.info("Current policy exp date is filled out: " + currentPolicyExpDate);
    }

    public void selectLengthOfCurrentInsurance(String lengthOfCurrentInsurance, boolean haveYouContinueslyInsured) throws Exception {
        WebElement lengthOfCurrentInsuranceElement = getDropDownMatSelectForInputLabel(LENGTH_OF_CURRENT_INSURANCE);
        selectValueInDropDown(lengthOfCurrentInsuranceElement, lengthOfCurrentInsurance);
        scrollElementToMiddle(lengthOfCurrentInsuranceElement);
        wait.until(ExpectedConditions.attributeToBe(lengthOfCurrentInsuranceElement, ARIA_INVALID, LOWERCASE_FALSE));
        Log.info("Length of Current policy is filled out: " + lengthOfCurrentInsurance);
        if (lengthOfCurrentInsurance.equals("< 6 Months")) {
            selectHaveYouContinuouslyInsuredQuestion(haveYouContinueslyInsured ? YES : NO);
        }
    }

    public void selectHaveYouContinuouslyInsuredQuestion(String yesOrNo) throws Exception {
        String xpath = String.format("//*[contains(@class,'tui-radio-button-group') and contains(.,'Have you been continuously insured for the past 6 months with any auto insurance company(s)?')]//mat-radio-button[contains(.,'%s')]//input", yesOrNo);
        if (isElementPresent(By.xpath(xpath) , 1)) {
            WebElement yesOrNoButton = driver().findElement(By.xpath(xpath));
            scrollElementToMiddle(yesOrNoButton);
            clickElement(yesOrNoButton);
            Log.info(CONTINUOUSLY_INSURED_QUESTION + " is selected: " + yesOrNo);
        }
    }

    public void selectReasonForNoInsurance(String noInsuranceReason) throws Exception {
        WebElement noInsuranceReasonElement = driver().findElement(By.xpath("//div[contains(.,'not currently')]//mat-select"));
        String dropDownOption = null;
        switch (noInsuranceReason) {
            case NEVER_INSURED:
                dropDownOption = "I never had insurance";
                break;
            case EXPIRED:
                dropDownOption = MY_INSURANCE_EXPIRED;
                break;
            case NOT_REQUIRED:
                dropDownOption = "I was not required to have insurance";
                break;
            case DEPLOYED:
                dropDownOption = "I was in the military and deployed overseas";
                break;
            default:
                Log.warn("Unrecognized insured status: " + noInsuranceReason);
                break;
        }

        selectValueInDropDown(noInsuranceReasonElement, dropDownOption);
        wait.until(ExpectedConditions.attributeToBe(noInsuranceReasonElement, ARIA_INVALID, LOWERCASE_FALSE));
        if (noInsuranceReason.equals(EXPIRED)) {
            // get Before option for "When did you prior policy expire" question
            clickElement(priorPolicyExpDateDropDown);
            String selectedPriorDateText = getTextFromElement(waitElementBeVisible(priorPolicyExpDateDropDownBeforeOption));
            clickElement(priorPolicyExpDateDropDownBeforeOption);
            if (getSessionStorageAppStore().getData().getLandingStateCode().equals(OR)) {
                selectPriorInsuranceCompany("AAA");
                selectPriorBodilyInjuryLimit("$50,000/$100,000");
                WebElement priorInsuranceLength = getDropDownMatSelectForInputLabel(LENGTH_OF_PRIOR_INSURANCE);
                clickElement(priorInsuranceLength);
                List<WebElement> matOptions = driver().findElements(By.xpath("//mat-option"));
                clickElement(matOptions.get(matOptions.size() - 1));
            }
            Log.info("For 'When did your prior policy expire?' question, user selected: " + selectedPriorDateText);
        }
        Log.info("No Insurance reason is selected: " + dropDownOption);
    }

    public void findAndClickButtonWithText(String buttonText) throws Exception {
        WebElement buttonElement = driver().findElement(By.xpath(String.format("//button[contains(.,'%s')]", buttonText)));
        scrollElementToMiddle(buttonElement);
        clickElement(buttonElement);
        wait.until(d -> isButtonSelected(buttonElement));
    }

    private WebElement getInputFieldForInputLabel(String label) throws Exception {
        return driver().findElement(By.xpath(String.format("//mat-form-field[contains(.,'%s')]//input", label)));
    }

    private WebElement getDropDownMatSelectForInputLabel(String label) throws Exception {
        return driver().findElement(By.xpath(String.format("//mat-form-field[contains(.,'%s')]//mat-select", label)));
    }

    private String getCheckboxXpathForTheLabel(String label) throws Exception {
        return String.format("//mat-checkbox[contains(.,\"%s\")]", label);
    }

    private WebElement getDriverEditButtonByFullName(String fullName) throws Exception {
        return driver().findElement(By.xpath(String.format("//app-driver-card[contains(.,'%s')]//a[contains(.,'Edit')]", fullName)));
    }

    private WebElement getDriverEditButtonByLastNameAndAge(String firstName, int Age) throws Exception {
        return driver().findElement(By.xpath(String.format("//app-driver-card[contains(.,'%s, %s')]//a[contains(.,'Edit')]", firstName, Age)));
    }

    public void clickAddAnotherDriverButton() throws Exception {
        scrollAndClickOnElement(addAnotherDriverButton);
    }

    public void clickCheckboxesForDriversIfNotAlreadyChecked() throws Exception {
        List<WebElement> unselectedDrivers = driver().findElements(By.xpath("//div[@class='card auto-drivers-card-item driver-unselected']//input"));
        for (int i = 0; i < unselectedDrivers.size(); i++) {
            clickElement(unselectedDrivers.get(i));
        }
    }

    public void clickEditButtonWithDriverFullName(String fullName) throws Exception {
        By editXpath = By.xpath(String.format("//app-driver-card[contains(.,'%s')]//a", fullName));
        wait.until(ExpectedConditions.elementToBeClickable(editXpath));
        WebElement editLink = driver().findElement(editXpath);
        clickElement(editLink);
        waitElementBeVisible(addEditDriverHeader);
    }

    public WebElement getCheckboxForGivenDriver(String fullName) throws Exception {
        return driver().findElement(By.xpath(String.format("//app-driver-card[contains(.,'%s')]//input", fullName)));
    }

    public void clickContinueButton() {
        scrollElementToMiddle(continueButton);
        clickElement(continueButton);
    }

    public void validatePrefilledValues(FarmersSoftAssert softAssert) throws Exception {
        String quoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
        ApiHelper apiHelper = new ApiHelper();
        AdpfServiceServiceCallEnd adpfCallResponsePayload = apiHelper.getAdpfCallResponsePayload(quoteNumber);
        List<AdpfServiceServiceCallEnd.ADPFResponseBean.Driver> drivers = adpfCallResponsePayload.getADPFResponseBean().getDriver();
        List<AdpfServiceServiceCallEnd.ADPFResponseBean.Vehicle> vehicles = adpfCallResponsePayload.getADPFResponseBean().getVehicle();

        if (drivers.isEmpty() && vehicles.isEmpty()) {
            softAssert.assertTrue(isElementVisible(addVehicleAndDriversButton, 1), "when no adpf driver or vehicle returned, validate the existance of 'addVehicleAndDriversButton'");
        } else {
            if (!drivers.isEmpty()) {
                validatePrefilledDrivers(drivers, softAssert);
            }
            if (!vehicles.isEmpty()) {
                validatePrefilledVehicles(vehicles, softAssert);
            }
        }
    }

    private void validatePrefilledVehicles(List<AdpfServiceServiceCallEnd.ADPFResponseBean.Vehicle> vehicles, FarmersSoftAssert softAssert) throws Exception {
        List<String> foundVehicleDescriptions = getDisplayedVehicles();

        softAssert.assertEquals(foundVehicleDescriptions.size(), vehicles.size(), "Adpf returned vehicles cound and displayed vehicle count are equal");
        for (int i = 0; i < vehicles.size(); i++) {
            AdpfServiceServiceCallEnd.ADPFResponseBean.Vehicle adpfReturnedVehicle = vehicles.get(i);
            validateVehicleCardDetails(softAssert, adpfReturnedVehicle);
            validateVehicleIsSelectedOrNot(softAssert, adpfReturnedVehicle);
        }

    }

    @NotNull
    public List<String> getDisplayedVehicles() {
        return foundVehicles.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    private void validateVehicleCardDetails(FarmersSoftAssert softAssert, AdpfServiceServiceCallEnd.ADPFResponseBean.Vehicle adpfReturnedVehicle) throws Exception {
        String maskedVin = adpfReturnedVehicle.getMaskedVin();
        String vehicleNumber = adpfReturnedVehicle.getAdpfVehicleReferenceNumber();
        String vehicleDescription = adpfReturnedVehicle.getYear() + SPACE + adpfReturnedVehicle.getMakeDesc() + SPACE + adpfReturnedVehicle.getModelDesc();

        // by this locator we automatically validate the vehicle year, make and model display on the UI
        String vehicleXpath = String.format("//app-vehicle-card[contains(.,'%s')]", vehicleDescription);
        WebElement vehicleNumberAndVin = driver().findElement(By.xpath(vehicleXpath + "//div[contains(@class,'tui-caption') and contains(.,'VIN')]"));
        String expectedVehicleNumberAndVin = String.format("Vehicle %s: (VIN •••%s)", vehicleNumber, maskedVin.substring(14));
        //Masked VIN may contain unicode chars we want to keep, so we use getText
        softAssert.assertEquals(vehicleNumberAndVin.getText().strip(), expectedVehicleNumberAndVin, "expectedVehicleNumberAndVin above the vehicle description is validated ");
        WebElement purchasedOrAcquiredDateElement = driver().findElement(By.xpath(vehicleXpath + "//div[@class='d-flex justify-content-between ng-star-inserted']//span[contains(.,'Purchase') or contains(.,'Acquired') or contains(.,'Owned') or contains(.,'Financed') or contains(.,'Leased')]/..//span[contains(@class,'vehicle-info-value')]"));
        String vehiclePurchaseDate;
        try {
            vehiclePurchaseDate = adpfReturnedVehicle.getPurchaseDate();
            vehiclePurchaseDate.isEmpty();
        } catch (NullPointerException npe) {
            Log.info("Purchase date is not provided in adpf response");
            vehiclePurchaseDate = EMPTY_STRING;
        }

        String month;
        String year;
        if (vehiclePurchaseDate.equals(EMPTY_STRING)) {
            month = "10";
            year = "" + (Integer.parseInt(adpfReturnedVehicle.getYear()) - 1);
        } else {
            month = vehiclePurchaseDate.substring(0, 2);
            year = vehiclePurchaseDate.substring(6);
        }

        String expectedPurchaseOrAcquireDate = String.format("%s/%s", month, year);
        String actualPurchaseDateDisplayed = getTextFromElement(purchasedOrAcquiredDateElement);
        softAssert.assertTrue(actualPurchaseDateDisplayed.contains(expectedPurchaseOrAcquireDate), "The purchase date of the vehicle is correctly prefilled for " + vehicleDescription + " Expected: " + expectedPurchaseOrAcquireDate + " Actual: " + actualPurchaseDateDisplayed);

        // - Verify the following fields are displayed with values prefilled from  ADPF in vehicle card -  Vehicle use,Rideshare, Ownership,Parked at.
        List<WebElement> displayedFieldsForVehicles = driver().findElements(By.xpath(vehicleXpath + "//div[contains(@class,'d-flex justify-content-between')]//span[contains(@class,'vehicle-info-label')]"));
        List<String> displayedFields = displayedFieldsForVehicles.stream().map(this::getTextFromElement).collect(Collectors.toList());
        ArrayList<String> expectedList = new ArrayList<>(Arrays.asList("Vehicle use", "Rideshare", "Owned", "Parked at"));
        softAssert.assertTrue(areTwoListEqual(displayedFields, expectedList), "The vehicle info field are matching for " + vehicleDescription);
    }

    private void validateVehicleIsSelectedOrNot(FarmersSoftAssert softAssert, AdpfServiceServiceCallEnd.ADPFResponseBean.Vehicle adpfReturnedVehicle) throws Exception {
        String vehicleDescription = adpfReturnedVehicle.getYear() + SPACE + adpfReturnedVehicle.getMakeDesc() + SPACE + adpfReturnedVehicle.getModelDesc();
        String vehicleXpath = String.format("//app-vehicle-card[contains(.,'%s')]", vehicleDescription);

        WebElement editReviewButton = driver().findElement(By.xpath(vehicleXpath + "//div[contains(@class,'auto-vehicles-card-edit')]//a"));
        String editOrReview = "";
        boolean checkboxSelected = true;
        try {
            adpfReturnedVehicle.getValidVehicle();
            adpfReturnedVehicle.getPurchaseDate();
            editOrReview = "Edit";
        } catch (Exception exception) {
            editOrReview = "Review";
            checkboxSelected = false;
        }
        softAssert.assertEquals(getTextFromElement(editReviewButton), String.format("%s vehicle", editOrReview), "Vehicle card shows edit or review");

        WebElement checkboxForVehicle = driver().findElement(By.xpath(vehicleXpath + "//input"));
        softAssert.assertTrue(checkboxSelected == getAttributeData(checkboxForVehicle, CLASS).contains(MDC_CHECKBOX_SELECTED), "Vehicle is " + (checkboxSelected? "selected" : "not selected") + " as expected for " + vehicleDescription);
    }

    private void validatePrefilledDrivers(List<AdpfServiceServiceCallEnd.ADPFResponseBean.Driver> drivers, FarmersSoftAssert softAssert) throws Exception {
        List<String> foundDriversDescriptions = foundDrivers.stream().map(this::getTextFromElement).collect(Collectors.toList());

        softAssert.assertEquals(drivers.size(), foundDriversDescriptions.size(), "adpf driver cound is equal to the displayed driver count");

        for (int i = 0; i < drivers.size(); i++) {
            AdpfServiceServiceCallEnd.ADPFResponseBean.Driver adpfDriver = drivers.get(i);
            validatePrefilledCardDetails(softAssert, adpfDriver);
            validateDriverIsSelectedOrNot(softAssert, adpfDriver);
        }
    }

    private void validatePrefilledCardDetails(FarmersSoftAssert softAssert, AdpfServiceServiceCallEnd.ADPFResponseBean.Driver adpfDriver) throws Exception {
        String driverNumber = adpfDriver.getAdpfDriverReferenceNumber();
        String age = adpfDriver.getAge();
        String fullName = adpfDriver.getFirstName() + SPACE + adpfDriver.getLastName();
        fullName = getTheFullNameWithFirstLetterInCaps(fullName);
        String basicDriverInfoAdpf = String.format("%s, %s", fullName, age);
        String driverCardXpath = String.format("//app-driver-card[contains(.,'%s')]", basicDriverInfoAdpf);
        WebElement driverNameAndAgeElement = driver().findElement(By.xpath(driverCardXpath + "//div[contains(@class,'driver-name-header')]"));
        softAssert.assertEquals(getTextFromElement(driverNameAndAgeElement).replace("Applicant should be selected",EMPTY_STRING).strip(), basicDriverInfoAdpf, "Driver fullname and age validated for " + basicDriverInfoAdpf);
        String roleOfDriver = "Additional driver";
        if (driverNumber.equals("1")) {
            roleOfDriver = "Primary insured";
        }
        WebElement roleOfDriverElement = driver().findElement(By.xpath(driverCardXpath + "//div[contains(@class,'auto-drivers-card-role')]"));
        softAssert.assertEquals(getTextFromElement(roleOfDriverElement).replace(" info", EMPTY_STRING), String.format("%s: Driver %s", roleOfDriver, driverNumber), "Driver number and role is matching for " + basicDriverInfoAdpf);

        List<WebElement> displayedDriverInfoElements = driver().findElements(By.xpath(driverCardXpath + "//span[contains(@class,'driver-info-label')]"));

        List<String> expectedDriverInfoLabels = new ArrayList<>(Arrays.asList("Licensed", "Accidents or violations", "Financial responsibility filing", "Marital status"));
        List<String> actualDriverInfoLabels = displayedDriverInfoElements.stream().map(this::getTextFromElement).collect(Collectors.toList());
        if (driverNumber.equals("1")) {
            expectedDriverInfoLabels.add("Currently insured");
            if (!isBDQFlowEnabled()) {
                expectedDriverInfoLabels.add("Occupation");
            }
        }

        if (Integer.parseInt(age) <= MAX_YOUNG_AGE) {
            expectedDriverInfoLabels.add("Attends school more than 100 miles");
            expectedDriverInfoLabels.add("Has a GPA over 3.0");
            expectedDriverInfoLabels.add("Licensed in the last 3 years");
        }

        if (Integer.parseInt(age) >= MIN_OLD_AGE) {
            expectedDriverInfoLabels.add("Driver safety course in last 3 years");
        }
        if (STATES_WITHOUT_FIN_RESP.contains(getSessionStorageAppStore().getData().getLandingStateCode())) {
            expectedDriverInfoLabels.remove("Financial responsibility filing");
        }
        softAssert.assertTrue(areTwoListEqual(actualDriverInfoLabels, expectedDriverInfoLabels), "Driver card info labels are not matching for " + basicDriverInfoAdpf);
    }

    private void validateDriverIsSelectedOrNot(FarmersSoftAssert softAssert, AdpfServiceServiceCallEnd.ADPFResponseBean.Driver adpfDriver) throws Exception {

        ADPFServiceEnd adpfServiceEnd = new ApiHelper().getADPFServiceEnd(getSessionStorageAppStore().getData().getQuoteNumber());

        String firstName = EMPTY_STRING;
        String lastName = EMPTY_STRING;
        String driverNumber = adpfDriver.getAdpfDriverReferenceNumber();
        String editOrReview = "Edit";
        boolean checkboxSelected = true;
        try {
            if (driverNumber.equals("1")) {
                ADPFServiceEnd.DriverPrefillDetails.CurrentCarrier currentCarrier = adpfServiceEnd.getDriverPrefillDetails().getCurrentCarrier();
                currentCarrier.getCarrierCompanyName();
                currentCarrier.getCarrierCompanyStatus();
                currentCarrier.getBILimitPerOccurance();
                currentCarrier.getBILimitPerPerson();
                currentCarrier.getCarrierRatingtNumber();
                adpfDriver.isCarrierNameAvailable();
                editOrReview = adpfDriver.isCarrierNameAvailable() ? "Edit" : "Review";
                checkboxSelected = adpfDriver.isCarrierNameAvailable();
            }
            firstName = adpfDriver.getFirstName();
            lastName = adpfDriver.getLastName();
            adpfDriver.getMaskedDateOfBirth();
            adpfDriver.isLicenseIssuedInUS();
        } catch (Exception e) {
            editOrReview = "Review";
            checkboxSelected = false;
        }

        String cappedFullName = getTheFullNameWithFirstLetterInCaps(firstName + SPACE + lastName);
        String driverXpath = String.format(DRIVER_CARD_XPATH, cappedFullName);
        WebElement editReviewButton = driver().findElement(By.xpath(driverXpath + "//div[contains(@class,'auto-drivers-card-edit')]//a"));

        softAssert.assertEquals(getTextFromElement(editReviewButton), String.format("%s driver", editOrReview), "Driver card shows edit or review for " + cappedFullName);

        WebElement checkboxForDriver = driver().findElement(By.xpath(driverXpath + "//input"));
        softAssert.assertTrue(checkboxSelected == getAttributeData(checkboxForDriver, CLASS).contains(MDC_CHECKBOX_SELECTED), "Driver is " + (checkboxSelected? "selected" : "not selected") + " as expected for " + cappedFullName);
    }


    public void validatePageDescription(FarmersSoftAssert softAssert) {
        List<String> expectedSubHeaders = List.of("Here's what we have so far. Does it all look good?", "Please check the information we have. You can edit anything that doesn't look right.");
        softAssert.assertTrue(expectedSubHeaders.contains(getPageDescriptionText()), "Page desc is matching");
    }

    public String getPageDescriptionText() {
        return getTextFromElement(pageDesc);
    }

    public void validateVehicleSideSheetAndVehicleCard(FarmersSoftAssert softAssert, Vehicle vehicle) throws Exception {
        validateVehicleSideSheetErrorMessages(softAssert);
        validateVehicleSelectedValuesAreReflectedOnTheCard(vehicle, softAssert);
    }

    public void validateDriverSideSheetAndDriverCard(FarmersSoftAssert softAssert, AutoApplicant applicant) throws Exception {
        WebElement driverEditCheckboxInputButtonByFullName = getDriverEditCheckboxInputButtonByFullName(getPniFullNameFromAutoApplicant(applicant));
        clickElement(driverEditCheckboxInputButtonByFullName);
        validateDriverSideSheetErrorMessagesApplicant(softAssert);
        validateDriverSideSheetErrorMessagesAdditionalDriver(softAssert);
        validateDriverSelectedValuesAreReflectedOnTheCard(applicant, softAssert);
    }

    private void validateVehicleSideSheetErrorMessages(FarmersSoftAssert softAssert) {
        clickOnAddVehicleAndDriversButton();
        waitAndClickElement(addVehicleButton);
        softAssert.assertEquals(getTextFromElement(yearErrorMessage), "Please provide year.", "Year error message");
        if (!isBDQFlowEnabled()) {
            softAssert.assertEquals(getTextFromElement(acquireErrorMessage), "Invalid Purchase Date", "Year error message");
        }
    }

    private void validateDriverSideSheetErrorMessagesApplicant(FarmersSoftAssert softAssert) {
        clickSaveChangesDriverSheet();
        String thisIsRequired = "This is required.";
        softAssert.assertEquals(getTextFromElement(genderErrorMessage), thisIsRequired, "Gender error message: applicant ");
        softAssert.assertEquals(getTextFromElement(usOrCaErrorMessage), thisIsRequired, "US or CA license error message applicant");
        softAssert.assertEquals(getTextFromElement(currentlyInsuredErrorMessage), thisIsRequired, "Currently insured error message : applicant");
        waitAndClickElement(closeIcon);
    }

    private void validateDriverSideSheetErrorMessagesAdditionalDriver(FarmersSoftAssert softAssert) {
        waitAndClickElement(addAnotherDriverButton);
        waitAndClickElement(addDriverButton);
        String thisIsRequired = "This is required.";
        String pleaseProvideYour = "Please provide your ";
        softAssert.assertEquals(getTextFromElement(firstNameErrorMessage), pleaseProvideYour + "first name.", "First name error message");
        softAssert.assertEquals(getTextFromElement(lastNameErrorMessage), pleaseProvideYour + "last name.", "Last name error message");
        softAssert.assertEquals(getTextFromElement(dobErrorMessage), pleaseProvideYour + "date of birth (mm/dd/yyyy).", "Dob name error message");
        softAssert.assertEquals(getTextFromElement(genderErrorMessage), thisIsRequired, "Gender error message");
        softAssert.assertEquals(getTextFromElement(usOrCaErrorMessage), thisIsRequired, "US or CA license error message additional driver");
        waitAndClickElement(closeIcon);
    }

    private void validateVehicleSelectedValuesAreReflectedOnTheCard(Vehicle vehicle, FarmersSoftAssert softAssert) throws Exception {

        addVehicleDetails(vehicle);
        waitAndClickElement(addVehicleButton);

        if (isElementVisible(doneAddingVehiclesSideSheet, 1)) {
            waitAndClickElement(doneAddingVehiclesSideSheet);
        } else {
            waitAndClickElement(continueToDriversButtonSideSheet);
        }

        waitAndClickElement(closeIcon);
        validateAddedVehicleDetailsOnCard(vehicle, softAssert);
    }

    public void validateAddedVehicleDetailsOnCard(Vehicle vehicle, FarmersSoftAssert softAssert) throws Exception {

        String vehicleDescription = getVehicleDescriptionFromVehicle(vehicle);

        String valueForLabel = String.format("//div[contains(@class,'card auto-vehicles-card-item vehicle') and contains(.,'%s')]", vehicleDescription) + "//div[contains(@class,'d-flex justify-content-between') and contains(.,'%s')]";

        WebElement displayedVehicleUseValue = driver().findElement(By.xpath(String.format(valueForLabel+"//span[contains(@class,'vehicle-info-value')]", "Vehicle use")));
        WebElement displayedOwnedFinancedLeased = driver().findElement(By.xpath(String.format(valueForLabel+"//span[contains(@class,'vehicle-info-label')]", vehicle.getOwnership())));
        WebElement displayedRideshare = driver().findElement(By.xpath(String.format(valueForLabel+"//span[contains(@class,'vehicle-info-value')]", "Rideshare")));
        WebElement displayedParkedAtValue = driver().findElement(By.xpath(String.format(valueForLabel+"//span[contains(@class,'vehicle-info-value')]", "Parked at")));

        String expectedPurchaseDate = vehicle.getPurchaseDate();
        String expectedVehicleUse = vehicle.getVehicleUsage().contains("Business") ? "Business" : PERSONAL;
        String expectedParkedAt = vehicle.isParkInResidentAddress() ? "Residence" : "Elsewhere";
        String expectedVehicleOwnership = vehicle.getOwnership().equals("Owned")  ? "Owned"
                : vehicle.getOwnership().equals("Financed")
                ? "Financed"
                : "Leased";
        if (isBDQFlowEnabled()) {
            expectedVehicleOwnership = YES;
        }
//      String expectedRideshare = vehicle.getVehicleUsage().contains(RIDESHARE) ? "Yes" : "No";
// Using vehicle.isRideSharing() for expectedRideshare value instead of vehicle.getVehicleUsage because the vehicle usage is overriden by method - updateApplicantDataToAvoidPossibleBw
        String expectedRideshare = vehicle.isRidesharing() ? "Yes" : "No";
        softAssert.assertEquals(getTextFromElement(displayedVehicleUseValue), expectedVehicleUse, "Expected vehicle use is not displayed as expected for " + vehicleDescription);
        softAssert.assertEquals(getTextFromElement(displayedOwnedFinancedLeased), expectedVehicleOwnership, "Expected vehicle ownership is not displayed as expected for " + vehicleDescription);
        softAssert.assertEquals(getTextFromElement(displayedRideshare), expectedRideshare, "Expected vehicle rideshare is not displayed as expected for " + vehicleDescription);
        softAssert.assertEquals(getTextFromElement(displayedParkedAtValue), expectedParkedAt, "Expected vehicle parked at is not displayed as expected for " + vehicleDescription);

    }

    private void validateDriverSelectedValuesAreReflectedOnTheCard(AutoApplicant applicant, FarmersSoftAssert softAssert) throws Exception {

        String fullName = getPniFullNameFromAutoApplicant(applicant);
        WebElement checkboxForApplicant = getDriverEditCheckboxInputButtonByFullName(fullName);

        String driverCardXpath = String.format(DRIVER_CARD_XPATH, fullName);
        String currentlyInsured = "Currently insured";
        String licensed = "Licensed";
        String accidentOrViolations = "Accidents or violations";
        String financialResponsibilityFiling = "Financial responsibility filing";
        String maritalStatus = "Marital status";
        String occupation = "Occupation";

        String driverInfoXpath = driverCardXpath + "//div[contains(@class,'justify-content-between') and contains(.,'%s')]//span[contains(@class,'driver-info-value')]";

        // validate the Nulls before updating the applicant details
        softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(String.format(driverInfoXpath, currentlyInsured)))), "---", "Currently insured status (before updating the details) is not matching for " + fullName);
        softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(String.format(driverInfoXpath, licensed)))), "---", "Licensed status (before updating the details) is not matching for " + fullName);
        softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(String.format(driverInfoXpath, accidentOrViolations)))), "0", "Accidents or violations count (before updating the details) is not matching for " + fullName);
        if (!STATES_WITHOUT_FIN_RESP.contains(applicant.getStateCode())) {
            softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(String.format(driverInfoXpath, financialResponsibilityFiling)))), NO, "Financial responsibility filing status (before updating the details) is not matching for " + fullName);
        }
        softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(String.format(driverInfoXpath, maritalStatus)))), "Single", "Marital status is (before updating the details) not matching for " + fullName);
        if (!isBDQFlowEnabled()) {
            softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(String.format(driverInfoXpath, occupation)))), "Unknown", "Occupation is (before updating the details) not matching for " + fullName);
        }

        clickElement(checkboxForApplicant);
List<Occupations> supportedEmployedOccupationsByState = new ArrayList<>(AceAutoSupportedOccupationByState.getSupportedEmployedOccupationsByState(applicant.getStateCode()));
Collections.shuffle(supportedEmployedOccupationsByState);
applicant.setOccupation(supportedEmployedOccupationsByState.get(0).getOccupationName());
        addApplicantDetails(applicant);
        AceAutoSupportedOccupationByState aceAutoSupportedOccupationByState = AceAutoSupportedOccupationByState.valueOf(applicant.getStateCode());
        if (!aceAutoSupportedOccupationByState.getSupportedEmployedOccupations().stream().map(each -> each.getOccupationName()).collect(Collectors.toList()).contains(applicant.getOccupation())) {
            applicant.setOccupation(OTHER);
        }
        //validate after updating the applicant details
        softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(String.format(driverInfoXpath, currentlyInsured)))), applicant.getCurrentlyInsuredStatus().equals("Insured") ? YES : NO, "Currently insured status is not matching for " + fullName);
        softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(String.format(driverInfoXpath, licensed)))), applicant.getFirstAgeForeignDriverLicense() == 18 ? NO : "US or Canada", "Licensed status is not matching for " + fullName);
        softAssert.assertEquals(Integer.parseInt(getTextFromElement(driver().findElement(By.xpath(String.format(driverInfoXpath, accidentOrViolations))))), applicant.getIncidents().size(), "Accidents or violations count is not matching for " + fullName);
        if (!STATES_WITHOUT_FIN_RESP.contains(applicant.getStateCode())) {
            softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(String.format(driverInfoXpath, financialResponsibilityFiling)))), applicant.getFinancialFiling().contains(SR_22) ? YES : NO, "Financial responsibility filing status is not matching for " + fullName);
        }
        softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(String.format(driverInfoXpath, maritalStatus)))), applicant.getMaritalStatus(), "Marital status is not matching for " + fullName);
        if (!isBDQFlowEnabled()) {
            softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(String.format(driverInfoXpath, occupation)))), (applicant.getOccupation().equals(OTHER) || applicant.getOccupation().equals(EMPTY_STRING)) ? "Unknown" : "Employed " + applicant.getOccupation(), "Occupation status is not matching for " + fullName);
        }
    }

    public WebElement getDriverEditCheckboxInputButtonByFullName(String fullName) throws Exception {
        String[] arrays = fullName.split(SPACE);
        StringBuilder capitalizedFullName = new StringBuilder();
        for (String string : arrays) {
            if (string.isEmpty()) {
                continue;
            }
            String adjusted = string.substring(0, 1).toUpperCase() + string.substring(1).toLowerCase();
            capitalizedFullName.append(adjusted).append(SPACE);
        }
        return driver().findElement(By.xpath(String.format(DRIVER_CARD_XPATH + "//input", capitalizedFullName.toString().strip())));
    }

    public void clickDriverCheckbox(String fullName) throws Exception {
        WebElement driverEditCheckboxInputButtonByFullName = getDriverEditCheckboxInputButtonByFullName(fullName);
        scrollElementToMiddle(driverEditCheckboxInputButtonByFullName);
        clickElement(driverEditCheckboxInputButtonByFullName);
    }

    public void clickEditButtonForDriver(String driverFullName) throws Exception {
        WebElement driverEditButtonByFullName = getDriverEditButtonByFullName(driverFullName);
        scrollElementToMiddle(driverEditButtonByFullName);
        waitAndClickElement(driverEditButtonByFullName);
        isElementVisible(addEditDriverHeader, 5);
    }

    public void validateMarriedCheckboxAndOptions(FarmersSoftAssert softAssert, ADPFApplicant applicant) throws Exception {
        List<String> displayedDrivers = foundDrivers.stream().map(each -> getTextFromElement(each).substring(0, getTextFromElement(each).indexOf(","))).collect(Collectors.toList());
        String applicantFullName = getPniFullNameFromAutoAdpfApplicant(applicant);
        displayedDrivers.remove(applicantFullName);
        WebElement driverEditCheckboxInputButtonByFullName = getDriverEditCheckboxInputButtonByFullName(applicantFullName);
        scrollElementToMiddle(driverEditCheckboxInputButtonByFullName);
        clickElement(driverEditCheckboxInputButtonByFullName);
        isElementVisible(addEditDriverHeader, 5);
        WebElement marriedCheckbox = driver().findElement(By.xpath(getCheckboxXpathForTheLabel(MARRIED_CHECKBOX_TEXT) + "//input"));
        // validate married checkbox subtitle
        WebElement marriedSubtitle = driver().findElement(By.xpath(String.format("//div[@class='row mb-2 consolidated-checkbox' and contains(.,'%s')]//p", MARRIED_CHECKBOX_TEXT)));
        softAssert.assertEquals(getTextFromElement(marriedSubtitle), MARRIED_CHECKBOX_SUB_TEXT, "Married checkbox subtitle is matching");

        clickElement(marriedCheckbox);
        sleep(1);
        List<WebElement> marriedRadioButtonOptions = driver().findElements(By.xpath("//div[@class='row ng-star-inserted' and contains(.,'Someone not on')]//label[@class='mdc-label']"));
        List<String> radioButtonOptionTexts = marriedRadioButtonOptions.stream().map(this::getTextFromElement).collect(Collectors.toList());
        displayedDrivers.forEach(each -> {
            softAssert.assertTrue(radioButtonOptionTexts.contains(each), "Spouse name " + each + " is displayed in the married radio button options");
        });

        // click on Someone Else option and validate the spouse side sheet
        if (!displayedDrivers.isEmpty()) {
            waitAndClickElement(someoneNotOnThisQuoteButton);
            softAssert.assertEquals(getTextFromElement(someoneNotOnThisQuoteButton), "Someone not on this quote", "Someone not on this quote button text is matching");
        }

        waitAndClickElement(driverSaveButton);

        // validate error messages for nested spouse side sheet
        String pleaseProvideYour = "Please provide your ";
        String thisIsRequired = "This is required.";
        softAssert.assertEquals(getTextFromElement(firstNameErrorMessage), pleaseProvideYour + "first name.", "First name error message : nested spouse side sheet");
        softAssert.assertEquals(getTextFromElement(lastNameErrorMessage), pleaseProvideYour + "last name.", "Last name error message : nested spouse side sheet");
        softAssert.assertEquals(getTextFromElement(dobErrorMessage), pleaseProvideYour + "date of birth (mm/dd/yyyy).", "Dob name error message : nested spouse side sheet");
        softAssert.assertEquals(getTextFromElement(spouseGenderErrorMessage), thisIsRequired, "Gender error message : nested spouse side sheet");
        if (isNonDriverImplementedState(applicant.getStateCode())) {
            softAssert.assertEquals(getTextFromElement(willBeDrivingErrorMessage), thisIsRequired, "Will your spouse be driving question error message : nested spouse side sheet");
        } else {
            softAssert.assertEquals(getTextFromElement(usOrCaErrorMessage), thisIsRequired, "US or CA license error message : nested spouse side sheet");
        }

        // add and save spouse details
        String spouseFirstName = "Spousefn";
        String spouseLastName = "Spouseln";
        String spouseFullName = spouseFirstName + SPACE + spouseLastName;
        addSpouseDetails("Accountant", spouseFirstName, spouseLastName, "01/15/1988", "Female", Optional.of(true), true, true);

        fillOutAdpfDriverDetailsRandomly(Collections.emptyList());
        sleep(1);
        String spouseDriverCard = String.format("//app-driver-card[contains(.,'%s')]", spouseFullName);
        String maritalInfoXpath = spouseDriverCard + "//div[contains(@class,'justify-content-between') and contains(.,'Marital status')]//span[contains(@class,'driver-info-value')]";
        WebElement spouseMaritalStatus = driver().findElement(By.xpath(maritalInfoXpath));
        scrollElementToMiddle(spouseMaritalStatus);
        softAssert.assertEquals(getTextFromElement(spouseMaritalStatus), "Married", "Marital status is not matching for spouse driver card");


    }

    public void editPNIDriverIfNeededWithAdpfData(ADPFApplicant applicant) throws Exception {
        String applicantFullName = getPniFullNameFromAutoAdpfApplicant(applicant);
        WebElement driverEditCheckboxInputButtonByFullName = getDriverEditCheckboxInputButtonByFullName(applicantFullName);
        if (!driverEditCheckboxInputButtonByFullName.getAttribute(CLASS).contains(MDC_CHECKBOX_SELECTED)) {
            scrollElementToMiddle(driverEditCheckboxInputButtonByFullName);
            clickElement(driverEditCheckboxInputButtonByFullName);
            fillOutAdpfDriverDetailsRandomly(Collections.emptyList());
        }
    }

    public void clickSaveChangesDriverSheet() {
        waitAndClickElement(addDriverSaveChangesButton);
        waitForSpinnerToBeGone();
    }

    public void validateDriverToolTips(ADPFApplicant applicant, FarmersSoftAssert softAssert) throws Exception {
        String additionalDriverContent = "Drivers have the same coverage, but limited access to your insurance account. They can get ID cards, pay bills and get insurance documents. But they cannot make any changes to your coverage.";
        String additionalDriverHeader = "Additional driver(s)";
        String pniContent = "The applicant and main point of contact for the insurance policy. They will be responsible for signing all documents upon purchase.";
        String pniHeader = "Primary named insured";
        String sniContent = "The spouse or domestic partner of the applicant will be added as a \"secondary named insured\" and will have the same rights to sign documents and make changes to the policy.";
        String sniHeader = "Secondary named insured";

        // validate tooltip for primary named insured
        String pniFullName = getPniFullNameFromAutoAdpfApplicant(applicant);
        validateDriverTooltipSection(pniFullName, pniHeader, pniContent, softAssert);

        // validate tooltip for additional drivers
        String additionalDriverFirstName = "Additional";
        String additionalDriverLastName = "Driver";
        String addDriverFullName = additionalDriverFirstName + SPACE + additionalDriverLastName;
        addAdditionalDriver(additionalDriverFirstName, additionalDriverLastName, false);
        validateDriverTooltipSection(addDriverFullName, additionalDriverHeader, additionalDriverContent, softAssert);

        // validate tooltip for sni
        String sniFirstName = "Spousefn";
        String sniLastName = "Spouseln";
        String sniFullName = sniFirstName + SPACE + sniLastName;
        addAdditionalDriver(sniFirstName, sniLastName, true);
        validateDriverTooltipSection(sniFullName, sniHeader, sniContent, softAssert);

        // validate nested tooltip for financial filing
        if (!isFinancialFilingQuestionDisabled(applicant.getStateCode())) {
            scrollAndClickOnElement(getDriverEditButtonByFullName(sniFullName));
            validateFinancialFilingNestedTooltipSection(softAssert);
            pressEscKey();
        }
    }


    private void validateDriverTooltipSection(String fullName, String expectedHeader, String expectedDesc, FarmersSoftAssert softAssert) throws Exception {
        String headerText;
        String descriptionText;
        if (isUseMobileViewEnabled()) {
            WebElement matIconForMobileView = driver().findElement(By.xpath(String.format(DRIVER_CARD_XPATH, fullName) + "/ancestor::div[@class='row ng-star-inserted']//mat-icon[@attr.aria-label='information icon']"));
            scrollElementToMiddle(matIconForMobileView);
            clickElement(matIconForMobileView);
            wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//h1[@class='col-10 tui-subtitle-text-1']")));
            headerText = getTextFromElement(driver().findElement(By.xpath("//h1[@class='col-10 tui-subtitle-text-1']")));
            descriptionText = getTextFromElement(driver().findElement(By.xpath("//p[@class='model-caption-text']")));
            waitAndClickElement(closeIcon);
        } else {
            headerText = getTextFromElement(driver().findElement(By.xpath(String.format(DRIVER_CARD_XPATH, fullName) + "/ancestor::div[@class='row ng-star-inserted']//p[contains(@class,'tui-info-box-header tui-field-label-text')]")));
            descriptionText = getTextFromElement(driver().findElement(By.xpath(String.format(DRIVER_CARD_XPATH, fullName) + "/ancestor::div[@class='row ng-star-inserted']//p[contains(@class,'tui-info-box-content')]")));
        }

        softAssert.assertEquals(headerText, expectedHeader, "Tooltip header is matching for " + fullName);
        softAssert.assertEquals(descriptionText, expectedDesc, "Tooltip description is matching for " + fullName);

    }

    private void validateFinancialFilingNestedTooltipSection(FarmersSoftAssert softAssert) throws Exception {

        String expectedHeader1 = "Financial responsibility filing";
        String expectedHeader2 = "Do I need an SR-22 or FR-44?";
        String expectedDesc1 = "Financial filing (also known as SR-22 or FR-44) are filed by insurance companies on behalf of the insured.";
        String expectedDesc2 = "The filing notifies the state if you are maintaining coverage and financially responsible for accidents. If you need a financial responsibility filing in a different state, please contact a Farmers representative.";

        scrollAndClickOnElement(financialFilingMatIcon);
        softAssert.assertEquals(getTextFromElement(waitElementBeVisible(financialFilingTooltipHeader1)), expectedHeader1, "Financial filing tooltip header1 is matching");
        softAssert.assertEquals(getTextFromElement(financialFilingTooltipHeader2), expectedHeader2, "Financial filing tooltip header2 is matching");
        softAssert.assertEquals(getTextFromElement(financialFilingTooltipDescription1), expectedDesc1, "Financial filing tooltip desc1 is matching");
        softAssert.assertEquals(getTextFromElement(financialFilingTooltipDescription2), expectedDesc2, "Financial filing tooltip desc2 is matching");
        closeSideSheetWithRandomClick();
    }

    private void addAdditionalDriver(String firstName, String lastName, boolean isMarriedToPni) throws Exception {
        waitAndClickElement(addAnotherDriverButton);
        isElementVisible(addEditDriverHeader, 1);
        selectGenderButton("Male");
        fillOutNamesAndDobFields(firstName, lastName, "05/20/1999");
        selectUSOrCALicensedButton("Yes");
        if (isMarriedToPni) {
            WebElement marriedCheckbox = driver().findElement(By.xpath(getCheckboxXpathForTheLabel(MARRIED_CHECKBOX_TEXT) + "//input"));
            scrollAndClickOnElement(marriedCheckbox);
            sleep(1);// wait for the radio button options to be visible
            AppStore.Data.CustomerData customerData = getSessionStorageAppStore().getData().getCustomerData();
            String pniFullName = customerData.getFirstName() + SPACE + customerData.getLastName();
            WebElement pniNameAsSpouse = driver().findElement(By.xpath(String.format("//mat-radio-button[contains(.,'" +
                    "%s')]//input", pniFullName)));
            scrollAndClickOnElement(pniNameAsSpouse);
        }
        waitAndClickElement(addDriverButton);
        waitForSpinnerToBeGone();
    }

    private void closeSideSheetWithRandomClick() throws Exception {
        boolean backButtonUse = RandomUtils.nextBoolean();
        if (backButtonUse) {
            scrollAndClickOnHiddenElement(infoSideSheetBackButton);
        } else {
            waitAndClickElement(closeIcon);
        }
    }

    public void updateUsCALicensedStatus(String fullName, boolean licensedInUSorCA) throws Exception {
        clickEditButtonWithDriverFullName(fullName);
        selectUSOrCALicensedButton(licensedInUSorCA ? NO : YES);
        clickDriverSaveChangesButton();
    }

    public void validateAdditionalQuestionsAreNotAskedForNonDrivingSpouse(AutoApplicant applicant, FarmersSoftAssert softAssert) throws Exception {
        waitElementBeVisible(addEditDriverHeader);
        selectGenderButton(applicant.getGender());
        selectUSOrCALicensedButton(applicant.getFirstAgeForeignDriverLicense() == 18 ? NO : YES);
        fillOutPriorInsuranceDetails(applicant);
        // click married checkbox
        WebElement marriedCheckbox = driver().findElement(By.xpath(getCheckboxXpathForTheLabel(MARRIED_CHECKBOX_TEXT) + "//input"));
        scrollElementToMiddle(marriedCheckbox);
        clickElement(marriedCheckbox);

        String spouseFn = "Spousefn";
        String spouseLn = "Spouseln";
        String spouseFullName = spouseFn + SPACE + spouseLn;
        addSpouseDetails("Accountant", spouseFn, spouseLn, "02/25/1999", "Female", Optional.of(false), false, false);
        WebElement yesButton = driver().findElement(By.xpath(String.format("//div[contains(@aria-label,'be driving')]//button[contains(.,'%s')]", YES)));
        WebElement noButton = driver().findElement(By.xpath(String.format("//div[contains(@aria-label,'be driving')]//button[contains(.,'%s')]", NO)));
        softAssert.assertTrue(isElementVisible(yesButton, 1) && isElementVisible(noButton, 1), "You spouse will Be driving question is displayed for non-driving spouse with Yes and No options");

        waitElementBeVisible(yesButton);
        scrollAndClickOnElement(yesButton);
        // validate occupation question is visible with Yes
        if (!isBDQFlowEnabled()) {
            softAssert.assertTrue(isElementVisible(letsFindMyOccupationButtonSpouse, 1), "Let's find my occupation button is displayed when spouse will be driving is Yes");
        }

        // validate is licensed in the US/CA question is visible with Yes
        By isLicensedYesXpath = By.xpath(String.format("//div[contains(@aria-label,'Add a spouse')]//div[@class='ng-star-inserted' and contains(.,'Canadian')]//button[contains(.,'%s')]", YES));
        By isLicensedNoXpath = By.xpath(String.format("//div[contains(@aria-label,'Add a spouse')]//div[@class='ng-star-inserted' and contains(.,'Canadian')]//button[contains(.,'%s')]", NO));

        softAssert.assertTrue(isElementDisplayed(isLicensedYesXpath), "Is your spouse licensed in the US or Canada question is displayed with Yes option when spouse will be driving is Yes");
        softAssert.assertTrue(isElementDisplayed(isLicensedNoXpath), "Is your spouse licensed in the US or Canada question is displayed with No option when spouse will be driving is Yes");

        scrollAndClickOnElement(noButton);
        // validate occupation question is not visible with No
        softAssert.assertFalse(isElementVisible(letsFindMyOccupationButtonSpouse, 1), "Let's find my occupation button is NOT displayed when spouse will be driving is No");

        // validate is licensed in the US/CA question is not visible with No
        softAssert.assertFalse(isElementDisplayed(isLicensedYesXpath), "Is your spouse licensed in the US or Canada question is NOT displayed with Yes option when spouse will be driving is No");
        softAssert.assertFalse(isElementDisplayed(isLicensedNoXpath), "Is your spouse licensed in the US or Canada question is NOT displayed with No option when spouse will be driving is No");
        clickDriverSaveButton(); // save SNI with Non driving details
        clickSaveChangesDriverSheet(); // save PNI side sheet
        waitAndClickElement(doneAddingDriverButton);
        scrollToBottomOfPage();
        String spouseCard = String.format(DRIVER_CARD_XPATH, spouseFullName);
        List<WebElement> displayedDriverInfoElements = driver().findElements(By.xpath(spouseCard + "//span[contains(@class,'driver-info-label')]"));
        List<String> displayedDriverInfoLabelsForNondrivingSpouse = displayedDriverInfoElements.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> expectedDriverInfoLabelsForNondrivingSpouse = new ArrayList<>(Arrays.asList("Licensed", "Marital status"));
        // validate only Licensed and Marital status labels are displayed for non-driving spouse
        softAssert.assertTrue(areTwoListEqual(displayedDriverInfoLabelsForNondrivingSpouse, expectedDriverInfoLabelsForNondrivingSpouse), "Driver card info labels are not matching for non-driving spouse");

        // validate the values for Licensed and Marital status for non-driving spouse
        String spouseInfoXpath = spouseCard + "//div[contains(@class,'justify-content-between') and contains(.,'%s')]//span[contains(@class,'driver-info-value')]";

        softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(String.format(spouseInfoXpath, "Licensed")))), "No", "License status should be No for non-driving spouse");
        softAssert.assertEquals(getTextFromElement(driver().findElement(By.xpath(String.format(spouseInfoXpath, "Marital status")))), "Married", "Marital status should be Married for non-driving spouse");


        // edit spouse to validate again
        clickEditButtonWithDriverFullName(spouseFn + SPACE + spouseLn);
        // validate that the additional questions are not displayed when spouse is non-driving
        softAssert.assertFalse(isElementVisible(letsFindMyOccupationButtonSpouse, 1), "Let's find my occupation button is NOT displayed for non-driving spouse");
        softAssert.assertFalse(isElementDisplayed(isLicensedYesXpath), "Is your spouse licensed in the US or Canada question is NOT displayed with Yes option when spouse will be driving is No");
        softAssert.assertFalse(isElementDisplayed(isLicensedNoXpath), "Is your spouse licensed in the US or Canada question is NOT displayed with No option when spouse will be driving is No");

        // validate accident checkbox is not visible
        softAssert.assertFalse(isElementPresent(By.xpath(getCheckboxXpathForTheLabel(ACCIDENT_CHECKBOX_TEXT))), "Accident checkbox is not displayed for non-driving spouse");
    }

    public void validateNonDrivingSpouseProperlyPassedInRateRequest(AutoApplicant applicant, boolean bwFlow) throws Exception {
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        applicant.setTestScenario(applicant.getTestScenario() + SPACE + NON_DRIVING_SPOUSE);
        SqlAdditionalDriver additionalDriver = applicant.getAdditionalDrivers().get(1);
        additionalDriver.setFirstName("Driverfn");
        additionalDriver.setLastName("Driverln");
        addVehiclesWhenNoneFound(applicant);
        addDriversWhenNoneFound(applicant);
        String additionalDriverFullName = additionalDriver.getFirstName() + SPACE + additionalDriver.getLastName();
        WebElement driverEditButtonByFullName = getDriverEditButtonByFullName(additionalDriverFullName);
        scrollAndClickOnElement(driverEditButtonByFullName);
        waitElementBeVisible(addEditDriverHeader, 1);
        WebElement marriedCheckbox = driver().findElement(By.xpath(getCheckboxXpathForTheLabel(MARRIED_CHECKBOX_TEXT)));
        scrollAndClickOnElement(marriedCheckbox);
        String additionalDriverSpouseFirstName = "Spousefn";
        String additionalDriverSpouseLastName = "Spouseln";
        addSpouseDetails("Accountant", additionalDriverSpouseFirstName, additionalDriverSpouseLastName, "03/30/1990", "Female", Optional.of(false), false, true);
        clickSaveChangesDriverSheet(); // save PNI side sheet

        navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        softAssert.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote summary page is loaded");
        ApiHelper apiHelper = new ApiHelper();

        String quoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
        if (!bwFlow) { // farmers flow
            RateQuoteServiceInitiated rateQuoteServiceInitiated = apiHelper.getRateQuoteServiceInitiated(quoteNumber);
            List<RateQuoteServiceInitiated.CalculateQuotePremium.AutoQuoteDetails.DriverVehicleDetails.Driver> drivers = rateQuoteServiceInitiated.getCalculateQuotePremium().getAutoQuoteDetails().getDriverVehicleDetails().get(0).getDriver();
            RateQuoteServiceInitiated.CalculateQuotePremium.AutoQuoteDetails.DriverVehicleDetails.Driver sni = drivers.stream().filter(each -> each.getFirstName().equals(applicant.getAdditionalDrivers().get(0).getFirstName())).collect(Collectors.toList()).get(0);
            testStepAssert(sni.getNonDriverReason().equals("EX"), "nonDriverReason for SNI should be EX");
            RateQuoteServiceInitiated.CalculateQuotePremium.AutoQuoteDetails.DriverVehicleDetails.Driver additionalDriverSpouse = drivers.stream().filter(each -> each.getFirstName().equals(additionalDriverSpouseFirstName)).collect(Collectors.toList()).get(0);
            testStepAssert(additionalDriverSpouse.getNonDriverReason().equals("EX"), "nonDriverReason for additional driver spouse should be EX");
        } else {
            ArrayList<AppStore.Auto.Driver> drivers = getSessionStorageAppStore().getAuto().getDrivers();
            AppStore.Auto.Driver sni = drivers.get(1);
            AppStore.Auto.Driver addDriverSpouse = drivers.get(3);
            softAssert.assertEquals(sni.getSpouseLicensed(), "NL", "Spouse licensed value for SNI should be NL");
            softAssert.assertEquals(addDriverSpouse.getSpouseLicensed(), "NL", "Spouse licensed value for additional driver spouse should be NL");
        }

        softAssert.assertAll();
    }

    public void addVehicleWithYMMAndFaultyVINAndValidateVINError(FarmersSoftAssert softAssert, Vehicle vehicle) throws Exception {
        clickOnAddVehicleAndDriversButton();
        fillOutYMMDetails(vehicle);
        sendKeysToElement(vinInputField, "22222222");
        clickAddVehicleButtonInAddVehicleSideSheet();
        checkVINShouldBe17CharError(softAssert);
        softAssert.assertTrue(isAddVehicleSideSheetOpen(), "Add vehicle side sheet is still open, User is not able to save vehicle with VIN error");
        clearOutFieldUsingBackSpace(vinInputField);
    }

    public void addVehicleWithUpdatedYMM(Vehicle vehicle) throws Exception {
        updateYMMTypeOwnerShipForVehicle(vehicle);
        fillOutYMMDetails(vehicle);
        fillOutVehiclePurchaseDate(vehicle);
        selectVehicleUsedFor(vehicle);
        selectVehicleOwnership(vehicle);
        selectGarageAddress(vehicle);
        clickAddVehicleButtonInAddVehicleSideSheet();
        waitAndClickElement(closeIcon);
        waitForSpinnerToBeGone();
    }

    private void clickAddVehicleButtonInAddVehicleSideSheet() {
        clickElement(addVehicleButton);
    }

    public void validateCheckboxesForAllDrivers(FarmersSoftAssert softAssert, AutoApplicant applicant) throws Exception {
        String pniFullName = getPniFullNameFromAutoApplicant(applicant);
        WebElement pniEditButton = getDriverEditButtonByFullName(pniFullName);
        waitAndClickElement(pniEditButton);
        waitElementBeVisible(addEditDriverHeader);
        List<String> displayedCheckboxLabels = checkboxLabels.stream().map(this::getTextFromElement).collect(Collectors.toList());
        displayedCheckboxLabels.removeIf(String::isEmpty);
        Log.info(String.format("Displayed checkbox labels for %s: ", pniFullName) + displayedCheckboxLabels);
        validateCheckboxSubtitles(softAssert, displayedCheckboxLabels);
        softAssert.assertTrue(areTwoListEqual(displayedCheckboxLabels, getExpectedCheckboxesForPni(applicant)), String.format("Displayed checkbox labels for PNI (%s) are as expected", pniFullName));
        waitAndClickElement(closeIcon);
        wait.until(ExpectedConditions.invisibilityOf(addEditDriverHeader));
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        for (SqlAdditionalDriver additionalDriver : additionalDrivers) {
            String additionalDriverFullName = additionalDriver.getFirstName() + SPACE + additionalDriver.getLastName();
            WebElement additionalDriverEditButton;
            try {
                // Existing behavior (unchanged for unmasked flows)
                additionalDriverEditButton = getDriverEditButtonByFullName(additionalDriverFullName);
            } catch (Exception e) {
                //  for retrieval flows where first name is masked
                additionalDriverEditButton = getDriverEditButtonByLastNameAndAge(
                        additionalDriver.getLastName(),
                        additionalDriver.getAge()
                );
            }
            waitElementBeVisible(additionalDriverEditButton);
            scrollAndClickOnElement(additionalDriverEditButton);
            waitElementBeVisible(addEditDriverHeader);
            List<String> additionalDriverDisplayedCheckboxLabels = checkboxLabels.stream().map(this::getTextFromElement).collect(Collectors.toList());
            validateCheckboxSubtitles(softAssert, additionalDriverDisplayedCheckboxLabels);
            additionalDriverDisplayedCheckboxLabels.removeIf(String::isEmpty);
            Log.info(String.format("Displayed checkbox labels for %s: ", additionalDriverFullName) + additionalDriverDisplayedCheckboxLabels);
            // validate that the displayed checkboxes for additional driver are same as PNI
            waitAndClickElement(closeIcon);
            softAssert.assertTrue(areTwoListEqual(additionalDriverDisplayedCheckboxLabels, getExpectedCheckboxesForAdditionalDriver(additionalDriver)), String.format("Displayed checkbox labels for Additional Driver (%s) are as expected", additionalDriverFullName));
            wait.until(ExpectedConditions.invisibilityOf(addEditDriverHeader));
        }
    }

    private List<String> getExpectedCheckboxesForPni(AutoApplicant applicant) throws Exception {
        List<String> expectedCheckboxLabelsForPni = new ArrayList<>(Arrays.asList(
                ACCIDENT_CHECKBOX_TEXT,
                MARRIED_CHECKBOX_TEXT,
                FINANCIAL_RESPONSIBILITY_CHECKBOX_TEXT
        ));

        String stateCode = applicant.getStateCode();

        if (STATES_WITHOUT_FIN_RESP.contains(stateCode)) {
            expectedCheckboxLabelsForPni.remove(FINANCIAL_RESPONSIBILITY_CHECKBOX_TEXT);
        }

        if (applicant.getAge() >= 55
                && isSafetyCourseExpectedState(stateCode)
                && ((isOnBristolWest() && isSafetyCourseExpectedStateBDQ(stateCode)) || isOnFarmers())) {

            if (stateCode.equals(OR) && applicant.getAge() >= 70) {
                expectedCheckboxLabelsForPni.add(SAFETY_COURSE_OR_LABEL);
            } else {
                expectedCheckboxLabelsForPni.add(SAFETY_COURSE_CHECKBOX_TEXT);
            }
        } else {
            // no age limit for OK state to have safety course checkbox
            if (stateCode.equals(OK)) {
                expectedCheckboxLabelsForPni.add(SAFETY_COURSE_CHECKBOX_TEXT);
            }
        }


        if (applicant.getAge() <= 25) {
            expectedCheckboxLabelsForPni.add(HAS_A_GPA_OVER_3);
            expectedCheckboxLabelsForPni.add(HAS_HAD_DRIVER_LICENSE_IN_LESS_THAN_3_YEARS);
            expectedCheckboxLabelsForPni.add(SHARES_VEHICLE_USAGE_IN_HOUSEHOLD);
        }

        return expectedCheckboxLabelsForPni;
    }

    private List<String> getExpectedCheckboxesForAdditionalDriver(SqlAdditionalDriver addDriver) throws Exception {
        String stateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        boolean isSni = addDriver.getRelationshipToApplicant().equals(SPOUSE);
        List<String> expectedCheckboxesForAdditionalDriver = new ArrayList<>(Arrays.asList(
                ACCIDENT_CHECKBOX_TEXT,
                MARRIED_CHECKBOX_TEXT,
                FINANCIAL_RESPONSIBILITY_CHECKBOX_TEXT
        ));

        if (STATES_WITHOUT_FIN_RESP.contains(stateCode)) {
            expectedCheckboxesForAdditionalDriver.remove(FINANCIAL_RESPONSIBILITY_CHECKBOX_TEXT);
        }

        if (stateCode.equals(MI) && !isSni) {
            expectedCheckboxesForAdditionalDriver.add(NOT_RELATED_TO_ME);
            expectedCheckboxesForAdditionalDriver.add(DOES_NOT_LIVE_IN_HOUSE);
        }

        if (stateCode.equals(VA) && isSni) {
            if (addDriver.getLicenseToDriveInUSA().equals(YES)) {
                expectedCheckboxesForAdditionalDriver.add(LIVES_AWAY_FROM_HOME);
            } else {
                expectedCheckboxesForAdditionalDriver.add(IS_DISABLED);
            }
        }

        if (addDriver.getAge() >= 55
                && isSafetyCourseExpectedState(stateCode)
                && ((isOnBristolWest() && !stateCode.equals(MI)) || isOnFarmers())) {
            if (stateCode.equals(OR) && addDriver.getAge() >= 70) {
                expectedCheckboxesForAdditionalDriver.add(SAFETY_COURSE_OR_LABEL);
            } else {
                expectedCheckboxesForAdditionalDriver.add(SAFETY_COURSE_CHECKBOX_TEXT);
            }
        } else {
            // no age limit for Ok state to see safety course
            if (stateCode.equals(OK)) {
                expectedCheckboxesForAdditionalDriver.add(SAFETY_COURSE_CHECKBOX_TEXT);
            }
        }

        if (addDriver.getAge() <= 25) {
            if(isOnFarmers()) {
                expectedCheckboxesForAdditionalDriver.add(HAS_A_GPA_OVER_3);
            }
            expectedCheckboxesForAdditionalDriver.add(HAS_HAD_DRIVER_LICENSE_IN_LESS_THAN_3_YEARS);
            if (stateCode.equals(OH)) {
                expectedCheckboxesForAdditionalDriver.add(SHARES_VEHICLE_USAGE_IN_HOUSEHOLD);
            }
            if (!isSni) {
                expectedCheckboxesForAdditionalDriver.add(DISTANT_STUDENT_CHECKBOX_TEXT);
            }
        }

        return expectedCheckboxesForAdditionalDriver;
    }

    private void validateCheckboxSubtitles(FarmersSoftAssert softAssert, List<String> checkboxes) throws Exception {

        if (checkboxes.contains(ACCIDENT_CHECKBOX_TEXT)) {
            WebElement accidentSubtitle = driver().findElement(By.xpath(String.format("//div[@class='row mb-2 consolidated-checkbox' and contains(.,'%s')]//p", ACCIDENT_CHECKBOX_TEXT)));
            softAssert.assertEquals(getTextFromElement(accidentSubtitle), ACCIDENT_CHECKBOX_SUB_TEXT, "Accident checkbox subtitle is matching");
        }

        if (checkboxes.contains(HAS_A_GPA_OVER_3)) {
            WebElement gpaSubtitle = driver().findElement(By.xpath(String.format("//div[@class='row mb-2 consolidated-checkbox' and contains(.,'%s')]//p", HAS_A_GPA_OVER_3)));
            softAssert.assertEquals(getTextFromElement(gpaSubtitle), MUST_BE_FULL_TIME, "GPA checkbox subtitle is matching");
        }

        if (checkboxes.contains(SAFETY_COURSE_CHECKBOX_TEXT)) {
            if (!getStateCodeFromAppStore().contains(OK)) {
                WebElement safetyCourseSubtitle = driver().findElement(By.xpath(String.format("//div[@class='row mb-2 consolidated-checkbox' and contains(.,'%s')]//p", SAFETY_COURSE_CHECKBOX_TEXT)));
                softAssert.assertEquals(getTextFromElement(safetyCourseSubtitle), SAFETY_COURSE_CHECKBOX_SUB_TEXT, "Safety course checkbox subtitle is matching");
            }
        }

        if (checkboxes.contains(DISTANT_STUDENT_CHECKBOX_TEXT)) {
            WebElement distantStudentSubtitle = driver().findElement(By.xpath(String.format("//div[@class='row mb-2 consolidated-checkbox' and contains(.,'%s')]//p", DISTANT_STUDENT_CHECKBOX_TEXT)));
            softAssert.assertEquals(getTextFromElement(distantStudentSubtitle), MUST_BE_FULL_TIME, "Distant student checkbox subtitle is matching");
        }
    }

    private boolean isNonDriverImplementedState(String stateCode) {
        List<String> nonDriverImplementedStates = Arrays.asList(TX, MI, IL, AZ, PA, WA, OR, OH, MO, OK);
        return nonDriverImplementedStates.contains(stateCode);
    }

    private void checkVINShouldBe17CharError(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(vinInputFieldErrorMessage), "VIN must be exactly 17 characters.", "Expected VIN error message not displayed'");
    }

    public boolean isAddVehicleSideSheetOpen() {
        return isElementVisible(addVehicleSideSheetHeader, 2);
    }

    private Vehicle updateYMMTypeOwnerShipForVehicle(Vehicle vehicle) {
        vehicle.setVehicleYear("2024");
        vehicle.setVehicleMake("HONDA");
        vehicle.setVehicleModel("ACCORD 4D EX");
        vehicle.setVehicleType("SEDAN");
        vehicle.setOwnership("Owned");
        vehicle.setRidesharing(false);
        vehicle.setParkInResidentAddress(true);
        return vehicle;
    }

    public void updateVehicleVinWhichWasAddedByYMMAndValidateVehicleCard(Vehicle vehicle, FarmersSoftAssert fsa) throws Exception {
        clickEditVehicleButton(vehicle);
        fillOutVinInputField(vehicle.getVehicleVIN());
        fillOutVehiclePurchaseDate(vehicle);
        clickVehicleSaveChangesButton();
        waitForSpinnerToBeGone();
        waitElementBeInvisible(closeIcon);
        sleep(1);
        AppStore.Auto.AppStoreVehicle appStoreVehicle = getSessionStorageAppStore().getAuto().getVehicles().stream().
                filter(i -> i.getVin().equals(vehicle.getVehicleVIN())).collect(Collectors.toList()).get(0);
        updateVehicleObjectWithNewlyAddedVehicleByVIN(appStoreVehicle, vehicle);
        validateAddedVehicleDetailsOnCard(vehicle, fsa);
    }

    public void updateVehicleYMMWhichWasAddedByVINAndValidateVehicleCard(Vehicle vehicle, FarmersSoftAssert fsa) throws Exception {
        clickEditVehicleButton(vehicle);
        if (isElementVisible(vinRemoveButtonDeleteIcon, 2)) {
            clickRemoveVinButton();
        }
        fillOutYMMDetails(vehicle);
        fillOutVehiclePurchaseDate(vehicle);
        clickVehicleSaveChangesButton();
        waitForSpinnerToBeGone();
        validateAddedVehicleDetailsOnCard(vehicle, fsa);
    }

    public void updateNewVehicleVinWhichWasAddedByVINAndValidateVehicleCard(Vehicle vehicle, FarmersSoftAssert fsa) throws Exception {
        clickEditVehicleButton(vehicle);
        clickRemoveVinButton();
        String randomVin = getRandomVinNumber(3);
        randomVin = fillOutVinInputField(randomVin);
        if(isElementVisible(typeDropDown, 1)) {
            fillOutVehicleType("Sedan");
        }
        fillOutVehiclePurchaseDate(vehicle);
        clickVehicleSaveChangesButton();
        waitForSpinnerToBeGone();

        // update the vehicle object with newly added vehicle details from AppStore by VIN
        String finalRandomVin = randomVin;
        AppStore.Auto.AppStoreVehicle appStoreVehicle = getSessionStorageAppStore().getAuto().getVehicles().stream().
                filter(i -> i.getVin().equals(finalRandomVin)).collect(Collectors.toList()).get(0);
        updateVehicleObjectWithNewlyAddedVehicleByVIN(appStoreVehicle, vehicle);
        validateAddedVehicleDetailsOnCard(vehicle, fsa);
    }

    public void editVehicleByAddingNewVinButDoNotSaveVehicleAndValidateVehicleCard(Vehicle vehicle, FarmersSoftAssert fsa) throws Exception {
        clickEditVehicleButton(vehicle);
        clickRemoveVinButton();
        sendKeysToVinInputField("2D4FV47V96H174256");
        clickCloseIcon();
        waitForSpinnerToBeGone();
        validateAddedVehicleDetailsOnCard(vehicle, fsa);
    }

    protected void clickRemoveVinButton() {
        waitAndClickElement(vinRemoveButtonDeleteIcon);
    }

    public void clickFirstVehicleEditLink() {
        clickElement(editVehicleLinks.get(0));
    }

    String getEditVehicleButtonXpath(String vehicleDescription) {
        String xpathForEditVehicleIcon = String.format("//div[contains(@class,'card auto-vehicles-card-item vehicle') and contains(.,'%s')]", vehicleDescription) + "//a";
        return xpathForEditVehicleIcon;
    }

    private WebElement getCheckboxForVehicle(String vehicleDescription) throws Exception {
        return driver().findElement(By.xpath(getVehicleCardXpathWithVehicleDescription(vehicleDescription) + "//input"));
    }

    public void addRandomNewVehicle() throws Exception {
        waitAndClickElement(addAnotherVehicleButton);
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleVIN(getRandomVinNumber(2));
        vehicle.setUseVIN(true);
        vehicle.setOwnership("Owned");
        vehicle.setVehicleUsage(PERSONAL);
        vehicle.setVehicleType("Sedan");
        addVehicleDetails(vehicle);
        waitAndClickElement(addVehicleButton);
        waitForSpinnerToBeGone();
        if (isElementVisible(doneAddingVehiclesSideSheet, 1)) {
            clickElement(doneAddingVehiclesSideSheet);
        }
    }

    public void addNewVehicle(Vehicle vehicle) throws Exception {
        waitAndClickElement(addAnotherVehicleButton);
        addVehicleDetails(vehicle);
        waitAndClickElement(addVehicleButton);
        waitForSpinnerToBeGone();
        if (isElementVisible(doneAddingVehiclesSideSheet, 1)) {
            clickElement(doneAddingVehiclesSideSheet);
        }
    }

    public List<WebElement> getEditButtonsForCheckedVehicles() throws Exception {
        return editVehicleLinks;
    }

    public void updateVehiclesAndDrivers(AutoApplicant applicant) throws Exception {

        // 1-  edit an existing vehicle
        WebElement firstVehicleEditButton = selectedVehiclesEditReviewButton.get(0);
        waitAndClickElement(firstVehicleEditButton);

        // vehicle ownership update
        Vehicle firstVehicle = applicant.getVehicles().get(0);
        firstVehicle.setOwnership("Owned");
        waitElementBeVisible(addOrEditVehicleSideSheetHeader);
        selectVehicleOwnership(firstVehicle);
        waitAndClickElement(addVehicleButton);

        // 2 - add a new vehicle
        addRandomNewVehicle();

        // update an existing driver
        SqlAdditionalDriver sqlAdditionalDriver = applicant.getAdditionalDrivers().get(applicant.getAdditionalDrivers().size() - 1);
        WebElement driverEditCheckboxInputButtonByFullName = driver().findElement(By.xpath(String.format("//app-driver-card[contains(.,'%s')]//a", sqlAdditionalDriver.getFirstName() + SPACE + sqlAdditionalDriver.getLastName())));
        waitAndClickElement(driverEditCheckboxInputButtonByFullName);
        selectGenderButton("Male");
        waitAndClickElement(addDriverSaveChangesButton);
        waitForSpinnerToBeGone();


        // add a new random driver
        addAdditionalDriver("Adddrfn", "Adddrln", false);

    }

    public String getVehicleCardXpathWithVehicleDescription(String vehicleDesc) {
        return String.format("//app-vehicle-card[contains(.,'%s')]", vehicleDesc);
    }

    public boolean isVehicleErrorMessageDisplayed(String vehicleDesc) throws Exception {
        return isElementPresent(By.xpath(getVehicleCardXpathWithVehicleDescription(vehicleDesc) + VEHICLE_VIN_ERROR_MESSAGE_XPATH), 1);
    }

    public void validateVinErrorMessage(String vehicleDesc, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(getVehicleCardXpathWithVehicleDescription(vehicleDesc) + VEHICLE_VIN_ERROR_MESSAGE_XPATH))), "We are unable to locate details for this vehicle. Please provide the VIN and try again.", "Expected VIN error message is displayed for vehicle: " + vehicleDesc);
    }

    public void uncheckVehicleCheckbox(Vehicle vehicle) throws Exception {
        String vehicleDescriptionFromVehicle = getVehicleDescriptionFromVehicle(vehicle);
        Log.info("User is unchecking the Vehicle checkbox: " + vehicleDescriptionFromVehicle);
        WebElement checkboxForVehicle = getCheckboxForVehicle(vehicleDescriptionFromVehicle);
        scrollElementToMiddle(checkboxForVehicle);
        clickElement(driver().findElement(By.xpath(getVehicleCardXpathWithVehicleDescription(vehicleDescriptionFromVehicle) + "//input")));
    }

    public void validateVinErrorAndAddValidVin(FarmersSoftAssert fsa, Vehicle vehicle) throws Exception {
        String vehicleDesc = getVehicleDescriptionFromVehicle(vehicle);
        fsa.assertTrue(isOnWhoShouldWeInsurePage(), "User is on who should we insure page with Bw rate failure with VIN");
        validateVinErrorMessage(vehicleDesc, fsa);
        fsa.assertTrue(isVehicleErrorMessageDisplayed(vehicleDesc), "We are unable to locate details for this vehicle. Please provide the VIN and try again. error message is displayed for first vehicle");

        // validate error message for CTA button
        clickContinueButton();
        // validate CTA error message
        fsa.assertEquals(getTextFromElement(pageCTAErrorMessage), "One or more fields required.", "Expected CTA error message is displayed on who should we insure page with Bw rate failure with VIN");


        // locate and click edit button for the vehicle
        WebElement vehicleEditButton = driver().findElement(By.xpath(getEditVehicleButtonXpath(vehicleDesc)));
        scrollToElement(vehicleEditButton);
        waitAndClickElement(vehicleEditButton);

        // update vehicle data
        String randomVin = getRandomVinNumber(3);
        vehicle.setUseVIN(true);
        vehicle.setVehicleVIN(randomVin);

        fillOutVinInputField(randomVin);

        clickVehicleSaveChangesButton();

    }

    public void validateDiscountSectionAndSideSheet(AutoApplicant applicant, FarmersSoftAssert softAssert) throws Exception {
        List<String> expectedDiscounts = new ArrayList<>();
        if (!isHomeownerDiscountDisabledState(applicant)) {
            expectedDiscounts.add("Homeowner");
        }

        if (applicant.getVehicles().get(0).isAntiTheftDevice() && isAntiTheftRecoverySystemEnabledState(applicant.getStateCode())) {
            expectedDiscounts.add("Anti-theft device");
        }

        String stateCode = applicant.getStateCode();
        if (isFlexState(stateCode)) {
            expectedDiscounts.add("Welcome");
        }

        if (applicant.getIncidents().isEmpty()) {
            expectedDiscounts.add("Accident free");
        }

        addVehiclesWhenNoneFound(applicant);
        addDriversWhenNoneFound(applicant);
        if (!isOnBristolWest() && !applicant.getOccupation().equals(OTHER) && !Arrays.asList(TN, MN).contains(applicant.getStateCode())) {
            if (!getTextFromElement(driver().findElement(By.xpath(String.format("//div[contains(@class,'justify-content-between') and contains(.,'Occupation')]//span[contains(@class,'driver-info-value')]")))).equals("Unknown")) {
                expectedDiscounts.add("Profession group");
            }
        }
        int expectedDiscountCount = expectedDiscounts.size(); // Based on applicantId=1 data

        // get the discount number on the bottom of the page
        int discountCountAtBottom = getTheDiscountCountFromBottomOfThePage();

        // validate the discount count
        softAssert.assertEquals(discountCountAtBottom, expectedDiscountCount, "Discount count at the bottom of the page and in the side sheet are matching");

        Log.info("Expected discounts to be validated: " + String.join(", ", expectedDiscounts));
        validateDiscountReviewSection(softAssert, expectedDiscounts);
    }

    public void validateMatureDriverDiscountAndSnackBarMessage(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String stateCode = applicant.getStateCode();
        boolean isDefensiveDiscountEnabled = isDefensiveDriverDiscountEnabledFarmersStreamlineState(stateCode);
        String pniFullNameFromAutoApplicant = getPniFullNameFromAutoApplicant(applicant);
        clickEditButtonWithDriverFullName(pniFullNameFromAutoApplicant);
        addSafetyCourse(applicant.getAge(), true, pniFullNameFromAutoApplicant);
        validateMatureOrDefensiveDriverDiscountAddedSnackBar(fsa, isDefensiveDiscountEnabled);
        clickSaveChangesDriverSheet();
        validateMatureOrDefensiveDriverDiscountPresent(fsa, isDefensiveDiscountEnabled);

        clickEditButtonWithDriverFullName(pniFullNameFromAutoApplicant);
        String fullName = applicant.getFirstName() + SPACE + applicant.getLastName();
        // uncheck the safety course checkbox to remove the discount and validate the snack bar message and discount removal
        WebElement safetyCourseCheckbox = getDriverSafetyCourseCheckBoxWebElement(applicant.getAge());
        if (getAttributeData(safetyCourseCheckbox, CLASS).contains(MDC_CHECKBOX_SELECTED)) {
            Log.info("Driver safety course checkbox was already selected for " + fullName);
            clickElement(safetyCourseCheckbox);
            wait.until(ExpectedConditions.attributeToBe(safetyCourseCheckbox, CLASS, "mdc-checkbox__native-control"));
        }
        validateMatureOrDefensiveDriverDiscountRemovedSnackBar(fsa, isDefensiveDiscountEnabled);
        clickSaveChangesDriverSheet();
        validateMatureOrDefensiveDriverDiscountNotPresent(fsa, isDefensiveDiscountEnabled);
    }

    public void validateDriverSafetyCheckBoxIsNotPresent(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(driver().findElements(By.xpath(getDriverSafetyCheckBoxXpath(56))).isEmpty(), "Driver safety course checkbox is not present in the driver side sheet.");
    }

    public void clickRideShareCheckbox() {
        clickElement(rideshareCheckboxInput);
    }

    private WebElement getVehicleEditButtonByVehicleDescription(Vehicle vehicle) throws Exception {
        String vehicleDescription = getVehicleDescriptionFromVehicle(vehicle);
        String xpathForEditVehicleIcon = getEditVehicleButtonXpath(vehicleDescription);
        return driver().findElement(By.xpath(xpathForEditVehicleIcon));
    }

    public void validateGaragingAddressFieldDisplayed(Vehicle vehicle, String stateCode, FarmersSoftAssert fsa) throws Exception {
        clickEditVehicleButton(vehicle);
        if (!vehicle.isParkInResidentAddress()) {
            clickElement(parkedAtOtherRadioButton);
            fsa.assertTrue(otherGarageAddressInputField.isDisplayed(), "Garaging address section is displayed when 'Parked at other' is selected");
            fsa.assertTrue(otherGarageApartmentInputField.isDisplayed(), "Garaging address apartment input field is displayed when 'Parked at other' is selected");
            fsa.assertTrue(otherGarageCityInputField.isDisplayed(), "Garaging address city input field is displayed when 'Parked at other' is selected");
            fsa.assertTrue(otherGarageStateInputField.isDisplayed(), "Garaging address state code input field is displayed when 'Parked at other' is selected");
            fsa.assertTrue(otherGarageZipInputField.isDisplayed(), "Garaging address zip code input field is displayed when 'Parked at other' is selected");
            fsa.assertTrue(otherGarageStateInputField.getAttribute(VALUE).equals(stateCode), "Garaging address state code input field prefilled");
        }
    }

    public void validateGaragingAddressFieldValueAfterRetrieval(FarmersSoftAssert fsa) throws Exception {
        AppStore.Auto.AppStoreVehicle.GrgingAddr grgingAddr = getSessionStorageAppStore().getAuto().getVehicles().get(0).getGrgingAddr();
        fsa.assertTrue(grgingAddr.getStreet().equals(otherGarageAddressInputField.getAttribute(VALUE)), "Garaging address field value is same after retrieval");
        fsa.assertTrue(grgingAddr.getCity().equals(otherGarageCityInputField.getAttribute(VALUE)), "Garaging address city field value is same after retrieval");
        fsa.assertTrue(grgingAddr.getState().equals(otherGarageStateInputField.getAttribute(VALUE)), "Garaging address state value is same after retrieval");
        fsa.assertTrue(grgingAddr.getZip().equals(otherGarageZipInputField.getAttribute(VALUE)), "Garaging address zipcode value is same after retrieval");
        fsa.assertTrue(grgingAddr.getApartment().equals(otherGarageApartmentInputField.getAttribute(VALUE)), "Garaging address apartment value is same after retrieval");
    }

    public void clickEditVehicleButton(Vehicle vehicle) throws Exception {
        WebElement vehicleEditButton = getVehicleEditButtonByVehicleDescription(vehicle);
        clickElement(vehicleEditButton);
    }

    public void clickParkedAtPrimaryAddressRadioButton() {
        clickElement(parkedAtPrimaryRadioButton);
    }

    public void removeNonPNIApplicant(ADPFApplicant adpfApplicant) {
        String applicantName = adpfApplicant.getFirstName().toLowerCase() + SPACE + adpfApplicant.getLastName().toLowerCase();
        if (!uncheckedDriversNames.isEmpty()) {
            for (WebElement checkedDriver : selectedDrivers) {
                if (!getTextFromElement(checkedDriver).toLowerCase().contains(applicantName)) {
                    clickElement(checkedDriver);
                }
            }
        }

    }

    public LinkedHashMap<String, String> getListOfCheckedDriverNames() throws Exception {
        LinkedHashMap<String, String> namesAndAges = new LinkedHashMap<>();
        for (WebElement checkedDriver : selectedDrivers) {
            String[] parts = getTextFromElement(checkedDriver).split(",");
            if (parts.length >= 2) {
                namesAndAges.put(parts[0].trim(), parts[1].trim());
            }
        }
        return namesAndAges;
    }

    public LinkedHashMap<String, String> getListOfUncheckedDriverNames() throws Exception {
        LinkedHashMap<String, String> namesAndAges = new LinkedHashMap<>();
        for (WebElement uncheckedDriver : uncheckedDriversNames) {
            String[] parts = getTextFromElement(uncheckedDriver).split(",");
            if (parts.length >= 2) {
                namesAndAges.put(parts[0].trim(), parts[1].trim().replaceAll("\\D", ""));
            }
        }
        return namesAndAges;
    }

    public boolean doesVINFieldHaveFocus() {
        waitElementBeVisible(addOrEditVehicleSideSheetHeader);
        return doesElementHaveFocus(waitElementBeVisible(vinInputField));
    }

    public void addAnotherVehicleUsingVin(String vin) throws Exception {
        clickElement(addAnotherVehicleButton);
        if (isElementDisplayed(addOrEditVehicleSideSheetHeader, 5)) {
            fillOutVinInputField(vin);
            if (isElementDisplayed(By.xpath("//mat-select[@formcontrolname='type']"))) {
                fillOutVehicleType("Sedan");
            }
            clickAddVehicleButtonInAddVehicleSideSheet();
        }
    }

    public VehiclesDriversInfoPage clickOnAddVehicleButton() {
        clickElement(addVehicleButton);
        return this;
    }

    public void validateIncompleteVehicleIsNotChecked() throws Exception {
        int numberOfUncheckedVehicles = getEleCount(uncheckedVehiclesCheckboxes, 2);
        testStepAssertTrue(!uncheckedVehiclesCheckboxes.isEmpty(), "Expected  to edit at least one Incomplete vehicle but found none. ");
        scrollAndClickOnElement(uncheckedVehiclesCheckboxes.get(0));
        testStepAssert(isElementVisible(addOrEditVehicleSideSheetHeader, 2), "Edit Vehicle side sheet opened");
        clickOnAddVehicleButton();
        testStepAssertTrue(isElementVisible(fieldErrorMessage, 3), "Save button click triggers error message as there is a missing info");
        clickCloseIcon();
        waitElementBeInvisible(closeIcon);
        testStepAssert(!isElementVisible(addOrEditVehicleSideSheetHeader, 3), "Edit Vehicle side sheet closed");
        testStepAssert(String.valueOf(getEleCount(uncheckedVehiclesCheckboxes, 2)), String.valueOf(numberOfUncheckedVehicles), "Checkbox is not checked for incomplete vehicle");
    }

    public void editCheckedVehicleAndvalidateNoErrorDisplayed() throws Exception {
        testStepAssertTrue(!selectedVehiclesEditReviewButton.isEmpty(), "Expected at least one checked vehicle to edit");
        scrollAndClickOnElement(selectedVehiclesEditReviewButton.get(0));
        testStepAssert(isElementVisible(addOrEditVehicleSideSheetHeader, 2), "Edit Vehicle side sheet opened");
        clickOnAddVehicleButton();
        testStepAssertTrue(!isElementVisible(fieldErrorMessage, 1), "Save button click does not trigger error message");
        testStepAssert(!isElementVisible(addOrEditVehicleSideSheetHeader, 1), "Save button click closed Edit Vehicle side sheet");
    }

    private int getMinAgeForSafetyCourse(String stateCode) {
        if (stateCode.equals(OK)) {
            return 0;
        } else if (stateCode.equals(NM)) {
            return 50;
        } else {
            return 55;
        }
    }

    public boolean doesDriverFirstNameFieldHaveFocus() throws Exception {
        waitElementBeVisible(addEditDriverHeader);
        return doesElementHaveFocus(waitElementBeVisible(firstName));
    }

    public void attemptAddingVehicleWithDuplicateVin(String vin, FarmersSoftAssert fsa) {
        clickElement(addAnotherVehicleButton);
        fsa.assertTrue(isElementDisplayed(addOrEditVehicleSideSheetHeader, 5), "Add vehicle side sheet is supposed to be displayed");
        waitElementBeVisibleClickable(vinInputField);
        sendKeysToElement(vinInputField, vin);
        clickOnAddVehicleButton();
    }

    public boolean isAddAnotherVehicleButtonDisplayed() {
        return isElementVisible(addAnotherVehicleButton, 3);
    }

    public void clickAddAnotherVehicleButton() {
        clickElement(addAnotherVehicleButton);
    }

    public void validateLessThanFiveCompleteVehiclesAreChecked() throws Exception {
        testStepAssert(!selectedVehiclesCheckboxes.isEmpty(), "Checked vehicle size should be more than zero");
        testStepAssert(uncheckedVehiclesCheckboxes.isEmpty(), "NON Checked vehicle size should be zero");
    }

    public boolean isDobEditable() {
        return !isInputFieldReadOnly(dobEntryField);
    }

    public String getDateOfBirthValue() {
        return getInputFieldValue(dobEntryField);
    }


    public void addAnotherDriverUsingRetrievedDriverDetails(Map<String, String> driverDetails) throws Exception {
        fillOutDriverDetailsUsingRetrievedDetails(driverDetails);
        waitAndClickElement(addDriverButton);
    }

    public int getFoundDriversCount() {
        return getEleCount(foundDrivers, 3);
    }

    public List<String> getDriverNamesAndAgesAsList() {
        return foundDrivers.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public void fillOutDriverDetailsUsingRetrievedDetails(Map<String, String> driverDetails) throws Exception {
        scrollAndClickOnElement(addAnotherDriverButton);
        isElementVisible(addEditDriverHeader, 2);
        selectGenderButton(driverDetails.get("gender"));
        fillOutNamesAndDobFields(driverDetails.get("firstName"), driverDetails.get("lastName"), driverDetails.get("dob"));
        selectUSOrCALicensedButton(driverDetails.get("isLicenseIssuedInUS"));
    }

    private void validateDiscountReviewSection(FarmersSoftAssert farmersSoftAssert, List<String> expectedDiscounts) throws Exception {
        // validate review discount section at the bottom
        farmersSoftAssert.assertTrue(isElementVisible(discountAddedText, 1) || isElementVisible(reviewDiscountsButton, 1), "Discount section is displayed");
        farmersSoftAssert.assertTrue(isElementVisible(discountAddedText, 1) || isElementVisible(discountPiggyBankImage, 1), "Discount section piggy bank icon is displayed");
        farmersSoftAssert.assertEquals(getTextFromElement(discountAddedText), String.format("%s discounts applied", expectedDiscounts.size()), "Discount added text is correct");
        farmersSoftAssert.assertEquals(getTextFromElement(reviewDiscountsButton), "Review discounts", "Review Discounts button text is correct");

        // open discount side sheet and get the discount number
        clickReviewDiscountButton();
        //validate side sheet header text
        farmersSoftAssert.assertEquals(getTextFromElement(waitElementBeVisible(discountsSidesheetTitle)), "Discounts applied", "Discount side sheet header text is correct");
        farmersSoftAssert.assertEquals(getTextFromElement(discountsSidesheetSubTitle), "All discounts applied to the quote.", "Discount side sheet sub header text is correct");
        farmersSoftAssert.assertEquals(getTextFromElement(discountsSidesheetAppliedText), String.format("Applied (%s)", expectedDiscounts.size()));
        List<String> displayedDiscounts = discounts.stream().map(this::getTextFromElement).collect(Collectors.toList());
        farmersSoftAssert.assertEquals(getSortedList(displayedDiscounts), getSortedList(expectedDiscounts), "Displayed discounts in the side sheet are correct");
        waitAndClickElement(closeIcon);
    }

    public boolean areAllFirstNameLastNameAndDobFieldsEditable() {
        for (WebElement additionalDriverEditButton : listOfAllEditButtonOfAdditionalDriverDetails) {
            clickElement(additionalDriverEditButton);
            if (!isFirstNameEditable() && !isLastNameEditable() && !isDobEditable()) {
                return false;
            }
        }
        return true;
    }

    public boolean validatePNIDriverCheckboxStatus() throws Exception {
        AppStore.Auto.Driver appStoreDriver = getSessionStorageAppStore().getAuto().getDrivers().get(0);
        String pniFullName = appStoreDriver.getFirstName() + SPACE + appStoreDriver.getLastName();
        WebElement pniEditButton = getDriverEditButtonByFullName(pniFullName);
        waitAndClickElement(pniEditButton);
        // making sure the side panel is open
        waitElementBeVisible(addEditDriverHeader);
        waitAndClickElement(addDriverSaveChangesButton);
        waitElementBeInvisible(addEditDriverHeader); // side sheet closed

        WebElement pniCheckbox = getDriverEditCheckboxInputButtonByFullName(pniFullName);
        boolean isCheckboxSelected = getAttributeData(pniCheckbox, CLASS).contains(MDC_CHECKBOX_SELECTED);

        boolean isMandatoryErrorVisible = isElementVisible(fieldErrorMessage, 2);

        // Selected => all required data present => no mandatory error
        // Unselected => missing required data => mandatory error shown
        return isCheckboxSelected ? !isMandatoryErrorVisible : isMandatoryErrorVisible;
    }

    public Map<String, String> getActualMapOfListedDriverDetails() throws Exception {
        // extracting driver first name and associated age.
        Map<String, String> actualMapOfListedDriverDetails = new HashMap<>();

        actualMapOfListedDriverDetails.putAll(getListOfUncheckedDriverNames());
        actualMapOfListedDriverDetails.putAll(getListOfCheckedDriverNames());
        actualMapOfListedDriverDetails.replaceAll((fullName, age) -> age.equals(EMPTY_STRING) ? "0" : age.substring(age.length() - 2));
        Map<String, String> lowerCaseMap = new HashMap<>();
        actualMapOfListedDriverDetails.forEach((k, v) ->
                lowerCaseMap.put(k.toLowerCase(), v)
        );
        return lowerCaseMap;
    }

    public void check2027YearDetailsUsingYMM(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        List<Vehicle> vehicles = applicant.getVehicles();
        Vehicle firstVehicle = vehicles.get(0);
        boolean isStreamlinedState = isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        WebElement yearDropdownElement = isStreamlinedState ? yearDropDown : (isMA61Environment() ? vehicleYearDropdownAlternate : vehicleYearDropdown);
        waitAndClickElement(yearDropdownElement);
        List<WebElement> yearValues = dropDownOptions.findElements(By.tagName("mat-option"));
        for (WebElement ele : yearValues) {
            fsa.assertTrue(ele.getText().contains("2027"), "Year dropdown list contains 2027 value");
            waitAndClickElement(ele);
            break;
        }
        fillOutVehicleMake(firstVehicle.getVehicleMake());
        fillOutVehicleModel(firstVehicle.getVehicleModel());
        fillOutVehicleType(firstVehicle.getVehicleType());
    }

    public List<String> getVinTipsDisplayed() {
        List<String> vinTips = vinTipsLists.stream().map(this::getTextFromElement).collect(Collectors.toList());
        return new ArrayList<>(vinTips);
    }

    public void setCheckboxTo(WebElement checkbox, boolean shouldBeChecked) {
        boolean isChecked = getAttributeData(checkbox, CLASS).contains(MDC_CHECKBOX_SELECTED);
        if (isChecked != shouldBeChecked) {
            clickElement(checkbox);
        }
    }

    public void setAllVehicleCheckboxesTo(boolean isChecked) throws Exception {
        for (WebElement checkbox : selectedVehiclesCheckboxes) {
            setCheckboxTo(checkbox, isChecked);
        }
        for (WebElement checkbox : uncheckedVehiclesCheckboxes) {
            setCheckboxTo(checkbox, isChecked);
        }
    }
    public void setAllDriversCheckboxesTo(boolean isChecked) throws Exception {
        for (WebElement checkbox : selectedDrivers) {
            setCheckboxTo(checkbox, isChecked);
        }
        for (WebElement checkbox : uncheckedDriversCheckboxes) {
            setCheckboxTo(checkbox, isChecked);
        }
    }
}

