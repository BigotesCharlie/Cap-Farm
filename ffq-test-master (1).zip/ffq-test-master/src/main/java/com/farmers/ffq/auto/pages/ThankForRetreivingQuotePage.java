package com.farmers.ffq.auto.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ThankForRetreivingQuotePage extends AutoBasePage {

	@FindBy(className = "auto-module__retrieve-confirmation-header-text")
	private WebElement thankYouForRetreivingYourQuoteText;

	@FindBy(xpath = "//mat-dialog-actions/button")
	private WebElement continueButton;
		
	public ThankForRetreivingQuotePage() throws Exception {
		super();
		WebDriver webDriver = driver();
		PageFactory.initElements(webDriver, this);
		waitForSpinnerToBeGone();
		continueToBristolWest(true);
		waitElementBeVisible(thankYouForRetreivingYourQuoteText);
	}
	
	public void clickContinueButton() {
		waitElementBeVisibleClickable(continueButton);
		continueButton.click();
		waitForSpinnerToBeGone();
	}

}
