package com.farmers.ffq.common.pages;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.framework.report.Log;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class BristolWestLandingPage extends AutoBasePage {

    @FindBy(id = "bw-main-content")
    private WebElement pageHeader;

    @FindBy(xpath = "//div[@class='hero-split__input-field']//input")
    private WebElement zipCodeInput;
    @FindBy(xpath = "//div[@class='hero-split__mobile-input-inner']//input")
    private WebElement zipCodeInputMobileView;
    @FindBy(xpath = "//button[@class='hero-split__button start-quote-btn']")
    private WebElement startQuoteButton;

    @FindBy(xpath = "//button[@class='hero-split__mobile-button start-quote-btn']")
    private WebElement startQuoteButtonMobileView;
    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public BristolWestLandingPage() throws Exception {
    }


    private boolean isOnBristolWestLandingPage() {
        return isElementVisible(pageHeader, 5);
    }

    public void launchBristolWestLandingPage(String url, String zipCode) throws Exception {
        if (isUseMobileViewEnabled()) {
            setBrowserDimensionToMobileBreakPoint();
        }

        driver().get(url);
        isOnBristolWestLandingPage();
        Log.info("User is on the Landing Page for BW");
        fillOutZipCodeInputField(zipCode);
        clickStartQuoteButton();
    }

    private void fillOutZipCodeInputField(String zipCode) throws Exception {
        if(isUseMobileViewEnabled()) {
            sendKeysToElement(zipCodeInputMobileView, zipCode);
        }else{
            sendKeysToElement(zipCodeInput, zipCode);
        }
    }

    private void clickStartQuoteButton() {
        if(isUseMobileViewEnabled()) {
            clickElement(startQuoteButtonMobileView);
        }else{
            clickElement(startQuoteButton);
        }
    }
}
