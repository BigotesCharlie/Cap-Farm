package com.farmers.ffq.ace.hrc.common;

import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCPropertyTypeBasePage extends AceHRCBasePage {
    protected static final String PAGE_TITLE = "What type of property is it?";

    @FindBy(xpath = "//app-property-type//h1")
    protected WebElement pageTitle;

    protected static final String PROPERTY_TYPE_CARD_XPATH = "//app-property-type//app-image-card";
    @FindBy(xpath = PROPERTY_TYPE_CARD_XPATH)
    protected WebElement propertyTypeCard;

    @FindBy(xpath = "//app-property-type//app-toggle-banner//div[contains(@class,'toggle-icon')]")
    protected WebElement togglePartnerIcon;

    @FindBy(xpath = "//app-property-type//app-toggle-banner//div[contains(@class,'toggle-text')]")
    protected WebElement togglePartnerText;

    private static final List<String> PROPERTY_TYPES = List.of(HOME, TOWNHOME, DUPLEX, CONDO, OTHER);

    private static final List<String> PROPERTY_TYPE_DESCRIPTIONS = List.of("Single-family home that you own.",
            "Multi-story home attached to similar homes by shared walls.", "I own the entire structure, but only reside in one unit.",
            "Multi-unit building in which you own an individual unit.", "Any other home type that does not fit in the above categories.");

    protected static final String PRIMARY_RESIDENCE_XPATH = "//app-property-type//div[@id='formField_isPrimaryResidence']";
    protected static final String PRIMARY_RESIDENCE_MEDIA_ALPHA_XPATH = "//app-personal-info//div[@id='formField_isPrimaryResidence']";
    protected static final String PRIMARY_RESIDENCE_LABEL_TEXT = "Is this your primary residence?";
    @FindBy(xpath = PRIMARY_RESIDENCE_XPATH)
    protected WebElement primaryResidenceText;

    protected static final String NOT_PRIMARY_RESIDENCE_REASON_XPATH = "//div[@id='formField_notPrimaryResidenceReason']";

    /**
     * Default Constructor
     */
    public AceHRCPropertyTypeBasePage() throws Exception {
        super();
    }

    public boolean isOnPropertyTypePage() {
        return isOnPageCheck(Property.PAGELOADTIMEOUT);
    }

    public boolean quickIsOnPropertyTypePageCheck() {
        return isOnPageCheck(5);
    }

    private boolean isOnPageCheck(int secondsToWait) {
        return isElementPresent(By.xpath(PROPERTY_TYPE_CARD_XPATH), secondsToWait);
    }

    public boolean isPageTitleDisplayed() {
        return getTextFromElement(pageTitle).equals(PAGE_TITLE);
    }

    public boolean isPageTitleInViewport() throws Exception {
        return isElementInViewport(pageTitle);
    }

    public List<String> getPropertyTypeCards() throws Exception {
        return driver().findElements(By.xpath(PROPERTY_TYPE_CARD_XPATH + "//div[@id='cardHeading']")).stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public List<String> getPropertyTypeCardDescriptions() throws Exception {
        return driver().findElements(By.xpath(PROPERTY_TYPE_CARD_XPATH + "//div[@id='cardDescription']")).stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public List<String> getPropertyTypeCardImageAltDescriptions() throws Exception {
        return driver().findElements(By.xpath(PROPERTY_TYPE_CARD_XPATH + "//div[contains(@class,'image-container')]/img"))
                .stream().map(w -> getAttributeData(w, "alt")).collect(Collectors.toList());
    }

    public void validatePageCards(FarmersSoftAssert sa, String origin) throws Exception {
        List<String> propertyTypeCards = new ArrayList<>(PROPERTY_TYPES);
        List<String> propertyTypeDescriptions = new ArrayList<>(PROPERTY_TYPE_DESCRIPTIONS);
        if (MEDIA_ALPHA.equalsIgnoreCase(origin)) {
            String quoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
            Reporter.pass(NEW_QUOTE_NUMBER + quoteNumber, true);
            int index = propertyTypeCards.indexOf(CONDO);
            if (index != NOT_FOUND_IN_LIST) {
                propertyTypeCards.set(index, MOBILE_MANUFACTURED_HOME);
                propertyTypeDescriptions.set(index, "A prefabricated structure, built before being transported to site.");
            }
        }
        sa.assertEquals(getPropertyTypeCards(), propertyTypeCards, "Property Type page - Expected Property Type Cards are displayed.");
        sa.assertEquals(getPropertyTypeCardImageAltDescriptions(), propertyTypeCards, "Property Type page - Property Type Card Image Alt attributes match.");
        sa.assertEquals(getPropertyTypeCardDescriptions(), propertyTypeDescriptions, "Property Type page - Expected Property Type Card Descriptions are displayed.");
    }

    public void validatePageCardsNewFlow(FarmersSoftAssert fsa, boolean cameFromMediaAlpha) throws Exception {
        List<String> propertyTypeCards = new ArrayList<>(PROPERTY_TYPES);
        List<String> propertyTypeDescriptions = new ArrayList<>(PROPERTY_TYPE_DESCRIPTIONS);
        if (cameFromMediaAlpha) {
            int index = propertyTypeCards.indexOf(CONDO);
            if (index != NOT_FOUND_IN_LIST) {
                propertyTypeCards.set(index, MOBILE_MANUFACTURED_HOME);
                propertyTypeDescriptions.set(index, "A prefabricated structure, built before being transported to site.");
            }
        } else {
        	propertyTypeCards.removeAll(List.of(TOWNHOME, DUPLEX));
        	propertyTypeDescriptions.remove(2);
        	propertyTypeDescriptions.remove(1);
        }
        fsa.assertEquals(getPropertyTypeCards(), propertyTypeCards, "Property Type page - Expected Property Type Cards are displayed.");
        fsa.assertEquals(getPropertyTypeCardImageAltDescriptions(), propertyTypeCards, "Property Type page - Property Type Card Image Alt attributes match.");
        fsa.assertEquals(getPropertyTypeCardDescriptions(), propertyTypeDescriptions, "Property Type page - Expected Property Type Card Descriptions are displayed.");
        for (String propertyType : propertyTypeCards) {
            selectPropertyType(propertyType);
            fsa.assertTrue(isImageCardSelected(propertyType), "Property type page - selected property type: " + propertyType);
        }
    }

    public void selectPropertyType(String propertyType) throws Exception {
        testStep("Selecting property type: " + propertyType);
        String propertyTypeCardXpath;
        propertyTypeCardXpath = PROPERTY_TYPE_CARD_XPATH + String.format("[contains(.,'%s')]//div[@data-test-id='IMAGE_CARD']", propertyType);
        WebElement we = driver().findElement(By.xpath(propertyTypeCardXpath));
        waitAndClickElement(we);
        waitForSpinnerToBeGone();
    }

    public boolean isImageCardSelected(String propertyType) throws Exception {
        String propertyTypeCardXpath = PROPERTY_TYPE_CARD_XPATH + String.format("[contains(.,'%s')]//div[@data-test-id='IMAGE_CARD']", propertyType);
        WebElement we = driver().findElement(By.xpath(propertyTypeCardXpath));
        return getAttributeData(we, CLASS).contains("selected");
    }

    public boolean isToggleBannerDisplayed() {
        return isElementDisplayed(togglePartnerIcon,1) && isElementDisplayed(togglePartnerText,1);
    }

    public void fillOutPropertyType(ApplicantAceHome applicant, String propertyType) throws Exception {
        String property = propertyType.equals(CONDO)? propertyType : HOME;
        selectPropertyType(property);
        if (isNewFlowEnabledState(applicant.getStateCode())) {
            selectPrimaryResidence(applicant.isPrimaryResidence());
            if (!applicant.isPrimaryResidence()) {
               selectNotPrimaryResidenceReason(applicant.getReasonWhyNotPrimaryResidence());
            }
            clickContinueButton();
        }
    }

    public boolean isPrimaryResidenceSelected() throws Exception {
    	String xpathToUse = isElementPresent(By.xpath(PRIMARY_RESIDENCE_XPATH), 2)? PRIMARY_RESIDENCE_XPATH : PRIMARY_RESIDENCE_MEDIA_ALPHA_XPATH;
        WebElement we = driver().findElement(By.xpath(xpathToUse + "//mat-button-toggle[.='Yes']"));
        return getAttributeData(we,CLASS).contains(CHECKED);
    }

    public void selectPrimaryResidence(boolean primaryResidence) throws Exception {
        if (primaryResidence == isPrimaryResidenceSelected()) {
            return; // No-op if desired value is already selected
        }
        String option = primaryResidence ? YES : NO;
    	String xpathToUse = isElementPresent(By.xpath(PRIMARY_RESIDENCE_XPATH), 2)? PRIMARY_RESIDENCE_XPATH : PRIMARY_RESIDENCE_MEDIA_ALPHA_XPATH;
        WebElement we = driver().findElement(By.xpath(xpathToUse + String.format("//button[normalize-space()='%s']", option)));
        waitAndClickElement(we);
        waitForSpinnerToBeGone();
    }

    public List<String> getNotPrimaryResidenceReasons() throws Exception {
        return driver().findElements(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH + "//mat-radio-button"))
                .stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public String getSelectedNotPrimaryResidenceReason() throws Exception {
        List<WebElement> weList = driver().findElements(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH + "//mat-radio-button"));
        String nonPrimaryReason = "";
        for (WebElement we : weList) {
            if (getAttributeData(we, CLASS).contains(RADIO_BUTTON_CHECKED)) {
                nonPrimaryReason = getValueFromWebElement(we.findElement(By.xpath(".//input")));
                break;
            }
        }
        Log.info("Property type page - Not Primary Residence Reason: " + nonPrimaryReason);
        return nonPrimaryReason;
    }

    public void selectNotPrimaryResidenceReason(String reason) throws Exception {
    	WebElement we = driver().findElement(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH + String.format("//mat-radio-button//input[@value='%s']", reason.toUpperCase())));
    	scrollAndClickOnElement(we);
    }

    public List<String> getNotPrimaryResidenceReasonsSubtext() throws Exception {
        return driver().findElements(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH + "//span[contains(@class,'primary-residence-usage__subtext')]"))
                .stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public void validatePageFormFieldsNewFlow(FarmersSoftAssert fsa, String stateCode) throws Exception {
    	boolean cameFromMediaAlpha = isElementPresent(By.xpath(PRIMARY_RESIDENCE_MEDIA_ALPHA_XPATH), 2);
    	boolean useLongList = stateCode.equals(AZ);
    	List<String> NOT_PRIMARY_RESIDENCE_REASONS = cameFromMediaAlpha?
    		useLongList? List.of("I rent it out", "I use it as a secondary home throughout the year", "I only use it seasonally", "Vacant", "Other") : List.of("I rent it out", "I use it part time", "Other") :
    		List.of("Long-term rental property", "Short-term rental property", "Seasonal or secondary home", "Vacant property");
    	List<String> NOT_PRIMARY_RESIDENCE_REASONS_SUBTEXT = cameFromMediaAlpha?
   			useLongList? List.of("This home is or will be occupied by a renter", "This home is for my seasonal or secondary usage", "This home is for my seasonal or secondary usage", "This home is vacant, or will be under renovation within 30 days.") :
   			List.of("My home is or will be occupied by a renter (short or long term)", "This home is for seasonal or secondary use.", "Such as my home is vacant, or will be under renovation within 30 days.") :
                List.of("This home is or will be occupied by a renter", "This home is used for home-sharing (AirBnB, Vrbo, etc.); I might also use it part-time", "This home is for my seasonal or secondary usage", "Unoccupied");
    	String primaryResidenceExpectedText = isSafariBrowser()? PRIMARY_RESIDENCE_LABEL_TEXT + YES + NO: PRIMARY_RESIDENCE_LABEL_TEXT + SPACE + YES + SPACE + NO;
    	String xpathToUse = cameFromMediaAlpha? PRIMARY_RESIDENCE_MEDIA_ALPHA_XPATH : PRIMARY_RESIDENCE_XPATH;
    	fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(xpathToUse))), primaryResidenceExpectedText, "Property type page - Primary Residence label text.");
    	fsa.assertTrue(isPrimaryResidenceSelected(), "Property type page - Primary Residence button is selected.");
    	selectPrimaryResidence(false);
    	fsa.assertEquals(getNotPrimaryResidenceReasons(), NOT_PRIMARY_RESIDENCE_REASONS, "Property type page - List of radio buttons for Non-primary reasons.");
    	fsa.assertEquals(getNotPrimaryResidenceReasonsSubtext(), NOT_PRIMARY_RESIDENCE_REASONS_SUBTEXT, "Property type page - Not Primary Residence Reasons subtext.");
    	fsa.assertEquals(getSelectedNotPrimaryResidenceReason(), RENT, "Property type page - Not Primary Residence Reason selected.");
    	selectPrimaryResidence(true);
    	wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH)));
    	fsa.assertTrue(getNotPrimaryResidenceReasons().isEmpty(), "Property type page - When Primary Residence, Non Primary Reasons should not display.");
    }
}

