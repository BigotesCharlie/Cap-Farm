package com.farmers.ffq.ace.bundle;

import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import static com.farmers.ffq.utils.GlobalVariables.MASTER_CARD;
import static com.farmers.ffq.utils.GlobalVariables.SRC;

import java.util.List;

public class AceBundleAutoPaymentPage extends BasePage {

    //Common elements

    @FindBy (xpath = "//h1[contains(@class, 'payment-overview-header-text')]")
    private WebElement autoPaymentPageTitle;

    //Farmers Elements
    @FindBy (xpath = "//input[@value='bank']")
    private WebElement bankPreferedPaymentRadioButton;
    @FindBy (xpath = "//input[@value='card']")
    private WebElement cardPreferedPaymentRadioButton;
    @FindBy (xpath = "//button[contains(@class, '-purchase-btn-bundle')]")
    private WebElement completeAutoPurchaseButton;

    //BW Elements
    @FindBy (xpath = "//div[contains(@class, 'bristol-west-bundle-icon')]//img")
    private WebElement autoPaymentPageBWIcon;
    @FindBy (xpath = "//div[contains(@class, 'bristol-west-bundle-body')]")
    private WebElement autoPaymentPageBWLabel;
    @FindBy (xpath = "//div[contains(@class, 'mat-tab-label')][@role='tab']")
    private List<WebElement> listOfTabsForAvailablePaymentPlans;
    @FindBy (xpath = "//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Pay in full')]")
    private WebElement selectAndSignDocumentsPayInFullButton;
    @FindBy (xpath = "//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly autopay bank')]")
    private WebElement selectAndSignDocumentsMonthlyBankButton;
    @FindBy (xpath = "//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly autopay card')]")
    private WebElement selectAndSignDocumentsMonthlyCardButton;
    @FindBy (xpath = "//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly direct')]")
    private WebElement selectAndSignDocumentsMonthlyDirectButton;
    @FindBy (xpath = "//mat-tab-body//button")
    private WebElement activeSelectAndSignDocumentsButton;
    @FindBy (xpath = "//button[contains(@class, 'tui-btn')]")
    private WebElement bwSetupPaymentButton;

    //ERSD Consent Dialog
    @FindBy (xpath = "//div[@data-qa='ersd-modal-content']")
    private WebElement ersdDialog;
    @FindBy (xpath = "//input[@data-qa='ersd-agree-checkbox']")
    private WebElement agreeToUseERSDCheckbox;
    @FindBy (xpath = "//button[@data-qa='ersd-modal-agree']")
    private WebElement ersdDialogContinueButton;

    //Docusign elements
    @FindBy (id = "oneds-title")
    private WebElement docusignDocument;
    @FindBy (xpath = "//button[contains(@data-qa,'initials-tab-required') and @aria-invalid='true']")
    private List<WebElement> listOfInitialHereLocations;
    @FindBy (xpath = "//button[contains(@data-qa,'signature-tab-required') and @aria-invalid='true']")
    private List<WebElement> listOfSignHereLocations;
    @FindBy (xpath = "//div[@data-qa='adopt-signature-modal-content']")
    private WebElement adoptSignatureDialog;
    @FindBy (xpath = "//button[@data-qa='adopt-submit']")
    private WebElement adoptAndInitialButton;
    @FindBy (xpath = "//button[contains(@data-qa,'action-bar-btn-finish')]")
    private WebElement finishDocusignButton;

    public AceBundleAutoPaymentPage() throws Exception {
    }

    public boolean isOnAceBundleAutoPaymentPage() {
	return isElementDisplayed(autoPaymentPageTitle, 4);
    }

    public void verifyAceBundleAutoPaymentPageContent(FarmersSoftAssert fsa) throws Exception {
	fsa.assertTrue(getListOfSteps().isEmpty(), "Stepper is not available on auto payment page");
	fsa.assertEquals(getTextFromElement(autoPaymentPageTitle), "First up: Pay for auto", "AceBundleAutoPaymentPage title verification");
	if (isElementDisplayed(autoPaymentPageBWIcon, 1)) {
	    fsa.assertTrue(getAttributeData(autoPaymentPageBWIcon, SRC).contains("bristol-west"), "AceBundleAutoPaymentPage using BW logo");
	    fsa.assertEquals(getTextFromElement(autoPaymentPageBWLabel), "Auto policy insured and serviced by Bristol West, a Farmers company", "AceBundleAutoPaymentPage BW label verification");
	}
    }

    public void fillOutAutoPaymentPageAndContinue(AutoApplicant autoApplicant) throws Exception {
	boolean isBristolWest = isElementDisplayed(autoPaymentPageBWIcon, 1);
	if (isBristolWest) {
	    clickElement(activeSelectAndSignDocumentsButton);
	    waitElementBeVisible(ersdDialog);
	    waitAndClickElement(agreeToUseERSDCheckbox);
	    waitAndClickElement(ersdDialogContinueButton);
	    waitElementBeInvisible(ersdDialog);
	    waitElementBeVisible(finishDocusignButton);
	    boolean firstTime = true;
	    for (WebElement initialHere : listOfInitialHereLocations) {
		scrollToElement(initialHere);
		waitAndClickElement(initialHere);
		if (firstTime) {
		    waitElementBeVisible(adoptSignatureDialog);
		    waitAndClickElement(adoptAndInitialButton);
		    waitElementBeInvisible(adoptSignatureDialog);
		    firstTime = false;
		}
	    }
	    for (WebElement signHere : listOfSignHereLocations) {
		scrollToElement(signHere);
		waitAndClickElement(signHere);
	    }
	    // Sometimes some of the clicks fail :(
	    for (WebElement initialHere : listOfInitialHereLocations) {
		scrollToElement(initialHere);
		waitAndClickElement(initialHere);
	    }
	    waitAndClickElement(finishDocusignButton);
	    waitElementBeInvisible(finishDocusignButton);
	    waitAndClickElement(bwSetupPaymentButton);
	} else {
	    scrollAndClickOnElement(cardPreferedPaymentRadioButton);
	}
	AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
	aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
	scrollAndClickOnElement(completeAutoPurchaseButton);
	waitForSpinnerToBeGone();
	if (isElementDisplayed(completeAutoPurchaseButton, 1)) {
	    scrollAndClickOnElement(completeAutoPurchaseButton);
	    waitForSpinnerToBeGone();
	}
    }
}
