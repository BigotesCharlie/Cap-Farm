package com.farmers.ffq.auto.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.farmers.ffq.utils.FarmersSoftAssert;

public class LeadFormThankYouPage extends AutoBasePage {

    @FindBy(css = "div[class='thank-you__title']>h1")
    private WebElement pageTitle;

    @FindBy(css = "div[class='tui-body thank-you__subtitle']>p")
    private WebElement pageSubtitle;

    @FindBy(css = "div[class='thank-you__quote-number ng-star-inserted']>span[class='tui-body-bold']")
    private WebElement quoteNumberText;

    @FindBy(css = "div[class='thank-you__quote-number ng-star-inserted']>span[class='tui-body']")
    private WebElement quoteNumberElement;

    @FindBy(xpath = "//div[contains(text(),'Need more help?')]")
    private WebElement needMoreHelp;

    @FindBy(xpath = "//div[contains(text(),'You can call customer service at')]")
    private WebElement youCanCallCustomerService;

    @FindBy(xpath = "//div[contains(@class,'toll-free-number')]")
    private WebElement tollNumber;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public LeadFormThankYouPage() throws Exception {
    }

    public void validateLeadFormThankYouPageContent(FarmersSoftAssert fsa, boolean isMobile) throws Exception {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageTitle)), "Thank you for choosing Farmers Insurance\u00ae", "Thank you page title check");
        fsa.assertEquals(getTextFromElement(pageSubtitle), "Your request has been submitted.", "Thank you page subtitle check");
        fsa.assertTrue(needMoreHelp.isDisplayed(), "Need more help link displayed");
        fsa.assertTrue(youCanCallCustomerService.isDisplayed(), "Call Customer service link displayed");
        String expectedPhoneNumber = isUseMobileViewEnabled() || isMobile? "1-888-587-2121" : "1-888-422-1618";
        fsa.assertEquals(getTextFromElement(tollNumber), expectedPhoneNumber, "Displayed phone number check");

        // Ace Auto and Bind - Validate that Quote Number is removed from lead thank you page for Auto LOBValidate
        fsa.assertFalse(getTextFromElement(driver().findElement(By.tagName("app-thank-you"))).contains("quote number:"), "Quote number should not be displayed in the content");

    }
}
