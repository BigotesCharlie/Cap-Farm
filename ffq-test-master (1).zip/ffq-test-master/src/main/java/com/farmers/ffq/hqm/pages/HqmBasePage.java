package com.farmers.ffq.hqm.pages;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.hqm.AgentInfoHQM;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.PageLinksHQM;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import lombok.Getter;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOf;


/**
 * Farmers Fast Quote (FFQ) - Base Page for FFQ + Top Navigation Menu.
 */
public class HqmBasePage extends BasePage {

	private static final String ARIA_SELECTED = "aria-selected";
	protected static final String FOUND_PAGE_ERRORS = "Found page errors: ";

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public HqmBasePage() throws Exception {
		super();
	}

	private static final String NEXT_BUTTON_XPATH = "//button[.//span[contains(text(),'NEXT')]]";
	@FindBy(xpath = NEXT_BUTTON_XPATH)
	private WebElement buttonNext;

	private static final String AGREE_N_SUBMIT_BUTTON_XPATH = "//button[@data-gtm='FFQ_Home_ContactInfo_Next_Button']";
	@FindBy(xpath = AGREE_N_SUBMIT_BUTTON_XPATH)
	protected WebElement buttonAgreeAndSubmit;

	private static final String BACK_BUTTON_XPATH = "//button[.//*[text()='BACK']]";
	@FindBy(xpath = BACK_BUTTON_XPATH)
	private WebElement buttonBack;

	private static final String XPATH_SUMMARY_MOBILE_ICON = "//mat-drawer-content//a[@id='hamburgerCollapsed']";
	@FindBy(xpath = XPATH_SUMMARY_MOBILE_ICON)
	protected WebElement summaryMobileIcon;

	private static final String XPATH_SUMMARY_ICON = "//mat-toolbar//a[@id='hamburger']";
	@FindBy(xpath = XPATH_SUMMARY_ICON)
	private WebElement summaryIcon;

	@FindBy(xpath = "//mat-drawer//mat-icon[text()='close']")
	private WebElement closeMenu;

	@FindBy(xpath = "//mat-drawer[contains(@class,'sidenav')]")
	protected WebElement sideDrawer;

	private final String sideDrawerCollapsedXpath = "//mat-drawer[contains(@class,'sidenav') and contains(@style, 'visibility: hidden')]";
	@FindBy(xpath = sideDrawerCollapsedXpath)
	private WebElement sideDrawerCollapsed;

	@FindBy(xpath = "//mat-drawer//mat-step-header[.//span[@id='address']]")
	private WebElement stepperAddressHeader;

	private static final String STEPPER_ADDRESS_XPATH = "//mat-drawer//mat-step-header//span[contains(@id,'address')]";
	@FindBy(xpath = STEPPER_ADDRESS_XPATH)
	private WebElement stepperAddress;

	private static final String STEPPER_ADDRESS_MOBILE_DIV_XPATH = "//mat-horizontal-stepper//mat-step-header[@aria-label='address']";
	@FindBy(xpath = STEPPER_ADDRESS_MOBILE_DIV_XPATH)
	private WebElement stepperAddressMobileDiv;

	private static final String STEPPER_ADDRESS_MOBILE_XPATH = STEPPER_ADDRESS_MOBILE_DIV_XPATH+ "//span[text()='Address']";
	@FindBy(xpath = STEPPER_ADDRESS_MOBILE_XPATH)
	private WebElement stepperAddressMobile;

	@FindBy(xpath = "//mat-drawer//mat-step-header[.//span[@id='property']]")
	private WebElement stepperPropertyHeader;

	private static final String STEPPER_PROPERTY_XPATH = "//mat-drawer//mat-step-header//span[@id='property']";
	@FindBy(xpath = STEPPER_PROPERTY_XPATH)
	private WebElement stepperProperty;

	private static final String STEPPER_PROPERTY_MOBILE_DIV_XPATH = "//mat-horizontal-stepper//mat-step-header[@aria-label='property']";
	@FindBy(xpath = STEPPER_PROPERTY_MOBILE_DIV_XPATH)
	private WebElement stepperPropertyMobileDiv;

	private static final String STEPPER_PROPERTY_MOBILE_XPATH = STEPPER_PROPERTY_MOBILE_DIV_XPATH + "//span[text()='Property']";
	@FindBy(xpath = STEPPER_PROPERTY_MOBILE_XPATH)
	private WebElement stepperPropertyMobile;

	@FindBy(xpath = "//mat-drawer//mat-step-header[.//span[@id='personalInfo']]")
	private WebElement stepperPersonalInfoHeader;

	private static final String STEPPER_PERSONAL_INFO_XPATH = "//mat-drawer//mat-step-header//span[@id='personalInfo']";
	@FindBy(xpath = STEPPER_PERSONAL_INFO_XPATH)
	private WebElement stepperPersonalInfo;

	@FindBy(xpath = "//mat-drawer//mat-step-header[.//span[@id='quotesection']]")
	private WebElement stepperQuoteHeader;

	private static final String STEPPER_QUOTE_XPATH = "//mat-drawer//mat-step-header//span[@id='quotesection']";
	@FindBy(xpath = STEPPER_QUOTE_XPATH)
	private WebElement stepperQuote;

	@FindBy(xpath = "//mat-drawer//span[contains(@class,'quote-summary')]")
	private WebElement txtQuoteNumber;

	@FindBy(xpath = "//div[contains(@class,'PopOverContainer')]//img[contains(@src,'close-btn')]")
	private WebElement btnCloseSurveyPopup;

	private static final String PERSONAL_INFO_USE_MOBILE_XPATH = "//form//a[starts-with(@aria-label,'Personal information use')]";
	private static final String PERSONAL_INFO_USE_XPATH = "//mat-drawer//a[@id='personalInfoUse' and starts-with(@aria-label,'Personal information use')]";
	@FindBy(xpath = PERSONAL_INFO_USE_XPATH)
	private WebElement linkPersonalInfoUse;

	private static final String SAVE_QUOTE_XPATH = "//mat-drawer//div[@id='personalInfoUse' and text()='Save quote & finish later']";
	@FindBy(xpath = SAVE_QUOTE_XPATH)
	private WebElement linkSaveQuote;

	private static final String INPUT_EMAIL_SAFL_XPATH = "//farmers-home-quote-save-finish-dialog//div//mat-label[.=' Email address']/../../../input";
	@FindBy(xpath = INPUT_EMAIL_SAFL_XPATH)
	protected WebElement inputEmailSaveFinishLaterDialog;

	private static final String NEED_HELP_XPATH = "//mat-drawer[contains(@class,'sidenav')]//div[text()='Need Help?']/../p[contains(@class,'caption')]";
	@FindBy(xpath = NEED_HELP_XPATH)
	private WebElement needHelpText;

	private static final String NEED_HELP_TEXT = "A Farmers Insurance\u00ae Representative is available if you have any questions.";
	private static final String NEED_HELP_TEXTQQ = "Work with a knowledgeable, friendly, insurance professional who would be able " +
			"to help with your insurance needs before sending you back to Rocket Mortgage\u00ae.";

	private static final String CALL_FARMERS_LINK_XPATH = "//mat-drawer//a[contains(@id,'phoneIcon')]";
	@FindBy(xpath = CALL_FARMERS_LINK_XPATH)
	private WebElement linkCallFarmers;

	private static final String CONTACT_US_LINK_XPATH = "//mat-drawer//a[contains(@href,'https://www.farmers.com/contact-us/') and contains(text(),'Contact us')]";
	@FindBy(xpath = CONTACT_US_LINK_XPATH)
	private WebElement linkContactUs;

	private static final String CALL_US_LINK_XPATH = "//mat-toolbar//a[starts-with(@aria-label,'Call us at')]";
	@FindBy(xpath = CALL_US_LINK_XPATH)
	private WebElement linkCallUs;

	private static final String TERMS_OF_USE_LINK_XPATH = "//mat-drawer//a[starts-with(@href,'https://www.farmers.com/terms-of-use') and text()='Terms of use']";
	@FindBy(xpath = TERMS_OF_USE_LINK_XPATH)
	private WebElement linkTermsOfUse;

	private static final String PRIVACY_POLICY_LINK_XPATH = "//mat-drawer//a[starts-with(@href,'https://www.farmers.com/privacy-statement/') " +
			"and text()='Do not sell or share my personal information']";
	@FindBy(xpath = PRIVACY_POLICY_LINK_XPATH)
	private WebElement linkPrivacyPolicy;

	private static final String YOUR_PRIVACY_LINK_XPATH = "//mat-drawer//a[@id='your-privacy']";
	@FindBy(xpath = YOUR_PRIVACY_LINK_XPATH)
	private WebElement linkYourPrivacyChoices;

	@FindBy(xpath = "//div[@role='alertdialog']//h4[text()='Notice of Right to Opt-Out']")
	private WebElement modalPrivacyChoicesTitle;

	@FindBy(xpath = "//div[@role='alertdialog']//button[contains(@class,'save-preference-btn')]")
	private WebElement modalPrivacyChoicesSaveButton;

	@FindBy(xpath = "//div[@role='alertdialog']//button[@id='close-pc-btn-handler']")
	private WebElement modalPrivacyChoicesCloseButton;

	@FindBy(xpath = "//div[contains(@class,'left-nav-block')]//span[contains(@class,'quote-summary')]")
	private WebElement textQuoteSummary;

	private static final String PRIVACY_POLICY_NEXT_XPATH = "//form//p[contains(.,'By clicking \"Agree\"')]" +
			"/a[starts-with(@href,'https://www.farmers.com/disclaimer/privacy-policy/')]/span[starts-with(text(),'Privacy Polic')]";
	@FindBy(xpath = PRIVACY_POLICY_NEXT_XPATH)
	private WebElement linkPrivacyPolicyNext;

	private static final String NOTICE_OF_INFORMATION_PRACTICES_LINK_XPATH = "//mat-drawer//a[starts-with(@href," +
			      "'https://www.farmers.com/information-practices/general/') and text()='Notice of information practices']";
	@FindBy(xpath = NOTICE_OF_INFORMATION_PRACTICES_LINK_XPATH)
	private WebElement linkNoticeOfInformationPractices;

	private static final String NOTICE_OF_INFORMATION_PRACTICES_LINK_XPATH_CA = "//mat-drawer//a[starts-with(@href,'https://www.farmers.com/information-practices/california/') " +
			                           "and text()='Notice of information practices']";
	@FindBy(xpath = NOTICE_OF_INFORMATION_PRACTICES_LINK_XPATH_CA)
	private WebElement linkNoticeOfInformationPracticesCA;

	private static final String DIGI_CERT_LINK_XPATH = "//mat-drawer//div[contains(@id,'DigiCertClickID')]//a";
	@FindBy(xpath = DIGI_CERT_LINK_XPATH)
	private WebElement linkDigiCert;

	@FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-opened')]//span[contains(@class,'quote-agent-name')]")
	private WebElement agentNameSide;

	@FindBy(xpath = "//farmers-home-quote-thank-you//span[contains(@class,'quote-agent-name')]")
	private WebElement agentName;

	@FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-opened')]//img[contains(@class,'agent-img')]")
	private WebElement agentImageSide;

	@FindBy(xpath = "//farmers-home-quote-thank-you//img[contains(@class,'agent-img')]")
	private WebElement agentImage;

	@FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-opened')]//span[contains(@class,'quote-agent-p')]")
	private WebElement localAgentTextSide;

	@FindBy(xpath = "//farmers-home-quote-thank-you//span[contains(@class,'quote-agent-p')]")
	private WebElement localAgentText;

	private static final String learnMoreLinkXpath = "//farmers-home-quote-address//strong/a[@id='learn-more-inline']";
	@FindBy (xpath=learnMoreLinkXpath)
	private WebElement learnMoreLink;

	private static final String LOCAL_AGENT_TEXT = "Your local Farmers Insurance\u00ae Agent is available if you have any questions.";

	private static final String AGENT_EMAIL_ICON_SIDE_XPATH = "//mat-drawer[contains(@class,'mat-drawer-opened')]//a[@id='emailTagId']//mat-icon[text()='email']";
	@FindBy(xpath = AGENT_EMAIL_ICON_SIDE_XPATH)
	private WebElement agentEmailIconSide;

	private static final String AGENT_EMAIL_ICON_XPATH = "//farmers-home-quote-thank-you//a[@id='emailTagId']//mat-icon[text()='email']";
	@FindBy(xpath = AGENT_EMAIL_ICON_XPATH)
	private WebElement agentEmailIcon;

	@FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-opened')]//a//div[contains(@class,'body-two')]")
	private WebElement agentEmailTextSide;

	@FindBy(xpath = "//farmers-home-quote-thank-you//a//div[contains(@class,'body-two')]")
	private WebElement agentEmailText;

	private static final String AGENT_PHONE_ICON_SIDE_XPATH = "//mat-drawer[contains(@class,'mat-drawer-opened')]//a[@id='phnTagId']//mat-icon[text()='phone']";
	@FindBy(xpath = AGENT_PHONE_ICON_SIDE_XPATH)
	private WebElement agentPhoneIconSide;

	private static final String AGENT_PHONE_ICON_XPATH = "//farmers-home-quote-thank-you//a[@id='phnTagId']//mat-icon[text()='phone']";
	@FindBy(xpath = AGENT_PHONE_ICON_XPATH)
	private WebElement agentPhoneIcon;

	@FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-opened')]//a[@id='phnTagId']//span[@data-gtm='FFQ_Home_Agent_phone_CTA']")
	private WebElement agentPhoneNumberSide;

	@FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='phnTagId']//span[@data-gtm='FFQ_Home_Agent_phone_CTA']")
	private WebElement agentPhoneNumber;

	private static final String AGENT_ADDRESS_ICON_SIDE_XPATH = "//mat-drawer[contains(@class,'mat-drawer-opened')]//a[@id='locTagId']//mat-icon[text()='place']";
	@FindBy(xpath = AGENT_ADDRESS_ICON_SIDE_XPATH)
	private WebElement agentAddressIconSide;

	private static final String AGENT_ADDRESS_ICON_XPATH = "//farmers-home-quote-thank-you//a[@id='locTagId']//mat-icon[text()='place']";
	@FindBy(xpath = AGENT_ADDRESS_ICON_XPATH)
	private WebElement agentAddressIcon;

	@FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-opened')]//span[@data-gtm='FFQ_Home_Agent_address_link']")
	private WebElement agentAddressTextSide;

	@FindBy(xpath = "//farmers-home-quote-thank-you//span[@data-gtm='FFQ_Home_Agent_address_link']")
	private WebElement agentAddressText;

	private static final String agentInfoSectionXpath = "//mat-drawer-container//*[contains(@class,'agents-Info')]";
	@FindBy(xpath = agentInfoSectionXpath)
	private WebElement agentInfoSection;

	@FindBy(xpath = "//farmers-home-quote-retrieve-dialog/h2[text()='Thank you for retrieving your quote']")
	private WebElement retrieveDialog;

	@FindBy(xpath = "//mat-dialog-actions/button[text()='CONTINUE' or text()='Continue']")
	private WebElement retrieveDialogContinueBtn;

	private final By errorMessage = By.xpath("//mat-error");

	private final By errorSlider = By.xpath("//farmers-home-quote-details-dialog//mat-slider[contains(@class,'errorSlider')]");

	@FindBy(xpath = "//farmers-home-quote-save-finish-dialog//h4[@mat-dialog-title]")
	private WebElement textSaveFinishLaterDialogTitle;

	@FindBy(xpath = "//farmers-home-quote-save-finish-dialog//mat-dialog-content//p[contains(@class,'sub-title-one')]")
	private WebElement textSaveFinishLaterDialogSubTitle;

	@FindBy(xpath = "//farmers-home-quote-save-finish-dialog//button[.='CONTINUE QUOTE']")
	private WebElement btnContinueSaveFinishLaterDialog;

	@FindBy(xpath = "//farmers-home-quote-save-finish-dialog//button[.='SAVE AND EXIT']")
	private WebElement btnSaveExitSaveFinishLaterDialog;

	public void clickNext() throws Exception {
		List<WebElement> errors = driver().findElements(errorMessage);
		if (errors.isEmpty()) {
			try {
				driverWait(5).until(ExpectedConditions.elementToBeClickable(buttonNext));
				waitAndClickElement(buttonNext);
			} catch (ElementClickInterceptedException e) {
				sendKeysToElement(buttonNext, Keys.ESCAPE);
				waitAndClickElement(buttonNext);
			}
		} else {
			errors.forEach(err -> Log.error("\n ***" + getTextFromElement(err) + "\n"));
			throw new AssertionError("There were errors reported on the page, cannot continue.");
		}

	}

	public void clickButtonNext() {
		waitAndClickElement(buttonNext);
	}

	public void clickBack() {
        waitAndClickElement(buttonBack);
	}

	public boolean checkIfElementIsEnabled(WebElement elementToLookFor, int waitTimeInSeconds) throws Exception {
		try {
			driverWait(waitTimeInSeconds).until(ExpectedConditions.elementToBeClickable(elementToLookFor));
			return elementToLookFor.isEnabled();
		} catch (TimeoutException e) {
			return false;
		}
	}

	public boolean checkIfElementIsDisplayed(WebElement elementToLookFor, int waitTimeInSeconds) throws Exception {
		try {
			driverWait(waitTimeInSeconds).until(visibilityOf(elementToLookFor));
			return elementToLookFor.isDisplayed();
		} catch (TimeoutException e) {
			return false;
		}
	}

	/**
	 * Get Quote Number.
	 * @return String quote number
	 */
    public String getQuoteNumber() throws Exception {
        Log.info("Getting Quote Number ");
        wait.until(ExpectedConditions.or(visibilityOf(summaryIcon), visibilityOf(summaryMobileIcon)));
        return getAttributeData(txtQuoteNumber, "textContent").split("#")[1].trim();
    }

	public boolean isButtonNextDisabled() {
		boolean bNext = false;
		String clazz = getAttributeData(buttonNext, CLASS);
		if ((clazz != null) && clazz.contains("button-disabled")){
			bNext = true;
		}
		return bNext;
	}

	public boolean isButtonNextDisplayed() throws Exception {
		return isElementDisplayed(By.xpath(NEXT_BUTTON_XPATH));
	}

	public boolean isButtonBackDisplayed() throws Exception {
		return isElementDisplayed(By.xpath(BACK_BUTTON_XPATH));
	}

	public boolean isButtonAgreeSubmitDisabled() {
		boolean bNext = false;
		String clazz = getAttributeData(buttonAgreeAndSubmit, CLASS);
		if ((clazz != null) && clazz.contains("button-disabled")){
			bNext = true;
		}
		return bNext;
	}

	public boolean isButtonAgreeSubmitDisplayed() throws Exception {
		return isElementDisplayed(By.xpath(AGREE_N_SUBMIT_BUTTON_XPATH));
	}

	public void clickStepperAddress(String source) {
		if (Objects.equals(source, MOBILE_BROWSER)) {
			waitAndClickElement(stepperAddressMobile);
		} else {
			scrollToElement(stepperAddress);
			waitAndClickElement(stepperAddress);
		}
	}

	public boolean isStepperAddressSelected(String source) {
		boolean bSelected = false;
		try {
			String stepper;
			if (source.equals(MOBILE_BROWSER)) {
				stepper = getAttributeData(stepperAddressMobileDiv, ARIA_SELECTED);
			} else {
				stepper = getAttributeData(stepperAddressHeader, ARIA_SELECTED);
			}
			if ((stepper != null) && stepper.equals(LOWERCASE_TRUE)) {
				bSelected = true;
			}
		} catch (NoSuchElementException ignored) {}
		return bSelected;
	}

	public boolean isStepperAddressDisplayed() throws Exception {
		return isElementDisplayed(By.xpath(STEPPER_ADDRESS_XPATH));
	}

	public void clickStepperProperty(String source) {
		if (Objects.nonNull(source) && source.equals(MOBILE_BROWSER)) {
			waitAndClickElement(stepperPropertyMobile);
		} else {
			scrollToTopOfPage();
			waitAndClickElement(stepperProperty);
		}
	}

	public boolean isStepperPropertySelected(String source) {
		boolean bSelected = false;
		try {
			String stepper;
			if (source.equals(MOBILE_BROWSER)) {
				stepper = getAttributeData(stepperPropertyMobileDiv, ARIA_SELECTED);
			} else {
				stepper = getAttributeData(stepperPropertyHeader, ARIA_SELECTED);
			}
			if ((stepper != null) && stepper.equals(LOWERCASE_TRUE)) {
				bSelected = true;
			}
		} catch (NoSuchElementException ignored) {}
		return bSelected;
	}

	public boolean isStepperPropertyDisplayed() throws Exception {
		return isElementDisplayed(By.xpath(STEPPER_PROPERTY_XPATH));
	}

	public void clickStepperPersonalInfo() {
		waitAndClickElement(stepperPersonalInfo);
	}

	public boolean isStepperPersonalInfoSelected() {
		boolean bSelected = false;
		String stepper = getAttributeData(stepperPersonalInfoHeader, ARIA_SELECTED);
		if ((stepper != null) && stepper.equals(LOWERCASE_TRUE)){
			bSelected = true;
		}
		return bSelected;
	}

	public boolean isStepperPersonalInfoDisplayed() throws Exception {
		return isElementDisplayed(By.xpath(STEPPER_PERSONAL_INFO_XPATH));
	}

	public void clickStepperQuote() {
		waitAndClickElement(stepperQuote);
	}

	public boolean isStepperQuoteSelected() {
		boolean bSelected = false;
		String stepper = getAttributeData(stepperQuoteHeader, ARIA_SELECTED);
		if ((stepper != null) && stepper.equals(LOWERCASE_TRUE)){
			bSelected = true;
		}
		return bSelected;
	}

	public boolean isStepperQuoteDisplayed() throws Exception {
		return isElementDisplayed(By.xpath(STEPPER_QUOTE_XPATH));
	}

	public boolean isSummaryIconDisplayed() throws Exception {
		if (isSideDrawerCollapsed()) {
			return isElementDisplayed(By.xpath(XPATH_SUMMARY_MOBILE_ICON));
		} else {
			return isElementDisplayed(By.xpath(XPATH_SUMMARY_ICON));
		}
	}

	public boolean isLinkPersonalInfoUse() throws Exception {
		return isElementDisplayed(By.xpath(PERSONAL_INFO_USE_MOBILE_XPATH));
	}

	public boolean isLinkPersonalInfoUseInSideDrawer() throws Exception {
		return isElementDisplayed(By.xpath(PERSONAL_INFO_USE_XPATH));
	}

	public boolean isLinkSaveQuote() throws Exception {
		return isElementDisplayed(By.xpath(SAVE_QUOTE_XPATH));
	}

	public boolean isLinkCallFarmers(String phoneNumber) throws Exception {
		boolean bCall = isElementDisplayed(By.xpath(CALL_FARMERS_LINK_XPATH));
		if (bCall) {
			String phone = "Call us at %s";
			Assert.assertEquals(getAttributeData(linkCallFarmers, ARIA_LABEL), String.format(phone, phoneNumber),
					"Need Help? - Call Farmers Phone number.");
		}
		return bCall;
	}

	public boolean isNeedHelpText() throws Exception {
		return isElementDisplayed(By.xpath(NEED_HELP_XPATH));
	}

	public boolean isLinkContactUs() throws Exception {
		scrollDownInLeftDrawer();
		return isElementDisplayed(By.xpath(CONTACT_US_LINK_XPATH));
	}

	public boolean isLinkCallUs(String phoneNumber) {
		boolean bCall;
		String phone = "Call us at " + phoneNumber;
		try {
			Assert.assertEquals(getAttributeData(linkCallUs, ARIA_LABEL).trim(), phone, "Call Us phone number in the top-right corner link.");
			bCall = true;
		} catch (NoSuchElementException e) {
			bCall = false;
		}
		return bCall;
	}

	public void scrollDownInLeftDrawer() {
		try {
//			waitForPageToBeReady();
			sleep(2);
			scrollToElementBottom(sideDrawer);
			sleep(1);
			scrollToElement(linkDigiCert);
		} catch (org.openqa.selenium.NoSuchElementException e) {
			sendKeysToElement(textQuoteSummary, Keys.ARROW_DOWN);
			sendKeysToElement(textQuoteSummary, Keys.ARROW_DOWN);
		}
	}

	public boolean isLinkTermsOfUse() throws Exception {
		return isElementDisplayed(By.xpath(TERMS_OF_USE_LINK_XPATH));
	}

	public boolean isLinkPrivacyPolicy() throws Exception {
		return isElementDisplayed(By.xpath(PRIVACY_POLICY_LINK_XPATH));
	}

	public boolean isLinkPrivacyPolicyNext() throws Exception {
		return isElementDisplayed(By.xpath(PRIVACY_POLICY_NEXT_XPATH));
	}

	public boolean isLinkNoticeOfInformationPractices() throws Exception {
		return isElementDisplayed(By.xpath(NOTICE_OF_INFORMATION_PRACTICES_LINK_XPATH));
	}

	public boolean isLinkNoticeOfInformationPracticesCA() throws Exception {
		return isElementDisplayed(By.xpath(NOTICE_OF_INFORMATION_PRACTICES_LINK_XPATH_CA));
	}

	public boolean getLinkDigiCert() {
		return getAttributeData(linkDigiCert, HREF).trim().startsWith("https://www.digicert.com");
	}

	public boolean isSideDrawerCollapsed() throws Exception {
		return isElementPresent(By.xpath(sideDrawerCollapsedXpath));
	}

	public AgentInfoHQM getAgentInfo (String quoteNumber) throws SQLException, IOException {
		AgentInfoHQM agentInfo = null;
		try {
			ApiHelper apiHelper = new ApiHelper();
			AgentInfoHQM.Agent agent = apiHelper.getStartQuoteFromJson(quoteNumber).getAgent();
			if (agent == null) {
				agentInfo = apiHelper.getAgentInfoFromJson(quoteNumber);
			} else {
				agentInfo = new AgentInfoHQM(agent);
			}
		} catch (NullPointerException ignored) {}
		return agentInfo;
	}

	public void validatePageLinks(PageLinksHQM pageLinks, String quoteNumber, FarmersSoftAssert fsa) throws Exception {
		// null - no validation
		// 0 - validate link/button not available (not displayed)
		// 1 - validate link/button available (displayed)
		// 2 - validate link/button disabled
		// 3 - validate link/button enabled
//		waitForPageToBeReady();
		sleep(3);
		boolean drawerCollapsed = this.isSideDrawerCollapsed();
		if (pageLinks.checkAgentInfo > 0) {
			AgentInfoHQM agentInfo = getAgentInfo(quoteNumber);
			if ((agentInfo != null) && (agentInfo.getAgent() != null)
					&& (agentInfo.getAgent().getLastName() != null)) {
				if (drawerCollapsed) {
					waitAndClickElement(summaryMobileIcon);
					sleep(1);
				}
				pageLinks.linkCallFarmers = null;
				pageLinks.needHelpText = null;
				validateAgentInfoSection(pageLinks, agentInfo, fsa);
				if (drawerCollapsed) {
					waitAndClickElement(closeMenu);
					sleep(1);
				}
			}
		}
		if (pageLinks.iconSummary != null) {
			fsa.assertEquals(this.isSummaryIconDisplayed(), pageLinks.iconSummary != 0, pageLinks.pageName + " - Summary icon is displayed.");
		}
		if (pageLinks.stepperAddress != null) {
			if (pageLinks.stepperAddress == 2) {
				fsa.assertFalse(this.isStepperAddressSelected(pageLinks.quoteType), pageLinks.pageName + " - Address stepper is selected.");
			} else if (pageLinks.stepperAddress == 3) {
				fsa.assertTrue(this.isStepperAddressSelected(pageLinks.quoteType), pageLinks.pageName + " - Address stepper is selected.");
			} else if (pageLinks.stepperAddress == 0) {
				fsa.assertFalse(this.isStepperAddressDisplayed(), pageLinks.pageName + " - Address stepper is displayed.");
			}
		}
		if (pageLinks.stepperProperty != null) {
			if (pageLinks.stepperProperty == 2) {
				fsa.assertFalse(this.isStepperPropertySelected(pageLinks.quoteType), pageLinks.pageName + " - Property stepper is selected.");
			} else if (pageLinks.stepperProperty == 3) {
				fsa.assertTrue(this.isStepperPropertySelected(pageLinks.quoteType), pageLinks.pageName + " - Property stepper is selected.");
			} else if (pageLinks.stepperProperty == 0) {
				fsa.assertFalse(this.isStepperPropertySelected(pageLinks.quoteType), pageLinks.pageName + " - Property stepper is displayed.");
			}
		}
		if (pageLinks.stepperPersonalInfo != null) {
			if (pageLinks.stepperPersonalInfo == 2) {
				fsa.assertFalse(this.isStepperPersonalInfoSelected(), pageLinks.pageName + " - Personal Info stepper is selected.");
			} else if (pageLinks.stepperPersonalInfo == 3) {
				fsa.assertTrue(this.isStepperPersonalInfoSelected(), pageLinks.pageName + " - Personal Info stepper is selected.");
			} else if (pageLinks.stepperPersonalInfo == 0) {
				fsa.assertFalse(stepperPersonalInfo.isDisplayed(), pageLinks.pageName + " - Personal Info stepper is displayed.");
			}
		}
		if (pageLinks.stepperQuote != null) {
			if (pageLinks.stepperQuote == 2) {
				fsa.assertFalse(this.isStepperQuoteSelected(), pageLinks.pageName + " - Quote stepper is selected.");
			} else if (pageLinks.stepperQuote == 3) {
				fsa.assertTrue(this.isStepperQuoteSelected(), pageLinks.pageName + " - Quote stepper is selected.");
			} else if (pageLinks.stepperQuote == 0) {
				fsa.assertFalse(stepperQuote.isDisplayed(), pageLinks.pageName + " - Quote stepper is displayed.");
			}
		}
		if (pageLinks.linkCallUs != null) {
			if (pageLinks.linkCallUs == 0) {
				fsa.assertFalse(linkCallUs.isDisplayed(), pageLinks.pageName + " - Call Us link in the top-right corner is not displayed.");
			} else {
				fsa.assertTrue(this.isLinkCallUs(pageLinks.phoneToCall), pageLinks.pageName + " - Call Us link in the top-right corner is displayed and text match.");
			}
		}
		if (pageLinks.linkPersonalInfoUse != null && pageLinks.quoteType.equals(MOBILE_BROWSER) && pageLinks.pageName.equals("addressPage")) {
			fsa.assertEquals(isLinkPersonalInfoUse(), pageLinks.linkPersonalInfoUse != 0, pageLinks.pageName + " - Personal Information Use link on main page is displayed.");
		}

		// expand side drawer, if it's collapsed
		if (drawerCollapsed && !pageLinks.pageName.equals("thankYouPage")) {
			waitAndClickElement(summaryMobileIcon);
		}
		if (pageLinks.linkPersonalInfoUse != null) {
			if (pageLinks.linkPersonalInfoUse == 1)	waitElementBeVisibleClickable(linkPersonalInfoUse);
			fsa.assertEquals(isLinkPersonalInfoUseInSideDrawer(), pageLinks.linkPersonalInfoUse != 0, pageLinks.pageName + " - Personal Information Use link in side drawer is displayed.");
		}
		if (pageLinks.linkSaveQuote != null) {
			fsa.assertEquals(isLinkSaveQuote(), pageLinks.linkSaveQuote != 0, pageLinks.pageName + " - Save Quote & finish later link is displayed.");
		}
		if (pageLinks.needHelpText != null) {
			if (pageLinks.needHelpText == 0) {
				fsa.assertFalse(this.isNeedHelpText(), pageLinks.pageName + " - Text below Need Help? is not displayed.");
			} else {
				waitElementBeVisible(needHelpText);
				fsa.assertTrue(this.isNeedHelpText(), pageLinks.pageName + " - Text below Need Help? is displayed.");
				fsa.assertEquals(getTextFromElement(needHelpText), pageLinks.quoteType.equals(QQ) ? NEED_HELP_TEXTQQ : NEED_HELP_TEXT,
						pageLinks.pageName + " - Text below Need Help? is correct.");
			}
		}
		if (pageLinks.linkCallFarmers != null) {
			fsa.assertEquals(this.isLinkCallFarmers(pageLinks.phoneToCall), pageLinks.linkCallFarmers != 0, pageLinks.pageName + " - Call Farmers link is displayed.");
		}
		if (pageLinks.linkContactUs != null) {
			fsa.assertEquals(this.isLinkContactUs(), pageLinks.linkContactUs != 0, pageLinks.pageName + " - Contact Us link is displayed.");
		}
		if (pageLinks.linkPrivacyPolicy != null) {
			fsa.assertEquals(this.isLinkPrivacyPolicy(), pageLinks.linkPrivacyPolicy != 0, pageLinks.pageName + " - Privacy Policy link is displayed.");
		}
		if (pageLinks.linkTermsOfUse != null) {
			fsa.assertEquals(this.isLinkTermsOfUse(), pageLinks.linkTermsOfUse != 0, pageLinks.pageName + " - Terms of use link is displayed.");
		}
		if (pageLinks.linkPrivacyPolicyNext != null) {
			if (isElementDisplayed(By.xpath(learnMoreLinkXpath))) {
				waitAndClickElement(learnMoreLink);
			}
			fsa.assertEquals(this.isLinkPrivacyPolicyNext(), pageLinks.linkPrivacyPolicyNext != 0, pageLinks.pageName + " - Privacy Policy NEXT link is displayed.");
		}
		if (pageLinks.linkNoticeOfInformationPractices != null) {
			if (!pageLinks.stateCode.equals(CA)) {
				if (pageLinks.linkNoticeOfInformationPractices == 0) {
					fsa.assertFalse(isLinkNoticeOfInformationPractices(), pageLinks.pageName + " - Notice of Information Practices link is not displayed.");
				} else {
					fsa.assertTrue(isLinkNoticeOfInformationPractices(), pageLinks.pageName + " - Notice of Information Practices link is displayed.");
				}
				fsa.assertFalse(isLinkNoticeOfInformationPracticesCA(), pageLinks.pageName + " - Notice of Information Practices CA link is not displayed.");
			} else {
				if (pageLinks.linkNoticeOfInformationPractices == 0) {
					fsa.assertFalse(isLinkNoticeOfInformationPracticesCA(), pageLinks.pageName + " - Notice of Information Practices CA link is not displayed.");
				} else {
					fsa.assertTrue(isLinkNoticeOfInformationPracticesCA(), pageLinks.pageName + " - Notice of Information Practices CA link is displayed.");
				}
				fsa.assertFalse(isLinkNoticeOfInformationPractices(), pageLinks.pageName + " - Notice of Information Practices link is not displayed.");
			}
		}
		if ((pageLinks.linkDigiCert != null) && (pageLinks.linkDigiCert != 0)) {
			fsa.assertEquals(this.getLinkDigiCert(), pageLinks.linkDigiCert != 0, pageLinks.pageName + " - Digi Cert link is displayed.");
		}
		// collapse side drawer, if it was collapsed
		if (drawerCollapsed && !pageLinks.pageName.equals("thankYouPage")) {
			waitAndClickElement(closeMenu);
		}
		if (pageLinks.buttonBack != null) {
			fsa.assertEquals(this.isButtonBackDisplayed(), pageLinks.buttonBack != 0, pageLinks.pageName + " - BACK button is displayed.");
		}
		if (!pageLinks.pageName.equals("contactInfoPage")) {
			if (pageLinks.buttonNext != null) {
				if (pageLinks.buttonNext == 2) {
					fsa.assertTrue(this.isButtonNextDisabled(), pageLinks.pageName + " - NEXT button is disabled.");
				} else if (pageLinks.buttonNext == 3) {
					fsa.assertFalse(this.isButtonNextDisabled(), pageLinks.pageName + " - NEXT button is not disabled.");
				} else if (pageLinks.buttonNext == 0) {
					fsa.assertFalse(this.isButtonNextDisplayed(), pageLinks.pageName + " - NEXT button is not displayed.");
				}
			}
		} else {
			if (pageLinks.buttonNext != null) {
				if (pageLinks.buttonNext == 2) {
					fsa.assertTrue(this.isButtonAgreeSubmitDisabled(), pageLinks.pageName + " - AGREE & SUBMIT button is disabled.");
				} else if (pageLinks.buttonNext == 3) {
					fsa.assertFalse(this.isButtonAgreeSubmitDisabled(), pageLinks.pageName + " - AGREE & SUBMIT button is not disabled.");
				} else if (pageLinks.buttonNext == 0) {
					fsa.assertFalse(this.isButtonAgreeSubmitDisplayed(), pageLinks.pageName + " - AGREE & SUBMIT button is not displayed.");
				}
			}
		}
	}

	@Getter
	public static class PageLink {
		private final WebElement linkElement;
		private final String page;
		private final String destinationPageTitleXpath;
		private final String destinationUrlPattern1;
		private final String destinationUrlPattern2;

		public PageLink(WebElement linkElement, String page, String destinationPageTitleXpath, String destinationUrlPattern1, String destinationUrlPattern2) {
			this.linkElement = linkElement;
			this.page = page;
			this.destinationPageTitleXpath = destinationPageTitleXpath;
			this.destinationUrlPattern1 = destinationUrlPattern1;
			this.destinationUrlPattern2 = destinationUrlPattern2;
		}
	}

	private ArrayList<PageLink> getPageLinks() {
		ArrayList<PageLink> pageLinks = new ArrayList<>();
		PageLink pageLink = new PageLink(linkPersonalInfoUse, "Personal information use", "//h1[.='Enterprise Privacy Statement']",
				"www.farmers.com/privacy-statement/", EMPTY_STRING);
		pageLinks.add(pageLink);
		pageLink = new PageLink(linkContactUs, "Contact us", "//h1[.='Contact us']",
				"www.farmers.com/contact-us/", EMPTY_STRING);
		pageLinks.add(pageLink);
		pageLink = new PageLink(linkTermsOfUse, "Terms of use", "//h1[.='Terms Of Use']",
				"www.farmers.com/terms-of-use.html", EMPTY_STRING);
		pageLinks.add(pageLink);
		pageLink = new PageLink(linkPrivacyPolicy, "Do not sell or share my personal information",
				"//h2[.='Do Not Sell/Share My Personal Information/Notice of Right to Opt Out']",
				"www.farmers.com/privacy-statement/", "#donotsell");
		pageLinks.add(pageLink);
		pageLink = new PageLink(linkNoticeOfInformationPractices, "Notice of information practices", "//h1[.='Notice of Information Practices']",
				"www.farmers.com/information-practices/general", EMPTY_STRING);
		pageLinks.add(pageLink);
		return pageLinks;
	}

	public void validatePageLinksNavigationTitles(FarmersSoftAssert sa) throws Exception {
		ArrayList<PageLink> pageLinks = getPageLinks();

		String baseWindow = driver().getWindowHandle();
		for (PageLink pageLink : pageLinks) {
			scrollToBottomOfPage();
			Log.info("Going to check: " + pageLink.getPage());
			scrollAndClickOnElement(pageLink.getLinkElement());
			for (int i = 0; i < 10; i++) {
				if (driver().getWindowHandles().size() > 1) {
					break;
				}
				sleep(2);
			}
			Set<String> newHandles = driver().getWindowHandles();
			int activeWindows = newHandles.size();
			for (String handle : newHandles) {
				if (!baseWindow.equalsIgnoreCase(handle)) {
					driver().switchTo().window(handle);
					driverWait(Property.PAGELOADTIMEOUT).until(ExpectedConditions.urlContains(pageLink.getDestinationUrlPattern1()));
					String currentURL = driver().getCurrentUrl();
					sa.assertTrue((pageLink.getDestinationUrlPattern2().isBlank() || currentURL.contains(pageLink.getDestinationUrlPattern2())),
							pageLink.getPage() + " Url - contains: " + pageLink.getDestinationUrlPattern2());
					driverWait(10).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(pageLink.getDestinationPageTitleXpath())));
					driver().close();
					activeWindows--;
					driverWait(Property.PAGELOADTIMEOUT).until(ExpectedConditions.numberOfWindowsToBe(activeWindows));
				}
			}
			driver().switchTo().window(baseWindow);
		}
		waitAndClickElement(linkYourPrivacyChoices);
		sa.assertEquals(getTextFromElement(modalPrivacyChoicesTitle), "Notice of Right to Opt-Out", "Your Privacy Choices popup Title");
		sa.assertEquals(getTextFromElement(modalPrivacyChoicesSaveButton), "Save My Changes", "Your Privacy Choices popup Save changes button");
		sa.assertEquals(getAttributeData(modalPrivacyChoicesCloseButton, ARIA_LABEL), "Close", "Your Privacy Choices popup Close button");
		waitAndClickElement(modalPrivacyChoicesCloseButton);
	}

	public void validateAgentInfoSection(PageLinksHQM pageLinks, AgentInfoHQM agentInfo, FarmersSoftAssert fsa) throws Exception {
		if (!pageLinks.pageName.equals("thankYouPage")) {
			fsa.assertEquals(getTextFromElement(agentNameSide), agentInfo.getAgent().getFirstName() + SPACE + agentInfo.getAgent().getLastName(),
					"Agent Name in the side drawer.");
			if ((agentInfo.getAgent().getAgentImageUrl() != null) && (!agentInfo.getAgent().getAgentImageUrl().isBlank())) {
				fsa.assertEquals(getAttributeData(agentImageSide, SRC), agentInfo.getAgent().getAgentImageUrl(),
						"Agent Image is displayed in the side drawer.");
			}
			fsa.assertEquals(getTextFromElement(localAgentTextSide), LOCAL_AGENT_TEXT, "Local Agent text match in the side drawer.");
			if ((agentInfo.getAgentEmailAddress() != null) && (!agentInfo.getAgentEmailAddress().isBlank())) {
				fsa.assertTrue(isElementDisplayed(By.xpath(AGENT_EMAIL_ICON_SIDE_XPATH)), "Agent email icon is displayed in the side drawer.");
				fsa.assertEquals(getTextFromElement(agentEmailTextSide), agentInfo.getAgentEmailAddress(), "Agent email address in the side drawer.");
			}
			fsa.assertTrue(isElementDisplayed(By.xpath(AGENT_PHONE_ICON_SIDE_XPATH)), "Agent phone icon is displayed in the side drawer.");
			fsa.assertEquals(getTextFromElement(agentPhoneNumberSide), agentInfo.getAgentPhoneNumber(), "Agent phone number in the side drawer.");
			fsa.assertTrue(isElementDisplayed(By.xpath(AGENT_ADDRESS_ICON_SIDE_XPATH)), "Agent address icon is displayed in the side drawer.");
			if (!agentInfo.getAgent().getAddress().getCity().isEmpty()) {
				fsa.assertEquals(getTextFromElement(agentAddressTextSide), agentInfo.getAgentFullAddress(), "Agent address in the side drawer.");
			}
		} else {
			fsa.assertEquals(getTextFromElement(agentName), agentInfo.getAgent().getFirstName() + SPACE + agentInfo.getAgent().getLastName(),
					"Agent Name in the page.");
			if ((agentInfo.getAgent().getAgentImageUrl() != null) && (!agentInfo.getAgent().getAgentImageUrl().isBlank())) {
				fsa.assertEquals(getAttributeData(agentImage, SRC), agentInfo.getAgent().getAgentImageUrl(),
						"Agent Image is displayed in the page.");
			}
			fsa.assertEquals(getTextFromElement(localAgentText), LOCAL_AGENT_TEXT, "Local Agent text match in the page.");
			if (agentInfo.getAgentEmailAddress() != null) {
				fsa.assertTrue(isElementDisplayed(By.xpath(AGENT_EMAIL_ICON_XPATH)), "Agent email icon is displayed in the page.");
				fsa.assertEquals(getTextFromElement(agentEmailText), agentInfo.getAgentEmailAddress(), "Agent email address in the page.");
			}
			fsa.assertTrue(isElementDisplayed(By.xpath(AGENT_PHONE_ICON_XPATH)), "Agent phone icon is displayed in the page.");
			fsa.assertEquals(getTextFromElement(agentPhoneNumber), agentInfo.getAgentPhoneNumber(), "Agent phone number in the page.");
			fsa.assertTrue(isElementDisplayed(By.xpath(AGENT_ADDRESS_ICON_XPATH)), "Agent address icon is displayed in the page.");
			if (!agentInfo.getAgent().getAddress().getCity().isEmpty()) {
				fsa.assertEquals(getTextFromElement(agentAddressText), agentInfo.getAgentFullAddress(), "Agent address in the page.");
			}
		}
	}

	public List<String> getPageErrors() throws Exception {
		sleep(1);
		return driver().findElements(errorMessage).stream().map(this::getTextFromElement).collect(Collectors.toList());
	}

	public List<WebElement> getSliderErrors() throws Exception {
		sleep(1);
		return new ArrayList<>(driver().findElements(errorSlider));
	}

	public void retrieveDialogContinue() {
		sleep(1);
		waitForPageToBeReady();
		waitAndClickElement(retrieveDialogContinueBtn);
		waitForSpinnerToBeGone();
	}

	public void clickSaveAndFinishLater() {
		waitAndClickElement(linkSaveQuote);
	}

	public void clickSaveAndExit() {
		waitAndClickElement(btnSaveExitSaveFinishLaterDialog);
	}

	public void clickContinueQuote() {
		waitAndClickElement(btnContinueSaveFinishLaterDialog);
	}

	public void clickDismissSurveyPopup() {
		try {
			driverWait(5).until(ExpectedConditions.visibilityOf(btnCloseSurveyPopup));
			clickElement(btnCloseSurveyPopup);
			Log.info("There was Survey Popup displayed and dismissed.");
		} catch (Exception e) {
			Log.warn("There was no Survey Popup displayed during the time allotted.");
		}
	}

	public boolean isEmailInSAFLDialogReadOnly() {
		String readOnly = getAttributeData(inputEmailSaveFinishLaterDialog, READONLY);
		return (readOnly != null) && readOnly.equals(LOWERCASE_TRUE);
	}

	protected boolean isGuideWireState(String stateCode) {
		List<String> guideWireStates = new ArrayList<>(Arrays.asList(AZ,MN));
		return guideWireStates.contains(stateCode);
	}

	protected boolean isNotGuideWireOrEasternExpansionState(String stateCode) {
		return !isGuideWireState(stateCode) && !isEasternExpansionState(stateCode);
	}

	protected boolean isAdtSecurityState(String stateCode) {
		List<String> adtStates = new ArrayList<>(Arrays.asList(MI, AR, SD, ND, AL, CT, CA, MO, CO, KS));
		return adtStates.contains(stateCode);
	}

	protected boolean isEarlyShoppingFactorState(String stateCode) {
		List<String> earlyShoppingStates = new ArrayList<>(Arrays.asList(AL, AR, AZ, CO, GA, IA, ID, IL, IN, KS, MD, MI, MN, MO,
				NE, ND, NM, OH, OK, OR, PA, SD, TN, TX, UT, WA, WI, WY, VA));
		return earlyShoppingStates.contains(stateCode);
	}

	public boolean isPLAState(String stateCode) {
		List<String> listPLAStates = new ArrayList<>(Arrays.asList(MT, CT));
		return listPLAStates.contains(stateCode);
	}

	public boolean isFlexState(String stateCode) {
		List<String> listFlexStates = new ArrayList<>(Arrays.asList(AR, AL, AZ, CA, CO, GA, IL, ID, MI, MO, ND, NE, NM, OK, OR, PA, SD, TN, TX, UT, WI, WY, VA));
		return listFlexStates.contains(stateCode);
	}

	public boolean isHqmDigitalMonetizationState(String stateCode) {
		List<String> hqmDigitalMonetizationStates = new ArrayList<>(Arrays.asList(CA, CT, LA, NV));
		return hqmDigitalMonetizationStates.contains(stateCode);
	}

	public String getContactUsPhoneNumber(ApplicantHQM applicant, String quoteSource, boolean afterQuote) throws Exception {
		// @quoteSource param is re-used as AEM campaign phone number, when it's not browser type and not QQ.
		String contactUs;
		boolean agentAssigned = isElementPresent(By.xpath(agentInfoSectionXpath));
		if (quoteSource.startsWith(DESKTOP_BROWSER)) {
			if (isEasternExpansionState(applicant.stateCode)) {
				contactUs = isHqmDigitalMonetizationState(applicant.stateCode) && afterQuote
						? CALL_FARMERS_HQM_MONETIZATION : CALL_FARMERS_EE;
			} else if (isHqmDigitalMonetizationState(applicant.stateCode) && !agentAssigned) {
				contactUs = afterQuote ? CALL_FARMERS_HQM_MONETIZATION : CALL_FARMERS;
			} else {
				contactUs = CALL_FARMERS;
			}
		} else if (quoteSource.startsWith(MOBILE_BROWSER)) {
			if (isEasternExpansionState(applicant.stateCode)) {
				contactUs = isHqmDigitalMonetizationState(applicant.stateCode) && afterQuote
						? CALL_FARMERS_MOBILE_HQM_MONETIZATION : CALL_FARMERS_EE;
			} else if (isHqmDigitalMonetizationState(applicant.stateCode) && !agentAssigned) {
				contactUs = afterQuote ? CALL_FARMERS_MOBILE_HQM_MONETIZATION : CALL_FARMERS_MOBILE;
			} else {
				contactUs = CALL_FARMERS_MOBILE;
			}
		} else if (quoteSource.startsWith(CW)) {
			contactUs = isHqmDigitalMonetizationState(applicant.stateCode) && afterQuote ?
					CALL_FARMERS_HQM_MONETIZATION : (isEasternExpansionState(applicant.stateCode) ? CALL_FARMERS_EE : CALL_FARMERS);
		} else if (quoteSource.startsWith(MB)) {
			contactUs = isHqmDigitalMonetizationState(applicant.stateCode) && afterQuote ?
					CALL_FARMERS_MOBILE_HQM_MONETIZATION : CALL_FARMERS_MOBILE;
		} else if (quoteSource.startsWith(QQ) && !isHqmDigitalMonetizationState(applicant.stateCode)) {
			contactUs = CALL_FARMERS_QUICKEN;
		} else {
			contactUs = quoteSource;
			if (isHqmDigitalMonetizationState(applicant.stateCode) && !agentAssigned) {
				contactUs = afterQuote ? CALL_FARMERS_HQM_MONETIZATION : contactUs;
			}
		}
		return contactUs;
	}
}
