package com.farmers.ffq.auto.pages;

import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Pattern;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AgentDetails extends AutoBasePage {

    @FindBy(xpath = "//div[contains(@class, 'auto-agent-details__save-quote')]")
    private WebElement quoteNumberSection;

    @FindBy(xpath = "//button[contains(@class, 'auto-agent-details__save-link')]")
    private WebElement saveQuoteLink;

    private static final String AGENT_INFO_SECTION_XPATH = "//div[@class ='tui-agent-box-column-2']";
    @FindBy(xpath = AGENT_INFO_SECTION_XPATH + "//div[@class='tui-caption']")
    private WebElement yourAgentLabel;

    private static final String AGENT_NAME_XPATH = AGENT_INFO_SECTION_XPATH + "//div[@class='tui-body-bold']";
    @FindBy(xpath = AGENT_NAME_XPATH)
    private WebElement agentName;

    @FindBy(xpath = "//div[contains(@class,'agent-details-container tui-stacking-top-md')][1]//mat-icon")
    private WebElement phoneIcon;

    @FindBy(xpath = "//div[contains(@class,'agent-details-container tui-stacking-top-md')][1]//a[contains(@class,'footer')]")
    private WebElement phoneNumber;

    @FindBy(xpath = "//div[contains(@class,'agent-details-container tui-stacking-top-md')][2]//mat-icon")
    private WebElement emailIcon;

    @FindBy(xpath = "//div[contains(@class,'agent-details-container tui-stacking-top-md')][2]//a[contains(@class,'footer')]")
    private WebElement agentEmail;

    @FindBy(xpath = "//div[contains(@class,'agent-details-container tui-stacking-top-md')][3]//mat-icon")
    private WebElement addressIcon;

    @FindBy(xpath = "//div[contains(@class,'agent-details-container tui-stacking-top-md')][3]//a[contains(@class,'footer')]")
    private WebElement agentAddress;

    @FindBy(xpath = AGENT_INFO_SECTION_XPATH + "//button")
    private WebElement contactMeButton;

    private final String CONTACT_FARMERS_REPRESENTATIVE = "Contact farmers representative at";
    @FindBy(xpath = AGENT_INFO_SECTION_XPATH + "//a[starts-with(@aria-label,'" + CONTACT_FARMERS_REPRESENTATIVE + "')]")
    private WebElement contactFarmersRepresentativeLink;

    @FindBy(id = "addDriverHeading")
    private WebElement sidePanelTitle;

    @FindBy(xpath = "//app-contact-agent//mat-icon")
    private WebElement sidePanelCloseButton;

    @FindBy(xpath = "//div[@class='auto-schedule-appointment-agent-text']/p[contains(@class,'tui-caption-text')]")
    private WebElement sidePanelYourAgentLabel;

    @FindBy(xpath = "//div[contains(@class, 'auto-contact-agent__fields-section')]//h5")
    private WebElement sidePanelAgentName;

    @FindBy(xpath = "//p/a[@class='auto-contact-agent-anchor']")
    private WebElement sidePanelAgentAddress;

    @FindBy(xpath = "//div[@class='auto-schedule-appointment-agent-text']/a[contains(@class, 'auto-contact-agent-anchor')]")
    private WebElement sidePanelAgentEmail;

    @FindBy(xpath = "//p[@class='tui-small-text']/a[contains(@class,'auto-contact-agent-anchor')]")
    private WebElement sidePanelAgentPhoneNumber;

    @FindBy(className = "required-caption")
    private WebElement sidePanelRequiredFieldLabel;

    @FindBy(xpath = "//div[@class='auto-contact-agent__fields-section']/div[@class='auto-contact-agent-subheading__section']/label[@class='tui-field-label-text']")
    private WebElement sidePanelReasonForContactLabel;

    @FindBy(xpath = "//textarea")
    private WebElement sidePanelReasonForContactTextArea;

    @FindBy(css = "span[class='tui-caption ng-star-inserted']")
    private WebElement remainingCharacter;

    @FindBy(xpath = "//div[@id='formField_reasonForContact']//mat-error")
    private WebElement sidePanelReasonForContactErrorMessageLabel;

    @FindBy(id = "contact-info")
    private WebElement sidePanelContactInfoLabel;

    @FindBy(xpath = "//div[@id='formField_firstName']//input")
    private WebElement sidePanelCustomerFirstName;

    @FindBy(xpath = "//mat-form-field[@id='auto-contact-agent-lname__input-field']//input")
    private WebElement sidePanelCustomerLastName;

    @FindBy(id = "preferred-contact")
    private WebElement sidePanelPreferredContactLabel;

    @FindBy(xpath = "//mat-form-field[@id='auto-contact-agent-email__input-field']//input")
    public WebElement sidePanelCustomerEmailEntryField;

    @FindBy(xpath = "//mat-form-field[@id='auto-contact-agent-email__input-field']//mat-error")
    private WebElement sidePanelCustomerEmailEntryFieldErrorMessageLabel;

    @FindBy(xpath = "//mat-form-field[@id='auto-contact-agent-phonenumber__input-field']//input")
    public WebElement sidePanelCustomerPhoneNumberEntryField;

    @FindBy(xpath = "//mat-form-field[@id='auto-contact-agent-phonenumber__input-field']//mat-error")
    private WebElement sidePanelCustomerPhoneNumberEntryFieldErrorMessageLabel;

    @FindBy(id = "existing-customerlabel")
    private WebElement sidePanelExistingCustomerLabel;

    private static final String EXISTING_CUSTOMER_RADIOBUTTON_XPATH = "//mat-radio-button//input[@value='Yes']";
    @FindBy(xpath = EXISTING_CUSTOMER_RADIOBUTTON_XPATH)
    private WebElement sidePanelYesExistingCustomerRadioButton;

    private static final String NOT_EXISTING_CUSTOMER_RADIOBUTTON_XPATH = "//mat-radio-button//input[@value='No']";
    @FindBy(xpath = NOT_EXISTING_CUSTOMER_RADIOBUTTON_XPATH)
    private WebElement sidePanelNoExistingCustomerRadioButton;

    @FindBy(xpath = "//div[@class='auto-contact-agent-subheading__section']//mat-error")
    private WebElement sidePanelExistingCustomerErrorMessageLabel;

    @FindBy(xpath = "//mat-form-field[@id='auto-contact-agent-quotenumber__input-field']//input")
    private WebElement sidePanelQuoteNumber;

    @FindBy(id = "schedule-agent-appointment")
    private WebElement sidePanelScheduleAnAppointmentLabel;

    @FindBy(id = "contact-agent-text")
    private WebElement sidePanelScheduleAnAppointmentText;

    @FindBy(xpath = "//div[@class ='auto-contact-agent-preferred-date__section']/label")
    private WebElement sidePanelPreferredDateAndTimeLabel;

    @FindBy(xpath = "//input[@formcontrolname='preferredDate']")
    public WebElement sidePanelChooseADateEntryField;

    @FindBy(xpath = "//div[@aria-labelledby='schedule-agent-appointment']//mat-error")
    private WebElement sidePanelChooseADateEntryFieldErrorLabel;

    @FindBy(id = "timeslot-checkox")
    private WebElement sidePanelTimeSlotLabel;

    private static final String FIRST_TIMESLOT_XPATH = "//div[@class='auto-contact-agent-timeslot-checkbox']//mat-checkbox[1]";
    private static final String SECOND_TIMESLOT_XPATH = "//div[@class='auto-contact-agent-timeslot-checkbox']//mat-checkbox[2]";
    private static final String THIRD_TIMESLOT_XPATH = "//div[@class='auto-contact-agent-timeslot-checkbox']//mat-checkbox[3]";
    private static final String CHECKBOX_XPATH = "//input";
    private static final String LABEL_XPATH = "//label";

    @FindBy(xpath = FIRST_TIMESLOT_XPATH + CHECKBOX_XPATH)
    private WebElement sidePanelMorningCheckbox;

    @FindBy(xpath = FIRST_TIMESLOT_XPATH + LABEL_XPATH)
    private WebElement sidePanelMorningLabel;

    @FindBy(xpath = SECOND_TIMESLOT_XPATH + CHECKBOX_XPATH)
    private WebElement sidePanelAfternoonCheckbox;

    @FindBy(xpath = SECOND_TIMESLOT_XPATH + LABEL_XPATH)
    private WebElement sidePanelAfternoonLabel;

    @FindBy(xpath = THIRD_TIMESLOT_XPATH + CHECKBOX_XPATH)
    private WebElement sidePanelEveningCheckbox;

    @FindBy(xpath = THIRD_TIMESLOT_XPATH + LABEL_XPATH)
    private WebElement sidePanelEveningLabel;

    @FindBy(xpath = "//div[@aria-labelledby='timeslot-checkox']//mat-error")
    public WebElement sidePanelTimeSlotSelectionErrorLabel;

    @FindBy(id = "disclaimerText")
    private WebElement sidePanelDisclaimerText;

    @FindBy(xpath = "//p[contains(@class, 'auto-contact-agent-multiple-fields-missing')]")
    private WebElement sidePanelErrorsFoundInPageLabel;

    @FindBy(xpath = "//a[contains(@aria-label, 'Personal information')]")
    private WebElement sidePanelPersonalInformationLink;

    private static final String SIDE_PANEL_AGREE_SUBMIT_BUTTON_XPATH = "//div[@class='auto-contact-agent-confirmation-button']/button";
    @FindBy(xpath = SIDE_PANEL_AGREE_SUBMIT_BUTTON_XPATH)
    private WebElement sidePanelAgreeAndSubmitButton;

    @FindBy(id = "requestSubmittedHeading")
    private WebElement sidePanelRequestSubmittedLabel;

    @FindBy(className = "auto-schedule-appointment-heading")
    private WebElement sidePanelAppointmentRequestSubmittedLabel;

    @FindBy(id = "confirmationMessage")
    private WebElement sidePanelThanksForSubmittingRequestLabel;

    @FindBy(xpath = "//div[@class='auto-contact-agent-confirmation-schedule__section']//label")
    private WebElement sidePanelAppointmentRequestSubmittedAgentNameLabel;

    @FindBy(xpath = "//div[@class='auto-contact-agent-confirmation-date__section']//label")
    private WebElement sidePanelAppointmentRequestSubmittedDateLabel;

    final String SIDE_PANEL_SUBMITTED_TIMESLOT_LABEL_XPATH = "//div[contains(@class,'tui-input-text')]//div";

    @FindBy(xpath = SIDE_PANEL_SUBMITTED_TIMESLOT_LABEL_XPATH)
    private List<WebElement> sidePanelAppointmentRequestSubmittedTimeslotLabels;

    @FindBy(className = "auto-contact-agent-confirmation-button")
    private WebElement sidePanelAppointmentRequestSubmittedDoneButton;

    public AgentDetails() throws Exception {
    }

    public boolean isYourAgentLabelDisplayed() {
        return isElementVisible(yourAgentLabel, 5) && getTextFromElement(yourAgentLabel).equals("Your agent");
    }

    public boolean isQuestionsDisplayed() {
        return isElementVisible(yourAgentLabel, 5) && getTextFromElement(yourAgentLabel).equals("Questions?");
    }

    public boolean isAgentNamePresent() {
        return isElementPresent(By.xpath(AGENT_NAME_XPATH), 5);
    }

    public boolean isContactMeLinkDisplayed() {
        return isElementVisible(contactMeButton, 5) && getTextFromElement(contactMeButton).equals("Contact me");
    }

    public boolean isContactUsLinkDisplayed() {
        return isElementVisible(contactMeButton, 5) && getTextFromElement(contactMeButton).equals("Contact us");
    }

    public boolean isContactFarmersRepresentativeLinkDisplayed() {
        return isElementVisible(contactFarmersRepresentativeLink, 3) &&
        		getAttributeData(contactFarmersRepresentativeLink, ARIA_LABEL).startsWith(CONTACT_FARMERS_REPRESENTATIVE);
    }

    public String getAssignedAgentName() {
        return getTextFromElement(agentName);
    }

    public String getQuoteNumber() {
        String[] quoteSectionStrings = getTextFromElement(quoteNumberSection).split(SPACE);
        //check if it's numeric
        Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
        for (String value : quoteSectionStrings) {
            if (pattern.matcher(value).matches()) {
                return value;
            }
        }
        return EMPTY_STRING;
    }

    public void closeContactMeDialog() {
        waitAndClickElement(sidePanelCloseButton);
    }

    public boolean validateSidePanelLabels() {
        waitElementBeVisible(sidePanelTitle);
        boolean validationResult = isExpectedTextDisplayed(sidePanelTitle, "Contact agent");
        validationResult &= isExpectedTextDisplayed(sidePanelYourAgentLabel, "Your agent");
        validationResult &= isExpectedTextDisplayed(sidePanelRequiredFieldLabel, "*Required field");
        validationResult &= isExpectedTextDisplayed(sidePanelReasonForContactLabel, "Reason for contact*");
        validationResult &= isExpectedTextDisplayed(sidePanelContactInfoLabel, "Contact information*");
        validationResult &= isExpectedTextDisplayed(sidePanelPreferredContactLabel, "Preferred contact method(s)");
        validationResult &= isExpectedTextDisplayed(sidePanelExistingCustomerLabel, "Are you an existing Farmers customer?*");
        validationResult &= isElementPresentByXPath(EXISTING_CUSTOMER_RADIOBUTTON_XPATH);
        validationResult &= isElementPresentByXPath(NOT_EXISTING_CUSTOMER_RADIOBUTTON_XPATH);
        validationResult &= isExpectedTextDisplayed(sidePanelScheduleAnAppointmentLabel, "Schedule an appointment (optional)");
        validationResult &= isExpectedTextDisplayed(sidePanelScheduleAnAppointmentText, "Submitting this form is not a confirmation of an appointment. Your Farmers agent will need to confirm the time and date of your appointment.");
        validationResult &= isExpectedTextDisplayed(sidePanelPreferredDateAndTimeLabel, "Preferred date and time");
        validationResult &= isExpectedTextDisplayed(sidePanelTimeSlotLabel, "Time slot (select all that apply)");
        validationResult &= isExpectedTextDisplayed(sidePanelMorningLabel, MORNING);
        validationResult &= isExpectedTextDisplayed(sidePanelAfternoonLabel, AFTERNOON);
        validationResult &= isExpectedTextDisplayed(sidePanelEveningLabel, EVENING);
        validationResult &= isExpectedTextContainedInElement(sidePanelDisclaimerText, "We sometimes reach out to consumers by call and/or text to provide helpful information about our products or services. By clicking \"Agree & submit\" you agree that marketing calls and/or texts can be made to the phone number(s) provided on behalf of Farmers\u00ae, Foremost\u00ae, Bristol West\u00ae, Farmers Life\u00ae and 21st Century\u00ae insurance entities or their representatives using an automated telephone dialing system and/or an artificial or pre-recorded voice. Your consent is not a condition of purchase.");
        validationResult &= isExpectedTextDisplayed(sidePanelPersonalInformationLink, "Personal information use");
        validationResult &= isExpectedTextDisplayed(sidePanelAgreeAndSubmitButton, "Agree & submit");
        return validationResult;
    }

    public void validateSidePanelErrorMessages(FarmersSoftAssert fsa) throws Exception {
        waitElementBeVisible(sidePanelTitle);
        setSidePanelCustomerContactEmail("Bogus");
        setSidePanelCustomerContactPhoneNumber("999");
        setSidePanelPreferedDate("999");
        scrollAndClickOnHiddenElement(sidePanelAgreeAndSubmitButton);
        fsa.assertEquals(getTextFromElement(sidePanelReasonForContactErrorMessageLabel), "Please provide reason for contact.");
        fsa.assertEquals(getTextFromElement(sidePanelExistingCustomerErrorMessageLabel), "This is required.", "Existing customer error message check");
        fsa.assertEquals(getTextFromElement(sidePanelTimeSlotSelectionErrorLabel), "This is required.", "Time slot error message check");
        fsa.assertEquals(getTextFromElement(sidePanelErrorsFoundInPageLabel), "One or more required fields is incomplete or incorrect. Please review.", "Errors found check");
        testStep("Agent contact me side sheet error messages validation");
    }

    /*
    validate reason to contact renders only 300 chars
     */
    public void validateContactReasonFieldMaxChar(FarmersSoftAssert fsa) throws Exception {
        setSidePanelReasonForContact(RandomStringUtils.randomAlphabetic(301));
        fsa.assertEquals(getTextFromElement(remainingCharacter), "Remaining 0 characters");
        testStep("Agent contact me side panel contact reason max char validation");
    }

    public String getSidePanelAssignedAgentName() {
        return getTextFromElement(waitElementBeVisible(sidePanelAgentName));
    }

    private String getSidePanelAssignedAgentAddress() {
        return getTextFromElement(sidePanelAgentAddress);
    }

    private String getSidePanelAssignedAgentEmail() {
        return getTextFromElement(sidePanelAgentEmail);
    }

    private String getSidePanelAssignedAgentPhoneNumber() {
        return getTextFromElement(sidePanelAgentPhoneNumber);
    }

    private void setSidePanelReasonForContact(String reasonForContactingAgent) {
        waitElementBeVisibleClickable(sidePanelReasonForContactTextArea);
        sendKeysToElement(sidePanelReasonForContactTextArea, reasonForContactingAgent);
    }

    public String getSidePanelCustomerFirstName() {
        return getAttributeData(sidePanelCustomerFirstName, VALUE);
    }

    public String getSidePanelCustomerLastName() {
        return getAttributeData(sidePanelCustomerLastName, VALUE);
    }

    public String getSidePanelCustomerEmailId() {
        return getAttributeData(sidePanelCustomerEmailEntryField, VALUE);
    }

    public String getSidePanelCustomerPhoneNumber() {
        return getAttributeData(sidePanelCustomerPhoneNumberEntryField, VALUE);
    }

    private void setSidePanelCustomerContactEmail(String customerEmailAddress) {
        sendKeysToElement(sidePanelCustomerEmailEntryField, customerEmailAddress);
    }

    private void setSidePanelCustomerContactPhoneNumber(String customerPhoneNumber) {
        sendKeysToElement(sidePanelCustomerPhoneNumberEntryField, customerPhoneNumber);
    }

    private void setSidePanelExistingCustomer(boolean isExistingCustomer) {
        if (isExistingCustomer) {
            setCheckboxTo(sidePanelYesExistingCustomerRadioButton, true);
        } else {
            setCheckboxTo(sidePanelNoExistingCustomerRadioButton, true);
        }
    }

    private void setSidePanelPreferedDate(String mmddyyyy) {
        clearOutFieldUsingBackSpace(sidePanelChooseADateEntryField);
        sendKeysToElement(sidePanelChooseADateEntryField, mmddyyyy);
    }

    private void setSidePanelTimeSlot(String period) {
        switch (period) {
            case MORNING:
                setCheckboxTo(sidePanelMorningCheckbox, true);
                break;
            case AFTERNOON:
                setCheckboxTo(sidePanelAfternoonCheckbox, true);
                break;
            case EVENING:
                setCheckboxTo(sidePanelEveningCheckbox, true);
                break;
            default:
                throw new IllegalArgumentException("Unknown period " + period);
        }
    }

    public String getSidePanelQuoteNumber() {
        return getAttributeData(sidePanelQuoteNumber, VALUE);
    }

    public void clickAgreeAndSubmitButton() throws Exception {
        scrollElementToMiddle(sidePanelAgreeAndSubmitButton);
        clickOnHiddenElement(sidePanelAgreeAndSubmitButton);
        waitForSpinnerToBeGone();
    }

    public void validateAppointmentRequestSubmittedLabels(FarmersSoftAssert fsa) throws Exception {
        AppStore.Data.AgentData agentData = getSessionStorageAppStore().getData().getAgentData();
        String agentFullName = agentData.getFirstName() + SPACE + agentData.getLastName();
        wait.until(ExpectedConditions.textToBePresentInElement(sidePanelRequestSubmittedLabel, "Request submitted"));
        fsa.assertEquals(getTextFromDoneButton(), "Done", "Agent contact me submit side sheet Done button text validated");
        fsa.assertEquals(getAppointmentRequestSubmittedAgentName(), agentFullName, "Agent full name is displayed and matching");
        fsa.assertEquals(getTextFromElement(sidePanelRequestSubmittedLabel), "Request submitted", "Agent contact request submitted side panel label");
        fsa.assertEquals(getTextFromElement(sidePanelAppointmentRequestSubmittedLabel), "Appointment request submitted", "Agent contact Appointment Request submitted side panel label");
        fsa.assertEquals(getTextFromElement(sidePanelThanksForSubmittingRequestLabel), "Thank you for submitting your request!", "Agent contact Thank  you message");
        testStep("Agent section validateAppointmentRequestSubmittedLabels");

    }

    public String getAppointmentRequestSubmittedAgentName() {
        return getTextFromElement(waitElementBeVisible(sidePanelAppointmentRequestSubmittedAgentNameLabel));
    }

    public String getAppointmentRequestSubmittedDate() {
        return getTextFromElement(sidePanelAppointmentRequestSubmittedDateLabel);
    }

    public List<String> getAppointmentRequestSubmittedTimeslots() {
        List<String> selectedTimeSlots = new ArrayList<>();
        for (WebElement timeSlot : sidePanelAppointmentRequestSubmittedTimeslotLabels) {
            selectedTimeSlots.add(getTextFromElement(timeSlot));
        }
        return selectedTimeSlots;
    }

    public void clickRequestSubmittedDoneButton() {
        waitAndClickElement(sidePanelAppointmentRequestSubmittedDoneButton);
    }


    public void fillOutContactMeForm(AutoApplicant applicant, String date, int timeSlot) throws Exception {
        String reasonForContact = "Need to discuss policy rate increase";
        AgentDetails agentDetails = new AgentDetails();
        agentDetails.setSidePanelReasonForContact(reasonForContact);
        agentDetails.setSidePanelCustomerContactEmail(applicant.getEmail());
        agentDetails.setSidePanelCustomerContactPhoneNumber(applicant.getPhoneNumber());
        agentDetails.setSidePanelExistingCustomer(false);
        agentDetails.setSidePanelPreferedDate(date);
        setContactTimeslot(timeSlot);
    }

    private void setContactTimeslot(int randomTimeslot) {
        switch (randomTimeslot) {
            case 0:
                setSidePanelTimeSlot(MORNING);
                break;
            case 1:
                setSidePanelTimeSlot(AFTERNOON);
                break;
            case 2:
                setSidePanelTimeSlot(EVENING);
                break;
            case 3:
                setSidePanelTimeSlot(MORNING);
                setSidePanelTimeSlot(AFTERNOON);
                break;
            case 4:
                setSidePanelTimeSlot(MORNING);
                setSidePanelTimeSlot(EVENING);
                break;
            case 5:
                setSidePanelTimeSlot(AFTERNOON);
                setSidePanelTimeSlot(EVENING);
                break;
            case 6:
                setSidePanelTimeSlot(MORNING);
                setSidePanelTimeSlot(AFTERNOON);
                setSidePanelTimeSlot(EVENING);
                break;
            default:
                throw new IllegalArgumentException("Unknown timeslot " + randomTimeslot);
        }
    }

    public void validateAgentContactDetailsAndLinks(FarmersSoftAssert fsa) throws Exception {
        AppStore sessionStorageAppStore = this.getSessionStorageAppStore();
        AppStore.Data.AgentData agentData = sessionStorageAppStore.getData().getAgentData();
        AppStore.Data.AgentData.Address agentAddress = agentData.getAddress();
        String fullAgentAddress = agentAddress.getStreet() + COMMA + SPACE + agentAddress.getCity() + COMMA + SPACE + agentAddress.getState() + SPACE + agentAddress.getZip();
        fsa.assertEquals(getSidePanelAssignedAgentAddress(), fullAgentAddress, "Validate displayed agent address against the agent call response");
        fsa.assertTrue(sidePanelAgentAddress.isEnabled(), "Validate agent address text is clickable");
        String baseWindowHandle = driver().getWindowHandle();
        waitAndClickElement(sidePanelAgentAddress);
        Set<String> windowHandles = driver().getWindowHandles();

        for (String windowHandle : windowHandles) {
            if (!windowHandle.equals(baseWindowHandle)) {
                driver().switchTo().window(windowHandle);
                wait.until(ExpectedConditions.titleContains("Google Maps"));
                fsa.assertTrue(driver().getTitle().contains("Google Maps"), "New tab should open google maps");
                driver().close();
            }
        }
        driver().switchTo().window(baseWindowHandle);

        AppStore.Data.AgentData.Communication agentCommunicationDetails = agentData.getCommunication();
        String agentEmailId = agentCommunicationDetails.getEmailId().getEmailAddress();
        fsa.assertEquals(getSidePanelAssignedAgentEmail(), agentEmailId, "Validate displayed agent email id against the agent call response");
        fsa.assertTrue(sidePanelAgentEmail.isEnabled(), "Validate agent email text is clickable");
        fsa.assertEquals(getAttributeData(sidePanelAgentEmail,HREF), String.format("mailto:%s", agentEmailId));
        String agentPhoneNumber = agentCommunicationDetails.getPhoneNumber().getPhoneNumber();
        fsa.assertEquals(getSidePanelAssignedAgentPhoneNumber().replace("(", EMPTY_STRING).replace(SPACE, EMPTY_STRING).replace(")", EMPTY_STRING).replace("-", EMPTY_STRING), agentPhoneNumber, "Validate displayed agent phone number against the agent call response");
        fsa.assertTrue(sidePanelAgentPhoneNumber.isEnabled(), "Validate agent email text is clickable");
        fsa.assertEquals(getAttributeData(sidePanelAgentPhoneNumber,HREF), String.format("tel:1-%s", agentPhoneNumber), "Agent Phone number check");
        clickRequestSubmittedDoneButton();
        testStep("Agent contact me side panel agent contact details and links validation");
    }


    public void validateDateField(FarmersSoftAssert fsa) throws Exception {
        LocalDate today = LocalDate.now();
        Month month = today.getMonth();
        int year = today.getYear();
        String formattedToday = today.format(DateTimeFormatter.ofPattern(MM_DD_YYYY));
        LocalDate yesterday = today.minusDays(1);
        String formattedYesterday = yesterday.format(DateTimeFormatter.ofPattern(MM_DD_YYYY));
        setSidePanelPreferedDate(formattedYesterday);
        sendKeysToElement(sidePanelChooseADateEntryField, Keys.TAB);
        // user should not be able to choose past date
        fsa.assertEquals(getTextFromElement(sidePanelChooseADateEntryFieldErrorLabel), "Please select a valid date.", "Date in past check");
        // today is also disabled
        setSidePanelPreferedDate(formattedToday);
        sendKeysToElement(sidePanelChooseADateEntryField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(sidePanelChooseADateEntryFieldErrorLabel), "Please select a valid date.", "Using today check");

        int bound = YearMonth.of(year, month).lengthOfMonth();
        List<LocalDate> weekends = new ArrayList<>();
        for (int day = 1; day <= bound; day++) {
            LocalDate date = LocalDate.of(year, month, day);

            if (date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY) {
                weekends.add(date);
            }
        }
        //validate user is not able to select weekend days
        for (LocalDate weekend : weekends) {
            String formattedWeekend = weekend.format(DateTimeFormatter.ofPattern(MM_DD_YYYY));
            setSidePanelPreferedDate(formattedWeekend);
            sendKeysToElement(sidePanelChooseADateEntryField, Keys.TAB);
            fsa.assertEquals(getTextFromElement(sidePanelChooseADateEntryFieldErrorLabel), "Please select a valid date.", "Date selection text check");

        }
        testStep("Agent contact me side sheet date input field validation");
    }


    /*
    Validate user is able to click on agree and submit without entering the time and date
    Validate only the agent name is displayed in the request submitted page if user doesn’t select the any date and time
    */
    public void validateNoDateOrTimeSlotScenario(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {

        clickAgentContactMeButton();
        waitElementBeVisible(sidePanelTitle);
        setSidePanelReasonForContact("Just adding test case");
        setSidePanelExistingCustomer(false);
        setSidePanelCustomerContactPhoneNumber(applicant.getPhoneNumber());
        setSidePanelExistingCustomer(false);
        clickAgreeAndSubmitButton();
        waitForSpinnerToBeGone();
        validateAppointmentRequestSubmittedLabels(fsa);
        fsa.assertEquals(getTextFromElement(sidePanelAppointmentRequestSubmittedDateLabel).replace(SPACE, EMPTY_STRING), EMPTY_STRING, "Date label should not be displayed if customer did not select any date");
        fsa.assertFalse(isElementPresent(By.xpath(SIDE_PANEL_SUBMITTED_TIMESLOT_LABEL_XPATH)), "Timeslots should not be present after submission when user does not select any date");
        clickRequestSubmittedDoneButton();
    }

    /*
        validate user is shown valid error when only date or time is added
     */
    public void validateUserIsShownValidErrorWhenOnlyDateOrTimeIsAdded(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        clickAgentContactMeButton();
        waitElementBeVisibleClickable(sidePanelTitle);
        LocalDate aWeekFromToday = LocalDate.now().plusWeeks(1);
        String aWeekFromNow = aWeekFromToday.format(DateTimeFormatter.ofPattern("EEE MMM d, yyyy"));
        int randomTimeslot = ThreadLocalRandom.current().nextInt(0, 7);
        setSidePanelReasonForContact("validate user is shown valid error when only date or time is added");
        setSidePanelPreferedDate(aWeekFromNow);
        setSidePanelCustomerContactEmail(applicant.getEmail());
        setSidePanelCustomerContactPhoneNumber(applicant.getPhoneNumber());
        setSidePanelExistingCustomer(false);
        clickAgreeAndSubmitButton();
        String expectedThisIsRequiredText = "This is required.";
        String actualThisIsRequiredText = getTextFromElement(sidePanelTimeSlotSelectionErrorLabel);
        fsa.assertTrue(waitElementBeVisible(sidePanelTimeSlotSelectionErrorLabel).isDisplayed(), "This is required should be displayed for timeslot section when user selects date but not timeslots");
        fsa.assertEquals(actualThisIsRequiredText, expectedThisIsRequiredText, "This is required text check");
        closeContactMeDialog();
        clickAgentContactMeButton();
        setSidePanelReasonForContact("validate user is shown valid error when only date or time is added");
        setSidePanelCustomerContactEmail(applicant.getEmail());
        setSidePanelCustomerContactPhoneNumber(applicant.getPhoneNumber());
        setSidePanelExistingCustomer(true);
        setContactTimeslot(randomTimeslot);
        clickAgreeAndSubmitButton();
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(sidePanelChooseADateEntryFieldErrorLabel)), "Please provide the preferred date", "Preferred date check");
        closeContactMeDialog();
    }

    private String getTextFromDoneButton() {
        return getTextFromElement(sidePanelAppointmentRequestSubmittedDoneButton);
    }

    public void validateADA_AgentSideSheet() throws Exception {
        if (isADATestingEnabled() && isAgentNamePresent()) {
            clickAgentContactMeButton();
            clickAgreeAndSubmitButton();
            performADATesting(this.getClass().getSimpleName() + "_AgentSideSheet", MARKETING_IT, ACE_AUTO);
            waitAndClickElement(closeIcon);
        }
    }

    public void validateAgentSectionAtBottom(FarmersSoftAssert fsa, boolean isAddressExpected) throws Exception {
        scrollToBottomOfPage();
        AppStore.Data.AgentData agentData = getSessionStorageAppStore().getData().getAgentData();
        String agentFullName = agentData.getFirstName() + SPACE + agentData.getLastName();
        String agentPhoneNumber = agentData.getCommunication().getPhoneNumber().getPhoneNumber();
        String formattedPhoneNumber = String.format("(%s) %s-%s", agentPhoneNumber.substring(0, 3), agentPhoneNumber.substring(3, 6), agentPhoneNumber.substring(6));
        fsa.assertEquals(getTextFromElement(yourAgentLabel), "Your agent", "Your agent label validated");
        fsa.assertEquals(getTextFromElement(agentName), agentFullName, "Agent full name is validated");
        if(!StringUtils.isEmpty(agentPhoneNumber)) {
            fsa.assertTrue(phoneIcon.isDisplayed() && phoneIcon.isEnabled(), "Phone icon is displayed and enabled");
            fsa.assertEquals(getTextFromElement(phoneNumber), formattedPhoneNumber, "Phone number is validated");
            fsa.assertTrue(phoneIcon.isEnabled(), "Phone number is enabled");
        }
        String emailAddress = agentData.getCommunication().getEmailId().getEmailAddress();
        if(!StringUtils.isEmpty(emailAddress)) {
            fsa.assertTrue(emailIcon.isDisplayed() && emailIcon.isEnabled(), "Email icon is displayed and enabled");
            fsa.assertEquals(getTextFromElement(agentEmail), emailAddress, "Agent email address validated");
            fsa.assertTrue(agentEmail.isEnabled(), "Agent email is enabled");
        }
        AppStore.Data.AgentData.Address address = agentData.getAddress();
        if (!address.getStreet().contains("Po Box") && isAddressExpected) {
            String formattedAgentAddress = String.format("%s %s, %s %s", address.getStreet().replace("|", ", "), address.getCity(), address.getState(), address.getZip());
            fsa.assertEquals(getTextFromElement(agentAddress).replace(SPACE, EMPTY_STRING), formattedAgentAddress.replace(SPACE, EMPTY_STRING), "Agent address validated");
            waitAndClickElement(agentAddress);
            wait.until(ExpectedConditions.numberOfWindowsToBe(2));
            Set<String> windowHandles = driver().getWindowHandles();
            String currentWindowHandle = driver().getWindowHandle();

            // Switch to the next tab (second tab) and validate it is google maps and switch to main window
            for (String handle : windowHandles) {
                if (!handle.equals(currentWindowHandle)) {
                    driver().switchTo().window(handle);
                    wait.until(ExpectedConditions.urlContains("www.google.com/maps"));
                    driver().close();
                    driver().switchTo().window(currentWindowHandle);
                    break;
                }
            }
            waitAndClickElement(agentAddress);
            wait.until(ExpectedConditions.numberOfWindowsToBe(2));
            currentWindowHandle = driver().getWindowHandle();
            windowHandles = driver().getWindowHandles();
            // Switch to the next tab (second tab) and validate it is google maps and switch to main window
            for (String handle : windowHandles) {
                if (!handle.equals(currentWindowHandle)) {
                    driver().switchTo().window(handle);
                    wait.until(ExpectedConditions.urlContains("www.google.com/maps"));
                    driver().close();
                    driver().switchTo().window(currentWindowHandle);
                    break;
                }
            }
        }
    }
}
