package com.farmers.ffq.ace.mobilehome;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.farmers.ffq.ace.hrc.common.AceHRCContactInfoBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;

public class AceMobileHomeLastStepPage extends AceHRCContactInfoBasePage {

    @FindBy(xpath = "//span[contains(.,'Short-term')]/preceding-sibling::i")
    private WebElement shortTermRentalIcon;

    @FindBy(xpath = "//span[contains(.,'Vacant')]/preceding-sibling::i")
    private WebElement vacantDwellingIcon;

    @FindBy(xpath = "//i[contains(@style,'recreational')]")
    private WebElement rvIcon;

    @FindBy(xpath = "//i[contains(@style,'motorcycle_rebrand')]")
    private WebElement motorcycleIcon;

    @FindBy(xpath = "//i[contains(@style,'offroad_rebrand')]")
    private WebElement offroadVehicleIcon;

    @FindBy(xpath = "//i[contains(@style,'rebrand_boat')]")
    private WebElement boatIcon;

    public AceMobileHomeLastStepPage() throws Exception {
        super();
    }

    public void verifyPageContent(FarmersSoftAssert fsa, ApplicantAceHome mobilehomeApplicant) throws Exception {
		String testCategory = mobilehomeApplicant.getTestCategory();
		boolean isForemostAffiliateQuote = testCategory.equals(USAA);
		String activeStep = getActiveStep(testCategory);
        validateHeaderAndSubHeaderContactInfoPage(fsa);
        validateSaveWithBundleSection(fsa, mobilehomeApplicant, isForemostAffiliateQuote);
        validateContentOfMailingAndOtherMailingAddress(fsa);
        validateContentOfContactInfo(fsa);
        validateDisclaimer(fsa, isForemostAffiliateQuote);
        validateContentOfAgreeAndSubmit(fsa);
        validatePageLinksText(fsa, activeStep);
		if (!isForemostAffiliateQuote) {
			validatePageLinksNavigationTitles(fsa);
		}
    }

    private void validateSaveWithBundleSection(FarmersSoftAssert fsa, ApplicantAceHome mobilehomeApplicant, boolean isForemostAffiliateQuote) throws Exception {
    	if (isForemostAffiliateQuote) {
    		String expectedHeader = "Save more when you bundle";
    		String expectedHeaderNote = "Select which eligible Foremost products you would like to bundle with:";
    		String expectedBundleAndSaveTipHeader = "Bundle and save";
    		String expectedBundleAndSaveDescription = "A bundle discount will be applied to your home quote today. " +
    				"You will have to purchase the policies you select to retain the discount. " +
    				"Please mention this when you're on the phone with a Foremost representative for help completing the process.";
    		fsa.assertEquals(getTextFromElement(bundleSaveHeading), expectedHeader, "Bundle Save section header check");
    		fsa.assertNotEquals(getTextFromElement(bundleSaveHeadingNote), expectedHeaderNote, "Bundle Save section header note check - DE326964");
    		if (isUseMobileViewEnabled()) {
    			waitAndClickElement(saveBundleInfoIcon);
    			fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalTitle, 3)), "How it works", "Bundle and Save info modal title matching");
    			fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalText, 3)), expectedBundleAndSaveDescription, "Bundle and Save info modal text matching");
    			waitAndClickElement(infoModalButtonClose);
    		} else {
    			fsa.assertEquals(getTextFromElement(bundleAndSaveTipHeader), expectedBundleAndSaveTipHeader, "Bundle Save tip header verification");
    			fsa.assertNotEquals(getTextFromElement(bundleAndSaveTipDescription), expectedBundleAndSaveDescription, "Bundle Save tip description verification - DE326965");
    		}
    		List<WebElement> listOfExpectedBundleIcons = new ArrayList<>(Arrays.asList(shortTermRentalIcon, vacantDwellingIcon, rvIcon, motorcycleIcon, offroadVehicleIcon, boatIcon));
    		// validate the list of the checkboxes
    		List<String> listOfExpectedBundleLabels = new ArrayList<>(Arrays.asList("Short-term rental property", "Vacant dwelling", "Recreational vehicle", "Motorcycle", "Off-road vehicle", "Boat"));
    		List<String> listOfActualBundleLabels = saveBundleCheckboxesText.stream().map(each -> getAttributeData(each, "innerText").strip()).collect(Collectors.toList());
    		for (WebElement icon:listOfExpectedBundleIcons) {
    			fsa.assertTrue(isElementDisplayed(icon, 2), icon + " is displayed");
    		}
    		fsa.assertEquals(listOfActualBundleLabels, listOfExpectedBundleLabels, "listOfActualBundleLabels matches listOfExpectedBundleLabels");
    		fsa.assertEquals(listOfActualBundleLabels.size(), listOfExpectedBundleIcons.size(), "Labels found and expected icon counts match");
     	} else {
            validateBundleSaveSection(mobilehomeApplicant, fsa, MOBILE_HOME);
    	}
	}

	public void validateSnackbarMessages(ApplicantAceHome mobilehomeApplicant,  FarmersSoftAssert fsa) {
        if (!mobilehomeApplicant.getStateCode().equals(CA)) {
            mobilehomeApplicant.setEarlyShoppingFactor(getFormattedDateAfter8days());
            enterPolicyStartDate(mobilehomeApplicant);
            fsa.assertTrue(isSnackBarMessageDisplayed("We added an early shopper discount!"), "Last step page - Early shopper discount added snackbar message found.");
            sleep(5);
            String EXPECTED_EARLY_SHOPPING_DISCOUNT_DESCRIPTION = "If your policy start date is 7 or more days from today, you get an early shopping discount. " +
                    "You can start your policy up to 30 days in the future.";
            try {
                if (!isUseMobileViewEnabled()) {
                    waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoTitle, 3);
                    fsa.assertEquals(getTextFromElement(earlyDiscountOrEstimatedClosingDateInfoTitle), EXPECTED_EARLY_SHOPPING_INFO_TITLE, "Early shopper help title");
                    fsa.assertEquals(getTextFromElement(earlyDiscountOrEstimatedClosingDateInfoDescription), EXPECTED_EARLY_SHOPPING_DISCOUNT_DESCRIPTION, "Early shopper help content");
                } else {
                    waitAndClickElement(earlyShoppingInfoIcon);
                    waitElementBeVisible(infoModalButtonClose, 3);
                    fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalTitle)), EXPECTED_EARLY_SHOPPING_INFO_TITLE, "Early shopper help title");
                    fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalText)), EXPECTED_EARLY_SHOPPING_DISCOUNT_DESCRIPTION, "Early shopper help content");
                    waitAndClickElement(infoModalButtonClose);
                }
            } catch (TimeoutException te) {
                fsa.fail("Early discount help section not found");
                if (isElementDisplayed(infoModalButtonClose, 2)) {
                    clickElement(infoModalButtonClose);
                }
            }
            mobilehomeApplicant.setEarlyShoppingFactor(getFormattedTomorrowDate());
            enterPolicyStartDate(mobilehomeApplicant);
            sleep(3);
            fsa.assertTrue(isSnackBarMessageDisplayed("Early shopper discount removed."), "Last step page - Early shopper discount removed snackbar message found.");
            mobilehomeApplicant.setEarlyShoppingFactor(getFormattedDateAfter8days());
            mobilehomeApplicant.getDiscounts().stream().forEach(discount -> discount.setAutoInsurance(true));
            enterPolicyStartDate(mobilehomeApplicant);
            sleep(5);
        }
		boolean isForemostAffiliateQuote = mobilehomeApplicant.getTestCategory().equals(USAA);
		if (isForemostAffiliateQuote) {
			selectBundle(true, "Short");
			selectBundle(true, "Vacant");
			selectBundle(true, "Motorcycle");
		} else {
			selectBundle(true, AUTO);
			selectBundle(true, LIFE);
			selectBundle(true, UMBRELLA);
		}
        fsa.assertTrue(isSnackBarMessageDisplayed("We added a multi-policy discount"), "Last step page - Multi-policy discount added snackbar message found.");
        mobilehomeApplicant.setEarlyShoppingFactor(getFormattedTomorrowDate());
		if (isForemostAffiliateQuote) {
			selectBundle(false, "Short");
			selectBundle(false, "Vacant");
			selectBundle(false, "Motorcycle");
		} else {
			selectBundle(false, AUTO);
			selectBundle(false, LIFE);
			selectBundle(false, UMBRELLA);
		}
        sleep(3);
        fsa.assertTrue(isSnackBarMessageDisplayed("Multi-policy discount removed"), "Last step page - Multi-policy discount removed snackbar message found.");
    }

    public void fillOutLastStepPageAndContinue(ApplicantAceHome mobilehomeApplicant) throws Exception {
        enterPolicyStartDate(mobilehomeApplicant);
        fillOutBundleAndSave(mobilehomeApplicant, MOBILE_HOME);
        enterMailingAddress(mobilehomeApplicant);
        enterEmailIdAndPhoneNumberInContactInfoPage(mobilehomeApplicant);
        clickOnAgreeAndSubmitButton();
        waitElementBeInvisible(agreeAndSubmitButton);
        longWaitForElementToBeGoneByXpath("//app-rc2-loading");
		while (isElementPresent(By.xpath("//app-rc2-loading"), 2)) {
			//keep waiting for the RC2 page to be dismissed...
			sleep(2);
		}
    }

    private void validateDisclaimer(FarmersSoftAssert fsa, boolean isForemostAffiliate) {
    	if(isForemostAffiliate) {
            String EXPECTED_ESIGN_DISCLAIMER = "By clicking \"Agree and submit\", you agree to these ESIGN terms and conditions and to receive marketing calls and texts as detailed below.";
            String EXPECTED_CONTACT_DISCLAIMER = "We sometimes call and/or text consumers to provide helpful information about products and services. " +
            		"By clicking \"Agree and submit\", you consent to receive marketing calls and texts from these Foremost\u00ae entities and their representatives using an automated telephone dialing system, AI-generated voice, and by artificial or pre-recorded voice, even if your number(s) is/are listed on national, state, or business do-not-call registries. " +
            		"Consent is not a condition of purchase. You can call 800-315-1122 as an alternate contact method. Message and data rates may apply.";
            scrollToElement(pageFooterDisclaimer);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageFooterDisclaimerEsign, 5)), EXPECTED_ESIGN_DISCLAIMER, "ESIGN disclaimer verification");
            fsa.assertNotEquals(getTextFromElement(waitElementBeVisible(pageFooterDisclaimer, 5)), EXPECTED_CONTACT_DISCLAIMER, "Contact disclaimer verification - DE326966");
    	} else {
            validateDisclaimerOnContactInfoPage(fsa);
    	}
    }
}
