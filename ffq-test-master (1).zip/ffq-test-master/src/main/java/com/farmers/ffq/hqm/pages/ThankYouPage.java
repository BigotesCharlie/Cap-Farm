package com.farmers.ffq.hqm.pages;

import com.farmers.ffq.datatransferobjects.hqm.AgentInfoHQM;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.QuoteRateHQM;
import com.farmers.ffq.datatransferobjects.hqm.StaticContentHQM;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import javax.annotation.Nullable;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Thank You Page - Home Quote Modernization (HQM).
 */

public class ThankYouPage extends HqmBasePage {

	@FindBy(xpath = "//farmers-home-quote-thank-you//div/p[text()='QUOTE NUMBER' or text()='HOME QUOTE NUMBER']/../p[2]")
	private WebElement textQuoteNumber;

	@FindBy(xpath = "//farmers-home-quote-thank-you//div/p[text()='ESTIMATED MONTHLY PREMIUM' or text()='ESTIMATED PRICE']/../p[2]")
	private WebElement textEstimatedPremium;

    @FindBy(xpath = "//farmers-home-quote-thank-you//a/img[@alt='Farmers Insurance Logo']")
    private WebElement linkFarmersLogo;

    @FindBy(xpath = "//farmers-home-quote-thank-you//h1")
    private WebElement pageTitle;

    @FindBy(xpath = "//farmers-home-quote-thank-you//p[contains(@class,'tui-subtitle-text-1')][1]")
    private WebElement pageSubTitle1;

    @FindBy(xpath = "//farmers-home-quote-thank-you//p[contains(@class,'tui-subtitle-text-1')][2]")
    private WebElement pageSubTitle2;

    @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'need-help-caption')]")
    private WebElement pageFooter1;

    @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'need-help-caption')]/../p")
    private WebElement pageFooter2;

    @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'PoliticalAgent')]//a[@id='phoneIcon']")
    private WebElement linkCallFarmersPA;

    @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'tui-subtitle-text-1')]")
    private WebElement pageFooterRedirect;

    @FindBy(xpath = "//farmers-home-quote-thank-you//div[contains(@class,'agents-Info')]//span[contains(@class,'quote-agent-name')]")
    private WebElement agentNameFooter;

    @FindBy(xpath = "//farmers-home-quote-thank-you//span[contains(@class,'quote-agent-p')]")
    private WebElement agentInfoFooter;

    @FindBy(xpath = "//farmers-home-quote-thank-you//img[contains(@class,'agent-img')]")
    private WebElement agentImage;

    @FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='emailTagId']//div/mat-icon[text()='email']/../.." +
            "/div[contains(@class,'body-two')]")
    private WebElement agentEmailAddress;

    @FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='phnTagId']//div/mat-icon[text()='phone']/../.." +
            "/div/span[contains(@class,'body-two')]")
    private WebElement agentPhoneNumber;

    @FindBy(xpath = "//farmers-home-quote-thank-you//a[@id='locTagId']//div/mat-icon[text()='place']/../.." +
            "/div/span[contains(@class,'body-two')]")
    private WebElement agentAddress;

    private static final String PAGE_TITLE_TEXT = "Thank you for choosing Farmers Insurance";

    private static final String PAGE_SUBTITLE1_TEXT = "Ready to purchase? Please call %s and reference your quote number. " +
            "A Farmers representative is standing by to assist you.";

    private static final String PAGE_SUBTITLE2_TEXT = "Below are the details of your quote. A quote summary will be emailed to you shortly.";
    private static final String PAGE_SUBTITLE2_TEXT_CA = "Below are the details of your quote.";

    private static final String PAGE_FOOTER2_TEXT = "A Farmers Insurance\u00ae Representative is available if\nyou have any questions.";

    private static final String PAGE_FOOTER_REDIRECT = "In the meantime, the following companies may be able to provide you with " +
            "an online quote. Please compare 2 or more of the following options.";

    private static final String AGENTINFO_FOOTER_TEXT = "Your local Farmers Insurance\u00ae Agent is available if you have any questions.";

    private static final String QUICKEN_INFO_FOOTER_TEXT = "Work with a knowledgeable, friendly, insurance professional who\nwould be able " +
            "to help with your insurance needs before sending you back to Rocket Mortgage\u00ae.";

    @FindBy(xpath = "//farmers-home-quote-thank-you//mat-card//h4")
    private WebElement pageCrossSellTitle;

    @FindBy(xpath = "//farmers-home-quote-thank-you//mat-card//p")
    private WebElement pageCrossSellSubTitle;

    private static final String CROSSSELL_SELECT_XPATH = "//farmers-home-quote-thank-you//mat-card//mat-select";
    @FindBy(xpath = CROSSSELL_SELECT_XPATH)
    private WebElement selectCrossSellType;

    @FindBy(xpath = "//farmers-home-quote-thank-you//ui-farmers-select//mat-label")
    private WebElement selectCrossSellTypeLabel;

    @FindBy(xpath = "//farmers-home-quote-thank-you//mat-card//button[.='START SAVING']")
    private WebElement buttonStartSaving;

    private final By selectListOptions = By.xpath("//div[contains(@class,'mat-select-panel-wrap')]//mat-option");

    private static final String SELECT_OPTIONS_XPATH = "//div[contains(@class,'mat-select-panel')]//mat-option[.='%s']";

    private static final String PAGE_CROSSSELL_TITLE_TEXT = "Do you qualify for a multi-policy discount?";

    private static final String PAGE_CROSSSELL_SUBTITLE_TEXT = "Find out if adding new coverage will help you save.";

    private static final String CROSSSELL_SELECT_LABEL_TEXT = "Select type of insurance";

    private static final String VALIDATE_THANK_YOU_PAGE_FOOTER_2 = "Validate Thank You page footer 2.";

    private static final String  VALIDATE_THANK_YOU_PAGE_FOOTER_REDIRECT = "Validate Thank You page redirection footer text.";

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public ThankYouPage() throws Exception {
        super();
        waitElementBeVisible(textQuoteNumber);
    }

    public String getQuoteNumberTY() {
    	return getTextFromElement(waitElementBeVisible(textQuoteNumber));
    }

    public String getEstimatedPremium() {
    	return getTextFromElement(waitElementBeVisible(textEstimatedPremium));
    }

    public void validatePageValues(ApplicantHQM applicant, String monthlyPremium, FarmersSoftAssert fsa, @Nullable QuoteRateHQM quoteRate) throws Exception {
        String quoteNumberThankYouPage = this.getQuoteNumberTY();
        String premiumThankYouPage = this.getEstimatedPremium();
        Double dPremium = NumberFormat.getCurrencyInstance(Locale.US).parse(premiumThankYouPage).doubleValue();
        Log.info("<< Thank You Page: >> quote: " + quoteNumberThankYouPage);
        fsa.assertEquals(quoteNumberThankYouPage, applicant.quoteNumber, "Thank You page - Quote Number validation.");
        if (quoteRate != null) {
            if (!isHqmDigitalMonetizationState(applicant.stateCode)) {
                fsa.assertEquals(dPremium, Double.parseDouble(quoteRate.getMonthlyPremium()),
                        "Thank You page - Quote Estimated Monthly Premium validation vs. Postgres value.");
            } else {
                fsa.assertEquals(dPremium, Double.parseDouble(quoteRate.getYearlyPremium()),
                        "Thank You page - Quote Estimated Yearly Premium validation vs. Postgres value.");
            }
        } else {
            fsa.assertEquals(premiumThankYouPage, monthlyPremium,
                    "Thank You page - Quote Estimated Monthly Premium validation vs. quote page value.");
        }
    }

    public void validatePageTitles(ApplicantHQM applicant, String quoteSource,
                                   FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) throws Exception {
        // @quoteSource param is re-used as AEM campaign phone number, when it's not null and not QQ.
        waitElementBeVisible(linkFarmersLogo);
        fsa.assertEquals(getAttributeData(linkFarmersLogo, "alt"), "Farmers Insurance Logo", "Thank You page - Farmers Insurance Logo.");
        fsa.assertEquals(getTextFromElement(pageTitle), PAGE_TITLE_TEXT, "Thank You page - page Title h1");
        AgentInfoHQM agentInfo = getAgentInfo(applicant.quoteNumber);
        if ((agentInfo == null) || (agentInfo.getAgent().getLastName() == null)) {
            String callUs = String.format(PAGE_SUBTITLE1_TEXT, getContactUsPhoneNumber(applicant, quoteSource, true));
            if (!isHqmDigitalMonetizationState(applicant.stateCode)) {
                fsa.assertEquals(getTextFromElement(pageSubTitle1), callUs, "Thank You page - page SubTitle 1 PA.");
                fsa.assertEquals(getTextFromElement(pageSubTitle2), PAGE_SUBTITLE2_TEXT, "Thank You page - page SubTitle 2 PA.");
            } else {
                fsa.assertEquals(getTextFromElement(pageSubTitle1), PAGE_SUBTITLE2_TEXT_CA, "Thank You page - page SubTitle 1 PA in CA.");
            }
        } else {
            fsa.assertEquals(getTextFromElement(pageSubTitle1), isHqmDigitalMonetizationState(applicant.stateCode) ?
                            PAGE_SUBTITLE2_TEXT_CA : PAGE_SUBTITLE2_TEXT,
                    "Thank You page - page SubTitle 1 EA.");
        }
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getThankYouTitle(), PAGE_TITLE_TEXT, "Thank You page - page Title h1 (AEM).");
            if ((agentInfo == null) || (agentInfo.getAgent().getLastName() == null)) {
                String callUs = String.format(PAGE_SUBTITLE1_TEXT, getContactUsPhoneNumber(applicant, quoteSource, true));
                fsa.assertEquals(staticContent.getThankYouCaption().replace("[PHONE NUMBER]", getContactUsPhoneNumber(applicant, quoteSource, true)),
                        callUs + " \n  " + PAGE_SUBTITLE2_TEXT, "Thank You page - page SubTitle PA (AEM).");
            }
        }
    }

    public void validatePageFooters(ApplicantHQM applicant, String quoteSource, FarmersSoftAssert fsa) throws Exception {
        // @quoteSource param is re-used as AEM campaign phone number, when it's not null and not QQ.
        AgentInfoHQM agentInfo = getAgentInfo(applicant.quoteNumber);
        if ((agentInfo == null) || (agentInfo.getAgent().getLastName() == null)) {
            fsa.assertEquals(getTextFromElement(pageFooter1), "Need Help?", "Validate Thank You page footer 1.");
            String contactUs = "phone " + getContactUsPhoneNumber(applicant, quoteSource, true);
            if (quoteSource.equals(FC)) {
                fsa.assertEquals(getTextFromElement(pageFooter2), PAGE_FOOTER2_TEXT, VALIDATE_THANK_YOU_PAGE_FOOTER_2);
                fsa.assertEquals(getTextFromElement(linkCallFarmersPA), contactUs, "Thank You page - Call Farmers Insurance Political " +
                        "Agent 800 number is displayed.");
                if (isHqmDigitalMonetizationState(applicant.stateCode)) {
                    fsa.assertEquals(getTextFromElement(pageFooterRedirect), PAGE_FOOTER_REDIRECT, VALIDATE_THANK_YOU_PAGE_FOOTER_REDIRECT);
                }
            } else if (quoteSource.equals(QQ)) {
                fsa.assertEquals(getTextFromElement(pageFooter2), QUICKEN_INFO_FOOTER_TEXT, VALIDATE_THANK_YOU_PAGE_FOOTER_2);
                fsa.assertEquals(getTextFromElement(linkCallFarmersPA), contactUs, "Thank You page - Call Farmers Quicken " +
                        "800 number is displayed.");
            } else {
                fsa.assertEquals(getTextFromElement(pageFooter2), PAGE_FOOTER2_TEXT, VALIDATE_THANK_YOU_PAGE_FOOTER_2);
                fsa.assertEquals(getTextFromElement(linkCallFarmersPA), contactUs, "Thank You page - Call Farmers Insurance AEM Campaign " +
                        "800 number is displayed.");
                if (isHqmDigitalMonetizationState(applicant.stateCode)) {
                    fsa.assertEquals(getTextFromElement(pageFooterRedirect), PAGE_FOOTER_REDIRECT, VALIDATE_THANK_YOU_PAGE_FOOTER_REDIRECT);
                }
            }
        } else {
            if ((agentInfo.getAgent().getAgentImageUrl() != null) && (!agentInfo.getAgent().getAgentImageUrl().isEmpty())) {
                fsa.assertEquals(getAttributeData(agentImage, SRC), agentInfo.getAgent().getAgentImageUrl(),
                        "Validate Thank You page - Agent Image Url in the footer.");
            }
            fsa.assertEquals(getTextFromElement(agentNameFooter), agentInfo.getAgent().getFirstName() + SPACE + agentInfo.getAgent().getLastName(),
                    "Validate Thank You page Agent Name footer.");
            fsa.assertEquals(getTextFromElement(agentInfoFooter), AGENTINFO_FOOTER_TEXT, "Validate Thank You page - Agent Info footer.");
            fsa.assertEquals(getTextFromElement(agentEmailAddress), agentInfo.getAgentEmailAddress(), "Validate Thank You page - Agent Email Address.");
            fsa.assertEquals(getTextFromElement(agentPhoneNumber), agentInfo.getAgentPhoneNumber(), "Validate Thank You page - Agent Phone Number.");
            if (!agentInfo.getAgent().getAddress().getCity().isEmpty()) {
                fsa.assertEquals(getTextFromElement(agentAddress), agentInfo.getAgentFullAddress(), "Validate Thank You page - Agent Address.");
            }
        }
    }

    public String getSelectedCrossSellType() {
    	return getTextFromElement(waitElementBeVisible(selectCrossSellType));
    }

    public List<String> getAvailableCrossSellTypes() throws Exception {
        List<String> listAvailableCrossSellTypes = new ArrayList<>();
        if (isElementDisplayed(By.xpath(CROSSSELL_SELECT_XPATH))) {
            waitAndClickElement(selectCrossSellType);
            listAvailableCrossSellTypes = driver().findElements(selectListOptions).stream()
                    .map(this::getTextFromElement).collect(Collectors.toList());
            listAvailableCrossSellTypes.remove("Select");
            selectCrossSellType.sendKeys(Keys.ESCAPE);
            Log.info(">> Available Cross Sell Types: " + listAvailableCrossSellTypes);
        } else {
            Log.info(">> No Cross Sell Type select was displayed.");
        }
        return listAvailableCrossSellTypes;
    }

    public void selectCrossSellType(String crossSellType) throws Exception {
        String crossSell = getSelectedCrossSellType();
        Log.info("Cross Sell type selected: " + crossSell + ";  Selecting now: " + crossSellType);
        if (StringUtils.isEmpty(crossSellType) || crossSell.equals(crossSellType)) {
            return;
        }
        waitAndClickElement(selectCrossSellType);
        WebElement optionWe = driver().findElement(By.xpath(String.format(SELECT_OPTIONS_XPATH, crossSellType)));
        waitAndClickElement(optionWe);
    }

    public void clickStartSaving() {
        waitAndClickElement(buttonStartSaving);
    }

    public void validatePageCrossSellTitles(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(pageCrossSellTitle), PAGE_CROSSSELL_TITLE_TEXT, "Thank You page - Cross Sell Title.");
        fsa.assertEquals(getTextFromElement(pageCrossSellSubTitle), PAGE_CROSSSELL_SUBTITLE_TEXT, "Thank You page - Cross Sell Sub-title.");
        fsa.assertEquals(getTextFromElement(selectCrossSellTypeLabel), CROSSSELL_SELECT_LABEL_TEXT, "Thank You page - Cross Sell Select Label.");
    }

    public boolean isCrossOptionDisplayed() {
        return isElementDisplayed(pageCrossSellTitle,2);
    }
}
