package com.farmers.ffq.ace.hrc.common;

import com.farmers.ffq.utils.FarmersSoftAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCFwsInterstitialPage extends AceHRCBasePage {

    private static final String FWS_INTERSTITIAL_PAGE_TITLE_TEXT_HOME = "It's not you. It's us.";
    private static final String FWS_INTERSTITIAL_PAGE_SUBTITLE_TEXT = "You're eligible for special discounts";
    private static final String FWS_COLP_SUBTITLE_TEXT = FWS_INTERSTITIAL_PAGE_SUBTITLE_TEXT + SPACE +
            "that are only available by phone.";

    private static final String FWS_CHOICE_PAGE_CONTENT = "Complete your quote online on our Farmers Insurance Choice site to apply your eligible discounts.";
    private static final String FWS_SPEAK_WITH_REPRESENTATIVE_TEXT = "Or speak with a representative at";

    private static final String FWS_COLP_PAGE_CONTENT = "Give us a quick call" + SEPARATOR + "to take advantage of this offer.";
    private static final String FWS_DIALOG_CONTAINER_CONTENT = "Regarding consent to transmit information." + SEPARATOR +
            "By clicking \"Agree and continue\", I expressly authorize Farmers Insurance\u00ae to share my information with Farmers " +
            "General Insurance Agency, Inc. (FGIA) and its affiliates for the purpose of generating insurance quotes.";
    private static final String FWS_QNB_PAGE_CONTENT = "To apply your special discounts, click the \"Get my quote\" button " +
            "to complete your quote online on our Farmers Insurance Group Quote site.";
    private static final String FWS_QNB_CALL_TO_REPRESENTATIVE_CONTENT = "Or call to speak with a licensed representative and complete your quote by phone";
    @FindBy(xpath = "//app-fws-eligibility//div[@class='fws-content-rebrand']//h1")
    private WebElement fwsInterstitialPageTitle;
    @FindBy(xpath = "//app-fws-eligibility//div[@class='fws-content-rebrand']//h2")
    private WebElement fwsInterstitialPageSubTitle;
    @FindBy(xpath = "//app-fws-eligibility//div[contains(text(), 'Farmers Insurance Choice')]")
    private WebElement farmersChoicePageContent;
    @FindBy(xpath = "//app-fws-eligibility//span[contains(text(), 'Farmers Insurance Group Quote site')]")
    private WebElement fwsInterstitialGroupQuoteContent;
    private static final String CONTACT_NUMBER_XPATH = "//app-fws-eligibility//div[@class='phone-number-rebrand']";
    @FindBy(xpath = CONTACT_NUMBER_XPATH)
    private WebElement fwsRepresentativeContactNumber;
    @FindBy(xpath = CONTACT_NUMBER_XPATH + "/preceding-sibling::div")
    private WebElement fwsSpeakWithRepresentativeText;
    @FindBy(xpath = "//app-fws-eligibility//button[contains(text(),'Apply discounts')]")
    private WebElement applyDiscountsButton;
    @FindBy(xpath = "//mat-dialog-container//h4[contains(@class,'consent-dialog-header-rebrand')]")
    private WebElement fwsInterstitialDialogContainerTitle;
    @FindBy(xpath = "//mat-dialog-container//mat-dialog-content[contains(@class,'dialog-content')]")
    private WebElement fwsInterstitialDialogContainerContent;
    @FindBy(xpath = "//mat-dialog-container//button[contains(@class, 'consent-dialog-agree-button')]")
    private WebElement fwsDialogContainerAgreeButton;
    @FindBy(xpath = "//mat-dialog-container//button[contains(@class, 'consent-dialog-cwd-button')]")
    private WebElement fwsDialogContainerContinueWithoutDataButton;
    @FindBy(xpath = "//div[contains(@class,'without-discount-link')]//a")
    private WebElement continueWithoutDiscountLink;
    @FindBy(xpath = "//span[@class='selected-indicator']/preceding-sibling::span")
    private WebElement selectedInsuranceType;
    private static final String FWS_COLP_CONTENT_XPATH = "//div[contains(@class,'fws-call-content-rebrand')]";
    @FindBy(xpath = FWS_COLP_CONTENT_XPATH)
    private WebElement fwsColpPageContent;
    private static final String PHONE_NUMBER_XPATH = "//div[contains(@class,'phone-number-rebrand')]";
    @FindBy(xpath = PHONE_NUMBER_XPATH)
    private WebElement fwsColpContactNumber;
    private static final String FWS_QnB_CONTENT_XPATH = "//div[contains(@class,'fws-card-rebrand')]";
    @FindBy(xpath = FWS_QnB_CONTENT_XPATH + "//div[1]")
    private WebElement fwsQnBPageContent;
    @FindBy(xpath = PHONE_NUMBER_XPATH + "/preceding-sibling::div")
    private WebElement fwsQnBCallToRepresentativeContent;
    @FindBy(xpath = FWS_QnB_CONTENT_XPATH + "//button[contains(text(),'Get my quote')]")
    private WebElement fwsQnBGetMyQuoteButton;
    @FindBy(xpath = "//div[contains(@class, 'qnbContent')]//h1")
    private WebElement qnbPageHeader;
    private static final String FWS_PAGE_SUBTITLE_XPATH = "//div[@class='fws-content-rebrand']//h4";
    @FindBy(xpath = FWS_PAGE_SUBTITLE_XPATH)
    private WebElement fwsPageSubtitle;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public AceHRCFwsInterstitialPage() throws Exception {
    }

    public void validateFwsFarmersChoicePage(FarmersSoftAssert fsa, String lobType) throws Exception {
        waitForPageToBeReady();
        fsa.assertEquals(getTextFromElement(fwsInterstitialPageTitle), FWS_INTERSTITIAL_PAGE_TITLE_TEXT_HOME, "FWS Interstitial page - Page title is not as expected.");
        fsa.assertEquals(getTextFromElement(fwsInterstitialPageSubTitle), FWS_INTERSTITIAL_PAGE_SUBTITLE_TEXT + PERIOD, "FWS Interstitial page - Page subtitle is not as expected.");
        String dynamicContent;
        if(lobType.equals(AUTO) || !lobType.equals(RENTERS) && isNewFlowEnabledState(getStateCodeFromAppStore())){
            dynamicContent = getSessionStorageAppStore().getData().getEmployerName();
        }
        else {
            dynamicContent = getSessionStorageAppStore().getData().getSubmitCustomerResponse().getEmployerName();
        }
        fsa.assertEquals(getTextFromElement(fwsPageSubtitle), String.format("As part of %s, you could save hundreds!", dynamicContent), "FWS Interstitial - Farmers choice page subtitle is not as expected.");
        fsa.assertEquals(getTextFromElement(farmersChoicePageContent), FWS_CHOICE_PAGE_CONTENT, "FWS Interstitial page - Farmers insurance choice content is not as expected.");
        fsa.assertEquals(getTextFromElement(fwsSpeakWithRepresentativeText), FWS_SPEAK_WITH_REPRESENTATIVE_TEXT, "FWS Interstitial page - Speak with representative text validation.");
        fsa.assertEquals(getTextFromElement(fwsRepresentativeContactNumber), CALL_FARMERS, "FWS Interstitial page - Representative contact number validation.");
        fsa.assertTrue(isElementVisible(applyDiscountsButton, 5), "FWS Interstitial page - Apply discounts button is not visible.");
        fsa.assertTrue(isElementVisible(continueWithoutDiscountLink, 5), "FWS Interstitial page - Continue without discount link is not visible.");
    }

    public void validateFWSInterstitialDialogContent(FarmersSoftAssert fsa) {
        fsa.assertTrue(isElementVisible(fwsInterstitialDialogContainerTitle, 5), "FWS Interstitial page - Consent dialog title is not visible.");
        fsa.assertEquals(getTextFromElement(fwsInterstitialDialogContainerContent), FWS_DIALOG_CONTAINER_CONTENT, "FWS Interstitial page - Consent dialog content is not as expected.");
        fsa.assertTrue(isElementVisible(fwsDialogContainerAgreeButton, 3), "FWS Interstitial page - Consent dialog Agree and continue button is not visible.");
        fsa.assertTrue(isElementVisible(fwsDialogContainerContinueWithoutDataButton, 3), "FWS Interstitial page - Consent dialog Continue without data button is not visible.");
    }

    public void validateFwsColpPage(FarmersSoftAssert fsa, String lobType) throws Exception {
    	waitForPageToBeReady();
        fsa.assertEquals(getTextFromElement(fwsInterstitialPageTitle), FWS_INTERSTITIAL_PAGE_TITLE_TEXT_HOME, "FWS Interstitial - COLP page title is not as expected.");
        fsa.assertEquals(getTextFromElement(fwsInterstitialPageSubTitle), FWS_COLP_SUBTITLE_TEXT, "FWS Interstitial - COLP page subtitle is not as expected.");
        String dynamicContent;
        if(lobType.equals(AUTO) || !lobType.equals(RENTERS) && isNewFlowEnabledState(getStateCodeFromAppStore())){
            dynamicContent = getSessionStorageAppStore().getData().getEmployerName();
        }
        else {
            dynamicContent = getSessionStorageAppStore().getData().getSubmitCustomerResponse().getEmployerName();
        }
        fsa.assertEquals(getTextFromElement(fwsPageSubtitle), String.format("As part of %s, you could save hundreds!", dynamicContent), "FWS Interstitial - COLP page subtitle is not as expected.");
        fsa.assertEquals(getTextFromElement(fwsColpPageContent), FWS_COLP_PAGE_CONTENT, "FWS Interstitial - COLP page content validation");
        fsa.assertEquals(getTextFromElement(fwsColpContactNumber), "Call " + CALL_FARMERS, "FWS Interstitial - COLP page phone number validation.");
        fsa.assertTrue(isElementVisible(continueWithoutDiscountLink, 5), "FWS Interstitial page - Continue without discount link is not visible.");
    }

    public void validateFwsQnBPage(FarmersSoftAssert fsa) throws Exception {
    	waitForPageToBeReady();
        fsa.assertEquals(getTextFromElement(fwsInterstitialPageTitle), FWS_INTERSTITIAL_PAGE_TITLE_TEXT_HOME, "FWS Interstitial - QnB page title is not as expected.");
        fsa.assertEquals(getTextFromElement(fwsInterstitialPageSubTitle), FWS_INTERSTITIAL_PAGE_SUBTITLE_TEXT + PERIOD, "FWS Interstitial - QnB page subtitle is not as expected.");
        String dynamicContent;
        if (isNewFlowEnabledState(getStateCodeFromAppStore())) {
            dynamicContent = getSessionStorageAppStore().getData().getEmployerName();
        } else {
            dynamicContent = getSessionStorageAppStore().getData().getSubmitCustomerResponse().getEmployerName();
        }
        fsa.assertEquals(getTextFromElement(fwsPageSubtitle), String.format("As part of %s, you could save hundreds!", dynamicContent), "FWS Interstitial - QnB page subtitle is not as expected.");
        fsa.assertEquals(getTextFromElement(fwsQnBPageContent), FWS_QNB_PAGE_CONTENT, "FWS Interstitial - QnB page content is not as expected.");
        fsa.assertTrue(isElementVisible(fwsQnBGetMyQuoteButton, 5), "FWS Interstitial page - QnB - Get My Quote button is not visible.");
        fsa.assertEquals(getTextFromElement(fwsQnBCallToRepresentativeContent), FWS_QNB_CALL_TO_REPRESENTATIVE_CONTENT, "FWS Interstitial - QnB page content is not as expected.");
        fsa.assertEquals(getTextFromElement(fwsColpContactNumber), CALL_FARMERS, "FWS Interstitial - QnB page content is not as expected.");
        fsa.assertFalse(isElementVisible(continueWithoutDiscountLink, 5), "FWS Interstitial page - QnB - Continue without discount link is visible.");
    }

    public boolean isOnFarmersChoiceInterstitialPage() {
        return isElementVisible(farmersChoicePageContent, 5);
    }

    public boolean isOnColpInterstitialPage() { return isExpectedTextDisplayed(fwsColpPageContent, FWS_COLP_PAGE_CONTENT); }

    public boolean isOnQnBInterstitialPage() { return isElementVisible(fwsQnBGetMyQuoteButton, 5); }

    public void clickOnApplyDiscountButton() {
        waitAndClickElement(applyDiscountsButton, 3);
    }

    public void clickOnGetMyQuoteButton() {
        waitAndClickElement(fwsQnBGetMyQuoteButton, 3);
    }

    public void clickOnDialogContainerAgreeButton() {
        waitAndClickElement(fwsDialogContainerAgreeButton, 3);
    }

    public boolean isOnBindableChoicePage(int seconds) {
        return isElementVisible(selectedInsuranceType, seconds);
    }

    public void validateSelectedInsuranceType(FarmersSoftAssert fsa, String lobType) throws Exception {
        String currentUrl = driver().getCurrentUrl();
        String EXPECTED_DOMAIN = "farmersinsurancechoice.com";
        fsa.assertTrue(currentUrl.contains(EXPECTED_DOMAIN), "Current URL does not contain expected domain. Current URL: " + currentUrl);
        if (!lobType.equals(RENTERS)) {
            fsa.assertEquals(getTextFromElement(selectedInsuranceType), "Homeowners", "Selected insurance type is not as expected on bindable choice page.");
        } else {
            fsa.assertEquals(getTextFromElement(selectedInsuranceType), RENTERS, "Selected insurance type is not as expected on bindable choice page.");
        }
    }

    public boolean isOnQnBSite() { return isElementVisible(qnbPageHeader, 30); }

    public void validateQnBUrl(FarmersSoftAssert fsa) throws Exception {
        String currentUrl = driver().getCurrentUrl();
        String EXPECTED_URL = "/quote-and-buy-farmers";
        fsa.assertTrue(currentUrl.contains(EXPECTED_URL), "Current URL does not contain expected url keywords. Current URL: " + currentUrl);
    }

    public void clickContinueWithoutDiscount() throws Exception {
        waitAndClickElement(continueWithoutDiscountLink, 3);
    }

    public boolean isOnFwsFarmersInsuranceChoicePage() {
        return isElementPresent(By.cssSelector("button[data-uid='pg_intro_next_btn']"), 4);
    }
}
