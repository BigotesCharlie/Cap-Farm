package com.farmers.ffq.auto.pages.legacy;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.datatransferobjects.SqlDiscount;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class DiscountsPage extends AutoBasePage {

	private static final String RENTS_DWELLING = "Rent a";
	private static final String DISCOUNT_PAGE_HEADER = "Let's see what other discounts and savings you qualify for.";
	private static final String DISCOUNT_PAGE_DESCRIPTION = "You may qualify for additional savings.";
	private static final String POLICY_STARTDATE_DESCRIPTION = "When would you like your new policy to start?";
	private static final String RESIDENCE_OWNERSHIP_DESCRIPTION = "Do you own or rent your current residence?";
	private static final String BW_RESIDENCE_OWNERSHIP_DESCRIPTION = "What is your Primary Residence insurance?";
	private static final String BUNDLE_DESCRIPTION = "Are you interested in bundling Auto with any additional policies? (Optional)";
	private static final String FFQ = "FFQ_";
	private static final String FFQ_AUTO = "FFQ_Auto_";

	@FindBy(id = "auto-module_header-title")
	private WebElement discountsPageHeader;

	@FindBy(className = "auto-module_title-description-text")
	private WebElement discountsPageDescription;

	@FindBy(xpath = "//button[@data-gtm='FFQ_Auto_Discount_back_button']")
	private WebElement backButton;

	@FindBy(xpath = "//button[@data-gtm='FFQ_Auto_BWDiscount_back_button']")
	private WebElement backButtonBW;

	@FindBy(xpath = "//div[@class='auto-module__discount-button-container']//button[3]")
	private WebElement nextYourQuoteButton;

	@FindBy(xpath = "//button[@data-gtm='FFQ_Auto_BWDiscount_next_button' and contains(@class, 'right_button')]")
	private WebElement bwNextYourQuoteButton;

	@FindBy(xpath = "//p[@class='auto-module__discount-text' and contains(text(), 'new policy to start')]")
	private WebElement policyStartDateDescription;

	@FindBy(xpath = "//span/label/mat-label[contains(text(),'policy start date')]/../../../input")
	private WebElement policyStartDateEntryField;

	@FindBy(xpath = "//p[@class='auto-module__discount_subheader-text' and contains(text(), 'Do you own or rent')]")
	private WebElement residenceOwnershipDescription;

	@FindBy(className = "auto-module__discount-text")
	private WebElement bwResidenceOwnershipDescription;

	@FindBy(className = "auto-module__discount-text")
	private WebElement bwOldResidenceOwnershipDescription;

	private static final String RADIO_BUTTON_XPATH = "//mat-radio-button";
	@FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_Auto_Discounts_ownHome_radio']")
	private WebElement ownAHomeRadioButton;

	@FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_Auto_Discounts_Rent_radio']")
	private WebElement rentRadioButton;

	@FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_Auto_Discounts_NoAns_radio']")
	private WebElement otherRadioButton;

	@FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_Primaryresidenceinsurance_HomeCondo_radio']")
	private WebElement bwOwnAHomeRadioButton;

	@FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_Primaryresidenceinsurance_Renters_radio']")
	private WebElement bwRentRadioButton;

	@FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_Primaryresidenceinsurance_None_radio']")
	private WebElement bwNoInsuranceRadioButton;

	@FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_Primaryresidenceinsurance_Mobilehome_radio']")
	private WebElement bwMobileHomeRadioButton;

	@FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_ownHome_radio']")
	private WebElement bwOldOwnAHomeRadioButton;

	@FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_Rent_radio']")
	private WebElement bwOldRentRadioButton;

	@FindBy(xpath = RADIO_BUTTON_XPATH + "[@data-gtm='FFQ_BWAuto_Discounts_NoAns_radio']")
	private WebElement bwOtherRadioButton;

	@FindBy(xpath = "//div/p[contains(text(),'Do you own or rent')]/../div[@class='auto-module__discount-form-element']/lib-select/mat-form-field/div/div/div/mat-select")
	private WebElement residenceOwnershipDropDown;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_Primaryresidenceinsurance_None_radio']")
	private WebElement noInsuranceRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_Primaryresidenceinsurance_Renters_radio']")
	private WebElement rentersInsuranceRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_Primaryresidenceinsurance_HomeCondo_radio']")
	private WebElement homeCondoInsuranceRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_Primaryresidenceinsurance_Mobilehome_radio']")
	private WebElement mobilehomeInsuranceRadioButton;

	private static final String BUNDLE_INSURANCE_SECTION_HEADER_XPATH = "//div[contains(@class, 'auto__discount__card')]//*[contains(text(), 'Bundle and Save')]";
	@FindBy(xpath = "//p[@class='auto-module__discount_subheader-text' and contains(text(), 'interested in bundling')]")
	private WebElement bundleInsuranceDescription;

	@FindBy(xpath = "//p[@class='auto-module__discount-text' and contains(text(), 'Do you own')]")
	private WebElement bundleInsuranceDescriptionBW;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_homecrosssell_checkbox']")
	private WebElement bundleHomeInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_homecrosssell_checkbox']")
	private WebElement bundleBWHomeInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_renterscrosssell_checkbox']")
	private WebElement bundleRentersInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_renterscrosssell_checkbox']")
	private WebElement bundleBWRentersInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_condocrosssell_checkbox']")
	private WebElement bundleCondoInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_condocrosssell_checkbox']")
	private WebElement bundleBWCondoInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_Lifecrosssell_checkbox']")
	private WebElement bundleVTLInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_Lifecrosssell_checkbox']")
	private WebElement bundleBWVTLInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_Umbrellacrosssell_checkbox']")
	private WebElement bundleUmbrellaInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_Umbrellacrosssell_checkbox']")
	private WebElement bundleBWUmbrellaInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_businesscrosssell_checkbox']")
	private WebElement bundleBusinessInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_BWAuto_bundlechk_businesscrosssell_checkbox']")
	private WebElement bundleBWBusinessInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_recreationalcrosssell_checkbox']")
	private WebElement bundleBoatInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_offroadcrosssell_checkbox']")
	private WebElement bundleORVInsuranceCheckbox;

	@FindBy(xpath = "//mat-checkbox[@data-gtm='FFQ_Auto_bundlechk_motorhomecrosssell_checkbox']")
	private WebElement bundleMotorhomeInsuranceCheckbox;

	private static final String XPATH_TO_DISABILITY_INSURANCE = "//p[@class='auto-module__discount-text' and contains(text(), 'disability insurance')]";
	@FindBy(xpath = XPATH_TO_DISABILITY_INSURANCE)
	private WebElement disabilityCoverageDescription;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_disabilitycoverage_yes_radio']")
	private WebElement disabilityCoverageRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Discounts_disabilitycoverage_no_radio']")
	private WebElement noDisabilityCoverageRadioButton;

	@FindBy(xpath = "//p[@class='auto-module__discount-text' and contains(text(), 'following insurance policies')]")
	private WebElement otherInsurancePoliciesDescription;

	@FindBy(xpath = "//mat-select[@data-gtm='FFQ_Auto_Discounts_Insurancepolicies_dropdown']")
	private WebElement otherInsurancePoliciesDropDown;

	@FindBy(xpath = "//p[@class='auto-module__discount-text' and contains(text(), 'many people')]")
	private WebElement dwellersInHouseholdDescription;

	@FindBy(xpath = "//mat-select[contains(@aria-label, 'people in household')]")
	private WebElement dwellersInHouseholdDropDown;

	public DiscountsPage() throws Exception {
		super();
		isBristolWest = isBristolWestQuote();
	}

	public QuotePageAuto fillForm(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		String stateCode = applicant.getStateCode();
		int applicantAge = applicant.getAge();
		SqlDiscount discounts = applicant.getDiscounts();
		SignalPage sp = new SignalPage();
		if (sp.onSignalPage()) {
			sp.validateSignalPage(stateCode, fsa);
			sp.continueToDiscountPage(discounts.isSignalSignup());
		}
		if (isADATestingEnabled()) {
			continueToQuotePage();
			performADATesting(getClass().getSimpleName(), MARKETING_IT, "Auto");
			screenCapture(discountsPageDescription, getClass().getSimpleName(), LOB_AUTO, false);
			enterHomeOwnershipInformation(OWN_A_HOME, fsa);
			performADATesting(getClass().getSimpleName()+"BundleOptions", MARKETING_IT, "Auto");
			screenCapture(discountsPageDescription, getClass().getSimpleName()+"BundleOptions", LOB_AUTO, false);
		}
		verifyHeader(fsa);
		String policyStartDate = stateCode.equals(CA) ? calculateDateFromPeriod("P28D") : calculateDateFromPeriod(discounts.getStartDateOfNewPolicy());
		enterPolicyStartDate(policyStartDate);
		isBristolWest = isBristolWestQuote();
		if (stateCode.equals(FL) && applicantAge < MAX_YOUNG_AGE && discounts.getOwnOrRentHome().equals(OWN_MOBILE_HOME)) {
			discounts.setOwnOrRentHome(OWN_A_HOME);
		}
		if (isBristolWest) {
			enterBWHomeOwnershipInformation(discounts.getOwnOrRentHome(), stateCode, fsa);
			enterBWBundleInsuranceInformation(discounts, stateCode, applicantAge, fsa);
			bwEnterPeopleInHousehold(stateCode);
		} else {
			if (stateCode.equals(MA)) {
				enterPrimaryResidenceInsuranceInformation(discounts);
			} else {
				enterHomeOwnershipInformation(discounts.getOwnOrRentHome(), fsa);
				enterBundleInsuranceInformation(discounts, stateCode, applicantAge, fsa);
				enterAdditionalInsuranceCoverageInformation(stateCode, NO);
			}
		}
		String quoteNumber = getRedesignedQuoteNumber();
		if (!findInCallStack(CREATE_CROSS_SELL_AUTO_QUOTE)) {
			validateGTMTags(stateCode, discounts.getOwnOrRentHome(), applicantAge, fsa);
		}
		continueToQuotePage(quoteNumber, fsa);
		if (stateCode.equals(NC)) {
			DriversPage dPage = new DriversPage(false);
			dPage.enterVehicleAssignmentData(applicant, false, fsa);
			if (onDiscountsPage()) {
				continueToQuotePage(quoteNumber, fsa);
			}
		}
		if (isBrightlinedQuote()) {
			continueToBristolWest(true);
			Log.info("***** QUOTE MOVED TO BRISTOL WEST ****");
			isBristolWest = true;
			waitForSpinnerToBeGone();
			checkForKnockout("DiscountsPage.fillForm brightlined", quoteNumber);
			bwEnterPeopleInHousehold(stateCode);
			if (onDiscountsPage()) {
				continueToQuotePage(quoteNumber, fsa);
			}
		}
		if (onDiscountsPage()) {
			continueToQuotePage(quoteNumber, fsa);
			if (onDiscountsPage()) {
				fsa.fail("Unable to proceed past discounts page");
				fsa.assertAll();
			}
		}
		return new QuotePageAuto();
	}

	private boolean errorsPresentInPage() throws Exception {
		return !noErrorsPresentInPage();
	}

	private void continueToQuotePage(String quoteNumber, FarmersSoftAssert fsa) throws Exception {
		continueToQuotePage();
		if (errorsPresentInPage()) {
			fsa.fail("Errors found in discount page");
		}
		checkForKnockout("DiscountsPage.fillForm", quoteNumber);
	}

	private void enterInsurancePolicyType() throws Exception {
		selectFromDropDownByPosition(otherInsurancePoliciesDropDown, FIRST_AVAILABLE_OPTION, otherInsurancePoliciesDescription);
	}

	private void enterPeopleInHousehold() throws Exception {
		selectFromDropDownByPosition(dwellersInHouseholdDropDown, SECOND_AVAILABLE_OPTION, dwellersInHouseholdDescription);
	}

	public boolean saveQuoteAndFinishLater(SqlApplicant applicant) throws Exception {
		if (applicant.isSaveAndRetrieveDiscountsPage()) {
			SignalPage sp = new SignalPage();
			if (sp.onSignalPage()) {
				sp.continueToDiscountPage(true);
			}
			FarmersSoftAssert fsa = new FarmersSoftAssert();
			if (isBristolWestQuote()) {
				enterBWHomeOwnershipInformation(DEFAULT_RESOLUTION, applicant.getStateCode(), fsa);
			} else {
				enterHomeOwnershipInformation(DEFAULT_RESOLUTION, fsa);
			}
			return saveAutoQuoteAndFinishLater(applicant, DISCOUNTS_PAGE_AUTO, true);
		} else {
			return false;
		}
	}

	private void verifyHeader(FarmersSoftAssert fsa) {
		waitElementBeVisible(discountsPageHeader);
		fsa.assertEquals(getTextFromElement(discountsPageHeader), DISCOUNT_PAGE_HEADER, "Discounts page header verification");
		if (isElementPresentByClass(discountsPageDescription)) {
			fsa.assertEquals(getTextFromElement(discountsPageDescription), DISCOUNT_PAGE_DESCRIPTION, "discountsPageDescription");
			fsa.assertEquals(getTextFromElement(policyStartDateDescription), POLICY_STARTDATE_DESCRIPTION, "policyStartDateDescription");
		}
	}

	private boolean validateGTMTags(String stateCode, String ownOrRentHome, int age, FarmersSoftAssert fsa) {
		try {
			scrollToBottomOfPage();
			List<String> rallyTestcasesCovered = isBristolWest ? new ArrayList<>(Arrays.asList("TC33203", "TC33210", "TC33212", "TC33214", "TC33217", "TC33225", "TC33287", "TC33288")) :
				new ArrayList<>(Arrays.asList("TC33203", "TC33205", "TC33209", "TC33210", "TC33212", "TC33214", "TC33215", "TC33216"));
			writeTestcaseState("DiscountsPage.validateGTMTags", stateCode, rallyTestcasesCovered, FAILED);
			isBristolWest = isBristolWestQuote();
			verifyElementExpectedAttribute(getListWithPageElements(stateCode, ownOrRentHome, age), getMapWithExpectedGTMTags(stateCode, ownOrRentHome, age), "data-gtm", fsa);
			writeTestcaseState("DiscountsPage.validateGTMTags", stateCode, rallyTestcasesCovered, PASSED);
			return true;
		} catch (Exception e) {
			Log.error(stateCode + " Discounts GTM error found is " + e.toString(), true);
			e.printStackTrace();
			return false;
		}
	}

	private void enterPolicyStartDate(String policyStartDate) {
		Log.info("Setting policy start date to " + policyStartDate);
		sendKeysToElement(policyStartDateEntryField, policyStartDate);
	}

	private void enterPrimaryResidenceInsuranceInformation(SqlDiscount discounts) {
		// Map out bundle selection to primary residence insurance selection
		scrollElementToMiddle(homeCondoInsuranceRadioButton);
		if (discounts.isHomeInsurance() || discounts.isCondoInsurance()) {
			clickElement(homeCondoInsuranceRadioButton);
		} else if (discounts.isRentersInsurance()) {
			clickElement(rentersInsuranceRadioButton);
		} else if (discounts.isValueTermLifeInsurance()) {
			clickElement(mobilehomeInsuranceRadioButton);
		} else {
			clickElement(noInsuranceRadioButton);
		}
	}

	private void enterHomeOwnershipInformation(String residenceOwnership, FarmersSoftAssert fsa) {
		scrollElementToTop(ownAHomeRadioButton);
		switch (residenceOwnership) {
		case OWN_A_HOME:
		case OWN_A_HOUSE:
		case OWN_A_CONDO:
		case OWN_A_CONDO_TOWNHOUSE:
		case OWN_APARTMENT:
		case OWN_MOBILE_HOME:
		case OWN_FARM:
			clickElement(ownAHomeRadioButton);
			break;
		case RENT_A_CONDO:
		case RENT_A_HOME:
		case RENT_A_CONDO_TOWNHOUSE:
		case RENT_AN_APARTMENT:
		case RENT_MOBILE_HOME:
			clickElement(rentRadioButton);
			break;
		default:
			clickElement(otherRadioButton);
			break;
		}
		fsa.assertTrue(getTextFromElement(residenceOwnershipDescription).contains(RESIDENCE_OWNERSHIP_DESCRIPTION), "residenceOwnershipDescription contains " + RESIDENCE_OWNERSHIP_DESCRIPTION);
		Log.info("Selecting <" + residenceOwnership + "> as home ownership information");
	}

	private void enterBWHomeOwnershipInformation(String residenceOwnership, String stateCode, FarmersSoftAssert fsa) {
		boolean useNewerDefinition = stateCode.equals(MA);
		switch (residenceOwnership) {
		case OWN_A_HOME:
		case OWN_A_HOUSE:
		case OWN_A_CONDO:
		case OWN_A_CONDO_TOWNHOUSE:
		case OWN_APARTMENT:
		case OWN_FARM:
			if (useNewerDefinition) {
				scrollAndClickOnElement(bwOwnAHomeRadioButton);
			} else {
				scrollAndClickOnElement(bwOldOwnAHomeRadioButton);
			}
			break;
		case OWN_MOBILE_HOME:
			if (useNewerDefinition) {
				scrollAndClickOnElement(bwMobileHomeRadioButton);
			} else {
				scrollAndClickOnElement(bwOldOwnAHomeRadioButton);
			}
			break;
		case RENT_A_CONDO:
		case RENT_A_HOME:
		case RENT_A_CONDO_TOWNHOUSE:
		case RENT_AN_APARTMENT:
		case RENT_MOBILE_HOME:
			if (useNewerDefinition) {
				scrollAndClickOnElement(bwRentRadioButton);
			} else {
				scrollAndClickOnElement(bwOldRentRadioButton);
			}
			break;
		default:
			if (useNewerDefinition) {
				scrollAndClickOnElement(bwNoInsuranceRadioButton);
			} else {
				scrollAndClickOnElement(bwOtherRadioButton);
			}
			break;
		}
		Log.info("Selecting <" + residenceOwnership + "> as home ownership information");
		if (useNewerDefinition) {
			fsa.assertTrue(getTextFromElement(bwResidenceOwnershipDescription).contains(BW_RESIDENCE_OWNERSHIP_DESCRIPTION), "bwResidenceOwnershipDescription contains " + BW_RESIDENCE_OWNERSHIP_DESCRIPTION);
		} else {
			fsa.assertTrue(getTextFromElement(residenceOwnershipDescription).contains(RESIDENCE_OWNERSHIP_DESCRIPTION), "residenceOwnershipDescription contains " + RESIDENCE_OWNERSHIP_DESCRIPTION);
		}
	}

	private void bwEnterPeopleInHousehold(String stateCode) throws Exception {
		if (stateCode.equals(MN)) {
			enterInsurancePolicyType();
			enterPeopleInHousehold();
		} else if (stateCode.equals(ND)) {
			enterPeopleInHousehold();
		}
	}

	private void enterBundleInsuranceInformation(SqlDiscount discounts, String stateCode, int age, FarmersSoftAssert fsa) {
		String homeOwnership = discounts.getOwnOrRentHome();
		if (isBundleSectionAvailable() && age > MAX_YOUNG_AGE) {
			if (hasBundleInsuranceDescriptionState(stateCode)) {
				fsa.assertEquals(getTextFromElement(bundleInsuranceDescription), BUNDLE_DESCRIPTION, "bundleInsuranceDescription");
			}
			if (findInCallStack(CREATE_CROSS_SELL_AUTO_QUOTE)) {
				if (isElementVisible(bundleHomeInsuranceCheckbox, 5)) {
					scrollToCheckboxAndSetToValue(bundleHomeInsuranceCheckbox, discounts.isHomeInsurance());
				}
				if (isElementVisible(bundleRentersInsuranceCheckbox, 5)) {
					scrollToCheckboxAndSetToValue(bundleRentersInsuranceCheckbox, discounts.isRentersInsurance());
				}
				if (isElementVisible(bundleCondoInsuranceCheckbox, 5)) {
					scrollToCheckboxAndSetToValue(bundleCondoInsuranceCheckbox, discounts.isCondoInsurance());
				}
			} else {
				setHomeOwnershipBundle(discounts, stateCode, homeOwnership);
			}
			if (isLifeInsuranceOfferingState(stateCode) && age <= MIN_OLD_AGE) {
				scrollToCheckboxAndSetToValue(bundleVTLInsuranceCheckbox, discounts.isValueTermLifeInsurance());
			}
			if (isUmbrellaInsuranceState(stateCode)) {
				scrollToCheckboxAndSetToValue(bundleUmbrellaInsuranceCheckbox, discounts.isUmbrellaInsurance());
			}
			if (isBusinessInsuranceState(stateCode)) {
				scrollToCheckboxAndSetToValue(bundleBusinessInsuranceCheckbox, discounts.isBusinessInsurance());
			}
		}
	}

	private void setHomeOwnershipBundle(SqlDiscount discounts, String stateCode, String homeOwnership) {
		if (homeOwnership.contains("Rent") && !isRentersCrossSellDisabledState(stateCode)) {
			scrollToCheckboxAndSetToValue(bundleRentersInsuranceCheckbox, discounts.isRentersInsurance());
		} else if (homeOwnership.contains(OWN_A_HOME) && !isHomeCrossSellDisabledState(stateCode)) {
			scrollToCheckboxAndSetToValue(bundleHomeInsuranceCheckbox, discounts.isHomeInsurance());
		} else if (homeOwnership.contains(OWN_A_CONDO) && !isCondoCrossSellDisabledState(stateCode)) {
			scrollToCheckboxAndSetToValue(bundleCondoInsuranceCheckbox, discounts.isCondoInsurance());
		}
	}

	private void enterBWBundleInsuranceInformation(SqlDiscount discounts, String stateCode, int age, FarmersSoftAssert fsa) {
		String homeOwnership = discounts.getOwnOrRentHome();
		if (isBundleSectionAvailable() && age > MAX_YOUNG_AGE) {
			if (hasBundleInsuranceDescriptionState(stateCode)) {
				fsa.assertEquals(getTextFromElement(bundleInsuranceDescription), BUNDLE_DESCRIPTION, "bundleInsuranceDescription");
			}
			if (findInCallStack(CREATE_CROSS_SELL_AUTO_QUOTE)) {
				if (isElementVisible(bundleBWHomeInsuranceCheckbox, 5)) {
					scrollToCheckboxAndSetToValue(bundleBWHomeInsuranceCheckbox, discounts.isHomeInsurance());
				}
				if (isElementVisible(bundleBWRentersInsuranceCheckbox, 5)) {
					scrollToCheckboxAndSetToValue(bundleBWRentersInsuranceCheckbox, discounts.isRentersInsurance());
				}
				if (isElementVisible(bundleBWCondoInsuranceCheckbox, 5)) {
					scrollToCheckboxAndSetToValue(bundleBWCondoInsuranceCheckbox, discounts.isCondoInsurance());
				}
			} else {
				setBWHomeOwnershipBundle(discounts, stateCode, homeOwnership);
			}
			if (isUmbrellaInsuranceState(stateCode)) {
				scrollToCheckboxAndSetToValue(bundleBWUmbrellaInsuranceCheckbox, discounts.isUmbrellaInsurance());
			}
			if (isBusinessInsuranceState(stateCode)) {
				scrollToCheckboxAndSetToValue(bundleBWBusinessInsuranceCheckbox, discounts.isBusinessInsurance());
			}
		}
	}

	private void setBWHomeOwnershipBundle(SqlDiscount discounts, String stateCode, String homeOwnership) {
		if (homeOwnership.contains("Rent") && !isRentersCrossSellDisabledState(stateCode)) {
			scrollToCheckboxAndSetToValue(bundleBWRentersInsuranceCheckbox, discounts.isRentersInsurance());
		} else if (homeOwnership.contains(OWN_A_HOME) && !isHomeCrossSellDisabledState(stateCode)) {
			scrollToCheckboxAndSetToValue(bundleBWHomeInsuranceCheckbox, discounts.isHomeInsurance());
		} else if (homeOwnership.contains(OWN_A_CONDO) && !isCondoCrossSellDisabledState(stateCode)) {
			scrollToCheckboxAndSetToValue(bundleBWCondoInsuranceCheckbox, discounts.isCondoInsurance());
		}
	}

	private void scrollToCheckboxAndSetToValue(WebElement checkbox, boolean isSelected) {
		scrollToElement(checkbox);
		setCheckboxTo(checkbox, isSelected);
	}

	private boolean hasBundleInsuranceDescriptionState(String stateCode) {
		List<String> noBundleInsuranceDescriptionStates = new ArrayList<>(Arrays.asList(AZ, IA, IL));
		return !noBundleInsuranceDescriptionStates.contains(stateCode);
	}

	private boolean isBundleSectionAvailable() {
		return isElementPresentByXPath(BUNDLE_INSURANCE_SECTION_HEADER_XPATH);
	}

	private void enterAdditionalInsuranceCoverageInformation(String stateCode, String value) {
		if (isAdditionalInsuranceCoverageQuestionsState(stateCode)) {
			List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC27208", "TC27211"));
			writeTestcaseState("DiscountsPage.enterAdditionalInsuranceCoverageInformation", stateCode, rallyTestcasesCovered, FAILED);
			if (value.equals("Yes")) {
				scrollAndClickOnElement(disabilityCoverageRadioButton);
			} else {
				scrollAndClickOnElement(noDisabilityCoverageRadioButton);
			}
			writeTestcaseState("DiscountsPage.enterAdditionalInsuranceCoverageInformation", stateCode, rallyTestcasesCovered, PASSED);
		}
	}

	private List<WebElement> getListWithPageElements(String stateCode, String ownOrRentHome, int age) {
		Log.info("Getting List with Your Info Page elements");
		List<WebElement> dpElements = new ArrayList<>();
		dpElements.add(policyStartDateEntryField);
		if (isBundleSectionAvailable()) {
			if (ownOrRentHome.equals(OWN_A_HOME) && !isHomeCrossSellDisabledState(stateCode)) {
				dpElements.add(chooseExpectedElement(bundleBWHomeInsuranceCheckbox, bundleHomeInsuranceCheckbox));
			} else if (ownOrRentHome.contains(RENTS_DWELLING) && !isRentersCrossSellDisabledState(stateCode)) {
				dpElements.add(chooseExpectedElement(bundleBWRentersInsuranceCheckbox, bundleRentersInsuranceCheckbox));
			} else if (ownOrRentHome.equals(OWN_A_CONDO) && !isCondoCrossSellDisabledState(stateCode)) {
				dpElements.add(chooseExpectedElement(bundleBWCondoInsuranceCheckbox, bundleCondoInsuranceCheckbox));
			}
			if (age <= MIN_OLD_AGE && age > MAX_YOUNG_AGE) {
				if (isLifeInsuranceOfferingState(stateCode)) {
					dpElements.add(chooseExpectedElement(bundleBWVTLInsuranceCheckbox, bundleVTLInsuranceCheckbox));
				}
				if (isUmbrellaInsuranceState(stateCode)) {
					dpElements.add(chooseExpectedElement(bundleBWUmbrellaInsuranceCheckbox, bundleUmbrellaInsuranceCheckbox));
				}
				if (isBusinessInsuranceState(stateCode)) {
					dpElements.add(chooseExpectedElement(bundleBWBusinessInsuranceCheckbox, bundleBusinessInsuranceCheckbox));
				}
				if (isAdditionalInsuranceCoverageQuestionsState(stateCode)) {
					dpElements.add(disabilityCoverageRadioButton);
					dpElements.add(noDisabilityCoverageRadioButton);
				}
			}
		}
		dpElements.add(chooseExpectedElement(backButtonBW, backButton));
		dpElements.add(chooseExpectedElement(bwNextYourQuoteButton, nextYourQuoteButton));
		return dpElements;
	}

	private Map<WebElement, String> getMapWithExpectedGTMTags(String stateCode, String ownOrRentHome, int age) {
		Log.info("Getting Map with expected Discount Page elements GTM values");
		Map<WebElement, String> expectedElementGTMMap = new HashMap<>();
		String modifier = isBristolWest ? "BW" : EMPTY_STRING;
		String homeBundleTag = FFQ + modifier + "Auto_bundlechk_homecrosssell_checkbox";
		String rentersBundleTag = FFQ + modifier + "Auto_bundlechk_renterscrosssell_checkbox";
		String condoBundleTag = FFQ + modifier + "Auto_bundlechk_condocrosssell_checkbox";
		String umbrellaBundleTag = FFQ + modifier + "Auto_bundlechk_Umbrellacrosssell_checkbox";
		String businessBundleTag = FFQ + modifier + "Auto_bundlechk_businesscrosssell_checkbox";
		String backButtonTag = FFQ_AUTO + modifier + "Discount_back_button";
		String nextButtonTag = FFQ_AUTO + modifier + "Discount_next_button";

		expectedElementGTMMap.put(policyStartDateEntryField, "FFQ_Auto_Discounts_policystart_date");
		if (isBundleSectionAvailable()) {
			if (ownOrRentHome.equals(OWN_A_HOME) && !isHomeCrossSellDisabledState(stateCode)) {
				expectedElementGTMMap.put(chooseExpectedElement(bundleBWHomeInsuranceCheckbox, bundleHomeInsuranceCheckbox), homeBundleTag);
			} else if (ownOrRentHome.contains(RENTS_DWELLING) && !isRentersCrossSellDisabledState(stateCode)) {
				expectedElementGTMMap.put(chooseExpectedElement(bundleBWRentersInsuranceCheckbox, bundleRentersInsuranceCheckbox), rentersBundleTag);
			} else if (ownOrRentHome.equals(OWN_A_CONDO) && !isCondoCrossSellDisabledState(stateCode)) {
				expectedElementGTMMap.put(chooseExpectedElement(bundleBWCondoInsuranceCheckbox, bundleCondoInsuranceCheckbox), condoBundleTag);
			}
			if (age <= MIN_OLD_AGE && age > MAX_YOUNG_AGE) {
				if (isUmbrellaInsuranceState(stateCode)) {
					expectedElementGTMMap.put(chooseExpectedElement(bundleBWUmbrellaInsuranceCheckbox, bundleUmbrellaInsuranceCheckbox), umbrellaBundleTag);
				}
				if (isBusinessInsuranceState(stateCode)) {
					expectedElementGTMMap.put(chooseExpectedElement(bundleBWBusinessInsuranceCheckbox, bundleBusinessInsuranceCheckbox), businessBundleTag);
				}
				if (isAdditionalInsuranceCoverageQuestionsState(stateCode)) {
					expectedElementGTMMap.put(disabilityCoverageRadioButton, "FFQ_Auto_Discounts_disabilitycoverage_yes_radio");
					expectedElementGTMMap.put(noDisabilityCoverageRadioButton, "FFQ_Auto_Discounts_disabilitycoverage_no_radio");
				}
			}
		}
		expectedElementGTMMap.put(chooseExpectedElement(backButtonBW, backButton), backButtonTag);
		expectedElementGTMMap.put(chooseExpectedElement(bwNextYourQuoteButton, nextYourQuoteButton), nextButtonTag);
		return expectedElementGTMMap;
	}

	private WebElement chooseExpectedElement(WebElement bwElement, WebElement farmersElement) {
		return isBristolWest? bwElement : farmersElement;
	}

	private boolean isAdditionalInsuranceCoverageQuestionsState(String stateCode) {
		List<String> additionalInsuranceCoverageQuestionsStates = new ArrayList<>(Arrays.asList(MI));
		return additionalInsuranceCoverageQuestionsStates.contains(stateCode);
	}

	private String getPolicyStartDate() {
		return getElementValue(policyStartDateEntryField, "Policy Start Date: ");
	}

	public void fillDiscountsInfo(FarmersSoftAssert fsa) throws Exception {
		SignalPage sp = new SignalPage();
		if (sp.onSignalPage()) {
			sp.continueToDiscountPage(false);
		}
		if (this.getPolicyStartDate().isEmpty()) {
			this.enterPolicyStartDate(LocalDate.now().plusDays(10).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)));
		}
		waitElementBeVisibleClickable(ownAHomeRadioButton);
		this.enterHomeOwnershipInformation(OWN_A_HOME, fsa);
		if (isElementDisplayed(By.xpath(XPATH_TO_DISABILITY_INSURANCE))) {
			scrollAndClickOnElement(disabilityCoverageRadioButton);
		}
	}

	public void continueToQuotePage() {
		WebElement nextToQuoteButton = isBristolWestQuote() ? bwNextYourQuoteButton : nextYourQuoteButton;
		scrollToBottomOfPage();
		clickElement(nextToQuoteButton);
		sleep(4);
		waitForSpinnerToBeGone();
	}

	public final boolean onDiscountsPage() {
		if (isElementPresentByID(discountsPageHeader)) {
			return getTextFromElement(discountsPageHeader).equals(DISCOUNT_PAGE_HEADER);
		} else {
			return false;
		}
	}

}
