package com.farmers.ffq.auto.pages.bw;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BristolWestAdditionalDiscountsPage extends AutoBasePage {

    @FindBy(xpath = "//app-additional-discounts//h1")
    private WebElement pageHeader;

    @FindBy(xpath = "//app-additional-discounts//h1/../p")
    private WebElement pageSubheader;

    @FindBy(xpath = "//app-additional-discounts//h1/../div[1]")
    private WebElement otherPolicyGroupLabel;

    @FindBy(id = "RADIO_BUTTON_FOR_H")
    private WebElement homeownerPolicyRadioButton;
    
    @FindBy(xpath = "//label[contains (@for, 'RADIO_BUTTON_FOR_H')]")
    private WebElement homeownerPolicyRadioButtonLabel;
    
    @FindBy(id = "RADIO_BUTTON_FOR_M")
    private WebElement mobileHomeownerPolicyRadioButton;

    @FindBy(xpath = "//label[contains (@for, 'RADIO_BUTTON_FOR_M')]")
    private WebElement mobileHomeownerPolicyRadioButtonLabel;

    @FindBy(id = "RADIO_BUTTON_FOR_R")
    private WebElement rentersPolicyRadioButton;

    @FindBy(xpath = "//label[contains (@for, 'RADIO_BUTTON_FOR_R')]")
    private WebElement rentersPolicyRadioButtonLabel;

    @FindBy(id = "RADIO_BUTTON_FOR_N")
    private WebElement noPolicyRadioButton;

    @FindBy(xpath = "//label[contains (@for, 'RADIO_BUTTON_FOR_N')]")
    private WebElement noPolicyRadioButtonLabel;

    @FindBy(xpath = "//app-additional-discounts//h1/../div[2]")
    private WebElement otherPeopleInHouseholdLabel;

    @FindBy(id = "SHOW_HOUSEHOLD_COUNT_YES")
    private WebElement otherPeopleLivingInHouseholdButton;
    
    @FindBy(id = "SHOW_HOUSEHOLD_COUNT_NO")
    private WebElement noOtherPeopleLivingInHouseholdButton;
    
    @FindBy(id = "CONTINUE_CTA")
    private WebElement continueButton;
    
    public BristolWestAdditionalDiscountsPage() throws Exception {
    	super();
	}

    public boolean isOnBristolWestAdditionalDiscountsPage() {
    	return isElementPresent(By.id("CONTINUE_CTA"), 3);
    }

    public QuoteSummaryAutoPage clickContinue() throws Exception {
    	scrollAndClickOnElement(continueButton);
    	waitForSpinnerToBeGone();
    	return new QuoteSummaryAutoPage();
    }    
}
