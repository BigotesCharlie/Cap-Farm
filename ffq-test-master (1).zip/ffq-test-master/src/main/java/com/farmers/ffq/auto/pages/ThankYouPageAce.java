package com.farmers.ffq.auto.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ThankYouPageAce extends AutoBasePage {

    @FindBy(xpath = "//div[@class='thank-you__title']//h1")
    private WebElement pageTitle;

    @FindBy(xpath = "//div[@class='tui-body thank-you__subtitle']//p")
    private WebElement pageSubTitle;

    @FindBy(xpath = "//div[@class='thank-you__quote-number ng-star-inserted']//span[2]")
    private WebElement thankYouPageQuoteNumber;

    @FindBy (xpath = "//img[@alt='Bristol West logo']")
    private WebElement bristolWestIcon;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public ThankYouPageAce() throws Exception {
    }

    public boolean isOnThankYouPage() {
        return isElementVisible(pageTitle, 15);
    }

    public boolean quickIsOnThankYouPage() {
        return isElementVisible(pageTitle, 3);
    }

    public boolean showsBristolWestIcon() {
        return isElementVisible(bristolWestIcon, 3);
    }

    public String getThankYouPageQuoteNumber() {
        scrollToElement(thankYouPageQuoteNumber);
        return getTextFromElement(thankYouPageQuoteNumber);
    }

    public String getThankYouPageTitle() {
    	return getTextFromElement(pageTitle);
    }

    public String getThankYouPageSubtitle() {
    	return getTextFromElement(pageSubTitle);
    }
}
