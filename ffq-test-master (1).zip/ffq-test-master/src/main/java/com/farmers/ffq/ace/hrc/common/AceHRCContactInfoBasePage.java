package com.farmers.ffq.ace.hrc.common;

import com.farmers.ffq.common.enums.FfqBundleOptions;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Home.Field;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.SqlDiscount;
import com.farmers.ffq.datatransferobjects.ffqace.AceHomeSupportedOccupationByState;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import lombok.SneakyThrows;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.farmers.ffq.common.pages.FfqAceBasePage.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCContactInfoBasePage extends AceHRCBasePage {
    private static final String AUTO_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "Nice! We'll add an auto bundle discount.";
    private static final String AUTO_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Auto & Home discount has been removed.";
    private static final String LIFE_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "Nice! We'll add a life bundle discount.";
    private static final String LIFE_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Home & Life discount has been removed.";
    private static final String UMBRELLA_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "Nice! We'll add an umbrella bundle discount.";
    private static final String MULTI_POLICY_CEA_DISCOUNT_CONGRATULATIONS_MESSAGE = "Great! We've added the Multi-policy Discount - CEA.";
    private static final String MULTI_POLICY_CEA_DISCOUNT_REMOVED_MESSAGE = "Multi-policy Discount - CEA has been removed.";
    private static final String UMBRELLA_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Home & Umbrella discount has been removed.";
    private static final String BUSINESS_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "Congrats! We added a business bundle discount!";
    private static final String BUSINESS_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Home & Business discount has been removed.";
    private static final String WATERCRAFT_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "Congrats -- we added a watercraft bundle discount!";
    private static final String WATERCRAFT_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Home & Watercraft discount has been removed.";
    private static final String OFF_ROAD_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "How fun -- we'll add an off-road bundle discount!";
    private static final String OFF_ROAD_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Home & Off-road vehicle discount has been removed.";
    private static final String RV_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "Hit the road! We've added an RV bundle discount.";
    private static final String RV_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Home & RV discount has been removed.";
    private static final String EXPECTED_ESTIMATED_CLOSING_DATE_TITLE = "What is your estimated closing date?";
    private static final String EXPECTED_ESTIMATED_CLOSING_DATE_AREA_LABEL = "Estimated closing date";

    private static final String EXPECTED_POLICY_START_DATE_TITLE = "When would you like your%s policy to begin?";
    private static final String EXPECTED_DATE_PICKER_AREA_LABEL = "Policy start date";
    protected static final String EXPECTED_EARLY_SHOPPING_INFO_TITLE = "Early shopping discount";
    private static final String MAILING_ADDRESS = "Mailing Address";
    private static final String EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION = "If your policy start date is 7 or more days from today, " +
            "you may get an early shopping discount. You can start your policy up to 60 days in the future.";

    private static final String EXPECTED_EARLY_SHOPPER_CONGRATS_MESSAGE = "Congratulations \u2014 You may get the early shopping discount!";

    private static final String ESTIMATED_CLOSING_DATE_INFO_TITLE = "Estimated closing date";
    private static final String ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION = "For now, provide an estimated date of when you expect escrow to close. We will confirm your actual close date later.";
    private static final String EXPECTED_PERSONAL_INFO_LABEL = "Contact information";
    @FindBy(css = "h1[class*='tui-h1']")
    private WebElement lastStepBeforeYourPageHeader;

    @FindBy(xpath = "//div[contains(@class,'contact-info-heading-note')]")
    private WebElement fewMoreQuestionBeforeYourQuoteHeader;
    @FindBy(xpath = "//div[contains(@class,'tooltip-section')]//div")
	protected WebElement policyStartDateOrEstimatedClosingDateTitle;

    @FindBy(xpath = "//app-contact-info//app-date-picker//mat-label")
	protected WebElement policyStartDateOrEstimatedClosingDatePlaceHolderText;
    @FindBy(xpath = "//app-contact-info//app-date-picker//input[contains(@class,'text-field-autofill')]")
	protected WebElement policyStartDateOrEstimatedClosingDateInputField;

    @FindBy(xpath = "//div[@id='policyStartDateDiv']//div[@class='discount-info']//div//div")
    protected WebElement earlyDiscountOrEstimatedClosingDateInfoTitle;

    @FindBy(xpath = "//div[@id='policyStartDateDiv']//div[@class='discount-info']//div//p")
    protected WebElement earlyDiscountOrEstimatedClosingDateInfoDescription;


    @FindBy(xpath = "//div[@id='policyStartDateDiv']//mat-icon[@id='policyStartDateDiv_info']")
    protected WebElement earlyShoppingInfoIcon;
    @FindBy(xpath = "//app-model-info-box//h1")
    protected WebElement infoModalTitle;
    @FindBy(xpath = "//app-model-info-box//div/p[contains(@class,'model-caption-text')]")
    protected WebElement infoModalText;
    @FindBy(xpath = "//app-model-info-box//mat-icon[text()='close']")
    protected WebElement infoModalButtonClose;


    @FindBy(css = "#auto-contact-info-early-shopper-message-container>div")
    private WebElement earlyDiscountCongratulationMessage;

    @FindBy(xpath = "//div[@id='policyContainerDiv']//mat-icon[@alt='Congratulations']")
    private WebElement earlyDiscountCongratulationGreenCheck;


    private static final String POLICY_START_DATE_XPATH = "//input[@aria-label='params.ariaLabel']";
    @FindBy(xpath = POLICY_START_DATE_XPATH)
    private WebElement policyStartOrEstimatedClosingDateDatePicker;

    private static final String DATEPICKER_TOGGLE_ICON_XPATH = "//mat-datepicker-toggle[contains(@class,'mat-datepicker-toggle')]";
    @FindBy(xpath = DATEPICKER_TOGGLE_ICON_XPATH)
	protected WebElement datePickerToggleIcon;

    @FindBy(xpath = "//app-date-picker//input[contains(@class,'form-field-autofill')]")
    private WebElement policyStartOrEstimatedClosingDateInputField;

    @FindBy(xpath = "//div[@id='policyStartDateDiv']//mat-error")
    private WebElement policyStartOrEstimatedClosingDateDateError;

    @FindBy(xpath = "//button[descendant::*[contains(@class,'selected')]]")
	protected WebElement selectedDateInDatePickerPopUp;

    @FindBy(xpath = "//div[contains(@class,'mat-calendar-header')]//button[contains(@class,'mat-calendar-period-button')]")
	protected WebElement selectedMonthYearHeaderInDatePickerPopUp;

    @FindBy(xpath = "//div[@id='mailingAddressDiv']//*[contains(@class,'tui-field-label-text')]")
    private WebElement mailingAddressLabel;

    @FindBy(xpath = "//mat-radio-button[@id='mailingAddressDiv_1']")
    protected WebElement defaultMailingAddressRadioButton;
    @FindBy(xpath = "//div[@id='mailingAddressDiv']//mat-radio-button[1]")
    protected WebElement defaultMailingAddressRadioButtonLabel;
    @FindBy(xpath = "//input[@id='mailingAddressDiv_2-input']")
    protected WebElement otherMailingAddressRadioButton;
    @FindBy(xpath = "//mat-radio-button[contains(.,'Other mailing address')]")
    protected WebElement otherMailingAddressRadioButtonLabel;

    @FindBy(xpath = "//div[@id='formField_address']//mat-label")
    private WebElement mailingAddressInputLabel;

    @FindBy(xpath = "//div[@id='formField_address']//mat-error")
    private WebElement mailingAddressError;

    @FindBy(css = "input[aria-label='Apartment number (optional)']")
    private WebElement apartmentNumberInputField;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_apartment']//mat-label")
    private WebElement apartmentInputLabel;

    @FindBy(xpath = "//mat-form-field[@id='auto-contact-info-apartment__input-field']//mat-error")
    private WebElement invalidAptError;
    @FindBy(css = "input[aria-label='City']")
    protected WebElement cityInputField;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_city']//mat-label")
    private WebElement cityInputLabel;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_city']//mat-error")
    private WebElement cityError;

    @FindBy(css = "mat-select[aria-label='State']")
    protected WebElement stateDropDown;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-label")
    private WebElement stateDropDownLabel;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-error/div")
    private WebElement stateError;

    @FindBy(css = "input[aria-label='Zip code']")
    protected WebElement zipCodeInputField;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//mat-label")
    private WebElement zipCodeInputLabel;

    @FindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//mat-error/div")
    private WebElement zipCodeError;
    @FindBy(xpath = "//address-autocomplete-input//input")
    private WebElement otherMailingAddressInputField;
    @FindBy(xpath = "//div[@id='mailingAddressDiv_apartment']//input")
    private WebElement otherMailingAddressUnitInputField;
    @FindBy(xpath = "//div[@id='mailingAddressDiv_city']//input")
    private WebElement otherMailingAddressCityInputField;
    @FindBy(xpath = "//div[@id='mailingAddressDiv_state']//mat-select")
    private WebElement otherMailingAddressStateDropdownField;
    @FindBy(xpath = "//div[@id='mailingAddressDiv_zipCode']//input")
    private WebElement otherMailingAddressZipCodeInputField;
    @FindBy(xpath = "//span[@class='mat-option-text']")
    private List<WebElement> listOfAllTheStatesInOtherMailingAddressStateDropDown;

    @FindBy(xpath = "//div[@id='flex-field-emailAddress_contactInfo']/p")
    private WebElement personalInfoLabel;

    @FindBy(xpath = "//div[@class='email-address']//label")
    private WebElement emailAddressFieldLabel;

    @FindBy(xpath = "//div[@id='flex-field-emailAddress_contactInfo']//mat-error")
    private WebElement emailAddressError;

    @FindBy(xpath = "//div[@id='flex-field-phoneNumber_contactInfo']//label")
    private WebElement mobilePhoneFieldLabel;

    @FindBy(xpath = "//div[@id='flex-field-phoneNumber_contactInfo']//input")
    protected WebElement phoneNumberInput;

    @FindBy(xpath = "//div[@id='flex-field-phoneNumber_contactInfo']//mat-error")
    private WebElement phoneNumberError;

    @FindBy(xpath = "//span[contains(.,'Text me a link')]")
    private WebElement textMeALinkCheckboxLabel;

    @FindBy(xpath = "//mat-checkbox/following-sibling::p")
    private WebElement textAuthorization;

    @FindBy(xpath = "//p[contains(.,'terms')]/a")
    private WebElement termsConditionLink;

    @FindBy(xpath = "//div[contains(@class,'contact-info-cta-validation')]")
    private WebElement pageErrorMessage;

    @FindBy(xpath = "//p[span[@class='contactInfoDisclaimer']]")
	protected WebElement pageFooterDisclaimer;

    @FindBy(linkText = "associated entities")
    private WebElement linkAssociatedEntities;

    @FindBy(xpath = "//h1")
    private WebElement electronicSignHeader;

    @FindBy(xpath = "//span[@class='h1']")
    private WebElement ourCompaniesHeader;

    @FindBy(xpath = "//p[span[@class='contactEsignDisclaimer']]")
	protected WebElement pageFooterDisclaimerEsign;

    @FindBy(linkText = "ESIGN terms and conditions")
    private WebElement linkDisclaimerEsign;

    @FindBy(xpath = "//p[contains(@class,'consent-disclaimer disclaimer-mobile-view-Margin')]/span[1]")
    private WebElement mobileDisclaimerAddition;

    @FindBy(xpath = "//button[@id='contactInfoCTAButton' and not(@hidden)]")
    public WebElement agreeAndSubmitButton;

    @FindBy(css = "button[class='auto-agent-details__save-link tui-link-button']")
    public WebElement saveQuoteButton;

    @FindBy(xpath = "//div[contains(@class,'save-in-progress-section')]/p")
    private WebElement progressSavedSection;

    private static final String EMAIL_ADDRESS_XPATH = "//div[@id='flex-field-emailAddress_contactInfo']//input";
    @FindBy(xpath = EMAIL_ADDRESS_XPATH)
    protected WebElement emailAddressInput;

    @FindBy(css = "input[aria-label='Mailing Address']")
    protected WebElement mailingAddressInputField;

    @FindBy(className = "save-bundle-info-heading-note")
	protected WebElement bundleSaveHeadingNote;


    @FindBy(xpath = "//app-save-bundle-sheet")
    private WebElement bundleAndSaveSection;
    @FindBy(xpath = "//app-save-bundle-sheet//h2")
	protected WebElement bundleSaveHeading;
    @FindBy(xpath = "//div[@id='saveBundleDiv']//h2[text()='Other details']")
    private WebElement otherDetailsTitle;
    @FindBy(xpath = "//div[@id='saveBundleDiv']//p[text()='Bundle discount']")
    private WebElement bundleDiscountTitle;
    private static final String BUNDLE_CHECKBOXES_XPATH = "//*[@class='save-bundle-discount-sheet']//mat-checkbox";
    @FindBy(xpath = BUNDLE_CHECKBOXES_XPATH)
	protected List<WebElement> saveBundleMatCheckboxes;
    @FindBy(xpath = BUNDLE_CHECKBOXES_XPATH + "//following-sibling::span")
	protected List<WebElement> saveBundleCheckboxesText;
    @FindBy(xpath = BUNDLE_CHECKBOXES_XPATH + "//input")
	protected List<WebElement> saveBundleMatCheckboxInputs;
    @FindBy(xpath = "//i[contains(@style,'rebrand-auto')]")
    private WebElement autoBundleIcon;
    @FindBy(xpath = "//i[contains(@style,'rebrand_home')]")
    private WebElement homeBundleIcon;
    @FindBy(xpath = "//i[contains(@style,'rebrand-life')]")
    private WebElement lifeBundleIcon;
    @FindBy(xpath = "//i[contains(@style,'rebrand-umbrella')]")
    private WebElement umbrellaBundleIcon;
    @FindBy(xpath = "//i[contains(@style,'rebrand_home')]")
    private WebElement multiPolicyCEAIcon;
    @FindBy(xpath = "//i[contains(@style,'rebrand-business')]")
    private WebElement businessBundleIcon;
    @FindBy(xpath = "//i[contains(@style,'rebrand_boat')]")
    private WebElement boatsBundleIcon;
    @FindBy(xpath = "//i[contains(@style,'atv_offroad_rebrand')]")
    private WebElement offRoadVehicleBundleIcon;
    @FindBy(xpath = "//i[contains(@style,'mobilehome_rebrand')]")
    private WebElement motorHomeBundleIcon;

    @FindBy(xpath = "//p[contains(@class,'auto-driver-review-save-bundle-congratulations-message')]")
    private WebElement saveBundleCongratulationMessage;
    @FindBy(xpath = "//div[@id='saveBundleDiv']//div[contains(@class,'discount-info')]//div")
	protected WebElement bundleAndSaveTipHeader;
    @FindBy(xpath = "//div[@id='saveBundleDiv']//div[contains(@class,'discount-info')]//p")
	protected WebElement bundleAndSaveTipDescription;

    @FindBy(xpath = "//app-save-bundle-sheet//mat-icon")
	protected WebElement saveBundleInfoIcon;

    private static final String ADDITIONAL_PRODUCTS_LINK_XPATH = "//div[@id='view-additional-products']//a";
    @FindBy(xpath = ADDITIONAL_PRODUCTS_LINK_XPATH)
    protected WebElement viewAdditionProductsLink;
    private static final String VIEW_ADDITIONAL_PRODUCT_LINK_TEXT = "View additional products to bundle";

    protected static final String FIRE_HYDRANT_SECTION_XPATH = "//app-contact-info//div[@id='fireHydrantdiv']";
    @FindBy(xpath = FIRE_HYDRANT_SECTION_XPATH)
    private WebElement fireHydrantSection;

    @FindBy(xpath = FIRE_HYDRANT_SECTION_XPATH + "//p")
    private WebElement fireHydrantSectionTitle;

    @FindBy(xpath = FIRE_HYDRANT_SECTION_XPATH + "//label")
    private WebElement fireHydrantSectionLabel;

    private static final String FIRE_HYDRANT_BUTTON_XPATH = "//app-contact-info//mat-button-toggle-group[contains(@class,'fireHydrantToggle')]";

    private static final String FIRE_HYDRANT_RADIO_BUTTON_QUESTIONS_XPATH = "//app-contact-info//div[@id='fireHydrantdiv']//p[contains(@class,'radio-group')]";
    @FindBy(xpath = FIRE_HYDRANT_RADIO_BUTTON_QUESTIONS_XPATH)
    private WebElement fireHydrantQuestionsText;

    @FindBy(xpath = "//app-contact-info//div[@id='fireHydrantdiv']//div[contains(@class,'tui-radio-button-group')][1]/label")
    private WebElement fireHydrantQuestion1label;

    @FindBy(xpath = "//app-contact-info//div[@id='fireHydrantdiv']//div[contains(@class,'tui-radio-button-group')][2]/label")
    private WebElement fireHydrantQuestion2label;

    private static final String IS_HOME_VISIBLE_QUESTION_BUTTON_XPATH = "//app-contact-info//div[@id='fireHydrantdiv']";

    private static final String IS_SECONDARY_HEATING_SOURCE_BUTTON_QUESTION_XPATH = FIRE_HYDRANT_SECTION_XPATH +
            "//mat-radio-group[@aria-label='Is there a secondary heating source installed in the home that burns wood, pellets, " +
            "coal or kerosene (excluding a fireplace)?']";

    protected static final String WILDFIRE_RISK_REDUCTION_MAT_CHECKBOX_XPATH = "//app-wildfire-selection//mat-checkbox[contains(.,'%s')]";
    protected static final String WILDFIRE_RISK_REDUCTION_TEMPLATE_XPATH = "//app-wildfire-selection//mat-checkbox[contains(.,'%s')]/label";
    @FindBy(xpath = "//app-wildfire-selection//mat-checkbox")
    List<WebElement> wildfireRiskReductionOptions;

    protected static final String WILDFIRE_RISK_REDUCTION_XPATH = "//div[@id='wildfireDiscount']";
    @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//label")  // text from  label + span = full sub-text
    protected WebElement wildfireRiskReductionLabelCA;
    @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//span")
    protected WebElement wildfireRiskReductionSpanCA;
    @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//mat-button-toggle[contains(.,'Yes')]")
    protected WebElement wildfireRiskMatButtonToggleYes;
    @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//mat-button-toggle[contains(.,'No')]")
    protected WebElement wildfireRiskMatButtonToggleNo;
    @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//mat-button-toggle[contains(.,'Yes')]//button")
    protected WebElement wildfireRiskButtonToggleYes;
    @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//mat-button-toggle[contains(.,'No')]//button")
    protected WebElement wildfireRiskButtonToggleNo;
    @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//a[text()='Edit']")
    protected WebElement editWildfireRiskReduction;
    @FindBy(xpath = WILDFIRE_RISK_REDUCTION_XPATH + "//div[contains(@class,'wildfire-riskreduction-subtext')]")
    protected WebElement wildfireRiskReductionSubtextCA;
    @FindBy(xpath = "//app-wildfire-selection//mat-icon[text()='close']")
    protected WebElement closeWildfireSideSheet;
    @FindBy(xpath = "//app-wildfire-selection//button[text()='Save']")
    protected  WebElement saveButtonWildfireRisk;
    @FindBy(xpath = "//mat-dialog-container[contains(.,'No selections made')]")
    protected WebElement dialogNoChanges;
    @FindBy(xpath = "//mat-dialog-container[contains(.,'No selections made')]//button[text()='Ok']")
    protected WebElement buttonNoChangesOk;

    @FindBy(xpath = "//app-wildfire-selection")
    protected WebElement wildfireRiskReductionSideSheet;
    @FindBy(xpath = "//app-wildfire-selection//h2")
    protected WebElement wildfireRiskReductionSideSheetTitle;
    @FindBy(xpath = "//app-wildfire-selection//mat-divider")
    protected WebElement wildfireRiskReductionSideSheetDivider;
    @FindBy(xpath = "//app-wildfire-selection//div[contains(@class,'tui-input-text')]/p[1]")
    protected WebElement wildfireRiskReductionSideSheetSubtitle;
    @FindBy(xpath = "//app-wildfire-selection//div[contains(@class,'tui-input-text')]/hr")
    protected WebElement wildfireRiskReductionSideSheetDivider1;
    @FindBy(xpath = "//app-wildfire-selection//div[contains(@class,'tui-input-text')]/p[2]")
    protected WebElement wildfireRiskReductionSideSheetSubtitle2;
    @FindBy(xpath = "//app-wildfire-selection//div//hr[contains(@class,'second-divider')]")
    protected WebElement wildfireRiskReductionSideSheetDivider2;
    @FindBy(xpath = "//app-wildfire-selection//div//hr[contains(@class,'second-divider')]/following-sibling::p")
    protected WebElement wildfireRiskReductionSideSheetSection2Subtitle;
    @FindBy(xpath = "//app-wildfire-selection//mat-checkbox")
    protected List<WebElement> wildfireRiskReductionSideSheetCheckboxes;
    @FindBy(xpath = "//app-wildfire-selection//mat-checkbox//label//p[contains(@class,'tui-input-text')]")
    protected List<WebElement> wildfireRiskReductionSideSheetCheckboxLabels;

    @FindBy(xpath = "//div[@id='floorResidenceContactInfo']")
    private WebElement residenceFloorSection;
    @FindBy(xpath = "//div[@id='floorResidenceContactInfo']//*[contains(@class,'tui-subtitle-text-1')]")
    private WebElement residenceFloorSectionSubtitle;
    @FindBy(xpath = "//div[@id='floorResidenceContactInfo']/mat-checkbox")
    private WebElement residenceFloorCheckbox;
    @FindBy(xpath = "//div[@id='floorResidenceContactInfo']//*[contains(@class,'label')]")
    private WebElement residenceFloorInfoLabel;
    @FindBy(xpath = "//div[@id='floorResidenceContactInfo']//*[contains(@class,'floorResidence-cont-info_checkbox-description')]")
    private WebElement residenceFloorInfoDescription;

    @FindBy(xpath = "//p[contains(@class,'tui-body-text mt')]//span[@id='conactInfoDisclaimer']")
    private WebElement contactInfoDisclaimer;
    @FindBy(xpath = "//p[contains(text(),'Primary named insured')]")
    private WebElement primaryInsuranceGroupTitle;
    @FindBy(xpath = "//mat-card//div[contains(@class,'brand-selection')]/p[1]")
    private WebElement selectInsuranceGroupTitle;
    @FindBy(xpath = "//mat-label[contains(@class,'brand-label')]")
    private WebElement selectAllCheckboxLabel;
    @FindBy(xpath = "//mat-label[normalize-space()='Farmers\u00ae']")
    private WebElement farmersCheckboxLabel;
    @FindBy(xpath = "//mat-label[normalize-space()='Bristol West\u00ae']")
    private WebElement BWCheckboxLabel;
    @FindBy(xpath = "//mat-label[normalize-space()='Farmers Life\u00ae']")
    private WebElement farmersLifeCheckboxLabel;
    @FindBy(xpath = "//mat-label[normalize-space()='Foremost\u00ae']")
    private WebElement foremostCheckboxLabel;
    @FindBy(xpath = "//p[normalize-space()='Choose them individually below:']")
    private WebElement selectAllCheckboxSubLabel;
    @FindBy(xpath = "//mat-label[normalize-space()='Farmers\u00ae']/following-sibling::p")
    private WebElement farmersCheckboxSubLabel;
    @FindBy(xpath = "//mat-label[normalize-space()='Bristol West\u00ae']/following-sibling::p")
    private WebElement BWCheckboxSubLabel;
    @FindBy(xpath = "//mat-label[normalize-space()='Farmers Life\u00ae']/following-sibling::p")
    private WebElement farmersLifeCheckboxSubLabel;
    @FindBy(xpath = "//mat-label[normalize-space()='Foremost\u00ae']/following-sibling::p")
    private WebElement foremostCheckboxSubLabel;
    @FindBy(xpath = "//div[@id='contactDetailsDiv']//div//li")
    private WebElement primaryInsuredName;
    protected static final String BRANDS_CHECKBOXES_XPATH = "(//div[@class='brand-selection']//div/mat-checkbox)[%d]";
    @FindBy(xpath = "//div[@class='brand-selection']//div/mat-checkbox")
    protected List<WebElement> individualBrandCheckboxes;
    protected static final String ALL_BRANDS_CHECKBOX_XPATH = "//div[@class='brand-selection']//mat-checkbox";
    @FindBy(xpath = ALL_BRANDS_CHECKBOX_XPATH)
    protected WebElement allBrandsCheckbox;
    @FindBy(xpath = "//button[contains(@class, 'continue-button')]")
    protected WebElement continueButtonBundleContactInfoPage;

    private static final String GENDER_SELECTION_XPATH = "//label[@id='formField_label_gender']/..//mat-button-toggle";
    @FindBy (xpath = GENDER_SELECTION_XPATH)
    List<WebElement> genderButtons;
    @FindBy (xpath = GENDER_SELECTION_XPATH)
    WebElement genderButton;

    private static final String FIRST_NAME = "First name";
    @FindBy(xpath = "//input[@aria-label='" + FIRST_NAME + "']")
    protected WebElement firstNameInputBox;

    @FindBy(xpath = "//mat-label[contains(text(), '" + FIRST_NAME + "')]")
    private WebElement firstNameAriaLabelText;

    private static final String LAST_NAME = "Last name";
    @FindBy(xpath = "//input[@aria-label='" + LAST_NAME + "']")
    protected WebElement lastNameInputBox;
    @FindBy(xpath = "//mat-label[contains(text(), '" + LAST_NAME + "')]")
    private WebElement lastNameAriaLabelText;

    private static final String DATE_OF_BIRTH_ARIA_LABEL = "Date of birth";
    private static final String DATE_OF_BIRTH_ARIA_LABEL_INPUT_BOX = "Date of birth in the format of mmddyyyy.";
    @FindBy(xpath = "//input[@aria-label='" + DATE_OF_BIRTH_ARIA_LABEL_INPUT_BOX + "']")
    protected WebElement dateOfBirthInputBox;
    @FindBy(xpath = "//mat-label[contains(text(), '" + DATE_OF_BIRTH_ARIA_LABEL + "')]")
    private WebElement dateOfBirthAriaLabelText;
    @FindBy(xpath = "//mat-hint[contains(text(), 'mm/dd/yyyy')]")
    private WebElement mmddyyyyHint;
    @FindBy(xpath = "//div[@id='spouseDetailsDiv']//div[contains(@class,'home-about-you__input-fields')]")
    private WebElement spouseInputFieldSection;

    @FindBy(xpath = "//div[@id='spouseDetailsDiv']//mat-form-field//input")
    private List<WebElement> spouseElements;
    private static final String SPOUSE_FIRST_NAME = "Spouse's First name";
    @FindBy(xpath = "//input[@aria-label=\"Spouse's First name\"]")
    private WebElement spouseFirstNameInputBox;

    private static final String SPOUSE_LAST_NAME = "Spouse's Last name";
    @FindBy(xpath = "//input[@aria-label=\"Spouse's Last name\"]")
    private WebElement spouseLastNameInputBox;

    private static final String SPOUSE_DATE_OF_BIRTH_ARIA_LABEL = "Spouse's Date Of birth";
    @FindBy(xpath = "//input[@aria-label=\"Spouse's Date Of birth\"]")
    private WebElement spouseDateOfBirthInputBox;

    @FindBy(xpath = "//mat-form-field[@id='auto-contact-info-city__input-field']//input")
    private WebElement priorOrCurrentAddressCityInputBox;
    @FindBy(xpath = "//mat-form-field[@id='state']//mat-select")
    private WebElement priorOrCurrentAddressStateSelect;
    @FindBy(xpath = "//mat-form-field[@id='auto-contact-info-zipCode__input-field']//input")
    private WebElement priorOrCurrentAddressZipInputBox;

    @FindBy(xpath = "//h2[contains(text(), '" + ABOUT_YOU_HEADER + "')]")
    protected WebElement aboutYouHeader;

    private static final String SPOUSE_GENDER_SELECTION_XPATH = "//label[@id='formField_label_spouseGender']/..//mat-button-toggle";
    @FindBy (xpath = SPOUSE_GENDER_SELECTION_XPATH)
    List<WebElement> spouseGenderButtons;

    @FindBy(xpath = "//div[contains(@class,'isMarried')]//mat-checkbox")
    private WebElement marriedOrInDomesticRelationMatCheckbox;
    @FindBy(xpath = "//div[contains(@class,'isMarried')]//input[@type='checkbox']")
    private WebElement marriedOrInDomesticRelationCheckboxInput;
    @FindBy(xpath = "//p[contains(@class, 'spouse__checkbox-description')]")
    private WebElement marriedOrInDomesticRelationCheckBoxDescription;
    private static final String MARRIED_CHECKBOX_DESCRIPTION = "Check to add your spouse or partner";
    private static final String MARRIED_DOMESTIC_RELATIONSHIP_LABEL = "Married or in a domestic partnership";
    @FindBy(xpath = "//span[contains(text(), '" + MARRIED_DOMESTIC_RELATIONSHIP_LABEL + "')]")
    private WebElement marriedOrInDomesticRelationLabel;

    private static final String CURRENT_FORMER_EMPLOYED_PROFESSIONAL = "Current or former employed professional (optional)";
    @FindBy(xpath = "//div[@id='primaryOccupationDiv']//p[contains(text(), '" + CURRENT_FORMER_EMPLOYED_PROFESSIONAL + "')]")
    private WebElement currentFormerEmployedHeaderPersonalInfoDiv;

    @FindBy(xpath = "//div[@id='spouseDetailsDiv']//p[contains(text(), '" + CURRENT_FORMER_EMPLOYED_PROFESSIONAL + "')]")
    private WebElement currentFormerEmployedHeaderSpouseDiv;
    private static final String ELIGIBLE_ADDITIONAL_SAVINGS = "Eligible occupations can qualify for additional savings";
    @FindBy(xpath = "//div[@id='primaryOccupationDiv']//p[contains(text(), '" + ELIGIBLE_ADDITIONAL_SAVINGS + "')]")
    private WebElement eligibleOccupationSavingsPersonalInfoDiv;

    @FindBy(xpath = "//div[@id='spouseDetailsDiv']//p[contains(text(), '" + ELIGIBLE_ADDITIONAL_SAVINGS + "')]")
    private WebElement eligibleOccupationSavingsSpouseDiv;

    private static final String ELIGIBLE_OCCUPATION_BUTTON = "See eligible occupations";
    @FindBy(xpath = "//button[@id='primaryOccupation']")
    private WebElement eligibleOccupationButtonPersonalInfoDiv;

    @FindBy(xpath = "//button[@id='spouseOccupation']")
    private WebElement eligibleOccupationButtonSpouseDiv;

    private static final String ELIGIBLE_OCCUPATION_HEADER = "Eligible occupations";
    @FindBy(xpath = "//h1[contains(text(), '" + ELIGIBLE_OCCUPATION_HEADER + "')]")
    private WebElement eligibleOccupationHeader;
    private static final String OCCUPATIONS_RADIO_BUTTONS_XPATH = "//app-occupation-list//mat-radio-button";
    @FindBy(xpath = OCCUPATIONS_RADIO_BUTTONS_XPATH)
    private List<WebElement> occupationRadioButtons;
    @FindBy(xpath = OCCUPATIONS_RADIO_BUTTONS_XPATH)
    private WebElement firstOccupationRadioButton;
    @FindBy(xpath = "//div[contains(@class,'col occupation-retired-checkbox-col')]//p")
    private WebElement currentlyEmployedOrRetiredQuestion;
    private static final String EMPLOYED_OR_RETIRED_TOGGLE_BUTTONS_XPATH = "//div[contains(@class,'col occupation-retired-checkbox-col')]//mat-button-toggle-group//mat-button-toggle//button";
    @FindBy(xpath = EMPLOYED_OR_RETIRED_TOGGLE_BUTTONS_XPATH)
    private List<WebElement> currentlyEmployedOrRetiredToggleButtons;
    @FindBy(xpath = EMPLOYED_OR_RETIRED_TOGGLE_BUTTONS_XPATH)
    private WebElement currentlyEmployedOrRetiredToggleButton;

    @FindBy(xpath = "//div[contains(@class,'col occupation-retired-checkbox-col')]//mat-button-toggle-group//mat-button-toggle//button//span")
    private List<WebElement> currentlyEmployedOrRetiredToggleButtonLabel;
    private static final String OCCUPATION_SUBLIST_XPATH = "//mat-radio-button[contains(@class,'radio-checked')]/following-sibling::*[1]//mat-radio-group//mat-radio-button";

    @FindBy(xpath = "//app-occupation-list//mat-icon[contains(text(), 'close')]")
    private WebElement closeIcon;

    @FindBy(xpath = "//app-occupation-list//button[contains(text(), 'Close')]")
    private WebElement closeButton;

    @FindBy(xpath = "//div[contains(@class,'occupation-retired-checkbox')]//mat-checkbox")
    private WebElement occupationRetiredCheckBox;

    private static final String RETIRED_FORMALLY_EMPLOYED_LABEL = "I am retired and a formerly employed professional";
    @FindBy(xpath = "//span[contains(text(), '" + RETIRED_FORMALLY_EMPLOYED_LABEL + "')]")
    private WebElement retiredFormerlyEmployedLabel;

    @FindBy(xpath = "//button[contains(text(), 'Add')]")
    private WebElement eligibleOccupationAddButton;

    @FindBy(xpath = "//mat-dialog-actions//button[contains(text(), 'Cancel')]")
    private WebElement eligibleOccupationCancelButton;

    @FindBy(xpath = "//div[@id='primaryOccupationDiv']//a")
    private WebElement removeOccupationLinkPrimaryApplicant;
    @FindBy(xpath = "//div[@id='spouseDetailsDiv']//a")
    private WebElement removeOccupationLinkSpouse;
    private static final String REMOVE_OCCUPATION_HEADER_IN_MODAL = "Remove occupation";
    @FindBy(xpath = "//app-remove-occupation//h1[contains(text(), '" + REMOVE_OCCUPATION_HEADER_IN_MODAL + "')]")
    private WebElement removeOccupationHeaderInModalBox;

    @FindBy(xpath = "//button[contains(text(), 'Keep occupation')]")
    private WebElement keepOccupationButton;

    @FindBy(xpath = "//button[contains(text(), 'Remove')]")
    private WebElement removeOccupationButton;
    private static final String REMOVE_OCCUPATION_QUESTION = "Are you sure you want to remove this occupation? You will lose any discount associated with it.";
    @FindBy(xpath = "//mat-dialog-content[contains(text(), '" + REMOVE_OCCUPATION_QUESTION + "')]")
    private WebElement removeOccupationQuestion;

    //home-occupation-selected-message
    @FindBy(xpath = "//div[contains(@class,'home-occupation-selected-message')]")
    private WebElement homeOccupationSelectedMessagePersonalInfo;

    @FindBy(xpath = "//div[@id='spouseDetailsDiv']//div[contains(@class,'home-occupation-selected-message')]")
    private WebElement homeOccupationSelectedMessageSpouseDiv;

    @FindBy(xpath = "//div[@id='primaryOccupationDiv']//div[contains(@class,'home-occupation-selected-message')]")
    private WebElement occupationPrimary;

    @FindBy(xpath = "//div[@id='spouseDetailsDiv']//div[contains(@class,'home-occupation-selected-message')]")
    private WebElement occupationSpouse;

    @FindBy(xpath = "//div[contains(@class,'home-occupation-selected')]")
    private List<WebElement> selectedOccupation;

    @FindBy(xpath = "//address-autocomplete-input//mat-icon")
    private WebElement closeIconInAddressInputBox;

    @FindBy(xpath = "//mat-form-field[@name='home-personal-info-apartment__input-field']//input")
    private WebElement unitInputBox;
    private static final String UNIT_NUMBER_PLACEHOLDER_TEXT = "Unit #";
    @FindBy(xpath = "//mat-label[contains(text(),'" + UNIT_NUMBER_PLACEHOLDER_TEXT + "')]")
    private WebElement unitNumberPlaceholderText;

    private static final String CITY_PLACEHOLDER_TEXT = "City";
    @FindBy(xpath = "//mat-label[contains(text(),'" + CITY_PLACEHOLDER_TEXT + "')]")
    private WebElement cityPlaceholderText;

    private static final String STATE_PLACEHOLDER_TEXT = "State";
    @FindBy(xpath = "//mat-label[contains(text(),'" + STATE_PLACEHOLDER_TEXT + "')]")
    private WebElement statePlaceholderText;

    private static final String ZIP_PLACEHOLDER_TEXT = "ZIP";
    @FindBy(xpath = "//mat-label[contains(text(),'" + ZIP_PLACEHOLDER_TEXT + "')]")
    private WebElement zipPlaceholderText;

    private static final String OPTIONAL_UNIT_NUMBER_HINT = "Optional";
    @FindBy(xpath = "//mat-hint[contains(text(),'" + OPTIONAL_UNIT_NUMBER_HINT + "')]")
    private WebElement optionalUnitNumberHint;

    private static final String PRIOR_ADDRESS_PLACEHOLDER_TEXT = "Prior home address";
    @FindBy(xpath = "//mat-label[contains(text(), '" + PRIOR_ADDRESS_PLACEHOLDER_TEXT + "')]")
    private WebElement priorAddressPlaceHolderText;

    private static final String CURRENT_HOME_ADDRESS_LABEL = "My current home address";
    @FindBy(xpath = "//div[@id='priorCurrentAddress']//div//p")
    private WebElement priorOrCurrentHomeAddressLabel;

    private static final String PRIOR_HOME_ADDRESS_LABEL = "My prior home address";

    private static final String CURRENT_ADDRESS_PLACEHOLDER_TEXT = "Current home address";
    @FindBy(xpath = "//mat-label[contains(text(), '" + CURRENT_ADDRESS_PLACEHOLDER_TEXT + "')]")
    private WebElement currentAddressPlaceHolderText;

    public boolean isCurrentFormerEmployedHeaderDisplayed(boolean isPrimaryApplicant) {
        if (isPrimaryApplicant) {
            return isElementDisplayed(currentFormerEmployedHeaderPersonalInfoDiv, 3);
        } else {
            return isElementDisplayed(currentFormerEmployedHeaderSpouseDiv, 3);
        }
    }

    public boolean isEligibleOccupationSavingsDisplayed(boolean isPrimaryApplicant) {
        if (isPrimaryApplicant) {
            return isElementDisplayed(eligibleOccupationSavingsPersonalInfoDiv, 3);
        } else {
            return isElementDisplayed(eligibleOccupationSavingsSpouseDiv, 3);
        }
    }

    public boolean isEligibleOccupationButtonDisplayed(boolean isPrimaryApplicant) {
        if (isPrimaryApplicant) {
            return isElementDisplayed(eligibleOccupationButtonPersonalInfoDiv, 3);
        } else {
            return isElementDisplayed(eligibleOccupationButtonSpouseDiv, 3);
        }
    }

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceHRCContactInfoBasePage() throws Exception {
    }

    public boolean isOnContactInfoPage(boolean longWait) {
        if (longWait) {
            try {
                waitForSpinnerToBeGone();
                wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOf(policyStartDateOrEstimatedClosingDateInputField),
                        ExpectedConditions.visibilityOf(tryAgainButton)));
            } catch (TimeoutException te) {
                return false;
            }
        }
        return isElementVisible(policyStartDateOrEstimatedClosingDateInputField, 3);
    }

    public void capturePEWC(String filename) throws Exception {
    	scrollToBottomOfPage();
        screenCapture(emailAddressInput, filename, LARGE, false);
    }

    public boolean isOnBundlePolicyStartDatePage() {
    	return isElementDisplayed(policyStartDateOrEstimatedClosingDateInputField, 3);
    }

    public boolean isResidenceInEscrow() throws Exception {
        String inEscrow = getSessionStorageAppStore().getHome().getAddressForm().getFields().get(0).getInEscrow();
        return  (inEscrow != null) && inEscrow.equals("Y");
    }

    public void validateErrorMessages(FarmersSoftAssert fsa, ApplicantAceHome applicant, String lobType) throws Exception {
    	// validate policy start date field error messages
    	validatePolicyStartDateErrorMessages(fsa, lobType);
        // validate spouse section error messages
        if (!List.of(RENTERS, MOBILE_HOME).contains(lobType) && isNewFlowEnabledState(applicant.getStateCode())) {
            validateSpouseSectionErrorMessages(applicant, fsa);
        }
    	// required field error messages validation
    	validateRequiredFieldErrorMessages(fsa, lobType);
    	// validate invalid entries
    	if (!lobType.equals(RENTERS)) {
    		validateInvalidEntriesErrorMessages(fsa);
    	}
    	if (lobType.equals(HOME)) {
    		// validate Fire hydrant section error messages
    		validateFireHydrantSectionErrorMessages(fsa, applicant);
    	}
    }

    public boolean areInvalidDatesTriggerErrorMessageForAgeLimit(ApplicantAceHome applicant) throws Exception {
        String dateOfBirth = generateDateOfBirthYoungerThan15OrOlderThan99();
        AtomicBoolean flag = new AtomicBoolean(true);

        // validate that DOB outside the allowed range (15–99 years) triggers the age-limit error
        fillOutSpouseApplicantFormWithValues(applicant.getFirstName(), applicant.getLastName(), dateOfBirth);

        if (getPageErrors().stream().noneMatch(msg -> msg.contains(AGE_LIMIT_ERROR))) {
            flag.set(false);
            Log.error("Error message did not trigger for this date of birth: " + dateOfBirth);
        }
        return flag.get();
    }

    public boolean areInvalidEntryDatesTriggerErrorMessage(ApplicantAceHome applicant) throws Exception {
        AtomicBoolean flag = new AtomicBoolean(true);

        // validate if Date of Birth is a valid entry
        fillOutSpouseApplicantFormWithValues(applicant.getFirstName(), applicant.getLastName(), INVALID_FORMAT_DATE);

        if (getPageErrors().stream().noneMatch(msg -> msg.contains(DOB_IS_NOT_VALID_ENTRY_ERROR))) {
            flag.set(false);
            Log.error("Error message did not trigger for this date of birth: " + INVALID_FORMAT_DATE);
        }
        return flag.get();
    }

    public void validateInvalidErrorMessagesForAgeLimitAndDob(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome) throws Exception {
        fsa.assertTrue(areInvalidDatesTriggerErrorMessageForAgeLimit(applicantAceHome), "Age-limit error displayed for date of birth outside the allowed range (15–99 years)");
        fsa.assertTrue(areInvalidEntryDatesTriggerErrorMessage(applicantAceHome), "Date of Birth is not a valid entry error displayed.");
    }

    public boolean notAllowedSpecialCharsNotAcceptedOnSpouseFirstNameField() {
        return areNotAllowedCharactersNotAccepted(spouseElements.get(0), NOT_ALLOWED_SPECIAL_CHARACTERS);
    }

    public boolean notAllowedSpecialCharsNotAcceptedOnSpouseLastNameField() {
        return areNotAllowedCharactersNotAccepted(spouseElements.get(1), NOT_ALLOWED_SPECIAL_CHARACTERS);
    }

    public void validateNotAllowedSpecialCharsInFirstLastNameSpouse(FarmersSoftAssert fsa) {
        fsa.assertTrue(notAllowedSpecialCharsNotAcceptedOnSpouseFirstNameField(), "Special chars are allowed in spouse's first name field");
        fsa.assertTrue(notAllowedSpecialCharsNotAcceptedOnSpouseLastNameField(), "Special chars are allowed in spouse's last name field");
    }

    public boolean notAllowedNumericCharsNotAcceptedOnSpouseFirstNameField() {
        return areNotAllowedCharactersNotAccepted(spouseElements.get(0), NOT_ALLOWED_NUMERIC_CHARACTERS);
    }

    public boolean notAllowedNumericCharsNotAcceptedOnSpouseLastNameField() {
        return areNotAllowedCharactersNotAccepted(spouseElements.get(1), NOT_ALLOWED_NUMERIC_CHARACTERS);
    }

    public boolean notAllowedSpecialCharsNotAcceptedOnDOBField() {
        scrollAndClickOnElement(spouseDateOfBirthInputBox);
        sendKeysToElement(spouseDateOfBirthInputBox, NOT_ALLOWED_SPECIAL_AND_ALPHABETIC_CHARACTERS);
        sendKeysToElement(spouseDateOfBirthInputBox, Keys.TAB);
        return getAttributeData(spouseDateOfBirthInputBox, CLASS).contains("ng-invalid");
    }

    public void validateNotAllowedNumericInFirstLastNameSpouse(FarmersSoftAssert fsa) throws Exception {
        if (!isMarriedCheckboxChecked()) {
            clickOnMarriedOrInDomesticRelationCheckbox();
        }
        waitElementBeVisible(spouseFirstNameInputBox);
        fsa.assertTrue(notAllowedNumericCharsNotAcceptedOnSpouseFirstNameField(), "Numeric chars are allowed in spouse's first name field");
        fsa.assertTrue(notAllowedNumericCharsNotAcceptedOnSpouseLastNameField(), "Numeric chars are allowed in spouse's last name field");
    }

    public void validateNotAllowedSpecialCharInDOBSpouse(FarmersSoftAssert fsa) {
        fsa.assertTrue(notAllowedSpecialCharsNotAcceptedOnDOBField(), "Special chars are allowed in the spouse date of birth field");
    }

    private boolean areNotAllowedCharactersNotAccepted(WebElement element, String notAllowedChars) {
        scrollAndClickOnElement(element);
        sendKeysToElement(element, notAllowedChars);
        return getValueFromWebElement(element).isBlank();
    }

    @SneakyThrows
    public void fillOutSpouseApplicantFormWithValues(String firstName, String lastName, String dateOfBirth) {
        waitElementBeVisible(spouseFirstNameInputBox);
        sleep(4);
        scrollToElement(spouseFirstNameInputBox);
        scrollAndClickOnHiddenElement(spouseFirstNameInputBox);
        enterValueInField(firstName, spouseFirstNameInputBox, LOG_MESSAGE_TEMPLATE + SPOUSE_FIRST_NAME + COLON + SPACE);
        scrollToElement(spouseLastNameInputBox);
        enterValueInField(lastName, spouseLastNameInputBox, LOG_MESSAGE_TEMPLATE + SPOUSE_LAST_NAME + COLON + SPACE);
        scrollToElement(spouseDateOfBirthInputBox);
        sendKeysOneByOne(spouseDateOfBirthInputBox, dateOfBirth);
        clickContinueButton();
    }

    public void fillOutApplicantFormWithIncorrectInput() {
        String wrongFirstNameInput = "--";
        String wrongLastNameInput = "--";
        String wrongDate = "03/24/2343";
        fillOutSpouseApplicantFormWithValues(wrongFirstNameInput, wrongLastNameInput, wrongDate);
    }

    private List<String> getListOfExpectedErrorMessagesForBlankOrInvalidInput(String errorTemplate) throws Exception {
        waitForPageToBeReady();
        String lobType = getLobTypeFromAppStore();
        List<String> listOfErrorMessages =  new ArrayList<>();
        listOfErrorMessages = Stream.of(SPOUSE_FIRST_NAME, SPOUSE_LAST_NAME, SPOUSE_DATE_OF_BIRTH_ARIA_LABEL)
                .map(String::toLowerCase)
                .map(field -> String.format(errorTemplate, field)).collect(Collectors.toList());
        if (!lobType.equals(MOBILE_HOME)) {
            listOfErrorMessages.add("This is required."); // Gender fields error message
        }
        return getSortedList(listOfErrorMessages);
    }

    public void validateErrorMessageForNoInput(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getListOfExpectedErrorMessagesForBlankOrInvalidInput("Please provide your %s."), getSortedList(getPageErrors()), "Spouse field error message validation for no input provided");
    }

    public void validateErrorMessageForInvalidInput(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getListOfExpectedErrorMessagesForBlankOrInvalidInput("Invalid %s"), getSortedList(getPageErrors()), "Spouse field error message validation for invalid input provided");
    }

    public void validateCharLimitFirstLastNameSpouse(FarmersSoftAssert fsa) {
        fsa.assertEquals(getAttributeData(spouseFirstNameInputBox, VALUE).length(), 15, "Check 15 chars allowed in spouse first name field");
        fsa.assertEquals(getAttributeData(spouseLastNameInputBox, VALUE).length(), 20, "Check 20 chars allowed in spouse last name field");
    }

    public void validateSpouseSectionErrorMessages(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        // check the spouse checkbox in order to validate errors in spouse section
        selectGender(applicant);
        clickOnMarriedOrInDomesticRelationCheckbox();

        // validate error messages when no input is provided
        clickContinueButton();
        validateErrorMessageForNoInput(fsa);

        // validate error messages when invalid input is provided
        fillOutApplicantFormWithIncorrectInput();
        validateErrorMessageForInvalidInput(fsa);

        //validate First/Last name char limit - 15 char and 20 char max respectively
        fillOutSpouseApplicantFormWithValues("MoreThanFifteenChars","MoreThanTwentyCharacters", "09/09/1600" );
        validateCharLimitFirstLastNameSpouse(fsa);

        // validate error messages for age limit and invalid date of birth format
        validateInvalidErrorMessagesForAgeLimitAndDob(fsa, applicant);

        //Not allowed special chars and numeric chars in Spouse's First name and Spouse's last name field
        validateNotAllowedSpecialCharsInFirstLastNameSpouse(fsa);
        driver().navigate().refresh();
        waitForPageToBeReady();
        fsa.assertTrue(!isMarriedCheckboxChecked(), "Married or in a domestic partnership checkbox should not be checked by default");
        validateNotAllowedNumericInFirstLastNameSpouse(fsa);

        //Not allowed special chars in DOB and spouse's DOB field
        validateNotAllowedSpecialCharInDOBSpouse(fsa);
    }

    public void validatePolicyStartDateErrorMessages(FarmersSoftAssert fsa, String lobType) {
    	if (lobType.equals(MOBILE_HOME)) {
    	    EXPECTED_POLICY_START_DATE_ERROR = "Please select your policy effective date between " + getFormattedForPolicyStartDate(today.plusDays(1)) + " and " + getFormattedForPolicyStartDate(today.plusDays(29)) + ".";
    	}
        //Today, invalid policy start date
        String formattedToday = getFormattedForPolicyStartDate(today);
        sendKeysToElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateInputField), Keys.chord(formattedToday, Keys.TAB));
        if (isElementDisplayed(policyStartOrEstimatedClosingDateDateError, 3)) {
            fsa.assertEquals(getTextFromElement(policyStartOrEstimatedClosingDateDateError), EXPECTED_POLICY_START_DATE_ERROR, "Policy start date range error verification - today's date");
        } else {
            fsa.fail(EXPECTED_POLICY_START_DATE_ERROR + " >> error for " + formattedToday + " date was not found.");
        }

        sleep(1);
        String futureDateOusideRange = getFormattedForPolicyStartDate(lobType.equals(MOBILE_HOME)? today.plusDays(30) : today.plusDays(60));
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, Keys.chord(futureDateOusideRange, Keys.TAB));
        if (isElementDisplayed(policyStartOrEstimatedClosingDateDateError, 3)) {
            fsa.assertEquals(getTextFromElement(policyStartOrEstimatedClosingDateDateError), EXPECTED_POLICY_START_DATE_ERROR, "Policy start date range error verification - future date outside of range");
        } else {
            fsa.fail(EXPECTED_POLICY_START_DATE_ERROR + " >> error for " + futureDateOusideRange + " date was not found.");
        }
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, getFormattedForPolicyStartDate(today.plusDays(1)));
    }

    public void validateRequiredFieldErrorMessages(FarmersSoftAssert fsa, String lobType) throws Exception {
        driver().navigate().refresh();
        waitForPageToBeReady();
        final String PLEASE_ENTER_YOUR = "Please enter your ";

        clearOutFieldUsingBackSpace(policyStartDateOrEstimatedClosingDateInputField);
        if(!lobType.equals(RENTERS)){
            scrollAndClickOnElement(otherMailingAddressRadioButton);
        }

//        enterCommunicationConsent(AZ);
        WebElement button = isNewFlowEnabledState(getStateCodeFromAppStore()) ? buttonContinue : agreeAndSubmitButton;
        waitAndClickElement(button);

        // Please provide your policy start date error validation - DE306469 only fixed in RA11
        String pleaseProvideYourPolicyStartDate = isResidenceInEscrow() ? "Please provide your estimated closing date." : "Please provide your policy start date.";
        fsa.assertEquals(getTextFromElement(policyStartOrEstimatedClosingDateDateError), pleaseProvideYourPolicyStartDate, errorMessage(pleaseProvideYourPolicyStartDate));

        if(!lobType.equals(RENTERS)){
            if(!isNewFlowEnabledState(getStateCodeFromAppStore())) {
                final String EXPECTED_EMAIL_ERROR = PLEASE_ENTER_YOUR + "email address.";
                fsa.assertEquals(getTextFromElement(emailAddressError), EXPECTED_EMAIL_ERROR, errorMessage(EXPECTED_EMAIL_ERROR));

                final String EXPECTED_PHONE_NUMBER_ERROR = PLEASE_ENTER_YOUR + "phone number.";
                fsa.assertEquals(getTextFromElement(phoneNumberError), EXPECTED_PHONE_NUMBER_ERROR, errorMessage(EXPECTED_PHONE_NUMBER_ERROR));
            }
            final String EXPECTED_PAGE_ERROR_MESSAGE = "One or more required fields are incomplete or incorrect. Please Review.";
            fsa.assertEquals(getTextFromElement(pageErrorMessage), EXPECTED_PAGE_ERROR_MESSAGE, errorMessage(EXPECTED_PAGE_ERROR_MESSAGE));

            final String EXPECTED_MAILING_ADDRESS_ERROR = PLEASE_ENTER_YOUR + "mailing address.";
            fsa.assertEquals(getTextFromElement(mailingAddressError), EXPECTED_MAILING_ADDRESS_ERROR, errorMessage(EXPECTED_MAILING_ADDRESS_ERROR));

            final String EXPECTED_CITY_ERROR = PLEASE_ENTER_YOUR + "city.";
            fsa.assertEquals(getTextFromElement(cityError), EXPECTED_CITY_ERROR, errorMessage(EXPECTED_CITY_ERROR));

            final String EXPECTED_STATE_ERROR = PLEASE_ENTER_YOUR + "state.";
            fsa.assertEquals(getTextFromElement(stateError), EXPECTED_STATE_ERROR, errorMessage(EXPECTED_STATE_ERROR));

            final String EXPECTED_ZIPCODE_ERROR = PLEASE_ENTER_YOUR + "ZIP code.";
            fsa.assertEquals(getTextFromElement(zipCodeError), EXPECTED_ZIPCODE_ERROR, errorMessage(EXPECTED_ZIPCODE_ERROR));
        }
    }

    private void validateInvalidEntriesErrorMessages(FarmersSoftAssert fsa) throws Exception {
        driver().navigate().refresh();
        waitForPageToBeReady();
        final String IS_NOT_VALID_ENTRY = "is not a valid entry.";

        //invalid email format
        if (!isNewFlowEnabledState(getStateCodeFromAppStore())) {
            String invalidEmail1 = "invalidEmail@";
            waitAndClickElement(emailAddressInput);
            sendKeysToElement(emailAddressInput, Keys.chord(invalidEmail1, Keys.TAB));
            final String EXPECTED_INVALID_EMAIL_ADDRESS_ERROR = "Email address entered is invalid.";
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(emailAddressError)), EXPECTED_INVALID_EMAIL_ADDRESS_ERROR, "Invalid email format check");

            //invalid domain --validate email call should fail
            String invalidEmail2 = "invalidemail_123@yopmael.com";
            waitAndClickElement(emailAddressInput);
            sendKeysToElement(emailAddressInput, Keys.chord(invalidEmail2, Keys.TAB));
            waitAndClickElement(phoneNumberInput);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(emailAddressError)), EXPECTED_INVALID_EMAIL_ADDRESS_ERROR, "Invalid email domain check");

            //invalid phone number
            String invalidPhone = "(123) 456-6796";
            sendKeysToElement(phoneNumberInput, invalidPhone);
            sendKeysOneByOne(phoneNumberInput, Keys.chord(invalidPhone, Keys.TAB));
            fsa.assertEquals(getTextFromElement(phoneNumberError), String.format("%s %s", invalidPhone, IS_NOT_VALID_ENTRY), "Invalid phone number check");
        }
        scrollAndClickOnElement(otherMailingAddressRadioButton);

        // invalid other mailing address entry

        String invalidMailingAddress = "123";
        waitAndClickElement(mailingAddressInputField);
        sendKeysToElement(waitElementBeVisible(mailingAddressInputField), Keys.chord(invalidMailingAddress, Keys.TAB, Keys.TAB));
        //this error message takes a while to appear, give it a chance...
        sleep(5);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(mailingAddressError)), "Please enter your mailing address.", "Invalid address check");

        // invalid city entry
        String invalidCityName = "%";
        waitAndClickElement(cityInputField);
        sendKeysToElement(cityInputField, invalidCityName);
        sendKeysToElement(waitElementBeVisible(cityInputField), invalidCityName + Keys.ENTER);
        fsa.assertEquals(getTextFromElement(cityError), "Please enter your city.", "Invalid city check");

        //invalid zipcode entry
        String invalidZip = "1234";
        waitAndClickElement(zipCodeInputField);
        sendKeysOneByOne(zipCodeInputField, Keys.chord(invalidZip, Keys.ESCAPE, Keys.TAB));
        String expectedInvalidZipCodeMessage = "Please enter a 5 digit ZIP Code.";
        fsa.assertEquals(getTextFromElement(zipCodeError), expectedInvalidZipCodeMessage, "Invalid zipcode check");

    }

    public void validateEarlyShopperDiscount(FarmersSoftAssert fsa, String stateCode) throws Exception {
        LocalDate today = getTodayDate(); //today
        //Today, invalid policy start date
        String formattedToday = getFormattedForPolicyStartDate(today);
        sendKeysToElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateInputField), formattedToday);
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, Keys.chord(Keys.TAB,Keys.TAB));
        fsa.assertEquals(getTextFromElement(policyStartOrEstimatedClosingDateDateError), EXPECTED_POLICY_START_DATE_ERROR, errorMessage(EXPECTED_POLICY_START_DATE_ERROR));

        // From tomorrow, seven days later to 30 days, eligible for discounts
        LocalDate sevenDaysLater = todayPlus8Days();
        String formattedSevenDaysLater = getFormattedForPolicyStartDate(sevenDaysLater);
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, formattedSevenDaysLater);
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, Keys.chord(Keys.TAB,Keys.TAB));

        validateEarlyShopperDiscountAndSideTextValidation(fsa, stateCode);

        // six days later (before seven days), no early shopping discount
        LocalDate sixDaysLater = todayPlus6Days();
        String formattedSixDaysLater = getFormattedForPolicyStartDate(sixDaysLater);
        waitAndClickElement(policyStartDateOrEstimatedClosingDateInputField);
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, formattedSixDaysLater);
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, Keys.chord(Keys.TAB,Keys.TAB));
        sleep(2);
        if (!isResidenceInEscrow()) {
            if (!isUseMobileViewEnabled()) {
                fsa.assertTrue(!isElementDisplayed(earlyDiscountOrEstimatedClosingDateInfoTitle, 2), "Policy start date info box should not appear");
            } else {
                fsa.assertTrue(!isElementDisplayed(earlyShoppingInfoIcon, 2), "Policy start date info icon should not appear");
            }
        }

        // From tomorrow, seven days later to 30 days, eligible for discounts
        LocalDate fiftyNineDays = todayPlus59Days();
        String formattedFiftyNineDays = getFormattedForPolicyStartDate(fiftyNineDays);
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, formattedFiftyNineDays);
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, Keys.chord(Keys.TAB,Keys.TAB));
        validateEarlyShopperDiscountAndSideTextValidation(fsa, stateCode);

    }

    public void validateEarlyShopperDiscountAndSideTextValidation(FarmersSoftAssert fsa, String stateCode) throws Exception {
        if (stateCode.equals(CA)) {
            fsa.assertFalse(isSnackBarMessageDisplayed(EXPECTED_EARLY_SHOPPER_CONGRATS_MESSAGE), "Contact Info page - No Early shopper discount message for CA state quotes.");
        } else {
            fsa.assertTrue(isSnackBarMessageDisplayed(EXPECTED_EARLY_SHOPPER_CONGRATS_MESSAGE), "Contact Info page - " + EXPECTED_EARLY_SHOPPER_CONGRATS_MESSAGE);
        }
        if (isResidenceInEscrow()) {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoTitle)), ESTIMATED_CLOSING_DATE_INFO_TITLE, errorMessage(ESTIMATED_CLOSING_DATE_INFO_TITLE));
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoDescription)), ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION, errorMessage(ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION));
        } else {
            if (stateCode.equals(CA)) {
                fsa.assertFalse(isElementDisplayed(earlyDiscountOrEstimatedClosingDateInfoTitle, 2), "Policy start date info box should not display for CA state quotes");
                fsa.assertFalse(isElementDisplayed(earlyDiscountOrEstimatedClosingDateInfoDescription, 2), "Policy start date info box should not display for CA state quotes");
            } else {
                if (!isUseMobileViewEnabled()) {
                    fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoTitle)), EXPECTED_EARLY_SHOPPING_INFO_TITLE);
                    fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoDescription)), EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION);
                } else {
                    waitAndClickElement(earlyShoppingInfoIcon);
                    fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalTitle)), EXPECTED_EARLY_SHOPPING_INFO_TITLE, EXPECTED_EARLY_SHOPPING_INFO_TITLE);
                    fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalText)), EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION, EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION);
                    waitAndClickElement(infoModalButtonClose);
                }
            }
        }
    }

    public void validateBundleSaveSection(ApplicantAceHome applicant, FarmersSoftAssert fsa, String lobType) throws Exception {
        String expectedHeader = "Save more when you bundle";
        String expectedHeaderNote = "Select which eligible Farmers products you would like to bundle with:";
        String expectedBundleAndSaveTipHeader = "Bundle and save";
        String dwellingType = lobType.equals(SPECIALTY_DWELLING) ? "dwelling" : lobType.equals(MOBILE_HOME)? "home" : lobType.toLowerCase();
        String expectedBundleAndSaveDescription = "A bundle discount will be applied to your " + dwellingType + " quote today. " +
        		"You will have to purchase the policies you select to retain the discount. " +
        		"A Farmers\u00ae representative will reach out to you to help you through the process.";
        String expectedInfoModalTitle = "How it works";
        if (!List.of(MOBILE_HOME, RENTERS).contains(lobType) && isNewFlowEnabledState(applicant.getStateCode())) {
            String expectedTitle = "Other details";
            String expectedBundleTitle = "Bundle discount";
            fsa.assertEquals(getTextFromElement(otherDetailsTitle), expectedTitle, "Other details section title check");
            fsa.assertEquals(getTextFromElement(bundleDiscountTitle), expectedBundleTitle, "Bundle discount Title check");
        }
        if (List.of(RENTERS, SPECIALTY_DWELLING, MOBILE_HOME).contains(lobType) || !isHomeToAutoBundleEligibleAndEnabled(applicant.getStateCode())) {
            fsa.assertEquals(getTextFromElement(bundleSaveHeading), expectedHeader, "Bundle Save section header check");
            fsa.assertEquals(getTextFromElement(bundleSaveHeadingNote), expectedHeaderNote, "Bundle Save section header note check");
            if (!isUseMobileViewEnabled()) {
                fsa.assertEquals(getTextFromElement(bundleAndSaveTipHeader), expectedBundleAndSaveTipHeader, "Bundle Save tip header verification");
                fsa.assertEquals(getTextFromElement(bundleAndSaveTipDescription), expectedBundleAndSaveDescription, "Bundle Save tip description verification");
            } else {
                waitAndClickElement(saveBundleInfoIcon);
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalTitle, 3)), expectedInfoModalTitle, "Bundle Save info modal title matching");
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalText, 3)), expectedBundleAndSaveDescription, "Bundle Save info modal text matching");
                waitAndClickElement(infoModalButtonClose);
            }
        } else {
            fsa.assertFalse(isElementDisplayed(bundleAndSaveSection, 1),
                    "Bundle Save section should be hidden when Home-to-Auto bundle is eligible/enabled.");
        }

        List<WebElement> listOfExpectedBundleIcons = new ArrayList<>();
        List<String> expectedCongratsMessages = new ArrayList<>();
        List<String> expectedDiscountsRemovedMessages = new ArrayList<>();

        String stateCode = applicant.getStateCode();
        if (lobType.equals(MOBILE_HOME)) {
            if (List.of(CT, NY).contains(stateCode)) {
            	listOfExpectedBundleIcons.addAll(List.of(homeBundleIcon, autoBundleIcon, umbrellaBundleIcon));
            } else {
            	listOfExpectedBundleIcons.addAll(List.of(homeBundleIcon, autoBundleIcon, lifeBundleIcon, umbrellaBundleIcon));
            }
        } else if (lobType.equals(SPECIALTY_DWELLING)) {
            if (List.of(CT, NY).contains(stateCode)) {
            	listOfExpectedBundleIcons.addAll(List.of(autoBundleIcon, homeBundleIcon, umbrellaBundleIcon));
            } else {
				listOfExpectedBundleIcons.addAll(List.of(autoBundleIcon, homeBundleIcon, lifeBundleIcon, umbrellaBundleIcon));
			}
        } else if (lobType.equals(CONDO) || lobType.equals(RENTERS) || isAdditionalHomeBundleDiscountsState(stateCode)) {
            // View additional products link validation
            if (isElementDisplayed(viewAdditionProductsLink, 3)) {
                fsa.assertTrue(getTextFromElement(viewAdditionProductsLink).contains(VIEW_ADDITIONAL_PRODUCT_LINK_TEXT), "View additional products to bundle link text contains [" + VIEW_ADDITIONAL_PRODUCT_LINK_TEXT + "]");
                scrollAndClickOnElement(viewAdditionProductsLink);
            }
            if (isNoLifeBundleState(stateCode)) {
            	listOfExpectedBundleIcons.addAll(List.of(autoBundleIcon, businessBundleIcon, boatsBundleIcon, offRoadVehicleBundleIcon, motorHomeBundleIcon));
            } else {
            	listOfExpectedBundleIcons.addAll(List.of(autoBundleIcon, lifeBundleIcon, businessBundleIcon, boatsBundleIcon, offRoadVehicleBundleIcon, motorHomeBundleIcon));
            }
            expectedCongratsMessages.addAll(List.of(AUTO_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, LIFE_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, BUSINESS_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE,
        	    WATERCRAFT_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, OFF_ROAD_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, RV_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE));
            expectedDiscountsRemovedMessages.addAll(List.of(AUTO_BUNDLE_DISCOUNT_REMOVED_MESSAGE, LIFE_BUNDLE_DISCOUNT_REMOVED_MESSAGE, BUSINESS_BUNDLE_DISCOUNT_REMOVED_MESSAGE,
        	    WATERCRAFT_BUNDLE_DISCOUNT_REMOVED_MESSAGE, OFF_ROAD_BUNDLE_DISCOUNT_REMOVED_MESSAGE, RV_BUNDLE_DISCOUNT_REMOVED_MESSAGE));
            if (!isEasternExpansionState(stateCode)) {
            	listOfExpectedBundleIcons.add(umbrellaBundleIcon);
                expectedCongratsMessages.add(UMBRELLA_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE);
                expectedDiscountsRemovedMessages.add(UMBRELLA_BUNDLE_DISCOUNT_REMOVED_MESSAGE);
                if (stateCode.equals(CA)) {
                	listOfExpectedBundleIcons.add(multiPolicyCEAIcon);
                    expectedCongratsMessages.add(MULTI_POLICY_CEA_DISCOUNT_CONGRATULATIONS_MESSAGE);
                    expectedDiscountsRemovedMessages.add(MULTI_POLICY_CEA_DISCOUNT_REMOVED_MESSAGE);
                }
            }
        } else {
            if (stateCode.equals(CA)) {
            	listOfExpectedBundleIcons.addAll(List.of(autoBundleIcon, umbrellaBundleIcon, multiPolicyCEAIcon));
            	expectedCongratsMessages.addAll(List.of(AUTO_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, MULTI_POLICY_CEA_DISCOUNT_CONGRATULATIONS_MESSAGE));
            	expectedDiscountsRemovedMessages.addAll(List.of(AUTO_BUNDLE_DISCOUNT_REMOVED_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_REMOVED_MESSAGE, MULTI_POLICY_CEA_DISCOUNT_REMOVED_MESSAGE));
            } else if (isNoLifeBundleState(stateCode)){
            	listOfExpectedBundleIcons.addAll(List.of(autoBundleIcon, umbrellaBundleIcon));
                expectedCongratsMessages.addAll(List.of(AUTO_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE));
                expectedDiscountsRemovedMessages.addAll(List.of(AUTO_BUNDLE_DISCOUNT_REMOVED_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_REMOVED_MESSAGE));
            } else {
            	listOfExpectedBundleIcons.addAll(List.of(autoBundleIcon, lifeBundleIcon, umbrellaBundleIcon));
            	expectedCongratsMessages.addAll(List.of(AUTO_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, LIFE_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE));
            	expectedDiscountsRemovedMessages.addAll(List.of(AUTO_BUNDLE_DISCOUNT_REMOVED_MESSAGE, LIFE_BUNDLE_DISCOUNT_REMOVED_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_REMOVED_MESSAGE));
            }
        }

        // validate the list of the checkboxes
        List<String> listOfExpectedBundleLabels = FfqBundleOptions.getBundleOptionsForAceHome(applicant, lobType);
        if (!List.of(MOBILE_HOME, SPECIALTY_DWELLING).contains(lobType) && (stateCode.equals(CT) || stateCode.equals(AL))) {
        	listOfExpectedBundleLabels.remove(LIFE);
            expectedCongratsMessages.remove(LIFE_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE);
            expectedDiscountsRemovedMessages.remove(LIFE_BUNDLE_DISCOUNT_REMOVED_MESSAGE);
        }
        if (List.of(RENTERS, MOBILE_HOME, SPECIALTY_DWELLING).contains(lobType) || !isHomeToAutoBundleEligibleAndEnabled(applicant.getStateCode())) {
        	List<String> listOfActualBundleLabels = saveBundleCheckboxesText.stream().map(each -> getAttributeData(each, "innerText").strip()).collect(Collectors.toList());
            listOfActualBundleLabels.remove(MOBILE_HOME);
            fsa.assertEquals(listOfActualBundleLabels, listOfExpectedBundleLabels, "listOfActualBundleLabels matches listOfExpectedBundleLabels");
        	for (WebElement icon:listOfExpectedBundleIcons) {
        		fsa.assertTrue(isElementDisplayed(icon, 2), icon + " is displayed");
        	}
        	fsa.assertEquals(listOfActualBundleLabels, listOfExpectedBundleLabels, "listOfActualBundleLabels matches listOfExpectedBundleLabels");
        	fsa.assertEquals(listOfActualBundleLabels.size(), listOfExpectedBundleIcons.size(), "Labels found and expected icon counts match");
        }

        // Validate that bundle checkboxes produce a singular congratulations message
        // Mobile home and specialty snackbar behave differently - no singular message
        if (lobType.equals(RENTERS) || (!List.of(SPECIALTY_DWELLING, MOBILE_HOME).contains(lobType) && !isHomeToAutoBundleEligibleAndEnabled(applicant.getStateCode()))) {
            List<String> foundCongratsMessages = new ArrayList<>();
            List<String> foundDiscountsRemovedMessages = new ArrayList<>();
            int i = 0;
        	for (WebElement saveBundleInput : saveBundleMatCheckboxInputs) {
                waitElementBeInvisible(snackBar);
        		scrollAndClickOnElement(saveBundleInput);
        		sleep(1);
        		waitElementBeVisible(snackBar,3);
        		foundCongratsMessages.add(getTextFromElement(snackBar));
        		fsa.assertTrue(getAttributeData(saveBundleMatCheckboxes.get(i), CLASS).contains(CHECKBOX_CHECKED), "Bundle checkbox: " + (i+1) + " checked");
                i++;
        	}
        	sleep(5);
            i = 0;
        	for (WebElement uncheckBundleInput : saveBundleMatCheckboxInputs) {
                waitElementBeInvisible(snackBar);
        		scrollAndClickOnElement(uncheckBundleInput);
        		sleep(1);
        		waitElementBeVisible(snackBar, 3);
        		foundDiscountsRemovedMessages.add(getTextFromElement(snackBar));
        		fsa.assertFalse(getAttributeData(saveBundleMatCheckboxes.get(i), CLASS).contains(CHECKBOX_CHECKED), "Bundle checkbox: " + (i+1) + " unchecked");
                i++;
        	}
        	fsa.assertEquals(getSortedList(foundCongratsMessages), getSortedList(expectedCongratsMessages), "Actual and expected Congratulations messages match - " + lobType);
        	fsa.assertEquals(getSortedList(foundDiscountsRemovedMessages), getSortedList(expectedDiscountsRemovedMessages), "Actual and expected Discount messages match - " + lobType);
        }
    }

    public void enterEmailIdAndPhoneNumberInContactInfoPage(ApplicantAceHome applicant) {
    	enterEmailAddress(applicant.getEmailAddress());
        waitAndClickElement(phoneNumberInput);
        sleep(2);
        sendKeysOneByOne(phoneNumberInput, applicant.getPhoneNumber());
        sleep(2);
        sendKeysToElement(phoneNumberInput, Keys.TAB);
    }

    public void enterEmailAddress (String emailAddress) {
        scrollToElement(emailAddressInput);
        waitAndClickElement(emailAddressInput);
        sendKeysToElement(emailAddressInput, emailAddress);
        sendKeysToElement(emailAddressInput, Keys.TAB);
    }


    public boolean isEmailAddressReadOnly() {
        return isAttributePresent(emailAddressInput, DISABLED);
    }

    public boolean isPhoneNumberReadOnly() {
        return isAttributePresent(phoneNumberInput, DISABLED);
    }

    public void clickOnAgreeAndSubmitButton(){
        scrollAndClickOnElement(agreeAndSubmitButton);
        waitForSpinnerToBeGone();
    }

    public void fillOutBundleAndSave(ApplicantAceHome applicant, String lobType) throws Exception {
        List<SqlDiscount> discounts = applicant.getDiscounts();
        if (!discounts.isEmpty() && (!lobType.equals(HOME) || !isHomeToAutoBundleEligibleAndEnabled(applicant.getStateCode()))) {
            SqlDiscount discount = discounts.get(FIRST_AVAILABLE_OPTION);
            selectBundle(discount.isAutoInsurance(), "Auto");
            sleep(1);
            selectBundle(discount.isLifeInsurance(), "Life");
            sleep(1);
            selectBundle(discount.isUmbrellaInsurance(), "Umbrella");
            sleep(1);
            selectBundle(discount.isMultiPolicyCEA(), "Multi-policy Discount - CEA");
            sleep(1);
            if (!List.of(SPECIALTY_DWELLING, MOBILE_HOME).contains(lobType) && (isAdditionalHomeBundleDiscountsState(applicant.getStateCode()) || !lobType.equals(HOME))) {
                if (isElementDisplayed(viewAdditionProductsLink,3)) {
                    waitAndClickElement(viewAdditionProductsLink);
                }
                selectBundle(discount.isBusinessInsurance(), FfqBundleOptions.BUSINESS.getBundleLob());
                selectBundle(discount.isRecreationalBoatWatercraftInsurance(), FfqBundleOptions.RECREATIONAL.getBundleLob());
                selectBundle(discount.isMotorcycleInsurance(), FfqBundleOptions.OFF_ROAD_VEHICLE.getBundleLob());
                selectBundle(discount.isMotorHome(), FfqBundleOptions.MOTOR_HOME.getBundleLob());
            }
        }
    }

    public void fillOutContactInfoPage(ApplicantAceHome applicant, String lobType) throws Exception {
        enterPolicyStartDate(applicant);
        enterFireHydrantData(applicant);
        if (applicant.getStateCode().equals(CA) && !applicant.getWildFireRisk().isBlank()) {
            fillOutWildfireRiskReductionCA(applicant.getWildFireRisk());
        }
        fillOutBundleAndSave(applicant, lobType);
		if (isNewFlowEnabledState(applicant.getStateCode())) {
	        fillOutAboutYouData(applicant);
		} else {
			enterEmailIdAndPhoneNumberInContactInfoPage(applicant);
		}
        clickOnAgreeAndSubmitButton();
    }

    public void fillOutAboutYouData(ApplicantAceHome applicant) throws Exception {
        fillOutPrimaryApplicantDetails(applicant);
        if (!applicant.getOccupation().isBlank() && !isNoEligibleOccupationState(applicant.getStateCode())) {
            clickEligibleOccupationButton(true);
            selectOccupationRadioButton(applicant.getOccupation());
            clickAddButton();
        }
        if (applicant.getMaritalStatus().equals(MARRIED)) {
            clickOnMarriedOrInDomesticRelationCheckbox();
            fillOutSpouseApplicantDetails(applicant);
            if (!applicant.getOccupation().isBlank() && !isNoEligibleOccupationState(applicant.getStateCode())) {
                clickEligibleOccupationButton(false);
                selectOccupationRadioButton(applicant.getOccupation());
                clickAddButton();
            }
        }
    }

    public boolean isEligibleOccupationButtonTextMatching(boolean isPrimaryApplicant) {
        if (isPrimaryApplicant) {
            return isExpectedTextDisplayed(eligibleOccupationButtonPersonalInfoDiv, ELIGIBLE_OCCUPATION_BUTTON);
        } else {
            return isExpectedTextDisplayed(eligibleOccupationButtonSpouseDiv, ELIGIBLE_OCCUPATION_BUTTON);
        }
    }

    public void clickEligibleOccupationButton(boolean isPrimaryApplicant) {
        if (isPrimaryApplicant) {
            waitAndClickElement(eligibleOccupationButtonPersonalInfoDiv);
        } else {
            waitAndClickElement(eligibleOccupationButtonSpouseDiv);
        }
    }

    public boolean isEligibleOccupationHeaderDisplayed() {
        waitElementBeVisible(eligibleOccupationHeader);
        return isExpectedTextDisplayed(eligibleOccupationHeader, ELIGIBLE_OCCUPATION_HEADER);
    }

    public boolean isCloseIconAddAndCancelButtonDisplayedInOccupationSideSheet() {
        return (closeIcon.isDisplayed() && eligibleOccupationAddButton.isDisplayed() && eligibleOccupationCancelButton.isDisplayed());
    }

    public boolean isRetiredProfessionalCheckBoxAndLabelDisplayed() {
        return occupationRetiredCheckBox.isDisplayed() && retiredFormerlyEmployedLabel.isDisplayed();
    }

    public void clickRetiredFormerlyEmployedCheckbox() {
        waitAndClickElement(occupationRetiredCheckBox);
    }

    public void clickCloseIcon() {
        waitAndClickElement(closeIcon);
    }

    public void clickAddButton() throws Exception {
        scrollAndClickOnElement(eligibleOccupationAddButton);
    }

    public void clickRemoveOccupationLink(boolean isPrimaryApplicant) {
        sleep(2);
        if (isPrimaryApplicant) {
            scrollAndClickOnElement(removeOccupationLinkPrimaryApplicant);
        } else {
            scrollAndClickOnElement(removeOccupationLinkSpouse);
        }
    }

    public boolean isRemoveOccupationHeaderTextDisplayed() {
        waitElementBeVisible(removeOccupationHeaderInModalBox);
        return isExpectedTextDisplayed(removeOccupationHeaderInModalBox, REMOVE_OCCUPATION_HEADER_IN_MODAL);
    }

    public boolean isRemoveOccupationQuestionTextDisplayed() {
        return isExpectedTextDisplayed(removeOccupationQuestion, REMOVE_OCCUPATION_QUESTION);
    }

    public boolean isAddedOccupationDisplayed(boolean isPrimaryApplicant) {
        sleep(2);
        if (isPrimaryApplicant) {
            return homeOccupationSelectedMessagePersonalInfo.isDisplayed();
        } else {
            return homeOccupationSelectedMessageSpouseDiv.isDisplayed();
        }
    }

    public void clickKeepOccupationButton() {
        waitAndClickElement(keepOccupationButton);
    }

    public void clickRemoveOccupationButton() throws Exception {
        waitAndClickElement(removeOccupationButton);
        waitSnackBarMessageInvisible(10);
    }

    public void clickCancelButton() {
        waitAndClickElement(eligibleOccupationCancelButton);
    }

    public void selectOccupationRadioButton(String occupation) throws Exception {
        WebElement radioButtonToBeSelected;
        List<String> listOccupations = getListOfOccupationFromSideSheet();

        // Workaround to one extra space in between 21st and Century
        if (occupation.contains("Century Employees")) {
            occupation = "Century Employees";
        }
        if (listOccupations.contains(occupation)) {
            radioButtonToBeSelected = driver().findElement(By.xpath(String.format("//mat-radio-button[contains(.,'%s')]//input", occupation)));
        } else {
            try {
                // try to find the occupation amongst the sub-occupations
                WebElement we = driver().findElement(By.xpath("//mat-radio-button[contains(.,'Military')]//input"));
                scrollAndClickOnHiddenElement(we);
                listOccupations = getListOfOccupationFromSideSheet();
                radioButtonToBeSelected = driver().findElement(By.xpath(String.format("//mat-radio-button[contains(.,'%s')]//input", occupation)));
            } catch (NoSuchElementException e) {
                Log.warn("Occupation: " + occupation + " was not found, going to select first available on the list");
                occupation = listOccupations.get(0).contains( "Century Employees")? "Century Employees" : listOccupations.get(0);
                radioButtonToBeSelected = driver().findElement(By.xpath(String.format("//mat-radio-button[contains(.,'%s')]//input", occupation)));
            }
        }
        scrollAndClickOnHiddenElement(radioButtonToBeSelected);
    }

    public List<String> getListOfOccupationFromSideSheet() {
        waitElementBeVisibleClickable(currentlyEmployedOrRetiredToggleButton);
        List<String> occupationList = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            occupationList = occupationRadioButtons.stream().map(this::getTextFromElement).collect(Collectors.toList());
            if (!occupationList.isEmpty()) {
                break;
            }
        }
        return occupationList;
    }

    public void validateOccupationIsBlank(FarmersSoftAssert fsa) {
        fsa.assertTrue(selectedOccupation.isEmpty(), "Applicant Occupation entered is not saved");
    }

    public void checkMilitaryPersonnelOccupationSubList(FarmersSoftAssert fsa) throws Exception {
        selectOccupationRadioButton(MILITARY_PERSONNEL);
        waitForElements(OCCUPATION_SUBLIST_XPATH);
        List<WebElement> militaryOccupationSubGroupWebElements = driver().findElements(By.xpath(OCCUPATION_SUBLIST_XPATH));
        List<String> actualMilitarySubOccupation = militaryOccupationSubGroupWebElements.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> expectedMilitaryOccupationList = Arrays.asList("Air Force", "Army", "Coast Guard", "Honorably discharged", "Marine", "Navy");
        fsa.assertEquals(actualMilitarySubOccupation, expectedMilitaryOccupationList, "Military Personnel occupation sublist verification");
    }

    public void fillOutPrimaryApplicantDetails(ApplicantAceHome applicant) {
        selectGender(applicant);
    }

    public void selectGender(ApplicantAceHome applicant) {
        try {
            waitElementBeVisibleClickable(genderButton);
            WebElement we = driver().findElement(By.xpath(GENDER_SELECTION_XPATH + "//span[contains(text(),'" + applicant.getGender() + "')]"));
            waitAndClickElement(we);
        } catch(Exception e) {
            Log.error(" Element not found for applicant for gender selection: " + applicant.getGender());
        }
    }

    public String  getGenderApplicant() throws Exception {
        String gender = EMPTY_STRING;
        try {
            WebElement genderWe = driver().findElement(By.xpath(GENDER_SELECTION_XPATH + "[contains(@class,'mat-button-toggle-checked')]"));
            gender = getTextFromElement(genderWe);
        } catch (org.openqa.selenium.NoSuchElementException e) {
            Log.info("About You page - Gender was not selected.");
        }
        return gender;
    }

    public boolean isGenderReadOnly() throws Exception {
        boolean readOnly = true;
        for (WebElement weBtn : genderButtons) {
            if (!getAttributeData(weBtn, CLASS).contains(DISABLED)) {
                readOnly = false;
                break;
            }
        }
        return readOnly;
    }

    public void clickOnMarriedOrInDomesticRelationCheckbox() throws Exception {
        waitElementBeVisibleClickable(marriedOrInDomesticRelationMatCheckbox);
        clickElement(marriedOrInDomesticRelationCheckboxInput);
    }

    public boolean isAboutYouHeaderDisplayed() {
        return isExpectedTextDisplayed(aboutYouHeader, ABOUT_YOU_HEADER);
    }

    private boolean arePNIGenderButtonsDisplayedCorrectly(String stateCode, String lob) throws Exception {
        return checkGenderButtons(genderButtons, stateCode, lob);
    }

    public boolean isCloseIconInsideAddressInputBoxDisplayedAndClickable() {
        return closeIconInAddressInputBox.isDisplayed() && closeIconInAddressInputBox.isEnabled();
    }

    public boolean isUnitNumberInputBoxDisplayed() {
        return unitInputBox.isDisplayed();
    }

    public boolean isUnitNumberPlaceHolderTextDisplayed() {
        return isExpectedTextDisplayed(unitNumberPlaceholderText, UNIT_NUMBER_PLACEHOLDER_TEXT);
    }

    public boolean isUnitNumberOptionalHintDisplayed() {
        return isExpectedTextDisplayed(optionalUnitNumberHint, OPTIONAL_UNIT_NUMBER_HINT);
    }

    public boolean isPriorHomeAddressPlaceHolderTextDisplayed() {
        return priorAddressPlaceHolderText.isDisplayed();
    }

    public boolean isPriorCurrentHomeAddressLabelDisplayed(boolean isPriorHomeAddress) {
        if (isPriorHomeAddress) {
            return isExpectedTextDisplayed(priorOrCurrentHomeAddressLabel, PRIOR_HOME_ADDRESS_LABEL);
        } else {
            return isExpectedTextDisplayed(priorOrCurrentHomeAddressLabel, CURRENT_HOME_ADDRESS_LABEL);
        }
    }

    public boolean isCurrentHomeAddressPlaceHolderTextDisplayed() {
        return currentAddressPlaceHolderText.isDisplayed();
    }


    public boolean isMarriedOrSpouseCheckBoxDescriptionMatching() {
        return isExpectedTextDisplayed(marriedOrInDomesticRelationCheckBoxDescription, MARRIED_CHECKBOX_DESCRIPTION);
    }

    public boolean isMarriedCheckboxReadOnly() {
        return getAttributeData(marriedOrInDomesticRelationMatCheckbox, CLASS).contains(CHECKBOX_DISABLED);
    }

    public boolean isMarriedCheckboxChecked() {
        return getAttributeData(marriedOrInDomesticRelationMatCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public void fillOutSpouseApplicantDetails(ApplicantAceHome applicantAceHome) {
        waitAndClickElement(spouseElements.get(0));
        sendKeysToElement(spouseElements.get(0), applicantAceHome.getSpouseFirstName());
        waitAndClickElement(spouseElements.get(1));
        sendKeysToElement(spouseElements.get(1), applicantAceHome.getSpouseLastName());
        waitAndClickElement(spouseElements.get(2));
        sendKeysToElement(spouseElements.get(2), applicantAceHome.getSpouseDateOfBirth());
        setGenderSpouse(applicantAceHome);
    }

    public String getGenderSpouse() throws Exception {
        String gender = EMPTY_STRING;
        try {
            WebElement genderWe = driver().findElement(By.xpath(SPOUSE_GENDER_SELECTION_XPATH + "[contains(@class,'mat-button-toggle-checked')]"));
            gender = getTextFromElement(genderWe);
        } catch (NoSuchElementException e) {
            Log.info("About You page - Spouse gender was not selected.");
        }
        return gender;

    }

    public void setGenderSpouse(ApplicantAceHome applicantAceHome) {
        try {
            List<WebElement> we = driver().findElements(By.xpath(SPOUSE_GENDER_SELECTION_XPATH + "//span[contains(text(),'" + applicantAceHome.getSpouseGender() + "')]"));
            waitAndClickElement(we.get(0));
        } catch (Exception e) {
            Log.error(" Element not found for spouse for gender selection");

        }
    }

    public boolean isSpouseGenderReadOnly() throws Exception {
        boolean readOnly = true;
        for (WebElement weBtn : spouseGenderButtons) {
            if (!getAttributeData(weBtn, CLASS).contains(DISABLED)) {
                readOnly = false;
                break;
            }
        }
        return readOnly;
    }

    public void validateHeaderAndSubHeaderContactInfoPage(FarmersSoftAssert fsa) throws Exception {
        String stateCode = getStateCodeFromAppStore();
        fsa.assertTrue(isElementInViewport(lastStepBeforeYourPageHeader), "Page title is in Viewport");
        // Validate header and sub header content
        String lastStepBeforeYourQuote;
        String lobFromAppStore = getLobTypeFromAppStore();
        if (lobFromAppStore.equalsIgnoreCase(RENTERS)) {
            lobFromAppStore = RENTERS;
        }
        switch (lobFromAppStore) {
		case RENTERS:
            lastStepBeforeYourQuote = "Last step before your coverage";
			break;
		case MOBILE_HOME:
            lastStepBeforeYourQuote = "Last step before coverages";
            break;
		default:
			lastStepBeforeYourQuote = isNewFlowEnabledState(stateCode) ? "Other policy questions" : "Last step before your quote";
			break;
		}
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(lastStepBeforeYourPageHeader, 5)), lastStepBeforeYourQuote, errorMessage(lastStepBeforeYourQuote));
        if (!isNewFlowEnabledState(stateCode)) {
            final String JUST_FEW_MORE_QUESTIONS_BEFORE_YOUR_QUOTE_LABEL = "Just a few more questions before we calculate your quote on the next page.";
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(fewMoreQuestionBeforeYourQuoteHeader, 5)), JUST_FEW_MORE_QUESTIONS_BEFORE_YOUR_QUOTE_LABEL, errorMessage(JUST_FEW_MORE_QUESTIONS_BEFORE_YOUR_QUOTE_LABEL));
        }
    }

    public void validateContentOfEstimatedClosingOrPolicyStartDate(FarmersSoftAssert fsa, String lobType) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        // Validate policy start date or estimated closing date on first load
        String policyStartDateOnInitialLoad = getValueFromWebElement(policyStartDateOrEstimatedClosingDateInputField);
        LocalDate policyStartDateFromDatePicker = getFormattedDateFromStringDate(policyStartDateOnInitialLoad);

        // Validate policy start date or estimated closing date content
        fsa.assertEquals(policyStartDateOnInitialLoad, getFormattedTomorrowDate(), "Estimated closing date verification on initial load");
        if (isResidenceInEscrow(appStore)) {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateTitle)), EXPECTED_ESTIMATED_CLOSING_DATE_TITLE, errorMessage(EXPECTED_ESTIMATED_CLOSING_DATE_TITLE));
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDatePlaceHolderText)), EXPECTED_ESTIMATED_CLOSING_DATE_AREA_LABEL, errorMessage(EXPECTED_DATE_PICKER_AREA_LABEL));
            if (isUseMobileViewEnabled()) {
                waitAndClickElement(earlyShoppingInfoIcon);
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalTitle)), ESTIMATED_CLOSING_DATE_INFO_TITLE, errorMessage(ESTIMATED_CLOSING_DATE_INFO_TITLE));
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalText)), ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION, errorMessage(ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION));
                waitAndClickElement(infoModalButtonClose);
            } else {
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoTitle)), ESTIMATED_CLOSING_DATE_INFO_TITLE, errorMessage(ESTIMATED_CLOSING_DATE_INFO_TITLE));
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoDescription)), ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION, errorMessage(ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION));
            }
        } else {
            String expectedTitle = !lobType.equals(RENTERS) && isNewFlowEnabledState(getStateCodeFromAppStore()) ? " property" : EMPTY_STRING;
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateTitle)), String.format(EXPECTED_POLICY_START_DATE_TITLE, expectedTitle), errorMessage(EXPECTED_POLICY_START_DATE_TITLE));
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDatePlaceHolderText)), EXPECTED_DATE_PICKER_AREA_LABEL, errorMessage(EXPECTED_DATE_PICKER_AREA_LABEL));

            policyStartDateOrEstimatedClosingDateInputField.clear();
            sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, getFormattedDateAfter8days());

            if (!appStore.getData().getLandingStateCode().equals(CA)) {
                if (!lobType.equals(RENTERS)) {
                    if (!isUseMobileViewEnabled()) {
                        fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoTitle)), EXPECTED_EARLY_SHOPPING_INFO_TITLE, errorMessage(EXPECTED_EARLY_SHOPPING_INFO_TITLE));
                        fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoDescription)), EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION, errorMessage(EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION));
                    } else {
                        waitAndClickElement(earlyShoppingInfoIcon);
                        fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalTitle)), EXPECTED_EARLY_SHOPPING_INFO_TITLE, errorMessage(EXPECTED_EARLY_SHOPPING_INFO_TITLE));
                        fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalText)), EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION, errorMessage(EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION));
                        waitAndClickElement(infoModalButtonClose);
                    }
                }
            }

        }

        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, getFormattedForPolicyStartDate(LocalDate.now().plusDays(7)));
        if (!lobType.equals(RENTERS) && !appStore.getData().getLandingStateCode().equals(CA)) {
            fsa.assertTrue(isSnackBarMessageDisplayed(EXPECTED_EARLY_SHOPPER_CONGRATS_MESSAGE), "Contact Info page - " + errorMessage(EXPECTED_EARLY_SHOPPER_CONGRATS_MESSAGE));
        }
        // Validate date picker pop up content
        String formattedTodayDate = getFormattedTodayDate();
        waitAndClickElement(datePickerToggleIcon);
        waitAndClickElement(selectedDateInDatePickerPopUp);
        waitAndClickElement(policyStartDateOrEstimatedClosingDateInputField);
        policyStartDateOrEstimatedClosingDateInputField.clear();
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, formattedTodayDate);
        waitAndClickElement(datePickerToggleIcon);

        if (!isEndOfTheMonthDate(formattedTodayDate)) {
            WebElement formattedTodayDateWebElement = driver().findElement(By.xpath("//button[*[contains(@class,'mat-calendar-body-today')]]"));
            fsa.assertTrue(isElementDisabled(formattedTodayDateWebElement), "Today's date is disabled in the DatePicker popup");
            waitAndClickElement(formattedTodayDateWebElement);
        }

        String formattedTomorrowDate = getFormattedTomorrowDate();
        policyStartDateOrEstimatedClosingDateInputField.clear();
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, formattedTomorrowDate);
        fsa.assertEquals(datePickerToggleIcon.isDisplayed(), true, "DatePicker Toggle Icon Displayed");
        waitAndClickElement(datePickerToggleIcon);
        fsa.assertEquals(String.valueOf(getFormattedDateFromStringDate(getValueFromWebElement(policyStartDateOrEstimatedClosingDateInputField)).getDayOfMonth()).trim(), getTextFromElement(selectedDateInDatePickerPopUp), "Policy Start Date From SqlApplicant check");
        String selectedMonthAndYear = policyStartDateFromDatePicker.getMonth() + " " + policyStartDateFromDatePicker.getYear();
        fsa.assertEquals(selectedMonthAndYear, getTextFromElement(selectedMonthYearHeaderInDatePickerPopUp), "Selected month and year verification in date picker pop up");
        waitAndClickElement(selectedDateInDatePickerPopUp);

    }

    public void validateContentOfMailingAndOtherMailingAddress(FarmersSoftAssert fsa) throws Exception {
        //validate mailing address input field content
        final String EXPECTED_MAILING_ADDRESS_LABEL = "Mailing address";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(mailingAddressLabel)), EXPECTED_MAILING_ADDRESS_LABEL, errorMessage(EXPECTED_MAILING_ADDRESS_LABEL));

        AppStore.Data.CustomerData.Address defaultMailingAddress = getSessionStorageAppStore().getData().getCustomerData().getAddress();
        fsa.assertTrue(defaultMailingAddressRadioButton.isEnabled(), "Default mailing address radio button enabled");
        String defaultMailAddressLabel = getTextFromElement(defaultMailingAddressRadioButtonLabel);
        fsa.assertTrue(defaultMailAddressLabel.contains(defaultMailingAddress.getStreet().toUpperCase(Locale.ROOT)), "Default mailing address verification");

        // Validate other mailing address content
        final String EXPECTED_OTHER_MAILING_ADDRESS_LABEL = "Other mailing address";
        clickElement(otherMailingAddressRadioButton);
        fsa.assertTrue(otherMailingAddressRadioButton.isEnabled(), "Other mailing address radio button is not enabled");
        fsa.assertEquals(getAttributeData(waitElementBeVisible(otherMailingAddressRadioButtonLabel), "innerText").strip(), EXPECTED_OTHER_MAILING_ADDRESS_LABEL, errorMessage(EXPECTED_OTHER_MAILING_ADDRESS_LABEL));

        fsa.assertEquals(getTextFromElement(waitElementBeVisible(mailingAddressInputLabel)), MAILING_ADDRESS, errorMessage(MAILING_ADDRESS));

        final String EXPECTED_APARTMENT_LABEL = "Unit #";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(apartmentInputLabel)), EXPECTED_APARTMENT_LABEL, errorMessage(EXPECTED_APARTMENT_LABEL));

        final String EXPECTED_CITY_LABEL = "City";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(cityInputLabel)), EXPECTED_CITY_LABEL, errorMessage(EXPECTED_CITY_LABEL));

        final String EXPECTED_STATE_LABEL = "State";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(stateDropDownLabel)), EXPECTED_STATE_LABEL, errorMessage(EXPECTED_STATE_LABEL));

        final String EXPECTED_ZIP_LABEL = "ZIP";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(zipCodeInputLabel)), EXPECTED_ZIP_LABEL, errorMessage(EXPECTED_ZIP_LABEL));

        final String EXPECTED_STREET_ADDRESS = "10528 Sea Palms Ave";
        final String EXPECTED_CITY = "Las Vegas";
        final String EXPECTED_STATE = "NV";
        final String EXPECTED_ZIP_CODE = "89134";
        scrollToElement(otherMailingAddressInputField);
        enterGoogleAddress(otherMailingAddressInputField, EXPECTED_STREET_ADDRESS, EXPECTED_CITY);
        sleep(5);
        fsa.assertEquals(getAttributeData(otherMailingAddressInputField, VALUE), EXPECTED_STREET_ADDRESS, "Other mailing address street verification.");
        fsa.assertEquals(getAttributeData(otherMailingAddressCityInputField, VALUE), EXPECTED_CITY, "Other mailing address city verification.");
        waitAndClickElement(stateDropDownLabel);
        List<String> foundListOfStates = stateDropDownOptions.stream().map(this::getTextFromElement).sorted().collect(Collectors.toList());
        fsa.assertEquals(foundListOfStates, listOfAllStates(), "Other mailing address list of states verification.");
        fsa.assertEquals(getTextFromElement(otherMailingAddressStateDropdownField), EXPECTED_STATE, "Other mailing address state verification in the state drop down.");
        fsa.assertEquals(getAttributeData(otherMailingAddressZipCodeInputField, VALUE), EXPECTED_ZIP_CODE, "Other mailing address zip code verification.");
        fsa.assertEquals(getAttributeData(otherMailingAddressUnitInputField, VALUE), EMPTY_STRING, "Other mailing address unit is empty.");
        sendKeysToElement(stateDropDown,Keys.TAB);
    }

    public void validateContentOfContactInfo(FarmersSoftAssert fsa) {
        // Validate contact info fields content
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(personalInfoLabel)), EXPECTED_PERSONAL_INFO_LABEL, errorMessage(EXPECTED_PERSONAL_INFO_LABEL));
        final String EXPECTED_EMAIL_ADDRESS_FIELD_LABEL = "Email address";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(emailAddressFieldLabel)), EXPECTED_EMAIL_ADDRESS_FIELD_LABEL, errorMessage(EXPECTED_EMAIL_ADDRESS_FIELD_LABEL));

        final String EXPECTED_MOBILE_PHONE_FIELD_LABEL = "Mobile phone";
        scrollToElement(waitElementBeVisible(mobilePhoneFieldLabel));
        fsa.assertEquals(getTextFromElement(mobilePhoneFieldLabel), EXPECTED_MOBILE_PHONE_FIELD_LABEL, errorMessage(EXPECTED_MOBILE_PHONE_FIELD_LABEL));
    }

    protected void validateContactInformationSection(FarmersSoftAssert fsa) {
    	scrollToElement(personalInfoLabel);
        fsa.assertEquals(getTextFromElement(personalInfoLabel), EXPECTED_PERSONAL_INFO_LABEL, "Verify contact information section header");
        fsa.assertEquals(getTextFromElement(emailAddressFieldLabel), "Email address", "Verify email field placeholder text");
        fsa.assertEquals(getTextFromElement(mobilePhoneFieldLabel), "Phone number", "Verify phone number field placeholder text");
    }

    public void validateDisclaimerOnContactInfoPage(FarmersSoftAssert fsa) {
        final String EXPECTED_ESIGN_DISCLAIMER = "By clicking \"Agree and submit\", you agree to these ESIGN terms and conditions and to receive marketing calls and texts as detailed below.";
        final String EXPECTED_CONTACT_DISCLAIMER = "We call and/or text consumers with information about products and services. " +
        	"By clicking \"Agree and submit\", you consent to receive marketing calls and texts on behalf of Farmers\u00ae, Foremost\u00ae, Bristol West\u00ae, and Farmers Life\u00ae associated entities and their " +
                "representatives using an automated telephone dialing system, AI-generated and artificial or pre-recorded voice, even for numbers listed on national, state, or business do-not-call registries. " +
        	"Consent is not a condition of purchase. Go to Farmers.com for alternative contact options. Message and data rates may apply.";
        scrollToElement(pageFooterDisclaimer);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageFooterDisclaimerEsign, 5)), EXPECTED_ESIGN_DISCLAIMER, "ESIGN disclaimer verification");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageFooterDisclaimer, 5)), EXPECTED_CONTACT_DISCLAIMER, "Contact disclaimer verification");
    }

    public void validateDisclaimerFooterLinks(FarmersSoftAssert fsa, String lob) throws Exception {
        String ELECTRONIC_BUSINESS_CONSENT_TITLE = "Use of Electronic Signatures, Consent to Be Provided Electronic Records, and Agreement to Do Business Electronically";
        String OUR_COMPANIES_TITLE = lob.equals(RENTERS) ? "List of Companies and State Licenses" : "Our Companies";

        Log.info(">> Going to check: ESIGN terms and conditions link.");
        clickElement(linkDisclaimerEsign);
        driverWait(10).until(ExpectedConditions.numberOfWindowsToBe(2));
        List<String> tabs = new ArrayList<>(driver().getWindowHandles());
        driver().switchTo().window(tabs.get(1));
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(electronicSignHeader, 5)).toUpperCase(), ELECTRONIC_BUSINESS_CONSENT_TITLE.toUpperCase(),
                "Contact info page - Electronic business consent title found in the newly opened tab.");
        driver().close();
        driver().switchTo().window(tabs.get(0));
        driverWait(10).until(ExpectedConditions.numberOfWindowsToBe(1));
        Log.info(">> Going to check: associated entities link.");
        clickElement(linkAssociatedEntities);
        driverWait(10).until(ExpectedConditions.numberOfWindowsToBe(2));
        tabs = new ArrayList<>(driver().getWindowHandles());
        driver().switchTo().window(tabs.get(1));
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(ourCompaniesHeader, 5)), OUR_COMPANIES_TITLE,
                "Contact info page - Our Companies title found in the newly opened tab.");
        driver().close();
        driver().switchTo().window(tabs.get(0));
        driverWait(10).until(ExpectedConditions.numberOfWindowsToBe(1));
    }

    public void validateContentOfAgreeAndSubmit(FarmersSoftAssert fsa) {
        final String EXPECTED_CTA_TEXT = "Agree and submit";
        scrollToElement(agreeAndSubmitButton);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(agreeAndSubmitButton)), EXPECTED_CTA_TEXT, errorMessage(EXPECTED_CTA_TEXT));
    }

    public boolean getFireHydrantYesNo() throws Exception {
        boolean fireHydrant;
        if (isElementDisplayed(By.xpath(FIRE_HYDRANT_BUTTON_XPATH))) {
            String hydrant = driver().findElements(By.xpath(FIRE_HYDRANT_BUTTON_XPATH + "//mat-button-toggle")).stream()
                    .filter(i -> getAttributeData(i, CLASS).contains("mat-button-toggle-checked"))
                    .map(BasePage::getValueFromWebElement).findFirst().orElse(null);
            assert hydrant != null;
            fireHydrant = hydrant.equals("Y");
        } else {
            fireHydrant = false;
        }
        return fireHydrant;
    }

    public boolean isFirehydrantYes() throws Exception {
        return isButtonSelected(driver().findElement(By.xpath(FIRE_HYDRANT_BUTTON_XPATH + "//button[.='Yes']")));
    }

    public boolean isFirehydrantNo() throws Exception {
        return isButtonSelected(driver().findElement(By.xpath(FIRE_HYDRANT_BUTTON_XPATH + "//button[.='No']")));
    }

    public void selectFirehydrant(boolean fireHydrant) throws Exception {
        String buttonXpath = fireHydrant ? "//button[.='Yes']" : "//button[.='No']";
        List<WebElement> buttonListWe = driver().findElements(By.xpath(FIRE_HYDRANT_BUTTON_XPATH + buttonXpath));
        if (!buttonListWe.isEmpty()) {
            if(buttonListWe.size() == 2){
                scrollAndClickOnElement(buttonListWe.get(1));
            }else{
                scrollAndClickOnElement(buttonListWe.get(0));
            }

        } else {
            Log.warn("Fire hydrant button Yes/No: " + fireHydrant + " is not displayed.");
        }
    }

    public void selectIsHomeVisible(boolean homeVisible) throws Exception {
        String buttonXpath = homeVisible ? "//mat-radio-button[@value='Y']" : "//mat-radio-button[@value='N']";
        WebElement we = driver().findElement(By.xpath(IS_HOME_VISIBLE_QUESTION_BUTTON_XPATH + buttonXpath + "//input"));
        scrollToTopOfPage();
        clickOnHiddenElement(we);
    }

    public void selectSecondaryHeatingSource(String secondaryHeatingSource) throws Exception {
        WebElement we = driver().findElement(By.xpath(IS_SECONDARY_HEATING_SOURCE_BUTTON_QUESTION_XPATH +
                String.format("//mat-radio-button[@value='%s']//input", secondaryHeatingSource)));
        scrollAndClickOnElement(we);
    }

    public void validateContentOfFireHydrantSection(FarmersSoftAssert fsa, String homeLobType) throws Exception {
        final String FIRE_HYDRANT_SECTION_TITLE = "Does this apply to your home?";
        final String FIRE_HYDRANT_SECTION_LABEL = "There is a fire hydrant within 1000 ft of the property.";
        final String TWO_ADDITIONAL_QUESTIONS_TEXT = "We just need to ask you two more questions:";
        final String FIRST_QUESTION_LABEL = "Is this home visible from the main road or by neighbors?";
        final String SECOND_QUESTION_LABEL = "Is there a secondary heating source installed in the home that burns wood, " +
                "pellets, coal or kerosene (excluding a fireplace)?";
        List<String> secondQuestionTextOptions = Arrays.asList("There is, it's professionally installed", "Yes, but it's not professionally installed",
                "No, there isn't");

        if (!homeLobType.equals(RENTERS)) { // Fire hydrant question related story: US626980
            try {
                AppStore.Home.GetLocation getLocation = getSessionStorageAppStore().getHome().getLocation();
                int yearBuilt = Integer.parseInt(getSessionStorageAppStore().getHome().getPropertyForm().getFields().get(0).getYearBuilt());
                boolean fireHydrantQuestion = (getLocation.getSplitPPCInd().equalsIgnoreCase(TRUE) && getLocation.getWaterSupplyType().equals("-"))
                        || (getLocation.getPublicProtectionClassification().equals("09") && ((currentDate.getYear() - yearBuilt) < 40));
                String expected = fireHydrantQuestion ? SPACE : NOT;
                fsa.assertEquals(isElementDisplayed(By.xpath(FIRE_HYDRANT_SECTION_XPATH)) && !isElementDisplayed(By.xpath(WILDFIRE_RISK_REDUCTION_XPATH)),
                        fireHydrantQuestion, "Contact Info page - Fire hydrant section" + expected + "present based on the getLocation response from appStore.");
            } catch (Exception e) {
                Log.warn("Some appStore data is unavailable:");
                Log.warn(e.toString());
            }
        }
        if (isElementDisplayed(By.xpath(FIRE_HYDRANT_SECTION_XPATH)) && !isElementDisplayed(By.xpath(WILDFIRE_RISK_REDUCTION_XPATH))) {
            selectFirehydrant(false);
            if (homeLobType.equals(HOME)) {
                fsa.assertEquals(getTextFromElement(fireHydrantSectionTitle), FIRE_HYDRANT_SECTION_TITLE, "Contact Info page - Fire hydrant section title.");
                if (isElementDisplayed(By.xpath(FIRE_HYDRANT_RADIO_BUTTON_QUESTIONS_XPATH))) {
                    fsa.assertEquals(getTextFromElement(fireHydrantSectionLabel), FIRE_HYDRANT_SECTION_LABEL, "Contact Info page - Fire hydrant section label.");
                    fsa.assertEquals(getTextFromElement(fireHydrantQuestionsText), TWO_ADDITIONAL_QUESTIONS_TEXT, "Contact Info page - Fire hydrant section 2 additional questions text.");
                }
                fsa.assertEquals(getTextFromElement(fireHydrantQuestion1label), FIRST_QUESTION_LABEL, "Contact Info page - Fire hydrant section 1st question label.");
                fsa.assertEquals(getTextFromElement(fireHydrantQuestion2label), SECOND_QUESTION_LABEL, "Contact Info page - Fire hydrant section 2nd question label.");
                List<String> secondQuestionOptions = driver().findElements(By.xpath(IS_SECONDARY_HEATING_SOURCE_BUTTON_QUESTION_XPATH + "//mat-radio-button"))
                        .stream().map(this::getTextFromElement).map(String::strip).collect(Collectors.toList());
                fsa.assertTrue(secondQuestionTextOptions.equals(secondQuestionOptions), "Contact Info page - Secondary Heating Source Options text.");
            } else {
                fsa.assertFalse(isElementPresent(By.xpath(FIRE_HYDRANT_RADIO_BUTTON_QUESTIONS_XPATH)), "Contact Info page - No additional questions for non-Home Lobs.");
            }
            selectFirehydrant(true);
        }
    }

    public void validateFireHydrantSectionErrorMessages(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {
        final String ERROR_MESSAGE = "This is a required field.";
        if (isElementDisplayed(By.xpath(FIRE_HYDRANT_SECTION_XPATH)) && !isElementDisplayed(By.xpath(WILDFIRE_RISK_REDUCTION_XPATH))) {
            waitAndClickElement(defaultMailingAddressRadioButton);
            if (!isNewFlowEnabledState(applicant.getStateCode())) {
                enterEmailIdAndPhoneNumberInContactInfoPage(applicant);
            }
            selectFirehydrant(false);
            WebElement button = isNewFlowEnabledState(applicant.getStateCode()) ? buttonContinue : agreeAndSubmitButton;
            waitAndClickElement(button); // to activate Fire hydrant is home visible message

            List<String> errors = getPageErrors();
            fsa.assertTrue((errors.contains(ERROR_MESSAGE) && errors.size() == 1), "Contact Info page - Is this home visible error.");
            selectIsHomeVisible(false);
            waitAndClickElement(button); // to activate Fire hydrant SHS error message

            errors = getPageErrors();
            fsa.assertTrue((errors.contains(ERROR_MESSAGE) && errors.size() == 1), "Contact Info page - Is SHS installed error.");
            selectSecondaryHeatingSource("N");
            errors = getPageErrors();
            fsa.assertTrue(errors.isEmpty(), "Contact Info page - Fire hydrant section has no errors.");
        }
    }


    public void validateContentOfWildfireRiskReductionSection(FarmersSoftAssert fsa) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        if (appStore.getData().getLandingStateCode().equals(CA)) {
            final String WILDFIRE_RISK_REDUCTION_SECTION_TITLE = "Does this apply to your home?";
            final String WILDFIRE_RISK_REDUCTION_SECTION_LABEL = "This property is eligible for wildfire risk reduction discounts. (Select \"Yes\" to review eligibility.)";
            final String WILDFIRE_RISK_REDUCTION_SECTION_SUBTEXT = "1 of 12 factors apply Edit";
            final String WILDFIRE_RISK_REDUCTION_SIDE_SHEET_TITLE = "Wildfire risk reduction";
            final String WILDFIRE_RISK_REDUCTION_SIDE_SHEET_SUBTITLE = "Please review and check the items that apply to your community and property. We may have pre-checked some items " +
                    "for you, but you can update as needed.";
            final String WILDFIRE_RISK_REDUCTION_SIDE_SHEET_SUBTITLE2 = "Do these apply to your community?";
            final String WILDFIRE_RISK_REDUCTION_SIDE_SHEET_SECTION2_SUBTITLE = "Select any wildfire mitigation measures that you have implemented on your property:";
            List<String> WILDFIRE_RISK_REDUCTION_CHECKBOXES = List.of("The property is located within a Firewise community.", "The property is located within a Fire Risk Reduction community.",
                    "Code compliance", "Windows and shutters", "Property's vents are fire-resistant", "Property's eaves are enclosed", "Class-A roof installed", "Noncombustible materials",
                    "Removal of combustible structures", "Vertical clearance", "Decking", "Clearing within 5 feet of the home");

            final String WILDFIRE_RISK_REDUCTION_SIDE_SHEET_BLOB = "Wildfire risk reduction close Please review and check the items that apply to your community and property. We may have " +
                    "pre-checked some items for you, but you can update as needed. Do these apply to your community? The property is located within a Firewise community. The property is " +
                    "located within a Fire Risk Reduction community. Select any wildfire mitigation measures that you have implemented on your property: Code compliance Property complies " +
                    "with Section 4291 of the Public Resources Code, and with any local ordinances, governing defensible space, OR Code compliance does not apply to my property Windows " +
                    "and shutters Property has multi-pane windows, or dual-pane windows, or functional shutters, which --when closed-- cover the entire window and do not have openings. " +
                    "Property's vents are fire-resistant Property's eaves are enclosed Class-A roof installed We received verification of this installation and have pre-checked this for you. " +
                    "Noncombustible materials Incorporation of only noncombustible materials into that portion of any improvements to the property on which the property is located, " +
                    "including fences and gates, within 5 feet of the home. Removal of combustible structures Removal or absence of combustible structures, including sheds and other " +
                    "outbuildings, from the area within 30 feet of the home, or from as much of the area that's under the control of the insured. Vertical clearance Property has at least 6 " +
                    "inches of noncombustible vertical clearance at the bottom of the exterior surface of the building, measured from the ground up. Decking Clearing of vegetation and debris from " +
                    "under decks, OR There is no decking Clearing within 5 feet of the home Clearing of vegetation, debris, mulch, stored combustible materials, and movable combustible objects.";


            List<String> wildfireOptions = new ArrayList<>();
            if (appStore.getHome().getContactInfo() != null) {
                wildfireOptions = appStore.getHome().getContactInfo().getWildFireOptions();
            }
            if ((wildfireOptions != null) && (!wildfireOptions.isEmpty())) {
                fsa.assertTrue(isElementDisplayed(By.xpath(WILDFIRE_RISK_REDUCTION_XPATH)), "Contact info page - Wildfire risk reduction section is displayed.");
                fsa.assertTrue(getAttributeData(wildfireRiskMatButtonToggleYes, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED), "Contact info page - Wildfire risk reduction Yes button is selected.");
                fsa.assertFalse(getAttributeData(wildfireRiskMatButtonToggleNo, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED), "Contact info page - Wildfire risk reduction No button is Not selected.");
                fsa.assertFalse(wildfireRiskButtonToggleNo.isEnabled(), "Contact info page - Wildfire risk reduction No button is disabled.");
                fsa.assertEquals(getTextFromElement(fireHydrantSectionTitle), WILDFIRE_RISK_REDUCTION_SECTION_TITLE, "Contact info page - Wildfire risk reduction section title.");
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionLabelCA) + SPACE + getTextFromElement(wildfireRiskReductionSpanCA), WILDFIRE_RISK_REDUCTION_SECTION_LABEL,
                        "Contact Info page - Wildfire risk reduction section label.");
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionSubtextCA), WILDFIRE_RISK_REDUCTION_SECTION_SUBTEXT,
                        "Contact Info page - Wildfire risk reduction section sub-text.");
                // validate wildfire risk reduction side sheet
                waitAndClickElement(editWildfireRiskReduction);
                driverWait(5).until(ExpectedConditions.elementToBeClickable(closeWildfireSideSheet));
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionSideSheet), WILDFIRE_RISK_REDUCTION_SIDE_SHEET_BLOB, "Contact info page - Wildfire risk reduction section text (BLOB).");
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionSideSheetTitle), WILDFIRE_RISK_REDUCTION_SIDE_SHEET_TITLE, "Contact info page - Wildfire risk reduction section title.");
                fsa.assertTrue(isElementDisplayed(wildfireRiskReductionSideSheetDivider,1), "Contact info page - Wildfire risk reduction section title divider.");
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionSideSheetSubtitle), WILDFIRE_RISK_REDUCTION_SIDE_SHEET_SUBTITLE, "Contact info page - Wildfire risk reduction section subtitle.");
                fsa.assertTrue(isElementDisplayed(wildfireRiskReductionSideSheetDivider1,1), "Contact info page - Wildfire risk reduction section sub-divider 1.");
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionSideSheetSubtitle2), WILDFIRE_RISK_REDUCTION_SIDE_SHEET_SUBTITLE2, "Contact info page - Wildfire risk reduction section subtitle 2.");
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionSideSheetSection2Subtitle), WILDFIRE_RISK_REDUCTION_SIDE_SHEET_SECTION2_SUBTITLE, "Contact info page - Wildfire risk reduction section2 subtitle.");
                fsa.assertTrue(isElementDisplayed(wildfireRiskReductionSideSheetDivider2,1), "Contact info page - Wildfire risk reduction section sub-divider 2.");
                List<String> checkboxLabels = wildfireRiskReductionSideSheetCheckboxLabels.stream().map(this::getTextFromElement).collect(Collectors.toList());
                fsa.assertEquals(checkboxLabels,WILDFIRE_RISK_REDUCTION_CHECKBOXES, "Contact info page - Wildfire risk reduction checkbox titles.");
                for (WebElement checkbox : wildfireRiskReductionSideSheetCheckboxes) {
                    if (getAttributeData(checkbox, CLASS).contains(MAT_CHECKBOX_CHECKED)) {
                        String option = getValueFromWebElement(checkbox.findElement(By.xpath("descendant::input"))).strip();
                        Log.info("Selected option value: " + option);
                        fsa.assertTrue(wildfireOptions.stream().anyMatch(e -> e.equalsIgnoreCase(option)), "Contact info page - Wildfire risk reduction checked checkbox titles match to the appStore values.");
                    }
                }
                waitAndClickElement(closeWildfireSideSheet);
            } else {
                fsa.assertFalse(isElementDisplayed(By.xpath(WILDFIRE_RISK_REDUCTION_XPATH)), "Contact Info page - Wildfire risk reduction section is not displayed.");
            }
        }
    }

    public void enterPolicyStartDate(ApplicantAceHome applicant) {
        String earlyShoppingFactor = applicant.getEarlyShoppingFactor();
        if (earlyShoppingFactor.equalsIgnoreCase(TRUE)) {
            String policyStartDate = getFormattedForPolicyStartDate(getTodayDate().plusDays(7));
            sendKeysToElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateInputField), policyStartDate);
        } else {
            if(!earlyShoppingFactor.equalsIgnoreCase(FALSE) && !earlyShoppingFactor.isBlank()){
                sendKeysToElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateInputField), earlyShoppingFactor);
            }
        }
    }

    // Update policy start date randomly
    public void updatePolicyStartDate(ApplicantAceHome applicant) {
        Random random = new Random();
        int randomDays = random.nextInt(12) + 3; // Any random day between 3 and 12;
        String policyStartDate = getFormattedForPolicyStartDate(getTodayDate().plusDays(randomDays));
        sendKeysToElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateInputField), policyStartDate);
    }

    public String getPolicyStartDate() {
        return getValueFromWebElement(policyStartDateOrEstimatedClosingDateInputField);
    }

    public void enterFireHydrantData(ApplicantAceHome applicant) throws Exception {
        if (isElementPresent(By.xpath(FIRE_HYDRANT_SECTION_XPATH))) {
            if (isElementPresent(By.xpath(FIRE_HYDRANT_BUTTON_XPATH))) {
                selectFirehydrant(applicant.isFireHydrant());
            }
            if (isElementPresent(By.xpath(IS_HOME_VISIBLE_QUESTION_BUTTON_XPATH + "//mat-radio-group"))) {
                selectIsHomeVisible(applicant.isHomeVisible());
            }
            if (isElementPresent(By.xpath(IS_SECONDARY_HEATING_SOURCE_BUTTON_QUESTION_XPATH))) {
            	String valueFromApplicant = applicant.getSecondaryHeatingSource();
            	String secondaryHeating = valueFromApplicant.isBlank()? "N": valueFromApplicant.equalsIgnoreCase(TRUE)? "P": valueFromApplicant;
                selectSecondaryHeatingSource(secondaryHeating);
            }
        }
    }

    public void fillOutWildfireRiskReductionCA(String wildfireRiskReduction) throws Exception {
        if (isElementDisplayed(By.xpath(WILDFIRE_RISK_REDUCTION_XPATH))) {
            if (!wildfireRiskReduction.isBlank()) {
                if (!getAttributeData(wildfireRiskMatButtonToggleYes, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED)) {
                    clickElement(wildfireRiskButtonToggleYes);
                    enterWildfireRiskReductionOptions(wildfireRiskReduction);
                }
            } else {
                if (!getAttributeData(wildfireRiskMatButtonToggleNo, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED)) {
                    clickElement(wildfireRiskButtonToggleNo);
                }
            }
        }
    }

    public void enterWildfireRiskReductionOptions(String options) throws Exception {
        List<String> listOptions = Stream.of(options.split(COMMA)).map(String::trim).collect(Collectors.toList());
        boolean updated = false;
        for (String option: listOptions) {
            WebElement weMatCheckbox = driver().findElement(By.xpath(String.format(WILDFIRE_RISK_REDUCTION_MAT_CHECKBOX_XPATH,option)));
            if (getAttributeData(weMatCheckbox, CLASS).contains(MAT_CHECKBOX_DISABLED)) {
                continue;
            }
            if (!getAttributeData(weMatCheckbox, CLASS).contains(MAT_CHECKBOX_CHECKED)) {
                WebElement weOption = driver().findElement(By.xpath(String.format(WILDFIRE_RISK_REDUCTION_TEMPLATE_XPATH, option)));
                waitAndClickElement(weOption);
                updated = true;
            }
        }
        if (updated) {
            waitAndClickElement(saveButtonWildfireRisk);
        } else {
            waitAndClickElement(closeWildfireSideSheet);
            if (isElementDisplayed(buttonNoChangesOk,2)) {
                waitAndClickElement(buttonNoChangesOk);
            }
        }
    }

    protected void enterMailingAddress(ApplicantAceHome applicant) throws Exception {
        if (applicant.isMailingAddressDifferent()) {
            scrollAndClickOnElement(otherMailingAddressRadioButton);
            enterValueInField(applicant.getAddress(), waitElementBeVisible(mailingAddressInputField), "Entering applicant's mailing address");
            enterValueInField(applicant.getCity(), waitElementBeVisible(cityInputField), "Entering applicant's city");
            selectValueInDropDown(waitElementBeVisible(stateDropDown), applicant.getStateCode());
            enterValueInField(applicant.getZipCode(), waitElementBeVisible(zipCodeInputField), "Entering applicant's zip code");
        }
    }

    public boolean isBundleCheckboxSelected(String name) throws Exception {
        return isCheckboxSelected(driver().findElement(By.xpath(BUNDLE_CHECKBOXES_XPATH + "//span[text()='" + name + "']/ancestor::mat-checkbox//input")));
    }

    public String getEmailAddress() {
        return getValueFromWebElement(emailAddressInput);
    }

    public String getPhoneNumber() {
        return getValueFromWebElement(phoneNumberInput);
    }


    public String getDateOfBirth() {
        return getValueFromWebElement(dateOfBirthInputBox);
    }

    public String getOccupation() {
        return getTextFromElement(occupationPrimary);
    }

    public String getSpouseFirstName() {
        return getValueFromWebElement(spouseFirstNameInputBox);
    }

    public boolean isSpouseFirstNameReadOnly() {
        return isAttributePresent(spouseFirstNameInputBox, DISABLED);
    }

    public String getSpouseLastName() {
        return getValueFromWebElement(spouseLastNameInputBox);
    }

    public boolean isSpouseLastNameReadOnly() {
        return isAttributePresent(spouseLastNameInputBox, DISABLED);
    }

    public String getSpouseDateOfBirth() {
        return getValueFromWebElement(spouseDateOfBirthInputBox);
    }

    public boolean isSpouseDateOfBirthReadOnly() {
        return isAttributePresent(spouseDateOfBirthInputBox, DISABLED);
    }

    public String getSpouseOccupation() {
        return getTextFromElement(occupationSpouse);
    }

    public boolean isSpouseFirstNameInputBoxDisplayed() {
        return isElementDisplayed(spouseFirstNameInputBox, 2);
    }

    public boolean isSpouseLastNameInputBoxDisplayed() {
        return isElementDisplayed(spouseLastNameInputBox, 2);
    }

    public boolean isSpouseDateOfBirthInputBoxDisplayed() {
        return isElementDisplayed(spouseDateOfBirthInputBox, 2);
    }

    public boolean isMMDDYYHintDisplayed() {
        return isElementDisplayed(mmddyyyyHint, 3);
    }

    private boolean checkGenderButtons(List<WebElement> listOfGenderButtons, String stateCode, String lob) throws Exception {
        List<String> listOfExpectedButtonLabels =new ArrayList<>(Arrays.asList(MALE, FEMALE, NONBINARY));
        List<String> listOfActualButtonLabels = new ArrayList<>();
        isElementDisplayed(By.xpath(GENDER_SELECTION_XPATH));
        listOfGenderButtons.forEach(button -> listOfActualButtonLabels.add(getTextFromElement(button).replace("-",""))); // diff b/w Non-binary vs. Nonbinary
        if (lob.equals(HOME)) {
            if (List.of(AL, KS, KY, IA, IN, LA, MA, MD, MN, MS, MT, NC, OH, WA).contains(stateCode)) {
                listOfExpectedButtonLabels.remove(NONBINARY);
            }
        } else {
            if (!List.of(CA, OR).contains(stateCode)) {
                listOfExpectedButtonLabels.remove(NONBINARY);
            }
        }
        return areTwoListEqual(listOfActualButtonLabels, listOfExpectedButtonLabels);
    }

    private boolean areSpouseGenderButtonsDisplayedCorrectly(String stateCode, String lob) throws Exception {
        return checkGenderButtons(spouseGenderButtons, stateCode, lob);
    }

    public boolean isSpouseGenderDisplayed() throws Exception {
        return isElementPresent(By.xpath(SPOUSE_GENDER_SELECTION_XPATH));
    }

    public String getPriorOrCurrentAddress() {
        return getValueFromWebElement(otherMailingAddressInputField);
    }

    public String getPriorOrCurrentAddressCity() {
        return getValueFromWebElement(priorOrCurrentAddressCityInputBox);
    }

    public String getPriorOrCurrentAddressState() {
        return getTextFromElement(priorOrCurrentAddressStateSelect);
    }

    public String getPriorOrCurrentAddressZip() {
        return getValueFromWebElement(priorOrCurrentAddressZipInputBox);
    }

    public void validateContactInfoSelections(ApplicantAceHome applicant, boolean ratedQuote, String lobType, FarmersSoftAssert fsa) throws Exception {
        // Policy start date
        String policyStartDate = applicant.getEarlyShoppingFactor().trim();
        if (policyStartDate.equalsIgnoreCase(TRUE)) {
            policyStartDate = getFormattedForPolicyStartDate(getTodayDate().plusDays(7));
        } else if (policyStartDate.isBlank() || policyStartDate.equalsIgnoreCase(FALSE)) {
            policyStartDate = getFormattedForPolicyStartDate(getTodayDate().plusDays(1));
        }
        fsa.assertEquals(getPolicyStartDate(), policyStartDate, "Contact Info page - Policy start date value.");
        // Fire hydrant question
        if (isElementDisplayed(By.xpath(FIRE_HYDRANT_SECTION_XPATH))) {
            fsa.assertEquals(getFireHydrantYesNo(), applicant.isFireHydrant(), "Contact Info page - Fire hydrant question value.");
        }
        String stateCode = applicant.getStateCode();
        // Discount bundles
        if (!isHomeToAutoBundleEligibleAndEnabled(stateCode)) {
            List<SqlDiscount> discounts = applicant.getDiscounts();
            SqlDiscount discount = discounts.stream().findFirst().orElse(null);
            assert discount != null;
            fsa.assertEquals(isBundleCheckboxSelected(AUTO), discount.isAutoInsurance(), "Contact Info page - bundle Auto insurance");
            if (!isNoLifeBundleState(stateCode) && ratedQuote) {
                fsa.assertEquals(isBundleCheckboxSelected(LIFE), discount.isLifeInsurance(), "Contact Info page - bundle Life insurance");
            }
            if (!isNonUmbrellaState(stateCode)) {
                fsa.assertEquals(isBundleCheckboxSelected(UMBRELLA), discount.isUmbrellaInsurance(), "Contact Info page - bundle Umbrella insurance");
            }
            if (isAdditionalHomeBundleDiscountsState(stateCode)) {
                fsa.assertEquals(isBundleCheckboxSelected(FfqBundleOptions.BUSINESS.getBundleLob()), discount.isBusinessInsurance(), "Contact Info page - bundle Business insurance");
                fsa.assertEquals(isBundleCheckboxSelected(FfqBundleOptions.RECREATIONAL.getBundleLob()), discount.isRecreationalBoatWatercraftInsurance(),
                        "Contact Info page - bundle Recreational Boat/Watercraft insurance");
                fsa.assertEquals(isBundleCheckboxSelected(FfqBundleOptions.OFF_ROAD_VEHICLE.getBundleLob()), discount.isMotorcycleInsurance(), "Contact Info page - bundle Off-Road Vehicle insurance");
                fsa.assertEquals(isBundleCheckboxSelected(FfqBundleOptions.MOTOR_HOME.getBundleLob()), discount.isMotorHome(),
                        "Contact Info page - bundle Motorhome, Travel Trailer or 5th Wheel insurance");
            }
        }
        if (!lobType.equals(RENTERS) && isNewFlowEnabledState(stateCode)) {
            if (ratedQuote) {
                fsa.assertTrue(isGenderReadOnly(), "About You page - Gender is read-only.");
                fsa.assertTrue(isMarriedCheckboxReadOnly(), "Married checkbox is read-only.");
            }
            fsa.assertEquals(getGenderApplicant(), applicant.getGender(), "About You page - Applicant's gender value.");
            if (!isNoEligibleOccupationState(stateCode)) {
                fsa.assertEquals(getOccupation(), applicant.getOccupation(), "About You page - Occupation.");
            }
            if (applicant.getMaritalStatus().equals(MARRIED)) {
                fsa.assertTrue(isMarriedCheckboxChecked(), "Married checkbox is checked.");
                if (ratedQuote) {
                    fsa.assertTrue(isMarriedCheckboxReadOnly(), "Married checkbox is read-only.");
                    fsa.assertTrue(isSpouseFirstNameReadOnly(), "About You page - Spouse first name is read-only.");
                    fsa.assertTrue(isSpouseLastNameReadOnly(), "About You page - Spouse last name is read-only.");
                    fsa.assertTrue(isSpouseDateOfBirthReadOnly(), "About You page - Spouse Date of birth is read-only.");
                    fsa.assertEquals(getSpouseDateOfBirth(), "**/**/" + applicant.getSpouseDateOfBirth().split("/")[2],
                            "About You page - Partially masked spouse Date of birth value.");
                    fsa.assertTrue(isSpouseGenderReadOnly(), "About You page - Spouse Gender is read-only.");
                } else {
                    fsa.assertFalse(isMarriedCheckboxReadOnly(), "Married checkbox is not read-only.");
                }
                fsa.assertEquals(getSpouseFirstName().toLowerCase(), applicant.getSpouseFirstName().toLowerCase(), "About You page - Spouse first name value.");
                fsa.assertEquals(getSpouseLastName().toLowerCase(), applicant.getSpouseLastName().toLowerCase(), "About You page - Spouse last name value.");
                fsa.assertEquals(getGenderSpouse(), applicant.getSpouseGender(), "About You page - Spouse's gender value.");
                if (!isNoEligibleOccupationState(stateCode)) {
                    fsa.assertEquals(getSpouseOccupation(), applicant.getOccupation(), "About You page - Spouse Occupation.");
                }
            } else {
                fsa.assertTrue(!isSpouseFirstNameInputBoxDisplayed(), "About you page - Spouse first name input field displayed.");
                fsa.assertTrue(!isSpouseLastNameInputBoxDisplayed(), "About you page - Spouse last name input field displayed.");
                fsa.assertTrue(!isSpouseDateOfBirthInputBoxDisplayed(), "About you page - Spouse date of birth input field displayed.");
                fsa.assertTrue(!isSpouseGenderDisplayed(), "About you page - Spouse date of birth input field displayed.");
                fsa.assertTrue(!isMarriedCheckboxChecked(), "Married checkbox is not checked.");
            }
        }
        // Mailing address
        if (!lobType.equals(RENTERS)) {
            AppStore.Data.CustomerData.Address address = getSessionStorageAppStore().getData().getCustomerData().getAddress();
            fsa.assertEquals(getAttributeData(defaultMailingAddressRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED), true,
                    "Contact Info page - Default mailing address radio-button is selected.");
            fsa.assertEquals(getTextFromElement(defaultMailingAddressRadioButtonLabel).toUpperCase(), address.getNew_address().toUpperCase(),
                    "Contact Info page - Default mailing address");
            fsa.assertEquals(getAttributeData(otherMailingAddressRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED), false,
                    "Contact Info page - Other mailing address radio-button is selected.");
        }
        // Contact info
        if (lobType.equals(RENTERS) || !isNewFlowEnabledState(stateCode)) {
            fsa.assertTrue(isEmailAddressReadOnly(), "Contact Info page - e-mail address is read-only.");
            fsa.assertTrue(isPhoneNumberReadOnly(), "Contact Info page - phone is read-only.");
            fsa.assertEquals(getEmailAddress(), applicant.getEmailAddress(), "Contact Info page - e-mail address.");
            fsa.assertEquals(getPhoneNumber(), getFormattedPhoneNumber(applicant.getPhoneNumber()), "Contact Info page - phone number.");
        }
    }

    public boolean validateFloorResidenceIsLocatedOnSection(String lob) {
        boolean result;
        if (lob.equals(RENTERS)) {
            result = isElementDisplayed(residenceFloorSection, 1) &&
                    getTextFromElement(residenceFloorSectionSubtitle).equals("Does this apply to your home?") &&
                    getTextFromElement(residenceFloorInfoLabel).equals("My unit is on the third floor, or higher") &&
                    getTextFromElement(residenceFloorInfoDescription).equals("It is not located in the basement, first, or second floor");
        } else {
            result = !isElementDisplayed(residenceFloorSection, 1) &&
                    !isElementDisplayed(residenceFloorCheckbox, 1) &&
                    !isElementDisplayed(residenceFloorInfoLabel, 1) &&
                    !isElementDisplayed(residenceFloorInfoDescription,1);
        }
        return result;
    }

    public void validateADA(String lobType) throws Exception {
        clearOutFieldUsingBackSpace(policyStartDateOrEstimatedClosingDateInputField);
        if (isElementVisible(fireHydrantSection,2)) {
            selectFirehydrant(false);
            if (isElementDisplayed(By.xpath(IS_HOME_VISIBLE_QUESTION_BUTTON_XPATH+"//mat-radio-button"))) {
                selectIsHomeVisible(false);
                selectSecondaryHeatingSource("P");
            }
        }
        scrollAndClickOnElement(otherMailingAddressRadioButton);
        waitAndClickElement(agreeAndSubmitButton);
        performADATesting("AceHRCContactInfoPage",MARKETING_IT,lobType);
        driver().navigate().refresh();
    }
    public boolean isResidenceInEscrow(AppStore sessionStorage) {
        Field field = sessionStorage.getHome().getAddressForm().getFields().get(0);
        return (field.getIsNewHome() != null && field.getIsNewHome().equals("Y") && field.getInEscrow().equals("Y"));
    }

    public void validatePrimaryNameInsured(ApplicantAceHome applicant, FarmersSoftAssert fsa) {
        final String PRIMARY_INSURANCE_NAME_TITLE = "Primary named insured";
        fsa.assertEquals(getTextFromElement(primaryInsuranceGroupTitle),PRIMARY_INSURANCE_NAME_TITLE, "Primary Name Insured section title verification.");
        String expectedPNI = applicant.getFirstName() +" "+ applicant.getLastName();
        fsa.assertEquals(getTextFromElement(primaryInsuredName), expectedPNI, "Primary Name Insured match.");
    }
    public void validateConsentSectionFramersInsuranceGroup(FarmersSoftAssert fsa) throws Exception {
        isElementDisplayed(contactInfoDisclaimer, 3);
        String CONSENT_TEXT = "By making the selection(s) below and clicking \"Agree and submit\", you agree to these ESIGN term and " +
                "conditions and to receive marketing calls and text messages as detailed below.";
        fsa.assertEquals(getTextFromElement(contactInfoDisclaimer), CONSENT_TEXT, "Contact info page - Consent text");
        String INSURANCE_GROUP_SECTION_TITLE = "Choose Farmers Insurance Group\u00AE brands to select the scope of your consent.";
        fsa.assertEquals(getTextFromElement(selectInsuranceGroupTitle), INSURANCE_GROUP_SECTION_TITLE, "Contact Info page - Selection of Insurance Group section title verification.");
        String expectedSelectAllCheckboxLabel = "Select all parties, or ...";
        fsa.assertEquals(getTextFromElement(selectAllCheckboxLabel), expectedSelectAllCheckboxLabel, "Select all  label verification.");
        String expectedSelectAllCheckboxSubLabel = "Choose them individually below:";
        fsa.assertEquals(getTextFromElement(selectAllCheckboxSubLabel), expectedSelectAllCheckboxSubLabel, "Select all sub label verification.");

        String expectedFarmersCheckboxLabel = "Farmers\u00AE";
        fsa.assertEquals(getTextFromElement(farmersCheckboxLabel), expectedFarmersCheckboxLabel, "Farmers label checkbox text verification.");
        String expectedFarmersCheckboxSubLabel = "Auto, property, umbrella, business, financial services, and more";
        fsa.assertEquals(getTextFromElement(farmersCheckboxSubLabel), expectedFarmersCheckboxSubLabel, "Farmers sub label checkbox text verification.");

        String expectedBWCheckboxLabel = "Bristol West\u00AE";
        fsa.assertEquals(getTextFromElement(BWCheckboxLabel), expectedBWCheckboxLabel, "BW label  verification.");
        String expectedBWCheckboxSubLabel = "Commercial and non-standard auto";
        fsa.assertEquals(getTextFromElement(BWCheckboxSubLabel), expectedBWCheckboxSubLabel, "BW sub label verification.");
        int numberOfCheckboxes = individualBrandCheckboxes.size();
        for (int i = 0; i < numberOfCheckboxes; i++) {
            checkUncheckMatCheckbox(String.format(BRANDS_CHECKBOXES_XPATH, i + 1), true);
            Log.info("Checkbox " + (i + 1) + " is now selected.", true);
            checkUncheckMatCheckbox(String.format(BRANDS_CHECKBOXES_XPATH, i + 1), false);
            Log.info("Checkbox " + (i + 1) + " is now unselected.", true);
        }
        checkUncheckMatCheckbox(ALL_BRANDS_CHECKBOX_XPATH, true);
        Log.info("Select all checkbox is now selected.", true);
        checkUncheckMatCheckbox(ALL_BRANDS_CHECKBOX_XPATH, false);
        Log.info("Select All Checkbox is now unselected.", true);

        validatePageLinksNavigationTitles(fsa);
    }

    public void verifyBundleTextChangesForHRCContactInfoPage(FarmersSoftAssert fsa, boolean isInEscrow){
        String expectedPropertyPolicyStartDateHeader = "Property policy start date";
        fsa.assertEquals(getTextFromElement(lastStepBeforeYourPageHeader), expectedPropertyPolicyStartDateHeader, expectedPropertyPolicyStartDateHeader + " header text validation");
        if( isInEscrow) {
            fsa.assertEquals(getTextFromElement(policyStartDateOrEstimatedClosingDateTitle), EXPECTED_ESTIMATED_CLOSING_DATE_TITLE, EXPECTED_ESTIMATED_CLOSING_DATE_TITLE + " header text validation");
            fsa.assertEquals(getTextFromElement(policyStartDateOrEstimatedClosingDatePlaceHolderText), EXPECTED_ESTIMATED_CLOSING_DATE_AREA_LABEL,EXPECTED_ESTIMATED_CLOSING_DATE_AREA_LABEL + " place holder text validation");
        } else {
            String expectedPolicyBeginQuestionText = "When would you like your property policy to begin?";
            fsa.assertEquals(getTextFromElement(policyStartDateOrEstimatedClosingDateTitle), expectedPolicyBeginQuestionText, expectedPolicyBeginQuestionText + " question text validation");
            fsa.assertEquals(getTextFromElement(policyStartDateOrEstimatedClosingDatePlaceHolderText), expectedPropertyPolicyStartDateHeader, expectedPropertyPolicyStartDateHeader + " place holder text validation");
        }
        fsa.assertEquals(getTextFromElement(continueButtonBundleContactInfoPage), "Continue", "Continue button text validation");
    }

    public String getPropertyPolicyStartDateOrEstimatedClosingDateValue(){
        return getElementValue(policyStartDateOrEstimatedClosingDateInputField, "HRC policy start date:").trim();
    }

    public void validateContentForEligibleOccupationButtonAndTitle(FarmersSoftAssert fsa, boolean isPrimaryApplicant) {
        fsa.assertTrue(isCurrentFormerEmployedHeaderDisplayed(isPrimaryApplicant), "Current former employed header personalInfoDiv displayed");
        fsa.assertTrue(isEligibleOccupationSavingsDisplayed(isPrimaryApplicant), "Eligible occupation savings personalInfoDiv displayed");
        fsa.assertTrue(isEligibleOccupationButtonDisplayed(isPrimaryApplicant), "Eligible occupation button personalInfoDiv displayed");
        fsa.assertTrue(isEligibleOccupationButtonTextMatching(isPrimaryApplicant), "Eligible occupation button text personalInfoDiv matching");
    }

    public void validateContentOfEligibleOccupationSideSheet(FarmersSoftAssert fsa, String landingStateCode, boolean isPrimaryApplicant) throws Exception {
        clickEligibleOccupationButton(isPrimaryApplicant);
        fsa.assertTrue(isEligibleOccupationHeaderDisplayed(), "Eligible occupation Header personalInfoDiv displayed");

        String expectedRetiredOrEmployedQuestion = "Are you currently employed or retired?";
        fsa.assertEquals(getTextFromElement(currentlyEmployedOrRetiredQuestion), expectedRetiredOrEmployedQuestion, "Currently employed or retired question text check");
        sleep(2);
        fsa.assertTrue(currentlyEmployedOrRetiredToggleButtons.size() == 2, "Currently employed or retired button size matching.");

        fsa.assertEquals(getTextFromElement(currentlyEmployedOrRetiredToggleButtonLabel.get(0)), "Employed", "Employed button label check");
        fsa.assertEquals(getTextFromElement(currentlyEmployedOrRetiredToggleButtonLabel.get(1)), "Retired", "Retired button label check");

        fsa.assertEquals(getSortedList(getListOfOccupationFromSideSheet()), AceHomeSupportedOccupationByState.valueOf(landingStateCode).getSupportedOccupation(), "List of occupations check");

        if (!List.of(CA, CT, GA, MI, TN, VA).contains(landingStateCode)){
            checkMilitaryPersonnelOccupationSubList(fsa);
        }
        if (!Objects.equals(TN, landingStateCode)) {
            fsa.assertTrue(isCloseIconAddAndCancelButtonDisplayedInOccupationSideSheet(), "Eligible occupation close icon, add and cancel button displayed");
        }
        closeSideSheetByEscKey(fsa);
    }

    public void selectOccupationRadioButtonAndValidateSelectedOccupation(FarmersSoftAssert fsa, String occupation) throws Exception {
        selectOccupationRadioButton(occupation);
        clickAddButton();
        fsa.assertTrue(isAddedOccupationDisplayed(true), "Occupation in personalInfo div");
    }

    public void validateRemoveOccupationHeaderAndQuestion(FarmersSoftAssert fsa) {
        fsa.assertTrue(isRemoveOccupationHeaderTextDisplayed(), "Remove occupation header text check");
        fsa.assertTrue(isRemoveOccupationQuestionTextDisplayed(), "Remove occupation question text check");
    }

    public void validateContentOfSpouseApplicant(FarmersSoftAssert fsa, String stateCode, String lob) throws Exception {
        fsa.assertTrue(isSpouseFirstNameInputBoxDisplayed(), "Spouse first name input box displayed");
        fsa.assertTrue(isSpouseLastNameInputBoxDisplayed(), "Spouse last name input box displayed");
        fsa.assertTrue(isSpouseDateOfBirthInputBoxDisplayed(), "Spouse date of birth input box displayed");

        // need to validate mmddyyyy hint in spouse section once it is added by dev
        fsa.assertTrue(isMMDDYYHintDisplayed(), "MMDDYYYY hint displayed");
        fsa.assertTrue(areSpouseGenderButtonsDisplayedCorrectly(stateCode, lob), "Spouse gender buttons displayed correctly");
    }

    public void validateMarriedOrInDomesticRelationCheckBoxDescription(FarmersSoftAssert fsa) {
        fsa.assertTrue(isMarriedOrSpouseCheckBoxDescriptionMatching(), "Married or in domestic relationship checkbox description check");
    }

    public void validateAboutYouSection(FarmersSoftAssert fsa, String stateCode, String lob) throws Exception {
        fsa.assertTrue(isAboutYouHeaderDisplayed(), "About you header displayed");
        fsa.assertTrue(isElementInViewport(aboutYouHeader), "About you - page title is in Viewport");
        fsa.assertTrue(arePNIGenderButtonsDisplayedCorrectly(stateCode, lob), "PNI gender buttons displayed correctly");
    }

    public void validateSpouseSectionIsDisplayed(FarmersSoftAssert fsa){
        fsa.assertEquals(isElementVisible(spouseInputFieldSection, 2), false, "Spouse element is displayed even without checking spouse checkbox.");
    }

    private void validateEligibleOccupation(ApplicantAceHome applicant, FarmersSoftAssert fsa,
                                            boolean isPrimaryApplicant) throws Exception {
        String stateCode = applicant.getStateCode();
        String occupation = applicant.getOccupation();
        // validate content of eligible occupation button, title, side sheet
        // Add occupation as per applicant, validate added occupation, remove occupation, validate content of remove occupation pop up
        if (!stateCode.equals(TN)) {
            validateContentForEligibleOccupationButtonAndTitle(fsa, isPrimaryApplicant);
            validateContentOfEligibleOccupationSideSheet(fsa, stateCode, isPrimaryApplicant);
            clickEligibleOccupationButton(isPrimaryApplicant);
            if (!applicant.getOccupation().isBlank()) {
                selectOccupationRadioButtonAndValidateSelectedOccupation(fsa, occupation);
                clickRemoveOccupationLink(isPrimaryApplicant);
                validateRemoveOccupationHeaderAndQuestion(fsa);
                clickKeepOccupationButton();
                clickRemoveOccupationLink(isPrimaryApplicant);
                clickRemoveOccupationButton();
                clickEligibleOccupationButton(isPrimaryApplicant);
                selectOccupationRadioButton(occupation);
                clickAddButton();
            }
            else{
                clickCancelButton();
            }
        } else {
            clickCloseIcon();
        }
    }

    public void validateContentOfAboutYouSection(FarmersSoftAssert fsa, ApplicantAceHome applicant, String lobType) throws Exception {

        String stateCode = applicant.getStateCode();
        validateAboutYouSection(fsa, stateCode, lobType);
        if (!isNoEligibleOccupationState(stateCode)) {
            validateEligibleOccupation(applicant, fsa, true);
        }

        // validate content in spouse section
        validateSpouseSectionIsDisplayed(fsa);
        clickOnMarriedOrInDomesticRelationCheckbox();
        validateMarriedOrInDomesticRelationCheckBoxDescription(fsa);
        validateContentOfSpouseApplicant(fsa, stateCode, lobType);
        if (!isNoEligibleOccupationState(stateCode)) {
            validateEligibleOccupation(applicant, fsa, false);
        }

        //validate occupations
        if (!applicant.getOccupation().isBlank() && !isNoEligibleOccupationState(stateCode)) {
            clickRemoveOccupationLink(true);
            clickRemoveOccupationButton();
            clickRemoveOccupationLink(false);
            clickRemoveOccupationButton();
        }
    }
}
