package com.farmers.ffq.hqm.pages;

import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.QuoteRateHQM;
import com.farmers.ffq.datatransferobjects.hqm.StaticContentHQM;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import javax.annotation.Nullable;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Quote Page - Home Quote Modernization (HQM).
 */

public class QuoteDetailsPage extends HqmBasePage {

    private static final String HURRICANE_DEDUCTIBLE_ERROR_IS_FOUND = "Hurricane deductible error is found.";
	private static final String HURRICANE_SLIDER_VALUE = "Hurricane slider value: ";
	private static final String WIND_HAIL_SLIDER_VALUE = "Wind & Hail slider value: ";
	private static final String ALL_PERIL_SLIDER_VALUE = "All peril slider value: ";
    private static final String WIND_HAIL_DEDUCTIBLE_ERROR_IS_FOUND = "Wind & Hail deductible error is found.";
    private static final String WIND_HAIL_HURRICANE_DEDUCTIBLES_ERROR_IS_FOUND = "Wind & Hail and Hurricane deductible errors are found.";
	private static final String QUOTE_DETAILS_PAGE = "Quote Details page - ";
	private static final String FOUND_PAGE_ERRORS = "Found page errors: ";
	private static final String BUILDING_ORDINANCE_OR_LAW_COVERAGE_SLIDER_SELECTED_PERCENTAGE = "Quote Details page - Building ordinance or law coverage slider selected percentage";
	private static final String SEPARATE_STRUCTURES_SLIDER_SELECTED_PERCENTAGE = "Quote Details page - Separate structures slider selected percentage";
	private static final String WATER_LOSSES = "Water Losses";
	private static final String HURRICANE_LOSSES = "Hurricane Losses";
	private static final String WIND_AND_HAIL_LOSSES = "Wind & Hail Losses";
	private static final String BUILDING_ORDINANCE_OR_LAW_COVERAGE = "Building ordinance or law coverage";
	private static final String MINE_SUBSIDENCE = "Mine subsidence";
	private static final String DWELLING = "Dwelling";

	@FindBy(xpath = "//farmers-home-quote-details-dialog//mat-icon[contains(text(),'close')]")
    private WebElement btnCloseModal;

    @FindBy(xpath = "//farmers-home-quote-details-dialog//button[contains(.,'RECALCULATE')]")
    private WebElement btnRecalculate;

    @FindBy(xpath = "//farmers-home-quote-details-dialog//button[contains(text(),'RESET')]")
    private WebElement btnReset;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Dwelling')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderDwellingDiv;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Dwelling')]" +
            "/../../div//mat-slider")
    private WebElement sliderDwelling;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Extended Replacement Cost')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderExtendedReplacementDiv;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Extended Replacement Cost')]" +
            "/../../div//mat-slider")
    private WebElement sliderExtendedReplacement;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Separate Structures')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderSeparateStructuresDiv;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Separate Structures')]" +
            "/../../div//mat-slider")
    private WebElement sliderSeparateStructures;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Property')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderPersonalPropertyDiv;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Property')]" +
            "/../../div//mat-slider")
    private WebElement sliderPersonalProperty;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Building Ordinance or Law Coverage')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderBOLDiv;

    private static final String SLIDERS_PROPERTY_COVERAGES_XPATH = "//div[h4[text()='Property coverages']]//mat-slider";
    @FindBy(xpath = SLIDERS_PROPERTY_COVERAGES_XPATH)
    private WebElement slidersPropertyCoverages;

    private static final String SLIDERS_DEDUCTIBLES_XPATH = "//div[h4[text()='Deductibles']]//mat-slider";
    @FindBy(xpath = SLIDERS_DEDUCTIBLES_XPATH)
    private WebElement slidersDeductibles;

    private static final String SLIDERS_LIABILITY_XPATH = "//div[h4[text()='Liability']]//mat-slider";
    @FindBy(xpath = SLIDERS_LIABILITY_XPATH)
    private WebElement slidersLiability;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'All Peril') or contains(text(),'All Other Peril')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderAllPerilDiv;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'All Peril') or contains(text(),'All Other Peril')]" +
            "/../../div//mat-slider")
    private WebElement sliderAllPeril;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Wind & Hail')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderWindAndHailDiv;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Wind & Hail')]" +
            "/../../div//mat-slider")
    private WebElement sliderWindAndHail;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Hurricane')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderHurricaneDiv;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Hurricane')]" +
            "/../../div//mat-slider")
    private WebElement sliderHurricane;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Water')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderWaterDiv;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Water')]" +
            "/../../div//mat-slider")
    private WebElement sliderWater;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Liability')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderPersonalLiabilityDiv;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Liability')]" +
            "/../../div//mat-slider")
    private WebElement sliderPersonalLiability;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Medical Payments to Others')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderMedicalPaymentsToOthersDiv;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Medical Payments to Others')]" +
            "/../../div//mat-slider")
    private WebElement sliderMedicalPaymentsToOthers;

    private static final String RADIOBUTTONS_MINE_SUBSIDENCE_XPATH = "//mat-radio-group[@id='mineSubsidence']";
    @FindBy(xpath = RADIOBUTTONS_MINE_SUBSIDENCE_XPATH)
    private WebElement rbtnsMineSubsidence;

    @FindBy(xpath = "//mat-radio-button[contains(@class,'mineSubsidenceYes')]//input")
    private WebElement rbtnMineSubsidenceYes;

    @FindBy(xpath = "//mat-radio-button[contains(@class,'mineSubsidenceNo')]//input")
    private WebElement rbtnMineSubsidenceNo;

    @FindBy(xpath = "//farmers-home-quote-details-dialog//div[@id='yearlyPremium']//span")
    private WebElement textYearlyPremium;

    private final String yearlyPremiumCAxPath = "//farmers-home-quote-details-dialog//div[contains(@id,'yearlyPremium')]";
    @FindBy(xpath = yearlyPremiumCAxPath)
    private WebElement textYearlyPremiumCA;

    private static final String YEARLY_XPATH = "//farmers-home-quote-details-dialog//div[@id='yearlyPremium']";

    @FindBy(xpath = YEARLY_XPATH + "/span/span")
    private WebElement textYearlyPremiumCents;

    @FindBy(xpath = YEARLY_XPATH + "/span/span/span[@aria-label='per year']")
    private WebElement textYearlyPremiumPerYear;

    private static final String PREMIUM_DISCLAIMER = "The premium shown may include a Preferred payment discount. " +
            "This discount is only available on a monthly basis, if you choose the monthly mortgagee pay plan.";

    @FindBy(xpath = YEARLY_XPATH + "/span/span/a[@aria-label='" + PREMIUM_DISCLAIMER + "']")
    private WebElement textYearlyPremiumDisclaimer;

    @FindBy(xpath = "//farmers-home-quote-details-dialog//div[contains(@class,'cost-block')]")
    private WebElement textMonthlyPremium;

    private static final String TITLE_XPATH = "//mat-dialog-container//h2[contains(@class,'header-title')]";
    @FindBy(xpath = TITLE_XPATH)
    private WebElement titleQuoteType;

    private final By textSubtitlesBy = By.xpath("//farmers-home-quote-details-dialog//h4[@role='heading']");

    private final By textSubSubtitlesBy = By.xpath("//farmers-home-quote-details-dialog//div[@class='coverage-content']" +
            "/h5[contains(@class,'title-description')]");

    private final List<String> listSubTitles = Arrays.asList("Property coverages", "Deductibles", "Liability");

    private final List<String> listSubSubTitles = Arrays.asList(DWELLING, "Extended replacement cost", "Separate structures",
            "Personal property", MINE_SUBSIDENCE, BUILDING_ORDINANCE_OR_LAW_COVERAGE, "All Peril Losses", WIND_AND_HAIL_LOSSES,
            HURRICANE_LOSSES, WATER_LOSSES, "Personal liability", "Medical payments to others");

    private final By textSubSubtitleHelpBy =
            By.xpath("//farmers-home-quote-details-dialog//div[contains(@class,'coverage-')]/*[contains(@class,'tui-caption-text')]");

    private final List<String> listSubSubTitlesHelp = Arrays.asList("This coverage can apply to many types and causes of loss, " +
                    "subject to your policy provisions, which include, but are not limited to, common exclusions such as, wear " +
                    "and tear, earth movement, earthquake, mold, flood and nuclear hazard.",
            "If selected, this coverage increases your Coverage A (Dwelling) limit up to an additional 25% or 50% of " +
                    "the Coverage A amount to repair or replace covered damage to your home, depending on which percentage option, " +
                    "if any, are available in your state for your policy form.",
            "This coverage can apply to other structures on your property (such as a detached garage or tool shed) other " +
                    "than those used for business purposes, subject to your policy provisions, in an amount that is a percentage " +
                    "of the coverage limit on your house.",
            "This coverage can help replace your possessions owned or used by an insured anywhere in the world subject " +
                    "to the policy provisions and special limits for things like jewelry, watches, furs, firearms and computers. " +
                    "For a complete list, please check with your Farmers agent.",
            "This coverage helps pay for the increased costs of repairing or replacing damage to the insured dwelling caused by " +
                    "a covered loss to comply with the building laws in effect at the time of loss or rebuilding. The limit for " +
                    "this coverage is a percentage of the Dwelling coverage limit. This is additional insurance.",
            "This covers Mine Subsidence, meaning the collapse of underground coal mines resulting in direct damage to a structure. " +
                    "It does not cover loss caused by earthquake, landslide, water seepage, volcanic eruption, or collapse of storm, " +
                    "and sewer drains.",
            "A deductible is the amount of a loss for which you're responsible. The deductible applies separately to each event of " +
                    "loss or damage.",
            "This deductible applies to all causes of loss, unless a separate deductible for a certain cause of loss is shown and selected.",
            "We pay for loss or damage when a covered loss exceeds the deductible applicable to the property. The deductible applies " +
                    "separately to each loss or damage event. This deductible specifically applies to Wind and Hail coverage.",
            "A deductible is the amount of a loss for which you're responsible. The deductible applies separately to each loss or damage event.",
            "As set forth in your policy, this coverage can pay damages an insured becomes legally obligated to pay " +
                    "because of bodily injury or property damage to others that results from an occurrence.",
            "This coverage can pay medical costs, up to the limit selected by you, for guests who are injured at your " +
                    "residence, regardless of your legal liability.");

    private static final String ERROR_WIND_HAIL = "Wind & Hail deductible should be greater than All Peril deductible.";
    private static final String ERROR_WIND_HAIL_MS = "Wind and Hail deductible should be greater than or equal to All Other deductible.";
    private static final String ERROR_HURRICANE = "Hurricane deductible should be greater than All Peril deductible.";
    private static final String ERROR_HURRICANE_CT = "Hurricane deductible should be greater than or equal to All Peril deductible.";
    private static final String ERROR_HURRICANE_MS = "Hurricane deductible should be greater than or equal to All Other deductible.";
    private static final String ERROR_WATER = "Water deductible should be greater than All Peril deductible.";
    private static final String ERROR_WIND_HAIL_HURRICANE = "Wind & Hail and Hurricane are mutually exclusive coverage terms and " +
            "could not be selected together.";

    @FindBy(xpath = "//farmers-home-quote-details-dialog//p[starts-with(@class,'coverages-info-text')]")
    private WebElement textFooterDisclaimer;

    private static final String DISCLAIMER_TEXT = "* The premium shown may include a Preferred payment discount. " +
            "This discount is only available on a monthly basis, if you choose the monthly mortgagee pay plan.";

    private static final String DISCLAIMER_TEXT_CA = "The default coverage shown is the Farmers Smart Plan Home\u00ae Standard package. " +
            "Farmers Smart Plan Home also includes an Enhanced homeowners package, with greater default features. Also available is " +
            "Farmers Next Generation\u00ae homeowners policy, which may include additional coverages or higher limits than Farmers " +
            "Smart Plan Home, and possibly lower premium. Please contact a Farmers\u00ae agent for more information.";

    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
    private final NumberFormat percentFormat = NumberFormat.getPercentInstance(Locale.US);

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public QuoteDetailsPage() throws Exception {
        super();
        try {
            waitElementBeVisible(titleQuoteType);
        } catch (Exception e) {
            Log.error(e.getMessage());
        } finally {
            try {
                driver().findElement(By.xpath(SURVEY_POPUP_XPATH));
                waitAndClickElement(closeSurveyButton);
            } catch (NoSuchElementException ignored) {}
        }
    }

    private static final String SURVEY_POPUP_XPATH = "//div[contains(@class,'PopOverContainer')]//img[contains(@src,'svg-close-btn-black')]";
    @FindBy(xpath = SURVEY_POPUP_XPATH)
    private WebElement closeSurveyButton;

    public String getTitleQuoteType() {
        return getTextFromElement(waitElementBeVisible(titleQuoteType));
    }

    public String getMonthlyPremium() {
        waitElementBeVisible(textMonthlyPremium);
        String[] value = getTextFromElement(textMonthlyPremium).split(NEWLINE);
        return value[0] + value[1] + value[2];
    }

    public boolean isMonthlyPremiumCrossed() {
        boolean styleCrossed = false;
        List<WebElement> childWE = textMonthlyPremium.findElements(By.xpath("small"));
        if (!childWE.isEmpty()) {
            styleCrossed = getAttributeData(childWE.get(0), CLASS).contains("strike-line");
        }
        return styleCrossed;
    }

    public String getYearlyPremium(String stateCode) {
        String premium;
        if (!isHqmDigitalMonetizationState(stateCode)) {
            waitElementBeVisible(textYearlyPremium);
            premium = getTextFromElement(textYearlyPremium).split("/")[0].replace(SPACE, EMPTY_STRING);
        } else {
            waitElementBeVisible(textYearlyPremiumCA);
            premium = getTextFromElement(textYearlyPremiumCA);
        }
        return premium;
    }

    public boolean isYearlyPremiumCrossed(String stateCode) throws Exception {
        boolean bCrossed = false;
        if (!isHqmDigitalMonetizationState(stateCode)) {
            bCrossed = getAttributeData(textYearlyPremium, CLASS).contains("overline-crossed");
        } else {
            if (isElementPresent(By.xpath(yearlyPremiumCAxPath + "//small"))) {
                bCrossed = getAttributeData(textYearlyPremiumCA.findElement(By.xpath("//small")), CLASS).contains("strike-line");
            }
        }
        return bCrossed;
    }

    public List<String> getSubTitles() throws Exception {
        return driver().findElements(textSubtitlesBy).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
    }

    public List<String> getSubSubTitles() throws Exception {
        return driver().findElements(textSubSubtitlesBy).stream()
                .map(we -> getAttributeData(we, "innerText")).map(String::trim).collect(Collectors.toList());
    }

    public List<String> getSubSubTitlesHelp() throws Exception {
        List<WebElement> weHelpText = driver().findElements(textSubSubtitleHelpBy);
        scrollToElement(weHelpText.get(weHelpText.size() - 1));
        return driver().findElements(textSubSubtitleHelpBy).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
    }

    public void moveSlider(WebElement slider, int moves) {
        Keys arrow = (moves > 0) ? Keys.ARROW_RIGHT : Keys.ARROW_LEFT;
        moves = Math.abs(moves);
        WebElement sliderThumb = slider.findElement(By.xpath("../p[text()='MIN']"));
        scrollToElement(sliderThumb);
        sleep(1);
        for (int i = 0; i < moves; i++) {
            sendKeysToElement(slider, arrow);
            sleep(1);
        }
    }

    public void moveSliderToValue(WebElement slider, WebElement sliderDiv, String value, boolean bRight) throws Exception {
        for (int i = 0; i < 10; i++) {
            String sliderVal = getTextFromElement(sliderDiv).split(NEWLINE)[0];
            sliderVal = sliderVal.split(SPACE)[sliderVal.split(SPACE).length - 1];
            Log.info("Slider value before move: " + sliderVal);
            if (!sliderVal.equals(value)) {
                if (bRight) {
                    this.moveSlider(slider, 1);
                } else {
                    this.moveSlider(slider, -1);
                }
                sliderVal = getTextFromElement(sliderDiv).split(NEWLINE)[0];
                sliderVal = sliderVal.split(SPACE)[sliderVal.split(SPACE).length - 1];
                Log.info("Slider value after move: " + sliderVal);
            }
            if (sliderVal.equals(value)) {
                break;
            }
        }
    }

    public String getSliderDwelling() {
        String text = getTextFromElement(sliderDwellingDiv);
        return text.split(NEWLINE)[0];
    }

    public String getSliderDwellingPercent() {
        String text = getTextFromElement(sliderDwellingDiv);
        return text.split(NEWLINE)[0].substring(13);
    }

    public String getSliderDwellingValue() {
        String text = getTextFromElement(sliderDwellingDiv);
        return text.split(NEWLINE)[1];
    }

    public void setSliderDwelling(int moves) throws Exception {
        moveSlider(sliderDwellingDiv, moves);
    }

    public String getSliderExtendedReplacement() throws Exception {
        scrollToElement(sliderExtendedReplacementDiv);
        String text = getTextFromElement(sliderExtendedReplacementDiv);
        return text.split(NEWLINE)[0];
    }

    public String getSliderExtendedReplacementPercent() throws Exception {
        scrollToElement(sliderExtendedReplacementDiv);
        String text = getTextFromElement(sliderExtendedReplacementDiv);
        return text.split(NEWLINE)[0].substring(13);
    }

    public void setSliderExtendedReplacement(int moves) throws Exception {
        moveSlider(sliderExtendedReplacement, moves);
    }

    public String getSliderSeparateStructures() {
        String text = getTextFromElement(sliderSeparateStructuresDiv);
        return text.split(NEWLINE)[0];
    }

    public String getSliderSeparateStructuresPercent() {
        String text = getTextFromElement(sliderSeparateStructuresDiv);
        return text.split(NEWLINE)[0].substring(13);
    }

    public String getSliderSeparateStructuresValue() {
        String text = getTextFromElement(sliderSeparateStructuresDiv);
        return text.split(NEWLINE)[1];
    }

    public String getSliderPersonalProperty() {
        String text = getTextFromElement(sliderPersonalPropertyDiv);
        return text.split(NEWLINE)[0];
    }

    public String getSliderPersonalPropertyPercent() {
        String text = getTextFromElement(sliderPersonalPropertyDiv);
        return text.split(NEWLINE)[0].substring(13);
    }

    public String getSliderPersonalPropertyValue() {
        String text = getTextFromElement(sliderPersonalPropertyDiv);
        return text.split(NEWLINE)[1];
    }

    public void setSliderPersonalProperty(int moves) throws Exception {
        moveSlider(sliderPersonalProperty, moves);
    }

    public String getSliderBOL() {
        String text = getTextFromElement(sliderBOLDiv);
        return text.split(NEWLINE)[0];
    }

    public String getSliderBOLPercent() {
        String text = getTextFromElement(sliderBOLDiv);
        return text.split(NEWLINE)[0].substring(13);
    }

    public String getSliderBOLValue() {
        String text = getTextFromElement(sliderBOLDiv);
        return text.split(NEWLINE)[1];
    }

    public String getSliderAllPeril() {
        String text = getTextFromElement(sliderAllPerilDiv);
        return text.split(NEWLINE)[0];
    }

    public void setSliderAllPeril(int moves) throws Exception {
        moveSlider(sliderAllPeril, moves);
    }

    public String getSliderAllPerilValue() {
        String text = getTextFromElement(sliderAllPerilDiv);
        return text.split(NEWLINE)[0].substring(11);
    }

    public boolean isSliderWindAndHailAvailable() throws Exception {
        return checkIfElementIsDisplayed(sliderWindAndHailDiv, 2);
    }

    public String getSliderWindAndHail() {
        String text = getTextFromElement(sliderWindAndHailDiv);
        return text.split(NEWLINE)[0];
    }

    public String getSliderWindAndHailValue() {
        String text = getTextFromElement(sliderWindAndHailDiv);
        return text.split(NEWLINE)[0].substring(11);
    }

    private boolean isWindAndHailState(String stateCode) {
        return Arrays.asList(VA, MI, AR, SD, ND, MT, AL, KY, AZ, MS, MA, LA, NV, MO, CO, IN, KS, MD, MN, OH, OK, PA, TX,
                WA, IL, UT, IA, NC, ID, OR, NM, WI, TN, NE, WY, GA).contains(stateCode);
    }

    private boolean isHurricaneState(String stateCode) {
        return Arrays.asList(AL, CT, GA, MS, MA, LA, MD, PA, TX, TN, VA).contains(stateCode);
    }

    private boolean isWaterDeductibleState(String stateCode) {
        return Objects.equals(CA, stateCode);
    }

    private boolean isBOLState(String stateCode) {
        return Objects.equals(CA, stateCode);
    }

    public boolean isSliderHurricaneAvailable() throws Exception {
        return checkIfElementIsDisplayed(sliderHurricaneDiv, 2);
    }

    public String getSliderHurricane() {
        String text = getTextFromElement(sliderHurricaneDiv);
        return text.split(NEWLINE)[0];
    }

    public String getSliderHurricaneValue() {
        String text = getTextFromElement(sliderHurricaneDiv);
        return text.split(NEWLINE)[0].substring(11);
    }


    public String getSliderWaterValue() {
        String text = getTextFromElement(sliderWaterDiv);
        return text.split(NEWLINE)[0].substring(11);
    }

    public boolean isSliderWaterAvailable() throws Exception {
        return checkIfElementIsDisplayed(sliderWaterDiv, 2);
    }

    public String getSliderWater() {
        String text = getTextFromElement(sliderWaterDiv);
        return text.split(NEWLINE)[0];
    }

    public void setSliderWindAndHail(int moves) throws Exception {
        waitElementBeVisible(sliderWindAndHailDiv);
        moveSlider(sliderWindAndHail, moves);
    }

    public String getSliderWindAndHailMin() {
        String minVal = getAttributeData(sliderWindAndHailDiv, ARIA_LABEL);
        minVal = minVal.replace("min value is ", "").split(SPACE)[0];
        minVal = minVal.endsWith(",") ? minVal.substring(0, minVal.length() - 1) : minVal;
        return minVal;
    }

    public String getSliderWindAndHailMax() {
        String maxVal = getAttributeData(sliderWindAndHailDiv, ARIA_LABEL);
        maxVal = maxVal.substring(maxVal.indexOf("max value is ") + 14).split(SPACE)[0];
        maxVal = maxVal.endsWith(",") ? maxVal.substring(0, maxVal.length() - 1) : maxVal;
        return maxVal;
    }

    public String getSliderWindAndHailSelected() {
        String maxVal = getAttributeData(sliderWindAndHailDiv, ARIA_LABEL);
        maxVal = maxVal.substring(maxVal.indexOf("selected value is") + 18).split(SPACE)[1];
        return maxVal;
    }

    public String getSliderPersonalLiability() {
        String text = getTextFromElement(sliderPersonalLiabilityDiv);
        return text.split(NEWLINE)[0];
    }

    public String getSliderPersonalLiabilityValue() {
        String text = getTextFromElement(sliderPersonalLiabilityDiv);
        return text.split(NEWLINE)[0].substring(14);
    }

    public void setSliderPersonalLiability(int moves) throws Exception {
        moveSlider(sliderPersonalLiability, moves);
    }

    public String getSliderMedicalPaymentsToOthers() {
        String text = getTextFromElement(sliderMedicalPaymentsToOthersDiv);
        return text.split(NEWLINE)[0];
    }

    public String getSliderMedicalPaymentsToOthersValue() {
        String text = getTextFromElement(sliderMedicalPaymentsToOthersDiv);
        return text.split(NEWLINE)[0].substring(14);
    }

    public List<WebElement> getAllSliders() throws Exception {
        List<WebElement> slidersAll = new ArrayList<>();
        slidersAll.addAll(driver().findElements(By.xpath(SLIDERS_PROPERTY_COVERAGES_XPATH)));
        slidersAll.addAll(driver().findElements(By.xpath(SLIDERS_DEDUCTIBLES_XPATH)));
        slidersAll.addAll(driver().findElements(By.xpath(SLIDERS_LIABILITY_XPATH)));
        return slidersAll;
    }

    public void setSliderMedicalPaymentsToOthers(int moves) throws Exception {
        moveSlider(sliderMedicalPaymentsToOthers, moves);
    }

    public void clickCloseModal() {
        try {
            waitAndClickElement(btnCloseModal);
        } catch (ElementClickInterceptedException e) {
            this.sendKeysToElement(titleQuoteType, Keys.ESCAPE);
        }
        sleep(1);
    }

    public void clickRecalculate() throws Exception {
        waitAndClickElement(btnRecalculate);
        driverWait(Property.PAGELOADTIMEOUT).until(ExpectedConditions.textToBe(By.xpath(TITLE_XPATH), "Standard Custom"));
        waitForSpinnerToBeGone();
        waitForPageToBeReady();
    }

    public void clickReset() throws Exception {
        waitAndClickElement(btnReset);
        driverWait(Property.PAGELOADTIMEOUT).until(ExpectedConditions.textToBe(By.xpath(TITLE_XPATH), "Standard"));
        waitForSpinnerToBeGone();
        waitForPageToBeReady();
    }

    public void verifyPremiums(ApplicantHQM applicant, FarmersSoftAssert fsa,
    		@Nullable QuoteRateHQM quoteRate, @Nullable Double quoteDelta, @Nullable String quotePremiumYearly) throws ParseException {
        // validate monthly and yearly premiums
        String monthlyPremiumQuoteDetails = this.getMonthlyPremium();
        double dMonthlyQuoteDetails = NumberFormat.getCurrencyInstance(Locale.US).parse(monthlyPremiumQuoteDetails).doubleValue();
        String yearlyPremiumQuoteDetails = this.getYearlyPremium(applicant.stateCode);
        Double dYearlyQuoteDetails = NumberFormat.getCurrencyInstance(Locale.US).parse(yearlyPremiumQuoteDetails).doubleValue();
        if (quoteRate != null) {
            if (!isHqmDigitalMonetizationState(applicant.stateCode)) {
                fsa.assertEquals(dMonthlyQuoteDetails, Double.parseDouble(quoteRate.getMonthlyPremium()),
                        "Quote Details page - Monthly Premium validation vs. Postgres value.");
            }
            fsa.assertEquals(dYearlyQuoteDetails, Double.parseDouble(quoteRate.getYearlyPremium()),
                    "Quote Details page - Yearly Premium validation vs. Postgres value.");
        } else if ((quoteDelta != null) && (quotePremiumYearly != null)) {
            fsa.assertEquals(dMonthlyQuoteDetails, Double.parseDouble(applicant.quoteRate),
                    Double.parseDouble(applicant.quoteRate) * quoteDelta,
                    "Quote Details page - Monthly Premium validation vs. datasource saved value.");
            fsa.assertEquals(yearlyPremiumQuoteDetails, quotePremiumYearly,
                    "Quote Details page - Yearly Premium validation vs. Quote page value.");
        }
    }

    public void validatePageTitlesSubtitles(ApplicantHQM applicant, FarmersSoftAssert fsa,
    		@Nullable QuoteRateHQM quoteRate, double quoteDelta, String quotePremiumYearly, @Nullable StaticContentHQM staticContent) throws Exception {
        String packageType = (quoteRate != null) ? quoteRate.getPackageType().get(0).getPackageTypeDescription() : "Standard";
        fsa.assertEquals(this.getTitleQuoteType().replaceAll(SPACE, ""), packageType, "Quote Details page - Quote Type title");

        this.verifyPremiums(applicant, fsa, quoteRate, quoteDelta, quotePremiumYearly);

        // validate page titles, subtitles and sub-subtitles
        List<String> subTitles = this.getSubTitles();
        Log.info("Found Quote Details page subtitles:" + subTitles);
        fsa.assertEquals(subTitles, listSubTitles, "Quote Details page - Quote subtitles");
        List<String> subSubTitles = this.getSubSubTitles();
        Log.info("Found Quote Details page sub-subtitles:" + subSubTitles);
        List<String> subSubTitlesList = new ArrayList<>(listSubSubTitles);
        if (Arrays.asList(MS, MA, LA, TX, NC).contains(applicant.stateCode)) {
            subSubTitlesList.set(subSubTitlesList.indexOf("All Peril Losses"), "All Other Peril Losses");
        }
        if (!isHurricaneState(applicant.stateCode)) {
            subSubTitlesList.remove(HURRICANE_LOSSES);
        }
        if (!isWindAndHailState(applicant.stateCode)) {
            subSubTitlesList.remove(WIND_AND_HAIL_LOSSES);
        }
        if (!isBOLState(applicant.stateCode)) {
            subSubTitlesList.remove(BUILDING_ORDINANCE_OR_LAW_COVERAGE);
        }
        if (!isWaterDeductibleState(applicant.stateCode)) {
            subSubTitlesList.remove(WATER_LOSSES);
        }
        if (applicant.stateCode.equals(KY)) {
            if (((quoteRate != null) && (quoteRate.getCoverageAmount("Mine Subsidence") == null)) ||
                    ((quoteRate == null) && (this.getMineSubsidence() == null))) {
                subSubTitlesList.remove(MINE_SUBSIDENCE);
            }
        } else {
            subSubTitlesList.remove(MINE_SUBSIDENCE);
        }
        fsa.assertEquals(subSubTitles, subSubTitlesList, "Quote Details page - Quote sub-subtitles");
        subSubTitlesList.remove(MINE_SUBSIDENCE);
        fsa.assertEquals(getAllSliders().size(), subSubTitlesList.size(),
                "Quote Details page - All Captions need to have sliders (except Mine subsidence).");

        List<String> subSubTitlesHelpList = new ArrayList<>(listSubSubTitlesHelp);
        if (!subSubTitles.contains(WIND_AND_HAIL_LOSSES)) {
            subSubTitlesHelpList.remove("We pay for loss or damage when a covered loss exceeds the deductible applicable " +
                    "to the property. The deductible applies separately to each loss or damage event. This deductible " +
                    "specifically applies to Wind and Hail coverage.");
        }
        if (!subSubTitles.contains(HURRICANE_LOSSES) && !subSubTitles.contains(WATER_LOSSES)) {
            subSubTitlesHelpList.remove("A deductible is the amount of a loss for which you're responsible. The deductible " +
                    "applies separately to each loss or damage event.");
        }
        if (!subSubTitles.contains(MINE_SUBSIDENCE)) {
            subSubTitlesHelpList.remove("This covers Mine Subsidence, meaning the collapse of underground coal mines resulting " +
                    "in direct damage to a structure. It does not cover loss caused by earthquake, landslide, water seepage, " +
                    "volcanic eruption, or collapse of storm, and sewer drains.");
        }
        if (!subSubTitles.contains(BUILDING_ORDINANCE_OR_LAW_COVERAGE)) {
            subSubTitlesHelpList.remove("This coverage helps pay for the increased costs of repairing or replacing damage to the insured " +
                    "dwelling caused by a covered loss to comply with the building laws in effect at the time of loss or rebuilding. " +
                    "The limit for this coverage is a percentage of the Dwelling coverage limit. This is additional insurance.");
        }
        if (applicant.stateCode.equals(NC)) {
            String additionalHelpText = " Loss settlement is based on Replacement Cost.";
            String separateStructuresHelp = "This coverage can apply to other structures on your property (such as a detached garage " +
                    "or tool shed) other than those used for business purposes, subject to your policy provisions, in an amount that is " +
                    "a percentage of the coverage limit on your house.";
            String personalPropertyHelp = "This coverage can help replace your possessions owned or used by an insured anywhere in the " +
                    "world subject to the policy provisions and special limits for things like jewelry, watches, furs, firearms and " +
                    "computers. For a complete list, please check with your Farmers agent.";
            subSubTitlesHelpList.set(subSubTitlesHelpList.indexOf(separateStructuresHelp), separateStructuresHelp + additionalHelpText);
            subSubTitlesHelpList.set(subSubTitlesHelpList.indexOf(personalPropertyHelp), personalPropertyHelp + additionalHelpText);
        }
        if (Arrays.asList(MS, NC).contains(applicant.stateCode)){
            String standardWnHText = "We pay for loss or damage when a covered loss exceeds the deductible applicable to the property. " +
                    "The deductible applies separately to each loss or damage event. This deductible specifically applies to Wind and Hail coverage.";
            String specificWnHText = "We pay for loss or damage when a covered loss exceeds the deductible applicable to the property. " +
                    "The deductible applies separately to each loss or damage event. This deductible specifically applies to Wind and Hail coverage. " +
                    "Wind and Hail Exclusion endorsement may be required.";
            subSubTitlesHelpList.set(subSubTitlesHelpList.indexOf(standardWnHText), specificWnHText);
        }
//        if (applicant.stateCode.equals(TN)) {
//            String personalPropertyHelp = "This coverage can help replace your possessions owned or used by an insured anywhere in " +
//                    "the world subject to the policy provisions and special limits for things like jewelry, watches, furs, firearms " +
//                    "and computers. For a complete list, please check with your Farmers agent.";
//            String personalPropertyHelpTN = "This coverage can help replace possessions owned or used by an insured anywhere in the " +
//                    "world subject to the policy provisions and special limits for things like jewelry, watches, furs, firearms and " +
//                    "computers. For a complete list, please check with a Farmers\u00ae representative. Your quote includes Broad Named " +
//                    "Perils coverage for personal property, which only provides coverage for those causes of loss identified in the " +
//                    "endorsement. Farmers also offers open peril coverage, which provides coverage for all causes of loss not " +
//                    "specifically excluded in the policy. For additional details on these options, please contact a Farmers\u00ae " +
//                    "representative prior to purchase.";
//            subSubTitlesHelpList.set(subSubTitlesHelpList.indexOf(personalPropertyHelp), personalPropertyHelpTN);
//        }
        fsa.assertEquals(this.getSubSubTitlesHelp(), subSubTitlesHelpList, "Quote Details page - Quote sub-subtitles Help text.");
        String disclaimers = applicant.stateCode.equals(CA) ? DISCLAIMER_TEXT_CA : DISCLAIMER_TEXT;
        fsa.assertEquals(getTextFromElement(textFooterDisclaimer), disclaimers, "Quote Details page - Expected footer disclaimer text.");
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getCoverageValuesDisclaimer(), disclaimers,
                    "Quote Details page - Expected footer disclaimer text (AEM).");
            List<String> coverageDescriptions = new ArrayList<>();
            coverageDescriptions.add(staticContent.getCoverageValuesDwelling());
            coverageDescriptions.add(staticContent.getCoverageValuesExtendedReplacementCost());
            coverageDescriptions.add(staticContent.getCoverageValuesSeparateStructures());
            coverageDescriptions.add(staticContent.getCoverageValuesPersonalProperty());
            if ((staticContent.getCoverageValuesMineSubsidence() != null) && subSubTitles.contains(MINE_SUBSIDENCE)) {
                coverageDescriptions.add(staticContent.getCoverageValuesMineSubsidence());
            }
            if (staticContent.getCoverageValuesBOL() != null) {
                coverageDescriptions.add(staticContent.getCoverageValuesBOL());
            }
            coverageDescriptions.add(staticContent.getDeductibleAllPeril());
            if (staticContent.getDeductibleWindHail() != null) {
                coverageDescriptions.add(staticContent.getDeductibleWindHail());
            }
            if ((staticContent.getDeductibleHurricane() != null) && subSubTitles.contains(HURRICANE_LOSSES)) {
                coverageDescriptions.add(staticContent.getDeductibleHurricane());
            }
            if (staticContent.getDeductibleWater() != null) {
                coverageDescriptions.add(staticContent.getDeductibleWater());
            }
            coverageDescriptions.add(staticContent.getCoverageValuesPersonalLiability());
            coverageDescriptions.add(staticContent.getCoverageValuesMedicalPayments());
            System.out.println();
            System.out.println(">> AEM sub sub-titles Help text: ");
            System.out.println(coverageDescriptions);
            System.out.println(">> Expected sub sub-titles Help text: ");
            String deductiblesDesc = "A deductible is the amount of a loss for which you're responsible. The deductible applies " +
                    "separately to each event of loss or damage.";
            subSubTitlesHelpList.remove(deductiblesDesc);
            System.out.println(subSubTitlesHelpList);
            if (applicant.stateCode.equals(NC)) {
                String separateStructuresHelp = "This coverage can apply to other structures on your property (such as a detached garage " +
                        "or tool shed) other than those used for business purposes, subject to your policy provisions, in an amount that is " +
                        "a percentage of the coverage limit on your house. Loss settlement is based on Replacement Cost.";
                String personalPropertyHelp = "This coverage can help replace your possessions owned or used by an insured anywhere in the " +
                        "world subject to the policy provisions and special limits for things like jewelry, watches, furs, firearms and " +
                        "computers. For a complete list, please check with your Farmers agent. Loss settlement is based on Replacement Cost.";
                int ind1 = subSubTitlesHelpList.indexOf(separateStructuresHelp);
                subSubTitlesHelpList.remove(ind1);
                subSubTitlesHelpList.add(ind1, separateStructuresHelp.replace(". Loss settlement", ".\\nLoss settlement"));
                int ind2 = subSubTitlesHelpList.indexOf(personalPropertyHelp);
                subSubTitlesHelpList.remove(ind2);
                subSubTitlesHelpList.add(ind2, personalPropertyHelp.replace(". Loss settlement", ".\\nLoss settlement"));
            }
            fsa.assertEquals(coverageDescriptions, subSubTitlesHelpList, "Quote Details page - Quote sub-subtitles Help text (AEM).");
        }
    }

    public String getMineSubsidence() throws Exception {
        String sMineSubsidence = null;
        if (isElementDisplayed(By.xpath(RADIOBUTTONS_MINE_SUBSIDENCE_XPATH))) {
            if (rbtnMineSubsidenceYes.isSelected()) {
                sMineSubsidence = "Yes";
            } else if (rbtnMineSubsidenceNo.isSelected()) {
                sMineSubsidence = "No";
            }
        }
        return sMineSubsidence;
    }

    public void validateCoverageSliders(ApplicantHQM applicant, QuoteRateHQM quoteRate, String reconstructionCost, FarmersSoftAssert fsa) throws Exception {
        String coveredUpTo = "Covered up to";
        currencyFormat.setMaximumFractionDigits(0);
        double dReconstructionCost;
        String sMineSubsidence;
        if (quoteRate == null) {
            dReconstructionCost = currencyFormat.parse(reconstructionCost).doubleValue();
            sMineSubsidence = this.getMineSubsidence();
        } else {
            dReconstructionCost = Double.parseDouble(quoteRate.getReconstructionCost());
            sMineSubsidence = quoteRate.getCoverageAmount("Mine Subsidence");
        }
        // Coverages
        Log.info("Property coverages::");

        // Dwelling
        Log.info("Dwelling: " + this.getSliderDwelling());
        fsa.assertTrue(this.getSliderDwelling().startsWith(coveredUpTo), "Quote Details page - Dwelling slider start text");
        if (quoteRate != null) {
            Double dDwellingPercent = Double.parseDouble(quoteRate.getCoverageAmount(DWELLING)) /
                    Double.parseDouble(quoteRate.getReconstructionCost());
            fsa.assertEquals(this.getSliderDwellingPercent(), percentFormat.format(dDwellingPercent),
                    "Quote Details page - Dwelling slider selected value vs. Postgres");
            Double dDwellingCoverage = Double.parseDouble(quoteRate.getCoverageAmount(DWELLING));
            fsa.assertEquals(this.getSliderDwellingValue(), currencyFormat.format(dDwellingCoverage),
                    "Quote Details page - Dwelling slider selected value vs. Postgres");
        } else {
            fsa.assertEquals(this.getSliderDwellingPercent(), "100%", "Quote Details page - Dwelling slider selected percentage");
            fsa.assertEquals(this.getSliderDwellingValue(), reconstructionCost,
                    "Quote Details page - Dwelling slider selected value vs. Quote page subtitle");
        }

        // Extended replacement cost
        Log.info("Extended Replacement Cost: " + this.getSliderExtendedReplacement());
        fsa.assertTrue(this.getSliderExtendedReplacement().startsWith(coveredUpTo),
                "Quote Details page - Extended replacement cost slider start text");
        String extendedReplacementPercent = this.getSliderExtendedReplacementPercent();
        if (quoteRate != null) {
            String extendedPercent = (quoteRate.getCoverageAmount("Extended Replacement Cost") == null) ? NONE :
                    quoteRate.getCoverageAmount("Extended Replacement Cost") + "%";
            fsa.assertEquals(extendedReplacementPercent, extendedPercent,
                    "Quote Details page - Extended replacement cost slider selected percentage");
        } else {
            fsa.assertEquals(extendedReplacementPercent, NONE,
                    "Quote Details page - Extended replacement cost slider selected percentage");
        }

        // Separate Structures
        Log.info("Separate structures: " + this.getSliderSeparateStructures());
        fsa.assertTrue(this.getSliderSeparateStructures().startsWith(coveredUpTo),
                "Quote Details page - Separate structures slider start text");
        String separateStructuresPercent = this.getSliderSeparateStructuresPercent();
        if (quoteRate != null) {
            fsa.assertEquals(separateStructuresPercent, quoteRate.getCoverageAmount("Separate Structures") + "%",
                    SEPARATE_STRUCTURES_SLIDER_SELECTED_PERCENTAGE);
        } else {
            String percent = (!applicant.stateCode.equals(CT)) ? "5%" : "10%";
            fsa.assertEquals(separateStructuresPercent, percent,
                    SEPARATE_STRUCTURES_SLIDER_SELECTED_PERCENTAGE);
        }
        double dSeparateStructures = percentFormat.parse(separateStructuresPercent).doubleValue();
        if (quoteRate != null) {
            double dDwellingCoverage = Double.parseDouble(quoteRate.getCoverageAmount(DWELLING));
            String separateStructuresValue = currencyFormat.format(dDwellingCoverage * dSeparateStructures);
            fsa.assertEquals(this.getSliderSeparateStructuresValue(), separateStructuresValue,
                    "Quote Details page - Separate structures slider selected value as percent of reconstruction cost");
            fsa.assertEquals(separateStructuresPercent, quoteRate.getCoverageAmount("Separate Structures") + "%",
                    SEPARATE_STRUCTURES_SLIDER_SELECTED_PERCENTAGE);
        } else {
            String percent = (!applicant.stateCode.equals(CT)) ? "5%" : "10%";
            fsa.assertEquals(separateStructuresPercent, percent,
                    SEPARATE_STRUCTURES_SLIDER_SELECTED_PERCENTAGE);
        }

        // Personal property
        String personalProperty = this.getSliderPersonalProperty();
        Log.info("Personal Property: " + personalProperty);
        fsa.assertTrue(personalProperty.startsWith(coveredUpTo), "Quote Details page - Personal property slider start text");
        String personalPropertyPercent = this.getSliderPersonalPropertyPercent();
        double dPersonalPropertyPercent = percentFormat.parse(personalPropertyPercent).doubleValue();
        if (quoteRate != null) {
            fsa.assertEquals(personalPropertyPercent, quoteRate.getCoverageAmount("Personal Property") + "%",
                    "Quote Details page - Personal property slider selected percentage vs. Postgres");
            Double dPersonalPropertyValue = Double.parseDouble(quoteRate.getCoverageAmount(DWELLING)) * dPersonalPropertyPercent;
            String personalPropertyValue = currencyFormat.format(dPersonalPropertyValue);
            fsa.assertEquals(this.getSliderPersonalPropertyValue(), personalPropertyValue,
                    "Quote Details page - Personal Property slider selected value as percent of reconstruction cost");
        } else {
            String percent;
            if (!applicant.stateCode.equals(CT)) {
                percent = "40%";
            } else {
                percent = "50%";
            }
            fsa.assertEquals(personalPropertyPercent, percent,
                    "Quote Details page - Personal property slider selected percentage vs. pre-defined");
            Double dPersonalPropertyValue = dReconstructionCost * dPersonalPropertyPercent;
            String personalPropertyValue = currencyFormat.format(dPersonalPropertyValue);
            fsa.assertEquals(this.getSliderPersonalPropertyValue(), personalPropertyValue,
                    "Quote Details page - Personal Property slider selected value as percent of reconstruction cost");
        }
        // Mine Subsidence
        if (applicant.stateCode.equals(KY)  && sMineSubsidence != null) {
        	fsa.assertEquals(this.getMineSubsidence(), sMineSubsidence, "Quote Details page - Mine Subsidence correct radio button selected.");
        }
        // Building ordinance or law coverage (BOL)
        if (isBOLState(applicant.stateCode)) {
            Log.info("BOL: " + this.getSliderBOL());
            fsa.assertTrue(this.getSliderBOL().startsWith(coveredUpTo),
                    "Quote Details page - Building ordinance or law coverage slider start text");
            String bolPercent = this.getSliderBOLPercent();
            if (quoteRate != null) {
                fsa.assertEquals(bolPercent, quoteRate.getCoverageAmount("Building Ordinance or Law Coverage") + "%",
                        BUILDING_ORDINANCE_OR_LAW_COVERAGE_SLIDER_SELECTED_PERCENTAGE);
            } else {
                String percent = "10%";
                fsa.assertEquals(bolPercent, percent,
                        BUILDING_ORDINANCE_OR_LAW_COVERAGE_SLIDER_SELECTED_PERCENTAGE);
            }
            double dBOL = percentFormat.parse(bolPercent).doubleValue();
            if (quoteRate != null) {
                double dDwellingCoverage = Double.parseDouble(quoteRate.getCoverageAmount(DWELLING));
                String bolValue = currencyFormat.format(dDwellingCoverage * dBOL);
                fsa.assertEquals(this.getSliderBOLValue(), bolValue,
                        "Quote Details page - Building ordinance or law coverage slider selected value as percent of reconstruction cost");
                fsa.assertEquals(bolPercent, quoteRate.getCoverageAmount("Building Ordinance or Law Coverage") + "%",
                        BUILDING_ORDINANCE_OR_LAW_COVERAGE_SLIDER_SELECTED_PERCENTAGE);
            } else {
                String percent = "10%";
                fsa.assertEquals(bolPercent, percent,
                        SEPARATE_STRUCTURES_SLIDER_SELECTED_PERCENTAGE);
            }
        }
    }

    public void validateDeductibleSliders(ApplicantHQM applicant, QuoteRateHQM quoteRate, FarmersSoftAssert fsa) {
        String deductible = "Deductible";
        // Deductibles
        Log.info("Deductibles::");
        // All peril
        String sliderAP = this.getSliderAllPeril();
        String sliderAPValue = this.getSliderAllPerilValue();
        Log.info("All peril deductible: " + sliderAP);
        fsa.assertTrue(sliderAP.startsWith(deductible), "Quote Details page - All Peril slider start text");
        if (quoteRate == null) {
            fsa.assertFalse(sliderAPValue.isEmpty(), "Quote Details page - All Peril slider value not empty");
        } else {
            String sliderAPdb = quoteRate.getDeductibleValue("All Peril", applicant.stateCode);
            fsa.assertEquals(Double.parseDouble(sliderAPValue.replace("%", "").replace("$", "")),
                    Double.parseDouble(sliderAPdb.replace("%", "").replace("$", "")),
                    "Quote Details page - All Peril slider value vs. Postgres");
        }
        // Wind & Hail
        if (quoteRate == null) {
            if (isWindAndHailState(applicant.stateCode)) {
                String sliderWnH = this.getSliderWindAndHail();
                String sliderWnHValue = this.getSliderWindAndHailValue();
                Log.info("Wind & Hail deductible: " + sliderWnH);
                fsa.assertTrue(sliderWnH.startsWith(deductible), "Quote Details page - Wind & Hail slider start text");
                fsa.assertFalse(sliderWnHValue.isEmpty(), "Quote Details page - Wind & Hail slider value not empty");
            }
        } else {
            if (isWindAndHailState(applicant.stateCode)) {
                String sliderWnH = this.getSliderWindAndHail();
                String sliderWnHValue = this.getSliderWindAndHailValue();
                String sliderWnHdb = quoteRate.getDeductibleValue("Wind & Hail", applicant.stateCode);
                Log.info("Wind & Hail deductible: " + sliderWnH);
                fsa.assertTrue(sliderWnH.startsWith(deductible), "Quote Details page - Wind & Hail slider start text");
                if (sliderWnHdb != null) {
                    fsa.assertEquals(Double.parseDouble(sliderWnHValue.replace("%", "").replace("$", "")),
                            Double.parseDouble(sliderWnHdb.replace("%", "").replace("$", "")),
                            "Quote Details page - Wind & Hail slider value vs. Postgres");
                } else {
                    fsa.assertTrue(sliderWnHValue.startsWith(NONE), "Quote Details page - Wind & Hail slider value is None");
                }
            }
        }
        // Hurricane
        if (quoteRate == null) {
            if (isHurricaneState(applicant.stateCode)) {
                String sliderH = this.getSliderHurricane();
                String sliderHValue = this.getSliderHurricaneValue();
                Log.info("Hurricane deductible: " + sliderH);
                fsa.assertTrue(sliderH.startsWith(deductible), "Quote Details page - Hurricane slider start text");
                fsa.assertFalse(sliderHValue.isEmpty(), "Quote Details page - Hurricane slider value not empty");
            }
        } else {
            if (isHurricaneState(applicant.stateCode)) {
                String sliderH = this.getSliderHurricane();
                String sliderHValue = this.getSliderHurricaneValue();
                String sliderHdb = quoteRate.getDeductibleValue("Hurricane", applicant.stateCode);
                Log.info("Hurricane deductible: " + sliderH);
                fsa.assertTrue(sliderH.startsWith(deductible), "Quote Details page - Hurricane slider start text");
                if (sliderHdb != null) {
                    fsa.assertEquals(Double.parseDouble(sliderHValue.replace("%", "").replace("$", "")),
                            Double.parseDouble(sliderHdb.replace("%", "").replace("$", "")),
                            "Quote Details page - Hurricane slider value vs. Postgres");
                } else {
                    fsa.assertTrue(sliderHValue.startsWith(NONE), "Quote Details page - Hurricane slider value is None");
                }
            }
        }
        // Water
        if (quoteRate == null) {
            if (isWaterDeductibleState(applicant.stateCode)) {
                String sliderW = this.getSliderWater();
                String sliderWValue = this.getSliderWaterValue();
                Log.info("Water deductible: " + sliderW);
                fsa.assertTrue(sliderW.startsWith(deductible), "Quote Details page - Water slider start text");
                fsa.assertFalse(sliderWValue.isEmpty(), "Quote Details page - Water slider value not empty");
            }
        } else {
            if (isWaterDeductibleState(applicant.stateCode)) {
                String sliderW = this.getSliderWater();
                String sliderWValue = this.getSliderWaterValue();
                String sliderWdb = quoteRate.getDeductibleValue("Water", applicant.stateCode);
                Log.info("Water deductible: " + sliderW);
                fsa.assertTrue(sliderW.startsWith(deductible), "Quote Details page - Water slider start text");
                if (sliderWdb != null) {
                    fsa.assertEquals(sliderWValue, sliderWdb, "Quote Details page - Water slider value vs. Postgres");
                    fsa.assertEquals(Double.parseDouble(sliderWValue.replace("%", "").replace("$", "")),
                            Double.parseDouble(sliderWdb.replace("%", "").replace("$", "")),
                            "Quote Details page - Water slider value vs. Postgres");
                } else {
                    fsa.assertTrue(sliderWValue.startsWith(NONE), "Quote Details page - Water slider value is None");
                }
            }
        }
    }

    public void validateLiabilitySliders(QuoteRateHQM quoteRate, FarmersSoftAssert fsa) throws ParseException {
        String coveredUpTo = "Covered up to";
        currencyFormat.setMaximumFractionDigits(0);
        // Liability
        Log.info("Liability::");
        // Personal liability
        String personalLiability = this.getSliderPersonalLiability();
        Log.info("Personal Liability: " + personalLiability);
        fsa.assertTrue(personalLiability.startsWith(coveredUpTo), "Quote Details page - Personal liability slider start text");
        String personalLiabilityValue = this.getSliderPersonalLiabilityValue();
        Double dPersonalLiability = currencyFormat.parse(personalLiabilityValue).doubleValue();
        personalLiabilityValue = currencyFormat.format(dPersonalLiability);
        if (quoteRate != null) {
            Double dPersonalLiabilityCoverage = Double.parseDouble(quoteRate.getCoverageAmount("Personal Liability"));
            fsa.assertEquals(personalLiabilityValue, currencyFormat.format(dPersonalLiabilityCoverage),
                    "Quote Details page - Personal liability slider selected value vs. Postgres");
        } else {
            String value = "$300,000";
            fsa.assertEquals(personalLiabilityValue, value,
                    "Quote Details page - Personal liability slider selected value vs. pre-defined");
        }

        // Medical payments to others
        String medicalPayments = this.getSliderMedicalPaymentsToOthers();
        Log.info("Medical payments to others: " + medicalPayments);
        fsa.assertTrue(medicalPayments.startsWith(coveredUpTo), "Quote Details page - Medical payments to others slider start text");
        String medicalPaymentsValue = this.getSliderMedicalPaymentsToOthersValue();
        Double dMedicalPayments = currencyFormat.parse(medicalPaymentsValue).doubleValue();
        medicalPaymentsValue = currencyFormat.format(dMedicalPayments);
        if (quoteRate != null) {
            Double dMedicalPaymentsCoverage = Double.parseDouble(quoteRate.getCoverageAmount("Medical Payments to Others"));
            fsa.assertEquals(medicalPaymentsValue, currencyFormat.format(dMedicalPaymentsCoverage),
                    "Quote Details page - Medical payments to others slider selected value vs. Postgres");
        } else {
            String value = "$1,000";
            fsa.assertEquals(medicalPaymentsValue, value,
                    "Quote Details page - Medical payments to others slider selected value vs. pre-defined");
        }
    }

    public void validateStandardPackageSliders(ApplicantHQM applicant, QuoteRateHQM quoteRate,
                                               @Nullable String reconstructionCost, FarmersSoftAssert fsa) throws Exception {
        this.validateCoverageSliders(applicant, quoteRate, reconstructionCost, fsa);
        this.validateDeductibleSliders(applicant, quoteRate, fsa);
        this.validateLiabilitySliders(quoteRate, fsa);
    }

    public void validatePageErrors(ApplicantHQM applicant, FarmersSoftAssert fsa) throws Exception {
        String allPerilDed = getSliderAllPerilValue();
        String windHailDed;
        List<String> pageErrors = this.getPageErrors();
        Log.info(FOUND_PAGE_ERRORS + pageErrors);
        switch (applicant.stateCode) {
            case VA:
            case MT:
            case AZ:
            case NV:
            case MO:
            case CO:
            case IN:
            case KS:
            case MN:
            case OH:
            case OK:
            case WA:
            case IL:
            case UT:
            case IA:
                windHailDed = getSliderWindAndHailValue();
                if (windHailDed.startsWith(NONE)) {
                    moveSlider(sliderWindAndHail, 1);
                    windHailDed = getSliderWindAndHailValue();
                }
                moveSliderToValue(sliderAllPeril, sliderAllPerilDiv, windHailDed, true);
                Log.info(ALL_PERIL_SLIDER_VALUE + getSliderAllPerilValue());
                Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                pageErrors = this.getPageErrors();
                Log.info(FOUND_PAGE_ERRORS + pageErrors);
                fsa.assertEquals(pageErrors, Collections.singletonList(ERROR_WIND_HAIL), QUOTE_DETAILS_PAGE + WIND_HAIL_DEDUCTIBLE_ERROR_IS_FOUND);
                this.moveSlider(sliderWindAndHail, 1);
                break;
            case MI:
                this.moveSlider(sliderWindAndHail, 1);
                Log.info(ALL_PERIL_SLIDER_VALUE + getSliderAllPerilValue());
                Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                pageErrors = this.getPageErrors();
                Log.info(FOUND_PAGE_ERRORS + pageErrors);
                fsa.assertEquals(pageErrors, Collections.singletonList(ERROR_WIND_HAIL), QUOTE_DETAILS_PAGE + WIND_HAIL_DEDUCTIBLE_ERROR_IS_FOUND);
                this.moveSlider(sliderAllPeril, -1);
                this.moveSlider(sliderWindAndHail, 3);
                break;
            case AR:
                windHailDed = getSliderWindAndHailValue();
                this.moveSliderToValue(sliderWindAndHail, sliderWindAndHailDiv, allPerilDed, true);
                Log.info(ALL_PERIL_SLIDER_VALUE + allPerilDed);
                Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                pageErrors = this.getPageErrors();
                Log.info(FOUND_PAGE_ERRORS + pageErrors);
                fsa.assertEquals(pageErrors, Collections.singletonList(ERROR_WIND_HAIL), QUOTE_DETAILS_PAGE + WIND_HAIL_DEDUCTIBLE_ERROR_IS_FOUND);
                this.moveSliderToValue(sliderWindAndHail, sliderWindAndHailDiv, windHailDed, false);
                break;
            case SD:
            case ND:
                windHailDed = getSliderWindAndHailValue();
                Log.info(ALL_PERIL_SLIDER_VALUE + allPerilDed);
                Log.info(WIND_HAIL_SLIDER_VALUE + windHailDed);
                if (applicant.roofCover.equals("Wood Shingles or Shakes")) {
                    fsa.assertEquals(windHailDed, "2.0%", "Quote Details page - Wind & Hail deductible should be 2.0%");
                    moveSliderToValue(sliderAllPeril, sliderAllPerilDiv, "2.0%", true);
                } else {
                    this.moveSlider(sliderAllPeril, 2);
                    this.moveSlider(sliderWindAndHail, 1);
                }
                Log.info(ALL_PERIL_SLIDER_VALUE + getSliderAllPerilValue());
                Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                pageErrors = this.getPageErrors();
                Log.info(FOUND_PAGE_ERRORS + pageErrors);
                fsa.assertEquals(pageErrors, Collections.singletonList(ERROR_WIND_HAIL), QUOTE_DETAILS_PAGE + WIND_HAIL_DEDUCTIBLE_ERROR_IS_FOUND);
                this.moveSlider(sliderWindAndHail, 1);
                break;
            case MD:
                if (pageErrors.isEmpty()) {
                    moveSliderToValue(sliderAllPeril, sliderAllPerilDiv, "2%", true);
                    pageErrors = this.getPageErrors();
                    if (pageErrors.isEmpty()) {
                        this.moveSlider(sliderHurricane, 1);
                    }
                    Log.info(ALL_PERIL_SLIDER_VALUE + getSliderAllPerilValue());
                    Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                    Log.info(HURRICANE_SLIDER_VALUE + getSliderHurricaneValue());
                    pageErrors = this.getPageErrors();
                    Log.info(FOUND_PAGE_ERRORS + pageErrors);
                }
                fsa.assertEquals(pageErrors, Collections.singletonList(ERROR_HURRICANE), QUOTE_DETAILS_PAGE + HURRICANE_DEDUCTIBLE_ERROR_IS_FOUND);
                moveSliderToValue(sliderHurricane, sliderHurricaneDiv, "3%", true);
                Log.info(ALL_PERIL_SLIDER_VALUE + getSliderAllPerilValue());
                Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                Log.info(HURRICANE_SLIDER_VALUE + getSliderHurricaneValue());
                pageErrors = this.getPageErrors();
                Log.info(FOUND_PAGE_ERRORS + pageErrors);
                fsa.assertTrue(pageErrors.isEmpty(), "Validate no errors are displayed.");
                this.moveSlider(sliderWindAndHail, 1);
                Log.info(ALL_PERIL_SLIDER_VALUE + getSliderAllPerilValue());
                Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                Log.info(HURRICANE_SLIDER_VALUE + getSliderHurricaneValue());
                pageErrors = this.getPageErrors();
                Log.info(FOUND_PAGE_ERRORS + pageErrors);
                fsa.assertEquals(pageErrors, Arrays.asList(ERROR_WIND_HAIL,ERROR_WIND_HAIL_HURRICANE),
                        QUOTE_DETAILS_PAGE + WIND_HAIL_HURRICANE_DEDUCTIBLES_ERROR_IS_FOUND);
                this.moveSlider(sliderWindAndHail, -1);
                break;
            case AL:
            case PA:
                if (pageErrors.isEmpty()) {
                    moveSliderToValue(sliderAllPeril, sliderAllPerilDiv, "2.0%", true);
                    pageErrors = this.getPageErrors();
                    if (pageErrors.isEmpty()) {
                        this.moveSlider(sliderHurricane, 1);
                    }
                    Log.info(ALL_PERIL_SLIDER_VALUE + getSliderAllPerilValue());
                    Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                    Log.info(HURRICANE_SLIDER_VALUE + getSliderHurricaneValue());
                    pageErrors = this.getPageErrors();
                    Log.info(FOUND_PAGE_ERRORS + pageErrors);
                }
                fsa.assertEquals(pageErrors, Collections.singletonList(ERROR_HURRICANE), QUOTE_DETAILS_PAGE + HURRICANE_DEDUCTIBLE_ERROR_IS_FOUND);
                moveSliderToValue(sliderHurricane, sliderHurricaneDiv, "3.0%", true);
                Log.info(ALL_PERIL_SLIDER_VALUE + getSliderAllPerilValue());
                Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                Log.info(HURRICANE_SLIDER_VALUE + getSliderHurricaneValue());
                pageErrors = this.getPageErrors();
                Log.info(FOUND_PAGE_ERRORS + pageErrors);
                fsa.assertTrue(pageErrors.isEmpty(), "Validate no errors are displayed.");
                this.moveSlider(sliderWindAndHail, 1);
                Log.info(ALL_PERIL_SLIDER_VALUE + getSliderAllPerilValue());
                Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                Log.info(HURRICANE_SLIDER_VALUE + getSliderHurricaneValue());
                pageErrors = this.getPageErrors();
                Log.info(FOUND_PAGE_ERRORS + pageErrors);
                fsa.assertEquals(pageErrors, Arrays.asList(ERROR_WIND_HAIL, ERROR_WIND_HAIL_HURRICANE), QUOTE_DETAILS_PAGE +
                        WIND_HAIL_HURRICANE_DEDUCTIBLES_ERROR_IS_FOUND);
                this.moveSlider(sliderWindAndHail, -1);
                break;
            case CT:
                String allPerilSlider = getSliderAllPerilValue();
                String hurricaneSlider = getSliderHurricaneValue();
                Log.info(ALL_PERIL_SLIDER_VALUE + allPerilSlider);
                Log.info(HURRICANE_SLIDER_VALUE + getSliderHurricaneValue());
                this.moveSliderToValue(sliderAllPeril, sliderAllPerilDiv, hurricaneSlider, true);
                this.moveSlider(sliderAllPeril, 1);
                pageErrors = this.getPageErrors();
                Log.info(FOUND_PAGE_ERRORS + pageErrors);
                fsa.assertEquals(pageErrors, Collections.singletonList(ERROR_HURRICANE_CT), QUOTE_DETAILS_PAGE + HURRICANE_DEDUCTIBLE_ERROR_IS_FOUND);
                this.moveSlider(sliderAllPeril, -1);
                break;
            case CA:
                String waterSlider = getSliderWaterValue();
                this.moveSliderToValue(sliderWater, sliderWaterDiv, allPerilDed, false);
                pageErrors = this.getPageErrors();
                if (pageErrors.isEmpty()) {
                    this.moveSliderToValue(sliderWater, sliderWaterDiv, allPerilDed, true);
                    pageErrors = this.getPageErrors();
                }
                Log.info(ALL_PERIL_SLIDER_VALUE + allPerilDed);
                Log.info("Water slider value: " + getSliderWaterValue());
                fsa.assertEquals(pageErrors, Collections.singletonList(ERROR_WATER), QUOTE_DETAILS_PAGE +
                        "Water deductible error is found.");
                this.moveSliderToValue(sliderWater, sliderWaterDiv, waterSlider, true);
                break;
            case KY:
                this.moveSlider(sliderAllPeril, 2);
                this.moveSlider(sliderWindAndHail, -1);
                Log.info(ALL_PERIL_SLIDER_VALUE + getSliderAllPerilValue());
                Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                pageErrors = this.getPageErrors();
                if (pageErrors.isEmpty()) {
                    this.moveSlider(sliderWindAndHail, -1);
                    Log.info(ALL_PERIL_SLIDER_VALUE + getSliderAllPerilValue());
                    Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                }
                pageErrors = this.getPageErrors();
                Log.info(FOUND_PAGE_ERRORS + pageErrors);
                fsa.assertEquals(pageErrors, Collections.singletonList(ERROR_WIND_HAIL), QUOTE_DETAILS_PAGE + WIND_HAIL_DEDUCTIBLE_ERROR_IS_FOUND);
                moveSliderToValue(sliderWindAndHail, sliderWindAndHailDiv, "2%", true);
                break;
            case MS:
            case MA:
            case TX:
                moveSliderToValue(sliderAllPeril, sliderAllPerilDiv, "5.0%", true);
                String allPerilSliderValue = getSliderAllPerilValue();
                String hurricaneSliderValue = getSliderHurricaneValue();
                Log.info(ALL_PERIL_SLIDER_VALUE + allPerilSliderValue);
                Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                Log.info(HURRICANE_SLIDER_VALUE + hurricaneSliderValue);
                pageErrors = this.getPageErrors();
                Log.info(FOUND_PAGE_ERRORS + pageErrors);
                List<String> listErrors = new ArrayList<>(Collections.singleton(ERROR_WIND_HAIL_MS));
                if (Double.parseDouble(allPerilSliderValue.replace("%", "")) >
                        Double.parseDouble(hurricaneSliderValue.replace("%", ""))) {
                    listErrors.add(ERROR_HURRICANE_MS);
                }
                fsa.assertEquals(pageErrors, listErrors, QUOTE_DETAILS_PAGE + "Wind & Hail and Hurricane deductible errors are found.");
                moveSliderToValue(sliderAllPeril, sliderAllPerilDiv, allPerilDed, false);
                break;
            case NC:
                Log.info(ALL_PERIL_SLIDER_VALUE + allPerilDed);
                Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                this.moveSlider(sliderAllPeril, 2);
                pageErrors = this.getPageErrors();
                if (pageErrors.isEmpty()) {
                    this.moveSlider(sliderAllPeril, 2);
                    Log.info(ALL_PERIL_SLIDER_VALUE + getSliderAllPerilValue());
                    Log.info(WIND_HAIL_SLIDER_VALUE + getSliderWindAndHailValue());
                }
                pageErrors = this.getPageErrors();
                Log.info(FOUND_PAGE_ERRORS + pageErrors);
                fsa.assertEquals(pageErrors, Collections.singletonList(ERROR_WIND_HAIL_MS), QUOTE_DETAILS_PAGE + WIND_HAIL_DEDUCTIBLE_ERROR_IS_FOUND);
                moveSliderToValue(sliderAllPeril, sliderAllPerilDiv, allPerilDed, false);
                break;
            default: {
                Log.warn("Unknown applicant state code: " + applicant.stateCode);
            }
        }
        pageErrors = this.getPageErrors();
        Log.info(FOUND_PAGE_ERRORS + pageErrors);
        fsa.assertTrue(pageErrors.isEmpty(), "Validate no errors are displayed after deductible sliders moved.");
    }

    public void updateSlidersRecalculate(ApplicantHQM applicant, FarmersSoftAssert fsa) throws Exception {
        String dwellingVal = null;
        String extendedReplacementVal = null;
        if (Arrays.asList(CA, NC, TX).contains(applicant.stateCode)) {
            moveSlider(sliderExtendedReplacement, 1);
            extendedReplacementVal = getSliderExtendedReplacementPercent();
        } else if (applicant.stateCode.equals(AL)) {
            this.moveSlider(sliderHurricane, 1);
        } else {
            this.moveSlider(sliderDwelling, -1);
            dwellingVal = getSliderDwellingValue();
        }
        if (!getPageErrors().isEmpty() || !getSliderErrors().isEmpty()) {
            clickReset();
        }
        String windHailVal = isWindAndHailState(applicant.stateCode) ? getSliderWindAndHailValue() : null;
        String hurricaneVal = isHurricaneState(applicant.stateCode) ? getSliderHurricaneValue() : null;
        String waterVal = isWaterDeductibleState(applicant.stateCode) ? getSliderWaterValue() : null;
        fsa.assertTrue(checkIfElementIsEnabled(btnRecalculate, 2), "Quote Details page - Recalculate button is enabled");
        // monthly and yearly premium's font style have to be strike-through
        fsa.assertTrue(isMonthlyPremiumCrossed(), "Quote Details page - Check Monthly premium text is strike-through.");
        fsa.assertTrue(isYearlyPremiumCrossed(applicant.stateCode), "Quote Details page - Check Yearly premium text is strike-through.");
        //
        clickRecalculate();
        // monthly and yearly premium's font style have to be w/o strike-through
        fsa.assertFalse(isMonthlyPremiumCrossed(), "Quote Details page - Check Monthly premium text is not strike-through.");
        fsa.assertFalse(isYearlyPremiumCrossed(applicant.stateCode), "Quote Details page - Check Yearly premium text is not strike-through.");
        //
        List<String> pageErrors = this.getPageErrors();
        Log.info(FOUND_PAGE_ERRORS + pageErrors);
        // this if statement is a workaround to AL state case when Reset button is not fully resets the Quote Details
        if (!pageErrors.isEmpty()) {
            this.clickCloseModal();
            QuotePage quotePage = new QuotePage();
            quotePage.clickQuoteDetails();
            driverWait(Property.PAGELOADTIMEOUT).until(ExpectedConditions.visibilityOf(titleQuoteType));
            if (applicant.stateCode.equals(CA)) {
                moveSlider(sliderExtendedReplacement, 1);
                extendedReplacementVal = getSliderExtendedReplacementPercent();
            } else {
                this.moveSlider(sliderDwelling, -1);
                dwellingVal = getSliderDwellingValue();
            }
            fsa.assertTrue(checkIfElementIsEnabled(btnRecalculate, 2), "Quote Details page - Recalculate button is enabled");
            clickRecalculate();
        }
        if (Arrays.asList(CA, NC, TX).contains(applicant.stateCode)) {
            String extendedReplacement2 = getSliderExtendedReplacementPercent();
            fsa.assertEquals(extendedReplacement2, extendedReplacementVal,
                    "Quote Details page - Extended Replacement Cost slider is customized");
            Log.info("Quote Details page - Extended Replacement Cost slider value: " + extendedReplacement2);
        } else if (applicant.stateCode.equals(AL)) {
            String hurricaneVal2 = getSliderHurricaneValue();
            fsa.assertEquals(hurricaneVal2, hurricaneVal, "Quote Details page - Hurricane slider is customized");
            Log.info("Quote Details page - Hurricane slider value: " + hurricaneVal2);
        } else {
            String dwellingVaL2 = getSliderDwellingValue();
            fsa.assertEquals(dwellingVaL2, dwellingVal, "Quote Details page - Dwelling slider is customized");
            Log.info("Quote Details page - Dwelling slider value: " + dwellingVaL2);
        }
        if (windHailVal != null) {
            fsa.assertEquals(getSliderWindAndHailValue(), windHailVal, "Quote Details page - Wind & Hail slider has not changed");
        }
        if (hurricaneVal != null) {
            fsa.assertEquals(getSliderHurricaneValue(), hurricaneVal, "Quote Details page - Hurricane slider has not changed");
        }
        if (waterVal != null) {
            fsa.assertEquals(getSliderWaterValue(), waterVal, "Quote Details page - Water slider has not changed");
        }
        fsa.assertEquals(this.getTitleQuoteType(), "Standard Custom", "Quote Details page - Quote type title");

    }

    public void customRateRecalculate(String stateCode) throws Exception {
        if (Arrays.asList(CA, TX, NC).contains(stateCode)) {
            this.moveSlider(sliderExtendedReplacement, 1);
        } else {
            this.moveSlider(sliderDwelling, -1);
        }
        List<String> pageErrors = this.getPageErrors();
        Log.info(FOUND_PAGE_ERRORS + pageErrors);
        if (!pageErrors.isEmpty()) {
            this.moveSlider(sliderWindAndHail, 3);
        }
        clickRecalculate();
        waitForPageToBeReady();
        Assert.assertEquals(this.getTitleQuoteType(), "Standard Custom", "Quote Details page - Quote type title");
    }

}
