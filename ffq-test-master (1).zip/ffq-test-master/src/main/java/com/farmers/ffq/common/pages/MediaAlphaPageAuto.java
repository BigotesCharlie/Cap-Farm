package com.farmers.ffq.common.pages;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.datatransferobjects.SqlIncident;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage.DID_NOT_REACH;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class MediaAlphaPageAuto extends AutoBasePage {
    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public MediaAlphaPageAuto() throws Exception {
    }

    public boolean isOnMediaAlphaPageAuto() {
        return isElementVisible(carYear, Property.PAGELOADTIMEOUT);
    }

    private static final String CAR_YEAR_XPATH = "//table[@id='home-panel-content']//div[@id='car-panel' and contains(.,'model year')]//a";
    private static final String CAR_MAKE_XPATH = "//table[@id='home-panel-content']//div[@id='car-panel' and contains(.,'make')]//a";
    private static final String CAR_MODEL_XPATH = "//table[@id='home-panel-content']//div[@id='car-panel' and contains(.,'model')]//a";
    private static final String CAR_SUBMODEL_XPATH = "//table[@id='home-panel-content']//div[@id='car-panel' and contains(.,'submodel')]//a[contains(@onclick,'update')]";

    @FindBy(xpath = "//table[@id='home-panel-content']//div[@id='car']")
    private WebElement carYear;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-alarm']")
    private WebElement checkBoxAlarm;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-primary-use-work']")
    private WebElement radioPrimaryUseWork;
    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-primary-use-pleasure']")
    private WebElement radioPrimaryUsePleasure;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-average-mileage']")
    private WebElement selectAverageMileage;
    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-annual-mileage']")
    private WebElement selectAnnualMileage;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-collision']")
    private WebElement selectDeductibleCollision;
    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-comprehensive']")
    private WebElement selectDeductibleComprehensive;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[@id='save-car']")
    private WebElement buttonSaveCar;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[@id='add-car']")
    private WebElement buttonAddCar;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-car-leased-1']")
    private WebElement radioCarLeasedYes;
    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id=''f-car-leased-0']")
    private WebElement radioCarLeasedNo;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-address']")
    private WebElement streetAddress;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-address2']")
    private WebElement aptUnit;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-home-length']")
    private WebElement selectHowLongLivedThere;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-city2']")
    private WebElement cityStateZip;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-type-own']")
    private WebElement radioOwnedYes;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-type-rent']")
    private WebElement radioOwnedNo;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-garage-yes']")
    private WebElement radioGarageYes;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-garage-no']")
    private WebElement radioGarageNo;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'go to step 2')]")
    private WebElement goToStep2Button;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'go to step 3')]")
    private WebElement goToStep3Button;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'almost done!')]")
    private WebElement almostDoneButton;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'last step')]")
    private WebElement lastStepButton;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@name='currently_insured']")
    private WebElement currentlyInsuredCheckbox;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'Go to Last Step')]")
    private WebElement goToLastStepButton;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'Get Your Quotes')]")
    private WebElement yourQuotesButton;

    @FindBy(xpath = "//li[@id='add-spouse']")
    private WebElement spouseDropDown;

   @FindBy(xpath = "//li[contains(@onclick,'child')]")
    private WebElement childDropDown;

    @FindBy(xpath = "//li[contains(@onclick,'other')]")
    private WebElement otherDropDown;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-driver-name']")
    private WebElement driverName;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-gender']")
    private WebElement selectDriverGender;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-married-yes']")
    private WebElement radioMarriedYes;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-married-no']")
    private WebElement radioMarriedNo;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-birthday']")
    private WebElement birthday;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-first-licensed']")
    private WebElement selectFirstLicensed;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-education']")
    private WebElement selectEducationLevel;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-primary-car']")
    private WebElement selectPrimaryCar;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-credit-rating']")
    private WebElement selectCreditRating;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-occupation']")
    private WebElement selectOccupation;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-occupation']//option")
    private List<WebElement> selectOccupationOptions;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-license-active']")
    private WebElement radioLicenseActive;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-license-suspended']")
    private WebElement radioLicenseSuspended;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-sr-22-yes']")
    private WebElement radioFileSR22Yes;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-sr-22-no']")
    private WebElement radioFileSR22No;

    @FindBy(xpath = "//button[@data-cb-id='button_cta' and contains(.,'View My Quote')]")
    private WebElement viewMyQuoteButton;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-email']")
    private WebElement email;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-phone']")
    private WebElement phone;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[@id='save-driver']")
    private WebElement saveDriverButton;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[@id='add-driver']")
    private WebElement addDriverButton;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-current-company']")
    private WebElement currentInsuranceCompany;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-continuous-coverage']")
    private WebElement continuosCoverage;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-current-customer']")
    private WebElement currentCustomer;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-current-policy-expires']")
    private WebElement currentPolicyExpires;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-coverage-minimum']")
    private WebElement radioMinimumCoverage;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-coverage-standard']")
    private WebElement radioStandardCoverage;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-coverage-super']")
    private WebElement radioPremiumCoverage;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-incident-type']")
    private WebElement incidentType;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-incident-driver']")
    private WebElement incidentDriver;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-incident-date']")
    private WebElement incidentDate;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-ticket-type']")
    private WebElement ticketType;

    @FindBy(xpath = "//table[@id='home-panel-content']//select[@id='f-incident-description']")
    private WebElement incidentDescription;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[@id='add-incident']")
    private WebElement incidentButtonAdd;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'Yes')]")
    private WebElement accidentButtonYes;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'No')]")
    private WebElement accidentButtonNo;

    @FindBy(xpath = "//button[@id='redirect-btn'][1]")
    private WebElement redirectButton;

    @FindBy(xpath = "//button[contains(@class,'mainForm__button')]")
    private WebElement proceedToFarmersButton;

    @FindBy(xpath = "//a[text()='Skip to contact']")
	private WebElement skipToContactLink;


    private void selectCarYear(String year) throws Exception {
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(CAR_YEAR_XPATH)));
        WebElement carAttributeWe = driver().findElement(By.xpath(CAR_YEAR_XPATH + "[text()='" + year + "']"));
        waitAndClickElement(carAttributeWe);
        Log.info("Selected car year: " + year);
    }

    private void selectCarMake(String make) throws Exception {
        String carMakeXpath = CAR_MAKE_XPATH + "[text()='" + make + "']";
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(carMakeXpath)));
        List<WebElement> makes = driver().findElements(By.xpath(carMakeXpath));
        if(makes.isEmpty()) {
            // if make is not available, randomly select
            makes = driver().findElements(By.xpath(CAR_MAKE_XPATH));
            Collections.shuffle(makes);
        }
        WebElement firstMake = makes.get(0);
        make = getTextFromElement(firstMake);
        waitAndClickElement(firstMake);
        Log.info("Selected car make: " + make);
    }

    private void selectCarModel(String model) throws Exception {
        String carModelXpath = CAR_MODEL_XPATH + "[text()='" + model + "']";
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(carModelXpath)));
        List<WebElement> models = driver().findElements(By.xpath(carModelXpath));
        if(models.isEmpty()) {
            // if specific model is not present, randomly select model
            models = driver().findElements(By.xpath(CAR_MODEL_XPATH));
            Collections.shuffle(models);
        }
        WebElement firstModel = models.get(0);
        model = getTextFromElement(firstModel);
        waitAndClickElement(firstModel);
        Log.info("Selected car model: " + model);
    }

    private void selectCarSubModel(String subModel) throws Exception {
        String carSubModelXpath = CAR_SUBMODEL_XPATH + "[contains(text(),'" + subModel + "')]";
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(carSubModelXpath)));

        List<WebElement> subModels = driver().findElements(By.xpath(carSubModelXpath));
        if(subModels.isEmpty()) {
            // if provided submodel is not there, randomly select
            subModels = driver().findElements(By.xpath(CAR_SUBMODEL_XPATH));
            subModels.removeIf(each -> getTextFromElement(each).contains("NOT SURE"));
            Collections.shuffle(subModels);
        }
        waitAndClickElement(subModels.get(0));
        Log.info("Selected car submodel: " + getTextFromElement(subModels.get(0)));
    }

    private void selectCarPrimaryUse(String primaryUse) {
        if (primaryUse.equals("Personal")) {
            waitAndClickElement(radioPrimaryUsePleasure);
        } else {
            waitAndClickElement(radioPrimaryUseWork);
        }
        Log.info("Selected car primary use: " + primaryUse);
    }

    private void selectCarLeased(String lessor) {
        if (lessor.isBlank()) {
            waitAndClickElement(radioCarLeasedNo);
        } else {
            waitAndClickElement(radioCarLeasedYes);
        }
        Log.info("Selected car leased: " + (lessor.isBlank() ? "No" : "Yes"));
    }

    private void enterAddress(String address) {
        sendKeysToElement(streetAddress, address);
        Log.info("Entered street address: " + address);
    }

    private void clickGoToStep2Button() {
        scrollElementToMiddle(goToStep2Button);
        waitAndClickElement(goToStep2Button);
    }

    private void clickGoToStep3Button() {
        scrollElementToMiddle(goToStep3Button);
        waitAndClickElement(goToStep3Button);
    }

    private void clickAlmostDoneButton() {
        scrollElementToMiddle(almostDoneButton);
        waitAndClickElement(almostDoneButton);
    }

    private void clickLastStepButton() {
        waitAndClickElement(lastStepButton);
    }

    private void clickGetYourQuotesButton() {
    	scrollAndClickOnElement(yourQuotesButton);
    }

    private void clickViewMyQuoteButton() {
        if (isElementVisible(viewMyQuoteButton, 15)) {
            scrollAndClickOnElement(viewMyQuoteButton);
        } else {
            throw new IllegalStateException(DID_NOT_REACH + "ViewMyQuoteButton");
        }
    }

    private void clickRedirectButton() {
        waitAndClickElement(redirectButton);
    }

    private void enterMaritalStatus(String status) {
        if(!isElementVisible(radioMarriedYes, 1)) {
            return;
        }
        if (status.equalsIgnoreCase("married")) {
            waitAndClickElement(radioMarriedYes);
        } else {
            waitAndClickElement(radioMarriedNo);
        }
    }

    private void enterBirthday(String birthday) {
        waitAndClickElement(this.birthday);
        sendKeysToElementWithoutClearingField(this.birthday, birthday);
    }

    private void enterEmail(String email) {
        waitAndClickElement(this.email);
        sendKeysOneByOne(this.email, email);
        Log.info("Entered email: " + email);
    }

    private void enterPhone(String phone) {
        waitAndClickElement(this.phone);
        sendKeysToElementWithoutClearingField(this.phone, phone);
        Log.info("Entered phone number: " + phone);
    }

    private void enterVehicleData(AutoApplicant applicant) throws Exception {
        int vehicles = applicant.getVehicles().size();
        for (int i=0; i < vehicles; i++) {
            sleep(1);
            selectCarYear(applicant.getVehicles().get(i).getVehicleYear());
            selectCarMake(applicant.getVehicles().get(i).getVehicleMake());
            selectCarModel(applicant.getVehicles().get(i).getVehicleModel().split(SPACE)[0]);
            sleep(1);
            if (driver().findElements(By.xpath(CAR_SUBMODEL_XPATH)).size() > 1) {
                selectCarSubModel(applicant.getVehicles().get(i).getVehicleModel().replaceAll("[^0-9]", EMPTY_STRING));
            }
            selectCarPrimaryUse(applicant.getVehicles().get(i).getVehicleUsage());
            selectCarLeased(applicant.getVehicles().get(i).getLessor());
            waitAndClickElement(buttonSaveCar);
            if ((i+1) < vehicles) {
                waitAndClickElement(buttonAddCar);
            }
        }
    }

    private void enterDriverName(String name) {
        scrollElementToMiddle(driverName);
        waitAndClickElement(driverName);
        sendKeysToElement(driverName, name);
        Log.info("Entered driver name: " + name);
    }

    private void enterDriverGender(String gender) {
        waitElementBeVisible(selectDriverGender);
        selectVisibleTextInDropDown(selectDriverGender, gender);
        Log.info("Driver gender is selected as : " + gender);
    }

    private void enterFirstLicensed(String year) {
        waitElementBeVisible(selectFirstLicensed);
        selectVisibleTextInDropDown(selectFirstLicensed, year);
        Log.info("Entered first licensed year: " + year);
    }

    private void selectPrimaryCar(String car) {
        waitElementBeVisible(selectPrimaryCar);
        selectVisibleTextInDropDown(selectPrimaryCar, car);
    }

    private void selectOccupation(String occupation) {
        waitElementBeVisible(selectOccupation);
        List<String> listOfOccupations = selectOccupationOptions.stream().map(this::getTextFromElement).collect(Collectors.toList());
        if(listOfOccupations.contains(occupation)) {
            selectVisibleTextInDropDown(selectOccupation, occupation);
        }
        Log.info("Selected occupation: " + occupation);
    }

    private void enterCurrentCompanyName(String company) {
        waitAndClickElement(currentInsuranceCompany);
        sendKeysToElement(currentInsuranceCompany, company);
    }

    private void selectContinuousCoverage(AutoApplicant applicant) {
        waitElementBeVisible(continuosCoverage);
        int age = applicant.getAge();
        String valueToSelect;
        switch(age) {
            case  16: case 17: case 18:
                valueToSelect = "1 year";
                break;
            case 19: case 20: case 21:
                valueToSelect = "3 years";
                break;
            case 22: case 23: case 24:
                valueToSelect = "5 to 10 years";
                break;
            default:
                valueToSelect = "Over 10 years";
        }
        selectVisibleTextInDropDown(continuosCoverage, valueToSelect);
        Log.info("Selected continuous coverage as: " + valueToSelect);
    }

    private void selectCurrentCustomer(String years) {
        waitElementBeVisible(currentCustomer);
        if(years.equals("< 6 Months")) {
            years = "Less than 6 months";
        }
        selectVisibleTextInDropDown(currentCustomer, years);
        Log.info("Selected current customer: " + years);
    }

    private void selectTicketType(String ticketType) {
        wait.until(ExpectedConditions.visibilityOf(incidentType));
        selectVisibleTextInDropDown(incidentType, ticketType);
            Log.info("Selected ticket type: " + ticketType);
    }

    private void selectIncidentDriver(String driver) {
        waitElementBeVisible(incidentDriver);
        selectVisibleTextInDropDown(incidentType, driver);
    }

    private void enterIncidentDate(String date) {
        waitAndClickElement(incidentDate);
        sendKeysToElement(incidentDate, date);
    }

    private void clickAccidentButtonYes() {
        wait.until(ExpectedConditions.visibilityOf(accidentButtonYes));
        waitAndClickElement(accidentButtonYes);
    }

    private void clickAccidentButtonNo() {
        sleep(2);
        clickElement(accidentButtonNo);
    }

    private void clickIncidentButtonAdd() {
        wait.until(ExpectedConditions.visibilityOf(incidentButtonAdd));
        waitAndClickElement(incidentButtonAdd);
    }

    private void enterPNIData(AutoApplicant applicant) {
        enterDriverName(applicant.getFirstName() + SPACE + applicant.getLastName());
        enterDriverGender(applicant.getGender());
        enterMaritalStatus(applicant.getMaritalStatus());
        enterBirthday(applicant.getDateOfBirth());
        enterFirstLicensed(String.valueOf(applicant.getFirstAgeUnitedStatesDriverLicense()));
//        selectPrimaryCar(applicant.getVehicles().get(0).getVehicleYear() + SPACE +
//                applicant.getVehicles().get(0).getVehicleMake() + SPACE + applicant.getVehicles().get(0).getVehicleModel());
        selectOccupation(applicant.getOccupation());
        scrollElementToMiddle(saveDriverButton);
        waitAndClickElement(saveDriverButton);
    }

    private void enterDriversData(SqlAdditionalDriver driver) {
        selectRelationToPNI(driver);
        enterDriverName(driver.getFirstName() + SPACE + driver.getLastName());
        enterDriverGender(driver.getGender());
        enterMaritalStatus(driver.getMaritalStatus());
        enterBirthday(driver.getDateOfBirth());
        enterFirstLicensed(String.valueOf(driver.getFirstAgeUnitedStatesDriverLicense()));
//        selectPrimaryCar(applicant.getVehicles().get(0).getVehicleYear() + SPACE +
//                applicant.getVehicles().get(0).getVehicleMake() + SPACE + applicant.getVehicles().get(0).getVehicleModel());
        selectOccupation(driver.getOccupation());
        scrollElementToMiddle(saveDriverButton);
        waitAndClickElement(saveDriverButton);
    }

    private void selectRelationToPNI(SqlAdditionalDriver driver) {
        String relationshipToApplicant = driver.getRelationshipToApplicant();
        switch (relationshipToApplicant) {
            case "Son": case "Daughter":
                waitAndClickElement(childDropDown);
                break;
            case SPOUSE:
                waitAndClickElement(spouseDropDown);
                break;
            default:
                waitAndClickElement(otherDropDown);
        }
    }

    private void enterCurrentCompanyData(AutoApplicant applicant) {
        if(applicant.getCurrentlyInsuredStatus().equals(NEVER_INSURED)) {
            clickElement(currentlyInsuredCheckbox);
            return;
        }
        enterCurrentCompanyName(applicant.getCurrentInsuranceCompany());
        selectContinuousCoverage(applicant);
        selectCurrentCustomer(applicant.getContinuosInsurancePeriod());
    }

    private void enterIncidentsData(AutoApplicant applicant) {
        int numIncidents = applicant.getIncidents().size();
        for (int i = 0; i < numIncidents; i++) {
            SqlIncident incident = applicant.getIncidents().get(i);
            selectTicketType(incident.getIncidentType());
//            selectIncidentDriver(incident.getApplicantId());



            if (i < (numIncidents + 1)) {
                clickIncidentButtonAdd();
            }
        }

    }

    public void enterAutoApplicantData(AutoApplicant applicant) throws Exception {
        enterVehicleData(applicant);
        clickGoToStep2Button();

        enterPNIData(applicant);

        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        for (int i = 0; i < additionalDrivers.size(); i++) {
            scrollElementToMiddle(addDriverButton);
            waitAndClickElement(addDriverButton);
            enterDriversData(additionalDrivers.get(i));
        }
        clickGoToStep3Button();
        enterCurrentCompanyData(applicant);
        clickAlmostDoneButton();
        if (applicant.getIncidents().isEmpty()) {
            clickAccidentButtonNo();
        } else {
            clickAccidentButtonYes();
            enterIncidentsData(applicant);
            clickLastStepButton();
        }

        enterEmail(applicant.getEmail());
        enterPhone(applicant.getPhoneNumber());
        enterAddress(applicant.getResidentAddress());
        skipToContact();
        clickGetYourQuotesButton();

        clickViewMyQuoteButton();
        switchToNewTab(2);
        clickRedirectButton();

        if (isElementVisible(proceedToFarmersButton, 45)) {
            waitAndClickElement(proceedToFarmersButton);
            clickRedirectButton();
        }
    }

	private void skipToContact() {
		clickElement(skipToContactLink);
	}

}
