package com.farmers.ffq.auto.pages.legacy;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.datatransferobjects.SqlVehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.Arrays;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfAllElementsLocatedBy;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;

/**
 * Farmers Fast Quote (FFQ) - Additional Information page.
 */
public class AdditionalInformationPage extends AutoBasePage  {

	@FindBy(id = "additionalInfo:AdditionalInformation")
	private WebElement additionalInformationPageHeader;

	@FindBy(id = "additionalInfo:vehInfo")
	private List<WebElement> vehicleList;

	@FindBy(id = "additionalInfo:drvInfo")
	private List<WebElement> driverList;

	private static final String CONTINUE_TO_PAYMENT_BUTTON_XPATH = "//*[@id='additionalInfo:nextDiscount']";
	@FindBy(xpath = CONTINUE_TO_PAYMENT_BUTTON_XPATH)
	private WebElement continueToPaymentButton;

	@FindBy(id = "additionalDrv:continue")
	private WebElement bwContinueToPaymentButton;
	
	@FindBy(xpath = "//*[@id='RegisterMyFarmers']")
	private WebElement generatingPremiumPopUpWindow;

	@FindBy(xpath = "//*[@id='RegisterMyFarmers']/div/p")
	private WebElement generatingPremiumPopUpMessage;

	@FindBy(id = "additionalInfo:countyCity")
	private WebElement residencyCountyDropdownList;

	private static final String CONTINUE_TO_ADDITIONAL_INFO_BUTTON_XPATH = "//button[@data-gtm='FFQ_AUTO_AddDriverInfo_Continue_Btn']";
	@FindBy(xpath = CONTINUE_TO_ADDITIONAL_INFO_BUTTON_XPATH)
	private WebElement continueToAdditionalInfoButton;
	
	@FindBy(id = "additionalInfo:signalInfo:0:signalMobNum")
	private WebElement signalMobilePhoneNumber;

	@FindBy(id = "additionalInfo:termsChk")
	private WebElement agreeToSignalTerms;
	
	@FindBy(id = "BwPopup")
	private WebElement bwInfoPopup;
	
	@FindBy(xpath = "//button[@id='btnClose' and @title='No']")
	private WebElement bwInfoPopupNoButton;

	@FindBy(xpath = "//button[@id='btnClose' and @title='Yes']")
	private WebElement bwInfoPopupYesButton;

	private static final String DRIVER_INFO_PARTIAL_XPATH = "//*[@id='additionalInfo:drvInfo:";
	private static final String VEHICLE_INFO_PARTIAL_XPATH = "//*[@id='additionalInfo:vehInfo:";
	private boolean isBristolWestQuote;

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public AdditionalInformationPage() throws Exception {
		super();
		checkForKnockout("AdditionalInformationPage");
		if (isElementPresentByXPath(CONTINUE_TO_ADDITIONAL_INFO_BUTTON_XPATH)) {
			clickElement(continueToAdditionalInfoButton);
		}
		waitElementBeVisible(additionalInformationPageHeader);
		isBristolWestQuote = isBristolWestQuote();
	}

	public boolean isOneAdditionalInfoPage() {
		return isElementVisible(additionalInformationPageHeader, 50);
	}

	public boolean verifyAdditionalInformationPage(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		verifyVehicles(applicant, fsa);
		if (!applicant.getStateCode().equals(MA)) {
			verifyDrivers(applicant, fsa);
		}
		if (!isBristolWestQuote && applicant.getCurrentlyInsuredStatus().equals("Insured")) {
			verifyPolicyStartDate(applicant, fsa);
		}
		enterAdditionalInformationPageData(applicant, fsa);
		selectContinueToPaymentButton();
		waitForSpinnerToBeGone();
		if (isBristolWestQuote) {
			enterDiscoveredAdditionalDriversData();
		} else if (isBrightlinedQuote()) {
			continueToBristolWest(true);
			isBristolWest = true;
		} else if(isElementPresentByXPath(CONTINUE_TO_PAYMENT_BUTTON_XPATH)) {
			clickElement(continueToPaymentButton);
		}
		return !(isElementPresentByXPath("//p[@class='errorOff' and contains(@style, 'px')]"));
	}

	private void enterDiscoveredAdditionalDriversData() throws Exception {
		//These are drivers found by the quoting services, remove them for now.
		List <WebElement> moreDrivers = driver().findElements(By.className("drvDivDetails"));
		if (!moreDrivers.isEmpty()) {
			int numberOfDiscoveredDrivers = moreDrivers.size();
			for (int index = 0; index < numberOfDiscoveredDrivers; index++) {
				List<WebElement> driverStatusDropdownBoxes = driver().findElements(By.id("additionalDrv:drvInfo:"+index+":driverStatus"));
				if (!driverStatusDropdownBoxes.isEmpty()) {
					selectFromDropDown(driverStatusDropdownBoxes.get(0), "Is not in my Household");
				}
			}
			if (isElementPresentByID(bwContinueToPaymentButton)) {
				scrollAndClickOnElement(bwContinueToPaymentButton);
			} else {
				selectContinueToPaymentButton();
			}
		}
	}

	public void enterAdditionalInformationPageData(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		enterVehicleInformation(applicant);
		if (!applicant.getStateCode().equals(MA)) {
			enterDriverInformation(applicant, fsa);
		}
	}

	private void verifyVehicles(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		Log.info("Verifying vehicles...");
		int maximumVehiclesAllowed = limitVehicleCountToMaxAllowed(applicant.getStateCode(), applicant.getVehicles().size());
		for (int i = 0; i < maximumVehiclesAllowed; i++) {
			String vehicleInfo = getTextFromElement(driver().findElement(By.xpath(VEHICLE_INFO_PARTIAL_XPATH + i + ":vehSpan']")));
			SqlVehicle expectedVehicle = applicant.getVehicles().get(i);
			String addTruck = (expectedVehicle.getVehicleMake().equals("FORD") && 
					(expectedVehicle.getVehicleType().contains("PICKUP") || expectedVehicle.getVehicleModel().contains("EXPEDITION")))?
					" TRUCK ": SPACE;
			String vehicle = expectedVehicle.getVehicleYear() + SPACE + expectedVehicle.getVehicleMake() + addTruck + expectedVehicle.getVehicleModel();
			String vehicleOwnership = expectedVehicle.getOwnership();
			boolean foundVehicleOwnership = vehicleInfo.contains(vehicleOwnership);
			if (!foundVehicleOwnership && vehicleOwnership.equals("Leased")) {
				foundVehicleOwnership = vehicleInfo.contains("Financed");
			}
			// This vehicle (AUDI A4 QUATTRO 4D 2.0T PRM PLUS) is being abbreviated in some states, better not check for it
			if (!vehicleInfo.contains("QUATTRO")) {
				fsa.assertTrue(vehicleInfo.contains(vehicle), "Vehicle " + Integer.toString(i+1) + ": " + vehicle + " found in " + vehicleInfo);
			}
			fsa.assertTrue(foundVehicleOwnership, vehicleOwnership + " for " + vehicle);
		}
	}

	private void verifyDrivers(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		Log.info("Verifying drivers...");
		String driverFirstName = getTextFromElement(driver().findElement(By.xpath(DRIVER_INFO_PARTIAL_XPATH + "0:firstName']"))).toLowerCase();
		String driverLastName = getTextFromElement(driver().findElement(By.xpath(DRIVER_INFO_PARTIAL_XPATH + "0:lastName']"))).toLowerCase();
		fsa.assertEquals(driverFirstName, applicant.getFirstName().toLowerCase(), "PNI first name");
		fsa.assertEquals(driverLastName, applicant.getLastName().toLowerCase(), "PNI last name");
    	int numberOfAdditionalDrivers = applicant.getAdditionalDrivers().size();
		for (int i = 0; i < numberOfAdditionalDrivers && i< MAX_NUMBER_OF_ADDITIONALDRIVERS; i++) {
			driverFirstName = getTextFromElement(driver().findElement(By.xpath(DRIVER_INFO_PARTIAL_XPATH + (i+1) + ":firstName']"))).toLowerCase();
			driverLastName = getTextFromElement(driver().findElement(By.xpath(DRIVER_INFO_PARTIAL_XPATH + (i+1) + ":lastName']"))).toLowerCase();
			SqlAdditionalDriver expectedAdditionalDriver = applicant.getAdditionalDrivers().get(i);
			fsa.assertEquals(driverFirstName, expectedAdditionalDriver.getFirstName().toLowerCase(), "Additional driver " + i+1+ " first name");
			fsa.assertEquals(driverLastName, expectedAdditionalDriver.getLastName().toLowerCase(), "Additional driver " + i+1+ " last name");
		}
	}

	private void verifyPolicyStartDate(SqlApplicant applicant, FarmersSoftAssert fsa)  throws Exception {
		Log.info("Verifying policy start date...");
		String date = getAttributeData(driver().findElement(By.id("additionalInfo:effDate")), VALUE);
		String policyStartDateFromDB = applicant.getCurrentInsuranceExpirationDate();
		convertDateAndCompare(date, policyStartDateFromDB, "Comparing that policy start date on form:<", fsa);
	}

	private void convertDateAndCompare(String date, String dateFromDB, String message, FarmersSoftAssert fsa) {
		String month = dateFromDB.substring(0, 2);
		String day = dateFromDB.substring(2, 4);
		String year = dateFromDB.substring(4, 8);
		dateFromDB = month + "/" + day + "/" + year;
		fsa.assertEquals(date, dateFromDB, message + date + "> matches <" + dateFromDB +">");
	}

	private void enterVehicleInformation(SqlApplicant applicant) throws Exception {
		Log.info("Entering vehicle(s) information...");
		int maximumVehiclesAllowed = limitVehicleCountToMaxAllowed(applicant.getStateCode(), applicant.getVehicles().size());
		for (int i = 0; i < maximumVehiclesAllowed; i++) {
			SqlVehicle expectedVehicle = applicant.getVehicles().get(i);
			enterVehicleIdentificationNumber(expectedVehicle, i);
			if (isFlexState(applicant.getStateCode()) && !isBristolWestQuote) {
				enterVehiclePurchaseDate(expectedVehicle, i);
			}
			String ownershipStatus = expectedVehicle.getOwnership();
			if(ownershipStatus.equalsIgnoreCase("Leased") || ownershipStatus.equalsIgnoreCase("Financed") ) {
				WebElement lessorName = driver().findElement(By.xpath(VEHICLE_INFO_PARTIAL_XPATH + i + ":leinHolder']"));
				waitElementBeVisible(lessorName);
				sendKeysToElement(lessorName, expectedVehicle.getLessor());
			}
			String parkedAtHomeRadioButtonXpath = VEHICLE_INFO_PARTIAL_XPATH + i + ":differentParkedAddress:1']";
			if (isElementPresentByXPath(parkedAtHomeRadioButtonXpath)) {
				WebElement parkedAtHomeRadioButton = driver().findElement(By.xpath(parkedAtHomeRadioButtonXpath));
				clickElement(parkedAtHomeRadioButton);
			}
			if(applicant.getStateCode().equalsIgnoreCase(CA)) {
				enterCurrentOdometer(expectedVehicle, i);
			}
		}
	}

	private void enterVehicleIdentificationNumber(SqlVehicle expectedVehicle, int vehicleIndex) throws Exception {
		Log.info("Entering VIN number for " + expectedVehicle.getVehicleMake() + SPACE + expectedVehicle.getVehicleModel());
		String vinElementPath = VEHICLE_INFO_PARTIAL_XPATH + vehicleIndex + ":VINValue']";
		WebElement vin = driver().findElement(By.xpath(vinElementPath));
		wait.until(presenceOfAllElementsLocatedBy(By.xpath(vinElementPath)));
		waitElementBeVisible(vin);
		if (!expectedVehicle.isUseVIN() && vin.isEnabled()) {
			sendKeysToElement(vin, expectedVehicle.getVehicleVIN());
		}
	}

	private void enterVehiclePurchaseDate(SqlVehicle expectedVehicle, int vehicleIndex) throws Exception {
		Log.info("Entering purchase date for " + expectedVehicle.getVehicleMake() + SPACE + expectedVehicle.getVehicleModel());
		String purchaseDateElementPath = VEHICLE_INFO_PARTIAL_XPATH + vehicleIndex + ":purchaseDate']";
		String purchaseDateFormatPath = purchaseDateElementPath + "/..//p[@class='effDateDesc']";
		WebElement purchaseDateEntryField = driver().findElement(By.xpath(purchaseDateElementPath));
		WebElement purchaseDateFormat = driver().findElement(By.xpath(purchaseDateFormatPath));
		waitElementBeVisible(purchaseDateEntryField);
		String vehiclePurchaseDate = expectedVehicle.getPurchaseDate();
		boolean isEightDigitDateField = getTextFromElement(purchaseDateFormat).equals("DD/MM/YYYY");
		if (isEightDigitDateField) {
			vehiclePurchaseDate = "01" + vehiclePurchaseDate;
		}
		sendKeysToElement(purchaseDateEntryField, vehiclePurchaseDate);		
	}

	private void enterCurrentOdometer(SqlVehicle expectedVehicle, int vehicleIndex) throws Exception {
		Log.info("Entering current odometer for " + expectedVehicle.getVehicleMake() + SPACE +  expectedVehicle.getVehicleModel());
		WebElement currentOdometer = driver().findElement(By.xpath(VEHICLE_INFO_PARTIAL_XPATH + vehicleIndex +":currentMileage']"));
		sendKeysToElement(currentOdometer, expectedVehicle.getCurrentOdometerReading());
	}

	private void enterDriverInformation(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		Log.info("Entering driver(s) information...");
		//Applicant Info
		int driverIndex = 0;
		verifyDateOfBirth(applicant.getDateOfBirth(), driverIndex, fsa);
		enterDriverLicense(applicant.getDriversLicense(), driverIndex);
		selectDriverLicenseIssueState(applicant.getLicenseIssueStateName(), driverIndex);
		if (isSignalApplicant(applicant) && !isBristolWestQuote) {
			scrollElementToMiddle(signalMobilePhoneNumber);
			sendKeysToElement(signalMobilePhoneNumber, applicant.getPhoneNumber());
		}
		//AdditionalDriver Info
		for (driverIndex = 1; driverIndex <= applicant.getAdditionalDrivers().size() && driverIndex <= MAX_NUMBER_OF_ADDITIONALDRIVERS; driverIndex++) {
			SqlAdditionalDriver additionalDriver = applicant.getAdditionalDrivers().get(driverIndex-1);
			verifyDateOfBirth(additionalDriver.getDateOfBirth(), driverIndex, fsa);
			if (additionalDriver.getLicenseToDriveInUSA() == null || additionalDriver.getLicenseToDriveInUSA().equals(YES) ||
					additionalDriver.getLicenseToDriveInUSA().equals(EMPTY_STRING)) {
				enterDriverLicense(additionalDriver.getDriversLicense(), driverIndex);
				selectDriverLicenseIssueState(additionalDriver.getLicenseIssueStateName(), driverIndex);
			}
			if (isSignalApplicant(applicant) && !isBristolWestQuote) {
				enterSignalMobileNumber(additionalDriver.getSignalMobilePhone(), driverIndex);
			}
			if (applicant.getStateCode().equals(MT)) {
				enterMontanaRequiredData(driverIndex);
			}
		}
		if (isElementPresentByID(agreeToSignalTerms) && !agreeToSignalTerms.isSelected()) {
			scrollAndClickOnElement(agreeToSignalTerms);
		}
	}

	private void enterMontanaRequiredData(int driverIndex) throws Exception {
		// Default to no on both questions
		String notActiveMemberOfMTNationalGuardRadioButtonPath = DRIVER_INFO_PARTIAL_XPATH + driverIndex + ":activeMemberMT:1']";
		String noSafetyCourseCompletedRadioButtonPath = DRIVER_INFO_PARTIAL_XPATH + driverIndex + ":safetyCourseMT:1']";
		WebElement notActiveMemberOfMTNationalGuardRadioButton = driver().findElement(By.xpath(notActiveMemberOfMTNationalGuardRadioButtonPath));
		scrollAndClickOnElement(notActiveMemberOfMTNationalGuardRadioButton);
		if (isElementPresentByXPath(noSafetyCourseCompletedRadioButtonPath)) {
			WebElement noSafetyCourseCompletedRadioButton = driver().findElement(By.xpath(noSafetyCourseCompletedRadioButtonPath));
			clickElement(noSafetyCourseCompletedRadioButton);
		}
	}

	private boolean isSignalApplicant(SqlApplicant applicant) {
		String stateCode = applicant.getStateCode();
		return applicant.getDiscounts().isSignalSignup() && (isFlexState(stateCode) || Arrays.asList(CO, IN, KS, MN, MO).contains(stateCode));
	}

	private void verifyDateOfBirth(String expectedDriverDateOfBirth, int driverIndex, FarmersSoftAssert fsa) throws Exception {
		Log.info("verifying driver's DOB...");
		String dobElementID = "additionalInfo:drvInfo:" + driverIndex + ":dobValue";
		wait.until(presenceOfElementLocated(By.id(dobElementID)));
		convertDateAndCompare(getTextFromElement(driver().findElement(By.id(dobElementID))), expectedDriverDateOfBirth, "Comparing that date of birth on form:<", fsa);
	}

	private void enterDriverLicense(String driverLicenseNumber, int driverIndex) throws Exception {
		String dlElementPathEnd = isBristolWestQuote ? ":licNum']" : ":hdnlicNum']";
		String driverLicenseElementPath = DRIVER_INFO_PARTIAL_XPATH + driverIndex + dlElementPathEnd;
		WebElement driverLicenseEntryField = driver().findElement(By.xpath(driverLicenseElementPath));
		wait.until(presenceOfAllElementsLocatedBy(By.xpath(driverLicenseElementPath)));
		sendKeysToElement(driverLicenseEntryField, driverLicenseNumber);
	}

	private void selectDriverLicenseIssueState(String driverLicenseIssuingState, int driverIndex) throws Exception {
		String driverLicenseIssueStateElementPath = DRIVER_INFO_PARTIAL_XPATH + driverIndex + ":licState']";
		WebElement driverLicenseIssueStateDropdown = driver().findElement(By.xpath(driverLicenseIssueStateElementPath));
		clickElement(driverLicenseIssueStateDropdown);
		wait.until(presenceOfAllElementsLocatedBy(By.xpath(driverLicenseIssueStateElementPath)));
		selectFromDropDown(driverLicenseIssueStateDropdown, driverLicenseIssuingState);
		String driverLicenseIssueStateLabelPath = DRIVER_INFO_PARTIAL_XPATH + driverIndex + ":licStateLbl']";
		WebElement driverLicenseIssueStateLabel = driver().findElement(By.xpath(driverLicenseIssueStateLabelPath));
		clickElement(driverLicenseIssueStateLabel);
	}

	private void enterSignalMobileNumber(String signalMobilePhoneNumber, int driverIndex) throws Exception {
		scrollToElementBottom(continueToPaymentButton);
		String signalMobileNumberElementPath = "additionalInfo:signalInfo:" + driverIndex + ":signalMobNum";
		WebElement additionalDriverSignalMobilePhoneNumber = driver().findElement(By.id(signalMobileNumberElementPath));
		scrollElementToMiddle(additionalDriverSignalMobilePhoneNumber);
		sendKeysToElement(additionalDriverSignalMobilePhoneNumber, signalMobilePhoneNumber);
		String signalMobileNumberLabelPath ="additionalInfo:signalInfo:" + driverIndex + ":signalMobileNum";
		WebElement additionalDriverSignalMobilePhoneNumberLabel = driver().findElement(By.id(signalMobileNumberLabelPath));
		clickElement(additionalDriverSignalMobilePhoneNumberLabel);	
	}

	public void selectContinueToPaymentButton() {
		Log.info("Selecting Continue To Payment button");
		scrollAndClickOnElement(additionalInformationPageHeader);
		scrollAndClickOnElement(continueToPaymentButton);
		if (isElementPresent(By.id("BwPopup"), 3)) {
			clickElement(bwInfoPopupYesButton);
		}
		waitForSpinnerToBeGone();
		if (isBrightlinedQuote()) {
			continueToBristolWest(true);
			isBristolWest = true;
			waitForSpinnerToBeGone();
		}
		if(isElementPresentByXPath(CONTINUE_TO_PAYMENT_BUTTON_XPATH)) {
			clickElement(continueToPaymentButton);
		}
	}
}
