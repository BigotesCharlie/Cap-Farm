package com.farmers.ffq.auto.pages;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class StartQuotePage extends BasePage {


    @FindBy(css = "div.mat-select-arrow-wrapper")
    private WebElement dropdownArrow;

    @FindBy(xpath = "//mat-option[./span[text() = 'Auto']]")
    private WebElement autoDropDownOption;

    @FindBy(css = "input[formcontrolname]")
    private WebElement zipCodeInput;

    @FindBy(xpath = "//button[text()='START QUOTE']")
    private WebElement startQuoteButton;



    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public StartQuotePage() throws Exception {
        String url = Property.getUri();
        driver().manage().deleteAllCookies();
        Log.info("\n\t\tNavigating to " + url);
        try {
            driver().navigate().to(url);
        } catch (TimeoutException te) {
            driver().navigate().refresh();
            driver().navigate().to(url);
        }
        WebDriver driver = driver();
        PageFactory.initElements(driver, this);
    }

    public void startQuote(AutoApplicant autoApplicant) {
        startQuote(autoApplicant.getZipCode());
    }

    public void startQuote(String zipCode) {
        waitAndClickElement(dropdownArrow);
        waitAndClickElement(autoDropDownOption);
        enterValueInField(zipCode, zipCodeInput, "Entering ZipCode: ");
        startQuoteButton.click();
    }
}
