package com.farmers.ffq.ace.home;

import static com.farmers.ffq.utils.GlobalVariables.EMPTY_STRING;
import static com.farmers.ffq.utils.GlobalVariables.FOREMOST;
import static com.farmers.ffq.utils.GlobalVariables.HOME;
import static com.farmers.ffq.utils.GlobalVariables.LOB_HOME;
import static com.farmers.ffq.utils.GlobalVariables.MEDIA_ALPHA;
import static com.farmers.ffq.utils.GlobalVariables.NEWLINE;
import static com.farmers.ffq.utils.GlobalVariables.SPACE;

import com.farmers.ffq.ace.hrc.common.AceHRCAddressContactBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCNameAndDobBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyTypeBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class AceSpecialtyDwellingNavigationHelper extends AceHomeNavigationHelper {

    public AceSpecialtyDwellingNavigationHelper() throws Exception {
        super();
    }

    public AceHRCPropertyTypeBasePage navigateToDwellingTypePage(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
    	boolean isMediaAlpha = MEDIA_ALPHA.equals(specialtyDwellingApplicant.getTestCategory());
		AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
        if (getResumeFromPage().equals(propertyTypePage.getClass().getSimpleName())) {
            return propertyTypePage;
        }
		if (isMediaAlpha) {
			processPartnerFlowPage(specialtyDwellingApplicant, LOB_HOME, true);
		} else {
			propertyTypePage = navigateToAceHomePropertyTypePage(specialtyDwellingApplicant);
		}
		if (propertyTypePage.isOnPropertyTypePage()) {
			if (isMediaAlpha) {
				specialtyDwellingApplicant.setQuoteNumber(propertyTypePage.getSessionStorageAppStore().getData().getQuoteNumber());
				Reporter.pass("Quote #: " + specialtyDwellingApplicant.getQuoteNumber());
			}
			Reporter.pass("Navigated to Dwelling Type page");
			return propertyTypePage;
		} else {
			throw new NavigationException(propertyTypePage.getClass().getSimpleName(), specialtyDwellingApplicant);
		}
    }

    public AceSpecialtyDwellingTellUsMorePage navigateToDwellingDetailsPage(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
    	AceSpecialtyDwellingTellUsMorePage tellUsMorePage = new AceSpecialtyDwellingTellUsMorePage();
        if (getResumeFromPage().equals(tellUsMorePage.getClass().getSimpleName())) {
            return tellUsMorePage;
        }
        if (FOREMOST.equals(specialtyDwellingApplicant.getTestCategory())) {
        	processForemostLaunchPage(specialtyDwellingApplicant.getZipCode(), specialtyDwellingApplicant.getReasonWhyNotPrimaryResidence());
        	specialtyDwellingApplicant.setQuoteNumber(tellUsMorePage.getSessionStorageAppStore().getData().getQuoteNumber());
        	Reporter.pass("Quote #: " + specialtyDwellingApplicant.getQuoteNumber());
        	Reporter.pass("Navigated to Name and DOB page");
        	new AceHRCNameAndDobBasePage().fillOutNameAndDobPage(specialtyDwellingApplicant);
        	waitForSpinnerToBeGone();
        	Reporter.pass("Navigated to Address and Contact info page");
        	new AceHRCAddressContactBasePage().fillOutAddressContactPage(specialtyDwellingApplicant);
        } else {
        	AceHRCPropertyTypeBasePage propertyTypePage = navigateToDwellingTypePage(specialtyDwellingApplicant);
        	propertyTypePage.fillOutPropertyType(specialtyDwellingApplicant, HOME);
        }
        waitForSpinnerToBeGone();
		if (tellUsMorePage.isOnTellUsMorePage()) {
			Reporter.pass("Navigated to Dwelling Details page");
			return tellUsMorePage;
		} else {
			throw new NavigationException(tellUsMorePage.getClass().getSimpleName(), specialtyDwellingApplicant);
		}
    }

    public AceSpecialtyDwellingAdditionalInfoPage navigateToAdditionalDwellingInformationPage(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
    	AceSpecialtyDwellingAdditionalInfoPage additionalDwellingInfoPage = new AceSpecialtyDwellingAdditionalInfoPage();
        if (getResumeFromPage().equals(additionalDwellingInfoPage.getClass().getSimpleName())) {
            return additionalDwellingInfoPage;
        }
        AceSpecialtyDwellingTellUsMorePage tellUsMorePage = navigateToDwellingDetailsPage(specialtyDwellingApplicant);
		tellUsMorePage.fillOutPageAndContinue(specialtyDwellingApplicant);
		if (additionalDwellingInfoPage.isOnAdditionalInfoPage()) {
			Reporter.pass("Navigated to Dwelling Additional Information page");
			return additionalDwellingInfoPage;
		} else {
			throw new NavigationException(additionalDwellingInfoPage.getClass().getSimpleName(), specialtyDwellingApplicant);
		}
    }

    public AceSpecialtyDwellingOtherPolicyQuestionsPage navigateToOtherPolicyQuestionsPage(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
    	AceSpecialtyDwellingOtherPolicyQuestionsPage otherPolicyQuestionsPage = new AceSpecialtyDwellingOtherPolicyQuestionsPage();
        if (getResumeFromPage().equals(otherPolicyQuestionsPage.getClass().getSimpleName())) {
            return otherPolicyQuestionsPage;
        }
        AceSpecialtyDwellingAdditionalInfoPage additionalDwellingInfoPage =  navigateToAdditionalDwellingInformationPage(specialtyDwellingApplicant);
        additionalDwellingInfoPage.fillOutSpecialtyDwellingAdditionalInfoPage(specialtyDwellingApplicant);
		if (otherPolicyQuestionsPage.isOnContactInfoPage(false)) {
			Reporter.pass("Navigated to Dwelling Other Policy Questions page");
			return otherPolicyQuestionsPage;
		} else {
			throw new NavigationException(otherPolicyQuestionsPage.getClass().getSimpleName(), specialtyDwellingApplicant);
		}
	}

    public AceSpecialtyDwellingQuoteReviewPage navigateToAceSpecialtyDwellingReviewQuotePage(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
    	AceSpecialtyDwellingQuoteReviewPage reviewQuotePage = new AceSpecialtyDwellingQuoteReviewPage(specialtyDwellingApplicant);
        if (getResumeFromPage().equals(reviewQuotePage.getClass().getSimpleName())) {
        	return reviewQuotePage;
        }
        AceSpecialtyDwellingOtherPolicyQuestionsPage otherPolicyQuestionsPage = navigateToOtherPolicyQuestionsPage(specialtyDwellingApplicant);
        otherPolicyQuestionsPage.fillOutPageAndContinue(specialtyDwellingApplicant);
        if (reviewQuotePage.isOnSpecialtyDwellingQuotePage()) {
            Reporter.pass("Navigated to Dwelling Review Quote page");
			try {
				ObjectMapper mapper = new ObjectMapper();
				mapper.enable(SerializationFeature.INDENT_OUTPUT);
				String json = mapper.writeValueAsString(getSessionStorageAppStore());
				writeDataToQuoteLogFile(specialtyDwellingApplicant.getTestCategory() + " : " + json);
			} catch (Exception e) {
				writeDataToQuoteLogFile(specialtyDwellingApplicant.getTestCategory() + " Exception - : " + getSessionStorageAppStore());
			}
            return reviewQuotePage;
        } else {
        	throw new NavigationException(reviewQuotePage.getClass().getSimpleName(), specialtyDwellingApplicant);
        }
    }

	private class NavigationException extends Exception {
		private static final long serialVersionUID = 1L;

		public NavigationException(String originatingPage, ApplicantAceHome specialtyDwellingApplicant) throws Exception {
			String message = DID_NOT_REACH + originatingPage + NEWLINE;
			try {
				ObjectMapper mapper = new ObjectMapper();
				mapper.enable(SerializationFeature.INDENT_OUTPUT);
				String json = mapper.writeValueAsString(getSessionStorageAppStore());
				writeDataToQuoteLogFile(message + " : " + json);
			} catch (IllegalArgumentException iae) {
				Log.warn("problem reading appstore: " + iae.getMessage());
			} catch (Exception e) {
				Log.warn("EXCEPTION while beautifying appstore");
				writeDataToQuoteLogFile(message + " Exception - : " + getSessionStorageAppStore());
			}
			StringBuilder errorMessageString = new StringBuilder();
			try {
				AppStore.Home home = getSessionStorageAppStore().getHome();
				if (home != null) {
					if (home.getQuote()!= null && home.getQuote().getRateQuoteResponses() !=null && home.getQuote().getRateQuoteResponses().get(0).getKnockOutBeanList() != null) {
						errorMessageString.append(home.getQuote().getRateQuoteResponses().get(0).getKnockOutBeanList().get(0).toString() + SPACE);
					} else  {
						getErrorInformation(errorMessageString);
					}
				} else {
					getErrorInformation(errorMessageString);
				}
				writeDataToQuoteLogFile(message + " Exception - : " + getSessionStorageAppStore());
			} catch (IllegalArgumentException iae) {
			}
			if (!errorMessageString.toString().isEmpty()) {
				message =  message + " -- Knocked out reason: " +  errorMessageString.toString();
			}
			throw new IllegalStateException(message);
		}

		private void getErrorInformation(StringBuilder errorMessageString) throws Exception {
			AppStore.Error error = getSessionStorageAppStore().getError();
			if (error != null && error.getErrorInfo() != null  && error.getErrorInfo().getErrorCode() != null) {
				String errorMessage = error.getErrorInfo().getErrorMessage() != null ? error.getErrorInfo().getErrorMessage() :
					error.getMessage() != null? error.getMessage() : EMPTY_STRING;
				errorMessageString.append(error.getErrorInfo().getErrorCode() + ": " + errorMessage);
			}
		}
	}

}
