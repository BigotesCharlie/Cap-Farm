package com.farmers.ffq.ace.hrc.common;

import com.farmers.ffq.common.pages.ForemostStartPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.common.pages.MediaAlphaPageHome;
import com.farmers.ffq.common.pages.MediaAlphaStartPage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.CSSToFFQAceApplicant;
import com.farmers.ffq.datatransferobjects.ToggleApplicant;
import com.farmers.ffq.utils.AESHelper;
import com.farmers.framework.Property;
import com.farmers.framework.driver.Driver;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.Setter;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter
public class AceHRCNavigationHelperBasePage extends AceHRCBasePage {
	public static final String DID_NOT_REACH = "Did not reach ";
    public static final String FAILED_RC2 = "FailedRC2";
    public static final String FAILED_RC3 = "FailedRC3";

    @Setter
    public String resumeFromPage = EMPTY_STRING;

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public AceHRCNavigationHelperBasePage() throws Exception {
	}

	public void processLandingPage(ApplicantAceHome applicant, String lob) throws Exception {
		lob = lob.equals(LOB_CONDO) ? LOB_HOME : lob;
		if (applicant.getAgentId()!=null && !applicant.getAgentId().isEmpty()) {
			new LandingPage(String.format(Property.getUri() + "?Lob=%s&Source_Indicator=AP&State_Code=%s&Agent_Code=%s&Zip_Code=%s",
                    lob.charAt(0), applicant.getStateCode(), applicant.getAgentId(), applicant.getZipCode()), isUseMobileViewEnabled());
			Reporter.pass("Application launched in AWS mode");
		} else {
			new LandingPage(isUseMobileViewEnabled(), true).enterLandingPageData(lob, applicant.getZipCode());
		}
	}

	public void processPartnerFlowPage(ApplicantAceHome applicant, String lob, boolean newApplicant) throws Exception {
		if (MEDIA_ALPHA.equals(applicant.getTestCategory())) {
			new MediaAlphaStartPage().processMediaAlphaStartPage(applicant.getZipCode(), HOME);
			MediaAlphaPageHome mediaAlphaPageHome = new MediaAlphaPageHome();
			if (mediaAlphaPageHome.isOnMediaAlphaPageHome()) {
				Reporter.pass("Application launched in Media Alpha mode");
				mediaAlphaPageHome.enterHomeApplicantData(applicant);
			}
		} else {
			ToggleApplicant toggleApplicant = new ToggleApplicant(applicant, lob, newApplicant);
			String url = Property.getUri() + "?param=";
			ObjectMapper mapper = new ObjectMapper();
			String customerData = mapper.writeValueAsString(toggleApplicant);
			Log.info("Customer Data:"  + customerData);
			url += AESHelper.encryptToggle(customerData) + "&Flow=TG&SRC=TOGREHBZFQ";
			Log.info("Navigating to: " + url);
			driver().navigate().to(url);
			if (isUseMobileViewEnabled()) {
				driver().manage().window().setSize(Driver.MOBILE);
			} else {
				driver().manage().window().maximize();
			}
		}
		waitForSpinnerToBeGone();
		acceptCookies();
	}

	public void processForemostLaunchPage(String zipcode, String lobOrProduct) throws Exception {
		new ForemostStartPage().processForemostStartPage(zipcode, lobOrProduct);
		waitForSpinnerToBeGone();
		if (new KnockoutInconveniencePage().isOnForemostKnockoutPage()) {
			throw new IllegalStateException("Knocked out when launching in Foremost mode");
		}
		Reporter.pass("Application launched in Foremost mode");
	}

    public void processSweepStakesCampaign(ApplicantAceHome applicant, String lob, String source_indicator, String source_id) throws Exception {
        String campaignUri = String.format(Property.getUri() + "?Lob=%s&Zip_Code=%s&source_indicator=%s&source_id=%s", lob,
                applicant.getZipCode(), source_indicator, source_id);
        Log.info("Navigating to " + campaignUri);
        driver().get(campaignUri);
        if (isUseMobileViewEnabled()) {
            driver().manage().window().setSize(Driver.MOBILE);
        } else {
            driver().manage().window().maximize();
        }
        acceptCookies();
    }

	public void processCSSToFFQFlowPage(ApplicantAceHome applicant, String lob) throws Exception {
		CSSToFFQAceApplicant cssToFFQAceApplicant = new CSSToFFQAceApplicant(applicant, lob);
		String url = Property.getUri().replace("/fastquote", "/quote") + "?param=";

		ObjectMapper mapper = new ObjectMapper();
		String customerData = mapper.writeValueAsString(cssToFFQAceApplicant);
		Log.info("Customer Data:"  + customerData);
		String value = AESHelper.encryptWithOutIV(customerData);
		url += URLEncoder.encode(value, StandardCharsets.UTF_8);
		if (!applicant.getAgentId().isBlank()) {
			url += "&Flow=CF&Lob=Home&AOR=" + applicant.getAgentId() + "&SRC=MV000000001";
		} else {
			url += "&Flow=CF&Lob=Home&SRC=MV000000001";
		}
		Log.info("Navigating to: " + url);
		driver().get(url);
		if (isUseMobileViewEnabled()) {
			driver().manage().window().setSize(Driver.MOBILE);
		} else {
			driver().manage().window().maximize();
			driver().navigate().refresh();
		}
		acceptCookies();
	}

	public void retrieveQuoteByQuoteNumber(ApplicantAceHome applicant) throws Exception {
		new LandingPage(isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant.getLastName(), applicant.getDateOfBirth(), applicant.getQuoteNumber(), applicant.getZipCode());
		testStep("Retrieve quote by quote number: " + applicant.getQuoteNumber(), false);
	}

	public void retrieveQuoteByEmail(ApplicantAceHome applicant) throws Exception {
		new LandingPage(isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant.getLastName(), applicant.getDateOfBirth(), applicant.getEmailAddress(), applicant.getZipCode());
		testStep("Retrieve quote by email: " + applicant.getEmailAddress(), false);
	}

	protected AceHRCPropertyTypeBasePage navigateToHRCPropertyTypePage(ApplicantAceHome applicant, String lob) throws Exception {
		if (getResumeFromPage().equals("PropertyTypePage")) {
            AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
            if (propertyTypePage.quickIsOnPropertyTypePageCheck()) {
                return propertyTypePage;
            } else {
                throw new IllegalStateException(DID_NOT_REACH + "PropertyTypePage");
            }
		}
		if (isNewFlowEnabledState(applicant.getStateCode())) {
			AceHRCAddressContactBasePage addressContactBasePage = navigateToAceHRCAddressContactBasePage(applicant, lob);
			addressContactBasePage.fillOutAddressContactPage(applicant);
			waitForSpinnerToBeGone();
		} else {
			processLandingPage(applicant, lob);
		}
		AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
		if (propertyTypePage.isOnPropertyTypePage()) {
			applicant.setQuoteNumber(propertyTypePage.getSessionStorageAppStore().getData().getQuoteNumber());
			if (isADATestingEnabled()) {
				if (lob.equals(LOB_HOME)) {
					performADATesting(propertyTypePage.getClass().getSimpleName(), MARKETING_IT, FFQ_ACE_HOME);
				}
			}
			Reporter.pass("Navigated to PropertyTypePage for quote " + applicant.getQuoteNumber());
			return propertyTypePage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "PropertyTypePage");
		}
	}

	protected AceHRCNameAndDobBasePage navigateToAceHRCNameAndDobBasePage(ApplicantAceHome applicant, String lob) throws Exception {
		AceHRCNameAndDobBasePage nameAndDobBasePage = new AceHRCNameAndDobBasePage();
		if (getResumeFromPage().equals(NAME_AND_DOB_PAGE)) {
			return nameAndDobBasePage;
		}
		processLandingPage(applicant, lob);
		waitForPageToBeReady();
		if (nameAndDobBasePage.isOnNameAndDobPage(false)) {
			Reporter.pass("Navigated to Name and DOB Page");
			if (applicant.getQuoteNumber() == null) {
				String quoteNumber = nameAndDobBasePage.getSessionStorageAppStore().getData().getQuoteNumber();
				Log.info(NEW_QUOTE_NUMBER + quoteNumber, true);
				applicant.setQuoteNumber(quoteNumber);
			}
			return nameAndDobBasePage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + NAME_AND_DOB_PAGE + SPACE + lob);
		}
	}

	protected AceHRCAddressContactBasePage navigateToAceHRCAddressContactBasePage(ApplicantAceHome applicant, String lob) throws Exception {
		AceHRCAddressContactBasePage addressContactBasePage = new AceHRCAddressContactBasePage();
		if (getResumeFromPage().equals(ADDRESS_CONTACT_PAGE)) {
			return addressContactBasePage;
		}
		AceHRCNameAndDobBasePage nameAndDobBasePage = navigateToAceHRCNameAndDobBasePage(applicant, lob);
		nameAndDobBasePage.fillOutNameAndDobPage(applicant);
		waitForPageToBeReady();
		if (addressContactBasePage.isOnAddressContactPage(false)) {
			Reporter.pass("Navigated to Address Contact Page");
			return addressContactBasePage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + ADDRESS_CONTACT_PAGE + SPACE + lob);
		}
	}

	protected AceHRCPropertyInfoBasePage navigateToAceHRCPropertyInfoBasePage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
		AceHRCPropertyInfoBasePage propertyInfoBasePage = new AceHRCPropertyInfoBasePage();
		if (getResumeFromPage().equals(PROPERTY_INFO)) {
			return propertyInfoBasePage;
		}
		AceHRCPropertyTypeBasePage propertyTypeBasePage = navigateToHRCPropertyTypePage(applicant, lob);
		propertyTypeBasePage.fillOutPropertyType(applicant, propertyType);
		waitForPageToBeReady();
		if (propertyInfoBasePage.isOnPropertyInfoPage(false)) {
			Reporter.pass("Navigated to Property info Page");
			return propertyInfoBasePage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + PROPERTY_INFO + SPACE + lob);
		}
	}

	protected AceHRCAddressBasePage navigateToHRCAddressPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
		AceHRCAddressBasePage addressPage = new AceHRCAddressBasePage();
		if (getResumeFromPage().equals(ADDRESS_PAGE)) {
			return addressPage;
		}
        processLandingPage(applicant, lob);
        waitForPageToBeReady();
        if (addressPage.isOnAddressPage(false)) {
            Reporter.pass("Navigated to AddressPage");
        } else {
            AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
            if (propertyTypePage.quickIsOnPropertyTypePageCheck()) {
                propertyTypePage.fillOutPropertyType(applicant, propertyType);
            }
        }
        if (addressPage.isOnAddressPage(true)) {
			Reporter.pass("Navigated to AddressPage");
			if (applicant.getQuoteNumber() == null) {
				String quoteNumber = addressPage.getSessionStorageAppStore().getData().getQuoteNumber();
				Log.info(NEW_QUOTE_NUMBER + quoteNumber, true);
				applicant.setQuoteNumber(quoteNumber);
			}
			writeCreatedQuoteInformationToFile("Ace " + lob + " - " + applicant.getQuoteNumber() + SPACE + applicant.getFirstName() + SPACE + applicant.getLastName() +
					SPACE + applicant.getAddress() + SPACE + applicant.getCity() + SPACE + applicant.getStateCode() + SPACE + applicant.getZipCode());
			if (isADATestingEnabled()) {
				if (lob.equals(LOB_CONDO)) {
					addressPage.validateADA(FFQ_ACE_CONDO);
				} else if (lob.equals(LOB_RENTERS)) {
					addressPage.validateADA(FFQ_ACE_RENTERS);
				} else {
					addressPage.validateADA(FFQ_ACE_HOME);
				}
			}
			return addressPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AddressPage " + lob);
		}
	}

	public AceHRCQualityGradeBasePage navigateToHRCPropertyDetailsQualityGradePage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
		AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
		if (getResumeFromPage().equals(QUALITY_GRADE)) {
			return qualityGradePage;
		}
		if (isNewFlowEnabledState(applicant.getStateCode())) {
			AceHRCPropertyInfoBasePage propertyInfoBasePage = navigateToAceHRCPropertyInfoBasePage(applicant, lob, propertyType);
			propertyInfoBasePage.fillOutPropertyInfo(applicant, propertyType);
		} else {
			AceHRCAddressBasePage addressPage = navigateToHRCAddressPage(applicant, lob, propertyType);
			addressPage.fillOutAddressPage(applicant);
		}
		AceHRCPropertyBasePage propertyBasePage = new AceHRCPropertyBasePage();
		if (propertyBasePage.isOnHRCPropertyBasePage(false)) {
			if (isADATestingEnabled()) {
				if (lob.equals(LOB_CONDO)) {
					propertyBasePage.validateADA(FFQ_ACE_CONDO);
				} else if (lob.equals(LOB_RENTERS)) {
					propertyBasePage.validateADA(FFQ_ACE_RENTERS);
				} else {
					propertyBasePage.validateADA(FFQ_ACE_HOME);
				}
			}
			sleep(3);
			propertyBasePage.enterPropertyPageFields(applicant);
			propertyBasePage.clickContinueButton();
		}
		if (isTryAgainPagePresent()) {
			wasTryAgainSuccessful();
		}
		AceHRCQualityGradeBasePage aceHRCQualityGradeBasePage = new AceHRCQualityGradeBasePage();
		if (aceHRCQualityGradeBasePage.isQualityGradePageAlone()) {
			aceHRCQualityGradeBasePage.fillOutQualityGradePage(applicant, getSessionStorageAppStore().getHome().getHomeQualityGradeForm());
			aceHRCQualityGradeBasePage.clickContinueButton();
			AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
			if (propertyDetailsPage.isOnPropertyDetailsPage()) {
				if (isADATestingEnabled()) {
					if (lob.equals(LOB_CONDO)) {
						propertyDetailsPage.validateADA(FFQ_ACE_CONDO);
					} else if (lob.equals(LOB_RENTERS)) {
						propertyDetailsPage.validateADA(FFQ_ACE_RENTERS);
					} else {
						propertyDetailsPage.validateADA(FFQ_ACE_HOME);
					}
				}
				Reporter.pass("Navigated to Property Details Page", true);
				return aceHRCQualityGradeBasePage;
			} else {
				throw new IllegalStateException(DID_NOT_REACH + "Property Details Page");
			}
		} else {
			if (aceHRCQualityGradeBasePage.isOnPropertyDetailsQualityGradePage(false)) {
				if (isADATestingEnabled()) {
					if (lob.equals(LOB_CONDO)) {
						aceHRCQualityGradeBasePage.validateADA(FFQ_ACE_CONDO);
					} else {
						aceHRCQualityGradeBasePage.validateADA(FFQ_ACE_HOME);
					}
				}
				Reporter.pass("Navigated to Property details + Quality grade page", true);
				return aceHRCQualityGradeBasePage;
			} else {
				throw new IllegalStateException(DID_NOT_REACH + "Property Details + Quality grade page");
			}
		}
	}

	public AceHRCQualityGradeBasePage navigateToHRCQualityGradePage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
		AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
		if (getResumeFromPage().equals(QUALITY_GRADE)) {
			return qualityGradePage;
		}
		if (isNewFlowEnabledState(applicant.getStateCode())) {
			AceHRCPropertyInfoBasePage propertyInfoBasePage = navigateToAceHRCPropertyInfoBasePage(applicant, lob, propertyType);
			propertyInfoBasePage.fillOutPropertyInfo(applicant, propertyType);
		} else {
			AceHRCAddressBasePage addressPage = navigateToHRCAddressPage(applicant, lob, propertyType);
			addressPage.fillOutAddressPage(applicant);
		}
		AceHRCPropertyBasePage propertyBasePage = new AceHRCPropertyBasePage();
		if (propertyBasePage.isOnHRCPropertyBasePage(false)) {
			if (isADATestingEnabled()) {
				if (lob.equals(LOB_CONDO)) {
					propertyBasePage.validateADA(FFQ_ACE_CONDO);
				} else if (lob.equals(LOB_RENTERS)) {
					propertyBasePage.validateADA(FFQ_ACE_RENTERS);
				} else {
					propertyBasePage.validateADA(FFQ_ACE_HOME);
				}
			}
			sleep(3);
			propertyBasePage.enterPropertyPageFields(applicant);
			propertyBasePage.clickContinueButton();
		}
		AceHRCQualityGradeBasePage aceHRCQualityGradeBasePage = new AceHRCQualityGradeBasePage();
		if (aceHRCQualityGradeBasePage.isOnQualityGradeOrPropertyDetailsAndQualityCombined(true)) {
			if (isADATestingEnabled()) {
				if (lob.equals(LOB_CONDO)) {
					aceHRCQualityGradeBasePage.validateADA(FFQ_ACE_CONDO);
				} else {
					aceHRCQualityGradeBasePage.validateADA(FFQ_ACE_HOME);
				}
			}
			Reporter.pass("Navigated to Quality grade page");
			return aceHRCQualityGradeBasePage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "Quality grade page");
		}
	}

	public AceHRCPropertyDetailsBasePage navigateToHRCPropertyDetailsPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
		AceHRCPropertyDetailsBasePage propertyDetailsBasePage = new AceHRCPropertyDetailsBasePage();
		if (getResumeFromPage().equals(PROPERTY_DETAILS)) {
			return propertyDetailsBasePage;
		}
		navigateToHRCQualityGradePage(applicant, lob, propertyType);
		(new AceHRCQualityGradeBasePage()).fillOutQualityGradePage(applicant, getSessionStorageAppStore().getHome().getHomeQualityGradeForm());
		clickContinueButton();
		if (propertyDetailsBasePage.isOnPropertyDetailsPage()) {
			if (isADATestingEnabled()) {
				propertyDetailsBasePage.validateADA(FFQ_ACE_HOME);
			}
			Reporter.pass("Navigated to Property Details Page");
			return propertyDetailsBasePage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "Property Details Page");
		}
	}

	protected AceHRCAdditionalInfoBasePage navigateToHRCAdditionalInfoPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
		AceHRCAdditionalInfoBasePage additionalInfoPage = new AceHRCAdditionalInfoBasePage();
		if (getResumeFromPage().equals(ADDITIONAL_INFO)) {
			return additionalInfoPage;
		}
		AceHRCQualityGradeBasePage qualityGradePage = navigateToHRCPropertyDetailsQualityGradePage(applicant, lob, propertyType);
		if (qualityGradePage.isOnPropertyDetailsQualityGradePage(false)) {
			qualityGradePage.fillOutQualityGradePage(applicant, getSessionStorageAppStore().getHome().getHomeQualityGradeForm());
		}
		AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
		propertyDetailsPage.enterPropertyDetails(applicant);
		propertyDetailsPage.clickContinueButton();
		if (additionalInfoPage.isOnAdditionalInfoPage()) {
			if (isADATestingEnabled()) {
				additionalInfoPage.validateADA(FFQ_ACE_HOME);
			}
			Reporter.pass("Navigated to AdditionalInfoPage");
			return additionalInfoPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AdditionalInfoPage");
		}
	}

	protected AceHRCAboutYouBasePage navigateToHRCAboutYouPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
		AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
		if (getResumeFromPage().equals(ABOUT_YOU)) {
			return aboutYouPage;
		}
		navigateToHRCAdditionalInfoPage(applicant, lob, propertyType).fillOutAdditionalInfoPageHomeLob(applicant, true);
		if (aboutYouPage.isOnAboutYouPage(true)) {
			if (isADATestingEnabled()) {
				aboutYouPage.validateADA(FFQ_ACE_HOME);
			}
			Reporter.pass("Navigated to AboutYouPage");
			return aboutYouPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AboutYouPage");
		}
	}

	public AceHRCContactInfoBasePage navigateToAceHRCContactInfoPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
		AceHRCContactInfoBasePage contactInfoPage = new AceHRCContactInfoBasePage();
		if (getResumeFromPage().equals(CONTACT_INFO)) {
			return contactInfoPage;
		}
		if (isNewFlowEnabledState(applicant.getStateCode())) {
			AceHRCAdditionalInfoBasePage additionalInfoBasePage = navigateToHRCAdditionalInfoPage(applicant, lob, propertyType);
			additionalInfoBasePage.fillOutAdditionalInfoPageHomeLob(applicant, true);
		} else {
			AceHRCAboutYouBasePage aboutYouPage = navigateToHRCAboutYouPage(applicant, lob, propertyType);
			aboutYouPage.fillOutTheDataInAboutYouPage(applicant, true);
		}
		waitForSpinnerToBeGone();
		if (contactInfoPage.isOnContactInfoPage(true)) {
			if (isADATestingEnabled()) {
				contactInfoPage.validateADA(FFQ_ACE_HOME);
			}
			Reporter.pass("Navigated to AceHomeContactInfoPage");
			return contactInfoPage;
		} else {
			int retries = 3;
			while (isTryAgainPagePresent() && wasTryAgainSuccessful() && retries>0) {
				if (applicant.isNewlyOwned()) {
					enterCurrentOrPriorAddress(applicant);
				}
				retries--;
				clickContinueButton();
			}
			if (contactInfoPage.isOnContactInfoPage(false)) {
				Reporter.pass("Navigated to AceHomeContactInfoPage");
				return contactInfoPage;
			}
			reportKnockout();
			throw new IllegalStateException(DID_NOT_REACH + "ContactInfoPage");
		}
	}
}


