package com.farmers.ffq.common.pages;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.DecimalFormat;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class PaymentSelectionBasePage extends AutoBasePage {
    protected static final String BANK_PAYMENT = "Bank payment";
    public static final String CARD = "Card";
    public static final String PAY_IN_FULL = "Pay in full";
    public static final String MONTHLY_AUTOPAY = "Monthly Autopay";
    public static final String PAY_IN_FULL_BANK_DEBIT = "Pay in full – bank or debit card";
    public static final String PAY_IN_FULL_CREDIT_CARD = "Pay in full – credit card";
    protected static final String VIEW_CREDIT_CARD_PRICE = "View credit card price";
    protected static final String TOTAL_PRICE_UPDATED = "Total price updated";
    protected static final String CREDIT_CARD = "Credit card";
    protected static final String DEBIT_CARD = "Debit card";
    protected static final String PAYMENT_METHOD = "Payment method";
    protected static final String ADD_YOUR_PREFERRED_PAYMENT_METHOD = "Add your preferred payment method.";
    protected static final String CHANGE_TO_NEW_PAYMENT_METHOD = "Change to a new payment method";
    protected static final String EDIT_PAYMENT_METHOD = "Edit payment method";
    protected static final String EXCLUDE_TAXES_TEXT= "Excludes taxes, fees, and surcharges";

    @FindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL + "')]")
    protected List<WebElement> payInFullHeader;
    protected static final String HOW_WOULD_YOU_LIKE_TO_PAY = "How would you like to pay?";
    @FindBy(xpath = "//h1[contains(text(), '" + HOW_WOULD_YOU_LIKE_TO_PAY + "')]")
    protected WebElement howWouldYouLikeToPay;
    @FindBy(xpath = "//app-payment-consolidated//h1")
    protected WebElement consolidatedPaymentPageHeader;
    @FindBy(xpath = "//app-payment-overview//h1")
    protected WebElement consolidatedPaymentPageHeaderBw;
    protected static final String BEST_VALUE_SUBHEADER = "Best value";
    @FindBy(xpath = "//p[contains(text(), '" + BEST_VALUE_SUBHEADER + "')]")
    protected List<WebElement> bestValueSubHeader;
    protected static final String ONE_TIME_PAYMENT = "One-time payment";
    @FindBy(xpath = "//p[contains(text(), '" + ONE_TIME_PAYMENT + "')]")
    protected List<WebElement> oneTimePaymentSubHeader;

    protected static final String SELECT_SETUP_PAYMENT = "Select & set up payment";
    @FindBy(xpath = "//mat-tab-group//button[contains(text(), '" + SELECT_SETUP_PAYMENT + "')]")
    protected WebElement selectAndSetUpPayment;

    @FindBy(xpath = "//*[contains(@class,'disclaimers-charge-text')]")
    protected WebElement disclaimerChargeText;

    // Preferred payment plan savings
    protected static final String PREFERRED_PAYMENT_PLAN_SAVINGS = "Preferred payment plan savings";
    @FindBy(xpath = "//p[contains(text(), '" + PREFERRED_PAYMENT_PLAN_SAVINGS + "')]")
    protected List<WebElement> preferredPayPlanSavings;


    private static final String PAYMENTUS_MANAGE_PAYMENT = "Paymentus Manage Payments";
    @FindBy(xpath = "//iframe[@title = '" + PAYMENTUS_MANAGE_PAYMENT + "']")
    private WebElement paymentUsIframe;

    //No service charge
    protected static final String NO_SERVICE_CHARGE = "No service charge";
    @FindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL +"')]/ancestor::mat-card//p[contains(text(),'" + NO_SERVICE_CHARGE + "')]")
    protected List<WebElement> noServiceChargeWhenPayInFull;

    @FindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL +"')]/ancestor::mat-card//p[contains(text(),'" + EXCLUDE_TAXES_TEXT + "')]")
    protected List<WebElement> excludeFeesSurchargePayInFull;

    @FindBy(xpath = "//h2[contains(text(), '" + PAY_IN_FULL +"')]/ancestor::mat-card//p[contains(text(),'" + INCLUDES_ALL_FEES + "')]")
    protected List<WebElement> includeAllFeesPayInFull;

    protected static final String BANK_DEBIT_CREDIT_PAYMENT = "Bank payment, debit card, or credit card";
    @FindBy(xpath = "//p[contains(text(), '" + BANK_DEBIT_CREDIT_PAYMENT + "')]")
    protected List<WebElement> bankDebitCreditCardPayment;

    protected static final String MONTHLY_AUTO_PAY_BANK_HEADER = "Monthly autopay - bank";
    protected static final String MONTHLY_AUTO_PAY_CARD_HEADER = "Monthly autopay - card";
    public static final String MONTHLY_DIRECT_BILL = "Monthly - direct bill";
    public static final String MONTHLY_DIRECT_BILL_PARENTHESIS = "Monthly (direct bill)";

    protected static final String MONTHLY_PAY_BANK_HEADER = "Monthly - bank";
    protected static final String MONTHLY_PAY_CARD_HEADER = "Monthly - card";

    @FindBy(xpath = "//h2[contains(text(), '" + MONTHLY_AUTO_PAY_BANK_HEADER + "')]")
    protected List<WebElement> payInMonthlyPayBankHeader;

    protected static final String CONVENIENT = "Convenient";
    @FindBy(xpath = "//p[contains(text(), '" + CONVENIENT + "')]")
    protected WebElement convenientHeader;

    protected static final String AUTO_PAY_SAVINGS_TEXT = "Autopay savings";
    protected String AUTO_PAY_SAVINGS_XPATH = "//p[contains(@class,'payment-overview-icon-padding')]";
    protected String AUTO_PAY_SAVINGS_XPATH_GREEN_CHECKMARK = "//mat-icon[contains(@class,'payment-overview-green-mark')]";
    protected static final String DOWN_PAYMENT_XPATH = "//div[@class='tui-payplan']";
    protected static final String TOTAL_PAYMENT_OVERVIEW_CARD_PREMIUM_XPATH = "//div[contains(@class,'payment-overview-card-premium-font')]";

    protected static final String MONTHLY_SERVICE_CHARGE = "Monthly service charge:";
    protected static final String INCLUDES_ALL_FEES = "(includes all fees)";
    @FindBy(xpath = "//p[contains(text(), '" + INCLUDES_ALL_FEES + "')]")
    protected WebElement includedAllFeesLabel;

    protected static final String CHANGE_LINK = "Change";
    @FindBy(xpath = "//a[contains(text(), '" + CHANGE_LINK + "')]")
    protected WebElement changeLink;
    private static final String BANK_OF_AMERICA = "BANK OF AMERICA, N.A. SFNB";
    @FindBy(xpath = "//span[@class='pm-display-bank-name bank-found']")
    private WebElement bankNameLabel;
    private static final String BANK_PAYMENT_ACCOUNT_ADDED = "Bank payment account added.";
    @FindBy(xpath = "//span[text() = '" + BANK_PAYMENT_ACCOUNT_ADDED + "']")
    private WebElement bankPaymentAddedMessage;

    @FindBy(xpath = "//i[@class='tui-icon tui-icon-generic-payment ng-star-inserted']")
    private WebElement bankIcon;

    private static final String SAVING_LABEL = "Savings";
    @FindBy(xpath = "//label[text() = '" + SAVING_LABEL + "']")
    private WebElement savingsLabel;

    private static final String BUSINESS_CHECKING_LABEL = "Business Checking";
    @FindBy(xpath = "//label[text() = '" + BUSINESS_CHECKING_LABEL + "']")
    private WebElement businessCheckingLabel;

    // paymentus iframe locators
    @FindBy(xpath = "//*[@aria-label='Edit payment method' and not(@role='dialog')]")
    protected WebElement paymentusIframeHeader;
    protected static final String BANK_PAYMENT_TOGGLE_BUTTON_TITLE = "Bank payment";
    @FindBy(xpath = "//div[@role='tab'][contains(.,'" + BANK_PAYMENT_TOGGLE_BUTTON_TITLE + "')]")
    protected WebElement paymentusBankPaymentToggle;
    @FindBy(xpath = "//div[@role='tab'][contains(.,'" + BANK_PAYMENT_TOGGLE_BUTTON_TITLE + "')]/span")
    protected WebElement paymentusBankPaymentToggleButton;
    protected static final String DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE = "Debit / Credit card";
    @FindBy(xpath = "//div[@role='tab'][contains(.,'" + DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE + "')]")
    protected WebElement paymentusDebitCreditCardToggle;
    @FindBy(xpath = "//div[@role='tab'][contains(.,'" + DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE + "')]/div")
    protected WebElement paymentusDebitCreditCardToggleButton;
    @FindBy(xpath = "//legend")
    protected WebElement paymentusBankAccountTypeHeader;
    @FindBy(xpath = "//fieldset//input[@id='checking']")
    protected WebElement paymentusCheckingAccountRadioButton;
    @FindBy(xpath = "//fieldset//input[@id='savings']")
    protected WebElement paymentusSavingsAccountRadioButton;
    @FindBy(xpath = "//fieldset//input[@id='busChecking']")
    protected WebElement paymentusBusinessCheckingAccountRadioButton;
    @FindBy(xpath = "//fieldset//label[@for='busChecking']")
    protected WebElement paymentusCheckingAccountLabel;
    @FindBy(xpath = "//fieldset//label[@for='savings']")
    protected WebElement paymentusSavingsAccountLabel;
    @FindBy(xpath = "//fieldset//label[@for='busChecking']")
    protected WebElement paymentusBusinessCheckingAccountLabel;
    @FindBy(xpath = "//input[@id='accountHolderField']")  // @id='cardHolderField'
    protected WebElement paymentusAccountHolderInput;
    @FindBy(xpath = "//span[contains(@class,'pm-display-logo-visa')]")
    private WebElement visaCardIcon;
    @FindBy(xpath = "//input[@id='cardNumberField']")
    private WebElement cardNumberInputField;
    @FindBy(xpath = "//span[contains(@class,'pm-display-logo-mc')]")
    private WebElement masterCardIcon;
    @FindBy(xpath = "//span[contains(@class,'pm-display-logo-disc')]")
    private WebElement discoverCardIcon;
    @FindBy(xpath = "//span[contains(@class,'pm-display-logo-amex')]")
    private WebElement amexCardIcon;

    @FindBy(xpath = "//label[@for='accountHolderField']")
    protected WebElement paymentusAccountHolderLabel;
    @FindBy(xpath = "//input[@id='cardHolderField']")
    protected WebElement paymentusCardHolderInput;
    @FindBy(xpath = "//label[@for='cardHolderField']")
    protected WebElement paymentusCardHolderLabel;
    @FindBy(xpath = "//input[@id='routingNumberField']")
    protected WebElement paymentusRoutingNumberInput;
    @FindBy(xpath = "//label[@for='routingNumberField']")
    protected WebElement paymentusRoutingNumberLabel;
    @FindBy(xpath = "//input[@id='cardNumberField']")
    protected WebElement paymentusCardNumberInput;
    @FindBy(xpath = "//label[@for='cardNumberField']")
    protected WebElement paymentusCardNumberLabel;
    @FindBy(xpath = "//div[contains(@class,'methodVisa')]")
    protected WebElement paymentusVisaCardIcon;
    @FindBy(xpath = "//div[contains(@class,'methodMastercard')]")
    protected WebElement paymentusMasterCardIcon;
    @FindBy(xpath = "//div[contains(@class,'methodDiscover')]")
    protected WebElement paymentusDiscoverCardIcon;
    @FindBy(xpath = "//div[contains(@class,'methodAmex')]")
    protected WebElement paymentusAmexCardIcon;
    @FindBy(xpath = "//input[@id='bankAccountField']")
    protected WebElement paymentusAccountNumberInput;
    @FindBy(xpath = "//label[@for='bankAccountField']")
    protected WebElement paymentusAccountNumberLabel;
    @FindBy(xpath = "//input[@id='ccExpirationDate']")
    protected WebElement paymentusCardExpirationDateInput;
    @FindBy(xpath = "//label[@for='ccExpirationDate']")
    protected WebElement paymentusCardExpirationDateLabel;
    @FindBy(xpath = "//input[@id='cardCVVField']")
    protected WebElement paymentusCardCVVFieldInput;
    @FindBy(xpath = "//label[@for='cardCVVField']")
    protected WebElement paymentusCardCVVFieldLabel;
    @FindBy(xpath = "//input[@id='zipCode']")
    protected WebElement paymentusZipCodeInput;
    @FindBy(xpath = "//label[@for='zipCode']")
    protected WebElement paymentusZipCodeLabel;
    @FindBy(xpath = "//input[@id='confirmBankAccountField']")
    protected WebElement paymentusConfirmAccountNumberInput;
    @FindBy(xpath = "//label[@for='confirmBankAccountField']")
    protected WebElement paymentusConfirmAccountNumberLabel;
    @FindBy(xpath = "//button[@name='submitBtn']")
    protected WebElement paymentusAddButton;
    @FindBy(xpath = "//a[contains(.,'Change')]")
    protected WebElement changePaymentMethodLink;

    private static final String ENTER_VALID_ACCOUNT_HOLDER_NAME_ERROR = "Please enter a valid account holder name.";
    @FindBy(xpath = "//span[text() = '" + ENTER_VALID_ACCOUNT_HOLDER_NAME_ERROR + "']")
    private WebElement enterValidAccountHolderNameError;

    private static final String ENTER_VALID_ROUTING_NUMBER_ERROR = "Please enter a valid routing number.";
    @FindBy(xpath = "//span[text() = '" + ENTER_VALID_ROUTING_NUMBER_ERROR + "']")
    private WebElement enterValidRoutingNumberError;

    private static final String ENTER_VALID_ACCOUNT_NUMBER_ERROR = "Please enter a valid bank account number.";
    @FindBy(xpath = "//span[text() = '" + ENTER_VALID_ACCOUNT_NUMBER_ERROR + "']")
    private WebElement enterValidAccountNumberError;

    private static final String BANK_ACCOUNT_NUMBERS_DO_NOT_MATCH_ERROR = "The bank account numbers do not match. Please re-enter your bank account number.";
    @FindBy(xpath = "//span[text() = '" + BANK_ACCOUNT_NUMBERS_DO_NOT_MATCH_ERROR + "']")
    private WebElement bankAccountNumbersDoNotMatchError;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public PaymentSelectionBasePage() throws Exception {
    }

    public String getDownPayment(AppStore appStore, String payPlanDescription) throws Exception {
        List<AppStore.VerifyResponse.PaymentSchedule> monthlyEffectivePayPlan = filterListOfPaymentScheduleByPayPlan(appStore.getVerifyResponse().getPaymentSchedules(), payPlanDescription);
        return monthlyEffectivePayPlan.get(0).getDownPayment().getAmount().getAmount();
    }

    protected String getInstallmentAmountFarmers(String paymentMethod) throws Exception {
        if (paymentMethod.equals(PAY_IN_FULL)) {
            return getFullTermPremiumAmountFarmers(paymentMethod);
        }
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPayPlanCode().equals(convertPaymentMethodToPayPlanCodeFarmers(paymentMethod))).findFirst().get().getInstallments().get(0).getCurrencyAmount();
    }

    protected String getInstallmentAmountBw(String paymentMethod) throws Exception {
        if (paymentMethod.equals(PAY_IN_FULL)) {
            return getFullTermPremiumAmountBW(paymentMethod);
        }
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPaymentMethod().equals(convertPaymentMethodToPayPlanCodeBW(paymentMethod))).findFirst().get().getInstallmentAmount();
    }

    protected String getFullTermPremiumAmountFarmers(String paymentMethod) throws Exception {
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPaymentMethod().equals(convertPaymentMethodToPayPlanCodeFarmers(paymentMethod))).findFirst().get().getFullTermPremium();
    }

    protected String getFullTermPremiumAmountBW(String paymentMethod) throws Exception {
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPaymentMethod().equals(convertPaymentMethodToPayPlanCodeBW(paymentMethod))).findFirst().get().getFullTermPremium();
    }

    public String convertPaymentMethodToPayPlanCodeBW(String paymentMethod) {
        switch (paymentMethod) {
            case PAY_IN_FULL:
                return "PIF";
            case MONTHLY_AUTO_PAY_BANK_HEADER:
                return "EFTB";
            case MONTHLY_AUTO_PAY_CARD_HEADER:
                return "EFTC";
            case MONTHLY_DIRECT_BILL:
                return "NON";
            case MONTHLY_AUTOPAY:
                return "MTEF";
            default:
                Log.error("Please provide acceptable payment method");
                return null;
        }
    }

    public String convertPaymentMethodToPayPlanCodeFarmers(String paymentMethod) {
        switch (paymentMethod) {
            case PAY_IN_FULL:
                return "A1";
            case MONTHLY_AUTO_PAY_BANK_HEADER:
            case MONTHLY_EFT:
                return "MTEF";
            case MONTHLY_AUTO_PAY_CARD_HEADER:
                return "MTPC";
            case MONTHLY_AUTOPAY:
            case MONTHLY_DEBIT_CARD_DESCRIPTION:
                return "MTPD";
            default:
                Log.error("Please provide acceptable payment method");
                return null;
        }
    }

    public List<AppStore.VerifyResponse.PaymentSchedule> filterListOfPaymentScheduleByPayPlan(List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules, String payPlanDescription){
        System.out.println("Payment schedules " + paymentSchedules);
        return  paymentSchedules.stream().filter(c -> c.getPayPlanDescription().equals(payPlanDescription)).collect(Collectors.toList());
    }

    public Double doublePolicyFeeAmount(String policyFee){
        Double doublePolicyFees = 0.0;
        if(!policyFee.equals("")){
            doublePolicyFees = Double.parseDouble(policyFee);
        }
        return doublePolicyFees;
    }

    public List<String> splitAmountByDecimalPoint(String fullAmount){
        String[] splitAmountByDecimalPoint = fullAmount.split("\\.");

        List<String> splittedAmountList = null;
        if(splitAmountByDecimalPoint.length == 2){
            splittedAmountList = Arrays.asList(splitAmountByDecimalPoint[0], splitAmountByDecimalPoint[1]);
        }else{
            splittedAmountList = Arrays.asList(splitAmountByDecimalPoint[0]);
        }
        return splittedAmountList;
    }
    public List<WebElement> listOfFullAmountWebElements(String amount, String htmlElement, boolean isCurrencyFormat) throws Exception {
        String currencyFormatAmount = CurrencyFormat.convertStringIntoCurrencyFormat(amount);
        String amountOnePayXpath = "";
        if(isCurrencyFormat){
            amountOnePayXpath  = "//" + htmlElement + "[contains(text(), '" + currencyFormatAmount + "')]";
        }else{
            amountOnePayXpath  = "//" + htmlElement + "[contains(text(), '" + String.format("%,d", Integer.parseInt(amount)) + "')]";
        }

        return driver().findElements(By.xpath(amountOnePayXpath));
    }

    public void isElementListSizeGreaterThanZero(List<WebElement> elementList, String message, FarmersSoftAssert fsa){
        fsa.assertTrue(!elementList.isEmpty(), message);
    }

    protected WebElement getPaymentCardSubHeaderByGivenPayMethod(String payMethod) throws Exception {
        return driver().findElement(By.xpath(getPaymentCardXPathByGivenPayMethod(payMethod) + "//div[contains(@class,'tui-presentment-card-header-row-1')]//p"));
    }

    protected String getPaymentCardXPathByGivenPayMethod(String payMethod) {
        return String.format("//mat-card[contains(.,'%s')]", payMethod);
    }

    public int getAdministrativeFeeForGivenPayPlanDescription(List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules, String payPlanDescription) {
        AppStore.VerifyResponse.PaymentSchedule paymentSchedule = filterListOfPaymentScheduleByPayPlan(paymentSchedules, payPlanDescription).stream().findFirst().get();
        String currencyAmount = paymentSchedule.getAdministrativeCharges().getCurrencyAmount();
        return (int) Double.parseDouble(currencyAmount);
    }

    public String getFormattedDecimal(double number) {
        DecimalFormat decimalFormat = new DecimalFormat("#,###.00");
        return decimalFormat.format(number);
    }


    public void addCardPaymentMethod(String cardNumber, String zipCode) throws Exception {
        clickPaymentusIframeCardToggle();
        switchToPaymentUsIframe();
        String cvv = cardNumber.equals(AMERICAN_EXPRESS_CARD) ? "1234" : CVV_NUMBER;
        enterCardNumber(cardNumber);
        Log.info("Card number has been entered: " + cardNumber);

        if (isSafariBrowser()) {
            JavascriptExecutor js = driver();
            js.executeScript(String.format("arguments[0].value='%s';", EXP_DATE), paymentusCardExpirationDateInput);
        } else {
            enterExpDate(EXP_DATE);
        }

        Log.info("Exp date has been entered: " + EXP_DATE);
        sendKeysToElement(waitElementBeVisible(paymentusCardCVVFieldInput), cvv);
        Log.info("Cvv has been entered: " + cvv);
        sendKeysToElement(waitElementBeVisible(paymentusZipCodeInput), zipCode);
        Log.info("Zipcode has been entered: " + zipCode);
        waitAndClickElement(paymentusAddButton);
        switchToParentWindow();
        waitForSpinnerToBeGone();
    }

    private void clickPaymentusIframeCardToggle() {
        if (isElementDisplayed(paymentusDebitCreditCardToggle, 5)) {
            int retry = 3;
            while (!getAttributeData(paymentusDebitCreditCardToggle, ARIA_SELECTED).equals(LOWERCASE_TRUE) && retry > 0) {
                waitAndClickElement(paymentusDebitCreditCardToggleButton);
                retry--;
                sleep(1);
            }
        }
    }

    public void addCheckingAccountPaymentMethod(String routingNumber, String accountNumber) throws Exception {
        switchToPaymentUsIframe();
        enterRoutingNumber(routingNumber);
        Log.info("Routing Number has been entered: " + routingNumber);
        enterAccountNumber(accountNumber);
        Log.info("Account Number has been entered: " + accountNumber);
        sendKeysToElement(waitElementBeVisible(paymentusConfirmAccountNumberInput), accountNumber);
        waitAndClickElement(paymentusAddButton);
        switchToParentWindow();
        waitForSpinnerToBeGone();
    }

    public void switchToPaymentUsIframe() throws Exception {
        waitElementBeVisible(paymentUsIframe);
        driver().switchTo().frame(paymentUsIframe);
        wait.until(ExpectedConditions.elementToBeClickable(paymentusAddButton));
    }

    public void isDisclaimerChargeTextCorrect(FarmersSoftAssert fsa, String expectedChargeMessage) {
        fsa.assertEquals(getTextFromElement(disclaimerChargeText), expectedChargeMessage, "Payment method charge disclaimer text validation");
    }

    public void enterCardNumber(String cardNumber){
        sendKeysToElement(waitElementBeVisible(paymentusCardNumberInput), cardNumber);
    }

    public void enterExpDate(String expDate){
        sendKeysToElement(waitElementBeVisible(paymentusCardExpirationDateInput), expDate);
    }

    public void enterRoutingNumber(String routingNumber){
        sendKeysToElement(waitElementBeVisible(paymentusRoutingNumberInput), routingNumber);
    }

    public void enterAccountNumber(String accountNumber){
        sendKeysToElement(waitElementBeVisible(paymentusAccountNumberInput), accountNumber);
    }

    public boolean isEditPaymentMethodLabelCorrect(){
        wait.until(ExpectedConditions.visibilityOf(paymentusIframeHeader));
        return isExpectedTextDisplayed(paymentusIframeHeader, EDIT_PAYMENT_METHOD);
    }

    public void clickChangeLink(){
        waitAndClickElement(changeLink);
    }

    public boolean isBOFABankNameLabelCorrect(){
        wait.until(ExpectedConditions.visibilityOf(bankNameLabel));
        return isExpectedTextDisplayed(bankNameLabel, BANK_OF_AMERICA);
    }

    public boolean isBankPaymentAccountAddedMsgCorrect() throws Exception {
        driver().switchTo().defaultContent();
        wait.until(ExpectedConditions.visibilityOf(bankPaymentAddedMessage));
        sleep(3);
        return isExpectedTextDisplayed(bankPaymentAddedMessage, BANK_PAYMENT_ACCOUNT_ADDED);
    }

    public boolean isBankIconDisplayed(){
        wait.until(ExpectedConditions.visibilityOf(bankIcon));
        return bankIcon.isDisplayed();
    }

    public void clickSavingsRadioButton(){
        waitAndClickElement(savingsLabel);
    }


    public void clickBusinessCheckingRadioButton(){
        waitAndClickElement(businessCheckingLabel);
    }

    public boolean isSavingsLabelCorrect(){
        return isExpectedTextDisplayed(savingsLabel, SAVING_LABEL);
    }

    public boolean isBusinessCheckingLabelCorrect(){
        return isExpectedTextDisplayed(businessCheckingLabel, BUSINESS_CHECKING_LABEL);
    }

    public void clearOutAccountHolderInputField(){
        paymentusAccountHolderInput.clear();
    }
    public boolean isEnterValidAccountHolderNameErrorCorrect(){
        wait.until(ExpectedConditions.visibilityOf(enterValidAccountHolderNameError));
        return isExpectedTextDisplayed(enterValidAccountHolderNameError, ENTER_VALID_ACCOUNT_HOLDER_NAME_ERROR);
    }

    public boolean isEnterValidRoutingNumberErrorCorrect(){
        wait.until(ExpectedConditions.visibilityOf(enterValidRoutingNumberError));
        return isExpectedTextDisplayed(enterValidRoutingNumberError, ENTER_VALID_ROUTING_NUMBER_ERROR);
    }

    public boolean isEnterValidBankAccountNumberErrorCorrect(){
        return isExpectedTextDisplayed(enterValidAccountNumberError, ENTER_VALID_ACCOUNT_NUMBER_ERROR);
    }

    public boolean isBankAccountNumbersNotMatchingErrorCorrect(){
        return isExpectedTextDisplayed(bankAccountNumbersDoNotMatchError, BANK_ACCOUNT_NUMBERS_DO_NOT_MATCH_ERROR);
    }

    public boolean isAccountHolderNameMatching(String fullName){
        String accountHolderNameFromInputField = getAttributeData(paymentusAccountHolderInput, VALUE);
        boolean isAccountHolderNameMatching = fullName.equals(accountHolderNameFromInputField);
        return isAccountHolderNameMatching;
    }

    public boolean isVisaCardIconDisplayed(){
        return visaCardIcon.isDisplayed();
    }

    public void clearOutCardNumberInputField(){
        waitAndClickElement(cardNumberInputField);
        cardNumberInputField.clear();
    }

    public boolean isMasterCardIconDisplayed(){
        return masterCardIcon.isDisplayed();
    }

    public boolean isDiscoverCardIconDisplayed(){
        return discoverCardIcon.isDisplayed();
    }

    public boolean isAmexCardIconDisplayed(){
        return amexCardIcon.isDisplayed();
    }

    // Reusable helper for Save Card popup
    protected void dismissSaveCardPopupIfPresent() throws Exception {
        By saveCardModal = By.xpath("//div[contains(.,'Save card?')]");
        By noThanksBtn = By.xpath("//button[normalize-space()='No thanks']");
        By closeBtn = By.xpath("//div[contains(.,'Save card?')]//button[normalize-space()='×' or normalize-space()='x' or @aria-label='Close']");

        try {
            // Short wait so we don't slow tests when popup is not displayed
            WebDriverWait shortWait = new WebDriverWait(driver(), Duration.ofSeconds(3));
            shortWait.until(ExpectedConditions.visibilityOfElementLocated(saveCardModal));

            // Prefer "No thanks"; fallback to close icon
            List<WebElement> noThanks = driver().findElements(noThanksBtn);
            if (!noThanks.isEmpty() && noThanks.get(0).isDisplayed()) {
                noThanks.get(0).click();
            } else {
                List<WebElement> close = driver().findElements(closeBtn);
                if (!close.isEmpty() && close.get(0).isDisplayed()) {
                    close.get(0).click();
                }
            }

            // Optional: wait for modal to disappear
            shortWait.until(ExpectedConditions.invisibilityOfElementLocated(saveCardModal));
        } catch (TimeoutException ignored) {
            // Popup did not appear; continue test
        }
    }

    public AppStore.VerifyResponse getAutoVerifyRateResponse() throws Exception {
        return getSessionStorageAppStore().getAuto().getVerifyResponse();
    }

}
