package com.farmers.ffq.home.pages;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.ApplicantHome;
import com.farmers.ffq.utils.FarmersSoftAssert;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.farmers.ffq.utils.GlobalVariables.FOOTER_DISCLAIMER_STATIC_TEXT;
import static com.farmers.ffq.utils.GlobalVariables.MAX_OLD_AGE;

/**
 * Farmers Fast Quote (FFQ) - Thank You Page - Home.
 *
 *
 */

public class ThankYouPage extends BasePage {

	@FindBy(id = "PolicyIntro")
	private WebElement headerText;

	@FindBy(xpath = "//span[contains(@id,'nextStep')]")
	private WebElement nextStepsStaticText;

	@FindBy(xpath = "//div[@class='homeprmHeading']/span[contains(@id, 'buypolicyHome')]/b")
	private WebElement premiumAmountCongratText;

	@FindBy(xpath = "//*[@id='Content']/div[3]/div[1]/p")
	private WebElement quoteNumber;

	@FindBy(xpath = "//input[contains(@value,'PRINT')]")
	private WebElement printQuoteButton;

	@FindBy(xpath = "//input[contains(@value,'EMAIL')]")
	private WebElement emailQuoteButton;

	@FindBy(xpath = "//*[@id='congratzHomeThankyou']/table[3]/tbody/tr[1]/td[2]")
	private WebElement coverageAmount;

	@FindBy(id = "buypolicyHome:startQuoteDesktop")
	private WebElement startQuoteButton;

	@FindBy(id = "homeAgentDisclaimer")
	private WebElement footerDisclaimerStaticText;

	@FindBy(xpath = "//*[@id='buypolicyHome:HomePolicyWay']/tbody/tr[1]/td/span")
	private WebElement qualifyMultiPolicyStaticText;

	@FindBy(xpath = "//*[@id='buypolicyHome:HomePolicyWay']/tbody/tr[1]/td/div[1]")
	private WebElement willHelpYouSaveStaticText;

	@FindBy(id = "buypolicyHome:quoteType")
	private WebElement crossSellDropDown;

	@FindBy(id = "buypolicyHome:startQuoteDesktop")
	private WebElement startCrossSellQuoteButton;

	@FindBy(xpath = "//*[@id='congratzHomeThankyou']/div[1]/table/tbody/tr/td/p")
	private WebElement lobText;

	@FindBy(css = "#homeAgentList") // .homeAgentListInfo
	private WebElement agentInfo;

	@FindBy(css = "#PolicyIntro>p")
	private WebElement yourFarmersAgentStaticText;

	@FindBy(css = ".homethankYouDisclaimer>small")
	private WebElement futurePaymentsStaticText;

	@FindBy(xpath = "//*[@id='congratzHomeThankyou']/div[1]/table/tbody/tr/td/span")
	private WebElement monthlyPaymentsStaticText;

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public ThankYouPage() throws Exception {
		// Nothing required
	}

	public void verifyThankYouPageContent(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		waitElementBeVisibleClickable(printQuoteButton);
		fsa.assertEquals(getTextFromElement(yourFarmersAgentStaticText), "Thank you for completing your quote", "Your Farmers agent static text check");
		fsa.assertTrue(agentInfo.isDisplayed(), "Agent info displayed");
		fsa.assertEquals(getTextFromElement(footerDisclaimerStaticText), FOOTER_DISCLAIMER_STATIC_TEXT, "Footer Disclaimer Static Text check");
		fsa.assertTrue(getTextFromElement(monthlyPaymentsStaticText).contains("monthly automatic*"), "\"monthly automatic*\" is displayed");
		fsa.assertEquals("* Future payments will be automatically withdrawn from your bank/credit account", getTextFromElement(futurePaymentsStaticText), "Future payments static text check");
		fsa.assertTrue(getTextFromElement(headerText).contains("Your Farmers agent is currently reviewing your quote, maximizing your coverage, and searching for more discounts."), "Header text check");
		fsa.assertTrue(premiumAmountCongratText.isDisplayed(), "\"Congratulations, your estimated policy premium is:\" displayed");
		fsa.assertTrue(driver().getPageSource().contains(applicant.getLineOfBusiness()), "Applicant LOB displayed");
		fsa.assertTrue(quoteNumber.isDisplayed(), "Quote number displayed ");
		fsa.assertTrue(emailQuoteButton.isDisplayed() && emailQuoteButton.isEnabled(), "\"Email Quote\" button displayed");
		fsa.assertTrue(printQuoteButton.isDisplayed() && printQuoteButton.isEnabled(), "\"Print Quote\" button displayed");
		if (applicant.getAge() < MAX_OLD_AGE) {
			fsa.assertEquals(getTextFromElement(qualifyMultiPolicyStaticText), "Do you qualify for a multi-policy discount?", "Do You qualifyFor multi-policy discount static text check");
			fsa.assertEquals(getTextFromElement(willHelpYouSaveStaticText), "Find out if adding new coverage will help you save", "Find out if adding new coverage will help you save static text check");
			fsa.assertTrue(startQuoteButton.isDisplayed() && startQuoteButton.isEnabled(), "\"Start Quote\" button displayed");
			fsa.assertTrue(crossSellDropDown.isDisplayed() && crossSellDropDown.isEnabled(), "Drop down for cross sell displayed");
		}
	}

	public void startCrossSellQuote(String quoteType) {
		closeSurveyDialog();
		selectFromDropDown(crossSellDropDown, quoteType);
		clickElement(startCrossSellQuoteButton);
		waitForSpinnerToBeGone();
		waitForLegacySpinnerToBeGone();
	}

}
